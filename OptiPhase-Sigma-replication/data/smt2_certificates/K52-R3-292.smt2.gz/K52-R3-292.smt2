; OptiPhase-Sigma refinement certificate for sweep K52-R3-292
; query 0: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x320 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x87 (or false false false)))
(let (($x254 (not $x87)))
(and $x254 (or $x87 (and (distinct ?x320 ?x320) true)))))))
(check-sat)
; query 1: function s162, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x22 (ite (bvslt (_ bv0 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x87 (or false false false)))
(let (($x254 (not $x87)))
(and $x254 (or $x87 (and (distinct ?x22 ?x22) true)))))))
(check-sat)
; query 2: function set1d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x282 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x87 (or false false false)))
(let (($x254 (not $x87)))
(and $x254 (or $x87 (and (distinct ?x282 ?x282) true)))))))
(check-sat)
; query 3: function set1ds, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x232 (ite (= (_ bv4294967295 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x87 (or false false false)))
(let (($x254 (not $x87)))
(and $x254 (or $x87 (and (distinct ?x232 ?x232) true)))))))
(check-sat)
; query 4: function set2d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x282 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x87 (or false false false)))
(let (($x254 (not $x87)))
(and $x254 (or $x87 (and (distinct ?x282 ?x282) true)))))))
(check-sat)
