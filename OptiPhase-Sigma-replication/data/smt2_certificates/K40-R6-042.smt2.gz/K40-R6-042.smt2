; OptiPhase-Sigma refinement certificate for sweep K40-R6-042
; query 0: function set_key, block 11, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let (($x85 (or false false false)))
(let (($x68 (not $x85)))
(and $x68 (or $x85 (and (distinct (bvand in2_32 (_ bv1 32)) (bvand in2_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function set_key, block 11, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x198 (ite (and (distinct (_ bv0 32) (bvand in2_32 (_ bv1 32))) true) (_ bv1 1) (_ bv0 1))))
(let (($x85 (or false false false)))
(let (($x55 (or $x85 false false)))
(let (($x27 (not $x55)))
(and $x27 (or $x55 (and (distinct ?x198 ?x198) true))))))))
(check-sat)
; query 2: function set_key, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let (($x85 (or false false false)))
(let (($x68 (not $x85)))
(and $x68 (or $x85 (and (distinct (bvand in2_32 (_ bv2 32)) (bvand in2_32 (_ bv2 32))) true))))))
(check-sat)
; query 3: function set_key, block 14, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x144 (ite (and (distinct (_ bv0 32) (bvand in2_32 (_ bv2 32))) true) (_ bv1 1) (_ bv0 1))))
(let (($x85 (or false false false)))
(let (($x55 (or $x85 false false)))
(let (($x27 (not $x55)))
(and $x27 (or $x55 (and (distinct ?x144 ?x144) true))))))))
(check-sat)
; query 4: function set_key, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x488 (ite (and (distinct (_ bv0 64) in1_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x85 (or false false false)))
(let (($x68 (not $x85)))
(and $x68 (or $x85 (and (distinct ?x488 ?x488) true)))))))
(check-sat)
; query 5: function set_key, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x368 (ite (bvult in1_64 (_ bv16 64)) (_ bv1 1) (_ bv0 1))))
(let (($x85 (or false false false)))
(let (($x68 (not $x85)))
(and $x68 (or $x85 (and (distinct ?x368 ?x368) true)))))))
(check-sat)
; query 6: function set_key, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x626 (ite (bvugt in1_64 (_ bv32 64)) (_ bv1 1) (_ bv0 1))))
(let (($x85 (or false false false)))
(let (($x68 (not $x85)))
(and $x68 (or $x85 (and (distinct ?x626 ?x626) true)))))))
(check-sat)
; query 7: function set_key, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let (($x85 (or false false false)))
(let (($x68 (not $x85)))
(and $x68 (or $x85 (and (distinct (bvand in1_64 (_ bv7 64)) (bvand in1_64 (_ bv7 64))) true))))))
(check-sat)
; query 8: function set_key, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x333 (ite (and (distinct (_ bv0 64) (bvand in1_64 (_ bv7 64))) true) (_ bv1 1) (_ bv0 1))))
(let (($x85 (or false false false)))
(let (($x55 (or $x85 false false)))
(let (($x27 (not $x55)))
(and $x27 (or $x55 (and (distinct ?x333 ?x333) true))))))))
(check-sat)
