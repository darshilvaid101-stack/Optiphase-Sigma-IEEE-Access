; OptiPhase-Sigma refinement certificate for sweep K32-R6-027
