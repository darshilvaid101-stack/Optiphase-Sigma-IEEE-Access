; OptiPhase-Sigma refinement certificate for sweep K33-R1-000
; query 0: function corner_draw, block 11, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x41 (ite (= (_ bv0 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x10 (or false false false)))
(let (($x130 (not $x10)))
(and $x130 (or $x10 (and (distinct ?x41 ?x41) true)))))))
(check-sat)
; query 1: function edge_draw, block 39, name %40
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x271 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x92 (or false false (or $x271))))
(and (not $x92) (or $x92 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function edge_draw, block 57, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x119 (and (distinct (bvadd ((_ sign_extend 1) in.12_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.12_32 (_ bv1 32)))) true)))
(let (($x101 (or false false (or $x119))))
(and (not $x101) (or $x101 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 3: function edge_draw, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let ((?x11 (ite (= (_ bv0 32) in4_32) (_ bv1 1) (_ bv0 1))))
(let (($x10 (or false false false)))
(let (($x130 (not $x10)))
(and $x130 (or $x10 (and (distinct ?x11 ?x11) true)))))))
(check-sat)
; query 4: function enlarge, block 106, name %107
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x46 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x110 (or false false (or $x46))))
(and (not $x110) (or $x110 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 5: function enlarge, block 158, name %159
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x75 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x22 (or false false (or $x75))))
(and (not $x22) (or $x22 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 6: function enlarge, block 161, name %162
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let (($x45 (and (distinct (bvadd ((_ sign_extend 1) in.2_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.2_32 (_ bv1 32)))) true)))
(let (($x28 (or false false (or $x45))))
(and (not $x28) (or $x28 (and (distinct (bvadd in.2_32 (_ bv1 32)) (bvadd in.2_32 (_ bv1 32))) true))))))
(check-sat)
; query 7: function enlarge, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x271 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x92 (or false false (or $x271))))
(and (not $x92) (or $x92 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function getint, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x83 (ite (bvsle (_ bv48 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x10 (or false false false)))
(let (($x130 (not $x10)))
(and $x130 (or $x10 (and (distinct ?x83 ?x83) true)))))))
(check-sat)
; query 9: function getint, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x157 (ite (bvsge (_ bv57 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x10 (or false false false)))
(let (($x130 (not $x10)))
(and $x130 (or $x10 (and (distinct ?x157 ?x157) true)))))))
(check-sat)
; query 10: function getint, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in26_32 () (_ BitVec 32))
(assert
 (let ((?x345 (ite (bvsgt (_ bv48 32) in26_32) (_ bv1 1) (_ bv0 1))))
(let (($x10 (or false false false)))
(let (($x130 (not $x10)))
(and $x130 (or $x10 (and (distinct ?x345 ?x345) true)))))))
(check-sat)
; query 11: function getint, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in26_32 () (_ BitVec 32))
(assert
 (let ((?x144 (ite (bvslt (_ bv57 32) in26_32) (_ bv1 1) (_ bv0 1))))
(let (($x10 (or false false false)))
(let (($x130 (not $x10)))
(and $x130 (or $x10 (and (distinct ?x144 ?x144) true)))))))
(check-sat)
; query 12: function getint, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x293 (ite (= (_ bv4294967295 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x10 (or false false false)))
(let (($x130 (not $x10)))
(and $x130 (or $x10 (and (distinct ?x293 ?x293) true)))))))
(check-sat)
; query 13: function int_to_uchar, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_32 () (_ BitVec 32))
(assert
 (let (($x47 (and (distinct (bvadd ((_ sign_extend 1) in.03_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.03_32 (_ bv1 32)))) true)))
(let (($x15 (or false false (or $x47))))
(and (not $x15) (or $x15 (and (distinct (bvadd in.03_32 (_ bv1 32)) (bvadd in.03_32 (_ bv1 32))) true))))))
(check-sat)
; query 14: function int_to_uchar, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.14_32 () (_ BitVec 32))
(assert
 (let (($x328 (and (distinct (bvadd ((_ sign_extend 1) in.14_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.14_32 (_ bv1 32)))) true)))
(let (($x313 (or false false (or $x328))))
(and (not $x313) (or $x313 (and (distinct (bvadd in.14_32 (_ bv1 32)) (bvadd in.14_32 (_ bv1 32))) true))))))
(check-sat)
; query 15: function main, block 129, name %130
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.011.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x177 (ite (and (distinct (_ bv0 32) in.011.lcssa_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x10 (or false false false)))
(let (($x130 (not $x10)))
(and $x130 (or $x10 (and (distinct ?x177 ?x177) true)))))))
(check-sat)
; query 16: function main, block 160, name %161
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x69 (ite (and (distinct (_ bv0 32) in.01.lcssa_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x10 (or false false false)))
(let (($x130 (not $x10)))
(and $x130 (or $x10 (and (distinct ?x69 ?x69) true)))))))
(check-sat)
; query 17: function main, block 35, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x133 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x32 (or false false (or $x133))))
(and (not $x32) (or $x32 (and (distinct (bvadd in.020_32 (_ bv1 32)) (bvadd in.020_32 (_ bv1 32))) true))))))
(check-sat)
; query 18: function main, block 35, name %37
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let ((?x34 (ite (bvsge (bvadd in.020_32 (_ bv1 32)) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x133 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x32 (or false false (or $x133))))
(let (($x188 (or $x32 false false)))
(and (not $x188) (or $x188 (and (distinct ?x34 ?x34) true))))))))
(check-sat)
; query 19: function main, block 49, name %50
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x133 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x32 (or false false (or $x133))))
(and (not $x32) (or $x32 (and (distinct (bvadd in.020_32 (_ bv1 32)) (bvadd in.020_32 (_ bv1 32))) true))))))
(check-sat)
; query 20: function main, block 49, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let ((?x34 (ite (bvsge (bvadd in.020_32 (_ bv1 32)) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x133 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x32 (or false false (or $x133))))
(let (($x188 (or $x32 false false)))
(and (not $x188) (or $x188 (and (distinct ?x34 ?x34) true))))))))
(check-sat)
; query 21: function main, block 66, name %67
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x207 (ite (= (_ bv0 32) in.0.lcssa_32) (_ bv1 1) (_ bv0 1))))
(let (($x10 (or false false false)))
(let (($x130 (not $x10)))
(and $x130 (or $x10 (and (distinct ?x207 ?x207) true)))))))
(check-sat)
; query 22: function main, block 84, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.07.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x223 (ite (and (distinct (_ bv0 32) in.07.lcssa_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x10 (or false false false)))
(let (($x130 (not $x10)))
(and $x130 (or $x10 (and (distinct ?x223 ?x223) true)))))))
(check-sat)
; query 23: function median, block 103, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x75 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x22 (or false false (or $x75))))
(and (not $x22) (or $x22 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 24: function median, block 106, name %107
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x271 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x92 (or false false (or $x271))))
(and (not $x92) (or $x92 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 25: function setup_brightness_lut, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x271 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x92 (or false false (or $x271))))
(and (not $x92) (or $x92 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 26: function susan_corners, block 1066, name %1067
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x75 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x22 (or false false (or $x75))))
(and (not $x22) (or $x22 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 27: function susan_corners, block 1069, name %1070
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x271 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x92 (or false false (or $x271))))
(and (not $x92) (or $x92 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 28: function susan_corners, block 1549, name %1550
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x46 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x110 (or false false (or $x46))))
(and (not $x110) (or $x110 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 29: function susan_corners, block 1552, name %1553
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x119 (and (distinct (bvadd ((_ sign_extend 1) in.12_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.12_32 (_ bv1 32)))) true)))
(let (($x101 (or false false (or $x119))))
(and (not $x101) (or $x101 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 30: function susan_corners, block 845, name %846
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in839_32 () (_ BitVec 32))
(declare-fun in840_32 () (_ BitVec 32))
(assert
 (let ((?x366 (ite (bvslt in840_32 in839_32) (_ bv1 1) (_ bv0 1))))
(let (($x10 (or false false false)))
(let (($x130 (not $x10)))
(and $x130 (or $x10 (and (distinct ?x366 ?x366) true)))))))
(check-sat)
; query 31: function susan_corners_quick, block 1469, name %1470
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x46 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x110 (or false false (or $x46))))
(and (not $x110) (or $x110 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 32: function susan_corners_quick, block 1472, name %1473
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x119 (and (distinct (bvadd ((_ sign_extend 1) in.12_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.12_32 (_ bv1 32)))) true)))
(let (($x101 (or false false (or $x119))))
(and (not $x101) (or $x101 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 33: function susan_corners_quick, block 433, name %434
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x75 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x22 (or false false (or $x75))))
(and (not $x22) (or $x22 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 34: function susan_corners_quick, block 436, name %437
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x271 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x92 (or false false (or $x271))))
(and (not $x92) (or $x92 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 35: function susan_edges, block 1432, name %1433
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1417_32 () (_ BitVec 32))
(assert
 (let ((?x227 (ite (bvslt (_ bv0 32) in1417_32) (_ bv1 1) (_ bv0 1))))
(let (($x10 (or false false false)))
(let (($x130 (not $x10)))
(and $x130 (or $x10 (and (distinct ?x227 ?x227) true)))))))
(check-sat)
; query 36: function susan_edges, block 1486, name %1487
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.116_32 () (_ BitVec 32))
(assert
 (let (($x572 (and (distinct (bvadd ((_ sign_extend 1) in.116_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.116_32 (_ bv1 32)))) true)))
(let (($x826 (or false false (or $x572))))
(and (not $x826) (or $x826 (and (distinct (bvadd in.116_32 (_ bv1 32)) (bvadd in.116_32 (_ bv1 32))) true))))))
(check-sat)
; query 37: function susan_edges, block 1489, name %1490
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.114_32 () (_ BitVec 32))
(assert
 (let (($x734 (and (distinct (bvadd ((_ sign_extend 1) in.114_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.114_32 (_ bv1 32)))) true)))
(let (($x351 (or false false (or $x734))))
(and (not $x351) (or $x351 (and (distinct (bvadd in.114_32 (_ bv1 32)) (bvadd in.114_32 (_ bv1 32))) true))))))
(check-sat)
; query 38: function susan_edges, block 379, name %380
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.015_32 () (_ BitVec 32))
(assert
 (let (($x445 (and (distinct (bvadd ((_ sign_extend 1) in.015_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.015_32 (_ bv1 32)))) true)))
(let (($x648 (or false false (or $x445))))
(and (not $x648) (or $x648 (and (distinct (bvadd in.015_32 (_ bv1 32)) (bvadd in.015_32 (_ bv1 32))) true))))))
(check-sat)
; query 39: function susan_edges, block 382, name %383
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.013_32 () (_ BitVec 32))
(assert
 (let (($x820 (and (distinct (bvadd ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.013_32 (_ bv1 32)))) true)))
(let (($x633 (or false false (or $x820))))
(and (not $x633) (or $x633 (and (distinct (bvadd in.013_32 (_ bv1 32)) (bvadd in.013_32 (_ bv1 32))) true))))))
(check-sat)
; query 40: function susan_edges, block 850, name %851
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in834_32 () (_ BitVec 32))
(assert
 (let ((?x560 (ite (= (_ bv0 32) in834_32) (_ bv1 1) (_ bv0 1))))
(let (($x10 (or false false false)))
(let (($x130 (not $x10)))
(and $x130 (or $x10 (and (distinct ?x560 ?x560) true)))))))
(check-sat)
; query 41: function susan_edges, block 870, name %871
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x663 (ite (bvslt (_ bv0 32) in.0_32) (_ bv1 1) (_ bv0 1))))
(let (($x10 (or false false false)))
(let (($x130 (not $x10)))
(and $x130 (or $x10 (and (distinct ?x663 ?x663) true)))))))
(check-sat)
; query 42: function susan_edges_small, block 119, name %120
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.09_32 () (_ BitVec 32))
(assert
 (let (($x791 (and (distinct (bvadd ((_ sign_extend 1) in.09_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.09_32 (_ bv1 32)))) true)))
(let (($x629 (or false false (or $x791))))
(and (not $x629) (or $x629 (and (distinct (bvadd in.09_32 (_ bv1 32)) (bvadd in.09_32 (_ bv1 32))) true))))))
(check-sat)
; query 43: function susan_edges_small, block 122, name %123
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.07_32 () (_ BitVec 32))
(assert
 (let (($x571 (and (distinct (bvadd ((_ sign_extend 1) in.07_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.07_32 (_ bv1 32)))) true)))
(let (($x868 (or false false (or $x571))))
(and (not $x868) (or $x868 (and (distinct (bvadd in.07_32 (_ bv1 32)) (bvadd in.07_32 (_ bv1 32))) true))))))
(check-sat)
; query 44: function susan_edges_small, block 258, name %259
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in243_32 () (_ BitVec 32))
(assert
 (let ((?x422 (ite (= (_ bv0 32) in243_32) (_ bv1 1) (_ bv0 1))))
(let (($x10 (or false false false)))
(let (($x130 (not $x10)))
(and $x130 (or $x10 (and (distinct ?x422 ?x422) true)))))))
(check-sat)
; query 45: function susan_edges_small, block 278, name %279
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x663 (ite (bvslt (_ bv0 32) in.0_32) (_ bv1 1) (_ bv0 1))))
(let (($x10 (or false false false)))
(let (($x130 (not $x10)))
(and $x130 (or $x10 (and (distinct ?x663 ?x663) true)))))))
(check-sat)
; query 46: function susan_edges_small, block 426, name %427
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in411_32 () (_ BitVec 32))
(assert
 (let ((?x469 (ite (bvslt (_ bv0 32) in411_32) (_ bv1 1) (_ bv0 1))))
(let (($x10 (or false false false)))
(let (($x130 (not $x10)))
(and $x130 (or $x10 (and (distinct ?x469 ?x469) true)))))))
(check-sat)
; query 47: function susan_edges_small, block 458, name %459
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.110_32 () (_ BitVec 32))
(assert
 (let (($x421 (and (distinct (bvadd ((_ sign_extend 1) in.110_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.110_32 (_ bv1 32)))) true)))
(let (($x763 (or false false (or $x421))))
(and (not $x763) (or $x763 (and (distinct (bvadd in.110_32 (_ bv1 32)) (bvadd in.110_32 (_ bv1 32))) true))))))
(check-sat)
; query 48: function susan_edges_small, block 461, name %462
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.18_32 () (_ BitVec 32))
(assert
 (let (($x205 (and (distinct (bvadd ((_ sign_extend 1) in.18_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.18_32 (_ bv1 32)))) true)))
(let (($x372 (or false false (or $x205))))
(and (not $x372) (or $x372 (and (distinct (bvadd in.18_32 (_ bv1 32)) (bvadd in.18_32 (_ bv1 32))) true))))))
(check-sat)
; query 49: function susan_principle, block 378, name %379
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x75 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x22 (or false false (or $x75))))
(and (not $x22) (or $x22 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 50: function susan_principle, block 381, name %382
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x271 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x92 (or false false (or $x271))))
(and (not $x92) (or $x92 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 51: function susan_principle_small, block 118, name %119
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x75 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x22 (or false false (or $x75))))
(and (not $x22) (or $x22 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 52: function susan_principle_small, block 121, name %122
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x271 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x92 (or false false (or $x271))))
(and (not $x92) (or $x92 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 53: function susan_smoothing, block 123, name %124
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.09_32 () (_ BitVec 32))
(assert
 (let (($x178 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in.09_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in.09_32))) true)))
(let (($x258 (or false false (or $x178))))
(and (not $x258) (or $x258 (and (distinct (bvsub (_ bv0 32) in.09_32) (bvsub (_ bv0 32) in.09_32)) true))))))
(check-sat)
; query 54: function susan_smoothing, block 143, name %144
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.016_32 () (_ BitVec 32))
(assert
 (let (($x616 (and (distinct (bvadd ((_ sign_extend 1) in.016_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.016_32 (_ bv1 32)))) true)))
(let (($x368 (or false false (or $x616))))
(and (not $x368) (or $x368 (and (distinct (bvadd in.016_32 (_ bv1 32)) (bvadd in.016_32 (_ bv1 32))) true))))))
(check-sat)
; query 55: function susan_smoothing, block 148, name %149
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.017_32 () (_ BitVec 32))
(assert
 (let (($x525 (and (distinct (bvadd ((_ sign_extend 1) in.017_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.017_32 (_ bv1 32)))) true)))
(let (($x347 (or false false (or $x525))))
(and (not $x347) (or $x347 (and (distinct (bvadd in.017_32 (_ bv1 32)) (bvadd in.017_32 (_ bv1 32))) true))))))
(check-sat)
; query 56: function susan_smoothing, block 165, name %166
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.114_32 () (_ BitVec 32))
(assert
 (let (($x734 (and (distinct (bvadd ((_ sign_extend 1) in.114_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.114_32 (_ bv1 32)))) true)))
(let (($x351 (or false false (or $x734))))
(and (not $x351) (or $x351 (and (distinct (bvadd in.114_32 (_ bv1 32)) (bvadd in.114_32 (_ bv1 32))) true))))))
(check-sat)
; query 57: function susan_smoothing, block 168, name %169
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.111_32 () (_ BitVec 32))
(assert
 (let (($x280 (and (distinct (bvadd ((_ sign_extend 1) in.111_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.111_32 (_ bv1 32)))) true)))
(let (($x564 (or false false (or $x280))))
(and (not $x564) (or $x564 (and (distinct (bvadd in.111_32 (_ bv1 32)) (bvadd in.111_32 (_ bv1 32))) true))))))
(check-sat)
; query 58: function susan_smoothing, block 21, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x399 (ite (= (_ bv0 32) (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x10 (or false false false)))
(let (($x130 (not $x10)))
(and $x130 (or $x10 (and (distinct ?x399 ?x399) true)))))))
(check-sat)
; query 59: function susan_smoothing, block 319, name %320
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.215_32 () (_ BitVec 32))
(assert
 (let (($x463 (and (distinct (bvadd ((_ sign_extend 1) in.215_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.215_32 (_ bv1 32)))) true)))
(let (($x172 (or false false (or $x463))))
(and (not $x172) (or $x172 (and (distinct (bvadd in.215_32 (_ bv1 32)) (bvadd in.215_32 (_ bv1 32))) true))))))
(check-sat)
; query 60: function susan_smoothing, block 322, name %323
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.212_32 () (_ BitVec 32))
(assert
 (let (($x615 (and (distinct (bvadd ((_ sign_extend 1) in.212_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.212_32 (_ bv1 32)))) true)))
(let (($x446 (or false false (or $x615))))
(and (not $x446) (or $x446 (and (distinct (bvadd in.212_32 (_ bv1 32)) (bvadd in.212_32 (_ bv1 32))) true))))))
(check-sat)
; query 61: function susan_smoothing, block 67, name %68
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.09_32 () (_ BitVec 32))
(assert
 (let (($x178 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in.09_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in.09_32))) true)))
(let (($x258 (or false false (or $x178))))
(and (not $x258) (or $x258 (and (distinct (bvsub (_ bv0 32) in.09_32) (bvsub (_ bv0 32) in.09_32)) true))))))
(check-sat)
; query 62: function susan_smoothing, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.013_32 () (_ BitVec 32))
(assert
 (let (($x820 (and (distinct (bvadd ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.013_32 (_ bv1 32)))) true)))
(let (($x633 (or false false (or $x820))))
(and (not $x633) (or $x633 (and (distinct (bvadd in.013_32 (_ bv1 32)) (bvadd in.013_32 (_ bv1 32))) true))))))
(check-sat)
; query 63: function susan_smoothing, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.010_32 () (_ BitVec 32))
(assert
 (let (($x685 (and (distinct (bvadd ((_ sign_extend 1) in.010_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.010_32 (_ bv1 32)))) true)))
(let (($x721 (or false false (or $x685))))
(and (not $x721) (or $x721 (and (distinct (bvadd in.010_32 (_ bv1 32)) (bvadd in.010_32 (_ bv1 32))) true))))))
(check-sat)
; query 64: function susan_thin, block 100, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in93_32 () (_ BitVec 32))
(assert
 (let ((?x557 (ite (= (_ bv1 32) in93_32) (_ bv1 1) (_ bv0 1))))
(let (($x10 (or false false false)))
(let (($x130 (not $x10)))
(and $x130 (or $x10 (and (distinct ?x557 ?x557) true)))))))
(check-sat)
; query 65: function susan_thin, block 428, name %429
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.022_32 () (_ BitVec 32))
(assert
 (let (($x779 (and (distinct (bvadd ((_ sign_extend 1) in.022_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.022_32 (_ bv1 32)))) true)))
(let (($x262 (or false false (or $x779))))
(and (not $x262) (or $x262 (and (distinct (bvadd in.022_32 (_ bv1 32)) (bvadd in.022_32 (_ bv1 32))) true))))))
(check-sat)
; query 66: function susan_thin, block 431, name %432
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.018_32 () (_ BitVec 32))
(assert
 (let (($x844 (and (distinct (bvadd ((_ sign_extend 1) in.018_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.018_32 (_ bv1 32)))) true)))
(let (($x574 (or false false (or $x844))))
(and (not $x574) (or $x574 (and (distinct (bvadd in.018_32 (_ bv1 32)) (bvadd in.018_32 (_ bv1 32))) true))))))
(check-sat)
; query 67: function susan_thin, block 469, name %470
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.235.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x323 (bvadd in.235.lcssa_32 in.235.lcssa_32)))
(let ((?x646 ((_ sign_extend 1) ?x323)))
(let (($x707 (and (distinct (bvadd ((_ sign_extend 1) in.235.lcssa_32) ((_ sign_extend 1) in.235.lcssa_32)) ?x646) true)))
(let (($x415 (or false false (or $x707))))
(and (not $x415) (or $x415 (and (distinct ?x323 ?x323) true))))))))
(check-sat)
; query 68: function susan_thin, block 469, name %471
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.228.lcssa_32 () (_ BitVec 32))
(declare-fun in.235.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x323 (bvadd in.235.lcssa_32 in.235.lcssa_32)))
(let ((?x364 (bvadd ?x323 in.228.lcssa_32)))
(let (($x387 (and (distinct (bvadd ((_ sign_extend 1) ?x323) ((_ sign_extend 1) in.228.lcssa_32)) ((_ sign_extend 1) ?x364)) true)))
(let ((?x646 ((_ sign_extend 1) ?x323)))
(let (($x707 (and (distinct (bvadd ((_ sign_extend 1) in.235.lcssa_32) ((_ sign_extend 1) in.235.lcssa_32)) ?x646) true)))
(let (($x415 (or false false (or $x707))))
(let (($x748 (or $x415 false (or $x387))))
(and (not $x748) (or $x748 (and (distinct ?x364 ?x364) true)))))))))))
(check-sat)
; query 69: function susan_thin, block 469, name %472
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.228.lcssa_32 () (_ BitVec 32))
(declare-fun in.235.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x323 (bvadd in.235.lcssa_32 in.235.lcssa_32)))
(let ((?x364 (bvadd ?x323 in.228.lcssa_32)))
(let ((?x152 (ite (bvsgt (_ bv3 32) ?x364) (_ bv1 1) (_ bv0 1))))
(let (($x387 (and (distinct (bvadd ((_ sign_extend 1) ?x323) ((_ sign_extend 1) in.228.lcssa_32)) ((_ sign_extend 1) ?x364)) true)))
(let ((?x646 ((_ sign_extend 1) ?x323)))
(let (($x707 (and (distinct (bvadd ((_ sign_extend 1) in.235.lcssa_32) ((_ sign_extend 1) in.235.lcssa_32)) ?x646) true)))
(let (($x415 (or false false (or $x707))))
(let (($x748 (or $x415 false (or $x387))))
(let (($x696 (or $x748 false false)))
(and (not $x696) (or $x696 (and (distinct ?x152 ?x152) true)))))))))))))
(check-sat)
; query 70: function susan_thin, block 473, name %474
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.235.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x437 (bvsub in.235.lcssa_32 (_ bv1 32))))
(let ((?x353 ((_ sign_extend 1) ?x437)))
(let (($x654 (and (distinct (bvsub ((_ sign_extend 1) in.235.lcssa_32) ((_ sign_extend 1) (_ bv1 32))) ?x353) true)))
(let (($x428 (or false false (or $x654))))
(and (not $x428) (or $x428 (and (distinct ?x437 ?x437) true))))))))
(check-sat)
; query 71: function susan_thin, block 473, name %475
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.235.lcssa_32 () (_ BitVec 32))
(declare-fun in.14_32 () (_ BitVec 32))
(assert
 (let ((?x437 (bvsub in.235.lcssa_32 (_ bv1 32))))
(let ((?x760 (bvadd in.14_32 ?x437)))
(let (($x321 (and (distinct (bvadd ((_ sign_extend 1) in.14_32) ((_ sign_extend 1) ?x437)) ((_ sign_extend 1) ?x760)) true)))
(let ((?x353 ((_ sign_extend 1) ?x437)))
(let (($x654 (and (distinct (bvsub ((_ sign_extend 1) in.235.lcssa_32) ((_ sign_extend 1) (_ bv1 32))) ?x353) true)))
(let (($x428 (or false false (or $x654))))
(let (($x338 (or false $x428 (or $x321))))
(and (not $x338) (or $x338 (and (distinct ?x760 ?x760) true)))))))))))
(check-sat)
; query 72: function susan_thin, block 473, name %476
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.228.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x879 (bvsub in.228.lcssa_32 (_ bv2 32))))
(let ((?x453 ((_ sign_extend 1) ?x879)))
(let (($x408 (and (distinct (bvsub ((_ sign_extend 1) in.228.lcssa_32) ((_ sign_extend 1) (_ bv2 32))) ?x453) true)))
(let (($x355 (or false false (or $x408))))
(and (not $x355) (or $x355 (and (distinct ?x879 ?x879) true))))))))
(check-sat)
; query 73: function susan_thin, block 473, name %477
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.228.lcssa_32 () (_ BitVec 32))
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x879 (bvsub in.228.lcssa_32 (_ bv2 32))))
(let ((?x741 (bvadd in.0_32 ?x879)))
(let (($x194 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) ?x879)) ((_ sign_extend 1) ?x741)) true)))
(let ((?x453 ((_ sign_extend 1) ?x879)))
(let (($x408 (and (distinct (bvsub ((_ sign_extend 1) in.228.lcssa_32) ((_ sign_extend 1) (_ bv2 32))) ?x453) true)))
(let (($x355 (or false false (or $x408))))
(let (($x500 (or false $x355 (or $x194))))
(and (not $x500) (or $x500 (and (distinct ?x741 ?x741) true)))))))))))
(check-sat)
; query 74: function susan_thin, block 473, name %478
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.235.lcssa_32 () (_ BitVec 32))
(declare-fun in.14_32 () (_ BitVec 32))
(assert
 (let ((?x765 (ite (bvsgt (_ bv4 32) (bvadd in.14_32 (bvsub in.235.lcssa_32 (_ bv1 32)))) (_ bv1 1) (_ bv0 1))))
(let ((?x437 (bvsub in.235.lcssa_32 (_ bv1 32))))
(let ((?x353 ((_ sign_extend 1) ?x437)))
(let ((?x174 ((_ sign_extend 1) in.14_32)))
(let (($x654 (and (distinct (bvsub ((_ sign_extend 1) in.235.lcssa_32) ((_ sign_extend 1) (_ bv1 32))) ?x353) true)))
(let (($x428 (or false false (or $x654))))
(let (($x338 (or false $x428 (or (and (distinct (bvadd ?x174 ?x353) ((_ sign_extend 1) (bvadd in.14_32 ?x437))) true)))))
(let (($x778 (or $x338 false false)))
(and (not $x778) (or $x778 (and (distinct ?x765 ?x765) true))))))))))))
(check-sat)
; query 75: function susan_thin, block 533, name %534
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in528_32 () (_ BitVec 32))
(declare-fun in498_32 () (_ BitVec 32))
(assert
 (let (($x10 (or false false false)))
(let (($x886 (or $x10 (and (distinct (bvor in498_32 in528_32) (bvor in498_32 in528_32)) true))))
(let (($x130 (not $x10)))
(and $x130 $x886)))))
(check-sat)
; query 76: function susan_thin, block 533, name %535
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in518_32 () (_ BitVec 32))
(declare-fun in508_32 () (_ BitVec 32))
(assert
 (let (($x10 (or false false false)))
(let (($x542 (or $x10 (and (distinct (bvor in508_32 in518_32) (bvor in508_32 in518_32)) true))))
(let (($x130 (not $x10)))
(and $x130 $x542)))))
(check-sat)
; query 77: function susan_thin, block 533, name %536
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in518_32 () (_ BitVec 32))
(declare-fun in508_32 () (_ BitVec 32))
(declare-fun in528_32 () (_ BitVec 32))
(declare-fun in498_32 () (_ BitVec 32))
(assert
 (let ((?x444 (bvor in508_32 in518_32)))
(let ((?x169 (bvor in498_32 in528_32)))
(let ((?x799 (bvand ?x169 ?x444)))
(let (($x10 (or false false false)))
(let (($x33 (or $x10 $x10 false)))
(let (($x812 (not $x33)))
(and $x812 (or $x33 (and (distinct ?x799 ?x799) true))))))))))
(check-sat)
; query 78: function susan_thin, block 533, name %537
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in518_32 () (_ BitVec 32))
(declare-fun in508_32 () (_ BitVec 32))
(declare-fun in528_32 () (_ BitVec 32))
(declare-fun in498_32 () (_ BitVec 32))
(assert
 (let ((?x444 (bvor in508_32 in518_32)))
(let ((?x169 (bvor in498_32 in528_32)))
(let ((?x799 (bvand ?x169 ?x444)))
(let ((?x358 (ite (and (distinct (_ bv0 32) ?x799) true) (_ bv1 1) (_ bv0 1))))
(let (($x10 (or false false false)))
(let (($x33 (or $x10 $x10 false)))
(let (($x385 (or $x33 false false)))
(let (($x420 (not $x385)))
(and $x420 (or $x385 (and (distinct ?x358 ?x358) true))))))))))))
(check-sat)
; query 79: function susan_thin, block 538, name %539
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in498_32 () (_ BitVec 32))
(assert
 (let ((?x403 (ite (and (distinct (_ bv0 32) in498_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x10 (or false false false)))
(let (($x130 (not $x10)))
(and $x130 (or $x10 (and (distinct ?x403 ?x403) true)))))))
(check-sat)
; query 80: function susan_thin, block 540, name %541
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in508_32 () (_ BitVec 32))
(assert
 (let ((?x267 (ite (and (distinct (_ bv0 32) in508_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x10 (or false false false)))
(let (($x130 (not $x10)))
(and $x130 (or $x10 (and (distinct ?x267 ?x267) true)))))))
(check-sat)
; query 81: function susan_thin, block 545, name %546
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in508_32 () (_ BitVec 32))
(assert
 (let ((?x267 (ite (and (distinct (_ bv0 32) in508_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x10 (or false false false)))
(let (($x130 (not $x10)))
(and $x130 (or $x10 (and (distinct ?x267 ?x267) true)))))))
(check-sat)
; query 82: function susan_thin, block 563, name %564
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.325_32 () (_ BitVec 32))
(assert
 (let ((?x113 (ite (= (_ bv0 32) in.325_32) (_ bv1 1) (_ bv0 1))))
(let (($x10 (or false false false)))
(let (($x130 (not $x10)))
(and $x130 (or $x10 (and (distinct ?x113 ?x113) true)))))))
(check-sat)
; query 83: function susan_thin, block 597, name %598
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.321_32 () (_ BitVec 32))
(assert
 (let ((?x577 (ite (= (_ bv0 32) in.321_32) (_ bv1 1) (_ bv0 1))))
(let (($x10 (or false false false)))
(let (($x130 (not $x10)))
(and $x130 (or $x10 (and (distinct ?x577 ?x577) true)))))))
(check-sat)
; query 84: function susan_thin, block 685, name %686
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in662_32 () (_ BitVec 32))
(declare-fun in680_32 () (_ BitVec 32))
(assert
 (let (($x10 (or false false false)))
(let (($x335 (or $x10 (and (distinct (bvor in680_32 in662_32) (bvor in680_32 in662_32)) true))))
(let (($x130 (not $x10)))
(and $x130 $x335)))))
(check-sat)
; query 85: function susan_thin, block 685, name %687
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in671_32 () (_ BitVec 32))
(declare-fun in653_32 () (_ BitVec 32))
(assert
 (let (($x10 (or false false false)))
(let (($x494 (or $x10 (and (distinct (bvor in653_32 in671_32) (bvor in653_32 in671_32)) true))))
(let (($x130 (not $x10)))
(and $x130 $x494)))))
(check-sat)
; query 86: function susan_thin, block 685, name %688
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in671_32 () (_ BitVec 32))
(declare-fun in653_32 () (_ BitVec 32))
(declare-fun in662_32 () (_ BitVec 32))
(declare-fun in680_32 () (_ BitVec 32))
(assert
 (let ((?x270 (bvor in653_32 in671_32)))
(let ((?x632 (bvor in680_32 in662_32)))
(let ((?x537 (bvand ?x632 ?x270)))
(let (($x10 (or false false false)))
(let (($x33 (or $x10 $x10 false)))
(let (($x812 (not $x33)))
(and $x812 (or $x33 (and (distinct ?x537 ?x537) true))))))))))
(check-sat)
; query 87: function susan_thin, block 685, name %689
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in671_32 () (_ BitVec 32))
(declare-fun in653_32 () (_ BitVec 32))
(declare-fun in662_32 () (_ BitVec 32))
(declare-fun in680_32 () (_ BitVec 32))
(assert
 (let ((?x270 (bvor in653_32 in671_32)))
(let ((?x632 (bvor in680_32 in662_32)))
(let ((?x537 (bvand ?x632 ?x270)))
(let ((?x636 (ite (and (distinct (_ bv0 32) ?x537) true) (_ bv1 1) (_ bv0 1))))
(let (($x10 (or false false false)))
(let (($x33 (or $x10 $x10 false)))
(let (($x385 (or $x33 false false)))
(let (($x420 (not $x385)))
(and $x420 (or $x385 (and (distinct ?x636 ?x636) true))))))))))))
(check-sat)
; query 88: function susan_thin, block 915, name %916
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.13_32 () (_ BitVec 32))
(assert
 (let (($x851 (and (distinct (bvadd ((_ sign_extend 1) in.13_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.13_32 (_ bv1 32)))) true)))
(let (($x904 (or false false (or $x851))))
(and (not $x904) (or $x904 (and (distinct (bvadd in.13_32 (_ bv1 32)) (bvadd in.13_32 (_ bv1 32))) true))))))
(check-sat)
; query 89: function susan_thin, block 918, name %919
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.14.lcssa_32 () (_ BitVec 32))
(assert
 (let (($x134 (and (distinct (bvadd ((_ sign_extend 1) in.14.lcssa_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.14.lcssa_32 (_ bv1 32)))) true)))
(let (($x759 (or false false (or $x134))))
(let (($x432 (or $x759 (and (distinct (bvadd in.14.lcssa_32 (_ bv1 32)) (bvadd in.14.lcssa_32 (_ bv1 32))) true))))
(and (not $x759) $x432)))))
(check-sat)
