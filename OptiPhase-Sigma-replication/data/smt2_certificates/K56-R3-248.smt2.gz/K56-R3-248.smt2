; OptiPhase-Sigma refinement certificate for sweep K56-R3-248
; query 0: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x974 (or false false)))
(let (($x11 (not $x974)))
(and $x11 (or $x974 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 1: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x661 ((_ sign_extend 16) in3_16)))
(let ((?x163 (bvand ?x661 (_ bv127 32))))
(let (($x974 (or false false)))
(let (($x174 (or $x974 false false)))
(let (($x58 (not $x174)))
(and $x58 (or $x174 (and (distinct ?x163 ?x163) true)))))))))
(check-sat)
; query 2: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x661 ((_ sign_extend 16) in3_16)))
(let ((?x163 (bvand ?x661 (_ bv127 32))))
(let ((?x130 ((_ extract 15 0) ?x163)))
(let (($x974 (or false false)))
(let (($x174 (or $x974 false false)))
(let (($x616 (or $x174 false)))
(and (not $x616) (or $x616 (and (distinct ?x130 ?x130) true))))))))))
(check-sat)
; query 3: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x974 (or false false)))
(let (($x11 (not $x974)))
(and $x11 (or $x974 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 4: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x282 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x974 (or false false)))
(let (($x174 (or $x974 false false)))
(let (($x58 (not $x174)))
(and $x58 (or $x174 (and (distinct ?x282 ?x282) true))))))))
(check-sat)
; query 5: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x1838 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x533 (or false false false)))
(let (($x1742 (not $x533)))
(and $x1742 (or $x533 (and (distinct ?x1838 ?x1838) true)))))))
(check-sat)
; query 6: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x110 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x533 (or false false false)))
(let (($x1742 (not $x533)))
(and $x1742 (or $x533 (and (distinct ?x110 ?x110) true)))))))
(check-sat)
; query 7: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x533 (or false false false)))
(let (($x1742 (not $x533)))
(and $x1742 (or $x533 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 8: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x790 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x715 (or false false (or $x790))))
(and (not $x715) (or $x715 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 9: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x404 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x533 (or false false false)))
(let (($x1742 (not $x533)))
(and $x1742 (or $x533 (and (distinct ?x404 ?x404) true)))))))
(check-sat)
