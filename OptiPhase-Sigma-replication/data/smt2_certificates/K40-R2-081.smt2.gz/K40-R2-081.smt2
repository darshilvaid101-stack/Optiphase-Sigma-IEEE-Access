; OptiPhase-Sigma refinement certificate for sweep K40-R2-081
; query 0: function decfile, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in17_32 () (_ BitVec 32))
(assert
 (let ((?x41 (ite (and (distinct (_ bv16 32) in17_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x226 (or false false false)))
(let (($x10 (not $x226)))
(and $x10 (or $x226 (and (distinct ?x41 ?x41) true)))))))
(check-sat)
; query 1: function decfile, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x759 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x12 (or false false (or $x759))))
(and (not $x12) (or $x12 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function decfile, block 82, name %83
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x884 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x230 (or false false (or $x884))))
(and (not $x230) (or $x230 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 3: function decfile, block 85, name %86
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x151 (ite (= (_ bv15 32) in.01.lcssa_32) (_ bv1 1) (_ bv0 1))))
(let (($x226 (or false false false)))
(let (($x10 (not $x226)))
(and $x10 (or $x226 (and (distinct ?x151 ?x151) true)))))))
(check-sat)
; query 4: function decfile, block 85, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x151 (ite (= (_ bv15 32) in.01.lcssa_32) (_ bv1 1) (_ bv0 1))))
(let ((?x851 ((_ zero_extend 63) ?x151)))
(let (($x226 (or false false false)))
(let (($x11 (or $x226 false)))
(and (not $x11) (or $x11 (and (distinct ?x851 ?x851) true))))))))
(check-sat)
; query 5: function decfile, block 85, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x151 (ite (= (_ bv15 32) in.01.lcssa_32) (_ bv1 1) (_ bv0 1))))
(let (($x130 (= (_ bv1 1) ?x151)))
(let ((?x668 (ite $x130 (_ bv1 32) (_ bv0 32))))
(let (($x226 (or false false false)))
(let (($x231 (or $x226 (ite $x130 false false))))
(and (not $x231) (or $x231 (and (distinct ?x668 ?x668) true)))))))))
(check-sat)
; query 6: function decfile, block 85, name %89
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x151 (ite (= (_ bv15 32) in.01.lcssa_32) (_ bv1 1) (_ bv0 1))))
(let (($x130 (= (_ bv1 1) ?x151)))
(let ((?x668 (ite $x130 (_ bv1 32) (_ bv0 32))))
(let ((?x225 (bvsub (_ bv1 32) ?x668)))
(let ((?x50 ((_ sign_extend 1) ?x225)))
(let (($x226 (or false false false)))
(let (($x231 (or $x226 (ite $x130 false false))))
(let (($x18 (or false $x231 (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv1 32)) ((_ sign_extend 1) ?x668)) ?x50) true)))))
(and (not $x18) (or $x18 (and (distinct ?x225 ?x225) true))))))))))))
(check-sat)
; query 7: function decfile, block 85, name %90
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01.lcssa_32 () (_ BitVec 32))
(declare-fun in46_32 () (_ BitVec 32))
(assert
 (let ((?x151 (ite (= (_ bv15 32) in.01.lcssa_32) (_ bv1 1) (_ bv0 1))))
(let (($x130 (= (_ bv1 1) ?x151)))
(let ((?x668 (ite $x130 (_ bv1 32) (_ bv0 32))))
(let ((?x225 (bvsub (_ bv1 32) ?x668)))
(let ((?x48 (bvadd in46_32 ?x225)))
(let (($x232 (and (distinct (bvadd ((_ sign_extend 1) in46_32) ((_ sign_extend 1) ?x225)) ((_ sign_extend 1) ?x48)) true)))
(let ((?x50 ((_ sign_extend 1) ?x225)))
(let (($x226 (or false false false)))
(let (($x231 (or $x226 (ite $x130 false false))))
(let (($x18 (or false $x231 (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv1 32)) ((_ sign_extend 1) ?x668)) ?x50) true)))))
(let (($x132 (or false $x18 (or $x232))))
(and (not $x132) (or $x132 (and (distinct ?x48 ?x48) true)))))))))))))))
(check-sat)
; query 8: function decfile, block 85, name %91
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01.lcssa_32 () (_ BitVec 32))
(declare-fun in46_32 () (_ BitVec 32))
(assert
 (let ((?x151 (ite (= (_ bv15 32) in.01.lcssa_32) (_ bv1 1) (_ bv0 1))))
(let (($x130 (= (_ bv1 1) ?x151)))
(let ((?x668 (ite $x130 (_ bv1 32) (_ bv0 32))))
(let ((?x225 (bvsub (_ bv1 32) ?x668)))
(let ((?x48 (bvadd in46_32 ?x225)))
(let ((?x92 (ite (and (distinct (_ bv0 32) ?x48) true) (_ bv1 1) (_ bv0 1))))
(let (($x232 (and (distinct (bvadd ((_ sign_extend 1) in46_32) ((_ sign_extend 1) ?x225)) ((_ sign_extend 1) ?x48)) true)))
(let ((?x50 ((_ sign_extend 1) ?x225)))
(let (($x226 (or false false false)))
(let (($x231 (or $x226 (ite $x130 false false))))
(let (($x18 (or false $x231 (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv1 32)) ((_ sign_extend 1) ?x668)) ?x50) true)))))
(let (($x132 (or false $x18 (or $x232))))
(let (($x159 (or $x132 false false)))
(and (not $x159) (or $x159 (and (distinct ?x92 ?x92) true)))))))))))))))))
(check-sat)
; query 9: function encfile, block 50, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_64 () (_ BitVec 64))
(assert
 (let (($x226 (or false false false)))
(let (($x10 (not $x226)))
(and $x10 (or $x226 (and (distinct (bvadd in.1_64 (_ bv1 64)) (bvadd in.1_64 (_ bv1 64))) true))))))
(check-sat)
; query 10: function encfile, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_64 () (_ BitVec 64))
(assert
 (let (($x226 (or false false false)))
(let (($x10 (not $x226)))
(and $x10 (or $x226 (and (distinct (bvadd in.2_64 (_ bv1 64)) (bvadd in.2_64 (_ bv1 64))) true))))))
(check-sat)
; query 11: function encfile, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.5_64 () (_ BitVec 64))
(assert
 (let (($x226 (or false false false)))
(let (($x10 (not $x226)))
(and $x10 (or $x226 (and (distinct (bvadd in.5_64 (_ bv1 64)) (bvadd in.5_64 (_ bv1 64))) true))))))
(check-sat)
; query 12: function fillrand, block 34, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x282 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x157 (or false false (or $x282))))
(and (not $x157) (or $x157 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 13: function main, block 41, name %42
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let (($x39 (or false false)))
(and (not $x39) (or $x39 (and (distinct ((_ sign_extend 24) in38_8) ((_ sign_extend 24) in38_8)) true)))))
(check-sat)
; query 14: function main, block 41, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let ((?x174 (ite (bvsge (_ bv57 32) ((_ sign_extend 24) in38_8)) (_ bv1 1) (_ bv0 1))))
(let (($x39 (or false false)))
(let (($x135 (or $x39 false false)))
(let (($x281 (not $x135)))
(and $x281 (or $x135 (and (distinct ?x174 ?x174) true))))))))
(check-sat)
; query 15: function main, block 44, name %45
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x226 (or false false false)))
(let (($x44 (or $x226 (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x44) (or $x44 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvshl in.01_32 (_ bv4 32))) true))))))
(check-sat)
; query 16: function main, block 44, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let (($x39 (or false false)))
(and (not $x39) (or $x39 (and (distinct ((_ sign_extend 24) in38_8) ((_ sign_extend 24) in38_8)) true)))))
(check-sat)
; query 17: function main, block 44, name %47
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x221 ((_ sign_extend 24) in38_8)))
(let ((?x144 (bvshl in.01_32 (_ bv4 32))))
(let ((?x107 (bvadd ?x144 ?x221)))
(let ((?x106 ((_ sign_extend 1) ?x107)))
(let (($x39 (or false false)))
(let (($x226 (or false false false)))
(let (($x44 (or $x226 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x125 (or $x44 $x39 (or (and (distinct (bvadd ((_ sign_extend 1) ?x144) ((_ sign_extend 1) ?x221)) ?x106) true)))))
(and (not $x125) (or $x125 (and (distinct ?x107 ?x107) true))))))))))))
(check-sat)
; query 18: function main, block 44, name %48
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x221 ((_ sign_extend 24) in38_8)))
(let ((?x144 (bvshl in.01_32 (_ bv4 32))))
(let ((?x107 (bvadd ?x144 ?x221)))
(let ((?x122 (bvsub ?x107 (_ bv48 32))))
(let (($x102 (and (distinct (bvsub ((_ sign_extend 1) ?x107) ((_ sign_extend 1) (_ bv48 32))) ((_ sign_extend 1) ?x122)) true)))
(let ((?x106 ((_ sign_extend 1) ?x107)))
(let (($x39 (or false false)))
(let (($x226 (or false false false)))
(let (($x44 (or $x226 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x125 (or $x44 $x39 (or (and (distinct (bvadd ((_ sign_extend 1) ?x144) ((_ sign_extend 1) ?x221)) ?x106) true)))))
(let (($x56 (or $x125 false (or $x102))))
(and (not $x56) (or $x56 (and (distinct ?x122 ?x122) true)))))))))))))))
(check-sat)
; query 19: function main, block 49, name %50
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let (($x39 (or false false)))
(and (not $x39) (or $x39 (and (distinct ((_ sign_extend 24) in38_8) ((_ sign_extend 24) in38_8)) true)))))
(check-sat)
; query 20: function main, block 49, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let ((?x424 (ite (bvsle (_ bv65 32) ((_ sign_extend 24) in38_8)) (_ bv1 1) (_ bv0 1))))
(let (($x39 (or false false)))
(let (($x135 (or $x39 false false)))
(let (($x281 (not $x135)))
(and $x281 (or $x135 (and (distinct ?x424 ?x424) true))))))))
(check-sat)
; query 21: function main, block 52, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let (($x39 (or false false)))
(and (not $x39) (or $x39 (and (distinct ((_ sign_extend 24) in38_8) ((_ sign_extend 24) in38_8)) true)))))
(check-sat)
; query 22: function main, block 52, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let ((?x103 (ite (bvsge (_ bv70 32) ((_ sign_extend 24) in38_8)) (_ bv1 1) (_ bv0 1))))
(let (($x39 (or false false)))
(let (($x135 (or $x39 false false)))
(let (($x281 (not $x135)))
(and $x281 (or $x135 (and (distinct ?x103 ?x103) true))))))))
(check-sat)
; query 23: function main, block 55, name %56
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x226 (or false false false)))
(let (($x44 (or $x226 (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x44) (or $x44 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvshl in.01_32 (_ bv4 32))) true))))))
(check-sat)
; query 24: function main, block 55, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let (($x39 (or false false)))
(and (not $x39) (or $x39 (and (distinct ((_ sign_extend 24) in38_8) ((_ sign_extend 24) in38_8)) true)))))
(check-sat)
; query 25: function main, block 55, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x221 ((_ sign_extend 24) in38_8)))
(let ((?x144 (bvshl in.01_32 (_ bv4 32))))
(let ((?x107 (bvadd ?x144 ?x221)))
(let ((?x106 ((_ sign_extend 1) ?x107)))
(let (($x39 (or false false)))
(let (($x226 (or false false false)))
(let (($x44 (or $x226 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x125 (or $x44 $x39 (or (and (distinct (bvadd ((_ sign_extend 1) ?x144) ((_ sign_extend 1) ?x221)) ?x106) true)))))
(and (not $x125) (or $x125 (and (distinct ?x107 ?x107) true))))))))))))
(check-sat)
; query 26: function main, block 55, name %59
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x221 ((_ sign_extend 24) in38_8)))
(let ((?x144 (bvshl in.01_32 (_ bv4 32))))
(let ((?x107 (bvadd ?x144 ?x221)))
(let ((?x58 (bvsub ?x107 (_ bv65 32))))
(let ((?x71 ((_ sign_extend 1) ?x58)))
(let ((?x106 ((_ sign_extend 1) ?x107)))
(let (($x39 (or false false)))
(let (($x226 (or false false false)))
(let (($x44 (or $x226 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x125 (or $x44 $x39 (or (and (distinct (bvadd ((_ sign_extend 1) ?x144) ((_ sign_extend 1) ?x221)) ?x106) true)))))
(let (($x392 (or $x125 false (or (and (distinct (bvsub ?x106 ((_ sign_extend 1) (_ bv65 32))) ?x71) true)))))
(and (not $x392) (or $x392 (and (distinct ?x58 ?x58) true)))))))))))))))
(check-sat)
; query 27: function main, block 55, name %60
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x221 ((_ sign_extend 24) in38_8)))
(let ((?x144 (bvshl in.01_32 (_ bv4 32))))
(let ((?x107 (bvadd ?x144 ?x221)))
(let ((?x58 (bvsub ?x107 (_ bv65 32))))
(let ((?x352 (bvadd ?x58 (_ bv10 32))))
(let (($x188 (and (distinct (bvadd ((_ sign_extend 1) ?x58) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x352)) true)))
(let ((?x71 ((_ sign_extend 1) ?x58)))
(let ((?x106 ((_ sign_extend 1) ?x107)))
(let (($x39 (or false false)))
(let (($x226 (or false false false)))
(let (($x44 (or $x226 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x125 (or $x44 $x39 (or (and (distinct (bvadd ((_ sign_extend 1) ?x144) ((_ sign_extend 1) ?x221)) ?x106) true)))))
(let (($x392 (or $x125 false (or (and (distinct (bvsub ?x106 ((_ sign_extend 1) (_ bv65 32))) ?x71) true)))))
(let (($x23 (or $x392 false (or $x188))))
(and (not $x23) (or $x23 (and (distinct ?x352 ?x352) true))))))))))))))))))
(check-sat)
; query 28: function main, block 81, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x350 (ite (bvsgt (_ bv32 32) in.06.lcssa_32) (_ bv1 1) (_ bv0 1))))
(let (($x226 (or false false false)))
(let (($x10 (not $x226)))
(and $x10 (or $x226 (and (distinct ?x350 ?x350) true)))))))
(check-sat)
; query 29: function main, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06.lcssa_32 () (_ BitVec 32))
(assert
 (let (($x226 (or false false false)))
(let (($x908 (or $x226 (and (distinct (bvand in.06.lcssa_32 (_ bv15 32)) (bvand in.06.lcssa_32 (_ bv15 32))) true))))
(let (($x10 (not $x226)))
(and $x10 $x908)))))
(check-sat)
; query 30: function main, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x227 (ite (and (distinct (_ bv0 32) (bvand in.06.lcssa_32 (_ bv15 32))) true) (_ bv1 1) (_ bv0 1))))
(let (($x226 (or false false false)))
(let (($x283 (or $x226 false false)))
(let (($x471 (not $x283)))
(and $x471 (or $x283 (and (distinct ?x227 ?x227) true))))))))
(check-sat)
; query 31: function set_key, block 11, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let (($x226 (or false false false)))
(let (($x10 (not $x226)))
(and $x10 (or $x226 (and (distinct (bvand in2_32 (_ bv1 32)) (bvand in2_32 (_ bv1 32))) true))))))
(check-sat)
; query 32: function set_key, block 11, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x826 (ite (and (distinct (_ bv0 32) (bvand in2_32 (_ bv1 32))) true) (_ bv1 1) (_ bv0 1))))
(let (($x226 (or false false false)))
(let (($x283 (or $x226 false false)))
(let (($x471 (not $x283)))
(and $x471 (or $x283 (and (distinct ?x826 ?x826) true))))))))
(check-sat)
; query 33: function set_key, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let (($x226 (or false false false)))
(let (($x10 (not $x226)))
(and $x10 (or $x226 (and (distinct (bvand in2_32 (_ bv2 32)) (bvand in2_32 (_ bv2 32))) true))))))
(check-sat)
; query 34: function set_key, block 14, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x734 (ite (and (distinct (_ bv0 32) (bvand in2_32 (_ bv2 32))) true) (_ bv1 1) (_ bv0 1))))
(let (($x226 (or false false false)))
(let (($x283 (or $x226 false false)))
(let (($x471 (not $x283)))
(and $x471 (or $x283 (and (distinct ?x734 ?x734) true))))))))
(check-sat)
; query 35: function set_key, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x864 (ite (and (distinct (_ bv0 64) in1_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x226 (or false false false)))
(let (($x10 (not $x226)))
(and $x10 (or $x226 (and (distinct ?x864 ?x864) true)))))))
(check-sat)
; query 36: function set_key, block 514, name %515
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_64 () (_ BitVec 64))
(assert
 (let (($x226 (or false false false)))
(let (($x10 (not $x226)))
(and $x10 (or $x226 (and (distinct (bvadd in.01_64 (_ bv1 64)) (bvadd in.01_64 (_ bv1 64))) true))))))
(check-sat)
; query 37: function set_key, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x93 (ite (bvult in1_64 (_ bv16 64)) (_ bv1 1) (_ bv0 1))))
(let (($x226 (or false false false)))
(let (($x10 (not $x226)))
(and $x10 (or $x226 (and (distinct ?x93 ?x93) true)))))))
(check-sat)
; query 38: function set_key, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x895 (ite (bvugt in1_64 (_ bv32 64)) (_ bv1 1) (_ bv0 1))))
(let (($x226 (or false false false)))
(let (($x10 (not $x226)))
(and $x10 (or $x226 (and (distinct ?x895 ?x895) true)))))))
(check-sat)
; query 39: function set_key, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let (($x226 (or false false false)))
(let (($x10 (not $x226)))
(and $x10 (or $x226 (and (distinct (bvand in1_64 (_ bv7 64)) (bvand in1_64 (_ bv7 64))) true))))))
(check-sat)
; query 40: function set_key, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x516 (ite (and (distinct (_ bv0 64) (bvand in1_64 (_ bv7 64))) true) (_ bv1 1) (_ bv0 1))))
(let (($x226 (or false false false)))
(let (($x283 (or $x226 false false)))
(let (($x471 (not $x283)))
(and $x471 (or $x283 (and (distinct ?x516 ?x516) true))))))))
(check-sat)
