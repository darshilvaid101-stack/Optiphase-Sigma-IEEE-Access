; OptiPhase-Sigma refinement certificate for sweep K44-R4-314
; query 0: function Index_to_frequency, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x454 (ite (bvuge in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x127 (or false false false)))
(let (($x287 (not $x127)))
(and $x287 (or $x127 (and (distinct ?x454 ?x454) true)))))))
(check-sat)
; query 1: function IsPowerOfTwo, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x333 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x127 (or false false false)))
(let (($x287 (not $x127)))
(and $x287 (or $x127 (and (distinct ?x333 ?x333) true)))))))
(check-sat)
; query 2: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x333 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x127 (or false false false)))
(let (($x287 (not $x127)))
(and $x287 (or $x127 (and (distinct ?x333 ?x333) true)))))))
(check-sat)
; query 3: function main, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x613 (ite (= (_ bv4 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x127 (or false false false)))
(let (($x287 (not $x127)))
(and $x287 (or $x127 (and (distinct ?x613 ?x613) true)))))))
(check-sat)
; query 4: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x62 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x127 (or false false false)))
(let (($x287 (not $x127)))
(and $x287 (or $x127 (and (distinct ?x62 ?x62) true)))))))
(check-sat)
