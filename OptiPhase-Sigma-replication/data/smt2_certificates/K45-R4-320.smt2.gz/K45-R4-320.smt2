; OptiPhase-Sigma refinement certificate for sweep K45-R4-320
; query 0: function Index_to_frequency, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x76 (ite (bvuge in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x655 (or false false false)))
(let (($x259 (not $x655)))
(and $x259 (or $x655 (and (distinct ?x76 ?x76) true)))))))
(check-sat)
; query 1: function IsPowerOfTwo, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x45 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x655 (or false false false)))
(let (($x259 (not $x655)))
(and $x259 (or $x655 (and (distinct ?x45 ?x45) true)))))))
(check-sat)
; query 2: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x45 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x655 (or false false false)))
(let (($x259 (not $x655)))
(and $x259 (or $x655 (and (distinct ?x45 ?x45) true)))))))
(check-sat)
; query 3: function main, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x1583 (ite (= (_ bv4 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x655 (or false false false)))
(let (($x259 (not $x655)))
(and $x259 (or $x655 (and (distinct ?x1583 ?x1583) true)))))))
(check-sat)
; query 4: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x97 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x655 (or false false false)))
(let (($x259 (not $x655)))
(and $x259 (or $x655 (and (distinct ?x97 ?x97) true)))))))
(check-sat)
