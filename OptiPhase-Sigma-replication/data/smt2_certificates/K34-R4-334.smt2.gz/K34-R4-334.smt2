; OptiPhase-Sigma refinement certificate for sweep K34-R4-334
; query 0: function edge_draw, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let ((?x15 (ite (= (_ bv0 32) in4_32) (_ bv1 1) (_ bv0 1))))
(let (($x291 (or false false false)))
(and (not $x291) (or $x291 (and (distinct ?x15 ?x15) true))))))
(check-sat)
