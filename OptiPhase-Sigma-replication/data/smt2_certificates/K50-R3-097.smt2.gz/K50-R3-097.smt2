; OptiPhase-Sigma refinement certificate for sweep K50-R3-097
