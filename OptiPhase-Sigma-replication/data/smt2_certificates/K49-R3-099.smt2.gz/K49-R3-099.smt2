; OptiPhase-Sigma refinement certificate for sweep K49-R3-099
; query 0: function APCM_inverse_quantization, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x727 (or false false)))
(let (($x111 (not $x727)))
(and $x111 (or $x727 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 1: function APCM_inverse_quantization, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x378 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x727 (or false false)))
(let (($x598 (or $x727 false false)))
(let (($x9 (not $x598)))
(and $x9 (or $x598 (and (distinct ?x378 ?x378) true))))))))
(check-sat)
; query 2: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x727 (or false false)))
(let (($x111 (not $x727)))
(and $x111 (or $x727 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 3: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x876 (ite (bvslt (_ bv15 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x727 (or false false)))
(let (($x598 (or $x727 false false)))
(let (($x9 (not $x598)))
(and $x9 (or $x598 (and (distinct ?x876 ?x876) true))))))))
(check-sat)
; query 4: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x727 (or false false)))
(let (($x111 (not $x727)))
(and $x111 (or $x727 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 5: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x94 (ite (bvsgt (_ bv40 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x727 (or false false)))
(let (($x598 (or $x727 false false)))
(let (($x9 (not $x598)))
(and $x9 (or $x598 (and (distinct ?x94 ?x94) true))))))))
(check-sat)
; query 6: function RPE_grid_positioning, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x727 (or false false)))
(let (($x111 (not $x727)))
(and $x111 (or $x727 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 7: function RPE_grid_positioning, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x134 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x115 (and (distinct ?x134 ?x134) true)))
(let (($x727 (or false false)))
(let (($x476 (or false $x727 false)))
(and (not $x476) (or $x476 $x115)))))))
(check-sat)
; query 8: function gsm_L_add, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x180 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x372 (or false false false)))
(let (($x168 (not $x372)))
(and $x168 (or $x372 (and (distinct ?x180 ?x180) true)))))))
(check-sat)
; query 9: function gsm_L_add, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x310 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvadd in0_64 in1_64))) true)))
(let (($x31 (or false false (or $x310))))
(let (($x181 (or $x31 (and (distinct (bvadd in0_64 in1_64) (bvadd in0_64 in1_64)) true))))
(and (not $x31) $x181)))))
(check-sat)
; query 10: function gsm_L_add, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x20 (bvadd in0_64 (_ bv1 64))))
(let ((?x93 (bvsub (_ bv0 64) ?x20)))
(let (($x15 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x20)) ((_ sign_extend 1) ?x93)) true)))
(let ((?x51 ((_ sign_extend 1) ?x20)))
(let (($x12 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x51) true)))))
(let (($x32 (or false $x12 (or $x15))))
(and (not $x32) (or $x32 (and (distinct ?x93 ?x93) true))))))))))
(check-sat)
; query 11: function gsm_L_add, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x340 (bvadd in1_64 (_ bv1 64))))
(let ((?x675 ((_ sign_extend 1) ?x340)))
(let (($x43 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x675) true)))))
(and (not $x43) (or $x43 (and (distinct ?x340 ?x340) true)))))))
(check-sat)
; query 12: function gsm_L_add, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x340 (bvadd in1_64 (_ bv1 64))))
(let ((?x249 (bvsub (_ bv0 64) ?x340)))
(let (($x53 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x340)) ((_ sign_extend 1) ?x249)) true)))
(let ((?x675 ((_ sign_extend 1) ?x340)))
(let (($x43 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x675) true)))))
(let (($x334 (or false $x43 (or $x53))))
(and (not $x334) (or $x334 (and (distinct ?x249 ?x249) true))))))))))
(check-sat)
; query 13: function gsm_L_add, block 8, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x340 (bvadd in1_64 (_ bv1 64))))
(let ((?x249 (bvsub (_ bv0 64) ?x340)))
(let ((?x20 (bvadd in0_64 (_ bv1 64))))
(let ((?x93 (bvsub (_ bv0 64) ?x20)))
(let ((?x380 (bvadd ?x93 ?x249)))
(let (($x53 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x340)) ((_ sign_extend 1) ?x249)) true)))
(let ((?x675 ((_ sign_extend 1) ?x340)))
(let (($x43 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x675) true)))))
(let (($x334 (or false $x43 (or $x53))))
(let (($x15 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x20)) ((_ sign_extend 1) ?x93)) true)))
(let ((?x51 ((_ sign_extend 1) ?x20)))
(let (($x12 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x51) true)))))
(let (($x32 (or false $x12 (or $x15))))
(let (($x59 (or $x32 $x334 false)))
(and (not $x59) (or $x59 (and (distinct ?x380 ?x380) true))))))))))))))))))
(check-sat)
; query 14: function gsm_L_add, block 8, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x340 (bvadd in1_64 (_ bv1 64))))
(let ((?x249 (bvsub (_ bv0 64) ?x340)))
(let ((?x20 (bvadd in0_64 (_ bv1 64))))
(let ((?x93 (bvsub (_ bv0 64) ?x20)))
(let ((?x380 (bvadd ?x93 ?x249)))
(let ((?x362 (ite (bvuge ?x380 (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x53 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x340)) ((_ sign_extend 1) ?x249)) true)))
(let ((?x675 ((_ sign_extend 1) ?x340)))
(let (($x43 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x675) true)))))
(let (($x334 (or false $x43 (or $x53))))
(let (($x15 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x20)) ((_ sign_extend 1) ?x93)) true)))
(let ((?x51 ((_ sign_extend 1) ?x20)))
(let (($x12 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x51) true)))))
(let (($x32 (or false $x12 (or $x15))))
(let (($x59 (or $x32 $x334 false)))
(let (($x45 (or $x59 false false)))
(and (not $x45) (or $x45 (and (distinct ?x362 ?x362) true))))))))))))))))))))
(check-sat)
; query 15: function gsm_L_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x20 (bvadd in0_64 (_ bv1 64))))
(let ((?x51 ((_ sign_extend 1) ?x20)))
(let (($x12 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x51) true)))))
(and (not $x12) (or $x12 (and (distinct ?x20 ?x20) true)))))))
(check-sat)
; query 16: function gsm_L_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x22 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x372 (or false false false)))
(let (($x168 (not $x372)))
(and $x168 (or $x372 (and (distinct ?x22 ?x22) true)))))))
(check-sat)
; query 17: function gsm_L_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x54 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x372 (or false false false)))
(let (($x168 (not $x372)))
(and $x168 (or $x372 (and (distinct ?x54 ?x54) true)))))))
(check-sat)
; query 18: function gsm_L_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x22 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x372 (or false false false)))
(let (($x168 (not $x372)))
(and $x168 (or $x372 (and (distinct ?x22 ?x22) true)))))))
(check-sat)
; query 19: function gsm_L_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x22 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x18 ((_ zero_extend 31) ?x22)))
(let (($x372 (or false false false)))
(let (($x34 (or $x372 false)))
(and (not $x34) (or $x34 (and (distinct ?x18 ?x18) true))))))))
(check-sat)
; query 20: function gsm_L_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x22 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x18 ((_ zero_extend 31) ?x22)))
(let ((?x295 (bvsub (_ bv0 32) ?x18)))
(let (($x423 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x18)) ((_ sign_extend 1) ?x295)) true)))
(let (($x372 (or false false false)))
(let (($x34 (or $x372 false)))
(let (($x542 (or false $x34 (or $x423))))
(and (not $x542) (or $x542 (and (distinct ?x295 ?x295) true)))))))))))
(check-sat)
; query 21: function gsm_L_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x22 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x18 ((_ zero_extend 31) ?x22)))
(let ((?x295 (bvsub (_ bv0 32) ?x18)))
(let ((?x72 ((_ sign_extend 32) ?x295)))
(let (($x423 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x18)) ((_ sign_extend 1) ?x295)) true)))
(let (($x372 (or false false false)))
(let (($x34 (or $x372 false)))
(let (($x542 (or false $x34 (or $x423))))
(let (($x28 (or $x542 false)))
(and (not $x28) (or $x28 (and (distinct ?x72 ?x72) true)))))))))))))
(check-sat)
; query 22: function gsm_L_asr, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x241 (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x372 (or false false false)))
(let (($x168 (not $x372)))
(and $x168 (or $x372 (and (distinct ?x241 ?x241) true)))))))
(check-sat)
; query 23: function gsm_L_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x54 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x372 (or false false false)))
(let (($x168 (not $x372)))
(and $x168 (or $x372 (and (distinct ?x54 ?x54) true)))))))
(check-sat)
; query 24: function gsm_L_sub, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x180 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x372 (or false false false)))
(let (($x168 (not $x372)))
(and $x168 (or $x372 (and (distinct ?x180 ?x180) true)))))))
(check-sat)
; query 25: function gsm_L_sub, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x290 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvsub in0_64 in1_64))) true)))
(let (($x403 (or false false (or $x290))))
(let (($x429 (or $x403 (and (distinct (bvsub in0_64 in1_64) (bvsub in0_64 in1_64)) true))))
(and (not $x403) $x429)))))
(check-sat)
; query 26: function gsm_L_sub, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x340 (bvadd in1_64 (_ bv1 64))))
(let ((?x249 (bvsub (_ bv0 64) ?x340)))
(let (($x53 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x340)) ((_ sign_extend 1) ?x249)) true)))
(let ((?x675 ((_ sign_extend 1) ?x340)))
(let (($x43 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x675) true)))))
(let (($x334 (or false $x43 (or $x53))))
(and (not $x334) (or $x334 (and (distinct ?x249 ?x249) true))))))))))
(check-sat)
; query 27: function gsm_L_sub, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x340 (bvadd in1_64 (_ bv1 64))))
(let ((?x249 (bvsub (_ bv0 64) ?x340)))
(let ((?x345 (bvadd in0_64 ?x249)))
(let (($x53 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x340)) ((_ sign_extend 1) ?x249)) true)))
(let ((?x675 ((_ sign_extend 1) ?x340)))
(let (($x43 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x675) true)))))
(let (($x334 (or false $x43 (or $x53))))
(let (($x106 (or false $x334 false)))
(and (not $x106) (or $x106 (and (distinct ?x345 ?x345) true))))))))))))
(check-sat)
; query 28: function gsm_L_sub, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x440 (ite (bvuge (bvadd in0_64 (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64)))) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x53 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) (bvadd in1_64 (_ bv1 64)))) ((_ sign_extend 1) (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64))))) true)))
(let ((?x340 (bvadd in1_64 (_ bv1 64))))
(let ((?x675 ((_ sign_extend 1) ?x340)))
(let (($x43 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x675) true)))))
(let (($x334 (or false $x43 (or $x53))))
(let (($x106 (or false $x334 false)))
(let (($x615 (or $x106 false false)))
(and (not $x615) (or $x615 (and (distinct ?x440 ?x440) true))))))))))))
(check-sat)
; query 29: function gsm_L_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x340 (bvadd in1_64 (_ bv1 64))))
(let ((?x675 ((_ sign_extend 1) ?x340)))
(let (($x43 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x675) true)))))
(and (not $x43) (or $x43 (and (distinct ?x340 ?x340) true)))))))
(check-sat)
; query 30: function gsm_L_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x577 (ite (bvsle (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x372 (or false false false)))
(let (($x168 (not $x372)))
(and $x168 (or $x372 (and (distinct ?x577 ?x577) true)))))))
(check-sat)
; query 31: function gsm_abs, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x727 (or false false)))
(let (($x111 (not $x727)))
(and $x111 (or $x727 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 32: function gsm_abs, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x731 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x727 (or false false)))
(let (($x598 (or $x727 false false)))
(let (($x9 (not $x598)))
(and $x9 (or $x598 (and (distinct ?x731 ?x731) true))))))))
(check-sat)
; query 33: function gsm_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x727 (or false false)))
(let (($x111 (not $x727)))
(and $x111 (or $x727 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 34: function gsm_add, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x727 (or false false)))
(let (($x111 (not $x727)))
(and $x111 (or $x727 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 35: function gsm_add, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x547 ((_ sign_extend 48) in1_16)))
(let ((?x297 ((_ sign_extend 48) in0_16)))
(let ((?x164 (bvadd ?x297 ?x547)))
(let (($x267 (and (distinct (bvadd ((_ sign_extend 1) ?x297) ((_ sign_extend 1) ?x547)) ((_ sign_extend 1) ?x164)) true)))
(let (($x727 (or false false)))
(let (($x145 (or $x727 $x727 (or $x267))))
(and (not $x145) (or $x145 (and (distinct ?x164 ?x164) true))))))))))
(check-sat)
; query 36: function gsm_add, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x351 (ite (bvsgt (_ bv18446744073709518848 64) (bvadd ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x547 ((_ sign_extend 48) in1_16)))
(let ((?x392 ((_ sign_extend 1) ?x547)))
(let ((?x297 ((_ sign_extend 48) in0_16)))
(let ((?x313 ((_ sign_extend 1) ?x297)))
(let (($x727 (or false false)))
(let (($x145 (or $x727 $x727 (or (and (distinct (bvadd ?x313 ?x392) ((_ sign_extend 1) (bvadd ?x297 ?x547))) true)))))
(let (($x687 (or $x145 false false)))
(and (not $x687) (or $x687 (and (distinct ?x351 ?x351) true))))))))))))
(check-sat)
; query 37: function gsm_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x668 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x372 (or false false false)))
(let (($x168 (not $x372)))
(and $x168 (or $x372 (and (distinct ?x668 ?x668) true)))))))
(check-sat)
; query 38: function gsm_asr, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x633 (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x372 (or false false false)))
(let (($x168 (not $x372)))
(and $x168 (or $x372 (and (distinct ?x633 ?x633) true)))))))
(check-sat)
; query 39: function gsm_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x727 (or false false)))
(let (($x111 (not $x727)))
(and $x111 (or $x727 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 40: function gsm_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x731 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x727 (or false false)))
(let (($x598 (or $x727 false false)))
(let (($x9 (not $x598)))
(and $x9 (or $x598 (and (distinct ?x731 ?x731) true))))))))
(check-sat)
; query 41: function gsm_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x731 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x872 ((_ zero_extend 31) ?x731)))
(let (($x727 (or false false)))
(let (($x598 (or $x727 false false)))
(let (($x595 (or $x598 false)))
(and (not $x595) (or $x595 (and (distinct ?x872 ?x872) true)))))))))
(check-sat)
; query 42: function gsm_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x731 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x872 ((_ zero_extend 31) ?x731)))
(let ((?x208 (bvsub (_ bv0 32) ?x872)))
(let (($x567 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x872)) ((_ sign_extend 1) ?x208)) true)))
(let (($x727 (or false false)))
(let (($x598 (or $x727 false false)))
(let (($x595 (or $x598 false)))
(let (($x915 (or false $x595 (or $x567))))
(and (not $x915) (or $x915 (and (distinct ?x208 ?x208) true))))))))))))
(check-sat)
; query 43: function gsm_asr, block 4, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x731 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x872 ((_ zero_extend 31) ?x731)))
(let ((?x208 (bvsub (_ bv0 32) ?x872)))
(let ((?x77 ((_ extract 15 0) ?x208)))
(let (($x567 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x872)) ((_ sign_extend 1) ?x208)) true)))
(let (($x727 (or false false)))
(let (($x598 (or $x727 false false)))
(let (($x595 (or $x598 false)))
(let (($x915 (or false $x595 (or $x567))))
(let (($x736 (or $x915 false)))
(and (not $x736) (or $x736 (and (distinct ?x77 ?x77) true))))))))))))))
(check-sat)
; query 44: function gsm_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x668 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x372 (or false false false)))
(let (($x168 (not $x372)))
(and $x168 (or $x372 (and (distinct ?x668 ?x668) true)))))))
(check-sat)
; query 45: function gsm_debug_longwords, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in15_32 () (_ BitVec 32))
(assert
 (let ((?x70 (ite (bvslt in15_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x372 (or false false false)))
(let (($x168 (not $x372)))
(and $x168 (or $x372 (and (distinct ?x70 ?x70) true)))))))
(check-sat)
; query 46: function gsm_debug_words, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in16_32 () (_ BitVec 32))
(assert
 (let ((?x306 (ite (bvslt in16_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x372 (or false false false)))
(let (($x168 (not $x372)))
(and $x168 (or $x372 (and (distinct ?x306 ?x306) true)))))))
(check-sat)
; query 47: function gsm_div, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x727 (or false false)))
(let (($x111 (not $x727)))
(and $x111 (or $x727 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 48: function gsm_div, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x727 (or false false)))
(let (($x111 (not $x727)))
(and $x111 (or $x727 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 49: function gsm_div, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x727 (or false false)))
(let (($x111 (not $x727)))
(and $x111 (or $x727 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 50: function gsm_div, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x134 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x115 (and (distinct ?x134 ?x134) true)))
(let (($x727 (or false false)))
(let (($x598 (or $x727 false false)))
(let (($x9 (not $x598)))
(and $x9 (or $x598 $x115))))))))
(check-sat)
; query 51: function gsm_norm, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x545 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x372 (or false false false)))
(let (($x168 (not $x372)))
(and $x168 (or $x372 (and (distinct ?x545 ?x545) true)))))))
(check-sat)
; query 52: function gsm_norm, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x545 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x430 (bvxor ?x545 (_ bv1 1))))
(let (($x372 (or false false false)))
(let (($x461 (or $x372 false false)))
(and (not $x461) (or $x461 (and (distinct ?x430 ?x430) true))))))))
(check-sat)
; query 53: function gsm_norm, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x545 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x430 (bvxor ?x545 (_ bv1 1))))
(let ((?x527 ((_ zero_extend 31) ?x430)))
(let (($x372 (or false false false)))
(let (($x461 (or $x372 false false)))
(let (($x608 (or $x461 false)))
(and (not $x608) (or $x608 (and (distinct ?x527 ?x527) true))))))))))
(check-sat)
; query 54: function gsm_norm, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x545 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x430 (bvxor ?x545 (_ bv1 1))))
(let ((?x527 ((_ zero_extend 31) ?x430)))
(let ((?x257 ((_ sign_extend 32) ?x527)))
(let (($x372 (or false false false)))
(let (($x461 (or $x372 false false)))
(let (($x608 (or $x461 false)))
(let (($x919 (or $x608 false)))
(and (not $x919) (or $x919 (and (distinct ?x257 ?x257) true))))))))))))
(check-sat)
; query 55: function gsm_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x727 (or false false)))
(let (($x111 (not $x727)))
(and $x111 (or $x727 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 56: function gsm_sub, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x727 (or false false)))
(let (($x111 (not $x727)))
(and $x111 (or $x727 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 57: function gsm_sub, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x547 ((_ sign_extend 48) in1_16)))
(let ((?x297 ((_ sign_extend 48) in0_16)))
(let ((?x655 (bvsub ?x297 ?x547)))
(let (($x730 (and (distinct (bvsub ((_ sign_extend 1) ?x297) ((_ sign_extend 1) ?x547)) ((_ sign_extend 1) ?x655)) true)))
(let (($x727 (or false false)))
(let (($x779 (or $x727 $x727 (or $x730))))
(and (not $x779) (or $x779 (and (distinct ?x655 ?x655) true))))))))))
(check-sat)
; query 58: function gsm_sub, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x532 (ite (bvsgt (_ bv18446744073709518848 64) (bvsub ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x547 ((_ sign_extend 48) in1_16)))
(let ((?x392 ((_ sign_extend 1) ?x547)))
(let ((?x297 ((_ sign_extend 48) in0_16)))
(let ((?x313 ((_ sign_extend 1) ?x297)))
(let (($x727 (or false false)))
(let (($x779 (or $x727 $x727 (or (and (distinct (bvsub ?x313 ?x392) ((_ sign_extend 1) (bvsub ?x297 ?x547))) true)))))
(let (($x135 (or $x779 false false)))
(and (not $x135) (or $x135 (and (distinct ?x532 ?x532) true))))))))))))
(check-sat)
