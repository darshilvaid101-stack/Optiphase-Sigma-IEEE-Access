; OptiPhase-Sigma refinement certificate for sweep K44-R4-323
; query 0: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x703 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x98 (or false false false)))
(let (($x512 (not $x98)))
(and $x512 (or $x98 (and (distinct ?x703 ?x703) true)))))))
(check-sat)
; query 1: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x137 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x98 (or false false false)))
(let (($x512 (not $x98)))
(and $x512 (or $x98 (and (distinct ?x137 ?x137) true)))))))
(check-sat)
