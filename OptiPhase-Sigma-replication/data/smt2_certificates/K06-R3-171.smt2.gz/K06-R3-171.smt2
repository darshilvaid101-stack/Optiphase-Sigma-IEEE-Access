; OptiPhase-Sigma refinement certificate for sweep K06-R3-171
; query 0: function xmalloc, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in7_32 () (_ BitVec 32))
(assert
 (let ((?x62 (ite (and (distinct (_ bv0 32) in7_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x84 (or false false false)))
(and (not $x84) (or $x84 (and (distinct ?x62 ?x62) true))))))
(check-sat)
