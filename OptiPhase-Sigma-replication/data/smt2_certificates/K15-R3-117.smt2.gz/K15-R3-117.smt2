; OptiPhase-Sigma refinement certificate for sweep K15-R3-117
