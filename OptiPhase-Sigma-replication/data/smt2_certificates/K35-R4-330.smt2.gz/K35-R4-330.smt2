; OptiPhase-Sigma refinement certificate for sweep K35-R4-330
; query 0: function edge_draw, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let ((?x169 (ite (= (_ bv0 32) in4_32) (_ bv1 1) (_ bv0 1))))
(let (($x230 (or false false false)))
(and (not $x230) (or $x230 (and (distinct ?x169 ?x169) true))))))
(check-sat)
