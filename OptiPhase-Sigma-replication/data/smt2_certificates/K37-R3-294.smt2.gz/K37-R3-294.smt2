; OptiPhase-Sigma refinement certificate for sweep K37-R3-294
; query 0: function bit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x94 (and (distinct (bvsub ((_ sign_extend 1) (_ bv31 32)) ((_ sign_extend 1) in0_32)) ((_ sign_extend 1) (bvsub (_ bv31 32) in0_32))) true)))
(let (($x261 (or false false (or $x94))))
(and (not $x261) (or $x261 (and (distinct (bvsub (_ bv31 32) in0_32) (bvsub (_ bv31 32) in0_32)) true))))))
(check-sat)
; query 1: function bit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x497 (bvsub (_ bv31 32) in0_32)))
(let ((?x9 (bvshl (_ bv1 32) ?x497)))
(let (($x94 (and (distinct (bvsub ((_ sign_extend 1) (_ bv31 32)) ((_ sign_extend 1) in0_32)) ((_ sign_extend 1) ?x497)) true)))
(let (($x261 (or false false (or $x94))))
(let (($x14 (or (or false $x261 false) (bvuge ?x497 (_ bv32 32)))))
(and (not $x14) (or $x14 (and (distinct ?x9 ?x9) true)))))))))
(check-sat)
; query 2: function bit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x497 (bvsub (_ bv31 32) in0_32)))
(let ((?x9 (bvshl (_ bv1 32) ?x497)))
(let ((?x514 ((_ sign_extend 32) ?x9)))
(let (($x94 (and (distinct (bvsub ((_ sign_extend 1) (_ bv31 32)) ((_ sign_extend 1) in0_32)) ((_ sign_extend 1) ?x497)) true)))
(let (($x261 (or false false (or $x94))))
(let (($x14 (or (or false $x261 false) (bvuge ?x497 (_ bv32 32)))))
(let (($x158 (or $x14 false)))
(and (not $x158) (or $x158 (and (distinct ?x514 ?x514) true)))))))))))
(check-sat)
; query 3: function bit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x497 (bvsub (_ bv31 32) in0_32)))
(let ((?x9 (bvshl (_ bv1 32) ?x497)))
(let ((?x514 ((_ sign_extend 32) ?x9)))
(let ((?x66 (bvand in1_64 ?x514)))
(let (($x94 (and (distinct (bvsub ((_ sign_extend 1) (_ bv31 32)) ((_ sign_extend 1) in0_32)) ((_ sign_extend 1) ?x497)) true)))
(let (($x261 (or false false (or $x94))))
(let (($x14 (or (or false $x261 false) (bvuge ?x497 (_ bv32 32)))))
(let (($x158 (or $x14 false)))
(let (($x117 (or false $x158 false)))
(and (not $x117) (or $x117 (and (distinct ?x66 ?x66) true)))))))))))))
(check-sat)
