; OptiPhase-Sigma refinement certificate for sweep K45-R3-104
; query 0: function Index_to_frequency, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x137 (ite (bvuge in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x38 (or false false false)))
(let (($x533 (not $x38)))
(and $x533 (or $x38 (and (distinct ?x137 ?x137) true)))))))
(check-sat)
; query 1: function IsPowerOfTwo, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x512 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x38 (or false false false)))
(let (($x533 (not $x38)))
(and $x533 (or $x38 (and (distinct ?x512 ?x512) true)))))))
(check-sat)
; query 2: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x512 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x38 (or false false false)))
(let (($x533 (not $x38)))
(and $x533 (or $x38 (and (distinct ?x512 ?x512) true)))))))
(check-sat)
; query 3: function main, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x449 (ite (= (_ bv4 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x38 (or false false false)))
(let (($x533 (not $x38)))
(and $x533 (or $x38 (and (distinct ?x449 ?x449) true)))))))
(check-sat)
; query 4: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x167 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x38 (or false false false)))
(let (($x533 (not $x38)))
(and $x533 (or $x38 (and (distinct ?x167 ?x167) true)))))))
(check-sat)
