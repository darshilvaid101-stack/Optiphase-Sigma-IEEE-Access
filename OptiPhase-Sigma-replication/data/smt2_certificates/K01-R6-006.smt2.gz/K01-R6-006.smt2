; OptiPhase-Sigma refinement certificate for sweep K01-R6-006
