; OptiPhase-Sigma refinement certificate for sweep K51-R3-106
; query 0: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x1934 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x148 (or false false false)))
(and (not $x148) (or $x148 (and (distinct ?x1934 ?x1934) true))))))
(check-sat)
