; OptiPhase-Sigma refinement certificate for sweep K57-R2-021
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x269 (or false false)))
(let (($x18 (not $x269)))
(and $x18 (or $x269 (and (distinct ((_ sign_extend 16) in25_16) ((_ sign_extend 16) in25_16)) true))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let ((?x638 (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))))
(let (($x269 (or false false)))
(let (($x222 (or $x269 false false)))
(let (($x337 (not $x222)))
(and $x337 (or $x222 (and (distinct ?x638 ?x638) true))))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x269 (or false false)))
(let (($x18 (not $x269)))
(and $x18 (or $x269 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x1263 ((_ sign_extend 16) in3_16)))
(let ((?x347 (bvand ?x1263 (_ bv127 32))))
(let (($x269 (or false false)))
(let (($x222 (or $x269 false false)))
(let (($x337 (not $x222)))
(and $x337 (or $x222 (and (distinct ?x347 ?x347) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x1263 ((_ sign_extend 16) in3_16)))
(let ((?x347 (bvand ?x1263 (_ bv127 32))))
(let ((?x800 ((_ extract 15 0) ?x347)))
(let (($x269 (or false false)))
(let (($x222 (or $x269 false false)))
(let (($x762 (or $x222 false)))
(let (($x173 (not $x762)))
(and $x173 (or $x762 (and (distinct ?x800 ?x800) true)))))))))))
(check-sat)
; query 5: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x269 (or false false)))
(let (($x18 (not $x269)))
(and $x18 (or $x269 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 6: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x318 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x269 (or false false)))
(let (($x222 (or $x269 false false)))
(let (($x337 (not $x222)))
(and $x337 (or $x222 (and (distinct ?x318 ?x318) true))))))))
(check-sat)
; query 7: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x233 (or false false false)))
(let (($x230 (not $x233)))
(and $x230 (or $x233 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x65 (bvadd in.01_32 (_ bv1 32))))
(let ((?x143 (bvmul ?x65 ?x65)))
(let (($x233 (or false false false)))
(let (($x241 (or $x233 $x233 false)))
(and (not $x241) (or $x241 (and (distinct ?x143 ?x143) true))))))))
(check-sat)
; query 9: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x65 (bvadd in.01_32 (_ bv1 32))))
(let ((?x143 (bvmul ?x65 ?x65)))
(let ((?x72 (bvmul ?x143 (_ bv2 32))))
(let (($x233 (or false false false)))
(let (($x241 (or $x233 $x233 false)))
(let (($x130 (or $x241 false false)))
(and (not $x130) (or $x130 (and (distinct ?x72 ?x72) true))))))))))
(check-sat)
; query 10: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x65 (bvadd in.01_32 (_ bv1 32))))
(let ((?x143 (bvmul ?x65 ?x65)))
(let ((?x72 (bvmul ?x143 (_ bv2 32))))
(let ((?x1267 (bvmul ?x72 (_ bv4 32))))
(let (($x233 (or false false false)))
(let (($x241 (or $x233 $x233 false)))
(let (($x130 (or $x241 false false)))
(let (($x81 (or $x130 false false)))
(and (not $x81) (or $x81 (and (distinct ?x1267 ?x1267) true))))))))))))
(check-sat)
; query 11: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x868 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x233 (or false false false)))
(let (($x230 (not $x233)))
(and $x230 (or $x233 (and (distinct ?x868 ?x868) true)))))))
(check-sat)
; query 12: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x547 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x233 (or false false false)))
(let (($x230 (not $x233)))
(and $x230 (or $x233 (and (distinct ?x547 ?x547) true)))))))
(check-sat)
; query 13: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x233 (or false false false)))
(let (($x230 (not $x233)))
(and $x230 (or $x233 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 14: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x423 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x721 (or false false (or $x423))))
(and (not $x721) (or $x721 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 15: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x61 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x233 (or false false false)))
(let (($x230 (not $x233)))
(and $x230 (or $x233 (and (distinct ?x61 ?x61) true)))))))
(check-sat)
; query 16: function crcu8, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x269 (or false false)))
(let (($x18 (not $x269)))
(and $x18 (or $x269 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 17: function crcu8, block 19, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x798 ((_ zero_extend 16) in.01_16)))
(let ((?x109 (bvxor ?x798 (_ bv16386 32))))
(let (($x269 (or false false)))
(let (($x222 (or $x269 false false)))
(let (($x337 (not $x222)))
(and $x337 (or $x222 (and (distinct ?x109 ?x109) true)))))))))
(check-sat)
; query 18: function crcu8, block 19, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x798 ((_ zero_extend 16) in.01_16)))
(let ((?x109 (bvxor ?x798 (_ bv16386 32))))
(let ((?x496 ((_ extract 15 0) ?x109)))
(let (($x269 (or false false)))
(let (($x222 (or $x269 false false)))
(let (($x762 (or $x222 false)))
(let (($x173 (not $x762)))
(and $x173 (or $x762 (and (distinct ?x496 ?x496) true)))))))))))
(check-sat)
; query 19: function crcu8, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x21 ((_ extract 7 0) in.01_16)))
(let ((?x101 ((_ zero_extend 24) ?x21)))
(let (($x269 (or false false)))
(let (($x231 (or $x269 false)))
(and (not $x231) (or $x231 (and (distinct ?x101 ?x101) true))))))))
(check-sat)
; query 20: function crcu8, block 6, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x21 ((_ extract 7 0) in.01_16)))
(let ((?x101 ((_ zero_extend 24) ?x21)))
(let ((?x939 (bvand ?x101 (_ bv1 32))))
(let (($x269 (or false false)))
(let (($x231 (or $x269 false)))
(let (($x806 (or $x231 false false)))
(and (not $x806) (or $x806 (and (distinct ?x939 ?x939) true))))))))))
(check-sat)
; query 21: function crcu8, block 6, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x21 ((_ extract 7 0) in.01_16)))
(let ((?x101 ((_ zero_extend 24) ?x21)))
(let ((?x939 (bvand ?x101 (_ bv1 32))))
(let ((?x281 ((_ zero_extend 24) in.0_8)))
(let ((?x145 (bvand ?x281 (_ bv1 32))))
(let ((?x376 (bvxor ?x145 ?x939)))
(let (($x269 (or false false)))
(let (($x231 (or $x269 false)))
(let (($x806 (or $x231 false false)))
(let (($x222 (or $x269 false false)))
(let (($x743 (or $x222 $x806 false)))
(and (not $x743) (or $x743 (and (distinct ?x376 ?x376) true)))))))))))))))
(check-sat)
; query 22: function crcu8, block 6, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x21 ((_ extract 7 0) in.01_16)))
(let ((?x101 ((_ zero_extend 24) ?x21)))
(let ((?x939 (bvand ?x101 (_ bv1 32))))
(let ((?x281 ((_ zero_extend 24) in.0_8)))
(let ((?x145 (bvand ?x281 (_ bv1 32))))
(let ((?x376 (bvxor ?x145 ?x939)))
(let ((?x893 ((_ extract 7 0) ?x376)))
(let (($x269 (or false false)))
(let (($x231 (or $x269 false)))
(let (($x806 (or $x231 false false)))
(let (($x222 (or $x269 false false)))
(let (($x743 (or $x222 $x806 false)))
(let (($x12 (or $x743 false)))
(and (not $x12) (or $x12 (and (distinct ?x893 ?x893) true)))))))))))))))))
(check-sat)
; query 23: function crcu8, block 6, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x269 (or false false)))
(let (($x18 (not $x269)))
(and $x18 (or $x269 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 24: function crcu8, block 6, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x281 ((_ zero_extend 24) in.0_8)))
(let ((?x285 (bvashr ?x281 (_ bv1 32))))
(let (($x269 (or false false)))
(let (($x222 (or $x269 false false)))
(let (($x785 (or $x222 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not $x785) (or $x785 (and (distinct ?x285 ?x285) true)))))))))
(check-sat)
; query 25: function crcu8, block 6, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x281 ((_ zero_extend 24) in.0_8)))
(let ((?x285 (bvashr ?x281 (_ bv1 32))))
(let ((?x124 ((_ extract 7 0) ?x285)))
(let (($x269 (or false false)))
(let (($x222 (or $x269 false false)))
(let (($x785 (or $x222 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x94 (or $x785 false)))
(and (not $x94) (or $x94 (and (distinct ?x124 ?x124) true)))))))))))
(check-sat)
; query 26: function crcu8, block 6, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x21 ((_ extract 7 0) in.01_16)))
(let ((?x101 ((_ zero_extend 24) ?x21)))
(let ((?x939 (bvand ?x101 (_ bv1 32))))
(let ((?x281 ((_ zero_extend 24) in.0_8)))
(let ((?x145 (bvand ?x281 (_ bv1 32))))
(let ((?x376 (bvxor ?x145 ?x939)))
(let ((?x893 ((_ extract 7 0) ?x376)))
(let ((?x22 ((_ zero_extend 24) ?x893)))
(let (($x269 (or false false)))
(let (($x231 (or $x269 false)))
(let (($x806 (or $x231 false false)))
(let (($x222 (or $x269 false false)))
(let (($x743 (or $x222 $x806 false)))
(let (($x12 (or $x743 false)))
(let (($x221 (or $x12 false)))
(and (not $x221) (or $x221 (and (distinct ?x22 ?x22) true)))))))))))))))))))
(check-sat)
; query 27: function crcu8, block 6, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x21 ((_ extract 7 0) in.01_16)))
(let ((?x101 ((_ zero_extend 24) ?x21)))
(let ((?x939 (bvand ?x101 (_ bv1 32))))
(let ((?x281 ((_ zero_extend 24) in.0_8)))
(let ((?x145 (bvand ?x281 (_ bv1 32))))
(let ((?x376 (bvxor ?x145 ?x939)))
(let ((?x893 ((_ extract 7 0) ?x376)))
(let ((?x22 ((_ zero_extend 24) ?x893)))
(let ((?x13 (ite (= (_ bv1 32) ?x22) (_ bv1 1) (_ bv0 1))))
(let (($x269 (or false false)))
(let (($x231 (or $x269 false)))
(let (($x806 (or $x231 false false)))
(let (($x222 (or $x269 false false)))
(let (($x743 (or $x222 $x806 false)))
(let (($x12 (or $x743 false)))
(let (($x221 (or $x12 false)))
(let (($x497 (or $x221 false false)))
(and (not $x497) (or $x497 (and (distinct ?x13 ?x13) true)))))))))))))))))))))
(check-sat)
; query 28: function crcu8, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x269 (or false false)))
(let (($x18 (not $x269)))
(and $x18 (or $x269 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 29: function crcu8, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x281 ((_ zero_extend 24) in.0_8)))
(let ((?x145 (bvand ?x281 (_ bv1 32))))
(let (($x269 (or false false)))
(let (($x222 (or $x269 false false)))
(let (($x337 (not $x222)))
(and $x337 (or $x222 (and (distinct ?x145 ?x145) true)))))))))
(check-sat)
; query 30: function crcu8, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x269 (or false false)))
(let (($x18 (not $x269)))
(and $x18 (or $x269 (and (distinct ((_ extract 7 0) in.01_16) ((_ extract 7 0) in.01_16)) true))))))
(check-sat)
; query 31: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1235 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x63 ((_ zero_extend 31) ?x1235)))
(let ((?x10 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x30 ((_ zero_extend 31) ?x10)))
(let ((?x1277 (bvand ?x30 ?x63)))
(let ((?x1281 (ite (and (distinct (_ bv0 32) ?x1277) true) (_ bv1 1) (_ bv0 1))))
(let ((?x1282 ((_ zero_extend 63) ?x1281)))
(let (($x269 (or false false)))
(let (($x222 (or $x269 false false)))
(let (($x762 (or $x222 false)))
(let (($x1261 (or $x762 $x762 false)))
(let (($x1278 (or $x1261 false false)))
(let (($x1286 (or $x1278 false)))
(and (not $x1286) (or $x1286 (and (distinct ?x1282 ?x1282) true)))))))))))))))))
(check-sat)
; query 32: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1235 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x63 ((_ zero_extend 31) ?x1235)))
(let ((?x10 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x30 ((_ zero_extend 31) ?x10)))
(let ((?x1277 (bvand ?x30 ?x63)))
(let ((?x1281 (ite (and (distinct (_ bv0 32) ?x1277) true) (_ bv1 1) (_ bv0 1))))
(let (($x1301 (= (_ bv1 1) ?x1281)))
(let ((?x1305 (ite $x1301 (_ bv1 32) (_ bv0 32))))
(let (($x269 (or false false)))
(let (($x222 (or $x269 false false)))
(let (($x762 (or $x222 false)))
(let (($x1261 (or $x762 $x762 false)))
(let (($x1278 (or $x1261 false false)))
(let (($x1308 (or $x1278 (ite $x1301 false false))))
(and (not $x1308) (or $x1308 (and (distinct ?x1305 ?x1305) true))))))))))))))))))
(check-sat)
; query 33: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1235 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x63 ((_ zero_extend 31) ?x1235)))
(let ((?x10 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x30 ((_ zero_extend 31) ?x10)))
(let ((?x1277 (bvand ?x30 ?x63)))
(let ((?x1281 (ite (and (distinct (_ bv0 32) ?x1277) true) (_ bv1 1) (_ bv0 1))))
(let (($x1301 (= (_ bv1 1) ?x1281)))
(let ((?x1305 (ite $x1301 (_ bv1 32) (_ bv0 32))))
(let ((?x1329 ((_ extract 7 0) ?x1305)))
(let (($x269 (or false false)))
(let (($x222 (or $x269 false false)))
(let (($x762 (or $x222 false)))
(let (($x1261 (or $x762 $x762 false)))
(let (($x1278 (or $x1261 false false)))
(let (($x1308 (or $x1278 (ite $x1301 false false))))
(let (($x1330 (or $x1308 false)))
(and (not $x1330) (or $x1330 (and (distinct ?x1329 ?x1329) true))))))))))))))))))))
(check-sat)
; query 34: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x269 (or false false)))
(let (($x18 (not $x269)))
(and $x18 (or $x269 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 35: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x10 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x269 (or false false)))
(let (($x222 (or $x269 false false)))
(let (($x337 (not $x222)))
(and $x337 (or $x222 (and (distinct ?x10 ?x10) true))))))))
(check-sat)
; query 36: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x10 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x30 ((_ zero_extend 31) ?x10)))
(let (($x269 (or false false)))
(let (($x222 (or $x269 false false)))
(let (($x762 (or $x222 false)))
(let (($x173 (not $x762)))
(and $x173 (or $x762 (and (distinct ?x30 ?x30) true))))))))))
(check-sat)
; query 37: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x269 (or false false)))
(let (($x18 (not $x269)))
(and $x18 (or $x269 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 38: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1235 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x269 (or false false)))
(let (($x222 (or $x269 false false)))
(let (($x337 (not $x222)))
(and $x337 (or $x222 (and (distinct ?x1235 ?x1235) true))))))))
(check-sat)
; query 39: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1235 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x63 ((_ zero_extend 31) ?x1235)))
(let (($x269 (or false false)))
(let (($x222 (or $x269 false false)))
(let (($x762 (or $x222 false)))
(let (($x173 (not $x762)))
(and $x173 (or $x762 (and (distinct ?x63 ?x63) true))))))))))
(check-sat)
; query 40: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1235 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x63 ((_ zero_extend 31) ?x1235)))
(let ((?x10 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x30 ((_ zero_extend 31) ?x10)))
(let ((?x1277 (bvand ?x30 ?x63)))
(let (($x269 (or false false)))
(let (($x222 (or $x269 false false)))
(let (($x762 (or $x222 false)))
(let (($x1261 (or $x762 $x762 false)))
(and (not $x1261) (or $x1261 (and (distinct ?x1277 ?x1277) true)))))))))))))
(check-sat)
; query 41: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1235 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x63 ((_ zero_extend 31) ?x1235)))
(let ((?x10 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x30 ((_ zero_extend 31) ?x10)))
(let ((?x1277 (bvand ?x30 ?x63)))
(let ((?x1281 (ite (and (distinct (_ bv0 32) ?x1277) true) (_ bv1 1) (_ bv0 1))))
(let (($x269 (or false false)))
(let (($x222 (or $x269 false false)))
(let (($x762 (or $x222 false)))
(let (($x1261 (or $x762 $x762 false)))
(let (($x1278 (or $x1261 false false)))
(and (not $x1278) (or $x1278 (and (distinct ?x1281 ?x1281) true)))))))))))))))
(check-sat)
; query 42: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1373 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x233 (or false false false)))
(let (($x230 (not $x233)))
(and $x230 (or $x233 (and (distinct ?x1373 ?x1373) true)))))))
(check-sat)
; query 43: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x269 (or false false)))
(let (($x18 (not $x269)))
(and $x18 (or $x269 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 44: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x452 ((_ sign_extend 16) in.1_16)))
(let ((?x49 (bvadd ?x452 (_ bv10 32))))
(let (($x649 (and (distinct (bvadd ((_ sign_extend 1) ?x452) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x49)) true)))
(let (($x269 (or false false)))
(let (($x385 (or $x269 false (or $x649))))
(and (not $x385) (or $x385 (and (distinct ?x49 ?x49) true)))))))))
(check-sat)
; query 45: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x452 ((_ sign_extend 16) in.1_16)))
(let ((?x49 (bvadd ?x452 (_ bv10 32))))
(let ((?x713 ((_ extract 15 0) ?x49)))
(let (($x649 (and (distinct (bvadd ((_ sign_extend 1) ?x452) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x49)) true)))
(let (($x269 (or false false)))
(let (($x385 (or $x269 false (or $x649))))
(let (($x586 (or $x385 false)))
(and (not $x586) (or $x586 (and (distinct ?x713 ?x713) true)))))))))))
(check-sat)
; query 46: function matrix_sum, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x863 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x233 (or false false false)))
(let (($x230 (not $x233)))
(and $x230 (or $x233 (and (distinct ?x863 ?x863) true)))))))
(check-sat)
; query 47: function matrix_sum, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x863 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let ((?x525 ((_ zero_extend 63) ?x863)))
(let (($x233 (or false false false)))
(let (($x367 (or $x233 false)))
(and (not $x367) (or $x367 (and (distinct ?x525 ?x525) true))))))))
(check-sat)
; query 48: function matrix_sum, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x863 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x19 (= (_ bv1 1) ?x863)))
(let ((?x489 (ite $x19 (_ bv1 32) (_ bv0 32))))
(let (($x233 (or false false false)))
(let (($x487 (or $x233 (ite $x19 false false))))
(and (not $x487) (or $x487 (and (distinct ?x489 ?x489) true)))))))))
(check-sat)
; query 49: function matrix_sum, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x269 (or false false)))
(let (($x18 (not $x269)))
(and $x18 (or $x269 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 50: function matrix_sum, block 22, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x863 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x19 (= (_ bv1 1) ?x863)))
(let ((?x489 (ite $x19 (_ bv1 32) (_ bv0 32))))
(let ((?x452 ((_ sign_extend 16) in.1_16)))
(let ((?x85 (bvadd ?x452 ?x489)))
(let (($x733 (and (distinct (bvadd ((_ sign_extend 1) ?x452) ((_ sign_extend 1) ?x489)) ((_ sign_extend 1) ?x85)) true)))
(let (($x233 (or false false false)))
(let (($x487 (or $x233 (ite $x19 false false))))
(let (($x269 (or false false)))
(let (($x350 (or $x269 $x487 (or $x733))))
(and (not $x350) (or $x350 (and (distinct ?x85 ?x85) true))))))))))))))
(check-sat)
; query 51: function matrix_sum, block 22, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x863 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x19 (= (_ bv1 1) ?x863)))
(let ((?x489 (ite $x19 (_ bv1 32) (_ bv0 32))))
(let ((?x452 ((_ sign_extend 16) in.1_16)))
(let ((?x85 (bvadd ?x452 ?x489)))
(let ((?x1343 ((_ extract 15 0) ?x85)))
(let (($x733 (and (distinct (bvadd ((_ sign_extend 1) ?x452) ((_ sign_extend 1) ?x489)) ((_ sign_extend 1) ?x85)) true)))
(let (($x233 (or false false false)))
(let (($x487 (or $x233 (ite $x19 false false))))
(let (($x269 (or false false)))
(let (($x350 (or $x269 $x487 (or $x733))))
(let (($x223 (or $x350 false)))
(and (not $x223) (or $x223 (and (distinct ?x1343 ?x1343) true))))))))))))))))
(check-sat)
