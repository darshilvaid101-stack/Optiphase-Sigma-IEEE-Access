; OptiPhase-Sigma refinement certificate for sweep K56-R4-343
; query 0: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x1568 (or false false false)))
(let (($x1564 (not $x1568)))
(and $x1564 (or $x1568 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 1: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1516 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x1568 (or false false false)))
(let (($x1564 (not $x1568)))
(and $x1564 (or $x1568 (and (distinct ?x1516 ?x1516) true)))))))
(check-sat)
