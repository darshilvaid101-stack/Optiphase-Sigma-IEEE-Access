; OptiPhase-Sigma refinement certificate for sweep K50-R3-165
; query 0: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x91 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x339 (or false false false)))
(let (($x22 (not $x339)))
(and $x22 (or $x339 (and (distinct ?x91 ?x91) true)))))))
(check-sat)
; query 1: function set1d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x96 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x339 (or false false false)))
(let (($x22 (not $x339)))
(and $x22 (or $x339 (and (distinct ?x96 ?x96) true)))))))
(check-sat)
; query 2: function set1ds, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x757 (ite (= (_ bv4294967295 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x339 (or false false false)))
(let (($x22 (not $x339)))
(and $x22 (or $x339 (and (distinct ?x757 ?x757) true)))))))
(check-sat)
; query 3: function set2d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x96 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x339 (or false false false)))
(let (($x22 (not $x339)))
(and $x22 (or $x339 (and (distinct ?x96 ?x96) true)))))))
(check-sat)
