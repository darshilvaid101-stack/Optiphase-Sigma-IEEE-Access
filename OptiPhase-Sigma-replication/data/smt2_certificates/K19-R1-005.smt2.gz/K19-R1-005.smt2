; OptiPhase-Sigma refinement certificate for sweep K19-R1-005
