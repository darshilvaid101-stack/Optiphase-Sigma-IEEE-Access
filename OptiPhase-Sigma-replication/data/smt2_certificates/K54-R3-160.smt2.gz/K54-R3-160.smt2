; OptiPhase-Sigma refinement certificate for sweep K54-R3-160
; query 0: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x72 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x1111 (or false false false)))
(let (($x453 (not $x1111)))
(and $x453 (or $x1111 (and (distinct ?x72 ?x72) true)))))))
(check-sat)
; query 1: function set1d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x273 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x1111 (or false false false)))
(let (($x453 (not $x1111)))
(and $x453 (or $x1111 (and (distinct ?x273 ?x273) true)))))))
(check-sat)
; query 2: function set1ds, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x16 (ite (= (_ bv4294967295 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x1111 (or false false false)))
(let (($x453 (not $x1111)))
(and $x453 (or $x1111 (and (distinct ?x16 ?x16) true)))))))
(check-sat)
; query 3: function set2d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x273 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x1111 (or false false false)))
(let (($x453 (not $x1111)))
(and $x453 (or $x1111 (and (distinct ?x273 ?x273) true)))))))
(check-sat)
