; OptiPhase-Sigma refinement certificate for sweep K43-R3-261
; query 0: function main, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x257 (ite (and (distinct (_ bv0 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x753 (or false false false)))
(and (not $x753) (or $x753 (and (distinct ?x257 ?x257) true))))))
(check-sat)
; query 1: function main, block 17, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x257 (ite (and (distinct (_ bv0 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let ((?x492 ((_ zero_extend 31) ?x257)))
(let (($x753 (or false false false)))
(let (($x98 (or $x753 false)))
(and (not $x98) (or $x98 (and (distinct ?x492 ?x492) true))))))))
(check-sat)
