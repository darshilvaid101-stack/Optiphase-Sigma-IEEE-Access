; OptiPhase-Sigma refinement certificate for sweep K56-R2-072
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x44 (or false false)))
(let (($x517 (not $x44)))
(and $x517 (or $x44 (and (distinct ((_ sign_extend 16) in25_16) ((_ sign_extend 16) in25_16)) true))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let ((?x509 (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))))
(let (($x44 (or false false)))
(let (($x45 (or $x44 false false)))
(let (($x120 (not $x45)))
(and $x120 (or $x45 (and (distinct ?x509 ?x509) true))))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x44 (or false false)))
(let (($x517 (not $x44)))
(and $x517 (or $x44 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x564 ((_ sign_extend 16) in3_16)))
(let ((?x114 (bvand ?x564 (_ bv127 32))))
(let (($x44 (or false false)))
(let (($x45 (or $x44 false false)))
(let (($x120 (not $x45)))
(and $x120 (or $x45 (and (distinct ?x114 ?x114) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x564 ((_ sign_extend 16) in3_16)))
(let ((?x114 (bvand ?x564 (_ bv127 32))))
(let ((?x398 ((_ extract 15 0) ?x114)))
(let (($x44 (or false false)))
(let (($x45 (or $x44 false false)))
(let (($x238 (or $x45 false)))
(let (($x98 (not $x238)))
(and $x98 (or $x238 (and (distinct ?x398 ?x398) true)))))))))))
(check-sat)
; query 5: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x44 (or false false)))
(let (($x517 (not $x44)))
(and $x517 (or $x44 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 6: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x105 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x44 (or false false)))
(let (($x45 (or $x44 false false)))
(let (($x120 (not $x45)))
(and $x120 (or $x45 (and (distinct ?x105 ?x105) true))))))))
(check-sat)
; query 7: function core_bench_list, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x257 (or false false false)))
(let (($x90 (not $x257)))
(and $x90 (or $x257 (and (distinct (bvadd in.0_16 (_ bv1 16)) (bvadd in.0_16 (_ bv1 16))) true))))))
(check-sat)
; query 8: function core_bench_list, block 82, name %83
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let (($x44 (or false false)))
(let (($x517 (not $x44)))
(and $x517 (or $x44 (and (distinct ((_ zero_extend 16) in.02_16) ((_ zero_extend 16) in.02_16)) true))))))
(check-sat)
; query 9: function core_bench_list, block 82, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x711 ((_ zero_extend 16) in.02_16)))
(let ((?x87 (bvmul ?x711 (_ bv4 32))))
(let (($x77 (and (distinct (bvmul ((_ sign_extend 32) ?x711) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x87)) true)))
(let (($x44 (or false false)))
(let (($x264 (or $x44 false (or $x77))))
(and (not $x264) (or $x264 (and (distinct ?x87 ?x87) true)))))))))
(check-sat)
; query 10: function core_bench_list, block 82, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let (($x44 (or false false)))
(let (($x517 (not $x44)))
(and $x517 (or $x44 (and (distinct ((_ zero_extend 16) in.04_16) ((_ zero_extend 16) in.04_16)) true))))))
(check-sat)
; query 11: function core_bench_list, block 82, name %86
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x159 ((_ zero_extend 16) in.04_16)))
(let ((?x711 ((_ zero_extend 16) in.02_16)))
(let ((?x87 (bvmul ?x711 (_ bv4 32))))
(let ((?x1599 (bvsub ?x87 ?x159)))
(let ((?x378 ((_ sign_extend 1) ?x1599)))
(let (($x44 (or false false)))
(let (($x77 (and (distinct (bvmul ((_ sign_extend 32) ?x711) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x87)) true)))
(let (($x264 (or $x44 false (or $x77))))
(let (($x139 (or $x264 $x44 (or (and (distinct (bvsub ((_ sign_extend 1) ?x87) ((_ sign_extend 1) ?x159)) ?x378) true)))))
(and (not $x139) (or $x139 (and (distinct ?x1599 ?x1599) true)))))))))))))
(check-sat)
; query 12: function core_bench_list, block 82, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x44 (or false false)))
(let (($x517 (not $x44)))
(and $x517 (or $x44 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 13: function core_bench_list, block 82, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x159 ((_ zero_extend 16) in.04_16)))
(let ((?x711 ((_ zero_extend 16) in.02_16)))
(let ((?x87 (bvmul ?x711 (_ bv4 32))))
(let ((?x1599 (bvsub ?x87 ?x159)))
(let ((?x329 ((_ zero_extend 16) in.01_16)))
(let ((?x447 (bvadd ?x329 ?x1599)))
(let (($x1367 (and (distinct (bvadd ((_ sign_extend 1) ?x329) ((_ sign_extend 1) ?x1599)) ((_ sign_extend 1) ?x447)) true)))
(let ((?x378 ((_ sign_extend 1) ?x1599)))
(let (($x44 (or false false)))
(let (($x77 (and (distinct (bvmul ((_ sign_extend 32) ?x711) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x87)) true)))
(let (($x264 (or $x44 false (or $x77))))
(let (($x139 (or $x264 $x44 (or (and (distinct (bvsub ((_ sign_extend 1) ?x87) ((_ sign_extend 1) ?x159)) ?x378) true)))))
(let (($x586 (or $x44 $x139 (or $x1367))))
(and (not $x586) (or $x586 (and (distinct ?x447 ?x447) true)))))))))))))))))
(check-sat)
; query 14: function core_bench_list, block 82, name %89
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x159 ((_ zero_extend 16) in.04_16)))
(let ((?x711 ((_ zero_extend 16) in.02_16)))
(let ((?x87 (bvmul ?x711 (_ bv4 32))))
(let ((?x1599 (bvsub ?x87 ?x159)))
(let ((?x329 ((_ zero_extend 16) in.01_16)))
(let ((?x447 (bvadd ?x329 ?x1599)))
(let ((?x59 ((_ extract 15 0) ?x447)))
(let (($x1367 (and (distinct (bvadd ((_ sign_extend 1) ?x329) ((_ sign_extend 1) ?x1599)) ((_ sign_extend 1) ?x447)) true)))
(let ((?x378 ((_ sign_extend 1) ?x1599)))
(let (($x44 (or false false)))
(let (($x77 (and (distinct (bvmul ((_ sign_extend 32) ?x711) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x87)) true)))
(let (($x264 (or $x44 false (or $x77))))
(let (($x139 (or $x264 $x44 (or (and (distinct (bvsub ((_ sign_extend 1) ?x87) ((_ sign_extend 1) ?x159)) ?x378) true)))))
(let (($x586 (or $x44 $x139 (or $x1367))))
(let (($x51 (or $x586 false)))
(and (not $x51) (or $x51 (and (distinct ?x59 ?x59) true)))))))))))))))))))
(check-sat)
; query 15: function core_bench_list, block 82, name %90
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x44 (or false false)))
(let (($x517 (not $x44)))
(and $x517 (or $x44 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 16: function core_bench_list, block 82, name %91
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x376 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x44 (or false false)))
(let (($x45 (or $x44 false false)))
(let (($x120 (not $x45)))
(and $x120 (or $x45 (and (distinct ?x376 ?x376) true))))))))
(check-sat)
; query 17: function core_bench_state, block 105, name %106
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x257 (or false false false)))
(let (($x90 (not $x257)))
(and $x90 (or $x257 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 18: function core_bench_state, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x257 (or false false false)))
(let (($x90 (not $x257)))
(and $x90 (or $x257 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 19: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x43 (bvadd in.01_32 (_ bv1 32))))
(let (($x226 (and (distinct ?x43 ?x43) true)))
(let (($x257 (or false false false)))
(let (($x90 (not $x257)))
(and $x90 (or $x257 $x226)))))))
(check-sat)
; query 20: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x43 (bvadd in.01_32 (_ bv1 32))))
(let ((?x863 (bvmul ?x43 ?x43)))
(let (($x257 (or false false false)))
(let (($x313 (or $x257 $x257 false)))
(and (not $x313) (or $x313 (and (distinct ?x863 ?x863) true))))))))
(check-sat)
; query 21: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x43 (bvadd in.01_32 (_ bv1 32))))
(let ((?x863 (bvmul ?x43 ?x43)))
(let ((?x1024 (bvmul ?x863 (_ bv2 32))))
(let (($x257 (or false false false)))
(let (($x313 (or $x257 $x257 false)))
(let (($x960 (or $x313 false false)))
(and (not $x960) (or $x960 (and (distinct ?x1024 ?x1024) true))))))))))
(check-sat)
; query 22: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x43 (bvadd in.01_32 (_ bv1 32))))
(let ((?x863 (bvmul ?x43 ?x43)))
(let ((?x1024 (bvmul ?x863 (_ bv2 32))))
(let ((?x689 (bvmul ?x1024 (_ bv4 32))))
(let (($x257 (or false false false)))
(let (($x313 (or $x257 $x257 false)))
(let (($x960 (or $x313 false false)))
(let (($x1031 (or $x960 false false)))
(and (not $x1031) (or $x1031 (and (distinct ?x689 ?x689) true))))))))))))
(check-sat)
; query 23: function core_init_matrix, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x257 (or false false false)))
(let (($x90 (not $x257)))
(and $x90 (or $x257 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 24: function core_init_matrix, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x257 (or false false false)))
(let (($x90 (not $x257)))
(and $x90 (or $x257 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 25: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x85 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x257 (or false false false)))
(let (($x90 (not $x257)))
(and $x90 (or $x257 (and (distinct ?x85 ?x85) true)))))))
(check-sat)
; query 26: function core_init_state, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_32 () (_ BitVec 32))
(assert
 (let (($x257 (or false false false)))
(let (($x90 (not $x257)))
(and $x90 (or $x257 (and (distinct (bvadd in.06_32 (_ bv1 32)) (bvadd in.06_32 (_ bv1 32))) true))))))
(check-sat)
; query 27: function core_init_state, block 65, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let (($x257 (or false false false)))
(let (($x90 (not $x257)))
(and $x90 (or $x257 (and (distinct (bvadd in4_32 (_ bv1 32)) (bvadd in4_32 (_ bv1 32))) true))))))
(check-sat)
; query 28: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x103 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x257 (or false false false)))
(let (($x90 (not $x257)))
(and $x90 (or $x257 (and (distinct ?x103 ?x103) true)))))))
(check-sat)
; query 29: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x257 (or false false false)))
(let (($x90 (not $x257)))
(and $x90 (or $x257 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 30: function core_list_init, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x43 (bvadd in.01_32 (_ bv1 32))))
(let (($x226 (and (distinct ?x43 ?x43) true)))
(let (($x257 (or false false false)))
(let (($x90 (not $x257)))
(and $x90 (or $x257 $x226)))))))
(check-sat)
; query 31: function core_list_mergesort, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x43 (bvadd in.01_32 (_ bv1 32))))
(let (($x226 (and (distinct ?x43 ?x43) true)))
(let (($x393 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x43)) true)))
(let (($x799 (or false false (or $x393))))
(and (not $x799) (or $x799 $x226)))))))
(check-sat)
; query 32: function core_list_mergesort, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x66 (ite (bvslt (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x257 (or false false false)))
(let (($x90 (not $x257)))
(and $x90 (or $x257 (and (distinct ?x66 ?x66) true)))))))
(check-sat)
; query 33: function core_list_mergesort, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.224_32 () (_ BitVec 32))
(assert
 (let ((?x1084 (ite (= (_ bv0 32) in.224_32) (_ bv1 1) (_ bv0 1))))
(let (($x257 (or false false false)))
(let (($x90 (not $x257)))
(and $x90 (or $x257 (and (distinct ?x1084 ?x1084) true)))))))
(check-sat)
; query 34: function core_list_mergesort, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x1744 (ite (= (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x257 (or false false false)))
(let (($x90 (not $x257)))
(and $x90 (or $x257 (and (distinct ?x1744 ?x1744) true)))))))
(check-sat)
; query 35: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x1306 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x557 (or false false (or $x1306))))
(and (not $x557) (or $x557 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 36: function core_list_mergesort, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x143 (and (distinct (bvmul ((_ sign_extend 32) in.020_32) ((_ sign_extend 32) (_ bv2 32))) ((_ sign_extend 32) (bvmul in.020_32 (_ bv2 32)))) true)))
(let (($x1910 (or false false (or $x143))))
(and (not $x1910) (or $x1910 (and (distinct (bvmul in.020_32 (_ bv2 32)) (bvmul in.020_32 (_ bv2 32))) true))))))
(check-sat)
; query 37: function core_state_transition, block 102, name %103
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x44 (or false false)))
(let (($x517 (not $x44)))
(and $x517 (or $x44 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 38: function core_state_transition, block 102, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1410 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x44 (or false false)))
(let (($x45 (or $x44 false false)))
(let (($x120 (not $x45)))
(and $x120 (or $x45 (and (distinct ?x1410 ?x1410) true))))))))
(check-sat)
; query 39: function core_state_transition, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x44 (or false false)))
(let (($x517 (not $x44)))
(and $x517 (or $x44 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 40: function core_state_transition, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x791 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x44 (or false false)))
(let (($x45 (or $x44 false false)))
(let (($x120 (not $x45)))
(and $x120 (or $x45 (and (distinct ?x791 ?x791) true))))))))
(check-sat)
; query 41: function core_state_transition, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x44 (or false false)))
(let (($x517 (not $x44)))
(and $x517 (or $x44 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 42: function core_state_transition, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1410 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x44 (or false false)))
(let (($x45 (or $x44 false false)))
(let (($x120 (not $x45)))
(and $x120 (or $x45 (and (distinct ?x1410 ?x1410) true))))))))
(check-sat)
; query 43: function core_state_transition, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x44 (or false false)))
(let (($x517 (not $x44)))
(and $x517 (or $x44 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 44: function core_state_transition, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1857 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x44 (or false false)))
(let (($x45 (or $x44 false false)))
(let (($x120 (not $x45)))
(and $x120 (or $x45 (and (distinct ?x1857 ?x1857) true))))))))
(check-sat)
; query 45: function core_state_transition, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x44 (or false false)))
(let (($x517 (not $x44)))
(and $x517 (or $x44 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 46: function core_state_transition, block 51, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1857 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x44 (or false false)))
(let (($x45 (or $x44 false false)))
(let (($x120 (not $x45)))
(and $x120 (or $x45 (and (distinct ?x1857 ?x1857) true))))))))
(check-sat)
; query 47: function core_state_transition, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x44 (or false false)))
(let (($x517 (not $x44)))
(and $x517 (or $x44 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 48: function core_state_transition, block 64, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1857 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x44 (or false false)))
(let (($x45 (or $x44 false false)))
(let (($x120 (not $x45)))
(and $x120 (or $x45 (and (distinct ?x1857 ?x1857) true))))))))
(check-sat)
; query 49: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x483 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x257 (or false false false)))
(let (($x90 (not $x257)))
(and $x90 (or $x257 (and (distinct ?x483 ?x483) true)))))))
(check-sat)
; query 50: function core_state_transition, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x44 (or false false)))
(let (($x517 (not $x44)))
(and $x517 (or $x44 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 51: function core_state_transition, block 80, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1843 (ite (= (_ bv69 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x44 (or false false)))
(let (($x45 (or $x44 false false)))
(let (($x120 (not $x45)))
(and $x120 (or $x45 (and (distinct ?x1843 ?x1843) true))))))))
(check-sat)
; query 52: function core_state_transition, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x44 (or false false)))
(let (($x517 (not $x44)))
(and $x517 (or $x44 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 53: function core_state_transition, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1940 (ite (= (_ bv101 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x44 (or false false)))
(let (($x45 (or $x44 false false)))
(let (($x120 (not $x45)))
(and $x120 (or $x45 (and (distinct ?x1940 ?x1940) true))))))))
(check-sat)
; query 54: function core_state_transition, block 99, name %100
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x44 (or false false)))
(let (($x517 (not $x44)))
(and $x517 (or $x44 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 55: function core_state_transition, block 99, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x791 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x44 (or false false)))
(let (($x45 (or $x44 false false)))
(let (($x120 (not $x45)))
(and $x120 (or $x45 (and (distinct ?x791 ?x791) true))))))))
(check-sat)
; query 56: function crcu8, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x44 (or false false)))
(let (($x517 (not $x44)))
(and $x517 (or $x44 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 57: function crcu8, block 19, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x329 ((_ zero_extend 16) in.01_16)))
(let ((?x111 (bvxor ?x329 (_ bv16386 32))))
(let (($x44 (or false false)))
(let (($x45 (or $x44 false false)))
(let (($x120 (not $x45)))
(and $x120 (or $x45 (and (distinct ?x111 ?x111) true)))))))))
(check-sat)
; query 58: function crcu8, block 19, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x329 ((_ zero_extend 16) in.01_16)))
(let ((?x111 (bvxor ?x329 (_ bv16386 32))))
(let ((?x1803 ((_ extract 15 0) ?x111)))
(let (($x44 (or false false)))
(let (($x45 (or $x44 false false)))
(let (($x238 (or $x45 false)))
(let (($x98 (not $x238)))
(and $x98 (or $x238 (and (distinct ?x1803 ?x1803) true)))))))))))
(check-sat)
; query 59: function crcu8, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x44 (or false false)))
(let (($x517 (not $x44)))
(and $x517 (or $x44 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 60: function crcu8, block 29, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1294 ((_ zero_extend 16) in27_16)))
(let ((?x12 (bvor ?x1294 (_ bv32768 32))))
(let (($x44 (or false false)))
(let (($x45 (or $x44 false false)))
(let (($x120 (not $x45)))
(and $x120 (or $x45 (and (distinct ?x12 ?x12) true)))))))))
(check-sat)
; query 61: function crcu8, block 29, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1294 ((_ zero_extend 16) in27_16)))
(let ((?x12 (bvor ?x1294 (_ bv32768 32))))
(let ((?x1005 ((_ extract 15 0) ?x12)))
(let (($x44 (or false false)))
(let (($x45 (or $x44 false false)))
(let (($x238 (or $x45 false)))
(let (($x98 (not $x238)))
(and $x98 (or $x238 (and (distinct ?x1005 ?x1005) true)))))))))))
(check-sat)
; query 62: function crcu8, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x44 (or false false)))
(let (($x517 (not $x44)))
(and $x517 (or $x44 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 63: function crcu8, block 33, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1294 ((_ zero_extend 16) in27_16)))
(let ((?x1236 (bvand ?x1294 (_ bv32767 32))))
(let (($x44 (or false false)))
(let (($x45 (or $x44 false false)))
(let (($x120 (not $x45)))
(and $x120 (or $x45 (and (distinct ?x1236 ?x1236) true)))))))))
(check-sat)
; query 64: function crcu8, block 33, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1294 ((_ zero_extend 16) in27_16)))
(let ((?x1236 (bvand ?x1294 (_ bv32767 32))))
(let ((?x494 ((_ extract 15 0) ?x1236)))
(let (($x44 (or false false)))
(let (($x45 (or $x44 false false)))
(let (($x238 (or $x45 false)))
(let (($x98 (not $x238)))
(and $x98 (or $x238 (and (distinct ?x494 ?x494) true)))))))))))
(check-sat)
; query 65: function crcu8, block 38, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_8 () (_ BitVec 8))
(assert
 (let (($x257 (or false false false)))
(let (($x90 (not $x257)))
(and $x90 (or $x257 (and (distinct (bvadd in.02_8 (_ bv1 8)) (bvadd in.02_8 (_ bv1 8))) true))))))
(check-sat)
; query 66: function crcu8, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x884 ((_ extract 7 0) in.01_16)))
(let ((?x1782 ((_ zero_extend 24) ?x884)))
(let (($x44 (or false false)))
(let (($x990 (or $x44 false)))
(and (not $x990) (or $x990 (and (distinct ?x1782 ?x1782) true))))))))
(check-sat)
; query 67: function crcu8, block 6, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x884 ((_ extract 7 0) in.01_16)))
(let ((?x1782 ((_ zero_extend 24) ?x884)))
(let ((?x1109 (bvand ?x1782 (_ bv1 32))))
(let (($x44 (or false false)))
(let (($x990 (or $x44 false)))
(let (($x2005 (or $x990 false false)))
(and (not $x2005) (or $x2005 (and (distinct ?x1109 ?x1109) true))))))))))
(check-sat)
; query 68: function crcu8, block 6, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x884 ((_ extract 7 0) in.01_16)))
(let ((?x1782 ((_ zero_extend 24) ?x884)))
(let ((?x1109 (bvand ?x1782 (_ bv1 32))))
(let ((?x1961 ((_ zero_extend 24) in.0_8)))
(let ((?x834 (bvand ?x1961 (_ bv1 32))))
(let ((?x886 (bvxor ?x834 ?x1109)))
(let (($x44 (or false false)))
(let (($x990 (or $x44 false)))
(let (($x2005 (or $x990 false false)))
(let (($x45 (or $x44 false false)))
(let (($x1245 (or $x45 $x2005 false)))
(and (not $x1245) (or $x1245 (and (distinct ?x886 ?x886) true)))))))))))))))
(check-sat)
; query 69: function crcu8, block 6, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x884 ((_ extract 7 0) in.01_16)))
(let ((?x1782 ((_ zero_extend 24) ?x884)))
(let ((?x1109 (bvand ?x1782 (_ bv1 32))))
(let ((?x1961 ((_ zero_extend 24) in.0_8)))
(let ((?x834 (bvand ?x1961 (_ bv1 32))))
(let ((?x886 (bvxor ?x834 ?x1109)))
(let ((?x858 ((_ extract 7 0) ?x886)))
(let (($x44 (or false false)))
(let (($x990 (or $x44 false)))
(let (($x2005 (or $x990 false false)))
(let (($x45 (or $x44 false false)))
(let (($x1245 (or $x45 $x2005 false)))
(let (($x829 (or $x1245 false)))
(and (not $x829) (or $x829 (and (distinct ?x858 ?x858) true)))))))))))))))))
(check-sat)
; query 70: function crcu8, block 6, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x44 (or false false)))
(let (($x517 (not $x44)))
(and $x517 (or $x44 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 71: function crcu8, block 6, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1961 ((_ zero_extend 24) in.0_8)))
(let ((?x987 (bvashr ?x1961 (_ bv1 32))))
(let (($x44 (or false false)))
(let (($x45 (or $x44 false false)))
(let (($x348 (or $x45 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not $x348) (or $x348 (and (distinct ?x987 ?x987) true)))))))))
(check-sat)
; query 72: function crcu8, block 6, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1961 ((_ zero_extend 24) in.0_8)))
(let ((?x987 (bvashr ?x1961 (_ bv1 32))))
(let ((?x1533 ((_ extract 7 0) ?x987)))
(let (($x44 (or false false)))
(let (($x45 (or $x44 false false)))
(let (($x348 (or $x45 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x1566 (or $x348 false)))
(and (not $x1566) (or $x1566 (and (distinct ?x1533 ?x1533) true)))))))))))
(check-sat)
; query 73: function crcu8, block 6, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x884 ((_ extract 7 0) in.01_16)))
(let ((?x1782 ((_ zero_extend 24) ?x884)))
(let ((?x1109 (bvand ?x1782 (_ bv1 32))))
(let ((?x1961 ((_ zero_extend 24) in.0_8)))
(let ((?x834 (bvand ?x1961 (_ bv1 32))))
(let ((?x886 (bvxor ?x834 ?x1109)))
(let ((?x858 ((_ extract 7 0) ?x886)))
(let ((?x708 ((_ zero_extend 24) ?x858)))
(let (($x44 (or false false)))
(let (($x990 (or $x44 false)))
(let (($x2005 (or $x990 false false)))
(let (($x45 (or $x44 false false)))
(let (($x1245 (or $x45 $x2005 false)))
(let (($x829 (or $x1245 false)))
(let (($x1275 (or $x829 false)))
(and (not $x1275) (or $x1275 (and (distinct ?x708 ?x708) true)))))))))))))))))))
(check-sat)
; query 74: function crcu8, block 6, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x884 ((_ extract 7 0) in.01_16)))
(let ((?x1782 ((_ zero_extend 24) ?x884)))
(let ((?x1109 (bvand ?x1782 (_ bv1 32))))
(let ((?x1961 ((_ zero_extend 24) in.0_8)))
(let ((?x834 (bvand ?x1961 (_ bv1 32))))
(let ((?x886 (bvxor ?x834 ?x1109)))
(let ((?x858 ((_ extract 7 0) ?x886)))
(let ((?x708 ((_ zero_extend 24) ?x858)))
(let ((?x2087 (ite (= (_ bv1 32) ?x708) (_ bv1 1) (_ bv0 1))))
(let (($x44 (or false false)))
(let (($x990 (or $x44 false)))
(let (($x2005 (or $x990 false false)))
(let (($x45 (or $x44 false false)))
(let (($x1245 (or $x45 $x2005 false)))
(let (($x829 (or $x1245 false)))
(let (($x1275 (or $x829 false)))
(let (($x1856 (or $x1275 false false)))
(and (not $x1856) (or $x1856 (and (distinct ?x2087 ?x2087) true)))))))))))))))))))))
(check-sat)
; query 75: function crcu8, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x44 (or false false)))
(let (($x517 (not $x44)))
(and $x517 (or $x44 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 76: function crcu8, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1961 ((_ zero_extend 24) in.0_8)))
(let ((?x834 (bvand ?x1961 (_ bv1 32))))
(let (($x44 (or false false)))
(let (($x45 (or $x44 false false)))
(let (($x120 (not $x45)))
(and $x120 (or $x45 (and (distinct ?x834 ?x834) true)))))))))
(check-sat)
; query 77: function crcu8, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x44 (or false false)))
(let (($x517 (not $x44)))
(and $x517 (or $x44 (and (distinct ((_ extract 7 0) in.01_16) ((_ extract 7 0) in.01_16)) true))))))
(check-sat)
; query 78: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x81 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x710 ((_ zero_extend 31) ?x81)))
(let ((?x82 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1198 ((_ zero_extend 31) ?x82)))
(let ((?x732 (bvand ?x1198 ?x710)))
(let ((?x728 (ite (and (distinct (_ bv0 32) ?x732) true) (_ bv1 1) (_ bv0 1))))
(let ((?x212 ((_ zero_extend 63) ?x728)))
(let (($x44 (or false false)))
(let (($x45 (or $x44 false false)))
(let (($x238 (or $x45 false)))
(let (($x152 (or $x238 $x238 false)))
(let (($x254 (or $x152 false false)))
(let (($x1119 (or $x254 false)))
(and (not $x1119) (or $x1119 (and (distinct ?x212 ?x212) true)))))))))))))))))
(check-sat)
; query 79: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x81 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x710 ((_ zero_extend 31) ?x81)))
(let ((?x82 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1198 ((_ zero_extend 31) ?x82)))
(let ((?x732 (bvand ?x1198 ?x710)))
(let ((?x728 (ite (and (distinct (_ bv0 32) ?x732) true) (_ bv1 1) (_ bv0 1))))
(let (($x1295 (= (_ bv1 1) ?x728)))
(let ((?x364 (ite $x1295 (_ bv1 32) (_ bv0 32))))
(let (($x44 (or false false)))
(let (($x45 (or $x44 false false)))
(let (($x238 (or $x45 false)))
(let (($x152 (or $x238 $x238 false)))
(let (($x254 (or $x152 false false)))
(let (($x1293 (or $x254 (ite $x1295 false false))))
(and (not $x1293) (or $x1293 (and (distinct ?x364 ?x364) true))))))))))))))))))
(check-sat)
; query 80: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x81 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x710 ((_ zero_extend 31) ?x81)))
(let ((?x82 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1198 ((_ zero_extend 31) ?x82)))
(let ((?x732 (bvand ?x1198 ?x710)))
(let ((?x728 (ite (and (distinct (_ bv0 32) ?x732) true) (_ bv1 1) (_ bv0 1))))
(let (($x1295 (= (_ bv1 1) ?x728)))
(let ((?x364 (ite $x1295 (_ bv1 32) (_ bv0 32))))
(let ((?x567 ((_ extract 7 0) ?x364)))
(let (($x44 (or false false)))
(let (($x45 (or $x44 false false)))
(let (($x238 (or $x45 false)))
(let (($x152 (or $x238 $x238 false)))
(let (($x254 (or $x152 false false)))
(let (($x1293 (or $x254 (ite $x1295 false false))))
(let (($x1506 (or $x1293 false)))
(and (not $x1506) (or $x1506 (and (distinct ?x567 ?x567) true))))))))))))))))))))
(check-sat)
; query 81: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x44 (or false false)))
(let (($x517 (not $x44)))
(and $x517 (or $x44 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 82: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x82 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x44 (or false false)))
(let (($x45 (or $x44 false false)))
(let (($x120 (not $x45)))
(and $x120 (or $x45 (and (distinct ?x82 ?x82) true))))))))
(check-sat)
; query 83: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x82 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1198 ((_ zero_extend 31) ?x82)))
(let (($x44 (or false false)))
(let (($x45 (or $x44 false false)))
(let (($x238 (or $x45 false)))
(let (($x98 (not $x238)))
(and $x98 (or $x238 (and (distinct ?x1198 ?x1198) true))))))))))
(check-sat)
; query 84: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x44 (or false false)))
(let (($x517 (not $x44)))
(and $x517 (or $x44 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 85: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x81 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x44 (or false false)))
(let (($x45 (or $x44 false false)))
(let (($x120 (not $x45)))
(and $x120 (or $x45 (and (distinct ?x81 ?x81) true))))))))
(check-sat)
; query 86: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x81 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x710 ((_ zero_extend 31) ?x81)))
(let (($x44 (or false false)))
(let (($x45 (or $x44 false false)))
(let (($x238 (or $x45 false)))
(let (($x98 (not $x238)))
(and $x98 (or $x238 (and (distinct ?x710 ?x710) true))))))))))
(check-sat)
; query 87: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x81 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x710 ((_ zero_extend 31) ?x81)))
(let ((?x82 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1198 ((_ zero_extend 31) ?x82)))
(let ((?x732 (bvand ?x1198 ?x710)))
(let (($x44 (or false false)))
(let (($x45 (or $x44 false false)))
(let (($x238 (or $x45 false)))
(let (($x152 (or $x238 $x238 false)))
(and (not $x152) (or $x152 (and (distinct ?x732 ?x732) true)))))))))))))
(check-sat)
; query 88: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x81 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x710 ((_ zero_extend 31) ?x81)))
(let ((?x82 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1198 ((_ zero_extend 31) ?x82)))
(let ((?x732 (bvand ?x1198 ?x710)))
(let ((?x728 (ite (and (distinct (_ bv0 32) ?x732) true) (_ bv1 1) (_ bv0 1))))
(let (($x44 (or false false)))
(let (($x45 (or $x44 false false)))
(let (($x238 (or $x45 false)))
(let (($x152 (or $x238 $x238 false)))
(let (($x254 (or $x152 false false)))
(and (not $x254) (or $x254 (and (distinct ?x728 ?x728) true)))))))))))))))
(check-sat)
; query 89: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1498 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x257 (or false false false)))
(let (($x90 (not $x257)))
(and $x90 (or $x257 (and (distinct ?x1498 ?x1498) true)))))))
(check-sat)
; query 90: function matrix_add_const, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x257 (or false false false)))
(let (($x90 (not $x257)))
(and $x90 (or $x257 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 91: function matrix_add_const, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x43 (bvadd in.01_32 (_ bv1 32))))
(let (($x226 (and (distinct ?x43 ?x43) true)))
(let (($x257 (or false false false)))
(let (($x90 (not $x257)))
(and $x90 (or $x257 $x226)))))))
(check-sat)
; query 92: function matrix_mul_const, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x257 (or false false false)))
(let (($x90 (not $x257)))
(and $x90 (or $x257 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 93: function matrix_mul_const, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x43 (bvadd in.01_32 (_ bv1 32))))
(let (($x226 (and (distinct ?x43 ?x43) true)))
(let (($x257 (or false false false)))
(let (($x90 (not $x257)))
(and $x90 (or $x257 $x226)))))))
(check-sat)
; query 94: function matrix_mul_matrix, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x257 (or false false false)))
(let (($x90 (not $x257)))
(and $x90 (or $x257 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 95: function matrix_mul_matrix, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x43 (bvadd in.01_32 (_ bv1 32))))
(let (($x226 (and (distinct ?x43 ?x43) true)))
(let (($x257 (or false false false)))
(let (($x90 (not $x257)))
(and $x90 (or $x257 $x226)))))))
(check-sat)
; query 96: function matrix_mul_matrix, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x257 (or false false false)))
(let (($x90 (not $x257)))
(and $x90 (or $x257 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 97: function matrix_mul_matrix_bitextract, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x257 (or false false false)))
(let (($x90 (not $x257)))
(and $x90 (or $x257 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 98: function matrix_mul_matrix_bitextract, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x43 (bvadd in.01_32 (_ bv1 32))))
(let (($x226 (and (distinct ?x43 ?x43) true)))
(let (($x257 (or false false false)))
(let (($x90 (not $x257)))
(and $x90 (or $x257 $x226)))))))
(check-sat)
; query 99: function matrix_mul_matrix_bitextract, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x257 (or false false false)))
(let (($x90 (not $x257)))
(and $x90 (or $x257 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 100: function matrix_mul_vect, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x257 (or false false false)))
(let (($x90 (not $x257)))
(and $x90 (or $x257 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 101: function matrix_mul_vect, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x43 (bvadd in.01_32 (_ bv1 32))))
(let (($x226 (and (distinct ?x43 ?x43) true)))
(let (($x257 (or false false false)))
(let (($x90 (not $x257)))
(and $x90 (or $x257 $x226)))))))
(check-sat)
; query 102: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x44 (or false false)))
(let (($x517 (not $x44)))
(and $x517 (or $x44 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 103: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x1984 ((_ sign_extend 16) in.1_16)))
(let ((?x363 (bvadd ?x1984 (_ bv10 32))))
(let (($x1904 (and (distinct (bvadd ((_ sign_extend 1) ?x1984) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x363)) true)))
(let (($x44 (or false false)))
(let (($x1754 (or $x44 false (or $x1904))))
(and (not $x1754) (or $x1754 (and (distinct ?x363 ?x363) true)))))))))
(check-sat)
; query 104: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x1984 ((_ sign_extend 16) in.1_16)))
(let ((?x363 (bvadd ?x1984 (_ bv10 32))))
(let ((?x465 ((_ extract 15 0) ?x363)))
(let (($x1904 (and (distinct (bvadd ((_ sign_extend 1) ?x1984) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x363)) true)))
(let (($x44 (or false false)))
(let (($x1754 (or $x44 false (or $x1904))))
(let (($x1793 (or $x1754 false)))
(and (not $x1793) (or $x1793 (and (distinct ?x465 ?x465) true)))))))))))
(check-sat)
; query 105: function matrix_sum, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x321 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x257 (or false false false)))
(let (($x90 (not $x257)))
(and $x90 (or $x257 (and (distinct ?x321 ?x321) true)))))))
(check-sat)
; query 106: function matrix_sum, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x321 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let ((?x568 ((_ zero_extend 63) ?x321)))
(let (($x257 (or false false false)))
(let (($x1868 (or $x257 false)))
(and (not $x1868) (or $x1868 (and (distinct ?x568 ?x568) true))))))))
(check-sat)
; query 107: function matrix_sum, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x321 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x1828 (= (_ bv1 1) ?x321)))
(let ((?x750 (ite $x1828 (_ bv1 32) (_ bv0 32))))
(let (($x257 (or false false false)))
(let (($x1032 (or $x257 (ite $x1828 false false))))
(and (not $x1032) (or $x1032 (and (distinct ?x750 ?x750) true)))))))))
(check-sat)
; query 108: function matrix_sum, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x44 (or false false)))
(let (($x517 (not $x44)))
(and $x517 (or $x44 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 109: function matrix_sum, block 22, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x321 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x1828 (= (_ bv1 1) ?x321)))
(let ((?x750 (ite $x1828 (_ bv1 32) (_ bv0 32))))
(let ((?x1984 ((_ sign_extend 16) in.1_16)))
(let ((?x936 (bvadd ?x1984 ?x750)))
(let (($x9 (and (distinct (bvadd ((_ sign_extend 1) ?x1984) ((_ sign_extend 1) ?x750)) ((_ sign_extend 1) ?x936)) true)))
(let (($x257 (or false false false)))
(let (($x1032 (or $x257 (ite $x1828 false false))))
(let (($x44 (or false false)))
(let (($x1971 (or $x44 $x1032 (or $x9))))
(and (not $x1971) (or $x1971 (and (distinct ?x936 ?x936) true))))))))))))))
(check-sat)
; query 110: function matrix_sum, block 22, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x321 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x1828 (= (_ bv1 1) ?x321)))
(let ((?x750 (ite $x1828 (_ bv1 32) (_ bv0 32))))
(let ((?x1984 ((_ sign_extend 16) in.1_16)))
(let ((?x936 (bvadd ?x1984 ?x750)))
(let ((?x1725 ((_ extract 15 0) ?x936)))
(let (($x9 (and (distinct (bvadd ((_ sign_extend 1) ?x1984) ((_ sign_extend 1) ?x750)) ((_ sign_extend 1) ?x936)) true)))
(let (($x257 (or false false false)))
(let (($x1032 (or $x257 (ite $x1828 false false))))
(let (($x44 (or false false)))
(let (($x1971 (or $x44 $x1032 (or $x9))))
(let (($x1343 (or $x1971 false)))
(and (not $x1343) (or $x1343 (and (distinct ?x1725 ?x1725) true))))))))))))))))
(check-sat)
; query 111: function matrix_sum, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x257 (or false false false)))
(let (($x90 (not $x257)))
(and $x90 (or $x257 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 112: function matrix_sum, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x43 (bvadd in.01_32 (_ bv1 32))))
(let (($x226 (and (distinct ?x43 ?x43) true)))
(let (($x257 (or false false false)))
(let (($x90 (not $x257)))
(and $x90 (or $x257 $x226)))))))
(check-sat)
; query 113: function parseval, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.23_32 () (_ BitVec 32))
(assert
 (let (($x1920 (and (distinct (bvmul ((_ sign_extend 32) in.23_32) ((_ sign_extend 32) (_ bv1024 32))) ((_ sign_extend 32) (bvmul in.23_32 (_ bv1024 32)))) true)))
(let (($x1893 (or false false (or $x1920))))
(and (not $x1893) (or $x1893 (and (distinct (bvmul in.23_32 (_ bv1024 32)) (bvmul in.23_32 (_ bv1024 32))) true))))))
(check-sat)
; query 114: function parseval, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.34_32 () (_ BitVec 32))
(assert
 (let (($x2062 (and (distinct (bvmul ((_ sign_extend 32) in.34_32) ((_ sign_extend 32) (_ bv1048576 32))) ((_ sign_extend 32) (bvmul in.34_32 (_ bv1048576 32)))) true)))
(let (($x1648 (or false false (or $x2062))))
(and (not $x1648) (or $x1648 (and (distinct (bvmul in.34_32 (_ bv1048576 32)) (bvmul in.34_32 (_ bv1048576 32))) true))))))
(check-sat)
; query 115: function partition_memory, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x257 (or false false false)))
(let (($x90 (not $x257)))
(and $x90 (or $x257 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
