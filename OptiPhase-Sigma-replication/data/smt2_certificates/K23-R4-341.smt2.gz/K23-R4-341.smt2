; OptiPhase-Sigma refinement certificate for sweep K23-R4-341
