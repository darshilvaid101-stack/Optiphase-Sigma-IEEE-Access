; OptiPhase-Sigma refinement certificate for sweep K14-R5-397
; query 0: function kernel_mvt, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x34 (and (distinct (bvadd ((_ zero_extend 1) in.0_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x62 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x97 (or (or false false (or $x62 $x34)) (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))
(and (not (or false false (or $x62))) $x97)))))
(check-sat)
; query 1: function kernel_mvt, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x9 (and (distinct (bvadd ((_ zero_extend 1) in.01_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x28 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x12 (or (or false false (or $x28 $x9)) (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))
(and (not (or false false (or $x28))) $x12)))))
(check-sat)
; query 2: function kernel_mvt, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x46 (and (distinct (bvadd ((_ zero_extend 1) in.1_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x73 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x54 (or (or false false (or $x73 $x46)) (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))
(and (not (or false false (or $x73))) $x54)))))
(check-sat)
; query 3: function kernel_mvt, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x553 (and (distinct (bvadd ((_ zero_extend 1) in.12_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.12_32 (_ bv1 32)))) true)))
(let (($x126 (and (distinct (bvadd ((_ sign_extend 1) in.12_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.12_32 (_ bv1 32)))) true)))
(let (($x108 (or (or false false (or $x126 $x553)) (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))
(and (not (or false false (or $x126))) $x108)))))
(check-sat)
