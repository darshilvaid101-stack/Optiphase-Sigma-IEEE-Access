; OptiPhase-Sigma refinement certificate for sweep K56-R3-085
; query 0: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x646 (or false false false)))
(let (($x71 (not $x646)))
(and $x71 (or $x646 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x24 (bvadd in.01_32 (_ bv1 32))))
(let ((?x669 (bvmul ?x24 ?x24)))
(let (($x646 (or false false false)))
(let (($x111 (or $x646 $x646 false)))
(and (not $x111) (or $x111 (and (distinct ?x669 ?x669) true))))))))
(check-sat)
; query 2: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x728 (and (distinct (bvmul (bvmul (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) (_ bv2 32)) (bvshl (bvmul (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) (_ bv3 32))) true)))
(let (($x646 (or false false false)))
(let (($x111 (or $x646 $x646 false)))
(let (($x364 (or $x111 false false)))
(and (not $x364) (or (or $x364 (bvuge (_ bv3 32) (_ bv32 32))) $x728)))))))
(check-sat)
; query 3: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x380 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x646 (or false false false)))
(let (($x71 (not $x646)))
(and $x71 (or $x646 (and (distinct ?x380 ?x380) true)))))))
(check-sat)
; query 4: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x646 (or false false false)))
(let (($x71 (not $x646)))
(and $x71 (or $x646 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 5: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x22 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x646 (or false false false)))
(let (($x71 (not $x646)))
(and $x71 (or $x646 (and (distinct ?x22 ?x22) true)))))))
(check-sat)
