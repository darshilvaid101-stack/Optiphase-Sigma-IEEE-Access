; OptiPhase-Sigma refinement certificate for sweep K59-R3-083
; query 0: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x84 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x152 (or false false false)))
(let (($x1071 (not $x152)))
(and $x1071 (or $x152 (and (distinct ?x84 ?x84) true)))))))
(check-sat)
; query 1: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x152 (or false false false)))
(let (($x1071 (not $x152)))
(and $x1071 (or $x152 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 2: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x658 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x152 (or false false false)))
(let (($x1071 (not $x152)))
(and $x1071 (or $x152 (and (distinct ?x658 ?x658) true)))))))
(check-sat)
