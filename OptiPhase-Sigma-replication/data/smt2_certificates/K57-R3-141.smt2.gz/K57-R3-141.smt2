; OptiPhase-Sigma refinement certificate for sweep K57-R3-141
; query 0: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x346 (or false false false)))
(let (($x665 (not $x346)))
(and $x665 (or $x346 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x297 (bvadd in.01_32 (_ bv1 32))))
(let ((?x470 (bvmul ?x297 ?x297)))
(let (($x346 (or false false false)))
(let (($x113 (or $x346 $x346 false)))
(and (not $x113) (or $x113 (and (distinct ?x470 ?x470) true))))))))
(check-sat)
; query 2: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x297 (bvadd in.01_32 (_ bv1 32))))
(let ((?x470 (bvmul ?x297 ?x297)))
(let ((?x1596 (bvmul ?x470 (_ bv2 32))))
(let (($x346 (or false false false)))
(let (($x113 (or $x346 $x346 false)))
(let (($x805 (or $x113 false false)))
(and (not $x805) (or $x805 (and (distinct ?x1596 ?x1596) true))))))))))
(check-sat)
; query 3: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x297 (bvadd in.01_32 (_ bv1 32))))
(let ((?x470 (bvmul ?x297 ?x297)))
(let ((?x1596 (bvmul ?x470 (_ bv2 32))))
(let ((?x617 (bvmul ?x1596 (_ bv4 32))))
(let (($x346 (or false false false)))
(let (($x113 (or $x346 $x346 false)))
(let (($x805 (or $x113 false false)))
(let (($x1709 (or $x805 false false)))
(and (not $x1709) (or $x1709 (and (distinct ?x617 ?x617) true))))))))))))
(check-sat)
; query 4: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x2870 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x346 (or false false false)))
(let (($x665 (not $x346)))
(and $x665 (or $x346 (and (distinct ?x2870 ?x2870) true)))))))
(check-sat)
; query 5: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x733 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x346 (or false false false)))
(let (($x665 (not $x346)))
(and $x665 (or $x346 (and (distinct ?x733 ?x733) true)))))))
(check-sat)
; query 6: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x346 (or false false false)))
(let (($x665 (not $x346)))
(and $x665 (or $x346 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 7: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x2062 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x99 (or false false (or $x2062))))
(and (not $x99) (or $x99 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x2872 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x346 (or false false false)))
(let (($x665 (not $x346)))
(and $x665 (or $x346 (and (distinct ?x2872 ?x2872) true)))))))
(check-sat)
; query 9: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1458 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x346 (or false false false)))
(let (($x665 (not $x346)))
(and $x665 (or $x346 (and (distinct ?x1458 ?x1458) true)))))))
(check-sat)
; query 10: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x115 (or false false)))
(and (not $x115) (or $x115 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true)))))
(check-sat)
; query 11: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x217 ((_ sign_extend 16) in.1_16)))
(let ((?x38 (bvadd ?x217 (_ bv10 32))))
(let (($x239 (and (distinct (bvadd ((_ sign_extend 1) ?x217) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x38)) true)))
(let (($x115 (or false false)))
(let (($x707 (or $x115 false (or $x239))))
(and (not $x707) (or $x707 (and (distinct ?x38 ?x38) true)))))))))
(check-sat)
; query 12: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x217 ((_ sign_extend 16) in.1_16)))
(let ((?x38 (bvadd ?x217 (_ bv10 32))))
(let ((?x401 ((_ extract 15 0) ?x38)))
(let (($x239 (and (distinct (bvadd ((_ sign_extend 1) ?x217) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x38)) true)))
(let (($x115 (or false false)))
(let (($x707 (or $x115 false (or $x239))))
(let (($x480 (or $x707 false)))
(and (not $x480) (or $x480 (and (distinct ?x401 ?x401) true)))))))))))
(check-sat)
; query 13: function matrix_sum, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x1104 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x346 (or false false false)))
(let (($x665 (not $x346)))
(and $x665 (or $x346 (and (distinct ?x1104 ?x1104) true)))))))
(check-sat)
; query 14: function matrix_sum, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x1104 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let ((?x197 ((_ zero_extend 63) ?x1104)))
(let (($x346 (or false false false)))
(let (($x1134 (or $x346 false)))
(and (not $x1134) (or $x1134 (and (distinct ?x197 ?x197) true))))))))
(check-sat)
; query 15: function matrix_sum, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x1104 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x2873 (= (_ bv1 1) ?x1104)))
(let ((?x1575 (ite $x2873 (_ bv1 32) (_ bv0 32))))
(let (($x346 (or false false false)))
(let (($x1598 (or $x346 (ite $x2873 false false))))
(and (not $x1598) (or $x1598 (and (distinct ?x1575 ?x1575) true)))))))))
(check-sat)
; query 16: function matrix_sum, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x115 (or false false)))
(and (not $x115) (or $x115 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true)))))
(check-sat)
; query 17: function matrix_sum, block 22, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x1104 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x2873 (= (_ bv1 1) ?x1104)))
(let ((?x1575 (ite $x2873 (_ bv1 32) (_ bv0 32))))
(let ((?x217 ((_ sign_extend 16) in.1_16)))
(let ((?x151 (bvadd ?x217 ?x1575)))
(let (($x1330 (and (distinct (bvadd ((_ sign_extend 1) ?x217) ((_ sign_extend 1) ?x1575)) ((_ sign_extend 1) ?x151)) true)))
(let (($x346 (or false false false)))
(let (($x1598 (or $x346 (ite $x2873 false false))))
(let (($x115 (or false false)))
(let (($x721 (or $x115 $x1598 (or $x1330))))
(and (not $x721) (or $x721 (and (distinct ?x151 ?x151) true))))))))))))))
(check-sat)
; query 18: function matrix_sum, block 22, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x1104 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x2873 (= (_ bv1 1) ?x1104)))
(let ((?x1575 (ite $x2873 (_ bv1 32) (_ bv0 32))))
(let ((?x217 ((_ sign_extend 16) in.1_16)))
(let ((?x151 (bvadd ?x217 ?x1575)))
(let ((?x109 ((_ extract 15 0) ?x151)))
(let (($x1330 (and (distinct (bvadd ((_ sign_extend 1) ?x217) ((_ sign_extend 1) ?x1575)) ((_ sign_extend 1) ?x151)) true)))
(let (($x346 (or false false false)))
(let (($x1598 (or $x346 (ite $x2873 false false))))
(let (($x115 (or false false)))
(let (($x721 (or $x115 $x1598 (or $x1330))))
(let (($x295 (or $x721 false)))
(and (not $x295) (or $x295 (and (distinct ?x109 ?x109) true))))))))))))))))
(check-sat)
