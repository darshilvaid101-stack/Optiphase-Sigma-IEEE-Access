; OptiPhase-Sigma refinement certificate for sweep K36-R4-362
