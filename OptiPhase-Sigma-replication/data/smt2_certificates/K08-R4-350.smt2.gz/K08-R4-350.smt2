; OptiPhase-Sigma refinement certificate for sweep K08-R4-350
