; OptiPhase-Sigma refinement certificate for sweep K35-R2-087
; query 0: function corner_draw, block 11, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x70 (ite (= (_ bv0 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x122 (or false false false)))
(let (($x94 (not $x122)))
(and $x94 (or $x122 (and (distinct ?x70 ?x70) true)))))))
(check-sat)
; query 1: function edge_draw, block 39, name %40
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x69 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x72 (or false false (or $x69))))
(and (not $x72) (or $x72 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function edge_draw, block 57, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x11 (and (distinct (bvadd ((_ sign_extend 1) in.12_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.12_32 (_ bv1 32)))) true)))
(let (($x339 (or false false (or $x11))))
(and (not $x339) (or $x339 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 3: function edge_draw, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let ((?x29 (ite (= (_ bv0 32) in4_32) (_ bv1 1) (_ bv0 1))))
(let (($x122 (or false false false)))
(let (($x94 (not $x122)))
(and $x94 (or $x122 (and (distinct ?x29 ?x29) true)))))))
(check-sat)
; query 4: function enlarge, block 106, name %107
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x576 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x145 (or false false (or $x576))))
(and (not $x145) (or $x145 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 5: function enlarge, block 158, name %159
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x89 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x37 (or false false (or $x89))))
(and (not $x37) (or $x37 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 6: function enlarge, block 161, name %162
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let (($x50 (and (distinct (bvadd ((_ sign_extend 1) in.2_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.2_32 (_ bv1 32)))) true)))
(let (($x86 (or false false (or $x50))))
(and (not $x86) (or $x86 (and (distinct (bvadd in.2_32 (_ bv1 32)) (bvadd in.2_32 (_ bv1 32))) true))))))
(check-sat)
; query 7: function enlarge, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x69 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x72 (or false false (or $x69))))
(and (not $x72) (or $x72 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function getint, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x27 (ite (bvsle (_ bv48 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x122 (or false false false)))
(let (($x94 (not $x122)))
(and $x94 (or $x122 (and (distinct ?x27 ?x27) true)))))))
(check-sat)
; query 9: function getint, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x169 (ite (bvsge (_ bv57 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x122 (or false false false)))
(let (($x94 (not $x122)))
(and $x94 (or $x122 (and (distinct ?x169 ?x169) true)))))))
(check-sat)
; query 10: function getint, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in26_32 () (_ BitVec 32))
(assert
 (let ((?x10 (ite (bvsgt (_ bv48 32) in26_32) (_ bv1 1) (_ bv0 1))))
(let (($x122 (or false false false)))
(let (($x94 (not $x122)))
(and $x94 (or $x122 (and (distinct ?x10 ?x10) true)))))))
(check-sat)
; query 11: function getint, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in26_32 () (_ BitVec 32))
(assert
 (let ((?x306 (ite (bvslt (_ bv57 32) in26_32) (_ bv1 1) (_ bv0 1))))
(let (($x122 (or false false false)))
(let (($x94 (not $x122)))
(and $x94 (or $x122 (and (distinct ?x306 ?x306) true)))))))
(check-sat)
; query 12: function getint, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x250 (ite (= (_ bv4294967295 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x122 (or false false false)))
(let (($x94 (not $x122)))
(and $x94 (or $x122 (and (distinct ?x250 ?x250) true)))))))
(check-sat)
; query 13: function int_to_uchar, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_32 () (_ BitVec 32))
(assert
 (let (($x45 (and (distinct (bvadd ((_ sign_extend 1) in.03_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.03_32 (_ bv1 32)))) true)))
(let (($x90 (or false false (or $x45))))
(and (not $x90) (or $x90 (and (distinct (bvadd in.03_32 (_ bv1 32)) (bvadd in.03_32 (_ bv1 32))) true))))))
(check-sat)
; query 14: function int_to_uchar, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x22 (and (distinct (bvsub ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) in.0_32)) ((_ sign_extend 1) (bvsub in.01_32 in.0_32))) true)))
(let (($x154 (or false false (or $x22))))
(let (($x20 (or $x154 (and (distinct (bvsub in.01_32 in.0_32) (bvsub in.01_32 in.0_32)) true))))
(and (not $x154) $x20)))))
(check-sat)
; query 15: function int_to_uchar, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.14_32 () (_ BitVec 32))
(assert
 (let (($x414 (and (distinct (bvadd ((_ sign_extend 1) in.14_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.14_32 (_ bv1 32)))) true)))
(let (($x395 (or false false (or $x414))))
(and (not $x395) (or $x395 (and (distinct (bvadd in.14_32 (_ bv1 32)) (bvadd in.14_32 (_ bv1 32))) true))))))
(check-sat)
; query 16: function main, block 129, name %130
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.011_32 () (_ BitVec 32))
(assert
 (let ((?x392 (ite (and (distinct (_ bv0 32) in.011_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x122 (or false false false)))
(let (($x94 (not $x122)))
(and $x94 (or $x122 (and (distinct ?x392 ?x392) true)))))))
(check-sat)
; query 17: function main, block 160, name %161
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x551 (ite (and (distinct (_ bv0 32) in.01_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x122 (or false false false)))
(let (($x94 (not $x122)))
(and $x94 (or $x122 (and (distinct ?x551 ?x551) true)))))))
(check-sat)
; query 18: function main, block 35, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x383 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x128 (or false false (or $x383))))
(and (not $x128) (or $x128 (and (distinct (bvadd in.020_32 (_ bv1 32)) (bvadd in.020_32 (_ bv1 32))) true))))))
(check-sat)
; query 19: function main, block 35, name %37
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let ((?x614 (ite (bvsge (bvadd in.020_32 (_ bv1 32)) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x383 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x128 (or false false (or $x383))))
(let (($x328 (or $x128 false false)))
(and (not $x328) (or $x328 (and (distinct ?x614 ?x614) true))))))))
(check-sat)
; query 20: function main, block 49, name %50
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x383 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x128 (or false false (or $x383))))
(and (not $x128) (or $x128 (and (distinct (bvadd in.020_32 (_ bv1 32)) (bvadd in.020_32 (_ bv1 32))) true))))))
(check-sat)
; query 21: function main, block 49, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let ((?x614 (ite (bvsge (bvadd in.020_32 (_ bv1 32)) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x383 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x128 (or false false (or $x383))))
(let (($x328 (or $x128 false false)))
(and (not $x328) (or $x328 (and (distinct ?x614 ?x614) true))))))))
(check-sat)
; query 22: function main, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.014_32 () (_ BitVec 32))
(assert
 (let ((?x474 (ite (= (_ bv1 32) in.014_32) (_ bv1 1) (_ bv0 1))))
(let (($x122 (or false false false)))
(let (($x94 (not $x122)))
(and $x94 (or $x122 (and (distinct ?x474 ?x474) true)))))))
(check-sat)
; query 23: function main, block 66, name %67
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x117 (ite (= (_ bv0 32) in.0_32) (_ bv1 1) (_ bv0 1))))
(let (($x122 (or false false false)))
(let (($x94 (not $x122)))
(and $x94 (or $x122 (and (distinct ?x117 ?x117) true)))))))
(check-sat)
; query 24: function main, block 84, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.07_32 () (_ BitVec 32))
(assert
 (let ((?x73 (ite (and (distinct (_ bv0 32) in.07_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x122 (or false false false)))
(let (($x94 (not $x122)))
(and $x94 (or $x122 (and (distinct ?x73 ?x73) true)))))))
(check-sat)
; query 25: function median, block 103, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x89 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x37 (or false false (or $x89))))
(and (not $x37) (or $x37 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 26: function median, block 106, name %107
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x69 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x72 (or false false (or $x69))))
(and (not $x72) (or $x72 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 27: function setup_brightness_lut, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x69 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x72 (or false false (or $x69))))
(and (not $x72) (or $x72 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 28: function susan_corners, block 1066, name %1067
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x89 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x37 (or false false (or $x89))))
(and (not $x37) (or $x37 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 29: function susan_corners, block 1069, name %1070
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x69 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x72 (or false false (or $x69))))
(and (not $x72) (or $x72 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 30: function susan_corners, block 1549, name %1550
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x576 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x145 (or false false (or $x576))))
(and (not $x145) (or $x145 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 31: function susan_corners, block 1552, name %1553
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x11 (and (distinct (bvadd ((_ sign_extend 1) in.12_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.12_32 (_ bv1 32)))) true)))
(let (($x339 (or false false (or $x11))))
(and (not $x339) (or $x339 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 32: function susan_corners, block 845, name %846
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in839_32 () (_ BitVec 32))
(declare-fun in840_32 () (_ BitVec 32))
(assert
 (let ((?x199 (ite (bvslt in840_32 in839_32) (_ bv1 1) (_ bv0 1))))
(let (($x122 (or false false false)))
(let (($x94 (not $x122)))
(and $x94 (or $x122 (and (distinct ?x199 ?x199) true)))))))
(check-sat)
; query 33: function susan_corners_quick, block 1469, name %1470
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x576 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x145 (or false false (or $x576))))
(and (not $x145) (or $x145 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 34: function susan_corners_quick, block 1472, name %1473
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x11 (and (distinct (bvadd ((_ sign_extend 1) in.12_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.12_32 (_ bv1 32)))) true)))
(let (($x339 (or false false (or $x11))))
(and (not $x339) (or $x339 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 35: function susan_corners_quick, block 433, name %434
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x89 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x37 (or false false (or $x89))))
(and (not $x37) (or $x37 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 36: function susan_corners_quick, block 436, name %437
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x69 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x72 (or false false (or $x69))))
(and (not $x72) (or $x72 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 37: function susan_edges, block 1432, name %1433
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1417_32 () (_ BitVec 32))
(assert
 (let ((?x584 (ite (bvslt (_ bv0 32) in1417_32) (_ bv1 1) (_ bv0 1))))
(let (($x122 (or false false false)))
(let (($x94 (not $x122)))
(and $x94 (or $x122 (and (distinct ?x584 ?x584) true)))))))
(check-sat)
; query 38: function susan_edges, block 1486, name %1487
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.116_32 () (_ BitVec 32))
(assert
 (let (($x126 (and (distinct (bvadd ((_ sign_extend 1) in.116_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.116_32 (_ bv1 32)))) true)))
(let (($x400 (or false false (or $x126))))
(and (not $x400) (or $x400 (and (distinct (bvadd in.116_32 (_ bv1 32)) (bvadd in.116_32 (_ bv1 32))) true))))))
(check-sat)
; query 39: function susan_edges, block 1489, name %1490
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.114_32 () (_ BitVec 32))
(assert
 (let (($x511 (and (distinct (bvadd ((_ sign_extend 1) in.114_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.114_32 (_ bv1 32)))) true)))
(let (($x669 (or false false (or $x511))))
(and (not $x669) (or $x669 (and (distinct (bvadd in.114_32 (_ bv1 32)) (bvadd in.114_32 (_ bv1 32))) true))))))
(check-sat)
; query 40: function susan_edges, block 379, name %380
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.015_32 () (_ BitVec 32))
(assert
 (let (($x373 (and (distinct (bvadd ((_ sign_extend 1) in.015_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.015_32 (_ bv1 32)))) true)))
(let (($x645 (or false false (or $x373))))
(and (not $x645) (or $x645 (and (distinct (bvadd in.015_32 (_ bv1 32)) (bvadd in.015_32 (_ bv1 32))) true))))))
(check-sat)
; query 41: function susan_edges, block 382, name %383
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.013_32 () (_ BitVec 32))
(assert
 (let (($x327 (and (distinct (bvadd ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.013_32 (_ bv1 32)))) true)))
(let (($x453 (or false false (or $x327))))
(and (not $x453) (or $x453 (and (distinct (bvadd in.013_32 (_ bv1 32)) (bvadd in.013_32 (_ bv1 32))) true))))))
(check-sat)
; query 42: function susan_edges, block 850, name %851
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in834_32 () (_ BitVec 32))
(assert
 (let ((?x631 (ite (= (_ bv0 32) in834_32) (_ bv1 1) (_ bv0 1))))
(let (($x122 (or false false false)))
(let (($x94 (not $x122)))
(and $x94 (or $x122 (and (distinct ?x631 ?x631) true)))))))
(check-sat)
; query 43: function susan_edges, block 870, name %871
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x398 (ite (bvslt (_ bv0 32) in.0_32) (_ bv1 1) (_ bv0 1))))
(let (($x122 (or false false false)))
(let (($x94 (not $x122)))
(and $x94 (or $x122 (and (distinct ?x398 ?x398) true)))))))
(check-sat)
; query 44: function susan_edges_small, block 119, name %120
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.09_32 () (_ BitVec 32))
(assert
 (let (($x436 (and (distinct (bvadd ((_ sign_extend 1) in.09_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.09_32 (_ bv1 32)))) true)))
(let (($x449 (or false false (or $x436))))
(and (not $x449) (or $x449 (and (distinct (bvadd in.09_32 (_ bv1 32)) (bvadd in.09_32 (_ bv1 32))) true))))))
(check-sat)
; query 45: function susan_edges_small, block 122, name %123
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.07_32 () (_ BitVec 32))
(assert
 (let (($x571 (and (distinct (bvadd ((_ sign_extend 1) in.07_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.07_32 (_ bv1 32)))) true)))
(let (($x667 (or false false (or $x571))))
(and (not $x667) (or $x667 (and (distinct (bvadd in.07_32 (_ bv1 32)) (bvadd in.07_32 (_ bv1 32))) true))))))
(check-sat)
; query 46: function susan_edges_small, block 258, name %259
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in243_32 () (_ BitVec 32))
(assert
 (let ((?x624 (ite (= (_ bv0 32) in243_32) (_ bv1 1) (_ bv0 1))))
(let (($x122 (or false false false)))
(let (($x94 (not $x122)))
(and $x94 (or $x122 (and (distinct ?x624 ?x624) true)))))))
(check-sat)
; query 47: function susan_edges_small, block 278, name %279
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x398 (ite (bvslt (_ bv0 32) in.0_32) (_ bv1 1) (_ bv0 1))))
(let (($x122 (or false false false)))
(let (($x94 (not $x122)))
(and $x94 (or $x122 (and (distinct ?x398 ?x398) true)))))))
(check-sat)
; query 48: function susan_edges_small, block 426, name %427
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in411_32 () (_ BitVec 32))
(assert
 (let ((?x415 (ite (bvslt (_ bv0 32) in411_32) (_ bv1 1) (_ bv0 1))))
(let (($x122 (or false false false)))
(let (($x94 (not $x122)))
(and $x94 (or $x122 (and (distinct ?x415 ?x415) true)))))))
(check-sat)
; query 49: function susan_edges_small, block 458, name %459
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.110_32 () (_ BitVec 32))
(assert
 (let (($x357 (and (distinct (bvadd ((_ sign_extend 1) in.110_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.110_32 (_ bv1 32)))) true)))
(let (($x131 (or false false (or $x357))))
(and (not $x131) (or $x131 (and (distinct (bvadd in.110_32 (_ bv1 32)) (bvadd in.110_32 (_ bv1 32))) true))))))
(check-sat)
; query 50: function susan_edges_small, block 461, name %462
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.18_32 () (_ BitVec 32))
(assert
 (let (($x512 (and (distinct (bvadd ((_ sign_extend 1) in.18_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.18_32 (_ bv1 32)))) true)))
(let (($x160 (or false false (or $x512))))
(and (not $x160) (or $x160 (and (distinct (bvadd in.18_32 (_ bv1 32)) (bvadd in.18_32 (_ bv1 32))) true))))))
(check-sat)
; query 51: function susan_principle, block 378, name %379
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x89 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x37 (or false false (or $x89))))
(and (not $x37) (or $x37 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 52: function susan_principle, block 381, name %382
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x69 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x72 (or false false (or $x69))))
(and (not $x72) (or $x72 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 53: function susan_principle_small, block 118, name %119
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x89 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x37 (or false false (or $x89))))
(and (not $x37) (or $x37 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 54: function susan_principle_small, block 121, name %122
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x69 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x72 (or false false (or $x69))))
(and (not $x72) (or $x72 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 55: function susan_smoothing, block 123, name %124
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.09_32 () (_ BitVec 32))
(assert
 (let (($x466 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in.09_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in.09_32))) true)))
(let (($x491 (or false false (or $x466))))
(and (not $x491) (or $x491 (and (distinct (bvsub (_ bv0 32) in.09_32) (bvsub (_ bv0 32) in.09_32)) true))))))
(check-sat)
; query 56: function susan_smoothing, block 143, name %144
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.016_32 () (_ BitVec 32))
(assert
 (let (($x460 (and (distinct (bvadd ((_ sign_extend 1) in.016_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.016_32 (_ bv1 32)))) true)))
(let (($x820 (or false false (or $x460))))
(and (not $x820) (or $x820 (and (distinct (bvadd in.016_32 (_ bv1 32)) (bvadd in.016_32 (_ bv1 32))) true))))))
(check-sat)
; query 57: function susan_smoothing, block 148, name %149
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.017_32 () (_ BitVec 32))
(assert
 (let (($x372 (and (distinct (bvadd ((_ sign_extend 1) in.017_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.017_32 (_ bv1 32)))) true)))
(let (($x792 (or false false (or $x372))))
(and (not $x792) (or $x792 (and (distinct (bvadd in.017_32 (_ bv1 32)) (bvadd in.017_32 (_ bv1 32))) true))))))
(check-sat)
; query 58: function susan_smoothing, block 150, name %151
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.018_32 () (_ BitVec 32))
(assert
 (let (($x76 (and (distinct (bvsub ((_ sign_extend 1) in.018_32) ((_ sign_extend 1) (_ bv10000 32))) ((_ sign_extend 1) (bvsub in.018_32 (_ bv10000 32)))) true)))
(let (($x213 (or false false (or $x76))))
(and (not $x213) (or $x213 (and (distinct (bvsub in.018_32 (_ bv10000 32)) (bvsub in.018_32 (_ bv10000 32))) true))))))
(check-sat)
; query 59: function susan_smoothing, block 150, name %152
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.018_32 () (_ BitVec 32))
(assert
 (let ((?x133 (ite (= (_ bv0 32) (bvsub in.018_32 (_ bv10000 32))) (_ bv1 1) (_ bv0 1))))
(let (($x76 (and (distinct (bvsub ((_ sign_extend 1) in.018_32) ((_ sign_extend 1) (_ bv10000 32))) ((_ sign_extend 1) (bvsub in.018_32 (_ bv10000 32)))) true)))
(let (($x213 (or false false (or $x76))))
(let (($x140 (or $x213 false false)))
(and (not $x140) (or $x140 (and (distinct ?x133 ?x133) true))))))))
(check-sat)
; query 60: function susan_smoothing, block 165, name %166
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.114_32 () (_ BitVec 32))
(assert
 (let (($x511 (and (distinct (bvadd ((_ sign_extend 1) in.114_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.114_32 (_ bv1 32)))) true)))
(let (($x669 (or false false (or $x511))))
(and (not $x669) (or $x669 (and (distinct (bvadd in.114_32 (_ bv1 32)) (bvadd in.114_32 (_ bv1 32))) true))))))
(check-sat)
; query 61: function susan_smoothing, block 168, name %169
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.111_32 () (_ BitVec 32))
(assert
 (let (($x211 (and (distinct (bvadd ((_ sign_extend 1) in.111_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.111_32 (_ bv1 32)))) true)))
(let (($x661 (or false false (or $x211))))
(and (not $x661) (or $x661 (and (distinct (bvadd in.111_32 (_ bv1 32)) (bvadd in.111_32 (_ bv1 32))) true))))))
(check-sat)
; query 62: function susan_smoothing, block 21, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x777 (ite (= (_ bv0 32) (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x122 (or false false false)))
(let (($x94 (not $x122)))
(and $x94 (or $x122 (and (distinct ?x777 ?x777) true)))))))
(check-sat)
; query 63: function susan_smoothing, block 319, name %320
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.215_32 () (_ BitVec 32))
(assert
 (let (($x652 (and (distinct (bvadd ((_ sign_extend 1) in.215_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.215_32 (_ bv1 32)))) true)))
(let (($x194 (or false false (or $x652))))
(and (not $x194) (or $x194 (and (distinct (bvadd in.215_32 (_ bv1 32)) (bvadd in.215_32 (_ bv1 32))) true))))))
(check-sat)
; query 64: function susan_smoothing, block 322, name %323
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.212_32 () (_ BitVec 32))
(assert
 (let (($x440 (and (distinct (bvadd ((_ sign_extend 1) in.212_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.212_32 (_ bv1 32)))) true)))
(let (($x429 (or false false (or $x440))))
(and (not $x429) (or $x429 (and (distinct (bvadd in.212_32 (_ bv1 32)) (bvadd in.212_32 (_ bv1 32))) true))))))
(check-sat)
; query 65: function susan_smoothing, block 67, name %68
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.09_32 () (_ BitVec 32))
(assert
 (let (($x466 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in.09_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in.09_32))) true)))
(let (($x491 (or false false (or $x466))))
(and (not $x491) (or $x491 (and (distinct (bvsub (_ bv0 32) in.09_32) (bvsub (_ bv0 32) in.09_32)) true))))))
(check-sat)
; query 66: function susan_smoothing, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.013_32 () (_ BitVec 32))
(assert
 (let (($x327 (and (distinct (bvadd ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.013_32 (_ bv1 32)))) true)))
(let (($x453 (or false false (or $x327))))
(and (not $x453) (or $x453 (and (distinct (bvadd in.013_32 (_ bv1 32)) (bvadd in.013_32 (_ bv1 32))) true))))))
(check-sat)
; query 67: function susan_smoothing, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.010_32 () (_ BitVec 32))
(assert
 (let (($x946 (and (distinct (bvadd ((_ sign_extend 1) in.010_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.010_32 (_ bv1 32)))) true)))
(let (($x88 (or false false (or $x946))))
(and (not $x88) (or $x88 (and (distinct (bvadd in.010_32 (_ bv1 32)) (bvadd in.010_32 (_ bv1 32))) true))))))
(check-sat)
; query 68: function susan_thin, block 100, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in93_32 () (_ BitVec 32))
(assert
 (let ((?x522 (ite (= (_ bv1 32) in93_32) (_ bv1 1) (_ bv0 1))))
(let (($x122 (or false false false)))
(let (($x94 (not $x122)))
(and $x94 (or $x122 (and (distinct ?x522 ?x522) true)))))))
(check-sat)
; query 69: function susan_thin, block 428, name %429
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.022_32 () (_ BitVec 32))
(assert
 (let (($x705 (and (distinct (bvadd ((_ sign_extend 1) in.022_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.022_32 (_ bv1 32)))) true)))
(let (($x127 (or false false (or $x705))))
(and (not $x127) (or $x127 (and (distinct (bvadd in.022_32 (_ bv1 32)) (bvadd in.022_32 (_ bv1 32))) true))))))
(check-sat)
; query 70: function susan_thin, block 431, name %432
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.018_32 () (_ BitVec 32))
(assert
 (let (($x366 (and (distinct (bvadd ((_ sign_extend 1) in.018_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.018_32 (_ bv1 32)))) true)))
(let (($x616 (or false false (or $x366))))
(and (not $x616) (or $x616 (and (distinct (bvadd in.018_32 (_ bv1 32)) (bvadd in.018_32 (_ bv1 32))) true))))))
(check-sat)
; query 71: function susan_thin, block 433, name %434
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.040_32 () (_ BitVec 32))
(assert
 (let ((?x683 (ite (bvslt (_ bv0 32) in.040_32) (_ bv1 1) (_ bv0 1))))
(let (($x122 (or false false false)))
(let (($x94 (not $x122)))
(and $x94 (or $x122 (and (distinct ?x683 ?x683) true)))))))
(check-sat)
; query 72: function susan_thin, block 469, name %470
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.235_32 () (_ BitVec 32))
(assert
 (let ((?x738 (bvadd in.235_32 in.235_32)))
(let ((?x883 ((_ sign_extend 1) ?x738)))
(let (($x945 (and (distinct (bvadd ((_ sign_extend 1) in.235_32) ((_ sign_extend 1) in.235_32)) ?x883) true)))
(let (($x654 (or false false (or $x945))))
(and (not $x654) (or $x654 (and (distinct ?x738 ?x738) true))))))))
(check-sat)
; query 73: function susan_thin, block 469, name %471
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.228_32 () (_ BitVec 32))
(declare-fun in.235_32 () (_ BitVec 32))
(assert
 (let ((?x738 (bvadd in.235_32 in.235_32)))
(let ((?x823 (bvadd ?x738 in.228_32)))
(let (($x882 (and (distinct (bvadd ((_ sign_extend 1) ?x738) ((_ sign_extend 1) in.228_32)) ((_ sign_extend 1) ?x823)) true)))
(let ((?x883 ((_ sign_extend 1) ?x738)))
(let (($x945 (and (distinct (bvadd ((_ sign_extend 1) in.235_32) ((_ sign_extend 1) in.235_32)) ?x883) true)))
(let (($x654 (or false false (or $x945))))
(let (($x475 (or $x654 false (or $x882))))
(and (not $x475) (or $x475 (and (distinct ?x823 ?x823) true)))))))))))
(check-sat)
; query 74: function susan_thin, block 469, name %472
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.228_32 () (_ BitVec 32))
(declare-fun in.235_32 () (_ BitVec 32))
(assert
 (let ((?x1023 (ite (bvsgt (_ bv3 32) (bvadd (bvadd in.235_32 in.235_32) in.228_32)) (_ bv1 1) (_ bv0 1))))
(let ((?x704 ((_ sign_extend 1) in.228_32)))
(let ((?x738 (bvadd in.235_32 in.235_32)))
(let ((?x883 ((_ sign_extend 1) ?x738)))
(let (($x396 (or (and (distinct (bvadd ?x883 ?x704) ((_ sign_extend 1) (bvadd ?x738 in.228_32))) true))))
(let (($x945 (and (distinct (bvadd ((_ sign_extend 1) in.235_32) ((_ sign_extend 1) in.235_32)) ?x883) true)))
(let (($x654 (or false false (or $x945))))
(let (($x475 (or $x654 false $x396)))
(let (($x712 (or $x475 false false)))
(and (not $x712) (or $x712 (and (distinct ?x1023 ?x1023) true)))))))))))))
(check-sat)
; query 75: function susan_thin, block 473, name %474
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.235_32 () (_ BitVec 32))
(assert
 (let ((?x706 (bvsub in.235_32 (_ bv1 32))))
(let ((?x850 ((_ sign_extend 1) ?x706)))
(let (($x622 (or (and (distinct (bvsub ((_ sign_extend 1) in.235_32) ((_ sign_extend 1) (_ bv1 32))) ?x850) true))))
(let (($x481 (or false false $x622)))
(and (not $x481) (or $x481 (and (distinct ?x706 ?x706) true))))))))
(check-sat)
; query 76: function susan_thin, block 473, name %475
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.235_32 () (_ BitVec 32))
(declare-fun in.14_32 () (_ BitVec 32))
(assert
 (let ((?x706 (bvsub in.235_32 (_ bv1 32))))
(let ((?x433 (bvadd in.14_32 ?x706)))
(let (($x285 (and (distinct (bvadd ((_ sign_extend 1) in.14_32) ((_ sign_extend 1) ?x706)) ((_ sign_extend 1) ?x433)) true)))
(let ((?x850 ((_ sign_extend 1) ?x706)))
(let (($x622 (or (and (distinct (bvsub ((_ sign_extend 1) in.235_32) ((_ sign_extend 1) (_ bv1 32))) ?x850) true))))
(let (($x481 (or false false $x622)))
(let (($x229 (or false $x481 (or $x285))))
(and (not $x229) (or $x229 (and (distinct ?x433 ?x433) true)))))))))))
(check-sat)
; query 77: function susan_thin, block 473, name %476
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.228_32 () (_ BitVec 32))
(assert
 (let ((?x136 (bvsub in.228_32 (_ bv2 32))))
(let ((?x202 ((_ sign_extend 1) ?x136)))
(let (($x129 (or (and (distinct (bvsub ((_ sign_extend 1) in.228_32) ((_ sign_extend 1) (_ bv2 32))) ?x202) true))))
(let (($x447 (or false false $x129)))
(and (not $x447) (or $x447 (and (distinct ?x136 ?x136) true))))))))
(check-sat)
; query 78: function susan_thin, block 473, name %477
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.228_32 () (_ BitVec 32))
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x136 (bvsub in.228_32 (_ bv2 32))))
(let ((?x937 (bvadd in.0_32 ?x136)))
(let (($x96 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) ?x136)) ((_ sign_extend 1) ?x937)) true)))
(let ((?x202 ((_ sign_extend 1) ?x136)))
(let (($x129 (or (and (distinct (bvsub ((_ sign_extend 1) in.228_32) ((_ sign_extend 1) (_ bv2 32))) ?x202) true))))
(let (($x447 (or false false $x129)))
(let (($x152 (or false $x447 (or $x96))))
(and (not $x152) (or $x152 (and (distinct ?x937 ?x937) true)))))))))))
(check-sat)
; query 79: function susan_thin, block 473, name %478
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.235_32 () (_ BitVec 32))
(declare-fun in.14_32 () (_ BitVec 32))
(assert
 (let ((?x142 (ite (bvsgt (_ bv4 32) (bvadd in.14_32 (bvsub in.235_32 (_ bv1 32)))) (_ bv1 1) (_ bv0 1))))
(let (($x285 (and (distinct (bvadd ((_ sign_extend 1) in.14_32) ((_ sign_extend 1) (bvsub in.235_32 (_ bv1 32)))) ((_ sign_extend 1) (bvadd in.14_32 (bvsub in.235_32 (_ bv1 32))))) true)))
(let ((?x706 (bvsub in.235_32 (_ bv1 32))))
(let ((?x850 ((_ sign_extend 1) ?x706)))
(let (($x622 (or (and (distinct (bvsub ((_ sign_extend 1) in.235_32) ((_ sign_extend 1) (_ bv1 32))) ?x850) true))))
(let (($x481 (or false false $x622)))
(let (($x229 (or false $x481 (or $x285))))
(let (($x578 (or $x229 false false)))
(and (not $x578) (or $x578 (and (distinct ?x142 ?x142) true))))))))))))
(check-sat)
; query 80: function susan_thin, block 533, name %534
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in528_32 () (_ BitVec 32))
(declare-fun in498_32 () (_ BitVec 32))
(assert
 (let (($x122 (or false false false)))
(let (($x166 (or $x122 (and (distinct (bvor in498_32 in528_32) (bvor in498_32 in528_32)) true))))
(let (($x94 (not $x122)))
(and $x94 $x166)))))
(check-sat)
; query 81: function susan_thin, block 533, name %535
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in518_32 () (_ BitVec 32))
(declare-fun in508_32 () (_ BitVec 32))
(assert
 (let (($x122 (or false false false)))
(let (($x240 (or $x122 (and (distinct (bvor in508_32 in518_32) (bvor in508_32 in518_32)) true))))
(let (($x94 (not $x122)))
(and $x94 $x240)))))
(check-sat)
; query 82: function susan_thin, block 533, name %536
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in518_32 () (_ BitVec 32))
(declare-fun in508_32 () (_ BitVec 32))
(declare-fun in528_32 () (_ BitVec 32))
(declare-fun in498_32 () (_ BitVec 32))
(assert
 (let ((?x900 (bvor in508_32 in518_32)))
(let ((?x612 (bvor in498_32 in528_32)))
(let ((?x868 (bvand ?x612 ?x900)))
(let (($x122 (or false false false)))
(let (($x218 (or $x122 $x122 false)))
(let (($x276 (not $x218)))
(and $x276 (or $x218 (and (distinct ?x868 ?x868) true))))))))))
(check-sat)
; query 83: function susan_thin, block 533, name %537
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in518_32 () (_ BitVec 32))
(declare-fun in508_32 () (_ BitVec 32))
(declare-fun in528_32 () (_ BitVec 32))
(declare-fun in498_32 () (_ BitVec 32))
(assert
 (let ((?x900 (bvor in508_32 in518_32)))
(let ((?x612 (bvor in498_32 in528_32)))
(let ((?x868 (bvand ?x612 ?x900)))
(let ((?x149 (ite (and (distinct (_ bv0 32) ?x868) true) (_ bv1 1) (_ bv0 1))))
(let (($x122 (or false false false)))
(let (($x218 (or $x122 $x122 false)))
(let (($x114 (or $x218 false false)))
(let (($x427 (not $x114)))
(and $x427 (or $x114 (and (distinct ?x149 ?x149) true))))))))))))
(check-sat)
; query 84: function susan_thin, block 538, name %539
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in498_32 () (_ BitVec 32))
(assert
 (let ((?x518 (ite (and (distinct (_ bv0 32) in498_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x122 (or false false false)))
(let (($x94 (not $x122)))
(and $x94 (or $x122 (and (distinct ?x518 ?x518) true)))))))
(check-sat)
; query 85: function susan_thin, block 540, name %541
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in508_32 () (_ BitVec 32))
(assert
 (let ((?x702 (ite (and (distinct (_ bv0 32) in508_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x122 (or false false false)))
(let (($x94 (not $x122)))
(and $x94 (or $x122 (and (distinct ?x702 ?x702) true)))))))
(check-sat)
; query 86: function susan_thin, block 545, name %546
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in508_32 () (_ BitVec 32))
(assert
 (let ((?x702 (ite (and (distinct (_ bv0 32) in508_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x122 (or false false false)))
(let (($x94 (not $x122)))
(and $x94 (or $x122 (and (distinct ?x702 ?x702) true)))))))
(check-sat)
; query 87: function susan_thin, block 563, name %564
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.325_32 () (_ BitVec 32))
(assert
 (let ((?x893 (ite (= (_ bv0 32) in.325_32) (_ bv1 1) (_ bv0 1))))
(let (($x122 (or false false false)))
(let (($x94 (not $x122)))
(and $x94 (or $x122 (and (distinct ?x893 ?x893) true)))))))
(check-sat)
; query 88: function susan_thin, block 597, name %598
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.321_32 () (_ BitVec 32))
(assert
 (let ((?x182 (ite (= (_ bv0 32) in.321_32) (_ bv1 1) (_ bv0 1))))
(let (($x122 (or false false false)))
(let (($x94 (not $x122)))
(and $x94 (or $x122 (and (distinct ?x182 ?x182) true)))))))
(check-sat)
; query 89: function susan_thin, block 685, name %686
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in662_32 () (_ BitVec 32))
(declare-fun in680_32 () (_ BitVec 32))
(assert
 (let (($x122 (or false false false)))
(let (($x304 (or $x122 (and (distinct (bvor in680_32 in662_32) (bvor in680_32 in662_32)) true))))
(let (($x94 (not $x122)))
(and $x94 $x304)))))
(check-sat)
; query 90: function susan_thin, block 685, name %687
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in671_32 () (_ BitVec 32))
(declare-fun in653_32 () (_ BitVec 32))
(assert
 (let (($x122 (or false false false)))
(let (($x775 (or $x122 (and (distinct (bvor in653_32 in671_32) (bvor in653_32 in671_32)) true))))
(let (($x94 (not $x122)))
(and $x94 $x775)))))
(check-sat)
; query 91: function susan_thin, block 685, name %688
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in671_32 () (_ BitVec 32))
(declare-fun in653_32 () (_ BitVec 32))
(declare-fun in662_32 () (_ BitVec 32))
(declare-fun in680_32 () (_ BitVec 32))
(assert
 (let ((?x682 (bvor in653_32 in671_32)))
(let ((?x299 (bvor in680_32 in662_32)))
(let ((?x106 (bvand ?x299 ?x682)))
(let (($x122 (or false false false)))
(let (($x218 (or $x122 $x122 false)))
(let (($x276 (not $x218)))
(and $x276 (or $x218 (and (distinct ?x106 ?x106) true))))))))))
(check-sat)
; query 92: function susan_thin, block 685, name %689
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in671_32 () (_ BitVec 32))
(declare-fun in653_32 () (_ BitVec 32))
(declare-fun in662_32 () (_ BitVec 32))
(declare-fun in680_32 () (_ BitVec 32))
(assert
 (let ((?x682 (bvor in653_32 in671_32)))
(let ((?x299 (bvor in680_32 in662_32)))
(let ((?x106 (bvand ?x299 ?x682)))
(let ((?x852 (ite (and (distinct (_ bv0 32) ?x106) true) (_ bv1 1) (_ bv0 1))))
(let (($x122 (or false false false)))
(let (($x218 (or $x122 $x122 false)))
(let (($x114 (or $x218 false false)))
(let (($x427 (not $x114)))
(and $x427 (or $x114 (and (distinct ?x852 ?x852) true))))))))))))
(check-sat)
; query 93: function susan_thin, block 915, name %916
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.13_32 () (_ BitVec 32))
(assert
 (let (($x368 (and (distinct (bvadd ((_ sign_extend 1) in.13_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.13_32 (_ bv1 32)))) true)))
(let (($x163 (or false false (or $x368))))
(and (not $x163) (or $x163 (and (distinct (bvadd in.13_32 (_ bv1 32)) (bvadd in.13_32 (_ bv1 32))) true))))))
(check-sat)
; query 94: function susan_thin, block 918, name %919
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.14_32 () (_ BitVec 32))
(assert
 (let (($x414 (and (distinct (bvadd ((_ sign_extend 1) in.14_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.14_32 (_ bv1 32)))) true)))
(let (($x395 (or false false (or $x414))))
(and (not $x395) (or $x395 (and (distinct (bvadd in.14_32 (_ bv1 32)) (bvadd in.14_32 (_ bv1 32))) true))))))
(check-sat)
