; OptiPhase-Sigma refinement certificate for sweep K46-R6-026
; query 0: function main, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x49 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x604 (or false false false)))
(and (not $x604) (or $x604 (and (distinct ?x49 ?x49) true))))))
(check-sat)
