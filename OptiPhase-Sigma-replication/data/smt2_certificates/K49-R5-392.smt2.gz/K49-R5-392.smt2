; OptiPhase-Sigma refinement certificate for sweep K49-R5-392
; query 0: function APCM_inverse_quantization, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x12 (or false false)))
(let (($x323 (not $x12)))
(and $x323 (or $x12 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 1: function APCM_inverse_quantization, block 7, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x231 (ite (bvsge (_ bv7 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x12 (or false false)))
(let (($x939 (or $x12 false false)))
(let (($x423 (not $x939)))
(and $x423 (or $x939 (and (distinct ?x231 ?x231) true))))))))
(check-sat)
; query 2: function APCM_inverse_quantization, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x12 (or false false)))
(let (($x323 (not $x12)))
(and $x323 (or $x12 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 3: function APCM_inverse_quantization, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x722 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x12 (or false false)))
(let (($x939 (or $x12 false false)))
(let (($x423 (not $x939)))
(and $x423 (or $x939 (and (distinct ?x722 ?x722) true))))))))
(check-sat)
; query 4: function APCM_quantization, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_16 () (_ BitVec 16))
(assert
 (let (($x12 (or false false)))
(let (($x323 (not $x12)))
(and $x323 (or $x12 (and (distinct ((_ sign_extend 16) in13_16) ((_ sign_extend 16) in13_16)) true))))))
(check-sat)
; query 5: function APCM_quantization, block 16, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_16 () (_ BitVec 16))
(assert
 (let ((?x523 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in13_16)) (_ bv1 1) (_ bv0 1))))
(let (($x12 (or false false)))
(let (($x939 (or $x12 false false)))
(let (($x423 (not $x939)))
(and $x423 (or $x939 (and (distinct ?x523 ?x523) true))))))))
(check-sat)
; query 6: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x12 (or false false)))
(let (($x323 (not $x12)))
(and $x323 (or $x12 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 7: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x119 (ite (bvslt (_ bv15 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x12 (or false false)))
(let (($x939 (or $x12 false false)))
(let (($x423 (not $x939)))
(and $x423 (or $x939 (and (distinct ?x119 ?x119) true))))))))
(check-sat)
; query 8: function Calculation_of_the_LTP_parameters, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in11_16 () (_ BitVec 16))
(assert
 (let (($x12 (or false false)))
(let (($x323 (not $x12)))
(and $x323 (or $x12 (and (distinct ((_ sign_extend 16) in11_16) ((_ sign_extend 16) in11_16)) true))))))
(check-sat)
; query 9: function Calculation_of_the_LTP_parameters, block 14, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in11_16 () (_ BitVec 16))
(assert
 (let ((?x230 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in11_16)) (_ bv1 1) (_ bv0 1))))
(let (($x12 (or false false)))
(let (($x939 (or $x12 false false)))
(let (($x423 (not $x939)))
(and $x423 (or $x939 (and (distinct ?x230 ?x230) true))))))))
(check-sat)
; query 10: function Coefficients_0_12, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in15_64 () (_ BitVec 64))
(assert
 (let ((?x224 (ite (bvslt (_ bv0 64) in15_64) (_ bv1 1) (_ bv0 1))))
(let (($x128 (or false false false)))
(let (($x153 (not $x128)))
(and $x153 (or $x128 (and (distinct ?x224 ?x224) true)))))))
(check-sat)
; query 11: function Coefficients_0_12, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in15_64 () (_ BitVec 64))
(assert
 (let ((?x224 (ite (bvslt (_ bv0 64) in15_64) (_ bv1 1) (_ bv0 1))))
(let ((?x490 ((_ zero_extend 63) ?x224)))
(let (($x128 (or false false false)))
(let (($x76 (or $x128 false)))
(let (($x86 (not $x76)))
(and $x86 (or $x76 (and (distinct ?x490 ?x490) true)))))))))
(check-sat)
; query 12: function Coefficients_0_12, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in15_64 () (_ BitVec 64))
(assert
 (let ((?x224 (ite (bvslt (_ bv0 64) in15_64) (_ bv1 1) (_ bv0 1))))
(let (($x374 (= (_ bv1 1) ?x224)))
(let ((?x737 (ite $x374 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x128 (or false false false)))
(let (($x80 (or $x128 (ite $x374 false false))))
(and (not $x80) (or $x80 (and (distinct ?x737 ?x737) true)))))))))
(check-sat)
; query 13: function Coefficients_0_12, block 18, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in15_64 () (_ BitVec 64))
(assert
 (let ((?x224 (ite (bvslt (_ bv0 64) in15_64) (_ bv1 1) (_ bv0 1))))
(let (($x374 (= (_ bv1 1) ?x224)))
(let ((?x737 (ite $x374 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x554 ((_ sign_extend 32) ?x737)))
(let (($x128 (or false false false)))
(let (($x80 (or $x128 (ite $x374 false false))))
(let (($x218 (or $x80 false)))
(and (not $x218) (or $x218 (and (distinct ?x554 ?x554) true)))))))))))
(check-sat)
; query 14: function Coefficients_13_26, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in15_64 () (_ BitVec 64))
(assert
 (let ((?x224 (ite (bvslt (_ bv0 64) in15_64) (_ bv1 1) (_ bv0 1))))
(let (($x128 (or false false false)))
(let (($x153 (not $x128)))
(and $x153 (or $x128 (and (distinct ?x224 ?x224) true)))))))
(check-sat)
; query 15: function Coefficients_13_26, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in15_64 () (_ BitVec 64))
(assert
 (let ((?x224 (ite (bvslt (_ bv0 64) in15_64) (_ bv1 1) (_ bv0 1))))
(let ((?x490 ((_ zero_extend 63) ?x224)))
(let (($x128 (or false false false)))
(let (($x76 (or $x128 false)))
(let (($x86 (not $x76)))
(and $x86 (or $x76 (and (distinct ?x490 ?x490) true)))))))))
(check-sat)
; query 16: function Coefficients_13_26, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in15_64 () (_ BitVec 64))
(assert
 (let ((?x224 (ite (bvslt (_ bv0 64) in15_64) (_ bv1 1) (_ bv0 1))))
(let (($x374 (= (_ bv1 1) ?x224)))
(let ((?x737 (ite $x374 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x128 (or false false false)))
(let (($x80 (or $x128 (ite $x374 false false))))
(and (not $x80) (or $x80 (and (distinct ?x737 ?x737) true)))))))))
(check-sat)
; query 17: function Coefficients_13_26, block 18, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in15_64 () (_ BitVec 64))
(assert
 (let ((?x224 (ite (bvslt (_ bv0 64) in15_64) (_ bv1 1) (_ bv0 1))))
(let (($x374 (= (_ bv1 1) ?x224)))
(let ((?x737 (ite $x374 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x554 ((_ sign_extend 32) ?x737)))
(let (($x128 (or false false false)))
(let (($x80 (or $x128 (ite $x374 false false))))
(let (($x218 (or $x80 false)))
(and (not $x218) (or $x218 (and (distinct ?x554 ?x554) true)))))))))))
(check-sat)
; query 18: function Coefficients_27_39, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in15_64 () (_ BitVec 64))
(assert
 (let ((?x224 (ite (bvslt (_ bv0 64) in15_64) (_ bv1 1) (_ bv0 1))))
(let (($x128 (or false false false)))
(let (($x153 (not $x128)))
(and $x153 (or $x128 (and (distinct ?x224 ?x224) true)))))))
(check-sat)
; query 19: function Coefficients_27_39, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in15_64 () (_ BitVec 64))
(assert
 (let ((?x224 (ite (bvslt (_ bv0 64) in15_64) (_ bv1 1) (_ bv0 1))))
(let ((?x490 ((_ zero_extend 63) ?x224)))
(let (($x128 (or false false false)))
(let (($x76 (or $x128 false)))
(let (($x86 (not $x76)))
(and $x86 (or $x76 (and (distinct ?x490 ?x490) true)))))))))
(check-sat)
; query 20: function Coefficients_27_39, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in15_64 () (_ BitVec 64))
(assert
 (let ((?x224 (ite (bvslt (_ bv0 64) in15_64) (_ bv1 1) (_ bv0 1))))
(let (($x374 (= (_ bv1 1) ?x224)))
(let ((?x737 (ite $x374 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x128 (or false false false)))
(let (($x80 (or $x128 (ite $x374 false false))))
(and (not $x80) (or $x80 (and (distinct ?x737 ?x737) true)))))))))
(check-sat)
; query 21: function Coefficients_27_39, block 18, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in15_64 () (_ BitVec 64))
(assert
 (let ((?x224 (ite (bvslt (_ bv0 64) in15_64) (_ bv1 1) (_ bv0 1))))
(let (($x374 (= (_ bv1 1) ?x224)))
(let ((?x737 (ite $x374 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x554 ((_ sign_extend 32) ?x737)))
(let (($x128 (or false false false)))
(let (($x80 (or $x128 (ite $x374 false false))))
(let (($x218 (or $x80 false)))
(and (not $x218) (or $x218 (and (distinct ?x554 ?x554) true)))))))))))
(check-sat)
; query 22: function Decoding_of_the_coded_Log_Area_Ratios, block 268, name %269
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in265_64 () (_ BitVec 64))
(assert
 (let (($x1011 (and (distinct (ite (bvsge (_ bv18446744073709518848 64) in265_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv0 64) in265_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x128 (or false false false)))
(let (($x153 (not $x128)))
(and $x153 (or $x128 $x1011))))))
(check-sat)
; query 23: function Decoding_of_the_coded_Log_Area_Ratios, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in6_64 () (_ BitVec 64))
(assert
 (let ((?x365 (ite (bvslt (_ bv0 64) in6_64) (_ bv1 1) (_ bv0 1))))
(let (($x128 (or false false false)))
(let (($x153 (not $x128)))
(and $x153 (or $x128 (and (distinct ?x365 ?x365) true)))))))
(check-sat)
; query 24: function Decoding_of_the_coded_Log_Area_Ratios, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in6_64 () (_ BitVec 64))
(assert
 (let ((?x365 (ite (bvslt (_ bv0 64) in6_64) (_ bv1 1) (_ bv0 1))))
(let ((?x181 ((_ zero_extend 63) ?x365)))
(let (($x128 (or false false false)))
(let (($x76 (or $x128 false)))
(let (($x86 (not $x76)))
(and $x86 (or $x76 (and (distinct ?x181 ?x181) true)))))))))
(check-sat)
; query 25: function Decoding_of_the_coded_Log_Area_Ratios, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in6_64 () (_ BitVec 64))
(assert
 (let ((?x365 (ite (bvslt (_ bv0 64) in6_64) (_ bv1 1) (_ bv0 1))))
(let (($x120 (= (_ bv1 1) ?x365)))
(let ((?x117 (ite $x120 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x128 (or false false false)))
(let (($x72 (or $x128 (ite $x120 false false))))
(and (not $x72) (or $x72 (and (distinct ?x117 ?x117) true)))))))))
(check-sat)
; query 26: function Decoding_of_the_coded_Log_Area_Ratios, block 9, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in6_64 () (_ BitVec 64))
(assert
 (let ((?x365 (ite (bvslt (_ bv0 64) in6_64) (_ bv1 1) (_ bv0 1))))
(let (($x120 (= (_ bv1 1) ?x365)))
(let ((?x117 (ite $x120 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x138 ((_ sign_extend 32) ?x117)))
(let (($x128 (or false false false)))
(let (($x72 (or $x128 (ite $x120 false false))))
(let (($x35 (or $x72 false)))
(and (not $x35) (or $x35 (and (distinct ?x138 ?x138) true)))))))))))
(check-sat)
; query 27: function Gsm_Coder, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in39_64 () (_ BitVec 64))
(assert
 (let ((?x23 (ite (bvslt (_ bv0 64) in39_64) (_ bv1 1) (_ bv0 1))))
(let (($x128 (or false false false)))
(let (($x153 (not $x128)))
(and $x153 (or $x128 (and (distinct ?x23 ?x23) true)))))))
(check-sat)
; query 28: function Gsm_Coder, block 42, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in39_64 () (_ BitVec 64))
(assert
 (let ((?x23 (ite (bvslt (_ bv0 64) in39_64) (_ bv1 1) (_ bv0 1))))
(let ((?x733 ((_ zero_extend 63) ?x23)))
(let (($x128 (or false false false)))
(let (($x76 (or $x128 false)))
(let (($x86 (not $x76)))
(and $x86 (or $x76 (and (distinct ?x733 ?x733) true)))))))))
(check-sat)
; query 29: function Gsm_Coder, block 42, name %45
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in39_64 () (_ BitVec 64))
(assert
 (let ((?x23 (ite (bvslt (_ bv0 64) in39_64) (_ bv1 1) (_ bv0 1))))
(let (($x14 (= (_ bv1 1) ?x23)))
(let ((?x532 (ite $x14 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x128 (or false false false)))
(let (($x867 (or $x128 (ite $x14 false false))))
(and (not $x867) (or $x867 (and (distinct ?x532 ?x532) true)))))))))
(check-sat)
; query 30: function Gsm_Coder, block 42, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in39_64 () (_ BitVec 64))
(assert
 (let ((?x23 (ite (bvslt (_ bv0 64) in39_64) (_ bv1 1) (_ bv0 1))))
(let (($x14 (= (_ bv1 1) ?x23)))
(let ((?x532 (ite $x14 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x59 ((_ sign_extend 32) ?x532)))
(let (($x128 (or false false false)))
(let (($x867 (or $x128 (ite $x14 false false))))
(let (($x158 (or $x867 false)))
(and (not $x158) (or $x158 (and (distinct ?x59 ?x59) true)))))))))))
(check-sat)
; query 31: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x12 (or false false)))
(let (($x323 (not $x12)))
(and $x323 (or $x12 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 32: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x149 (ite (bvsgt (_ bv40 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x12 (or false false)))
(let (($x939 (or $x12 false false)))
(let (($x423 (not $x939)))
(and $x423 (or $x939 (and (distinct ?x149 ?x149) true))))))))
(check-sat)
; query 33: function Postprocessing, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in17_64 () (_ BitVec 64))
(assert
 (let ((?x552 (ite (bvslt (_ bv0 64) in17_64) (_ bv1 1) (_ bv0 1))))
(let (($x128 (or false false false)))
(let (($x153 (not $x128)))
(and $x153 (or $x128 (and (distinct ?x552 ?x552) true)))))))
(check-sat)
; query 34: function Postprocessing, block 20, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in17_64 () (_ BitVec 64))
(assert
 (let ((?x552 (ite (bvslt (_ bv0 64) in17_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1019 ((_ zero_extend 63) ?x552)))
(let (($x128 (or false false false)))
(let (($x76 (or $x128 false)))
(let (($x86 (not $x76)))
(and $x86 (or $x76 (and (distinct ?x1019 ?x1019) true)))))))))
(check-sat)
; query 35: function Postprocessing, block 20, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in17_64 () (_ BitVec 64))
(assert
 (let ((?x552 (ite (bvslt (_ bv0 64) in17_64) (_ bv1 1) (_ bv0 1))))
(let (($x123 (= (_ bv1 1) ?x552)))
(let ((?x107 (ite $x123 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x128 (or false false false)))
(let (($x211 (or $x128 (ite $x123 false false))))
(and (not $x211) (or $x211 (and (distinct ?x107 ?x107) true)))))))))
(check-sat)
; query 36: function Postprocessing, block 20, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in17_64 () (_ BitVec 64))
(assert
 (let ((?x552 (ite (bvslt (_ bv0 64) in17_64) (_ bv1 1) (_ bv0 1))))
(let (($x123 (= (_ bv1 1) ?x552)))
(let ((?x107 (ite $x123 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x66 ((_ sign_extend 32) ?x107)))
(let (($x128 (or false false false)))
(let (($x211 (or $x128 (ite $x123 false false))))
(let (($x341 (or $x211 false)))
(and (not $x341) (or $x341 (and (distinct ?x66 ?x66) true)))))))))))
(check-sat)
; query 37: function Quantization_and_coding, block 11, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in8_64 () (_ BitVec 64))
(assert
 (let ((?x253 (ite (bvslt (_ bv0 64) in8_64) (_ bv1 1) (_ bv0 1))))
(let (($x128 (or false false false)))
(let (($x153 (not $x128)))
(and $x153 (or $x128 (and (distinct ?x253 ?x253) true)))))))
(check-sat)
; query 38: function Quantization_and_coding, block 11, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in8_64 () (_ BitVec 64))
(assert
 (let ((?x253 (ite (bvslt (_ bv0 64) in8_64) (_ bv1 1) (_ bv0 1))))
(let ((?x191 ((_ zero_extend 63) ?x253)))
(let (($x128 (or false false false)))
(let (($x76 (or $x128 false)))
(let (($x86 (not $x76)))
(and $x86 (or $x76 (and (distinct ?x191 ?x191) true)))))))))
(check-sat)
; query 39: function Quantization_and_coding, block 11, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in8_64 () (_ BitVec 64))
(assert
 (let ((?x253 (ite (bvslt (_ bv0 64) in8_64) (_ bv1 1) (_ bv0 1))))
(let (($x182 (= (_ bv1 1) ?x253)))
(let ((?x13 (ite $x182 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x128 (or false false false)))
(let (($x315 (or $x128 (ite $x182 false false))))
(and (not $x315) (or $x315 (and (distinct ?x13 ?x13) true)))))))))
(check-sat)
; query 40: function Quantization_and_coding, block 11, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in8_64 () (_ BitVec 64))
(assert
 (let ((?x253 (ite (bvslt (_ bv0 64) in8_64) (_ bv1 1) (_ bv0 1))))
(let (($x182 (= (_ bv1 1) ?x253)))
(let ((?x13 (ite $x182 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x832 ((_ sign_extend 32) ?x13)))
(let (($x128 (or false false false)))
(let (($x315 (or $x128 (ite $x182 false false))))
(let (($x37 (or $x315 false)))
(and (not $x37) (or $x37 (and (distinct ?x832 ?x832) true)))))))))))
(check-sat)
; query 41: function Quantization_and_coding, block 111, name %112
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in108_64 () (_ BitVec 64))
(assert
 (let ((?x47 (ite (bvslt (_ bv0 64) in108_64) (_ bv1 1) (_ bv0 1))))
(let (($x128 (or false false false)))
(let (($x153 (not $x128)))
(and $x153 (or $x128 (and (distinct ?x47 ?x47) true)))))))
(check-sat)
; query 42: function Quantization_and_coding, block 111, name %113
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in108_64 () (_ BitVec 64))
(assert
 (let ((?x47 (ite (bvslt (_ bv0 64) in108_64) (_ bv1 1) (_ bv0 1))))
(let ((?x5 ((_ zero_extend 63) ?x47)))
(let (($x128 (or false false false)))
(let (($x76 (or $x128 false)))
(let (($x86 (not $x76)))
(and $x86 (or $x76 (and (distinct ?x5 ?x5) true)))))))))
(check-sat)
; query 43: function Quantization_and_coding, block 111, name %114
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in108_64 () (_ BitVec 64))
(assert
 (let ((?x47 (ite (bvslt (_ bv0 64) in108_64) (_ bv1 1) (_ bv0 1))))
(let (($x150 (= (_ bv1 1) ?x47)))
(let ((?x227 (ite $x150 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x128 (or false false false)))
(let (($x648 (or $x128 (ite $x150 false false))))
(and (not $x648) (or $x648 (and (distinct ?x227 ?x227) true)))))))))
(check-sat)
; query 44: function Quantization_and_coding, block 111, name %115
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in108_64 () (_ BitVec 64))
(assert
 (let ((?x47 (ite (bvslt (_ bv0 64) in108_64) (_ bv1 1) (_ bv0 1))))
(let (($x150 (= (_ bv1 1) ?x47)))
(let ((?x227 (ite $x150 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x89 ((_ sign_extend 32) ?x227)))
(let (($x128 (or false false false)))
(let (($x648 (or $x128 (ite $x150 false false))))
(let (($x140 (or $x648 false)))
(and (not $x140) (or $x140 (and (distinct ?x89 ?x89) true)))))))))))
(check-sat)
; query 45: function RPE_grid_positioning, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x12 (or false false)))
(let (($x323 (not $x12)))
(and $x323 (or $x12 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 46: function RPE_grid_positioning, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x121 (ite (bvsge (_ bv3 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x12 (or false false)))
(let (($x939 (or $x12 false false)))
(let (($x423 (not $x939)))
(and $x423 (or $x939 (and (distinct ?x121 ?x121) true))))))))
(check-sat)
; query 47: function RPE_grid_positioning, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x12 (or false false)))
(let (($x323 (not $x12)))
(and $x323 (or $x12 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 48: function RPE_grid_positioning, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x77 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x613 (and (distinct ?x77 ?x77) true)))
(let (($x12 (or false false)))
(let (($x46 (or false $x12 false)))
(and (not $x46) (or $x46 $x613)))))))
(check-sat)
; query 49: function Reflection_coefficients, block 207, name %208
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in204_64 () (_ BitVec 64))
(assert
 (let ((?x172 (ite (bvslt (_ bv0 64) in204_64) (_ bv1 1) (_ bv0 1))))
(let (($x128 (or false false false)))
(let (($x153 (not $x128)))
(and $x153 (or $x128 (and (distinct ?x172 ?x172) true)))))))
(check-sat)
; query 50: function Reflection_coefficients, block 207, name %209
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in204_64 () (_ BitVec 64))
(assert
 (let ((?x172 (ite (bvslt (_ bv0 64) in204_64) (_ bv1 1) (_ bv0 1))))
(let ((?x83 ((_ zero_extend 63) ?x172)))
(let (($x128 (or false false false)))
(let (($x76 (or $x128 false)))
(let (($x86 (not $x76)))
(and $x86 (or $x76 (and (distinct ?x83 ?x83) true)))))))))
(check-sat)
; query 51: function Reflection_coefficients, block 207, name %210
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in204_64 () (_ BitVec 64))
(assert
 (let ((?x172 (ite (bvslt (_ bv0 64) in204_64) (_ bv1 1) (_ bv0 1))))
(let (($x33 (= (_ bv1 1) ?x172)))
(let ((?x68 (ite $x33 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x128 (or false false false)))
(let (($x343 (or $x128 (ite $x33 false false))))
(and (not $x343) (or $x343 (and (distinct ?x68 ?x68) true)))))))))
(check-sat)
; query 52: function Reflection_coefficients, block 207, name %211
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in204_64 () (_ BitVec 64))
(assert
 (let ((?x172 (ite (bvslt (_ bv0 64) in204_64) (_ bv1 1) (_ bv0 1))))
(let (($x33 (= (_ bv1 1) ?x172)))
(let ((?x68 (ite $x33 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x51 ((_ sign_extend 32) ?x68)))
(let (($x128 (or false false false)))
(let (($x343 (or $x128 (ite $x33 false false))))
(let (($x171 (or $x343 false)))
(and (not $x171) (or $x171 (and (distinct ?x51 ?x51) true)))))))))))
(check-sat)
; query 53: function Short_term_analysis_filtering, block 34, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in31_64 () (_ BitVec 64))
(assert
 (let ((?x146 (ite (bvslt (_ bv0 64) in31_64) (_ bv1 1) (_ bv0 1))))
(let (($x128 (or false false false)))
(let (($x153 (not $x128)))
(and $x153 (or $x128 (and (distinct ?x146 ?x146) true)))))))
(check-sat)
; query 54: function Short_term_analysis_filtering, block 34, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in31_64 () (_ BitVec 64))
(assert
 (let ((?x146 (ite (bvslt (_ bv0 64) in31_64) (_ bv1 1) (_ bv0 1))))
(let ((?x91 ((_ zero_extend 63) ?x146)))
(let (($x128 (or false false false)))
(let (($x76 (or $x128 false)))
(let (($x86 (not $x76)))
(and $x86 (or $x76 (and (distinct ?x91 ?x91) true)))))))))
(check-sat)
; query 55: function Short_term_analysis_filtering, block 34, name %37
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in31_64 () (_ BitVec 64))
(assert
 (let ((?x146 (ite (bvslt (_ bv0 64) in31_64) (_ bv1 1) (_ bv0 1))))
(let (($x84 (= (_ bv1 1) ?x146)))
(let ((?x78 (ite $x84 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x128 (or false false false)))
(let (($x264 (or $x128 (ite $x84 false false))))
(and (not $x264) (or $x264 (and (distinct ?x78 ?x78) true)))))))))
(check-sat)
; query 56: function Short_term_analysis_filtering, block 34, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in31_64 () (_ BitVec 64))
(assert
 (let ((?x146 (ite (bvslt (_ bv0 64) in31_64) (_ bv1 1) (_ bv0 1))))
(let (($x84 (= (_ bv1 1) ?x146)))
(let ((?x78 (ite $x84 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x280 ((_ sign_extend 32) ?x78)))
(let (($x128 (or false false false)))
(let (($x264 (or $x128 (ite $x84 false false))))
(let (($x258 (or $x264 false)))
(and (not $x258) (or $x258 (and (distinct ?x280 ?x280) true)))))))))))
(check-sat)
; query 57: function Transformation_to_Log_Area_Ratios, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_16 () (_ BitVec 16))
(assert
 (let ((?x204 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in5_16)) (_ bv1 1) (_ bv0 1))))
(let (($x12 (or false false)))
(let (($x939 (or $x12 false false)))
(let (($x423 (not $x939)))
(and $x423 (or $x939 (and (distinct ?x204 ?x204) true))))))))
(check-sat)
; query 58: function Transformation_to_Log_Area_Ratios, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_16 () (_ BitVec 16))
(assert
 (let (($x12 (or false false)))
(let (($x323 (not $x12)))
(and $x323 (or $x12 (and (distinct ((_ sign_extend 16) in5_16) ((_ sign_extend 16) in5_16)) true))))))
(check-sat)
; query 59: function gsm_L_add, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x85 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x128 (or false false false)))
(let (($x153 (not $x128)))
(and $x153 (or $x128 (and (distinct ?x85 ?x85) true)))))))
(check-sat)
; query 60: function gsm_L_add, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x535 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvadd in0_64 in1_64))) true)))
(let (($x452 (or false false (or $x535))))
(let (($x570 (or $x452 (and (distinct (bvadd in0_64 in1_64) (bvadd in0_64 in1_64)) true))))
(and (not $x452) $x570)))))
(check-sat)
; query 61: function gsm_L_add, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x363 (bvadd in0_64 (_ bv1 64))))
(let ((?x529 (bvsub (_ bv0 64) ?x363)))
(let (($x350 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x363)) ((_ sign_extend 1) ?x529)) true)))
(let ((?x990 ((_ sign_extend 1) ?x363)))
(let (($x571 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x990) true)))))
(let (($x917 (or false $x571 (or $x350))))
(and (not $x917) (or $x917 (and (distinct ?x529 ?x529) true))))))))))
(check-sat)
; query 62: function gsm_L_add, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1043 (bvadd in1_64 (_ bv1 64))))
(let ((?x863 ((_ sign_extend 1) ?x1043)))
(let (($x548 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x863) true)))))
(and (not $x548) (or $x548 (and (distinct ?x1043 ?x1043) true)))))))
(check-sat)
; query 63: function gsm_L_add, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1043 (bvadd in1_64 (_ bv1 64))))
(let ((?x578 (bvsub (_ bv0 64) ?x1043)))
(let (($x192 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1043)) ((_ sign_extend 1) ?x578)) true)))
(let ((?x863 ((_ sign_extend 1) ?x1043)))
(let (($x548 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x863) true)))))
(let (($x397 (or false $x548 (or $x192))))
(and (not $x397) (or $x397 (and (distinct ?x578 ?x578) true))))))))))
(check-sat)
; query 64: function gsm_L_add, block 8, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1043 (bvadd in1_64 (_ bv1 64))))
(let ((?x578 (bvsub (_ bv0 64) ?x1043)))
(let ((?x363 (bvadd in0_64 (_ bv1 64))))
(let ((?x529 (bvsub (_ bv0 64) ?x363)))
(let ((?x429 (bvadd ?x529 ?x578)))
(let (($x192 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1043)) ((_ sign_extend 1) ?x578)) true)))
(let ((?x863 ((_ sign_extend 1) ?x1043)))
(let (($x548 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x863) true)))))
(let (($x397 (or false $x548 (or $x192))))
(let (($x350 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x363)) ((_ sign_extend 1) ?x529)) true)))
(let ((?x990 ((_ sign_extend 1) ?x363)))
(let (($x571 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x990) true)))))
(let (($x917 (or false $x571 (or $x350))))
(let (($x409 (or $x917 $x397 false)))
(and (not $x409) (or $x409 (and (distinct ?x429 ?x429) true))))))))))))))))))
(check-sat)
; query 65: function gsm_L_add, block 8, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1043 (bvadd in1_64 (_ bv1 64))))
(let ((?x578 (bvsub (_ bv0 64) ?x1043)))
(let ((?x363 (bvadd in0_64 (_ bv1 64))))
(let ((?x529 (bvsub (_ bv0 64) ?x363)))
(let ((?x429 (bvadd ?x529 ?x578)))
(let ((?x517 (ite (bvuge ?x429 (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x192 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1043)) ((_ sign_extend 1) ?x578)) true)))
(let ((?x863 ((_ sign_extend 1) ?x1043)))
(let (($x548 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x863) true)))))
(let (($x397 (or false $x548 (or $x192))))
(let (($x350 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x363)) ((_ sign_extend 1) ?x529)) true)))
(let ((?x990 ((_ sign_extend 1) ?x363)))
(let (($x571 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x990) true)))))
(let (($x917 (or false $x571 (or $x350))))
(let (($x409 (or $x917 $x397 false)))
(let (($x336 (or $x409 false false)))
(and (not $x336) (or $x336 (and (distinct ?x517 ?x517) true))))))))))))))))))))
(check-sat)
; query 66: function gsm_L_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x363 (bvadd in0_64 (_ bv1 64))))
(let ((?x990 ((_ sign_extend 1) ?x363)))
(let (($x571 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x990) true)))))
(and (not $x571) (or $x571 (and (distinct ?x363 ?x363) true)))))))
(check-sat)
; query 67: function gsm_L_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x479 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x128 (or false false false)))
(let (($x153 (not $x128)))
(and $x153 (or $x128 (and (distinct ?x479 ?x479) true)))))))
(check-sat)
; query 68: function gsm_L_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x400 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x128 (or false false false)))
(let (($x153 (not $x128)))
(and $x153 (or $x128 (and (distinct ?x400 ?x400) true)))))))
(check-sat)
; query 69: function gsm_L_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x479 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x128 (or false false false)))
(let (($x153 (not $x128)))
(and $x153 (or $x128 (and (distinct ?x479 ?x479) true)))))))
(check-sat)
; query 70: function gsm_L_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x479 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x118 ((_ zero_extend 31) ?x479)))
(let (($x128 (or false false false)))
(let (($x76 (or $x128 false)))
(let (($x86 (not $x76)))
(and $x86 (or $x76 (and (distinct ?x118 ?x118) true)))))))))
(check-sat)
; query 71: function gsm_L_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x479 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x118 ((_ zero_extend 31) ?x479)))
(let ((?x542 (bvsub (_ bv0 32) ?x118)))
(let (($x642 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x118)) ((_ sign_extend 1) ?x542)) true)))
(let (($x128 (or false false false)))
(let (($x76 (or $x128 false)))
(let (($x325 (or false $x76 (or $x642))))
(and (not $x325) (or $x325 (and (distinct ?x542 ?x542) true)))))))))))
(check-sat)
; query 72: function gsm_L_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x479 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x118 ((_ zero_extend 31) ?x479)))
(let ((?x542 (bvsub (_ bv0 32) ?x118)))
(let ((?x620 ((_ sign_extend 32) ?x542)))
(let (($x642 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x118)) ((_ sign_extend 1) ?x542)) true)))
(let (($x128 (or false false false)))
(let (($x76 (or $x128 false)))
(let (($x325 (or false $x76 (or $x642))))
(let (($x478 (or $x325 false)))
(and (not $x478) (or $x478 (and (distinct ?x620 ?x620) true)))))))))))))
(check-sat)
; query 73: function gsm_L_asr, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x390 (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x128 (or false false false)))
(let (($x153 (not $x128)))
(and $x153 (or $x128 (and (distinct ?x390 ?x390) true)))))))
(check-sat)
; query 74: function gsm_L_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x400 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x128 (or false false false)))
(let (($x153 (not $x128)))
(and $x153 (or $x128 (and (distinct ?x400 ?x400) true)))))))
(check-sat)
; query 75: function gsm_L_mult, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x12 (or false false)))
(let (($x323 (not $x12)))
(and $x323 (or $x12 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 76: function gsm_L_mult, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x472 (ite (and (distinct (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) true) (_ bv1 1) (_ bv0 1))))
(let (($x12 (or false false)))
(let (($x939 (or $x12 false false)))
(let (($x423 (not $x939)))
(and $x423 (or $x939 (and (distinct ?x472 ?x472) true))))))))
(check-sat)
; query 77: function gsm_L_mult, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x12 (or false false)))
(let (($x323 (not $x12)))
(and $x323 (or $x12 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 78: function gsm_L_mult, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x389 (ite (and (distinct (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) true) (_ bv1 1) (_ bv0 1))))
(let (($x12 (or false false)))
(let (($x939 (or $x12 false false)))
(let (($x423 (not $x939)))
(and $x423 (or $x939 (and (distinct ?x389 ?x389) true))))))))
(check-sat)
; query 79: function gsm_L_sub, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x85 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x128 (or false false false)))
(let (($x153 (not $x128)))
(and $x153 (or $x128 (and (distinct ?x85 ?x85) true)))))))
(check-sat)
; query 80: function gsm_L_sub, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x448 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvsub in0_64 in1_64))) true)))
(let (($x622 (or false false (or $x448))))
(let (($x444 (or $x622 (and (distinct (bvsub in0_64 in1_64) (bvsub in0_64 in1_64)) true))))
(and (not $x622) $x444)))))
(check-sat)
; query 81: function gsm_L_sub, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1043 (bvadd in1_64 (_ bv1 64))))
(let ((?x578 (bvsub (_ bv0 64) ?x1043)))
(let (($x192 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1043)) ((_ sign_extend 1) ?x578)) true)))
(let ((?x863 ((_ sign_extend 1) ?x1043)))
(let (($x548 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x863) true)))))
(let (($x397 (or false $x548 (or $x192))))
(and (not $x397) (or $x397 (and (distinct ?x578 ?x578) true))))))))))
(check-sat)
; query 82: function gsm_L_sub, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1043 (bvadd in1_64 (_ bv1 64))))
(let ((?x578 (bvsub (_ bv0 64) ?x1043)))
(let ((?x771 (bvadd in0_64 ?x578)))
(let (($x192 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1043)) ((_ sign_extend 1) ?x578)) true)))
(let ((?x863 ((_ sign_extend 1) ?x1043)))
(let (($x548 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x863) true)))))
(let (($x397 (or false $x548 (or $x192))))
(let (($x913 (or false $x397 false)))
(and (not $x913) (or $x913 (and (distinct ?x771 ?x771) true))))))))))))
(check-sat)
; query 83: function gsm_L_sub, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x499 (ite (bvuge (bvadd in0_64 (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64)))) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x192 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) (bvadd in1_64 (_ bv1 64)))) ((_ sign_extend 1) (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64))))) true)))
(let ((?x1043 (bvadd in1_64 (_ bv1 64))))
(let ((?x863 ((_ sign_extend 1) ?x1043)))
(let (($x548 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x863) true)))))
(let (($x397 (or false $x548 (or $x192))))
(let (($x913 (or false $x397 false)))
(let (($x332 (or $x913 false false)))
(and (not $x332) (or $x332 (and (distinct ?x499 ?x499) true))))))))))))
(check-sat)
; query 84: function gsm_L_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1043 (bvadd in1_64 (_ bv1 64))))
(let ((?x863 ((_ sign_extend 1) ?x1043)))
(let (($x548 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x863) true)))))
(and (not $x548) (or $x548 (and (distinct ?x1043 ?x1043) true)))))))
(check-sat)
; query 85: function gsm_L_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x818 (ite (bvsle (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x128 (or false false false)))
(let (($x153 (not $x128)))
(and $x153 (or $x128 (and (distinct ?x818 ?x818) true)))))))
(check-sat)
; query 86: function gsm_abs, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x12 (or false false)))
(let (($x323 (not $x12)))
(and $x323 (or $x12 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 87: function gsm_abs, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x104 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x12 (or false false)))
(let (($x939 (or $x12 false false)))
(let (($x423 (not $x939)))
(and $x423 (or $x939 (and (distinct ?x104 ?x104) true))))))))
(check-sat)
; query 88: function gsm_abs, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x12 (or false false)))
(let (($x323 (not $x12)))
(and $x323 (or $x12 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 89: function gsm_abs, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x687 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x12 (or false false)))
(let (($x939 (or $x12 false false)))
(let (($x423 (not $x939)))
(and $x423 (or $x939 (and (distinct ?x687 ?x687) true))))))))
(check-sat)
; query 90: function gsm_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x12 (or false false)))
(let (($x323 (not $x12)))
(and $x323 (or $x12 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 91: function gsm_add, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x12 (or false false)))
(let (($x323 (not $x12)))
(and $x323 (or $x12 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 92: function gsm_add, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x503 ((_ sign_extend 48) in1_16)))
(let ((?x268 ((_ sign_extend 48) in0_16)))
(let ((?x288 (bvadd ?x268 ?x503)))
(let (($x457 (and (distinct (bvadd ((_ sign_extend 1) ?x268) ((_ sign_extend 1) ?x503)) ((_ sign_extend 1) ?x288)) true)))
(let (($x12 (or false false)))
(let (($x267 (or $x12 $x12 (or $x457))))
(and (not $x267) (or $x267 (and (distinct ?x288 ?x288) true))))))))))
(check-sat)
; query 93: function gsm_add, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x473 (ite (bvsgt (_ bv18446744073709518848 64) (bvadd ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x503 ((_ sign_extend 48) in1_16)))
(let ((?x212 ((_ sign_extend 1) ?x503)))
(let ((?x268 ((_ sign_extend 48) in0_16)))
(let ((?x813 ((_ sign_extend 1) ?x268)))
(let (($x12 (or false false)))
(let (($x267 (or $x12 $x12 (or (and (distinct (bvadd ?x813 ?x212) ((_ sign_extend 1) (bvadd ?x268 ?x503))) true)))))
(let (($x416 (or $x267 false false)))
(and (not $x416) (or $x416 (and (distinct ?x473 ?x473) true))))))))))))
(check-sat)
; query 94: function gsm_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x485 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x128 (or false false false)))
(let (($x153 (not $x128)))
(and $x153 (or $x128 (and (distinct ?x485 ?x485) true)))))))
(check-sat)
; query 95: function gsm_asr, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x705 (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x128 (or false false false)))
(let (($x153 (not $x128)))
(and $x153 (or $x128 (and (distinct ?x705 ?x705) true)))))))
(check-sat)
; query 96: function gsm_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x12 (or false false)))
(let (($x323 (not $x12)))
(and $x323 (or $x12 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 97: function gsm_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x687 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x12 (or false false)))
(let (($x939 (or $x12 false false)))
(let (($x423 (not $x939)))
(and $x423 (or $x939 (and (distinct ?x687 ?x687) true))))))))
(check-sat)
; query 98: function gsm_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x687 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x491 ((_ zero_extend 31) ?x687)))
(let (($x12 (or false false)))
(let (($x939 (or $x12 false false)))
(let (($x597 (or $x939 false)))
(and (not $x597) (or $x597 (and (distinct ?x491 ?x491) true)))))))))
(check-sat)
; query 99: function gsm_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x687 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x491 ((_ zero_extend 31) ?x687)))
(let ((?x557 (bvsub (_ bv0 32) ?x491)))
(let (($x753 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x491)) ((_ sign_extend 1) ?x557)) true)))
(let (($x12 (or false false)))
(let (($x939 (or $x12 false false)))
(let (($x597 (or $x939 false)))
(let (($x410 (or false $x597 (or $x753))))
(and (not $x410) (or $x410 (and (distinct ?x557 ?x557) true))))))))))))
(check-sat)
; query 100: function gsm_asr, block 4, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x687 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x491 ((_ zero_extend 31) ?x687)))
(let ((?x557 (bvsub (_ bv0 32) ?x491)))
(let ((?x254 ((_ extract 15 0) ?x557)))
(let (($x753 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x491)) ((_ sign_extend 1) ?x557)) true)))
(let (($x12 (or false false)))
(let (($x939 (or $x12 false false)))
(let (($x597 (or $x939 false)))
(let (($x410 (or false $x597 (or $x753))))
(let (($x122 (or $x410 false)))
(and (not $x122) (or $x122 (and (distinct ?x254 ?x254) true))))))))))))))
(check-sat)
; query 101: function gsm_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x485 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x128 (or false false false)))
(let (($x153 (not $x128)))
(and $x153 (or $x128 (and (distinct ?x485 ?x485) true)))))))
(check-sat)
; query 102: function gsm_debug_longwords, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in15_32 () (_ BitVec 32))
(assert
 (let ((?x750 (ite (bvslt in15_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x128 (or false false false)))
(let (($x153 (not $x128)))
(and $x153 (or $x128 (and (distinct ?x750 ?x750) true)))))))
(check-sat)
; query 103: function gsm_debug_words, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in16_32 () (_ BitVec 32))
(assert
 (let ((?x199 (ite (bvslt in16_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x128 (or false false false)))
(let (($x153 (not $x128)))
(and $x153 (or $x128 (and (distinct ?x199 ?x199) true)))))))
(check-sat)
; query 104: function gsm_div, block 7, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x675 (ite (bvsge ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x12 (or false false)))
(let (($x394 (or $x12 $x12 false)))
(and (not $x394) (or $x394 (and (distinct ?x675 ?x675) true)))))))
(check-sat)
; query 105: function gsm_div, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x12 (or false false)))
(let (($x323 (not $x12)))
(and $x323 (or $x12 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 106: function gsm_div, block 7, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x12 (or false false)))
(let (($x323 (not $x12)))
(and $x323 (or $x12 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 107: function gsm_div, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x12 (or false false)))
(let (($x323 (not $x12)))
(and $x323 (or $x12 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 108: function gsm_div, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x12 (or false false)))
(let (($x323 (not $x12)))
(and $x323 (or $x12 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 109: function gsm_div, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x12 (or false false)))
(let (($x323 (not $x12)))
(and $x323 (or $x12 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 110: function gsm_div, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x77 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x613 (and (distinct ?x77 ?x77) true)))
(let (($x12 (or false false)))
(let (($x939 (or $x12 false false)))
(let (($x423 (not $x939)))
(and $x423 (or $x939 $x613))))))))
(check-sat)
; query 111: function gsm_norm, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x479 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x128 (or false false false)))
(let (($x153 (not $x128)))
(and $x153 (or $x128 (and (distinct ?x479 (ite (bvsge (_ bv18446744072635809792 64) in0_64) (_ bv1 1) (_ bv0 1))) true)))))))
(check-sat)
; query 112: function gsm_norm, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x630 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x128 (or false false false)))
(let (($x153 (not $x128)))
(and $x153 (or $x128 (and (distinct ?x630 ?x630) true)))))))
(check-sat)
; query 113: function gsm_norm, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x630 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x623 (bvxor ?x630 (_ bv1 1))))
(let (($x128 (or false false false)))
(let (($x321 (or $x128 false false)))
(and (not $x321) (or $x321 (and (distinct ?x623 ?x623) true))))))))
(check-sat)
; query 114: function gsm_norm, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x630 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x623 (bvxor ?x630 (_ bv1 1))))
(let ((?x754 ((_ zero_extend 31) ?x623)))
(let (($x128 (or false false false)))
(let (($x321 (or $x128 false false)))
(let (($x299 (or $x321 false)))
(and (not $x299) (or $x299 (and (distinct ?x754 ?x754) true))))))))))
(check-sat)
; query 115: function gsm_norm, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x630 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x623 (bvxor ?x630 (_ bv1 1))))
(let ((?x754 ((_ zero_extend 31) ?x623)))
(let ((?x506 ((_ sign_extend 32) ?x754)))
(let (($x128 (or false false false)))
(let (($x321 (or $x128 false false)))
(let (($x299 (or $x321 false)))
(let (($x780 (or $x299 false)))
(and (not $x780) (or $x780 (and (distinct ?x506 ?x506) true))))))))))))
(check-sat)
; query 116: function gsm_norm, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x630 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x623 (bvxor ?x630 (_ bv1 1))))
(let ((?x754 ((_ zero_extend 31) ?x623)))
(let ((?x506 ((_ sign_extend 32) ?x754)))
(let ((?x284 (ite (and (distinct (_ bv0 64) ?x506) true) (_ bv1 1) (_ bv0 1))))
(let (($x128 (or false false false)))
(let (($x321 (or $x128 false false)))
(let (($x299 (or $x321 false)))
(let (($x780 (or $x299 false)))
(let (($x488 (or $x780 false false)))
(and (not $x488) (or $x488 (and (distinct ?x284 ?x284) true))))))))))))))
(check-sat)
; query 117: function gsm_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x12 (or false false)))
(let (($x323 (not $x12)))
(and $x323 (or $x12 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 118: function gsm_sub, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x12 (or false false)))
(let (($x323 (not $x12)))
(and $x323 (or $x12 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 119: function gsm_sub, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x503 ((_ sign_extend 48) in1_16)))
(let ((?x268 ((_ sign_extend 48) in0_16)))
(let ((?x396 (bvsub ?x268 ?x503)))
(let (($x815 (and (distinct (bvsub ((_ sign_extend 1) ?x268) ((_ sign_extend 1) ?x503)) ((_ sign_extend 1) ?x396)) true)))
(let (($x12 (or false false)))
(let (($x918 (or $x12 $x12 (or $x815))))
(and (not $x918) (or $x918 (and (distinct ?x396 ?x396) true))))))))))
(check-sat)
; query 120: function gsm_sub, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x165 (ite (bvsgt (_ bv18446744073709518848 64) (bvsub ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x503 ((_ sign_extend 48) in1_16)))
(let ((?x212 ((_ sign_extend 1) ?x503)))
(let ((?x268 ((_ sign_extend 48) in0_16)))
(let ((?x813 ((_ sign_extend 1) ?x268)))
(let (($x12 (or false false)))
(let (($x918 (or $x12 $x12 (or (and (distinct (bvsub ?x813 ?x212) ((_ sign_extend 1) (bvsub ?x268 ?x503))) true)))))
(let (($x518 (or $x918 false false)))
(and (not $x518) (or $x518 (and (distinct ?x165 ?x165) true))))))))))))
(check-sat)
; query 121: function process_decode, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let (($x12 (or false false)))
(let (($x323 (not $x12)))
(and $x323 (or $x12 (and (distinct ((_ sign_extend 32) in14_32) ((_ sign_extend 32) in14_32)) true))))))
(check-sat)
; query 122: function process_decode, block 16, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x898 (ite (and (distinct (_ bv33 64) ((_ sign_extend 32) in14_32)) true) (_ bv1 1) (_ bv0 1))))
(let (($x12 (or false false)))
(let (($x939 (or $x12 false false)))
(let (($x423 (not $x939)))
(and $x423 (or $x939 (and (distinct ?x898 ?x898) true))))))))
(check-sat)
; query 123: function process_encode, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_32 () (_ BitVec 32))
(assert
 (let (($x12 (or false false)))
(let (($x323 (not $x12)))
(and $x323 (or $x12 (and (distinct ((_ sign_extend 32) in13_32) ((_ sign_extend 32) in13_32)) true))))))
(check-sat)
; query 124: function process_encode, block 15, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_32 () (_ BitVec 32))
(assert
 (let ((?x686 (ite (bvult ((_ sign_extend 32) in13_32) (_ bv160 64)) (_ bv1 1) (_ bv0 1))))
(let (($x12 (or false false)))
(let (($x939 (or $x12 false false)))
(let (($x423 (not $x939)))
(and $x423 (or $x939 (and (distinct ?x686 ?x686) true))))))))
(check-sat)
