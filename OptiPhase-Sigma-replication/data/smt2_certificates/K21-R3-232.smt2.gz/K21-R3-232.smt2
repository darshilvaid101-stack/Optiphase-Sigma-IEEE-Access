; OptiPhase-Sigma refinement certificate for sweep K21-R3-232
; query 0: function init_array, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x109 (and (distinct (bvadd ((_ zero_extend 1) in.0_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x232 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x176 (or (or false false (or $x232 $x109)) (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))
(and (not (or false false (or $x232))) $x176)))))
(check-sat)
; query 1: function init_array, block 25, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x110 (and (distinct (bvadd ((_ zero_extend 1) in.01_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x88 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x132 (or (or false false (or $x88 $x110)) (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))
(and (not (or false false (or $x88))) $x132)))))
(check-sat)
