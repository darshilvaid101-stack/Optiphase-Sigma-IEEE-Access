; OptiPhase-Sigma refinement certificate for sweep K44-R6-039
; query 0: function Index_to_frequency, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x347 (ite (bvuge in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x159 (or false false false)))
(let (($x306 (not $x159)))
(and $x306 (or $x159 (and (distinct ?x347 ?x347) true)))))))
(check-sat)
; query 1: function IsPowerOfTwo, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x159 (or false false false)))
(let (($x306 (not $x159)))
(and $x306 (or $x159 (and (distinct (bvsub in0_32 (_ bv1 32)) (bvsub in0_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function IsPowerOfTwo, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x45 (bvsub in0_32 (_ bv1 32))))
(let ((?x28 (bvand in0_32 ?x45)))
(let (($x159 (or false false false)))
(let (($x152 (or false $x159 false)))
(and (not $x152) (or $x152 (and (distinct ?x28 ?x28) true))))))))
(check-sat)
; query 3: function IsPowerOfTwo, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x44 (ite (and (distinct (_ bv0 32) (bvand in0_32 (bvsub in0_32 (_ bv1 32)))) true) (_ bv1 1) (_ bv0 1))))
(let (($x159 (or false false false)))
(let (($x152 (or false $x159 false)))
(let (($x188 (or $x152 false false)))
(and (not $x188) (or $x188 (and (distinct ?x44 ?x44) true))))))))
(check-sat)
; query 4: function IsPowerOfTwo, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x60 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x159 (or false false false)))
(let (($x306 (not $x159)))
(and $x306 (or $x159 (and (distinct ?x60 ?x60) true)))))))
(check-sat)
; query 5: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x60 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x159 (or false false false)))
(let (($x306 (not $x159)))
(and $x306 (or $x159 (and (distinct ?x60 ?x60) true)))))))
(check-sat)
; query 6: function fft_float, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x82 (ite (and (distinct (_ bv0 32) in1_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x159 (or false false false)))
(let (($x306 (not $x159)))
(and $x306 (or $x159 (and (distinct ?x82 ?x82) true)))))))
(check-sat)
; query 7: function main, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x37 (ite (= (_ bv4 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x159 (or false false false)))
(let (($x306 (not $x159)))
(and $x306 (or $x159 (and (distinct ?x37 ?x37) true)))))))
(check-sat)
; query 8: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x180 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x159 (or false false false)))
(let (($x306 (not $x159)))
(and $x306 (or $x159 (and (distinct ?x180 ?x180) true)))))))
(check-sat)
