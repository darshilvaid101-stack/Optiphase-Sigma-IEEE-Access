; OptiPhase-Sigma refinement certificate for sweep K39-R3-247
