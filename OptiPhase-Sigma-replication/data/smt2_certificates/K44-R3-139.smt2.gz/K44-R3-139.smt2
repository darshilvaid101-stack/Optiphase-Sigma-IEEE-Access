; OptiPhase-Sigma refinement certificate for sweep K44-R3-139
; query 0: function Index_to_frequency, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x428 (ite (bvuge in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x43 (or false false false)))
(let (($x190 (not $x43)))
(and $x190 (or $x43 (and (distinct ?x428 ?x428) true)))))))
(check-sat)
; query 1: function IsPowerOfTwo, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x43 (or false false false)))
(let (($x190 (not $x43)))
(and $x190 (or $x43 (and (distinct (bvsub in0_32 (_ bv1 32)) (bvsub in0_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function IsPowerOfTwo, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x405 (bvsub in0_32 (_ bv1 32))))
(let ((?x474 (bvand in0_32 ?x405)))
(let (($x43 (or false false false)))
(let (($x413 (or false $x43 false)))
(and (not $x413) (or $x413 (and (distinct ?x474 ?x474) true))))))))
(check-sat)
; query 3: function IsPowerOfTwo, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x19 (ite (and (distinct (_ bv0 32) (bvand in0_32 (bvsub in0_32 (_ bv1 32)))) true) (_ bv1 1) (_ bv0 1))))
(let (($x43 (or false false false)))
(let (($x413 (or false $x43 false)))
(let (($x340 (or $x413 false false)))
(and (not $x340) (or $x340 (and (distinct ?x19 ?x19) true))))))))
(check-sat)
; query 4: function IsPowerOfTwo, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x64 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x43 (or false false false)))
(let (($x190 (not $x43)))
(and $x190 (or $x43 (and (distinct ?x64 ?x64) true)))))))
(check-sat)
; query 5: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x64 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x43 (or false false false)))
(let (($x190 (not $x43)))
(and $x190 (or $x43 (and (distinct ?x64 ?x64) true)))))))
(check-sat)
; query 6: function main, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x572 (ite (= (_ bv4 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x43 (or false false false)))
(let (($x190 (not $x43)))
(and $x190 (or $x43 (and (distinct ?x572 ?x572) true)))))))
(check-sat)
; query 7: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x26 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x43 (or false false false)))
(let (($x190 (not $x43)))
(and $x190 (or $x43 (and (distinct ?x26 ?x26) true)))))))
(check-sat)
