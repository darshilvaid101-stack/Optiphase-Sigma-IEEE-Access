; OptiPhase-Sigma refinement certificate for sweep K32-R2-089
; query 0: function compare, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in7_32 () (_ BitVec 32))
(assert
 (let ((?x554 (ite (= (_ bv0 32) in7_32) (_ bv1 1) (_ bv0 1))))
(let (($x523 (or false false false)))
(let (($x534 (not $x523)))
(and $x534 (or $x523 (and (distinct ?x554 ?x554) true)))))))
(check-sat)
; query 1: function compare, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in7_32 () (_ BitVec 32))
(assert
 (let ((?x554 (ite (= (_ bv0 32) in7_32) (_ bv1 1) (_ bv0 1))))
(let ((?x504 ((_ zero_extend 63) ?x554)))
(let (($x523 (or false false false)))
(let (($x183 (or $x523 false)))
(and (not $x183) (or $x183 (and (distinct ?x504 ?x504) true))))))))
(check-sat)
; query 2: function compare, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in7_32 () (_ BitVec 32))
(assert
 (let ((?x554 (ite (= (_ bv0 32) in7_32) (_ bv1 1) (_ bv0 1))))
(let (($x519 (= (_ bv1 1) ?x554)))
(let ((?x569 (ite $x519 (_ bv0 32) (_ bv4294967295 32))))
(let (($x523 (or false false false)))
(let (($x28 (or $x523 (ite $x519 false false))))
(and (not $x28) (or $x28 (and (distinct ?x569 ?x569) true)))))))))
(check-sat)
; query 3: function main, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x375 (ite (bvsgt (_ bv60000 32) in.0_32) (_ bv1 1) (_ bv0 1))))
(let (($x523 (or false false false)))
(let (($x534 (not $x523)))
(and $x534 (or $x523 (and (distinct ?x375 ?x375) true)))))))
(check-sat)
; query 4: function main, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x71 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x114 (or false false (or $x71))))
(and (not $x114) (or $x114 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 5: function main, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x70 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x458 (or false false (or $x70))))
(and (not $x458) (or $x458 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
