; OptiPhase-Sigma refinement certificate for sweep K50-R6-018
; query 0: function check, block 103, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x42 (ite (= (_ bv22 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x230 (or false false false)))
(let (($x36 (not $x230)))
(and $x36 (or $x230 (and (distinct ?x42 (ite (= (_ bv0 32) in0_32) (_ bv1 1) (_ bv0 1))) true)))))))
(check-sat)
; query 1: function check, block 109, name %110
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x306 (ite (= (_ bv33 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x230 (or false false false)))
(let (($x36 (not $x230)))
(and $x36 (or $x230 (and (distinct ?x306 (ite (= (_ bv12 32) in0_32) (_ bv1 1) (_ bv0 1))) true)))))))
(check-sat)
; query 2: function check, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x218 (ite (= (_ bv4 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x230 (or false false false)))
(let (($x36 (not $x230)))
(and $x36 (or $x230 (and (distinct (ite (= (_ bv2 32) in0_32) (_ bv1 1) (_ bv0 1)) ?x218) true)))))))
(check-sat)
; query 3: function check, block 79, name %80
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x554 (ite (= (_ bv5 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x230 (or false false false)))
(let (($x36 (not $x230)))
(and $x36 (or $x230 (and (distinct (ite (= (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1)) ?x554) true)))))))
(check-sat)
; query 4: function check, block 85, name %86
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x401 (ite (= (_ bv11 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let ((?x218 (ite (= (_ bv4 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x230 (or false false false)))
(let (($x36 (not $x230)))
(and $x36 (or $x230 (and (distinct ?x218 ?x401) true))))))))
(check-sat)
; query 5: function check, block 91, name %92
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x42 (ite (= (_ bv22 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let ((?x554 (ite (= (_ bv5 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x230 (or false false false)))
(let (($x36 (not $x230)))
(and $x36 (or $x230 (and (distinct ?x554 ?x42) true))))))))
(check-sat)
; query 6: function check, block 97, name %98
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x306 (ite (= (_ bv33 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let ((?x401 (ite (= (_ bv11 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x230 (or false false false)))
(let (($x36 (not $x230)))
(and $x36 (or $x230 (and (distinct ?x401 ?x306) true))))))))
(check-sat)
; query 7: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x785 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x230 (or false false false)))
(let (($x36 (not $x230)))
(and $x36 (or $x230 (and (distinct ?x785 ?x785) true)))))))
(check-sat)
; query 8: function s115, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x269 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x29 (or false false (or $x269))))
(and (not $x29) (or $x29 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 9: function set1d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x102 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x230 (or false false false)))
(let (($x36 (not $x230)))
(and $x36 (or $x230 (and (distinct ?x102 ?x102) true)))))))
(check-sat)
; query 10: function set1ds, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x99 (ite (= (_ bv4294967295 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x230 (or false false false)))
(let (($x36 (not $x230)))
(and $x36 (or $x230 (and (distinct ?x99 ?x99) true)))))))
(check-sat)
; query 11: function set2d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x102 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x230 (or false false false)))
(let (($x36 (not $x230)))
(and $x36 (or $x230 (and (distinct ?x102 ?x102) true)))))))
(check-sat)
