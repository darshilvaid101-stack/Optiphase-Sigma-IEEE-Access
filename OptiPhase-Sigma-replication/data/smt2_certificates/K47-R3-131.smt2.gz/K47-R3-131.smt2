; OptiPhase-Sigma refinement certificate for sweep K47-R3-131
; query 0: function adpcm_decoder, block 61, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.210_32 () (_ BitVec 32))
(declare-fun in.013_32 () (_ BitVec 32))
(assert
 (let ((?x499 (bvadd in.013_32 in.210_32)))
(let ((?x296 (bvsub in.013_32 in.210_32)))
(let (($x33 (and (distinct (bvadd ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x499)) true)))
(let (($x364 (and (distinct (bvsub ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x296)) true)))
(and (not (or false false (or $x364))) (or (or false false (or $x33)) (and (distinct ?x296 ?x499) true))))))))
(check-sat)
; query 1: function main, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x1065 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x848 (or false false false)))
(and (not $x848) (or $x848 (and (distinct ?x1065 ?x1065) true))))))
(check-sat)
