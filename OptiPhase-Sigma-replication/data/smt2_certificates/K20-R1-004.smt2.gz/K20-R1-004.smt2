; OptiPhase-Sigma refinement certificate for sweep K20-R1-004
