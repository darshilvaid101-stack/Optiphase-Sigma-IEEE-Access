; OptiPhase-Sigma refinement certificate for sweep K44-R3-107
; query 0: function Index_to_frequency, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x428 (ite (bvuge in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x36 (or false false false)))
(let (($x139 (not $x36)))
(and $x139 (or $x36 (and (distinct ?x428 ?x428) true)))))))
(check-sat)
; query 1: function IsPowerOfTwo, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x120 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x36 (or false false false)))
(let (($x139 (not $x36)))
(and $x139 (or $x36 (and (distinct ?x120 ?x120) true)))))))
(check-sat)
; query 2: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x120 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x36 (or false false false)))
(let (($x139 (not $x36)))
(and $x139 (or $x36 (and (distinct ?x120 ?x120) true)))))))
(check-sat)
; query 3: function main, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x497 (ite (= (_ bv4 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x36 (or false false false)))
(let (($x139 (not $x36)))
(and $x139 (or $x36 (and (distinct ?x497 ?x497) true)))))))
(check-sat)
; query 4: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x337 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x36 (or false false false)))
(let (($x139 (not $x36)))
(and $x139 (or $x36 (and (distinct ?x337 ?x337) true)))))))
(check-sat)
