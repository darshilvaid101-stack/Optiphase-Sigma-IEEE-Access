; OptiPhase-Sigma refinement certificate for sweep K04-R4-326
