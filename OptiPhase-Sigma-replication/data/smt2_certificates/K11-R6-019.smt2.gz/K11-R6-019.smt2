; OptiPhase-Sigma refinement certificate for sweep K11-R6-019
