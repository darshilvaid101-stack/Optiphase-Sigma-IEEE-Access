; OptiPhase-Sigma refinement certificate for sweep K19-R4-311
; query 0: function init_array, block 103, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x230 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x233 (or false false (or $x230))))
(and (not $x233) (or $x233 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function init_array, block 106, name %107
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.13_32 () (_ BitVec 32))
(assert
 (let (($x154 (and (distinct (bvadd ((_ sign_extend 1) in.13_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.13_32 (_ bv1 32)))) true)))
(let (($x162 (or false false (or $x154))))
(and (not $x162) (or $x162 (and (distinct (bvadd in.13_32 (_ bv1 32)) (bvadd in.13_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function init_array, block 109, name %110
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x126 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x83 (or false false (or $x126))))
(and (not $x83) (or $x83 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 3: function init_array, block 127, name %128
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let (($x69 (and (distinct (bvadd ((_ sign_extend 1) in.2_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.2_32 (_ bv1 32)))) true)))
(let (($x6 (or false false (or $x69))))
(and (not $x6) (or $x6 (and (distinct (bvadd in.2_32 (_ bv1 32)) (bvadd in.2_32 (_ bv1 32))) true))))))
(check-sat)
; query 4: function init_array, block 130, name %131
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.24_32 () (_ BitVec 32))
(assert
 (let (($x5 (and (distinct (bvadd ((_ sign_extend 1) in.24_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.24_32 (_ bv1 32)))) true)))
(let (($x54 (or false false (or $x5))))
(and (not $x54) (or $x54 (and (distinct (bvadd in.24_32 (_ bv1 32)) (bvadd in.24_32 (_ bv1 32))) true))))))
(check-sat)
; query 5: function init_array, block 21, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.07_32 () (_ BitVec 32))
(assert
 (let (($x136 (and (distinct (bvadd ((_ sign_extend 1) in.07_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.07_32 (_ bv1 32)))) true)))
(let (($x133 (or false false (or $x136))))
(and (not $x133) (or $x133 (and (distinct (bvadd in.07_32 (_ bv1 32)) (bvadd in.07_32 (_ bv1 32))) true))))))
(check-sat)
; query 6: function init_array, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.05_32 () (_ BitVec 32))
(assert
 (let (($x65 (and (distinct (bvadd ((_ sign_extend 1) in.05_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.05_32 (_ bv1 32)))) true)))
(let (($x86 (or false false (or $x65))))
(and (not $x86) (or $x86 (and (distinct (bvadd in.05_32 (_ bv1 32)) (bvadd in.05_32 (_ bv1 32))) true))))))
(check-sat)
; query 7: function init_array, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.18_32 () (_ BitVec 32))
(assert
 (let (($x101 (and (distinct (bvadd ((_ sign_extend 1) in.18_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.18_32 (_ bv1 32)))) true)))
(let (($x58 (or false false (or $x101))))
(and (not $x58) (or $x58 (and (distinct (bvadd in.18_32 (_ bv1 32)) (bvadd in.18_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function init_array, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.16_32 () (_ BitVec 32))
(assert
 (let (($x39 (and (distinct (bvadd ((_ sign_extend 1) in.16_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.16_32 (_ bv1 32)))) true)))
(let (($x140 (or false false (or $x39))))
(and (not $x140) (or $x140 (and (distinct (bvadd in.16_32 (_ bv1 32)) (bvadd in.16_32 (_ bv1 32))) true))))))
(check-sat)
; query 9: function init_array, block 58, name %59
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.18_32 () (_ BitVec 32))
(assert
 (let (($x101 (and (distinct (bvadd ((_ sign_extend 1) in.18_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.18_32 (_ bv1 32)))) true)))
(let (($x58 (or false false (or $x101))))
(and (not $x58) (or $x58 (and (distinct (bvadd in.18_32 (_ bv1 32)) (bvadd in.18_32 (_ bv1 32))) true))))))
(check-sat)
; query 10: function init_array, block 72, name %73
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x90 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x46 (or false false (or $x90))))
(and (not $x46) (or $x46 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 11: function init_array, block 75, name %76
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x52 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x21 (or false false (or $x52))))
(and (not $x21) (or $x21 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 12: function kernel_ludcmp, block 103, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.25_32 () (_ BitVec 32))
(assert
 (let (($x43 (and (distinct (bvadd ((_ sign_extend 1) in.25_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.25_32 (_ bv1 32)))) true)))
(let (($x48 (or false false (or $x43))))
(and (not $x48) (or $x48 (and (distinct (bvadd in.25_32 (_ bv1 32)) (bvadd in.25_32 (_ bv1 32))) true))))))
(check-sat)
; query 13: function kernel_ludcmp, block 108, name %109
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.18_32 () (_ BitVec 32))
(assert
 (let (($x101 (and (distinct (bvadd ((_ sign_extend 1) in.18_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.18_32 (_ bv1 32)))) true)))
(let (($x58 (or false false (or $x101))))
(and (not $x58) (or $x58 (and (distinct (bvadd in.18_32 (_ bv1 32)) (bvadd in.18_32 (_ bv1 32))) true))))))
(check-sat)
; query 14: function kernel_ludcmp, block 110, name %111
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x74 (and (distinct (bvsub ((_ sign_extend 1) in0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvsub in0_32 (_ bv1 32)))) true)))
(let (($x149 (or false false (or $x74))))
(and (not $x149) (or $x149 (and (distinct (bvsub in0_32 (_ bv1 32)) (bvsub in0_32 (_ bv1 32))) true))))))
(check-sat)
; query 15: function kernel_ludcmp, block 132, name %133
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.36_32 () (_ BitVec 32))
(assert
 (let (($x161 (and (distinct (bvadd ((_ sign_extend 1) in.36_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.36_32 (_ bv1 32)))) true)))
(let (($x109 (or false false (or $x161))))
(and (not $x109) (or $x109 (and (distinct (bvadd in.36_32 (_ bv1 32)) (bvadd in.36_32 (_ bv1 32))) true))))))
(check-sat)
; query 16: function kernel_ludcmp, block 143, name %144
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.29_32 () (_ BitVec 32))
(assert
 (let (($x166 (and (distinct (bvadd ((_ sign_extend 1) in.29_32) ((_ sign_extend 1) (_ bv4294967295 32))) ((_ sign_extend 1) (bvadd in.29_32 (_ bv4294967295 32)))) true)))
(let (($x178 (or false false (or $x166))))
(and (not $x178) (or $x178 (and (distinct (bvadd in.29_32 (_ bv4294967295 32)) (bvadd in.29_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 17: function kernel_ludcmp, block 32, name %33
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x90 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x46 (or false false (or $x90))))
(and (not $x46) (or $x46 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 18: function kernel_ludcmp, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_32 () (_ BitVec 32))
(assert
 (let (($x183 (and (distinct (bvadd ((_ sign_extend 1) in.03_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.03_32 (_ bv1 32)))) true)))
(let (($x185 (or false false (or $x183))))
(and (not $x185) (or $x185 (and (distinct (bvadd in.03_32 (_ bv1 32)) (bvadd in.03_32 (_ bv1 32))) true))))))
(check-sat)
; query 19: function kernel_ludcmp, block 71, name %72
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x195 (and (distinct (bvadd ((_ sign_extend 1) in.12_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.12_32 (_ bv1 32)))) true)))
(let (($x197 (or false false (or $x195))))
(and (not $x197) (or $x197 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 20: function kernel_ludcmp, block 78, name %79
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.14_32 () (_ BitVec 32))
(assert
 (let (($x207 (and (distinct (bvadd ((_ sign_extend 1) in.14_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.14_32 (_ bv1 32)))) true)))
(let (($x209 (or false false (or $x207))))
(and (not $x209) (or $x209 (and (distinct (bvadd in.14_32 (_ bv1 32)) (bvadd in.14_32 (_ bv1 32))) true))))))
(check-sat)
; query 21: function kernel_ludcmp, block 81, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.07_32 () (_ BitVec 32))
(assert
 (let (($x136 (and (distinct (bvadd ((_ sign_extend 1) in.07_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.07_32 (_ bv1 32)))) true)))
(let (($x133 (or false false (or $x136))))
(and (not $x133) (or $x133 (and (distinct (bvadd in.07_32 (_ bv1 32)) (bvadd in.07_32 (_ bv1 32))) true))))))
(check-sat)
; query 22: function polybench_flush_cache, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x90 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x46 (or false false (or $x90))))
(and (not $x46) (or $x46 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 23: function print_array, block 21, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x126 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x83 (or false false (or $x126))))
(and (not $x83) (or $x83 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 24: function xmalloc, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in7_32 () (_ BitVec 32))
(assert
 (let ((?x220 (ite (and (distinct (_ bv0 32) in7_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x217 (or false false false)))
(and (not $x217) (or $x217 (and (distinct ?x220 ?x220) true))))))
(check-sat)
