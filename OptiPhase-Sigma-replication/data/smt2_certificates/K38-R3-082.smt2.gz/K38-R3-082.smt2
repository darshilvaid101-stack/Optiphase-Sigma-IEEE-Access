; OptiPhase-Sigma refinement certificate for sweep K38-R3-082
