; OptiPhase-Sigma refinement certificate for sweep K38-R3-275
; query 0: function BF_cbc_encrypt, block 126, name %127
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.010_64 () (_ BitVec 64))
(assert
 (let (($x119 (and (distinct (bvsub ((_ sign_extend 1) in.010_64) ((_ sign_extend 1) (_ bv8 64))) ((_ sign_extend 1) (bvsub in.010_64 (_ bv8 64)))) true)))
(let (($x550 (or false false (or $x119))))
(and (not $x550) (or $x550 (and (distinct (bvsub in.010_64 (_ bv8 64)) (bvsub in.010_64 (_ bv8 64))) true))))))
(check-sat)
; query 1: function BF_cbc_encrypt, block 128, name %129
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.010_64 () (_ BitVec 64))
(assert
 (let ((?x9 (ite (and (distinct (_ bv18446744073709551608 64) in.010_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x606 (or false false false)))
(let (($x473 (not $x606)))
(and $x473 (or $x606 (and (distinct ?x9 ?x9) true)))))))
(check-sat)
; query 2: function BF_cfb64_encrypt, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.07_32 () (_ BitVec 32))
(assert
 (let ((?x185 (ite (= (_ bv0 32) in.07_32) (_ bv1 1) (_ bv0 1))))
(let (($x606 (or false false false)))
(let (($x473 (not $x606)))
(and $x473 (or $x606 (and (distinct ?x185 ?x185) true)))))))
(check-sat)
; query 3: function BF_set_key, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x14 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x319 (or false false (or $x14))))
(and (not $x319) (or $x319 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 4: function BF_set_key, block 69, name %70
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.13_32 () (_ BitVec 32))
(assert
 (let (($x6 (and (distinct (bvadd ((_ sign_extend 1) in.13_32) ((_ sign_extend 1) (_ bv2 32))) ((_ sign_extend 1) (bvadd in.13_32 (_ bv2 32)))) true)))
(let (($x34 (or false false (or $x6))))
(and (not $x34) (or $x34 (and (distinct (bvadd in.13_32 (_ bv2 32)) (bvadd in.13_32 (_ bv2 32))) true))))))
(check-sat)
; query 5: function BF_set_key, block 87, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.24_32 () (_ BitVec 32))
(assert
 (let (($x53 (and (distinct (bvadd ((_ sign_extend 1) in.24_32) ((_ sign_extend 1) (_ bv2 32))) ((_ sign_extend 1) (bvadd in.24_32 (_ bv2 32)))) true)))
(let (($x123 (or false false (or $x53))))
(and (not $x123) (or $x123 (and (distinct (bvadd in.24_32 (_ bv2 32)) (bvadd in.24_32 (_ bv2 32))) true))))))
(check-sat)
; query 6: function main, block 60, name %61
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x100 (or false false)))
(and (not $x100) (or $x100 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 7: function main, block 60, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x71 (ite (bvsge (_ bv57 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x100 (or false false)))
(let (($x30 (or $x100 false false)))
(let (($x75 (not $x30)))
(and $x75 (or $x30 (and (distinct ?x71 ?x71) true))))))))
(check-sat)
; query 8: function main, block 63, name %64
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x606 (or false false false)))
(and (not (or $x606 (bvuge (_ bv4 32) (_ bv32 32)))) (or $x606 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvmul in.01_32 (_ bv16 32))) true)))))
(check-sat)
; query 9: function main, block 63, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x100 (or false false)))
(and (not $x100) (or $x100 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 10: function main, block 63, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x39 (bvmul in.01_32 (_ bv16 32))))
(let ((?x19 (bvadd ?x39 (_ bv4294967248 32))))
(let ((?x33 ((_ sign_extend 24) in57_8)))
(let ((?x50 (bvshl in.01_32 (_ bv4 32))))
(let ((?x87 (bvadd ?x50 ?x33)))
(let (($x606 (or false false false)))
(let (($x40 (or $x606 false false)))
(let ((?x258 ((_ sign_extend 1) ?x87)))
(let (($x100 (or false false)))
(let (($x13 (or $x606 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x49 (or $x13 $x100 (or (and (distinct (bvadd ((_ sign_extend 1) ?x50) ((_ sign_extend 1) ?x33)) ?x258) true)))))
(let (($x448 (not $x49)))
(and $x448 (or $x40 (and (distinct ?x87 ?x19) true))))))))))))))))
(check-sat)
; query 11: function main, block 63, name %67
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x33 ((_ sign_extend 24) in57_8)))
(let ((?x50 (bvshl in.01_32 (_ bv4 32))))
(let ((?x87 (bvadd ?x50 ?x33)))
(let ((?x386 (bvsub ?x87 (_ bv48 32))))
(let (($x100 (or false false)))
(let (($x606 (or false false false)))
(let (($x40 (or $x606 false false)))
(let (($x330 (or $x40 $x100 false)))
(let (($x146 (or $x330 (and (distinct ?x386 (bvadd (bvadd (bvmul in.01_32 (_ bv16 32)) (_ bv4294967248 32)) ?x33)) true))))
(let (($x359 (and (distinct (bvsub ((_ sign_extend 1) ?x87) ((_ sign_extend 1) (_ bv48 32))) ((_ sign_extend 1) ?x386)) true)))
(let ((?x258 ((_ sign_extend 1) ?x87)))
(let (($x13 (or $x606 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x49 (or $x13 $x100 (or (and (distinct (bvadd ((_ sign_extend 1) ?x50) ((_ sign_extend 1) ?x33)) ?x258) true)))))
(and (not (or $x49 false (or $x359))) $x146)))))))))))))))
(check-sat)
; query 12: function main, block 68, name %69
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x100 (or false false)))
(and (not $x100) (or $x100 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 13: function main, block 68, name %70
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x576 (ite (bvsle (_ bv65 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x100 (or false false)))
(let (($x30 (or $x100 false false)))
(let (($x75 (not $x30)))
(and $x75 (or $x30 (and (distinct ?x576 ?x576) true))))))))
(check-sat)
; query 14: function main, block 71, name %72
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x100 (or false false)))
(and (not $x100) (or $x100 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 15: function main, block 71, name %73
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x124 (ite (bvsge (_ bv70 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x100 (or false false)))
(let (($x30 (or $x100 false false)))
(let (($x75 (not $x30)))
(and $x75 (or $x30 (and (distinct ?x124 ?x124) true))))))))
(check-sat)
; query 16: function main, block 74, name %75
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x606 (or false false false)))
(and (not (or $x606 (bvuge (_ bv4 32) (_ bv32 32)))) (or $x606 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvmul in.01_32 (_ bv16 32))) true)))))
(check-sat)
; query 17: function main, block 74, name %76
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x100 (or false false)))
(and (not $x100) (or $x100 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 18: function main, block 74, name %77
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x39 (bvmul in.01_32 (_ bv16 32))))
(let ((?x383 (bvadd ?x39 (_ bv4294967241 32))))
(let ((?x33 ((_ sign_extend 24) in57_8)))
(let ((?x50 (bvshl in.01_32 (_ bv4 32))))
(let ((?x87 (bvadd ?x50 ?x33)))
(let (($x606 (or false false false)))
(let (($x40 (or $x606 false false)))
(let ((?x258 ((_ sign_extend 1) ?x87)))
(let (($x100 (or false false)))
(let (($x13 (or $x606 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x49 (or $x13 $x100 (or (and (distinct (bvadd ((_ sign_extend 1) ?x50) ((_ sign_extend 1) ?x33)) ?x258) true)))))
(let (($x448 (not $x49)))
(and $x448 (or $x40 (and (distinct ?x87 ?x383) true))))))))))))))))
(check-sat)
; query 19: function main, block 74, name %78
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x33 ((_ sign_extend 24) in57_8)))
(let ((?x50 (bvshl in.01_32 (_ bv4 32))))
(let ((?x87 (bvadd ?x50 ?x33)))
(let ((?x90 (bvsub ?x87 (_ bv65 32))))
(let (($x100 (or false false)))
(let (($x606 (or false false false)))
(let (($x40 (or $x606 false false)))
(let (($x330 (or $x40 $x100 false)))
(let (($x540 (or $x330 (and (distinct ?x90 (bvadd (bvadd (bvmul in.01_32 (_ bv16 32)) (_ bv4294967241 32)) ?x33)) true))))
(let (($x116 (and (distinct (bvsub ((_ sign_extend 1) ?x87) ((_ sign_extend 1) (_ bv65 32))) ((_ sign_extend 1) ?x90)) true)))
(let ((?x258 ((_ sign_extend 1) ?x87)))
(let (($x13 (or $x606 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x49 (or $x13 $x100 (or (and (distinct (bvadd ((_ sign_extend 1) ?x50) ((_ sign_extend 1) ?x33)) ?x258) true)))))
(and (not (or $x49 false (or $x116))) $x540)))))))))))))))
(check-sat)
