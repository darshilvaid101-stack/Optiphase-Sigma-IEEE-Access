; OptiPhase-Sigma refinement certificate for sweep K40-R4-361
