; OptiPhase-Sigma refinement certificate for sweep K57-R5-398
; query 0: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x674 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x41 (or false false false)))
(let (($x337 (not $x41)))
(and $x337 (or $x41 (and (distinct ?x674 ?x674) true)))))))
(check-sat)
; query 1: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x167 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x41 (or false false false)))
(let (($x337 (not $x41)))
(and $x337 (or $x41 (and (distinct ?x167 ?x167) true)))))))
(check-sat)
