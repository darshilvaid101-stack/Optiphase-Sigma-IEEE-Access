; OptiPhase-Sigma refinement certificate for sweep K30-R3-097
; query 0: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x8 (ite (bvsgt (_ bv2 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x6 (or false false false)))
(and (not $x6) (or $x6 (and (distinct ?x8 ?x8) true))))))
(check-sat)
