; OptiPhase-Sigma refinement certificate for sweep K37-R6-020
; query 0: function bit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x102 (and (distinct (bvsub ((_ sign_extend 1) (_ bv31 32)) ((_ sign_extend 1) in0_32)) ((_ sign_extend 1) (bvsub (_ bv31 32) in0_32))) true)))
(let (($x167 (or false false (or $x102))))
(and (not $x167) (or $x167 (and (distinct (bvsub (_ bv31 32) in0_32) (bvsub (_ bv31 32) in0_32)) true))))))
(check-sat)
; query 1: function bit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x71 (bvsub (_ bv31 32) in0_32)))
(let ((?x246 (bvshl (_ bv1 32) ?x71)))
(let (($x17 (bvuge ?x71 (_ bv32 32))))
(let (($x102 (and (distinct (bvsub ((_ sign_extend 1) (_ bv31 32)) ((_ sign_extend 1) in0_32)) ((_ sign_extend 1) ?x71)) true)))
(let (($x167 (or false false (or $x102))))
(let (($x203 (or (or false $x167 (or (and (distinct (_ bv1 32) (bvlshr ?x246 ?x71)) true))) $x17)))
(and (not (or (or false $x167 false) $x17)) (or $x203 (and (distinct ?x246 ?x246) true))))))))))
(check-sat)
; query 2: function bit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x71 (bvsub (_ bv31 32) in0_32)))
(let ((?x246 (bvshl (_ bv1 32) ?x71)))
(let ((?x69 ((_ sign_extend 32) ?x246)))
(let (($x17 (bvuge ?x71 (_ bv32 32))))
(let (($x102 (and (distinct (bvsub ((_ sign_extend 1) (_ bv31 32)) ((_ sign_extend 1) in0_32)) ((_ sign_extend 1) ?x71)) true)))
(let (($x167 (or false false (or $x102))))
(let (($x203 (or (or false $x167 (or (and (distinct (_ bv1 32) (bvlshr ?x246 ?x71)) true))) $x17)))
(let (($x322 (or $x203 false)))
(and (not (or (or (or false $x167 false) $x17) false)) (or $x322 (and (distinct ?x69 ?x69) true))))))))))))
(check-sat)
; query 3: function bit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x71 (bvsub (_ bv31 32) in0_32)))
(let ((?x246 (bvshl (_ bv1 32) ?x71)))
(let ((?x69 ((_ sign_extend 32) ?x246)))
(let ((?x569 (bvand in1_64 ?x69)))
(let (($x17 (bvuge ?x71 (_ bv32 32))))
(let (($x102 (and (distinct (bvsub ((_ sign_extend 1) (_ bv31 32)) ((_ sign_extend 1) in0_32)) ((_ sign_extend 1) ?x71)) true)))
(let (($x167 (or false false (or $x102))))
(let (($x203 (or (or false $x167 (or (and (distinct (_ bv1 32) (bvlshr ?x246 ?x71)) true))) $x17)))
(let (($x322 (or $x203 false)))
(let (($x454 (not (or false (or (or (or false $x167 false) $x17) false) false))))
(and $x454 (or (or false $x322 false) (and (distinct ?x569 ?x569) true))))))))))))))
(check-sat)
