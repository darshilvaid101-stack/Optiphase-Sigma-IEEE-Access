; OptiPhase-Sigma refinement certificate for sweep K18-R2-021
; query 0: function xmalloc, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in7_32 () (_ BitVec 32))
(assert
 (let ((?x24 (ite (and (distinct (_ bv0 32) in7_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x66 (or false false false)))
(and (not $x66) (or $x66 (and (distinct ?x24 ?x24) true))))))
(check-sat)
