; OptiPhase-Sigma refinement certificate for sweep K38-R3-282
; query 0: function main, block 60, name %61
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x149 (or false false)))
(and (not $x149) (or $x149 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 1: function main, block 60, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x20 (ite (bvsge (_ bv57 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x149 (or false false)))
(let (($x175 (or $x149 false false)))
(let (($x365 (not $x175)))
(and $x365 (or $x175 (and (distinct ?x20 ?x20) true))))))))
(check-sat)
; query 2: function main, block 63, name %64
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x416 (or false false false)))
(and (not (or $x416 (bvuge (_ bv4 32) (_ bv32 32)))) (or $x416 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvmul in.01_32 (_ bv16 32))) true)))))
(check-sat)
; query 3: function main, block 63, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x149 (or false false)))
(and (not $x149) (or $x149 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 4: function main, block 63, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x59 (bvmul in.01_32 (_ bv16 32))))
(let ((?x429 (bvadd ?x59 (_ bv4294967248 32))))
(let ((?x196 ((_ sign_extend 24) in57_8)))
(let ((?x278 (bvshl in.01_32 (_ bv4 32))))
(let ((?x500 (bvadd ?x278 ?x196)))
(let (($x416 (or false false false)))
(let (($x24 (or $x416 false false)))
(let ((?x299 ((_ sign_extend 1) ?x500)))
(let (($x149 (or false false)))
(let (($x366 (or $x416 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x286 (or $x366 $x149 (or (and (distinct (bvadd ((_ sign_extend 1) ?x278) ((_ sign_extend 1) ?x196)) ?x299) true)))))
(let (($x38 (not $x286)))
(and $x38 (or $x24 (and (distinct ?x500 ?x429) true))))))))))))))))
(check-sat)
; query 5: function main, block 63, name %67
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x196 ((_ sign_extend 24) in57_8)))
(let ((?x278 (bvshl in.01_32 (_ bv4 32))))
(let ((?x500 (bvadd ?x278 ?x196)))
(let ((?x253 (bvsub ?x500 (_ bv48 32))))
(let (($x149 (or false false)))
(let (($x416 (or false false false)))
(let (($x24 (or $x416 false false)))
(let (($x39 (or $x24 $x149 false)))
(let (($x501 (or $x39 (and (distinct ?x253 (bvadd (bvadd (bvmul in.01_32 (_ bv16 32)) (_ bv4294967248 32)) ?x196)) true))))
(let (($x90 (and (distinct (bvsub ((_ sign_extend 1) ?x500) ((_ sign_extend 1) (_ bv48 32))) ((_ sign_extend 1) ?x253)) true)))
(let ((?x299 ((_ sign_extend 1) ?x500)))
(let (($x366 (or $x416 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x286 (or $x366 $x149 (or (and (distinct (bvadd ((_ sign_extend 1) ?x278) ((_ sign_extend 1) ?x196)) ?x299) true)))))
(and (not (or $x286 false (or $x90))) $x501)))))))))))))))
(check-sat)
; query 6: function main, block 68, name %69
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x149 (or false false)))
(and (not $x149) (or $x149 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 7: function main, block 68, name %70
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x124 (ite (bvsle (_ bv65 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x149 (or false false)))
(let (($x175 (or $x149 false false)))
(let (($x365 (not $x175)))
(and $x365 (or $x175 (and (distinct ?x124 ?x124) true))))))))
(check-sat)
; query 8: function main, block 71, name %72
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x149 (or false false)))
(and (not $x149) (or $x149 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 9: function main, block 71, name %73
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x140 (ite (bvsge (_ bv70 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x149 (or false false)))
(let (($x175 (or $x149 false false)))
(let (($x365 (not $x175)))
(and $x365 (or $x175 (and (distinct ?x140 ?x140) true))))))))
(check-sat)
; query 10: function main, block 74, name %75
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x416 (or false false false)))
(and (not (or $x416 (bvuge (_ bv4 32) (_ bv32 32)))) (or $x416 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvmul in.01_32 (_ bv16 32))) true)))))
(check-sat)
; query 11: function main, block 74, name %76
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x149 (or false false)))
(and (not $x149) (or $x149 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 12: function main, block 74, name %77
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x59 (bvmul in.01_32 (_ bv16 32))))
(let ((?x54 (bvadd ?x59 (_ bv4294967241 32))))
(let ((?x196 ((_ sign_extend 24) in57_8)))
(let ((?x278 (bvshl in.01_32 (_ bv4 32))))
(let ((?x500 (bvadd ?x278 ?x196)))
(let (($x416 (or false false false)))
(let (($x24 (or $x416 false false)))
(let ((?x299 ((_ sign_extend 1) ?x500)))
(let (($x149 (or false false)))
(let (($x366 (or $x416 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x286 (or $x366 $x149 (or (and (distinct (bvadd ((_ sign_extend 1) ?x278) ((_ sign_extend 1) ?x196)) ?x299) true)))))
(let (($x38 (not $x286)))
(and $x38 (or $x24 (and (distinct ?x500 ?x54) true))))))))))))))))
(check-sat)
; query 13: function main, block 74, name %78
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x196 ((_ sign_extend 24) in57_8)))
(let ((?x278 (bvshl in.01_32 (_ bv4 32))))
(let ((?x500 (bvadd ?x278 ?x196)))
(let ((?x120 (bvsub ?x500 (_ bv65 32))))
(let (($x149 (or false false)))
(let (($x416 (or false false false)))
(let (($x24 (or $x416 false false)))
(let (($x39 (or $x24 $x149 false)))
(let (($x121 (or $x39 (and (distinct ?x120 (bvadd (bvadd (bvmul in.01_32 (_ bv16 32)) (_ bv4294967241 32)) ?x196)) true))))
(let (($x18 (and (distinct (bvsub ((_ sign_extend 1) ?x500) ((_ sign_extend 1) (_ bv65 32))) ((_ sign_extend 1) ?x120)) true)))
(let ((?x299 ((_ sign_extend 1) ?x500)))
(let (($x366 (or $x416 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x286 (or $x366 $x149 (or (and (distinct (bvadd ((_ sign_extend 1) ?x278) ((_ sign_extend 1) ?x196)) ?x299) true)))))
(and (not (or $x286 false (or $x18))) $x121)))))))))))))))
(check-sat)
