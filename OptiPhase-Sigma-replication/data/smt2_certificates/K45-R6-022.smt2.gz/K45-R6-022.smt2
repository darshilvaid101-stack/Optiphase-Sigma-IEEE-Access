; OptiPhase-Sigma refinement certificate for sweep K45-R6-022
; query 0: function Index_to_frequency, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x83 (ite (bvuge in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x1278 (or false false false)))
(let (($x383 (not $x1278)))
(and $x383 (or $x1278 (and (distinct ?x83 ?x83) true)))))))
(check-sat)
; query 1: function IsPowerOfTwo, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x1278 (or false false false)))
(let (($x383 (not $x1278)))
(and $x383 (or $x1278 (and (distinct (bvsub in0_32 (_ bv1 32)) (bvsub in0_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function IsPowerOfTwo, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x33 (bvsub in0_32 (_ bv1 32))))
(let ((?x62 (bvand in0_32 ?x33)))
(let (($x1278 (or false false false)))
(let (($x145 (or false $x1278 false)))
(and (not $x145) (or $x145 (and (distinct ?x62 ?x62) true))))))))
(check-sat)
; query 3: function IsPowerOfTwo, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x310 (ite (and (distinct (_ bv0 32) (bvand in0_32 (bvsub in0_32 (_ bv1 32)))) true) (_ bv1 1) (_ bv0 1))))
(let (($x1278 (or false false false)))
(let (($x145 (or false $x1278 false)))
(let (($x576 (or $x145 false false)))
(and (not $x576) (or $x576 (and (distinct ?x310 ?x310) true))))))))
(check-sat)
; query 4: function IsPowerOfTwo, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x44 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x1278 (or false false false)))
(let (($x383 (not $x1278)))
(and $x383 (or $x1278 (and (distinct ?x44 ?x44) true)))))))
(check-sat)
; query 5: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x44 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x1278 (or false false false)))
(let (($x383 (not $x1278)))
(and $x383 (or $x1278 (and (distinct ?x44 ?x44) true)))))))
(check-sat)
; query 6: function fft_float, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x121 (ite (and (distinct (_ bv0 32) in1_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x1278 (or false false false)))
(let (($x383 (not $x1278)))
(and $x383 (or $x1278 (and (distinct ?x121 ?x121) true)))))))
(check-sat)
; query 7: function main, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x80 (ite (= (_ bv4 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x1278 (or false false false)))
(let (($x383 (not $x1278)))
(and $x383 (or $x1278 (and (distinct ?x80 ?x80) true)))))))
(check-sat)
; query 8: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x208 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x1278 (or false false false)))
(let (($x383 (not $x1278)))
(and $x383 (or $x1278 (and (distinct ?x208 ?x208) true)))))))
(check-sat)
