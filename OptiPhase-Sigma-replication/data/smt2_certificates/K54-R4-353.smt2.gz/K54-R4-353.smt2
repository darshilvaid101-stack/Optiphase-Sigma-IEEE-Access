; OptiPhase-Sigma refinement certificate for sweep K54-R4-353
