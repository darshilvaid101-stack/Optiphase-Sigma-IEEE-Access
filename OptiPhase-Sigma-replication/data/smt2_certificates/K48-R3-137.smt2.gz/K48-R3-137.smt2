; OptiPhase-Sigma refinement certificate for sweep K48-R3-137
; query 0: function APCM_inverse_quantization, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x139 (or false false)))
(let (($x586 (not $x139)))
(and $x586 (or $x139 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 1: function APCM_inverse_quantization, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x265 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x139 (or false false)))
(let (($x175 (or $x139 false false)))
(let (($x119 (not $x175)))
(and $x119 (or $x175 (and (distinct ?x265 ?x265) true))))))))
(check-sat)
; query 2: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x139 (or false false)))
(let (($x586 (not $x139)))
(and $x586 (or $x139 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 3: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x45 (ite (bvslt (_ bv15 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x139 (or false false)))
(let (($x175 (or $x139 false false)))
(let (($x119 (not $x175)))
(and $x119 (or $x175 (and (distinct ?x45 ?x45) true))))))))
(check-sat)
; query 4: function Decoding_of_the_coded_Log_Area_Ratios, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in6_64 () (_ BitVec 64))
(assert
 (let ((?x110 (ite (bvslt (_ bv0 64) in6_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x220 (not $x89)))
(and $x220 (or $x89 (and (distinct ?x110 ?x110) true)))))))
(check-sat)
; query 5: function Decoding_of_the_coded_Log_Area_Ratios, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in6_64 () (_ BitVec 64))
(assert
 (let ((?x110 (ite (bvslt (_ bv0 64) in6_64) (_ bv1 1) (_ bv0 1))))
(let ((?x168 ((_ zero_extend 63) ?x110)))
(let (($x89 (or false false false)))
(let (($x153 (or $x89 false)))
(let (($x160 (not $x153)))
(and $x160 (or $x153 (and (distinct ?x168 ?x168) true)))))))))
(check-sat)
; query 6: function Decoding_of_the_coded_Log_Area_Ratios, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in6_64 () (_ BitVec 64))
(assert
 (let ((?x110 (ite (bvslt (_ bv0 64) in6_64) (_ bv1 1) (_ bv0 1))))
(let (($x44 (= (_ bv1 1) ?x110)))
(let ((?x116 (ite $x44 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x89 (or false false false)))
(let (($x122 (or $x89 (ite $x44 false false))))
(and (not $x122) (or $x122 (and (distinct ?x116 ?x116) true)))))))))
(check-sat)
; query 7: function Decoding_of_the_coded_Log_Area_Ratios, block 9, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in6_64 () (_ BitVec 64))
(assert
 (let ((?x110 (ite (bvslt (_ bv0 64) in6_64) (_ bv1 1) (_ bv0 1))))
(let (($x44 (= (_ bv1 1) ?x110)))
(let ((?x116 (ite $x44 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x121 ((_ sign_extend 32) ?x116)))
(let (($x89 (or false false false)))
(let (($x122 (or $x89 (ite $x44 false false))))
(let (($x9 (or $x122 false)))
(and (not $x9) (or $x9 (and (distinct ?x121 ?x121) true)))))))))))
(check-sat)
; query 8: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x139 (or false false)))
(let (($x586 (not $x139)))
(and $x586 (or $x139 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 9: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x229 (ite (bvsgt (_ bv40 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x139 (or false false)))
(let (($x175 (or $x139 false false)))
(let (($x119 (not $x175)))
(and $x119 (or $x175 (and (distinct ?x229 ?x229) true))))))))
(check-sat)
; query 10: function Postprocessing, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in17_64 () (_ BitVec 64))
(assert
 (let ((?x162 (ite (bvslt (_ bv0 64) in17_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x220 (not $x89)))
(and $x220 (or $x89 (and (distinct ?x162 ?x162) true)))))))
(check-sat)
; query 11: function Postprocessing, block 20, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in17_64 () (_ BitVec 64))
(assert
 (let ((?x162 (ite (bvslt (_ bv0 64) in17_64) (_ bv1 1) (_ bv0 1))))
(let ((?x615 ((_ zero_extend 63) ?x162)))
(let (($x89 (or false false false)))
(let (($x153 (or $x89 false)))
(let (($x160 (not $x153)))
(and $x160 (or $x153 (and (distinct ?x615 ?x615) true)))))))))
(check-sat)
; query 12: function Postprocessing, block 20, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in17_64 () (_ BitVec 64))
(assert
 (let ((?x162 (ite (bvslt (_ bv0 64) in17_64) (_ bv1 1) (_ bv0 1))))
(let (($x142 (= (_ bv1 1) ?x162)))
(let ((?x61 (ite $x142 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x89 (or false false false)))
(let (($x169 (or $x89 (ite $x142 false false))))
(and (not $x169) (or $x169 (and (distinct ?x61 ?x61) true)))))))))
(check-sat)
; query 13: function Postprocessing, block 20, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in17_64 () (_ BitVec 64))
(assert
 (let ((?x162 (ite (bvslt (_ bv0 64) in17_64) (_ bv1 1) (_ bv0 1))))
(let (($x142 (= (_ bv1 1) ?x162)))
(let ((?x61 (ite $x142 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x143 ((_ sign_extend 32) ?x61)))
(let (($x89 (or false false false)))
(let (($x169 (or $x89 (ite $x142 false false))))
(let (($x75 (or $x169 false)))
(and (not $x75) (or $x75 (and (distinct ?x143 ?x143) true)))))))))))
(check-sat)
; query 14: function Quantization_and_coding, block 24, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_32 () (_ BitVec 32))
(declare-fun in21_64 () (_ BitVec 64))
(assert
 (let (($x14 (and (distinct (ite (bvslt (_ bv0 64) in21_64) (_ bv1 1) (_ bv0 1)) (ite (bvsgt (_ bv4294967264 32) in21_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x89 (or false false false)))
(let (($x220 (not $x89)))
(and $x220 (or $x89 $x14))))))
(check-sat)
; query 15: function Quantization_and_coding, block 261, name %262
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in258_32 () (_ BitVec 32))
(declare-fun in258_64 () (_ BitVec 64))
(assert
 (let (($x88 (and (distinct (ite (bvslt (_ bv0 64) in258_64) (_ bv1 1) (_ bv0 1)) (ite (bvsgt (_ bv4294967292 32) in258_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x89 (or false false false)))
(let (($x220 (not $x89)))
(and $x220 (or $x89 $x88))))))
(check-sat)
; query 16: function RPE_grid_positioning, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x139 (or false false)))
(let (($x586 (not $x139)))
(and $x586 (or $x139 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 17: function RPE_grid_positioning, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x27 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x64 (and (distinct ?x27 ?x27) true)))
(let (($x139 (or false false)))
(let (($x575 (or false $x139 false)))
(and (not $x575) (or $x575 $x64)))))))
(check-sat)
; query 18: function gsm_L_add, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_64 () (_ BitVec 64))
(assert
 (let ((?x144 (bvsub (_ bv0 64) in13_64)))
(let ((?x112 ((_ sign_extend 1) ?x144)))
(let (($x149 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in13_64)) ?x112) true)))))
(and (not $x149) (or $x149 (and (distinct ?x144 ?x144) true)))))))
(check-sat)
; query 19: function gsm_L_add, block 16, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_64 () (_ BitVec 64))
(assert
 (let ((?x144 (bvsub (_ bv0 64) in13_64)))
(let ((?x138 (bvsub ?x144 (_ bv2 64))))
(let (($x11 (and (distinct (bvsub ((_ sign_extend 1) ?x144) ((_ sign_extend 1) (_ bv2 64))) ((_ sign_extend 1) ?x138)) true)))
(let ((?x112 ((_ sign_extend 1) ?x144)))
(let (($x149 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in13_64)) ?x112) true)))))
(let (($x98 (or $x149 false (or $x11))))
(and (not $x98) (or $x98 (and (distinct ?x138 ?x138) true))))))))))
(check-sat)
; query 20: function gsm_L_add, block 21, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x173 (ite (bvsge (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x220 (not $x89)))
(and $x220 (or $x89 (and (distinct ?x173 ?x173) true)))))))
(check-sat)
; query 21: function gsm_L_add, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x65 (bvadd in0_64 in1_64)))
(let (($x54 (and (distinct ?x65 ?x65) true)))
(let (($x35 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) ?x65)) true)))
(let (($x79 (or false false (or $x35))))
(and (not $x79) (or $x79 $x54)))))))
(check-sat)
; query 22: function gsm_L_add, block 25, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x65 (bvadd in0_64 in1_64)))
(let (($x54 (and (distinct ?x65 ?x65) true)))
(let (($x180 (and (distinct (bvadd ((_ zero_extend 1) in0_64) ((_ zero_extend 1) in1_64)) ((_ zero_extend 1) ?x65)) true)))
(let (($x146 (or false false (or $x180))))
(let (($x89 (or false false false)))
(let (($x220 (not $x89)))
(and $x220 (or $x146 $x54)))))))))
(check-sat)
; query 23: function gsm_L_add, block 25, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x324 (ite (bvugt (bvadd in0_64 in1_64) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x180 (and (distinct (bvadd ((_ zero_extend 1) in0_64) ((_ zero_extend 1) in1_64)) ((_ zero_extend 1) (bvadd in0_64 in1_64))) true)))
(let (($x146 (or false false (or $x180))))
(let (($x89 (or false false false)))
(let (($x392 (or $x89 false false)))
(let (($x77 (not $x392)))
(and $x77 (or (or $x146 false false) (and (distinct ?x324 ?x324) true))))))))))
(check-sat)
; query 24: function gsm_L_add, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x632 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x220 (not $x89)))
(and $x220 (or $x89 (and (distinct ?x632 ?x632) true)))))))
(check-sat)
; query 25: function gsm_L_add, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x65 (bvadd in0_64 in1_64)))
(let (($x54 (and (distinct ?x65 ?x65) true)))
(let (($x35 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) ?x65)) true)))
(let (($x79 (or false false (or $x35))))
(and (not $x79) (or $x79 $x54)))))))
(check-sat)
; query 26: function gsm_L_add, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1750 (bvadd in0_64 (_ bv1 64))))
(let ((?x2081 (bvsub (_ bv0 64) ?x1750)))
(let (($x1176 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1750)) ((_ sign_extend 1) ?x2081)) true)))
(let ((?x369 ((_ sign_extend 1) ?x1750)))
(let (($x2230 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x369) true)))))
(let (($x634 (or false $x2230 (or $x1176))))
(and (not $x634) (or $x634 (and (distinct ?x2081 ?x2081) true))))))))))
(check-sat)
; query 27: function gsm_L_add, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1107 (bvadd in1_64 (_ bv1 64))))
(let ((?x215 ((_ sign_extend 1) ?x1107)))
(let (($x70 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x215) true)))))
(and (not $x70) (or $x70 (and (distinct ?x1107 ?x1107) true)))))))
(check-sat)
; query 28: function gsm_L_add, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1107 (bvadd in1_64 (_ bv1 64))))
(let ((?x1948 (bvsub (_ bv0 64) ?x1107)))
(let (($x896 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1107)) ((_ sign_extend 1) ?x1948)) true)))
(let ((?x215 ((_ sign_extend 1) ?x1107)))
(let (($x70 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x215) true)))))
(let (($x1928 (or false $x70 (or $x896))))
(and (not $x1928) (or $x1928 (and (distinct ?x1948 ?x1948) true))))))))))
(check-sat)
; query 29: function gsm_L_add, block 8, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1107 (bvadd in1_64 (_ bv1 64))))
(let ((?x1948 (bvsub (_ bv0 64) ?x1107)))
(let ((?x1750 (bvadd in0_64 (_ bv1 64))))
(let ((?x2081 (bvsub (_ bv0 64) ?x1750)))
(let ((?x78 (bvadd ?x2081 ?x1948)))
(let (($x2417 (and (distinct (bvadd ((_ zero_extend 1) ?x2081) ((_ zero_extend 1) ?x1948)) ((_ zero_extend 1) ?x78)) true)))
(let (($x896 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1107)) ((_ sign_extend 1) ?x1948)) true)))
(let ((?x215 ((_ sign_extend 1) ?x1107)))
(let (($x70 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x215) true)))))
(let (($x1928 (or false $x70 (or $x896))))
(let (($x1176 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1750)) ((_ sign_extend 1) ?x2081)) true)))
(let ((?x369 ((_ sign_extend 1) ?x1750)))
(let (($x2230 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x369) true)))))
(let (($x634 (or false $x2230 (or $x1176))))
(let (($x1181 (or $x634 $x1928 (or $x2417))))
(and (not (or $x634 $x1928 false)) (or $x1181 (and (distinct ?x78 ?x78) true)))))))))))))))))))
(check-sat)
; query 30: function gsm_L_add, block 8, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1107 (bvadd in1_64 (_ bv1 64))))
(let ((?x1948 (bvsub (_ bv0 64) ?x1107)))
(let ((?x1750 (bvadd in0_64 (_ bv1 64))))
(let ((?x2081 (bvsub (_ bv0 64) ?x1750)))
(let ((?x78 (bvadd ?x2081 ?x1948)))
(let ((?x212 (ite (bvuge ?x78 (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x2417 (and (distinct (bvadd ((_ zero_extend 1) ?x2081) ((_ zero_extend 1) ?x1948)) ((_ zero_extend 1) ?x78)) true)))
(let (($x896 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1107)) ((_ sign_extend 1) ?x1948)) true)))
(let ((?x215 ((_ sign_extend 1) ?x1107)))
(let (($x70 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x215) true)))))
(let (($x1928 (or false $x70 (or $x896))))
(let (($x1176 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1750)) ((_ sign_extend 1) ?x2081)) true)))
(let ((?x369 ((_ sign_extend 1) ?x1750)))
(let (($x2230 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x369) true)))))
(let (($x634 (or false $x2230 (or $x1176))))
(let (($x1181 (or $x634 $x1928 (or $x2417))))
(and (not (or (or $x634 $x1928 false) false false)) (or (or $x1181 false false) (and (distinct ?x212 ?x212) true))))))))))))))))))))
(check-sat)
; query 31: function gsm_L_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1750 (bvadd in0_64 (_ bv1 64))))
(let ((?x369 ((_ sign_extend 1) ?x1750)))
(let (($x2230 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x369) true)))))
(and (not $x2230) (or $x2230 (and (distinct ?x1750 ?x1750) true)))))))
(check-sat)
; query 32: function gsm_L_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1369 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x220 (not $x89)))
(and $x220 (or $x89 (and (distinct ?x1369 ?x1369) true)))))))
(check-sat)
; query 33: function gsm_L_asl, block 12, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1205 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x220 (not $x89)))
(and $x220 (or $x89 (and (distinct ?x1205 ?x1205) true)))))))
(check-sat)
; query 34: function gsm_L_asl, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x1197 (or false (or (= ((_ extract 31 31) in1_32) (_ bv1 1))))))
(let (($x139 (or false false)))
(let (($x586 (not $x139)))
(and $x586 (or $x1197 (and (distinct ((_ zero_extend 32) in1_32) ((_ zero_extend 32) in1_32)) true)))))))
(check-sat)
; query 35: function gsm_L_asl, block 17, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1706 ((_ zero_extend 32) in1_32)))
(let ((?x127 (bvshl in0_64 ?x1706)))
(let (($x2620 (bvuge ?x1706 (_ bv64 64))))
(let (($x1587 (or (or false (or false (or (= ((_ extract 31 31) in1_32) (_ bv1 1)))) false) $x2620)))
(let (($x2769 (not (or (or false (or false false) false) $x2620))))
(and $x2769 (or $x1587 (and (distinct ?x127 ?x127) true)))))))))
(check-sat)
; query 36: function gsm_L_asl, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1397 (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x220 (not $x89)))
(and $x220 (or $x89 (and (distinct ?x1397 ?x1397) true)))))))
(check-sat)
; query 37: function gsm_L_asl, block 7, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1369 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1710 ((_ zero_extend 31) ?x1369)))
(let ((?x2431 (bvsub (_ bv0 32) ?x1710)))
(let (($x416 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1710)) ((_ sign_extend 1) ?x2431)) true)))
(let (($x89 (or false false false)))
(let (($x153 (or $x89 false)))
(let (($x2660 (or false $x153 (or $x416))))
(and (not $x2660) (or $x2660 (and (distinct ?x2431 ?x2431) true)))))))))))
(check-sat)
; query 38: function gsm_L_asl, block 7, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1369 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1710 ((_ zero_extend 31) ?x1369)))
(let ((?x2431 (bvsub (_ bv0 32) ?x1710)))
(let ((?x1604 ((_ sign_extend 32) ?x2431)))
(let (($x416 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1710)) ((_ sign_extend 1) ?x2431)) true)))
(let (($x89 (or false false false)))
(let (($x153 (or $x89 false)))
(let (($x2660 (or false $x153 (or $x416))))
(let (($x1024 (or $x2660 false)))
(and (not $x1024) (or $x1024 (and (distinct ?x1604 ?x1604) true)))))))))))))
(check-sat)
; query 39: function gsm_L_asl, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1369 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x220 (not $x89)))
(and $x220 (or $x89 (and (distinct ?x1369 ?x1369) true)))))))
(check-sat)
; query 40: function gsm_L_asl, block 7, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1369 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1710 ((_ zero_extend 31) ?x1369)))
(let (($x89 (or false false false)))
(let (($x153 (or $x89 false)))
(let (($x160 (not $x153)))
(and $x160 (or $x153 (and (distinct ?x1710 ?x1710) true)))))))))
(check-sat)
; query 41: function gsm_L_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1526 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x220 (not $x89)))
(and $x220 (or $x89 (and (distinct ?x1526 ?x1526) true)))))))
(check-sat)
; query 42: function gsm_L_asr, block 12, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1205 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x220 (not $x89)))
(and $x220 (or $x89 (and (distinct ?x1205 ?x1205) true)))))))
(check-sat)
; query 43: function gsm_L_asr, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x2633 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in1_32))) true)))
(let (($x1753 (or false false (or $x2633))))
(and (not $x1753) (or $x1753 (and (distinct (bvsub (_ bv0 32) in1_32) (bvsub (_ bv0 32) in1_32)) true))))))
(check-sat)
; query 44: function gsm_L_asr, block 14, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x534 (bvsub (_ bv0 32) in1_32)))
(let ((?x1351 ((_ zero_extend 32) ?x534)))
(let (($x2633 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x534)) true)))
(let (($x1753 (or false false (or $x2633))))
(let (($x1914 (or $x1753 (or (= ((_ extract 31 31) ?x534) (_ bv1 1))))))
(and (not (or $x1753 false)) (or $x1914 (and (distinct ?x1351 ?x1351) true)))))))))
(check-sat)
; query 45: function gsm_L_asr, block 14, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x534 (bvsub (_ bv0 32) in1_32)))
(let ((?x1351 ((_ zero_extend 32) ?x534)))
(let ((?x1410 (bvshl in0_64 ?x1351)))
(let (($x1648 (bvuge ?x1351 (_ bv64 64))))
(let (($x2633 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x534)) true)))
(let (($x1753 (or false false (or $x2633))))
(let (($x1914 (or $x1753 (or (= ((_ extract 31 31) ?x534) (_ bv1 1))))))
(and (not (or (or false (or $x1753 false) false) $x1648)) (or (or (or false $x1914 false) $x1648) (and (distinct ?x1410 ?x1410) true)))))))))))
(check-sat)
; query 46: function gsm_L_asr, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x1197 (or false (or (= ((_ extract 31 31) in1_32) (_ bv1 1))))))
(let (($x139 (or false false)))
(let (($x586 (not $x139)))
(and $x586 (or $x1197 (and (distinct ((_ zero_extend 32) in1_32) ((_ zero_extend 32) in1_32)) true)))))))
(check-sat)
; query 47: function gsm_L_asr, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1706 ((_ zero_extend 32) in1_32)))
(let ((?x1570 (bvashr in0_64 ?x1706)))
(let (($x2620 (bvuge ?x1706 (_ bv64 64))))
(let (($x1587 (or (or false (or false (or (= ((_ extract 31 31) in1_32) (_ bv1 1)))) false) $x2620)))
(let (($x2769 (not (or (or false (or false false) false) $x2620))))
(and $x2769 (or $x1587 (and (distinct ?x1570 ?x1570) true)))))))))
(check-sat)
; query 48: function gsm_L_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1369 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x220 (not $x89)))
(and $x220 (or $x89 (and (distinct ?x1369 ?x1369) true)))))))
(check-sat)
; query 49: function gsm_L_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1369 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1710 ((_ zero_extend 31) ?x1369)))
(let (($x89 (or false false false)))
(let (($x153 (or $x89 false)))
(let (($x160 (not $x153)))
(and $x160 (or $x153 (and (distinct ?x1710 ?x1710) true)))))))))
(check-sat)
; query 50: function gsm_L_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1369 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1710 ((_ zero_extend 31) ?x1369)))
(let ((?x2431 (bvsub (_ bv0 32) ?x1710)))
(let (($x416 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1710)) ((_ sign_extend 1) ?x2431)) true)))
(let (($x89 (or false false false)))
(let (($x153 (or $x89 false)))
(let (($x2660 (or false $x153 (or $x416))))
(and (not $x2660) (or $x2660 (and (distinct ?x2431 ?x2431) true)))))))))))
(check-sat)
; query 51: function gsm_L_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1369 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1710 ((_ zero_extend 31) ?x1369)))
(let ((?x2431 (bvsub (_ bv0 32) ?x1710)))
(let ((?x1604 ((_ sign_extend 32) ?x2431)))
(let (($x416 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1710)) ((_ sign_extend 1) ?x2431)) true)))
(let (($x89 (or false false false)))
(let (($x153 (or $x89 false)))
(let (($x2660 (or false $x153 (or $x416))))
(let (($x1024 (or $x2660 false)))
(and (not $x1024) (or $x1024 (and (distinct ?x1604 ?x1604) true)))))))))))))
(check-sat)
; query 52: function gsm_L_asr, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1397 (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x220 (not $x89)))
(and $x220 (or $x89 (and (distinct ?x1397 ?x1397) true)))))))
(check-sat)
; query 53: function gsm_L_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1526 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x220 (not $x89)))
(and $x220 (or $x89 (and (distinct ?x1526 ?x1526) true)))))))
(check-sat)
; query 54: function gsm_L_mult, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x139 (or false false)))
(let (($x586 (not $x139)))
(and $x586 (or $x139 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 55: function gsm_L_mult, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x813 (ite (and (distinct (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) true) (_ bv1 1) (_ bv0 1))))
(let (($x139 (or false false)))
(let (($x175 (or $x139 false false)))
(let (($x119 (not $x175)))
(and $x119 (or $x175 (and (distinct ?x813 ?x813) true))))))))
(check-sat)
; query 56: function gsm_L_mult, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x139 (or false false)))
(let (($x586 (not $x139)))
(and $x586 (or $x139 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 57: function gsm_L_mult, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x2272 (ite (and (distinct (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) true) (_ bv1 1) (_ bv0 1))))
(let (($x139 (or false false)))
(let (($x175 (or $x139 false false)))
(let (($x119 (not $x175)))
(and $x119 (or $x175 (and (distinct ?x2272 ?x2272) true))))))))
(check-sat)
; query 58: function gsm_L_sub, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in11_64 () (_ BitVec 64))
(assert
 (let (($x769 (and (distinct (bvadd ((_ zero_extend 1) in11_64) ((_ zero_extend 1) (_ bv1 64))) ((_ zero_extend 1) (bvadd in11_64 (_ bv1 64)))) true)))
(let (($x1452 (and (distinct (bvadd ((_ sign_extend 1) in11_64) ((_ sign_extend 1) (_ bv1 64))) ((_ sign_extend 1) (bvadd in11_64 (_ bv1 64)))) true)))
(let (($x1268 (or (or false false (or $x1452 $x769)) (and (distinct (bvadd in11_64 (_ bv1 64)) (bvadd in11_64 (_ bv1 64))) true))))
(let (($x89 (or false false false)))
(let (($x220 (not $x89)))
(and $x220 $x1268)))))))
(check-sat)
; query 59: function gsm_L_sub, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x173 (ite (bvsge (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x220 (not $x89)))
(and $x220 (or $x89 (and (distinct ?x173 ?x173) true)))))))
(check-sat)
; query 60: function gsm_L_sub, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x689 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvsub in0_64 in1_64))) true)))
(let (($x2672 (or false false (or $x689))))
(let (($x2084 (or $x2672 (and (distinct (bvsub in0_64 in1_64) (bvsub in0_64 in1_64)) true))))
(and (not $x2672) $x2084)))))
(check-sat)
; query 61: function gsm_L_sub, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1750 (bvadd in0_64 (_ bv1 64))))
(let ((?x369 ((_ sign_extend 1) ?x1750)))
(let (($x2230 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x369) true)))))
(and (not $x2230) (or $x2230 (and (distinct ?x1750 ?x1750) true)))))))
(check-sat)
; query 62: function gsm_L_sub, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1750 (bvadd in0_64 (_ bv1 64))))
(let ((?x2081 (bvsub (_ bv0 64) ?x1750)))
(let (($x1176 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1750)) ((_ sign_extend 1) ?x2081)) true)))
(let ((?x369 ((_ sign_extend 1) ?x1750)))
(let (($x2230 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x369) true)))))
(let (($x634 (or false $x2230 (or $x1176))))
(and (not $x634) (or $x634 (and (distinct ?x2081 ?x2081) true))))))))))
(check-sat)
; query 63: function gsm_L_sub, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1750 (bvadd in0_64 (_ bv1 64))))
(let ((?x2081 (bvsub (_ bv0 64) ?x1750)))
(let ((?x1496 (bvadd ?x2081 in1_64)))
(let (($x1929 (and (distinct (bvadd ((_ zero_extend 1) ?x2081) ((_ zero_extend 1) in1_64)) ((_ zero_extend 1) ?x1496)) true)))
(let (($x1176 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1750)) ((_ sign_extend 1) ?x2081)) true)))
(let ((?x369 ((_ sign_extend 1) ?x1750)))
(let (($x2230 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x369) true)))))
(let (($x634 (or false $x2230 (or $x1176))))
(let (($x1936 (or $x634 false (or $x1929))))
(and (not (or $x634 false false)) (or $x1936 (and (distinct ?x1496 ?x1496) true)))))))))))))
(check-sat)
; query 64: function gsm_L_sub, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1931 (ite (bvuge (bvadd (bvsub (_ bv0 64) (bvadd in0_64 (_ bv1 64))) in1_64) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let ((?x647 ((_ zero_extend 1) in1_64)))
(let ((?x1750 (bvadd in0_64 (_ bv1 64))))
(let ((?x2081 (bvsub (_ bv0 64) ?x1750)))
(let ((?x1658 ((_ zero_extend 1) ?x2081)))
(let (($x1176 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1750)) ((_ sign_extend 1) ?x2081)) true)))
(let ((?x369 ((_ sign_extend 1) ?x1750)))
(let (($x2230 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x369) true)))))
(let (($x634 (or false $x2230 (or $x1176))))
(let (($x1936 (or $x634 false (or (and (distinct (bvadd ?x1658 ?x647) ((_ zero_extend 1) (bvadd ?x2081 in1_64))) true)))))
(and (not (or (or $x634 false false) false false)) (or (or $x1936 false false) (and (distinct ?x1931 ?x1931) true))))))))))))))
(check-sat)
; query 65: function gsm_L_sub, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_64 () (_ BitVec 64))
(assert
 (let ((?x310 (bvsub (_ bv0 64) in25_64)))
(let ((?x403 ((_ sign_extend 1) ?x310)))
(let (($x1339 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in25_64)) ?x403) true)))))
(and (not $x1339) (or $x1339 (and (distinct ?x310 ?x310) true)))))))
(check-sat)
; query 66: function gsm_L_sub, block 28, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_64 () (_ BitVec 64))
(assert
 (let ((?x310 (bvsub (_ bv0 64) in25_64)))
(let ((?x1791 (bvsub ?x310 (_ bv1 64))))
(let (($x2082 (and (distinct (bvsub ((_ zero_extend 1) ?x310) ((_ zero_extend 1) (_ bv1 64))) ((_ zero_extend 1) ?x1791)) true)))
(let (($x1098 (and (distinct (bvsub ((_ sign_extend 1) ?x310) ((_ sign_extend 1) (_ bv1 64))) ((_ sign_extend 1) ?x1791)) true)))
(let ((?x403 ((_ sign_extend 1) ?x310)))
(let (($x1339 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in25_64)) ?x403) true)))))
(and (not (or $x1339 false (or $x1098))) (or (or $x1339 false (or $x1098 $x2082)) (and (distinct ?x1791 ?x1791) true))))))))))
(check-sat)
; query 67: function gsm_L_sub, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x632 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x220 (not $x89)))
(and $x220 (or $x89 (and (distinct ?x632 ?x632) true)))))))
(check-sat)
; query 68: function gsm_L_sub, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x689 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvsub in0_64 in1_64))) true)))
(let (($x2672 (or false false (or $x689))))
(let (($x2084 (or $x2672 (and (distinct (bvsub in0_64 in1_64) (bvsub in0_64 in1_64)) true))))
(and (not $x2672) $x2084)))))
(check-sat)
; query 69: function gsm_L_sub, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1107 (bvadd in1_64 (_ bv1 64))))
(let ((?x1948 (bvsub (_ bv0 64) ?x1107)))
(let (($x896 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1107)) ((_ sign_extend 1) ?x1948)) true)))
(let ((?x215 ((_ sign_extend 1) ?x1107)))
(let (($x70 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x215) true)))))
(let (($x1928 (or false $x70 (or $x896))))
(and (not $x1928) (or $x1928 (and (distinct ?x1948 ?x1948) true))))))))))
(check-sat)
; query 70: function gsm_L_sub, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1107 (bvadd in1_64 (_ bv1 64))))
(let ((?x1948 (bvsub (_ bv0 64) ?x1107)))
(let ((?x248 (bvadd in0_64 ?x1948)))
(let (($x2258 (and (distinct (bvadd ((_ zero_extend 1) in0_64) ((_ zero_extend 1) ?x1948)) ((_ zero_extend 1) ?x248)) true)))
(let (($x896 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1107)) ((_ sign_extend 1) ?x1948)) true)))
(let ((?x215 ((_ sign_extend 1) ?x1107)))
(let (($x70 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x215) true)))))
(let (($x1928 (or false $x70 (or $x896))))
(let (($x1057 (or false $x1928 (or $x2258))))
(and (not (or false $x1928 false)) (or $x1057 (and (distinct ?x248 ?x248) true)))))))))))))
(check-sat)
; query 71: function gsm_L_sub, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1487 (ite (bvuge (bvadd in0_64 (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64)))) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let ((?x1107 (bvadd in1_64 (_ bv1 64))))
(let ((?x1948 (bvsub (_ bv0 64) ?x1107)))
(let ((?x1787 ((_ zero_extend 1) ?x1948)))
(let ((?x74 ((_ zero_extend 1) in0_64)))
(let (($x896 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1107)) ((_ sign_extend 1) ?x1948)) true)))
(let ((?x215 ((_ sign_extend 1) ?x1107)))
(let (($x70 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x215) true)))))
(let (($x1928 (or false $x70 (or $x896))))
(let (($x1057 (or false $x1928 (or (and (distinct (bvadd ?x74 ?x1787) ((_ zero_extend 1) (bvadd in0_64 ?x1948))) true)))))
(and (not (or (or false $x1928 false) false false)) (or (or $x1057 false false) (and (distinct ?x1487 ?x1487) true))))))))))))))
(check-sat)
; query 72: function gsm_L_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1107 (bvadd in1_64 (_ bv1 64))))
(let ((?x215 ((_ sign_extend 1) ?x1107)))
(let (($x70 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x215) true)))))
(and (not $x70) (or $x70 (and (distinct ?x1107 ?x1107) true)))))))
(check-sat)
; query 73: function gsm_L_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x591 (ite (bvsle (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x220 (not $x89)))
(and $x220 (or $x89 (and (distinct ?x591 ?x591) true)))))))
(check-sat)
; query 74: function gsm_abs, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x139 (or false false)))
(let (($x586 (not $x139)))
(and $x586 (or $x139 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 75: function gsm_abs, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1912 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x139 (or false false)))
(let (($x175 (or $x139 false false)))
(let (($x119 (not $x175)))
(and $x119 (or $x175 (and (distinct ?x1912 ?x1912) true))))))))
(check-sat)
; query 76: function gsm_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_64 () (_ BitVec 64))
(assert
 (let ((?x1111 (ite (bvslt (_ bv32767 64) in5_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x220 (not $x89)))
(and $x220 (or $x89 (and (distinct ?x1111 ?x1111) true)))))))
(check-sat)
; query 77: function gsm_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x139 (or false false)))
(let (($x586 (not $x139)))
(and $x586 (or $x139 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 78: function gsm_add, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x139 (or false false)))
(let (($x586 (not $x139)))
(and $x586 (or $x139 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 79: function gsm_add, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1879 ((_ sign_extend 48) in1_16)))
(let ((?x1186 ((_ sign_extend 48) in0_16)))
(let ((?x267 (bvadd ?x1186 ?x1879)))
(let (($x1901 (and (distinct (bvadd ((_ sign_extend 1) ?x1186) ((_ sign_extend 1) ?x1879)) ((_ sign_extend 1) ?x267)) true)))
(let (($x139 (or false false)))
(let (($x1642 (or $x139 $x139 (or $x1901))))
(and (not $x1642) (or $x1642 (and (distinct ?x267 ?x267) true))))))))))
(check-sat)
; query 80: function gsm_add, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1392 (ite (bvsgt (_ bv18446744073709518848 64) (bvadd ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x1879 ((_ sign_extend 48) in1_16)))
(let ((?x1754 ((_ sign_extend 1) ?x1879)))
(let ((?x1186 ((_ sign_extend 48) in0_16)))
(let ((?x719 ((_ sign_extend 1) ?x1186)))
(let (($x139 (or false false)))
(let (($x1642 (or $x139 $x139 (or (and (distinct (bvadd ?x719 ?x1754) ((_ sign_extend 1) (bvadd ?x1186 ?x1879))) true)))))
(let (($x1643 (or $x1642 false false)))
(and (not $x1643) (or $x1643 (and (distinct ?x1392 ?x1392) true))))))))))))
(check-sat)
; query 81: function gsm_asl, block 13, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1205 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x220 (not $x89)))
(and $x220 (or $x89 (and (distinct ?x1205 ?x1205) true)))))))
(check-sat)
; query 82: function gsm_asl, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x139 (or false false)))
(let (($x586 (not $x139)))
(and $x586 (or $x139 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 83: function gsm_asl, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x166 ((_ sign_extend 16) in0_16)))
(let ((?x1771 (bvshl ?x166 in1_32)))
(let (($x795 (bvuge in1_32 (_ bv32 32))))
(let (($x139 (or false false)))
(let (($x1832 (or (or $x139 false (or (and (distinct (bvashr ?x1771 in1_32) ?x166) true))) $x795)))
(let (($x175 (or $x139 false false)))
(let (($x516 (or $x175 $x795)))
(let (($x1189 (not $x516)))
(and $x1189 (or $x1832 (and (distinct ?x1771 ?x1771) true))))))))))))
(check-sat)
; query 84: function gsm_asl, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x166 ((_ sign_extend 16) in0_16)))
(let ((?x1771 (bvshl ?x166 in1_32)))
(let ((?x2702 ((_ extract 15 0) ?x1771)))
(let (($x795 (bvuge in1_32 (_ bv32 32))))
(let (($x139 (or false false)))
(let (($x1832 (or (or $x139 false (or (and (distinct (bvashr ?x1771 in1_32) ?x166) true))) $x795)))
(let (($x1155 (not (or (or (or $x139 false false) $x795) false))))
(and $x1155 (or (or $x1832 false) (and (distinct ?x2702 ?x2702) true)))))))))))
(check-sat)
; query 85: function gsm_asl, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x938 (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x220 (not $x89)))
(and $x220 (or $x89 (and (distinct ?x938 ?x938) true)))))))
(check-sat)
; query 86: function gsm_asl, block 7, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1912 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x198 ((_ zero_extend 31) ?x1912)))
(let (($x139 (or false false)))
(let (($x175 (or $x139 false false)))
(let (($x1470 (or $x175 false)))
(and (not $x1470) (or $x1470 (and (distinct ?x198 ?x198) true)))))))))
(check-sat)
; query 87: function gsm_asl, block 7, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1912 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x198 ((_ zero_extend 31) ?x1912)))
(let ((?x429 (bvsub (_ bv0 32) ?x198)))
(let (($x280 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x198)) ((_ sign_extend 1) ?x429)) true)))
(let (($x139 (or false false)))
(let (($x175 (or $x139 false false)))
(let (($x1470 (or $x175 false)))
(let (($x2093 (or false $x1470 (or $x280))))
(and (not $x2093) (or $x2093 (and (distinct ?x429 ?x429) true))))))))))))
(check-sat)
; query 88: function gsm_asl, block 7, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1912 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x198 ((_ zero_extend 31) ?x1912)))
(let ((?x429 (bvsub (_ bv0 32) ?x198)))
(let ((?x252 ((_ extract 15 0) ?x429)))
(let (($x280 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x198)) ((_ sign_extend 1) ?x429)) true)))
(let (($x139 (or false false)))
(let (($x175 (or $x139 false false)))
(let (($x1470 (or $x175 false)))
(let (($x2093 (or false $x1470 (or $x280))))
(let (($x1630 (or (or $x2093 (or (and (distinct ((_ sign_extend 16) ?x252) ?x429) true))) (and (distinct ?x252 ?x252) true))))
(and (not (or $x2093 false)) $x1630))))))))))))
(check-sat)
; query 89: function gsm_asl, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x139 (or false false)))
(let (($x586 (not $x139)))
(and $x586 (or $x139 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 90: function gsm_asl, block 7, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1912 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x139 (or false false)))
(let (($x175 (or $x139 false false)))
(let (($x119 (not $x175)))
(and $x119 (or $x175 (and (distinct ?x1912 ?x1912) true))))))))
(check-sat)
; query 91: function gsm_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x592 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x220 (not $x89)))
(and $x220 (or $x89 (and (distinct ?x592 ?x592) true)))))))
(check-sat)
; query 92: function gsm_asr, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x938 (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x220 (not $x89)))
(and $x220 (or $x89 (and (distinct ?x938 ?x938) true)))))))
(check-sat)
; query 93: function gsm_asr, block 13, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1205 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x220 (not $x89)))
(and $x220 (or $x89 (and (distinct ?x1205 ?x1205) true)))))))
(check-sat)
; query 94: function gsm_asr, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x139 (or false false)))
(let (($x586 (not $x139)))
(and $x586 (or $x139 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 95: function gsm_asr, block 15, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x2633 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in1_32))) true)))
(let (($x1753 (or false false (or $x2633))))
(and (not $x1753) (or $x1753 (and (distinct (bvsub (_ bv0 32) in1_32) (bvsub (_ bv0 32) in1_32)) true))))))
(check-sat)
; query 96: function gsm_asr, block 15, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x534 (bvsub (_ bv0 32) in1_32)))
(let ((?x166 ((_ sign_extend 16) in0_16)))
(let ((?x1182 (bvshl ?x166 ?x534)))
(let (($x1860 (bvuge ?x534 (_ bv32 32))))
(let (($x2633 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x534)) true)))
(let (($x1753 (or false false (or $x2633))))
(let (($x139 (or false false)))
(let (($x1349 (or (or $x139 $x1753 (or (and (distinct (bvashr ?x1182 ?x534) ?x166) true))) $x1860)))
(and (not (or (or $x139 $x1753 false) $x1860)) (or $x1349 (and (distinct ?x1182 ?x1182) true))))))))))))
(check-sat)
; query 97: function gsm_asr, block 15, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x534 (bvsub (_ bv0 32) in1_32)))
(let ((?x166 ((_ sign_extend 16) in0_16)))
(let ((?x1182 (bvshl ?x166 ?x534)))
(let ((?x1565 ((_ extract 15 0) ?x1182)))
(let (($x1860 (bvuge ?x534 (_ bv32 32))))
(let (($x2633 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x534)) true)))
(let (($x1753 (or false false (or $x2633))))
(let (($x139 (or false false)))
(let (($x1349 (or (or $x139 $x1753 (or (and (distinct (bvashr ?x1182 ?x534) ?x166) true))) $x1860)))
(and (not (or (or (or $x139 $x1753 false) $x1860) false)) (or (or $x1349 false) (and (distinct ?x1565 ?x1565) true)))))))))))))
(check-sat)
; query 98: function gsm_asr, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x139 (or false false)))
(let (($x586 (not $x139)))
(and $x586 (or $x139 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 99: function gsm_asr, block 20, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x166 ((_ sign_extend 16) in0_16)))
(let ((?x1721 (bvashr ?x166 in1_32)))
(let (($x795 (bvuge in1_32 (_ bv32 32))))
(let (($x139 (or false false)))
(let (($x175 (or $x139 false false)))
(let (($x516 (or $x175 $x795)))
(let (($x1189 (not $x516)))
(and $x1189 (or $x516 (and (distinct ?x1721 ?x1721) true)))))))))))
(check-sat)
; query 100: function gsm_asr, block 20, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x166 ((_ sign_extend 16) in0_16)))
(let ((?x1721 (bvashr ?x166 in1_32)))
(let ((?x2757 ((_ extract 15 0) ?x1721)))
(let (($x795 (bvuge in1_32 (_ bv32 32))))
(let (($x139 (or false false)))
(let (($x175 (or $x139 false false)))
(let (($x516 (or $x175 $x795)))
(let (($x287 (or (or $x516 (or (and (distinct ((_ sign_extend 16) ?x2757) ?x1721) true))) (and (distinct ?x2757 ?x2757) true))))
(let (($x1155 (not (or $x516 false))))
(and $x1155 $x287)))))))))))
(check-sat)
; query 101: function gsm_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x139 (or false false)))
(let (($x586 (not $x139)))
(and $x586 (or $x139 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 102: function gsm_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1912 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x139 (or false false)))
(let (($x175 (or $x139 false false)))
(let (($x119 (not $x175)))
(and $x119 (or $x175 (and (distinct ?x1912 ?x1912) true))))))))
(check-sat)
; query 103: function gsm_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1912 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x198 ((_ zero_extend 31) ?x1912)))
(let (($x139 (or false false)))
(let (($x175 (or $x139 false false)))
(let (($x1470 (or $x175 false)))
(and (not $x1470) (or $x1470 (and (distinct ?x198 ?x198) true)))))))))
(check-sat)
; query 104: function gsm_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1912 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x198 ((_ zero_extend 31) ?x1912)))
(let ((?x429 (bvsub (_ bv0 32) ?x198)))
(let (($x280 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x198)) ((_ sign_extend 1) ?x429)) true)))
(let (($x139 (or false false)))
(let (($x175 (or $x139 false false)))
(let (($x1470 (or $x175 false)))
(let (($x2093 (or false $x1470 (or $x280))))
(and (not $x2093) (or $x2093 (and (distinct ?x429 ?x429) true))))))))))))
(check-sat)
; query 105: function gsm_asr, block 4, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1912 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x198 ((_ zero_extend 31) ?x1912)))
(let ((?x429 (bvsub (_ bv0 32) ?x198)))
(let ((?x252 ((_ extract 15 0) ?x429)))
(let (($x280 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x198)) ((_ sign_extend 1) ?x429)) true)))
(let (($x139 (or false false)))
(let (($x175 (or $x139 false false)))
(let (($x1470 (or $x175 false)))
(let (($x2093 (or false $x1470 (or $x280))))
(let (($x1630 (or (or $x2093 (or (and (distinct ((_ sign_extend 16) ?x252) ?x429) true))) (and (distinct ?x252 ?x252) true))))
(and (not (or $x2093 false)) $x1630))))))))))))
(check-sat)
; query 106: function gsm_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x592 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x220 (not $x89)))
(and $x220 (or $x89 (and (distinct ?x592 ?x592) true)))))))
(check-sat)
; query 107: function gsm_debug_longwords, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in15_32 () (_ BitVec 32))
(assert
 (let ((?x877 (ite (bvslt in15_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x220 (not $x89)))
(and $x220 (or $x89 (and (distinct ?x877 ?x877) true)))))))
(check-sat)
; query 108: function gsm_debug_words, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in16_32 () (_ BitVec 32))
(assert
 (let ((?x1809 (ite (bvslt in16_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x220 (not $x89)))
(and $x220 (or $x89 (and (distinct ?x1809 ?x1809) true)))))))
(check-sat)
; query 109: function gsm_div, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x139 (or false false)))
(let (($x586 (not $x139)))
(and $x586 (or $x139 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 110: function gsm_div, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x139 (or false false)))
(let (($x586 (not $x139)))
(and $x586 (or $x139 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 111: function gsm_div, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x139 (or false false)))
(let (($x586 (not $x139)))
(and $x586 (or $x139 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 112: function gsm_div, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x27 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x64 (and (distinct ?x27 ?x27) true)))
(let (($x139 (or false false)))
(let (($x175 (or $x139 false false)))
(let (($x119 (not $x175)))
(and $x119 (or $x175 $x64))))))))
(check-sat)
; query 113: function gsm_mult, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x139 (or false false)))
(let (($x586 (not $x139)))
(and $x586 (or $x139 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 114: function gsm_mult, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1294 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x139 (or false false)))
(let (($x175 (or $x139 false false)))
(let (($x119 (not $x175)))
(and $x119 (or $x175 (and (distinct ?x1294 ?x1294) true))))))))
(check-sat)
; query 115: function gsm_mult, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x139 (or false false)))
(let (($x586 (not $x139)))
(and $x586 (or $x139 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 116: function gsm_mult, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x139 (or false false)))
(let (($x586 (not $x139)))
(and $x586 (or $x139 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 117: function gsm_mult, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1879 ((_ sign_extend 48) in1_16)))
(let ((?x1186 ((_ sign_extend 48) in0_16)))
(let ((?x2662 (bvmul ?x1186 ?x1879)))
(let (($x1652 (and (distinct (bvmul ((_ sign_extend 64) ?x1186) ((_ sign_extend 64) ?x1879)) ((_ sign_extend 64) ?x2662)) true)))
(let (($x139 (or false false)))
(let (($x1311 (or $x139 $x139 (or $x1652))))
(and (not $x1311) (or $x1311 (and (distinct ?x2662 ?x2662) true))))))))))
(check-sat)
; query 118: function gsm_mult, block 9, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1879 ((_ sign_extend 48) in1_16)))
(let ((?x1186 ((_ sign_extend 48) in0_16)))
(let ((?x2662 (bvmul ?x1186 ?x1879)))
(let ((?x811 (bvashr ?x2662 (_ bv15 64))))
(let (($x1026 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1652 (and (distinct (bvmul ((_ sign_extend 64) ?x1186) ((_ sign_extend 64) ?x1879)) ((_ sign_extend 64) ?x2662)) true)))
(let (($x139 (or false false)))
(let (($x1311 (or $x139 $x139 (or $x1652))))
(let (($x2641 (or (or $x1311 false false) $x1026)))
(and (not $x2641) (or $x2641 (and (distinct ?x811 ?x811) true)))))))))))))
(check-sat)
; query 119: function gsm_mult, block 9, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1879 ((_ sign_extend 48) in1_16)))
(let ((?x1186 ((_ sign_extend 48) in0_16)))
(let ((?x2662 (bvmul ?x1186 ?x1879)))
(let ((?x811 (bvashr ?x2662 (_ bv15 64))))
(let ((?x728 ((_ extract 15 0) ?x811)))
(let (($x1026 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1652 (and (distinct (bvmul ((_ sign_extend 64) ?x1186) ((_ sign_extend 64) ?x1879)) ((_ sign_extend 64) ?x2662)) true)))
(let (($x139 (or false false)))
(let (($x1311 (or $x139 $x139 (or $x1652))))
(let (($x2641 (or (or $x1311 false false) $x1026)))
(let (($x943 (or $x2641 false)))
(and (not $x943) (or $x943 (and (distinct ?x728 ?x728) true)))))))))))))))
(check-sat)
; query 120: function gsm_mult, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x139 (or false false)))
(let (($x586 (not $x139)))
(and $x586 (or $x139 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 121: function gsm_mult, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1751 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x139 (or false false)))
(let (($x175 (or $x139 false false)))
(let (($x119 (not $x175)))
(and $x119 (or $x175 (and (distinct ?x1751 ?x1751) true))))))))
(check-sat)
; query 122: function gsm_mult_r, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x139 (or false false)))
(let (($x586 (not $x139)))
(and $x586 (or $x139 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 123: function gsm_mult_r, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1751 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x139 (or false false)))
(let (($x175 (or $x139 false false)))
(let (($x119 (not $x175)))
(and $x119 (or $x175 (and (distinct ?x1751 ?x1751) true))))))))
(check-sat)
; query 124: function gsm_mult_r, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x139 (or false false)))
(let (($x586 (not $x139)))
(and $x586 (or $x139 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 125: function gsm_mult_r, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x139 (or false false)))
(let (($x586 (not $x139)))
(and $x586 (or $x139 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 126: function gsm_mult_r, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1879 ((_ sign_extend 48) in1_16)))
(let ((?x1186 ((_ sign_extend 48) in0_16)))
(let ((?x2662 (bvmul ?x1186 ?x1879)))
(let (($x1652 (and (distinct (bvmul ((_ sign_extend 64) ?x1186) ((_ sign_extend 64) ?x1879)) ((_ sign_extend 64) ?x2662)) true)))
(let (($x139 (or false false)))
(let (($x1311 (or $x139 $x139 (or $x1652))))
(and (not $x1311) (or $x1311 (and (distinct ?x2662 ?x2662) true))))))))))
(check-sat)
; query 127: function gsm_mult_r, block 9, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1879 ((_ sign_extend 48) in1_16)))
(let ((?x1186 ((_ sign_extend 48) in0_16)))
(let ((?x2662 (bvmul ?x1186 ?x1879)))
(let ((?x117 (bvadd ?x2662 (_ bv16384 64))))
(let (($x1320 (and (distinct (bvadd ((_ sign_extend 1) ?x2662) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x117)) true)))
(let (($x1652 (and (distinct (bvmul ((_ sign_extend 64) ?x1186) ((_ sign_extend 64) ?x1879)) ((_ sign_extend 64) ?x2662)) true)))
(let (($x139 (or false false)))
(let (($x1311 (or $x139 $x139 (or $x1652))))
(let (($x1670 (or $x1311 false (or $x1320))))
(and (not $x1670) (or $x1670 (and (distinct ?x117 ?x117) true)))))))))))))
(check-sat)
; query 128: function gsm_mult_r, block 9, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1879 ((_ sign_extend 48) in1_16)))
(let ((?x1186 ((_ sign_extend 48) in0_16)))
(let ((?x2662 (bvmul ?x1186 ?x1879)))
(let ((?x117 (bvadd ?x2662 (_ bv16384 64))))
(let ((?x1263 (bvashr ?x117 (_ bv15 64))))
(let (($x1026 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1320 (and (distinct (bvadd ((_ sign_extend 1) ?x2662) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x117)) true)))
(let (($x1652 (and (distinct (bvmul ((_ sign_extend 64) ?x1186) ((_ sign_extend 64) ?x1879)) ((_ sign_extend 64) ?x2662)) true)))
(let (($x139 (or false false)))
(let (($x1311 (or $x139 $x139 (or $x1652))))
(let (($x1670 (or $x1311 false (or $x1320))))
(let (($x454 (or (or $x1670 false false) $x1026)))
(and (not $x454) (or $x454 (and (distinct ?x1263 ?x1263) true))))))))))))))))
(check-sat)
; query 129: function gsm_mult_r, block 9, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1879 ((_ sign_extend 48) in1_16)))
(let ((?x1186 ((_ sign_extend 48) in0_16)))
(let ((?x2662 (bvmul ?x1186 ?x1879)))
(let ((?x117 (bvadd ?x2662 (_ bv16384 64))))
(let ((?x1263 (bvashr ?x117 (_ bv15 64))))
(let ((?x1052 (bvand ?x1263 (_ bv65535 64))))
(let (($x1026 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1320 (and (distinct (bvadd ((_ sign_extend 1) ?x2662) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x117)) true)))
(let (($x1652 (and (distinct (bvmul ((_ sign_extend 64) ?x1186) ((_ sign_extend 64) ?x1879)) ((_ sign_extend 64) ?x2662)) true)))
(let (($x139 (or false false)))
(let (($x1311 (or $x139 $x139 (or $x1652))))
(let (($x1670 (or $x1311 false (or $x1320))))
(let (($x454 (or (or $x1670 false false) $x1026)))
(let (($x457 (or $x454 false false)))
(and (not $x457) (or $x457 (and (distinct ?x1052 ?x1052) true))))))))))))))))))
(check-sat)
; query 130: function gsm_mult_r, block 9, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1879 ((_ sign_extend 48) in1_16)))
(let ((?x1186 ((_ sign_extend 48) in0_16)))
(let ((?x2662 (bvmul ?x1186 ?x1879)))
(let ((?x117 (bvadd ?x2662 (_ bv16384 64))))
(let ((?x1263 (bvashr ?x117 (_ bv15 64))))
(let ((?x1052 (bvand ?x1263 (_ bv65535 64))))
(let ((?x1783 ((_ extract 15 0) ?x1052)))
(let (($x1026 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1320 (and (distinct (bvadd ((_ sign_extend 1) ?x2662) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x117)) true)))
(let (($x1652 (and (distinct (bvmul ((_ sign_extend 64) ?x1186) ((_ sign_extend 64) ?x1879)) ((_ sign_extend 64) ?x2662)) true)))
(let (($x139 (or false false)))
(let (($x1311 (or $x139 $x139 (or $x1652))))
(let (($x1670 (or $x1311 false (or $x1320))))
(let (($x454 (or (or $x1670 false false) $x1026)))
(let (($x457 (or $x454 false false)))
(let (($x1934 (or (or $x457 (or (and (distinct ((_ zero_extend 48) ?x1783) ?x1052) true))) (and (distinct ?x1783 ?x1783) true))))
(and (not (or $x457 false)) $x1934))))))))))))))))))
(check-sat)
; query 131: function gsm_mult_r, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x139 (or false false)))
(let (($x586 (not $x139)))
(and $x586 (or $x139 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 132: function gsm_mult_r, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1294 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x139 (or false false)))
(let (($x175 (or $x139 false false)))
(let (($x119 (not $x175)))
(and $x119 (or $x175 (and (distinct ?x1294 ?x1294) true))))))))
(check-sat)
; query 133: function gsm_norm, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1369 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x220 (not $x89)))
(and $x220 (or $x89 (and (distinct ?x1369 (ite (bvsge (_ bv18446744072635809792 64) in0_64) (_ bv1 1) (_ bv0 1))) true)))))))
(check-sat)
; query 134: function gsm_norm, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x336 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x220 (not $x89)))
(and $x220 (or $x89 (and (distinct ?x336 ?x336) true)))))))
(check-sat)
; query 135: function gsm_norm, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x336 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x1167 (bvxor ?x336 (_ bv1 1))))
(let (($x89 (or false false false)))
(let (($x392 (or $x89 false false)))
(let (($x77 (not $x392)))
(and $x77 (or $x392 (and (distinct ?x1167 ?x1167) true)))))))))
(check-sat)
; query 136: function gsm_norm, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x336 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x1167 (bvxor ?x336 (_ bv1 1))))
(let ((?x2096 ((_ zero_extend 31) ?x1167)))
(let (($x89 (or false false false)))
(let (($x392 (or $x89 false false)))
(let (($x2076 (or $x392 false)))
(and (not $x2076) (or $x2076 (and (distinct ?x2096 ?x2096) true))))))))))
(check-sat)
; query 137: function gsm_norm, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x336 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x1167 (bvxor ?x336 (_ bv1 1))))
(let ((?x2096 ((_ zero_extend 31) ?x1167)))
(let (($x89 (or false false false)))
(let (($x392 (or $x89 false false)))
(let (($x2076 (or $x392 false)))
(let (($x2133 (or (or $x2076 (or (= ((_ extract 31 31) ?x2096) (_ bv1 1)))) (and (distinct ((_ sign_extend 32) ?x2096) ((_ zero_extend 32) ?x2096)) true))))
(and (not (or $x2076 false)) $x2133)))))))))
(check-sat)
; query 138: function gsm_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_64 () (_ BitVec 64))
(assert
 (let ((?x1111 (ite (bvslt (_ bv32767 64) in5_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x220 (not $x89)))
(and $x220 (or $x89 (and (distinct ?x1111 ?x1111) true)))))))
(check-sat)
; query 139: function gsm_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x139 (or false false)))
(let (($x586 (not $x139)))
(and $x586 (or $x139 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 140: function gsm_sub, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x139 (or false false)))
(let (($x586 (not $x139)))
(and $x586 (or $x139 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 141: function gsm_sub, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1879 ((_ sign_extend 48) in1_16)))
(let ((?x1186 ((_ sign_extend 48) in0_16)))
(let ((?x2772 (bvsub ?x1186 ?x1879)))
(let (($x1569 (and (distinct (bvsub ((_ sign_extend 1) ?x1186) ((_ sign_extend 1) ?x1879)) ((_ sign_extend 1) ?x2772)) true)))
(let (($x139 (or false false)))
(let (($x2074 (or $x139 $x139 (or $x1569))))
(and (not $x2074) (or $x2074 (and (distinct ?x2772 ?x2772) true))))))))))
(check-sat)
; query 142: function gsm_sub, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1086 (ite (bvsgt (_ bv18446744073709518848 64) (bvsub ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x1879 ((_ sign_extend 48) in1_16)))
(let ((?x1754 ((_ sign_extend 1) ?x1879)))
(let ((?x1186 ((_ sign_extend 48) in0_16)))
(let ((?x719 ((_ sign_extend 1) ?x1186)))
(let (($x139 (or false false)))
(let (($x2074 (or $x139 $x139 (or (and (distinct (bvsub ?x719 ?x1754) ((_ sign_extend 1) (bvsub ?x1186 ?x1879))) true)))))
(let (($x2762 (or $x2074 false false)))
(and (not $x2762) (or $x2762 (and (distinct ?x1086 ?x1086) true))))))))))))
(check-sat)
; query 143: function ok_to_replace, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x968 (ite (and (distinct (_ bv4294967295 32) in.01_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x220 (not $x89)))
(and $x220 (or $x89 (and (distinct ?x968 ?x968) true)))))))
(check-sat)
; query 144: function suffix, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_64 () (_ BitVec 64))
(declare-fun in3_64 () (_ BitVec 64))
(assert
 (let ((?x206 (ite (bvule in3_64 in4_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x220 (not $x89)))
(and $x220 (or $x89 (and (distinct ?x206 ?x206) true)))))))
(check-sat)
