; OptiPhase-Sigma refinement certificate for sweep K50-R3-100
; query 0: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x198 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x676 (or false false false)))
(and (not $x676) (or $x676 (and (distinct ?x198 ?x198) true))))))
(check-sat)
