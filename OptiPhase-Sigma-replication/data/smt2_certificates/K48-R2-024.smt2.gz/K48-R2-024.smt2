; OptiPhase-Sigma refinement certificate for sweep K48-R2-024
; query 0: function APCM_inverse_quantization, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in53_16) ((_ sign_extend 16) in53_16)) true))))))
(check-sat)
; query 1: function APCM_inverse_quantization, block 56, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let ((?x36 (ite (bvsle (_ bv4294967289 32) ((_ sign_extend 16) in53_16)) (_ bv1 1) (_ bv0 1))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x39 (not $x309)))
(and $x39 (or $x309 (and (distinct ?x36 ?x36) true))))))))
(check-sat)
; query 2: function APCM_inverse_quantization, block 68, name %69
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in53_16) ((_ sign_extend 16) in53_16)) true))))))
(check-sat)
; query 3: function APCM_inverse_quantization, block 68, name %70
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let ((?x182 ((_ sign_extend 16) in53_16)))
(let ((?x111 (bvshl ?x182 (_ bv12 32))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x149 (or $x309 (bvuge (_ bv12 32) (_ bv32 32)))))
(and (not $x149) (or $x149 (and (distinct ?x111 ?x111) true)))))))))
(check-sat)
; query 4: function APCM_inverse_quantization, block 68, name %71
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let ((?x182 ((_ sign_extend 16) in53_16)))
(let ((?x111 (bvshl ?x182 (_ bv12 32))))
(let ((?x71 ((_ extract 15 0) ?x111)))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x149 (or $x309 (bvuge (_ bv12 32) (_ bv32 32)))))
(let (($x411 (or $x149 false)))
(and (not $x411) (or $x411 (and (distinct ?x71 ?x71) true)))))))))))
(check-sat)
; query 5: function APCM_inverse_quantization, block 68, name %72
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in22_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 48) in22_16) ((_ sign_extend 48) in22_16)) true))))))
(check-sat)
; query 6: function APCM_inverse_quantization, block 68, name %73
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let ((?x182 ((_ sign_extend 16) in53_16)))
(let ((?x111 (bvshl ?x182 (_ bv12 32))))
(let ((?x71 ((_ extract 15 0) ?x111)))
(let ((?x108 ((_ sign_extend 48) ?x71)))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x149 (or $x309 (bvuge (_ bv12 32) (_ bv32 32)))))
(let (($x411 (or $x149 false)))
(let (($x458 (or $x411 false)))
(and (not $x458) (or $x458 (and (distinct ?x108 ?x108) true)))))))))))))
(check-sat)
; query 7: function APCM_inverse_quantization, block 68, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(declare-fun in22_16 () (_ BitVec 16))
(assert
 (let ((?x182 ((_ sign_extend 16) in53_16)))
(let ((?x111 (bvshl ?x182 (_ bv12 32))))
(let ((?x71 ((_ extract 15 0) ?x111)))
(let ((?x108 ((_ sign_extend 48) ?x71)))
(let ((?x120 ((_ sign_extend 48) in22_16)))
(let ((?x173 (bvmul ?x120 ?x108)))
(let (($x73 (and (distinct (bvmul ((_ sign_extend 64) ?x120) ((_ sign_extend 64) ?x108)) ((_ sign_extend 64) ?x173)) true)))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x149 (or $x309 (bvuge (_ bv12 32) (_ bv32 32)))))
(let (($x411 (or $x149 false)))
(let (($x458 (or $x411 false)))
(let (($x226 (or $x489 $x458 (or $x73))))
(and (not $x226) (or $x226 (and (distinct ?x173 ?x173) true)))))))))))))))))
(check-sat)
; query 8: function APCM_inverse_quantization, block 68, name %75
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(declare-fun in22_16 () (_ BitVec 16))
(assert
 (let ((?x182 ((_ sign_extend 16) in53_16)))
(let ((?x111 (bvshl ?x182 (_ bv12 32))))
(let ((?x71 ((_ extract 15 0) ?x111)))
(let ((?x108 ((_ sign_extend 48) ?x71)))
(let ((?x120 ((_ sign_extend 48) in22_16)))
(let ((?x173 (bvmul ?x120 ?x108)))
(let ((?x18 (bvadd ?x173 (_ bv16384 64))))
(let (($x83 (and (distinct (bvadd ((_ sign_extend 1) ?x173) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x18)) true)))
(let (($x73 (and (distinct (bvmul ((_ sign_extend 64) ?x120) ((_ sign_extend 64) ?x108)) ((_ sign_extend 64) ?x173)) true)))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x149 (or $x309 (bvuge (_ bv12 32) (_ bv32 32)))))
(let (($x411 (or $x149 false)))
(let (($x458 (or $x411 false)))
(let (($x226 (or $x489 $x458 (or $x73))))
(let (($x127 (or $x226 false (or $x83))))
(and (not $x127) (or $x127 (and (distinct ?x18 ?x18) true))))))))))))))))))))
(check-sat)
; query 9: function APCM_inverse_quantization, block 68, name %76
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(declare-fun in22_16 () (_ BitVec 16))
(assert
 (let ((?x182 ((_ sign_extend 16) in53_16)))
(let ((?x111 (bvshl ?x182 (_ bv12 32))))
(let ((?x71 ((_ extract 15 0) ?x111)))
(let ((?x108 ((_ sign_extend 48) ?x71)))
(let ((?x120 ((_ sign_extend 48) in22_16)))
(let ((?x173 (bvmul ?x120 ?x108)))
(let ((?x18 (bvadd ?x173 (_ bv16384 64))))
(let ((?x243 (bvashr ?x18 (_ bv15 64))))
(let (($x509 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x83 (and (distinct (bvadd ((_ sign_extend 1) ?x173) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x18)) true)))
(let (($x73 (and (distinct (bvmul ((_ sign_extend 64) ?x120) ((_ sign_extend 64) ?x108)) ((_ sign_extend 64) ?x173)) true)))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x149 (or $x309 (bvuge (_ bv12 32) (_ bv32 32)))))
(let (($x411 (or $x149 false)))
(let (($x458 (or $x411 false)))
(let (($x226 (or $x489 $x458 (or $x73))))
(let (($x127 (or $x226 false (or $x83))))
(let (($x287 (or (or $x127 false false) $x509)))
(and (not $x287) (or $x287 (and (distinct ?x243 ?x243) true)))))))))))))))))))))))
(check-sat)
; query 10: function APCM_inverse_quantization, block 68, name %77
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(declare-fun in22_16 () (_ BitVec 16))
(assert
 (let ((?x182 ((_ sign_extend 16) in53_16)))
(let ((?x111 (bvshl ?x182 (_ bv12 32))))
(let ((?x71 ((_ extract 15 0) ?x111)))
(let ((?x108 ((_ sign_extend 48) ?x71)))
(let ((?x120 ((_ sign_extend 48) in22_16)))
(let ((?x173 (bvmul ?x120 ?x108)))
(let ((?x18 (bvadd ?x173 (_ bv16384 64))))
(let ((?x243 (bvashr ?x18 (_ bv15 64))))
(let ((?x408 ((_ extract 15 0) ?x243)))
(let (($x509 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x83 (and (distinct (bvadd ((_ sign_extend 1) ?x173) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x18)) true)))
(let (($x73 (and (distinct (bvmul ((_ sign_extend 64) ?x120) ((_ sign_extend 64) ?x108)) ((_ sign_extend 64) ?x173)) true)))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x149 (or $x309 (bvuge (_ bv12 32) (_ bv32 32)))))
(let (($x411 (or $x149 false)))
(let (($x458 (or $x411 false)))
(let (($x226 (or $x489 $x458 (or $x73))))
(let (($x127 (or $x226 false (or $x83))))
(let (($x287 (or (or $x127 false false) $x509)))
(let (($x172 (or $x287 false)))
(and (not $x172) (or $x172 (and (distinct ?x408 ?x408) true)))))))))))))))))))))))))
(check-sat)
; query 11: function APCM_inverse_quantization, block 68, name %78
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(declare-fun in22_16 () (_ BitVec 16))
(assert
 (let ((?x182 ((_ sign_extend 16) in53_16)))
(let ((?x111 (bvshl ?x182 (_ bv12 32))))
(let ((?x71 ((_ extract 15 0) ?x111)))
(let ((?x108 ((_ sign_extend 48) ?x71)))
(let ((?x120 ((_ sign_extend 48) in22_16)))
(let ((?x173 (bvmul ?x120 ?x108)))
(let ((?x18 (bvadd ?x173 (_ bv16384 64))))
(let ((?x243 (bvashr ?x18 (_ bv15 64))))
(let ((?x408 ((_ extract 15 0) ?x243)))
(let ((?x113 ((_ sign_extend 48) ?x408)))
(let (($x509 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x83 (and (distinct (bvadd ((_ sign_extend 1) ?x173) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x18)) true)))
(let (($x73 (and (distinct (bvmul ((_ sign_extend 64) ?x120) ((_ sign_extend 64) ?x108)) ((_ sign_extend 64) ?x173)) true)))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x149 (or $x309 (bvuge (_ bv12 32) (_ bv32 32)))))
(let (($x411 (or $x149 false)))
(let (($x458 (or $x411 false)))
(let (($x226 (or $x489 $x458 (or $x73))))
(let (($x127 (or $x226 false (or $x83))))
(let (($x287 (or (or $x127 false false) $x509)))
(let (($x172 (or $x287 false)))
(let (($x159 (or $x172 false)))
(and (not $x159) (or $x159 (and (distinct ?x113 ?x113) true)))))))))))))))))))))))))))
(check-sat)
; query 12: function APCM_inverse_quantization, block 68, name %79
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in26_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 48) in26_16) ((_ sign_extend 48) in26_16)) true))))))
(check-sat)
; query 13: function APCM_inverse_quantization, block 68, name %80
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in26_16 () (_ BitVec 16))
(declare-fun in53_16 () (_ BitVec 16))
(declare-fun in22_16 () (_ BitVec 16))
(assert
 (let ((?x146 ((_ sign_extend 48) in26_16)))
(let ((?x182 ((_ sign_extend 16) in53_16)))
(let ((?x111 (bvshl ?x182 (_ bv12 32))))
(let ((?x71 ((_ extract 15 0) ?x111)))
(let ((?x108 ((_ sign_extend 48) ?x71)))
(let ((?x120 ((_ sign_extend 48) in22_16)))
(let ((?x173 (bvmul ?x120 ?x108)))
(let ((?x18 (bvadd ?x173 (_ bv16384 64))))
(let ((?x243 (bvashr ?x18 (_ bv15 64))))
(let ((?x408 ((_ extract 15 0) ?x243)))
(let ((?x113 ((_ sign_extend 48) ?x408)))
(let ((?x47 (bvadd ?x113 ?x146)))
(let ((?x441 ((_ sign_extend 1) ?x47)))
(let (($x489 (or false false)))
(let (($x509 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x83 (and (distinct (bvadd ((_ sign_extend 1) ?x173) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x18)) true)))
(let (($x73 (and (distinct (bvmul ((_ sign_extend 64) ?x120) ((_ sign_extend 64) ?x108)) ((_ sign_extend 64) ?x173)) true)))
(let (($x309 (or $x489 false false)))
(let (($x149 (or $x309 (bvuge (_ bv12 32) (_ bv32 32)))))
(let (($x411 (or $x149 false)))
(let (($x458 (or $x411 false)))
(let (($x226 (or $x489 $x458 (or $x73))))
(let (($x127 (or $x226 false (or $x83))))
(let (($x287 (or (or $x127 false false) $x509)))
(let (($x172 (or $x287 false)))
(let (($x159 (or $x172 false)))
(let (($x44 (or $x159 $x489 (or (and (distinct (bvadd ((_ sign_extend 1) ?x113) ((_ sign_extend 1) ?x146)) ?x441) true)))))
(and (not $x44) (or $x44 (and (distinct ?x47 ?x47) true)))))))))))))))))))))))))))))))
(check-sat)
; query 14: function APCM_inverse_quantization, block 68, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in26_16 () (_ BitVec 16))
(declare-fun in53_16 () (_ BitVec 16))
(declare-fun in22_16 () (_ BitVec 16))
(assert
 (let ((?x146 ((_ sign_extend 48) in26_16)))
(let ((?x182 ((_ sign_extend 16) in53_16)))
(let ((?x111 (bvshl ?x182 (_ bv12 32))))
(let ((?x71 ((_ extract 15 0) ?x111)))
(let ((?x108 ((_ sign_extend 48) ?x71)))
(let ((?x120 ((_ sign_extend 48) in22_16)))
(let ((?x173 (bvmul ?x120 ?x108)))
(let ((?x18 (bvadd ?x173 (_ bv16384 64))))
(let ((?x243 (bvashr ?x18 (_ bv15 64))))
(let ((?x408 ((_ extract 15 0) ?x243)))
(let ((?x113 ((_ sign_extend 48) ?x408)))
(let ((?x47 (bvadd ?x113 ?x146)))
(let ((?x196 (bvsub ?x47 (_ bv18446744073709518848 64))))
(let (($x33 (and (distinct (bvsub ((_ sign_extend 1) ?x47) ((_ sign_extend 1) (_ bv18446744073709518848 64))) ((_ sign_extend 1) ?x196)) true)))
(let ((?x441 ((_ sign_extend 1) ?x47)))
(let (($x489 (or false false)))
(let (($x509 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x83 (and (distinct (bvadd ((_ sign_extend 1) ?x173) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x18)) true)))
(let (($x73 (and (distinct (bvmul ((_ sign_extend 64) ?x120) ((_ sign_extend 64) ?x108)) ((_ sign_extend 64) ?x173)) true)))
(let (($x309 (or $x489 false false)))
(let (($x149 (or $x309 (bvuge (_ bv12 32) (_ bv32 32)))))
(let (($x411 (or $x149 false)))
(let (($x458 (or $x411 false)))
(let (($x226 (or $x489 $x458 (or $x73))))
(let (($x127 (or $x226 false (or $x83))))
(let (($x287 (or (or $x127 false false) $x509)))
(let (($x172 (or $x287 false)))
(let (($x159 (or $x172 false)))
(let (($x44 (or $x159 $x489 (or (and (distinct (bvadd ((_ sign_extend 1) ?x113) ((_ sign_extend 1) ?x146)) ?x441) true)))))
(let (($x333 (or $x44 false (or $x33))))
(and (not $x333) (or $x333 (and (distinct ?x196 ?x196) true))))))))))))))))))))))))))))))))))
(check-sat)
; query 15: function APCM_inverse_quantization, block 68, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in26_16 () (_ BitVec 16))
(declare-fun in53_16 () (_ BitVec 16))
(declare-fun in22_16 () (_ BitVec 16))
(assert
 (let ((?x146 ((_ sign_extend 48) in26_16)))
(let ((?x182 ((_ sign_extend 16) in53_16)))
(let ((?x111 (bvshl ?x182 (_ bv12 32))))
(let ((?x71 ((_ extract 15 0) ?x111)))
(let ((?x108 ((_ sign_extend 48) ?x71)))
(let ((?x120 ((_ sign_extend 48) in22_16)))
(let ((?x173 (bvmul ?x120 ?x108)))
(let ((?x18 (bvadd ?x173 (_ bv16384 64))))
(let ((?x243 (bvashr ?x18 (_ bv15 64))))
(let ((?x408 ((_ extract 15 0) ?x243)))
(let ((?x113 ((_ sign_extend 48) ?x408)))
(let ((?x47 (bvadd ?x113 ?x146)))
(let ((?x196 (bvsub ?x47 (_ bv18446744073709518848 64))))
(let ((?x422 (ite (bvugt ?x196 (_ bv65535 64)) (_ bv1 1) (_ bv0 1))))
(let (($x33 (and (distinct (bvsub ((_ sign_extend 1) ?x47) ((_ sign_extend 1) (_ bv18446744073709518848 64))) ((_ sign_extend 1) ?x196)) true)))
(let ((?x441 ((_ sign_extend 1) ?x47)))
(let (($x489 (or false false)))
(let (($x509 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x83 (and (distinct (bvadd ((_ sign_extend 1) ?x173) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x18)) true)))
(let (($x73 (and (distinct (bvmul ((_ sign_extend 64) ?x120) ((_ sign_extend 64) ?x108)) ((_ sign_extend 64) ?x173)) true)))
(let (($x309 (or $x489 false false)))
(let (($x149 (or $x309 (bvuge (_ bv12 32) (_ bv32 32)))))
(let (($x411 (or $x149 false)))
(let (($x458 (or $x411 false)))
(let (($x226 (or $x489 $x458 (or $x73))))
(let (($x127 (or $x226 false (or $x83))))
(let (($x287 (or (or $x127 false false) $x509)))
(let (($x172 (or $x287 false)))
(let (($x159 (or $x172 false)))
(let (($x44 (or $x159 $x489 (or (and (distinct (bvadd ((_ sign_extend 1) ?x113) ((_ sign_extend 1) ?x146)) ?x441) true)))))
(let (($x333 (or $x44 false (or $x33))))
(let (($x30 (or $x333 false false)))
(and (not $x30) (or $x30 (and (distinct ?x422 ?x422) true))))))))))))))))))))))))))))))))))))
(check-sat)
; query 16: function APCM_inverse_quantization, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 17: function APCM_inverse_quantization, block 7, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x559 (ite (bvsge (_ bv7 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x39 (not $x309)))
(and $x39 (or $x309 (and (distinct ?x559 ?x559) true))))))))
(check-sat)
; query 18: function APCM_inverse_quantization, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 19: function APCM_inverse_quantization, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x87 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x39 (not $x309)))
(and $x39 (or $x309 (and (distinct ?x87 ?x87) true))))))))
(check-sat)
; query 20: function APCM_quantization, block 159, name %160
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in152_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in152_16) ((_ sign_extend 16) in152_16)) true))))))
(check-sat)
; query 21: function APCM_quantization, block 159, name %161
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in152_16 () (_ BitVec 16))
(assert
 (let ((?x6 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in152_16)) (_ bv1 1) (_ bv0 1))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x39 (not $x309)))
(and $x39 (or $x309 (and (distinct ?x6 ?x6) true))))))))
(check-sat)
; query 22: function APCM_quantization, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in13_16) ((_ sign_extend 16) in13_16)) true))))))
(check-sat)
; query 23: function APCM_quantization, block 16, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_16 () (_ BitVec 16))
(assert
 (let ((?x106 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in13_16)) (_ bv1 1) (_ bv0 1))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x39 (not $x309)))
(and $x39 (or $x309 (and (distinct ?x106 ?x106) true))))))))
(check-sat)
; query 24: function APCM_quantization, block 162, name %163
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in152_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in152_16) ((_ sign_extend 16) in152_16)) true))))))
(check-sat)
; query 25: function APCM_quantization, block 162, name %164
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in152_16 () (_ BitVec 16))
(assert
 (let ((?x114 (ite (bvsgt (_ bv16 32) ((_ sign_extend 16) in152_16)) (_ bv1 1) (_ bv0 1))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x39 (not $x309)))
(and $x39 (or $x309 (and (distinct ?x114 ?x114) true))))))))
(check-sat)
; query 26: function APCM_quantization, block 195, name %196
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let (($x359 (and (distinct (bvadd ((_ sign_extend 1) in.2_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.2_32 (_ bv1 32)))) true)))
(let (($x356 (or false false (or $x359))))
(and (not $x356) (or $x356 (and (distinct (bvadd in.2_32 (_ bv1 32)) (bvadd in.2_32 (_ bv1 32))) true))))))
(check-sat)
; query 27: function APCM_quantization, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in13_16) ((_ sign_extend 16) in13_16)) true))))))
(check-sat)
; query 28: function APCM_quantization, block 20, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_16 () (_ BitVec 16))
(assert
 (let ((?x135 ((_ sign_extend 16) in13_16)))
(let ((?x48 (bvsub (_ bv0 32) ?x135)))
(let (($x304 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x135)) ((_ sign_extend 1) ?x48)) true)))
(let (($x489 (or false false)))
(let (($x259 (or false $x489 (or $x304))))
(and (not $x259) (or $x259 (and (distinct ?x48 ?x48) true)))))))))
(check-sat)
; query 29: function APCM_quantization, block 25, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in13_16) ((_ sign_extend 16) in13_16)) true))))))
(check-sat)
; query 30: function APCM_quantization, block 35, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_32 () (_ BitVec 32))
(assert
 (let (($x319 (and (distinct (bvadd ((_ sign_extend 1) in.03_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.03_32 (_ bv1 32)))) true)))
(let (($x390 (or false false (or $x319))))
(and (not $x390) (or $x390 (and (distinct (bvadd in.03_32 (_ bv1 32)) (bvadd in.03_32 (_ bv1 32))) true))))))
(check-sat)
; query 31: function APCM_quantization, block 61, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in47_32 () (_ BitVec 32))
(assert
 (let ((?x433 (ite (= (_ bv0 32) in47_32) (_ bv1 1) (_ bv0 1))))
(let (($x616 (or false false false)))
(let (($x382 (not $x616)))
(and $x382 (or $x616 (and (distinct ?x433 ?x433) true)))))))
(check-sat)
; query 32: function APCM_quantization, block 67, name %68
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.14_32 () (_ BitVec 32))
(assert
 (let (($x46 (and (distinct (bvadd ((_ sign_extend 1) in.14_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.14_32 (_ bv1 32)))) true)))
(let (($x20 (or false false (or $x46))))
(and (not $x20) (or $x20 (and (distinct (bvadd in.14_32 (_ bv1 32)) (bvadd in.14_32 (_ bv1 32))) true))))))
(check-sat)
; query 33: function APCM_quantization, block 93, name %94
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in90_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in90_16) ((_ sign_extend 16) in90_16)) true))))))
(check-sat)
; query 34: function APCM_quantization, block 93, name %95
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in90_16 () (_ BitVec 16))
(assert
 (let ((?x178 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in90_16)) (_ bv1 1) (_ bv0 1))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x39 (not $x309)))
(and $x39 (or $x309 (and (distinct ?x178 ?x178) true))))))))
(check-sat)
; query 35: function APCM_quantization_xmaxc_to_exp_mant, block 24, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in.0_16) ((_ sign_extend 16) in.0_16)) true))))))
(check-sat)
; query 36: function APCM_quantization_xmaxc_to_exp_mant, block 24, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let ((?x183 ((_ sign_extend 16) in.0_16)))
(let ((?x184 (bvshl ?x183 (_ bv1 32))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x166 (or $x309 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x776 (not $x166)))
(and $x776 (or $x166 (and (distinct ?x184 ?x184) true))))))))))
(check-sat)
; query 37: function APCM_quantization_xmaxc_to_exp_mant, block 24, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let ((?x183 ((_ sign_extend 16) in.0_16)))
(let ((?x184 (bvshl ?x183 (_ bv1 32))))
(let ((?x334 (bvor ?x184 (_ bv1 32))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x166 (or $x309 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x28 (or $x166 false false)))
(and (not $x28) (or $x28 (and (distinct ?x334 ?x334) true)))))))))))
(check-sat)
; query 38: function APCM_quantization_xmaxc_to_exp_mant, block 24, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let ((?x183 ((_ sign_extend 16) in.0_16)))
(let ((?x184 (bvshl ?x183 (_ bv1 32))))
(let ((?x334 (bvor ?x184 (_ bv1 32))))
(let ((?x577 ((_ extract 15 0) ?x334)))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x166 (or $x309 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x28 (or $x166 false false)))
(let (($x156 (or $x28 false)))
(and (not $x156) (or $x156 (and (distinct ?x577 ?x577) true)))))))))))))
(check-sat)
; query 39: function APCM_quantization_xmaxc_to_exp_mant, block 24, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_16 () (_ BitVec 16))
(assert
 (let (($x616 (or false false false)))
(let (($x382 (not $x616)))
(and $x382 (or $x616 (and (distinct (bvadd in.12_16 (_ bv65535 16)) (bvadd in.12_16 (_ bv65535 16))) true))))))
(check-sat)
; query 40: function APCM_quantization_xmaxc_to_exp_mant, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in.0_16) ((_ sign_extend 16) in.0_16)) true))))))
(check-sat)
; query 41: function APCM_quantization_xmaxc_to_exp_mant, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let ((?x183 ((_ sign_extend 16) in.0_16)))
(let ((?x297 (bvsub ?x183 (_ bv8 32))))
(let (($x524 (and (distinct (bvsub ((_ sign_extend 1) ?x183) ((_ sign_extend 1) (_ bv8 32))) ((_ sign_extend 1) ?x297)) true)))
(let (($x489 (or false false)))
(let (($x133 (or $x489 false (or $x524))))
(and (not $x133) (or $x133 (and (distinct ?x297 ?x297) true)))))))))
(check-sat)
; query 42: function APCM_quantization_xmaxc_to_exp_mant, block 30, name %33
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let ((?x183 ((_ sign_extend 16) in.0_16)))
(let ((?x297 (bvsub ?x183 (_ bv8 32))))
(let ((?x220 ((_ extract 15 0) ?x297)))
(let (($x524 (and (distinct (bvsub ((_ sign_extend 1) ?x183) ((_ sign_extend 1) (_ bv8 32))) ((_ sign_extend 1) ?x297)) true)))
(let (($x489 (or false false)))
(let (($x133 (or $x489 false (or $x524))))
(let (($x567 (or $x133 false)))
(and (not $x567) (or $x567 (and (distinct ?x220 ?x220) true)))))))))))
(check-sat)
; query 43: function APCM_quantization_xmaxc_to_exp_mant, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in.2_16) ((_ sign_extend 16) in.2_16)) true))))))
(check-sat)
; query 44: function APCM_quantization_xmaxc_to_exp_mant, block 37, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_16 () (_ BitVec 16))
(assert
 (let ((?x492 (ite (bvsge (_ bv6 32) ((_ sign_extend 16) in.2_16)) (_ bv1 1) (_ bv0 1))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x39 (not $x309)))
(and $x39 (or $x309 (and (distinct ?x492 ?x492) true))))))))
(check-sat)
; query 45: function APCM_quantization_xmaxc_to_exp_mant, block 49, name %50
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 46: function APCM_quantization_xmaxc_to_exp_mant, block 49, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x633 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in.1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x39 (not $x309)))
(and $x39 (or $x309 (and (distinct ?x633 ?x633) true))))))))
(check-sat)
; query 47: function APCM_quantization_xmaxc_to_exp_mant, block 52, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 48: function APCM_quantization_xmaxc_to_exp_mant, block 52, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x2041 (ite (bvsge (_ bv7 32) ((_ sign_extend 16) in.1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x39 (not $x309)))
(and $x39 (or $x309 (and (distinct ?x2041 ?x2041) true))))))))
(check-sat)
; query 49: function APCM_quantization_xmaxc_to_exp_mant, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1991 ((_ sign_extend 16) in0_16)))
(let ((?x1951 (bvashr ?x1991 (_ bv3 32))))
(let ((?x1911 (bvsub ?x1951 (_ bv1 32))))
(let ((?x1871 ((_ extract 15 0) ?x1911)))
(let (($x1901 (and (distinct (bvsub ((_ sign_extend 1) ?x1951) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x1911)) true)))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x1961 (or $x309 (bvuge (_ bv3 32) (_ bv32 32)))))
(let (($x1881 (or $x1961 false (or $x1901))))
(let (($x1861 (or $x1881 false)))
(and (not $x1861) (or $x1861 (and (distinct ?x1871 ?x1871) true))))))))))))))
(check-sat)
; query 50: function APCM_quantization_xmaxc_to_exp_mant, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 51: function APCM_quantization_xmaxc_to_exp_mant, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1991 ((_ sign_extend 16) in0_16)))
(let ((?x1951 (bvashr ?x1991 (_ bv3 32))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x1961 (or $x309 (bvuge (_ bv3 32) (_ bv32 32)))))
(and (not $x1961) (or $x1961 (and (distinct ?x1951 ?x1951) true)))))))))
(check-sat)
; query 52: function APCM_quantization_xmaxc_to_exp_mant, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1991 ((_ sign_extend 16) in0_16)))
(let ((?x1951 (bvashr ?x1991 (_ bv3 32))))
(let ((?x1911 (bvsub ?x1951 (_ bv1 32))))
(let (($x1901 (and (distinct (bvsub ((_ sign_extend 1) ?x1951) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x1911)) true)))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x1961 (or $x309 (bvuge (_ bv3 32) (_ bv32 32)))))
(let (($x1881 (or $x1961 false (or $x1901))))
(and (not $x1881) (or $x1881 (and (distinct ?x1911 ?x1911) true))))))))))))
(check-sat)
; query 53: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 54: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1382 (ite (bvslt (_ bv15 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x39 (not $x309)))
(and $x39 (or $x309 (and (distinct ?x1382 ?x1382) true))))))))
(check-sat)
; query 55: function Autocorrelation, block 115, name %116
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.3_32 () (_ BitVec 32))
(assert
 (let (($x1790 (and (distinct (bvadd ((_ sign_extend 1) in.3_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.3_32 (_ bv1 32)))) true)))
(let (($x1797 (or false false (or $x1790))))
(and (not $x1797) (or $x1797 (and (distinct (bvadd in.3_32 (_ bv1 32)) (bvadd in.3_32 (_ bv1 32))) true))))))
(check-sat)
; query 56: function Autocorrelation, block 132, name %133
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.4_32 () (_ BitVec 32))
(assert
 (let (($x1814 (and (distinct (bvadd ((_ sign_extend 1) in.4_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.4_32 (_ bv1 32)))) true)))
(let (($x414 (or false false (or $x1814))))
(and (not $x414) (or $x414 (and (distinct (bvadd in.4_32 (_ bv1 32)) (bvadd in.4_32 (_ bv1 32))) true))))))
(check-sat)
; query 57: function Autocorrelation, block 39, name %40
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x1822 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x1818 (or false false (or $x1822))))
(and (not $x1818) (or $x1818 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 58: function Autocorrelation, block 41, name %42
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in.04_16) ((_ sign_extend 16) in.04_16)) true))))))
(check-sat)
; query 59: function Autocorrelation, block 41, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let ((?x1833 (ite (= (_ bv0 32) ((_ sign_extend 16) in.04_16)) (_ bv1 1) (_ bv0 1))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x39 (not $x309)))
(and $x39 (or $x309 (and (distinct ?x1833 ?x1833) true))))))))
(check-sat)
; query 60: function Autocorrelation, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in.04_16) ((_ sign_extend 16) in.04_16)) true))))))
(check-sat)
; query 61: function Autocorrelation, block 45, name %47
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let ((?x1842 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.04_16)) (_ bv1 1) (_ bv0 1))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x39 (not $x309)))
(and $x39 (or $x309 (and (distinct ?x1842 ?x1842) true))))))))
(check-sat)
; query 62: function Autocorrelation, block 45, name %48
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let ((?x1842 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.04_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1838 (bvxor ?x1842 (_ bv1 1))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x1843 (or $x309 false false)))
(let (($x1857 (not $x1843)))
(and $x1857 (or $x1843 (and (distinct ?x1838 ?x1838) true))))))))))
(check-sat)
; query 63: function Autocorrelation, block 45, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let ((?x1842 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.04_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1838 (bvxor ?x1842 (_ bv1 1))))
(let ((?x1839 ((_ zero_extend 31) ?x1838)))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x1843 (or $x309 false false)))
(let (($x1846 (or $x1843 false)))
(let (($x1862 (not $x1846)))
(and $x1862 (or $x1846 (and (distinct ?x1839 ?x1839) true))))))))))))
(check-sat)
; query 64: function Autocorrelation, block 45, name %50
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let ((?x1842 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.04_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1838 (bvxor ?x1842 (_ bv1 1))))
(let ((?x1839 ((_ zero_extend 31) ?x1838)))
(let ((?x1847 ((_ sign_extend 32) ?x1839)))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x1843 (or $x309 false false)))
(let (($x1846 (or $x1843 false)))
(let (($x1854 (or $x1846 false)))
(let (($x1866 (not $x1854)))
(and $x1866 (or $x1854 (and (distinct ?x1847 ?x1847) true))))))))))))))
(check-sat)
; query 65: function Autocorrelation, block 45, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let ((?x1842 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.04_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1838 (bvxor ?x1842 (_ bv1 1))))
(let ((?x1839 ((_ zero_extend 31) ?x1838)))
(let ((?x1847 ((_ sign_extend 32) ?x1839)))
(let ((?x1853 (ite (and (distinct (_ bv0 64) ?x1847) true) (_ bv1 1) (_ bv0 1))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x1843 (or $x309 false false)))
(let (($x1846 (or $x1843 false)))
(let (($x1854 (or $x1846 false)))
(let (($x1852 (or $x1854 false false)))
(let (($x753 (not $x1852)))
(and $x753 (or $x1852 (and (distinct ?x1853 ?x1853) true))))))))))))))))
(check-sat)
; query 66: function Autocorrelation, block 525, name %526
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x357 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x1883 (or false false (or $x357))))
(and (not $x1883) (or $x1883 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 67: function Autocorrelation, block 537, name %538
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in.06_16) ((_ sign_extend 16) in.06_16)) true))))))
(check-sat)
; query 68: function Autocorrelation, block 537, name %539
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_16 () (_ BitVec 16))
(assert
 (let ((?x1892 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.06_16)) (_ bv1 1) (_ bv0 1))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x39 (not $x309)))
(and $x39 (or $x309 (and (distinct ?x1892 ?x1892) true))))))))
(check-sat)
; query 69: function Autocorrelation, block 540, name %541
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in.06_16) ((_ sign_extend 16) in.06_16)) true))))))
(check-sat)
; query 70: function Autocorrelation, block 540, name %542
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_16 () (_ BitVec 16))
(assert
 (let ((?x1902 (ite (bvsge (_ bv4 32) ((_ sign_extend 16) in.06_16)) (_ bv1 1) (_ bv0 1))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x39 (not $x309)))
(and $x39 (or $x309 (and (distinct ?x1902 ?x1902) true))))))))
(check-sat)
; query 71: function Autocorrelation, block 540, name %543
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_16 () (_ BitVec 16))
(assert
 (let ((?x1902 (ite (bvsge (_ bv4 32) ((_ sign_extend 16) in.06_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1903 (bvxor ?x1902 (_ bv1 1))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x1843 (or $x309 false false)))
(let (($x1857 (not $x1843)))
(and $x1857 (or $x1843 (and (distinct ?x1903 ?x1903) true))))))))))
(check-sat)
; query 72: function Autocorrelation, block 540, name %544
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_16 () (_ BitVec 16))
(assert
 (let ((?x1902 (ite (bvsge (_ bv4 32) ((_ sign_extend 16) in.06_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1903 (bvxor ?x1902 (_ bv1 1))))
(let ((?x1898 ((_ zero_extend 31) ?x1903)))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x1843 (or $x309 false false)))
(let (($x1846 (or $x1843 false)))
(let (($x1862 (not $x1846)))
(and $x1862 (or $x1846 (and (distinct ?x1898 ?x1898) true))))))))))))
(check-sat)
; query 73: function Autocorrelation, block 540, name %545
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_16 () (_ BitVec 16))
(assert
 (let ((?x1902 (ite (bvsge (_ bv4 32) ((_ sign_extend 16) in.06_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1903 (bvxor ?x1902 (_ bv1 1))))
(let ((?x1898 ((_ zero_extend 31) ?x1903)))
(let ((?x1899 ((_ sign_extend 32) ?x1898)))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x1843 (or $x309 false false)))
(let (($x1846 (or $x1843 false)))
(let (($x1854 (or $x1846 false)))
(let (($x1866 (not $x1854)))
(and $x1866 (or $x1854 (and (distinct ?x1899 ?x1899) true))))))))))))))
(check-sat)
; query 74: function Autocorrelation, block 540, name %546
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_16 () (_ BitVec 16))
(assert
 (let ((?x1902 (ite (bvsge (_ bv4 32) ((_ sign_extend 16) in.06_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1903 (bvxor ?x1902 (_ bv1 1))))
(let ((?x1898 ((_ zero_extend 31) ?x1903)))
(let ((?x1899 ((_ sign_extend 32) ?x1898)))
(let ((?x1907 (ite (and (distinct (_ bv0 64) ?x1899) true) (_ bv1 1) (_ bv0 1))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x1843 (or $x309 false false)))
(let (($x1846 (or $x1843 false)))
(let (($x1854 (or $x1846 false)))
(let (($x1852 (or $x1854 false false)))
(let (($x753 (not $x1852)))
(and $x753 (or $x1852 (and (distinct ?x1907 ?x1907) true))))))))))))))))
(check-sat)
; query 75: function Autocorrelation, block 81, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x269 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x1933 (or false false (or $x269))))
(and (not $x1933) (or $x1933 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 76: function Autocorrelation, block 98, name %99
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let (($x359 (and (distinct (bvadd ((_ sign_extend 1) in.2_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.2_32 (_ bv1 32)))) true)))
(let (($x356 (or false false (or $x359))))
(and (not $x356) (or $x356 (and (distinct (bvadd in.2_32 (_ bv1 32)) (bvadd in.2_32 (_ bv1 32))) true))))))
(check-sat)
; query 77: function Calculation_of_the_LTP_parameters, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in11_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in11_16) ((_ sign_extend 16) in11_16)) true))))))
(check-sat)
; query 78: function Calculation_of_the_LTP_parameters, block 14, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in11_16 () (_ BitVec 16))
(assert
 (let ((?x1942 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in11_16)) (_ bv1 1) (_ bv0 1))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x39 (not $x309)))
(and $x39 (or $x309 (and (distinct ?x1942 ?x1942) true))))))))
(check-sat)
; query 79: function Calculation_of_the_LTP_parameters, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in11_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in11_16) ((_ sign_extend 16) in11_16)) true))))))
(check-sat)
; query 80: function Calculation_of_the_LTP_parameters, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in11_16 () (_ BitVec 16))
(assert
 (let ((?x1945 ((_ sign_extend 16) in11_16)))
(let ((?x1953 (bvsub (_ bv0 32) ?x1945)))
(let (($x1948 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1945)) ((_ sign_extend 1) ?x1953)) true)))
(let (($x489 (or false false)))
(let (($x1956 (or false $x489 (or $x1948))))
(and (not $x1956) (or $x1956 (and (distinct ?x1953 ?x1953) true)))))))))
(check-sat)
; query 81: function Calculation_of_the_LTP_parameters, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in11_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in11_16) ((_ sign_extend 16) in11_16)) true))))))
(check-sat)
; query 82: function Calculation_of_the_LTP_parameters, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_32 () (_ BitVec 32))
(assert
 (let (($x319 (and (distinct (bvadd ((_ sign_extend 1) in.03_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.03_32 (_ bv1 32)))) true)))
(let (($x390 (or false false (or $x319))))
(and (not $x390) (or $x390 (and (distinct (bvadd in.03_32 (_ bv1 32)) (bvadd in.03_32 (_ bv1 32))) true))))))
(check-sat)
; query 83: function Calculation_of_the_LTP_parameters, block 35, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in.02_16) ((_ sign_extend 16) in.02_16)) true))))))
(check-sat)
; query 84: function Calculation_of_the_LTP_parameters, block 35, name %37
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x1959 (ite (= (_ bv0 32) ((_ sign_extend 16) in.02_16)) (_ bv1 1) (_ bv0 1))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x39 (not $x309)))
(and $x39 (or $x309 (and (distinct ?x1959 ?x1959) true))))))))
(check-sat)
; query 85: function Calculation_of_the_LTP_parameters, block 39, name %40
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in.02_16) ((_ sign_extend 16) in.02_16)) true))))))
(check-sat)
; query 86: function Calculation_of_the_LTP_parameters, block 39, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x1968 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.02_16)) (_ bv1 1) (_ bv0 1))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x39 (not $x309)))
(and $x39 (or $x309 (and (distinct ?x1968 ?x1968) true))))))))
(check-sat)
; query 87: function Calculation_of_the_LTP_parameters, block 39, name %42
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x1968 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.02_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1969 (bvxor ?x1968 (_ bv1 1))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x1843 (or $x309 false false)))
(let (($x1857 (not $x1843)))
(and $x1857 (or $x1843 (and (distinct ?x1969 ?x1969) true))))))))))
(check-sat)
; query 88: function Calculation_of_the_LTP_parameters, block 39, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x1968 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.02_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1969 (bvxor ?x1968 (_ bv1 1))))
(let ((?x1976 ((_ zero_extend 31) ?x1969)))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x1843 (or $x309 false false)))
(let (($x1846 (or $x1843 false)))
(let (($x1862 (not $x1846)))
(and $x1862 (or $x1846 (and (distinct ?x1976 ?x1976) true))))))))))))
(check-sat)
; query 89: function Calculation_of_the_LTP_parameters, block 39, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x1968 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.02_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1969 (bvxor ?x1968 (_ bv1 1))))
(let ((?x1976 ((_ zero_extend 31) ?x1969)))
(let ((?x1977 ((_ sign_extend 32) ?x1976)))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x1843 (or $x309 false false)))
(let (($x1846 (or $x1843 false)))
(let (($x1854 (or $x1846 false)))
(let (($x1866 (not $x1854)))
(and $x1866 (or $x1854 (and (distinct ?x1977 ?x1977) true))))))))))))))
(check-sat)
; query 90: function Calculation_of_the_LTP_parameters, block 39, name %45
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x1968 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.02_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1969 (bvxor ?x1968 (_ bv1 1))))
(let ((?x1976 ((_ zero_extend 31) ?x1969)))
(let ((?x1977 ((_ sign_extend 32) ?x1976)))
(let ((?x1985 (ite (and (distinct (_ bv0 64) ?x1977) true) (_ bv1 1) (_ bv0 1))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x1843 (or $x309 false false)))
(let (($x1846 (or $x1843 false)))
(let (($x1854 (or $x1846 false)))
(let (($x1852 (or $x1854 false false)))
(let (($x753 (not $x1852)))
(and $x753 (or $x1852 (and (distinct ?x1985 ?x1985) true))))))))))))))))
(check-sat)
; query 91: function Calculation_of_the_LTP_parameters, block 530, name %531
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.05_32 () (_ BitVec 32))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ extract 15 0) in.05_32) ((_ extract 15 0) in.05_32)) true))))))
(check-sat)
; query 92: function Calculation_of_the_LTP_parameters, block 533, name %534
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.05_32 () (_ BitVec 32))
(assert
 (let (($x2007 (and (distinct (bvadd ((_ sign_extend 1) in.05_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.05_32 (_ bv1 32)))) true)))
(let (($x2015 (or false false (or $x2007))))
(and (not $x2015) (or $x2015 (and (distinct (bvadd in.05_32 (_ bv1 32)) (bvadd in.05_32 (_ bv1 32))) true))))))
(check-sat)
; query 93: function Calculation_of_the_LTP_parameters, block 539, name %540
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in.01_16) ((_ sign_extend 16) in.01_16)) true))))))
(check-sat)
; query 94: function Calculation_of_the_LTP_parameters, block 539, name %541
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x2025 (ite (bvsle (_ bv4294967196 32) ((_ sign_extend 16) in.01_16)) (_ bv1 1) (_ bv0 1))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x39 (not $x309)))
(and $x39 (or $x309 (and (distinct ?x2025 ?x2025) true))))))))
(check-sat)
; query 95: function Calculation_of_the_LTP_parameters, block 551, name %552
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in.01_16) ((_ sign_extend 16) in.01_16)) true))))))
(check-sat)
; query 96: function Calculation_of_the_LTP_parameters, block 551, name %553
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x2016 ((_ sign_extend 16) in.01_16)))
(let ((?x2032 (bvsub (_ bv6 32) ?x2016)))
(let (($x2033 (and (distinct (bvsub ((_ sign_extend 1) (_ bv6 32)) ((_ sign_extend 1) ?x2016)) ((_ sign_extend 1) ?x2032)) true)))
(let (($x489 (or false false)))
(let (($x2029 (or false $x489 (or $x2033))))
(and (not $x2029) (or $x2029 (and (distinct ?x2032 ?x2032) true)))))))))
(check-sat)
; query 97: function Calculation_of_the_LTP_parameters, block 551, name %554
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x2016 ((_ sign_extend 16) in.01_16)))
(let ((?x2032 (bvsub (_ bv6 32) ?x2016)))
(let ((?x2036 ((_ zero_extend 32) ?x2032)))
(let (($x2033 (and (distinct (bvsub ((_ sign_extend 1) (_ bv6 32)) ((_ sign_extend 1) ?x2016)) ((_ sign_extend 1) ?x2032)) true)))
(let (($x489 (or false false)))
(let (($x2029 (or false $x489 (or $x2033))))
(let (($x2037 (or $x2029 false)))
(and (not $x2037) (or $x2037 (and (distinct ?x2036 ?x2036) true)))))))))))
(check-sat)
; query 98: function Calculation_of_the_LTP_parameters, block 551, name %555
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in536_64 () (_ BitVec 64))
(assert
 (let ((?x2016 ((_ sign_extend 16) in.01_16)))
(let ((?x2032 (bvsub (_ bv6 32) ?x2016)))
(let ((?x2036 ((_ zero_extend 32) ?x2032)))
(let ((?x2043 (bvashr in536_64 ?x2036)))
(let (($x2033 (and (distinct (bvsub ((_ sign_extend 1) (_ bv6 32)) ((_ sign_extend 1) ?x2016)) ((_ sign_extend 1) ?x2032)) true)))
(let (($x489 (or false false)))
(let (($x2029 (or false $x489 (or $x2033))))
(let (($x2037 (or $x2029 false)))
(let (($x2042 (or (or false $x2037 false) (bvuge ?x2036 (_ bv64 64)))))
(and (not $x2042) (or $x2042 (and (distinct ?x2043 ?x2043) true)))))))))))))
(check-sat)
; query 99: function Calculation_of_the_LTP_parameters, block 551, name %556
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in.06_16) ((_ sign_extend 16) in.06_16)) true))))))
(check-sat)
; query 100: function Calculation_of_the_LTP_parameters, block 551, name %557
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_16 () (_ BitVec 16))
(assert
 (let ((?x2046 (ite (bvsge (_ bv120 32) ((_ sign_extend 16) in.06_16)) (_ bv1 1) (_ bv0 1))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x39 (not $x309)))
(and $x39 (or $x309 (and (distinct ?x2046 ?x2046) true))))))))
(check-sat)
; query 101: function Calculation_of_the_LTP_parameters, block 558, name %559
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in.06_16) ((_ sign_extend 16) in.06_16)) true))))))
(check-sat)
; query 102: function Calculation_of_the_LTP_parameters, block 558, name %560
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_16 () (_ BitVec 16))
(assert
 (let ((?x2066 (ite (bvsle (_ bv40 32) ((_ sign_extend 16) in.06_16)) (_ bv1 1) (_ bv0 1))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x39 (not $x309)))
(and $x39 (or $x309 (and (distinct ?x2066 ?x2066) true))))))))
(check-sat)
; query 103: function Calculation_of_the_LTP_parameters, block 57, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in.0_16) ((_ sign_extend 16) in.0_16)) true))))))
(check-sat)
; query 104: function Calculation_of_the_LTP_parameters, block 57, name %59
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let ((?x183 ((_ sign_extend 16) in.0_16)))
(let ((?x2073 (bvsub (_ bv6 32) ?x183)))
(let (($x2068 (and (distinct (bvsub ((_ sign_extend 1) (_ bv6 32)) ((_ sign_extend 1) ?x183)) ((_ sign_extend 1) ?x2073)) true)))
(let (($x489 (or false false)))
(let (($x2076 (or false $x489 (or $x2068))))
(and (not $x2076) (or $x2076 (and (distinct ?x2073 ?x2073) true)))))))))
(check-sat)
; query 105: function Calculation_of_the_LTP_parameters, block 57, name %60
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let ((?x183 ((_ sign_extend 16) in.0_16)))
(let ((?x2073 (bvsub (_ bv6 32) ?x183)))
(let ((?x2080 ((_ extract 15 0) ?x2073)))
(let (($x2068 (and (distinct (bvsub ((_ sign_extend 1) (_ bv6 32)) ((_ sign_extend 1) ?x183)) ((_ sign_extend 1) ?x2073)) true)))
(let (($x489 (or false false)))
(let (($x2076 (or false $x489 (or $x2068))))
(let (($x2081 (or $x2076 false)))
(and (not $x2081) (or $x2081 (and (distinct ?x2080 ?x2080) true)))))))))))
(check-sat)
; query 106: function Calculation_of_the_LTP_parameters, block 584, name %585
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let (($x359 (and (distinct (bvadd ((_ sign_extend 1) in.2_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.2_32 (_ bv1 32)))) true)))
(let (($x356 (or false false (or $x359))))
(and (not $x356) (or $x356 (and (distinct (bvadd in.2_32 (_ bv1 32)) (bvadd in.2_32 (_ bv1 32))) true))))))
(check-sat)
; query 107: function Calculation_of_the_LTP_parameters, block 586, name %587
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.011_64 () (_ BitVec 64))
(assert
 (let (($x2083 (bvuge (_ bv1 64) (_ bv64 64))))
(let (($x616 (or false false false)))
(let (($x2088 (or $x616 $x2083)))
(let (($x766 (not $x2088)))
(and $x766 (or $x2088 (and (distinct (bvshl in.011_64 (_ bv1 64)) (bvshl in.011_64 (_ bv1 64))) true))))))))
(check-sat)
; query 108: function Calculation_of_the_LTP_parameters, block 586, name %588
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in555_64 () (_ BitVec 64))
(assert
 (let ((?x673 (ite (bvsge (_ bv0 64) in555_64) (_ bv1 1) (_ bv0 1))))
(let (($x616 (or false false false)))
(let (($x382 (not $x616)))
(and $x382 (or $x616 (and (distinct ?x673 ?x673) true)))))))
(check-sat)
; query 109: function Calculation_of_the_LTP_parameters, block 590, name %591
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in587_64 () (_ BitVec 64))
(declare-fun in555_64 () (_ BitVec 64))
(assert
 (let ((?x540 (ite (bvsge in555_64 in587_64) (_ bv1 1) (_ bv0 1))))
(let (($x616 (or false false false)))
(let (($x382 (not $x616)))
(and $x382 (or $x616 (and (distinct ?x540 ?x540) true)))))))
(check-sat)
; query 110: function Calculation_of_the_LTP_parameters, block 618, name %619
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.08_16 () (_ BitVec 16))
(assert
 (let (($x616 (or false false false)))
(let (($x382 (not $x616)))
(and $x382 (or $x616 (and (distinct (bvadd in.08_16 (_ bv1 16)) (bvadd in.08_16 (_ bv1 16))) true))))))
(check-sat)
; query 111: function Calculation_of_the_LTP_parameters, block 84, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.14_32 () (_ BitVec 32))
(assert
 (let (($x46 (and (distinct (bvadd ((_ sign_extend 1) in.14_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.14_32 (_ bv1 32)))) true)))
(let (($x20 (or false false (or $x46))))
(and (not $x20) (or $x20 (and (distinct (bvadd in.14_32 (_ bv1 32)) (bvadd in.14_32 (_ bv1 32))) true))))))
(check-sat)
; query 112: function Gsm_Decoder, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1502 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x1499 (or false false (or $x1502))))
(and (not $x1499) (or $x1499 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 113: function Gsm_Long_Term_Synthesis_Filtering, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 114: function Gsm_Long_Term_Synthesis_Filtering, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in19_16) ((_ sign_extend 16) in19_16)) true))))))
(check-sat)
; query 115: function Gsm_Long_Term_Synthesis_Filtering, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x1503 (ite (bvsge (_ bv120 32) ((_ sign_extend 16) in19_16)) (_ bv1 1) (_ bv0 1))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x39 (not $x309)))
(and $x39 (or $x309 (and (distinct ?x1503 ?x1503) true))))))))
(check-sat)
; query 116: function Gsm_Long_Term_Synthesis_Filtering, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1510 (ite (bvslt (_ bv120 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x39 (not $x309)))
(and $x39 (or $x309 (and (distinct ?x1510 ?x1510) true))))))))
(check-sat)
; query 117: function Gsm_Long_Term_Synthesis_Filtering, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 118: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 119: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1516 (ite (bvsgt (_ bv40 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x39 (not $x309)))
(and $x39 (or $x309 (and (distinct ?x1516 ?x1516) true))))))))
(check-sat)
; query 120: function Gsm_Preprocess, block 106, name %107
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in104_64 () (_ BitVec 64))
(assert
 (let ((?x1523 (bvadd in104_64 (_ bv16384 64))))
(let (($x1528 (and (distinct ?x1523 ?x1523) true)))
(let (($x1518 (and (distinct (bvadd ((_ sign_extend 1) in104_64) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x1523)) true)))
(let (($x1525 (or false false (or $x1518))))
(and (not $x1525) (or $x1525 $x1528)))))))
(check-sat)
; query 121: function Gsm_Preprocess, block 108, name %109
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in104_64 () (_ BitVec 64))
(assert
 (let ((?x1523 (bvadd in104_64 (_ bv16384 64))))
(let (($x1528 (and (distinct ?x1523 ?x1523) true)))
(let (($x616 (or false false false)))
(let (($x382 (not $x616)))
(and $x382 (or $x616 $x1528)))))))
(check-sat)
; query 122: function Gsm_Preprocess, block 108, name %110
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in104_64 () (_ BitVec 64))
(assert
 (let ((?x1532 (ite (bvuge (bvadd in104_64 (_ bv16384 64)) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x616 (or false false false)))
(let (($x671 (or $x616 false false)))
(let (($x1530 (not $x671)))
(and $x1530 (or $x671 (and (distinct ?x1532 ?x1532) true))))))))
(check-sat)
; query 123: function Gsm_Preprocess, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in19_16) ((_ sign_extend 16) in19_16)) true))))))
(check-sat)
; query 124: function Gsm_Preprocess, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x1545 (ite (bvsge (_ bv16380 32) ((_ sign_extend 16) in19_16)) (_ bv1 1) (_ bv0 1))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x39 (not $x309)))
(and $x39 (or $x309 (and (distinct ?x1545 ?x1545) true))))))))
(check-sat)
; query 125: function Gsm_Preprocess, block 30, name %33
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x1545 (ite (bvsge (_ bv16380 32) ((_ sign_extend 16) in19_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1553 (bvxor ?x1545 (_ bv1 1))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x1843 (or $x309 false false)))
(let (($x1857 (not $x1843)))
(and $x1857 (or $x1843 (and (distinct ?x1553 ?x1553) true))))))))))
(check-sat)
; query 126: function Gsm_Preprocess, block 30, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x1545 (ite (bvsge (_ bv16380 32) ((_ sign_extend 16) in19_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1553 (bvxor ?x1545 (_ bv1 1))))
(let ((?x1548 ((_ zero_extend 31) ?x1553)))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x1843 (or $x309 false false)))
(let (($x1846 (or $x1843 false)))
(let (($x1862 (not $x1846)))
(and $x1862 (or $x1846 (and (distinct ?x1548 ?x1548) true))))))))))))
(check-sat)
; query 127: function Gsm_Preprocess, block 30, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x1545 (ite (bvsge (_ bv16380 32) ((_ sign_extend 16) in19_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1553 (bvxor ?x1545 (_ bv1 1))))
(let ((?x1548 ((_ zero_extend 31) ?x1553)))
(let ((?x1556 ((_ sign_extend 32) ?x1548)))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x1843 (or $x309 false false)))
(let (($x1846 (or $x1843 false)))
(let (($x1854 (or $x1846 false)))
(let (($x1866 (not $x1854)))
(and $x1866 (or $x1854 (and (distinct ?x1556 ?x1556) true))))))))))))))
(check-sat)
; query 128: function Gsm_Preprocess, block 30, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x1545 (ite (bvsge (_ bv16380 32) ((_ sign_extend 16) in19_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1553 (bvxor ?x1545 (_ bv1 1))))
(let ((?x1548 ((_ zero_extend 31) ?x1553)))
(let ((?x1556 ((_ sign_extend 32) ?x1548)))
(let ((?x1541 (ite (and (distinct (_ bv0 64) ?x1556) true) (_ bv1 1) (_ bv0 1))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x1843 (or $x309 false false)))
(let (($x1846 (or $x1843 false)))
(let (($x1854 (or $x1846 false)))
(let (($x1852 (or $x1854 false false)))
(let (($x753 (not $x1852)))
(and $x753 (or $x1852 (and (distinct ?x1541 ?x1541) true))))))))))))))))
(check-sat)
; query 129: function Gsm_Preprocess, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in19_16) ((_ sign_extend 16) in19_16)) true))))))
(check-sat)
; query 130: function Gsm_Preprocess, block 40, name %42
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in.03_16) ((_ sign_extend 16) in.03_16)) true))))))
(check-sat)
; query 131: function Gsm_Preprocess, block 40, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_16 () (_ BitVec 16))
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x1564 ((_ sign_extend 16) in.03_16)))
(let ((?x1495 ((_ sign_extend 16) in19_16)))
(let ((?x1565 (bvsub ?x1495 ?x1564)))
(let (($x1566 (and (distinct (bvsub ((_ sign_extend 1) ?x1495) ((_ sign_extend 1) ?x1564)) ((_ sign_extend 1) ?x1565)) true)))
(let (($x489 (or false false)))
(let (($x1563 (or $x489 $x489 (or $x1566))))
(and (not $x1563) (or $x1563 (and (distinct ?x1565 ?x1565) true))))))))))
(check-sat)
; query 132: function Gsm_Preprocess, block 40, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_16 () (_ BitVec 16))
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x1564 ((_ sign_extend 16) in.03_16)))
(let ((?x1495 ((_ sign_extend 16) in19_16)))
(let ((?x1565 (bvsub ?x1495 ?x1564)))
(let ((?x1569 ((_ extract 15 0) ?x1565)))
(let (($x1566 (and (distinct (bvsub ((_ sign_extend 1) ?x1495) ((_ sign_extend 1) ?x1564)) ((_ sign_extend 1) ?x1565)) true)))
(let (($x489 (or false false)))
(let (($x1563 (or $x489 $x489 (or $x1566))))
(let (($x1571 (or $x1563 false)))
(and (not $x1571) (or $x1571 (and (distinct ?x1569 ?x1569) true))))))))))))
(check-sat)
; query 133: function Gsm_Preprocess, block 40, name %45
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_16 () (_ BitVec 16))
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x1564 ((_ sign_extend 16) in.03_16)))
(let ((?x1495 ((_ sign_extend 16) in19_16)))
(let ((?x1565 (bvsub ?x1495 ?x1564)))
(let ((?x1569 ((_ extract 15 0) ?x1565)))
(let ((?x1572 ((_ sign_extend 16) ?x1569)))
(let (($x1566 (and (distinct (bvsub ((_ sign_extend 1) ?x1495) ((_ sign_extend 1) ?x1564)) ((_ sign_extend 1) ?x1565)) true)))
(let (($x489 (or false false)))
(let (($x1563 (or $x489 $x489 (or $x1566))))
(let (($x1571 (or $x1563 false)))
(let (($x1575 (or $x1571 false)))
(and (not $x1575) (or $x1575 (and (distinct ?x1572 ?x1572) true))))))))))))))
(check-sat)
; query 134: function Gsm_Preprocess, block 40, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_16 () (_ BitVec 16))
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x1564 ((_ sign_extend 16) in.03_16)))
(let ((?x1495 ((_ sign_extend 16) in19_16)))
(let ((?x1565 (bvsub ?x1495 ?x1564)))
(let ((?x1569 ((_ extract 15 0) ?x1565)))
(let ((?x1572 ((_ sign_extend 16) ?x1569)))
(let ((?x1579 (ite (and (distinct (_ bv4294934528 32) ?x1572) true) (_ bv1 1) (_ bv0 1))))
(let (($x1566 (and (distinct (bvsub ((_ sign_extend 1) ?x1495) ((_ sign_extend 1) ?x1564)) ((_ sign_extend 1) ?x1565)) true)))
(let (($x489 (or false false)))
(let (($x1563 (or $x489 $x489 (or $x1566))))
(let (($x1571 (or $x1563 false)))
(let (($x1575 (or $x1571 false)))
(let (($x1578 (or $x1575 false false)))
(and (not $x1578) (or $x1578 (and (distinct ?x1579 ?x1579) true))))))))))))))))
(check-sat)
; query 135: function Gsm_Preprocess, block 40, name %47
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_16 () (_ BitVec 16))
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x1564 ((_ sign_extend 16) in.03_16)))
(let ((?x1495 ((_ sign_extend 16) in19_16)))
(let ((?x1565 (bvsub ?x1495 ?x1564)))
(let ((?x1569 ((_ extract 15 0) ?x1565)))
(let ((?x1572 ((_ sign_extend 16) ?x1569)))
(let ((?x1579 (ite (and (distinct (_ bv4294934528 32) ?x1572) true) (_ bv1 1) (_ bv0 1))))
(let ((?x1576 (bvxor ?x1579 (_ bv1 1))))
(let (($x1566 (and (distinct (bvsub ((_ sign_extend 1) ?x1495) ((_ sign_extend 1) ?x1564)) ((_ sign_extend 1) ?x1565)) true)))
(let (($x489 (or false false)))
(let (($x1563 (or $x489 $x489 (or $x1566))))
(let (($x1571 (or $x1563 false)))
(let (($x1575 (or $x1571 false)))
(let (($x1578 (or $x1575 false false)))
(let (($x665 (or $x1578 false false)))
(and (not $x665) (or $x665 (and (distinct ?x1576 ?x1576) true))))))))))))))))))
(check-sat)
; query 136: function Gsm_Preprocess, block 40, name %48
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_16 () (_ BitVec 16))
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x1564 ((_ sign_extend 16) in.03_16)))
(let ((?x1495 ((_ sign_extend 16) in19_16)))
(let ((?x1565 (bvsub ?x1495 ?x1564)))
(let ((?x1569 ((_ extract 15 0) ?x1565)))
(let ((?x1572 ((_ sign_extend 16) ?x1569)))
(let ((?x1579 (ite (and (distinct (_ bv4294934528 32) ?x1572) true) (_ bv1 1) (_ bv0 1))))
(let ((?x1576 (bvxor ?x1579 (_ bv1 1))))
(let ((?x1577 ((_ zero_extend 31) ?x1576)))
(let (($x1566 (and (distinct (bvsub ((_ sign_extend 1) ?x1495) ((_ sign_extend 1) ?x1564)) ((_ sign_extend 1) ?x1565)) true)))
(let (($x489 (or false false)))
(let (($x1563 (or $x489 $x489 (or $x1566))))
(let (($x1571 (or $x1563 false)))
(let (($x1575 (or $x1571 false)))
(let (($x1578 (or $x1575 false false)))
(let (($x665 (or $x1578 false false)))
(let (($x1573 (or $x665 false)))
(and (not $x1573) (or $x1573 (and (distinct ?x1577 ?x1577) true))))))))))))))))))))
(check-sat)
; query 137: function Gsm_Preprocess, block 40, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_16 () (_ BitVec 16))
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x1564 ((_ sign_extend 16) in.03_16)))
(let ((?x1495 ((_ sign_extend 16) in19_16)))
(let ((?x1565 (bvsub ?x1495 ?x1564)))
(let ((?x1569 ((_ extract 15 0) ?x1565)))
(let ((?x1572 ((_ sign_extend 16) ?x1569)))
(let ((?x1579 (ite (and (distinct (_ bv4294934528 32) ?x1572) true) (_ bv1 1) (_ bv0 1))))
(let ((?x1576 (bvxor ?x1579 (_ bv1 1))))
(let ((?x1577 ((_ zero_extend 31) ?x1576)))
(let ((?x1574 ((_ sign_extend 32) ?x1577)))
(let (($x1566 (and (distinct (bvsub ((_ sign_extend 1) ?x1495) ((_ sign_extend 1) ?x1564)) ((_ sign_extend 1) ?x1565)) true)))
(let (($x489 (or false false)))
(let (($x1563 (or $x489 $x489 (or $x1566))))
(let (($x1571 (or $x1563 false)))
(let (($x1575 (or $x1571 false)))
(let (($x1578 (or $x1575 false false)))
(let (($x665 (or $x1578 false false)))
(let (($x1573 (or $x665 false)))
(let (($x1580 (or $x1573 false)))
(and (not $x1580) (or $x1580 (and (distinct ?x1574 ?x1574) true))))))))))))))))))))))
(check-sat)
; query 138: function Gsm_Preprocess, block 40, name %50
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_16 () (_ BitVec 16))
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x1564 ((_ sign_extend 16) in.03_16)))
(let ((?x1495 ((_ sign_extend 16) in19_16)))
(let ((?x1565 (bvsub ?x1495 ?x1564)))
(let ((?x1569 ((_ extract 15 0) ?x1565)))
(let ((?x1572 ((_ sign_extend 16) ?x1569)))
(let ((?x1579 (ite (and (distinct (_ bv4294934528 32) ?x1572) true) (_ bv1 1) (_ bv0 1))))
(let ((?x1576 (bvxor ?x1579 (_ bv1 1))))
(let ((?x1577 ((_ zero_extend 31) ?x1576)))
(let ((?x1574 ((_ sign_extend 32) ?x1577)))
(let ((?x1586 (ite (and (distinct (_ bv0 64) ?x1574) true) (_ bv1 1) (_ bv0 1))))
(let (($x1566 (and (distinct (bvsub ((_ sign_extend 1) ?x1495) ((_ sign_extend 1) ?x1564)) ((_ sign_extend 1) ?x1565)) true)))
(let (($x489 (or false false)))
(let (($x1563 (or $x489 $x489 (or $x1566))))
(let (($x1571 (or $x1563 false)))
(let (($x1575 (or $x1571 false)))
(let (($x1578 (or $x1575 false false)))
(let (($x665 (or $x1578 false false)))
(let (($x1573 (or $x665 false)))
(let (($x1580 (or $x1573 false)))
(let (($x1583 (or $x1580 false false)))
(and (not $x1583) (or $x1583 (and (distinct ?x1586 ?x1586) true))))))))))))))))))))))))
(check-sat)
; query 139: function Gsm_Preprocess, block 54, name %55
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in44_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 48) in44_16) ((_ sign_extend 48) in44_16)) true))))))
(check-sat)
; query 140: function Gsm_Preprocess, block 54, name %56
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in44_16 () (_ BitVec 16))
(assert
 (let ((?x1614 ((_ sign_extend 48) in44_16)))
(let ((?x1623 (bvshl ?x1614 (_ bv15 64))))
(let (($x509 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x1622 (or $x309 $x509)))
(and (not $x1622) (or $x1622 (and (distinct ?x1623 ?x1623) true))))))))))
(check-sat)
; query 141: function Gsm_Preprocess, block 54, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_64 () (_ BitVec 64))
(assert
 (let (($x509 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x616 (or false false false)))
(let (($x1620 (or $x616 $x509)))
(and (not $x1620) (or $x1620 (and (distinct (bvashr in.04_64 (_ bv15 64)) (bvashr in.04_64 (_ bv15 64))) true)))))))
(check-sat)
; query 142: function Gsm_Preprocess, block 54, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_64 () (_ BitVec 64))
(assert
 (let ((?x1621 (bvashr in.04_64 (_ bv15 64))))
(let ((?x1617 ((_ extract 15 0) ?x1621)))
(let (($x509 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x616 (or false false false)))
(let (($x1620 (or $x616 $x509)))
(let (($x1618 (or $x1620 false)))
(and (not $x1618) (or $x1618 (and (distinct ?x1617 ?x1617) true))))))))))
(check-sat)
; query 143: function Gsm_Preprocess, block 54, name %59
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_64 () (_ BitVec 64))
(assert
 (let ((?x1621 (bvashr in.04_64 (_ bv15 64))))
(let ((?x1617 ((_ extract 15 0) ?x1621)))
(let ((?x1624 ((_ sign_extend 48) ?x1617)))
(let (($x509 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x616 (or false false false)))
(let (($x1620 (or $x616 $x509)))
(let (($x1618 (or $x1620 false)))
(let (($x1626 (or $x1618 false)))
(and (not $x1626) (or $x1626 (and (distinct ?x1624 ?x1624) true))))))))))))
(check-sat)
; query 144: function Gsm_Preprocess, block 54, name %60
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_64 () (_ BitVec 64))
(assert
 (let ((?x1621 (bvashr in.04_64 (_ bv15 64))))
(let ((?x1617 ((_ extract 15 0) ?x1621)))
(let ((?x1624 ((_ sign_extend 48) ?x1617)))
(let ((?x1625 (bvshl ?x1624 (_ bv15 64))))
(let (($x509 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x616 (or false false false)))
(let (($x1620 (or $x616 $x509)))
(let (($x1618 (or $x1620 false)))
(let (($x1626 (or $x1618 false)))
(let (($x1627 (or (or $x1626 false false) $x509)))
(and (not $x1627) (or $x1627 (and (distinct ?x1625 ?x1625) true))))))))))))))
(check-sat)
; query 145: function Gsm_Preprocess, block 54, name %61
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_64 () (_ BitVec 64))
(assert
 (let ((?x1621 (bvashr in.04_64 (_ bv15 64))))
(let ((?x1617 ((_ extract 15 0) ?x1621)))
(let ((?x1624 ((_ sign_extend 48) ?x1617)))
(let ((?x1625 (bvshl ?x1624 (_ bv15 64))))
(let ((?x1632 (bvsub in.04_64 ?x1625)))
(let (($x1628 (and (distinct (bvsub ((_ sign_extend 1) in.04_64) ((_ sign_extend 1) ?x1625)) ((_ sign_extend 1) ?x1632)) true)))
(let (($x509 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x616 (or false false false)))
(let (($x1620 (or $x616 $x509)))
(let (($x1618 (or $x1620 false)))
(let (($x1626 (or $x1618 false)))
(let (($x1627 (or (or $x1626 false false) $x509)))
(let (($x1635 (or false $x1627 (or $x1628))))
(and (not $x1635) (or $x1635 (and (distinct ?x1632 ?x1632) true)))))))))))))))))
(check-sat)
; query 146: function Gsm_Preprocess, block 54, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_64 () (_ BitVec 64))
(assert
 (let ((?x1621 (bvashr in.04_64 (_ bv15 64))))
(let ((?x1617 ((_ extract 15 0) ?x1621)))
(let ((?x1624 ((_ sign_extend 48) ?x1617)))
(let ((?x1625 (bvshl ?x1624 (_ bv15 64))))
(let ((?x1632 (bvsub in.04_64 ?x1625)))
(let ((?x1637 ((_ extract 15 0) ?x1632)))
(let (($x1628 (and (distinct (bvsub ((_ sign_extend 1) in.04_64) ((_ sign_extend 1) ?x1625)) ((_ sign_extend 1) ?x1632)) true)))
(let (($x509 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x616 (or false false false)))
(let (($x1620 (or $x616 $x509)))
(let (($x1618 (or $x1620 false)))
(let (($x1626 (or $x1618 false)))
(let (($x1627 (or (or $x1626 false false) $x509)))
(let (($x1635 (or false $x1627 (or $x1628))))
(let (($x1638 (or $x1635 false)))
(and (not $x1638) (or $x1638 (and (distinct ?x1637 ?x1637) true)))))))))))))))))))
(check-sat)
; query 147: function Gsm_Preprocess, block 54, name %63
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_64 () (_ BitVec 64))
(assert
 (let ((?x1621 (bvashr in.04_64 (_ bv15 64))))
(let ((?x1617 ((_ extract 15 0) ?x1621)))
(let ((?x1624 ((_ sign_extend 48) ?x1617)))
(let ((?x1625 (bvshl ?x1624 (_ bv15 64))))
(let ((?x1632 (bvsub in.04_64 ?x1625)))
(let ((?x1637 ((_ extract 15 0) ?x1632)))
(let ((?x1641 ((_ sign_extend 48) ?x1637)))
(let (($x1628 (and (distinct (bvsub ((_ sign_extend 1) in.04_64) ((_ sign_extend 1) ?x1625)) ((_ sign_extend 1) ?x1632)) true)))
(let (($x509 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x616 (or false false false)))
(let (($x1620 (or $x616 $x509)))
(let (($x1618 (or $x1620 false)))
(let (($x1626 (or $x1618 false)))
(let (($x1627 (or (or $x1626 false false) $x509)))
(let (($x1635 (or false $x1627 (or $x1628))))
(let (($x1638 (or $x1635 false)))
(let (($x1636 (or $x1638 false)))
(and (not $x1636) (or $x1636 (and (distinct ?x1641 ?x1641) true)))))))))))))))))))))
(check-sat)
; query 148: function Gsm_Preprocess, block 54, name %64
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_64 () (_ BitVec 64))
(assert
 (let ((?x1621 (bvashr in.04_64 (_ bv15 64))))
(let ((?x1617 ((_ extract 15 0) ?x1621)))
(let ((?x1624 ((_ sign_extend 48) ?x1617)))
(let ((?x1625 (bvshl ?x1624 (_ bv15 64))))
(let ((?x1632 (bvsub in.04_64 ?x1625)))
(let ((?x1637 ((_ extract 15 0) ?x1632)))
(let ((?x1641 ((_ sign_extend 48) ?x1637)))
(let ((?x1640 (bvmul ?x1641 (_ bv32735 64))))
(let (($x1643 (and (distinct (bvmul ((_ sign_extend 64) ?x1641) ((_ sign_extend 64) (_ bv32735 64))) ((_ sign_extend 64) ?x1640)) true)))
(let (($x1628 (and (distinct (bvsub ((_ sign_extend 1) in.04_64) ((_ sign_extend 1) ?x1625)) ((_ sign_extend 1) ?x1632)) true)))
(let (($x509 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x616 (or false false false)))
(let (($x1620 (or $x616 $x509)))
(let (($x1618 (or $x1620 false)))
(let (($x1626 (or $x1618 false)))
(let (($x1627 (or (or $x1626 false false) $x509)))
(let (($x1635 (or false $x1627 (or $x1628))))
(let (($x1638 (or $x1635 false)))
(let (($x1636 (or $x1638 false)))
(let (($x1648 (or $x1636 false (or $x1643))))
(and (not $x1648) (or $x1648 (and (distinct ?x1640 ?x1640) true))))))))))))))))))))))))
(check-sat)
; query 149: function Gsm_Preprocess, block 54, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_64 () (_ BitVec 64))
(assert
 (let ((?x1621 (bvashr in.04_64 (_ bv15 64))))
(let ((?x1617 ((_ extract 15 0) ?x1621)))
(let ((?x1624 ((_ sign_extend 48) ?x1617)))
(let ((?x1625 (bvshl ?x1624 (_ bv15 64))))
(let ((?x1632 (bvsub in.04_64 ?x1625)))
(let ((?x1637 ((_ extract 15 0) ?x1632)))
(let ((?x1641 ((_ sign_extend 48) ?x1637)))
(let ((?x1640 (bvmul ?x1641 (_ bv32735 64))))
(let ((?x1647 (bvadd ?x1640 (_ bv16384 64))))
(let (($x1656 (and (distinct (bvadd ((_ sign_extend 1) ?x1640) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x1647)) true)))
(let (($x1643 (and (distinct (bvmul ((_ sign_extend 64) ?x1641) ((_ sign_extend 64) (_ bv32735 64))) ((_ sign_extend 64) ?x1640)) true)))
(let (($x1628 (and (distinct (bvsub ((_ sign_extend 1) in.04_64) ((_ sign_extend 1) ?x1625)) ((_ sign_extend 1) ?x1632)) true)))
(let (($x509 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x616 (or false false false)))
(let (($x1620 (or $x616 $x509)))
(let (($x1618 (or $x1620 false)))
(let (($x1626 (or $x1618 false)))
(let (($x1627 (or (or $x1626 false false) $x509)))
(let (($x1635 (or false $x1627 (or $x1628))))
(let (($x1638 (or $x1635 false)))
(let (($x1636 (or $x1638 false)))
(let (($x1648 (or $x1636 false (or $x1643))))
(let (($x1653 (or $x1648 false (or $x1656))))
(and (not $x1653) (or $x1653 (and (distinct ?x1647 ?x1647) true)))))))))))))))))))))))))))
(check-sat)
; query 150: function Gsm_Preprocess, block 54, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_64 () (_ BitVec 64))
(assert
 (let ((?x1621 (bvashr in.04_64 (_ bv15 64))))
(let ((?x1617 ((_ extract 15 0) ?x1621)))
(let ((?x1624 ((_ sign_extend 48) ?x1617)))
(let ((?x1625 (bvshl ?x1624 (_ bv15 64))))
(let ((?x1632 (bvsub in.04_64 ?x1625)))
(let ((?x1637 ((_ extract 15 0) ?x1632)))
(let ((?x1641 ((_ sign_extend 48) ?x1637)))
(let ((?x1640 (bvmul ?x1641 (_ bv32735 64))))
(let ((?x1647 (bvadd ?x1640 (_ bv16384 64))))
(let ((?x1651 (bvashr ?x1647 (_ bv15 64))))
(let (($x509 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1656 (and (distinct (bvadd ((_ sign_extend 1) ?x1640) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x1647)) true)))
(let (($x1643 (and (distinct (bvmul ((_ sign_extend 64) ?x1641) ((_ sign_extend 64) (_ bv32735 64))) ((_ sign_extend 64) ?x1640)) true)))
(let (($x1628 (and (distinct (bvsub ((_ sign_extend 1) in.04_64) ((_ sign_extend 1) ?x1625)) ((_ sign_extend 1) ?x1632)) true)))
(let (($x616 (or false false false)))
(let (($x1620 (or $x616 $x509)))
(let (($x1618 (or $x1620 false)))
(let (($x1626 (or $x1618 false)))
(let (($x1627 (or (or $x1626 false false) $x509)))
(let (($x1635 (or false $x1627 (or $x1628))))
(let (($x1638 (or $x1635 false)))
(let (($x1636 (or $x1638 false)))
(let (($x1648 (or $x1636 false (or $x1643))))
(let (($x1653 (or $x1648 false (or $x1656))))
(let (($x1650 (or (or $x1653 false false) $x509)))
(and (not $x1650) (or $x1650 (and (distinct ?x1651 ?x1651) true)))))))))))))))))))))))))))))
(check-sat)
; query 151: function Gsm_Preprocess, block 54, name %67
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_64 () (_ BitVec 64))
(declare-fun in44_16 () (_ BitVec 16))
(assert
 (let ((?x1621 (bvashr in.04_64 (_ bv15 64))))
(let ((?x1617 ((_ extract 15 0) ?x1621)))
(let ((?x1624 ((_ sign_extend 48) ?x1617)))
(let ((?x1625 (bvshl ?x1624 (_ bv15 64))))
(let ((?x1632 (bvsub in.04_64 ?x1625)))
(let ((?x1637 ((_ extract 15 0) ?x1632)))
(let ((?x1641 ((_ sign_extend 48) ?x1637)))
(let ((?x1640 (bvmul ?x1641 (_ bv32735 64))))
(let ((?x1647 (bvadd ?x1640 (_ bv16384 64))))
(let ((?x1651 (bvashr ?x1647 (_ bv15 64))))
(let ((?x1614 ((_ sign_extend 48) in44_16)))
(let ((?x1623 (bvshl ?x1614 (_ bv15 64))))
(let ((?x1663 (bvadd ?x1623 ?x1651)))
(let (($x1666 (and (distinct (bvadd ((_ sign_extend 1) ?x1623) ((_ sign_extend 1) ?x1651)) ((_ sign_extend 1) ?x1663)) true)))
(let (($x509 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1656 (and (distinct (bvadd ((_ sign_extend 1) ?x1640) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x1647)) true)))
(let (($x1643 (and (distinct (bvmul ((_ sign_extend 64) ?x1641) ((_ sign_extend 64) (_ bv32735 64))) ((_ sign_extend 64) ?x1640)) true)))
(let (($x1628 (and (distinct (bvsub ((_ sign_extend 1) in.04_64) ((_ sign_extend 1) ?x1625)) ((_ sign_extend 1) ?x1632)) true)))
(let (($x616 (or false false false)))
(let (($x1620 (or $x616 $x509)))
(let (($x1618 (or $x1620 false)))
(let (($x1626 (or $x1618 false)))
(let (($x1627 (or (or $x1626 false false) $x509)))
(let (($x1635 (or false $x1627 (or $x1628))))
(let (($x1638 (or $x1635 false)))
(let (($x1636 (or $x1638 false)))
(let (($x1648 (or $x1636 false (or $x1643))))
(let (($x1653 (or $x1648 false (or $x1656))))
(let (($x1650 (or (or $x1653 false false) $x509)))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x1622 (or $x309 $x509)))
(let (($x1028 (or $x1622 $x1650 (or $x1666))))
(and (not $x1028) (or $x1028 (and (distinct ?x1663 ?x1663) true)))))))))))))))))))))))))))))))))))))
(check-sat)
; query 152: function Gsm_Preprocess, block 54, name %68
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_64 () (_ BitVec 64))
(assert
 (let ((?x1621 (bvashr in.04_64 (_ bv15 64))))
(let ((?x1617 ((_ extract 15 0) ?x1621)))
(let ((?x1624 ((_ sign_extend 48) ?x1617)))
(let (($x509 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x616 (or false false false)))
(let (($x1620 (or $x616 $x509)))
(let (($x1618 (or $x1620 false)))
(let (($x1626 (or $x1618 false)))
(and (not $x1626) (or $x1626 (and (distinct ?x1624 ?x1624) true))))))))))))
(check-sat)
; query 153: function Gsm_Preprocess, block 54, name %69
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_64 () (_ BitVec 64))
(assert
 (let ((?x1621 (bvashr in.04_64 (_ bv15 64))))
(let ((?x1617 ((_ extract 15 0) ?x1621)))
(let ((?x1624 ((_ sign_extend 48) ?x1617)))
(let ((?x1668 (bvmul ?x1624 (_ bv32735 64))))
(let (($x1661 (and (distinct (bvmul ((_ sign_extend 64) ?x1624) ((_ sign_extend 64) (_ bv32735 64))) ((_ sign_extend 64) ?x1668)) true)))
(let (($x509 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x616 (or false false false)))
(let (($x1620 (or $x616 $x509)))
(let (($x1618 (or $x1620 false)))
(let (($x1626 (or $x1618 false)))
(let (($x1671 (or $x1626 false (or $x1661))))
(and (not $x1671) (or $x1671 (and (distinct ?x1668 ?x1668) true)))))))))))))))
(check-sat)
; query 154: function Gsm_Preprocess, block 54, name %70
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_64 () (_ BitVec 64))
(assert
 (let ((?x1621 (bvashr in.04_64 (_ bv15 64))))
(let ((?x1617 ((_ extract 15 0) ?x1621)))
(let ((?x1624 ((_ sign_extend 48) ?x1617)))
(let ((?x1668 (bvmul ?x1624 (_ bv32735 64))))
(let ((?x1677 (ite (bvsgt (_ bv0 64) ?x1668) (_ bv1 1) (_ bv0 1))))
(let (($x1661 (and (distinct (bvmul ((_ sign_extend 64) ?x1624) ((_ sign_extend 64) (_ bv32735 64))) ((_ sign_extend 64) ?x1668)) true)))
(let (($x509 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x616 (or false false false)))
(let (($x1620 (or $x616 $x509)))
(let (($x1618 (or $x1620 false)))
(let (($x1626 (or $x1618 false)))
(let (($x1671 (or $x1626 false (or $x1661))))
(let (($x1669 (or $x1671 false false)))
(and (not $x1669) (or $x1669 (and (distinct ?x1677 ?x1677) true)))))))))))))))))
(check-sat)
; query 155: function Gsm_Preprocess, block 71, name %72
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in67_64 () (_ BitVec 64))
(assert
 (let ((?x1025 (ite (bvsle (_ bv0 64) in67_64) (_ bv1 1) (_ bv0 1))))
(let (($x616 (or false false false)))
(let (($x382 (not $x616)))
(and $x382 (or $x616 (and (distinct ?x1025 ?x1025) true)))))))
(check-sat)
; query 156: function Gsm_Preprocess, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in67_64 () (_ BitVec 64))
(declare-fun in69_64 () (_ BitVec 64))
(assert
 (let ((?x1740 (bvadd in69_64 in67_64)))
(let (($x1742 (and (distinct ?x1740 ?x1740) true)))
(let (($x1743 (and (distinct (bvadd ((_ sign_extend 1) in69_64) ((_ sign_extend 1) in67_64)) ((_ sign_extend 1) ?x1740)) true)))
(let (($x1047 (or false false (or $x1743))))
(and (not $x1047) (or $x1047 $x1742)))))))
(check-sat)
; query 157: function Gsm_Preprocess, block 75, name %76
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in69_64 () (_ BitVec 64))
(assert
 (let ((?x1748 (bvadd in69_64 (_ bv1 64))))
(let ((?x1751 ((_ sign_extend 1) ?x1748)))
(let (($x1755 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in69_64) ((_ sign_extend 1) (_ bv1 64))) ?x1751) true)))))
(and (not $x1755) (or $x1755 (and (distinct ?x1748 ?x1748) true)))))))
(check-sat)
; query 158: function Gsm_Preprocess, block 75, name %77
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in69_64 () (_ BitVec 64))
(assert
 (let ((?x1748 (bvadd in69_64 (_ bv1 64))))
(let ((?x1749 (bvsub (_ bv0 64) ?x1748)))
(let (($x1750 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1748)) ((_ sign_extend 1) ?x1749)) true)))
(let ((?x1751 ((_ sign_extend 1) ?x1748)))
(let (($x1755 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in69_64) ((_ sign_extend 1) (_ bv1 64))) ?x1751) true)))))
(let (($x1758 (or false $x1755 (or $x1750))))
(and (not $x1758) (or $x1758 (and (distinct ?x1749 ?x1749) true))))))))))
(check-sat)
; query 159: function Gsm_Preprocess, block 75, name %78
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in67_64 () (_ BitVec 64))
(assert
 (let ((?x1762 (bvadd in67_64 (_ bv1 64))))
(let ((?x1757 ((_ sign_extend 1) ?x1762)))
(let (($x996 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in67_64) ((_ sign_extend 1) (_ bv1 64))) ?x1757) true)))))
(and (not $x996) (or $x996 (and (distinct ?x1762 ?x1762) true)))))))
(check-sat)
; query 160: function Gsm_Preprocess, block 75, name %79
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in67_64 () (_ BitVec 64))
(assert
 (let ((?x1762 (bvadd in67_64 (_ bv1 64))))
(let ((?x1760 (bvsub (_ bv0 64) ?x1762)))
(let (($x1761 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1762)) ((_ sign_extend 1) ?x1760)) true)))
(let ((?x1757 ((_ sign_extend 1) ?x1762)))
(let (($x996 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in67_64) ((_ sign_extend 1) (_ bv1 64))) ?x1757) true)))))
(let (($x1769 (or false $x996 (or $x1761))))
(and (not $x1769) (or $x1769 (and (distinct ?x1760 ?x1760) true))))))))))
(check-sat)
; query 161: function Gsm_Preprocess, block 75, name %80
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in67_64 () (_ BitVec 64))
(declare-fun in69_64 () (_ BitVec 64))
(assert
 (let ((?x1762 (bvadd in67_64 (_ bv1 64))))
(let ((?x1760 (bvsub (_ bv0 64) ?x1762)))
(let ((?x1748 (bvadd in69_64 (_ bv1 64))))
(let ((?x1749 (bvsub (_ bv0 64) ?x1748)))
(let ((?x1773 (bvadd ?x1749 ?x1760)))
(let (($x1761 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1762)) ((_ sign_extend 1) ?x1760)) true)))
(let ((?x1757 ((_ sign_extend 1) ?x1762)))
(let (($x996 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in67_64) ((_ sign_extend 1) (_ bv1 64))) ?x1757) true)))))
(let (($x1769 (or false $x996 (or $x1761))))
(let (($x1750 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1748)) ((_ sign_extend 1) ?x1749)) true)))
(let ((?x1751 ((_ sign_extend 1) ?x1748)))
(let (($x1755 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in69_64) ((_ sign_extend 1) (_ bv1 64))) ?x1751) true)))))
(let (($x1758 (or false $x1755 (or $x1750))))
(let (($x1770 (or $x1758 $x1769 false)))
(and (not $x1770) (or $x1770 (and (distinct ?x1773 ?x1773) true))))))))))))))))))
(check-sat)
; query 162: function Gsm_Preprocess, block 75, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in67_64 () (_ BitVec 64))
(declare-fun in69_64 () (_ BitVec 64))
(assert
 (let ((?x1762 (bvadd in67_64 (_ bv1 64))))
(let ((?x1760 (bvsub (_ bv0 64) ?x1762)))
(let ((?x1748 (bvadd in69_64 (_ bv1 64))))
(let ((?x1749 (bvsub (_ bv0 64) ?x1748)))
(let ((?x1773 (bvadd ?x1749 ?x1760)))
(let ((?x1777 (ite (bvuge ?x1773 (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x1761 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1762)) ((_ sign_extend 1) ?x1760)) true)))
(let ((?x1757 ((_ sign_extend 1) ?x1762)))
(let (($x996 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in67_64) ((_ sign_extend 1) (_ bv1 64))) ?x1757) true)))))
(let (($x1769 (or false $x996 (or $x1761))))
(let (($x1750 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1748)) ((_ sign_extend 1) ?x1749)) true)))
(let ((?x1751 ((_ sign_extend 1) ?x1748)))
(let (($x1755 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in69_64) ((_ sign_extend 1) (_ bv1 64))) ?x1751) true)))))
(let (($x1758 (or false $x1755 (or $x1750))))
(let (($x1770 (or $x1758 $x1769 false)))
(let (($x1776 (or $x1770 false false)))
(and (not $x1776) (or $x1776 (and (distinct ?x1777 ?x1777) true))))))))))))))))))))
(check-sat)
; query 163: function Gsm_Preprocess, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in80_64 () (_ BitVec 64))
(assert
 (let ((?x1310 (bvsub (_ bv0 64) in80_64)))
(let ((?x1300 ((_ sign_extend 1) ?x1310)))
(let (($x1282 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in80_64)) ?x1300) true)))))
(and (not $x1282) (or $x1282 (and (distinct ?x1310 ?x1310) true)))))))
(check-sat)
; query 164: function Gsm_Preprocess, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in80_64 () (_ BitVec 64))
(assert
 (let ((?x1310 (bvsub (_ bv0 64) in80_64)))
(let ((?x1270 (bvsub ?x1310 (_ bv2 64))))
(let (($x1272 (and (distinct (bvsub ((_ sign_extend 1) ?x1310) ((_ sign_extend 1) (_ bv2 64))) ((_ sign_extend 1) ?x1270)) true)))
(let ((?x1300 ((_ sign_extend 1) ?x1310)))
(let (($x1282 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in80_64)) ?x1300) true)))))
(let (($x1242 (or $x1282 false (or $x1272))))
(and (not $x1242) (or $x1242 (and (distinct ?x1270 ?x1270) true))))))))))
(check-sat)
; query 165: function Gsm_Preprocess, block 90, name %91
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in67_64 () (_ BitVec 64))
(assert
 (let ((?x1172 (ite (bvsge (_ bv0 64) in67_64) (_ bv1 1) (_ bv0 1))))
(let (($x616 (or false false false)))
(let (($x382 (not $x616)))
(and $x382 (or $x616 (and (distinct ?x1172 ?x1172) true)))))))
(check-sat)
; query 166: function Gsm_Preprocess, block 92, name %93
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in67_64 () (_ BitVec 64))
(declare-fun in69_64 () (_ BitVec 64))
(assert
 (let ((?x1740 (bvadd in69_64 in67_64)))
(let (($x1742 (and (distinct ?x1740 ?x1740) true)))
(let (($x1743 (and (distinct (bvadd ((_ sign_extend 1) in69_64) ((_ sign_extend 1) in67_64)) ((_ sign_extend 1) ?x1740)) true)))
(let (($x1047 (or false false (or $x1743))))
(and (not $x1047) (or $x1047 $x1742)))))))
(check-sat)
; query 167: function Gsm_Preprocess, block 94, name %95
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in67_64 () (_ BitVec 64))
(declare-fun in69_64 () (_ BitVec 64))
(assert
 (let ((?x1740 (bvadd in69_64 in67_64)))
(let (($x1742 (and (distinct ?x1740 ?x1740) true)))
(let (($x616 (or false false false)))
(let (($x382 (not $x616)))
(and $x382 (or $x616 $x1742)))))))
(check-sat)
; query 168: function Gsm_Preprocess, block 94, name %96
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in67_64 () (_ BitVec 64))
(declare-fun in69_64 () (_ BitVec 64))
(assert
 (let ((?x1160 (ite (bvuge (bvadd in69_64 in67_64) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x616 (or false false false)))
(let (($x671 (or $x616 false false)))
(let (($x1530 (not $x671)))
(and $x1530 (or $x671 (and (distinct ?x1160 ?x1160) true))))))))
(check-sat)
; query 169: function LARp_to_rp, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in19_16) ((_ sign_extend 16) in19_16)) true))))))
(check-sat)
; query 170: function LARp_to_rp, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x1495 ((_ sign_extend 16) in19_16)))
(let ((?x1150 (bvshl ?x1495 (_ bv1 32))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x166 (or $x309 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x776 (not $x166)))
(and $x776 (or $x166 (and (distinct ?x1150 ?x1150) true))))))))))
(check-sat)
; query 171: function LARp_to_rp, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x1495 ((_ sign_extend 16) in19_16)))
(let ((?x1150 (bvshl ?x1495 (_ bv1 32))))
(let ((?x1152 ((_ sign_extend 32) ?x1150)))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x166 (or $x309 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x1120 (or $x166 false)))
(let (($x947 (not $x1120)))
(and $x947 (or $x1120 (and (distinct ?x1152 ?x1152) true))))))))))))
(check-sat)
; query 172: function LARp_to_rp, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in19_16) ((_ sign_extend 16) in19_16)) true))))))
(check-sat)
; query 173: function LARp_to_rp, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x403 (ite (bvsgt (_ bv20070 32) ((_ sign_extend 16) in19_16)) (_ bv1 1) (_ bv0 1))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x39 (not $x309)))
(and $x39 (or $x309 (and (distinct ?x403 ?x403) true))))))))
(check-sat)
; query 174: function LARp_to_rp, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in19_16) ((_ sign_extend 16) in19_16)) true))))))
(check-sat)
; query 175: function LARp_to_rp, block 29, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x1495 ((_ sign_extend 16) in19_16)))
(let ((?x570 (bvadd ?x1495 (_ bv11059 32))))
(let (($x292 (and (distinct (bvadd ((_ sign_extend 1) ?x1495) ((_ sign_extend 1) (_ bv11059 32))) ((_ sign_extend 1) ?x570)) true)))
(let (($x489 (or false false)))
(let (($x579 (or $x489 false (or $x292))))
(and (not $x579) (or $x579 (and (distinct ?x570 ?x570) true)))))))))
(check-sat)
; query 176: function LARp_to_rp, block 29, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x1495 ((_ sign_extend 16) in19_16)))
(let ((?x570 (bvadd ?x1495 (_ bv11059 32))))
(let ((?x352 ((_ sign_extend 32) ?x570)))
(let (($x292 (and (distinct (bvadd ((_ sign_extend 1) ?x1495) ((_ sign_extend 1) (_ bv11059 32))) ((_ sign_extend 1) ?x570)) true)))
(let (($x489 (or false false)))
(let (($x579 (or $x489 false (or $x292))))
(let (($x810 (or $x579 false)))
(and (not $x810) (or $x810 (and (distinct ?x352 ?x352) true)))))))))))
(check-sat)
; query 177: function LARp_to_rp, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in19_16) ((_ sign_extend 16) in19_16)) true))))))
(check-sat)
; query 178: function LARp_to_rp, block 33, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x1495 ((_ sign_extend 16) in19_16)))
(let ((?x675 (bvashr ?x1495 (_ bv2 32))))
(let (($x894 (bvuge (_ bv2 32) (_ bv32 32))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x118 (or $x309 $x894)))
(and (not $x118) (or $x118 (and (distinct ?x675 ?x675) true))))))))))
(check-sat)
; query 179: function LARp_to_rp, block 33, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x1495 ((_ sign_extend 16) in19_16)))
(let ((?x675 (bvashr ?x1495 (_ bv2 32))))
(let ((?x575 ((_ sign_extend 32) ?x675)))
(let (($x894 (bvuge (_ bv2 32) (_ bv32 32))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x118 (or $x309 $x894)))
(let (($x457 (or $x118 false)))
(and (not $x457) (or $x457 (and (distinct ?x575 ?x575) true))))))))))))
(check-sat)
; query 180: function LARp_to_rp, block 33, name %37
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x1495 ((_ sign_extend 16) in19_16)))
(let ((?x675 (bvashr ?x1495 (_ bv2 32))))
(let ((?x575 ((_ sign_extend 32) ?x675)))
(let ((?x966 (bvadd ?x575 (_ bv26112 64))))
(let ((?x224 ((_ sign_extend 1) ?x966)))
(let (($x894 (bvuge (_ bv2 32) (_ bv32 32))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x118 (or $x309 $x894)))
(let (($x457 (or $x118 false)))
(let (($x452 (or $x457 false (or (and (distinct (bvadd ((_ sign_extend 1) ?x575) ((_ sign_extend 1) (_ bv26112 64))) ?x224) true)))))
(and (not $x452) (or $x452 (and (distinct ?x966 ?x966) true)))))))))))))))
(check-sat)
; query 181: function LARp_to_rp, block 33, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x1495 ((_ sign_extend 16) in19_16)))
(let ((?x675 (bvashr ?x1495 (_ bv2 32))))
(let ((?x575 ((_ sign_extend 32) ?x675)))
(let ((?x966 (bvadd ?x575 (_ bv26112 64))))
(let ((?x380 (bvsub ?x966 (_ bv18446744073709518848 64))))
(let (($x542 (and (distinct (bvsub ((_ sign_extend 1) ?x966) ((_ sign_extend 1) (_ bv18446744073709518848 64))) ((_ sign_extend 1) ?x380)) true)))
(let ((?x224 ((_ sign_extend 1) ?x966)))
(let (($x894 (bvuge (_ bv2 32) (_ bv32 32))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x118 (or $x309 $x894)))
(let (($x457 (or $x118 false)))
(let (($x452 (or $x457 false (or (and (distinct (bvadd ((_ sign_extend 1) ?x575) ((_ sign_extend 1) (_ bv26112 64))) ?x224) true)))))
(let (($x723 (or $x452 false (or $x542))))
(and (not $x723) (or $x723 (and (distinct ?x380 ?x380) true))))))))))))))))))
(check-sat)
; query 182: function LARp_to_rp, block 33, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x1495 ((_ sign_extend 16) in19_16)))
(let ((?x675 (bvashr ?x1495 (_ bv2 32))))
(let ((?x575 ((_ sign_extend 32) ?x675)))
(let ((?x966 (bvadd ?x575 (_ bv26112 64))))
(let ((?x380 (bvsub ?x966 (_ bv18446744073709518848 64))))
(let ((?x449 (ite (bvugt ?x380 (_ bv65535 64)) (_ bv1 1) (_ bv0 1))))
(let (($x542 (and (distinct (bvsub ((_ sign_extend 1) ?x966) ((_ sign_extend 1) (_ bv18446744073709518848 64))) ((_ sign_extend 1) ?x380)) true)))
(let ((?x224 ((_ sign_extend 1) ?x966)))
(let (($x894 (bvuge (_ bv2 32) (_ bv32 32))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x118 (or $x309 $x894)))
(let (($x457 (or $x118 false)))
(let (($x452 (or $x457 false (or (and (distinct (bvadd ((_ sign_extend 1) ?x575) ((_ sign_extend 1) (_ bv26112 64))) ?x224) true)))))
(let (($x723 (or $x452 false (or $x542))))
(let (($x852 (or $x723 false false)))
(and (not $x852) (or $x852 (and (distinct ?x449 ?x449) true))))))))))))))))))))
(check-sat)
; query 183: function Long_term_analysis_filtering, block 117, name %118
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in114_64 () (_ BitVec 64))
(assert
 (let ((?x994 (ite (bvsge (_ bv18446744073709518848 64) in114_64) (_ bv1 1) (_ bv0 1))))
(let (($x616 (or false false false)))
(let (($x382 (not $x616)))
(and $x382 (or $x616 (and (distinct ?x994 ?x994) true)))))))
(check-sat)
; query 184: function Long_term_analysis_filtering, block 128, name %129
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let (($x359 (and (distinct (bvadd ((_ sign_extend 1) in.2_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.2_32 (_ bv1 32)))) true)))
(let (($x356 (or false false (or $x359))))
(and (not $x356) (or $x356 (and (distinct (bvadd in.2_32 (_ bv1 32)) (bvadd in.2_32 (_ bv1 32))) true))))))
(check-sat)
; query 185: function Long_term_analysis_filtering, block 158, name %159
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in155_64 () (_ BitVec 64))
(assert
 (let ((?x424 (ite (bvsge (_ bv18446744073709518848 64) in155_64) (_ bv1 1) (_ bv0 1))))
(let (($x616 (or false false false)))
(let (($x382 (not $x616)))
(and $x382 (or $x616 (and (distinct ?x424 ?x424) true)))))))
(check-sat)
; query 186: function Long_term_analysis_filtering, block 169, name %170
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.3_32 () (_ BitVec 32))
(assert
 (let (($x1790 (and (distinct (bvadd ((_ sign_extend 1) in.3_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.3_32 (_ bv1 32)))) true)))
(let (($x1797 (or false false (or $x1790))))
(and (not $x1797) (or $x1797 (and (distinct (bvadd in.3_32 (_ bv1 32)) (bvadd in.3_32 (_ bv1 32))) true))))))
(check-sat)
; query 187: function Long_term_analysis_filtering, block 35, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in32_64 () (_ BitVec 64))
(assert
 (let ((?x550 (ite (bvsge (_ bv18446744073709518848 64) in32_64) (_ bv1 1) (_ bv0 1))))
(let (($x616 (or false false false)))
(let (($x382 (not $x616)))
(and $x382 (or $x616 (and (distinct ?x550 ?x550) true)))))))
(check-sat)
; query 188: function Long_term_analysis_filtering, block 46, name %47
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1502 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x1499 (or false false (or $x1502))))
(and (not $x1499) (or $x1499 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 189: function Long_term_analysis_filtering, block 76, name %77
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in73_64 () (_ BitVec 64))
(assert
 (let ((?x649 (ite (bvsge (_ bv18446744073709518848 64) in73_64) (_ bv1 1) (_ bv0 1))))
(let (($x616 (or false false false)))
(let (($x382 (not $x616)))
(and $x382 (or $x616 (and (distinct ?x649 ?x649) true)))))))
(check-sat)
; query 190: function Long_term_analysis_filtering, block 87, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x269 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x1933 (or false false (or $x269))))
(and (not $x1933) (or $x1933 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 191: function RPE_grid_positioning, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.27_32 () (_ BitVec 32))
(assert
 (let (($x228 (and (distinct (bvadd ((_ sign_extend 1) in.27_32) ((_ sign_extend 1) (_ bv4294967295 32))) ((_ sign_extend 1) (bvadd in.27_32 (_ bv4294967295 32)))) true)))
(let (($x609 (or false false (or $x228))))
(and (not $x609) (or $x609 (and (distinct (bvadd in.27_32 (_ bv4294967295 32)) (bvadd in.27_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 192: function RPE_grid_positioning, block 31, name %33
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.27_32 () (_ BitVec 32))
(assert
 (let ((?x794 (ite (and (distinct (_ bv0 32) (bvadd in.27_32 (_ bv4294967295 32))) true) (_ bv1 1) (_ bv0 1))))
(let (($x228 (and (distinct (bvadd ((_ sign_extend 1) in.27_32) ((_ sign_extend 1) (_ bv4294967295 32))) ((_ sign_extend 1) (bvadd in.27_32 (_ bv4294967295 32)))) true)))
(let (($x609 (or false false (or $x228))))
(let (($x170 (or $x609 false false)))
(and (not $x170) (or $x170 (and (distinct ?x794 ?x794) true))))))))
(check-sat)
; query 193: function RPE_grid_positioning, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 194: function RPE_grid_positioning, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x651 (ite (bvsge (_ bv3 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x39 (not $x309)))
(and $x39 (or $x309 (and (distinct ?x651 ?x651) true))))))))
(check-sat)
; query 195: function RPE_grid_positioning, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 196: function RPE_grid_positioning, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x537 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x643 (and (distinct ?x537 ?x537) true)))
(let (($x489 (or false false)))
(let (($x395 (or false $x489 false)))
(and (not $x395) (or $x395 $x643)))))))
(check-sat)
; query 197: function RPE_grid_selection, block 308, name %309
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_32 () (_ BitVec 32))
(assert
 (let (($x319 (and (distinct (bvadd ((_ sign_extend 1) in.03_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.03_32 (_ bv1 32)))) true)))
(let (($x390 (or false false (or $x319))))
(and (not $x390) (or $x390 (and (distinct (bvadd in.03_32 (_ bv1 32)) (bvadd in.03_32 (_ bv1 32))) true))))))
(check-sat)
; query 198: function Reflection_coefficients, block 101, name %102
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in89_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in89_16) ((_ sign_extend 16) in89_16)) true))))))
(check-sat)
; query 199: function Reflection_coefficients, block 116, name %117
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.4_32 () (_ BitVec 32))
(assert
 (let (($x1814 (and (distinct (bvadd ((_ sign_extend 1) in.4_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.4_32 (_ bv1 32)))) true)))
(let (($x414 (or false false (or $x1814))))
(and (not $x414) (or $x414 (and (distinct (bvadd in.4_32 (_ bv1 32)) (bvadd in.4_32 (_ bv1 32))) true))))))
(check-sat)
; query 200: function Reflection_coefficients, block 154, name %155
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.05_32 () (_ BitVec 32))
(assert
 (let ((?x1423 (ite (= (_ bv8 32) in.05_32) (_ bv1 1) (_ bv0 1))))
(let (($x616 (or false false false)))
(let (($x382 (not $x616)))
(and $x382 (or $x616 (and (distinct ?x1423 ?x1423) true)))))))
(check-sat)
; query 201: function Reflection_coefficients, block 34, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in31_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in31_16) ((_ sign_extend 16) in31_16)) true))))))
(check-sat)
; query 202: function Reflection_coefficients, block 34, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in31_16 () (_ BitVec 16))
(assert
 (let ((?x1425 (ite (bvsgt (_ bv32 32) ((_ sign_extend 16) in31_16)) (_ bv1 1) (_ bv0 1))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x39 (not $x309)))
(and $x39 (or $x309 (and (distinct ?x1425 ?x1425) true))))))))
(check-sat)
; query 203: function Reflection_coefficients, block 60, name %61
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x1434 (and (distinct (bvadd ((_ sign_extend 1) in.12_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.12_32 (_ bv1 32)))) true)))
(let (($x1440 (or false false (or $x1434))))
(and (not $x1440) (or $x1440 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 204: function Reflection_coefficients, block 71, name %72
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.23_32 () (_ BitVec 32))
(assert
 (let (($x1454 (and (distinct (bvadd ((_ sign_extend 1) in.23_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.23_32 (_ bv1 32)))) true)))
(let (($x1452 (or false false (or $x1454))))
(and (not $x1452) (or $x1452 (and (distinct (bvadd in.23_32 (_ bv1 32)) (bvadd in.23_32 (_ bv1 32))) true))))))
(check-sat)
; query 205: function Reflection_coefficients, block 82, name %83
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.3_32 () (_ BitVec 32))
(assert
 (let (($x1790 (and (distinct (bvadd ((_ sign_extend 1) in.3_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.3_32 (_ bv1 32)))) true)))
(let (($x1797 (or false false (or $x1790))))
(and (not $x1797) (or $x1797 (and (distinct (bvadd in.3_32 (_ bv1 32)) (bvadd in.3_32 (_ bv1 32))) true))))))
(check-sat)
; query 206: function Reflection_coefficients, block 92, name %93
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in89_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in89_16) ((_ sign_extend 16) in89_16)) true))))))
(check-sat)
; query 207: function Reflection_coefficients, block 92, name %94
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in89_16 () (_ BitVec 16))
(assert
 (let ((?x1462 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in89_16)) (_ bv1 1) (_ bv0 1))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x39 (not $x309)))
(and $x39 (or $x309 (and (distinct ?x1462 ?x1462) true))))))))
(check-sat)
; query 208: function Reflection_coefficients, block 96, name %97
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in89_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in89_16) ((_ sign_extend 16) in89_16)) true))))))
(check-sat)
; query 209: function Reflection_coefficients, block 96, name %98
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in89_16 () (_ BitVec 16))
(assert
 (let ((?x905 ((_ sign_extend 16) in89_16)))
(let ((?x1465 (bvsub (_ bv0 32) ?x905)))
(let (($x1470 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x905)) ((_ sign_extend 1) ?x1465)) true)))
(let (($x489 (or false false)))
(let (($x1404 (or false $x489 (or $x1470))))
(and (not $x1404) (or $x1404 (and (distinct ?x1465 ?x1465) true)))))))))
(check-sat)
; query 210: function Short_term_synthesis_filtering, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in23_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in23_16) ((_ sign_extend 16) in23_16)) true))))))
(check-sat)
; query 211: function Short_term_synthesis_filtering, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in23_16 () (_ BitVec 16))
(assert
 (let ((?x1466 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in23_16)) (_ bv1 1) (_ bv0 1))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x39 (not $x309)))
(and $x39 (or $x309 (and (distinct ?x1466 ?x1466) true))))))))
(check-sat)
; query 212: function Short_term_synthesis_filtering, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in20_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 48) in20_16) ((_ sign_extend 48) in20_16)) true))))))
(check-sat)
; query 213: function Short_term_synthesis_filtering, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in23_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 48) in23_16) ((_ sign_extend 48) in23_16)) true))))))
(check-sat)
; query 214: function Short_term_synthesis_filtering, block 30, name %33
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in23_16 () (_ BitVec 16))
(declare-fun in20_16 () (_ BitVec 16))
(assert
 (let ((?x1467 ((_ sign_extend 48) in23_16)))
(let ((?x1476 ((_ sign_extend 48) in20_16)))
(let ((?x837 (bvmul ?x1476 ?x1467)))
(let (($x761 (and (distinct (bvmul ((_ sign_extend 64) ?x1476) ((_ sign_extend 64) ?x1467)) ((_ sign_extend 64) ?x837)) true)))
(let (($x489 (or false false)))
(let (($x239 (or $x489 $x489 (or $x761))))
(and (not $x239) (or $x239 (and (distinct ?x837 ?x837) true))))))))))
(check-sat)
; query 215: function Short_term_synthesis_filtering, block 30, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in23_16 () (_ BitVec 16))
(declare-fun in20_16 () (_ BitVec 16))
(assert
 (let ((?x1467 ((_ sign_extend 48) in23_16)))
(let ((?x1476 ((_ sign_extend 48) in20_16)))
(let ((?x837 (bvmul ?x1476 ?x1467)))
(let ((?x619 (bvadd ?x837 (_ bv16384 64))))
(let (($x323 (and (distinct (bvadd ((_ sign_extend 1) ?x837) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x619)) true)))
(let (($x761 (and (distinct (bvmul ((_ sign_extend 64) ?x1476) ((_ sign_extend 64) ?x1467)) ((_ sign_extend 64) ?x837)) true)))
(let (($x489 (or false false)))
(let (($x239 (or $x489 $x489 (or $x761))))
(let (($x637 (or $x239 false (or $x323))))
(and (not $x637) (or $x637 (and (distinct ?x619 ?x619) true)))))))))))))
(check-sat)
; query 216: function Short_term_synthesis_filtering, block 30, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in23_16 () (_ BitVec 16))
(declare-fun in20_16 () (_ BitVec 16))
(assert
 (let ((?x1467 ((_ sign_extend 48) in23_16)))
(let ((?x1476 ((_ sign_extend 48) in20_16)))
(let ((?x837 (bvmul ?x1476 ?x1467)))
(let ((?x619 (bvadd ?x837 (_ bv16384 64))))
(let ((?x635 (bvashr ?x619 (_ bv15 64))))
(let (($x509 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x323 (and (distinct (bvadd ((_ sign_extend 1) ?x837) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x619)) true)))
(let (($x761 (and (distinct (bvmul ((_ sign_extend 64) ?x1476) ((_ sign_extend 64) ?x1467)) ((_ sign_extend 64) ?x837)) true)))
(let (($x489 (or false false)))
(let (($x239 (or $x489 $x489 (or $x761))))
(let (($x637 (or $x239 false (or $x323))))
(let (($x571 (or (or $x637 false false) $x509)))
(and (not $x571) (or $x571 (and (distinct ?x635 ?x635) true))))))))))))))))
(check-sat)
; query 217: function Short_term_synthesis_filtering, block 30, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in23_16 () (_ BitVec 16))
(declare-fun in20_16 () (_ BitVec 16))
(assert
 (let ((?x1467 ((_ sign_extend 48) in23_16)))
(let ((?x1476 ((_ sign_extend 48) in20_16)))
(let ((?x837 (bvmul ?x1476 ?x1467)))
(let ((?x619 (bvadd ?x837 (_ bv16384 64))))
(let ((?x635 (bvashr ?x619 (_ bv15 64))))
(let ((?x445 (bvand (_ bv65535 64) ?x635)))
(let (($x509 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x323 (and (distinct (bvadd ((_ sign_extend 1) ?x837) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x619)) true)))
(let (($x761 (and (distinct (bvmul ((_ sign_extend 64) ?x1476) ((_ sign_extend 64) ?x1467)) ((_ sign_extend 64) ?x837)) true)))
(let (($x489 (or false false)))
(let (($x239 (or $x489 $x489 (or $x761))))
(let (($x637 (or $x239 false (or $x323))))
(let (($x571 (or (or $x637 false false) $x509)))
(let (($x735 (or false $x571 false)))
(and (not $x735) (or $x735 (and (distinct ?x445 ?x445) true))))))))))))))))))
(check-sat)
; query 218: function Short_term_synthesis_filtering, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in42_64 () (_ BitVec 64))
(assert
 (let ((?x779 (ite (bvsge (_ bv18446744073709518848 64) in42_64) (_ bv1 1) (_ bv0 1))))
(let (($x616 (or false false false)))
(let (($x382 (not $x616)))
(and $x382 (or $x616 (and (distinct ?x779 ?x779) true)))))))
(check-sat)
; query 219: function Short_term_synthesis_filtering, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in53_16) ((_ sign_extend 16) in53_16)) true))))))
(check-sat)
; query 220: function Short_term_synthesis_filtering, block 56, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let ((?x1001 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in53_16)) (_ bv1 1) (_ bv0 1))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x39 (not $x309)))
(and $x39 (or $x309 (and (distinct ?x1001 ?x1001) true))))))))
(check-sat)
; query 221: function Short_term_synthesis_filtering, block 60, name %61
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in20_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 48) in20_16) ((_ sign_extend 48) in20_16)) true))))))
(check-sat)
; query 222: function Short_term_synthesis_filtering, block 60, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 48) in53_16) ((_ sign_extend 48) in53_16)) true))))))
(check-sat)
; query 223: function Short_term_synthesis_filtering, block 60, name %63
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(declare-fun in20_16 () (_ BitVec 16))
(assert
 (let ((?x876 ((_ sign_extend 48) in53_16)))
(let ((?x1476 ((_ sign_extend 48) in20_16)))
(let ((?x1093 (bvmul ?x1476 ?x876)))
(let (($x1031 (and (distinct (bvmul ((_ sign_extend 64) ?x1476) ((_ sign_extend 64) ?x876)) ((_ sign_extend 64) ?x1093)) true)))
(let (($x489 (or false false)))
(let (($x812 (or $x489 $x489 (or $x1031))))
(and (not $x812) (or $x812 (and (distinct ?x1093 ?x1093) true))))))))))
(check-sat)
; query 224: function Short_term_synthesis_filtering, block 60, name %64
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(declare-fun in20_16 () (_ BitVec 16))
(assert
 (let ((?x876 ((_ sign_extend 48) in53_16)))
(let ((?x1476 ((_ sign_extend 48) in20_16)))
(let ((?x1093 (bvmul ?x1476 ?x876)))
(let ((?x1066 (bvadd ?x1093 (_ bv16384 64))))
(let (($x1003 (and (distinct (bvadd ((_ sign_extend 1) ?x1093) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x1066)) true)))
(let (($x1031 (and (distinct (bvmul ((_ sign_extend 64) ?x1476) ((_ sign_extend 64) ?x876)) ((_ sign_extend 64) ?x1093)) true)))
(let (($x489 (or false false)))
(let (($x812 (or $x489 $x489 (or $x1031))))
(let (($x1002 (or $x812 false (or $x1003))))
(and (not $x1002) (or $x1002 (and (distinct ?x1066 ?x1066) true)))))))))))))
(check-sat)
; query 225: function Short_term_synthesis_filtering, block 60, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(declare-fun in20_16 () (_ BitVec 16))
(assert
 (let ((?x876 ((_ sign_extend 48) in53_16)))
(let ((?x1476 ((_ sign_extend 48) in20_16)))
(let ((?x1093 (bvmul ?x1476 ?x876)))
(let ((?x1066 (bvadd ?x1093 (_ bv16384 64))))
(let ((?x1020 (bvashr ?x1066 (_ bv15 64))))
(let (($x509 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1003 (and (distinct (bvadd ((_ sign_extend 1) ?x1093) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x1066)) true)))
(let (($x1031 (and (distinct (bvmul ((_ sign_extend 64) ?x1476) ((_ sign_extend 64) ?x876)) ((_ sign_extend 64) ?x1093)) true)))
(let (($x489 (or false false)))
(let (($x812 (or $x489 $x489 (or $x1031))))
(let (($x1002 (or $x812 false (or $x1003))))
(let (($x811 (or (or $x1002 false false) $x509)))
(and (not $x811) (or $x811 (and (distinct ?x1020 ?x1020) true))))))))))))))))
(check-sat)
; query 226: function Short_term_synthesis_filtering, block 60, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(declare-fun in20_16 () (_ BitVec 16))
(assert
 (let ((?x876 ((_ sign_extend 48) in53_16)))
(let ((?x1476 ((_ sign_extend 48) in20_16)))
(let ((?x1093 (bvmul ?x1476 ?x876)))
(let ((?x1066 (bvadd ?x1093 (_ bv16384 64))))
(let ((?x1020 (bvashr ?x1066 (_ bv15 64))))
(let ((?x1035 (bvand (_ bv65535 64) ?x1020)))
(let (($x509 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1003 (and (distinct (bvadd ((_ sign_extend 1) ?x1093) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x1066)) true)))
(let (($x1031 (and (distinct (bvmul ((_ sign_extend 64) ?x1476) ((_ sign_extend 64) ?x876)) ((_ sign_extend 64) ?x1093)) true)))
(let (($x489 (or false false)))
(let (($x812 (or $x489 $x489 (or $x1031))))
(let (($x1002 (or $x812 false (or $x1003))))
(let (($x811 (or (or $x1002 false false) $x509)))
(let (($x686 (or false $x811 false)))
(and (not $x686) (or $x686 (and (distinct ?x1035 ?x1035) true))))))))))))))))))
(check-sat)
; query 227: function Transformation_to_Log_Area_Ratios, block 12, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in5_16) ((_ sign_extend 16) in5_16)) true))))))
(check-sat)
; query 228: function Transformation_to_Log_Area_Ratios, block 12, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_16 () (_ BitVec 16))
(assert
 (let ((?x1103 ((_ sign_extend 16) in5_16)))
(let ((?x968 (bvsub (_ bv0 32) ?x1103)))
(let (($x956 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1103)) ((_ sign_extend 1) ?x968)) true)))
(let (($x489 (or false false)))
(let (($x977 (or false $x489 (or $x956))))
(and (not $x977) (or $x977 (and (distinct ?x968 ?x968) true)))))))))
(check-sat)
; query 229: function Transformation_to_Log_Area_Ratios, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in5_16) ((_ sign_extend 16) in5_16)) true))))))
(check-sat)
; query 230: function Transformation_to_Log_Area_Ratios, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in21_16) ((_ sign_extend 16) in21_16)) true))))))
(check-sat)
; query 231: function Transformation_to_Log_Area_Ratios, block 31, name %33
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let ((?x897 (ite (bvsgt (_ bv22118 32) ((_ sign_extend 16) in21_16)) (_ bv1 1) (_ bv0 1))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x39 (not $x309)))
(and $x39 (or $x309 (and (distinct ?x897 ?x897) true))))))))
(check-sat)
; query 232: function Transformation_to_Log_Area_Ratios, block 34, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in21_16) ((_ sign_extend 16) in21_16)) true))))))
(check-sat)
; query 233: function Transformation_to_Log_Area_Ratios, block 34, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let ((?x800 ((_ sign_extend 16) in21_16)))
(let ((?x861 (bvashr ?x800 (_ bv1 32))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x166 (or $x309 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x776 (not $x166)))
(and $x776 (or $x166 (and (distinct ?x861 ?x861) true))))))))))
(check-sat)
; query 234: function Transformation_to_Log_Area_Ratios, block 34, name %37
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let ((?x800 ((_ sign_extend 16) in21_16)))
(let ((?x861 (bvashr ?x800 (_ bv1 32))))
(let ((?x834 ((_ extract 15 0) ?x861)))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x166 (or $x309 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x1120 (or $x166 false)))
(let (($x947 (not $x1120)))
(and $x947 (or $x1120 (and (distinct ?x834 ?x834) true))))))))))))
(check-sat)
; query 235: function Transformation_to_Log_Area_Ratios, block 38, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in21_16) ((_ sign_extend 16) in21_16)) true))))))
(check-sat)
; query 236: function Transformation_to_Log_Area_Ratios, block 38, name %40
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let ((?x986 (ite (bvsgt (_ bv31130 32) ((_ sign_extend 16) in21_16)) (_ bv1 1) (_ bv0 1))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x39 (not $x309)))
(and $x39 (or $x309 (and (distinct ?x986 ?x986) true))))))))
(check-sat)
; query 237: function Transformation_to_Log_Area_Ratios, block 41, name %42
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in21_16) ((_ sign_extend 16) in21_16)) true))))))
(check-sat)
; query 238: function Transformation_to_Log_Area_Ratios, block 41, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let ((?x1115 (ite (bvsle (_ bv11059 32) ((_ sign_extend 16) in21_16)) (_ bv1 1) (_ bv0 1))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x39 (not $x309)))
(and $x39 (or $x309 (and (distinct ?x1115 ?x1115) true))))))))
(check-sat)
; query 239: function Transformation_to_Log_Area_Ratios, block 41, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let ((?x1115 (ite (bvsle (_ bv11059 32) ((_ sign_extend 16) in21_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1108 (bvxor ?x1115 (_ bv1 1))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x1843 (or $x309 false false)))
(let (($x1857 (not $x1843)))
(and $x1857 (or $x1843 (and (distinct ?x1108 ?x1108) true))))))))))
(check-sat)
; query 240: function Transformation_to_Log_Area_Ratios, block 41, name %45
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let ((?x1115 (ite (bvsle (_ bv11059 32) ((_ sign_extend 16) in21_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1108 (bvxor ?x1115 (_ bv1 1))))
(let ((?x1109 ((_ zero_extend 31) ?x1108)))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x1843 (or $x309 false false)))
(let (($x1846 (or $x1843 false)))
(let (($x1862 (not $x1846)))
(and $x1862 (or $x1846 (and (distinct ?x1109 ?x1109) true))))))))))))
(check-sat)
; query 241: function Transformation_to_Log_Area_Ratios, block 41, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let ((?x1115 (ite (bvsle (_ bv11059 32) ((_ sign_extend 16) in21_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1108 (bvxor ?x1115 (_ bv1 1))))
(let ((?x1109 ((_ zero_extend 31) ?x1108)))
(let ((?x1110 ((_ sign_extend 32) ?x1109)))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x1843 (or $x309 false false)))
(let (($x1846 (or $x1843 false)))
(let (($x1854 (or $x1846 false)))
(let (($x1866 (not $x1854)))
(and $x1866 (or $x1854 (and (distinct ?x1110 ?x1110) true))))))))))))))
(check-sat)
; query 242: function Transformation_to_Log_Area_Ratios, block 41, name %47
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let ((?x1115 (ite (bvsle (_ bv11059 32) ((_ sign_extend 16) in21_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1108 (bvxor ?x1115 (_ bv1 1))))
(let ((?x1109 ((_ zero_extend 31) ?x1108)))
(let ((?x1110 ((_ sign_extend 32) ?x1109)))
(let ((?x1040 (ite (and (distinct (_ bv0 64) ?x1110) true) (_ bv1 1) (_ bv0 1))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x1843 (or $x309 false false)))
(let (($x1846 (or $x1843 false)))
(let (($x1854 (or $x1846 false)))
(let (($x1852 (or $x1854 false false)))
(let (($x753 (not $x1852)))
(and $x753 (or $x1852 (and (distinct ?x1040 ?x1040) true))))))))))))))))
(check-sat)
; query 243: function Transformation_to_Log_Area_Ratios, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in21_16) ((_ sign_extend 16) in21_16)) true))))))
(check-sat)
; query 244: function Transformation_to_Log_Area_Ratios, block 51, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let ((?x800 ((_ sign_extend 16) in21_16)))
(let ((?x914 (bvsub ?x800 (_ bv11059 32))))
(let (($x862 (and (distinct (bvsub ((_ sign_extend 1) ?x800) ((_ sign_extend 1) (_ bv11059 32))) ((_ sign_extend 1) ?x914)) true)))
(let (($x489 (or false false)))
(let (($x935 (or $x489 false (or $x862))))
(and (not $x935) (or $x935 (and (distinct ?x914 ?x914) true)))))))))
(check-sat)
; query 245: function Transformation_to_Log_Area_Ratios, block 51, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let ((?x800 ((_ sign_extend 16) in21_16)))
(let ((?x914 (bvsub ?x800 (_ bv11059 32))))
(let ((?x1004 ((_ extract 15 0) ?x914)))
(let (($x862 (and (distinct (bvsub ((_ sign_extend 1) ?x800) ((_ sign_extend 1) (_ bv11059 32))) ((_ sign_extend 1) ?x914)) true)))
(let (($x489 (or false false)))
(let (($x935 (or $x489 false (or $x862))))
(let (($x1086 (or $x935 false)))
(and (not $x1086) (or $x1086 (and (distinct ?x1004 ?x1004) true)))))))))))
(check-sat)
; query 246: function Transformation_to_Log_Area_Ratios, block 55, name %56
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in21_16) ((_ sign_extend 16) in21_16)) true))))))
(check-sat)
; query 247: function Transformation_to_Log_Area_Ratios, block 55, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let ((?x933 (ite (bvsle (_ bv26112 32) ((_ sign_extend 16) in21_16)) (_ bv1 1) (_ bv0 1))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x39 (not $x309)))
(and $x39 (or $x309 (and (distinct ?x933 ?x933) true))))))))
(check-sat)
; query 248: function Transformation_to_Log_Area_Ratios, block 55, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let ((?x933 (ite (bvsle (_ bv26112 32) ((_ sign_extend 16) in21_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x918 (bvxor ?x933 (_ bv1 1))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x1843 (or $x309 false false)))
(let (($x1857 (not $x1843)))
(and $x1857 (or $x1843 (and (distinct ?x918 ?x918) true))))))))))
(check-sat)
; query 249: function Transformation_to_Log_Area_Ratios, block 55, name %59
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let ((?x933 (ite (bvsle (_ bv26112 32) ((_ sign_extend 16) in21_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x918 (bvxor ?x933 (_ bv1 1))))
(let ((?x1062 ((_ zero_extend 31) ?x918)))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x1843 (or $x309 false false)))
(let (($x1846 (or $x1843 false)))
(let (($x1862 (not $x1846)))
(and $x1862 (or $x1846 (and (distinct ?x1062 ?x1062) true))))))))))))
(check-sat)
; query 250: function Transformation_to_Log_Area_Ratios, block 55, name %60
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let ((?x933 (ite (bvsle (_ bv26112 32) ((_ sign_extend 16) in21_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x918 (bvxor ?x933 (_ bv1 1))))
(let ((?x1062 ((_ zero_extend 31) ?x918)))
(let ((?x963 ((_ sign_extend 32) ?x1062)))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x1843 (or $x309 false false)))
(let (($x1846 (or $x1843 false)))
(let (($x1854 (or $x1846 false)))
(let (($x1866 (not $x1854)))
(and $x1866 (or $x1854 (and (distinct ?x963 ?x963) true))))))))))))))
(check-sat)
; query 251: function Transformation_to_Log_Area_Ratios, block 55, name %61
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let ((?x933 (ite (bvsle (_ bv26112 32) ((_ sign_extend 16) in21_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x918 (bvxor ?x933 (_ bv1 1))))
(let ((?x1062 ((_ zero_extend 31) ?x918)))
(let ((?x963 ((_ sign_extend 32) ?x1062)))
(let ((?x888 (ite (and (distinct (_ bv0 64) ?x963) true) (_ bv1 1) (_ bv0 1))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x1843 (or $x309 false false)))
(let (($x1846 (or $x1843 false)))
(let (($x1854 (or $x1846 false)))
(let (($x1852 (or $x1854 false false)))
(let (($x753 (not $x1852)))
(and $x753 (or $x1852 (and (distinct ?x888 ?x888) true))))))))))))))))
(check-sat)
; query 252: function Transformation_to_Log_Area_Ratios, block 65, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in21_16) ((_ sign_extend 16) in21_16)) true))))))
(check-sat)
; query 253: function Transformation_to_Log_Area_Ratios, block 65, name %67
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let ((?x800 ((_ sign_extend 16) in21_16)))
(let ((?x845 (bvsub ?x800 (_ bv26112 32))))
(let (($x1021 (and (distinct (bvsub ((_ sign_extend 1) ?x800) ((_ sign_extend 1) (_ bv26112 32))) ((_ sign_extend 1) ?x845)) true)))
(let (($x489 (or false false)))
(let (($x981 (or $x489 false (or $x1021))))
(and (not $x981) (or $x981 (and (distinct ?x845 ?x845) true)))))))))
(check-sat)
; query 254: function Transformation_to_Log_Area_Ratios, block 65, name %68
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let ((?x800 ((_ sign_extend 16) in21_16)))
(let ((?x845 (bvsub ?x800 (_ bv26112 32))))
(let ((?x830 ((_ extract 15 0) ?x845)))
(let (($x1021 (and (distinct (bvsub ((_ sign_extend 1) ?x800) ((_ sign_extend 1) (_ bv26112 32))) ((_ sign_extend 1) ?x845)) true)))
(let (($x489 (or false false)))
(let (($x981 (or $x489 false (or $x1021))))
(let (($x874 (or $x981 false)))
(and (not $x874) (or $x874 (and (distinct ?x830 ?x830) true)))))))))))
(check-sat)
; query 255: function Transformation_to_Log_Area_Ratios, block 65, name %69
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let ((?x800 ((_ sign_extend 16) in21_16)))
(let ((?x845 (bvsub ?x800 (_ bv26112 32))))
(let ((?x830 ((_ extract 15 0) ?x845)))
(let ((?x856 ((_ sign_extend 16) ?x830)))
(let (($x1021 (and (distinct (bvsub ((_ sign_extend 1) ?x800) ((_ sign_extend 1) (_ bv26112 32))) ((_ sign_extend 1) ?x845)) true)))
(let (($x489 (or false false)))
(let (($x981 (or $x489 false (or $x1021))))
(let (($x874 (or $x981 false)))
(let (($x1057 (or $x874 false)))
(and (not $x1057) (or $x1057 (and (distinct ?x856 ?x856) true)))))))))))))
(check-sat)
; query 256: function Transformation_to_Log_Area_Ratios, block 65, name %70
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let ((?x800 ((_ sign_extend 16) in21_16)))
(let ((?x845 (bvsub ?x800 (_ bv26112 32))))
(let ((?x830 ((_ extract 15 0) ?x845)))
(let ((?x856 ((_ sign_extend 16) ?x830)))
(let ((?x922 (bvshl ?x856 (_ bv2 32))))
(let (($x894 (bvuge (_ bv2 32) (_ bv32 32))))
(let (($x1021 (and (distinct (bvsub ((_ sign_extend 1) ?x800) ((_ sign_extend 1) (_ bv26112 32))) ((_ sign_extend 1) ?x845)) true)))
(let (($x489 (or false false)))
(let (($x981 (or $x489 false (or $x1021))))
(let (($x874 (or $x981 false)))
(let (($x1057 (or $x874 false)))
(let (($x758 (or (or $x1057 false false) $x894)))
(and (not $x758) (or $x758 (and (distinct ?x922 ?x922) true))))))))))))))))
(check-sat)
; query 257: function Transformation_to_Log_Area_Ratios, block 65, name %71
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let ((?x800 ((_ sign_extend 16) in21_16)))
(let ((?x845 (bvsub ?x800 (_ bv26112 32))))
(let ((?x830 ((_ extract 15 0) ?x845)))
(let ((?x856 ((_ sign_extend 16) ?x830)))
(let ((?x922 (bvshl ?x856 (_ bv2 32))))
(let ((?x871 ((_ extract 15 0) ?x922)))
(let (($x894 (bvuge (_ bv2 32) (_ bv32 32))))
(let (($x1021 (and (distinct (bvsub ((_ sign_extend 1) ?x800) ((_ sign_extend 1) (_ bv26112 32))) ((_ sign_extend 1) ?x845)) true)))
(let (($x489 (or false false)))
(let (($x981 (or $x489 false (or $x1021))))
(let (($x874 (or $x981 false)))
(let (($x1057 (or $x874 false)))
(let (($x758 (or (or $x1057 false false) $x894)))
(let (($x1111 (or $x758 false)))
(and (not $x1111) (or $x1111 (and (distinct ?x871 ?x871) true))))))))))))))))))
(check-sat)
; query 258: function Transformation_to_Log_Area_Ratios, block 77, name %78
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 259: function Transformation_to_Log_Area_Ratios, block 77, name %79
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x289 ((_ sign_extend 16) in.1_16)))
(let ((?x1081 (bvsub (_ bv0 32) ?x289)))
(let (($x1080 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x289)) ((_ sign_extend 1) ?x1081)) true)))
(let (($x489 (or false false)))
(let (($x1053 (or false $x489 (or $x1080))))
(and (not $x1053) (or $x1053 (and (distinct ?x1081 ?x1081) true)))))))))
(check-sat)
; query 260: function Transformation_to_Log_Area_Ratios, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_16 () (_ BitVec 16))
(assert
 (let ((?x1055 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in5_16)) (_ bv1 1) (_ bv0 1))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x39 (not $x309)))
(and $x39 (or $x309 (and (distinct ?x1055 ?x1055) true))))))))
(check-sat)
; query 261: function Transformation_to_Log_Area_Ratios, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in5_16) ((_ sign_extend 16) in5_16)) true))))))
(check-sat)
; query 262: function Transformation_to_Log_Area_Ratios, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 263: function Weighting_filter, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in70_64 () (_ BitVec 64))
(assert
 (let ((?x1018 (ite (bvslt (_ bv32767 64) in70_64) (_ bv1 1) (_ bv0 1))))
(let (($x616 (or false false false)))
(let (($x382 (not $x616)))
(and $x382 (or $x616 (and (distinct ?x1018 ?x1018) true)))))))
(check-sat)
; query 264: function Weighting_filter, block 84, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1502 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x1499 (or false false (or $x1502))))
(and (not $x1499) (or $x1499 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 265: function alaw_input, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x357 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x1883 (or false false (or $x357))))
(and (not $x1883) (or $x1883 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 266: function alaw_input, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let ((?x948 (ite (= (_ bv4294967295 32) in.1_32) (_ bv1 1) (_ bv0 1))))
(let (($x616 (or false false false)))
(let (($x382 (not $x616)))
(and $x382 (or $x616 (and (distinct ?x948 ?x948) true)))))))
(check-sat)
; query 267: function gsm_L_add, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_64 () (_ BitVec 64))
(assert
 (let ((?x1007 (bvsub (_ bv0 64) in13_64)))
(let ((?x1030 ((_ sign_extend 1) ?x1007)))
(let (($x965 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in13_64)) ?x1030) true)))))
(and (not $x965) (or $x965 (and (distinct ?x1007 ?x1007) true)))))))
(check-sat)
; query 268: function gsm_L_add, block 16, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_64 () (_ BitVec 64))
(assert
 (let ((?x1007 (bvsub (_ bv0 64) in13_64)))
(let ((?x855 (bvsub ?x1007 (_ bv2 64))))
(let (($x813 (and (distinct (bvsub ((_ sign_extend 1) ?x1007) ((_ sign_extend 1) (_ bv2 64))) ((_ sign_extend 1) ?x855)) true)))
(let ((?x1030 ((_ sign_extend 1) ?x1007)))
(let (($x965 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in13_64)) ?x1030) true)))))
(let (($x961 (or $x965 false (or $x813))))
(and (not $x961) (or $x961 (and (distinct ?x855 ?x855) true))))))))))
(check-sat)
; query 269: function gsm_L_add, block 21, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x940 (ite (bvsge (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x616 (or false false false)))
(let (($x382 (not $x616)))
(and $x382 (or $x616 (and (distinct ?x940 ?x940) true)))))))
(check-sat)
; query 270: function gsm_L_add, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x685 (bvadd in0_64 in1_64)))
(let (($x1391 (and (distinct ?x685 ?x685) true)))
(let (($x748 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) ?x685)) true)))
(let (($x690 (or false false (or $x748))))
(and (not $x690) (or $x690 $x1391)))))))
(check-sat)
; query 271: function gsm_L_add, block 25, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x685 (bvadd in0_64 in1_64)))
(let (($x1391 (and (distinct ?x685 ?x685) true)))
(let (($x616 (or false false false)))
(let (($x382 (not $x616)))
(and $x382 (or $x616 $x1391)))))))
(check-sat)
; query 272: function gsm_L_add, block 25, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1383 (ite (bvugt (bvadd in0_64 in1_64) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x616 (or false false false)))
(let (($x671 (or $x616 false false)))
(let (($x1530 (not $x671)))
(and $x1530 (or $x671 (and (distinct ?x1383 ?x1383) true))))))))
(check-sat)
; query 273: function gsm_L_add, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1341 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x616 (or false false false)))
(let (($x382 (not $x616)))
(and $x382 (or $x616 (and (distinct ?x1341 ?x1341) true)))))))
(check-sat)
; query 274: function gsm_L_add, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x685 (bvadd in0_64 in1_64)))
(let (($x1391 (and (distinct ?x685 ?x685) true)))
(let (($x748 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) ?x685)) true)))
(let (($x690 (or false false (or $x748))))
(and (not $x690) (or $x690 $x1391)))))))
(check-sat)
; query 275: function gsm_L_add, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1323 (bvadd in0_64 (_ bv1 64))))
(let ((?x1281 (bvsub (_ bv0 64) ?x1323)))
(let (($x1283 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1323)) ((_ sign_extend 1) ?x1281)) true)))
(let ((?x1311 ((_ sign_extend 1) ?x1323)))
(let (($x1303 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1311) true)))))
(let (($x1273 (or false $x1303 (or $x1283))))
(and (not $x1273) (or $x1273 (and (distinct ?x1281 ?x1281) true))))))))))
(check-sat)
; query 276: function gsm_L_add, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1263 (bvadd in1_64 (_ bv1 64))))
(let ((?x1251 ((_ sign_extend 1) ?x1263)))
(let (($x1243 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1251) true)))))
(and (not $x1243) (or $x1243 (and (distinct ?x1263 ?x1263) true)))))))
(check-sat)
; query 277: function gsm_L_add, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1263 (bvadd in1_64 (_ bv1 64))))
(let ((?x1221 (bvsub (_ bv0 64) ?x1263)))
(let (($x1223 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1263)) ((_ sign_extend 1) ?x1221)) true)))
(let ((?x1251 ((_ sign_extend 1) ?x1263)))
(let (($x1243 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1251) true)))))
(let (($x1213 (or false $x1243 (or $x1223))))
(and (not $x1213) (or $x1213 (and (distinct ?x1221 ?x1221) true))))))))))
(check-sat)
; query 278: function gsm_L_add, block 8, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1263 (bvadd in1_64 (_ bv1 64))))
(let ((?x1221 (bvsub (_ bv0 64) ?x1263)))
(let ((?x1323 (bvadd in0_64 (_ bv1 64))))
(let ((?x1281 (bvsub (_ bv0 64) ?x1323)))
(let ((?x1203 (bvadd ?x1281 ?x1221)))
(let (($x1223 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1263)) ((_ sign_extend 1) ?x1221)) true)))
(let ((?x1251 ((_ sign_extend 1) ?x1263)))
(let (($x1243 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1251) true)))))
(let (($x1213 (or false $x1243 (or $x1223))))
(let (($x1283 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1323)) ((_ sign_extend 1) ?x1281)) true)))
(let ((?x1311 ((_ sign_extend 1) ?x1323)))
(let (($x1303 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1311) true)))))
(let (($x1273 (or false $x1303 (or $x1283))))
(let (($x1201 (or $x1273 $x1213 false)))
(and (not $x1201) (or $x1201 (and (distinct ?x1203 ?x1203) true))))))))))))))))))
(check-sat)
; query 279: function gsm_L_add, block 8, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1263 (bvadd in1_64 (_ bv1 64))))
(let ((?x1221 (bvsub (_ bv0 64) ?x1263)))
(let ((?x1323 (bvadd in0_64 (_ bv1 64))))
(let ((?x1281 (bvsub (_ bv0 64) ?x1323)))
(let ((?x1203 (bvadd ?x1281 ?x1221)))
(let ((?x1181 (ite (bvuge ?x1203 (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x1223 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1263)) ((_ sign_extend 1) ?x1221)) true)))
(let ((?x1251 ((_ sign_extend 1) ?x1263)))
(let (($x1243 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1251) true)))))
(let (($x1213 (or false $x1243 (or $x1223))))
(let (($x1283 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1323)) ((_ sign_extend 1) ?x1281)) true)))
(let ((?x1311 ((_ sign_extend 1) ?x1323)))
(let (($x1303 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1311) true)))))
(let (($x1273 (or false $x1303 (or $x1283))))
(let (($x1201 (or $x1273 $x1213 false)))
(let (($x1193 (or $x1201 false false)))
(and (not $x1193) (or $x1193 (and (distinct ?x1181 ?x1181) true))))))))))))))))))))
(check-sat)
; query 280: function gsm_L_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1323 (bvadd in0_64 (_ bv1 64))))
(let ((?x1311 ((_ sign_extend 1) ?x1323)))
(let (($x1303 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1311) true)))))
(and (not $x1303) (or $x1303 (and (distinct ?x1323 ?x1323) true)))))))
(check-sat)
; query 281: function gsm_L_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1116 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x616 (or false false false)))
(let (($x382 (not $x616)))
(and $x382 (or $x616 (and (distinct ?x1116 ?x1116) true)))))))
(check-sat)
; query 282: function gsm_L_asl, block 12, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1126 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x616 (or false false false)))
(let (($x382 (not $x616)))
(and $x382 (or $x616 (and (distinct ?x1126 ?x1126) true)))))))
(check-sat)
; query 283: function gsm_L_asl, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ zero_extend 32) in1_32) ((_ zero_extend 32) in1_32)) true))))))
(check-sat)
; query 284: function gsm_L_asl, block 17, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1134 ((_ zero_extend 32) in1_32)))
(let ((?x1137 (bvshl in0_64 ?x1134)))
(let (($x489 (or false false)))
(let (($x395 (or false $x489 false)))
(let (($x1136 (or $x395 (bvuge ?x1134 (_ bv64 64)))))
(let (($x1145 (not $x1136)))
(and $x1145 (or $x1136 (and (distinct ?x1137 ?x1137) true))))))))))
(check-sat)
; query 285: function gsm_L_asl, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1155 (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x616 (or false false false)))
(let (($x382 (not $x616)))
(and $x382 (or $x616 (and (distinct ?x1155 ?x1155) true)))))))
(check-sat)
; query 286: function gsm_L_asl, block 7, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1116 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1159 ((_ zero_extend 31) ?x1116)))
(let ((?x1168 (bvsub (_ bv0 32) ?x1159)))
(let (($x1169 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1159)) ((_ sign_extend 1) ?x1168)) true)))
(let (($x616 (or false false false)))
(let (($x1164 (or $x616 false)))
(let (($x1175 (or false $x1164 (or $x1169))))
(and (not $x1175) (or $x1175 (and (distinct ?x1168 ?x1168) true)))))))))))
(check-sat)
; query 287: function gsm_L_asl, block 7, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1116 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1159 ((_ zero_extend 31) ?x1116)))
(let ((?x1168 (bvsub (_ bv0 32) ?x1159)))
(let ((?x1176 ((_ sign_extend 32) ?x1168)))
(let (($x1169 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1159)) ((_ sign_extend 1) ?x1168)) true)))
(let (($x616 (or false false false)))
(let (($x1164 (or $x616 false)))
(let (($x1175 (or false $x1164 (or $x1169))))
(let (($x1177 (or $x1175 false)))
(and (not $x1177) (or $x1177 (and (distinct ?x1176 ?x1176) true)))))))))))))
(check-sat)
; query 288: function gsm_L_asl, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1116 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x616 (or false false false)))
(let (($x382 (not $x616)))
(and $x382 (or $x616 (and (distinct ?x1116 ?x1116) true)))))))
(check-sat)
; query 289: function gsm_L_asl, block 7, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1116 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1159 ((_ zero_extend 31) ?x1116)))
(let (($x616 (or false false false)))
(let (($x1164 (or $x616 false)))
(and (not $x1164) (or $x1164 (and (distinct ?x1159 ?x1159) true))))))))
(check-sat)
; query 290: function gsm_L_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1199 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x616 (or false false false)))
(let (($x382 (not $x616)))
(and $x382 (or $x616 (and (distinct ?x1199 ?x1199) true)))))))
(check-sat)
; query 291: function gsm_L_asr, block 12, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1126 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x616 (or false false false)))
(let (($x382 (not $x616)))
(and $x382 (or $x616 (and (distinct ?x1126 ?x1126) true)))))))
(check-sat)
; query 292: function gsm_L_asr, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x1215 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in1_32))) true)))
(let (($x1217 (or false false (or $x1215))))
(and (not $x1217) (or $x1217 (and (distinct (bvsub (_ bv0 32) in1_32) (bvsub (_ bv0 32) in1_32)) true))))))
(check-sat)
; query 293: function gsm_L_asr, block 14, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1214 (bvsub (_ bv0 32) in1_32)))
(let ((?x1218 ((_ zero_extend 32) ?x1214)))
(let (($x1215 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x1214)) true)))
(let (($x1217 (or false false (or $x1215))))
(let (($x1219 (or $x1217 false)))
(and (not $x1219) (or $x1219 (and (distinct ?x1218 ?x1218) true)))))))))
(check-sat)
; query 294: function gsm_L_asr, block 14, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1214 (bvsub (_ bv0 32) in1_32)))
(let ((?x1218 ((_ zero_extend 32) ?x1214)))
(let ((?x1227 (bvshl in0_64 ?x1218)))
(let (($x1215 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x1214)) true)))
(let (($x1217 (or false false (or $x1215))))
(let (($x1219 (or $x1217 false)))
(let (($x1226 (or (or false $x1219 false) (bvuge ?x1218 (_ bv64 64)))))
(and (not $x1226) (or $x1226 (and (distinct ?x1227 ?x1227) true)))))))))))
(check-sat)
; query 295: function gsm_L_asr, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ zero_extend 32) in1_32) ((_ zero_extend 32) in1_32)) true))))))
(check-sat)
; query 296: function gsm_L_asr, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1134 ((_ zero_extend 32) in1_32)))
(let ((?x1248 (bvashr in0_64 ?x1134)))
(let (($x489 (or false false)))
(let (($x395 (or false $x489 false)))
(let (($x1136 (or $x395 (bvuge ?x1134 (_ bv64 64)))))
(let (($x1145 (not $x1136)))
(and $x1145 (or $x1136 (and (distinct ?x1248 ?x1248) true))))))))))
(check-sat)
; query 297: function gsm_L_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1116 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x616 (or false false false)))
(let (($x382 (not $x616)))
(and $x382 (or $x616 (and (distinct ?x1116 ?x1116) true)))))))
(check-sat)
; query 298: function gsm_L_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1116 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1159 ((_ zero_extend 31) ?x1116)))
(let (($x616 (or false false false)))
(let (($x1164 (or $x616 false)))
(and (not $x1164) (or $x1164 (and (distinct ?x1159 ?x1159) true))))))))
(check-sat)
; query 299: function gsm_L_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1116 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1159 ((_ zero_extend 31) ?x1116)))
(let ((?x1168 (bvsub (_ bv0 32) ?x1159)))
(let (($x1169 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1159)) ((_ sign_extend 1) ?x1168)) true)))
(let (($x616 (or false false false)))
(let (($x1164 (or $x616 false)))
(let (($x1175 (or false $x1164 (or $x1169))))
(and (not $x1175) (or $x1175 (and (distinct ?x1168 ?x1168) true)))))))))))
(check-sat)
; query 300: function gsm_L_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1116 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1159 ((_ zero_extend 31) ?x1116)))
(let ((?x1168 (bvsub (_ bv0 32) ?x1159)))
(let ((?x1176 ((_ sign_extend 32) ?x1168)))
(let (($x1169 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1159)) ((_ sign_extend 1) ?x1168)) true)))
(let (($x616 (or false false false)))
(let (($x1164 (or $x616 false)))
(let (($x1175 (or false $x1164 (or $x1169))))
(let (($x1177 (or $x1175 false)))
(and (not $x1177) (or $x1177 (and (distinct ?x1176 ?x1176) true)))))))))))))
(check-sat)
; query 301: function gsm_L_asr, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1155 (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x616 (or false false false)))
(let (($x382 (not $x616)))
(and $x382 (or $x616 (and (distinct ?x1155 ?x1155) true)))))))
(check-sat)
; query 302: function gsm_L_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1199 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x616 (or false false false)))
(let (($x382 (not $x616)))
(and $x382 (or $x616 (and (distinct ?x1199 ?x1199) true)))))))
(check-sat)
; query 303: function gsm_L_mult, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 304: function gsm_L_mult, block 17, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 305: function gsm_L_mult, block 17, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1257 ((_ sign_extend 48) in1_16)))
(let ((?x1256 ((_ sign_extend 48) in0_16)))
(let ((?x1267 (bvmul ?x1256 ?x1257)))
(let (($x1265 (and (distinct (bvmul ((_ sign_extend 64) ?x1256) ((_ sign_extend 64) ?x1257)) ((_ sign_extend 64) ?x1267)) true)))
(let (($x489 (or false false)))
(let (($x1269 (or $x489 $x489 (or $x1265))))
(and (not $x1269) (or $x1269 (and (distinct ?x1267 ?x1267) true))))))))))
(check-sat)
; query 306: function gsm_L_mult, block 17, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1257 ((_ sign_extend 48) in1_16)))
(let ((?x1256 ((_ sign_extend 48) in0_16)))
(let ((?x1267 (bvmul ?x1256 ?x1257)))
(let ((?x1276 (bvshl ?x1267 (_ bv1 64))))
(let (($x2083 (bvuge (_ bv1 64) (_ bv64 64))))
(let (($x1265 (and (distinct (bvmul ((_ sign_extend 64) ?x1256) ((_ sign_extend 64) ?x1257)) ((_ sign_extend 64) ?x1267)) true)))
(let (($x489 (or false false)))
(let (($x1269 (or $x489 $x489 (or $x1265))))
(let (($x1275 (or $x1269 false false)))
(let (($x1274 (or $x1275 $x2083)))
(and (not $x1274) (or $x1274 (and (distinct ?x1276 ?x1276) true))))))))))))))
(check-sat)
; query 307: function gsm_L_mult, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 308: function gsm_L_mult, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1304 (ite (and (distinct (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) true) (_ bv1 1) (_ bv0 1))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x39 (not $x309)))
(and $x39 (or $x309 (and (distinct ?x1304 ?x1304) true))))))))
(check-sat)
; query 309: function gsm_L_mult, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 310: function gsm_L_mult, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1309 (ite (and (distinct (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) true) (_ bv1 1) (_ bv0 1))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x39 (not $x309)))
(and $x39 (or $x309 (and (distinct ?x1309 ?x1309) true))))))))
(check-sat)
; query 311: function gsm_L_sub, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in11_64 () (_ BitVec 64))
(assert
 (let (($x616 (or false false false)))
(let (($x382 (not $x616)))
(and $x382 (or $x616 (and (distinct (bvadd in11_64 (_ bv1 64)) (bvadd in11_64 (_ bv1 64))) true))))))
(check-sat)
; query 312: function gsm_L_sub, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x940 (ite (bvsge (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x616 (or false false false)))
(let (($x382 (not $x616)))
(and $x382 (or $x616 (and (distinct ?x940 ?x940) true)))))))
(check-sat)
; query 313: function gsm_L_sub, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x1328 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvsub in0_64 in1_64))) true)))
(let (($x1335 (or false false (or $x1328))))
(let (($x1338 (or $x1335 (and (distinct (bvsub in0_64 in1_64) (bvsub in0_64 in1_64)) true))))
(and (not $x1335) $x1338)))))
(check-sat)
; query 314: function gsm_L_sub, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1323 (bvadd in0_64 (_ bv1 64))))
(let ((?x1311 ((_ sign_extend 1) ?x1323)))
(let (($x1303 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1311) true)))))
(and (not $x1303) (or $x1303 (and (distinct ?x1323 ?x1323) true)))))))
(check-sat)
; query 315: function gsm_L_sub, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1323 (bvadd in0_64 (_ bv1 64))))
(let ((?x1281 (bvsub (_ bv0 64) ?x1323)))
(let (($x1283 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1323)) ((_ sign_extend 1) ?x1281)) true)))
(let ((?x1311 ((_ sign_extend 1) ?x1323)))
(let (($x1303 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1311) true)))))
(let (($x1273 (or false $x1303 (or $x1283))))
(and (not $x1273) (or $x1273 (and (distinct ?x1281 ?x1281) true))))))))))
(check-sat)
; query 316: function gsm_L_sub, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1323 (bvadd in0_64 (_ bv1 64))))
(let ((?x1281 (bvsub (_ bv0 64) ?x1323)))
(let ((?x1344 (bvadd ?x1281 in1_64)))
(let (($x1283 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1323)) ((_ sign_extend 1) ?x1281)) true)))
(let ((?x1311 ((_ sign_extend 1) ?x1323)))
(let (($x1303 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1311) true)))))
(let (($x1273 (or false $x1303 (or $x1283))))
(let (($x1345 (or $x1273 false false)))
(and (not $x1345) (or $x1345 (and (distinct ?x1344 ?x1344) true))))))))))))
(check-sat)
; query 317: function gsm_L_sub, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1348 (ite (bvuge (bvadd (bvsub (_ bv0 64) (bvadd in0_64 (_ bv1 64))) in1_64) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x1283 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) (bvadd in0_64 (_ bv1 64)))) ((_ sign_extend 1) (bvsub (_ bv0 64) (bvadd in0_64 (_ bv1 64))))) true)))
(let ((?x1323 (bvadd in0_64 (_ bv1 64))))
(let ((?x1311 ((_ sign_extend 1) ?x1323)))
(let (($x1303 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1311) true)))))
(let (($x1273 (or false $x1303 (or $x1283))))
(let (($x1345 (or $x1273 false false)))
(let (($x1347 (or $x1345 false false)))
(and (not $x1347) (or $x1347 (and (distinct ?x1348 ?x1348) true))))))))))))
(check-sat)
; query 318: function gsm_L_sub, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_64 () (_ BitVec 64))
(assert
 (let ((?x1369 (bvsub (_ bv0 64) in25_64)))
(let ((?x1367 ((_ sign_extend 1) ?x1369)))
(let (($x1376 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in25_64)) ?x1367) true)))))
(and (not $x1376) (or $x1376 (and (distinct ?x1369 ?x1369) true)))))))
(check-sat)
; query 319: function gsm_L_sub, block 28, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_64 () (_ BitVec 64))
(assert
 (let ((?x1369 (bvsub (_ bv0 64) in25_64)))
(let ((?x1379 (bvsub ?x1369 (_ bv1 64))))
(let (($x1384 (and (distinct (bvsub ((_ sign_extend 1) ?x1369) ((_ sign_extend 1) (_ bv1 64))) ((_ sign_extend 1) ?x1379)) true)))
(let ((?x1367 ((_ sign_extend 1) ?x1369)))
(let (($x1376 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in25_64)) ?x1367) true)))))
(let (($x1386 (or $x1376 false (or $x1384))))
(and (not $x1386) (or $x1386 (and (distinct ?x1379 ?x1379) true))))))))))
(check-sat)
; query 320: function gsm_L_sub, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1341 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x616 (or false false false)))
(let (($x382 (not $x616)))
(and $x382 (or $x616 (and (distinct ?x1341 ?x1341) true)))))))
(check-sat)
; query 321: function gsm_L_sub, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x1328 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvsub in0_64 in1_64))) true)))
(let (($x1335 (or false false (or $x1328))))
(let (($x1338 (or $x1335 (and (distinct (bvsub in0_64 in1_64) (bvsub in0_64 in1_64)) true))))
(and (not $x1335) $x1338)))))
(check-sat)
; query 322: function gsm_L_sub, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1263 (bvadd in1_64 (_ bv1 64))))
(let ((?x1221 (bvsub (_ bv0 64) ?x1263)))
(let (($x1223 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1263)) ((_ sign_extend 1) ?x1221)) true)))
(let ((?x1251 ((_ sign_extend 1) ?x1263)))
(let (($x1243 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1251) true)))))
(let (($x1213 (or false $x1243 (or $x1223))))
(and (not $x1213) (or $x1213 (and (distinct ?x1221 ?x1221) true))))))))))
(check-sat)
; query 323: function gsm_L_sub, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1263 (bvadd in1_64 (_ bv1 64))))
(let ((?x1221 (bvsub (_ bv0 64) ?x1263)))
(let ((?x1400 (bvadd in0_64 ?x1221)))
(let (($x1223 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1263)) ((_ sign_extend 1) ?x1221)) true)))
(let ((?x1251 ((_ sign_extend 1) ?x1263)))
(let (($x1243 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1251) true)))))
(let (($x1213 (or false $x1243 (or $x1223))))
(let (($x1406 (or false $x1213 false)))
(and (not $x1406) (or $x1406 (and (distinct ?x1400 ?x1400) true))))))))))))
(check-sat)
; query 324: function gsm_L_sub, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1409 (ite (bvuge (bvadd in0_64 (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64)))) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x1223 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) (bvadd in1_64 (_ bv1 64)))) ((_ sign_extend 1) (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64))))) true)))
(let ((?x1263 (bvadd in1_64 (_ bv1 64))))
(let ((?x1251 ((_ sign_extend 1) ?x1263)))
(let (($x1243 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1251) true)))))
(let (($x1213 (or false $x1243 (or $x1223))))
(let (($x1406 (or false $x1213 false)))
(let (($x1408 (or $x1406 false false)))
(and (not $x1408) (or $x1408 (and (distinct ?x1409 ?x1409) true))))))))))))
(check-sat)
; query 325: function gsm_L_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1263 (bvadd in1_64 (_ bv1 64))))
(let ((?x1251 ((_ sign_extend 1) ?x1263)))
(let (($x1243 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1251) true)))))
(and (not $x1243) (or $x1243 (and (distinct ?x1263 ?x1263) true)))))))
(check-sat)
; query 326: function gsm_L_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x535 (ite (bvsle (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x616 (or false false false)))
(let (($x382 (not $x616)))
(and $x382 (or $x616 (and (distinct ?x535 ?x535) true)))))))
(check-sat)
; query 327: function gsm_abs, block 13, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 328: function gsm_abs, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 329: function gsm_abs, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x447 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x39 (not $x309)))
(and $x39 (or $x309 (and (distinct ?x447 ?x447) true))))))))
(check-sat)
; query 330: function gsm_abs, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1991 ((_ sign_extend 16) in0_16)))
(let ((?x533 (bvsub (_ bv0 32) ?x1991)))
(let (($x242 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1991)) ((_ sign_extend 1) ?x533)) true)))
(let (($x489 (or false false)))
(let (($x291 (or false $x489 (or $x242))))
(and (not $x291) (or $x291 (and (distinct ?x533 ?x533) true)))))))))
(check-sat)
; query 331: function gsm_abs, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 332: function gsm_abs, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 333: function gsm_abs, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x902 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x39 (not $x309)))
(and $x39 (or $x309 (and (distinct ?x902 ?x902) true))))))))
(check-sat)
; query 334: function gsm_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_64 () (_ BitVec 64))
(assert
 (let ((?x678 (ite (bvslt (_ bv32767 64) in5_64) (_ bv1 1) (_ bv0 1))))
(let (($x616 (or false false false)))
(let (($x382 (not $x616)))
(and $x382 (or $x616 (and (distinct ?x678 ?x678) true)))))))
(check-sat)
; query 335: function gsm_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 336: function gsm_add, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 337: function gsm_add, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1257 ((_ sign_extend 48) in1_16)))
(let ((?x1256 ((_ sign_extend 48) in0_16)))
(let ((?x316 (bvadd ?x1256 ?x1257)))
(let (($x169 (and (distinct (bvadd ((_ sign_extend 1) ?x1256) ((_ sign_extend 1) ?x1257)) ((_ sign_extend 1) ?x316)) true)))
(let (($x489 (or false false)))
(let (($x646 (or $x489 $x489 (or $x169))))
(and (not $x646) (or $x646 (and (distinct ?x316 ?x316) true))))))))))
(check-sat)
; query 338: function gsm_add, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x443 (ite (bvsgt (_ bv18446744073709518848 64) (bvadd ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x1257 ((_ sign_extend 48) in1_16)))
(let ((?x667 ((_ sign_extend 1) ?x1257)))
(let ((?x1256 ((_ sign_extend 48) in0_16)))
(let ((?x556 ((_ sign_extend 1) ?x1256)))
(let (($x489 (or false false)))
(let (($x646 (or $x489 $x489 (or (and (distinct (bvadd ?x556 ?x667) ((_ sign_extend 1) (bvadd ?x1256 ?x1257))) true)))))
(let (($x578 (or $x646 false false)))
(and (not $x578) (or $x578 (and (distinct ?x443 ?x443) true))))))))))))
(check-sat)
; query 339: function gsm_asl, block 13, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1126 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x616 (or false false false)))
(let (($x382 (not $x616)))
(and $x382 (or $x616 (and (distinct ?x1126 ?x1126) true)))))))
(check-sat)
; query 340: function gsm_asl, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 341: function gsm_asl, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1991 ((_ sign_extend 16) in0_16)))
(let ((?x742 (bvshl ?x1991 in1_32)))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x564 (or $x309 (bvuge in1_32 (_ bv32 32)))))
(let (($x299 (not $x564)))
(and $x299 (or $x564 (and (distinct ?x742 ?x742) true))))))))))
(check-sat)
; query 342: function gsm_asl, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1991 ((_ sign_extend 16) in0_16)))
(let ((?x742 (bvshl ?x1991 in1_32)))
(let ((?x407 ((_ extract 15 0) ?x742)))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x564 (or $x309 (bvuge in1_32 (_ bv32 32)))))
(let (($x820 (or $x564 false)))
(let (($x780 (not $x820)))
(and $x780 (or $x820 (and (distinct ?x407 ?x407) true))))))))))))
(check-sat)
; query 343: function gsm_asl, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x306 (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x616 (or false false false)))
(let (($x382 (not $x616)))
(and $x382 (or $x616 (and (distinct ?x306 ?x306) true)))))))
(check-sat)
; query 344: function gsm_asl, block 7, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x902 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x614 ((_ zero_extend 31) ?x902)))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x653 (or $x309 false)))
(and (not $x653) (or $x653 (and (distinct ?x614 ?x614) true)))))))))
(check-sat)
; query 345: function gsm_asl, block 7, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x902 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x614 ((_ zero_extend 31) ?x902)))
(let ((?x511 (bvsub (_ bv0 32) ?x614)))
(let (($x398 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x614)) ((_ sign_extend 1) ?x511)) true)))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x653 (or $x309 false)))
(let (($x442 (or false $x653 (or $x398))))
(and (not $x442) (or $x442 (and (distinct ?x511 ?x511) true))))))))))))
(check-sat)
; query 346: function gsm_asl, block 7, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x902 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x614 ((_ zero_extend 31) ?x902)))
(let ((?x511 (bvsub (_ bv0 32) ?x614)))
(let ((?x598 ((_ extract 15 0) ?x511)))
(let (($x398 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x614)) ((_ sign_extend 1) ?x511)) true)))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x653 (or $x309 false)))
(let (($x442 (or false $x653 (or $x398))))
(let (($x731 (or $x442 false)))
(and (not $x731) (or $x731 (and (distinct ?x598 ?x598) true))))))))))))))
(check-sat)
; query 347: function gsm_asl, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 348: function gsm_asl, block 7, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x902 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x39 (not $x309)))
(and $x39 (or $x309 (and (distinct ?x902 ?x902) true))))))))
(check-sat)
; query 349: function gsm_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x893 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x616 (or false false false)))
(let (($x382 (not $x616)))
(and $x382 (or $x616 (and (distinct ?x893 ?x893) true)))))))
(check-sat)
; query 350: function gsm_asr, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x306 (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x616 (or false false false)))
(let (($x382 (not $x616)))
(and $x382 (or $x616 (and (distinct ?x306 ?x306) true)))))))
(check-sat)
; query 351: function gsm_asr, block 13, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1126 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x616 (or false false false)))
(let (($x382 (not $x616)))
(and $x382 (or $x616 (and (distinct ?x1126 ?x1126) true)))))))
(check-sat)
; query 352: function gsm_asr, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 353: function gsm_asr, block 15, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x1215 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in1_32))) true)))
(let (($x1217 (or false false (or $x1215))))
(and (not $x1217) (or $x1217 (and (distinct (bvsub (_ bv0 32) in1_32) (bvsub (_ bv0 32) in1_32)) true))))))
(check-sat)
; query 354: function gsm_asr, block 15, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1214 (bvsub (_ bv0 32) in1_32)))
(let ((?x1991 ((_ sign_extend 16) in0_16)))
(let ((?x844 (bvshl ?x1991 ?x1214)))
(let (($x1215 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x1214)) true)))
(let (($x1217 (or false false (or $x1215))))
(let (($x489 (or false false)))
(let (($x522 (or (or $x489 $x1217 false) (bvuge ?x1214 (_ bv32 32)))))
(and (not $x522) (or $x522 (and (distinct ?x844 ?x844) true)))))))))))
(check-sat)
; query 355: function gsm_asr, block 15, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1214 (bvsub (_ bv0 32) in1_32)))
(let ((?x1991 ((_ sign_extend 16) in0_16)))
(let ((?x844 (bvshl ?x1991 ?x1214)))
(let ((?x695 ((_ extract 15 0) ?x844)))
(let (($x1215 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x1214)) true)))
(let (($x1217 (or false false (or $x1215))))
(let (($x489 (or false false)))
(let (($x522 (or (or $x489 $x1217 false) (bvuge ?x1214 (_ bv32 32)))))
(let (($x798 (or $x522 false)))
(and (not $x798) (or $x798 (and (distinct ?x695 ?x695) true)))))))))))))
(check-sat)
; query 356: function gsm_asr, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 357: function gsm_asr, block 20, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1991 ((_ sign_extend 16) in0_16)))
(let ((?x647 (bvashr ?x1991 in1_32)))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x564 (or $x309 (bvuge in1_32 (_ bv32 32)))))
(let (($x299 (not $x564)))
(and $x299 (or $x564 (and (distinct ?x647 ?x647) true))))))))))
(check-sat)
; query 358: function gsm_asr, block 20, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1991 ((_ sign_extend 16) in0_16)))
(let ((?x647 (bvashr ?x1991 in1_32)))
(let ((?x744 ((_ extract 15 0) ?x647)))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x564 (or $x309 (bvuge in1_32 (_ bv32 32)))))
(let (($x820 (or $x564 false)))
(let (($x780 (not $x820)))
(and $x780 (or $x820 (and (distinct ?x744 ?x744) true))))))))))))
(check-sat)
; query 359: function gsm_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 360: function gsm_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x902 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x39 (not $x309)))
(and $x39 (or $x309 (and (distinct ?x902 ?x902) true))))))))
(check-sat)
; query 361: function gsm_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x902 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x614 ((_ zero_extend 31) ?x902)))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x653 (or $x309 false)))
(and (not $x653) (or $x653 (and (distinct ?x614 ?x614) true)))))))))
(check-sat)
; query 362: function gsm_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x902 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x614 ((_ zero_extend 31) ?x902)))
(let ((?x511 (bvsub (_ bv0 32) ?x614)))
(let (($x398 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x614)) ((_ sign_extend 1) ?x511)) true)))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x653 (or $x309 false)))
(let (($x442 (or false $x653 (or $x398))))
(and (not $x442) (or $x442 (and (distinct ?x511 ?x511) true))))))))))))
(check-sat)
; query 363: function gsm_asr, block 4, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x902 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x614 ((_ zero_extend 31) ?x902)))
(let ((?x511 (bvsub (_ bv0 32) ?x614)))
(let ((?x598 ((_ extract 15 0) ?x511)))
(let (($x398 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x614)) ((_ sign_extend 1) ?x511)) true)))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x653 (or $x309 false)))
(let (($x442 (or false $x653 (or $x398))))
(let (($x731 (or $x442 false)))
(and (not $x731) (or $x731 (and (distinct ?x598 ?x598) true))))))))))))))
(check-sat)
; query 364: function gsm_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x893 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x616 (or false false false)))
(let (($x382 (not $x616)))
(and $x382 (or $x616 (and (distinct ?x893 ?x893) true)))))))
(check-sat)
; query 365: function gsm_debug_longwords, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in15_32 () (_ BitVec 32))
(assert
 (let ((?x465 (ite (bvslt in15_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x616 (or false false false)))
(let (($x382 (not $x616)))
(and $x382 (or $x616 (and (distinct ?x465 ?x465) true)))))))
(check-sat)
; query 366: function gsm_debug_words, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in16_32 () (_ BitVec 32))
(assert
 (let ((?x606 (ite (bvslt in16_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x616 (or false false false)))
(let (($x382 (not $x616)))
(and $x382 (or $x616 (and (distinct ?x606 ?x606) true)))))))
(check-sat)
; query 367: function gsm_div, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 368: function gsm_div, block 20, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x526 (ite (= (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x39 (not $x309)))
(and $x39 (or $x309 (and (distinct ?x526 ?x526) true))))))))
(check-sat)
; query 369: function gsm_div, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in.02_16) ((_ sign_extend 16) in.02_16)) true))))))
(check-sat)
; query 370: function gsm_div, block 28, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x1963 ((_ sign_extend 16) in.02_16)))
(let ((?x662 (bvshl ?x1963 (_ bv1 32))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x166 (or $x309 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x776 (not $x166)))
(and $x776 (or $x166 (and (distinct ?x662 ?x662) true))))))))))
(check-sat)
; query 371: function gsm_div, block 28, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x1963 ((_ sign_extend 16) in.02_16)))
(let ((?x662 (bvshl ?x1963 (_ bv1 32))))
(let ((?x992 ((_ extract 15 0) ?x662)))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x166 (or $x309 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x1120 (or $x166 false)))
(let (($x947 (not $x1120)))
(and $x947 (or $x1120 (and (distinct ?x992 ?x992) true))))))))))))
(check-sat)
; query 372: function gsm_div, block 28, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_64 () (_ BitVec 64))
(assert
 (let (($x2083 (bvuge (_ bv1 64) (_ bv64 64))))
(let (($x616 (or false false false)))
(let (($x2088 (or $x616 $x2083)))
(let (($x766 (not $x2088)))
(and $x766 (or $x2088 (and (distinct (bvshl in.03_64 (_ bv1 64)) (bvshl in.03_64 (_ bv1 64))) true))))))))
(check-sat)
; query 373: function gsm_div, block 28, name %33
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_64 () (_ BitVec 64))
(declare-fun in.03_64 () (_ BitVec 64))
(assert
 (let ((?x444 (ite (bvsge (bvshl in.03_64 (_ bv1 64)) in4_64) (_ bv1 1) (_ bv0 1))))
(let (($x2083 (bvuge (_ bv1 64) (_ bv64 64))))
(let (($x616 (or false false false)))
(let (($x2088 (or $x616 $x2083)))
(let (($x265 (or $x2088 false false)))
(and (not $x265) (or $x265 (and (distinct ?x444 ?x444) true)))))))))
(check-sat)
; query 374: function gsm_div, block 34, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_64 () (_ BitVec 64))
(declare-fun in32_64 () (_ BitVec 64))
(assert
 (let (($x904 (and (distinct (bvsub ((_ sign_extend 1) in32_64) ((_ sign_extend 1) in4_64)) ((_ sign_extend 1) (bvsub in32_64 in4_64))) true)))
(let (($x514 (or false false (or $x904))))
(let (($x623 (or $x514 (and (distinct (bvsub in32_64 in4_64) (bvsub in32_64 in4_64)) true))))
(and (not $x514) $x623)))))
(check-sat)
; query 375: function gsm_div, block 34, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in31_16 () (_ BitVec 16))
(assert
 (let (($x616 (or false false false)))
(let (($x382 (not $x616)))
(and $x382 (or $x616 (and (distinct (bvadd in31_16 (_ bv1 16)) (bvadd in31_16 (_ bv1 16))) true))))))
(check-sat)
; query 376: function gsm_div, block 7, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x402 (ite (bvsge ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x489 (or false false)))
(let (($x658 (or $x489 $x489 false)))
(and (not $x658) (or $x658 (and (distinct ?x402 ?x402) true)))))))
(check-sat)
; query 377: function gsm_div, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 378: function gsm_div, block 7, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 379: function gsm_div, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 380: function gsm_div, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 381: function gsm_div, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 382: function gsm_div, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x537 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x643 (and (distinct ?x537 ?x537) true)))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x39 (not $x309)))
(and $x39 (or $x309 $x643))))))))
(check-sat)
; query 383: function gsm_mult, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 384: function gsm_mult, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x781 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x39 (not $x309)))
(and $x39 (or $x309 (and (distinct ?x781 ?x781) true))))))))
(check-sat)
; query 385: function gsm_mult, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 386: function gsm_mult, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 387: function gsm_mult, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1257 ((_ sign_extend 48) in1_16)))
(let ((?x1256 ((_ sign_extend 48) in0_16)))
(let ((?x1267 (bvmul ?x1256 ?x1257)))
(let (($x1265 (and (distinct (bvmul ((_ sign_extend 64) ?x1256) ((_ sign_extend 64) ?x1257)) ((_ sign_extend 64) ?x1267)) true)))
(let (($x489 (or false false)))
(let (($x1269 (or $x489 $x489 (or $x1265))))
(and (not $x1269) (or $x1269 (and (distinct ?x1267 ?x1267) true))))))))))
(check-sat)
; query 388: function gsm_mult, block 9, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1257 ((_ sign_extend 48) in1_16)))
(let ((?x1256 ((_ sign_extend 48) in0_16)))
(let ((?x1267 (bvmul ?x1256 ?x1257)))
(let ((?x890 (bvashr ?x1267 (_ bv15 64))))
(let (($x509 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1265 (and (distinct (bvmul ((_ sign_extend 64) ?x1256) ((_ sign_extend 64) ?x1257)) ((_ sign_extend 64) ?x1267)) true)))
(let (($x489 (or false false)))
(let (($x1269 (or $x489 $x489 (or $x1265))))
(let (($x1275 (or $x1269 false false)))
(let (($x750 (or $x1275 $x509)))
(and (not $x750) (or $x750 (and (distinct ?x890 ?x890) true))))))))))))))
(check-sat)
; query 389: function gsm_mult, block 9, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1257 ((_ sign_extend 48) in1_16)))
(let ((?x1256 ((_ sign_extend 48) in0_16)))
(let ((?x1267 (bvmul ?x1256 ?x1257)))
(let ((?x890 (bvashr ?x1267 (_ bv15 64))))
(let ((?x763 ((_ extract 15 0) ?x890)))
(let (($x509 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1265 (and (distinct (bvmul ((_ sign_extend 64) ?x1256) ((_ sign_extend 64) ?x1257)) ((_ sign_extend 64) ?x1267)) true)))
(let (($x489 (or false false)))
(let (($x1269 (or $x489 $x489 (or $x1265))))
(let (($x1275 (or $x1269 false false)))
(let (($x750 (or $x1275 $x509)))
(let (($x222 (or $x750 false)))
(and (not $x222) (or $x222 (and (distinct ?x763 ?x763) true))))))))))))))))
(check-sat)
; query 390: function gsm_mult, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 391: function gsm_mult, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x447 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x39 (not $x309)))
(and $x39 (or $x309 (and (distinct ?x447 ?x447) true))))))))
(check-sat)
; query 392: function gsm_mult_r, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 393: function gsm_mult_r, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x447 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x39 (not $x309)))
(and $x39 (or $x309 (and (distinct ?x447 ?x447) true))))))))
(check-sat)
; query 394: function gsm_mult_r, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 395: function gsm_mult_r, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 396: function gsm_mult_r, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1257 ((_ sign_extend 48) in1_16)))
(let ((?x1256 ((_ sign_extend 48) in0_16)))
(let ((?x1267 (bvmul ?x1256 ?x1257)))
(let (($x1265 (and (distinct (bvmul ((_ sign_extend 64) ?x1256) ((_ sign_extend 64) ?x1257)) ((_ sign_extend 64) ?x1267)) true)))
(let (($x489 (or false false)))
(let (($x1269 (or $x489 $x489 (or $x1265))))
(and (not $x1269) (or $x1269 (and (distinct ?x1267 ?x1267) true))))))))))
(check-sat)
; query 397: function gsm_mult_r, block 9, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1257 ((_ sign_extend 48) in1_16)))
(let ((?x1256 ((_ sign_extend 48) in0_16)))
(let ((?x1267 (bvmul ?x1256 ?x1257)))
(let ((?x819 (bvadd ?x1267 (_ bv16384 64))))
(let (($x284 (and (distinct (bvadd ((_ sign_extend 1) ?x1267) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x819)) true)))
(let (($x1265 (and (distinct (bvmul ((_ sign_extend 64) ?x1256) ((_ sign_extend 64) ?x1257)) ((_ sign_extend 64) ?x1267)) true)))
(let (($x489 (or false false)))
(let (($x1269 (or $x489 $x489 (or $x1265))))
(let (($x615 (or $x1269 false (or $x284))))
(and (not $x615) (or $x615 (and (distinct ?x819 ?x819) true)))))))))))))
(check-sat)
; query 398: function gsm_mult_r, block 9, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1257 ((_ sign_extend 48) in1_16)))
(let ((?x1256 ((_ sign_extend 48) in0_16)))
(let ((?x1267 (bvmul ?x1256 ?x1257)))
(let ((?x819 (bvadd ?x1267 (_ bv16384 64))))
(let ((?x57 (bvashr ?x819 (_ bv15 64))))
(let (($x509 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x284 (and (distinct (bvadd ((_ sign_extend 1) ?x1267) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x819)) true)))
(let (($x1265 (and (distinct (bvmul ((_ sign_extend 64) ?x1256) ((_ sign_extend 64) ?x1257)) ((_ sign_extend 64) ?x1267)) true)))
(let (($x489 (or false false)))
(let (($x1269 (or $x489 $x489 (or $x1265))))
(let (($x615 (or $x1269 false (or $x284))))
(let (($x654 (or (or $x615 false false) $x509)))
(and (not $x654) (or $x654 (and (distinct ?x57 ?x57) true))))))))))))))))
(check-sat)
; query 399: function gsm_mult_r, block 9, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1257 ((_ sign_extend 48) in1_16)))
(let ((?x1256 ((_ sign_extend 48) in0_16)))
(let ((?x1267 (bvmul ?x1256 ?x1257)))
(let ((?x819 (bvadd ?x1267 (_ bv16384 64))))
(let ((?x57 (bvashr ?x819 (_ bv15 64))))
(let ((?x471 (bvand ?x57 (_ bv65535 64))))
(let (($x509 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x284 (and (distinct (bvadd ((_ sign_extend 1) ?x1267) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x819)) true)))
(let (($x1265 (and (distinct (bvmul ((_ sign_extend 64) ?x1256) ((_ sign_extend 64) ?x1257)) ((_ sign_extend 64) ?x1267)) true)))
(let (($x489 (or false false)))
(let (($x1269 (or $x489 $x489 (or $x1265))))
(let (($x615 (or $x1269 false (or $x284))))
(let (($x654 (or (or $x615 false false) $x509)))
(let (($x768 (or $x654 false false)))
(and (not $x768) (or $x768 (and (distinct ?x471 ?x471) true))))))))))))))))))
(check-sat)
; query 400: function gsm_mult_r, block 9, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1257 ((_ sign_extend 48) in1_16)))
(let ((?x1256 ((_ sign_extend 48) in0_16)))
(let ((?x1267 (bvmul ?x1256 ?x1257)))
(let ((?x819 (bvadd ?x1267 (_ bv16384 64))))
(let ((?x57 (bvashr ?x819 (_ bv15 64))))
(let ((?x471 (bvand ?x57 (_ bv65535 64))))
(let ((?x505 ((_ extract 15 0) ?x471)))
(let (($x509 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x284 (and (distinct (bvadd ((_ sign_extend 1) ?x1267) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x819)) true)))
(let (($x1265 (and (distinct (bvmul ((_ sign_extend 64) ?x1256) ((_ sign_extend 64) ?x1257)) ((_ sign_extend 64) ?x1267)) true)))
(let (($x489 (or false false)))
(let (($x1269 (or $x489 $x489 (or $x1265))))
(let (($x615 (or $x1269 false (or $x284))))
(let (($x654 (or (or $x615 false false) $x509)))
(let (($x768 (or $x654 false false)))
(let (($x772 (or $x768 false)))
(and (not $x772) (or $x772 (and (distinct ?x505 ?x505) true))))))))))))))))))))
(check-sat)
; query 401: function gsm_mult_r, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 402: function gsm_mult_r, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x781 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x39 (not $x309)))
(and $x39 (or $x309 (and (distinct ?x781 ?x781) true))))))))
(check-sat)
; query 403: function gsm_norm, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1116 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x616 (or false false false)))
(let (($x382 (not $x616)))
(and $x382 (or $x616 (and (distinct ?x1116 ?x1116) true)))))))
(check-sat)
; query 404: function gsm_norm, block 12, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x551 (ite (bvsge (_ bv18446744072635809792 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x616 (or false false false)))
(let (($x382 (not $x616)))
(and $x382 (or $x616 (and (distinct ?x551 ?x551) true)))))))
(check-sat)
; query 405: function gsm_norm, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x616 (or false false false)))
(let (($x382 (not $x616)))
(and $x382 (or $x616 (and (distinct (bvxor in0_64 (_ bv18446744073709551615 64)) (bvxor in0_64 (_ bv18446744073709551615 64))) true))))))
(check-sat)
; query 406: function gsm_norm, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_64 () (_ BitVec 64))
(assert
 (let (($x616 (or false false false)))
(let (($x382 (not $x616)))
(and $x382 (or $x616 (and (distinct (bvand in.01_64 (_ bv4278190080 64)) (bvand in.01_64 (_ bv4278190080 64))) true))))))
(check-sat)
; query 407: function gsm_norm, block 20, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_64 () (_ BitVec 64))
(assert
 (let ((?x531 (ite (and (distinct (_ bv0 64) (bvand in.01_64 (_ bv4278190080 64))) true) (_ bv1 1) (_ bv0 1))))
(let (($x616 (or false false false)))
(let (($x671 (or $x616 false false)))
(let (($x1530 (not $x671)))
(and $x1530 (or $x671 (and (distinct ?x531 ?x531) true))))))))
(check-sat)
; query 408: function gsm_norm, block 39, name %40
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_64 () (_ BitVec 64))
(assert
 (let (($x616 (or false false false)))
(let (($x382 (not $x616)))
(and $x382 (or $x616 (and (distinct (bvand in.01_64 (_ bv65280 64)) (bvand in.01_64 (_ bv65280 64))) true))))))
(check-sat)
; query 409: function gsm_norm, block 39, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_64 () (_ BitVec 64))
(assert
 (let ((?x875 (ite (and (distinct (_ bv0 64) (bvand in.01_64 (_ bv65280 64))) true) (_ bv1 1) (_ bv0 1))))
(let (($x616 (or false false false)))
(let (($x671 (or $x616 false false)))
(let (($x1530 (not $x671)))
(and $x1530 (or $x671 (and (distinct ?x875 ?x875) true))))))))
(check-sat)
; query 410: function gsm_norm, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x211 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x616 (or false false false)))
(let (($x382 (not $x616)))
(and $x382 (or $x616 (and (distinct ?x211 ?x211) true)))))))
(check-sat)
; query 411: function gsm_norm, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x211 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x644 (bvxor ?x211 (_ bv1 1))))
(let (($x616 (or false false false)))
(let (($x671 (or $x616 false false)))
(let (($x1530 (not $x671)))
(and $x1530 (or $x671 (and (distinct ?x644 ?x644) true)))))))))
(check-sat)
; query 412: function gsm_norm, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x211 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x644 (bvxor ?x211 (_ bv1 1))))
(let ((?x482 ((_ zero_extend 31) ?x644)))
(let (($x616 (or false false false)))
(let (($x671 (or $x616 false false)))
(let (($x523 (or $x671 false)))
(and (not $x523) (or $x523 (and (distinct ?x482 ?x482) true))))))))))
(check-sat)
; query 413: function gsm_norm, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x211 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x644 (bvxor ?x211 (_ bv1 1))))
(let ((?x482 ((_ zero_extend 31) ?x644)))
(let ((?x832 ((_ sign_extend 32) ?x482)))
(let (($x616 (or false false false)))
(let (($x671 (or $x616 false false)))
(let (($x523 (or $x671 false)))
(let (($x941 (or $x523 false)))
(and (not $x941) (or $x941 (and (distinct ?x832 ?x832) true))))))))))))
(check-sat)
; query 414: function gsm_norm, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x211 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x644 (bvxor ?x211 (_ bv1 1))))
(let ((?x482 ((_ zero_extend 31) ?x644)))
(let ((?x832 ((_ sign_extend 32) ?x482)))
(let ((?x327 (ite (and (distinct (_ bv0 64) ?x832) true) (_ bv1 1) (_ bv0 1))))
(let (($x616 (or false false false)))
(let (($x671 (or $x616 false false)))
(let (($x523 (or $x671 false)))
(let (($x941 (or $x523 false)))
(let (($x585 (or $x941 false false)))
(and (not $x585) (or $x585 (and (distinct ?x327 ?x327) true))))))))))))))
(check-sat)
; query 415: function gsm_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_64 () (_ BitVec 64))
(assert
 (let ((?x678 (ite (bvslt (_ bv32767 64) in5_64) (_ bv1 1) (_ bv0 1))))
(let (($x616 (or false false false)))
(let (($x382 (not $x616)))
(and $x382 (or $x616 (and (distinct ?x678 ?x678) true)))))))
(check-sat)
; query 416: function gsm_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 417: function gsm_sub, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 418: function gsm_sub, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1257 ((_ sign_extend 48) in1_16)))
(let ((?x1256 ((_ sign_extend 48) in0_16)))
(let ((?x2030 (bvsub ?x1256 ?x1257)))
(let (($x2010 (and (distinct (bvsub ((_ sign_extend 1) ?x1256) ((_ sign_extend 1) ?x1257)) ((_ sign_extend 1) ?x2030)) true)))
(let (($x489 (or false false)))
(let (($x1990 (or $x489 $x489 (or $x2010))))
(and (not $x1990) (or $x1990 (and (distinct ?x2030 ?x2030) true))))))))))
(check-sat)
; query 419: function gsm_sub, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1960 (ite (bvsgt (_ bv18446744073709518848 64) (bvsub ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x1257 ((_ sign_extend 48) in1_16)))
(let ((?x667 ((_ sign_extend 1) ?x1257)))
(let ((?x1256 ((_ sign_extend 48) in0_16)))
(let ((?x556 ((_ sign_extend 1) ?x1256)))
(let (($x489 (or false false)))
(let (($x1990 (or $x489 $x489 (or (and (distinct (bvsub ?x556 ?x667) ((_ sign_extend 1) (bvsub ?x1256 ?x1257))) true)))))
(let (($x1970 (or $x1990 false false)))
(and (not $x1970) (or $x1970 (and (distinct ?x1960 ?x1960) true))))))))))))
(check-sat)
; query 420: function ok_to_replace, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1860 (ite (and (distinct (_ bv4294967295 32) in.01_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x616 (or false false false)))
(let (($x382 (not $x616)))
(and $x382 (or $x616 (and (distinct ?x1860 ?x1860) true)))))))
(check-sat)
; query 421: function ok_to_replace, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in16_32 () (_ BitVec 32))
(assert
 (let ((?x1800 (ite (= (_ bv121 32) in16_32) (_ bv1 1) (_ bv0 1))))
(let (($x616 (or false false false)))
(let (($x382 (not $x616)))
(and $x382 (or $x616 (and (distinct ?x1800 ?x1800) true)))))))
(check-sat)
; query 422: function process_decode, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 32) in14_32) ((_ sign_extend 32) in14_32)) true))))))
(check-sat)
; query 423: function process_decode, block 16, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x2102 (ite (and (distinct (_ bv33 64) ((_ sign_extend 32) in14_32)) true) (_ bv1 1) (_ bv0 1))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x39 (not $x309)))
(and $x39 (or $x309 (and (distinct ?x2102 ?x2102) true))))))))
(check-sat)
; query 424: function process_decode, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x2110 (ite (bvsle (_ bv0 32) in14_32) (_ bv1 1) (_ bv0 1))))
(let (($x616 (or false false false)))
(let (($x382 (not $x616)))
(and $x382 (or $x616 (and (distinct ?x2110 ?x2110) true)))))))
(check-sat)
; query 425: function process_decode, block 71, name %72
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x2115 (ite (bvsgt (_ bv0 32) in14_32) (_ bv1 1) (_ bv0 1))))
(let (($x616 (or false false false)))
(let (($x382 (not $x616)))
(and $x382 (or $x616 (and (distinct ?x2115 ?x2115) true)))))))
(check-sat)
; query 426: function process_encode, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_32 () (_ BitVec 32))
(assert
 (let (($x489 (or false false)))
(let (($x383 (not $x489)))
(and $x383 (or $x489 (and (distinct ((_ sign_extend 32) in13_32) ((_ sign_extend 32) in13_32)) true))))))
(check-sat)
; query 427: function process_encode, block 15, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_32 () (_ BitVec 32))
(assert
 (let ((?x2123 (ite (bvult ((_ sign_extend 32) in13_32) (_ bv160 64)) (_ bv1 1) (_ bv0 1))))
(let (($x489 (or false false)))
(let (($x309 (or $x489 false false)))
(let (($x39 (not $x309)))
(and $x39 (or $x309 (and (distinct ?x2123 ?x2123) true))))))))
(check-sat)
; query 428: function process_encode, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_32 () (_ BitVec 32))
(assert
 (let ((?x2131 (ite (bvsgt (_ bv0 32) in13_32) (_ bv1 1) (_ bv0 1))))
(let (($x616 (or false false false)))
(let (($x382 (not $x616)))
(and $x382 (or $x616 (and (distinct ?x2131 ?x2131) true)))))))
(check-sat)
; query 429: function suffix, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_64 () (_ BitVec 64))
(declare-fun in3_64 () (_ BitVec 64))
(assert
 (let ((?x2137 (ite (bvule in3_64 in4_64) (_ bv1 1) (_ bv0 1))))
(let (($x616 (or false false false)))
(let (($x382 (not $x616)))
(and $x382 (or $x616 (and (distinct ?x2137 ?x2137) true)))))))
(check-sat)
; query 430: function ulaw_input, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x357 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x1883 (or false false (or $x357))))
(and (not $x1883) (or $x1883 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 431: function ulaw_input, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let ((?x948 (ite (= (_ bv4294967295 32) in.1_32) (_ bv1 1) (_ bv0 1))))
(let (($x616 (or false false false)))
(let (($x382 (not $x616)))
(and $x382 (or $x616 (and (distinct ?x948 ?x948) true)))))))
(check-sat)
