; OptiPhase-Sigma refinement certificate for sweep K19-R2-063
