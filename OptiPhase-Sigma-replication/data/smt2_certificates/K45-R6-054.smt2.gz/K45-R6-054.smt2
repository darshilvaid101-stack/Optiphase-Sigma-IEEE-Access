; OptiPhase-Sigma refinement certificate for sweep K45-R6-054
; query 0: function IsPowerOfTwo, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x216 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x46 (or false false false)))
(let (($x52 (not $x46)))
(and $x52 (or $x46 (and (distinct ?x216 ?x216) true)))))))
(check-sat)
; query 1: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x216 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x46 (or false false false)))
(let (($x52 (not $x46)))
(and $x52 (or $x46 (and (distinct ?x216 ?x216) true)))))))
(check-sat)
; query 2: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x66 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x46 (or false false false)))
(let (($x52 (not $x46)))
(and $x52 (or $x46 (and (distinct ?x66 ?x66) true)))))))
(check-sat)
