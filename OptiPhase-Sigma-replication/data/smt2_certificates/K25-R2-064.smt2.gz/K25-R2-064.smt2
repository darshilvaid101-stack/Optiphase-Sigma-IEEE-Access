; OptiPhase-Sigma refinement certificate for sweep K25-R2-064
