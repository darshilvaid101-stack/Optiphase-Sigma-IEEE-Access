; OptiPhase-Sigma refinement certificate for sweep K43-R4-322
