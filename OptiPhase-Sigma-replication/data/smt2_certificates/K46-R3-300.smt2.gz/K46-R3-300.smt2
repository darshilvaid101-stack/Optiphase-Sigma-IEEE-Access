; OptiPhase-Sigma refinement certificate for sweep K46-R3-300
; query 0: function adpcm_coder, block 25, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in20_32 () (_ BitVec 32))
(assert
 (let (($x18 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in20_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in20_32))) true)))
(let (($x418 (or false false (or $x18))))
(and (not $x418) (or $x418 (and (distinct (bvsub (_ bv0 32) in20_32) (bvsub (_ bv0 32) in20_32)) true))))))
(check-sat)
; query 1: function adpcm_coder, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(declare-fun in.017_32 () (_ BitVec 32))
(assert
 (let ((?x62 (bvsub in.017_32 in.020_32)))
(let (($x454 (and (distinct (bvsub ((_ sign_extend 1) in.017_32) ((_ sign_extend 1) in.020_32)) ((_ sign_extend 1) ?x62)) true)))
(let (($x35 (or false false (or $x454))))
(and (not $x35) (or $x35 (and (distinct ?x62 ?x62) true)))))))
(check-sat)
; query 2: function adpcm_coder, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(declare-fun in28_32 () (_ BitVec 32))
(assert
 (let (($x172 (and (distinct (bvadd ((_ sign_extend 1) in28_32) ((_ sign_extend 1) in.020_32)) ((_ sign_extend 1) (bvadd in28_32 in.020_32))) true)))
(let (($x167 (or false false (or $x172))))
(let (($x86 (or $x167 (and (distinct (bvadd in28_32 in.020_32) (bvadd in28_32 in.020_32)) true))))
(and (not $x167) $x86)))))
(check-sat)
; query 3: function adpcm_coder, block 36, name %37
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.014_32 () (_ BitVec 32))
(assert
 (let (($x182 (or false false false)))
(let (($x16 (not $x182)))
(and $x16 (or $x182 (and (distinct (bvor in.014_32 (_ bv2 32)) (bvor in.014_32 (_ bv2 32))) true))))))
(check-sat)
; query 4: function adpcm_coder, block 36, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in34_32 () (_ BitVec 32))
(declare-fun in.118_32 () (_ BitVec 32))
(assert
 (let (($x309 (and (distinct (bvsub ((_ sign_extend 1) in.118_32) ((_ sign_extend 1) in34_32)) ((_ sign_extend 1) (bvsub in.118_32 in34_32))) true)))
(let (($x21 (or false false (or $x309))))
(let (($x82 (or $x21 (and (distinct (bvsub in.118_32 in34_32) (bvsub in.118_32 in34_32)) true))))
(and (not $x21) $x82)))))
(check-sat)
; query 5: function adpcm_coder, block 36, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in34_32 () (_ BitVec 32))
(declare-fun in.08_32 () (_ BitVec 32))
(assert
 (let (($x72 (and (distinct (bvadd ((_ sign_extend 1) in.08_32) ((_ sign_extend 1) in34_32)) ((_ sign_extend 1) (bvadd in.08_32 in34_32))) true)))
(let (($x545 (or false false (or $x72))))
(let (($x125 (or $x545 (and (distinct (bvadd in.08_32 in34_32) (bvadd in.08_32 in34_32)) true))))
(and (not $x545) $x125)))))
(check-sat)
; query 6: function adpcm_coder, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.115_32 () (_ BitVec 32))
(assert
 (let (($x182 (or false false false)))
(let (($x16 (not $x182)))
(and $x16 (or $x182 (and (distinct (bvor in.115_32 (_ bv1 32)) (bvor in.115_32 (_ bv1 32))) true))))))
(check-sat)
; query 7: function adpcm_coder, block 43, name %45
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in41_32 () (_ BitVec 32))
(declare-fun in.19_32 () (_ BitVec 32))
(assert
 (let (($x485 (and (distinct (bvadd ((_ sign_extend 1) in.19_32) ((_ sign_extend 1) in41_32)) ((_ sign_extend 1) (bvadd in.19_32 in41_32))) true)))
(let (($x22 (or false false (or $x485))))
(let (($x519 (or $x22 (and (distinct (bvadd in.19_32 in41_32) (bvadd in.19_32 in41_32)) true))))
(and (not $x22) $x519)))))
(check-sat)
; query 8: function adpcm_coder, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.210_32 () (_ BitVec 32))
(declare-fun in.011_32 () (_ BitVec 32))
(assert
 (let ((?x335 (bvsub in.011_32 in.210_32)))
(let (($x116 (and (distinct (bvsub ((_ sign_extend 1) in.011_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x335)) true)))
(let (($x12 (or false false (or $x116))))
(and (not $x12) (or $x12 (and (distinct ?x335 ?x335) true)))))))
(check-sat)
; query 9: function adpcm_coder, block 50, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.210_32 () (_ BitVec 32))
(declare-fun in.011_32 () (_ BitVec 32))
(assert
 (let ((?x151 (bvadd in.011_32 in.210_32)))
(let (($x58 (and (distinct (bvadd ((_ sign_extend 1) in.011_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x151)) true)))
(let (($x38 (or false false (or $x58))))
(and (not $x38) (or $x38 (and (distinct ?x151 ?x151) true)))))))
(check-sat)
; query 10: function adpcm_decoder, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x53 (ite (and (distinct (_ bv0 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x182 (or false false false)))
(let (($x16 (not $x182)))
(and $x16 (or $x182 (and (distinct ?x53 ?x53) true)))))))
(check-sat)
; query 11: function adpcm_decoder, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x182 (or false false false)))
(let (($x16 (not $x182)))
(and $x16 (or $x182 (and (distinct (bvand in.01_32 (_ bv15 32)) (bvand in.01_32 (_ bv15 32))) true))))))
(check-sat)
; query 12: function adpcm_decoder, block 61, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.210_32 () (_ BitVec 32))
(declare-fun in.013_32 () (_ BitVec 32))
(assert
 (let ((?x217 (bvadd in.013_32 in.210_32)))
(let ((?x6 (bvsub in.013_32 in.210_32)))
(let (($x290 (and (distinct (bvadd ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x217)) true)))
(let (($x434 (and (distinct (bvsub ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x6)) true)))
(and (not (or false false (or $x434))) (or (or false false (or $x290)) (and (distinct ?x6 ?x217) true))))))))
(check-sat)
; query 13: function main, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x516 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x182 (or false false false)))
(let (($x16 (not $x182)))
(and $x16 (or $x182 (and (distinct ?x516 ?x516) true)))))))
(check-sat)
