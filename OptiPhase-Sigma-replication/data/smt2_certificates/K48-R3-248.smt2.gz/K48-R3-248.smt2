; OptiPhase-Sigma refinement certificate for sweep K48-R3-248
; query 0: function APCM_inverse_quantization, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x318 (or false false)))
(let (($x140 (not $x318)))
(and $x140 (or $x318 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 1: function APCM_inverse_quantization, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x409 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x318 (or false false)))
(let (($x1025 (or $x318 false false)))
(let (($x809 (not $x1025)))
(and $x809 (or $x1025 (and (distinct ?x409 ?x409) true))))))))
(check-sat)
; query 2: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x318 (or false false)))
(let (($x140 (not $x318)))
(and $x140 (or $x318 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 3: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x113 (ite (bvslt (_ bv15 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x318 (or false false)))
(let (($x1025 (or $x318 false false)))
(let (($x809 (not $x1025)))
(and $x809 (or $x1025 (and (distinct ?x113 ?x113) true))))))))
(check-sat)
; query 4: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x318 (or false false)))
(let (($x140 (not $x318)))
(and $x140 (or $x318 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 5: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x19 (ite (bvsgt (_ bv40 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x318 (or false false)))
(let (($x1025 (or $x318 false false)))
(let (($x809 (not $x1025)))
(and $x809 (or $x1025 (and (distinct ?x19 ?x19) true))))))))
(check-sat)
; query 6: function RPE_grid_positioning, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x318 (or false false)))
(let (($x140 (not $x318)))
(and $x140 (or $x318 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 7: function RPE_grid_positioning, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x29 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x171 (and (distinct ?x29 ?x29) true)))
(let (($x318 (or false false)))
(let (($x170 (or false $x318 false)))
(and (not $x170) (or $x170 $x171)))))))
(check-sat)
; query 8: function gsm_L_add, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x518 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x66 (or false false false)))
(let (($x197 (not $x66)))
(and $x197 (or $x66 (and (distinct ?x518 ?x518) true)))))))
(check-sat)
; query 9: function gsm_L_add, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x34 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvadd in0_64 in1_64))) true)))
(let (($x114 (or false false (or $x34))))
(let (($x590 (or $x114 (and (distinct (bvadd in0_64 in1_64) (bvadd in0_64 in1_64)) true))))
(and (not $x114) $x590)))))
(check-sat)
; query 10: function gsm_L_add, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x104 (bvadd in0_64 (_ bv1 64))))
(let ((?x444 (bvsub (_ bv0 64) ?x104)))
(let (($x208 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x104)) ((_ sign_extend 1) ?x444)) true)))
(let ((?x86 ((_ sign_extend 1) ?x104)))
(let (($x51 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x86) true)))))
(let (($x54 (or false $x51 (or $x208))))
(and (not $x54) (or $x54 (and (distinct ?x444 ?x444) true))))))))))
(check-sat)
; query 11: function gsm_L_add, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x446 (bvadd in1_64 (_ bv1 64))))
(let ((?x75 ((_ sign_extend 1) ?x446)))
(let (($x20 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x75) true)))))
(and (not $x20) (or $x20 (and (distinct ?x446 ?x446) true)))))))
(check-sat)
; query 12: function gsm_L_add, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x446 (bvadd in1_64 (_ bv1 64))))
(let ((?x347 (bvsub (_ bv0 64) ?x446)))
(let (($x21 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x446)) ((_ sign_extend 1) ?x347)) true)))
(let ((?x75 ((_ sign_extend 1) ?x446)))
(let (($x20 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x75) true)))))
(let (($x70 (or false $x20 (or $x21))))
(and (not $x70) (or $x70 (and (distinct ?x347 ?x347) true))))))))))
(check-sat)
; query 13: function gsm_L_add, block 8, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x446 (bvadd in1_64 (_ bv1 64))))
(let ((?x347 (bvsub (_ bv0 64) ?x446)))
(let ((?x104 (bvadd in0_64 (_ bv1 64))))
(let ((?x444 (bvsub (_ bv0 64) ?x104)))
(let ((?x74 (bvadd ?x444 ?x347)))
(let (($x21 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x446)) ((_ sign_extend 1) ?x347)) true)))
(let ((?x75 ((_ sign_extend 1) ?x446)))
(let (($x20 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x75) true)))))
(let (($x70 (or false $x20 (or $x21))))
(let (($x208 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x104)) ((_ sign_extend 1) ?x444)) true)))
(let ((?x86 ((_ sign_extend 1) ?x104)))
(let (($x51 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x86) true)))))
(let (($x54 (or false $x51 (or $x208))))
(let (($x559 (or $x54 $x70 false)))
(and (not $x559) (or $x559 (and (distinct ?x74 ?x74) true))))))))))))))))))
(check-sat)
; query 14: function gsm_L_add, block 8, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x446 (bvadd in1_64 (_ bv1 64))))
(let ((?x347 (bvsub (_ bv0 64) ?x446)))
(let ((?x104 (bvadd in0_64 (_ bv1 64))))
(let ((?x444 (bvsub (_ bv0 64) ?x104)))
(let ((?x74 (bvadd ?x444 ?x347)))
(let ((?x35 (ite (bvuge ?x74 (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x21 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x446)) ((_ sign_extend 1) ?x347)) true)))
(let ((?x75 ((_ sign_extend 1) ?x446)))
(let (($x20 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x75) true)))))
(let (($x70 (or false $x20 (or $x21))))
(let (($x208 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x104)) ((_ sign_extend 1) ?x444)) true)))
(let ((?x86 ((_ sign_extend 1) ?x104)))
(let (($x51 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x86) true)))))
(let (($x54 (or false $x51 (or $x208))))
(let (($x559 (or $x54 $x70 false)))
(let (($x696 (or $x559 false false)))
(and (not $x696) (or $x696 (and (distinct ?x35 ?x35) true))))))))))))))))))))
(check-sat)
; query 15: function gsm_L_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x104 (bvadd in0_64 (_ bv1 64))))
(let ((?x86 ((_ sign_extend 1) ?x104)))
(let (($x51 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x86) true)))))
(and (not $x51) (or $x51 (and (distinct ?x104 ?x104) true)))))))
(check-sat)
; query 16: function gsm_L_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x437 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x66 (or false false false)))
(let (($x197 (not $x66)))
(and $x197 (or $x66 (and (distinct ?x437 ?x437) true)))))))
(check-sat)
; query 17: function gsm_L_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x37 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x66 (or false false false)))
(let (($x197 (not $x66)))
(and $x197 (or $x66 (and (distinct ?x37 ?x37) true)))))))
(check-sat)
; query 18: function gsm_L_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x437 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x66 (or false false false)))
(let (($x197 (not $x66)))
(and $x197 (or $x66 (and (distinct ?x437 ?x437) true)))))))
(check-sat)
; query 19: function gsm_L_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x437 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x334 ((_ zero_extend 31) ?x437)))
(let (($x66 (or false false false)))
(let (($x15 (or $x66 false)))
(and (not $x15) (or $x15 (and (distinct ?x334 ?x334) true))))))))
(check-sat)
; query 20: function gsm_L_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x437 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x334 ((_ zero_extend 31) ?x437)))
(let ((?x259 (bvsub (_ bv0 32) ?x334)))
(let (($x260 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x334)) ((_ sign_extend 1) ?x259)) true)))
(let (($x66 (or false false false)))
(let (($x15 (or $x66 false)))
(let (($x39 (or false $x15 (or $x260))))
(and (not $x39) (or $x39 (and (distinct ?x259 ?x259) true)))))))))))
(check-sat)
; query 21: function gsm_L_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x437 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x334 ((_ zero_extend 31) ?x437)))
(let ((?x259 (bvsub (_ bv0 32) ?x334)))
(let ((?x235 ((_ sign_extend 32) ?x259)))
(let (($x260 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x334)) ((_ sign_extend 1) ?x259)) true)))
(let (($x66 (or false false false)))
(let (($x15 (or $x66 false)))
(let (($x39 (or false $x15 (or $x260))))
(let (($x536 (or $x39 false)))
(and (not $x536) (or $x536 (and (distinct ?x235 ?x235) true)))))))))))))
(check-sat)
; query 22: function gsm_L_asr, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x315 (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x66 (or false false false)))
(let (($x197 (not $x66)))
(and $x197 (or $x66 (and (distinct ?x315 ?x315) true)))))))
(check-sat)
; query 23: function gsm_L_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x37 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x66 (or false false false)))
(let (($x197 (not $x66)))
(and $x197 (or $x66 (and (distinct ?x37 ?x37) true)))))))
(check-sat)
; query 24: function gsm_L_sub, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x518 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x66 (or false false false)))
(let (($x197 (not $x66)))
(and $x197 (or $x66 (and (distinct ?x518 ?x518) true)))))))
(check-sat)
; query 25: function gsm_L_sub, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x494 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvsub in0_64 in1_64))) true)))
(let (($x404 (or false false (or $x494))))
(let (($x354 (or $x404 (and (distinct (bvsub in0_64 in1_64) (bvsub in0_64 in1_64)) true))))
(and (not $x404) $x354)))))
(check-sat)
; query 26: function gsm_L_sub, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x446 (bvadd in1_64 (_ bv1 64))))
(let ((?x347 (bvsub (_ bv0 64) ?x446)))
(let (($x21 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x446)) ((_ sign_extend 1) ?x347)) true)))
(let ((?x75 ((_ sign_extend 1) ?x446)))
(let (($x20 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x75) true)))))
(let (($x70 (or false $x20 (or $x21))))
(and (not $x70) (or $x70 (and (distinct ?x347 ?x347) true))))))))))
(check-sat)
; query 27: function gsm_L_sub, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x446 (bvadd in1_64 (_ bv1 64))))
(let ((?x347 (bvsub (_ bv0 64) ?x446)))
(let ((?x12 (bvadd in0_64 ?x347)))
(let (($x21 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x446)) ((_ sign_extend 1) ?x347)) true)))
(let ((?x75 ((_ sign_extend 1) ?x446)))
(let (($x20 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x75) true)))))
(let (($x70 (or false $x20 (or $x21))))
(let (($x756 (or false $x70 false)))
(and (not $x756) (or $x756 (and (distinct ?x12 ?x12) true))))))))))))
(check-sat)
; query 28: function gsm_L_sub, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x291 (ite (bvuge (bvadd in0_64 (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64)))) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x21 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) (bvadd in1_64 (_ bv1 64)))) ((_ sign_extend 1) (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64))))) true)))
(let ((?x446 (bvadd in1_64 (_ bv1 64))))
(let ((?x75 ((_ sign_extend 1) ?x446)))
(let (($x20 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x75) true)))))
(let (($x70 (or false $x20 (or $x21))))
(let (($x756 (or false $x70 false)))
(let (($x99 (or $x756 false false)))
(and (not $x99) (or $x99 (and (distinct ?x291 ?x291) true))))))))))))
(check-sat)
; query 29: function gsm_L_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x446 (bvadd in1_64 (_ bv1 64))))
(let ((?x75 ((_ sign_extend 1) ?x446)))
(let (($x20 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x75) true)))))
(and (not $x20) (or $x20 (and (distinct ?x446 ?x446) true)))))))
(check-sat)
; query 30: function gsm_L_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x302 (ite (bvsle (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x66 (or false false false)))
(let (($x197 (not $x66)))
(and $x197 (or $x66 (and (distinct ?x302 ?x302) true)))))))
(check-sat)
; query 31: function gsm_abs, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x318 (or false false)))
(let (($x140 (not $x318)))
(and $x140 (or $x318 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 32: function gsm_abs, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x498 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x318 (or false false)))
(let (($x1025 (or $x318 false false)))
(let (($x809 (not $x1025)))
(and $x809 (or $x1025 (and (distinct ?x498 ?x498) true))))))))
(check-sat)
; query 33: function gsm_abs, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x318 (or false false)))
(let (($x140 (not $x318)))
(and $x140 (or $x318 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 34: function gsm_abs, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x192 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x318 (or false false)))
(let (($x1025 (or $x318 false false)))
(let (($x809 (not $x1025)))
(and $x809 (or $x1025 (and (distinct ?x192 ?x192) true))))))))
(check-sat)
; query 35: function gsm_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x318 (or false false)))
(let (($x140 (not $x318)))
(and $x140 (or $x318 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 36: function gsm_add, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x318 (or false false)))
(let (($x140 (not $x318)))
(and $x140 (or $x318 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 37: function gsm_add, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x623 ((_ sign_extend 48) in1_16)))
(let ((?x969 ((_ sign_extend 48) in0_16)))
(let ((?x220 (bvadd ?x969 ?x623)))
(let (($x62 (and (distinct (bvadd ((_ sign_extend 1) ?x969) ((_ sign_extend 1) ?x623)) ((_ sign_extend 1) ?x220)) true)))
(let (($x318 (or false false)))
(let (($x428 (or $x318 $x318 (or $x62))))
(and (not $x428) (or $x428 (and (distinct ?x220 ?x220) true))))))))))
(check-sat)
; query 38: function gsm_add, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x231 (ite (bvsgt (_ bv18446744073709518848 64) (bvadd ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x623 ((_ sign_extend 48) in1_16)))
(let ((?x722 ((_ sign_extend 1) ?x623)))
(let ((?x969 ((_ sign_extend 48) in0_16)))
(let ((?x619 ((_ sign_extend 1) ?x969)))
(let (($x318 (or false false)))
(let (($x428 (or $x318 $x318 (or (and (distinct (bvadd ?x619 ?x722) ((_ sign_extend 1) (bvadd ?x969 ?x623))) true)))))
(let (($x330 (or $x428 false false)))
(and (not $x330) (or $x330 (and (distinct ?x231 ?x231) true))))))))))))
(check-sat)
; query 39: function gsm_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x601 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x66 (or false false false)))
(let (($x197 (not $x66)))
(and $x197 (or $x66 (and (distinct ?x601 ?x601) true)))))))
(check-sat)
; query 40: function gsm_asr, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x761 (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x66 (or false false false)))
(let (($x197 (not $x66)))
(and $x197 (or $x66 (and (distinct ?x761 ?x761) true)))))))
(check-sat)
; query 41: function gsm_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x318 (or false false)))
(let (($x140 (not $x318)))
(and $x140 (or $x318 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 42: function gsm_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x192 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x318 (or false false)))
(let (($x1025 (or $x318 false false)))
(let (($x809 (not $x1025)))
(and $x809 (or $x1025 (and (distinct ?x192 ?x192) true))))))))
(check-sat)
; query 43: function gsm_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x192 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x597 ((_ zero_extend 31) ?x192)))
(let (($x318 (or false false)))
(let (($x1025 (or $x318 false false)))
(let (($x907 (or $x1025 false)))
(and (not $x907) (or $x907 (and (distinct ?x597 ?x597) true)))))))))
(check-sat)
; query 44: function gsm_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x192 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x597 ((_ zero_extend 31) ?x192)))
(let ((?x946 (bvsub (_ bv0 32) ?x597)))
(let (($x455 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x597)) ((_ sign_extend 1) ?x946)) true)))
(let (($x318 (or false false)))
(let (($x1025 (or $x318 false false)))
(let (($x907 (or $x1025 false)))
(let (($x175 (or false $x907 (or $x455))))
(and (not $x175) (or $x175 (and (distinct ?x946 ?x946) true))))))))))))
(check-sat)
; query 45: function gsm_asr, block 4, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x192 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x597 ((_ zero_extend 31) ?x192)))
(let ((?x946 (bvsub (_ bv0 32) ?x597)))
(let ((?x1012 ((_ extract 15 0) ?x946)))
(let (($x455 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x597)) ((_ sign_extend 1) ?x946)) true)))
(let (($x318 (or false false)))
(let (($x1025 (or $x318 false false)))
(let (($x907 (or $x1025 false)))
(let (($x175 (or false $x907 (or $x455))))
(let (($x861 (or $x175 false)))
(and (not $x861) (or $x861 (and (distinct ?x1012 ?x1012) true))))))))))))))
(check-sat)
; query 46: function gsm_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x601 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x66 (or false false false)))
(let (($x197 (not $x66)))
(and $x197 (or $x66 (and (distinct ?x601 ?x601) true)))))))
(check-sat)
; query 47: function gsm_debug_longwords, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in15_32 () (_ BitVec 32))
(assert
 (let ((?x112 (ite (bvslt in15_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x66 (or false false false)))
(let (($x197 (not $x66)))
(and $x197 (or $x66 (and (distinct ?x112 ?x112) true)))))))
(check-sat)
; query 48: function gsm_debug_words, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in16_32 () (_ BitVec 32))
(assert
 (let ((?x551 (ite (bvslt in16_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x66 (or false false false)))
(let (($x197 (not $x66)))
(and $x197 (or $x66 (and (distinct ?x551 ?x551) true)))))))
(check-sat)
; query 49: function gsm_div, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x318 (or false false)))
(let (($x140 (not $x318)))
(and $x140 (or $x318 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 50: function gsm_div, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x318 (or false false)))
(let (($x140 (not $x318)))
(and $x140 (or $x318 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 51: function gsm_div, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x318 (or false false)))
(let (($x140 (not $x318)))
(and $x140 (or $x318 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 52: function gsm_div, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x29 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x171 (and (distinct ?x29 ?x29) true)))
(let (($x318 (or false false)))
(let (($x1025 (or $x318 false false)))
(let (($x809 (not $x1025)))
(and $x809 (or $x1025 $x171))))))))
(check-sat)
; query 53: function gsm_norm, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x437 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x66 (or false false false)))
(let (($x197 (not $x66)))
(and $x197 (or $x66 (and (distinct ?x437 (ite (bvsge (_ bv18446744072635809792 64) in0_64) (_ bv1 1) (_ bv0 1))) true)))))))
(check-sat)
; query 54: function gsm_norm, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x264 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x66 (or false false false)))
(let (($x197 (not $x66)))
(and $x197 (or $x66 (and (distinct ?x264 ?x264) true)))))))
(check-sat)
; query 55: function gsm_norm, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x264 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x374 (bvxor ?x264 (_ bv1 1))))
(let (($x66 (or false false false)))
(let (($x328 (or $x66 false false)))
(and (not $x328) (or $x328 (and (distinct ?x374 ?x374) true))))))))
(check-sat)
; query 56: function gsm_norm, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x264 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x374 (bvxor ?x264 (_ bv1 1))))
(let ((?x420 ((_ zero_extend 31) ?x374)))
(let (($x66 (or false false false)))
(let (($x328 (or $x66 false false)))
(let (($x122 (or $x328 false)))
(and (not $x122) (or $x122 (and (distinct ?x420 ?x420) true))))))))))
(check-sat)
; query 57: function gsm_norm, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x264 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x374 (bvxor ?x264 (_ bv1 1))))
(let ((?x420 ((_ zero_extend 31) ?x374)))
(let ((?x882 ((_ sign_extend 32) ?x420)))
(let (($x66 (or false false false)))
(let (($x328 (or $x66 false false)))
(let (($x122 (or $x328 false)))
(let (($x1036 (or $x122 false)))
(and (not $x1036) (or $x1036 (and (distinct ?x882 ?x882) true))))))))))))
(check-sat)
; query 58: function gsm_norm, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x264 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x374 (bvxor ?x264 (_ bv1 1))))
(let ((?x420 ((_ zero_extend 31) ?x374)))
(let ((?x882 ((_ sign_extend 32) ?x420)))
(let ((?x546 (ite (and (distinct (_ bv0 64) ?x882) true) (_ bv1 1) (_ bv0 1))))
(let (($x66 (or false false false)))
(let (($x328 (or $x66 false false)))
(let (($x122 (or $x328 false)))
(let (($x1036 (or $x122 false)))
(let (($x790 (or $x1036 false false)))
(and (not $x790) (or $x790 (and (distinct ?x546 ?x546) true))))))))))))))
(check-sat)
; query 59: function gsm_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x318 (or false false)))
(let (($x140 (not $x318)))
(and $x140 (or $x318 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 60: function gsm_sub, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x318 (or false false)))
(let (($x140 (not $x318)))
(and $x140 (or $x318 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 61: function gsm_sub, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x623 ((_ sign_extend 48) in1_16)))
(let ((?x969 ((_ sign_extend 48) in0_16)))
(let ((?x560 (bvsub ?x969 ?x623)))
(let (($x1044 (and (distinct (bvsub ((_ sign_extend 1) ?x969) ((_ sign_extend 1) ?x623)) ((_ sign_extend 1) ?x560)) true)))
(let (($x318 (or false false)))
(let (($x748 (or $x318 $x318 (or $x1044))))
(and (not $x748) (or $x748 (and (distinct ?x560 ?x560) true))))))))))
(check-sat)
; query 62: function gsm_sub, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x914 (ite (bvsgt (_ bv18446744073709518848 64) (bvsub ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x623 ((_ sign_extend 48) in1_16)))
(let ((?x722 ((_ sign_extend 1) ?x623)))
(let ((?x969 ((_ sign_extend 48) in0_16)))
(let ((?x619 ((_ sign_extend 1) ?x969)))
(let (($x318 (or false false)))
(let (($x748 (or $x318 $x318 (or (and (distinct (bvsub ?x619 ?x722) ((_ sign_extend 1) (bvsub ?x969 ?x623))) true)))))
(let (($x103 (or $x748 false false)))
(and (not $x103) (or $x103 (and (distinct ?x914 ?x914) true))))))))))))
(check-sat)
; query 63: function process_decode, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let (($x318 (or false false)))
(let (($x140 (not $x318)))
(and $x140 (or $x318 (and (distinct ((_ sign_extend 32) in14_32) ((_ sign_extend 32) in14_32)) true))))))
(check-sat)
; query 64: function process_decode, block 16, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x911 (ite (and (distinct (_ bv33 64) ((_ sign_extend 32) in14_32)) true) (_ bv1 1) (_ bv0 1))))
(let (($x318 (or false false)))
(let (($x1025 (or $x318 false false)))
(let (($x809 (not $x1025)))
(and $x809 (or $x1025 (and (distinct ?x911 ?x911) true))))))))
(check-sat)
; query 65: function process_encode, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_32 () (_ BitVec 32))
(assert
 (let (($x318 (or false false)))
(let (($x140 (not $x318)))
(and $x140 (or $x318 (and (distinct ((_ sign_extend 32) in13_32) ((_ sign_extend 32) in13_32)) true))))))
(check-sat)
; query 66: function process_encode, block 15, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_32 () (_ BitVec 32))
(assert
 (let ((?x977 (ite (bvult ((_ sign_extend 32) in13_32) (_ bv160 64)) (_ bv1 1) (_ bv0 1))))
(let (($x318 (or false false)))
(let (($x1025 (or $x318 false false)))
(let (($x809 (not $x1025)))
(and $x809 (or $x1025 (and (distinct ?x977 ?x977) true))))))))
(check-sat)
