; OptiPhase-Sigma refinement certificate for sweep K19-R2-081
; query 0: function init_array, block 103, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x85 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x88 (or false false (or $x85))))
(and (not $x88) (or $x88 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function init_array, block 106, name %107
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.13_32 () (_ BitVec 32))
(assert
 (let (($x315 (and (distinct (bvadd ((_ sign_extend 1) in.13_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.13_32 (_ bv1 32)))) true)))
(let (($x94 (or false false (or $x315))))
(and (not $x94) (or $x94 (and (distinct (bvadd in.13_32 (_ bv1 32)) (bvadd in.13_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function init_array, block 109, name %110
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x122 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x10 (or false false (or $x122))))
(and (not $x10) (or $x10 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 3: function init_array, block 127, name %128
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let (($x208 (and (distinct (bvadd ((_ sign_extend 1) in.2_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.2_32 (_ bv1 32)))) true)))
(let (($x117 (or false false (or $x208))))
(and (not $x117) (or $x117 (and (distinct (bvadd in.2_32 (_ bv1 32)) (bvadd in.2_32 (_ bv1 32))) true))))))
(check-sat)
; query 4: function init_array, block 130, name %131
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.24_32 () (_ BitVec 32))
(assert
 (let (($x87 (and (distinct (bvadd ((_ sign_extend 1) in.24_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.24_32 (_ bv1 32)))) true)))
(let (($x22 (or false false (or $x87))))
(and (not $x22) (or $x22 (and (distinct (bvadd in.24_32 (_ bv1 32)) (bvadd in.24_32 (_ bv1 32))) true))))))
(check-sat)
; query 5: function init_array, block 21, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.07_32 () (_ BitVec 32))
(assert
 (let (($x118 (and (distinct (bvadd ((_ sign_extend 1) in.07_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.07_32 (_ bv1 32)))) true)))
(let (($x57 (or false false (or $x118))))
(and (not $x57) (or $x57 (and (distinct (bvadd in.07_32 (_ bv1 32)) (bvadd in.07_32 (_ bv1 32))) true))))))
(check-sat)
; query 6: function init_array, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.05_32 () (_ BitVec 32))
(assert
 (let (($x33 (and (distinct (bvadd ((_ sign_extend 1) in.05_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.05_32 (_ bv1 32)))) true)))
(let (($x37 (or false false (or $x33))))
(and (not $x37) (or $x37 (and (distinct (bvadd in.05_32 (_ bv1 32)) (bvadd in.05_32 (_ bv1 32))) true))))))
(check-sat)
; query 7: function init_array, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.18_32 () (_ BitVec 32))
(assert
 (let (($x28 (and (distinct (bvadd ((_ sign_extend 1) in.18_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.18_32 (_ bv1 32)))) true)))
(let (($x58 (or false false (or $x28))))
(and (not $x58) (or $x58 (and (distinct (bvadd in.18_32 (_ bv1 32)) (bvadd in.18_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function init_array, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.16_32 () (_ BitVec 32))
(assert
 (let (($x60 (and (distinct (bvadd ((_ sign_extend 1) in.16_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.16_32 (_ bv1 32)))) true)))
(let (($x29 (or false false (or $x60))))
(and (not $x29) (or $x29 (and (distinct (bvadd in.16_32 (_ bv1 32)) (bvadd in.16_32 (_ bv1 32))) true))))))
(check-sat)
; query 9: function init_array, block 58, name %59
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.18_32 () (_ BitVec 32))
(assert
 (let (($x28 (and (distinct (bvadd ((_ sign_extend 1) in.18_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.18_32 (_ bv1 32)))) true)))
(let (($x58 (or false false (or $x28))))
(and (not $x58) (or $x58 (and (distinct (bvadd in.18_32 (_ bv1 32)) (bvadd in.18_32 (_ bv1 32))) true))))))
(check-sat)
; query 10: function init_array, block 72, name %73
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x100 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x112 (or false false (or $x100))))
(and (not $x112) (or $x112 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 11: function init_array, block 75, name %76
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x126 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x140 (or false false (or $x126))))
(and (not $x140) (or $x140 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 12: function kernel_ludcmp, block 103, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.25_32 () (_ BitVec 32))
(assert
 (let (($x203 (and (distinct (bvadd ((_ sign_extend 1) in.25_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.25_32 (_ bv1 32)))) true)))
(let (($x153 (or false false (or $x203))))
(and (not $x153) (or $x153 (and (distinct (bvadd in.25_32 (_ bv1 32)) (bvadd in.25_32 (_ bv1 32))) true))))))
(check-sat)
; query 13: function kernel_ludcmp, block 108, name %109
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.18_32 () (_ BitVec 32))
(assert
 (let (($x28 (and (distinct (bvadd ((_ sign_extend 1) in.18_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.18_32 (_ bv1 32)))) true)))
(let (($x58 (or false false (or $x28))))
(and (not $x58) (or $x58 (and (distinct (bvadd in.18_32 (_ bv1 32)) (bvadd in.18_32 (_ bv1 32))) true))))))
(check-sat)
; query 14: function kernel_ludcmp, block 110, name %111
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x183 (and (distinct (bvsub ((_ sign_extend 1) in0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvsub in0_32 (_ bv1 32)))) true)))
(let (($x327 (or false false (or $x183))))
(and (not $x327) (or $x327 (and (distinct (bvsub in0_32 (_ bv1 32)) (bvsub in0_32 (_ bv1 32))) true))))))
(check-sat)
; query 15: function kernel_ludcmp, block 132, name %133
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.36_32 () (_ BitVec 32))
(assert
 (let (($x255 (and (distinct (bvadd ((_ sign_extend 1) in.36_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.36_32 (_ bv1 32)))) true)))
(let (($x337 (or false false (or $x255))))
(and (not $x337) (or $x337 (and (distinct (bvadd in.36_32 (_ bv1 32)) (bvadd in.36_32 (_ bv1 32))) true))))))
(check-sat)
; query 16: function kernel_ludcmp, block 143, name %144
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.29_32 () (_ BitVec 32))
(assert
 (let (($x365 (and (distinct (bvadd ((_ sign_extend 1) in.29_32) ((_ sign_extend 1) (_ bv4294967295 32))) ((_ sign_extend 1) (bvadd in.29_32 (_ bv4294967295 32)))) true)))
(let (($x290 (or false false (or $x365))))
(and (not $x290) (or $x290 (and (distinct (bvadd in.29_32 (_ bv4294967295 32)) (bvadd in.29_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 17: function kernel_ludcmp, block 32, name %33
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x100 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x112 (or false false (or $x100))))
(and (not $x112) (or $x112 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 18: function kernel_ludcmp, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_32 () (_ BitVec 32))
(assert
 (let (($x160 (and (distinct (bvadd ((_ sign_extend 1) in.03_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.03_32 (_ bv1 32)))) true)))
(let (($x175 (or false false (or $x160))))
(and (not $x175) (or $x175 (and (distinct (bvadd in.03_32 (_ bv1 32)) (bvadd in.03_32 (_ bv1 32))) true))))))
(check-sat)
; query 19: function kernel_ludcmp, block 71, name %72
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x93 (and (distinct (bvadd ((_ sign_extend 1) in.12_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.12_32 (_ bv1 32)))) true)))
(let (($x294 (or false false (or $x93))))
(and (not $x294) (or $x294 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 20: function kernel_ludcmp, block 78, name %79
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.14_32 () (_ BitVec 32))
(assert
 (let (($x442 (and (distinct (bvadd ((_ sign_extend 1) in.14_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.14_32 (_ bv1 32)))) true)))
(let (($x341 (or false false (or $x442))))
(and (not $x341) (or $x341 (and (distinct (bvadd in.14_32 (_ bv1 32)) (bvadd in.14_32 (_ bv1 32))) true))))))
(check-sat)
; query 21: function kernel_ludcmp, block 81, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.07_32 () (_ BitVec 32))
(assert
 (let (($x118 (and (distinct (bvadd ((_ sign_extend 1) in.07_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.07_32 (_ bv1 32)))) true)))
(let (($x57 (or false false (or $x118))))
(and (not $x57) (or $x57 (and (distinct (bvadd in.07_32 (_ bv1 32)) (bvadd in.07_32 (_ bv1 32))) true))))))
(check-sat)
; query 22: function polybench_flush_cache, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x100 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x112 (or false false (or $x100))))
(and (not $x112) (or $x112 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 23: function print_array, block 21, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x122 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x10 (or false false (or $x122))))
(and (not $x10) (or $x10 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 24: function xmalloc, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in7_32 () (_ BitVec 32))
(assert
 (let ((?x562 (ite (and (distinct (_ bv0 32) in7_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x537 (or false false false)))
(and (not $x537) (or $x537 (and (distinct ?x562 ?x562) true))))))
(check-sat)
