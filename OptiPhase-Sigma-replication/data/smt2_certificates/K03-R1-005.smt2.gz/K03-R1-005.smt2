; OptiPhase-Sigma refinement certificate for sweep K03-R1-005
