; OptiPhase-Sigma refinement certificate for sweep K57-R2-072
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x346 (or false false)))
(let (($x21 (not $x346)))
(and $x21 (or $x346 (and (distinct ((_ sign_extend 16) in25_16) ((_ sign_extend 16) in25_16)) true))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let ((?x1117 (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))))
(let (($x346 (or false false)))
(let (($x63 (or $x346 false false)))
(let (($x2056 (not $x63)))
(and $x2056 (or $x63 (and (distinct ?x1117 ?x1117) true))))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x346 (or false false)))
(let (($x21 (not $x346)))
(and $x21 (or $x346 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x83 ((_ sign_extend 16) in3_16)))
(let ((?x100 (bvand ?x83 (_ bv127 32))))
(let (($x346 (or false false)))
(let (($x63 (or $x346 false false)))
(let (($x2056 (not $x63)))
(and $x2056 (or $x63 (and (distinct ?x100 ?x100) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x83 ((_ sign_extend 16) in3_16)))
(let ((?x100 (bvand ?x83 (_ bv127 32))))
(let ((?x20 ((_ extract 15 0) ?x100)))
(let (($x346 (or false false)))
(let (($x63 (or $x346 false false)))
(let (($x1042 (or $x63 false)))
(let (($x116 (not $x1042)))
(and $x116 (or $x1042 (and (distinct ?x20 ?x20) true)))))))))))
(check-sat)
; query 5: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x346 (or false false)))
(let (($x21 (not $x346)))
(and $x21 (or $x346 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 6: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x652 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x346 (or false false)))
(let (($x63 (or $x346 false false)))
(let (($x2056 (not $x63)))
(and $x2056 (or $x63 (and (distinct ?x652 ?x652) true))))))))
(check-sat)
; query 7: function core_bench_list, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x297 (or false false false)))
(let (($x921 (not $x297)))
(and $x921 (or $x297 (and (distinct (bvadd in.0_16 (_ bv1 16)) (bvadd in.0_16 (_ bv1 16))) true))))))
(check-sat)
; query 8: function core_bench_list, block 82, name %83
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let (($x346 (or false false)))
(let (($x21 (not $x346)))
(and $x21 (or $x346 (and (distinct ((_ zero_extend 16) in.02_16) ((_ zero_extend 16) in.02_16)) true))))))
(check-sat)
; query 9: function core_bench_list, block 82, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x58 ((_ zero_extend 16) in.02_16)))
(let ((?x212 (bvmul ?x58 (_ bv4 32))))
(let (($x186 (and (distinct (bvmul ((_ sign_extend 32) ?x58) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x212)) true)))
(let (($x346 (or false false)))
(let (($x539 (or $x346 false (or $x186))))
(and (not $x539) (or $x539 (and (distinct ?x212 ?x212) true)))))))))
(check-sat)
; query 10: function core_bench_list, block 82, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let (($x346 (or false false)))
(let (($x21 (not $x346)))
(and $x21 (or $x346 (and (distinct ((_ zero_extend 16) in.04_16) ((_ zero_extend 16) in.04_16)) true))))))
(check-sat)
; query 11: function core_bench_list, block 82, name %86
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x622 ((_ zero_extend 16) in.04_16)))
(let ((?x58 ((_ zero_extend 16) in.02_16)))
(let ((?x212 (bvmul ?x58 (_ bv4 32))))
(let ((?x1458 (bvsub ?x212 ?x622)))
(let ((?x88 ((_ sign_extend 1) ?x1458)))
(let (($x346 (or false false)))
(let (($x186 (and (distinct (bvmul ((_ sign_extend 32) ?x58) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x212)) true)))
(let (($x539 (or $x346 false (or $x186))))
(let (($x217 (or $x539 $x346 (or (and (distinct (bvsub ((_ sign_extend 1) ?x212) ((_ sign_extend 1) ?x622)) ?x88) true)))))
(and (not $x217) (or $x217 (and (distinct ?x1458 ?x1458) true)))))))))))))
(check-sat)
; query 12: function core_bench_list, block 82, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x346 (or false false)))
(let (($x21 (not $x346)))
(and $x21 (or $x346 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 13: function core_bench_list, block 82, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x622 ((_ zero_extend 16) in.04_16)))
(let ((?x58 ((_ zero_extend 16) in.02_16)))
(let ((?x212 (bvmul ?x58 (_ bv4 32))))
(let ((?x1458 (bvsub ?x212 ?x622)))
(let ((?x707 ((_ zero_extend 16) in.01_16)))
(let ((?x1091 (bvadd ?x707 ?x1458)))
(let (($x534 (and (distinct (bvadd ((_ sign_extend 1) ?x707) ((_ sign_extend 1) ?x1458)) ((_ sign_extend 1) ?x1091)) true)))
(let ((?x88 ((_ sign_extend 1) ?x1458)))
(let (($x346 (or false false)))
(let (($x186 (and (distinct (bvmul ((_ sign_extend 32) ?x58) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x212)) true)))
(let (($x539 (or $x346 false (or $x186))))
(let (($x217 (or $x539 $x346 (or (and (distinct (bvsub ((_ sign_extend 1) ?x212) ((_ sign_extend 1) ?x622)) ?x88) true)))))
(let (($x434 (or $x346 $x217 (or $x534))))
(and (not $x434) (or $x434 (and (distinct ?x1091 ?x1091) true)))))))))))))))))
(check-sat)
; query 14: function core_bench_list, block 82, name %89
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x622 ((_ zero_extend 16) in.04_16)))
(let ((?x58 ((_ zero_extend 16) in.02_16)))
(let ((?x212 (bvmul ?x58 (_ bv4 32))))
(let ((?x1458 (bvsub ?x212 ?x622)))
(let ((?x707 ((_ zero_extend 16) in.01_16)))
(let ((?x1091 (bvadd ?x707 ?x1458)))
(let ((?x38 ((_ extract 15 0) ?x1091)))
(let (($x534 (and (distinct (bvadd ((_ sign_extend 1) ?x707) ((_ sign_extend 1) ?x1458)) ((_ sign_extend 1) ?x1091)) true)))
(let ((?x88 ((_ sign_extend 1) ?x1458)))
(let (($x346 (or false false)))
(let (($x186 (and (distinct (bvmul ((_ sign_extend 32) ?x58) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x212)) true)))
(let (($x539 (or $x346 false (or $x186))))
(let (($x217 (or $x539 $x346 (or (and (distinct (bvsub ((_ sign_extend 1) ?x212) ((_ sign_extend 1) ?x622)) ?x88) true)))))
(let (($x434 (or $x346 $x217 (or $x534))))
(let (($x737 (or $x434 false)))
(and (not $x737) (or $x737 (and (distinct ?x38 ?x38) true)))))))))))))))))))
(check-sat)
; query 15: function core_bench_list, block 82, name %90
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x346 (or false false)))
(let (($x21 (not $x346)))
(and $x21 (or $x346 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 16: function core_bench_list, block 82, name %91
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1464 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x346 (or false false)))
(let (($x63 (or $x346 false false)))
(let (($x2056 (not $x63)))
(and $x2056 (or $x63 (and (distinct ?x1464 ?x1464) true))))))))
(check-sat)
; query 17: function core_bench_state, block 105, name %106
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x297 (or false false false)))
(let (($x921 (not $x297)))
(and $x921 (or $x297 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 18: function core_bench_state, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x297 (or false false false)))
(let (($x921 (not $x297)))
(and $x921 (or $x297 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 19: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x76 (bvadd in.01_32 (_ bv1 32))))
(let (($x155 (and (distinct ?x76 ?x76) true)))
(let (($x297 (or false false false)))
(let (($x921 (not $x297)))
(and $x921 (or $x297 $x155)))))))
(check-sat)
; query 20: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x76 (bvadd in.01_32 (_ bv1 32))))
(let ((?x1862 (bvmul ?x76 ?x76)))
(let (($x297 (or false false false)))
(let (($x1063 (or $x297 $x297 false)))
(and (not $x1063) (or $x1063 (and (distinct ?x1862 ?x1862) true))))))))
(check-sat)
; query 21: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x76 (bvadd in.01_32 (_ bv1 32))))
(let ((?x1862 (bvmul ?x76 ?x76)))
(let ((?x583 (bvmul ?x1862 (_ bv2 32))))
(let (($x297 (or false false false)))
(let (($x1063 (or $x297 $x297 false)))
(let (($x450 (or $x1063 false false)))
(and (not $x450) (or $x450 (and (distinct ?x583 ?x583) true))))))))))
(check-sat)
; query 22: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x76 (bvadd in.01_32 (_ bv1 32))))
(let ((?x1862 (bvmul ?x76 ?x76)))
(let ((?x583 (bvmul ?x1862 (_ bv2 32))))
(let ((?x168 (bvmul ?x583 (_ bv4 32))))
(let (($x297 (or false false false)))
(let (($x1063 (or $x297 $x297 false)))
(let (($x450 (or $x1063 false false)))
(let (($x2058 (or $x450 false false)))
(and (not $x2058) (or $x2058 (and (distinct ?x168 ?x168) true))))))))))))
(check-sat)
; query 23: function core_init_matrix, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x297 (or false false false)))
(let (($x921 (not $x297)))
(and $x921 (or $x297 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 24: function core_init_matrix, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x297 (or false false false)))
(let (($x921 (not $x297)))
(and $x921 (or $x297 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 25: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x5079 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x297 (or false false false)))
(let (($x921 (not $x297)))
(and $x921 (or $x297 (and (distinct ?x5079 ?x5079) true)))))))
(check-sat)
; query 26: function core_init_state, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_32 () (_ BitVec 32))
(assert
 (let (($x297 (or false false false)))
(let (($x921 (not $x297)))
(and $x921 (or $x297 (and (distinct (bvadd in.06_32 (_ bv1 32)) (bvadd in.06_32 (_ bv1 32))) true))))))
(check-sat)
; query 27: function core_init_state, block 65, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let (($x297 (or false false false)))
(let (($x921 (not $x297)))
(and $x921 (or $x297 (and (distinct (bvadd in4_32 (_ bv1 32)) (bvadd in4_32 (_ bv1 32))) true))))))
(check-sat)
; query 28: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x421 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x297 (or false false false)))
(let (($x921 (not $x297)))
(and $x921 (or $x297 (and (distinct ?x421 ?x421) true)))))))
(check-sat)
; query 29: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x297 (or false false false)))
(let (($x921 (not $x297)))
(and $x921 (or $x297 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 30: function core_list_init, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x76 (bvadd in.01_32 (_ bv1 32))))
(let (($x155 (and (distinct ?x76 ?x76) true)))
(let (($x297 (or false false false)))
(let (($x921 (not $x297)))
(and $x921 (or $x297 $x155)))))))
(check-sat)
; query 31: function core_list_mergesort, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x76 (bvadd in.01_32 (_ bv1 32))))
(let (($x155 (and (distinct ?x76 ?x76) true)))
(let (($x2008 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x76)) true)))
(let (($x542 (or false false (or $x2008))))
(and (not $x542) (or $x542 $x155)))))))
(check-sat)
; query 32: function core_list_mergesort, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x372 (ite (bvslt (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x297 (or false false false)))
(let (($x921 (not $x297)))
(and $x921 (or $x297 (and (distinct ?x372 ?x372) true)))))))
(check-sat)
; query 33: function core_list_mergesort, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.224_32 () (_ BitVec 32))
(assert
 (let ((?x131 (ite (= (_ bv0 32) in.224_32) (_ bv1 1) (_ bv0 1))))
(let (($x297 (or false false false)))
(let (($x921 (not $x297)))
(and $x921 (or $x297 (and (distinct ?x131 ?x131) true)))))))
(check-sat)
; query 34: function core_list_mergesort, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x569 (ite (= (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x297 (or false false false)))
(let (($x921 (not $x297)))
(and $x921 (or $x297 (and (distinct ?x569 ?x569) true)))))))
(check-sat)
; query 35: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x634 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x267 (or false false (or $x634))))
(and (not $x267) (or $x267 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 36: function core_list_mergesort, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x386 (and (distinct (bvmul ((_ sign_extend 32) in.020_32) ((_ sign_extend 32) (_ bv2 32))) ((_ sign_extend 32) (bvmul in.020_32 (_ bv2 32)))) true)))
(let (($x2074 (or false false (or $x386))))
(and (not $x2074) (or $x2074 (and (distinct (bvmul in.020_32 (_ bv2 32)) (bvmul in.020_32 (_ bv2 32))) true))))))
(check-sat)
; query 37: function core_state_transition, block 102, name %103
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x346 (or false false)))
(let (($x21 (not $x346)))
(and $x21 (or $x346 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 38: function core_state_transition, block 102, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x2020 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x346 (or false false)))
(let (($x63 (or $x346 false false)))
(let (($x2056 (not $x63)))
(and $x2056 (or $x63 (and (distinct ?x2020 ?x2020) true))))))))
(check-sat)
; query 39: function core_state_transition, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x346 (or false false)))
(let (($x21 (not $x346)))
(and $x21 (or $x346 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 40: function core_state_transition, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1704 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x346 (or false false)))
(let (($x63 (or $x346 false false)))
(let (($x2056 (not $x63)))
(and $x2056 (or $x63 (and (distinct ?x1704 ?x1704) true))))))))
(check-sat)
; query 41: function core_state_transition, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x346 (or false false)))
(let (($x21 (not $x346)))
(and $x21 (or $x346 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 42: function core_state_transition, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x2020 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x346 (or false false)))
(let (($x63 (or $x346 false false)))
(let (($x2056 (not $x63)))
(and $x2056 (or $x63 (and (distinct ?x2020 ?x2020) true))))))))
(check-sat)
; query 43: function core_state_transition, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x346 (or false false)))
(let (($x21 (not $x346)))
(and $x21 (or $x346 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 44: function core_state_transition, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1870 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x346 (or false false)))
(let (($x63 (or $x346 false false)))
(let (($x2056 (not $x63)))
(and $x2056 (or $x63 (and (distinct ?x1870 ?x1870) true))))))))
(check-sat)
; query 45: function core_state_transition, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x346 (or false false)))
(let (($x21 (not $x346)))
(and $x21 (or $x346 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 46: function core_state_transition, block 51, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1870 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x346 (or false false)))
(let (($x63 (or $x346 false false)))
(let (($x2056 (not $x63)))
(and $x2056 (or $x63 (and (distinct ?x1870 ?x1870) true))))))))
(check-sat)
; query 47: function core_state_transition, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x346 (or false false)))
(let (($x21 (not $x346)))
(and $x21 (or $x346 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 48: function core_state_transition, block 64, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1870 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x346 (or false false)))
(let (($x63 (or $x346 false false)))
(let (($x2056 (not $x63)))
(and $x2056 (or $x63 (and (distinct ?x1870 ?x1870) true))))))))
(check-sat)
; query 49: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x3278 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x297 (or false false false)))
(let (($x921 (not $x297)))
(and $x921 (or $x297 (and (distinct ?x3278 ?x3278) true)))))))
(check-sat)
; query 50: function core_state_transition, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x346 (or false false)))
(let (($x21 (not $x346)))
(and $x21 (or $x346 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 51: function core_state_transition, block 80, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x2775 (ite (= (_ bv69 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x346 (or false false)))
(let (($x63 (or $x346 false false)))
(let (($x2056 (not $x63)))
(and $x2056 (or $x63 (and (distinct ?x2775 ?x2775) true))))))))
(check-sat)
; query 52: function core_state_transition, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x346 (or false false)))
(let (($x21 (not $x346)))
(and $x21 (or $x346 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 53: function core_state_transition, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x923 (ite (= (_ bv101 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x346 (or false false)))
(let (($x63 (or $x346 false false)))
(let (($x2056 (not $x63)))
(and $x2056 (or $x63 (and (distinct ?x923 ?x923) true))))))))
(check-sat)
; query 54: function core_state_transition, block 99, name %100
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x346 (or false false)))
(let (($x21 (not $x346)))
(and $x21 (or $x346 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 55: function core_state_transition, block 99, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1704 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x346 (or false false)))
(let (($x63 (or $x346 false false)))
(let (($x2056 (not $x63)))
(and $x2056 (or $x63 (and (distinct ?x1704 ?x1704) true))))))))
(check-sat)
; query 56: function crcu8, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x346 (or false false)))
(let (($x21 (not $x346)))
(and $x21 (or $x346 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 57: function crcu8, block 19, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x707 ((_ zero_extend 16) in.01_16)))
(let ((?x959 (bvxor ?x707 (_ bv16386 32))))
(let (($x346 (or false false)))
(let (($x63 (or $x346 false false)))
(let (($x2056 (not $x63)))
(and $x2056 (or $x63 (and (distinct ?x959 ?x959) true)))))))))
(check-sat)
; query 58: function crcu8, block 19, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x707 ((_ zero_extend 16) in.01_16)))
(let ((?x959 (bvxor ?x707 (_ bv16386 32))))
(let ((?x852 ((_ extract 15 0) ?x959)))
(let (($x346 (or false false)))
(let (($x63 (or $x346 false false)))
(let (($x1042 (or $x63 false)))
(let (($x116 (not $x1042)))
(and $x116 (or $x1042 (and (distinct ?x852 ?x852) true)))))))))))
(check-sat)
; query 59: function crcu8, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x346 (or false false)))
(let (($x21 (not $x346)))
(and $x21 (or $x346 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 60: function crcu8, block 29, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x3335 ((_ zero_extend 16) in27_16)))
(let ((?x1019 (bvor ?x3335 (_ bv32768 32))))
(let (($x346 (or false false)))
(let (($x63 (or $x346 false false)))
(let (($x2056 (not $x63)))
(and $x2056 (or $x63 (and (distinct ?x1019 ?x1019) true)))))))))
(check-sat)
; query 61: function crcu8, block 29, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x3335 ((_ zero_extend 16) in27_16)))
(let ((?x1019 (bvor ?x3335 (_ bv32768 32))))
(let ((?x4346 ((_ extract 15 0) ?x1019)))
(let (($x346 (or false false)))
(let (($x63 (or $x346 false false)))
(let (($x1042 (or $x63 false)))
(let (($x116 (not $x1042)))
(and $x116 (or $x1042 (and (distinct ?x4346 ?x4346) true)))))))))))
(check-sat)
; query 62: function crcu8, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x346 (or false false)))
(let (($x21 (not $x346)))
(and $x21 (or $x346 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 63: function crcu8, block 33, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x3335 ((_ zero_extend 16) in27_16)))
(let ((?x3093 (bvand ?x3335 (_ bv32767 32))))
(let (($x346 (or false false)))
(let (($x63 (or $x346 false false)))
(let (($x2056 (not $x63)))
(and $x2056 (or $x63 (and (distinct ?x3093 ?x3093) true)))))))))
(check-sat)
; query 64: function crcu8, block 33, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x3335 ((_ zero_extend 16) in27_16)))
(let ((?x3093 (bvand ?x3335 (_ bv32767 32))))
(let ((?x5294 ((_ extract 15 0) ?x3093)))
(let (($x346 (or false false)))
(let (($x63 (or $x346 false false)))
(let (($x1042 (or $x63 false)))
(let (($x116 (not $x1042)))
(and $x116 (or $x1042 (and (distinct ?x5294 ?x5294) true)))))))))))
(check-sat)
; query 65: function crcu8, block 38, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_8 () (_ BitVec 8))
(assert
 (let (($x297 (or false false false)))
(let (($x921 (not $x297)))
(and $x921 (or $x297 (and (distinct (bvadd in.02_8 (_ bv1 8)) (bvadd in.02_8 (_ bv1 8))) true))))))
(check-sat)
; query 66: function crcu8, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x1149 ((_ extract 7 0) in.01_16)))
(let ((?x2482 ((_ zero_extend 24) ?x1149)))
(let (($x346 (or false false)))
(let (($x1633 (or $x346 false)))
(and (not $x1633) (or $x1633 (and (distinct ?x2482 ?x2482) true))))))))
(check-sat)
; query 67: function crcu8, block 6, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x1149 ((_ extract 7 0) in.01_16)))
(let ((?x2482 ((_ zero_extend 24) ?x1149)))
(let ((?x4296 (bvand ?x2482 (_ bv1 32))))
(let (($x346 (or false false)))
(let (($x1633 (or $x346 false)))
(let (($x2516 (or $x1633 false false)))
(and (not $x2516) (or $x2516 (and (distinct ?x4296 ?x4296) true))))))))))
(check-sat)
; query 68: function crcu8, block 6, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1149 ((_ extract 7 0) in.01_16)))
(let ((?x2482 ((_ zero_extend 24) ?x1149)))
(let ((?x4296 (bvand ?x2482 (_ bv1 32))))
(let ((?x931 ((_ zero_extend 24) in.0_8)))
(let ((?x861 (bvand ?x931 (_ bv1 32))))
(let ((?x1080 (bvxor ?x861 ?x4296)))
(let (($x346 (or false false)))
(let (($x1633 (or $x346 false)))
(let (($x2516 (or $x1633 false false)))
(let (($x63 (or $x346 false false)))
(let (($x7214 (or $x63 $x2516 false)))
(and (not $x7214) (or $x7214 (and (distinct ?x1080 ?x1080) true)))))))))))))))
(check-sat)
; query 69: function crcu8, block 6, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1149 ((_ extract 7 0) in.01_16)))
(let ((?x2482 ((_ zero_extend 24) ?x1149)))
(let ((?x4296 (bvand ?x2482 (_ bv1 32))))
(let ((?x931 ((_ zero_extend 24) in.0_8)))
(let ((?x861 (bvand ?x931 (_ bv1 32))))
(let ((?x1080 (bvxor ?x861 ?x4296)))
(let ((?x5093 ((_ extract 7 0) ?x1080)))
(let (($x346 (or false false)))
(let (($x1633 (or $x346 false)))
(let (($x2516 (or $x1633 false false)))
(let (($x63 (or $x346 false false)))
(let (($x7214 (or $x63 $x2516 false)))
(let (($x1897 (or $x7214 false)))
(and (not $x1897) (or $x1897 (and (distinct ?x5093 ?x5093) true)))))))))))))))))
(check-sat)
; query 70: function crcu8, block 6, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x346 (or false false)))
(let (($x21 (not $x346)))
(and $x21 (or $x346 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 71: function crcu8, block 6, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x931 ((_ zero_extend 24) in.0_8)))
(let ((?x1375 (bvashr ?x931 (_ bv1 32))))
(let (($x346 (or false false)))
(let (($x63 (or $x346 false false)))
(let (($x4257 (or $x63 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not $x4257) (or $x4257 (and (distinct ?x1375 ?x1375) true)))))))))
(check-sat)
; query 72: function crcu8, block 6, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x931 ((_ zero_extend 24) in.0_8)))
(let ((?x1375 (bvashr ?x931 (_ bv1 32))))
(let ((?x527 ((_ extract 7 0) ?x1375)))
(let (($x346 (or false false)))
(let (($x63 (or $x346 false false)))
(let (($x4257 (or $x63 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x1962 (or $x4257 false)))
(and (not $x1962) (or $x1962 (and (distinct ?x527 ?x527) true)))))))))))
(check-sat)
; query 73: function crcu8, block 6, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1149 ((_ extract 7 0) in.01_16)))
(let ((?x2482 ((_ zero_extend 24) ?x1149)))
(let ((?x4296 (bvand ?x2482 (_ bv1 32))))
(let ((?x931 ((_ zero_extend 24) in.0_8)))
(let ((?x861 (bvand ?x931 (_ bv1 32))))
(let ((?x1080 (bvxor ?x861 ?x4296)))
(let ((?x5093 ((_ extract 7 0) ?x1080)))
(let ((?x5867 ((_ zero_extend 24) ?x5093)))
(let (($x346 (or false false)))
(let (($x1633 (or $x346 false)))
(let (($x2516 (or $x1633 false false)))
(let (($x63 (or $x346 false false)))
(let (($x7214 (or $x63 $x2516 false)))
(let (($x1897 (or $x7214 false)))
(let (($x2328 (or $x1897 false)))
(and (not $x2328) (or $x2328 (and (distinct ?x5867 ?x5867) true)))))))))))))))))))
(check-sat)
; query 74: function crcu8, block 6, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1149 ((_ extract 7 0) in.01_16)))
(let ((?x2482 ((_ zero_extend 24) ?x1149)))
(let ((?x4296 (bvand ?x2482 (_ bv1 32))))
(let ((?x931 ((_ zero_extend 24) in.0_8)))
(let ((?x861 (bvand ?x931 (_ bv1 32))))
(let ((?x1080 (bvxor ?x861 ?x4296)))
(let ((?x5093 ((_ extract 7 0) ?x1080)))
(let ((?x5867 ((_ zero_extend 24) ?x5093)))
(let ((?x481 (ite (= (_ bv1 32) ?x5867) (_ bv1 1) (_ bv0 1))))
(let (($x346 (or false false)))
(let (($x1633 (or $x346 false)))
(let (($x2516 (or $x1633 false false)))
(let (($x63 (or $x346 false false)))
(let (($x7214 (or $x63 $x2516 false)))
(let (($x1897 (or $x7214 false)))
(let (($x2328 (or $x1897 false)))
(let (($x1518 (or $x2328 false false)))
(and (not $x1518) (or $x1518 (and (distinct ?x481 ?x481) true)))))))))))))))))))))
(check-sat)
; query 75: function crcu8, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x346 (or false false)))
(let (($x21 (not $x346)))
(and $x21 (or $x346 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 76: function crcu8, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x931 ((_ zero_extend 24) in.0_8)))
(let ((?x861 (bvand ?x931 (_ bv1 32))))
(let (($x346 (or false false)))
(let (($x63 (or $x346 false false)))
(let (($x2056 (not $x63)))
(and $x2056 (or $x63 (and (distinct ?x861 ?x861) true)))))))))
(check-sat)
; query 77: function crcu8, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x346 (or false false)))
(let (($x21 (not $x346)))
(and $x21 (or $x346 (and (distinct ((_ extract 7 0) in.01_16) ((_ extract 7 0) in.01_16)) true))))))
(check-sat)
; query 78: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x7099 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x4228 ((_ zero_extend 31) ?x7099)))
(let ((?x367 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x69 ((_ zero_extend 31) ?x367)))
(let ((?x2631 (bvand ?x69 ?x4228)))
(let ((?x122 (ite (and (distinct (_ bv0 32) ?x2631) true) (_ bv1 1) (_ bv0 1))))
(let ((?x5058 ((_ zero_extend 63) ?x122)))
(let (($x346 (or false false)))
(let (($x63 (or $x346 false false)))
(let (($x1042 (or $x63 false)))
(let (($x3791 (or $x1042 $x1042 false)))
(let (($x7079 (or $x3791 false false)))
(let (($x4845 (or $x7079 false)))
(and (not $x4845) (or $x4845 (and (distinct ?x5058 ?x5058) true)))))))))))))))))
(check-sat)
; query 79: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x7099 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x4228 ((_ zero_extend 31) ?x7099)))
(let ((?x367 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x69 ((_ zero_extend 31) ?x367)))
(let ((?x2631 (bvand ?x69 ?x4228)))
(let ((?x122 (ite (and (distinct (_ bv0 32) ?x2631) true) (_ bv1 1) (_ bv0 1))))
(let (($x1432 (= (_ bv1 1) ?x122)))
(let ((?x1415 (ite $x1432 (_ bv1 32) (_ bv0 32))))
(let (($x346 (or false false)))
(let (($x63 (or $x346 false false)))
(let (($x1042 (or $x63 false)))
(let (($x3791 (or $x1042 $x1042 false)))
(let (($x7079 (or $x3791 false false)))
(let (($x1048 (or $x7079 (ite $x1432 false false))))
(and (not $x1048) (or $x1048 (and (distinct ?x1415 ?x1415) true))))))))))))))))))
(check-sat)
; query 80: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x7099 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x4228 ((_ zero_extend 31) ?x7099)))
(let ((?x367 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x69 ((_ zero_extend 31) ?x367)))
(let ((?x2631 (bvand ?x69 ?x4228)))
(let ((?x122 (ite (and (distinct (_ bv0 32) ?x2631) true) (_ bv1 1) (_ bv0 1))))
(let (($x1432 (= (_ bv1 1) ?x122)))
(let ((?x1415 (ite $x1432 (_ bv1 32) (_ bv0 32))))
(let ((?x5219 ((_ extract 7 0) ?x1415)))
(let (($x346 (or false false)))
(let (($x63 (or $x346 false false)))
(let (($x1042 (or $x63 false)))
(let (($x3791 (or $x1042 $x1042 false)))
(let (($x7079 (or $x3791 false false)))
(let (($x1048 (or $x7079 (ite $x1432 false false))))
(let (($x5454 (or $x1048 false)))
(and (not $x5454) (or $x5454 (and (distinct ?x5219 ?x5219) true))))))))))))))))))))
(check-sat)
; query 81: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x346 (or false false)))
(let (($x21 (not $x346)))
(and $x21 (or $x346 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 82: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x367 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x346 (or false false)))
(let (($x63 (or $x346 false false)))
(let (($x2056 (not $x63)))
(and $x2056 (or $x63 (and (distinct ?x367 ?x367) true))))))))
(check-sat)
; query 83: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x367 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x69 ((_ zero_extend 31) ?x367)))
(let (($x346 (or false false)))
(let (($x63 (or $x346 false false)))
(let (($x1042 (or $x63 false)))
(let (($x116 (not $x1042)))
(and $x116 (or $x1042 (and (distinct ?x69 ?x69) true))))))))))
(check-sat)
; query 84: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x346 (or false false)))
(let (($x21 (not $x346)))
(and $x21 (or $x346 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 85: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x7099 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x346 (or false false)))
(let (($x63 (or $x346 false false)))
(let (($x2056 (not $x63)))
(and $x2056 (or $x63 (and (distinct ?x7099 ?x7099) true))))))))
(check-sat)
; query 86: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x7099 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x4228 ((_ zero_extend 31) ?x7099)))
(let (($x346 (or false false)))
(let (($x63 (or $x346 false false)))
(let (($x1042 (or $x63 false)))
(let (($x116 (not $x1042)))
(and $x116 (or $x1042 (and (distinct ?x4228 ?x4228) true))))))))))
(check-sat)
; query 87: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x7099 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x4228 ((_ zero_extend 31) ?x7099)))
(let ((?x367 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x69 ((_ zero_extend 31) ?x367)))
(let ((?x2631 (bvand ?x69 ?x4228)))
(let (($x346 (or false false)))
(let (($x63 (or $x346 false false)))
(let (($x1042 (or $x63 false)))
(let (($x3791 (or $x1042 $x1042 false)))
(and (not $x3791) (or $x3791 (and (distinct ?x2631 ?x2631) true)))))))))))))
(check-sat)
; query 88: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x7099 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x4228 ((_ zero_extend 31) ?x7099)))
(let ((?x367 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x69 ((_ zero_extend 31) ?x367)))
(let ((?x2631 (bvand ?x69 ?x4228)))
(let ((?x122 (ite (and (distinct (_ bv0 32) ?x2631) true) (_ bv1 1) (_ bv0 1))))
(let (($x346 (or false false)))
(let (($x63 (or $x346 false false)))
(let (($x1042 (or $x63 false)))
(let (($x3791 (or $x1042 $x1042 false)))
(let (($x7079 (or $x3791 false false)))
(and (not $x7079) (or $x7079 (and (distinct ?x122 ?x122) true)))))))))))))))
(check-sat)
; query 89: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1873 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x297 (or false false false)))
(let (($x921 (not $x297)))
(and $x921 (or $x297 (and (distinct ?x1873 ?x1873) true)))))))
(check-sat)
; query 90: function matrix_add_const, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x297 (or false false false)))
(let (($x921 (not $x297)))
(and $x921 (or $x297 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 91: function matrix_add_const, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x76 (bvadd in.01_32 (_ bv1 32))))
(let (($x155 (and (distinct ?x76 ?x76) true)))
(let (($x297 (or false false false)))
(let (($x921 (not $x297)))
(and $x921 (or $x297 $x155)))))))
(check-sat)
; query 92: function matrix_mul_const, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x297 (or false false false)))
(let (($x921 (not $x297)))
(and $x921 (or $x297 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 93: function matrix_mul_const, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x76 (bvadd in.01_32 (_ bv1 32))))
(let (($x155 (and (distinct ?x76 ?x76) true)))
(let (($x297 (or false false false)))
(let (($x921 (not $x297)))
(and $x921 (or $x297 $x155)))))))
(check-sat)
; query 94: function matrix_mul_matrix, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x297 (or false false false)))
(let (($x921 (not $x297)))
(and $x921 (or $x297 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 95: function matrix_mul_matrix, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x76 (bvadd in.01_32 (_ bv1 32))))
(let (($x155 (and (distinct ?x76 ?x76) true)))
(let (($x297 (or false false false)))
(let (($x921 (not $x297)))
(and $x921 (or $x297 $x155)))))))
(check-sat)
; query 96: function matrix_mul_matrix, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x297 (or false false false)))
(let (($x921 (not $x297)))
(and $x921 (or $x297 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 97: function matrix_mul_matrix_bitextract, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x297 (or false false false)))
(let (($x921 (not $x297)))
(and $x921 (or $x297 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 98: function matrix_mul_matrix_bitextract, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x76 (bvadd in.01_32 (_ bv1 32))))
(let (($x155 (and (distinct ?x76 ?x76) true)))
(let (($x297 (or false false false)))
(let (($x921 (not $x297)))
(and $x921 (or $x297 $x155)))))))
(check-sat)
; query 99: function matrix_mul_matrix_bitextract, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x297 (or false false false)))
(let (($x921 (not $x297)))
(and $x921 (or $x297 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 100: function matrix_mul_vect, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x297 (or false false false)))
(let (($x921 (not $x297)))
(and $x921 (or $x297 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 101: function matrix_mul_vect, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x76 (bvadd in.01_32 (_ bv1 32))))
(let (($x155 (and (distinct ?x76 ?x76) true)))
(let (($x297 (or false false false)))
(let (($x921 (not $x297)))
(and $x921 (or $x297 $x155)))))))
(check-sat)
; query 102: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x346 (or false false)))
(let (($x21 (not $x346)))
(and $x21 (or $x346 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 103: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x5060 ((_ sign_extend 16) in.1_16)))
(let ((?x1087 (bvadd ?x5060 (_ bv10 32))))
(let (($x1390 (and (distinct (bvadd ((_ sign_extend 1) ?x5060) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x1087)) true)))
(let (($x346 (or false false)))
(let (($x4997 (or $x346 false (or $x1390))))
(and (not $x4997) (or $x4997 (and (distinct ?x1087 ?x1087) true)))))))))
(check-sat)
; query 104: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x5060 ((_ sign_extend 16) in.1_16)))
(let ((?x1087 (bvadd ?x5060 (_ bv10 32))))
(let ((?x3171 ((_ extract 15 0) ?x1087)))
(let (($x1390 (and (distinct (bvadd ((_ sign_extend 1) ?x5060) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x1087)) true)))
(let (($x346 (or false false)))
(let (($x4997 (or $x346 false (or $x1390))))
(let (($x541 (or $x4997 false)))
(and (not $x541) (or $x541 (and (distinct ?x3171 ?x3171) true)))))))))))
(check-sat)
; query 105: function matrix_sum, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x7250 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x297 (or false false false)))
(let (($x921 (not $x297)))
(and $x921 (or $x297 (and (distinct ?x7250 ?x7250) true)))))))
(check-sat)
; query 106: function matrix_sum, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x7250 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let ((?x3072 ((_ zero_extend 63) ?x7250)))
(let (($x297 (or false false false)))
(let (($x5136 (or $x297 false)))
(and (not $x5136) (or $x5136 (and (distinct ?x3072 ?x3072) true))))))))
(check-sat)
; query 107: function matrix_sum, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x7250 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x1963 (= (_ bv1 1) ?x7250)))
(let ((?x2583 (ite $x1963 (_ bv1 32) (_ bv0 32))))
(let (($x297 (or false false false)))
(let (($x5744 (or $x297 (ite $x1963 false false))))
(and (not $x5744) (or $x5744 (and (distinct ?x2583 ?x2583) true)))))))))
(check-sat)
; query 108: function matrix_sum, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x346 (or false false)))
(let (($x21 (not $x346)))
(and $x21 (or $x346 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 109: function matrix_sum, block 22, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x7250 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x1963 (= (_ bv1 1) ?x7250)))
(let ((?x2583 (ite $x1963 (_ bv1 32) (_ bv0 32))))
(let ((?x5060 ((_ sign_extend 16) in.1_16)))
(let ((?x6979 (bvadd ?x5060 ?x2583)))
(let (($x7047 (and (distinct (bvadd ((_ sign_extend 1) ?x5060) ((_ sign_extend 1) ?x2583)) ((_ sign_extend 1) ?x6979)) true)))
(let (($x297 (or false false false)))
(let (($x5744 (or $x297 (ite $x1963 false false))))
(let (($x346 (or false false)))
(let (($x2765 (or $x346 $x5744 (or $x7047))))
(and (not $x2765) (or $x2765 (and (distinct ?x6979 ?x6979) true))))))))))))))
(check-sat)
; query 110: function matrix_sum, block 22, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x7250 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x1963 (= (_ bv1 1) ?x7250)))
(let ((?x2583 (ite $x1963 (_ bv1 32) (_ bv0 32))))
(let ((?x5060 ((_ sign_extend 16) in.1_16)))
(let ((?x6979 (bvadd ?x5060 ?x2583)))
(let ((?x5517 ((_ extract 15 0) ?x6979)))
(let (($x7047 (and (distinct (bvadd ((_ sign_extend 1) ?x5060) ((_ sign_extend 1) ?x2583)) ((_ sign_extend 1) ?x6979)) true)))
(let (($x297 (or false false false)))
(let (($x5744 (or $x297 (ite $x1963 false false))))
(let (($x346 (or false false)))
(let (($x2765 (or $x346 $x5744 (or $x7047))))
(let (($x5182 (or $x2765 false)))
(and (not $x5182) (or $x5182 (and (distinct ?x5517 ?x5517) true))))))))))))))))
(check-sat)
; query 111: function matrix_sum, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x297 (or false false false)))
(let (($x921 (not $x297)))
(and $x921 (or $x297 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 112: function matrix_sum, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x76 (bvadd in.01_32 (_ bv1 32))))
(let (($x155 (and (distinct ?x76 ?x76) true)))
(let (($x297 (or false false false)))
(let (($x921 (not $x297)))
(and $x921 (or $x297 $x155)))))))
(check-sat)
; query 113: function parseval, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.23_32 () (_ BitVec 32))
(assert
 (let (($x573 (and (distinct (bvmul ((_ sign_extend 32) in.23_32) ((_ sign_extend 32) (_ bv1024 32))) ((_ sign_extend 32) (bvmul in.23_32 (_ bv1024 32)))) true)))
(let (($x2215 (or false false (or $x573))))
(and (not $x2215) (or $x2215 (and (distinct (bvmul in.23_32 (_ bv1024 32)) (bvmul in.23_32 (_ bv1024 32))) true))))))
(check-sat)
; query 114: function parseval, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.34_32 () (_ BitVec 32))
(assert
 (let (($x5624 (and (distinct (bvmul ((_ sign_extend 32) in.34_32) ((_ sign_extend 32) (_ bv1048576 32))) ((_ sign_extend 32) (bvmul in.34_32 (_ bv1048576 32)))) true)))
(let (($x5284 (or false false (or $x5624))))
(and (not $x5284) (or $x5284 (and (distinct (bvmul in.34_32 (_ bv1048576 32)) (bvmul in.34_32 (_ bv1048576 32))) true))))))
(check-sat)
; query 115: function partition_memory, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x297 (or false false false)))
(let (($x921 (not $x297)))
(and $x921 (or $x297 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
