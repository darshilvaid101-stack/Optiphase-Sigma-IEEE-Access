; OptiPhase-Sigma refinement certificate for sweep K09-R2-014
; query 0: function xmalloc, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in7_32 () (_ BitVec 32))
(assert
 (let ((?x10 (ite (and (distinct (_ bv0 32) in7_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x76 (or false false false)))
(and (not $x76) (or $x76 (and (distinct ?x10 ?x10) true))))))
(check-sat)
