; OptiPhase-Sigma refinement certificate for sweep K54-R3-083
; query 0: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x586 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x139 (or false false false)))
(and (not $x139) (or $x139 (and (distinct ?x586 ?x586) true))))))
(check-sat)
