; OptiPhase-Sigma refinement certificate for sweep K58-R2-015
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x308 (or false false)))
(let (($x410 (not $x308)))
(and $x410 (or $x308 (and (distinct ((_ sign_extend 16) in25_16) ((_ sign_extend 16) in25_16)) true))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let ((?x831 (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))))
(let (($x308 (or false false)))
(let (($x938 (or $x308 false false)))
(let (($x15 (not $x938)))
(and $x15 (or $x938 (and (distinct ?x831 ?x831) true))))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x308 (or false false)))
(let (($x410 (not $x308)))
(and $x410 (or $x308 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x435 ((_ sign_extend 16) in3_16)))
(let ((?x278 (bvand ?x435 (_ bv127 32))))
(let (($x308 (or false false)))
(let (($x938 (or $x308 false false)))
(let (($x15 (not $x938)))
(and $x15 (or $x938 (and (distinct ?x278 ?x278) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x435 ((_ sign_extend 16) in3_16)))
(let ((?x278 (bvand ?x435 (_ bv127 32))))
(let ((?x480 ((_ extract 15 0) ?x278)))
(let (($x308 (or false false)))
(let (($x938 (or $x308 false false)))
(let (($x1059 (or $x938 false)))
(let (($x515 (not $x1059)))
(and $x515 (or $x1059 (and (distinct ?x480 ?x480) true)))))))))))
(check-sat)
; query 5: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x308 (or false false)))
(let (($x410 (not $x308)))
(and $x410 (or $x308 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 6: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x134 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x308 (or false false)))
(let (($x938 (or $x308 false false)))
(let (($x15 (not $x938)))
(and $x15 (or $x938 (and (distinct ?x134 ?x134) true))))))))
(check-sat)
; query 7: function core_bench_list, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x364 (or false false false)))
(let (($x24 (not $x364)))
(and $x24 (or $x364 (and (distinct (bvadd in.0_16 (_ bv1 16)) (bvadd in.0_16 (_ bv1 16))) true))))))
(check-sat)
; query 8: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x56 (bvadd in.01_32 (_ bv1 32))))
(let (($x402 (and (distinct ?x56 ?x56) true)))
(let (($x364 (or false false false)))
(let (($x24 (not $x364)))
(and $x24 (or $x364 $x402)))))))
(check-sat)
; query 9: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x56 (bvadd in.01_32 (_ bv1 32))))
(let ((?x51 (bvmul ?x56 ?x56)))
(let (($x364 (or false false false)))
(let (($x696 (or $x364 $x364 false)))
(and (not $x696) (or $x696 (and (distinct ?x51 ?x51) true))))))))
(check-sat)
; query 10: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x56 (bvadd in.01_32 (_ bv1 32))))
(let ((?x51 (bvmul ?x56 ?x56)))
(let ((?x396 (bvmul ?x51 (_ bv2 32))))
(let (($x364 (or false false false)))
(let (($x696 (or $x364 $x364 false)))
(let (($x124 (or $x696 false false)))
(and (not $x124) (or $x124 (and (distinct ?x396 ?x396) true))))))))))
(check-sat)
; query 11: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x56 (bvadd in.01_32 (_ bv1 32))))
(let ((?x51 (bvmul ?x56 ?x56)))
(let ((?x396 (bvmul ?x51 (_ bv2 32))))
(let ((?x287 (bvmul ?x396 (_ bv4 32))))
(let (($x364 (or false false false)))
(let (($x696 (or $x364 $x364 false)))
(let (($x124 (or $x696 false false)))
(let (($x516 (or $x124 false false)))
(and (not $x516) (or $x516 (and (distinct ?x287 ?x287) true))))))))))))
(check-sat)
; query 12: function core_init_matrix, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x364 (or false false false)))
(let (($x24 (not $x364)))
(and $x24 (or $x364 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 13: function core_init_matrix, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x364 (or false false false)))
(let (($x24 (not $x364)))
(and $x24 (or $x364 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 14: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x12 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x364 (or false false false)))
(let (($x24 (not $x364)))
(and $x24 (or $x364 (and (distinct ?x12 ?x12) true)))))))
(check-sat)
; query 15: function core_init_state, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_32 () (_ BitVec 32))
(assert
 (let (($x364 (or false false false)))
(let (($x24 (not $x364)))
(and $x24 (or $x364 (and (distinct (bvadd in.06_32 (_ bv1 32)) (bvadd in.06_32 (_ bv1 32))) true))))))
(check-sat)
; query 16: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x340 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x364 (or false false false)))
(let (($x24 (not $x364)))
(and $x24 (or $x364 (and (distinct ?x340 ?x340) true)))))))
(check-sat)
; query 17: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x364 (or false false false)))
(let (($x24 (not $x364)))
(and $x24 (or $x364 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 18: function core_list_init, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x56 (bvadd in.01_32 (_ bv1 32))))
(let (($x402 (and (distinct ?x56 ?x56) true)))
(let (($x364 (or false false false)))
(let (($x24 (not $x364)))
(and $x24 (or $x364 $x402)))))))
(check-sat)
; query 19: function core_list_mergesort, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x56 (bvadd in.01_32 (_ bv1 32))))
(let (($x402 (and (distinct ?x56 ?x56) true)))
(let (($x90 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x56)) true)))
(let (($x1060 (or false false (or $x90))))
(and (not $x1060) (or $x1060 $x402)))))))
(check-sat)
; query 20: function core_list_mergesort, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x429 (ite (bvslt (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x364 (or false false false)))
(let (($x24 (not $x364)))
(and $x24 (or $x364 (and (distinct ?x429 ?x429) true)))))))
(check-sat)
; query 21: function core_list_mergesort, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.224_32 () (_ BitVec 32))
(assert
 (let ((?x738 (ite (= (_ bv0 32) in.224_32) (_ bv1 1) (_ bv0 1))))
(let (($x364 (or false false false)))
(let (($x24 (not $x364)))
(and $x24 (or $x364 (and (distinct ?x738 ?x738) true)))))))
(check-sat)
; query 22: function core_list_mergesort, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x1077 (ite (= (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x364 (or false false false)))
(let (($x24 (not $x364)))
(and $x24 (or $x364 (and (distinct ?x1077 ?x1077) true)))))))
(check-sat)
; query 23: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x82 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x285 (or false false (or $x82))))
(and (not $x285) (or $x285 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 24: function core_list_mergesort, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x268 (and (distinct (bvmul ((_ sign_extend 32) in.020_32) ((_ sign_extend 32) (_ bv2 32))) ((_ sign_extend 32) (bvmul in.020_32 (_ bv2 32)))) true)))
(let (($x366 (or false false (or $x268))))
(and (not $x366) (or $x366 (and (distinct (bvmul in.020_32 (_ bv2 32)) (bvmul in.020_32 (_ bv2 32))) true))))))
(check-sat)
; query 25: function core_state_transition, block 102, name %103
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x308 (or false false)))
(let (($x410 (not $x308)))
(and $x410 (or $x308 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 26: function core_state_transition, block 102, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x43 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x308 (or false false)))
(let (($x938 (or $x308 false false)))
(let (($x15 (not $x938)))
(and $x15 (or $x938 (and (distinct ?x43 ?x43) true))))))))
(check-sat)
; query 27: function core_state_transition, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x308 (or false false)))
(let (($x410 (not $x308)))
(and $x410 (or $x308 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 28: function core_state_transition, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x155 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x308 (or false false)))
(let (($x938 (or $x308 false false)))
(let (($x15 (not $x938)))
(and $x15 (or $x938 (and (distinct ?x155 ?x155) true))))))))
(check-sat)
; query 29: function core_state_transition, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x308 (or false false)))
(let (($x410 (not $x308)))
(and $x410 (or $x308 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 30: function core_state_transition, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x43 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x308 (or false false)))
(let (($x938 (or $x308 false false)))
(let (($x15 (not $x938)))
(and $x15 (or $x938 (and (distinct ?x43 ?x43) true))))))))
(check-sat)
; query 31: function core_state_transition, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x308 (or false false)))
(let (($x410 (not $x308)))
(and $x410 (or $x308 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 32: function core_state_transition, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1848 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x308 (or false false)))
(let (($x938 (or $x308 false false)))
(let (($x15 (not $x938)))
(and $x15 (or $x938 (and (distinct ?x1848 ?x1848) true))))))))
(check-sat)
; query 33: function core_state_transition, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x308 (or false false)))
(let (($x410 (not $x308)))
(and $x410 (or $x308 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 34: function core_state_transition, block 51, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1848 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x308 (or false false)))
(let (($x938 (or $x308 false false)))
(let (($x15 (not $x938)))
(and $x15 (or $x938 (and (distinct ?x1848 ?x1848) true))))))))
(check-sat)
; query 35: function core_state_transition, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x308 (or false false)))
(let (($x410 (not $x308)))
(and $x410 (or $x308 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 36: function core_state_transition, block 64, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1848 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x308 (or false false)))
(let (($x938 (or $x308 false false)))
(let (($x15 (not $x938)))
(and $x15 (or $x938 (and (distinct ?x1848 ?x1848) true))))))))
(check-sat)
; query 37: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x1512 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x364 (or false false false)))
(let (($x24 (not $x364)))
(and $x24 (or $x364 (and (distinct ?x1512 ?x1512) true)))))))
(check-sat)
; query 38: function core_state_transition, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x308 (or false false)))
(let (($x410 (not $x308)))
(and $x410 (or $x308 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 39: function core_state_transition, block 80, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x2598 (ite (= (_ bv69 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x308 (or false false)))
(let (($x938 (or $x308 false false)))
(let (($x15 (not $x938)))
(and $x15 (or $x938 (and (distinct ?x2598 ?x2598) true))))))))
(check-sat)
; query 40: function core_state_transition, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x308 (or false false)))
(let (($x410 (not $x308)))
(and $x410 (or $x308 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 41: function core_state_transition, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x136 (ite (= (_ bv101 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x308 (or false false)))
(let (($x938 (or $x308 false false)))
(let (($x15 (not $x938)))
(and $x15 (or $x938 (and (distinct ?x136 ?x136) true))))))))
(check-sat)
; query 42: function core_state_transition, block 99, name %100
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x308 (or false false)))
(let (($x410 (not $x308)))
(and $x410 (or $x308 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 43: function core_state_transition, block 99, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x155 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x308 (or false false)))
(let (($x938 (or $x308 false false)))
(let (($x15 (not $x938)))
(and $x15 (or $x938 (and (distinct ?x155 ?x155) true))))))))
(check-sat)
; query 44: function crcu8, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x308 (or false false)))
(let (($x410 (not $x308)))
(and $x410 (or $x308 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 45: function crcu8, block 19, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x1594 ((_ zero_extend 16) in.01_16)))
(let ((?x250 (bvxor ?x1594 (_ bv16386 32))))
(let (($x308 (or false false)))
(let (($x938 (or $x308 false false)))
(let (($x15 (not $x938)))
(and $x15 (or $x938 (and (distinct ?x250 ?x250) true)))))))))
(check-sat)
; query 46: function crcu8, block 19, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x1594 ((_ zero_extend 16) in.01_16)))
(let ((?x250 (bvxor ?x1594 (_ bv16386 32))))
(let ((?x1240 ((_ extract 15 0) ?x250)))
(let (($x308 (or false false)))
(let (($x938 (or $x308 false false)))
(let (($x1059 (or $x938 false)))
(let (($x515 (not $x1059)))
(and $x515 (or $x1059 (and (distinct ?x1240 ?x1240) true)))))))))))
(check-sat)
; query 47: function crcu8, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x308 (or false false)))
(let (($x410 (not $x308)))
(and $x410 (or $x308 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 48: function crcu8, block 29, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x816 ((_ zero_extend 16) in27_16)))
(let ((?x669 (bvor ?x816 (_ bv32768 32))))
(let (($x308 (or false false)))
(let (($x938 (or $x308 false false)))
(let (($x15 (not $x938)))
(and $x15 (or $x938 (and (distinct ?x669 ?x669) true)))))))))
(check-sat)
; query 49: function crcu8, block 29, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x816 ((_ zero_extend 16) in27_16)))
(let ((?x669 (bvor ?x816 (_ bv32768 32))))
(let ((?x810 ((_ extract 15 0) ?x669)))
(let (($x308 (or false false)))
(let (($x938 (or $x308 false false)))
(let (($x1059 (or $x938 false)))
(let (($x515 (not $x1059)))
(and $x515 (or $x1059 (and (distinct ?x810 ?x810) true)))))))))))
(check-sat)
; query 50: function crcu8, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x308 (or false false)))
(let (($x410 (not $x308)))
(and $x410 (or $x308 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 51: function crcu8, block 33, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x816 ((_ zero_extend 16) in27_16)))
(let ((?x183 (bvand ?x816 (_ bv32767 32))))
(let (($x308 (or false false)))
(let (($x938 (or $x308 false false)))
(let (($x15 (not $x938)))
(and $x15 (or $x938 (and (distinct ?x183 ?x183) true)))))))))
(check-sat)
; query 52: function crcu8, block 33, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x816 ((_ zero_extend 16) in27_16)))
(let ((?x183 (bvand ?x816 (_ bv32767 32))))
(let ((?x840 ((_ extract 15 0) ?x183)))
(let (($x308 (or false false)))
(let (($x938 (or $x308 false false)))
(let (($x1059 (or $x938 false)))
(let (($x515 (not $x1059)))
(and $x515 (or $x1059 (and (distinct ?x840 ?x840) true)))))))))))
(check-sat)
; query 53: function crcu8, block 38, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_8 () (_ BitVec 8))
(assert
 (let (($x364 (or false false false)))
(let (($x24 (not $x364)))
(and $x24 (or $x364 (and (distinct (bvadd in.02_8 (_ bv1 8)) (bvadd in.02_8 (_ bv1 8))) true))))))
(check-sat)
; query 54: function crcu8, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x92 ((_ extract 7 0) in.01_16)))
(let ((?x70 ((_ zero_extend 24) ?x92)))
(let (($x308 (or false false)))
(let (($x1116 (or $x308 false)))
(and (not $x1116) (or $x1116 (and (distinct ?x70 ?x70) true))))))))
(check-sat)
; query 55: function crcu8, block 6, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x92 ((_ extract 7 0) in.01_16)))
(let ((?x70 ((_ zero_extend 24) ?x92)))
(let ((?x458 (bvand ?x70 (_ bv1 32))))
(let (($x308 (or false false)))
(let (($x1116 (or $x308 false)))
(let (($x219 (or $x1116 false false)))
(and (not $x219) (or $x219 (and (distinct ?x458 ?x458) true))))))))))
(check-sat)
; query 56: function crcu8, block 6, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x92 ((_ extract 7 0) in.01_16)))
(let ((?x70 ((_ zero_extend 24) ?x92)))
(let ((?x458 (bvand ?x70 (_ bv1 32))))
(let ((?x766 ((_ zero_extend 24) in.0_8)))
(let ((?x1348 (bvand ?x766 (_ bv1 32))))
(let ((?x420 (bvxor ?x1348 ?x458)))
(let (($x308 (or false false)))
(let (($x1116 (or $x308 false)))
(let (($x219 (or $x1116 false false)))
(let (($x938 (or $x308 false false)))
(let (($x1875 (or $x938 $x219 false)))
(and (not $x1875) (or $x1875 (and (distinct ?x420 ?x420) true)))))))))))))))
(check-sat)
; query 57: function crcu8, block 6, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x92 ((_ extract 7 0) in.01_16)))
(let ((?x70 ((_ zero_extend 24) ?x92)))
(let ((?x458 (bvand ?x70 (_ bv1 32))))
(let ((?x766 ((_ zero_extend 24) in.0_8)))
(let ((?x1348 (bvand ?x766 (_ bv1 32))))
(let ((?x420 (bvxor ?x1348 ?x458)))
(let ((?x502 ((_ extract 7 0) ?x420)))
(let (($x308 (or false false)))
(let (($x1116 (or $x308 false)))
(let (($x219 (or $x1116 false false)))
(let (($x938 (or $x308 false false)))
(let (($x1875 (or $x938 $x219 false)))
(let (($x1887 (or $x1875 false)))
(and (not $x1887) (or $x1887 (and (distinct ?x502 ?x502) true)))))))))))))))))
(check-sat)
; query 58: function crcu8, block 6, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x308 (or false false)))
(let (($x410 (not $x308)))
(and $x410 (or $x308 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 59: function crcu8, block 6, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x766 ((_ zero_extend 24) in.0_8)))
(let ((?x1767 (bvashr ?x766 (_ bv1 32))))
(let (($x308 (or false false)))
(let (($x938 (or $x308 false false)))
(let (($x1825 (or $x938 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not $x1825) (or $x1825 (and (distinct ?x1767 ?x1767) true)))))))))
(check-sat)
; query 60: function crcu8, block 6, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x766 ((_ zero_extend 24) in.0_8)))
(let ((?x1767 (bvashr ?x766 (_ bv1 32))))
(let ((?x953 ((_ extract 7 0) ?x1767)))
(let (($x308 (or false false)))
(let (($x938 (or $x308 false false)))
(let (($x1825 (or $x938 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x1492 (or $x1825 false)))
(and (not $x1492) (or $x1492 (and (distinct ?x953 ?x953) true)))))))))))
(check-sat)
; query 61: function crcu8, block 6, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x92 ((_ extract 7 0) in.01_16)))
(let ((?x70 ((_ zero_extend 24) ?x92)))
(let ((?x458 (bvand ?x70 (_ bv1 32))))
(let ((?x766 ((_ zero_extend 24) in.0_8)))
(let ((?x1348 (bvand ?x766 (_ bv1 32))))
(let ((?x420 (bvxor ?x1348 ?x458)))
(let ((?x502 ((_ extract 7 0) ?x420)))
(let ((?x286 ((_ zero_extend 24) ?x502)))
(let (($x308 (or false false)))
(let (($x1116 (or $x308 false)))
(let (($x219 (or $x1116 false false)))
(let (($x938 (or $x308 false false)))
(let (($x1875 (or $x938 $x219 false)))
(let (($x1887 (or $x1875 false)))
(let (($x2059 (or $x1887 false)))
(and (not $x2059) (or $x2059 (and (distinct ?x286 ?x286) true)))))))))))))))))))
(check-sat)
; query 62: function crcu8, block 6, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x92 ((_ extract 7 0) in.01_16)))
(let ((?x70 ((_ zero_extend 24) ?x92)))
(let ((?x458 (bvand ?x70 (_ bv1 32))))
(let ((?x766 ((_ zero_extend 24) in.0_8)))
(let ((?x1348 (bvand ?x766 (_ bv1 32))))
(let ((?x420 (bvxor ?x1348 ?x458)))
(let ((?x502 ((_ extract 7 0) ?x420)))
(let ((?x286 ((_ zero_extend 24) ?x502)))
(let ((?x1246 (ite (= (_ bv1 32) ?x286) (_ bv1 1) (_ bv0 1))))
(let (($x308 (or false false)))
(let (($x1116 (or $x308 false)))
(let (($x219 (or $x1116 false false)))
(let (($x938 (or $x308 false false)))
(let (($x1875 (or $x938 $x219 false)))
(let (($x1887 (or $x1875 false)))
(let (($x2059 (or $x1887 false)))
(let (($x2252 (or $x2059 false false)))
(and (not $x2252) (or $x2252 (and (distinct ?x1246 ?x1246) true)))))))))))))))))))))
(check-sat)
; query 63: function crcu8, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x308 (or false false)))
(let (($x410 (not $x308)))
(and $x410 (or $x308 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 64: function crcu8, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x766 ((_ zero_extend 24) in.0_8)))
(let ((?x1348 (bvand ?x766 (_ bv1 32))))
(let (($x308 (or false false)))
(let (($x938 (or $x308 false false)))
(let (($x15 (not $x938)))
(and $x15 (or $x938 (and (distinct ?x1348 ?x1348) true)))))))))
(check-sat)
; query 65: function crcu8, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x308 (or false false)))
(let (($x410 (not $x308)))
(and $x410 (or $x308 (and (distinct ((_ extract 7 0) in.01_16) ((_ extract 7 0) in.01_16)) true))))))
(check-sat)
; query 66: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x911 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x665 ((_ zero_extend 31) ?x911)))
(let ((?x5 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1861 ((_ zero_extend 31) ?x5)))
(let ((?x1789 (bvand ?x1861 ?x665)))
(let ((?x929 (ite (and (distinct (_ bv0 32) ?x1789) true) (_ bv1 1) (_ bv0 1))))
(let ((?x757 ((_ zero_extend 63) ?x929)))
(let (($x308 (or false false)))
(let (($x938 (or $x308 false false)))
(let (($x1059 (or $x938 false)))
(let (($x209 (or $x1059 $x1059 false)))
(let (($x1707 (or $x209 false false)))
(let (($x1734 (or $x1707 false)))
(and (not $x1734) (or $x1734 (and (distinct ?x757 ?x757) true)))))))))))))))))
(check-sat)
; query 67: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x911 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x665 ((_ zero_extend 31) ?x911)))
(let ((?x5 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1861 ((_ zero_extend 31) ?x5)))
(let ((?x1789 (bvand ?x1861 ?x665)))
(let ((?x929 (ite (and (distinct (_ bv0 32) ?x1789) true) (_ bv1 1) (_ bv0 1))))
(let (($x1557 (= (_ bv1 1) ?x929)))
(let ((?x1442 (ite $x1557 (_ bv1 32) (_ bv0 32))))
(let (($x308 (or false false)))
(let (($x938 (or $x308 false false)))
(let (($x1059 (or $x938 false)))
(let (($x209 (or $x1059 $x1059 false)))
(let (($x1707 (or $x209 false false)))
(let (($x313 (or $x1707 (ite $x1557 false false))))
(and (not $x313) (or $x313 (and (distinct ?x1442 ?x1442) true))))))))))))))))))
(check-sat)
; query 68: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x911 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x665 ((_ zero_extend 31) ?x911)))
(let ((?x5 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1861 ((_ zero_extend 31) ?x5)))
(let ((?x1789 (bvand ?x1861 ?x665)))
(let ((?x929 (ite (and (distinct (_ bv0 32) ?x1789) true) (_ bv1 1) (_ bv0 1))))
(let (($x1557 (= (_ bv1 1) ?x929)))
(let ((?x1442 (ite $x1557 (_ bv1 32) (_ bv0 32))))
(let ((?x434 ((_ extract 7 0) ?x1442)))
(let (($x308 (or false false)))
(let (($x938 (or $x308 false false)))
(let (($x1059 (or $x938 false)))
(let (($x209 (or $x1059 $x1059 false)))
(let (($x1707 (or $x209 false false)))
(let (($x313 (or $x1707 (ite $x1557 false false))))
(let (($x74 (or $x313 false)))
(and (not $x74) (or $x74 (and (distinct ?x434 ?x434) true))))))))))))))))))))
(check-sat)
; query 69: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x308 (or false false)))
(let (($x410 (not $x308)))
(and $x410 (or $x308 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 70: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x5 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x308 (or false false)))
(let (($x938 (or $x308 false false)))
(let (($x15 (not $x938)))
(and $x15 (or $x938 (and (distinct ?x5 ?x5) true))))))))
(check-sat)
; query 71: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x5 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1861 ((_ zero_extend 31) ?x5)))
(let (($x308 (or false false)))
(let (($x938 (or $x308 false false)))
(let (($x1059 (or $x938 false)))
(let (($x515 (not $x1059)))
(and $x515 (or $x1059 (and (distinct ?x1861 ?x1861) true))))))))))
(check-sat)
; query 72: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x308 (or false false)))
(let (($x410 (not $x308)))
(and $x410 (or $x308 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 73: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x911 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x308 (or false false)))
(let (($x938 (or $x308 false false)))
(let (($x15 (not $x938)))
(and $x15 (or $x938 (and (distinct ?x911 ?x911) true))))))))
(check-sat)
; query 74: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x911 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x665 ((_ zero_extend 31) ?x911)))
(let (($x308 (or false false)))
(let (($x938 (or $x308 false false)))
(let (($x1059 (or $x938 false)))
(let (($x515 (not $x1059)))
(and $x515 (or $x1059 (and (distinct ?x665 ?x665) true))))))))))
(check-sat)
; query 75: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x911 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x665 ((_ zero_extend 31) ?x911)))
(let ((?x5 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1861 ((_ zero_extend 31) ?x5)))
(let ((?x1789 (bvand ?x1861 ?x665)))
(let (($x308 (or false false)))
(let (($x938 (or $x308 false false)))
(let (($x1059 (or $x938 false)))
(let (($x209 (or $x1059 $x1059 false)))
(and (not $x209) (or $x209 (and (distinct ?x1789 ?x1789) true)))))))))))))
(check-sat)
; query 76: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x911 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x665 ((_ zero_extend 31) ?x911)))
(let ((?x5 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1861 ((_ zero_extend 31) ?x5)))
(let ((?x1789 (bvand ?x1861 ?x665)))
(let ((?x929 (ite (and (distinct (_ bv0 32) ?x1789) true) (_ bv1 1) (_ bv0 1))))
(let (($x308 (or false false)))
(let (($x938 (or $x308 false false)))
(let (($x1059 (or $x938 false)))
(let (($x209 (or $x1059 $x1059 false)))
(let (($x1707 (or $x209 false false)))
(and (not $x1707) (or $x1707 (and (distinct ?x929 ?x929) true)))))))))))))))
(check-sat)
; query 77: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x423 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x364 (or false false false)))
(let (($x24 (not $x364)))
(and $x24 (or $x364 (and (distinct ?x423 ?x423) true)))))))
(check-sat)
; query 78: function matrix_add_const, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x364 (or false false false)))
(let (($x24 (not $x364)))
(and $x24 (or $x364 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 79: function matrix_add_const, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x56 (bvadd in.01_32 (_ bv1 32))))
(let (($x402 (and (distinct ?x56 ?x56) true)))
(let (($x364 (or false false false)))
(let (($x24 (not $x364)))
(and $x24 (or $x364 $x402)))))))
(check-sat)
; query 80: function matrix_mul_const, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x364 (or false false false)))
(let (($x24 (not $x364)))
(and $x24 (or $x364 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 81: function matrix_mul_const, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x56 (bvadd in.01_32 (_ bv1 32))))
(let (($x402 (and (distinct ?x56 ?x56) true)))
(let (($x364 (or false false false)))
(let (($x24 (not $x364)))
(and $x24 (or $x364 $x402)))))))
(check-sat)
; query 82: function matrix_mul_matrix, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x364 (or false false false)))
(let (($x24 (not $x364)))
(and $x24 (or $x364 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 83: function matrix_mul_matrix, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x56 (bvadd in.01_32 (_ bv1 32))))
(let (($x402 (and (distinct ?x56 ?x56) true)))
(let (($x364 (or false false false)))
(let (($x24 (not $x364)))
(and $x24 (or $x364 $x402)))))))
(check-sat)
; query 84: function matrix_mul_matrix, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x364 (or false false false)))
(let (($x24 (not $x364)))
(and $x24 (or $x364 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 85: function matrix_mul_matrix_bitextract, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x364 (or false false false)))
(let (($x24 (not $x364)))
(and $x24 (or $x364 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 86: function matrix_mul_matrix_bitextract, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x56 (bvadd in.01_32 (_ bv1 32))))
(let (($x402 (and (distinct ?x56 ?x56) true)))
(let (($x364 (or false false false)))
(let (($x24 (not $x364)))
(and $x24 (or $x364 $x402)))))))
(check-sat)
; query 87: function matrix_mul_matrix_bitextract, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x364 (or false false false)))
(let (($x24 (not $x364)))
(and $x24 (or $x364 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 88: function matrix_mul_vect, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x364 (or false false false)))
(let (($x24 (not $x364)))
(and $x24 (or $x364 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 89: function matrix_mul_vect, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x56 (bvadd in.01_32 (_ bv1 32))))
(let (($x402 (and (distinct ?x56 ?x56) true)))
(let (($x364 (or false false false)))
(let (($x24 (not $x364)))
(and $x24 (or $x364 $x402)))))))
(check-sat)
; query 90: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x308 (or false false)))
(let (($x410 (not $x308)))
(and $x410 (or $x308 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 91: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x522 ((_ sign_extend 16) in.1_16)))
(let ((?x812 (bvadd ?x522 (_ bv10 32))))
(let (($x303 (and (distinct (bvadd ((_ sign_extend 1) ?x522) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x812)) true)))
(let (($x308 (or false false)))
(let (($x101 (or $x308 false (or $x303))))
(and (not $x101) (or $x101 (and (distinct ?x812 ?x812) true)))))))))
(check-sat)
; query 92: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x522 ((_ sign_extend 16) in.1_16)))
(let ((?x812 (bvadd ?x522 (_ bv10 32))))
(let ((?x1336 ((_ extract 15 0) ?x812)))
(let (($x303 (and (distinct (bvadd ((_ sign_extend 1) ?x522) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x812)) true)))
(let (($x308 (or false false)))
(let (($x101 (or $x308 false (or $x303))))
(let (($x908 (or $x101 false)))
(and (not $x908) (or $x908 (and (distinct ?x1336 ?x1336) true)))))))))))
(check-sat)
; query 93: function matrix_sum, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x1487 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x364 (or false false false)))
(let (($x24 (not $x364)))
(and $x24 (or $x364 (and (distinct ?x1487 ?x1487) true)))))))
(check-sat)
; query 94: function matrix_sum, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x1487 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let ((?x1964 ((_ zero_extend 63) ?x1487)))
(let (($x364 (or false false false)))
(let (($x1905 (or $x364 false)))
(and (not $x1905) (or $x1905 (and (distinct ?x1964 ?x1964) true))))))))
(check-sat)
; query 95: function matrix_sum, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x1487 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x1661 (= (_ bv1 1) ?x1487)))
(let ((?x133 (ite $x1661 (_ bv1 32) (_ bv0 32))))
(let (($x364 (or false false false)))
(let (($x333 (or $x364 (ite $x1661 false false))))
(and (not $x333) (or $x333 (and (distinct ?x133 ?x133) true)))))))))
(check-sat)
; query 96: function matrix_sum, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x308 (or false false)))
(let (($x410 (not $x308)))
(and $x410 (or $x308 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 97: function matrix_sum, block 22, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x1487 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x1661 (= (_ bv1 1) ?x1487)))
(let ((?x133 (ite $x1661 (_ bv1 32) (_ bv0 32))))
(let ((?x522 ((_ sign_extend 16) in.1_16)))
(let ((?x301 (bvadd ?x522 ?x133)))
(let (($x1899 (and (distinct (bvadd ((_ sign_extend 1) ?x522) ((_ sign_extend 1) ?x133)) ((_ sign_extend 1) ?x301)) true)))
(let (($x364 (or false false false)))
(let (($x333 (or $x364 (ite $x1661 false false))))
(let (($x308 (or false false)))
(let (($x1170 (or $x308 $x333 (or $x1899))))
(and (not $x1170) (or $x1170 (and (distinct ?x301 ?x301) true))))))))))))))
(check-sat)
; query 98: function matrix_sum, block 22, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x1487 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x1661 (= (_ bv1 1) ?x1487)))
(let ((?x133 (ite $x1661 (_ bv1 32) (_ bv0 32))))
(let ((?x522 ((_ sign_extend 16) in.1_16)))
(let ((?x301 (bvadd ?x522 ?x133)))
(let ((?x1320 ((_ extract 15 0) ?x301)))
(let (($x1899 (and (distinct (bvadd ((_ sign_extend 1) ?x522) ((_ sign_extend 1) ?x133)) ((_ sign_extend 1) ?x301)) true)))
(let (($x364 (or false false false)))
(let (($x333 (or $x364 (ite $x1661 false false))))
(let (($x308 (or false false)))
(let (($x1170 (or $x308 $x333 (or $x1899))))
(let (($x962 (or $x1170 false)))
(and (not $x962) (or $x962 (and (distinct ?x1320 ?x1320) true))))))))))))))))
(check-sat)
; query 99: function matrix_sum, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x364 (or false false false)))
(let (($x24 (not $x364)))
(and $x24 (or $x364 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 100: function matrix_sum, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x56 (bvadd in.01_32 (_ bv1 32))))
(let (($x402 (and (distinct ?x56 ?x56) true)))
(let (($x364 (or false false false)))
(let (($x24 (not $x364)))
(and $x24 (or $x364 $x402)))))))
(check-sat)
; query 101: function parseval, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.23_32 () (_ BitVec 32))
(assert
 (let (($x431 (and (distinct (bvmul ((_ sign_extend 32) in.23_32) ((_ sign_extend 32) (_ bv1024 32))) ((_ sign_extend 32) (bvmul in.23_32 (_ bv1024 32)))) true)))
(let (($x2638 (or false false (or $x431))))
(and (not $x2638) (or $x2638 (and (distinct (bvmul in.23_32 (_ bv1024 32)) (bvmul in.23_32 (_ bv1024 32))) true))))))
(check-sat)
; query 102: function parseval, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.34_32 () (_ BitVec 32))
(assert
 (let (($x983 (and (distinct (bvmul ((_ sign_extend 32) in.34_32) ((_ sign_extend 32) (_ bv1048576 32))) ((_ sign_extend 32) (bvmul in.34_32 (_ bv1048576 32)))) true)))
(let (($x1094 (or false false (or $x983))))
(and (not $x1094) (or $x1094 (and (distinct (bvmul in.34_32 (_ bv1048576 32)) (bvmul in.34_32 (_ bv1048576 32))) true))))))
(check-sat)
; query 103: function run_crc_loop, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x56 (bvadd in.01_32 (_ bv1 32))))
(let (($x402 (and (distinct ?x56 ?x56) true)))
(let (($x364 (or false false false)))
(let (($x24 (not $x364)))
(and $x24 (or $x364 $x402)))))))
(check-sat)
