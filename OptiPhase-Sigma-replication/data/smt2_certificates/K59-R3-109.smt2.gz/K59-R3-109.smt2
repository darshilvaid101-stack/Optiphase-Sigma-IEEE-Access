; OptiPhase-Sigma refinement certificate for sweep K59-R3-109
; query 0: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x1288 (or false false)))
(let (($x1048 (not $x1288)))
(and $x1048 (or $x1288 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 1: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x1285 ((_ sign_extend 16) in3_16)))
(let ((?x224 (bvand ?x1285 (_ bv127 32))))
(let (($x1288 (or false false)))
(let (($x23 (or $x1288 false false)))
(let (($x153 (not $x23)))
(and $x153 (or $x23 (and (distinct ?x224 ?x224) true)))))))))
(check-sat)
; query 2: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x1285 ((_ sign_extend 16) in3_16)))
(let ((?x224 (bvand ?x1285 (_ bv127 32))))
(let ((?x392 ((_ extract 15 0) ?x224)))
(let (($x1288 (or false false)))
(let (($x23 (or $x1288 false false)))
(let (($x93 (or $x23 false)))
(let (($x13 (not $x93)))
(and $x13 (or $x93 (and (distinct ?x392 ?x392) true)))))))))))
(check-sat)
; query 3: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x1288 (or false false)))
(let (($x1048 (not $x1288)))
(and $x1048 (or $x1288 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 4: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x990 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x1288 (or false false)))
(let (($x23 (or $x1288 false false)))
(let (($x153 (not $x23)))
(and $x153 (or $x23 (and (distinct ?x990 ?x990) true))))))))
(check-sat)
; query 5: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x18 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x535 (or false false false)))
(let (($x119 (not $x535)))
(and $x119 (or $x535 (and (distinct ?x18 ?x18) true)))))))
(check-sat)
; query 6: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x487 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x535 (or false false false)))
(let (($x119 (not $x535)))
(and $x119 (or $x535 (and (distinct ?x487 ?x487) true)))))))
(check-sat)
; query 7: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x535 (or false false false)))
(let (($x119 (not $x535)))
(and $x119 (or $x535 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 8: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x733 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x50 (or false false (or $x733))))
(and (not $x50) (or $x50 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 9: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x747 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x318 ((_ zero_extend 31) ?x747)))
(let ((?x326 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x222 ((_ zero_extend 31) ?x326)))
(let ((?x143 (bvand ?x222 ?x318)))
(let ((?x241 (ite (and (distinct (_ bv0 32) ?x143) true) (_ bv1 1) (_ bv0 1))))
(let ((?x102 ((_ zero_extend 63) ?x241)))
(let (($x1288 (or false false)))
(let (($x23 (or $x1288 false false)))
(let (($x93 (or $x23 false)))
(let (($x495 (or $x93 $x93 false)))
(let (($x639 (or $x495 false false)))
(let (($x1269 (or $x639 false)))
(and (not $x1269) (or $x1269 (and (distinct ?x102 ?x102) true)))))))))))))))))
(check-sat)
; query 10: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x747 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x318 ((_ zero_extend 31) ?x747)))
(let ((?x326 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x222 ((_ zero_extend 31) ?x326)))
(let ((?x143 (bvand ?x222 ?x318)))
(let ((?x241 (ite (and (distinct (_ bv0 32) ?x143) true) (_ bv1 1) (_ bv0 1))))
(let (($x1309 (= (_ bv1 1) ?x241)))
(let ((?x1272 (ite $x1309 (_ bv1 32) (_ bv0 32))))
(let (($x1288 (or false false)))
(let (($x23 (or $x1288 false false)))
(let (($x93 (or $x23 false)))
(let (($x495 (or $x93 $x93 false)))
(let (($x639 (or $x495 false false)))
(let (($x75 (or $x639 (ite $x1309 false false))))
(and (not $x75) (or $x75 (and (distinct ?x1272 ?x1272) true))))))))))))))))))
(check-sat)
; query 11: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x747 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x318 ((_ zero_extend 31) ?x747)))
(let ((?x326 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x222 ((_ zero_extend 31) ?x326)))
(let ((?x143 (bvand ?x222 ?x318)))
(let ((?x241 (ite (and (distinct (_ bv0 32) ?x143) true) (_ bv1 1) (_ bv0 1))))
(let (($x1309 (= (_ bv1 1) ?x241)))
(let ((?x1272 (ite $x1309 (_ bv1 32) (_ bv0 32))))
(let ((?x323 ((_ extract 7 0) ?x1272)))
(let (($x1288 (or false false)))
(let (($x23 (or $x1288 false false)))
(let (($x93 (or $x23 false)))
(let (($x495 (or $x93 $x93 false)))
(let (($x639 (or $x495 false false)))
(let (($x75 (or $x639 (ite $x1309 false false))))
(let (($x1287 (or $x75 false)))
(and (not $x1287) (or $x1287 (and (distinct ?x323 ?x323) true))))))))))))))))))))
(check-sat)
; query 12: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x1288 (or false false)))
(let (($x1048 (not $x1288)))
(and $x1048 (or $x1288 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 13: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x326 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1288 (or false false)))
(let (($x23 (or $x1288 false false)))
(let (($x153 (not $x23)))
(and $x153 (or $x23 (and (distinct ?x326 ?x326) true))))))))
(check-sat)
; query 14: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x326 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x222 ((_ zero_extend 31) ?x326)))
(let (($x1288 (or false false)))
(let (($x23 (or $x1288 false false)))
(let (($x93 (or $x23 false)))
(let (($x13 (not $x93)))
(and $x13 (or $x93 (and (distinct ?x222 ?x222) true))))))))))
(check-sat)
; query 15: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x1288 (or false false)))
(let (($x1048 (not $x1288)))
(and $x1048 (or $x1288 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 16: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x747 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1288 (or false false)))
(let (($x23 (or $x1288 false false)))
(let (($x153 (not $x23)))
(and $x153 (or $x23 (and (distinct ?x747 ?x747) true))))))))
(check-sat)
; query 17: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x747 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x318 ((_ zero_extend 31) ?x747)))
(let (($x1288 (or false false)))
(let (($x23 (or $x1288 false false)))
(let (($x93 (or $x23 false)))
(let (($x13 (not $x93)))
(and $x13 (or $x93 (and (distinct ?x318 ?x318) true))))))))))
(check-sat)
; query 18: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x747 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x318 ((_ zero_extend 31) ?x747)))
(let ((?x326 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x222 ((_ zero_extend 31) ?x326)))
(let ((?x143 (bvand ?x222 ?x318)))
(let (($x1288 (or false false)))
(let (($x23 (or $x1288 false false)))
(let (($x93 (or $x23 false)))
(let (($x495 (or $x93 $x93 false)))
(and (not $x495) (or $x495 (and (distinct ?x143 ?x143) true)))))))))))))
(check-sat)
; query 19: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x747 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x318 ((_ zero_extend 31) ?x747)))
(let ((?x326 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x222 ((_ zero_extend 31) ?x326)))
(let ((?x143 (bvand ?x222 ?x318)))
(let ((?x241 (ite (and (distinct (_ bv0 32) ?x143) true) (_ bv1 1) (_ bv0 1))))
(let (($x1288 (or false false)))
(let (($x23 (or $x1288 false false)))
(let (($x93 (or $x23 false)))
(let (($x495 (or $x93 $x93 false)))
(let (($x639 (or $x495 false false)))
(and (not $x639) (or $x639 (and (distinct ?x241 ?x241) true)))))))))))))))
(check-sat)
; query 20: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x514 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x535 (or false false false)))
(let (($x119 (not $x535)))
(and $x119 (or $x535 (and (distinct ?x514 ?x514) true)))))))
(check-sat)
