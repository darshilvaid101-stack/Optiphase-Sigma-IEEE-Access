; OptiPhase-Sigma refinement certificate for sweep K12-R3-304
; query 0: function xmalloc, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in7_32 () (_ BitVec 32))
(assert
 (let ((?x74 (ite (and (distinct (_ bv0 32) in7_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x319 (or false false false)))
(and (not $x319) (or $x319 (and (distinct ?x74 ?x74) true))))))
(check-sat)
