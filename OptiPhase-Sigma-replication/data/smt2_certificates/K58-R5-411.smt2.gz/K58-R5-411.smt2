; OptiPhase-Sigma refinement certificate for sweep K58-R5-411
; query 0: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x593 (or false false false)))
(let (($x1108 (not $x593)))
(and $x1108 (or $x593 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x2168 (bvadd in.01_32 (_ bv1 32))))
(let ((?x2348 (bvmul ?x2168 ?x2168)))
(let (($x593 (or false false false)))
(let (($x2370 (or $x593 $x593 false)))
(and (not $x2370) (or $x2370 (and (distinct ?x2348 ?x2348) true))))))))
(check-sat)
; query 2: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x83 (and (distinct (bvmul (bvmul (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) (_ bv2 32)) (bvshl (bvmul (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) (_ bv3 32))) true)))
(let (($x593 (or false false false)))
(let (($x2370 (or $x593 $x593 false)))
(let (($x1133 (or $x2370 false false)))
(and (not $x1133) (or (or $x1133 (bvuge (_ bv3 32) (_ bv32 32))) $x83)))))))
(check-sat)
; query 3: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x550 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x593 (or false false false)))
(let (($x1108 (not $x593)))
(and $x1108 (or $x593 (and (distinct ?x550 ?x550) true)))))))
(check-sat)
; query 4: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x46 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x593 (or false false false)))
(let (($x1108 (not $x593)))
(and $x1108 (or $x593 (and (distinct ?x46 ?x46) true)))))))
(check-sat)
