; OptiPhase-Sigma refinement certificate for sweep K55-R3-159
; query 0: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x49 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x742 (or false false false)))
(let (($x628 (not $x742)))
(and $x628 (or $x742 (and (distinct ?x49 ?x49) true)))))))
(check-sat)
; query 1: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x742 (or false false false)))
(let (($x628 (not $x742)))
(and $x628 (or $x742 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 2: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x1462 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x742 (or false false false)))
(let (($x628 (not $x742)))
(and $x628 (or $x742 (and (distinct ?x1462 ?x1462) true)))))))
(check-sat)
; query 3: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1750 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x742 (or false false false)))
(let (($x628 (not $x742)))
(and $x628 (or $x742 (and (distinct ?x1750 ?x1750) true)))))))
(check-sat)
