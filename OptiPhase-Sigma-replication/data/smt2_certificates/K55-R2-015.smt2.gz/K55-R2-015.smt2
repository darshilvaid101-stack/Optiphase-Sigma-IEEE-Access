; OptiPhase-Sigma refinement certificate for sweep K55-R2-015
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x582 (or false false)))
(let (($x2369 (not $x582)))
(and $x2369 (or $x582 (and (distinct ((_ sign_extend 16) in25_16) ((_ sign_extend 16) in25_16)) true))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let ((?x775 (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))))
(let (($x582 (or false false)))
(let (($x70 (or $x582 false false)))
(let (($x101 (not $x70)))
(and $x101 (or $x70 (and (distinct ?x775 ?x775) true))))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x582 (or false false)))
(let (($x2369 (not $x582)))
(and $x2369 (or $x582 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x876 ((_ sign_extend 16) in3_16)))
(let ((?x1152 (bvand ?x876 (_ bv127 32))))
(let (($x582 (or false false)))
(let (($x70 (or $x582 false false)))
(let (($x101 (not $x70)))
(and $x101 (or $x70 (and (distinct ?x1152 ?x1152) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x876 ((_ sign_extend 16) in3_16)))
(let ((?x1152 (bvand ?x876 (_ bv127 32))))
(let ((?x494 ((_ extract 15 0) ?x1152)))
(let (($x582 (or false false)))
(let (($x70 (or $x582 false false)))
(let (($x83 (or $x70 false)))
(let (($x467 (not $x83)))
(and $x467 (or $x83 (and (distinct ?x494 ?x494) true)))))))))))
(check-sat)
; query 5: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x582 (or false false)))
(let (($x2369 (not $x582)))
(and $x2369 (or $x582 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 6: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x31 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x582 (or false false)))
(let (($x70 (or $x582 false false)))
(let (($x101 (not $x70)))
(and $x101 (or $x70 (and (distinct ?x31 ?x31) true))))))))
(check-sat)
; query 7: function core_bench_list, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x54 (or false false false)))
(let (($x1319 (not $x54)))
(and $x1319 (or $x54 (and (distinct (bvadd in.0_16 (_ bv1 16)) (bvadd in.0_16 (_ bv1 16))) true))))))
(check-sat)
; query 8: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x2665 (bvadd in.01_32 (_ bv1 32))))
(let (($x659 (and (distinct ?x2665 ?x2665) true)))
(let (($x54 (or false false false)))
(let (($x1319 (not $x54)))
(and $x1319 (or $x54 $x659)))))))
(check-sat)
; query 9: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x2665 (bvadd in.01_32 (_ bv1 32))))
(let ((?x442 (bvmul ?x2665 ?x2665)))
(let (($x54 (or false false false)))
(let (($x117 (or $x54 $x54 false)))
(and (not $x117) (or $x117 (and (distinct ?x442 ?x442) true))))))))
(check-sat)
; query 10: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x2665 (bvadd in.01_32 (_ bv1 32))))
(let ((?x442 (bvmul ?x2665 ?x2665)))
(let ((?x2371 (bvmul ?x442 (_ bv2 32))))
(let (($x54 (or false false false)))
(let (($x117 (or $x54 $x54 false)))
(let (($x2159 (or $x117 false false)))
(and (not $x2159) (or $x2159 (and (distinct ?x2371 ?x2371) true))))))))))
(check-sat)
; query 11: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x2665 (bvadd in.01_32 (_ bv1 32))))
(let ((?x442 (bvmul ?x2665 ?x2665)))
(let ((?x2371 (bvmul ?x442 (_ bv2 32))))
(let ((?x1309 (bvmul ?x2371 (_ bv4 32))))
(let (($x54 (or false false false)))
(let (($x117 (or $x54 $x54 false)))
(let (($x2159 (or $x117 false false)))
(let (($x842 (or $x2159 false false)))
(and (not $x842) (or $x842 (and (distinct ?x1309 ?x1309) true))))))))))))
(check-sat)
; query 12: function core_init_matrix, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x54 (or false false false)))
(let (($x1319 (not $x54)))
(and $x1319 (or $x54 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 13: function core_init_matrix, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x54 (or false false false)))
(let (($x1319 (not $x54)))
(and $x1319 (or $x54 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 14: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x10 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x54 (or false false false)))
(let (($x1319 (not $x54)))
(and $x1319 (or $x54 (and (distinct ?x10 ?x10) true)))))))
(check-sat)
; query 15: function core_init_state, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_32 () (_ BitVec 32))
(assert
 (let (($x54 (or false false false)))
(let (($x1319 (not $x54)))
(and $x1319 (or $x54 (and (distinct (bvadd in.06_32 (_ bv1 32)) (bvadd in.06_32 (_ bv1 32))) true))))))
(check-sat)
; query 16: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x354 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x54 (or false false false)))
(let (($x1319 (not $x54)))
(and $x1319 (or $x54 (and (distinct ?x354 ?x354) true)))))))
(check-sat)
; query 17: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x54 (or false false false)))
(let (($x1319 (not $x54)))
(and $x1319 (or $x54 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 18: function core_list_init, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x2665 (bvadd in.01_32 (_ bv1 32))))
(let (($x659 (and (distinct ?x2665 ?x2665) true)))
(let (($x54 (or false false false)))
(let (($x1319 (not $x54)))
(and $x1319 (or $x54 $x659)))))))
(check-sat)
; query 19: function core_list_mergesort, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x2665 (bvadd in.01_32 (_ bv1 32))))
(let (($x659 (and (distinct ?x2665 ?x2665) true)))
(let (($x633 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x2665)) true)))
(let (($x495 (or false false (or $x633))))
(and (not $x495) (or $x495 $x659)))))))
(check-sat)
; query 20: function core_list_mergesort, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x555 (ite (bvslt (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x54 (or false false false)))
(let (($x1319 (not $x54)))
(and $x1319 (or $x54 (and (distinct ?x555 ?x555) true)))))))
(check-sat)
; query 21: function core_list_mergesort, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.224_32 () (_ BitVec 32))
(assert
 (let ((?x1580 (ite (= (_ bv0 32) in.224_32) (_ bv1 1) (_ bv0 1))))
(let (($x54 (or false false false)))
(let (($x1319 (not $x54)))
(and $x1319 (or $x54 (and (distinct ?x1580 ?x1580) true)))))))
(check-sat)
; query 22: function core_list_mergesort, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x148 (ite (= (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x54 (or false false false)))
(let (($x1319 (not $x54)))
(and $x1319 (or $x54 (and (distinct ?x148 ?x148) true)))))))
(check-sat)
; query 23: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x230 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x576 (or false false (or $x230))))
(and (not $x576) (or $x576 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 24: function core_list_mergesort, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x903 (and (distinct (bvmul ((_ sign_extend 32) in.020_32) ((_ sign_extend 32) (_ bv2 32))) ((_ sign_extend 32) (bvmul in.020_32 (_ bv2 32)))) true)))
(let (($x962 (or false false (or $x903))))
(and (not $x962) (or $x962 (and (distinct (bvmul in.020_32 (_ bv2 32)) (bvmul in.020_32 (_ bv2 32))) true))))))
(check-sat)
; query 25: function core_state_transition, block 102, name %103
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x582 (or false false)))
(let (($x2369 (not $x582)))
(and $x2369 (or $x582 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 26: function core_state_transition, block 102, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1299 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x582 (or false false)))
(let (($x70 (or $x582 false false)))
(let (($x101 (not $x70)))
(and $x101 (or $x70 (and (distinct ?x1299 ?x1299) true))))))))
(check-sat)
; query 27: function core_state_transition, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x582 (or false false)))
(let (($x2369 (not $x582)))
(and $x2369 (or $x582 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 28: function core_state_transition, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x114 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x582 (or false false)))
(let (($x70 (or $x582 false false)))
(let (($x101 (not $x70)))
(and $x101 (or $x70 (and (distinct ?x114 ?x114) true))))))))
(check-sat)
; query 29: function core_state_transition, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x582 (or false false)))
(let (($x2369 (not $x582)))
(and $x2369 (or $x582 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 30: function core_state_transition, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1299 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x582 (or false false)))
(let (($x70 (or $x582 false false)))
(let (($x101 (not $x70)))
(and $x101 (or $x70 (and (distinct ?x1299 ?x1299) true))))))))
(check-sat)
; query 31: function core_state_transition, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x582 (or false false)))
(let (($x2369 (not $x582)))
(and $x2369 (or $x582 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 32: function core_state_transition, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1542 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x582 (or false false)))
(let (($x70 (or $x582 false false)))
(let (($x101 (not $x70)))
(and $x101 (or $x70 (and (distinct ?x1542 ?x1542) true))))))))
(check-sat)
; query 33: function core_state_transition, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x582 (or false false)))
(let (($x2369 (not $x582)))
(and $x2369 (or $x582 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 34: function core_state_transition, block 51, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1542 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x582 (or false false)))
(let (($x70 (or $x582 false false)))
(let (($x101 (not $x70)))
(and $x101 (or $x70 (and (distinct ?x1542 ?x1542) true))))))))
(check-sat)
; query 35: function core_state_transition, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x582 (or false false)))
(let (($x2369 (not $x582)))
(and $x2369 (or $x582 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 36: function core_state_transition, block 64, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1542 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x582 (or false false)))
(let (($x70 (or $x582 false false)))
(let (($x101 (not $x70)))
(and $x101 (or $x70 (and (distinct ?x1542 ?x1542) true))))))))
(check-sat)
; query 37: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x1051 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x54 (or false false false)))
(let (($x1319 (not $x54)))
(and $x1319 (or $x54 (and (distinct ?x1051 ?x1051) true)))))))
(check-sat)
; query 38: function core_state_transition, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x582 (or false false)))
(let (($x2369 (not $x582)))
(and $x2369 (or $x582 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 39: function core_state_transition, block 80, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x35 (ite (= (_ bv69 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x582 (or false false)))
(let (($x70 (or $x582 false false)))
(let (($x101 (not $x70)))
(and $x101 (or $x70 (and (distinct ?x35 ?x35) true))))))))
(check-sat)
; query 40: function core_state_transition, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x582 (or false false)))
(let (($x2369 (not $x582)))
(and $x2369 (or $x582 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 41: function core_state_transition, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1289 (ite (= (_ bv101 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x582 (or false false)))
(let (($x70 (or $x582 false false)))
(let (($x101 (not $x70)))
(and $x101 (or $x70 (and (distinct ?x1289 ?x1289) true))))))))
(check-sat)
; query 42: function core_state_transition, block 99, name %100
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x582 (or false false)))
(let (($x2369 (not $x582)))
(and $x2369 (or $x582 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 43: function core_state_transition, block 99, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x114 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x582 (or false false)))
(let (($x70 (or $x582 false false)))
(let (($x101 (not $x70)))
(and $x101 (or $x70 (and (distinct ?x114 ?x114) true))))))))
(check-sat)
; query 44: function crcu8, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x582 (or false false)))
(let (($x2369 (not $x582)))
(and $x2369 (or $x582 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 45: function crcu8, block 19, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x744 ((_ zero_extend 16) in.01_16)))
(let ((?x1635 (bvxor ?x744 (_ bv16386 32))))
(let (($x582 (or false false)))
(let (($x70 (or $x582 false false)))
(let (($x101 (not $x70)))
(and $x101 (or $x70 (and (distinct ?x1635 ?x1635) true)))))))))
(check-sat)
; query 46: function crcu8, block 19, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x744 ((_ zero_extend 16) in.01_16)))
(let ((?x1635 (bvxor ?x744 (_ bv16386 32))))
(let ((?x837 ((_ extract 15 0) ?x1635)))
(let (($x582 (or false false)))
(let (($x70 (or $x582 false false)))
(let (($x83 (or $x70 false)))
(let (($x467 (not $x83)))
(and $x467 (or $x83 (and (distinct ?x837 ?x837) true)))))))))))
(check-sat)
; query 47: function crcu8, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x582 (or false false)))
(let (($x2369 (not $x582)))
(and $x2369 (or $x582 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 48: function crcu8, block 29, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1930 ((_ zero_extend 16) in27_16)))
(let ((?x1684 (bvor ?x1930 (_ bv32768 32))))
(let (($x582 (or false false)))
(let (($x70 (or $x582 false false)))
(let (($x101 (not $x70)))
(and $x101 (or $x70 (and (distinct ?x1684 ?x1684) true)))))))))
(check-sat)
; query 49: function crcu8, block 29, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1930 ((_ zero_extend 16) in27_16)))
(let ((?x1684 (bvor ?x1930 (_ bv32768 32))))
(let ((?x1700 ((_ extract 15 0) ?x1684)))
(let (($x582 (or false false)))
(let (($x70 (or $x582 false false)))
(let (($x83 (or $x70 false)))
(let (($x467 (not $x83)))
(and $x467 (or $x83 (and (distinct ?x1700 ?x1700) true)))))))))))
(check-sat)
; query 50: function crcu8, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x582 (or false false)))
(let (($x2369 (not $x582)))
(and $x2369 (or $x582 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 51: function crcu8, block 33, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1930 ((_ zero_extend 16) in27_16)))
(let ((?x905 (bvand ?x1930 (_ bv32767 32))))
(let (($x582 (or false false)))
(let (($x70 (or $x582 false false)))
(let (($x101 (not $x70)))
(and $x101 (or $x70 (and (distinct ?x905 ?x905) true)))))))))
(check-sat)
; query 52: function crcu8, block 33, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1930 ((_ zero_extend 16) in27_16)))
(let ((?x905 (bvand ?x1930 (_ bv32767 32))))
(let ((?x164 ((_ extract 15 0) ?x905)))
(let (($x582 (or false false)))
(let (($x70 (or $x582 false false)))
(let (($x83 (or $x70 false)))
(let (($x467 (not $x83)))
(and $x467 (or $x83 (and (distinct ?x164 ?x164) true)))))))))))
(check-sat)
; query 53: function crcu8, block 38, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_8 () (_ BitVec 8))
(assert
 (let (($x54 (or false false false)))
(let (($x1319 (not $x54)))
(and $x1319 (or $x54 (and (distinct (bvadd in.02_8 (_ bv1 8)) (bvadd in.02_8 (_ bv1 8))) true))))))
(check-sat)
; query 54: function crcu8, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x132 ((_ extract 7 0) in.01_16)))
(let ((?x757 ((_ zero_extend 24) ?x132)))
(let (($x582 (or false false)))
(let (($x716 (or $x582 false)))
(and (not $x716) (or $x716 (and (distinct ?x757 ?x757) true))))))))
(check-sat)
; query 55: function crcu8, block 6, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x132 ((_ extract 7 0) in.01_16)))
(let ((?x757 ((_ zero_extend 24) ?x132)))
(let ((?x1712 (bvand ?x757 (_ bv1 32))))
(let (($x582 (or false false)))
(let (($x716 (or $x582 false)))
(let (($x304 (or $x716 false false)))
(and (not $x304) (or $x304 (and (distinct ?x1712 ?x1712) true))))))))))
(check-sat)
; query 56: function crcu8, block 6, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x132 ((_ extract 7 0) in.01_16)))
(let ((?x757 ((_ zero_extend 24) ?x132)))
(let ((?x1712 (bvand ?x757 (_ bv1 32))))
(let ((?x542 ((_ zero_extend 24) in.0_8)))
(let ((?x1820 (bvand ?x542 (_ bv1 32))))
(let ((?x1786 (bvxor ?x1820 ?x1712)))
(let (($x582 (or false false)))
(let (($x716 (or $x582 false)))
(let (($x304 (or $x716 false false)))
(let (($x70 (or $x582 false false)))
(let (($x806 (or $x70 $x304 false)))
(and (not $x806) (or $x806 (and (distinct ?x1786 ?x1786) true)))))))))))))))
(check-sat)
; query 57: function crcu8, block 6, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x132 ((_ extract 7 0) in.01_16)))
(let ((?x757 ((_ zero_extend 24) ?x132)))
(let ((?x1712 (bvand ?x757 (_ bv1 32))))
(let ((?x542 ((_ zero_extend 24) in.0_8)))
(let ((?x1820 (bvand ?x542 (_ bv1 32))))
(let ((?x1786 (bvxor ?x1820 ?x1712)))
(let ((?x625 ((_ extract 7 0) ?x1786)))
(let (($x582 (or false false)))
(let (($x716 (or $x582 false)))
(let (($x304 (or $x716 false false)))
(let (($x70 (or $x582 false false)))
(let (($x806 (or $x70 $x304 false)))
(let (($x1639 (or $x806 false)))
(and (not $x1639) (or $x1639 (and (distinct ?x625 ?x625) true)))))))))))))))))
(check-sat)
; query 58: function crcu8, block 6, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x582 (or false false)))
(let (($x2369 (not $x582)))
(and $x2369 (or $x582 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 59: function crcu8, block 6, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x542 ((_ zero_extend 24) in.0_8)))
(let ((?x51 (bvashr ?x542 (_ bv1 32))))
(let (($x582 (or false false)))
(let (($x70 (or $x582 false false)))
(let (($x1847 (or $x70 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not $x1847) (or $x1847 (and (distinct ?x51 ?x51) true)))))))))
(check-sat)
; query 60: function crcu8, block 6, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x542 ((_ zero_extend 24) in.0_8)))
(let ((?x51 (bvashr ?x542 (_ bv1 32))))
(let ((?x1277 ((_ extract 7 0) ?x51)))
(let (($x582 (or false false)))
(let (($x70 (or $x582 false false)))
(let (($x1847 (or $x70 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x1475 (or $x1847 false)))
(and (not $x1475) (or $x1475 (and (distinct ?x1277 ?x1277) true)))))))))))
(check-sat)
; query 61: function crcu8, block 6, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x132 ((_ extract 7 0) in.01_16)))
(let ((?x757 ((_ zero_extend 24) ?x132)))
(let ((?x1712 (bvand ?x757 (_ bv1 32))))
(let ((?x542 ((_ zero_extend 24) in.0_8)))
(let ((?x1820 (bvand ?x542 (_ bv1 32))))
(let ((?x1786 (bvxor ?x1820 ?x1712)))
(let ((?x625 ((_ extract 7 0) ?x1786)))
(let ((?x1049 ((_ zero_extend 24) ?x625)))
(let (($x582 (or false false)))
(let (($x716 (or $x582 false)))
(let (($x304 (or $x716 false false)))
(let (($x70 (or $x582 false false)))
(let (($x806 (or $x70 $x304 false)))
(let (($x1639 (or $x806 false)))
(let (($x531 (or $x1639 false)))
(and (not $x531) (or $x531 (and (distinct ?x1049 ?x1049) true)))))))))))))))))))
(check-sat)
; query 62: function crcu8, block 6, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x132 ((_ extract 7 0) in.01_16)))
(let ((?x757 ((_ zero_extend 24) ?x132)))
(let ((?x1712 (bvand ?x757 (_ bv1 32))))
(let ((?x542 ((_ zero_extend 24) in.0_8)))
(let ((?x1820 (bvand ?x542 (_ bv1 32))))
(let ((?x1786 (bvxor ?x1820 ?x1712)))
(let ((?x625 ((_ extract 7 0) ?x1786)))
(let ((?x1049 ((_ zero_extend 24) ?x625)))
(let ((?x1759 (ite (= (_ bv1 32) ?x1049) (_ bv1 1) (_ bv0 1))))
(let (($x582 (or false false)))
(let (($x716 (or $x582 false)))
(let (($x304 (or $x716 false false)))
(let (($x70 (or $x582 false false)))
(let (($x806 (or $x70 $x304 false)))
(let (($x1639 (or $x806 false)))
(let (($x531 (or $x1639 false)))
(let (($x771 (or $x531 false false)))
(and (not $x771) (or $x771 (and (distinct ?x1759 ?x1759) true)))))))))))))))))))))
(check-sat)
; query 63: function crcu8, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x582 (or false false)))
(let (($x2369 (not $x582)))
(and $x2369 (or $x582 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 64: function crcu8, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x542 ((_ zero_extend 24) in.0_8)))
(let ((?x1820 (bvand ?x542 (_ bv1 32))))
(let (($x582 (or false false)))
(let (($x70 (or $x582 false false)))
(let (($x101 (not $x70)))
(and $x101 (or $x70 (and (distinct ?x1820 ?x1820) true)))))))))
(check-sat)
; query 65: function crcu8, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x582 (or false false)))
(let (($x2369 (not $x582)))
(and $x2369 (or $x582 (and (distinct ((_ extract 7 0) in.01_16) ((_ extract 7 0) in.01_16)) true))))))
(check-sat)
; query 66: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x2008 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x480 ((_ zero_extend 31) ?x2008)))
(let ((?x747 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1984 ((_ zero_extend 31) ?x747)))
(let ((?x1974 (bvand ?x1984 ?x480)))
(let ((?x1827 (ite (and (distinct (_ bv0 32) ?x1974) true) (_ bv1 1) (_ bv0 1))))
(let ((?x1320 ((_ zero_extend 63) ?x1827)))
(let (($x582 (or false false)))
(let (($x70 (or $x582 false false)))
(let (($x83 (or $x70 false)))
(let (($x1447 (or $x83 $x83 false)))
(let (($x1327 (or $x1447 false false)))
(let (($x318 (or $x1327 false)))
(and (not $x318) (or $x318 (and (distinct ?x1320 ?x1320) true)))))))))))))))))
(check-sat)
; query 67: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x2008 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x480 ((_ zero_extend 31) ?x2008)))
(let ((?x747 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1984 ((_ zero_extend 31) ?x747)))
(let ((?x1974 (bvand ?x1984 ?x480)))
(let ((?x1827 (ite (and (distinct (_ bv0 32) ?x1974) true) (_ bv1 1) (_ bv0 1))))
(let (($x1653 (= (_ bv1 1) ?x1827)))
(let ((?x469 (ite $x1653 (_ bv1 32) (_ bv0 32))))
(let (($x582 (or false false)))
(let (($x70 (or $x582 false false)))
(let (($x83 (or $x70 false)))
(let (($x1447 (or $x83 $x83 false)))
(let (($x1327 (or $x1447 false false)))
(let (($x1747 (or $x1327 (ite $x1653 false false))))
(and (not $x1747) (or $x1747 (and (distinct ?x469 ?x469) true))))))))))))))))))
(check-sat)
; query 68: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x2008 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x480 ((_ zero_extend 31) ?x2008)))
(let ((?x747 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1984 ((_ zero_extend 31) ?x747)))
(let ((?x1974 (bvand ?x1984 ?x480)))
(let ((?x1827 (ite (and (distinct (_ bv0 32) ?x1974) true) (_ bv1 1) (_ bv0 1))))
(let (($x1653 (= (_ bv1 1) ?x1827)))
(let ((?x469 (ite $x1653 (_ bv1 32) (_ bv0 32))))
(let ((?x1621 ((_ extract 7 0) ?x469)))
(let (($x582 (or false false)))
(let (($x70 (or $x582 false false)))
(let (($x83 (or $x70 false)))
(let (($x1447 (or $x83 $x83 false)))
(let (($x1327 (or $x1447 false false)))
(let (($x1747 (or $x1327 (ite $x1653 false false))))
(let (($x872 (or $x1747 false)))
(and (not $x872) (or $x872 (and (distinct ?x1621 ?x1621) true))))))))))))))))))))
(check-sat)
; query 69: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x582 (or false false)))
(let (($x2369 (not $x582)))
(and $x2369 (or $x582 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 70: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x747 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x582 (or false false)))
(let (($x70 (or $x582 false false)))
(let (($x101 (not $x70)))
(and $x101 (or $x70 (and (distinct ?x747 ?x747) true))))))))
(check-sat)
; query 71: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x747 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1984 ((_ zero_extend 31) ?x747)))
(let (($x582 (or false false)))
(let (($x70 (or $x582 false false)))
(let (($x83 (or $x70 false)))
(let (($x467 (not $x83)))
(and $x467 (or $x83 (and (distinct ?x1984 ?x1984) true))))))))))
(check-sat)
; query 72: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x582 (or false false)))
(let (($x2369 (not $x582)))
(and $x2369 (or $x582 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 73: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x2008 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x582 (or false false)))
(let (($x70 (or $x582 false false)))
(let (($x101 (not $x70)))
(and $x101 (or $x70 (and (distinct ?x2008 ?x2008) true))))))))
(check-sat)
; query 74: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x2008 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x480 ((_ zero_extend 31) ?x2008)))
(let (($x582 (or false false)))
(let (($x70 (or $x582 false false)))
(let (($x83 (or $x70 false)))
(let (($x467 (not $x83)))
(and $x467 (or $x83 (and (distinct ?x480 ?x480) true))))))))))
(check-sat)
; query 75: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x2008 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x480 ((_ zero_extend 31) ?x2008)))
(let ((?x747 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1984 ((_ zero_extend 31) ?x747)))
(let ((?x1974 (bvand ?x1984 ?x480)))
(let (($x582 (or false false)))
(let (($x70 (or $x582 false false)))
(let (($x83 (or $x70 false)))
(let (($x1447 (or $x83 $x83 false)))
(and (not $x1447) (or $x1447 (and (distinct ?x1974 ?x1974) true)))))))))))))
(check-sat)
; query 76: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x2008 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x480 ((_ zero_extend 31) ?x2008)))
(let ((?x747 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1984 ((_ zero_extend 31) ?x747)))
(let ((?x1974 (bvand ?x1984 ?x480)))
(let ((?x1827 (ite (and (distinct (_ bv0 32) ?x1974) true) (_ bv1 1) (_ bv0 1))))
(let (($x582 (or false false)))
(let (($x70 (or $x582 false false)))
(let (($x83 (or $x70 false)))
(let (($x1447 (or $x83 $x83 false)))
(let (($x1327 (or $x1447 false false)))
(and (not $x1327) (or $x1327 (and (distinct ?x1827 ?x1827) true)))))))))))))))
(check-sat)
; query 77: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1802 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x54 (or false false false)))
(let (($x1319 (not $x54)))
(and $x1319 (or $x54 (and (distinct ?x1802 ?x1802) true)))))))
(check-sat)
; query 78: function matrix_add_const, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x54 (or false false false)))
(let (($x1319 (not $x54)))
(and $x1319 (or $x54 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 79: function matrix_add_const, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x2665 (bvadd in.01_32 (_ bv1 32))))
(let (($x659 (and (distinct ?x2665 ?x2665) true)))
(let (($x54 (or false false false)))
(let (($x1319 (not $x54)))
(and $x1319 (or $x54 $x659)))))))
(check-sat)
; query 80: function matrix_mul_const, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x54 (or false false false)))
(let (($x1319 (not $x54)))
(and $x1319 (or $x54 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 81: function matrix_mul_const, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x2665 (bvadd in.01_32 (_ bv1 32))))
(let (($x659 (and (distinct ?x2665 ?x2665) true)))
(let (($x54 (or false false false)))
(let (($x1319 (not $x54)))
(and $x1319 (or $x54 $x659)))))))
(check-sat)
; query 82: function matrix_mul_matrix, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x54 (or false false false)))
(let (($x1319 (not $x54)))
(and $x1319 (or $x54 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 83: function matrix_mul_matrix, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x2665 (bvadd in.01_32 (_ bv1 32))))
(let (($x659 (and (distinct ?x2665 ?x2665) true)))
(let (($x54 (or false false false)))
(let (($x1319 (not $x54)))
(and $x1319 (or $x54 $x659)))))))
(check-sat)
; query 84: function matrix_mul_matrix, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x54 (or false false false)))
(let (($x1319 (not $x54)))
(and $x1319 (or $x54 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 85: function matrix_mul_matrix_bitextract, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x54 (or false false false)))
(let (($x1319 (not $x54)))
(and $x1319 (or $x54 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 86: function matrix_mul_matrix_bitextract, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x2665 (bvadd in.01_32 (_ bv1 32))))
(let (($x659 (and (distinct ?x2665 ?x2665) true)))
(let (($x54 (or false false false)))
(let (($x1319 (not $x54)))
(and $x1319 (or $x54 $x659)))))))
(check-sat)
; query 87: function matrix_mul_matrix_bitextract, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x54 (or false false false)))
(let (($x1319 (not $x54)))
(and $x1319 (or $x54 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 88: function matrix_mul_vect, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x54 (or false false false)))
(let (($x1319 (not $x54)))
(and $x1319 (or $x54 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 89: function matrix_mul_vect, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x2665 (bvadd in.01_32 (_ bv1 32))))
(let (($x659 (and (distinct ?x2665 ?x2665) true)))
(let (($x54 (or false false false)))
(let (($x1319 (not $x54)))
(and $x1319 (or $x54 $x659)))))))
(check-sat)
; query 90: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x582 (or false false)))
(let (($x2369 (not $x582)))
(and $x2369 (or $x582 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 91: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x193 ((_ sign_extend 16) in.1_16)))
(let ((?x1780 (bvadd ?x193 (_ bv10 32))))
(let (($x849 (and (distinct (bvadd ((_ sign_extend 1) ?x193) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x1780)) true)))
(let (($x582 (or false false)))
(let (($x1231 (or $x582 false (or $x849))))
(and (not $x1231) (or $x1231 (and (distinct ?x1780 ?x1780) true)))))))))
(check-sat)
; query 92: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x193 ((_ sign_extend 16) in.1_16)))
(let ((?x1780 (bvadd ?x193 (_ bv10 32))))
(let ((?x452 ((_ extract 15 0) ?x1780)))
(let (($x849 (and (distinct (bvadd ((_ sign_extend 1) ?x193) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x1780)) true)))
(let (($x582 (or false false)))
(let (($x1231 (or $x582 false (or $x849))))
(let (($x1021 (or $x1231 false)))
(and (not $x1021) (or $x1021 (and (distinct ?x452 ?x452) true)))))))))))
(check-sat)
; query 93: function matrix_sum, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x896 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x54 (or false false false)))
(let (($x1319 (not $x54)))
(and $x1319 (or $x54 (and (distinct ?x896 ?x896) true)))))))
(check-sat)
; query 94: function matrix_sum, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x896 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let ((?x1740 ((_ zero_extend 63) ?x896)))
(let (($x54 (or false false false)))
(let (($x1556 (or $x54 false)))
(and (not $x1556) (or $x1556 (and (distinct ?x1740 ?x1740) true))))))))
(check-sat)
; query 95: function matrix_sum, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x896 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x397 (= (_ bv1 1) ?x896)))
(let ((?x995 (ite $x397 (_ bv1 32) (_ bv0 32))))
(let (($x54 (or false false false)))
(let (($x724 (or $x54 (ite $x397 false false))))
(and (not $x724) (or $x724 (and (distinct ?x995 ?x995) true)))))))))
(check-sat)
; query 96: function matrix_sum, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x582 (or false false)))
(let (($x2369 (not $x582)))
(and $x2369 (or $x582 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 97: function matrix_sum, block 22, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x896 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x397 (= (_ bv1 1) ?x896)))
(let ((?x995 (ite $x397 (_ bv1 32) (_ bv0 32))))
(let ((?x193 ((_ sign_extend 16) in.1_16)))
(let ((?x1236 (bvadd ?x193 ?x995)))
(let (($x1784 (and (distinct (bvadd ((_ sign_extend 1) ?x193) ((_ sign_extend 1) ?x995)) ((_ sign_extend 1) ?x1236)) true)))
(let (($x54 (or false false false)))
(let (($x724 (or $x54 (ite $x397 false false))))
(let (($x582 (or false false)))
(let (($x485 (or $x582 $x724 (or $x1784))))
(and (not $x485) (or $x485 (and (distinct ?x1236 ?x1236) true))))))))))))))
(check-sat)
; query 98: function matrix_sum, block 22, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x896 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x397 (= (_ bv1 1) ?x896)))
(let ((?x995 (ite $x397 (_ bv1 32) (_ bv0 32))))
(let ((?x193 ((_ sign_extend 16) in.1_16)))
(let ((?x1236 (bvadd ?x193 ?x995)))
(let ((?x245 ((_ extract 15 0) ?x1236)))
(let (($x1784 (and (distinct (bvadd ((_ sign_extend 1) ?x193) ((_ sign_extend 1) ?x995)) ((_ sign_extend 1) ?x1236)) true)))
(let (($x54 (or false false false)))
(let (($x724 (or $x54 (ite $x397 false false))))
(let (($x582 (or false false)))
(let (($x485 (or $x582 $x724 (or $x1784))))
(let (($x984 (or $x485 false)))
(and (not $x984) (or $x984 (and (distinct ?x245 ?x245) true))))))))))))))))
(check-sat)
; query 99: function matrix_sum, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x54 (or false false false)))
(let (($x1319 (not $x54)))
(and $x1319 (or $x54 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 100: function matrix_sum, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x2665 (bvadd in.01_32 (_ bv1 32))))
(let (($x659 (and (distinct ?x2665 ?x2665) true)))
(let (($x54 (or false false false)))
(let (($x1319 (not $x54)))
(and $x1319 (or $x54 $x659)))))))
(check-sat)
; query 101: function parseval, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.23_32 () (_ BitVec 32))
(assert
 (let (($x1691 (and (distinct (bvmul ((_ sign_extend 32) in.23_32) ((_ sign_extend 32) (_ bv1024 32))) ((_ sign_extend 32) (bvmul in.23_32 (_ bv1024 32)))) true)))
(let (($x1257 (or false false (or $x1691))))
(and (not $x1257) (or $x1257 (and (distinct (bvmul in.23_32 (_ bv1024 32)) (bvmul in.23_32 (_ bv1024 32))) true))))))
(check-sat)
; query 102: function parseval, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.34_32 () (_ BitVec 32))
(assert
 (let (($x885 (and (distinct (bvmul ((_ sign_extend 32) in.34_32) ((_ sign_extend 32) (_ bv1048576 32))) ((_ sign_extend 32) (bvmul in.34_32 (_ bv1048576 32)))) true)))
(let (($x1230 (or false false (or $x885))))
(and (not $x1230) (or $x1230 (and (distinct (bvmul in.34_32 (_ bv1048576 32)) (bvmul in.34_32 (_ bv1048576 32))) true))))))
(check-sat)
