; OptiPhase-Sigma refinement certificate for sweep K52-R3-208
; query 0: function check, block 115, name %116
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x158 (and (distinct (ite (= (_ bv0 32) in0_32) (_ bv1 1) (_ bv0 1)) (ite (= (_ bv13 32) in0_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x2563 (or false false false)))
(let (($x608 (not $x2563)))
(and $x608 (or $x2563 $x158))))))
(check-sat)
; query 1: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x78 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x2563 (or false false false)))
(let (($x608 (not $x2563)))
(and $x608 (or $x2563 (and (distinct ?x78 ?x78) true)))))))
(check-sat)
; query 2: function set1d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x1374 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x2563 (or false false false)))
(let (($x608 (not $x2563)))
(and $x608 (or $x2563 (and (distinct ?x1374 ?x1374) true)))))))
(check-sat)
; query 3: function set1ds, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x1787 (ite (= (_ bv4294967295 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x2563 (or false false false)))
(let (($x608 (not $x2563)))
(and $x608 (or $x2563 (and (distinct ?x1787 ?x1787) true)))))))
(check-sat)
; query 4: function set2d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x1374 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x2563 (or false false false)))
(let (($x608 (not $x2563)))
(and $x608 (or $x2563 (and (distinct ?x1374 ?x1374) true)))))))
(check-sat)
