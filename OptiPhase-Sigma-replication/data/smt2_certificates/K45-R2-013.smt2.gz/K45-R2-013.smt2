; OptiPhase-Sigma refinement certificate for sweep K45-R2-013
; query 0: function Index_to_frequency, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x337 (ite (bvuge in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x79 (or false false false)))
(let (($x114 (not $x79)))
(and $x114 (or $x79 (and (distinct ?x337 ?x337) true)))))))
(check-sat)
; query 1: function IsPowerOfTwo, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x79 (or false false false)))
(let (($x114 (not $x79)))
(and $x114 (or $x79 (and (distinct (bvsub in0_32 (_ bv1 32)) (bvsub in0_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function IsPowerOfTwo, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x384 (bvsub in0_32 (_ bv1 32))))
(let ((?x279 (bvand in0_32 ?x384)))
(let (($x79 (or false false false)))
(let (($x139 (or false $x79 false)))
(and (not $x139) (or $x139 (and (distinct ?x279 ?x279) true))))))))
(check-sat)
; query 3: function IsPowerOfTwo, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x56 (ite (and (distinct (_ bv0 32) (bvand in0_32 (bvsub in0_32 (_ bv1 32)))) true) (_ bv1 1) (_ bv0 1))))
(let (($x79 (or false false false)))
(let (($x139 (or false $x79 false)))
(let (($x61 (or $x139 false false)))
(and (not $x61) (or $x61 (and (distinct ?x56 ?x56) true))))))))
(check-sat)
; query 4: function IsPowerOfTwo, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x6 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x79 (or false false false)))
(let (($x114 (not $x79)))
(and $x114 (or $x79 (and (distinct ?x6 ?x6) true)))))))
(check-sat)
; query 5: function NumberOfBitsNeeded, block 13, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x79 (or false false false)))
(let (($x114 (not $x79)))
(and $x114 (or $x79 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 6: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x6 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x79 (or false false false)))
(let (($x114 (not $x79)))
(and $x114 (or $x79 (and (distinct ?x6 ?x6) true)))))))
(check-sat)
; query 7: function ReverseBits, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x79 (or false false false)))
(let (($x114 (not $x79)))
(and $x114 (or $x79 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function ReverseBits, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x79 (or false false false)))
(let (($x832 (or $x79 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x514 (not $x832)))
(and $x514 (or $x832 (and (distinct (bvshl in.01_32 (_ bv1 32)) (bvshl in.01_32 (_ bv1 32))) true)))))))
(check-sat)
; query 9: function ReverseBits, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x79 (or false false false)))
(let (($x114 (not $x79)))
(and $x114 (or $x79 (and (distinct (bvand in.0_32 (_ bv1 32)) (bvand in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 10: function ReverseBits, block 5, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x40 (bvand in.0_32 (_ bv1 32))))
(let ((?x292 (bvshl in.01_32 (_ bv1 32))))
(let ((?x256 (bvor ?x292 ?x40)))
(let (($x79 (or false false false)))
(let (($x832 (or $x79 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x30 (or $x832 $x79 false)))
(and (not $x30) (or $x30 (and (distinct ?x256 ?x256) true))))))))))
(check-sat)
; query 11: function ReverseBits, block 5, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x79 (or false false false)))
(let (($x832 (or $x79 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x514 (not $x832)))
(and $x514 (or $x832 (and (distinct (bvlshr in.0_32 (_ bv1 32)) (bvlshr in.0_32 (_ bv1 32))) true)))))))
(check-sat)
; query 12: function fft_float, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x81 (ite (and (distinct (_ bv0 32) in1_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x79 (or false false false)))
(let (($x114 (not $x79)))
(and $x114 (or $x79 (and (distinct ?x81 ?x81) true)))))))
(check-sat)
; query 13: function fft_float, block 41, name %42
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.05_32 () (_ BitVec 32))
(assert
 (let (($x79 (or false false false)))
(let (($x114 (not $x79)))
(and $x114 (or $x79 (and (distinct (bvadd in.05_32 (_ bv1 32)) (bvadd in.05_32 (_ bv1 32))) true))))))
(check-sat)
; query 14: function main, block 110, name %111
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x79 (or false false false)))
(let (($x114 (not $x79)))
(and $x114 (or $x79 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 15: function main, block 113, name %114
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x79 (or false false false)))
(let (($x114 (not $x79)))
(and $x114 (or $x79 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 16: function main, block 126, name %127
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let (($x79 (or false false false)))
(let (($x114 (not $x79)))
(and $x114 (or $x79 (and (distinct (bvadd in.2_32 (_ bv1 32)) (bvadd in.2_32 (_ bv1 32))) true))))))
(check-sat)
; query 17: function main, block 139, name %140
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.3_32 () (_ BitVec 32))
(assert
 (let (($x79 (or false false false)))
(let (($x114 (not $x79)))
(and $x114 (or $x79 (and (distinct (bvadd in.3_32 (_ bv1 32)) (bvadd in.3_32 (_ bv1 32))) true))))))
(check-sat)
; query 18: function main, block 57, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x79 (or false false false)))
(let (($x114 (not $x79)))
(and $x114 (or $x79 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 19: function main, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x143 (ite (= (_ bv4 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x79 (or false false false)))
(let (($x114 (not $x79)))
(and $x114 (or $x79 (and (distinct ?x143 ?x143) true)))))))
(check-sat)
; query 20: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x24 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x79 (or false false false)))
(let (($x114 (not $x79)))
(and $x114 (or $x79 (and (distinct ?x24 ?x24) true)))))))
(check-sat)
