; OptiPhase-Sigma refinement certificate for sweep K17-R3-222
; query 0: function xmalloc, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in7_32 () (_ BitVec 32))
(assert
 (let ((?x34 (ite (and (distinct (_ bv0 32) in7_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x125 (or false false false)))
(and (not $x125) (or $x125 (and (distinct ?x34 ?x34) true))))))
(check-sat)
