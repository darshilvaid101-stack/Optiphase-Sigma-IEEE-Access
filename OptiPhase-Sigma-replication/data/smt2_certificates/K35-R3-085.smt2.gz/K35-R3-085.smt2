; OptiPhase-Sigma refinement certificate for sweep K35-R3-085
; query 0: function edge_draw, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let ((?x156 (ite (= (_ bv0 32) in4_32) (_ bv1 1) (_ bv0 1))))
(let (($x54 (or false false false)))
(and (not $x54) (or $x54 (and (distinct ?x156 ?x156) true))))))
(check-sat)
