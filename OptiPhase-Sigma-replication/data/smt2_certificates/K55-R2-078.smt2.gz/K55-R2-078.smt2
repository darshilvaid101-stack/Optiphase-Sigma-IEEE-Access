; OptiPhase-Sigma refinement certificate for sweep K55-R2-078
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x6389 (or false false)))
(let (($x190 (not $x6389)))
(and $x190 (or $x6389 (and (distinct ((_ sign_extend 16) in25_16) ((_ sign_extend 16) in25_16)) true))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let ((?x3881 (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))))
(let (($x6389 (or false false)))
(let (($x491 (or $x6389 false false)))
(let (($x227 (not $x491)))
(and $x227 (or $x491 (and (distinct ?x3881 ?x3881) true))))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x6389 (or false false)))
(let (($x190 (not $x6389)))
(and $x190 (or $x6389 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x88 ((_ sign_extend 16) in3_16)))
(let ((?x106 (bvand ?x88 (_ bv127 32))))
(let (($x6389 (or false false)))
(let (($x491 (or $x6389 false false)))
(let (($x227 (not $x491)))
(and $x227 (or $x491 (and (distinct ?x106 ?x106) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x88 ((_ sign_extend 16) in3_16)))
(let ((?x106 (bvand ?x88 (_ bv127 32))))
(let ((?x225 ((_ extract 15 0) ?x106)))
(let (($x6389 (or false false)))
(let (($x491 (or $x6389 false false)))
(let (($x3581 (or $x491 false)))
(let (($x442 (not $x3581)))
(and $x442 (or $x3581 (and (distinct ?x225 ?x225) true)))))))))))
(check-sat)
; query 5: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x6389 (or false false)))
(let (($x190 (not $x6389)))
(and $x190 (or $x6389 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 6: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x1711 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x6389 (or false false)))
(let (($x491 (or $x6389 false false)))
(let (($x227 (not $x491)))
(and $x227 (or $x491 (and (distinct ?x1711 ?x1711) true))))))))
(check-sat)
; query 7: function core_bench_list, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x96 (or false false false)))
(let (($x49 (not $x96)))
(and $x49 (or $x96 (and (distinct (bvadd in.0_16 (_ bv1 16)) (bvadd in.0_16 (_ bv1 16))) true))))))
(check-sat)
; query 8: function core_bench_state, block 105, name %106
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x96 (or false false false)))
(let (($x49 (not $x96)))
(and $x49 (or $x96 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 9: function core_bench_state, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x96 (or false false false)))
(let (($x49 (not $x96)))
(and $x49 (or $x96 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 10: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x46 (bvadd in.01_32 (_ bv1 32))))
(let (($x131 (and (distinct ?x46 ?x46) true)))
(let (($x96 (or false false false)))
(let (($x49 (not $x96)))
(and $x49 (or $x96 $x131)))))))
(check-sat)
; query 11: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x46 (bvadd in.01_32 (_ bv1 32))))
(let ((?x132 (bvmul ?x46 ?x46)))
(let (($x96 (or false false false)))
(let (($x235 (or $x96 $x96 false)))
(and (not $x235) (or $x235 (and (distinct ?x132 ?x132) true))))))))
(check-sat)
; query 12: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x46 (bvadd in.01_32 (_ bv1 32))))
(let ((?x132 (bvmul ?x46 ?x46)))
(let ((?x40 (bvmul ?x132 (_ bv2 32))))
(let (($x96 (or false false false)))
(let (($x235 (or $x96 $x96 false)))
(let (($x284 (or $x235 false false)))
(and (not $x284) (or $x284 (and (distinct ?x40 ?x40) true))))))))))
(check-sat)
; query 13: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x46 (bvadd in.01_32 (_ bv1 32))))
(let ((?x132 (bvmul ?x46 ?x46)))
(let ((?x40 (bvmul ?x132 (_ bv2 32))))
(let ((?x409 (bvmul ?x40 (_ bv4 32))))
(let (($x96 (or false false false)))
(let (($x235 (or $x96 $x96 false)))
(let (($x284 (or $x235 false false)))
(let (($x671 (or $x284 false false)))
(and (not $x671) (or $x671 (and (distinct ?x409 ?x409) true))))))))))))
(check-sat)
; query 14: function core_init_matrix, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x96 (or false false false)))
(let (($x49 (not $x96)))
(and $x49 (or $x96 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 15: function core_init_matrix, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x96 (or false false false)))
(let (($x49 (not $x96)))
(and $x49 (or $x96 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 16: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x97 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x96 (or false false false)))
(let (($x49 (not $x96)))
(and $x49 (or $x96 (and (distinct ?x97 ?x97) true)))))))
(check-sat)
; query 17: function core_init_state, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_32 () (_ BitVec 32))
(assert
 (let (($x96 (or false false false)))
(let (($x49 (not $x96)))
(and $x49 (or $x96 (and (distinct (bvadd in.06_32 (_ bv1 32)) (bvadd in.06_32 (_ bv1 32))) true))))))
(check-sat)
; query 18: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x33 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x96 (or false false false)))
(let (($x49 (not $x96)))
(and $x49 (or $x96 (and (distinct ?x33 ?x33) true)))))))
(check-sat)
; query 19: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x96 (or false false false)))
(let (($x49 (not $x96)))
(and $x49 (or $x96 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 20: function core_list_init, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x46 (bvadd in.01_32 (_ bv1 32))))
(let (($x131 (and (distinct ?x46 ?x46) true)))
(let (($x96 (or false false false)))
(let (($x49 (not $x96)))
(and $x49 (or $x96 $x131)))))))
(check-sat)
; query 21: function core_list_mergesort, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x46 (bvadd in.01_32 (_ bv1 32))))
(let (($x131 (and (distinct ?x46 ?x46) true)))
(let (($x188 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x46)) true)))
(let (($x3336 (or false false (or $x188))))
(and (not $x3336) (or $x3336 $x131)))))))
(check-sat)
; query 22: function core_list_mergesort, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x11 (ite (bvslt (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x96 (or false false false)))
(let (($x49 (not $x96)))
(and $x49 (or $x96 (and (distinct ?x11 ?x11) true)))))))
(check-sat)
; query 23: function core_list_mergesort, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.224_32 () (_ BitVec 32))
(assert
 (let ((?x35 (ite (= (_ bv0 32) in.224_32) (_ bv1 1) (_ bv0 1))))
(let (($x96 (or false false false)))
(let (($x49 (not $x96)))
(and $x49 (or $x96 (and (distinct ?x35 ?x35) true)))))))
(check-sat)
; query 24: function core_list_mergesort, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x102 (ite (= (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x96 (or false false false)))
(let (($x49 (not $x96)))
(and $x49 (or $x96 (and (distinct ?x102 ?x102) true)))))))
(check-sat)
; query 25: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x103 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x105 (or false false (or $x103))))
(and (not $x105) (or $x105 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 26: function core_list_mergesort, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x69 (and (distinct (bvmul ((_ sign_extend 32) in.020_32) ((_ sign_extend 32) (_ bv2 32))) ((_ sign_extend 32) (bvmul in.020_32 (_ bv2 32)))) true)))
(let (($x156 (or false false (or $x69))))
(and (not $x156) (or $x156 (and (distinct (bvmul in.020_32 (_ bv2 32)) (bvmul in.020_32 (_ bv2 32))) true))))))
(check-sat)
; query 27: function core_state_transition, block 102, name %103
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x6389 (or false false)))
(let (($x190 (not $x6389)))
(and $x190 (or $x6389 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 28: function core_state_transition, block 102, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x347 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x6389 (or false false)))
(let (($x491 (or $x6389 false false)))
(let (($x227 (not $x491)))
(and $x227 (or $x491 (and (distinct ?x347 ?x347) true))))))))
(check-sat)
; query 29: function core_state_transition, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x6389 (or false false)))
(let (($x190 (not $x6389)))
(and $x190 (or $x6389 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 30: function core_state_transition, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x3901 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x6389 (or false false)))
(let (($x491 (or $x6389 false false)))
(let (($x227 (not $x491)))
(and $x227 (or $x491 (and (distinct ?x3901 ?x3901) true))))))))
(check-sat)
; query 31: function core_state_transition, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x6389 (or false false)))
(let (($x190 (not $x6389)))
(and $x190 (or $x6389 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 32: function core_state_transition, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x347 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x6389 (or false false)))
(let (($x491 (or $x6389 false false)))
(let (($x227 (not $x491)))
(and $x227 (or $x491 (and (distinct ?x347 ?x347) true))))))))
(check-sat)
; query 33: function core_state_transition, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x6389 (or false false)))
(let (($x190 (not $x6389)))
(and $x190 (or $x6389 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 34: function core_state_transition, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1162 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x6389 (or false false)))
(let (($x491 (or $x6389 false false)))
(let (($x227 (not $x491)))
(and $x227 (or $x491 (and (distinct ?x1162 ?x1162) true))))))))
(check-sat)
; query 35: function core_state_transition, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x6389 (or false false)))
(let (($x190 (not $x6389)))
(and $x190 (or $x6389 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 36: function core_state_transition, block 51, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1162 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x6389 (or false false)))
(let (($x491 (or $x6389 false false)))
(let (($x227 (not $x491)))
(and $x227 (or $x491 (and (distinct ?x1162 ?x1162) true))))))))
(check-sat)
; query 37: function core_state_transition, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x6389 (or false false)))
(let (($x190 (not $x6389)))
(and $x190 (or $x6389 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 38: function core_state_transition, block 64, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1162 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x6389 (or false false)))
(let (($x491 (or $x6389 false false)))
(let (($x227 (not $x491)))
(and $x227 (or $x491 (and (distinct ?x1162 ?x1162) true))))))))
(check-sat)
; query 39: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x7521 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x96 (or false false false)))
(let (($x49 (not $x96)))
(and $x49 (or $x96 (and (distinct ?x7521 ?x7521) true)))))))
(check-sat)
; query 40: function core_state_transition, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x6389 (or false false)))
(let (($x190 (not $x6389)))
(and $x190 (or $x6389 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 41: function core_state_transition, block 80, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x3603 (ite (= (_ bv69 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x6389 (or false false)))
(let (($x491 (or $x6389 false false)))
(let (($x227 (not $x491)))
(and $x227 (or $x491 (and (distinct ?x3603 ?x3603) true))))))))
(check-sat)
; query 42: function core_state_transition, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x6389 (or false false)))
(let (($x190 (not $x6389)))
(and $x190 (or $x6389 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 43: function core_state_transition, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x3011 (ite (= (_ bv101 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x6389 (or false false)))
(let (($x491 (or $x6389 false false)))
(let (($x227 (not $x491)))
(and $x227 (or $x491 (and (distinct ?x3011 ?x3011) true))))))))
(check-sat)
; query 44: function core_state_transition, block 99, name %100
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x6389 (or false false)))
(let (($x190 (not $x6389)))
(and $x190 (or $x6389 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 45: function core_state_transition, block 99, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x3901 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x6389 (or false false)))
(let (($x491 (or $x6389 false false)))
(let (($x227 (not $x491)))
(and $x227 (or $x491 (and (distinct ?x3901 ?x3901) true))))))))
(check-sat)
; query 46: function crcu8, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x6389 (or false false)))
(let (($x190 (not $x6389)))
(and $x190 (or $x6389 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 47: function crcu8, block 19, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x1535 ((_ zero_extend 16) in.01_16)))
(let ((?x1783 (bvxor ?x1535 (_ bv16386 32))))
(let (($x6389 (or false false)))
(let (($x491 (or $x6389 false false)))
(let (($x227 (not $x491)))
(and $x227 (or $x491 (and (distinct ?x1783 ?x1783) true)))))))))
(check-sat)
; query 48: function crcu8, block 19, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x1535 ((_ zero_extend 16) in.01_16)))
(let ((?x1783 (bvxor ?x1535 (_ bv16386 32))))
(let ((?x2882 ((_ extract 15 0) ?x1783)))
(let (($x6389 (or false false)))
(let (($x491 (or $x6389 false false)))
(let (($x3581 (or $x491 false)))
(let (($x442 (not $x3581)))
(and $x442 (or $x3581 (and (distinct ?x2882 ?x2882) true)))))))))))
(check-sat)
; query 49: function crcu8, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x6389 (or false false)))
(let (($x190 (not $x6389)))
(and $x190 (or $x6389 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 50: function crcu8, block 29, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x2715 ((_ zero_extend 16) in27_16)))
(let ((?x6034 (bvor ?x2715 (_ bv32768 32))))
(let (($x6389 (or false false)))
(let (($x491 (or $x6389 false false)))
(let (($x227 (not $x491)))
(and $x227 (or $x491 (and (distinct ?x6034 ?x6034) true)))))))))
(check-sat)
; query 51: function crcu8, block 29, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x2715 ((_ zero_extend 16) in27_16)))
(let ((?x6034 (bvor ?x2715 (_ bv32768 32))))
(let ((?x3134 ((_ extract 15 0) ?x6034)))
(let (($x6389 (or false false)))
(let (($x491 (or $x6389 false false)))
(let (($x3581 (or $x491 false)))
(let (($x442 (not $x3581)))
(and $x442 (or $x3581 (and (distinct ?x3134 ?x3134) true)))))))))))
(check-sat)
; query 52: function crcu8, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x6389 (or false false)))
(let (($x190 (not $x6389)))
(and $x190 (or $x6389 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 53: function crcu8, block 33, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x2715 ((_ zero_extend 16) in27_16)))
(let ((?x5080 (bvand ?x2715 (_ bv32767 32))))
(let (($x6389 (or false false)))
(let (($x491 (or $x6389 false false)))
(let (($x227 (not $x491)))
(and $x227 (or $x491 (and (distinct ?x5080 ?x5080) true)))))))))
(check-sat)
; query 54: function crcu8, block 33, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x2715 ((_ zero_extend 16) in27_16)))
(let ((?x5080 (bvand ?x2715 (_ bv32767 32))))
(let ((?x6648 ((_ extract 15 0) ?x5080)))
(let (($x6389 (or false false)))
(let (($x491 (or $x6389 false false)))
(let (($x3581 (or $x491 false)))
(let (($x442 (not $x3581)))
(and $x442 (or $x3581 (and (distinct ?x6648 ?x6648) true)))))))))))
(check-sat)
; query 55: function crcu8, block 38, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_8 () (_ BitVec 8))
(assert
 (let (($x96 (or false false false)))
(let (($x49 (not $x96)))
(and $x49 (or $x96 (and (distinct (bvadd in.02_8 (_ bv1 8)) (bvadd in.02_8 (_ bv1 8))) true))))))
(check-sat)
; query 56: function crcu8, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x7422 ((_ extract 7 0) in.01_16)))
(let ((?x4778 ((_ zero_extend 24) ?x7422)))
(let (($x6389 (or false false)))
(let (($x730 (or $x6389 false)))
(and (not $x730) (or $x730 (and (distinct ?x4778 ?x4778) true))))))))
(check-sat)
; query 57: function crcu8, block 6, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x7422 ((_ extract 7 0) in.01_16)))
(let ((?x4778 ((_ zero_extend 24) ?x7422)))
(let ((?x5009 (bvand ?x4778 (_ bv1 32))))
(let (($x6389 (or false false)))
(let (($x730 (or $x6389 false)))
(let (($x6415 (or $x730 false false)))
(and (not $x6415) (or $x6415 (and (distinct ?x5009 ?x5009) true))))))))))
(check-sat)
; query 58: function crcu8, block 6, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x7422 ((_ extract 7 0) in.01_16)))
(let ((?x4778 ((_ zero_extend 24) ?x7422)))
(let ((?x5009 (bvand ?x4778 (_ bv1 32))))
(let ((?x694 ((_ zero_extend 24) in.0_8)))
(let ((?x283 (bvand ?x694 (_ bv1 32))))
(let ((?x7157 (bvxor ?x283 ?x5009)))
(let (($x6389 (or false false)))
(let (($x730 (or $x6389 false)))
(let (($x6415 (or $x730 false false)))
(let (($x491 (or $x6389 false false)))
(let (($x4380 (or $x491 $x6415 false)))
(and (not $x4380) (or $x4380 (and (distinct ?x7157 ?x7157) true)))))))))))))))
(check-sat)
; query 59: function crcu8, block 6, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x7422 ((_ extract 7 0) in.01_16)))
(let ((?x4778 ((_ zero_extend 24) ?x7422)))
(let ((?x5009 (bvand ?x4778 (_ bv1 32))))
(let ((?x694 ((_ zero_extend 24) in.0_8)))
(let ((?x283 (bvand ?x694 (_ bv1 32))))
(let ((?x7157 (bvxor ?x283 ?x5009)))
(let ((?x865 ((_ extract 7 0) ?x7157)))
(let (($x6389 (or false false)))
(let (($x730 (or $x6389 false)))
(let (($x6415 (or $x730 false false)))
(let (($x491 (or $x6389 false false)))
(let (($x4380 (or $x491 $x6415 false)))
(let (($x6850 (or $x4380 false)))
(and (not $x6850) (or $x6850 (and (distinct ?x865 ?x865) true)))))))))))))))))
(check-sat)
; query 60: function crcu8, block 6, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x6389 (or false false)))
(let (($x190 (not $x6389)))
(and $x190 (or $x6389 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 61: function crcu8, block 6, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x694 ((_ zero_extend 24) in.0_8)))
(let ((?x7226 (bvashr ?x694 (_ bv1 32))))
(let (($x6389 (or false false)))
(let (($x491 (or $x6389 false false)))
(let (($x917 (or $x491 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not $x917) (or $x917 (and (distinct ?x7226 ?x7226) true)))))))))
(check-sat)
; query 62: function crcu8, block 6, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x694 ((_ zero_extend 24) in.0_8)))
(let ((?x7226 (bvashr ?x694 (_ bv1 32))))
(let ((?x3796 ((_ extract 7 0) ?x7226)))
(let (($x6389 (or false false)))
(let (($x491 (or $x6389 false false)))
(let (($x917 (or $x491 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x6414 (or $x917 false)))
(and (not $x6414) (or $x6414 (and (distinct ?x3796 ?x3796) true)))))))))))
(check-sat)
; query 63: function crcu8, block 6, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x7422 ((_ extract 7 0) in.01_16)))
(let ((?x4778 ((_ zero_extend 24) ?x7422)))
(let ((?x5009 (bvand ?x4778 (_ bv1 32))))
(let ((?x694 ((_ zero_extend 24) in.0_8)))
(let ((?x283 (bvand ?x694 (_ bv1 32))))
(let ((?x7157 (bvxor ?x283 ?x5009)))
(let ((?x865 ((_ extract 7 0) ?x7157)))
(let ((?x3147 ((_ zero_extend 24) ?x865)))
(let (($x6389 (or false false)))
(let (($x730 (or $x6389 false)))
(let (($x6415 (or $x730 false false)))
(let (($x491 (or $x6389 false false)))
(let (($x4380 (or $x491 $x6415 false)))
(let (($x6850 (or $x4380 false)))
(let (($x5633 (or $x6850 false)))
(and (not $x5633) (or $x5633 (and (distinct ?x3147 ?x3147) true)))))))))))))))))))
(check-sat)
; query 64: function crcu8, block 6, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x7422 ((_ extract 7 0) in.01_16)))
(let ((?x4778 ((_ zero_extend 24) ?x7422)))
(let ((?x5009 (bvand ?x4778 (_ bv1 32))))
(let ((?x694 ((_ zero_extend 24) in.0_8)))
(let ((?x283 (bvand ?x694 (_ bv1 32))))
(let ((?x7157 (bvxor ?x283 ?x5009)))
(let ((?x865 ((_ extract 7 0) ?x7157)))
(let ((?x3147 ((_ zero_extend 24) ?x865)))
(let ((?x2505 (ite (= (_ bv1 32) ?x3147) (_ bv1 1) (_ bv0 1))))
(let (($x6389 (or false false)))
(let (($x730 (or $x6389 false)))
(let (($x6415 (or $x730 false false)))
(let (($x491 (or $x6389 false false)))
(let (($x4380 (or $x491 $x6415 false)))
(let (($x6850 (or $x4380 false)))
(let (($x5633 (or $x6850 false)))
(let (($x2165 (or $x5633 false false)))
(and (not $x2165) (or $x2165 (and (distinct ?x2505 ?x2505) true)))))))))))))))))))))
(check-sat)
; query 65: function crcu8, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x6389 (or false false)))
(let (($x190 (not $x6389)))
(and $x190 (or $x6389 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 66: function crcu8, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x694 ((_ zero_extend 24) in.0_8)))
(let ((?x283 (bvand ?x694 (_ bv1 32))))
(let (($x6389 (or false false)))
(let (($x491 (or $x6389 false false)))
(let (($x227 (not $x491)))
(and $x227 (or $x491 (and (distinct ?x283 ?x283) true)))))))))
(check-sat)
; query 67: function crcu8, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x6389 (or false false)))
(let (($x190 (not $x6389)))
(and $x190 (or $x6389 (and (distinct ((_ extract 7 0) in.01_16) ((_ extract 7 0) in.01_16)) true))))))
(check-sat)
; query 68: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x4367 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1257 ((_ zero_extend 31) ?x4367)))
(let ((?x880 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2963 ((_ zero_extend 31) ?x880)))
(let ((?x5467 (bvand ?x2963 ?x1257)))
(let ((?x626 (ite (and (distinct (_ bv0 32) ?x5467) true) (_ bv1 1) (_ bv0 1))))
(let ((?x6963 ((_ zero_extend 63) ?x626)))
(let (($x6389 (or false false)))
(let (($x491 (or $x6389 false false)))
(let (($x3581 (or $x491 false)))
(let (($x3236 (or $x3581 $x3581 false)))
(let (($x4809 (or $x3236 false false)))
(let (($x4511 (or $x4809 false)))
(and (not $x4511) (or $x4511 (and (distinct ?x6963 ?x6963) true)))))))))))))))))
(check-sat)
; query 69: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x4367 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1257 ((_ zero_extend 31) ?x4367)))
(let ((?x880 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2963 ((_ zero_extend 31) ?x880)))
(let ((?x5467 (bvand ?x2963 ?x1257)))
(let ((?x626 (ite (and (distinct (_ bv0 32) ?x5467) true) (_ bv1 1) (_ bv0 1))))
(let (($x7153 (= (_ bv1 1) ?x626)))
(let ((?x3842 (ite $x7153 (_ bv1 32) (_ bv0 32))))
(let (($x6389 (or false false)))
(let (($x491 (or $x6389 false false)))
(let (($x3581 (or $x491 false)))
(let (($x3236 (or $x3581 $x3581 false)))
(let (($x4809 (or $x3236 false false)))
(let (($x1241 (or $x4809 (ite $x7153 false false))))
(and (not $x1241) (or $x1241 (and (distinct ?x3842 ?x3842) true))))))))))))))))))
(check-sat)
; query 70: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x4367 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1257 ((_ zero_extend 31) ?x4367)))
(let ((?x880 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2963 ((_ zero_extend 31) ?x880)))
(let ((?x5467 (bvand ?x2963 ?x1257)))
(let ((?x626 (ite (and (distinct (_ bv0 32) ?x5467) true) (_ bv1 1) (_ bv0 1))))
(let (($x7153 (= (_ bv1 1) ?x626)))
(let ((?x3842 (ite $x7153 (_ bv1 32) (_ bv0 32))))
(let ((?x3547 ((_ extract 7 0) ?x3842)))
(let (($x6389 (or false false)))
(let (($x491 (or $x6389 false false)))
(let (($x3581 (or $x491 false)))
(let (($x3236 (or $x3581 $x3581 false)))
(let (($x4809 (or $x3236 false false)))
(let (($x1241 (or $x4809 (ite $x7153 false false))))
(let (($x4383 (or $x1241 false)))
(and (not $x4383) (or $x4383 (and (distinct ?x3547 ?x3547) true))))))))))))))))))))
(check-sat)
; query 71: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x6389 (or false false)))
(let (($x190 (not $x6389)))
(and $x190 (or $x6389 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 72: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x880 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x6389 (or false false)))
(let (($x491 (or $x6389 false false)))
(let (($x227 (not $x491)))
(and $x227 (or $x491 (and (distinct ?x880 ?x880) true))))))))
(check-sat)
; query 73: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x880 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2963 ((_ zero_extend 31) ?x880)))
(let (($x6389 (or false false)))
(let (($x491 (or $x6389 false false)))
(let (($x3581 (or $x491 false)))
(let (($x442 (not $x3581)))
(and $x442 (or $x3581 (and (distinct ?x2963 ?x2963) true))))))))))
(check-sat)
; query 74: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x6389 (or false false)))
(let (($x190 (not $x6389)))
(and $x190 (or $x6389 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 75: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x4367 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x6389 (or false false)))
(let (($x491 (or $x6389 false false)))
(let (($x227 (not $x491)))
(and $x227 (or $x491 (and (distinct ?x4367 ?x4367) true))))))))
(check-sat)
; query 76: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x4367 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1257 ((_ zero_extend 31) ?x4367)))
(let (($x6389 (or false false)))
(let (($x491 (or $x6389 false false)))
(let (($x3581 (or $x491 false)))
(let (($x442 (not $x3581)))
(and $x442 (or $x3581 (and (distinct ?x1257 ?x1257) true))))))))))
(check-sat)
; query 77: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x4367 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1257 ((_ zero_extend 31) ?x4367)))
(let ((?x880 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2963 ((_ zero_extend 31) ?x880)))
(let ((?x5467 (bvand ?x2963 ?x1257)))
(let (($x6389 (or false false)))
(let (($x491 (or $x6389 false false)))
(let (($x3581 (or $x491 false)))
(let (($x3236 (or $x3581 $x3581 false)))
(and (not $x3236) (or $x3236 (and (distinct ?x5467 ?x5467) true)))))))))))))
(check-sat)
; query 78: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x4367 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1257 ((_ zero_extend 31) ?x4367)))
(let ((?x880 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2963 ((_ zero_extend 31) ?x880)))
(let ((?x5467 (bvand ?x2963 ?x1257)))
(let ((?x626 (ite (and (distinct (_ bv0 32) ?x5467) true) (_ bv1 1) (_ bv0 1))))
(let (($x6389 (or false false)))
(let (($x491 (or $x6389 false false)))
(let (($x3581 (or $x491 false)))
(let (($x3236 (or $x3581 $x3581 false)))
(let (($x4809 (or $x3236 false false)))
(and (not $x4809) (or $x4809 (and (distinct ?x626 ?x626) true)))))))))))))))
(check-sat)
; query 79: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1638 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x96 (or false false false)))
(let (($x49 (not $x96)))
(and $x49 (or $x96 (and (distinct ?x1638 ?x1638) true)))))))
(check-sat)
; query 80: function matrix_add_const, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x96 (or false false false)))
(let (($x49 (not $x96)))
(and $x49 (or $x96 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 81: function matrix_add_const, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x46 (bvadd in.01_32 (_ bv1 32))))
(let (($x131 (and (distinct ?x46 ?x46) true)))
(let (($x96 (or false false false)))
(let (($x49 (not $x96)))
(and $x49 (or $x96 $x131)))))))
(check-sat)
; query 82: function matrix_mul_const, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x96 (or false false false)))
(let (($x49 (not $x96)))
(and $x49 (or $x96 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 83: function matrix_mul_const, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x46 (bvadd in.01_32 (_ bv1 32))))
(let (($x131 (and (distinct ?x46 ?x46) true)))
(let (($x96 (or false false false)))
(let (($x49 (not $x96)))
(and $x49 (or $x96 $x131)))))))
(check-sat)
; query 84: function matrix_mul_matrix, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x96 (or false false false)))
(let (($x49 (not $x96)))
(and $x49 (or $x96 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 85: function matrix_mul_matrix, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x46 (bvadd in.01_32 (_ bv1 32))))
(let (($x131 (and (distinct ?x46 ?x46) true)))
(let (($x96 (or false false false)))
(let (($x49 (not $x96)))
(and $x49 (or $x96 $x131)))))))
(check-sat)
; query 86: function matrix_mul_matrix, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x96 (or false false false)))
(let (($x49 (not $x96)))
(and $x49 (or $x96 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 87: function matrix_mul_matrix_bitextract, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x96 (or false false false)))
(let (($x49 (not $x96)))
(and $x49 (or $x96 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 88: function matrix_mul_matrix_bitextract, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x46 (bvadd in.01_32 (_ bv1 32))))
(let (($x131 (and (distinct ?x46 ?x46) true)))
(let (($x96 (or false false false)))
(let (($x49 (not $x96)))
(and $x49 (or $x96 $x131)))))))
(check-sat)
; query 89: function matrix_mul_matrix_bitextract, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x96 (or false false false)))
(let (($x49 (not $x96)))
(and $x49 (or $x96 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 90: function matrix_mul_vect, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x96 (or false false false)))
(let (($x49 (not $x96)))
(and $x49 (or $x96 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 91: function matrix_mul_vect, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x46 (bvadd in.01_32 (_ bv1 32))))
(let (($x131 (and (distinct ?x46 ?x46) true)))
(let (($x96 (or false false false)))
(let (($x49 (not $x96)))
(and $x49 (or $x96 $x131)))))))
(check-sat)
; query 92: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x6389 (or false false)))
(let (($x190 (not $x6389)))
(and $x190 (or $x6389 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 93: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x1917 ((_ sign_extend 16) in.1_16)))
(let ((?x4361 (bvadd ?x1917 (_ bv10 32))))
(let (($x805 (and (distinct (bvadd ((_ sign_extend 1) ?x1917) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x4361)) true)))
(let (($x6389 (or false false)))
(let (($x3988 (or $x6389 false (or $x805))))
(and (not $x3988) (or $x3988 (and (distinct ?x4361 ?x4361) true)))))))))
(check-sat)
; query 94: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x1917 ((_ sign_extend 16) in.1_16)))
(let ((?x4361 (bvadd ?x1917 (_ bv10 32))))
(let ((?x3109 ((_ extract 15 0) ?x4361)))
(let (($x805 (and (distinct (bvadd ((_ sign_extend 1) ?x1917) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x4361)) true)))
(let (($x6389 (or false false)))
(let (($x3988 (or $x6389 false (or $x805))))
(let (($x2844 (or $x3988 false)))
(and (not $x2844) (or $x2844 (and (distinct ?x3109 ?x3109) true)))))))))))
(check-sat)
; query 95: function matrix_sum, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x3641 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x96 (or false false false)))
(let (($x49 (not $x96)))
(and $x49 (or $x96 (and (distinct ?x3641 ?x3641) true)))))))
(check-sat)
; query 96: function matrix_sum, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x3641 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let ((?x3345 ((_ zero_extend 63) ?x3641)))
(let (($x96 (or false false false)))
(let (($x2853 (or $x96 false)))
(and (not $x2853) (or $x2853 (and (distinct ?x3345 ?x3345) true))))))))
(check-sat)
; query 97: function matrix_sum, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x3641 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x3441 (= (_ bv1 1) ?x3641)))
(let ((?x533 (ite $x3441 (_ bv1 32) (_ bv0 32))))
(let (($x96 (or false false false)))
(let (($x7137 (or $x96 (ite $x3441 false false))))
(and (not $x7137) (or $x7137 (and (distinct ?x533 ?x533) true)))))))))
(check-sat)
; query 98: function matrix_sum, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x6389 (or false false)))
(let (($x190 (not $x6389)))
(and $x190 (or $x6389 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 99: function matrix_sum, block 22, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x3641 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x3441 (= (_ bv1 1) ?x3641)))
(let ((?x533 (ite $x3441 (_ bv1 32) (_ bv0 32))))
(let ((?x1917 ((_ sign_extend 16) in.1_16)))
(let ((?x1143 (bvadd ?x1917 ?x533)))
(let (($x7465 (and (distinct (bvadd ((_ sign_extend 1) ?x1917) ((_ sign_extend 1) ?x533)) ((_ sign_extend 1) ?x1143)) true)))
(let (($x96 (or false false false)))
(let (($x7137 (or $x96 (ite $x3441 false false))))
(let (($x6389 (or false false)))
(let (($x5004 (or $x6389 $x7137 (or $x7465))))
(and (not $x5004) (or $x5004 (and (distinct ?x1143 ?x1143) true))))))))))))))
(check-sat)
; query 100: function matrix_sum, block 22, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x3641 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x3441 (= (_ bv1 1) ?x3641)))
(let ((?x533 (ite $x3441 (_ bv1 32) (_ bv0 32))))
(let ((?x1917 ((_ sign_extend 16) in.1_16)))
(let ((?x1143 (bvadd ?x1917 ?x533)))
(let ((?x1277 ((_ extract 15 0) ?x1143)))
(let (($x7465 (and (distinct (bvadd ((_ sign_extend 1) ?x1917) ((_ sign_extend 1) ?x533)) ((_ sign_extend 1) ?x1143)) true)))
(let (($x96 (or false false false)))
(let (($x7137 (or $x96 (ite $x3441 false false))))
(let (($x6389 (or false false)))
(let (($x5004 (or $x6389 $x7137 (or $x7465))))
(let (($x5072 (or $x5004 false)))
(and (not $x5072) (or $x5072 (and (distinct ?x1277 ?x1277) true))))))))))))))))
(check-sat)
; query 101: function matrix_sum, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x96 (or false false false)))
(let (($x49 (not $x96)))
(and $x49 (or $x96 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 102: function matrix_sum, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x46 (bvadd in.01_32 (_ bv1 32))))
(let (($x131 (and (distinct ?x46 ?x46) true)))
(let (($x96 (or false false false)))
(let (($x49 (not $x96)))
(and $x49 (or $x96 $x131)))))))
(check-sat)
; query 103: function parseval, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.23_32 () (_ BitVec 32))
(assert
 (let (($x350 (and (distinct (bvmul ((_ sign_extend 32) in.23_32) ((_ sign_extend 32) (_ bv1024 32))) ((_ sign_extend 32) (bvmul in.23_32 (_ bv1024 32)))) true)))
(let (($x3709 (or false false (or $x350))))
(and (not $x3709) (or $x3709 (and (distinct (bvmul in.23_32 (_ bv1024 32)) (bvmul in.23_32 (_ bv1024 32))) true))))))
(check-sat)
; query 104: function parseval, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.34_32 () (_ BitVec 32))
(assert
 (let (($x1195 (and (distinct (bvmul ((_ sign_extend 32) in.34_32) ((_ sign_extend 32) (_ bv1048576 32))) ((_ sign_extend 32) (bvmul in.34_32 (_ bv1048576 32)))) true)))
(let (($x4926 (or false false (or $x1195))))
(and (not $x4926) (or $x4926 (and (distinct (bvmul in.34_32 (_ bv1048576 32)) (bvmul in.34_32 (_ bv1048576 32))) true))))))
(check-sat)
; query 105: function partition_memory, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x96 (or false false false)))
(let (($x49 (not $x96)))
(and $x49 (or $x96 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
