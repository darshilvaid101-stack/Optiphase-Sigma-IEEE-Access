; OptiPhase-Sigma refinement certificate for sweep K16-R6-028
