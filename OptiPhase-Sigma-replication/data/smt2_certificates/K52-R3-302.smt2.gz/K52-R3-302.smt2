; OptiPhase-Sigma refinement certificate for sweep K52-R3-302
; query 0: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x141 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x20 (or false false false)))
(let (($x96 (not $x20)))
(and $x96 (or $x20 (and (distinct ?x141 ?x141) true)))))))
(check-sat)
; query 1: function s162, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x132 (ite (bvslt (_ bv0 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x20 (or false false false)))
(let (($x96 (not $x20)))
(and $x96 (or $x20 (and (distinct ?x132 ?x132) true)))))))
(check-sat)
; query 2: function s276, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x12 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x8 (or false false (or $x12))))
(and (not $x8) (or $x8 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 3: function s276, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x182 (and (distinct (ite (bvsgt (_ bv16000 32) (bvadd in.0_32 (_ bv1 32))) (_ bv1 1) (_ bv0 1)) (ite (bvsgt (_ bv15999 32) in.0_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x20 (or false false false)))
(let (($x12 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x8 (or false false (or $x12))))
(and (not (or $x8 false false)) (or $x20 $x182)))))))
(check-sat)
; query 4: function set1d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x868 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x20 (or false false false)))
(let (($x96 (not $x20)))
(and $x96 (or $x20 (and (distinct ?x868 ?x868) true)))))))
(check-sat)
; query 5: function set1ds, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x125 (ite (= (_ bv4294967295 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x20 (or false false false)))
(let (($x96 (not $x20)))
(and $x96 (or $x20 (and (distinct ?x125 ?x125) true)))))))
(check-sat)
; query 6: function set2d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x868 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x20 (or false false false)))
(let (($x96 (not $x20)))
(and $x96 (or $x20 (and (distinct ?x868 ?x868) true)))))))
(check-sat)
