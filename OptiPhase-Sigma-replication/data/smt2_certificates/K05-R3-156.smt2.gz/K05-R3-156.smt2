; OptiPhase-Sigma refinement certificate for sweep K05-R3-156
; query 0: function xmalloc, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in7_32 () (_ BitVec 32))
(assert
 (let ((?x43 (ite (and (distinct (_ bv0 32) in7_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x73 (or false false false)))
(and (not $x73) (or $x73 (and (distinct ?x43 ?x43) true))))))
(check-sat)
