; OptiPhase-Sigma refinement certificate for sweep K57-R3-248
; query 0: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x233 (or false false)))
(let (($x863 (not $x233)))
(and $x863 (or $x233 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 1: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x269 ((_ sign_extend 16) in3_16)))
(let ((?x174 (bvand ?x269 (_ bv127 32))))
(let (($x233 (or false false)))
(let (($x619 (or $x233 false false)))
(let (($x580 (not $x619)))
(and $x580 (or $x619 (and (distinct ?x174 ?x174) true)))))))))
(check-sat)
; query 2: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x269 ((_ sign_extend 16) in3_16)))
(let ((?x174 (bvand ?x269 (_ bv127 32))))
(let ((?x451 ((_ extract 15 0) ?x174)))
(let (($x233 (or false false)))
(let (($x619 (or $x233 false false)))
(let (($x50 (or $x619 false)))
(and (not $x50) (or $x50 (and (distinct ?x451 ?x451) true))))))))))
(check-sat)
; query 3: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x233 (or false false)))
(let (($x863 (not $x233)))
(and $x863 (or $x233 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 4: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x524 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x233 (or false false)))
(let (($x619 (or $x233 false false)))
(let (($x580 (not $x619)))
(and $x580 (or $x619 (and (distinct ?x524 ?x524) true))))))))
(check-sat)
; query 5: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x222 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x86 (or false false false)))
(let (($x29 (not $x86)))
(and $x29 (or $x86 (and (distinct ?x222 ?x222) true)))))))
(check-sat)
; query 6: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x119 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x86 (or false false false)))
(let (($x29 (not $x86)))
(and $x29 (or $x86 (and (distinct ?x119 ?x119) true)))))))
(check-sat)
; query 7: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x86 (or false false false)))
(let (($x29 (not $x86)))
(and $x29 (or $x86 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 8: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x1272 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x1287 (or false false (or $x1272))))
(and (not $x1287) (or $x1287 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 9: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x867 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x86 (or false false false)))
(let (($x29 (not $x86)))
(and $x29 (or $x86 (and (distinct ?x867 ?x867) true)))))))
(check-sat)
