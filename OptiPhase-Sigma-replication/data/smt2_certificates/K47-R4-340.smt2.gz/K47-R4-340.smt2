; OptiPhase-Sigma refinement certificate for sweep K47-R4-340
; query 0: function main, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x170 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x46 (or false false false)))
(and (not $x46) (or $x46 (and (distinct ?x170 ?x170) true))))))
(check-sat)
