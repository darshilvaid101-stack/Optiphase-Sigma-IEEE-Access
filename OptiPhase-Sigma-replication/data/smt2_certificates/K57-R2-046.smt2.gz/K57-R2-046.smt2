; OptiPhase-Sigma refinement certificate for sweep K57-R2-046
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x131 (or false false)))
(let (($x56 (not $x131)))
(and $x56 (or $x131 (and (distinct ((_ sign_extend 16) in25_16) ((_ sign_extend 16) in25_16)) true))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let ((?x42 (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))))
(let (($x131 (or false false)))
(let (($x1296 (or $x131 false false)))
(let (($x128 (not $x1296)))
(and $x128 (or $x1296 (and (distinct ?x42 ?x42) true))))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x131 (or false false)))
(let (($x56 (not $x131)))
(and $x56 (or $x131 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x104 ((_ sign_extend 16) in3_16)))
(let ((?x100 (bvand ?x104 (_ bv127 32))))
(let (($x131 (or false false)))
(let (($x1296 (or $x131 false false)))
(let (($x128 (not $x1296)))
(and $x128 (or $x1296 (and (distinct ?x100 ?x100) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x104 ((_ sign_extend 16) in3_16)))
(let ((?x100 (bvand ?x104 (_ bv127 32))))
(let ((?x189 ((_ extract 15 0) ?x100)))
(let (($x131 (or false false)))
(let (($x1296 (or $x131 false false)))
(let (($x148 (or $x1296 false)))
(let (($x601 (not $x148)))
(and $x601 (or $x148 (and (distinct ?x189 ?x189) true)))))))))))
(check-sat)
; query 5: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x131 (or false false)))
(let (($x56 (not $x131)))
(and $x56 (or $x131 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 6: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x513 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x131 (or false false)))
(let (($x1296 (or $x131 false false)))
(let (($x128 (not $x1296)))
(and $x128 (or $x1296 (and (distinct ?x513 ?x513) true))))))))
(check-sat)
; query 7: function core_bench_list, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x46 (or false false false)))
(let (($x732 (not $x46)))
(and $x732 (or $x46 (and (distinct (bvadd in.0_16 (_ bv1 16)) (bvadd in.0_16 (_ bv1 16))) true))))))
(check-sat)
; query 8: function core_bench_state, block 105, name %106
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x46 (or false false false)))
(let (($x732 (not $x46)))
(and $x732 (or $x46 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 9: function core_bench_state, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x46 (or false false false)))
(let (($x732 (not $x46)))
(and $x732 (or $x46 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 10: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x141 (bvadd in.01_32 (_ bv1 32))))
(let (($x107 (and (distinct ?x141 ?x141) true)))
(let (($x46 (or false false false)))
(let (($x732 (not $x46)))
(and $x732 (or $x46 $x107)))))))
(check-sat)
; query 11: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x141 (bvadd in.01_32 (_ bv1 32))))
(let ((?x227 (bvmul ?x141 ?x141)))
(let (($x46 (or false false false)))
(let (($x625 (or $x46 $x46 false)))
(and (not $x625) (or $x625 (and (distinct ?x227 ?x227) true))))))))
(check-sat)
; query 12: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x141 (bvadd in.01_32 (_ bv1 32))))
(let ((?x227 (bvmul ?x141 ?x141)))
(let ((?x50 (bvmul ?x227 (_ bv2 32))))
(let (($x46 (or false false false)))
(let (($x625 (or $x46 $x46 false)))
(let (($x1071 (or $x625 false false)))
(and (not $x1071) (or $x1071 (and (distinct ?x50 ?x50) true))))))))))
(check-sat)
; query 13: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x141 (bvadd in.01_32 (_ bv1 32))))
(let ((?x227 (bvmul ?x141 ?x141)))
(let ((?x50 (bvmul ?x227 (_ bv2 32))))
(let ((?x228 (bvmul ?x50 (_ bv4 32))))
(let (($x46 (or false false false)))
(let (($x625 (or $x46 $x46 false)))
(let (($x1071 (or $x625 false false)))
(let (($x80 (or $x1071 false false)))
(and (not $x80) (or $x80 (and (distinct ?x228 ?x228) true))))))))))))
(check-sat)
; query 14: function core_init_matrix, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x46 (or false false false)))
(let (($x732 (not $x46)))
(and $x732 (or $x46 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 15: function core_init_matrix, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x46 (or false false false)))
(let (($x732 (not $x46)))
(and $x732 (or $x46 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 16: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x121 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x46 (or false false false)))
(let (($x732 (not $x46)))
(and $x732 (or $x46 (and (distinct ?x121 ?x121) true)))))))
(check-sat)
; query 17: function core_init_state, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_32 () (_ BitVec 32))
(assert
 (let (($x46 (or false false false)))
(let (($x732 (not $x46)))
(and $x732 (or $x46 (and (distinct (bvadd in.06_32 (_ bv1 32)) (bvadd in.06_32 (_ bv1 32))) true))))))
(check-sat)
; query 18: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x8 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x46 (or false false false)))
(let (($x732 (not $x46)))
(and $x732 (or $x46 (and (distinct ?x8 ?x8) true)))))))
(check-sat)
; query 19: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x46 (or false false false)))
(let (($x732 (not $x46)))
(and $x732 (or $x46 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 20: function core_list_init, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x141 (bvadd in.01_32 (_ bv1 32))))
(let (($x107 (and (distinct ?x141 ?x141) true)))
(let (($x46 (or false false false)))
(let (($x732 (not $x46)))
(and $x732 (or $x46 $x107)))))))
(check-sat)
; query 21: function core_list_mergesort, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x141 (bvadd in.01_32 (_ bv1 32))))
(let (($x107 (and (distinct ?x141 ?x141) true)))
(let (($x458 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x141)) true)))
(let (($x64 (or false false (or $x458))))
(and (not $x64) (or $x64 $x107)))))))
(check-sat)
; query 22: function core_list_mergesort, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x162 (ite (bvslt (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x46 (or false false false)))
(let (($x732 (not $x46)))
(and $x732 (or $x46 (and (distinct ?x162 ?x162) true)))))))
(check-sat)
; query 23: function core_list_mergesort, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.224_32 () (_ BitVec 32))
(assert
 (let ((?x846 (ite (= (_ bv0 32) in.224_32) (_ bv1 1) (_ bv0 1))))
(let (($x46 (or false false false)))
(let (($x732 (not $x46)))
(and $x732 (or $x46 (and (distinct ?x846 ?x846) true)))))))
(check-sat)
; query 24: function core_list_mergesort, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x734 (ite (= (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x46 (or false false false)))
(let (($x732 (not $x46)))
(and $x732 (or $x46 (and (distinct ?x734 ?x734) true)))))))
(check-sat)
; query 25: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x11 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x226 (or false false (or $x11))))
(and (not $x226) (or $x226 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 26: function core_list_mergesort, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x231 (and (distinct (bvmul ((_ sign_extend 32) in.020_32) ((_ sign_extend 32) (_ bv2 32))) ((_ sign_extend 32) (bvmul in.020_32 (_ bv2 32)))) true)))
(let (($x650 (or false false (or $x231))))
(and (not $x650) (or $x650 (and (distinct (bvmul in.020_32 (_ bv2 32)) (bvmul in.020_32 (_ bv2 32))) true))))))
(check-sat)
; query 27: function core_state_transition, block 102, name %103
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x131 (or false false)))
(let (($x56 (not $x131)))
(and $x56 (or $x131 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 28: function core_state_transition, block 102, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x93 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x131 (or false false)))
(let (($x1296 (or $x131 false false)))
(let (($x128 (not $x1296)))
(and $x128 (or $x1296 (and (distinct ?x93 ?x93) true))))))))
(check-sat)
; query 29: function core_state_transition, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x131 (or false false)))
(let (($x56 (not $x131)))
(and $x56 (or $x131 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 30: function core_state_transition, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x789 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x131 (or false false)))
(let (($x1296 (or $x131 false false)))
(let (($x128 (not $x1296)))
(and $x128 (or $x1296 (and (distinct ?x789 ?x789) true))))))))
(check-sat)
; query 31: function core_state_transition, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x131 (or false false)))
(let (($x56 (not $x131)))
(and $x56 (or $x131 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 32: function core_state_transition, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x93 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x131 (or false false)))
(let (($x1296 (or $x131 false false)))
(let (($x128 (not $x1296)))
(and $x128 (or $x1296 (and (distinct ?x93 ?x93) true))))))))
(check-sat)
; query 33: function core_state_transition, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x131 (or false false)))
(let (($x56 (not $x131)))
(and $x56 (or $x131 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 34: function core_state_transition, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x78 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x131 (or false false)))
(let (($x1296 (or $x131 false false)))
(let (($x128 (not $x1296)))
(and $x128 (or $x1296 (and (distinct ?x78 ?x78) true))))))))
(check-sat)
; query 35: function core_state_transition, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x131 (or false false)))
(let (($x56 (not $x131)))
(and $x56 (or $x131 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 36: function core_state_transition, block 51, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x78 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x131 (or false false)))
(let (($x1296 (or $x131 false false)))
(let (($x128 (not $x1296)))
(and $x128 (or $x1296 (and (distinct ?x78 ?x78) true))))))))
(check-sat)
; query 37: function core_state_transition, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x131 (or false false)))
(let (($x56 (not $x131)))
(and $x56 (or $x131 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 38: function core_state_transition, block 64, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x78 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x131 (or false false)))
(let (($x1296 (or $x131 false false)))
(let (($x128 (not $x1296)))
(and $x128 (or $x1296 (and (distinct ?x78 ?x78) true))))))))
(check-sat)
; query 39: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x79 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x46 (or false false false)))
(let (($x732 (not $x46)))
(and $x732 (or $x46 (and (distinct ?x79 ?x79) true)))))))
(check-sat)
; query 40: function core_state_transition, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x131 (or false false)))
(let (($x56 (not $x131)))
(and $x56 (or $x131 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 41: function core_state_transition, block 80, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x34 (ite (= (_ bv69 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x131 (or false false)))
(let (($x1296 (or $x131 false false)))
(let (($x128 (not $x1296)))
(and $x128 (or $x1296 (and (distinct ?x34 ?x34) true))))))))
(check-sat)
; query 42: function core_state_transition, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x131 (or false false)))
(let (($x56 (not $x131)))
(and $x56 (or $x131 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 43: function core_state_transition, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x169 (ite (= (_ bv101 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x131 (or false false)))
(let (($x1296 (or $x131 false false)))
(let (($x128 (not $x1296)))
(and $x128 (or $x1296 (and (distinct ?x169 ?x169) true))))))))
(check-sat)
; query 44: function core_state_transition, block 99, name %100
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x131 (or false false)))
(let (($x56 (not $x131)))
(and $x56 (or $x131 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 45: function core_state_transition, block 99, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x789 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x131 (or false false)))
(let (($x1296 (or $x131 false false)))
(let (($x128 (not $x1296)))
(and $x128 (or $x1296 (and (distinct ?x789 ?x789) true))))))))
(check-sat)
; query 46: function crcu8, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x131 (or false false)))
(let (($x56 (not $x131)))
(and $x56 (or $x131 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 47: function crcu8, block 19, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x44 ((_ zero_extend 16) in.01_16)))
(let ((?x146 (bvxor ?x44 (_ bv16386 32))))
(let (($x131 (or false false)))
(let (($x1296 (or $x131 false false)))
(let (($x128 (not $x1296)))
(and $x128 (or $x1296 (and (distinct ?x146 ?x146) true)))))))))
(check-sat)
; query 48: function crcu8, block 19, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x44 ((_ zero_extend 16) in.01_16)))
(let ((?x146 (bvxor ?x44 (_ bv16386 32))))
(let ((?x111 ((_ extract 15 0) ?x146)))
(let (($x131 (or false false)))
(let (($x1296 (or $x131 false false)))
(let (($x148 (or $x1296 false)))
(let (($x601 (not $x148)))
(and $x601 (or $x148 (and (distinct ?x111 ?x111) true)))))))))))
(check-sat)
; query 49: function crcu8, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x131 (or false false)))
(let (($x56 (not $x131)))
(and $x56 (or $x131 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 50: function crcu8, block 29, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x184 ((_ zero_extend 16) in27_16)))
(let ((?x1260 (bvor ?x184 (_ bv32768 32))))
(let (($x131 (or false false)))
(let (($x1296 (or $x131 false false)))
(let (($x128 (not $x1296)))
(and $x128 (or $x1296 (and (distinct ?x1260 ?x1260) true)))))))))
(check-sat)
; query 51: function crcu8, block 29, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x184 ((_ zero_extend 16) in27_16)))
(let ((?x1260 (bvor ?x184 (_ bv32768 32))))
(let ((?x28 ((_ extract 15 0) ?x1260)))
(let (($x131 (or false false)))
(let (($x1296 (or $x131 false false)))
(let (($x148 (or $x1296 false)))
(let (($x601 (not $x148)))
(and $x601 (or $x148 (and (distinct ?x28 ?x28) true)))))))))))
(check-sat)
; query 52: function crcu8, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x131 (or false false)))
(let (($x56 (not $x131)))
(and $x56 (or $x131 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 53: function crcu8, block 33, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x184 ((_ zero_extend 16) in27_16)))
(let ((?x834 (bvand ?x184 (_ bv32767 32))))
(let (($x131 (or false false)))
(let (($x1296 (or $x131 false false)))
(let (($x128 (not $x1296)))
(and $x128 (or $x1296 (and (distinct ?x834 ?x834) true)))))))))
(check-sat)
; query 54: function crcu8, block 33, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x184 ((_ zero_extend 16) in27_16)))
(let ((?x834 (bvand ?x184 (_ bv32767 32))))
(let ((?x59 ((_ extract 15 0) ?x834)))
(let (($x131 (or false false)))
(let (($x1296 (or $x131 false false)))
(let (($x148 (or $x1296 false)))
(let (($x601 (not $x148)))
(and $x601 (or $x148 (and (distinct ?x59 ?x59) true)))))))))))
(check-sat)
; query 55: function crcu8, block 38, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_8 () (_ BitVec 8))
(assert
 (let (($x46 (or false false false)))
(let (($x732 (not $x46)))
(and $x732 (or $x46 (and (distinct (bvadd in.02_8 (_ bv1 8)) (bvadd in.02_8 (_ bv1 8))) true))))))
(check-sat)
; query 56: function crcu8, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x140 ((_ extract 7 0) in.01_16)))
(let ((?x476 ((_ zero_extend 24) ?x140)))
(let (($x131 (or false false)))
(let (($x498 (or $x131 false)))
(and (not $x498) (or $x498 (and (distinct ?x476 ?x476) true))))))))
(check-sat)
; query 57: function crcu8, block 6, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x140 ((_ extract 7 0) in.01_16)))
(let ((?x476 ((_ zero_extend 24) ?x140)))
(let ((?x69 (bvand ?x476 (_ bv1 32))))
(let (($x131 (or false false)))
(let (($x498 (or $x131 false)))
(let (($x1284 (or $x498 false false)))
(and (not $x1284) (or $x1284 (and (distinct ?x69 ?x69) true))))))))))
(check-sat)
; query 58: function crcu8, block 6, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x140 ((_ extract 7 0) in.01_16)))
(let ((?x476 ((_ zero_extend 24) ?x140)))
(let ((?x69 (bvand ?x476 (_ bv1 32))))
(let ((?x127 ((_ zero_extend 24) in.0_8)))
(let ((?x10 (bvand ?x127 (_ bv1 32))))
(let ((?x392 (bvxor ?x10 ?x69)))
(let (($x131 (or false false)))
(let (($x498 (or $x131 false)))
(let (($x1284 (or $x498 false false)))
(let (($x1296 (or $x131 false false)))
(let (($x527 (or $x1296 $x1284 false)))
(and (not $x527) (or $x527 (and (distinct ?x392 ?x392) true)))))))))))))))
(check-sat)
; query 59: function crcu8, block 6, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x140 ((_ extract 7 0) in.01_16)))
(let ((?x476 ((_ zero_extend 24) ?x140)))
(let ((?x69 (bvand ?x476 (_ bv1 32))))
(let ((?x127 ((_ zero_extend 24) in.0_8)))
(let ((?x10 (bvand ?x127 (_ bv1 32))))
(let ((?x392 (bvxor ?x10 ?x69)))
(let ((?x1160 ((_ extract 7 0) ?x392)))
(let (($x131 (or false false)))
(let (($x498 (or $x131 false)))
(let (($x1284 (or $x498 false false)))
(let (($x1296 (or $x131 false false)))
(let (($x527 (or $x1296 $x1284 false)))
(let (($x143 (or $x527 false)))
(and (not $x143) (or $x143 (and (distinct ?x1160 ?x1160) true)))))))))))))))))
(check-sat)
; query 60: function crcu8, block 6, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x131 (or false false)))
(let (($x56 (not $x131)))
(and $x56 (or $x131 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 61: function crcu8, block 6, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x127 ((_ zero_extend 24) in.0_8)))
(let ((?x723 (bvashr ?x127 (_ bv1 32))))
(let (($x131 (or false false)))
(let (($x1296 (or $x131 false false)))
(let (($x82 (or $x1296 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not $x82) (or $x82 (and (distinct ?x723 ?x723) true)))))))))
(check-sat)
; query 62: function crcu8, block 6, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x127 ((_ zero_extend 24) in.0_8)))
(let ((?x723 (bvashr ?x127 (_ bv1 32))))
(let ((?x1049 ((_ extract 7 0) ?x723)))
(let (($x131 (or false false)))
(let (($x1296 (or $x131 false false)))
(let (($x82 (or $x1296 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x30 (or $x82 false)))
(and (not $x30) (or $x30 (and (distinct ?x1049 ?x1049) true)))))))))))
(check-sat)
; query 63: function crcu8, block 6, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x140 ((_ extract 7 0) in.01_16)))
(let ((?x476 ((_ zero_extend 24) ?x140)))
(let ((?x69 (bvand ?x476 (_ bv1 32))))
(let ((?x127 ((_ zero_extend 24) in.0_8)))
(let ((?x10 (bvand ?x127 (_ bv1 32))))
(let ((?x392 (bvxor ?x10 ?x69)))
(let ((?x1160 ((_ extract 7 0) ?x392)))
(let ((?x490 ((_ zero_extend 24) ?x1160)))
(let (($x131 (or false false)))
(let (($x498 (or $x131 false)))
(let (($x1284 (or $x498 false false)))
(let (($x1296 (or $x131 false false)))
(let (($x527 (or $x1296 $x1284 false)))
(let (($x143 (or $x527 false)))
(let (($x208 (or $x143 false)))
(and (not $x208) (or $x208 (and (distinct ?x490 ?x490) true)))))))))))))))))))
(check-sat)
; query 64: function crcu8, block 6, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x140 ((_ extract 7 0) in.01_16)))
(let ((?x476 ((_ zero_extend 24) ?x140)))
(let ((?x69 (bvand ?x476 (_ bv1 32))))
(let ((?x127 ((_ zero_extend 24) in.0_8)))
(let ((?x10 (bvand ?x127 (_ bv1 32))))
(let ((?x392 (bvxor ?x10 ?x69)))
(let ((?x1160 ((_ extract 7 0) ?x392)))
(let ((?x490 ((_ zero_extend 24) ?x1160)))
(let ((?x629 (ite (= (_ bv1 32) ?x490) (_ bv1 1) (_ bv0 1))))
(let (($x131 (or false false)))
(let (($x498 (or $x131 false)))
(let (($x1284 (or $x498 false false)))
(let (($x1296 (or $x131 false false)))
(let (($x527 (or $x1296 $x1284 false)))
(let (($x143 (or $x527 false)))
(let (($x208 (or $x143 false)))
(let (($x1134 (or $x208 false false)))
(and (not $x1134) (or $x1134 (and (distinct ?x629 ?x629) true)))))))))))))))))))))
(check-sat)
; query 65: function crcu8, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x131 (or false false)))
(let (($x56 (not $x131)))
(and $x56 (or $x131 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 66: function crcu8, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x127 ((_ zero_extend 24) in.0_8)))
(let ((?x10 (bvand ?x127 (_ bv1 32))))
(let (($x131 (or false false)))
(let (($x1296 (or $x131 false false)))
(let (($x128 (not $x1296)))
(and $x128 (or $x1296 (and (distinct ?x10 ?x10) true)))))))))
(check-sat)
; query 67: function crcu8, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x131 (or false false)))
(let (($x56 (not $x131)))
(and $x56 (or $x131 (and (distinct ((_ extract 7 0) in.01_16) ((_ extract 7 0) in.01_16)) true))))))
(check-sat)
; query 68: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x98 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x235 ((_ zero_extend 31) ?x98)))
(let ((?x378 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x874 ((_ zero_extend 31) ?x378)))
(let ((?x1008 (bvand ?x874 ?x235)))
(let ((?x32 (ite (and (distinct (_ bv0 32) ?x1008) true) (_ bv1 1) (_ bv0 1))))
(let ((?x717 ((_ zero_extend 63) ?x32)))
(let (($x131 (or false false)))
(let (($x1296 (or $x131 false false)))
(let (($x148 (or $x1296 false)))
(let (($x662 (or $x148 $x148 false)))
(let (($x1015 (or $x662 false false)))
(let (($x989 (or $x1015 false)))
(and (not $x989) (or $x989 (and (distinct ?x717 ?x717) true)))))))))))))))))
(check-sat)
; query 69: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x98 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x235 ((_ zero_extend 31) ?x98)))
(let ((?x378 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x874 ((_ zero_extend 31) ?x378)))
(let ((?x1008 (bvand ?x874 ?x235)))
(let ((?x32 (ite (and (distinct (_ bv0 32) ?x1008) true) (_ bv1 1) (_ bv0 1))))
(let (($x1031 (= (_ bv1 1) ?x32)))
(let ((?x254 (ite $x1031 (_ bv1 32) (_ bv0 32))))
(let (($x131 (or false false)))
(let (($x1296 (or $x131 false false)))
(let (($x148 (or $x1296 false)))
(let (($x662 (or $x148 $x148 false)))
(let (($x1015 (or $x662 false false)))
(let (($x171 (or $x1015 (ite $x1031 false false))))
(and (not $x171) (or $x171 (and (distinct ?x254 ?x254) true))))))))))))))))))
(check-sat)
; query 70: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x98 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x235 ((_ zero_extend 31) ?x98)))
(let ((?x378 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x874 ((_ zero_extend 31) ?x378)))
(let ((?x1008 (bvand ?x874 ?x235)))
(let ((?x32 (ite (and (distinct (_ bv0 32) ?x1008) true) (_ bv1 1) (_ bv0 1))))
(let (($x1031 (= (_ bv1 1) ?x32)))
(let ((?x254 (ite $x1031 (_ bv1 32) (_ bv0 32))))
(let ((?x216 ((_ extract 7 0) ?x254)))
(let (($x131 (or false false)))
(let (($x1296 (or $x131 false false)))
(let (($x148 (or $x1296 false)))
(let (($x662 (or $x148 $x148 false)))
(let (($x1015 (or $x662 false false)))
(let (($x171 (or $x1015 (ite $x1031 false false))))
(let (($x431 (or $x171 false)))
(and (not $x431) (or $x431 (and (distinct ?x216 ?x216) true))))))))))))))))))))
(check-sat)
; query 71: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x131 (or false false)))
(let (($x56 (not $x131)))
(and $x56 (or $x131 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 72: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x378 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x131 (or false false)))
(let (($x1296 (or $x131 false false)))
(let (($x128 (not $x1296)))
(and $x128 (or $x1296 (and (distinct ?x378 ?x378) true))))))))
(check-sat)
; query 73: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x378 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x874 ((_ zero_extend 31) ?x378)))
(let (($x131 (or false false)))
(let (($x1296 (or $x131 false false)))
(let (($x148 (or $x1296 false)))
(let (($x601 (not $x148)))
(and $x601 (or $x148 (and (distinct ?x874 ?x874) true))))))))))
(check-sat)
; query 74: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x131 (or false false)))
(let (($x56 (not $x131)))
(and $x56 (or $x131 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 75: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x98 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x131 (or false false)))
(let (($x1296 (or $x131 false false)))
(let (($x128 (not $x1296)))
(and $x128 (or $x1296 (and (distinct ?x98 ?x98) true))))))))
(check-sat)
; query 76: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x98 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x235 ((_ zero_extend 31) ?x98)))
(let (($x131 (or false false)))
(let (($x1296 (or $x131 false false)))
(let (($x148 (or $x1296 false)))
(let (($x601 (not $x148)))
(and $x601 (or $x148 (and (distinct ?x235 ?x235) true))))))))))
(check-sat)
; query 77: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x98 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x235 ((_ zero_extend 31) ?x98)))
(let ((?x378 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x874 ((_ zero_extend 31) ?x378)))
(let ((?x1008 (bvand ?x874 ?x235)))
(let (($x131 (or false false)))
(let (($x1296 (or $x131 false false)))
(let (($x148 (or $x1296 false)))
(let (($x662 (or $x148 $x148 false)))
(and (not $x662) (or $x662 (and (distinct ?x1008 ?x1008) true)))))))))))))
(check-sat)
; query 78: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x98 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x235 ((_ zero_extend 31) ?x98)))
(let ((?x378 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x874 ((_ zero_extend 31) ?x378)))
(let ((?x1008 (bvand ?x874 ?x235)))
(let ((?x32 (ite (and (distinct (_ bv0 32) ?x1008) true) (_ bv1 1) (_ bv0 1))))
(let (($x131 (or false false)))
(let (($x1296 (or $x131 false false)))
(let (($x148 (or $x1296 false)))
(let (($x662 (or $x148 $x148 false)))
(let (($x1015 (or $x662 false false)))
(and (not $x1015) (or $x1015 (and (distinct ?x32 ?x32) true)))))))))))))))
(check-sat)
; query 79: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x546 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x46 (or false false false)))
(let (($x732 (not $x46)))
(and $x732 (or $x46 (and (distinct ?x546 ?x546) true)))))))
(check-sat)
; query 80: function matrix_add_const, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x46 (or false false false)))
(let (($x732 (not $x46)))
(and $x732 (or $x46 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 81: function matrix_add_const, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x141 (bvadd in.01_32 (_ bv1 32))))
(let (($x107 (and (distinct ?x141 ?x141) true)))
(let (($x46 (or false false false)))
(let (($x732 (not $x46)))
(and $x732 (or $x46 $x107)))))))
(check-sat)
; query 82: function matrix_mul_const, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x46 (or false false false)))
(let (($x732 (not $x46)))
(and $x732 (or $x46 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 83: function matrix_mul_const, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x141 (bvadd in.01_32 (_ bv1 32))))
(let (($x107 (and (distinct ?x141 ?x141) true)))
(let (($x46 (or false false false)))
(let (($x732 (not $x46)))
(and $x732 (or $x46 $x107)))))))
(check-sat)
; query 84: function matrix_mul_matrix, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x46 (or false false false)))
(let (($x732 (not $x46)))
(and $x732 (or $x46 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 85: function matrix_mul_matrix, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x141 (bvadd in.01_32 (_ bv1 32))))
(let (($x107 (and (distinct ?x141 ?x141) true)))
(let (($x46 (or false false false)))
(let (($x732 (not $x46)))
(and $x732 (or $x46 $x107)))))))
(check-sat)
; query 86: function matrix_mul_matrix, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x46 (or false false false)))
(let (($x732 (not $x46)))
(and $x732 (or $x46 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 87: function matrix_mul_matrix_bitextract, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x46 (or false false false)))
(let (($x732 (not $x46)))
(and $x732 (or $x46 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 88: function matrix_mul_matrix_bitextract, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x141 (bvadd in.01_32 (_ bv1 32))))
(let (($x107 (and (distinct ?x141 ?x141) true)))
(let (($x46 (or false false false)))
(let (($x732 (not $x46)))
(and $x732 (or $x46 $x107)))))))
(check-sat)
; query 89: function matrix_mul_matrix_bitextract, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x46 (or false false false)))
(let (($x732 (not $x46)))
(and $x732 (or $x46 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 90: function matrix_mul_vect, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x46 (or false false false)))
(let (($x732 (not $x46)))
(and $x732 (or $x46 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 91: function matrix_mul_vect, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x141 (bvadd in.01_32 (_ bv1 32))))
(let (($x107 (and (distinct ?x141 ?x141) true)))
(let (($x46 (or false false false)))
(let (($x732 (not $x46)))
(and $x732 (or $x46 $x107)))))))
(check-sat)
; query 92: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x131 (or false false)))
(let (($x56 (not $x131)))
(and $x56 (or $x131 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 93: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x456 ((_ sign_extend 16) in.1_16)))
(let ((?x330 (bvadd ?x456 (_ bv10 32))))
(let (($x407 (and (distinct (bvadd ((_ sign_extend 1) ?x456) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x330)) true)))
(let (($x131 (or false false)))
(let (($x542 (or $x131 false (or $x407))))
(and (not $x542) (or $x542 (and (distinct ?x330 ?x330) true)))))))))
(check-sat)
; query 94: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x456 ((_ sign_extend 16) in.1_16)))
(let ((?x330 (bvadd ?x456 (_ bv10 32))))
(let ((?x1080 ((_ extract 15 0) ?x330)))
(let (($x407 (and (distinct (bvadd ((_ sign_extend 1) ?x456) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x330)) true)))
(let (($x131 (or false false)))
(let (($x542 (or $x131 false (or $x407))))
(let (($x448 (or $x542 false)))
(and (not $x448) (or $x448 (and (distinct ?x1080 ?x1080) true)))))))))))
(check-sat)
; query 95: function matrix_sum, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x265 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x46 (or false false false)))
(let (($x732 (not $x46)))
(and $x732 (or $x46 (and (distinct ?x265 ?x265) true)))))))
(check-sat)
; query 96: function matrix_sum, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x265 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let ((?x267 ((_ zero_extend 63) ?x265)))
(let (($x46 (or false false false)))
(let (($x115 (or $x46 false)))
(and (not $x115) (or $x115 (and (distinct ?x267 ?x267) true))))))))
(check-sat)
; query 97: function matrix_sum, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x265 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x355 (= (_ bv1 1) ?x265)))
(let ((?x222 (ite $x355 (_ bv1 32) (_ bv0 32))))
(let (($x46 (or false false false)))
(let (($x594 (or $x46 (ite $x355 false false))))
(and (not $x594) (or $x594 (and (distinct ?x222 ?x222) true)))))))))
(check-sat)
; query 98: function matrix_sum, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x131 (or false false)))
(let (($x56 (not $x131)))
(and $x56 (or $x131 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 99: function matrix_sum, block 22, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x265 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x355 (= (_ bv1 1) ?x265)))
(let ((?x222 (ite $x355 (_ bv1 32) (_ bv0 32))))
(let ((?x456 ((_ sign_extend 16) in.1_16)))
(let ((?x672 (bvadd ?x456 ?x222)))
(let (($x713 (and (distinct (bvadd ((_ sign_extend 1) ?x456) ((_ sign_extend 1) ?x222)) ((_ sign_extend 1) ?x672)) true)))
(let (($x46 (or false false false)))
(let (($x594 (or $x46 (ite $x355 false false))))
(let (($x131 (or false false)))
(let (($x327 (or $x131 $x594 (or $x713))))
(and (not $x327) (or $x327 (and (distinct ?x672 ?x672) true))))))))))))))
(check-sat)
; query 100: function matrix_sum, block 22, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x265 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x355 (= (_ bv1 1) ?x265)))
(let ((?x222 (ite $x355 (_ bv1 32) (_ bv0 32))))
(let ((?x456 ((_ sign_extend 16) in.1_16)))
(let ((?x672 (bvadd ?x456 ?x222)))
(let ((?x691 ((_ extract 15 0) ?x672)))
(let (($x713 (and (distinct (bvadd ((_ sign_extend 1) ?x456) ((_ sign_extend 1) ?x222)) ((_ sign_extend 1) ?x672)) true)))
(let (($x46 (or false false false)))
(let (($x594 (or $x46 (ite $x355 false false))))
(let (($x131 (or false false)))
(let (($x327 (or $x131 $x594 (or $x713))))
(let (($x516 (or $x327 false)))
(and (not $x516) (or $x516 (and (distinct ?x691 ?x691) true))))))))))))))))
(check-sat)
; query 101: function matrix_sum, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x46 (or false false false)))
(let (($x732 (not $x46)))
(and $x732 (or $x46 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 102: function matrix_sum, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x141 (bvadd in.01_32 (_ bv1 32))))
(let (($x107 (and (distinct ?x141 ?x141) true)))
(let (($x46 (or false false false)))
(let (($x732 (not $x46)))
(and $x732 (or $x46 $x107)))))))
(check-sat)
; query 103: function parseval, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.23_32 () (_ BitVec 32))
(assert
 (let (($x970 (and (distinct (bvmul ((_ sign_extend 32) in.23_32) ((_ sign_extend 32) (_ bv1024 32))) ((_ sign_extend 32) (bvmul in.23_32 (_ bv1024 32)))) true)))
(let (($x304 (or false false (or $x970))))
(and (not $x304) (or $x304 (and (distinct (bvmul in.23_32 (_ bv1024 32)) (bvmul in.23_32 (_ bv1024 32))) true))))))
(check-sat)
; query 104: function parseval, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.34_32 () (_ BitVec 32))
(assert
 (let (($x435 (and (distinct (bvmul ((_ sign_extend 32) in.34_32) ((_ sign_extend 32) (_ bv1048576 32))) ((_ sign_extend 32) (bvmul in.34_32 (_ bv1048576 32)))) true)))
(let (($x1364 (or false false (or $x435))))
(and (not $x1364) (or $x1364 (and (distinct (bvmul in.34_32 (_ bv1048576 32)) (bvmul in.34_32 (_ bv1048576 32))) true))))))
(check-sat)
; query 105: function partition_memory, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x46 (or false false false)))
(let (($x732 (not $x46)))
(and $x732 (or $x46 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
