; OptiPhase-Sigma refinement certificate for sweep K38-R3-293
; query 0: function BF_ofb64_encrypt, block 82, name %83
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x151 (ite (= (_ bv0 32) in.04_32) (_ bv1 1) (_ bv0 1))))
(let (($x531 (or false false false)))
(and (not $x531) (or $x531 (and (distinct ?x151 ?x151) true))))))
(check-sat)
