; OptiPhase-Sigma refinement certificate for sweep K59-R2-047
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x17 (or false false)))
(let (($x9747 (not $x17)))
(and $x9747 (or $x17 (and (distinct ((_ sign_extend 16) in25_16) ((_ sign_extend 16) in25_16)) true))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let ((?x11558 (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))))
(let (($x17 (or false false)))
(let (($x2628 (or $x17 false false)))
(let (($x9100 (not $x2628)))
(and $x9100 (or $x2628 (and (distinct ?x11558 ?x11558) true))))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x17 (or false false)))
(let (($x9747 (not $x17)))
(and $x9747 (or $x17 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x7376 ((_ sign_extend 16) in3_16)))
(let ((?x7476 (bvand ?x7376 (_ bv127 32))))
(let (($x17 (or false false)))
(let (($x2628 (or $x17 false false)))
(let (($x9100 (not $x2628)))
(and $x9100 (or $x2628 (and (distinct ?x7476 ?x7476) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x7376 ((_ sign_extend 16) in3_16)))
(let ((?x7476 (bvand ?x7376 (_ bv127 32))))
(let ((?x3367 ((_ extract 15 0) ?x7476)))
(let (($x17 (or false false)))
(let (($x2628 (or $x17 false false)))
(let (($x1415 (or $x2628 false)))
(let (($x600 (not $x1415)))
(and $x600 (or $x1415 (and (distinct ?x3367 ?x3367) true)))))))))))
(check-sat)
; query 5: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x17 (or false false)))
(let (($x9747 (not $x17)))
(and $x9747 (or $x17 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 6: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x623 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x17 (or false false)))
(let (($x2628 (or $x17 false false)))
(let (($x9100 (not $x2628)))
(and $x9100 (or $x2628 (and (distinct ?x623 ?x623) true))))))))
(check-sat)
; query 7: function core_bench_list, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x1814 (or false false false)))
(let (($x131 (not $x1814)))
(and $x131 (or $x1814 (and (distinct (bvadd in.0_16 (_ bv1 16)) (bvadd in.0_16 (_ bv1 16))) true))))))
(check-sat)
; query 8: function core_bench_list, block 82, name %83
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let (($x17 (or false false)))
(let (($x9747 (not $x17)))
(and $x9747 (or $x17 (and (distinct ((_ zero_extend 16) in.02_16) ((_ zero_extend 16) in.02_16)) true))))))
(check-sat)
; query 9: function core_bench_list, block 82, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x161 ((_ zero_extend 16) in.02_16)))
(let ((?x7972 (bvmul ?x161 (_ bv4 32))))
(let (($x64 (and (distinct (bvmul ((_ sign_extend 32) ?x161) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x7972)) true)))
(let (($x17 (or false false)))
(let (($x894 (or $x17 false (or $x64))))
(and (not $x894) (or $x894 (and (distinct ?x7972 ?x7972) true)))))))))
(check-sat)
; query 10: function core_bench_list, block 82, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let (($x17 (or false false)))
(let (($x9747 (not $x17)))
(and $x9747 (or $x17 (and (distinct ((_ zero_extend 16) in.04_16) ((_ zero_extend 16) in.04_16)) true))))))
(check-sat)
; query 11: function core_bench_list, block 82, name %86
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x1968 ((_ zero_extend 16) in.04_16)))
(let ((?x161 ((_ zero_extend 16) in.02_16)))
(let ((?x7972 (bvmul ?x161 (_ bv4 32))))
(let ((?x478 (bvsub ?x7972 ?x1968)))
(let ((?x1095 ((_ sign_extend 1) ?x478)))
(let (($x17 (or false false)))
(let (($x64 (and (distinct (bvmul ((_ sign_extend 32) ?x161) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x7972)) true)))
(let (($x894 (or $x17 false (or $x64))))
(let (($x115 (or $x894 $x17 (or (and (distinct (bvsub ((_ sign_extend 1) ?x7972) ((_ sign_extend 1) ?x1968)) ?x1095) true)))))
(and (not $x115) (or $x115 (and (distinct ?x478 ?x478) true)))))))))))))
(check-sat)
; query 12: function core_bench_list, block 82, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x17 (or false false)))
(let (($x9747 (not $x17)))
(and $x9747 (or $x17 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 13: function core_bench_list, block 82, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x1968 ((_ zero_extend 16) in.04_16)))
(let ((?x161 ((_ zero_extend 16) in.02_16)))
(let ((?x7972 (bvmul ?x161 (_ bv4 32))))
(let ((?x478 (bvsub ?x7972 ?x1968)))
(let ((?x1967 ((_ zero_extend 16) in.01_16)))
(let ((?x1462 (bvadd ?x1967 ?x478)))
(let (($x1052 (and (distinct (bvadd ((_ sign_extend 1) ?x1967) ((_ sign_extend 1) ?x478)) ((_ sign_extend 1) ?x1462)) true)))
(let ((?x1095 ((_ sign_extend 1) ?x478)))
(let (($x17 (or false false)))
(let (($x64 (and (distinct (bvmul ((_ sign_extend 32) ?x161) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x7972)) true)))
(let (($x894 (or $x17 false (or $x64))))
(let (($x115 (or $x894 $x17 (or (and (distinct (bvsub ((_ sign_extend 1) ?x7972) ((_ sign_extend 1) ?x1968)) ?x1095) true)))))
(let (($x167 (or $x17 $x115 (or $x1052))))
(and (not $x167) (or $x167 (and (distinct ?x1462 ?x1462) true)))))))))))))))))
(check-sat)
; query 14: function core_bench_list, block 82, name %89
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x1968 ((_ zero_extend 16) in.04_16)))
(let ((?x161 ((_ zero_extend 16) in.02_16)))
(let ((?x7972 (bvmul ?x161 (_ bv4 32))))
(let ((?x478 (bvsub ?x7972 ?x1968)))
(let ((?x1967 ((_ zero_extend 16) in.01_16)))
(let ((?x1462 (bvadd ?x1967 ?x478)))
(let ((?x320 ((_ extract 15 0) ?x1462)))
(let (($x1052 (and (distinct (bvadd ((_ sign_extend 1) ?x1967) ((_ sign_extend 1) ?x478)) ((_ sign_extend 1) ?x1462)) true)))
(let ((?x1095 ((_ sign_extend 1) ?x478)))
(let (($x17 (or false false)))
(let (($x64 (and (distinct (bvmul ((_ sign_extend 32) ?x161) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x7972)) true)))
(let (($x894 (or $x17 false (or $x64))))
(let (($x115 (or $x894 $x17 (or (and (distinct (bvsub ((_ sign_extend 1) ?x7972) ((_ sign_extend 1) ?x1968)) ?x1095) true)))))
(let (($x167 (or $x17 $x115 (or $x1052))))
(let (($x100 (or $x167 false)))
(and (not $x100) (or $x100 (and (distinct ?x320 ?x320) true)))))))))))))))))))
(check-sat)
; query 15: function core_bench_list, block 82, name %90
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x17 (or false false)))
(let (($x9747 (not $x17)))
(and $x9747 (or $x17 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 16: function core_bench_list, block 82, name %91
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x249 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x17 (or false false)))
(let (($x2628 (or $x17 false false)))
(let (($x9100 (not $x2628)))
(and $x9100 (or $x2628 (and (distinct ?x249 ?x249) true))))))))
(check-sat)
; query 17: function core_bench_state, block 105, name %106
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x1814 (or false false false)))
(let (($x131 (not $x1814)))
(and $x131 (or $x1814 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 18: function core_bench_state, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1814 (or false false false)))
(let (($x131 (not $x1814)))
(and $x131 (or $x1814 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 19: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x229 (bvadd in.01_32 (_ bv1 32))))
(let (($x3821 (and (distinct ?x229 ?x229) true)))
(let (($x1814 (or false false false)))
(let (($x131 (not $x1814)))
(and $x131 (or $x1814 $x3821)))))))
(check-sat)
; query 20: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x229 (bvadd in.01_32 (_ bv1 32))))
(let ((?x3380 (bvmul ?x229 ?x229)))
(let (($x1814 (or false false false)))
(let (($x372 (or $x1814 $x1814 false)))
(and (not $x372) (or $x372 (and (distinct ?x3380 ?x3380) true))))))))
(check-sat)
; query 21: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x229 (bvadd in.01_32 (_ bv1 32))))
(let ((?x3380 (bvmul ?x229 ?x229)))
(let ((?x4204 (bvmul ?x3380 (_ bv2 32))))
(let (($x1814 (or false false false)))
(let (($x372 (or $x1814 $x1814 false)))
(let (($x179 (or $x372 false false)))
(and (not $x179) (or $x179 (and (distinct ?x4204 ?x4204) true))))))))))
(check-sat)
; query 22: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x229 (bvadd in.01_32 (_ bv1 32))))
(let ((?x3380 (bvmul ?x229 ?x229)))
(let ((?x4204 (bvmul ?x3380 (_ bv2 32))))
(let ((?x127 (bvmul ?x4204 (_ bv4 32))))
(let (($x1814 (or false false false)))
(let (($x372 (or $x1814 $x1814 false)))
(let (($x179 (or $x372 false false)))
(let (($x89 (or $x179 false false)))
(and (not $x89) (or $x89 (and (distinct ?x127 ?x127) true))))))))))))
(check-sat)
; query 23: function core_init_matrix, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x1814 (or false false false)))
(let (($x131 (not $x1814)))
(and $x131 (or $x1814 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 24: function core_init_matrix, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x1814 (or false false false)))
(let (($x131 (not $x1814)))
(and $x131 (or $x1814 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 25: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x5496 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x1814 (or false false false)))
(let (($x131 (not $x1814)))
(and $x131 (or $x1814 (and (distinct ?x5496 ?x5496) true)))))))
(check-sat)
; query 26: function core_init_state, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_32 () (_ BitVec 32))
(assert
 (let (($x1814 (or false false false)))
(let (($x131 (not $x1814)))
(and $x131 (or $x1814 (and (distinct (bvadd in.06_32 (_ bv1 32)) (bvadd in.06_32 (_ bv1 32))) true))))))
(check-sat)
; query 27: function core_init_state, block 65, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let (($x1814 (or false false false)))
(let (($x131 (not $x1814)))
(and $x131 (or $x1814 (and (distinct (bvadd in4_32 (_ bv1 32)) (bvadd in4_32 (_ bv1 32))) true))))))
(check-sat)
; query 28: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x90 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x1814 (or false false false)))
(let (($x131 (not $x1814)))
(and $x131 (or $x1814 (and (distinct ?x90 ?x90) true)))))))
(check-sat)
; query 29: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x1814 (or false false false)))
(let (($x131 (not $x1814)))
(and $x131 (or $x1814 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 30: function core_list_init, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x229 (bvadd in.01_32 (_ bv1 32))))
(let (($x3821 (and (distinct ?x229 ?x229) true)))
(let (($x1814 (or false false false)))
(let (($x131 (not $x1814)))
(and $x131 (or $x1814 $x3821)))))))
(check-sat)
; query 31: function core_list_mergesort, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x229 (bvadd in.01_32 (_ bv1 32))))
(let (($x3821 (and (distinct ?x229 ?x229) true)))
(let (($x135 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x229)) true)))
(let (($x3953 (or false false (or $x135))))
(and (not $x3953) (or $x3953 $x3821)))))))
(check-sat)
; query 32: function core_list_mergesort, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x4136 (ite (bvslt (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x1814 (or false false false)))
(let (($x131 (not $x1814)))
(and $x131 (or $x1814 (and (distinct ?x4136 ?x4136) true)))))))
(check-sat)
; query 33: function core_list_mergesort, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.224_32 () (_ BitVec 32))
(assert
 (let ((?x6677 (ite (= (_ bv0 32) in.224_32) (_ bv1 1) (_ bv0 1))))
(let (($x1814 (or false false false)))
(let (($x131 (not $x1814)))
(and $x131 (or $x1814 (and (distinct ?x6677 ?x6677) true)))))))
(check-sat)
; query 34: function core_list_mergesort, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x4983 (ite (= (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x1814 (or false false false)))
(let (($x131 (not $x1814)))
(and $x131 (or $x1814 (and (distinct ?x4983 ?x4983) true)))))))
(check-sat)
; query 35: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x139 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x8182 (or false false (or $x139))))
(and (not $x8182) (or $x8182 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 36: function core_list_mergesort, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x2217 (and (distinct (bvmul ((_ sign_extend 32) in.020_32) ((_ sign_extend 32) (_ bv2 32))) ((_ sign_extend 32) (bvmul in.020_32 (_ bv2 32)))) true)))
(let (($x5162 (or false false (or $x2217))))
(and (not $x5162) (or $x5162 (and (distinct (bvmul in.020_32 (_ bv2 32)) (bvmul in.020_32 (_ bv2 32))) true))))))
(check-sat)
; query 37: function core_state_transition, block 102, name %103
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x17 (or false false)))
(let (($x9747 (not $x17)))
(and $x9747 (or $x17 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 38: function core_state_transition, block 102, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x7743 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x17 (or false false)))
(let (($x2628 (or $x17 false false)))
(let (($x9100 (not $x2628)))
(and $x9100 (or $x2628 (and (distinct ?x7743 ?x7743) true))))))))
(check-sat)
; query 39: function core_state_transition, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x17 (or false false)))
(let (($x9747 (not $x17)))
(and $x9747 (or $x17 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 40: function core_state_transition, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x6815 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x17 (or false false)))
(let (($x2628 (or $x17 false false)))
(let (($x9100 (not $x2628)))
(and $x9100 (or $x2628 (and (distinct ?x6815 ?x6815) true))))))))
(check-sat)
; query 41: function core_state_transition, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x17 (or false false)))
(let (($x9747 (not $x17)))
(and $x9747 (or $x17 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 42: function core_state_transition, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x7743 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x17 (or false false)))
(let (($x2628 (or $x17 false false)))
(let (($x9100 (not $x2628)))
(and $x9100 (or $x2628 (and (distinct ?x7743 ?x7743) true))))))))
(check-sat)
; query 43: function core_state_transition, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x17 (or false false)))
(let (($x9747 (not $x17)))
(and $x9747 (or $x17 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 44: function core_state_transition, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x5033 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x17 (or false false)))
(let (($x2628 (or $x17 false false)))
(let (($x9100 (not $x2628)))
(and $x9100 (or $x2628 (and (distinct ?x5033 ?x5033) true))))))))
(check-sat)
; query 45: function core_state_transition, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x17 (or false false)))
(let (($x9747 (not $x17)))
(and $x9747 (or $x17 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 46: function core_state_transition, block 51, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x5033 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x17 (or false false)))
(let (($x2628 (or $x17 false false)))
(let (($x9100 (not $x2628)))
(and $x9100 (or $x2628 (and (distinct ?x5033 ?x5033) true))))))))
(check-sat)
; query 47: function core_state_transition, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x17 (or false false)))
(let (($x9747 (not $x17)))
(and $x9747 (or $x17 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 48: function core_state_transition, block 64, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x5033 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x17 (or false false)))
(let (($x2628 (or $x17 false false)))
(let (($x9100 (not $x2628)))
(and $x9100 (or $x2628 (and (distinct ?x5033 ?x5033) true))))))))
(check-sat)
; query 49: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x5298 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x1814 (or false false false)))
(let (($x131 (not $x1814)))
(and $x131 (or $x1814 (and (distinct ?x5298 ?x5298) true)))))))
(check-sat)
; query 50: function core_state_transition, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x17 (or false false)))
(let (($x9747 (not $x17)))
(and $x9747 (or $x17 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 51: function core_state_transition, block 80, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x11830 (ite (= (_ bv69 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x17 (or false false)))
(let (($x2628 (or $x17 false false)))
(let (($x9100 (not $x2628)))
(and $x9100 (or $x2628 (and (distinct ?x11830 ?x11830) true))))))))
(check-sat)
; query 52: function core_state_transition, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x17 (or false false)))
(let (($x9747 (not $x17)))
(and $x9747 (or $x17 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 53: function core_state_transition, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x11967 (ite (= (_ bv101 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x17 (or false false)))
(let (($x2628 (or $x17 false false)))
(let (($x9100 (not $x2628)))
(and $x9100 (or $x2628 (and (distinct ?x11967 ?x11967) true))))))))
(check-sat)
; query 54: function core_state_transition, block 99, name %100
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x17 (or false false)))
(let (($x9747 (not $x17)))
(and $x9747 (or $x17 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 55: function core_state_transition, block 99, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x6815 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x17 (or false false)))
(let (($x2628 (or $x17 false false)))
(let (($x9100 (not $x2628)))
(and $x9100 (or $x2628 (and (distinct ?x6815 ?x6815) true))))))))
(check-sat)
; query 56: function crcu8, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x17 (or false false)))
(let (($x9747 (not $x17)))
(and $x9747 (or $x17 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 57: function crcu8, block 19, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x1967 ((_ zero_extend 16) in.01_16)))
(let ((?x6332 (bvxor ?x1967 (_ bv16386 32))))
(let (($x17 (or false false)))
(let (($x2628 (or $x17 false false)))
(let (($x9100 (not $x2628)))
(and $x9100 (or $x2628 (and (distinct ?x6332 ?x6332) true)))))))))
(check-sat)
; query 58: function crcu8, block 19, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x1967 ((_ zero_extend 16) in.01_16)))
(let ((?x6332 (bvxor ?x1967 (_ bv16386 32))))
(let ((?x2457 ((_ extract 15 0) ?x6332)))
(let (($x17 (or false false)))
(let (($x2628 (or $x17 false false)))
(let (($x1415 (or $x2628 false)))
(let (($x600 (not $x1415)))
(and $x600 (or $x1415 (and (distinct ?x2457 ?x2457) true)))))))))))
(check-sat)
; query 59: function crcu8, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x17 (or false false)))
(let (($x9747 (not $x17)))
(and $x9747 (or $x17 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 60: function crcu8, block 29, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x5436 ((_ zero_extend 16) in27_16)))
(let ((?x5471 (bvor ?x5436 (_ bv32768 32))))
(let (($x17 (or false false)))
(let (($x2628 (or $x17 false false)))
(let (($x9100 (not $x2628)))
(and $x9100 (or $x2628 (and (distinct ?x5471 ?x5471) true)))))))))
(check-sat)
; query 61: function crcu8, block 29, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x5436 ((_ zero_extend 16) in27_16)))
(let ((?x5471 (bvor ?x5436 (_ bv32768 32))))
(let ((?x5409 ((_ extract 15 0) ?x5471)))
(let (($x17 (or false false)))
(let (($x2628 (or $x17 false false)))
(let (($x1415 (or $x2628 false)))
(let (($x600 (not $x1415)))
(and $x600 (or $x1415 (and (distinct ?x5409 ?x5409) true)))))))))))
(check-sat)
; query 62: function crcu8, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x17 (or false false)))
(let (($x9747 (not $x17)))
(and $x9747 (or $x17 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 63: function crcu8, block 33, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x5436 ((_ zero_extend 16) in27_16)))
(let ((?x3585 (bvand ?x5436 (_ bv32767 32))))
(let (($x17 (or false false)))
(let (($x2628 (or $x17 false false)))
(let (($x9100 (not $x2628)))
(and $x9100 (or $x2628 (and (distinct ?x3585 ?x3585) true)))))))))
(check-sat)
; query 64: function crcu8, block 33, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x5436 ((_ zero_extend 16) in27_16)))
(let ((?x3585 (bvand ?x5436 (_ bv32767 32))))
(let ((?x8476 ((_ extract 15 0) ?x3585)))
(let (($x17 (or false false)))
(let (($x2628 (or $x17 false false)))
(let (($x1415 (or $x2628 false)))
(let (($x600 (not $x1415)))
(and $x600 (or $x1415 (and (distinct ?x8476 ?x8476) true)))))))))))
(check-sat)
; query 65: function crcu8, block 38, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_8 () (_ BitVec 8))
(assert
 (let (($x1814 (or false false false)))
(let (($x131 (not $x1814)))
(and $x131 (or $x1814 (and (distinct (bvadd in.02_8 (_ bv1 8)) (bvadd in.02_8 (_ bv1 8))) true))))))
(check-sat)
; query 66: function crcu8, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x7233 ((_ extract 7 0) in.01_16)))
(let ((?x9888 ((_ zero_extend 24) ?x7233)))
(let (($x17 (or false false)))
(let (($x5145 (or $x17 false)))
(and (not $x5145) (or $x5145 (and (distinct ?x9888 ?x9888) true))))))))
(check-sat)
; query 67: function crcu8, block 6, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x7233 ((_ extract 7 0) in.01_16)))
(let ((?x9888 ((_ zero_extend 24) ?x7233)))
(let ((?x11422 (bvand ?x9888 (_ bv1 32))))
(let (($x17 (or false false)))
(let (($x5145 (or $x17 false)))
(let (($x1808 (or $x5145 false false)))
(and (not $x1808) (or $x1808 (and (distinct ?x11422 ?x11422) true))))))))))
(check-sat)
; query 68: function crcu8, block 6, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x7233 ((_ extract 7 0) in.01_16)))
(let ((?x9888 ((_ zero_extend 24) ?x7233)))
(let ((?x11422 (bvand ?x9888 (_ bv1 32))))
(let ((?x6622 ((_ zero_extend 24) in.0_8)))
(let ((?x12361 (bvand ?x6622 (_ bv1 32))))
(let ((?x11423 (bvxor ?x12361 ?x11422)))
(let (($x17 (or false false)))
(let (($x5145 (or $x17 false)))
(let (($x1808 (or $x5145 false false)))
(let (($x2628 (or $x17 false false)))
(let (($x8373 (or $x2628 $x1808 false)))
(and (not $x8373) (or $x8373 (and (distinct ?x11423 ?x11423) true)))))))))))))))
(check-sat)
; query 69: function crcu8, block 6, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x7233 ((_ extract 7 0) in.01_16)))
(let ((?x9888 ((_ zero_extend 24) ?x7233)))
(let ((?x11422 (bvand ?x9888 (_ bv1 32))))
(let ((?x6622 ((_ zero_extend 24) in.0_8)))
(let ((?x12361 (bvand ?x6622 (_ bv1 32))))
(let ((?x11423 (bvxor ?x12361 ?x11422)))
(let ((?x9821 ((_ extract 7 0) ?x11423)))
(let (($x17 (or false false)))
(let (($x5145 (or $x17 false)))
(let (($x1808 (or $x5145 false false)))
(let (($x2628 (or $x17 false false)))
(let (($x8373 (or $x2628 $x1808 false)))
(let (($x3100 (or $x8373 false)))
(and (not $x3100) (or $x3100 (and (distinct ?x9821 ?x9821) true)))))))))))))))))
(check-sat)
; query 70: function crcu8, block 6, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x17 (or false false)))
(let (($x9747 (not $x17)))
(and $x9747 (or $x17 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 71: function crcu8, block 6, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x6622 ((_ zero_extend 24) in.0_8)))
(let ((?x4666 (bvashr ?x6622 (_ bv1 32))))
(let (($x17 (or false false)))
(let (($x2628 (or $x17 false false)))
(let (($x6471 (or $x2628 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not $x6471) (or $x6471 (and (distinct ?x4666 ?x4666) true)))))))))
(check-sat)
; query 72: function crcu8, block 6, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x6622 ((_ zero_extend 24) in.0_8)))
(let ((?x4666 (bvashr ?x6622 (_ bv1 32))))
(let ((?x7722 ((_ extract 7 0) ?x4666)))
(let (($x17 (or false false)))
(let (($x2628 (or $x17 false false)))
(let (($x6471 (or $x2628 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x8606 (or $x6471 false)))
(and (not $x8606) (or $x8606 (and (distinct ?x7722 ?x7722) true)))))))))))
(check-sat)
; query 73: function crcu8, block 6, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x7233 ((_ extract 7 0) in.01_16)))
(let ((?x9888 ((_ zero_extend 24) ?x7233)))
(let ((?x11422 (bvand ?x9888 (_ bv1 32))))
(let ((?x6622 ((_ zero_extend 24) in.0_8)))
(let ((?x12361 (bvand ?x6622 (_ bv1 32))))
(let ((?x11423 (bvxor ?x12361 ?x11422)))
(let ((?x9821 ((_ extract 7 0) ?x11423)))
(let ((?x1767 ((_ zero_extend 24) ?x9821)))
(let (($x17 (or false false)))
(let (($x5145 (or $x17 false)))
(let (($x1808 (or $x5145 false false)))
(let (($x2628 (or $x17 false false)))
(let (($x8373 (or $x2628 $x1808 false)))
(let (($x3100 (or $x8373 false)))
(let (($x4397 (or $x3100 false)))
(and (not $x4397) (or $x4397 (and (distinct ?x1767 ?x1767) true)))))))))))))))))))
(check-sat)
; query 74: function crcu8, block 6, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x7233 ((_ extract 7 0) in.01_16)))
(let ((?x9888 ((_ zero_extend 24) ?x7233)))
(let ((?x11422 (bvand ?x9888 (_ bv1 32))))
(let ((?x6622 ((_ zero_extend 24) in.0_8)))
(let ((?x12361 (bvand ?x6622 (_ bv1 32))))
(let ((?x11423 (bvxor ?x12361 ?x11422)))
(let ((?x9821 ((_ extract 7 0) ?x11423)))
(let ((?x1767 ((_ zero_extend 24) ?x9821)))
(let ((?x8820 (ite (= (_ bv1 32) ?x1767) (_ bv1 1) (_ bv0 1))))
(let (($x17 (or false false)))
(let (($x5145 (or $x17 false)))
(let (($x1808 (or $x5145 false false)))
(let (($x2628 (or $x17 false false)))
(let (($x8373 (or $x2628 $x1808 false)))
(let (($x3100 (or $x8373 false)))
(let (($x4397 (or $x3100 false)))
(let (($x9162 (or $x4397 false false)))
(and (not $x9162) (or $x9162 (and (distinct ?x8820 ?x8820) true)))))))))))))))))))))
(check-sat)
; query 75: function crcu8, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x17 (or false false)))
(let (($x9747 (not $x17)))
(and $x9747 (or $x17 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 76: function crcu8, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x6622 ((_ zero_extend 24) in.0_8)))
(let ((?x12361 (bvand ?x6622 (_ bv1 32))))
(let (($x17 (or false false)))
(let (($x2628 (or $x17 false false)))
(let (($x9100 (not $x2628)))
(and $x9100 (or $x2628 (and (distinct ?x12361 ?x12361) true)))))))))
(check-sat)
; query 77: function crcu8, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x17 (or false false)))
(let (($x9747 (not $x17)))
(and $x9747 (or $x17 (and (distinct ((_ extract 7 0) in.01_16) ((_ extract 7 0) in.01_16)) true))))))
(check-sat)
; query 78: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x9365 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1256 ((_ zero_extend 31) ?x9365)))
(let ((?x12362 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x11732 ((_ zero_extend 31) ?x12362)))
(let ((?x3315 (bvand ?x11732 ?x1256)))
(let ((?x3830 (ite (and (distinct (_ bv0 32) ?x3315) true) (_ bv1 1) (_ bv0 1))))
(let ((?x10077 ((_ zero_extend 63) ?x3830)))
(let (($x17 (or false false)))
(let (($x2628 (or $x17 false false)))
(let (($x1415 (or $x2628 false)))
(let (($x3781 (or $x1415 $x1415 false)))
(let (($x3613 (or $x3781 false false)))
(let (($x6863 (or $x3613 false)))
(and (not $x6863) (or $x6863 (and (distinct ?x10077 ?x10077) true)))))))))))))))))
(check-sat)
; query 79: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x9365 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1256 ((_ zero_extend 31) ?x9365)))
(let ((?x12362 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x11732 ((_ zero_extend 31) ?x12362)))
(let ((?x3315 (bvand ?x11732 ?x1256)))
(let ((?x3830 (ite (and (distinct (_ bv0 32) ?x3315) true) (_ bv1 1) (_ bv0 1))))
(let (($x2948 (= (_ bv1 1) ?x3830)))
(let ((?x6297 (ite $x2948 (_ bv1 32) (_ bv0 32))))
(let (($x17 (or false false)))
(let (($x2628 (or $x17 false false)))
(let (($x1415 (or $x2628 false)))
(let (($x3781 (or $x1415 $x1415 false)))
(let (($x3613 (or $x3781 false false)))
(let (($x5285 (or $x3613 (ite $x2948 false false))))
(and (not $x5285) (or $x5285 (and (distinct ?x6297 ?x6297) true))))))))))))))))))
(check-sat)
; query 80: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x9365 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1256 ((_ zero_extend 31) ?x9365)))
(let ((?x12362 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x11732 ((_ zero_extend 31) ?x12362)))
(let ((?x3315 (bvand ?x11732 ?x1256)))
(let ((?x3830 (ite (and (distinct (_ bv0 32) ?x3315) true) (_ bv1 1) (_ bv0 1))))
(let (($x2948 (= (_ bv1 1) ?x3830)))
(let ((?x6297 (ite $x2948 (_ bv1 32) (_ bv0 32))))
(let ((?x7021 ((_ extract 7 0) ?x6297)))
(let (($x17 (or false false)))
(let (($x2628 (or $x17 false false)))
(let (($x1415 (or $x2628 false)))
(let (($x3781 (or $x1415 $x1415 false)))
(let (($x3613 (or $x3781 false false)))
(let (($x5285 (or $x3613 (ite $x2948 false false))))
(let (($x4083 (or $x5285 false)))
(and (not $x4083) (or $x4083 (and (distinct ?x7021 ?x7021) true))))))))))))))))))))
(check-sat)
; query 81: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x17 (or false false)))
(let (($x9747 (not $x17)))
(and $x9747 (or $x17 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 82: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x12362 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x17 (or false false)))
(let (($x2628 (or $x17 false false)))
(let (($x9100 (not $x2628)))
(and $x9100 (or $x2628 (and (distinct ?x12362 ?x12362) true))))))))
(check-sat)
; query 83: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x12362 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x11732 ((_ zero_extend 31) ?x12362)))
(let (($x17 (or false false)))
(let (($x2628 (or $x17 false false)))
(let (($x1415 (or $x2628 false)))
(let (($x600 (not $x1415)))
(and $x600 (or $x1415 (and (distinct ?x11732 ?x11732) true))))))))))
(check-sat)
; query 84: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x17 (or false false)))
(let (($x9747 (not $x17)))
(and $x9747 (or $x17 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 85: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x9365 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x17 (or false false)))
(let (($x2628 (or $x17 false false)))
(let (($x9100 (not $x2628)))
(and $x9100 (or $x2628 (and (distinct ?x9365 ?x9365) true))))))))
(check-sat)
; query 86: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x9365 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1256 ((_ zero_extend 31) ?x9365)))
(let (($x17 (or false false)))
(let (($x2628 (or $x17 false false)))
(let (($x1415 (or $x2628 false)))
(let (($x600 (not $x1415)))
(and $x600 (or $x1415 (and (distinct ?x1256 ?x1256) true))))))))))
(check-sat)
; query 87: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x9365 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1256 ((_ zero_extend 31) ?x9365)))
(let ((?x12362 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x11732 ((_ zero_extend 31) ?x12362)))
(let ((?x3315 (bvand ?x11732 ?x1256)))
(let (($x17 (or false false)))
(let (($x2628 (or $x17 false false)))
(let (($x1415 (or $x2628 false)))
(let (($x3781 (or $x1415 $x1415 false)))
(and (not $x3781) (or $x3781 (and (distinct ?x3315 ?x3315) true)))))))))))))
(check-sat)
; query 88: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x9365 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1256 ((_ zero_extend 31) ?x9365)))
(let ((?x12362 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x11732 ((_ zero_extend 31) ?x12362)))
(let ((?x3315 (bvand ?x11732 ?x1256)))
(let ((?x3830 (ite (and (distinct (_ bv0 32) ?x3315) true) (_ bv1 1) (_ bv0 1))))
(let (($x17 (or false false)))
(let (($x2628 (or $x17 false false)))
(let (($x1415 (or $x2628 false)))
(let (($x3781 (or $x1415 $x1415 false)))
(let (($x3613 (or $x3781 false false)))
(and (not $x3613) (or $x3613 (and (distinct ?x3830 ?x3830) true)))))))))))))))
(check-sat)
; query 89: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x11031 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x1814 (or false false false)))
(let (($x131 (not $x1814)))
(and $x131 (or $x1814 (and (distinct ?x11031 ?x11031) true)))))))
(check-sat)
; query 90: function matrix_add_const, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1814 (or false false false)))
(let (($x131 (not $x1814)))
(and $x131 (or $x1814 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 91: function matrix_add_const, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x229 (bvadd in.01_32 (_ bv1 32))))
(let (($x3821 (and (distinct ?x229 ?x229) true)))
(let (($x1814 (or false false false)))
(let (($x131 (not $x1814)))
(and $x131 (or $x1814 $x3821)))))))
(check-sat)
; query 92: function matrix_mul_const, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1814 (or false false false)))
(let (($x131 (not $x1814)))
(and $x131 (or $x1814 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 93: function matrix_mul_const, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x229 (bvadd in.01_32 (_ bv1 32))))
(let (($x3821 (and (distinct ?x229 ?x229) true)))
(let (($x1814 (or false false false)))
(let (($x131 (not $x1814)))
(and $x131 (or $x1814 $x3821)))))))
(check-sat)
; query 94: function matrix_mul_matrix, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1814 (or false false false)))
(let (($x131 (not $x1814)))
(and $x131 (or $x1814 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 95: function matrix_mul_matrix, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x229 (bvadd in.01_32 (_ bv1 32))))
(let (($x3821 (and (distinct ?x229 ?x229) true)))
(let (($x1814 (or false false false)))
(let (($x131 (not $x1814)))
(and $x131 (or $x1814 $x3821)))))))
(check-sat)
; query 96: function matrix_mul_matrix, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x1814 (or false false false)))
(let (($x131 (not $x1814)))
(and $x131 (or $x1814 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 97: function matrix_mul_matrix_bitextract, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1814 (or false false false)))
(let (($x131 (not $x1814)))
(and $x131 (or $x1814 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 98: function matrix_mul_matrix_bitextract, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x229 (bvadd in.01_32 (_ bv1 32))))
(let (($x3821 (and (distinct ?x229 ?x229) true)))
(let (($x1814 (or false false false)))
(let (($x131 (not $x1814)))
(and $x131 (or $x1814 $x3821)))))))
(check-sat)
; query 99: function matrix_mul_matrix_bitextract, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x1814 (or false false false)))
(let (($x131 (not $x1814)))
(and $x131 (or $x1814 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 100: function matrix_mul_vect, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1814 (or false false false)))
(let (($x131 (not $x1814)))
(and $x131 (or $x1814 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 101: function matrix_mul_vect, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x229 (bvadd in.01_32 (_ bv1 32))))
(let (($x3821 (and (distinct ?x229 ?x229) true)))
(let (($x1814 (or false false false)))
(let (($x131 (not $x1814)))
(and $x131 (or $x1814 $x3821)))))))
(check-sat)
; query 102: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x17 (or false false)))
(let (($x9747 (not $x17)))
(and $x9747 (or $x17 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 103: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x4593 ((_ sign_extend 16) in.1_16)))
(let ((?x7816 (bvadd ?x4593 (_ bv10 32))))
(let (($x3099 (and (distinct (bvadd ((_ sign_extend 1) ?x4593) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x7816)) true)))
(let (($x17 (or false false)))
(let (($x12082 (or $x17 false (or $x3099))))
(and (not $x12082) (or $x12082 (and (distinct ?x7816 ?x7816) true)))))))))
(check-sat)
; query 104: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x4593 ((_ sign_extend 16) in.1_16)))
(let ((?x7816 (bvadd ?x4593 (_ bv10 32))))
(let ((?x11898 ((_ extract 15 0) ?x7816)))
(let (($x3099 (and (distinct (bvadd ((_ sign_extend 1) ?x4593) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x7816)) true)))
(let (($x17 (or false false)))
(let (($x12082 (or $x17 false (or $x3099))))
(let (($x12113 (or $x12082 false)))
(and (not $x12113) (or $x12113 (and (distinct ?x11898 ?x11898) true)))))))))))
(check-sat)
; query 105: function matrix_sum, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x12131 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x1814 (or false false false)))
(let (($x131 (not $x1814)))
(and $x131 (or $x1814 (and (distinct ?x12131 ?x12131) true)))))))
(check-sat)
; query 106: function matrix_sum, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x12131 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let ((?x7973 ((_ zero_extend 63) ?x12131)))
(let (($x1814 (or false false false)))
(let (($x2735 (or $x1814 false)))
(and (not $x2735) (or $x2735 (and (distinct ?x7973 ?x7973) true))))))))
(check-sat)
; query 107: function matrix_sum, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x12131 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x159 (= (_ bv1 1) ?x12131)))
(let ((?x7553 (ite $x159 (_ bv1 32) (_ bv0 32))))
(let (($x1814 (or false false false)))
(let (($x8875 (or $x1814 (ite $x159 false false))))
(and (not $x8875) (or $x8875 (and (distinct ?x7553 ?x7553) true)))))))))
(check-sat)
; query 108: function matrix_sum, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x17 (or false false)))
(let (($x9747 (not $x17)))
(and $x9747 (or $x17 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 109: function matrix_sum, block 22, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x12131 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x159 (= (_ bv1 1) ?x12131)))
(let ((?x7553 (ite $x159 (_ bv1 32) (_ bv0 32))))
(let ((?x4593 ((_ sign_extend 16) in.1_16)))
(let ((?x11843 (bvadd ?x4593 ?x7553)))
(let (($x10073 (and (distinct (bvadd ((_ sign_extend 1) ?x4593) ((_ sign_extend 1) ?x7553)) ((_ sign_extend 1) ?x11843)) true)))
(let (($x1814 (or false false false)))
(let (($x8875 (or $x1814 (ite $x159 false false))))
(let (($x17 (or false false)))
(let (($x7429 (or $x17 $x8875 (or $x10073))))
(and (not $x7429) (or $x7429 (and (distinct ?x11843 ?x11843) true))))))))))))))
(check-sat)
; query 110: function matrix_sum, block 22, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x12131 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x159 (= (_ bv1 1) ?x12131)))
(let ((?x7553 (ite $x159 (_ bv1 32) (_ bv0 32))))
(let ((?x4593 ((_ sign_extend 16) in.1_16)))
(let ((?x11843 (bvadd ?x4593 ?x7553)))
(let ((?x11671 ((_ extract 15 0) ?x11843)))
(let (($x10073 (and (distinct (bvadd ((_ sign_extend 1) ?x4593) ((_ sign_extend 1) ?x7553)) ((_ sign_extend 1) ?x11843)) true)))
(let (($x1814 (or false false false)))
(let (($x8875 (or $x1814 (ite $x159 false false))))
(let (($x17 (or false false)))
(let (($x7429 (or $x17 $x8875 (or $x10073))))
(let (($x3239 (or $x7429 false)))
(and (not $x3239) (or $x3239 (and (distinct ?x11671 ?x11671) true))))))))))))))))
(check-sat)
; query 111: function matrix_sum, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1814 (or false false false)))
(let (($x131 (not $x1814)))
(and $x131 (or $x1814 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 112: function matrix_sum, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x229 (bvadd in.01_32 (_ bv1 32))))
(let (($x3821 (and (distinct ?x229 ?x229) true)))
(let (($x1814 (or false false false)))
(let (($x131 (not $x1814)))
(and $x131 (or $x1814 $x3821)))))))
(check-sat)
; query 113: function parseval, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.23_32 () (_ BitVec 32))
(assert
 (let (($x6847 (and (distinct (bvmul ((_ sign_extend 32) in.23_32) ((_ sign_extend 32) (_ bv1024 32))) ((_ sign_extend 32) (bvmul in.23_32 (_ bv1024 32)))) true)))
(let (($x7801 (or false false (or $x6847))))
(and (not $x7801) (or $x7801 (and (distinct (bvmul in.23_32 (_ bv1024 32)) (bvmul in.23_32 (_ bv1024 32))) true))))))
(check-sat)
; query 114: function parseval, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.34_32 () (_ BitVec 32))
(assert
 (let (($x4431 (and (distinct (bvmul ((_ sign_extend 32) in.34_32) ((_ sign_extend 32) (_ bv1048576 32))) ((_ sign_extend 32) (bvmul in.34_32 (_ bv1048576 32)))) true)))
(let (($x6041 (or false false (or $x4431))))
(and (not $x6041) (or $x6041 (and (distinct (bvmul in.34_32 (_ bv1048576 32)) (bvmul in.34_32 (_ bv1048576 32))) true))))))
(check-sat)
; query 115: function partition_memory, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1814 (or false false false)))
(let (($x131 (not $x1814)))
(and $x131 (or $x1814 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 116: function run_matrix_multiply, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x1814 (or false false false)))
(let (($x131 (not $x1814)))
(and $x131 (or $x1814 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 117: function run_matrix_multiply, block 34, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x229 (bvadd in.01_32 (_ bv1 32))))
(let (($x3821 (and (distinct ?x229 ?x229) true)))
(let (($x1814 (or false false false)))
(let (($x131 (not $x1814)))
(and $x131 (or $x1814 $x3821)))))))
(check-sat)
