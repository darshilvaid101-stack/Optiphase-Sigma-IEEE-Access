; OptiPhase-Sigma refinement certificate for sweep K35-R3-124
; query 0: function corner_draw, block 11, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x413 (ite (= (_ bv0 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x85 (or false false false)))
(let (($x56 (not $x85)))
(and $x56 (or $x85 (and (distinct ?x413 ?x413) true)))))))
(check-sat)
; query 1: function edge_draw, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let ((?x23 (ite (= (_ bv0 32) in4_32) (_ bv1 1) (_ bv0 1))))
(let (($x85 (or false false false)))
(let (($x56 (not $x85)))
(and $x56 (or $x85 (and (distinct ?x23 ?x23) true)))))))
(check-sat)
; query 2: function main, block 129, name %130
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.011_32 () (_ BitVec 32))
(assert
 (let ((?x374 (ite (and (distinct (_ bv0 32) in.011_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x85 (or false false false)))
(let (($x56 (not $x85)))
(and $x56 (or $x85 (and (distinct ?x374 ?x374) true)))))))
(check-sat)
; query 3: function main, block 160, name %161
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x38 (ite (and (distinct (_ bv0 32) in.01_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x85 (or false false false)))
(let (($x56 (not $x85)))
(and $x56 (or $x85 (and (distinct ?x38 ?x38) true)))))))
(check-sat)
; query 4: function main, block 35, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x115 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x311 (or false false (or $x115))))
(and (not $x311) (or $x311 (and (distinct (bvadd in.020_32 (_ bv1 32)) (bvadd in.020_32 (_ bv1 32))) true))))))
(check-sat)
; query 5: function main, block 35, name %37
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let ((?x37 (ite (bvsge (bvadd in.020_32 (_ bv1 32)) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x115 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x311 (or false false (or $x115))))
(let (($x12 (or $x311 false false)))
(and (not $x12) (or $x12 (and (distinct ?x37 ?x37) true))))))))
(check-sat)
; query 6: function main, block 49, name %50
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x115 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x311 (or false false (or $x115))))
(and (not $x311) (or $x311 (and (distinct (bvadd in.020_32 (_ bv1 32)) (bvadd in.020_32 (_ bv1 32))) true))))))
(check-sat)
; query 7: function main, block 49, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let ((?x37 (ite (bvsge (bvadd in.020_32 (_ bv1 32)) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x115 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x311 (or false false (or $x115))))
(let (($x12 (or $x311 false false)))
(and (not $x12) (or $x12 (and (distinct ?x37 ?x37) true))))))))
(check-sat)
; query 8: function main, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.014_32 () (_ BitVec 32))
(assert
 (let ((?x20 (ite (= (_ bv1 32) in.014_32) (_ bv1 1) (_ bv0 1))))
(let (($x85 (or false false false)))
(let (($x56 (not $x85)))
(and $x56 (or $x85 (and (distinct ?x20 ?x20) true)))))))
(check-sat)
; query 9: function main, block 66, name %67
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x142 (ite (= (_ bv0 32) in.0_32) (_ bv1 1) (_ bv0 1))))
(let (($x85 (or false false false)))
(let (($x56 (not $x85)))
(and $x56 (or $x85 (and (distinct ?x142 ?x142) true)))))))
(check-sat)
; query 10: function main, block 84, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.07_32 () (_ BitVec 32))
(assert
 (let ((?x28 (ite (and (distinct (_ bv0 32) in.07_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x85 (or false false false)))
(let (($x56 (not $x85)))
(and $x56 (or $x85 (and (distinct ?x28 ?x28) true)))))))
(check-sat)
