; OptiPhase-Sigma refinement certificate for sweep K50-R3-252
; query 0: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x78 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x514 (or false false false)))
(let (($x73 (not $x514)))
(and $x73 (or $x514 (and (distinct ?x78 ?x78) true)))))))
(check-sat)
; query 1: function set1d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x25 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x514 (or false false false)))
(let (($x73 (not $x514)))
(and $x73 (or $x514 (and (distinct ?x25 ?x25) true)))))))
(check-sat)
; query 2: function set1ds, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x315 (ite (= (_ bv4294967295 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x514 (or false false false)))
(let (($x73 (not $x514)))
(and $x73 (or $x514 (and (distinct ?x315 ?x315) true)))))))
(check-sat)
; query 3: function set2d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x25 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x514 (or false false false)))
(let (($x73 (not $x514)))
(and $x73 (or $x514 (and (distinct ?x25 ?x25) true)))))))
(check-sat)
