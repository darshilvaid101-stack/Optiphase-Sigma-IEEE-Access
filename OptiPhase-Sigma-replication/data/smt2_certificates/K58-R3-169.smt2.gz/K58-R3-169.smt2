; OptiPhase-Sigma refinement certificate for sweep K58-R3-169
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x17 (or false false)))
(let (($x1568 (not $x17)))
(and $x1568 (or $x17 (and (distinct ((_ sign_extend 16) in25_16) ((_ sign_extend 16) in25_16)) true))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let ((?x1097 (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))))
(let (($x17 (or false false)))
(let (($x77 (or $x17 false false)))
(let (($x229 (not $x77)))
(and $x229 (or $x77 (and (distinct ?x1097 ?x1097) true))))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x17 (or false false)))
(let (($x1568 (not $x17)))
(and $x1568 (or $x17 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x34 ((_ sign_extend 16) in3_16)))
(let ((?x479 (bvand ?x34 (_ bv127 32))))
(let (($x17 (or false false)))
(let (($x77 (or $x17 false false)))
(let (($x229 (not $x77)))
(and $x229 (or $x77 (and (distinct ?x479 ?x479) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x34 ((_ sign_extend 16) in3_16)))
(let ((?x479 (bvand ?x34 (_ bv127 32))))
(let ((?x586 ((_ extract 15 0) ?x479)))
(let (($x17 (or false false)))
(let (($x77 (or $x17 false false)))
(let (($x12 (or $x77 false)))
(let (($x1588 (not $x12)))
(and $x1588 (or $x12 (and (distinct ?x586 ?x586) true)))))))))))
(check-sat)
; query 5: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x17 (or false false)))
(let (($x1568 (not $x17)))
(and $x1568 (or $x17 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 6: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x274 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x17 (or false false)))
(let (($x77 (or $x17 false false)))
(let (($x229 (not $x77)))
(and $x229 (or $x77 (and (distinct ?x274 ?x274) true))))))))
(check-sat)
; query 7: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x347 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x58 (or false false false)))
(let (($x132 (not $x58)))
(and $x132 (or $x58 (and (distinct ?x347 ?x347) true)))))))
(check-sat)
; query 8: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x58 (or false false false)))
(let (($x132 (not $x58)))
(and $x132 (or $x58 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 9: function core_state_transition, block 102, name %103
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x17 (or false false)))
(let (($x1568 (not $x17)))
(and $x1568 (or $x17 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 10: function core_state_transition, block 102, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x124 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x17 (or false false)))
(let (($x77 (or $x17 false false)))
(let (($x229 (not $x77)))
(and $x229 (or $x77 (and (distinct ?x124 ?x124) true))))))))
(check-sat)
; query 11: function core_state_transition, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x17 (or false false)))
(let (($x1568 (not $x17)))
(and $x1568 (or $x17 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 12: function core_state_transition, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x382 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x17 (or false false)))
(let (($x77 (or $x17 false false)))
(let (($x229 (not $x77)))
(and $x229 (or $x77 (and (distinct ?x382 ?x382) true))))))))
(check-sat)
; query 13: function core_state_transition, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x17 (or false false)))
(let (($x1568 (not $x17)))
(and $x1568 (or $x17 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 14: function core_state_transition, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x124 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x17 (or false false)))
(let (($x77 (or $x17 false false)))
(let (($x229 (not $x77)))
(and $x229 (or $x77 (and (distinct ?x124 ?x124) true))))))))
(check-sat)
; query 15: function core_state_transition, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x17 (or false false)))
(let (($x1568 (not $x17)))
(and $x1568 (or $x17 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 16: function core_state_transition, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x69 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x17 (or false false)))
(let (($x77 (or $x17 false false)))
(let (($x229 (not $x77)))
(and $x229 (or $x77 (and (distinct ?x69 ?x69) true))))))))
(check-sat)
; query 17: function core_state_transition, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x17 (or false false)))
(let (($x1568 (not $x17)))
(and $x1568 (or $x17 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 18: function core_state_transition, block 51, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x69 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x17 (or false false)))
(let (($x77 (or $x17 false false)))
(let (($x229 (not $x77)))
(and $x229 (or $x77 (and (distinct ?x69 ?x69) true))))))))
(check-sat)
; query 19: function core_state_transition, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x17 (or false false)))
(let (($x1568 (not $x17)))
(and $x1568 (or $x17 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 20: function core_state_transition, block 64, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x69 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x17 (or false false)))
(let (($x77 (or $x17 false false)))
(let (($x229 (not $x77)))
(and $x229 (or $x77 (and (distinct ?x69 ?x69) true))))))))
(check-sat)
; query 21: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x6 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x58 (or false false false)))
(let (($x132 (not $x58)))
(and $x132 (or $x58 (and (distinct ?x6 ?x6) true)))))))
(check-sat)
; query 22: function core_state_transition, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x17 (or false false)))
(let (($x1568 (not $x17)))
(and $x1568 (or $x17 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 23: function core_state_transition, block 80, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x523 (ite (= (_ bv69 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x17 (or false false)))
(let (($x77 (or $x17 false false)))
(let (($x229 (not $x77)))
(and $x229 (or $x77 (and (distinct ?x523 ?x523) true))))))))
(check-sat)
; query 24: function core_state_transition, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x17 (or false false)))
(let (($x1568 (not $x17)))
(and $x1568 (or $x17 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 25: function core_state_transition, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x164 (ite (= (_ bv101 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x17 (or false false)))
(let (($x77 (or $x17 false false)))
(let (($x229 (not $x77)))
(and $x229 (or $x77 (and (distinct ?x164 ?x164) true))))))))
(check-sat)
; query 26: function core_state_transition, block 99, name %100
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x17 (or false false)))
(let (($x1568 (not $x17)))
(and $x1568 (or $x17 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 27: function core_state_transition, block 99, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x382 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x17 (or false false)))
(let (($x77 (or $x17 false false)))
(let (($x229 (not $x77)))
(and $x229 (or $x77 (and (distinct ?x382 ?x382) true))))))))
(check-sat)
; query 28: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x864 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x417 ((_ zero_extend 31) ?x864)))
(let ((?x19 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x670 ((_ zero_extend 31) ?x19)))
(let ((?x1590 (bvand ?x670 ?x417)))
(let ((?x885 (ite (and (distinct (_ bv0 32) ?x1590) true) (_ bv1 1) (_ bv0 1))))
(let ((?x24 ((_ zero_extend 63) ?x885)))
(let (($x17 (or false false)))
(let (($x77 (or $x17 false false)))
(let (($x12 (or $x77 false)))
(let (($x316 (or $x12 $x12 false)))
(let (($x1023 (or $x316 false false)))
(let (($x1525 (or $x1023 false)))
(and (not $x1525) (or $x1525 (and (distinct ?x24 ?x24) true)))))))))))))))))
(check-sat)
; query 29: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x864 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x417 ((_ zero_extend 31) ?x864)))
(let ((?x19 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x670 ((_ zero_extend 31) ?x19)))
(let ((?x1590 (bvand ?x670 ?x417)))
(let ((?x885 (ite (and (distinct (_ bv0 32) ?x1590) true) (_ bv1 1) (_ bv0 1))))
(let (($x272 (= (_ bv1 1) ?x885)))
(let ((?x117 (ite $x272 (_ bv1 32) (_ bv0 32))))
(let (($x17 (or false false)))
(let (($x77 (or $x17 false false)))
(let (($x12 (or $x77 false)))
(let (($x316 (or $x12 $x12 false)))
(let (($x1023 (or $x316 false false)))
(let (($x137 (or $x1023 (ite $x272 false false))))
(and (not $x137) (or $x137 (and (distinct ?x117 ?x117) true))))))))))))))))))
(check-sat)
; query 30: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x864 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x417 ((_ zero_extend 31) ?x864)))
(let ((?x19 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x670 ((_ zero_extend 31) ?x19)))
(let ((?x1590 (bvand ?x670 ?x417)))
(let ((?x885 (ite (and (distinct (_ bv0 32) ?x1590) true) (_ bv1 1) (_ bv0 1))))
(let (($x272 (= (_ bv1 1) ?x885)))
(let ((?x117 (ite $x272 (_ bv1 32) (_ bv0 32))))
(let ((?x458 ((_ extract 7 0) ?x117)))
(let (($x17 (or false false)))
(let (($x77 (or $x17 false false)))
(let (($x12 (or $x77 false)))
(let (($x316 (or $x12 $x12 false)))
(let (($x1023 (or $x316 false false)))
(let (($x137 (or $x1023 (ite $x272 false false))))
(let (($x1078 (or $x137 false)))
(and (not $x1078) (or $x1078 (and (distinct ?x458 ?x458) true))))))))))))))))))))
(check-sat)
; query 31: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x17 (or false false)))
(let (($x1568 (not $x17)))
(and $x1568 (or $x17 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 32: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x19 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x17 (or false false)))
(let (($x77 (or $x17 false false)))
(let (($x229 (not $x77)))
(and $x229 (or $x77 (and (distinct ?x19 ?x19) true))))))))
(check-sat)
; query 33: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x19 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x670 ((_ zero_extend 31) ?x19)))
(let (($x17 (or false false)))
(let (($x77 (or $x17 false false)))
(let (($x12 (or $x77 false)))
(let (($x1588 (not $x12)))
(and $x1588 (or $x12 (and (distinct ?x670 ?x670) true))))))))))
(check-sat)
; query 34: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x17 (or false false)))
(let (($x1568 (not $x17)))
(and $x1568 (or $x17 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 35: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x864 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x17 (or false false)))
(let (($x77 (or $x17 false false)))
(let (($x229 (not $x77)))
(and $x229 (or $x77 (and (distinct ?x864 ?x864) true))))))))
(check-sat)
; query 36: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x864 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x417 ((_ zero_extend 31) ?x864)))
(let (($x17 (or false false)))
(let (($x77 (or $x17 false false)))
(let (($x12 (or $x77 false)))
(let (($x1588 (not $x12)))
(and $x1588 (or $x12 (and (distinct ?x417 ?x417) true))))))))))
(check-sat)
; query 37: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x864 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x417 ((_ zero_extend 31) ?x864)))
(let ((?x19 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x670 ((_ zero_extend 31) ?x19)))
(let ((?x1590 (bvand ?x670 ?x417)))
(let (($x17 (or false false)))
(let (($x77 (or $x17 false false)))
(let (($x12 (or $x77 false)))
(let (($x316 (or $x12 $x12 false)))
(and (not $x316) (or $x316 (and (distinct ?x1590 ?x1590) true)))))))))))))
(check-sat)
; query 38: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x864 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x417 ((_ zero_extend 31) ?x864)))
(let ((?x19 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x670 ((_ zero_extend 31) ?x19)))
(let ((?x1590 (bvand ?x670 ?x417)))
(let ((?x885 (ite (and (distinct (_ bv0 32) ?x1590) true) (_ bv1 1) (_ bv0 1))))
(let (($x17 (or false false)))
(let (($x77 (or $x17 false false)))
(let (($x12 (or $x77 false)))
(let (($x316 (or $x12 $x12 false)))
(let (($x1023 (or $x316 false false)))
(and (not $x1023) (or $x1023 (and (distinct ?x885 ?x885) true)))))))))))))))
(check-sat)
; query 39: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x685 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x58 (or false false false)))
(let (($x132 (not $x58)))
(and $x132 (or $x58 (and (distinct ?x685 ?x685) true)))))))
(check-sat)
; query 40: function parseval, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.23_32 () (_ BitVec 32))
(assert
 (let (($x59 (and (distinct (bvmul ((_ sign_extend 32) in.23_32) ((_ sign_extend 32) (_ bv1024 32))) ((_ sign_extend 32) (bvmul in.23_32 (_ bv1024 32)))) true)))
(let (($x1449 (or false false (or $x59))))
(and (not $x1449) (or $x1449 (and (distinct (bvmul in.23_32 (_ bv1024 32)) (bvmul in.23_32 (_ bv1024 32))) true))))))
(check-sat)
; query 41: function parseval, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.34_32 () (_ BitVec 32))
(assert
 (let (($x466 (and (distinct (bvmul ((_ sign_extend 32) in.34_32) ((_ sign_extend 32) (_ bv1048576 32))) ((_ sign_extend 32) (bvmul in.34_32 (_ bv1048576 32)))) true)))
(let (($x241 (or false false (or $x466))))
(and (not $x241) (or $x241 (and (distinct (bvmul in.34_32 (_ bv1048576 32)) (bvmul in.34_32 (_ bv1048576 32))) true))))))
(check-sat)
