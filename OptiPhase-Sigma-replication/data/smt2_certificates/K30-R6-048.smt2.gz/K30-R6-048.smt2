; OptiPhase-Sigma refinement certificate for sweep K30-R6-048
; query 0: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x104 (ite (bvsgt (_ bv2 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x151 (or false false false)))
(and (not $x151) (or $x151 (and (distinct ?x104 ?x104) true))))))
(check-sat)
