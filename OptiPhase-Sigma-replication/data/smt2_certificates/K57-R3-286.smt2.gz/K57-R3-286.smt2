; OptiPhase-Sigma refinement certificate for sweep K57-R3-286
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x28 (or false false)))
(let (($x83 (not $x28)))
(and $x83 (or $x28 (and (distinct ((_ sign_extend 16) in25_16) ((_ sign_extend 16) in25_16)) true))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let ((?x1547 (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))))
(let (($x28 (or false false)))
(let (($x327 (or $x28 false false)))
(let (($x858 (not $x327)))
(and $x858 (or $x327 (and (distinct ?x1547 ?x1547) true))))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x28 (or false false)))
(let (($x83 (not $x28)))
(and $x83 (or $x28 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x104 ((_ sign_extend 16) in3_16)))
(let ((?x339 (bvand ?x104 (_ bv127 32))))
(let (($x28 (or false false)))
(let (($x327 (or $x28 false false)))
(let (($x858 (not $x327)))
(and $x858 (or $x327 (and (distinct ?x339 ?x339) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x104 ((_ sign_extend 16) in3_16)))
(let ((?x339 (bvand ?x104 (_ bv127 32))))
(let ((?x151 ((_ extract 15 0) ?x339)))
(let (($x28 (or false false)))
(let (($x327 (or $x28 false false)))
(let (($x2117 (or $x327 false)))
(let (($x147 (not $x2117)))
(and $x147 (or $x2117 (and (distinct ?x151 ?x151) true)))))))))))
(check-sat)
; query 5: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x28 (or false false)))
(let (($x83 (not $x28)))
(and $x83 (or $x28 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 6: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x342 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x28 (or false false)))
(let (($x327 (or $x28 false false)))
(let (($x858 (not $x327)))
(and $x858 (or $x327 (and (distinct ?x342 ?x342) true))))))))
(check-sat)
; query 7: function core_bench_list, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x18 (or false false false)))
(let (($x64 (not $x18)))
(and $x64 (or $x18 (and (distinct (bvadd in.0_16 (_ bv1 16)) (bvadd in.0_16 (_ bv1 16))) true))))))
(check-sat)
; query 8: function core_bench_list, block 82, name %83
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let (($x28 (or false false)))
(let (($x83 (not $x28)))
(and $x83 (or $x28 (and (distinct ((_ zero_extend 16) in.02_16) ((_ zero_extend 16) in.02_16)) true))))))
(check-sat)
; query 9: function core_bench_list, block 82, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x19 ((_ zero_extend 16) in.02_16)))
(let ((?x142 (bvmul ?x19 (_ bv4 32))))
(let (($x714 (and (distinct (bvmul ((_ sign_extend 32) ?x19) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x142)) true)))
(let (($x28 (or false false)))
(let (($x15 (or $x28 false (or $x714))))
(and (not $x15) (or $x15 (and (distinct ?x142 ?x142) true)))))))))
(check-sat)
; query 10: function core_bench_list, block 82, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let (($x28 (or false false)))
(let (($x83 (not $x28)))
(and $x83 (or $x28 (and (distinct ((_ zero_extend 16) in.04_16) ((_ zero_extend 16) in.04_16)) true))))))
(check-sat)
; query 11: function core_bench_list, block 82, name %86
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x19 ((_ zero_extend 16) in.02_16)))
(let ((?x142 (bvmul ?x19 (_ bv4 32))))
(let ((?x1249 (bvadd ?x142 (bvsub (_ bv0 32) ((_ zero_extend 16) in.04_16)))))
(let ((?x649 ((_ zero_extend 16) in.04_16)))
(let ((?x681 (bvsub ?x142 ?x649)))
(let (($x714 (and (distinct (bvmul ((_ sign_extend 32) ?x19) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x142)) true)))
(let (($x28 (or false false)))
(let (($x15 (or $x28 false (or $x714))))
(let (($x206 (or $x15 (or false $x28 false) false)))
(let ((?x426 ((_ sign_extend 1) ?x681)))
(let (($x446 (or $x15 $x28 (or (and (distinct (bvsub ((_ sign_extend 1) ?x142) ((_ sign_extend 1) ?x649)) ?x426) true)))))
(and (not $x446) (or $x206 (and (distinct ?x681 ?x1249) true)))))))))))))))
(check-sat)
; query 12: function core_bench_list, block 82, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x28 (or false false)))
(let (($x83 (not $x28)))
(and $x83 (or $x28 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 13: function core_bench_list, block 82, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x9642 ((_ zero_extend 16) in.01_16)))
(let ((?x19 ((_ zero_extend 16) in.02_16)))
(let ((?x142 (bvmul ?x19 (_ bv4 32))))
(let ((?x1249 (bvadd ?x142 (bvsub (_ bv0 32) ((_ zero_extend 16) in.04_16)))))
(let ((?x320 (bvadd ?x1249 ?x9642)))
(let ((?x649 ((_ zero_extend 16) in.04_16)))
(let ((?x681 (bvsub ?x142 ?x649)))
(let ((?x1669 (bvadd ?x9642 ?x681)))
(let (($x538 (and (distinct (bvadd ((_ sign_extend 1) ?x1249) ((_ sign_extend 1) ?x9642)) ((_ sign_extend 1) ?x320)) true)))
(let (($x28 (or false false)))
(let (($x714 (and (distinct (bvmul ((_ sign_extend 32) ?x19) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x142)) true)))
(let (($x15 (or $x28 false (or $x714))))
(let (($x206 (or $x15 (or false $x28 false) false)))
(let (($x203 (or $x206 $x28 (or $x538))))
(let (($x362 (and (distinct (bvadd ((_ sign_extend 1) ?x9642) ((_ sign_extend 1) ?x681)) ((_ sign_extend 1) ?x1669)) true)))
(let ((?x426 ((_ sign_extend 1) ?x681)))
(let (($x446 (or $x15 $x28 (or (and (distinct (bvsub ((_ sign_extend 1) ?x142) ((_ sign_extend 1) ?x649)) ?x426) true)))))
(let (($x42 (or $x28 $x446 (or $x362))))
(and (not $x42) (or $x203 (and (distinct ?x1669 ?x320) true))))))))))))))))))))))
(check-sat)
; query 14: function core_bench_list, block 82, name %89
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x9642 ((_ zero_extend 16) in.01_16)))
(let ((?x19 ((_ zero_extend 16) in.02_16)))
(let ((?x142 (bvmul ?x19 (_ bv4 32))))
(let ((?x1249 (bvadd ?x142 (bvsub (_ bv0 32) ((_ zero_extend 16) in.04_16)))))
(let ((?x320 (bvadd ?x1249 ?x9642)))
(let (($x98 (and (distinct ((_ extract 15 0) (bvadd ?x9642 (bvsub ?x142 ((_ zero_extend 16) in.04_16)))) ((_ extract 15 0) ?x320)) true)))
(let (($x538 (and (distinct (bvadd ((_ sign_extend 1) ?x1249) ((_ sign_extend 1) ?x9642)) ((_ sign_extend 1) ?x320)) true)))
(let (($x28 (or false false)))
(let (($x714 (and (distinct (bvmul ((_ sign_extend 32) ?x19) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x142)) true)))
(let (($x15 (or $x28 false (or $x714))))
(let (($x206 (or $x15 (or false $x28 false) false)))
(let (($x203 (or $x206 $x28 (or $x538))))
(let ((?x649 ((_ zero_extend 16) in.04_16)))
(let ((?x681 (bvsub ?x142 ?x649)))
(let ((?x426 ((_ sign_extend 1) ?x681)))
(let ((?x101 ((_ sign_extend 1) ?x9642)))
(let (($x446 (or $x15 $x28 (or (and (distinct (bvsub ((_ sign_extend 1) ?x142) ((_ sign_extend 1) ?x649)) ?x426) true)))))
(let (($x42 (or $x28 $x446 (or (and (distinct (bvadd ?x101 ?x426) ((_ sign_extend 1) (bvadd ?x9642 ?x681))) true)))))
(and (not (or $x42 false)) (or (or $x203 false) $x98)))))))))))))))))))))
(check-sat)
; query 15: function core_bench_list, block 82, name %90
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x28 (or false false)))
(let (($x83 (not $x28)))
(and $x83 (or $x28 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 16: function core_bench_list, block 82, name %91
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1022 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x28 (or false false)))
(let (($x327 (or $x28 false false)))
(let (($x858 (not $x327)))
(and $x858 (or $x327 (and (distinct ?x1022 ?x1022) true))))))))
(check-sat)
; query 17: function core_bench_state, block 105, name %106
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x18 (or false false false)))
(let (($x64 (not $x18)))
(and $x64 (or $x18 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 18: function core_bench_state, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x18 (or false false false)))
(let (($x64 (not $x18)))
(and $x64 (or $x18 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 19: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1952 (bvadd in.01_32 (_ bv1 32))))
(let (($x38916 (and (distinct ?x1952 ?x1952) true)))
(let (($x18 (or false false false)))
(let (($x64 (not $x18)))
(and $x64 (or $x18 $x38916)))))))
(check-sat)
; query 20: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1952 (bvadd in.01_32 (_ bv1 32))))
(let ((?x618 (bvmul ?x1952 (_ bv8 32))))
(let ((?x365 (bvmul ?x1952 ?x1952)))
(let (($x18 (or false false false)))
(let (($x321 (or $x18 false false)))
(and (not (or $x18 $x18 false)) (or $x321 (and (distinct ?x365 ?x618) true)))))))))
(check-sat)
; query 21: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x40808 (and (distinct (bvmul (bvmul (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) (_ bv2 32)) (bvmul (bvmul (bvadd in.01_32 (_ bv1 32)) (_ bv8 32)) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x18 (or false false false)))
(let (($x321 (or $x18 false false)))
(and (not (or (or $x18 $x18 false) false false)) (or (or $x321 $x18 false) $x40808))))))
(check-sat)
; query 22: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x17 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x18 (or false false false)))
(let (($x64 (not $x18)))
(and $x64 (or $x18 (and (distinct ?x17 ?x17) true)))))))
(check-sat)
; query 23: function core_init_state, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_32 () (_ BitVec 32))
(assert
 (let (($x18 (or false false false)))
(let (($x64 (not $x18)))
(and $x64 (or $x18 (and (distinct (bvadd in.06_32 (_ bv1 32)) (bvadd in.06_32 (_ bv1 32))) true))))))
(check-sat)
; query 24: function core_init_state, block 65, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let (($x18 (or false false false)))
(let (($x64 (not $x18)))
(and $x64 (or $x18 (and (distinct (bvadd in4_32 (_ bv1 32)) (bvadd in4_32 (_ bv1 32))) true))))))
(check-sat)
; query 25: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x19958 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x18 (or false false false)))
(let (($x64 (not $x18)))
(and $x64 (or $x18 (and (distinct ?x19958 ?x19958) true)))))))
(check-sat)
; query 26: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x18 (or false false false)))
(let (($x64 (not $x18)))
(and $x64 (or $x18 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 27: function core_list_init, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1952 (bvadd in.01_32 (_ bv1 32))))
(let (($x38916 (and (distinct ?x1952 ?x1952) true)))
(let (($x18 (or false false false)))
(let (($x64 (not $x18)))
(and $x64 (or $x18 $x38916)))))))
(check-sat)
; query 28: function core_list_mergesort, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1952 (bvadd in.01_32 (_ bv1 32))))
(let (($x38916 (and (distinct ?x1952 ?x1952) true)))
(let (($x20418 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x1952)) true)))
(let (($x44095 (or false false (or $x20418))))
(and (not $x44095) (or $x44095 $x38916)))))))
(check-sat)
; query 29: function core_list_mergesort, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x11586 (ite (bvslt (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x18 (or false false false)))
(let (($x64 (not $x18)))
(and $x64 (or $x18 (and (distinct ?x11586 ?x11586) true)))))))
(check-sat)
; query 30: function core_list_mergesort, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.224_32 () (_ BitVec 32))
(assert
 (let ((?x1902 (ite (= (_ bv0 32) in.224_32) (_ bv1 1) (_ bv0 1))))
(let (($x18 (or false false false)))
(let (($x64 (not $x18)))
(and $x64 (or $x18 (and (distinct ?x1902 ?x1902) true)))))))
(check-sat)
; query 31: function core_list_mergesort, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x9876 (ite (= (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x18 (or false false false)))
(let (($x64 (not $x18)))
(and $x64 (or $x18 (and (distinct ?x9876 ?x9876) true)))))))
(check-sat)
; query 32: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x962 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x14364 (or false false (or $x962))))
(and (not $x14364) (or $x14364 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 33: function core_list_mergesort, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x13418 (and (distinct (bvmul ((_ sign_extend 32) in.020_32) ((_ sign_extend 32) (_ bv2 32))) ((_ sign_extend 32) (bvmul in.020_32 (_ bv2 32)))) true)))
(let (($x42815 (or false false (or $x13418))))
(and (not $x42815) (or $x42815 (and (distinct (bvmul in.020_32 (_ bv2 32)) (bvmul in.020_32 (_ bv2 32))) true))))))
(check-sat)
; query 34: function core_state_transition, block 102, name %103
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x28 (or false false)))
(let (($x83 (not $x28)))
(and $x83 (or $x28 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 35: function core_state_transition, block 102, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x219 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x28 (or false false)))
(let (($x327 (or $x28 false false)))
(let (($x858 (not $x327)))
(and $x858 (or $x327 (and (distinct ?x219 ?x219) true))))))))
(check-sat)
; query 36: function core_state_transition, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x28 (or false false)))
(let (($x83 (not $x28)))
(and $x83 (or $x28 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 37: function core_state_transition, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x72 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x28 (or false false)))
(let (($x327 (or $x28 false false)))
(let (($x858 (not $x327)))
(and $x858 (or $x327 (and (distinct ?x72 ?x72) true))))))))
(check-sat)
; query 38: function core_state_transition, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x28 (or false false)))
(let (($x83 (not $x28)))
(and $x83 (or $x28 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 39: function core_state_transition, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x219 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x28 (or false false)))
(let (($x327 (or $x28 false false)))
(let (($x858 (not $x327)))
(and $x858 (or $x327 (and (distinct ?x219 ?x219) true))))))))
(check-sat)
; query 40: function core_state_transition, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x28 (or false false)))
(let (($x83 (not $x28)))
(and $x83 (or $x28 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 41: function core_state_transition, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x12097 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x28 (or false false)))
(let (($x327 (or $x28 false false)))
(let (($x858 (not $x327)))
(and $x858 (or $x327 (and (distinct ?x12097 ?x12097) true))))))))
(check-sat)
; query 42: function core_state_transition, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x28 (or false false)))
(let (($x83 (not $x28)))
(and $x83 (or $x28 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 43: function core_state_transition, block 51, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x12097 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x28 (or false false)))
(let (($x327 (or $x28 false false)))
(let (($x858 (not $x327)))
(and $x858 (or $x327 (and (distinct ?x12097 ?x12097) true))))))))
(check-sat)
; query 44: function core_state_transition, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x28 (or false false)))
(let (($x83 (not $x28)))
(and $x83 (or $x28 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 45: function core_state_transition, block 64, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x12097 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x28 (or false false)))
(let (($x327 (or $x28 false false)))
(let (($x858 (not $x327)))
(and $x858 (or $x327 (and (distinct ?x12097 ?x12097) true))))))))
(check-sat)
; query 46: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x564 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x18 (or false false false)))
(let (($x64 (not $x18)))
(and $x64 (or $x18 (and (distinct ?x564 ?x564) true)))))))
(check-sat)
; query 47: function core_state_transition, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x28 (or false false)))
(let (($x83 (not $x28)))
(and $x83 (or $x28 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 48: function core_state_transition, block 80, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x127 (ite (= (_ bv69 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x28 (or false false)))
(let (($x327 (or $x28 false false)))
(let (($x858 (not $x327)))
(and $x858 (or $x327 (and (distinct ?x127 ?x127) true))))))))
(check-sat)
; query 49: function core_state_transition, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x28 (or false false)))
(let (($x83 (not $x28)))
(and $x83 (or $x28 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 50: function core_state_transition, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x13892 (ite (= (_ bv101 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x28 (or false false)))
(let (($x327 (or $x28 false false)))
(let (($x858 (not $x327)))
(and $x858 (or $x327 (and (distinct ?x13892 ?x13892) true))))))))
(check-sat)
; query 51: function core_state_transition, block 99, name %100
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x28 (or false false)))
(let (($x83 (not $x28)))
(and $x83 (or $x28 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 52: function core_state_transition, block 99, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x72 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x28 (or false false)))
(let (($x327 (or $x28 false false)))
(let (($x858 (not $x327)))
(and $x858 (or $x327 (and (distinct ?x72 ?x72) true))))))))
(check-sat)
; query 53: function crcu8, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x28 (or false false)))
(let (($x83 (not $x28)))
(and $x83 (or $x28 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 54: function crcu8, block 19, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x9642 ((_ zero_extend 16) in.01_16)))
(let ((?x44281 (bvxor ?x9642 (_ bv16386 32))))
(let (($x28 (or false false)))
(let (($x327 (or $x28 false false)))
(let (($x858 (not $x327)))
(and $x858 (or $x327 (and (distinct ?x44281 ?x44281) true)))))))))
(check-sat)
; query 55: function crcu8, block 19, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x9642 ((_ zero_extend 16) in.01_16)))
(let ((?x44281 (bvxor ?x9642 (_ bv16386 32))))
(let ((?x38309 ((_ extract 15 0) ?x44281)))
(let (($x28 (or false false)))
(let (($x327 (or $x28 false false)))
(let (($x2117 (or $x327 false)))
(let (($x147 (not $x2117)))
(and $x147 (or $x2117 (and (distinct ?x38309 ?x38309) true)))))))))))
(check-sat)
; query 56: function crcu8, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x28 (or false false)))
(let (($x83 (not $x28)))
(and $x83 (or $x28 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 57: function crcu8, block 29, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x10601 ((_ zero_extend 16) in27_16)))
(let ((?x18985 (bvor ?x10601 (_ bv32768 32))))
(let (($x28 (or false false)))
(let (($x327 (or $x28 false false)))
(let (($x858 (not $x327)))
(and $x858 (or $x327 (and (distinct ?x18985 ?x18985) true)))))))))
(check-sat)
; query 58: function crcu8, block 29, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x10601 ((_ zero_extend 16) in27_16)))
(let ((?x18985 (bvor ?x10601 (_ bv32768 32))))
(let ((?x18259 ((_ extract 15 0) ?x18985)))
(let (($x28 (or false false)))
(let (($x327 (or $x28 false false)))
(let (($x2117 (or $x327 false)))
(let (($x147 (not $x2117)))
(and $x147 (or $x2117 (and (distinct ?x18259 ?x18259) true)))))))))))
(check-sat)
; query 59: function crcu8, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x28 (or false false)))
(let (($x83 (not $x28)))
(and $x83 (or $x28 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 60: function crcu8, block 33, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x10601 ((_ zero_extend 16) in27_16)))
(let ((?x1141 (bvand ?x10601 (_ bv32767 32))))
(let (($x28 (or false false)))
(let (($x327 (or $x28 false false)))
(let (($x858 (not $x327)))
(and $x858 (or $x327 (and (distinct ?x1141 ?x1141) true)))))))))
(check-sat)
; query 61: function crcu8, block 33, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x10601 ((_ zero_extend 16) in27_16)))
(let ((?x1141 (bvand ?x10601 (_ bv32767 32))))
(let ((?x14870 ((_ extract 15 0) ?x1141)))
(let (($x28 (or false false)))
(let (($x327 (or $x28 false false)))
(let (($x2117 (or $x327 false)))
(let (($x147 (not $x2117)))
(and $x147 (or $x2117 (and (distinct ?x14870 ?x14870) true)))))))))))
(check-sat)
; query 62: function crcu8, block 38, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_8 () (_ BitVec 8))
(assert
 (let (($x18 (or false false false)))
(let (($x64 (not $x18)))
(and $x64 (or $x18 (and (distinct (bvadd in.02_8 (_ bv1 8)) (bvadd in.02_8 (_ bv1 8))) true))))))
(check-sat)
; query 63: function crcu8, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x43716 ((_ extract 7 0) in.01_16)))
(let ((?x731 ((_ zero_extend 24) ?x43716)))
(let (($x28 (or false false)))
(let (($x1282 (or $x28 false)))
(and (not $x1282) (or $x1282 (and (distinct ?x731 ?x731) true))))))))
(check-sat)
; query 64: function crcu8, block 6, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x43716 ((_ extract 7 0) in.01_16)))
(let ((?x731 ((_ zero_extend 24) ?x43716)))
(let ((?x11015 (bvand ?x731 (_ bv1 32))))
(let (($x28 (or false false)))
(let (($x1282 (or $x28 false)))
(let (($x21728 (or $x1282 false false)))
(and (not $x21728) (or $x21728 (and (distinct ?x11015 ?x11015) true))))))))))
(check-sat)
; query 65: function crcu8, block 6, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x43716 ((_ extract 7 0) in.01_16)))
(let ((?x731 ((_ zero_extend 24) ?x43716)))
(let ((?x11015 (bvand ?x731 (_ bv1 32))))
(let ((?x1171 ((_ zero_extend 24) in.0_8)))
(let ((?x42401 (bvand ?x1171 (_ bv1 32))))
(let ((?x724 (bvxor ?x42401 ?x11015)))
(let (($x28 (or false false)))
(let (($x1282 (or $x28 false)))
(let (($x21728 (or $x1282 false false)))
(let (($x327 (or $x28 false false)))
(let (($x1534 (or $x327 $x21728 false)))
(and (not $x1534) (or $x1534 (and (distinct ?x724 ?x724) true)))))))))))))))
(check-sat)
; query 66: function crcu8, block 6, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x43716 ((_ extract 7 0) in.01_16)))
(let ((?x731 ((_ zero_extend 24) ?x43716)))
(let ((?x11015 (bvand ?x731 (_ bv1 32))))
(let ((?x1171 ((_ zero_extend 24) in.0_8)))
(let ((?x42401 (bvand ?x1171 (_ bv1 32))))
(let ((?x724 (bvxor ?x42401 ?x11015)))
(let ((?x41816 ((_ extract 7 0) ?x724)))
(let (($x28 (or false false)))
(let (($x1282 (or $x28 false)))
(let (($x21728 (or $x1282 false false)))
(let (($x327 (or $x28 false false)))
(let (($x1534 (or $x327 $x21728 false)))
(let (($x40750 (or $x1534 false)))
(and (not $x40750) (or $x40750 (and (distinct ?x41816 ?x41816) true)))))))))))))))))
(check-sat)
; query 67: function crcu8, block 6, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x28 (or false false)))
(let (($x83 (not $x28)))
(and $x83 (or $x28 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 68: function crcu8, block 6, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1171 ((_ zero_extend 24) in.0_8)))
(let ((?x17928 (bvashr ?x1171 (_ bv1 32))))
(let (($x28 (or false false)))
(let (($x327 (or $x28 false false)))
(let (($x39796 (or $x327 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not $x39796) (or $x39796 (and (distinct ?x17928 ?x17928) true)))))))))
(check-sat)
; query 69: function crcu8, block 6, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1171 ((_ zero_extend 24) in.0_8)))
(let ((?x17928 (bvashr ?x1171 (_ bv1 32))))
(let ((?x17725 ((_ extract 7 0) ?x17928)))
(let (($x28 (or false false)))
(let (($x327 (or $x28 false false)))
(let (($x39796 (or $x327 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x2134 (or $x39796 false)))
(and (not $x2134) (or $x2134 (and (distinct ?x17725 ?x17725) true)))))))))))
(check-sat)
; query 70: function crcu8, block 6, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x43716 ((_ extract 7 0) in.01_16)))
(let ((?x731 ((_ zero_extend 24) ?x43716)))
(let ((?x11015 (bvand ?x731 (_ bv1 32))))
(let ((?x1171 ((_ zero_extend 24) in.0_8)))
(let ((?x42401 (bvand ?x1171 (_ bv1 32))))
(let ((?x724 (bvxor ?x42401 ?x11015)))
(let ((?x41816 ((_ extract 7 0) ?x724)))
(let ((?x746 ((_ zero_extend 24) ?x41816)))
(let (($x28 (or false false)))
(let (($x1282 (or $x28 false)))
(let (($x21728 (or $x1282 false false)))
(let (($x327 (or $x28 false false)))
(let (($x1534 (or $x327 $x21728 false)))
(let (($x40750 (or $x1534 false)))
(let (($x874 (or $x40750 false)))
(and (not $x874) (or $x874 (and (distinct ?x746 ?x746) true)))))))))))))))))))
(check-sat)
; query 71: function crcu8, block 6, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x43716 ((_ extract 7 0) in.01_16)))
(let ((?x731 ((_ zero_extend 24) ?x43716)))
(let ((?x11015 (bvand ?x731 (_ bv1 32))))
(let ((?x1171 ((_ zero_extend 24) in.0_8)))
(let ((?x42401 (bvand ?x1171 (_ bv1 32))))
(let ((?x724 (bvxor ?x42401 ?x11015)))
(let ((?x41816 ((_ extract 7 0) ?x724)))
(let ((?x746 ((_ zero_extend 24) ?x41816)))
(let ((?x21087 (ite (= (_ bv1 32) ?x746) (_ bv1 1) (_ bv0 1))))
(let (($x28 (or false false)))
(let (($x1282 (or $x28 false)))
(let (($x21728 (or $x1282 false false)))
(let (($x327 (or $x28 false false)))
(let (($x1534 (or $x327 $x21728 false)))
(let (($x40750 (or $x1534 false)))
(let (($x874 (or $x40750 false)))
(let (($x318 (or $x874 false false)))
(and (not $x318) (or $x318 (and (distinct ?x21087 ?x21087) true)))))))))))))))))))))
(check-sat)
; query 72: function crcu8, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x28 (or false false)))
(let (($x83 (not $x28)))
(and $x83 (or $x28 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 73: function crcu8, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1171 ((_ zero_extend 24) in.0_8)))
(let ((?x42401 (bvand ?x1171 (_ bv1 32))))
(let (($x28 (or false false)))
(let (($x327 (or $x28 false false)))
(let (($x858 (not $x327)))
(and $x858 (or $x327 (and (distinct ?x42401 ?x42401) true)))))))))
(check-sat)
; query 74: function crcu8, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x28 (or false false)))
(let (($x83 (not $x28)))
(and $x83 (or $x28 (and (distinct ((_ extract 7 0) in.01_16) ((_ extract 7 0) in.01_16)) true))))))
(check-sat)
; query 75: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x21386 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x18 (or false false false)))
(let (($x64 (not $x18)))
(and $x64 (or $x18 (and (distinct ?x21386 ?x21386) true)))))))
(check-sat)
; query 76: function matrix_add_const, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x18 (or false false false)))
(let (($x64 (not $x18)))
(and $x64 (or $x18 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 77: function matrix_add_const, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1952 (bvadd in.01_32 (_ bv1 32))))
(let (($x38916 (and (distinct ?x1952 ?x1952) true)))
(let (($x18 (or false false false)))
(let (($x64 (not $x18)))
(and $x64 (or $x18 $x38916)))))))
(check-sat)
; query 78: function matrix_mul_const, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x18 (or false false false)))
(let (($x64 (not $x18)))
(and $x64 (or $x18 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 79: function matrix_mul_const, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1952 (bvadd in.01_32 (_ bv1 32))))
(let (($x38916 (and (distinct ?x1952 ?x1952) true)))
(let (($x18 (or false false false)))
(let (($x64 (not $x18)))
(and $x64 (or $x18 $x38916)))))))
(check-sat)
; query 80: function matrix_mul_matrix, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x18 (or false false false)))
(let (($x64 (not $x18)))
(and $x64 (or $x18 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 81: function matrix_mul_matrix, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1952 (bvadd in.01_32 (_ bv1 32))))
(let (($x38916 (and (distinct ?x1952 ?x1952) true)))
(let (($x18 (or false false false)))
(let (($x64 (not $x18)))
(and $x64 (or $x18 $x38916)))))))
(check-sat)
; query 82: function matrix_mul_matrix, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x18 (or false false false)))
(let (($x64 (not $x18)))
(and $x64 (or $x18 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 83: function matrix_mul_matrix_bitextract, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x18 (or false false false)))
(let (($x64 (not $x18)))
(and $x64 (or $x18 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 84: function matrix_mul_matrix_bitextract, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1952 (bvadd in.01_32 (_ bv1 32))))
(let (($x38916 (and (distinct ?x1952 ?x1952) true)))
(let (($x18 (or false false false)))
(let (($x64 (not $x18)))
(and $x64 (or $x18 $x38916)))))))
(check-sat)
; query 85: function matrix_mul_matrix_bitextract, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x18 (or false false false)))
(let (($x64 (not $x18)))
(and $x64 (or $x18 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 86: function matrix_mul_vect, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x18 (or false false false)))
(let (($x64 (not $x18)))
(and $x64 (or $x18 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 87: function matrix_mul_vect, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1952 (bvadd in.01_32 (_ bv1 32))))
(let (($x38916 (and (distinct ?x1952 ?x1952) true)))
(let (($x18 (or false false false)))
(let (($x64 (not $x18)))
(and $x64 (or $x18 $x38916)))))))
(check-sat)
; query 88: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x28 (or false false)))
(let (($x83 (not $x28)))
(and $x83 (or $x28 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 89: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x12265 ((_ sign_extend 16) in.1_16)))
(let ((?x15286 (bvadd ?x12265 (_ bv10 32))))
(let (($x19718 (and (distinct (bvadd ((_ sign_extend 1) ?x12265) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x15286)) true)))
(let (($x28 (or false false)))
(let (($x1487 (or $x28 false (or $x19718))))
(and (not $x1487) (or $x1487 (and (distinct ?x15286 ?x15286) true)))))))))
(check-sat)
; query 90: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x12265 ((_ sign_extend 16) in.1_16)))
(let ((?x15286 (bvadd ?x12265 (_ bv10 32))))
(let ((?x41851 ((_ extract 15 0) ?x15286)))
(let (($x19718 (and (distinct (bvadd ((_ sign_extend 1) ?x12265) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x15286)) true)))
(let (($x28 (or false false)))
(let (($x1487 (or $x28 false (or $x19718))))
(let (($x9136 (or $x1487 false)))
(and (not $x9136) (or $x9136 (and (distinct ?x41851 ?x41851) true)))))))))))
(check-sat)
; query 91: function partition_memory, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x18 (or false false false)))
(let (($x64 (not $x18)))
(and $x64 (or $x18 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
