; OptiPhase-Sigma refinement certificate for sweep K58-R3-171
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x337 (or false false)))
(let (($x759 (not $x337)))
(and $x759 (or $x337 (and (distinct ((_ sign_extend 16) in25_16) ((_ sign_extend 16) in25_16)) true))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let ((?x251 (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))))
(let (($x337 (or false false)))
(let (($x854 (or $x337 false false)))
(let (($x608 (not $x854)))
(and $x608 (or $x854 (and (distinct ?x251 ?x251) true))))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x337 (or false false)))
(let (($x759 (not $x337)))
(and $x759 (or $x337 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x81 ((_ sign_extend 16) in3_16)))
(let ((?x34 (bvand ?x81 (_ bv127 32))))
(let (($x337 (or false false)))
(let (($x854 (or $x337 false false)))
(let (($x608 (not $x854)))
(and $x608 (or $x854 (and (distinct ?x34 ?x34) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x81 ((_ sign_extend 16) in3_16)))
(let ((?x34 (bvand ?x81 (_ bv127 32))))
(let ((?x675 ((_ extract 15 0) ?x34)))
(let (($x337 (or false false)))
(let (($x854 (or $x337 false false)))
(let (($x717 (or $x854 false)))
(let (($x1042 (not $x717)))
(and $x1042 (or $x717 (and (distinct ?x675 ?x675) true)))))))))))
(check-sat)
; query 5: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x337 (or false false)))
(let (($x759 (not $x337)))
(and $x759 (or $x337 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 6: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x385 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x337 (or false false)))
(let (($x854 (or $x337 false false)))
(let (($x608 (not $x854)))
(and $x608 (or $x854 (and (distinct ?x385 ?x385) true))))))))
(check-sat)
; query 7: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x234 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x191 (or false false false)))
(let (($x1125 (not $x191)))
(and $x1125 (or $x191 (and (distinct ?x234 ?x234) true)))))))
(check-sat)
; query 8: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x191 (or false false false)))
(let (($x1125 (not $x191)))
(and $x1125 (or $x191 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 9: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x114 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x191 (or false false false)))
(let (($x1125 (not $x191)))
(and $x1125 (or $x191 (and (distinct ?x114 ?x114) true)))))))
(check-sat)
; query 10: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1103 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x710 ((_ zero_extend 31) ?x1103)))
(let ((?x16 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x31 ((_ zero_extend 31) ?x16)))
(let ((?x844 (bvand ?x31 ?x710)))
(let ((?x518 (ite (and (distinct (_ bv0 32) ?x844) true) (_ bv1 1) (_ bv0 1))))
(let ((?x917 ((_ zero_extend 63) ?x518)))
(let (($x337 (or false false)))
(let (($x854 (or $x337 false false)))
(let (($x717 (or $x854 false)))
(let (($x69 (or $x717 $x717 false)))
(let (($x98 (or $x69 false false)))
(let (($x1034 (or $x98 false)))
(and (not $x1034) (or $x1034 (and (distinct ?x917 ?x917) true)))))))))))))))))
(check-sat)
; query 11: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1103 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x710 ((_ zero_extend 31) ?x1103)))
(let ((?x16 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x31 ((_ zero_extend 31) ?x16)))
(let ((?x844 (bvand ?x31 ?x710)))
(let ((?x518 (ite (and (distinct (_ bv0 32) ?x844) true) (_ bv1 1) (_ bv0 1))))
(let (($x696 (= (_ bv1 1) ?x518)))
(let ((?x148 (ite $x696 (_ bv1 32) (_ bv0 32))))
(let (($x337 (or false false)))
(let (($x854 (or $x337 false false)))
(let (($x717 (or $x854 false)))
(let (($x69 (or $x717 $x717 false)))
(let (($x98 (or $x69 false false)))
(let (($x36 (or $x98 (ite $x696 false false))))
(and (not $x36) (or $x36 (and (distinct ?x148 ?x148) true))))))))))))))))))
(check-sat)
; query 12: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1103 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x710 ((_ zero_extend 31) ?x1103)))
(let ((?x16 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x31 ((_ zero_extend 31) ?x16)))
(let ((?x844 (bvand ?x31 ?x710)))
(let ((?x518 (ite (and (distinct (_ bv0 32) ?x844) true) (_ bv1 1) (_ bv0 1))))
(let (($x696 (= (_ bv1 1) ?x518)))
(let ((?x148 (ite $x696 (_ bv1 32) (_ bv0 32))))
(let ((?x72 ((_ extract 7 0) ?x148)))
(let (($x337 (or false false)))
(let (($x854 (or $x337 false false)))
(let (($x717 (or $x854 false)))
(let (($x69 (or $x717 $x717 false)))
(let (($x98 (or $x69 false false)))
(let (($x36 (or $x98 (ite $x696 false false))))
(let (($x57 (or $x36 false)))
(and (not $x57) (or $x57 (and (distinct ?x72 ?x72) true))))))))))))))))))))
(check-sat)
; query 13: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x337 (or false false)))
(let (($x759 (not $x337)))
(and $x759 (or $x337 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 14: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x16 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x337 (or false false)))
(let (($x854 (or $x337 false false)))
(let (($x608 (not $x854)))
(and $x608 (or $x854 (and (distinct ?x16 ?x16) true))))))))
(check-sat)
; query 15: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x16 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x31 ((_ zero_extend 31) ?x16)))
(let (($x337 (or false false)))
(let (($x854 (or $x337 false false)))
(let (($x717 (or $x854 false)))
(let (($x1042 (not $x717)))
(and $x1042 (or $x717 (and (distinct ?x31 ?x31) true))))))))))
(check-sat)
; query 16: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x337 (or false false)))
(let (($x759 (not $x337)))
(and $x759 (or $x337 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 17: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1103 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x337 (or false false)))
(let (($x854 (or $x337 false false)))
(let (($x608 (not $x854)))
(and $x608 (or $x854 (and (distinct ?x1103 ?x1103) true))))))))
(check-sat)
; query 18: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1103 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x710 ((_ zero_extend 31) ?x1103)))
(let (($x337 (or false false)))
(let (($x854 (or $x337 false false)))
(let (($x717 (or $x854 false)))
(let (($x1042 (not $x717)))
(and $x1042 (or $x717 (and (distinct ?x710 ?x710) true))))))))))
(check-sat)
; query 19: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1103 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x710 ((_ zero_extend 31) ?x1103)))
(let ((?x16 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x31 ((_ zero_extend 31) ?x16)))
(let ((?x844 (bvand ?x31 ?x710)))
(let (($x337 (or false false)))
(let (($x854 (or $x337 false false)))
(let (($x717 (or $x854 false)))
(let (($x69 (or $x717 $x717 false)))
(and (not $x69) (or $x69 (and (distinct ?x844 ?x844) true)))))))))))))
(check-sat)
; query 20: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1103 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x710 ((_ zero_extend 31) ?x1103)))
(let ((?x16 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x31 ((_ zero_extend 31) ?x16)))
(let ((?x844 (bvand ?x31 ?x710)))
(let ((?x518 (ite (and (distinct (_ bv0 32) ?x844) true) (_ bv1 1) (_ bv0 1))))
(let (($x337 (or false false)))
(let (($x854 (or $x337 false false)))
(let (($x717 (or $x854 false)))
(let (($x69 (or $x717 $x717 false)))
(let (($x98 (or $x69 false false)))
(and (not $x98) (or $x98 (and (distinct ?x518 ?x518) true)))))))))))))))
(check-sat)
; query 21: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x409 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x191 (or false false false)))
(let (($x1125 (not $x191)))
(and $x1125 (or $x191 (and (distinct ?x409 ?x409) true)))))))
(check-sat)
