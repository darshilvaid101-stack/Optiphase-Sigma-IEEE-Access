; OptiPhase-Sigma refinement certificate for sweep K30-R4-367
; query 0: function bit_count, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x180 (and (distinct (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1)) (ite (= (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x244 (or false false false)))
(let (($x224 (not $x244)))
(and $x224 (or $x244 $x180))))))
(check-sat)
; query 1: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x223 (ite (bvsgt (_ bv2 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x244 (or false false false)))
(let (($x224 (not $x244)))
(and $x224 (or $x244 (and (distinct ?x223 ?x223) true)))))))
(check-sat)
