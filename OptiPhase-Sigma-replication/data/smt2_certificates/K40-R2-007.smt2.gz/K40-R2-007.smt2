; OptiPhase-Sigma refinement certificate for sweep K40-R2-007
; query 0: function decfile, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in17_32 () (_ BitVec 32))
(assert
 (let ((?x156 (ite (and (distinct (_ bv16 32) in17_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x222 (or false false false)))
(let (($x326 (not $x222)))
(and $x326 (or $x222 (and (distinct ?x156 ?x156) true)))))))
(check-sat)
; query 1: function decfile, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x79 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x279 (or false false (or $x79))))
(and (not $x279) (or $x279 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function decfile, block 82, name %83
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x40 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x124 (or false false (or $x40))))
(and (not $x124) (or $x124 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 3: function decfile, block 85, name %86
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x531 (ite (= (_ bv15 32) in.01.lcssa_32) (_ bv1 1) (_ bv0 1))))
(let (($x222 (or false false false)))
(let (($x326 (not $x222)))
(and $x326 (or $x222 (and (distinct ?x531 ?x531) true)))))))
(check-sat)
; query 4: function decfile, block 85, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x531 (ite (= (_ bv15 32) in.01.lcssa_32) (_ bv1 1) (_ bv0 1))))
(let ((?x211 ((_ zero_extend 63) ?x531)))
(let (($x222 (or false false false)))
(let (($x555 (or $x222 false)))
(and (not $x555) (or $x555 (and (distinct ?x211 ?x211) true))))))))
(check-sat)
; query 5: function decfile, block 85, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x531 (ite (= (_ bv15 32) in.01.lcssa_32) (_ bv1 1) (_ bv0 1))))
(let (($x50 (= (_ bv1 1) ?x531)))
(let ((?x1011 (ite $x50 (_ bv1 32) (_ bv0 32))))
(let (($x222 (or false false false)))
(let (($x94 (or $x222 (ite $x50 false false))))
(and (not $x94) (or $x94 (and (distinct ?x1011 ?x1011) true)))))))))
(check-sat)
; query 6: function decfile, block 85, name %89
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x531 (ite (= (_ bv15 32) in.01.lcssa_32) (_ bv1 1) (_ bv0 1))))
(let (($x50 (= (_ bv1 1) ?x531)))
(let ((?x1011 (ite $x50 (_ bv1 32) (_ bv0 32))))
(let ((?x9 (bvsub (_ bv1 32) ?x1011)))
(let ((?x73 ((_ sign_extend 1) ?x9)))
(let (($x222 (or false false false)))
(let (($x94 (or $x222 (ite $x50 false false))))
(let (($x494 (or false $x94 (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv1 32)) ((_ sign_extend 1) ?x1011)) ?x73) true)))))
(and (not $x494) (or $x494 (and (distinct ?x9 ?x9) true))))))))))))
(check-sat)
; query 7: function decfile, block 85, name %90
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01.lcssa_32 () (_ BitVec 32))
(declare-fun in46_32 () (_ BitVec 32))
(assert
 (let ((?x531 (ite (= (_ bv15 32) in.01.lcssa_32) (_ bv1 1) (_ bv0 1))))
(let (($x50 (= (_ bv1 1) ?x531)))
(let ((?x1011 (ite $x50 (_ bv1 32) (_ bv0 32))))
(let ((?x9 (bvsub (_ bv1 32) ?x1011)))
(let ((?x119 (bvadd in46_32 ?x9)))
(let (($x117 (and (distinct (bvadd ((_ sign_extend 1) in46_32) ((_ sign_extend 1) ?x9)) ((_ sign_extend 1) ?x119)) true)))
(let ((?x73 ((_ sign_extend 1) ?x9)))
(let (($x222 (or false false false)))
(let (($x94 (or $x222 (ite $x50 false false))))
(let (($x494 (or false $x94 (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv1 32)) ((_ sign_extend 1) ?x1011)) ?x73) true)))))
(let (($x672 (or false $x494 (or $x117))))
(and (not $x672) (or $x672 (and (distinct ?x119 ?x119) true)))))))))))))))
(check-sat)
; query 8: function decfile, block 85, name %91
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01.lcssa_32 () (_ BitVec 32))
(declare-fun in46_32 () (_ BitVec 32))
(assert
 (let ((?x531 (ite (= (_ bv15 32) in.01.lcssa_32) (_ bv1 1) (_ bv0 1))))
(let (($x50 (= (_ bv1 1) ?x531)))
(let ((?x1011 (ite $x50 (_ bv1 32) (_ bv0 32))))
(let ((?x9 (bvsub (_ bv1 32) ?x1011)))
(let ((?x119 (bvadd in46_32 ?x9)))
(let ((?x158 (ite (and (distinct (_ bv0 32) ?x119) true) (_ bv1 1) (_ bv0 1))))
(let (($x117 (and (distinct (bvadd ((_ sign_extend 1) in46_32) ((_ sign_extend 1) ?x9)) ((_ sign_extend 1) ?x119)) true)))
(let ((?x73 ((_ sign_extend 1) ?x9)))
(let (($x222 (or false false false)))
(let (($x94 (or $x222 (ite $x50 false false))))
(let (($x494 (or false $x94 (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv1 32)) ((_ sign_extend 1) ?x1011)) ?x73) true)))))
(let (($x672 (or false $x494 (or $x117))))
(let (($x785 (or $x672 false false)))
(and (not $x785) (or $x785 (and (distinct ?x158 ?x158) true)))))))))))))))))
(check-sat)
; query 9: function encfile, block 50, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_64 () (_ BitVec 64))
(assert
 (let (($x222 (or false false false)))
(let (($x326 (not $x222)))
(and $x326 (or $x222 (and (distinct (bvadd in.1_64 (_ bv1 64)) (bvadd in.1_64 (_ bv1 64))) true))))))
(check-sat)
; query 10: function encfile, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_64 () (_ BitVec 64))
(assert
 (let (($x222 (or false false false)))
(let (($x326 (not $x222)))
(and $x326 (or $x222 (and (distinct (bvadd in.2_64 (_ bv1 64)) (bvadd in.2_64 (_ bv1 64))) true))))))
(check-sat)
; query 11: function encfile, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.5_64 () (_ BitVec 64))
(assert
 (let (($x222 (or false false false)))
(let (($x326 (not $x222)))
(and $x326 (or $x222 (and (distinct (bvadd in.5_64 (_ bv1 64)) (bvadd in.5_64 (_ bv1 64))) true))))))
(check-sat)
; query 12: function fillrand, block 34, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x185 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x101 (or false false (or $x185))))
(and (not $x101) (or $x101 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 13: function main, block 41, name %42
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let (($x100 (or false false)))
(and (not $x100) (or $x100 (and (distinct ((_ sign_extend 24) in38_8) ((_ sign_extend 24) in38_8)) true)))))
(check-sat)
; query 14: function main, block 41, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let ((?x16 (ite (bvsge (_ bv57 32) ((_ sign_extend 24) in38_8)) (_ bv1 1) (_ bv0 1))))
(let (($x100 (or false false)))
(let (($x5 (or $x100 false false)))
(let (($x648 (not $x5)))
(and $x648 (or $x5 (and (distinct ?x16 ?x16) true))))))))
(check-sat)
; query 15: function main, block 44, name %45
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x222 (or false false false)))
(let (($x53 (or $x222 (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x53) (or $x53 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvshl in.01_32 (_ bv4 32))) true))))))
(check-sat)
; query 16: function main, block 44, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let (($x100 (or false false)))
(and (not $x100) (or $x100 (and (distinct ((_ sign_extend 24) in38_8) ((_ sign_extend 24) in38_8)) true)))))
(check-sat)
; query 17: function main, block 44, name %47
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x134 ((_ sign_extend 24) in38_8)))
(let ((?x205 (bvshl in.01_32 (_ bv4 32))))
(let ((?x228 (bvadd ?x205 ?x134)))
(let ((?x333 ((_ sign_extend 1) ?x228)))
(let (($x100 (or false false)))
(let (($x222 (or false false false)))
(let (($x53 (or $x222 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x214 (or $x53 $x100 (or (and (distinct (bvadd ((_ sign_extend 1) ?x205) ((_ sign_extend 1) ?x134)) ?x333) true)))))
(and (not $x214) (or $x214 (and (distinct ?x228 ?x228) true))))))))))))
(check-sat)
; query 18: function main, block 44, name %48
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x134 ((_ sign_extend 24) in38_8)))
(let ((?x205 (bvshl in.01_32 (_ bv4 32))))
(let ((?x228 (bvadd ?x205 ?x134)))
(let ((?x164 (bvsub ?x228 (_ bv48 32))))
(let (($x93 (and (distinct (bvsub ((_ sign_extend 1) ?x228) ((_ sign_extend 1) (_ bv48 32))) ((_ sign_extend 1) ?x164)) true)))
(let ((?x333 ((_ sign_extend 1) ?x228)))
(let (($x100 (or false false)))
(let (($x222 (or false false false)))
(let (($x53 (or $x222 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x214 (or $x53 $x100 (or (and (distinct (bvadd ((_ sign_extend 1) ?x205) ((_ sign_extend 1) ?x134)) ?x333) true)))))
(let (($x227 (or $x214 false (or $x93))))
(and (not $x227) (or $x227 (and (distinct ?x164 ?x164) true)))))))))))))))
(check-sat)
; query 19: function main, block 49, name %50
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let (($x100 (or false false)))
(and (not $x100) (or $x100 (and (distinct ((_ sign_extend 24) in38_8) ((_ sign_extend 24) in38_8)) true)))))
(check-sat)
; query 20: function main, block 49, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let ((?x31 (ite (bvsle (_ bv65 32) ((_ sign_extend 24) in38_8)) (_ bv1 1) (_ bv0 1))))
(let (($x100 (or false false)))
(let (($x5 (or $x100 false false)))
(let (($x648 (not $x5)))
(and $x648 (or $x5 (and (distinct ?x31 ?x31) true))))))))
(check-sat)
; query 21: function main, block 52, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let (($x100 (or false false)))
(and (not $x100) (or $x100 (and (distinct ((_ sign_extend 24) in38_8) ((_ sign_extend 24) in38_8)) true)))))
(check-sat)
; query 22: function main, block 52, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let ((?x230 (ite (bvsge (_ bv70 32) ((_ sign_extend 24) in38_8)) (_ bv1 1) (_ bv0 1))))
(let (($x100 (or false false)))
(let (($x5 (or $x100 false false)))
(let (($x648 (not $x5)))
(and $x648 (or $x5 (and (distinct ?x230 ?x230) true))))))))
(check-sat)
; query 23: function main, block 55, name %56
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x222 (or false false false)))
(let (($x53 (or $x222 (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x53) (or $x53 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvshl in.01_32 (_ bv4 32))) true))))))
(check-sat)
; query 24: function main, block 55, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let (($x100 (or false false)))
(and (not $x100) (or $x100 (and (distinct ((_ sign_extend 24) in38_8) ((_ sign_extend 24) in38_8)) true)))))
(check-sat)
; query 25: function main, block 55, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x134 ((_ sign_extend 24) in38_8)))
(let ((?x205 (bvshl in.01_32 (_ bv4 32))))
(let ((?x228 (bvadd ?x205 ?x134)))
(let ((?x333 ((_ sign_extend 1) ?x228)))
(let (($x100 (or false false)))
(let (($x222 (or false false false)))
(let (($x53 (or $x222 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x214 (or $x53 $x100 (or (and (distinct (bvadd ((_ sign_extend 1) ?x205) ((_ sign_extend 1) ?x134)) ?x333) true)))))
(and (not $x214) (or $x214 (and (distinct ?x228 ?x228) true))))))))))))
(check-sat)
; query 26: function main, block 55, name %59
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x134 ((_ sign_extend 24) in38_8)))
(let ((?x205 (bvshl in.01_32 (_ bv4 32))))
(let ((?x228 (bvadd ?x205 ?x134)))
(let ((?x71 (bvsub ?x228 (_ bv65 32))))
(let ((?x83 ((_ sign_extend 1) ?x71)))
(let ((?x333 ((_ sign_extend 1) ?x228)))
(let (($x100 (or false false)))
(let (($x222 (or false false false)))
(let (($x53 (or $x222 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x214 (or $x53 $x100 (or (and (distinct (bvadd ((_ sign_extend 1) ?x205) ((_ sign_extend 1) ?x134)) ?x333) true)))))
(let (($x54 (or $x214 false (or (and (distinct (bvsub ?x333 ((_ sign_extend 1) (_ bv65 32))) ?x83) true)))))
(and (not $x54) (or $x54 (and (distinct ?x71 ?x71) true)))))))))))))))
(check-sat)
; query 27: function main, block 55, name %60
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x134 ((_ sign_extend 24) in38_8)))
(let ((?x205 (bvshl in.01_32 (_ bv4 32))))
(let ((?x228 (bvadd ?x205 ?x134)))
(let ((?x71 (bvsub ?x228 (_ bv65 32))))
(let ((?x44 (bvadd ?x71 (_ bv10 32))))
(let (($x25 (and (distinct (bvadd ((_ sign_extend 1) ?x71) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x44)) true)))
(let ((?x83 ((_ sign_extend 1) ?x71)))
(let ((?x333 ((_ sign_extend 1) ?x228)))
(let (($x100 (or false false)))
(let (($x222 (or false false false)))
(let (($x53 (or $x222 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x214 (or $x53 $x100 (or (and (distinct (bvadd ((_ sign_extend 1) ?x205) ((_ sign_extend 1) ?x134)) ?x333) true)))))
(let (($x54 (or $x214 false (or (and (distinct (bvsub ?x333 ((_ sign_extend 1) (_ bv65 32))) ?x83) true)))))
(let (($x613 (or $x54 false (or $x25))))
(and (not $x613) (or $x613 (and (distinct ?x44 ?x44) true))))))))))))))))))
(check-sat)
; query 28: function main, block 81, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x317 (ite (bvsgt (_ bv32 32) in.06.lcssa_32) (_ bv1 1) (_ bv0 1))))
(let (($x222 (or false false false)))
(let (($x326 (not $x222)))
(and $x326 (or $x222 (and (distinct ?x317 ?x317) true)))))))
(check-sat)
; query 29: function main, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06.lcssa_32 () (_ BitVec 32))
(assert
 (let (($x222 (or false false false)))
(let (($x862 (or $x222 (and (distinct (bvand in.06.lcssa_32 (_ bv15 32)) (bvand in.06.lcssa_32 (_ bv15 32))) true))))
(let (($x326 (not $x222)))
(and $x326 $x862)))))
(check-sat)
; query 30: function main, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x188 (ite (and (distinct (_ bv0 32) (bvand in.06.lcssa_32 (_ bv15 32))) true) (_ bv1 1) (_ bv0 1))))
(let (($x222 (or false false false)))
(let (($x11 (or $x222 false false)))
(let (($x153 (not $x11)))
(and $x153 (or $x11 (and (distinct ?x188 ?x188) true))))))))
(check-sat)
; query 31: function set_key, block 11, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let (($x222 (or false false false)))
(let (($x326 (not $x222)))
(and $x326 (or $x222 (and (distinct (bvand in2_32 (_ bv1 32)) (bvand in2_32 (_ bv1 32))) true))))))
(check-sat)
; query 32: function set_key, block 11, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x264 (ite (and (distinct (_ bv0 32) (bvand in2_32 (_ bv1 32))) true) (_ bv1 1) (_ bv0 1))))
(let (($x222 (or false false false)))
(let (($x11 (or $x222 false false)))
(let (($x153 (not $x11)))
(and $x153 (or $x11 (and (distinct ?x264 ?x264) true))))))))
(check-sat)
; query 33: function set_key, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let (($x222 (or false false false)))
(let (($x326 (not $x222)))
(and $x326 (or $x222 (and (distinct (bvand in2_32 (_ bv2 32)) (bvand in2_32 (_ bv2 32))) true))))))
(check-sat)
; query 34: function set_key, block 14, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x225 (ite (and (distinct (_ bv0 32) (bvand in2_32 (_ bv2 32))) true) (_ bv1 1) (_ bv0 1))))
(let (($x222 (or false false false)))
(let (($x11 (or $x222 false false)))
(let (($x153 (not $x11)))
(and $x153 (or $x11 (and (distinct ?x225 ?x225) true))))))))
(check-sat)
; query 35: function set_key, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x125 (ite (and (distinct (_ bv0 64) in1_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x222 (or false false false)))
(let (($x326 (not $x222)))
(and $x326 (or $x222 (and (distinct ?x125 ?x125) true)))))))
(check-sat)
; query 36: function set_key, block 514, name %515
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_64 () (_ BitVec 64))
(assert
 (let (($x222 (or false false false)))
(let (($x326 (not $x222)))
(and $x326 (or $x222 (and (distinct (bvadd in.01_64 (_ bv1 64)) (bvadd in.01_64 (_ bv1 64))) true))))))
(check-sat)
; query 37: function set_key, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x496 (ite (bvult in1_64 (_ bv16 64)) (_ bv1 1) (_ bv0 1))))
(let (($x222 (or false false false)))
(let (($x326 (not $x222)))
(and $x326 (or $x222 (and (distinct ?x496 ?x496) true)))))))
(check-sat)
; query 38: function set_key, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x235 (ite (bvugt in1_64 (_ bv32 64)) (_ bv1 1) (_ bv0 1))))
(let (($x222 (or false false false)))
(let (($x326 (not $x222)))
(and $x326 (or $x222 (and (distinct ?x235 ?x235) true)))))))
(check-sat)
; query 39: function set_key, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let (($x222 (or false false false)))
(let (($x326 (not $x222)))
(and $x326 (or $x222 (and (distinct (bvand in1_64 (_ bv7 64)) (bvand in1_64 (_ bv7 64))) true))))))
(check-sat)
; query 40: function set_key, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x149 (ite (and (distinct (_ bv0 64) (bvand in1_64 (_ bv7 64))) true) (_ bv1 1) (_ bv0 1))))
(let (($x222 (or false false false)))
(let (($x11 (or $x222 false false)))
(let (($x153 (not $x11)))
(and $x153 (or $x11 (and (distinct ?x149 ?x149) true))))))))
(check-sat)
