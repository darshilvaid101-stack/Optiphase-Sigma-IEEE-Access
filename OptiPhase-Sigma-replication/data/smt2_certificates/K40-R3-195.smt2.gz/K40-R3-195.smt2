; OptiPhase-Sigma refinement certificate for sweep K40-R3-195
; query 0: function decfile, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in17_32 () (_ BitVec 32))
(assert
 (let ((?x67 (ite (and (distinct (_ bv16 32) in17_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x124 (or false false false)))
(let (($x283 (not $x124)))
(and $x283 (or $x124 (and (distinct ?x67 ?x67) true)))))))
(check-sat)
; query 1: function fillrand, block 34, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x462 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x738 (or false false (or $x462))))
(and (not $x738) (or $x738 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function main, block 41, name %42
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let (($x10 (or false false)))
(and (not $x10) (or $x10 (and (distinct ((_ sign_extend 24) in38_8) ((_ sign_extend 24) in38_8)) true)))))
(check-sat)
; query 3: function main, block 41, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let ((?x122 (ite (bvsge (_ bv57 32) ((_ sign_extend 24) in38_8)) (_ bv1 1) (_ bv0 1))))
(let (($x10 (or false false)))
(let (($x172 (or $x10 false false)))
(let (($x15 (not $x172)))
(and $x15 (or $x172 (and (distinct ?x122 ?x122) true))))))))
(check-sat)
; query 4: function main, block 44, name %45
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x124 (or false false false)))
(let (($x64 (or $x124 (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x64) (or $x64 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvshl in.01_32 (_ bv4 32))) true))))))
(check-sat)
; query 5: function main, block 44, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let (($x10 (or false false)))
(and (not $x10) (or $x10 (and (distinct ((_ sign_extend 24) in38_8) ((_ sign_extend 24) in38_8)) true)))))
(check-sat)
; query 6: function main, block 44, name %47
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x134 ((_ sign_extend 24) in38_8)))
(let ((?x318 (bvshl in.01_32 (_ bv4 32))))
(let ((?x60 (bvadd ?x318 ?x134)))
(let ((?x533 ((_ sign_extend 1) ?x60)))
(let (($x10 (or false false)))
(let (($x124 (or false false false)))
(let (($x64 (or $x124 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x416 (or $x64 $x10 (or (and (distinct (bvadd ((_ sign_extend 1) ?x318) ((_ sign_extend 1) ?x134)) ?x533) true)))))
(and (not $x416) (or $x416 (and (distinct ?x60 ?x60) true))))))))))))
(check-sat)
; query 7: function main, block 44, name %48
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x134 ((_ sign_extend 24) in38_8)))
(let ((?x318 (bvshl in.01_32 (_ bv4 32))))
(let ((?x60 (bvadd ?x318 ?x134)))
(let ((?x500 (bvsub ?x60 (_ bv48 32))))
(let (($x175 (and (distinct (bvsub ((_ sign_extend 1) ?x60) ((_ sign_extend 1) (_ bv48 32))) ((_ sign_extend 1) ?x500)) true)))
(let ((?x533 ((_ sign_extend 1) ?x60)))
(let (($x10 (or false false)))
(let (($x124 (or false false false)))
(let (($x64 (or $x124 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x416 (or $x64 $x10 (or (and (distinct (bvadd ((_ sign_extend 1) ?x318) ((_ sign_extend 1) ?x134)) ?x533) true)))))
(let (($x24 (or $x416 false (or $x175))))
(and (not $x24) (or $x24 (and (distinct ?x500 ?x500) true)))))))))))))))
(check-sat)
; query 8: function main, block 49, name %50
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let (($x10 (or false false)))
(and (not $x10) (or $x10 (and (distinct ((_ sign_extend 24) in38_8) ((_ sign_extend 24) in38_8)) true)))))
(check-sat)
; query 9: function main, block 49, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let ((?x105 (ite (bvsle (_ bv65 32) ((_ sign_extend 24) in38_8)) (_ bv1 1) (_ bv0 1))))
(let (($x10 (or false false)))
(let (($x172 (or $x10 false false)))
(let (($x15 (not $x172)))
(and $x15 (or $x172 (and (distinct ?x105 ?x105) true))))))))
(check-sat)
; query 10: function main, block 52, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let (($x10 (or false false)))
(and (not $x10) (or $x10 (and (distinct ((_ sign_extend 24) in38_8) ((_ sign_extend 24) in38_8)) true)))))
(check-sat)
; query 11: function main, block 52, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let ((?x7 (ite (bvsge (_ bv70 32) ((_ sign_extend 24) in38_8)) (_ bv1 1) (_ bv0 1))))
(let (($x10 (or false false)))
(let (($x172 (or $x10 false false)))
(let (($x15 (not $x172)))
(and $x15 (or $x172 (and (distinct ?x7 ?x7) true))))))))
(check-sat)
; query 12: function main, block 55, name %56
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x124 (or false false false)))
(let (($x64 (or $x124 (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x64) (or $x64 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvshl in.01_32 (_ bv4 32))) true))))))
(check-sat)
; query 13: function main, block 55, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let (($x10 (or false false)))
(and (not $x10) (or $x10 (and (distinct ((_ sign_extend 24) in38_8) ((_ sign_extend 24) in38_8)) true)))))
(check-sat)
; query 14: function main, block 55, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x134 ((_ sign_extend 24) in38_8)))
(let ((?x318 (bvshl in.01_32 (_ bv4 32))))
(let ((?x60 (bvadd ?x318 ?x134)))
(let ((?x533 ((_ sign_extend 1) ?x60)))
(let (($x10 (or false false)))
(let (($x124 (or false false false)))
(let (($x64 (or $x124 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x416 (or $x64 $x10 (or (and (distinct (bvadd ((_ sign_extend 1) ?x318) ((_ sign_extend 1) ?x134)) ?x533) true)))))
(and (not $x416) (or $x416 (and (distinct ?x60 ?x60) true))))))))))))
(check-sat)
; query 15: function main, block 55, name %59
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x134 ((_ sign_extend 24) in38_8)))
(let ((?x318 (bvshl in.01_32 (_ bv4 32))))
(let ((?x60 (bvadd ?x318 ?x134)))
(let ((?x285 (bvsub ?x60 (_ bv65 32))))
(let ((?x499 ((_ sign_extend 1) ?x285)))
(let ((?x533 ((_ sign_extend 1) ?x60)))
(let (($x10 (or false false)))
(let (($x124 (or false false false)))
(let (($x64 (or $x124 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x416 (or $x64 $x10 (or (and (distinct (bvadd ((_ sign_extend 1) ?x318) ((_ sign_extend 1) ?x134)) ?x533) true)))))
(let (($x39 (or $x416 false (or (and (distinct (bvsub ?x533 ((_ sign_extend 1) (_ bv65 32))) ?x499) true)))))
(and (not $x39) (or $x39 (and (distinct ?x285 ?x285) true)))))))))))))))
(check-sat)
; query 16: function main, block 55, name %60
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x134 ((_ sign_extend 24) in38_8)))
(let ((?x318 (bvshl in.01_32 (_ bv4 32))))
(let ((?x60 (bvadd ?x318 ?x134)))
(let ((?x285 (bvsub ?x60 (_ bv65 32))))
(let ((?x20 (bvadd ?x285 (_ bv10 32))))
(let (($x43 (and (distinct (bvadd ((_ sign_extend 1) ?x285) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x20)) true)))
(let ((?x499 ((_ sign_extend 1) ?x285)))
(let ((?x533 ((_ sign_extend 1) ?x60)))
(let (($x10 (or false false)))
(let (($x124 (or false false false)))
(let (($x64 (or $x124 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x416 (or $x64 $x10 (or (and (distinct (bvadd ((_ sign_extend 1) ?x318) ((_ sign_extend 1) ?x134)) ?x533) true)))))
(let (($x39 (or $x416 false (or (and (distinct (bvsub ?x533 ((_ sign_extend 1) (_ bv65 32))) ?x499) true)))))
(let (($x96 (or $x39 false (or $x43))))
(and (not $x96) (or $x96 (and (distinct ?x20 ?x20) true))))))))))))))))))
(check-sat)
; query 17: function set_key, block 11, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let (($x124 (or false false false)))
(let (($x283 (not $x124)))
(and $x283 (or $x124 (and (distinct (bvand in2_32 (_ bv1 32)) (bvand in2_32 (_ bv1 32))) true))))))
(check-sat)
; query 18: function set_key, block 11, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x508 (ite (and (distinct (_ bv0 32) (bvand in2_32 (_ bv1 32))) true) (_ bv1 1) (_ bv0 1))))
(let (($x124 (or false false false)))
(let (($x83 (or $x124 false false)))
(let (($x42 (not $x83)))
(and $x42 (or $x83 (and (distinct ?x508 ?x508) true))))))))
(check-sat)
; query 19: function set_key, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let (($x124 (or false false false)))
(let (($x283 (not $x124)))
(and $x283 (or $x124 (and (distinct (bvand in2_32 (_ bv2 32)) (bvand in2_32 (_ bv2 32))) true))))))
(check-sat)
; query 20: function set_key, block 14, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x72 (ite (and (distinct (_ bv0 32) (bvand in2_32 (_ bv2 32))) true) (_ bv1 1) (_ bv0 1))))
(let (($x124 (or false false false)))
(let (($x83 (or $x124 false false)))
(let (($x42 (not $x83)))
(and $x42 (or $x83 (and (distinct ?x72 ?x72) true))))))))
(check-sat)
; query 21: function set_key, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x155 (ite (and (distinct (_ bv0 64) in1_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x124 (or false false false)))
(let (($x283 (not $x124)))
(and $x283 (or $x124 (and (distinct ?x155 ?x155) true)))))))
(check-sat)
; query 22: function set_key, block 514, name %515
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_64 () (_ BitVec 64))
(assert
 (let (($x124 (or false false false)))
(let (($x283 (not $x124)))
(and $x283 (or $x124 (and (distinct (bvadd in.01_64 (_ bv1 64)) (bvadd in.01_64 (_ bv1 64))) true))))))
(check-sat)
; query 23: function set_key, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x256 (ite (bvult in1_64 (_ bv16 64)) (_ bv1 1) (_ bv0 1))))
(let (($x124 (or false false false)))
(let (($x283 (not $x124)))
(and $x283 (or $x124 (and (distinct ?x256 ?x256) true)))))))
(check-sat)
; query 24: function set_key, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1750 (ite (bvugt in1_64 (_ bv32 64)) (_ bv1 1) (_ bv0 1))))
(let (($x124 (or false false false)))
(let (($x283 (not $x124)))
(and $x283 (or $x124 (and (distinct ?x1750 ?x1750) true)))))))
(check-sat)
; query 25: function set_key, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let (($x124 (or false false false)))
(let (($x283 (not $x124)))
(and $x283 (or $x124 (and (distinct (bvand in1_64 (_ bv7 64)) (bvand in1_64 (_ bv7 64))) true))))))
(check-sat)
; query 26: function set_key, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x287 (ite (and (distinct (_ bv0 64) (bvand in1_64 (_ bv7 64))) true) (_ bv1 1) (_ bv0 1))))
(let (($x124 (or false false false)))
(let (($x83 (or $x124 false false)))
(let (($x42 (not $x83)))
(and $x42 (or $x83 (and (distinct ?x287 ?x287) true))))))))
(check-sat)
