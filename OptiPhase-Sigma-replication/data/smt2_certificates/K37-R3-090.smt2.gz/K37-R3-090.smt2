; OptiPhase-Sigma refinement certificate for sweep K37-R3-090
