; OptiPhase-Sigma refinement certificate for sweep K32-R4-358
