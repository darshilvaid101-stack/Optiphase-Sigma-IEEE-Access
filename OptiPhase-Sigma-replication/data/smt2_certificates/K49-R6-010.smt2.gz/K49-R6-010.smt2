; OptiPhase-Sigma refinement certificate for sweep K49-R6-010
; query 0: function APCM_inverse_quantization, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x125 (or false false)))
(let (($x45 (not $x125)))
(and $x45 (or $x125 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 1: function APCM_inverse_quantization, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x142 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x125 (or false false)))
(let (($x165 (or $x125 false false)))
(let (($x96 (not $x165)))
(and $x96 (or $x165 (and (distinct ?x142 ?x142) true))))))))
(check-sat)
; query 2: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x125 (or false false)))
(let (($x45 (not $x125)))
(and $x45 (or $x125 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 3: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x37 (ite (bvslt (_ bv15 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x125 (or false false)))
(let (($x165 (or $x125 false false)))
(let (($x96 (not $x165)))
(and $x96 (or $x165 (and (distinct ?x37 ?x37) true))))))))
(check-sat)
; query 4: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x125 (or false false)))
(let (($x45 (not $x125)))
(and $x45 (or $x125 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 5: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x153 (ite (bvsgt (_ bv40 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x125 (or false false)))
(let (($x165 (or $x125 false false)))
(let (($x96 (not $x165)))
(and $x96 (or $x165 (and (distinct ?x153 ?x153) true))))))))
(check-sat)
; query 6: function RPE_grid_positioning, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x125 (or false false)))
(let (($x45 (not $x125)))
(and $x45 (or $x125 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 7: function RPE_grid_positioning, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x134 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x107 (and (distinct ?x134 ?x134) true)))
(let (($x125 (or false false)))
(let (($x132 (or false $x125 false)))
(and (not $x132) (or $x132 $x107)))))))
(check-sat)
; query 8: function gsm_L_add, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x73 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x200 (or false false false)))
(let (($x75 (not $x200)))
(and $x75 (or $x200 (and (distinct ?x73 ?x73) true)))))))
(check-sat)
; query 9: function gsm_L_add, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x347 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvadd in0_64 in1_64))) true)))
(let (($x22 (or false false (or $x347))))
(let (($x152 (or $x22 (and (distinct (bvadd in0_64 in1_64) (bvadd in0_64 in1_64)) true))))
(and (not $x22) $x152)))))
(check-sat)
; query 10: function gsm_L_add, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x624 (bvadd in0_64 (_ bv1 64))))
(let ((?x90 (bvsub (_ bv0 64) ?x624)))
(let (($x20 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x624)) ((_ sign_extend 1) ?x90)) true)))
(let ((?x161 ((_ sign_extend 1) ?x624)))
(let (($x179 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x161) true)))))
(let (($x164 (or false $x179 (or $x20))))
(and (not $x164) (or $x164 (and (distinct ?x90 ?x90) true))))))))))
(check-sat)
; query 11: function gsm_L_add, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x141 (bvadd in1_64 (_ bv1 64))))
(let ((?x83 ((_ sign_extend 1) ?x141)))
(let (($x131 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x83) true)))))
(and (not $x131) (or $x131 (and (distinct ?x141 ?x141) true)))))))
(check-sat)
; query 12: function gsm_L_add, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x141 (bvadd in1_64 (_ bv1 64))))
(let ((?x10 (bvsub (_ bv0 64) ?x141)))
(let (($x146 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x141)) ((_ sign_extend 1) ?x10)) true)))
(let ((?x83 ((_ sign_extend 1) ?x141)))
(let (($x131 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x83) true)))))
(let (($x144 (or false $x131 (or $x146))))
(and (not $x144) (or $x144 (and (distinct ?x10 ?x10) true))))))))))
(check-sat)
; query 13: function gsm_L_add, block 8, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x141 (bvadd in1_64 (_ bv1 64))))
(let ((?x10 (bvsub (_ bv0 64) ?x141)))
(let ((?x624 (bvadd in0_64 (_ bv1 64))))
(let ((?x90 (bvsub (_ bv0 64) ?x624)))
(let ((?x900 (bvadd ?x90 ?x10)))
(let (($x146 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x141)) ((_ sign_extend 1) ?x10)) true)))
(let ((?x83 ((_ sign_extend 1) ?x141)))
(let (($x131 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x83) true)))))
(let (($x144 (or false $x131 (or $x146))))
(let (($x20 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x624)) ((_ sign_extend 1) ?x90)) true)))
(let ((?x161 ((_ sign_extend 1) ?x624)))
(let (($x179 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x161) true)))))
(let (($x164 (or false $x179 (or $x20))))
(let (($x160 (or $x164 $x144 false)))
(and (not $x160) (or $x160 (and (distinct ?x900 ?x900) true))))))))))))))))))
(check-sat)
; query 14: function gsm_L_add, block 8, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x141 (bvadd in1_64 (_ bv1 64))))
(let ((?x10 (bvsub (_ bv0 64) ?x141)))
(let ((?x624 (bvadd in0_64 (_ bv1 64))))
(let ((?x90 (bvsub (_ bv0 64) ?x624)))
(let ((?x900 (bvadd ?x90 ?x10)))
(let ((?x74 (ite (bvuge ?x900 (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x146 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x141)) ((_ sign_extend 1) ?x10)) true)))
(let ((?x83 ((_ sign_extend 1) ?x141)))
(let (($x131 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x83) true)))))
(let (($x144 (or false $x131 (or $x146))))
(let (($x20 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x624)) ((_ sign_extend 1) ?x90)) true)))
(let ((?x161 ((_ sign_extend 1) ?x624)))
(let (($x179 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x161) true)))))
(let (($x164 (or false $x179 (or $x20))))
(let (($x160 (or $x164 $x144 false)))
(let (($x133 (or $x160 false false)))
(and (not $x133) (or $x133 (and (distinct ?x74 ?x74) true))))))))))))))))))))
(check-sat)
; query 15: function gsm_L_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x624 (bvadd in0_64 (_ bv1 64))))
(let ((?x161 ((_ sign_extend 1) ?x624)))
(let (($x179 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x161) true)))))
(and (not $x179) (or $x179 (and (distinct ?x624 ?x624) true)))))))
(check-sat)
; query 16: function gsm_L_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x297 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x200 (or false false false)))
(let (($x75 (not $x200)))
(and $x75 (or $x200 (and (distinct ?x297 ?x297) true)))))))
(check-sat)
; query 17: function gsm_L_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x82 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x200 (or false false false)))
(let (($x75 (not $x200)))
(and $x75 (or $x200 (and (distinct ?x82 ?x82) true)))))))
(check-sat)
; query 18: function gsm_L_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x297 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x200 (or false false false)))
(let (($x75 (not $x200)))
(and $x75 (or $x200 (and (distinct ?x297 ?x297) true)))))))
(check-sat)
; query 19: function gsm_L_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x297 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x298 ((_ zero_extend 31) ?x297)))
(let (($x200 (or false false false)))
(let (($x188 (or $x200 false)))
(and (not $x188) (or $x188 (and (distinct ?x298 ?x298) true))))))))
(check-sat)
; query 20: function gsm_L_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x297 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x298 ((_ zero_extend 31) ?x297)))
(let ((?x169 (bvsub (_ bv0 32) ?x298)))
(let (($x32 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x298)) ((_ sign_extend 1) ?x169)) true)))
(let (($x200 (or false false false)))
(let (($x188 (or $x200 false)))
(let (($x117 (or false $x188 (or $x32))))
(and (not $x117) (or $x117 (and (distinct ?x169 ?x169) true)))))))))))
(check-sat)
; query 21: function gsm_L_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x297 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x298 ((_ zero_extend 31) ?x297)))
(let ((?x169 (bvsub (_ bv0 32) ?x298)))
(let ((?x538 ((_ sign_extend 32) ?x169)))
(let (($x32 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x298)) ((_ sign_extend 1) ?x169)) true)))
(let (($x200 (or false false false)))
(let (($x188 (or $x200 false)))
(let (($x117 (or false $x188 (or $x32))))
(let (($x122 (or $x117 false)))
(and (not $x122) (or $x122 (and (distinct ?x538 ?x538) true)))))))))))))
(check-sat)
; query 22: function gsm_L_asr, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x140 (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x200 (or false false false)))
(let (($x75 (not $x200)))
(and $x75 (or $x200 (and (distinct ?x140 ?x140) true)))))))
(check-sat)
; query 23: function gsm_L_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x82 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x200 (or false false false)))
(let (($x75 (not $x200)))
(and $x75 (or $x200 (and (distinct ?x82 ?x82) true)))))))
(check-sat)
; query 24: function gsm_L_sub, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x73 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x200 (or false false false)))
(let (($x75 (not $x200)))
(and $x75 (or $x200 (and (distinct ?x73 ?x73) true)))))))
(check-sat)
; query 25: function gsm_L_sub, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x173 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvsub in0_64 in1_64))) true)))
(let (($x184 (or false false (or $x173))))
(let (($x12 (or $x184 (and (distinct (bvsub in0_64 in1_64) (bvsub in0_64 in1_64)) true))))
(and (not $x184) $x12)))))
(check-sat)
; query 26: function gsm_L_sub, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x141 (bvadd in1_64 (_ bv1 64))))
(let ((?x10 (bvsub (_ bv0 64) ?x141)))
(let (($x146 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x141)) ((_ sign_extend 1) ?x10)) true)))
(let ((?x83 ((_ sign_extend 1) ?x141)))
(let (($x131 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x83) true)))))
(let (($x144 (or false $x131 (or $x146))))
(and (not $x144) (or $x144 (and (distinct ?x10 ?x10) true))))))))))
(check-sat)
; query 27: function gsm_L_sub, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x141 (bvadd in1_64 (_ bv1 64))))
(let ((?x10 (bvsub (_ bv0 64) ?x141)))
(let ((?x51 (bvadd in0_64 ?x10)))
(let (($x146 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x141)) ((_ sign_extend 1) ?x10)) true)))
(let ((?x83 ((_ sign_extend 1) ?x141)))
(let (($x131 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x83) true)))))
(let (($x144 (or false $x131 (or $x146))))
(let (($x24 (or false $x144 false)))
(and (not $x24) (or $x24 (and (distinct ?x51 ?x51) true))))))))))))
(check-sat)
; query 28: function gsm_L_sub, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x8 (ite (bvuge (bvadd in0_64 (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64)))) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x146 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) (bvadd in1_64 (_ bv1 64)))) ((_ sign_extend 1) (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64))))) true)))
(let ((?x141 (bvadd in1_64 (_ bv1 64))))
(let ((?x83 ((_ sign_extend 1) ?x141)))
(let (($x131 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x83) true)))))
(let (($x144 (or false $x131 (or $x146))))
(let (($x24 (or false $x144 false)))
(let (($x1071 (or $x24 false false)))
(and (not $x1071) (or $x1071 (and (distinct ?x8 ?x8) true))))))))))))
(check-sat)
; query 29: function gsm_L_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x141 (bvadd in1_64 (_ bv1 64))))
(let ((?x83 ((_ sign_extend 1) ?x141)))
(let (($x131 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x83) true)))))
(and (not $x131) (or $x131 (and (distinct ?x141 ?x141) true)))))))
(check-sat)
; query 30: function gsm_L_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x597 (ite (bvsle (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x200 (or false false false)))
(let (($x75 (not $x200)))
(and $x75 (or $x200 (and (distinct ?x597 ?x597) true)))))))
(check-sat)
; query 31: function gsm_abs, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x125 (or false false)))
(let (($x45 (not $x125)))
(and $x45 (or $x125 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 32: function gsm_abs, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x616 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x125 (or false false)))
(let (($x165 (or $x125 false false)))
(let (($x96 (not $x165)))
(and $x96 (or $x165 (and (distinct ?x616 ?x616) true))))))))
(check-sat)
; query 33: function gsm_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x125 (or false false)))
(let (($x45 (not $x125)))
(and $x45 (or $x125 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 34: function gsm_add, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x125 (or false false)))
(let (($x45 (not $x125)))
(and $x45 (or $x125 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 35: function gsm_add, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x463 ((_ sign_extend 48) in1_16)))
(let ((?x182 ((_ sign_extend 48) in0_16)))
(let ((?x587 (bvadd ?x182 ?x463)))
(let (($x29 (and (distinct (bvadd ((_ sign_extend 1) ?x182) ((_ sign_extend 1) ?x463)) ((_ sign_extend 1) ?x587)) true)))
(let (($x125 (or false false)))
(let (($x170 (or $x125 $x125 (or $x29))))
(and (not $x170) (or $x170 (and (distinct ?x587 ?x587) true))))))))))
(check-sat)
; query 36: function gsm_add, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x196 (ite (bvsgt (_ bv18446744073709518848 64) (bvadd ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x463 ((_ sign_extend 48) in1_16)))
(let ((?x157 ((_ sign_extend 1) ?x463)))
(let ((?x182 ((_ sign_extend 48) in0_16)))
(let ((?x48 ((_ sign_extend 1) ?x182)))
(let (($x125 (or false false)))
(let (($x170 (or $x125 $x125 (or (and (distinct (bvadd ?x48 ?x157) ((_ sign_extend 1) (bvadd ?x182 ?x463))) true)))))
(let (($x584 (or $x170 false false)))
(and (not $x584) (or $x584 (and (distinct ?x196 ?x196) true))))))))))))
(check-sat)
; query 37: function gsm_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x706 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x200 (or false false false)))
(let (($x75 (not $x200)))
(and $x75 (or $x200 (and (distinct ?x706 ?x706) true)))))))
(check-sat)
; query 38: function gsm_asr, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x5 (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x200 (or false false false)))
(let (($x75 (not $x200)))
(and $x75 (or $x200 (and (distinct ?x5 ?x5) true)))))))
(check-sat)
; query 39: function gsm_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x125 (or false false)))
(let (($x45 (not $x125)))
(and $x45 (or $x125 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 40: function gsm_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x616 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x125 (or false false)))
(let (($x165 (or $x125 false false)))
(let (($x96 (not $x165)))
(and $x96 (or $x165 (and (distinct ?x616 ?x616) true))))))))
(check-sat)
; query 41: function gsm_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x616 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x118 ((_ zero_extend 31) ?x616)))
(let (($x125 (or false false)))
(let (($x165 (or $x125 false false)))
(let (($x774 (or $x165 false)))
(and (not $x774) (or $x774 (and (distinct ?x118 ?x118) true)))))))))
(check-sat)
; query 42: function gsm_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x616 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x118 ((_ zero_extend 31) ?x616)))
(let ((?x113 (bvsub (_ bv0 32) ?x118)))
(let (($x151 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x118)) ((_ sign_extend 1) ?x113)) true)))
(let (($x125 (or false false)))
(let (($x165 (or $x125 false false)))
(let (($x774 (or $x165 false)))
(let (($x177 (or false $x774 (or $x151))))
(and (not $x177) (or $x177 (and (distinct ?x113 ?x113) true))))))))))))
(check-sat)
; query 43: function gsm_asr, block 4, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x616 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x118 ((_ zero_extend 31) ?x616)))
(let ((?x113 (bvsub (_ bv0 32) ?x118)))
(let ((?x760 ((_ extract 15 0) ?x113)))
(let (($x151 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x118)) ((_ sign_extend 1) ?x113)) true)))
(let (($x125 (or false false)))
(let (($x165 (or $x125 false false)))
(let (($x774 (or $x165 false)))
(let (($x177 (or false $x774 (or $x151))))
(let (($x158 (or $x177 false)))
(and (not $x158) (or $x158 (and (distinct ?x760 ?x760) true))))))))))))))
(check-sat)
; query 44: function gsm_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x706 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x200 (or false false false)))
(let (($x75 (not $x200)))
(and $x75 (or $x200 (and (distinct ?x706 ?x706) true)))))))
(check-sat)
; query 45: function gsm_debug_longwords, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in15_32 () (_ BitVec 32))
(assert
 (let ((?x76 (ite (bvslt in15_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x200 (or false false false)))
(let (($x75 (not $x200)))
(and $x75 (or $x200 (and (distinct ?x76 ?x76) true)))))))
(check-sat)
; query 46: function gsm_debug_words, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in16_32 () (_ BitVec 32))
(assert
 (let ((?x381 (ite (bvslt in16_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x200 (or false false false)))
(let (($x75 (not $x200)))
(and $x75 (or $x200 (and (distinct ?x381 ?x381) true)))))))
(check-sat)
; query 47: function gsm_div, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x125 (or false false)))
(let (($x45 (not $x125)))
(and $x45 (or $x125 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 48: function gsm_div, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x125 (or false false)))
(let (($x45 (not $x125)))
(and $x45 (or $x125 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 49: function gsm_div, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x125 (or false false)))
(let (($x45 (not $x125)))
(and $x45 (or $x125 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 50: function gsm_div, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x134 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x107 (and (distinct ?x134 ?x134) true)))
(let (($x125 (or false false)))
(let (($x165 (or $x125 false false)))
(let (($x96 (not $x165)))
(and $x96 (or $x165 $x107))))))))
(check-sat)
; query 51: function gsm_norm, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x829 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x200 (or false false false)))
(let (($x75 (not $x200)))
(and $x75 (or $x200 (and (distinct ?x829 ?x829) true)))))))
(check-sat)
; query 52: function gsm_norm, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x829 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x385 (bvxor ?x829 (_ bv1 1))))
(let (($x200 (or false false false)))
(let (($x462 (or $x200 false false)))
(and (not $x462) (or $x462 (and (distinct ?x385 ?x385) true))))))))
(check-sat)
; query 53: function gsm_norm, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x829 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x385 (bvxor ?x829 (_ bv1 1))))
(let ((?x627 ((_ zero_extend 31) ?x385)))
(let (($x200 (or false false false)))
(let (($x462 (or $x200 false false)))
(let (($x413 (or $x462 false)))
(and (not $x413) (or $x413 (and (distinct ?x627 ?x627) true))))))))))
(check-sat)
; query 54: function gsm_norm, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x829 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x385 (bvxor ?x829 (_ bv1 1))))
(let ((?x627 ((_ zero_extend 31) ?x385)))
(let ((?x309 ((_ sign_extend 32) ?x627)))
(let (($x200 (or false false false)))
(let (($x462 (or $x200 false false)))
(let (($x413 (or $x462 false)))
(let (($x637 (or $x413 false)))
(and (not $x637) (or $x637 (and (distinct ?x309 ?x309) true))))))))))))
(check-sat)
; query 55: function gsm_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x125 (or false false)))
(let (($x45 (not $x125)))
(and $x45 (or $x125 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 56: function gsm_sub, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x125 (or false false)))
(let (($x45 (not $x125)))
(and $x45 (or $x125 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 57: function gsm_sub, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x463 ((_ sign_extend 48) in1_16)))
(let ((?x182 ((_ sign_extend 48) in0_16)))
(let ((?x607 (bvsub ?x182 ?x463)))
(let (($x19 (and (distinct (bvsub ((_ sign_extend 1) ?x182) ((_ sign_extend 1) ?x463)) ((_ sign_extend 1) ?x607)) true)))
(let (($x125 (or false false)))
(let (($x614 (or $x125 $x125 (or $x19))))
(and (not $x614) (or $x614 (and (distinct ?x607 ?x607) true))))))))))
(check-sat)
; query 58: function gsm_sub, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x548 (ite (bvsgt (_ bv18446744073709518848 64) (bvsub ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x463 ((_ sign_extend 48) in1_16)))
(let ((?x157 ((_ sign_extend 1) ?x463)))
(let ((?x182 ((_ sign_extend 48) in0_16)))
(let ((?x48 ((_ sign_extend 1) ?x182)))
(let (($x125 (or false false)))
(let (($x614 (or $x125 $x125 (or (and (distinct (bvsub ?x48 ?x157) ((_ sign_extend 1) (bvsub ?x182 ?x463))) true)))))
(let (($x896 (or $x614 false false)))
(and (not $x896) (or $x896 (and (distinct ?x548 ?x548) true))))))))))))
(check-sat)
