; OptiPhase-Sigma refinement certificate for sweep K45-R6-053
; query 0: function IsPowerOfTwo, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x80 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x161 (or false false false)))
(let (($x475 (not $x161)))
(and $x475 (or $x161 (and (distinct ?x80 ?x80) true)))))))
(check-sat)
; query 1: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x80 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x161 (or false false false)))
(let (($x475 (not $x161)))
(and $x475 (or $x161 (and (distinct ?x80 ?x80) true)))))))
(check-sat)
; query 2: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x192 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x161 (or false false false)))
(let (($x475 (not $x161)))
(and $x475 (or $x161 (and (distinct ?x192 ?x192) true)))))))
(check-sat)
