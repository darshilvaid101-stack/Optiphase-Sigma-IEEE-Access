; OptiPhase-Sigma refinement certificate for sweep K45-R4-325
; query 0: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x145 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x12 (or false false false)))
(let (($x30 (not $x12)))
(and $x30 (or $x12 (and (distinct ?x145 ?x145) true)))))))
(check-sat)
; query 1: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x308 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x12 (or false false false)))
(let (($x30 (not $x12)))
(and $x30 (or $x12 (and (distinct ?x308 ?x308) true)))))))
(check-sat)
