; OptiPhase-Sigma refinement certificate for sweep K32-R5-398
