; OptiPhase-Sigma refinement certificate for sweep K49-R6-020
; query 0: function APCM_inverse_quantization, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x137 (or false false)))
(let (($x121 (not $x137)))
(and $x121 (or $x137 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 1: function APCM_inverse_quantization, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x142 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x137 (or false false)))
(let (($x145 (or $x137 false false)))
(let (($x666 (not $x145)))
(and $x666 (or $x145 (and (distinct ?x142 ?x142) true))))))))
(check-sat)
; query 2: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x137 (or false false)))
(let (($x121 (not $x137)))
(and $x121 (or $x137 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 3: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x246 (ite (bvslt (_ bv15 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x137 (or false false)))
(let (($x145 (or $x137 false false)))
(let (($x666 (not $x145)))
(and $x666 (or $x145 (and (distinct ?x246 ?x246) true))))))))
(check-sat)
; query 4: function Decoding_of_the_coded_Log_Area_Ratios, block 170, name %171
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in167_64 () (_ BitVec 64))
(assert
 (let (($x90 (and (distinct (ite (bvsge (_ bv18446744073709518848 64) in167_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv0 64) in167_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x187 (or false false false)))
(let (($x467 (not $x187)))
(and $x467 (or $x187 $x90))))))
(check-sat)
; query 5: function Decoding_of_the_coded_Log_Area_Ratios, block 268, name %269
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in265_64 () (_ BitVec 64))
(assert
 (let (($x409 (and (distinct (ite (bvsge (_ bv18446744073709518848 64) in265_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv0 64) in265_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x187 (or false false false)))
(let (($x467 (not $x187)))
(and $x467 (or $x187 $x409))))))
(check-sat)
; query 6: function Decoding_of_the_coded_Log_Area_Ratios, block 58, name %59
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in55_64 () (_ BitVec 64))
(assert
 (let (($x13 (and (distinct (ite (bvslt (_ bv0 64) in55_64) (_ bv1 1) (_ bv0 1)) (ite (bvsge (_ bv18446744073709518848 64) in55_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x187 (or false false false)))
(let (($x467 (not $x187)))
(and $x467 (or $x187 $x13))))))
(check-sat)
; query 7: function Decoding_of_the_coded_Log_Area_Ratios, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in6_64 () (_ BitVec 64))
(assert
 (let ((?x96 (ite (bvslt (_ bv0 64) in6_64) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false false)))
(let (($x467 (not $x187)))
(and $x467 (or $x187 (and (distinct ?x96 ?x96) true)))))))
(check-sat)
; query 8: function Decoding_of_the_coded_Log_Area_Ratios, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in6_64 () (_ BitVec 64))
(assert
 (let ((?x96 (ite (bvslt (_ bv0 64) in6_64) (_ bv1 1) (_ bv0 1))))
(let ((?x31 ((_ zero_extend 63) ?x96)))
(let (($x187 (or false false false)))
(let (($x178 (or $x187 false)))
(let (($x1055 (not $x178)))
(and $x1055 (or $x178 (and (distinct ?x31 ?x31) true)))))))))
(check-sat)
; query 9: function Decoding_of_the_coded_Log_Area_Ratios, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in6_64 () (_ BitVec 64))
(assert
 (let ((?x96 (ite (bvslt (_ bv0 64) in6_64) (_ bv1 1) (_ bv0 1))))
(let (($x229 (= (_ bv1 1) ?x96)))
(let ((?x980 (ite $x229 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x187 (or false false false)))
(let (($x97 (or $x187 (ite $x229 false false))))
(and (not $x97) (or $x97 (and (distinct ?x980 ?x980) true)))))))))
(check-sat)
; query 10: function Decoding_of_the_coded_Log_Area_Ratios, block 9, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in6_64 () (_ BitVec 64))
(assert
 (let ((?x96 (ite (bvslt (_ bv0 64) in6_64) (_ bv1 1) (_ bv0 1))))
(let (($x229 (= (_ bv1 1) ?x96)))
(let ((?x980 (ite $x229 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x16 ((_ sign_extend 32) ?x980)))
(let (($x187 (or false false false)))
(let (($x97 (or $x187 (ite $x229 false false))))
(let (($x177 (or $x97 false)))
(and (not $x177) (or $x177 (and (distinct ?x16 ?x16) true)))))))))))
(check-sat)
; query 11: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x137 (or false false)))
(let (($x121 (not $x137)))
(and $x121 (or $x137 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 12: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x2078 (ite (bvsgt (_ bv40 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x137 (or false false)))
(let (($x145 (or $x137 false false)))
(let (($x666 (not $x145)))
(and $x666 (or $x145 (and (distinct ?x2078 ?x2078) true))))))))
(check-sat)
; query 13: function RPE_grid_positioning, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x137 (or false false)))
(let (($x121 (not $x137)))
(and $x121 (or $x137 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 14: function RPE_grid_positioning, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x101 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x69 (and (distinct ?x101 ?x101) true)))
(let (($x137 (or false false)))
(let (($x184 (or false $x137 false)))
(and (not $x184) (or $x184 $x69)))))))
(check-sat)
; query 15: function Reflection_coefficients, block 174, name %175
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in171_64 () (_ BitVec 64))
(assert
 (let ((?x192 (ite (bvslt (_ bv0 64) in171_64) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false false)))
(let (($x467 (not $x187)))
(and $x467 (or $x187 (and (distinct ?x192 ?x192) true)))))))
(check-sat)
; query 16: function Reflection_coefficients, block 174, name %176
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in171_64 () (_ BitVec 64))
(assert
 (let ((?x192 (ite (bvslt (_ bv0 64) in171_64) (_ bv1 1) (_ bv0 1))))
(let ((?x176 ((_ zero_extend 63) ?x192)))
(let (($x187 (or false false false)))
(let (($x178 (or $x187 false)))
(let (($x1055 (not $x178)))
(and $x1055 (or $x178 (and (distinct ?x176 ?x176) true)))))))))
(check-sat)
; query 17: function Reflection_coefficients, block 174, name %177
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in171_64 () (_ BitVec 64))
(assert
 (let ((?x192 (ite (bvslt (_ bv0 64) in171_64) (_ bv1 1) (_ bv0 1))))
(let (($x24 (= (_ bv1 1) ?x192)))
(let ((?x68 (ite $x24 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x187 (or false false false)))
(let (($x674 (or $x187 (ite $x24 false false))))
(and (not $x674) (or $x674 (and (distinct ?x68 ?x68) true)))))))))
(check-sat)
; query 18: function Reflection_coefficients, block 174, name %178
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in171_64 () (_ BitVec 64))
(assert
 (let ((?x192 (ite (bvslt (_ bv0 64) in171_64) (_ bv1 1) (_ bv0 1))))
(let (($x24 (= (_ bv1 1) ?x192)))
(let ((?x68 (ite $x24 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x48 ((_ sign_extend 32) ?x68)))
(let (($x187 (or false false false)))
(let (($x674 (or $x187 (ite $x24 false false))))
(let (($x188 (or $x674 false)))
(and (not $x188) (or $x188 (and (distinct ?x48 ?x48) true)))))))))))
(check-sat)
; query 19: function gsm_L_add, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_64 () (_ BitVec 64))
(assert
 (let ((?x32 (bvsub (_ bv0 64) in13_64)))
(let ((?x22 ((_ sign_extend 1) ?x32)))
(let (($x6 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in13_64)) ?x22) true)))))
(and (not $x6) (or $x6 (and (distinct ?x32 ?x32) true)))))))
(check-sat)
; query 20: function gsm_L_add, block 16, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_64 () (_ BitVec 64))
(assert
 (let ((?x32 (bvsub (_ bv0 64) in13_64)))
(let ((?x82 (bvsub ?x32 (_ bv2 64))))
(let (($x232 (and (distinct (bvsub ((_ sign_extend 1) ?x32) ((_ sign_extend 1) (_ bv2 64))) ((_ sign_extend 1) ?x82)) true)))
(let ((?x22 ((_ sign_extend 1) ?x32)))
(let (($x6 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in13_64)) ?x22) true)))))
(let (($x136 (or $x6 false (or $x232))))
(and (not $x136) (or $x136 (and (distinct ?x82 ?x82) true))))))))))
(check-sat)
; query 21: function gsm_L_add, block 21, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x19 (ite (bvsge (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false false)))
(let (($x467 (not $x187)))
(and $x467 (or $x187 (and (distinct ?x19 ?x19) true)))))))
(check-sat)
; query 22: function gsm_L_add, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x35 (bvadd in0_64 in1_64)))
(let (($x146 (and (distinct ?x35 ?x35) true)))
(let (($x2791 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) ?x35)) true)))
(let (($x83 (or false false (or $x2791))))
(and (not $x83) (or $x83 $x146)))))))
(check-sat)
; query 23: function gsm_L_add, block 25, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x35 (bvadd in0_64 in1_64)))
(let (($x146 (and (distinct ?x35 ?x35) true)))
(let (($x93 (and (distinct (bvadd ((_ zero_extend 1) in0_64) ((_ zero_extend 1) in1_64)) ((_ zero_extend 1) ?x35)) true)))
(let (($x79 (or false false (or $x93))))
(let (($x187 (or false false false)))
(let (($x467 (not $x187)))
(and $x467 (or $x79 $x146)))))))))
(check-sat)
; query 24: function gsm_L_add, block 25, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x42 (ite (bvugt (bvadd in0_64 in1_64) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x93 (and (distinct (bvadd ((_ zero_extend 1) in0_64) ((_ zero_extend 1) in1_64)) ((_ zero_extend 1) (bvadd in0_64 in1_64))) true)))
(let (($x79 (or false false (or $x93))))
(let (($x187 (or false false false)))
(let (($x590 (or $x187 false false)))
(let (($x369 (not $x590)))
(and $x369 (or (or $x79 false false) (and (distinct ?x42 ?x42) true))))))))))
(check-sat)
; query 25: function gsm_L_add, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x125 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false false)))
(let (($x467 (not $x187)))
(and $x467 (or $x187 (and (distinct ?x125 ?x125) true)))))))
(check-sat)
; query 26: function gsm_L_add, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x35 (bvadd in0_64 in1_64)))
(let (($x146 (and (distinct ?x35 ?x35) true)))
(let (($x2791 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) ?x35)) true)))
(let (($x83 (or false false (or $x2791))))
(and (not $x83) (or $x83 $x146)))))))
(check-sat)
; query 27: function gsm_L_add, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x157 (bvadd in0_64 (_ bv1 64))))
(let ((?x358 (bvsub (_ bv0 64) ?x157)))
(let (($x634 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x157)) ((_ sign_extend 1) ?x358)) true)))
(let ((?x324 ((_ sign_extend 1) ?x157)))
(let (($x527 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x324) true)))))
(let (($x2260 (or false $x527 (or $x634))))
(and (not $x2260) (or $x2260 (and (distinct ?x358 ?x358) true))))))))))
(check-sat)
; query 28: function gsm_L_add, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1136 (bvadd in1_64 (_ bv1 64))))
(let ((?x183 ((_ sign_extend 1) ?x1136)))
(let (($x890 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x183) true)))))
(and (not $x890) (or $x890 (and (distinct ?x1136 ?x1136) true)))))))
(check-sat)
; query 29: function gsm_L_add, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1136 (bvadd in1_64 (_ bv1 64))))
(let ((?x2081 (bvsub (_ bv0 64) ?x1136)))
(let (($x1549 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1136)) ((_ sign_extend 1) ?x2081)) true)))
(let ((?x183 ((_ sign_extend 1) ?x1136)))
(let (($x890 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x183) true)))))
(let (($x76 (or false $x890 (or $x1549))))
(and (not $x76) (or $x76 (and (distinct ?x2081 ?x2081) true))))))))))
(check-sat)
; query 30: function gsm_L_add, block 8, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1136 (bvadd in1_64 (_ bv1 64))))
(let ((?x2081 (bvsub (_ bv0 64) ?x1136)))
(let ((?x157 (bvadd in0_64 (_ bv1 64))))
(let ((?x358 (bvsub (_ bv0 64) ?x157)))
(let ((?x701 (bvadd ?x358 ?x2081)))
(let (($x78 (and (distinct (bvadd ((_ zero_extend 1) ?x358) ((_ zero_extend 1) ?x2081)) ((_ zero_extend 1) ?x701)) true)))
(let (($x1549 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1136)) ((_ sign_extend 1) ?x2081)) true)))
(let ((?x183 ((_ sign_extend 1) ?x1136)))
(let (($x890 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x183) true)))))
(let (($x76 (or false $x890 (or $x1549))))
(let (($x634 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x157)) ((_ sign_extend 1) ?x358)) true)))
(let ((?x324 ((_ sign_extend 1) ?x157)))
(let (($x527 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x324) true)))))
(let (($x2260 (or false $x527 (or $x634))))
(let (($x1787 (or $x2260 $x76 (or $x78))))
(and (not (or $x2260 $x76 false)) (or $x1787 (and (distinct ?x701 ?x701) true)))))))))))))))))))
(check-sat)
; query 31: function gsm_L_add, block 8, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1136 (bvadd in1_64 (_ bv1 64))))
(let ((?x2081 (bvsub (_ bv0 64) ?x1136)))
(let ((?x157 (bvadd in0_64 (_ bv1 64))))
(let ((?x358 (bvsub (_ bv0 64) ?x157)))
(let ((?x701 (bvadd ?x358 ?x2081)))
(let ((?x1185 (ite (bvuge ?x701 (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x78 (and (distinct (bvadd ((_ zero_extend 1) ?x358) ((_ zero_extend 1) ?x2081)) ((_ zero_extend 1) ?x701)) true)))
(let (($x1549 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1136)) ((_ sign_extend 1) ?x2081)) true)))
(let ((?x183 ((_ sign_extend 1) ?x1136)))
(let (($x890 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x183) true)))))
(let (($x76 (or false $x890 (or $x1549))))
(let (($x634 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x157)) ((_ sign_extend 1) ?x358)) true)))
(let ((?x324 ((_ sign_extend 1) ?x157)))
(let (($x527 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x324) true)))))
(let (($x2260 (or false $x527 (or $x634))))
(let (($x1787 (or $x2260 $x76 (or $x78))))
(and (not (or (or $x2260 $x76 false) false false)) (or (or $x1787 false false) (and (distinct ?x1185 ?x1185) true))))))))))))))))))))
(check-sat)
; query 32: function gsm_L_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x157 (bvadd in0_64 (_ bv1 64))))
(let ((?x324 ((_ sign_extend 1) ?x157)))
(let (($x527 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x324) true)))))
(and (not $x527) (or $x527 (and (distinct ?x157 ?x157) true)))))))
(check-sat)
; query 33: function gsm_L_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1188 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false false)))
(let (($x467 (not $x187)))
(and $x467 (or $x187 (and (distinct ?x1188 ?x1188) true)))))))
(check-sat)
; query 34: function gsm_L_asl, block 12, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1369 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false false)))
(let (($x467 (not $x187)))
(and $x467 (or $x187 (and (distinct ?x1369 ?x1369) true)))))))
(check-sat)
; query 35: function gsm_L_asl, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x675 (or false (or (= ((_ extract 31 31) in1_32) (_ bv1 1))))))
(let (($x137 (or false false)))
(let (($x121 (not $x137)))
(and $x121 (or $x675 (and (distinct ((_ zero_extend 32) in1_32) ((_ zero_extend 32) in1_32)) true)))))))
(check-sat)
; query 36: function gsm_L_asl, block 17, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x595 ((_ zero_extend 32) in1_32)))
(let ((?x1352 (bvshl in0_64 ?x595)))
(let (($x1205 (bvuge ?x595 (_ bv64 64))))
(let (($x689 (or (or false (or false (or (= ((_ extract 31 31) in1_32) (_ bv1 1)))) false) $x1205)))
(let (($x2753 (not (or (or false (or false false) false) $x1205))))
(and $x2753 (or $x689 (and (distinct ?x1352 ?x1352) true)))))))))
(check-sat)
; query 37: function gsm_L_asl, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x403 (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false false)))
(let (($x467 (not $x187)))
(and $x467 (or $x187 (and (distinct ?x403 ?x403) true)))))))
(check-sat)
; query 38: function gsm_L_asl, block 7, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1188 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x416 ((_ zero_extend 31) ?x1188)))
(let ((?x267 (bvsub (_ bv0 32) ?x416)))
(let (($x1660 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x416)) ((_ sign_extend 1) ?x267)) true)))
(let (($x187 (or false false false)))
(let (($x178 (or $x187 false)))
(let (($x2459 (or false $x178 (or $x1660))))
(and (not $x2459) (or $x2459 (and (distinct ?x267 ?x267) true)))))))))))
(check-sat)
; query 39: function gsm_L_asl, block 7, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1188 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x416 ((_ zero_extend 31) ?x1188)))
(let ((?x267 (bvsub (_ bv0 32) ?x416)))
(let ((?x399 ((_ sign_extend 32) ?x267)))
(let (($x1660 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x416)) ((_ sign_extend 1) ?x267)) true)))
(let (($x187 (or false false false)))
(let (($x178 (or $x187 false)))
(let (($x2459 (or false $x178 (or $x1660))))
(let (($x999 (or $x2459 false)))
(and (not $x999) (or $x999 (and (distinct ?x399 ?x399) true)))))))))))))
(check-sat)
; query 40: function gsm_L_asl, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1188 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false false)))
(let (($x467 (not $x187)))
(and $x467 (or $x187 (and (distinct ?x1188 ?x1188) true)))))))
(check-sat)
; query 41: function gsm_L_asl, block 7, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1188 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x416 ((_ zero_extend 31) ?x1188)))
(let (($x187 (or false false false)))
(let (($x178 (or $x187 false)))
(let (($x1055 (not $x178)))
(and $x1055 (or $x178 (and (distinct ?x416 ?x416) true)))))))))
(check-sat)
; query 42: function gsm_L_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1901 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false false)))
(let (($x467 (not $x187)))
(and $x467 (or $x187 (and (distinct ?x1901 ?x1901) true)))))))
(check-sat)
; query 43: function gsm_L_asr, block 12, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1369 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false false)))
(let (($x467 (not $x187)))
(and $x467 (or $x187 (and (distinct ?x1369 ?x1369) true)))))))
(check-sat)
; query 44: function gsm_L_asr, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x2647 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in1_32))) true)))
(let (($x237 (or false false (or $x2647))))
(and (not $x237) (or $x237 (and (distinct (bvsub (_ bv0 32) in1_32) (bvsub (_ bv0 32) in1_32)) true))))))
(check-sat)
; query 45: function gsm_L_asr, block 14, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1024 (bvsub (_ bv0 32) in1_32)))
(let ((?x2075 ((_ zero_extend 32) ?x1024)))
(let (($x2647 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x1024)) true)))
(let (($x237 (or false false (or $x2647))))
(let (($x1970 (or $x237 (or (= ((_ extract 31 31) ?x1024) (_ bv1 1))))))
(and (not (or $x237 false)) (or $x1970 (and (distinct ?x2075 ?x2075) true)))))))))
(check-sat)
; query 46: function gsm_L_asr, block 14, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1024 (bvsub (_ bv0 32) in1_32)))
(let ((?x2075 ((_ zero_extend 32) ?x1024)))
(let ((?x1792 (bvshl in0_64 ?x2075)))
(let (($x212 (bvuge ?x2075 (_ bv64 64))))
(let (($x2647 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x1024)) true)))
(let (($x237 (or false false (or $x2647))))
(let (($x1970 (or $x237 (or (= ((_ extract 31 31) ?x1024) (_ bv1 1))))))
(and (not (or (or false (or $x237 false) false) $x212)) (or (or (or false $x1970 false) $x212) (and (distinct ?x1792 ?x1792) true)))))))))))
(check-sat)
; query 47: function gsm_L_asr, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x675 (or false (or (= ((_ extract 31 31) in1_32) (_ bv1 1))))))
(let (($x137 (or false false)))
(let (($x121 (not $x137)))
(and $x121 (or $x675 (and (distinct ((_ zero_extend 32) in1_32) ((_ zero_extend 32) in1_32)) true)))))))
(check-sat)
; query 48: function gsm_L_asr, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x595 ((_ zero_extend 32) in1_32)))
(let ((?x2392 (bvashr in0_64 ?x595)))
(let (($x1205 (bvuge ?x595 (_ bv64 64))))
(let (($x689 (or (or false (or false (or (= ((_ extract 31 31) in1_32) (_ bv1 1)))) false) $x1205)))
(let (($x2753 (not (or (or false (or false false) false) $x1205))))
(and $x2753 (or $x689 (and (distinct ?x2392 ?x2392) true)))))))))
(check-sat)
; query 49: function gsm_L_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1188 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false false)))
(let (($x467 (not $x187)))
(and $x467 (or $x187 (and (distinct ?x1188 ?x1188) true)))))))
(check-sat)
; query 50: function gsm_L_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1188 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x416 ((_ zero_extend 31) ?x1188)))
(let (($x187 (or false false false)))
(let (($x178 (or $x187 false)))
(let (($x1055 (not $x178)))
(and $x1055 (or $x178 (and (distinct ?x416 ?x416) true)))))))))
(check-sat)
; query 51: function gsm_L_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1188 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x416 ((_ zero_extend 31) ?x1188)))
(let ((?x267 (bvsub (_ bv0 32) ?x416)))
(let (($x1660 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x416)) ((_ sign_extend 1) ?x267)) true)))
(let (($x187 (or false false false)))
(let (($x178 (or $x187 false)))
(let (($x2459 (or false $x178 (or $x1660))))
(and (not $x2459) (or $x2459 (and (distinct ?x267 ?x267) true)))))))))))
(check-sat)
; query 52: function gsm_L_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1188 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x416 ((_ zero_extend 31) ?x1188)))
(let ((?x267 (bvsub (_ bv0 32) ?x416)))
(let ((?x399 ((_ sign_extend 32) ?x267)))
(let (($x1660 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x416)) ((_ sign_extend 1) ?x267)) true)))
(let (($x187 (or false false false)))
(let (($x178 (or $x187 false)))
(let (($x2459 (or false $x178 (or $x1660))))
(let (($x999 (or $x2459 false)))
(and (not $x999) (or $x999 (and (distinct ?x399 ?x399) true)))))))))))))
(check-sat)
; query 53: function gsm_L_asr, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x403 (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false false)))
(let (($x467 (not $x187)))
(and $x467 (or $x187 (and (distinct ?x403 ?x403) true)))))))
(check-sat)
; query 54: function gsm_L_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1901 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false false)))
(let (($x467 (not $x187)))
(and $x467 (or $x187 (and (distinct ?x1901 ?x1901) true)))))))
(check-sat)
; query 55: function gsm_L_mult, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x137 (or false false)))
(let (($x121 (not $x137)))
(and $x121 (or $x137 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 56: function gsm_L_mult, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1061 (ite (and (distinct (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) true) (_ bv1 1) (_ bv0 1))))
(let (($x137 (or false false)))
(let (($x145 (or $x137 false false)))
(let (($x666 (not $x145)))
(and $x666 (or $x145 (and (distinct ?x1061 ?x1061) true))))))))
(check-sat)
; query 57: function gsm_L_mult, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x137 (or false false)))
(let (($x121 (not $x137)))
(and $x121 (or $x137 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 58: function gsm_L_mult, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1701 (ite (and (distinct (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) true) (_ bv1 1) (_ bv0 1))))
(let (($x137 (or false false)))
(let (($x145 (or $x137 false false)))
(let (($x666 (not $x145)))
(and $x666 (or $x145 (and (distinct ?x1701 ?x1701) true))))))))
(check-sat)
; query 59: function gsm_L_sub, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in11_64 () (_ BitVec 64))
(assert
 (let (($x1941 (and (distinct (bvadd ((_ zero_extend 1) in11_64) ((_ zero_extend 1) (_ bv1 64))) ((_ zero_extend 1) (bvadd in11_64 (_ bv1 64)))) true)))
(let (($x1280 (and (distinct (bvadd ((_ sign_extend 1) in11_64) ((_ sign_extend 1) (_ bv1 64))) ((_ sign_extend 1) (bvadd in11_64 (_ bv1 64)))) true)))
(let (($x592 (or (or false false (or $x1280 $x1941)) (and (distinct (bvadd in11_64 (_ bv1 64)) (bvadd in11_64 (_ bv1 64))) true))))
(let (($x187 (or false false false)))
(let (($x467 (not $x187)))
(and $x467 $x592)))))))
(check-sat)
; query 60: function gsm_L_sub, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x19 (ite (bvsge (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false false)))
(let (($x467 (not $x187)))
(and $x467 (or $x187 (and (distinct ?x19 ?x19) true)))))))
(check-sat)
; query 61: function gsm_L_sub, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x1417 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvsub in0_64 in1_64))) true)))
(let (($x714 (or false false (or $x1417))))
(let (($x1210 (or $x714 (and (distinct (bvsub in0_64 in1_64) (bvsub in0_64 in1_64)) true))))
(and (not $x714) $x1210)))))
(check-sat)
; query 62: function gsm_L_sub, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x157 (bvadd in0_64 (_ bv1 64))))
(let ((?x324 ((_ sign_extend 1) ?x157)))
(let (($x527 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x324) true)))))
(and (not $x527) (or $x527 (and (distinct ?x157 ?x157) true)))))))
(check-sat)
; query 63: function gsm_L_sub, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x157 (bvadd in0_64 (_ bv1 64))))
(let ((?x358 (bvsub (_ bv0 64) ?x157)))
(let (($x634 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x157)) ((_ sign_extend 1) ?x358)) true)))
(let ((?x324 ((_ sign_extend 1) ?x157)))
(let (($x527 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x324) true)))))
(let (($x2260 (or false $x527 (or $x634))))
(and (not $x2260) (or $x2260 (and (distinct ?x358 ?x358) true))))))))))
(check-sat)
; query 64: function gsm_L_sub, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x157 (bvadd in0_64 (_ bv1 64))))
(let ((?x358 (bvsub (_ bv0 64) ?x157)))
(let ((?x466 (bvadd ?x358 in1_64)))
(let (($x2729 (and (distinct (bvadd ((_ zero_extend 1) ?x358) ((_ zero_extend 1) in1_64)) ((_ zero_extend 1) ?x466)) true)))
(let (($x634 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x157)) ((_ sign_extend 1) ?x358)) true)))
(let ((?x324 ((_ sign_extend 1) ?x157)))
(let (($x527 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x324) true)))))
(let (($x2260 (or false $x527 (or $x634))))
(let (($x7168 (or $x2260 false (or $x2729))))
(and (not (or $x2260 false false)) (or $x7168 (and (distinct ?x466 ?x466) true)))))))))))))
(check-sat)
; query 65: function gsm_L_sub, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x6184 (ite (bvuge (bvadd (bvsub (_ bv0 64) (bvadd in0_64 (_ bv1 64))) in1_64) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let ((?x105 ((_ zero_extend 1) in1_64)))
(let ((?x157 (bvadd in0_64 (_ bv1 64))))
(let ((?x358 (bvsub (_ bv0 64) ?x157)))
(let ((?x1750 ((_ zero_extend 1) ?x358)))
(let (($x634 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x157)) ((_ sign_extend 1) ?x358)) true)))
(let ((?x324 ((_ sign_extend 1) ?x157)))
(let (($x527 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x324) true)))))
(let (($x2260 (or false $x527 (or $x634))))
(let (($x7168 (or $x2260 false (or (and (distinct (bvadd ?x1750 ?x105) ((_ zero_extend 1) (bvadd ?x358 in1_64))) true)))))
(and (not (or (or $x2260 false false) false false)) (or (or $x7168 false false) (and (distinct ?x6184 ?x6184) true))))))))))))))
(check-sat)
; query 66: function gsm_L_sub, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_64 () (_ BitVec 64))
(assert
 (let ((?x3623 (bvsub (_ bv0 64) in25_64)))
(let ((?x2478 ((_ sign_extend 1) ?x3623)))
(let (($x1474 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in25_64)) ?x2478) true)))))
(and (not $x1474) (or $x1474 (and (distinct ?x3623 ?x3623) true)))))))
(check-sat)
; query 67: function gsm_L_sub, block 28, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_64 () (_ BitVec 64))
(assert
 (let ((?x3623 (bvsub (_ bv0 64) in25_64)))
(let ((?x5312 (bvsub ?x3623 (_ bv1 64))))
(let (($x4636 (and (distinct (bvsub ((_ zero_extend 1) ?x3623) ((_ zero_extend 1) (_ bv1 64))) ((_ zero_extend 1) ?x5312)) true)))
(let (($x1344 (and (distinct (bvsub ((_ sign_extend 1) ?x3623) ((_ sign_extend 1) (_ bv1 64))) ((_ sign_extend 1) ?x5312)) true)))
(let ((?x2478 ((_ sign_extend 1) ?x3623)))
(let (($x1474 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in25_64)) ?x2478) true)))))
(and (not (or $x1474 false (or $x1344))) (or (or $x1474 false (or $x1344 $x4636)) (and (distinct ?x5312 ?x5312) true))))))))))
(check-sat)
; query 68: function gsm_L_sub, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x125 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false false)))
(let (($x467 (not $x187)))
(and $x467 (or $x187 (and (distinct ?x125 ?x125) true)))))))
(check-sat)
; query 69: function gsm_L_sub, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x1417 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvsub in0_64 in1_64))) true)))
(let (($x714 (or false false (or $x1417))))
(let (($x1210 (or $x714 (and (distinct (bvsub in0_64 in1_64) (bvsub in0_64 in1_64)) true))))
(and (not $x714) $x1210)))))
(check-sat)
; query 70: function gsm_L_sub, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1136 (bvadd in1_64 (_ bv1 64))))
(let ((?x2081 (bvsub (_ bv0 64) ?x1136)))
(let (($x1549 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1136)) ((_ sign_extend 1) ?x2081)) true)))
(let ((?x183 ((_ sign_extend 1) ?x1136)))
(let (($x890 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x183) true)))))
(let (($x76 (or false $x890 (or $x1549))))
(and (not $x76) (or $x76 (and (distinct ?x2081 ?x2081) true))))))))))
(check-sat)
; query 71: function gsm_L_sub, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1136 (bvadd in1_64 (_ bv1 64))))
(let ((?x2081 (bvsub (_ bv0 64) ?x1136)))
(let ((?x3093 (bvadd in0_64 ?x2081)))
(let (($x2641 (and (distinct (bvadd ((_ zero_extend 1) in0_64) ((_ zero_extend 1) ?x2081)) ((_ zero_extend 1) ?x3093)) true)))
(let (($x1549 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1136)) ((_ sign_extend 1) ?x2081)) true)))
(let ((?x183 ((_ sign_extend 1) ?x1136)))
(let (($x890 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x183) true)))))
(let (($x76 (or false $x890 (or $x1549))))
(let (($x5624 (or false $x76 (or $x2641))))
(and (not (or false $x76 false)) (or $x5624 (and (distinct ?x3093 ?x3093) true)))))))))))))
(check-sat)
; query 72: function gsm_L_sub, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x271 (ite (bvuge (bvadd in0_64 (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64)))) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let ((?x1136 (bvadd in1_64 (_ bv1 64))))
(let ((?x2081 (bvsub (_ bv0 64) ?x1136)))
(let ((?x70 ((_ zero_extend 1) ?x2081)))
(let ((?x74 ((_ zero_extend 1) in0_64)))
(let (($x1549 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1136)) ((_ sign_extend 1) ?x2081)) true)))
(let ((?x183 ((_ sign_extend 1) ?x1136)))
(let (($x890 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x183) true)))))
(let (($x76 (or false $x890 (or $x1549))))
(let (($x5624 (or false $x76 (or (and (distinct (bvadd ?x74 ?x70) ((_ zero_extend 1) (bvadd in0_64 ?x2081))) true)))))
(and (not (or (or false $x76 false) false false)) (or (or $x5624 false false) (and (distinct ?x271 ?x271) true))))))))))))))
(check-sat)
; query 73: function gsm_L_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1136 (bvadd in1_64 (_ bv1 64))))
(let ((?x183 ((_ sign_extend 1) ?x1136)))
(let (($x890 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x183) true)))))
(and (not $x890) (or $x890 (and (distinct ?x1136 ?x1136) true)))))))
(check-sat)
; query 74: function gsm_L_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x3195 (ite (bvsle (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false false)))
(let (($x467 (not $x187)))
(and $x467 (or $x187 (and (distinct ?x3195 ?x3195) true)))))))
(check-sat)
; query 75: function gsm_abs, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x137 (or false false)))
(let (($x121 (not $x137)))
(and $x121 (or $x137 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 76: function gsm_abs, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1995 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x137 (or false false)))
(let (($x145 (or $x137 false false)))
(let (($x666 (not $x145)))
(and $x666 (or $x145 (and (distinct ?x1995 ?x1995) true))))))))
(check-sat)
; query 77: function gsm_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_64 () (_ BitVec 64))
(assert
 (let ((?x1803 (ite (bvslt (_ bv32767 64) in5_64) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false false)))
(let (($x467 (not $x187)))
(and $x467 (or $x187 (and (distinct ?x1803 ?x1803) true)))))))
(check-sat)
; query 78: function gsm_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x137 (or false false)))
(let (($x121 (not $x137)))
(and $x121 (or $x137 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 79: function gsm_add, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x137 (or false false)))
(let (($x121 (not $x137)))
(and $x121 (or $x137 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 80: function gsm_add, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x2170 ((_ sign_extend 48) in1_16)))
(let ((?x5785 ((_ sign_extend 48) in0_16)))
(let ((?x12 (bvadd ?x5785 ?x2170)))
(let (($x3136 (and (distinct (bvadd ((_ sign_extend 1) ?x5785) ((_ sign_extend 1) ?x2170)) ((_ sign_extend 1) ?x12)) true)))
(let (($x137 (or false false)))
(let (($x1420 (or $x137 $x137 (or $x3136))))
(and (not $x1420) (or $x1420 (and (distinct ?x12 ?x12) true))))))))))
(check-sat)
; query 81: function gsm_add, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1402 (ite (bvsgt (_ bv18446744073709518848 64) (bvadd ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x2170 ((_ sign_extend 48) in1_16)))
(let ((?x2473 ((_ sign_extend 1) ?x2170)))
(let ((?x5785 ((_ sign_extend 48) in0_16)))
(let ((?x5692 ((_ sign_extend 1) ?x5785)))
(let (($x137 (or false false)))
(let (($x1420 (or $x137 $x137 (or (and (distinct (bvadd ?x5692 ?x2473) ((_ sign_extend 1) (bvadd ?x5785 ?x2170))) true)))))
(let (($x3724 (or $x1420 false false)))
(and (not $x3724) (or $x3724 (and (distinct ?x1402 ?x1402) true))))))))))))
(check-sat)
; query 82: function gsm_asl, block 13, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1369 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false false)))
(let (($x467 (not $x187)))
(and $x467 (or $x187 (and (distinct ?x1369 ?x1369) true)))))))
(check-sat)
; query 83: function gsm_asl, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x137 (or false false)))
(let (($x121 (not $x137)))
(and $x121 (or $x137 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 84: function gsm_asl, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x225 ((_ sign_extend 16) in0_16)))
(let ((?x4296 (bvshl ?x225 in1_32)))
(let (($x1051 (bvuge in1_32 (_ bv32 32))))
(let (($x137 (or false false)))
(let (($x2744 (or (or $x137 false (or (and (distinct (bvashr ?x4296 in1_32) ?x225) true))) $x1051)))
(let (($x145 (or $x137 false false)))
(let (($x5155 (or $x145 $x1051)))
(let (($x5322 (not $x5155)))
(and $x5322 (or $x2744 (and (distinct ?x4296 ?x4296) true))))))))))))
(check-sat)
; query 85: function gsm_asl, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x225 ((_ sign_extend 16) in0_16)))
(let ((?x4296 (bvshl ?x225 in1_32)))
(let ((?x5783 ((_ extract 15 0) ?x4296)))
(let (($x1051 (bvuge in1_32 (_ bv32 32))))
(let (($x137 (or false false)))
(let (($x2744 (or (or $x137 false (or (and (distinct (bvashr ?x4296 in1_32) ?x225) true))) $x1051)))
(let (($x1307 (not (or (or (or $x137 false false) $x1051) false))))
(and $x1307 (or (or $x2744 false) (and (distinct ?x5783 ?x5783) true)))))))))))
(check-sat)
; query 86: function gsm_asl, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x2280 (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false false)))
(let (($x467 (not $x187)))
(and $x467 (or $x187 (and (distinct ?x2280 ?x2280) true)))))))
(check-sat)
; query 87: function gsm_asl, block 7, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1995 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x502 ((_ zero_extend 31) ?x1995)))
(let (($x137 (or false false)))
(let (($x145 (or $x137 false false)))
(let (($x540 (or $x145 false)))
(and (not $x540) (or $x540 (and (distinct ?x502 ?x502) true)))))))))
(check-sat)
; query 88: function gsm_asl, block 7, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1995 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x502 ((_ zero_extend 31) ?x1995)))
(let ((?x492 (bvsub (_ bv0 32) ?x502)))
(let (($x2784 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x502)) ((_ sign_extend 1) ?x492)) true)))
(let (($x137 (or false false)))
(let (($x145 (or $x137 false false)))
(let (($x540 (or $x145 false)))
(let (($x2775 (or false $x540 (or $x2784))))
(and (not $x2775) (or $x2775 (and (distinct ?x492 ?x492) true))))))))))))
(check-sat)
; query 89: function gsm_asl, block 7, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1995 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x502 ((_ zero_extend 31) ?x1995)))
(let ((?x492 (bvsub (_ bv0 32) ?x502)))
(let ((?x1816 ((_ extract 15 0) ?x492)))
(let (($x2784 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x502)) ((_ sign_extend 1) ?x492)) true)))
(let (($x137 (or false false)))
(let (($x145 (or $x137 false false)))
(let (($x540 (or $x145 false)))
(let (($x2775 (or false $x540 (or $x2784))))
(let (($x1035 (or (or $x2775 (or (and (distinct ((_ sign_extend 16) ?x1816) ?x492) true))) (and (distinct ?x1816 ?x1816) true))))
(and (not (or $x2775 false)) $x1035))))))))))))
(check-sat)
; query 90: function gsm_asl, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x137 (or false false)))
(let (($x121 (not $x137)))
(and $x121 (or $x137 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 91: function gsm_asl, block 7, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1995 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x137 (or false false)))
(let (($x145 (or $x137 false false)))
(let (($x666 (not $x145)))
(and $x666 (or $x145 (and (distinct ?x1995 ?x1995) true))))))))
(check-sat)
; query 92: function gsm_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1501 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false false)))
(let (($x467 (not $x187)))
(and $x467 (or $x187 (and (distinct ?x1501 ?x1501) true)))))))
(check-sat)
; query 93: function gsm_asr, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x2280 (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false false)))
(let (($x467 (not $x187)))
(and $x467 (or $x187 (and (distinct ?x2280 ?x2280) true)))))))
(check-sat)
; query 94: function gsm_asr, block 13, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1369 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false false)))
(let (($x467 (not $x187)))
(and $x467 (or $x187 (and (distinct ?x1369 ?x1369) true)))))))
(check-sat)
; query 95: function gsm_asr, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x137 (or false false)))
(let (($x121 (not $x137)))
(and $x121 (or $x137 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 96: function gsm_asr, block 15, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x2647 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in1_32))) true)))
(let (($x237 (or false false (or $x2647))))
(and (not $x237) (or $x237 (and (distinct (bvsub (_ bv0 32) in1_32) (bvsub (_ bv0 32) in1_32)) true))))))
(check-sat)
; query 97: function gsm_asr, block 15, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1024 (bvsub (_ bv0 32) in1_32)))
(let ((?x225 ((_ sign_extend 16) in0_16)))
(let ((?x3626 (bvshl ?x225 ?x1024)))
(let (($x704 (bvuge ?x1024 (_ bv32 32))))
(let (($x2647 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x1024)) true)))
(let (($x237 (or false false (or $x2647))))
(let (($x137 (or false false)))
(let (($x217 (or (or $x137 $x237 (or (and (distinct (bvashr ?x3626 ?x1024) ?x225) true))) $x704)))
(and (not (or (or $x137 $x237 false) $x704)) (or $x217 (and (distinct ?x3626 ?x3626) true))))))))))))
(check-sat)
; query 98: function gsm_asr, block 15, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1024 (bvsub (_ bv0 32) in1_32)))
(let ((?x225 ((_ sign_extend 16) in0_16)))
(let ((?x3626 (bvshl ?x225 ?x1024)))
(let ((?x537 ((_ extract 15 0) ?x3626)))
(let (($x704 (bvuge ?x1024 (_ bv32 32))))
(let (($x2647 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x1024)) true)))
(let (($x237 (or false false (or $x2647))))
(let (($x137 (or false false)))
(let (($x217 (or (or $x137 $x237 (or (and (distinct (bvashr ?x3626 ?x1024) ?x225) true))) $x704)))
(and (not (or (or (or $x137 $x237 false) $x704) false)) (or (or $x217 false) (and (distinct ?x537 ?x537) true)))))))))))))
(check-sat)
; query 99: function gsm_asr, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x137 (or false false)))
(let (($x121 (not $x137)))
(and $x121 (or $x137 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 100: function gsm_asr, block 20, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x225 ((_ sign_extend 16) in0_16)))
(let ((?x72 (bvashr ?x225 in1_32)))
(let (($x1051 (bvuge in1_32 (_ bv32 32))))
(let (($x137 (or false false)))
(let (($x145 (or $x137 false false)))
(let (($x5155 (or $x145 $x1051)))
(let (($x5322 (not $x5155)))
(and $x5322 (or $x5155 (and (distinct ?x72 ?x72) true)))))))))))
(check-sat)
; query 101: function gsm_asr, block 20, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x225 ((_ sign_extend 16) in0_16)))
(let ((?x72 (bvashr ?x225 in1_32)))
(let ((?x964 ((_ extract 15 0) ?x72)))
(let (($x1051 (bvuge in1_32 (_ bv32 32))))
(let (($x137 (or false false)))
(let (($x145 (or $x137 false false)))
(let (($x5155 (or $x145 $x1051)))
(let (($x1548 (or (or $x5155 (or (and (distinct ((_ sign_extend 16) ?x964) ?x72) true))) (and (distinct ?x964 ?x964) true))))
(let (($x1307 (not (or $x5155 false))))
(and $x1307 $x1548)))))))))))
(check-sat)
; query 102: function gsm_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x137 (or false false)))
(let (($x121 (not $x137)))
(and $x121 (or $x137 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 103: function gsm_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1995 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x137 (or false false)))
(let (($x145 (or $x137 false false)))
(let (($x666 (not $x145)))
(and $x666 (or $x145 (and (distinct ?x1995 ?x1995) true))))))))
(check-sat)
; query 104: function gsm_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1995 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x502 ((_ zero_extend 31) ?x1995)))
(let (($x137 (or false false)))
(let (($x145 (or $x137 false false)))
(let (($x540 (or $x145 false)))
(and (not $x540) (or $x540 (and (distinct ?x502 ?x502) true)))))))))
(check-sat)
; query 105: function gsm_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1995 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x502 ((_ zero_extend 31) ?x1995)))
(let ((?x492 (bvsub (_ bv0 32) ?x502)))
(let (($x2784 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x502)) ((_ sign_extend 1) ?x492)) true)))
(let (($x137 (or false false)))
(let (($x145 (or $x137 false false)))
(let (($x540 (or $x145 false)))
(let (($x2775 (or false $x540 (or $x2784))))
(and (not $x2775) (or $x2775 (and (distinct ?x492 ?x492) true))))))))))))
(check-sat)
; query 106: function gsm_asr, block 4, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1995 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x502 ((_ zero_extend 31) ?x1995)))
(let ((?x492 (bvsub (_ bv0 32) ?x502)))
(let ((?x1816 ((_ extract 15 0) ?x492)))
(let (($x2784 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x502)) ((_ sign_extend 1) ?x492)) true)))
(let (($x137 (or false false)))
(let (($x145 (or $x137 false false)))
(let (($x540 (or $x145 false)))
(let (($x2775 (or false $x540 (or $x2784))))
(let (($x1035 (or (or $x2775 (or (and (distinct ((_ sign_extend 16) ?x1816) ?x492) true))) (and (distinct ?x1816 ?x1816) true))))
(and (not (or $x2775 false)) $x1035))))))))))))
(check-sat)
; query 107: function gsm_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1501 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false false)))
(let (($x467 (not $x187)))
(and $x467 (or $x187 (and (distinct ?x1501 ?x1501) true)))))))
(check-sat)
; query 108: function gsm_debug_longwords, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in15_32 () (_ BitVec 32))
(assert
 (let ((?x2386 (ite (bvslt in15_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false false)))
(let (($x467 (not $x187)))
(and $x467 (or $x187 (and (distinct ?x2386 ?x2386) true)))))))
(check-sat)
; query 109: function gsm_debug_words, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in16_32 () (_ BitVec 32))
(assert
 (let ((?x1306 (ite (bvslt in16_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false false)))
(let (($x467 (not $x187)))
(and $x467 (or $x187 (and (distinct ?x1306 ?x1306) true)))))))
(check-sat)
; query 110: function gsm_div, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x137 (or false false)))
(let (($x121 (not $x137)))
(and $x121 (or $x137 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 111: function gsm_div, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x137 (or false false)))
(let (($x121 (not $x137)))
(and $x121 (or $x137 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 112: function gsm_div, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x137 (or false false)))
(let (($x121 (not $x137)))
(and $x121 (or $x137 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 113: function gsm_div, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x101 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x69 (and (distinct ?x101 ?x101) true)))
(let (($x137 (or false false)))
(let (($x145 (or $x137 false false)))
(let (($x666 (not $x145)))
(and $x666 (or $x145 $x69))))))))
(check-sat)
; query 114: function gsm_mult, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x137 (or false false)))
(let (($x121 (not $x137)))
(and $x121 (or $x137 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 115: function gsm_mult, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x441 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x137 (or false false)))
(let (($x145 (or $x137 false false)))
(let (($x666 (not $x145)))
(and $x666 (or $x145 (and (distinct ?x441 ?x441) true))))))))
(check-sat)
; query 116: function gsm_mult, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x137 (or false false)))
(let (($x121 (not $x137)))
(and $x121 (or $x137 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 117: function gsm_mult, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x137 (or false false)))
(let (($x121 (not $x137)))
(and $x121 (or $x137 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 118: function gsm_mult, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x2170 ((_ sign_extend 48) in1_16)))
(let ((?x5785 ((_ sign_extend 48) in0_16)))
(let ((?x756 (bvmul ?x5785 ?x2170)))
(let (($x991 (and (distinct (bvmul ((_ sign_extend 64) ?x5785) ((_ sign_extend 64) ?x2170)) ((_ sign_extend 64) ?x756)) true)))
(let (($x137 (or false false)))
(let (($x1189 (or $x137 $x137 (or $x991))))
(and (not $x1189) (or $x1189 (and (distinct ?x756 ?x756) true))))))))))
(check-sat)
; query 119: function gsm_mult, block 9, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x2170 ((_ sign_extend 48) in1_16)))
(let ((?x5785 ((_ sign_extend 48) in0_16)))
(let ((?x756 (bvmul ?x5785 ?x2170)))
(let ((?x1570 (bvashr ?x756 (_ bv15 64))))
(let (($x1343 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x991 (and (distinct (bvmul ((_ sign_extend 64) ?x5785) ((_ sign_extend 64) ?x2170)) ((_ sign_extend 64) ?x756)) true)))
(let (($x137 (or false false)))
(let (($x1189 (or $x137 $x137 (or $x991))))
(let (($x1505 (or (or $x1189 false false) $x1343)))
(and (not $x1505) (or $x1505 (and (distinct ?x1570 ?x1570) true)))))))))))))
(check-sat)
; query 120: function gsm_mult, block 9, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x2170 ((_ sign_extend 48) in1_16)))
(let ((?x5785 ((_ sign_extend 48) in0_16)))
(let ((?x756 (bvmul ?x5785 ?x2170)))
(let ((?x1570 (bvashr ?x756 (_ bv15 64))))
(let ((?x1659 ((_ extract 15 0) ?x1570)))
(let (($x1343 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x991 (and (distinct (bvmul ((_ sign_extend 64) ?x5785) ((_ sign_extend 64) ?x2170)) ((_ sign_extend 64) ?x756)) true)))
(let (($x137 (or false false)))
(let (($x1189 (or $x137 $x137 (or $x991))))
(let (($x1505 (or (or $x1189 false false) $x1343)))
(let (($x1670 (or $x1505 false)))
(and (not $x1670) (or $x1670 (and (distinct ?x1659 ?x1659) true)))))))))))))))
(check-sat)
; query 121: function gsm_mult, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x137 (or false false)))
(let (($x121 (not $x137)))
(and $x121 (or $x137 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 122: function gsm_mult, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x248 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x137 (or false false)))
(let (($x145 (or $x137 false false)))
(let (($x666 (not $x145)))
(and $x666 (or $x145 (and (distinct ?x248 ?x248) true))))))))
(check-sat)
; query 123: function gsm_mult_r, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x137 (or false false)))
(let (($x121 (not $x137)))
(and $x121 (or $x137 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 124: function gsm_mult_r, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x248 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x137 (or false false)))
(let (($x145 (or $x137 false false)))
(let (($x666 (not $x145)))
(and $x666 (or $x145 (and (distinct ?x248 ?x248) true))))))))
(check-sat)
; query 125: function gsm_mult_r, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x137 (or false false)))
(let (($x121 (not $x137)))
(and $x121 (or $x137 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 126: function gsm_mult_r, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x137 (or false false)))
(let (($x121 (not $x137)))
(and $x121 (or $x137 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 127: function gsm_mult_r, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x2170 ((_ sign_extend 48) in1_16)))
(let ((?x5785 ((_ sign_extend 48) in0_16)))
(let ((?x756 (bvmul ?x5785 ?x2170)))
(let (($x991 (and (distinct (bvmul ((_ sign_extend 64) ?x5785) ((_ sign_extend 64) ?x2170)) ((_ sign_extend 64) ?x756)) true)))
(let (($x137 (or false false)))
(let (($x1189 (or $x137 $x137 (or $x991))))
(and (not $x1189) (or $x1189 (and (distinct ?x756 ?x756) true))))))))))
(check-sat)
; query 128: function gsm_mult_r, block 9, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x2170 ((_ sign_extend 48) in1_16)))
(let ((?x5785 ((_ sign_extend 48) in0_16)))
(let ((?x756 (bvmul ?x5785 ?x2170)))
(let ((?x6194 (bvadd ?x756 (_ bv16384 64))))
(let (($x1063 (and (distinct (bvadd ((_ sign_extend 1) ?x756) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x6194)) true)))
(let (($x991 (and (distinct (bvmul ((_ sign_extend 64) ?x5785) ((_ sign_extend 64) ?x2170)) ((_ sign_extend 64) ?x756)) true)))
(let (($x137 (or false false)))
(let (($x1189 (or $x137 $x137 (or $x991))))
(let (($x4922 (or $x1189 false (or $x1063))))
(and (not $x4922) (or $x4922 (and (distinct ?x6194 ?x6194) true)))))))))))))
(check-sat)
; query 129: function gsm_mult_r, block 9, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x2170 ((_ sign_extend 48) in1_16)))
(let ((?x5785 ((_ sign_extend 48) in0_16)))
(let ((?x756 (bvmul ?x5785 ?x2170)))
(let ((?x6194 (bvadd ?x756 (_ bv16384 64))))
(let ((?x750 (bvashr ?x6194 (_ bv15 64))))
(let (($x1343 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1063 (and (distinct (bvadd ((_ sign_extend 1) ?x756) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x6194)) true)))
(let (($x991 (and (distinct (bvmul ((_ sign_extend 64) ?x5785) ((_ sign_extend 64) ?x2170)) ((_ sign_extend 64) ?x756)) true)))
(let (($x137 (or false false)))
(let (($x1189 (or $x137 $x137 (or $x991))))
(let (($x4922 (or $x1189 false (or $x1063))))
(let (($x1196 (or (or $x4922 false false) $x1343)))
(and (not $x1196) (or $x1196 (and (distinct ?x750 ?x750) true))))))))))))))))
(check-sat)
; query 130: function gsm_mult_r, block 9, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x2170 ((_ sign_extend 48) in1_16)))
(let ((?x5785 ((_ sign_extend 48) in0_16)))
(let ((?x756 (bvmul ?x5785 ?x2170)))
(let ((?x6194 (bvadd ?x756 (_ bv16384 64))))
(let ((?x750 (bvashr ?x6194 (_ bv15 64))))
(let ((?x883 (bvand ?x750 (_ bv65535 64))))
(let (($x1343 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1063 (and (distinct (bvadd ((_ sign_extend 1) ?x756) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x6194)) true)))
(let (($x991 (and (distinct (bvmul ((_ sign_extend 64) ?x5785) ((_ sign_extend 64) ?x2170)) ((_ sign_extend 64) ?x756)) true)))
(let (($x137 (or false false)))
(let (($x1189 (or $x137 $x137 (or $x991))))
(let (($x4922 (or $x1189 false (or $x1063))))
(let (($x1196 (or (or $x4922 false false) $x1343)))
(let (($x5621 (or $x1196 false false)))
(and (not $x5621) (or $x5621 (and (distinct ?x883 ?x883) true))))))))))))))))))
(check-sat)
; query 131: function gsm_mult_r, block 9, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x2170 ((_ sign_extend 48) in1_16)))
(let ((?x5785 ((_ sign_extend 48) in0_16)))
(let ((?x756 (bvmul ?x5785 ?x2170)))
(let ((?x6194 (bvadd ?x756 (_ bv16384 64))))
(let ((?x750 (bvashr ?x6194 (_ bv15 64))))
(let ((?x883 (bvand ?x750 (_ bv65535 64))))
(let ((?x4726 ((_ extract 15 0) ?x883)))
(let (($x1343 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1063 (and (distinct (bvadd ((_ sign_extend 1) ?x756) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x6194)) true)))
(let (($x991 (and (distinct (bvmul ((_ sign_extend 64) ?x5785) ((_ sign_extend 64) ?x2170)) ((_ sign_extend 64) ?x756)) true)))
(let (($x137 (or false false)))
(let (($x1189 (or $x137 $x137 (or $x991))))
(let (($x4922 (or $x1189 false (or $x1063))))
(let (($x1196 (or (or $x4922 false false) $x1343)))
(let (($x5621 (or $x1196 false false)))
(let (($x429 (or (or $x5621 (or (and (distinct ((_ zero_extend 48) ?x4726) ?x883) true))) (and (distinct ?x4726 ?x4726) true))))
(and (not (or $x5621 false)) $x429))))))))))))))))))
(check-sat)
; query 132: function gsm_mult_r, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x137 (or false false)))
(let (($x121 (not $x137)))
(and $x121 (or $x137 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 133: function gsm_mult_r, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x441 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x137 (or false false)))
(let (($x145 (or $x137 false false)))
(let (($x666 (not $x145)))
(and $x666 (or $x145 (and (distinct ?x441 ?x441) true))))))))
(check-sat)
; query 134: function gsm_norm, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2035 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false false)))
(let (($x467 (not $x187)))
(and $x467 (or $x187 (and (distinct ?x2035 ?x2035) true)))))))
(check-sat)
; query 135: function gsm_norm, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2035 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x1912 (bvxor ?x2035 (_ bv1 1))))
(let (($x187 (or false false false)))
(let (($x590 (or $x187 false false)))
(let (($x369 (not $x590)))
(and $x369 (or $x590 (and (distinct ?x1912 ?x1912) true)))))))))
(check-sat)
; query 136: function gsm_norm, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2035 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x1912 (bvxor ?x2035 (_ bv1 1))))
(let ((?x728 ((_ zero_extend 31) ?x1912)))
(let (($x187 (or false false false)))
(let (($x590 (or $x187 false false)))
(let (($x1412 (or $x590 false)))
(and (not $x1412) (or $x1412 (and (distinct ?x728 ?x728) true))))))))))
(check-sat)
; query 137: function gsm_norm, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2035 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x1912 (bvxor ?x2035 (_ bv1 1))))
(let ((?x728 ((_ zero_extend 31) ?x1912)))
(let (($x187 (or false false false)))
(let (($x590 (or $x187 false false)))
(let (($x1412 (or $x590 false)))
(let (($x3793 (or (or $x1412 (or (= ((_ extract 31 31) ?x728) (_ bv1 1)))) (and (distinct ((_ sign_extend 32) ?x728) ((_ zero_extend 32) ?x728)) true))))
(and (not (or $x1412 false)) $x3793)))))))))
(check-sat)
; query 138: function gsm_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_64 () (_ BitVec 64))
(assert
 (let ((?x1803 (ite (bvslt (_ bv32767 64) in5_64) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false false)))
(let (($x467 (not $x187)))
(and $x467 (or $x187 (and (distinct ?x1803 ?x1803) true)))))))
(check-sat)
; query 139: function gsm_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x137 (or false false)))
(let (($x121 (not $x137)))
(and $x121 (or $x137 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 140: function gsm_sub, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x137 (or false false)))
(let (($x121 (not $x137)))
(and $x121 (or $x137 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 141: function gsm_sub, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x2170 ((_ sign_extend 48) in1_16)))
(let ((?x5785 ((_ sign_extend 48) in0_16)))
(let ((?x2026 (bvsub ?x5785 ?x2170)))
(let (($x2952 (and (distinct (bvsub ((_ sign_extend 1) ?x5785) ((_ sign_extend 1) ?x2170)) ((_ sign_extend 1) ?x2026)) true)))
(let (($x137 (or false false)))
(let (($x5761 (or $x137 $x137 (or $x2952))))
(and (not $x5761) (or $x5761 (and (distinct ?x2026 ?x2026) true))))))))))
(check-sat)
; query 142: function gsm_sub, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x2874 (ite (bvsgt (_ bv18446744073709518848 64) (bvsub ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x2170 ((_ sign_extend 48) in1_16)))
(let ((?x2473 ((_ sign_extend 1) ?x2170)))
(let ((?x5785 ((_ sign_extend 48) in0_16)))
(let ((?x5692 ((_ sign_extend 1) ?x5785)))
(let (($x137 (or false false)))
(let (($x5761 (or $x137 $x137 (or (and (distinct (bvsub ?x5692 ?x2473) ((_ sign_extend 1) (bvsub ?x5785 ?x2170))) true)))))
(let (($x1213 (or $x5761 false false)))
(and (not $x1213) (or $x1213 (and (distinct ?x2874 ?x2874) true))))))))))))
(check-sat)
; query 143: function ok_to_replace, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x296 (ite (and (distinct (_ bv4294967295 32) in.01_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false false)))
(let (($x467 (not $x187)))
(and $x467 (or $x187 (and (distinct ?x296 ?x296) true)))))))
(check-sat)
; query 144: function suffix, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_64 () (_ BitVec 64))
(declare-fun in3_64 () (_ BitVec 64))
(assert
 (let ((?x1566 (ite (bvule in3_64 in4_64) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false false)))
(let (($x467 (not $x187)))
(and $x467 (or $x187 (and (distinct ?x1566 ?x1566) true)))))))
(check-sat)
