; OptiPhase-Sigma refinement certificate for sweep K40-R2-065
; query 0: function set_key, block 11, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let (($x114 (or false false false)))
(let (($x6 (not $x114)))
(and $x6 (or $x114 (and (distinct (bvand in2_32 (_ bv1 32)) (bvand in2_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function set_key, block 11, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x29 (ite (and (distinct (_ bv0 32) (bvand in2_32 (_ bv1 32))) true) (_ bv1 1) (_ bv0 1))))
(let (($x114 (or false false false)))
(let (($x809 (or $x114 false false)))
(let (($x66 (not $x809)))
(and $x66 (or $x809 (and (distinct ?x29 ?x29) true))))))))
(check-sat)
; query 2: function set_key, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let (($x114 (or false false false)))
(let (($x6 (not $x114)))
(and $x6 (or $x114 (and (distinct (bvand in2_32 (_ bv2 32)) (bvand in2_32 (_ bv2 32))) true))))))
(check-sat)
; query 3: function set_key, block 14, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x431 (ite (and (distinct (_ bv0 32) (bvand in2_32 (_ bv2 32))) true) (_ bv1 1) (_ bv0 1))))
(let (($x114 (or false false false)))
(let (($x809 (or $x114 false false)))
(let (($x66 (not $x809)))
(and $x66 (or $x809 (and (distinct ?x431 ?x431) true))))))))
(check-sat)
; query 4: function set_key, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x52 (ite (and (distinct (_ bv0 64) in1_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x114 (or false false false)))
(let (($x6 (not $x114)))
(and $x6 (or $x114 (and (distinct ?x52 ?x52) true)))))))
(check-sat)
; query 5: function set_key, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x25 (ite (bvult in1_64 (_ bv16 64)) (_ bv1 1) (_ bv0 1))))
(let (($x114 (or false false false)))
(let (($x6 (not $x114)))
(and $x6 (or $x114 (and (distinct ?x25 ?x25) true)))))))
(check-sat)
; query 6: function set_key, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x518 (ite (bvugt in1_64 (_ bv32 64)) (_ bv1 1) (_ bv0 1))))
(let (($x114 (or false false false)))
(let (($x6 (not $x114)))
(and $x6 (or $x114 (and (distinct ?x518 ?x518) true)))))))
(check-sat)
; query 7: function set_key, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let (($x114 (or false false false)))
(let (($x6 (not $x114)))
(and $x6 (or $x114 (and (distinct (bvand in1_64 (_ bv7 64)) (bvand in1_64 (_ bv7 64))) true))))))
(check-sat)
; query 8: function set_key, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x759 (ite (and (distinct (_ bv0 64) (bvand in1_64 (_ bv7 64))) true) (_ bv1 1) (_ bv0 1))))
(let (($x114 (or false false false)))
(let (($x809 (or $x114 false false)))
(let (($x66 (not $x809)))
(and $x66 (or $x809 (and (distinct ?x759 ?x759) true))))))))
(check-sat)
