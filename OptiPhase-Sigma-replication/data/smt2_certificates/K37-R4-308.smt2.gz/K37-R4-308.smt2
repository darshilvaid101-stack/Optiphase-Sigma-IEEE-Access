; OptiPhase-Sigma refinement certificate for sweep K37-R4-308
; query 0: function bit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x16 (and (distinct (bvsub ((_ sign_extend 1) (_ bv31 32)) ((_ sign_extend 1) in0_32)) ((_ sign_extend 1) (bvsub (_ bv31 32) in0_32))) true)))
(let (($x423 (or false false (or $x16))))
(and (not $x423) (or $x423 (and (distinct (bvsub (_ bv31 32) in0_32) (bvsub (_ bv31 32) in0_32)) true))))))
(check-sat)
; query 1: function bit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x762 (bvsub (_ bv31 32) in0_32)))
(let ((?x112 (bvshl (_ bv1 32) ?x762)))
(let (($x16 (and (distinct (bvsub ((_ sign_extend 1) (_ bv31 32)) ((_ sign_extend 1) in0_32)) ((_ sign_extend 1) ?x762)) true)))
(let (($x423 (or false false (or $x16))))
(let (($x743 (or (or false $x423 false) (bvuge ?x762 (_ bv32 32)))))
(and (not $x743) (or $x743 (and (distinct ?x112 ?x112) true)))))))))
(check-sat)
; query 2: function bit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x762 (bvsub (_ bv31 32) in0_32)))
(let ((?x112 (bvshl (_ bv1 32) ?x762)))
(let ((?x383 ((_ sign_extend 32) ?x112)))
(let (($x16 (and (distinct (bvsub ((_ sign_extend 1) (_ bv31 32)) ((_ sign_extend 1) in0_32)) ((_ sign_extend 1) ?x762)) true)))
(let (($x423 (or false false (or $x16))))
(let (($x743 (or (or false $x423 false) (bvuge ?x762 (_ bv32 32)))))
(let (($x609 (or $x743 false)))
(and (not $x609) (or $x609 (and (distinct ?x383 ?x383) true)))))))))))
(check-sat)
; query 3: function bit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x762 (bvsub (_ bv31 32) in0_32)))
(let ((?x112 (bvshl (_ bv1 32) ?x762)))
(let ((?x383 ((_ sign_extend 32) ?x112)))
(let ((?x746 (bvand in1_64 ?x383)))
(let (($x16 (and (distinct (bvsub ((_ sign_extend 1) (_ bv31 32)) ((_ sign_extend 1) in0_32)) ((_ sign_extend 1) ?x762)) true)))
(let (($x423 (or false false (or $x16))))
(let (($x743 (or (or false $x423 false) (bvuge ?x762 (_ bv32 32)))))
(let (($x609 (or $x743 false)))
(let (($x196 (or false $x609 false)))
(and (not $x196) (or $x196 (and (distinct ?x746 ?x746) true)))))))))))))
(check-sat)
; query 4: function main, block 104, name %105
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (and (not (or false false)) (or (or false false) (and (distinct ((_ extract 31 0) (_ bv4294967295 64)) ((_ extract 31 0) (_ bv4294967295 64))) true))))
(check-sat)
; query 5: function main, block 104, name %106
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x357 (or false false)))
(let (($x235 (or $x357 false false)))
(let (($x5 (or $x235 (and (distinct (bvand ((_ extract 31 0) (_ bv4294967295 64)) (_ bv4278190080 32)) (bvand ((_ extract 31 0) (_ bv4294967295 64)) (_ bv4278190080 32))) true))))
(let (($x260 (not $x235)))
(and $x260 $x5))))))
(check-sat)
; query 6: function main, block 104, name %107
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x53 ((_ extract 31 0) (_ bv4294967295 64))))
(let ((?x7 (bvand ?x53 (_ bv4278190080 32))))
(let ((?x217 (bvlshr ?x7 (_ bv24 32))))
(let (($x357 (or false false)))
(let (($x235 (or $x357 false false)))
(let (($x82 (or $x235 false false)))
(let (($x34 (or $x82 (bvuge (_ bv24 32) (_ bv32 32)))))
(let (($x126 (not $x34)))
(and $x126 (or $x34 (and (distinct ?x217 ?x217) true))))))))))))
(check-sat)
; query 7: function main, block 104, name %108
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (and (not (or false false)) (or (or false false) (and (distinct ((_ extract 31 0) (_ bv4294967295 64)) ((_ extract 31 0) (_ bv4294967295 64))) true))))
(check-sat)
; query 8: function main, block 104, name %109
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x357 (or false false)))
(let (($x235 (or $x357 false false)))
(let (($x83 (or $x235 (and (distinct (bvand ((_ extract 31 0) (_ bv4294967295 64)) (_ bv16711680 32)) (bvand ((_ extract 31 0) (_ bv4294967295 64)) (_ bv16711680 32))) true))))
(let (($x260 (not $x235)))
(and $x260 $x83))))))
(check-sat)
; query 9: function main, block 104, name %110
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x53 ((_ extract 31 0) (_ bv4294967295 64))))
(let ((?x147 (bvand ?x53 (_ bv16711680 32))))
(let ((?x232 (bvlshr ?x147 (_ bv8 32))))
(let (($x357 (or false false)))
(let (($x235 (or $x357 false false)))
(let (($x82 (or $x235 false false)))
(let (($x71 (or $x82 (bvuge (_ bv8 32) (_ bv32 32)))))
(let (($x223 (not $x71)))
(and $x223 (or $x71 (and (distinct ?x232 ?x232) true))))))))))))
(check-sat)
; query 10: function main, block 104, name %111
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x53 ((_ extract 31 0) (_ bv4294967295 64))))
(let ((?x147 (bvand ?x53 (_ bv16711680 32))))
(let ((?x232 (bvlshr ?x147 (_ bv8 32))))
(let ((?x7 (bvand ?x53 (_ bv4278190080 32))))
(let ((?x217 (bvlshr ?x7 (_ bv24 32))))
(let ((?x73 (bvor ?x217 ?x232)))
(let (($x357 (or false false)))
(let (($x235 (or $x357 false false)))
(let (($x82 (or $x235 false false)))
(let (($x71 (or $x82 (bvuge (_ bv8 32) (_ bv32 32)))))
(let (($x34 (or $x82 (bvuge (_ bv24 32) (_ bv32 32)))))
(let (($x106 (or $x34 $x71 false)))
(and (not $x106) (or $x106 (and (distinct ?x73 ?x73) true))))))))))))))))
(check-sat)
; query 11: function main, block 104, name %112
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (and (not (or false false)) (or (or false false) (and (distinct ((_ extract 31 0) (_ bv4294967295 64)) ((_ extract 31 0) (_ bv4294967295 64))) true))))
(check-sat)
; query 12: function main, block 104, name %113
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x357 (or false false)))
(let (($x235 (or $x357 false false)))
(let (($x165 (or $x235 (and (distinct (bvand ((_ extract 31 0) (_ bv4294967295 64)) (_ bv65280 32)) (bvand ((_ extract 31 0) (_ bv4294967295 64)) (_ bv65280 32))) true))))
(let (($x260 (not $x235)))
(and $x260 $x165))))))
(check-sat)
; query 13: function main, block 104, name %114
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x53 ((_ extract 31 0) (_ bv4294967295 64))))
(let ((?x109 (bvand ?x53 (_ bv65280 32))))
(let ((?x39 (bvshl ?x109 (_ bv8 32))))
(let (($x357 (or false false)))
(let (($x235 (or $x357 false false)))
(let (($x82 (or $x235 false false)))
(let (($x71 (or $x82 (bvuge (_ bv8 32) (_ bv32 32)))))
(let (($x223 (not $x71)))
(and $x223 (or $x71 (and (distinct ?x39 ?x39) true))))))))))))
(check-sat)
; query 14: function main, block 104, name %115
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x53 ((_ extract 31 0) (_ bv4294967295 64))))
(let ((?x109 (bvand ?x53 (_ bv65280 32))))
(let ((?x39 (bvshl ?x109 (_ bv8 32))))
(let ((?x147 (bvand ?x53 (_ bv16711680 32))))
(let ((?x232 (bvlshr ?x147 (_ bv8 32))))
(let ((?x7 (bvand ?x53 (_ bv4278190080 32))))
(let ((?x217 (bvlshr ?x7 (_ bv24 32))))
(let ((?x73 (bvor ?x217 ?x232)))
(let ((?x131 (bvor ?x73 ?x39)))
(let (($x357 (or false false)))
(let (($x235 (or $x357 false false)))
(let (($x82 (or $x235 false false)))
(let (($x71 (or $x82 (bvuge (_ bv8 32) (_ bv32 32)))))
(let (($x34 (or $x82 (bvuge (_ bv24 32) (_ bv32 32)))))
(let (($x106 (or $x34 $x71 false)))
(let (($x58 (or $x106 $x71 false)))
(and (not $x58) (or $x58 (and (distinct ?x131 ?x131) true))))))))))))))))))))
(check-sat)
; query 15: function main, block 104, name %116
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (and (not (or false false)) (or (or false false) (and (distinct ((_ extract 31 0) (_ bv4294967295 64)) ((_ extract 31 0) (_ bv4294967295 64))) true))))
(check-sat)
; query 16: function main, block 104, name %117
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x357 (or false false)))
(let (($x235 (or $x357 false false)))
(let (($x94 (or $x235 (and (distinct (bvand ((_ extract 31 0) (_ bv4294967295 64)) (_ bv255 32)) (bvand ((_ extract 31 0) (_ bv4294967295 64)) (_ bv255 32))) true))))
(let (($x260 (not $x235)))
(and $x260 $x94))))))
(check-sat)
; query 17: function main, block 104, name %118
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x53 ((_ extract 31 0) (_ bv4294967295 64))))
(let ((?x20 (bvand ?x53 (_ bv255 32))))
(let ((?x78 (bvshl ?x20 (_ bv24 32))))
(let (($x357 (or false false)))
(let (($x235 (or $x357 false false)))
(let (($x82 (or $x235 false false)))
(let (($x34 (or $x82 (bvuge (_ bv24 32) (_ bv32 32)))))
(let (($x126 (not $x34)))
(and $x126 (or $x34 (and (distinct ?x78 ?x78) true))))))))))))
(check-sat)
; query 18: function main, block 104, name %119
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x53 ((_ extract 31 0) (_ bv4294967295 64))))
(let ((?x20 (bvand ?x53 (_ bv255 32))))
(let ((?x78 (bvshl ?x20 (_ bv24 32))))
(let ((?x109 (bvand ?x53 (_ bv65280 32))))
(let ((?x39 (bvshl ?x109 (_ bv8 32))))
(let ((?x147 (bvand ?x53 (_ bv16711680 32))))
(let ((?x232 (bvlshr ?x147 (_ bv8 32))))
(let ((?x7 (bvand ?x53 (_ bv4278190080 32))))
(let ((?x217 (bvlshr ?x7 (_ bv24 32))))
(let ((?x73 (bvor ?x217 ?x232)))
(let ((?x131 (bvor ?x73 ?x39)))
(let ((?x113 (bvor ?x131 ?x78)))
(let (($x357 (or false false)))
(let (($x235 (or $x357 false false)))
(let (($x82 (or $x235 false false)))
(let (($x34 (or $x82 (bvuge (_ bv24 32) (_ bv32 32)))))
(let (($x71 (or $x82 (bvuge (_ bv8 32) (_ bv32 32)))))
(let (($x106 (or $x34 $x71 false)))
(let (($x58 (or $x106 $x71 false)))
(let (($x136 (or $x58 $x34 false)))
(and (not $x136) (or $x136 (and (distinct ?x113 ?x113) true))))))))))))))))))))))))
(check-sat)
; query 19: function pat_insert, block 156, name %157
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.3_32 () (_ BitVec 32))
(assert
 (let (($x157 (and (distinct (bvadd ((_ sign_extend 1) in.3_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.3_32 (_ bv1 32)))) true)))
(let (($x372 (or false false (or $x157))))
(and (not $x372) (or $x372 (and (distinct (bvadd in.3_32 (_ bv1 32)) (bvadd in.3_32 (_ bv1 32))) true))))))
(check-sat)
; query 20: function pat_insert, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_32 () (_ BitVec 32))
(assert
 (let (($x61 (and (distinct (bvadd ((_ sign_extend 1) in.03_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.03_32 (_ bv1 32)))) true)))
(let (($x57 (or false false (or $x61))))
(and (not $x57) (or $x57 (and (distinct (bvadd in.03_32 (_ bv1 32)) (bvadd in.03_32 (_ bv1 32))) true))))))
(check-sat)
; query 21: function pat_remove, block 190, name %191
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x84 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x104 (or false false (or $x84))))
(and (not $x104) (or $x104 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 22: function pat_remove, block 230, name %231
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x871 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x115 (or false false (or $x871))))
(and (not $x115) (or $x115 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
