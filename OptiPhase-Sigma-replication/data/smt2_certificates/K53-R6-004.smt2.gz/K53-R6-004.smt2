; OptiPhase-Sigma refinement certificate for sweep K53-R6-004
; query 0: function check, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x1272 (ite (= (_ bv11 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x1285 (or false false false)))
(let (($x323 (not $x1285)))
(and $x323 (or $x1285 (and (distinct (ite (= (_ bv2 32) in0_32) (_ bv1 1) (_ bv0 1)) ?x1272) true)))))))
(check-sat)
; query 1: function check, block 79, name %80
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x867 (and (distinct (ite (= (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1)) (ite (= (_ bv22 32) in0_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x1285 (or false false false)))
(let (($x323 (not $x1285)))
(and $x323 (or $x1285 $x867))))))
(check-sat)
; query 2: function check, block 85, name %86
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x139 (and (distinct (ite (= (_ bv4 32) in0_32) (_ bv1 1) (_ bv0 1)) (ite (= (_ bv33 32) in0_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x1285 (or false false false)))
(let (($x323 (not $x1285)))
(and $x323 (or $x1285 $x139))))))
(check-sat)
; query 3: function check, block 91, name %92
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x173 (and (distinct (ite (= (_ bv5 32) in0_32) (_ bv1 1) (_ bv0 1)) (ite (= (_ bv0 32) in0_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x1285 (or false false false)))
(let (($x323 (not $x1285)))
(and $x323 (or $x1285 $x173))))))
(check-sat)
; query 4: function check, block 97, name %98
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x1272 (ite (= (_ bv11 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x1285 (or false false false)))
(let (($x323 (not $x1285)))
(and $x323 (or $x1285 (and (distinct ?x1272 (ite (= (_ bv12 32) in0_32) (_ bv1 1) (_ bv0 1))) true)))))))
(check-sat)
; query 5: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x868 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x1285 (or false false false)))
(let (($x323 (not $x1285)))
(and $x323 (or $x1285 (and (distinct ?x868 ?x868) true)))))))
(check-sat)
; query 6: function set1d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x230 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x1285 (or false false false)))
(let (($x323 (not $x1285)))
(and $x323 (or $x1285 (and (distinct ?x230 ?x230) true)))))))
(check-sat)
; query 7: function set1ds, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x365 (ite (= (_ bv4294967295 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x1285 (or false false false)))
(let (($x323 (not $x1285)))
(and $x323 (or $x1285 (and (distinct ?x365 ?x365) true)))))))
(check-sat)
; query 8: function set2d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x230 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x1285 (or false false false)))
(let (($x323 (not $x1285)))
(and $x323 (or $x1285 (and (distinct ?x230 ?x230) true)))))))
(check-sat)
