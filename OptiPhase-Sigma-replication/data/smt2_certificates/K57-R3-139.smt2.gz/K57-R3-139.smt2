; OptiPhase-Sigma refinement certificate for sweep K57-R3-139
; query 0: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x105 (or false false false)))
(let (($x517 (not $x105)))
(and $x517 (or $x105 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x492 (bvadd in.01_32 (_ bv1 32))))
(let ((?x64 (bvmul ?x492 ?x492)))
(let (($x105 (or false false false)))
(let (($x6 (or $x105 $x105 false)))
(and (not $x6) (or $x6 (and (distinct ?x64 ?x64) true))))))))
(check-sat)
; query 2: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x492 (bvadd in.01_32 (_ bv1 32))))
(let ((?x64 (bvmul ?x492 ?x492)))
(let ((?x63 (bvmul ?x64 (_ bv2 32))))
(let (($x105 (or false false false)))
(let (($x6 (or $x105 $x105 false)))
(let (($x948 (or $x6 false false)))
(and (not $x948) (or $x948 (and (distinct ?x63 ?x63) true))))))))))
(check-sat)
; query 3: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x492 (bvadd in.01_32 (_ bv1 32))))
(let ((?x64 (bvmul ?x492 ?x492)))
(let ((?x63 (bvmul ?x64 (_ bv2 32))))
(let ((?x1730 (bvmul ?x63 (_ bv4 32))))
(let (($x105 (or false false false)))
(let (($x6 (or $x105 $x105 false)))
(let (($x948 (or $x6 false false)))
(let (($x10 (or $x948 false false)))
(and (not $x10) (or $x10 (and (distinct ?x1730 ?x1730) true))))))))))))
(check-sat)
; query 4: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x509 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x105 (or false false false)))
(let (($x517 (not $x105)))
(and $x517 (or $x105 (and (distinct ?x509 ?x509) true)))))))
(check-sat)
; query 5: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x476 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x105 (or false false false)))
(let (($x517 (not $x105)))
(and $x517 (or $x105 (and (distinct ?x476 ?x476) true)))))))
(check-sat)
; query 6: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x105 (or false false false)))
(let (($x517 (not $x105)))
(and $x517 (or $x105 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 7: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x609 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x420 (or false false (or $x609))))
(and (not $x420) (or $x420 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x17 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x105 (or false false false)))
(let (($x517 (not $x105)))
(and $x517 (or $x105 (and (distinct ?x17 ?x17) true)))))))
(check-sat)
; query 9: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x77 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x105 (or false false false)))
(let (($x517 (not $x105)))
(and $x517 (or $x105 (and (distinct ?x77 ?x77) true)))))))
(check-sat)
; query 10: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x47 (or false false)))
(and (not $x47) (or $x47 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true)))))
(check-sat)
; query 11: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x432 ((_ sign_extend 16) in.1_16)))
(let ((?x307 (bvadd ?x432 (_ bv10 32))))
(let (($x59 (and (distinct (bvadd ((_ sign_extend 1) ?x432) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x307)) true)))
(let (($x47 (or false false)))
(let (($x23 (or $x47 false (or $x59))))
(and (not $x23) (or $x23 (and (distinct ?x307 ?x307) true)))))))))
(check-sat)
; query 12: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x432 ((_ sign_extend 16) in.1_16)))
(let ((?x307 (bvadd ?x432 (_ bv10 32))))
(let ((?x572 ((_ extract 15 0) ?x307)))
(let (($x59 (and (distinct (bvadd ((_ sign_extend 1) ?x432) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x307)) true)))
(let (($x47 (or false false)))
(let (($x23 (or $x47 false (or $x59))))
(let (($x662 (or $x23 false)))
(and (not $x662) (or $x662 (and (distinct ?x572 ?x572) true)))))))))))
(check-sat)
; query 13: function matrix_sum, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x2781 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x105 (or false false false)))
(let (($x517 (not $x105)))
(and $x517 (or $x105 (and (distinct ?x2781 ?x2781) true)))))))
(check-sat)
; query 14: function matrix_sum, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x2781 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let ((?x428 ((_ zero_extend 63) ?x2781)))
(let (($x105 (or false false false)))
(let (($x37 (or $x105 false)))
(and (not $x37) (or $x37 (and (distinct ?x428 ?x428) true))))))))
(check-sat)
; query 15: function matrix_sum, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x2781 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x86 (= (_ bv1 1) ?x2781)))
(let ((?x630 (ite $x86 (_ bv1 32) (_ bv0 32))))
(let (($x105 (or false false false)))
(let (($x426 (or $x105 (ite $x86 false false))))
(and (not $x426) (or $x426 (and (distinct ?x630 ?x630) true)))))))))
(check-sat)
; query 16: function matrix_sum, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x47 (or false false)))
(and (not $x47) (or $x47 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true)))))
(check-sat)
; query 17: function matrix_sum, block 22, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x2781 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x86 (= (_ bv1 1) ?x2781)))
(let ((?x630 (ite $x86 (_ bv1 32) (_ bv0 32))))
(let ((?x432 ((_ sign_extend 16) in.1_16)))
(let ((?x149 (bvadd ?x432 ?x630)))
(let (($x2785 (and (distinct (bvadd ((_ sign_extend 1) ?x432) ((_ sign_extend 1) ?x630)) ((_ sign_extend 1) ?x149)) true)))
(let (($x105 (or false false false)))
(let (($x426 (or $x105 (ite $x86 false false))))
(let (($x47 (or false false)))
(let (($x378 (or $x47 $x426 (or $x2785))))
(and (not $x378) (or $x378 (and (distinct ?x149 ?x149) true))))))))))))))
(check-sat)
; query 18: function matrix_sum, block 22, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x2781 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x86 (= (_ bv1 1) ?x2781)))
(let ((?x630 (ite $x86 (_ bv1 32) (_ bv0 32))))
(let ((?x432 ((_ sign_extend 16) in.1_16)))
(let ((?x149 (bvadd ?x432 ?x630)))
(let ((?x55 ((_ extract 15 0) ?x149)))
(let (($x2785 (and (distinct (bvadd ((_ sign_extend 1) ?x432) ((_ sign_extend 1) ?x630)) ((_ sign_extend 1) ?x149)) true)))
(let (($x105 (or false false false)))
(let (($x426 (or $x105 (ite $x86 false false))))
(let (($x47 (or false false)))
(let (($x378 (or $x47 $x426 (or $x2785))))
(let (($x790 (or $x378 false)))
(and (not $x790) (or $x790 (and (distinct ?x55 ?x55) true))))))))))))))))
(check-sat)
