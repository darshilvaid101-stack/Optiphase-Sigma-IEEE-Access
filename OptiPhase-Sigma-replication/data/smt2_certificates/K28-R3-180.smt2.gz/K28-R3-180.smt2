; OptiPhase-Sigma refinement certificate for sweep K28-R3-180
; query 0: function xmalloc, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in7_32 () (_ BitVec 32))
(assert
 (let ((?x374 (ite (and (distinct (_ bv0 32) in7_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x428 (or false false false)))
(and (not $x428) (or $x428 (and (distinct ?x374 ?x374) true))))))
(check-sat)
