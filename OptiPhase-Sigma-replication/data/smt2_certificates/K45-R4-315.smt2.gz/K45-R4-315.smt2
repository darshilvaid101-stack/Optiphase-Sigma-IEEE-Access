; OptiPhase-Sigma refinement certificate for sweep K45-R4-315
; query 0: function Index_to_frequency, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x411 (ite (bvuge in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x161 (or false false false)))
(let (($x192 (not $x161)))
(and $x192 (or $x161 (and (distinct ?x411 ?x411) true)))))))
(check-sat)
; query 1: function IsPowerOfTwo, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x110 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x161 (or false false false)))
(let (($x192 (not $x161)))
(and $x192 (or $x161 (and (distinct ?x110 ?x110) true)))))))
(check-sat)
; query 2: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x110 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x161 (or false false false)))
(let (($x192 (not $x161)))
(and $x192 (or $x161 (and (distinct ?x110 ?x110) true)))))))
(check-sat)
; query 3: function main, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x56 (ite (= (_ bv4 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x161 (or false false false)))
(let (($x192 (not $x161)))
(and $x192 (or $x161 (and (distinct ?x56 ?x56) true)))))))
(check-sat)
; query 4: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x19 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x161 (or false false false)))
(let (($x192 (not $x161)))
(and $x192 (or $x161 (and (distinct ?x19 ?x19) true)))))))
(check-sat)
