; OptiPhase-Sigma refinement certificate for sweep K33-R6-031
; query 0: function edge_draw, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let ((?x627 (ite (= (_ bv0 32) in4_32) (_ bv1 1) (_ bv0 1))))
(let (($x39 (or false false false)))
(and (not $x39) (or $x39 (and (distinct ?x627 ?x627) true))))))
(check-sat)
