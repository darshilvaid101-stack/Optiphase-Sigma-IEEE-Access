; OptiPhase-Sigma refinement certificate for sweep K11-R4-329
