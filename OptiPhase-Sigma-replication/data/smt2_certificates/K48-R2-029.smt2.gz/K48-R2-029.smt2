; OptiPhase-Sigma refinement certificate for sweep K48-R2-029
; query 0: function APCM_inverse_quantization, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x8 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 1: function APCM_inverse_quantization, block 7, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x7 (ite (bvsge (_ bv7 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x8 (or false false)))
(let (($x253 (or $x8 false false)))
(let (($x122 (not $x253)))
(and $x122 (or $x253 (and (distinct ?x7 ?x7) true))))))))
(check-sat)
; query 2: function APCM_inverse_quantization, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x8 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 3: function APCM_inverse_quantization, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x365 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x8 (or false false)))
(let (($x253 (or $x8 false false)))
(let (($x122 (not $x253)))
(and $x122 (or $x253 (and (distinct ?x365 ?x365) true))))))))
(check-sat)
; query 4: function APCM_quantization, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_16 () (_ BitVec 16))
(assert
 (let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x8 (and (distinct ((_ sign_extend 16) in13_16) ((_ sign_extend 16) in13_16)) true))))))
(check-sat)
; query 5: function APCM_quantization, block 16, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_16 () (_ BitVec 16))
(assert
 (let ((?x274 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in13_16)) (_ bv1 1) (_ bv0 1))))
(let (($x8 (or false false)))
(let (($x253 (or $x8 false false)))
(let (($x122 (not $x253)))
(and $x122 (or $x253 (and (distinct ?x274 ?x274) true))))))))
(check-sat)
; query 6: function APCM_quantization, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_16 () (_ BitVec 16))
(assert
 (let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x8 (and (distinct ((_ sign_extend 16) in13_16) ((_ sign_extend 16) in13_16)) true))))))
(check-sat)
; query 7: function APCM_quantization, block 20, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_16 () (_ BitVec 16))
(assert
 (let ((?x18 ((_ sign_extend 16) in13_16)))
(let ((?x813 (bvsub (_ bv0 32) ?x18)))
(let (($x60 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x18)) ((_ sign_extend 1) ?x813)) true)))
(let (($x8 (or false false)))
(let (($x644 (or false $x8 (or $x60))))
(and (not $x644) (or $x644 (and (distinct ?x813 ?x813) true)))))))))
(check-sat)
; query 8: function APCM_quantization, block 25, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_16 () (_ BitVec 16))
(assert
 (let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x8 (and (distinct ((_ sign_extend 16) in13_16) ((_ sign_extend 16) in13_16)) true))))))
(check-sat)
; query 9: function APCM_quantization, block 35, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_32 () (_ BitVec 32))
(assert
 (let (($x134 (and (distinct (bvadd ((_ sign_extend 1) in.03_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.03_32 (_ bv1 32)))) true)))
(let (($x127 (or false false (or $x134))))
(and (not $x127) (or $x127 (and (distinct (bvadd in.03_32 (_ bv1 32)) (bvadd in.03_32 (_ bv1 32))) true))))))
(check-sat)
; query 10: function APCM_quantization_xmaxc_to_exp_mant, block 24, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x8 (and (distinct ((_ sign_extend 16) in.0_16) ((_ sign_extend 16) in.0_16)) true))))))
(check-sat)
; query 11: function APCM_quantization_xmaxc_to_exp_mant, block 24, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let ((?x153 ((_ sign_extend 16) in.0_16)))
(let ((?x52 (bvshl ?x153 (_ bv1 32))))
(let (($x98 (bvuge (_ bv1 32) (_ bv32 32))))
(let (($x8 (or false false)))
(let (($x124 (or (or $x8 false (or (and (distinct (bvashr ?x52 (_ bv1 32)) ?x153) true))) $x98)))
(let (($x253 (or $x8 false false)))
(let (($x484 (or $x253 $x98)))
(let (($x1059 (not $x484)))
(and $x1059 (or $x124 (and (distinct ?x52 ?x52) true))))))))))))
(check-sat)
; query 12: function APCM_quantization_xmaxc_to_exp_mant, block 24, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let ((?x153 ((_ sign_extend 16) in.0_16)))
(let ((?x52 (bvshl ?x153 (_ bv1 32))))
(let ((?x261 (bvor ?x52 (_ bv1 32))))
(let (($x98 (bvuge (_ bv1 32) (_ bv32 32))))
(let (($x8 (or false false)))
(let (($x124 (or (or $x8 false (or (and (distinct (bvashr ?x52 (_ bv1 32)) ?x153) true))) $x98)))
(let (($x416 (or $x124 false false)))
(and (not (or (or (or $x8 false false) $x98) false false)) (or $x416 (and (distinct ?x261 ?x261) true)))))))))))
(check-sat)
; query 13: function APCM_quantization_xmaxc_to_exp_mant, block 24, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let ((?x153 ((_ sign_extend 16) in.0_16)))
(let ((?x52 (bvshl ?x153 (_ bv1 32))))
(let ((?x261 (bvor ?x52 (_ bv1 32))))
(let ((?x283 ((_ extract 15 0) ?x261)))
(let (($x98 (bvuge (_ bv1 32) (_ bv32 32))))
(let (($x8 (or false false)))
(let (($x124 (or (or $x8 false (or (and (distinct (bvashr ?x52 (_ bv1 32)) ?x153) true))) $x98)))
(let (($x416 (or $x124 false false)))
(let (($x381 (not (or (or (or (or $x8 false false) $x98) false false) false))))
(and $x381 (or (or $x416 false) (and (distinct ?x283 ?x283) true)))))))))))))
(check-sat)
; query 14: function APCM_quantization_xmaxc_to_exp_mant, block 24, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_16 () (_ BitVec 16))
(assert
 (let (($x118 (or false false false)))
(let (($x91 (not $x118)))
(and $x91 (or $x118 (and (distinct (bvadd in.12_16 (_ bv65535 16)) (bvadd in.12_16 (_ bv65535 16))) true))))))
(check-sat)
; query 15: function APCM_quantization_xmaxc_to_exp_mant, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x8 (and (distinct ((_ sign_extend 16) in.0_16) ((_ sign_extend 16) in.0_16)) true))))))
(check-sat)
; query 16: function APCM_quantization_xmaxc_to_exp_mant, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let ((?x153 ((_ sign_extend 16) in.0_16)))
(let ((?x87 (bvsub ?x153 (_ bv8 32))))
(let (($x80 (and (distinct (bvsub ((_ sign_extend 1) ?x153) ((_ sign_extend 1) (_ bv8 32))) ((_ sign_extend 1) ?x87)) true)))
(let (($x8 (or false false)))
(let (($x126 (or $x8 false (or $x80))))
(and (not $x126) (or $x126 (and (distinct ?x87 ?x87) true)))))))))
(check-sat)
; query 17: function APCM_quantization_xmaxc_to_exp_mant, block 30, name %33
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let ((?x153 ((_ sign_extend 16) in.0_16)))
(let ((?x87 (bvsub ?x153 (_ bv8 32))))
(let ((?x175 ((_ extract 15 0) ?x87)))
(let (($x80 (and (distinct (bvsub ((_ sign_extend 1) ?x153) ((_ sign_extend 1) (_ bv8 32))) ((_ sign_extend 1) ?x87)) true)))
(let (($x8 (or false false)))
(let (($x126 (or $x8 false (or $x80))))
(let (($x51 (or $x126 false)))
(and (not $x51) (or $x51 (and (distinct ?x175 ?x175) true)))))))))))
(check-sat)
; query 18: function APCM_quantization_xmaxc_to_exp_mant, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_16 () (_ BitVec 16))
(assert
 (let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x8 (and (distinct ((_ sign_extend 16) in.2_16) ((_ sign_extend 16) in.2_16)) true))))))
(check-sat)
; query 19: function APCM_quantization_xmaxc_to_exp_mant, block 37, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_16 () (_ BitVec 16))
(assert
 (let ((?x103 (ite (bvsge (_ bv6 32) ((_ sign_extend 16) in.2_16)) (_ bv1 1) (_ bv0 1))))
(let (($x8 (or false false)))
(let (($x253 (or $x8 false false)))
(let (($x122 (not $x253)))
(and $x122 (or $x253 (and (distinct ?x103 ?x103) true))))))))
(check-sat)
; query 20: function APCM_quantization_xmaxc_to_exp_mant, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x627 ((_ sign_extend 16) in0_16)))
(let ((?x1900 (bvashr ?x627 (_ bv3 32))))
(let ((?x818 (bvsub ?x1900 (_ bv1 32))))
(let ((?x206 ((_ extract 15 0) ?x818)))
(let (($x575 (and (distinct (bvsub ((_ sign_extend 1) ?x1900) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x818)) true)))
(let (($x8 (or false false)))
(let (($x253 (or $x8 false false)))
(let (($x2780 (or $x253 (bvuge (_ bv3 32) (_ bv32 32)))))
(let (($x429 (or $x2780 false (or $x575))))
(let (($x615 (or (or $x429 (or (and (distinct ((_ sign_extend 16) ?x206) ?x818) true))) (and (distinct ?x206 ?x206) true))))
(and (not (or $x429 false)) $x615))))))))))))
(check-sat)
; query 21: function APCM_quantization_xmaxc_to_exp_mant, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x8 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 22: function APCM_quantization_xmaxc_to_exp_mant, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x627 ((_ sign_extend 16) in0_16)))
(let ((?x1900 (bvashr ?x627 (_ bv3 32))))
(let (($x8 (or false false)))
(let (($x253 (or $x8 false false)))
(let (($x2780 (or $x253 (bvuge (_ bv3 32) (_ bv32 32)))))
(and (not $x2780) (or $x2780 (and (distinct ?x1900 ?x1900) true)))))))))
(check-sat)
; query 23: function APCM_quantization_xmaxc_to_exp_mant, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x627 ((_ sign_extend 16) in0_16)))
(let ((?x1900 (bvashr ?x627 (_ bv3 32))))
(let ((?x818 (bvsub ?x1900 (_ bv1 32))))
(let (($x575 (and (distinct (bvsub ((_ sign_extend 1) ?x1900) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x818)) true)))
(let (($x8 (or false false)))
(let (($x253 (or $x8 false false)))
(let (($x2780 (or $x253 (bvuge (_ bv3 32) (_ bv32 32)))))
(let (($x429 (or $x2780 false (or $x575))))
(and (not $x429) (or $x429 (and (distinct ?x818 ?x818) true))))))))))))
(check-sat)
; query 24: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x8 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 25: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x810 (ite (bvslt (_ bv15 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x8 (or false false)))
(let (($x253 (or $x8 false false)))
(let (($x122 (not $x253)))
(and $x122 (or $x253 (and (distinct ?x810 ?x810) true))))))))
(check-sat)
; query 26: function Autocorrelation, block 39, name %40
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x2614 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x926 (or false false (or $x2614))))
(and (not $x926) (or $x926 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 27: function Autocorrelation, block 41, name %42
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x8 (and (distinct ((_ sign_extend 16) in.04_16) ((_ sign_extend 16) in.04_16)) true))))))
(check-sat)
; query 28: function Autocorrelation, block 41, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let ((?x1348 (ite (= (_ bv0 32) ((_ sign_extend 16) in.04_16)) (_ bv1 1) (_ bv0 1))))
(let (($x8 (or false false)))
(let (($x253 (or $x8 false false)))
(let (($x122 (not $x253)))
(and $x122 (or $x253 (and (distinct ?x1348 ?x1348) true))))))))
(check-sat)
; query 29: function Autocorrelation, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x8 (and (distinct ((_ sign_extend 16) in.04_16) ((_ sign_extend 16) in.04_16)) true))))))
(check-sat)
; query 30: function Autocorrelation, block 45, name %47
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let ((?x984 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.04_16)) (_ bv1 1) (_ bv0 1))))
(let (($x8 (or false false)))
(let (($x253 (or $x8 false false)))
(let (($x122 (not $x253)))
(and $x122 (or $x253 (and (distinct ?x984 ?x984) true))))))))
(check-sat)
; query 31: function Autocorrelation, block 45, name %48
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let ((?x984 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.04_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x92 (bvxor ?x984 (_ bv1 1))))
(let (($x8 (or false false)))
(let (($x253 (or $x8 false false)))
(let (($x816 (or $x253 false false)))
(let (($x1837 (not $x816)))
(and $x1837 (or $x816 (and (distinct ?x92 ?x92) true))))))))))
(check-sat)
; query 32: function Autocorrelation, block 45, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let ((?x984 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.04_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x92 (bvxor ?x984 (_ bv1 1))))
(let ((?x179 ((_ zero_extend 31) ?x92)))
(let (($x8 (or false false)))
(let (($x253 (or $x8 false false)))
(let (($x816 (or $x253 false false)))
(let (($x48 (or $x816 false)))
(let (($x1825 (not $x48)))
(and $x1825 (or $x48 (and (distinct ?x179 ?x179) true))))))))))))
(check-sat)
; query 33: function Autocorrelation, block 45, name %50
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let ((?x984 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.04_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x92 (bvxor ?x984 (_ bv1 1))))
(let ((?x179 ((_ zero_extend 31) ?x92)))
(let ((?x953 ((_ zero_extend 32) ?x179)))
(let ((?x1751 ((_ sign_extend 32) ?x179)))
(let (($x8 (or false false)))
(let (($x253 (or $x8 false false)))
(let (($x816 (or $x253 false false)))
(let (($x48 (or $x816 false)))
(let (($x1875 (or $x48 (or (= ((_ extract 31 31) ?x179) (_ bv1 1))))))
(let (($x605 (or $x48 false)))
(let (($x742 (not $x605)))
(and $x742 (or $x1875 (and (distinct ?x1751 ?x953) true))))))))))))))))
(check-sat)
; query 34: function Autocorrelation, block 45, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let ((?x984 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.04_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x92 (bvxor ?x984 (_ bv1 1))))
(let ((?x179 ((_ zero_extend 31) ?x92)))
(let ((?x953 ((_ zero_extend 32) ?x179)))
(let (($x70 (and (distinct (ite (and (distinct (_ bv0 64) ((_ sign_extend 32) ?x179)) true) (_ bv1 1) (_ bv0 1)) (ite (and (distinct (_ bv0 64) ?x953) true) (_ bv1 1) (_ bv0 1))) true)))
(let (($x8 (or false false)))
(let (($x253 (or $x8 false false)))
(let (($x816 (or $x253 false false)))
(let (($x48 (or $x816 false)))
(let (($x1875 (or $x48 (or (= ((_ extract 31 31) ?x179) (_ bv1 1))))))
(let (($x305 (not (or (or $x48 false) false false))))
(and $x305 (or (or $x1875 false false) $x70))))))))))))))
(check-sat)
; query 35: function Calculation_of_the_LTP_parameters, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in11_16 () (_ BitVec 16))
(assert
 (let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x8 (and (distinct ((_ sign_extend 16) in11_16) ((_ sign_extend 16) in11_16)) true))))))
(check-sat)
; query 36: function Calculation_of_the_LTP_parameters, block 14, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in11_16 () (_ BitVec 16))
(assert
 (let ((?x766 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in11_16)) (_ bv1 1) (_ bv0 1))))
(let (($x8 (or false false)))
(let (($x253 (or $x8 false false)))
(let (($x122 (not $x253)))
(and $x122 (or $x253 (and (distinct ?x766 ?x766) true))))))))
(check-sat)
; query 37: function Calculation_of_the_LTP_parameters, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in11_16 () (_ BitVec 16))
(assert
 (let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x8 (and (distinct ((_ sign_extend 16) in11_16) ((_ sign_extend 16) in11_16)) true))))))
(check-sat)
; query 38: function Calculation_of_the_LTP_parameters, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in11_16 () (_ BitVec 16))
(assert
 (let ((?x532 ((_ sign_extend 16) in11_16)))
(let ((?x1246 (bvsub (_ bv0 32) ?x532)))
(let (($x819 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x532)) ((_ sign_extend 1) ?x1246)) true)))
(let (($x8 (or false false)))
(let (($x2673 (or false $x8 (or $x819))))
(and (not $x2673) (or $x2673 (and (distinct ?x1246 ?x1246) true)))))))))
(check-sat)
; query 39: function Calculation_of_the_LTP_parameters, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in11_16 () (_ BitVec 16))
(assert
 (let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x8 (and (distinct ((_ sign_extend 16) in11_16) ((_ sign_extend 16) in11_16)) true))))))
(check-sat)
; query 40: function Calculation_of_the_LTP_parameters, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_32 () (_ BitVec 32))
(assert
 (let (($x134 (and (distinct (bvadd ((_ sign_extend 1) in.03_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.03_32 (_ bv1 32)))) true)))
(let (($x127 (or false false (or $x134))))
(and (not $x127) (or $x127 (and (distinct (bvadd in.03_32 (_ bv1 32)) (bvadd in.03_32 (_ bv1 32))) true))))))
(check-sat)
; query 41: function Calculation_of_the_LTP_parameters, block 35, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x8 (and (distinct ((_ sign_extend 16) in.02_16) ((_ sign_extend 16) in.02_16)) true))))))
(check-sat)
; query 42: function Calculation_of_the_LTP_parameters, block 35, name %37
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x53 (ite (= (_ bv0 32) ((_ sign_extend 16) in.02_16)) (_ bv1 1) (_ bv0 1))))
(let (($x8 (or false false)))
(let (($x253 (or $x8 false false)))
(let (($x122 (not $x253)))
(and $x122 (or $x253 (and (distinct ?x53 ?x53) true))))))))
(check-sat)
; query 43: function Calculation_of_the_LTP_parameters, block 39, name %40
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x8 (and (distinct ((_ sign_extend 16) in.02_16) ((_ sign_extend 16) in.02_16)) true))))))
(check-sat)
; query 44: function Calculation_of_the_LTP_parameters, block 39, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x31 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.02_16)) (_ bv1 1) (_ bv0 1))))
(let (($x8 (or false false)))
(let (($x253 (or $x8 false false)))
(let (($x122 (not $x253)))
(and $x122 (or $x253 (and (distinct ?x31 ?x31) true))))))))
(check-sat)
; query 45: function Calculation_of_the_LTP_parameters, block 39, name %42
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x31 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.02_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x981 (bvxor ?x31 (_ bv1 1))))
(let (($x8 (or false false)))
(let (($x253 (or $x8 false false)))
(let (($x816 (or $x253 false false)))
(let (($x1837 (not $x816)))
(and $x1837 (or $x816 (and (distinct ?x981 ?x981) true))))))))))
(check-sat)
; query 46: function Calculation_of_the_LTP_parameters, block 39, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x31 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.02_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x981 (bvxor ?x31 (_ bv1 1))))
(let ((?x2653 ((_ zero_extend 31) ?x981)))
(let (($x8 (or false false)))
(let (($x253 (or $x8 false false)))
(let (($x816 (or $x253 false false)))
(let (($x48 (or $x816 false)))
(let (($x1825 (not $x48)))
(and $x1825 (or $x48 (and (distinct ?x2653 ?x2653) true))))))))))))
(check-sat)
; query 47: function Calculation_of_the_LTP_parameters, block 39, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x31 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.02_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x981 (bvxor ?x31 (_ bv1 1))))
(let ((?x2653 ((_ zero_extend 31) ?x981)))
(let ((?x1191 ((_ zero_extend 32) ?x2653)))
(let ((?x1377 ((_ sign_extend 32) ?x2653)))
(let (($x8 (or false false)))
(let (($x253 (or $x8 false false)))
(let (($x816 (or $x253 false false)))
(let (($x48 (or $x816 false)))
(let (($x62 (or $x48 (or (= ((_ extract 31 31) ?x2653) (_ bv1 1))))))
(let (($x605 (or $x48 false)))
(let (($x742 (not $x605)))
(and $x742 (or $x62 (and (distinct ?x1377 ?x1191) true))))))))))))))))
(check-sat)
; query 48: function Calculation_of_the_LTP_parameters, block 39, name %45
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x31 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.02_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x981 (bvxor ?x31 (_ bv1 1))))
(let ((?x2653 ((_ zero_extend 31) ?x981)))
(let ((?x1191 ((_ zero_extend 32) ?x2653)))
(let (($x209 (and (distinct (ite (and (distinct (_ bv0 64) ((_ sign_extend 32) ?x2653)) true) (_ bv1 1) (_ bv0 1)) (ite (and (distinct (_ bv0 64) ?x1191) true) (_ bv1 1) (_ bv0 1))) true)))
(let (($x8 (or false false)))
(let (($x253 (or $x8 false false)))
(let (($x816 (or $x253 false false)))
(let (($x48 (or $x816 false)))
(let (($x62 (or $x48 (or (= ((_ extract 31 31) ?x2653) (_ bv1 1))))))
(let (($x305 (not (or (or $x48 false) false false))))
(and $x305 (or (or $x62 false false) $x209))))))))))))))
(check-sat)
; query 49: function Decoding_of_the_coded_Log_Area_Ratios, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in20_64 () (_ BitVec 64))
(assert
 (let ((?x895 (ite (bvsge (_ bv18446744073709518848 64) in20_64) (_ bv1 1) (_ bv0 1))))
(let (($x118 (or false false false)))
(let (($x91 (not $x118)))
(and $x91 (or $x118 (and (distinct ?x895 ?x895) true)))))))
(check-sat)
; query 50: function Decoding_of_the_coded_Log_Area_Ratios, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in6_64 () (_ BitVec 64))
(assert
 (let ((?x619 (ite (bvslt (_ bv0 64) in6_64) (_ bv1 1) (_ bv0 1))))
(let (($x118 (or false false false)))
(let (($x91 (not $x118)))
(and $x91 (or $x118 (and (distinct ?x619 ?x619) true)))))))
(check-sat)
; query 51: function Decoding_of_the_coded_Log_Area_Ratios, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in6_64 () (_ BitVec 64))
(assert
 (let ((?x619 (ite (bvslt (_ bv0 64) in6_64) (_ bv1 1) (_ bv0 1))))
(let ((?x912 ((_ zero_extend 63) ?x619)))
(let (($x118 (or false false false)))
(let (($x420 (or $x118 false)))
(let (($x1168 (not $x420)))
(and $x1168 (or $x420 (and (distinct ?x912 ?x912) true)))))))))
(check-sat)
; query 52: function Decoding_of_the_coded_Log_Area_Ratios, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in6_64 () (_ BitVec 64))
(assert
 (let ((?x619 (ite (bvslt (_ bv0 64) in6_64) (_ bv1 1) (_ bv0 1))))
(let (($x603 (= (_ bv1 1) ?x619)))
(let ((?x1311 (ite $x603 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x118 (or false false false)))
(let (($x142 (or $x118 (ite $x603 false false))))
(and (not $x142) (or $x142 (and (distinct ?x1311 ?x1311) true)))))))))
(check-sat)
; query 53: function Decoding_of_the_coded_Log_Area_Ratios, block 9, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in6_64 () (_ BitVec 64))
(assert
 (let ((?x619 (ite (bvslt (_ bv0 64) in6_64) (_ bv1 1) (_ bv0 1))))
(let (($x603 (= (_ bv1 1) ?x619)))
(let ((?x1311 (ite $x603 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x1031 ((_ sign_extend 32) ?x1311)))
(let (($x118 (or false false false)))
(let (($x142 (or $x118 (ite $x603 false false))))
(let (($x1209 (or $x142 false)))
(and (not $x1209) (or $x1209 (and (distinct ?x1031 ?x1031) true)))))))))))
(check-sat)
; query 54: function Gsm_Coder, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in39_64 () (_ BitVec 64))
(assert
 (let ((?x537 (ite (bvslt (_ bv0 64) in39_64) (_ bv1 1) (_ bv0 1))))
(let (($x118 (or false false false)))
(let (($x91 (not $x118)))
(and $x91 (or $x118 (and (distinct ?x537 ?x537) true)))))))
(check-sat)
; query 55: function Gsm_Coder, block 42, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in39_64 () (_ BitVec 64))
(assert
 (let ((?x537 (ite (bvslt (_ bv0 64) in39_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1310 ((_ zero_extend 63) ?x537)))
(let (($x118 (or false false false)))
(let (($x420 (or $x118 false)))
(let (($x1168 (not $x420)))
(and $x1168 (or $x420 (and (distinct ?x1310 ?x1310) true)))))))))
(check-sat)
; query 56: function Gsm_Coder, block 42, name %45
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in39_64 () (_ BitVec 64))
(assert
 (let ((?x537 (ite (bvslt (_ bv0 64) in39_64) (_ bv1 1) (_ bv0 1))))
(let (($x1723 (= (_ bv1 1) ?x537)))
(let ((?x1307 (ite $x1723 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x118 (or false false false)))
(let (($x853 (or $x118 (ite $x1723 false false))))
(and (not $x853) (or $x853 (and (distinct ?x1307 ?x1307) true)))))))))
(check-sat)
; query 57: function Gsm_Coder, block 42, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in39_64 () (_ BitVec 64))
(assert
 (let ((?x537 (ite (bvslt (_ bv0 64) in39_64) (_ bv1 1) (_ bv0 1))))
(let (($x1723 (= (_ bv1 1) ?x537)))
(let ((?x1307 (ite $x1723 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x1774 ((_ sign_extend 32) ?x1307)))
(let (($x118 (or false false false)))
(let (($x853 (or $x118 (ite $x1723 false false))))
(let (($x1496 (or $x853 false)))
(and (not $x1496) (or $x1496 (and (distinct ?x1774 ?x1774) true)))))))))))
(check-sat)
; query 58: function Gsm_Coder, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1935 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x1177 (or false false (or $x1935))))
(and (not $x1177) (or $x1177 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 59: function Gsm_Decoder, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1935 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x1177 (or false false (or $x1935))))
(and (not $x1177) (or $x1177 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 60: function Gsm_Long_Term_Synthesis_Filtering, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x8 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 61: function Gsm_Long_Term_Synthesis_Filtering, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x8 (and (distinct ((_ sign_extend 16) in19_16) ((_ sign_extend 16) in19_16)) true))))))
(check-sat)
; query 62: function Gsm_Long_Term_Synthesis_Filtering, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x1661 (ite (bvsge (_ bv120 32) ((_ sign_extend 16) in19_16)) (_ bv1 1) (_ bv0 1))))
(let (($x8 (or false false)))
(let (($x253 (or $x8 false false)))
(let (($x122 (not $x253)))
(and $x122 (or $x253 (and (distinct ?x1661 ?x1661) true))))))))
(check-sat)
; query 63: function Gsm_Long_Term_Synthesis_Filtering, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1527 (ite (bvslt (_ bv120 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x8 (or false false)))
(let (($x253 (or $x8 false false)))
(let (($x122 (not $x253)))
(and $x122 (or $x253 (and (distinct ?x1527 ?x1527) true))))))))
(check-sat)
; query 64: function Gsm_Long_Term_Synthesis_Filtering, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x8 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 65: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x8 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 66: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1643 (ite (bvsgt (_ bv40 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x8 (or false false)))
(let (($x253 (or $x8 false false)))
(let (($x122 (not $x253)))
(and $x122 (or $x253 (and (distinct ?x1643 ?x1643) true))))))))
(check-sat)
; query 67: function LARp_to_rp, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x8 (and (distinct ((_ sign_extend 16) in19_16) ((_ sign_extend 16) in19_16)) true))))))
(check-sat)
; query 68: function LARp_to_rp, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x503 ((_ sign_extend 16) in19_16)))
(let ((?x649 (bvshl ?x503 (_ bv1 32))))
(let (($x98 (bvuge (_ bv1 32) (_ bv32 32))))
(let (($x8 (or false false)))
(let (($x1983 (or (or $x8 false (or (and (distinct (bvashr ?x649 (_ bv1 32)) ?x503) true))) $x98)))
(let (($x253 (or $x8 false false)))
(let (($x484 (or $x253 $x98)))
(let (($x1059 (not $x484)))
(and $x1059 (or $x1983 (and (distinct ?x649 ?x649) true))))))))))))
(check-sat)
; query 69: function LARp_to_rp, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x503 ((_ sign_extend 16) in19_16)))
(let ((?x649 (bvshl ?x503 (_ bv1 32))))
(let ((?x665 ((_ sign_extend 32) ?x649)))
(let (($x98 (bvuge (_ bv1 32) (_ bv32 32))))
(let (($x8 (or false false)))
(let (($x1983 (or (or $x8 false (or (and (distinct (bvashr ?x649 (_ bv1 32)) ?x503) true))) $x98)))
(and (not (or (or (or $x8 false false) $x98) false)) (or (or $x1983 false) (and (distinct ?x665 ?x665) true))))))))))
(check-sat)
; query 70: function LARp_to_rp, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x8 (and (distinct ((_ sign_extend 16) in19_16) ((_ sign_extend 16) in19_16)) true))))))
(check-sat)
; query 71: function LARp_to_rp, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x812 (ite (bvsgt (_ bv20070 32) ((_ sign_extend 16) in19_16)) (_ bv1 1) (_ bv0 1))))
(let (($x8 (or false false)))
(let (($x253 (or $x8 false false)))
(let (($x122 (not $x253)))
(and $x122 (or $x253 (and (distinct ?x812 ?x812) true))))))))
(check-sat)
; query 72: function LARp_to_rp, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x8 (and (distinct ((_ sign_extend 16) in19_16) ((_ sign_extend 16) in19_16)) true))))))
(check-sat)
; query 73: function LARp_to_rp, block 29, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x503 ((_ sign_extend 16) in19_16)))
(let ((?x423 (bvadd ?x503 (_ bv11059 32))))
(let (($x1308 (and (distinct (bvadd ((_ sign_extend 1) ?x503) ((_ sign_extend 1) (_ bv11059 32))) ((_ sign_extend 1) ?x423)) true)))
(let (($x8 (or false false)))
(let (($x1116 (or $x8 false (or $x1308))))
(and (not $x1116) (or $x1116 (and (distinct ?x423 ?x423) true)))))))))
(check-sat)
; query 74: function LARp_to_rp, block 29, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x503 ((_ sign_extend 16) in19_16)))
(let ((?x423 (bvadd ?x503 (_ bv11059 32))))
(let ((?x1554 ((_ sign_extend 32) ?x423)))
(let (($x1308 (and (distinct (bvadd ((_ sign_extend 1) ?x503) ((_ sign_extend 1) (_ bv11059 32))) ((_ sign_extend 1) ?x423)) true)))
(let (($x8 (or false false)))
(let (($x1116 (or $x8 false (or $x1308))))
(let (($x2322 (or $x1116 false)))
(and (not $x2322) (or $x2322 (and (distinct ?x1554 ?x1554) true)))))))))))
(check-sat)
; query 75: function LARp_to_rp, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x8 (and (distinct ((_ sign_extend 16) in19_16) ((_ sign_extend 16) in19_16)) true))))))
(check-sat)
; query 76: function LARp_to_rp, block 33, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x503 ((_ sign_extend 16) in19_16)))
(let ((?x1049 (bvashr ?x503 (_ bv2 32))))
(let (($x8 (or false false)))
(let (($x253 (or $x8 false false)))
(let (($x881 (or $x253 (bvuge (_ bv2 32) (_ bv32 32)))))
(and (not $x881) (or $x881 (and (distinct ?x1049 ?x1049) true)))))))))
(check-sat)
; query 77: function LARp_to_rp, block 33, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x503 ((_ sign_extend 16) in19_16)))
(let ((?x1049 (bvashr ?x503 (_ bv2 32))))
(let ((?x252 ((_ sign_extend 32) ?x1049)))
(let (($x8 (or false false)))
(let (($x253 (or $x8 false false)))
(let (($x881 (or $x253 (bvuge (_ bv2 32) (_ bv32 32)))))
(let (($x977 (or $x881 false)))
(and (not $x977) (or $x977 (and (distinct ?x252 ?x252) true)))))))))))
(check-sat)
; query 78: function LARp_to_rp, block 33, name %37
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x503 ((_ sign_extend 16) in19_16)))
(let ((?x1049 (bvashr ?x503 (_ bv2 32))))
(let ((?x252 ((_ sign_extend 32) ?x1049)))
(let ((?x1095 (bvadd ?x252 (_ bv26112 64))))
(let ((?x1443 ((_ sign_extend 1) ?x1095)))
(let (($x8 (or false false)))
(let (($x253 (or $x8 false false)))
(let (($x881 (or $x253 (bvuge (_ bv2 32) (_ bv32 32)))))
(let (($x977 (or $x881 false)))
(let (($x983 (or $x977 false (or (and (distinct (bvadd ((_ sign_extend 1) ?x252) ((_ sign_extend 1) (_ bv26112 64))) ?x1443) true)))))
(and (not $x983) (or $x983 (and (distinct ?x1095 ?x1095) true))))))))))))))
(check-sat)
; query 79: function LARp_to_rp, block 33, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x503 ((_ sign_extend 16) in19_16)))
(let ((?x1049 (bvashr ?x503 (_ bv2 32))))
(let ((?x252 ((_ sign_extend 32) ?x1049)))
(let ((?x1095 (bvadd ?x252 (_ bv26112 64))))
(let ((?x2361 (bvsub ?x1095 (_ bv18446744073709518848 64))))
(let (($x2347 (and (distinct (bvsub ((_ sign_extend 1) ?x1095) ((_ sign_extend 1) (_ bv18446744073709518848 64))) ((_ sign_extend 1) ?x2361)) true)))
(let ((?x1443 ((_ sign_extend 1) ?x1095)))
(let (($x8 (or false false)))
(let (($x253 (or $x8 false false)))
(let (($x881 (or $x253 (bvuge (_ bv2 32) (_ bv32 32)))))
(let (($x977 (or $x881 false)))
(let (($x983 (or $x977 false (or (and (distinct (bvadd ((_ sign_extend 1) ?x252) ((_ sign_extend 1) (_ bv26112 64))) ?x1443) true)))))
(let (($x1004 (or $x983 false (or $x2347))))
(and (not $x1004) (or $x1004 (and (distinct ?x2361 ?x2361) true)))))))))))))))))
(check-sat)
; query 80: function LARp_to_rp, block 33, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x503 ((_ sign_extend 16) in19_16)))
(let ((?x1049 (bvashr ?x503 (_ bv2 32))))
(let ((?x252 ((_ sign_extend 32) ?x1049)))
(let ((?x1095 (bvadd ?x252 (_ bv26112 64))))
(let ((?x2361 (bvsub ?x1095 (_ bv18446744073709518848 64))))
(let ((?x2459 (ite (bvugt ?x2361 (_ bv65535 64)) (_ bv1 1) (_ bv0 1))))
(let (($x2347 (and (distinct (bvsub ((_ sign_extend 1) ?x1095) ((_ sign_extend 1) (_ bv18446744073709518848 64))) ((_ sign_extend 1) ?x2361)) true)))
(let ((?x1443 ((_ sign_extend 1) ?x1095)))
(let (($x8 (or false false)))
(let (($x253 (or $x8 false false)))
(let (($x881 (or $x253 (bvuge (_ bv2 32) (_ bv32 32)))))
(let (($x977 (or $x881 false)))
(let (($x983 (or $x977 false (or (and (distinct (bvadd ((_ sign_extend 1) ?x252) ((_ sign_extend 1) (_ bv26112 64))) ?x1443) true)))))
(let (($x1004 (or $x983 false (or $x2347))))
(let (($x377 (or $x1004 false false)))
(and (not $x377) (or $x377 (and (distinct ?x2459 ?x2459) true)))))))))))))))))))
(check-sat)
; query 81: function Long_term_analysis_filtering, block 117, name %118
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in114_64 () (_ BitVec 64))
(assert
 (let ((?x1864 (ite (bvsge (_ bv18446744073709518848 64) in114_64) (_ bv1 1) (_ bv0 1))))
(let (($x118 (or false false false)))
(let (($x91 (not $x118)))
(and $x91 (or $x118 (and (distinct ?x1864 ?x1864) true)))))))
(check-sat)
; query 82: function Long_term_analysis_filtering, block 128, name %129
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let (($x2031 (and (distinct (bvadd ((_ sign_extend 1) in.2_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.2_32 (_ bv1 32)))) true)))
(let (($x1573 (or false false (or $x2031))))
(and (not $x1573) (or $x1573 (and (distinct (bvadd in.2_32 (_ bv1 32)) (bvadd in.2_32 (_ bv1 32))) true))))))
(check-sat)
; query 83: function Long_term_analysis_filtering, block 158, name %159
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in155_64 () (_ BitVec 64))
(assert
 (let ((?x553 (ite (bvsge (_ bv18446744073709518848 64) in155_64) (_ bv1 1) (_ bv0 1))))
(let (($x118 (or false false false)))
(let (($x91 (not $x118)))
(and $x91 (or $x118 (and (distinct ?x553 ?x553) true)))))))
(check-sat)
; query 84: function Long_term_analysis_filtering, block 169, name %170
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.3_32 () (_ BitVec 32))
(assert
 (let (($x1782 (and (distinct (bvadd ((_ sign_extend 1) in.3_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.3_32 (_ bv1 32)))) true)))
(let (($x789 (or false false (or $x1782))))
(and (not $x789) (or $x789 (and (distinct (bvadd in.3_32 (_ bv1 32)) (bvadd in.3_32 (_ bv1 32))) true))))))
(check-sat)
; query 85: function Long_term_analysis_filtering, block 35, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in32_64 () (_ BitVec 64))
(assert
 (let ((?x1205 (ite (bvsge (_ bv18446744073709518848 64) in32_64) (_ bv1 1) (_ bv0 1))))
(let (($x118 (or false false false)))
(let (($x91 (not $x118)))
(and $x91 (or $x118 (and (distinct ?x1205 ?x1205) true)))))))
(check-sat)
; query 86: function Long_term_analysis_filtering, block 46, name %47
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1935 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x1177 (or false false (or $x1935))))
(and (not $x1177) (or $x1177 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 87: function Long_term_analysis_filtering, block 76, name %77
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in73_64 () (_ BitVec 64))
(assert
 (let ((?x1137 (ite (bvsge (_ bv18446744073709518848 64) in73_64) (_ bv1 1) (_ bv0 1))))
(let (($x118 (or false false false)))
(let (($x91 (not $x118)))
(and $x91 (or $x118 (and (distinct ?x1137 ?x1137) true)))))))
(check-sat)
; query 88: function Long_term_analysis_filtering, block 87, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x911 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x363 (or false false (or $x911))))
(and (not $x363) (or $x363 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 89: function Postprocessing, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in17_64 () (_ BitVec 64))
(assert
 (let ((?x255 (ite (bvslt (_ bv0 64) in17_64) (_ bv1 1) (_ bv0 1))))
(let (($x118 (or false false false)))
(let (($x91 (not $x118)))
(and $x91 (or $x118 (and (distinct ?x255 ?x255) true)))))))
(check-sat)
; query 90: function Postprocessing, block 20, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in17_64 () (_ BitVec 64))
(assert
 (let ((?x255 (ite (bvslt (_ bv0 64) in17_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1056 ((_ zero_extend 63) ?x255)))
(let (($x118 (or false false false)))
(let (($x420 (or $x118 false)))
(let (($x1168 (not $x420)))
(and $x1168 (or $x420 (and (distinct ?x1056 ?x1056) true)))))))))
(check-sat)
; query 91: function Postprocessing, block 20, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in17_64 () (_ BitVec 64))
(assert
 (let ((?x255 (ite (bvslt (_ bv0 64) in17_64) (_ bv1 1) (_ bv0 1))))
(let (($x1894 (= (_ bv1 1) ?x255)))
(let ((?x1895 (ite $x1894 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x118 (or false false false)))
(let (($x1892 (or $x118 (ite $x1894 false false))))
(and (not $x1892) (or $x1892 (and (distinct ?x1895 ?x1895) true)))))))))
(check-sat)
; query 92: function Postprocessing, block 20, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in17_64 () (_ BitVec 64))
(assert
 (let ((?x255 (ite (bvslt (_ bv0 64) in17_64) (_ bv1 1) (_ bv0 1))))
(let (($x1894 (= (_ bv1 1) ?x255)))
(let ((?x1895 (ite $x1894 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x1893 ((_ sign_extend 32) ?x1895)))
(let (($x118 (or false false false)))
(let (($x1892 (or $x118 (ite $x1894 false false))))
(let (($x1867 (or $x1892 false)))
(and (not $x1867) (or $x1867 (and (distinct ?x1893 ?x1893) true)))))))))))
(check-sat)
; query 93: function Postprocessing, block 34, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in31_64 () (_ BitVec 64))
(assert
 (let ((?x473 (ite (bvslt (_ bv0 64) in31_64) (_ bv1 1) (_ bv0 1))))
(let (($x118 (or false false false)))
(let (($x91 (not $x118)))
(and $x91 (or $x118 (and (distinct ?x473 ?x473) true)))))))
(check-sat)
; query 94: function Postprocessing, block 34, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in31_64 () (_ BitVec 64))
(assert
 (let ((?x473 (ite (bvslt (_ bv0 64) in31_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1915 ((_ zero_extend 63) ?x473)))
(let (($x118 (or false false false)))
(let (($x420 (or $x118 false)))
(let (($x1168 (not $x420)))
(and $x1168 (or $x420 (and (distinct ?x1915 ?x1915) true)))))))))
(check-sat)
; query 95: function Postprocessing, block 34, name %37
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in31_64 () (_ BitVec 64))
(assert
 (let ((?x473 (ite (bvslt (_ bv0 64) in31_64) (_ bv1 1) (_ bv0 1))))
(let (($x1349 (= (_ bv1 1) ?x473)))
(let ((?x428 (ite $x1349 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x118 (or false false false)))
(let (($x770 (or $x118 (ite $x1349 false false))))
(and (not $x770) (or $x770 (and (distinct ?x428 ?x428) true)))))))))
(check-sat)
; query 96: function Postprocessing, block 34, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in31_64 () (_ BitVec 64))
(assert
 (let ((?x473 (ite (bvslt (_ bv0 64) in31_64) (_ bv1 1) (_ bv0 1))))
(let (($x1349 (= (_ bv1 1) ?x473)))
(let ((?x428 (ite $x1349 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x654 ((_ sign_extend 32) ?x428)))
(let (($x118 (or false false false)))
(let (($x770 (or $x118 (ite $x1349 false false))))
(let (($x1064 (or $x770 false)))
(and (not $x1064) (or $x1064 (and (distinct ?x654 ?x654) true)))))))))))
(check-sat)
; query 97: function RPE_grid_positioning, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x8 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 98: function RPE_grid_positioning, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x909 (ite (bvsge (_ bv3 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x8 (or false false)))
(let (($x253 (or $x8 false false)))
(let (($x122 (not $x253)))
(and $x122 (or $x253 (and (distinct ?x909 ?x909) true))))))))
(check-sat)
; query 99: function RPE_grid_positioning, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x8 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 100: function RPE_grid_positioning, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1096 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1015 (and (distinct ?x1096 ?x1096) true)))
(let (($x8 (or false false)))
(let (($x263 (or false $x8 false)))
(and (not $x263) (or $x263 $x1015)))))))
(check-sat)
; query 101: function RPE_grid_selection, block 308, name %309
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_32 () (_ BitVec 32))
(assert
 (let (($x134 (and (distinct (bvadd ((_ sign_extend 1) in.03_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.03_32 (_ bv1 32)))) true)))
(let (($x127 (or false false (or $x134))))
(and (not $x127) (or $x127 (and (distinct (bvadd in.03_32 (_ bv1 32)) (bvadd in.03_32 (_ bv1 32))) true))))))
(check-sat)
; query 102: function Short_term_analysis_filtering, block 34, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in31_64 () (_ BitVec 64))
(assert
 (let ((?x473 (ite (bvslt (_ bv0 64) in31_64) (_ bv1 1) (_ bv0 1))))
(let (($x118 (or false false false)))
(let (($x91 (not $x118)))
(and $x91 (or $x118 (and (distinct ?x473 ?x473) true)))))))
(check-sat)
; query 103: function Short_term_analysis_filtering, block 34, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in31_64 () (_ BitVec 64))
(assert
 (let ((?x473 (ite (bvslt (_ bv0 64) in31_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1915 ((_ zero_extend 63) ?x473)))
(let (($x118 (or false false false)))
(let (($x420 (or $x118 false)))
(let (($x1168 (not $x420)))
(and $x1168 (or $x420 (and (distinct ?x1915 ?x1915) true)))))))))
(check-sat)
; query 104: function Short_term_analysis_filtering, block 34, name %37
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in31_64 () (_ BitVec 64))
(assert
 (let ((?x473 (ite (bvslt (_ bv0 64) in31_64) (_ bv1 1) (_ bv0 1))))
(let (($x1349 (= (_ bv1 1) ?x473)))
(let ((?x428 (ite $x1349 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x118 (or false false false)))
(let (($x770 (or $x118 (ite $x1349 false false))))
(and (not $x770) (or $x770 (and (distinct ?x428 ?x428) true)))))))))
(check-sat)
; query 105: function Short_term_analysis_filtering, block 34, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in31_64 () (_ BitVec 64))
(assert
 (let ((?x473 (ite (bvslt (_ bv0 64) in31_64) (_ bv1 1) (_ bv0 1))))
(let (($x1349 (= (_ bv1 1) ?x473)))
(let ((?x428 (ite $x1349 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x654 ((_ sign_extend 32) ?x428)))
(let (($x118 (or false false false)))
(let (($x770 (or $x118 (ite $x1349 false false))))
(let (($x1064 (or $x770 false)))
(and (not $x1064) (or $x1064 (and (distinct ?x654 ?x654) true)))))))))))
(check-sat)
; query 106: function Short_term_analysis_filtering, block 54, name %55
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in51_64 () (_ BitVec 64))
(assert
 (let ((?x866 (ite (bvslt (_ bv0 64) in51_64) (_ bv1 1) (_ bv0 1))))
(let (($x118 (or false false false)))
(let (($x91 (not $x118)))
(and $x91 (or $x118 (and (distinct ?x866 ?x866) true)))))))
(check-sat)
; query 107: function Short_term_analysis_filtering, block 54, name %56
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in51_64 () (_ BitVec 64))
(assert
 (let ((?x866 (ite (bvslt (_ bv0 64) in51_64) (_ bv1 1) (_ bv0 1))))
(let ((?x960 ((_ zero_extend 63) ?x866)))
(let (($x118 (or false false false)))
(let (($x420 (or $x118 false)))
(let (($x1168 (not $x420)))
(and $x1168 (or $x420 (and (distinct ?x960 ?x960) true)))))))))
(check-sat)
; query 108: function Short_term_analysis_filtering, block 54, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in51_64 () (_ BitVec 64))
(assert
 (let ((?x866 (ite (bvslt (_ bv0 64) in51_64) (_ bv1 1) (_ bv0 1))))
(let (($x2697 (= (_ bv1 1) ?x866)))
(let ((?x2777 (ite $x2697 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x118 (or false false false)))
(let (($x975 (or $x118 (ite $x2697 false false))))
(and (not $x975) (or $x975 (and (distinct ?x2777 ?x2777) true)))))))))
(check-sat)
; query 109: function Short_term_analysis_filtering, block 54, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in51_64 () (_ BitVec 64))
(assert
 (let ((?x866 (ite (bvslt (_ bv0 64) in51_64) (_ bv1 1) (_ bv0 1))))
(let (($x2697 (= (_ bv1 1) ?x866)))
(let ((?x2777 (ite $x2697 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x1016 ((_ sign_extend 32) ?x2777)))
(let (($x118 (or false false false)))
(let (($x975 (or $x118 (ite $x2697 false false))))
(let (($x402 (or $x975 false)))
(and (not $x402) (or $x402 (and (distinct ?x1016 ?x1016) true)))))))))))
(check-sat)
; query 110: function Short_term_analysis_filtering, block 63, name %64
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_32 () (_ BitVec 32))
(assert
 (let (($x134 (and (distinct (bvadd ((_ sign_extend 1) in.03_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.03_32 (_ bv1 32)))) true)))
(let (($x127 (or false false (or $x134))))
(and (not $x127) (or $x127 (and (distinct (bvadd in.03_32 (_ bv1 32)) (bvadd in.03_32 (_ bv1 32))) true))))))
(check-sat)
; query 111: function Short_term_synthesis_filtering, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in23_16 () (_ BitVec 16))
(assert
 (let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x8 (and (distinct ((_ sign_extend 16) in23_16) ((_ sign_extend 16) in23_16)) true))))))
(check-sat)
; query 112: function Short_term_synthesis_filtering, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in23_16 () (_ BitVec 16))
(assert
 (let ((?x2678 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in23_16)) (_ bv1 1) (_ bv0 1))))
(let (($x8 (or false false)))
(let (($x253 (or $x8 false false)))
(let (($x122 (not $x253)))
(and $x122 (or $x253 (and (distinct ?x2678 ?x2678) true))))))))
(check-sat)
; query 113: function Short_term_synthesis_filtering, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in20_16 () (_ BitVec 16))
(assert
 (let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x8 (and (distinct ((_ sign_extend 48) in20_16) ((_ sign_extend 48) in20_16)) true))))))
(check-sat)
; query 114: function Short_term_synthesis_filtering, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in23_16 () (_ BitVec 16))
(assert
 (let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x8 (and (distinct ((_ sign_extend 48) in23_16) ((_ sign_extend 48) in23_16)) true))))))
(check-sat)
; query 115: function Short_term_synthesis_filtering, block 30, name %33
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in23_16 () (_ BitVec 16))
(declare-fun in20_16 () (_ BitVec 16))
(assert
 (let ((?x1260 ((_ sign_extend 48) in23_16)))
(let ((?x1170 ((_ sign_extend 48) in20_16)))
(let ((?x1541 (bvmul ?x1170 ?x1260)))
(let (($x1909 (and (distinct (bvmul ((_ sign_extend 64) ?x1170) ((_ sign_extend 64) ?x1260)) ((_ sign_extend 64) ?x1541)) true)))
(let (($x8 (or false false)))
(let (($x1908 (or $x8 $x8 (or $x1909))))
(and (not $x1908) (or $x1908 (and (distinct ?x1541 ?x1541) true))))))))))
(check-sat)
; query 116: function Short_term_synthesis_filtering, block 30, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in23_16 () (_ BitVec 16))
(declare-fun in20_16 () (_ BitVec 16))
(assert
 (let ((?x1260 ((_ sign_extend 48) in23_16)))
(let ((?x1170 ((_ sign_extend 48) in20_16)))
(let ((?x1541 (bvmul ?x1170 ?x1260)))
(let ((?x165 (bvadd ?x1541 (_ bv16384 64))))
(let (($x259 (and (distinct (bvadd ((_ sign_extend 1) ?x1541) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x165)) true)))
(let (($x1909 (and (distinct (bvmul ((_ sign_extend 64) ?x1170) ((_ sign_extend 64) ?x1260)) ((_ sign_extend 64) ?x1541)) true)))
(let (($x8 (or false false)))
(let (($x1908 (or $x8 $x8 (or $x1909))))
(let (($x606 (or $x1908 false (or $x259))))
(and (not $x606) (or $x606 (and (distinct ?x165 ?x165) true)))))))))))))
(check-sat)
; query 117: function Short_term_synthesis_filtering, block 30, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in23_16 () (_ BitVec 16))
(declare-fun in20_16 () (_ BitVec 16))
(assert
 (let ((?x1260 ((_ sign_extend 48) in23_16)))
(let ((?x1170 ((_ sign_extend 48) in20_16)))
(let ((?x1541 (bvmul ?x1170 ?x1260)))
(let ((?x165 (bvadd ?x1541 (_ bv16384 64))))
(let ((?x1856 (bvashr ?x165 (_ bv15 64))))
(let (($x262 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x259 (and (distinct (bvadd ((_ sign_extend 1) ?x1541) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x165)) true)))
(let (($x1909 (and (distinct (bvmul ((_ sign_extend 64) ?x1170) ((_ sign_extend 64) ?x1260)) ((_ sign_extend 64) ?x1541)) true)))
(let (($x8 (or false false)))
(let (($x1908 (or $x8 $x8 (or $x1909))))
(let (($x606 (or $x1908 false (or $x259))))
(let (($x229 (or (or $x606 false false) $x262)))
(and (not $x229) (or $x229 (and (distinct ?x1856 ?x1856) true))))))))))))))))
(check-sat)
; query 118: function Short_term_synthesis_filtering, block 30, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in23_16 () (_ BitVec 16))
(declare-fun in20_16 () (_ BitVec 16))
(assert
 (let ((?x1260 ((_ sign_extend 48) in23_16)))
(let ((?x1170 ((_ sign_extend 48) in20_16)))
(let ((?x1541 (bvmul ?x1170 ?x1260)))
(let ((?x165 (bvadd ?x1541 (_ bv16384 64))))
(let ((?x1856 (bvashr ?x165 (_ bv15 64))))
(let ((?x201 (bvand (_ bv65535 64) ?x1856)))
(let (($x262 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x259 (and (distinct (bvadd ((_ sign_extend 1) ?x1541) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x165)) true)))
(let (($x1909 (and (distinct (bvmul ((_ sign_extend 64) ?x1170) ((_ sign_extend 64) ?x1260)) ((_ sign_extend 64) ?x1541)) true)))
(let (($x8 (or false false)))
(let (($x1908 (or $x8 $x8 (or $x1909))))
(let (($x606 (or $x1908 false (or $x259))))
(let (($x229 (or (or $x606 false false) $x262)))
(let (($x1448 (or false $x229 false)))
(and (not $x1448) (or $x1448 (and (distinct ?x201 ?x201) true))))))))))))))))))
(check-sat)
; query 119: function Short_term_synthesis_filtering, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in42_64 () (_ BitVec 64))
(assert
 (let ((?x2783 (ite (bvsge (_ bv18446744073709518848 64) in42_64) (_ bv1 1) (_ bv0 1))))
(let (($x118 (or false false false)))
(let (($x91 (not $x118)))
(and $x91 (or $x118 (and (distinct ?x2783 ?x2783) true)))))))
(check-sat)
; query 120: function Short_term_synthesis_filtering, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x8 (and (distinct ((_ sign_extend 16) in53_16) ((_ sign_extend 16) in53_16)) true))))))
(check-sat)
; query 121: function Short_term_synthesis_filtering, block 56, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let ((?x2763 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in53_16)) (_ bv1 1) (_ bv0 1))))
(let (($x8 (or false false)))
(let (($x253 (or $x8 false false)))
(let (($x122 (not $x253)))
(and $x122 (or $x253 (and (distinct ?x2763 ?x2763) true))))))))
(check-sat)
; query 122: function Short_term_synthesis_filtering, block 60, name %61
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in20_16 () (_ BitVec 16))
(assert
 (let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x8 (and (distinct ((_ sign_extend 48) in20_16) ((_ sign_extend 48) in20_16)) true))))))
(check-sat)
; query 123: function Short_term_synthesis_filtering, block 60, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x8 (and (distinct ((_ sign_extend 48) in53_16) ((_ sign_extend 48) in53_16)) true))))))
(check-sat)
; query 124: function Short_term_synthesis_filtering, block 60, name %63
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(declare-fun in20_16 () (_ BitVec 16))
(assert
 (let ((?x1020 ((_ sign_extend 48) in53_16)))
(let ((?x1170 ((_ sign_extend 48) in20_16)))
(let ((?x2641 (bvmul ?x1170 ?x1020)))
(let (($x2599 (and (distinct (bvmul ((_ sign_extend 64) ?x1170) ((_ sign_extend 64) ?x1020)) ((_ sign_extend 64) ?x2641)) true)))
(let (($x8 (or false false)))
(let (($x802 (or $x8 $x8 (or $x2599))))
(and (not $x802) (or $x802 (and (distinct ?x2641 ?x2641) true))))))))))
(check-sat)
; query 125: function Short_term_synthesis_filtering, block 60, name %64
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(declare-fun in20_16 () (_ BitVec 16))
(assert
 (let ((?x1020 ((_ sign_extend 48) in53_16)))
(let ((?x1170 ((_ sign_extend 48) in20_16)))
(let ((?x2641 (bvmul ?x1170 ?x1020)))
(let ((?x1083 (bvadd ?x2641 (_ bv16384 64))))
(let (($x1224 (and (distinct (bvadd ((_ sign_extend 1) ?x2641) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x1083)) true)))
(let (($x2599 (and (distinct (bvmul ((_ sign_extend 64) ?x1170) ((_ sign_extend 64) ?x1020)) ((_ sign_extend 64) ?x2641)) true)))
(let (($x8 (or false false)))
(let (($x802 (or $x8 $x8 (or $x2599))))
(let (($x185 (or $x802 false (or $x1224))))
(and (not $x185) (or $x185 (and (distinct ?x1083 ?x1083) true)))))))))))))
(check-sat)
; query 126: function Short_term_synthesis_filtering, block 60, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(declare-fun in20_16 () (_ BitVec 16))
(assert
 (let ((?x1020 ((_ sign_extend 48) in53_16)))
(let ((?x1170 ((_ sign_extend 48) in20_16)))
(let ((?x2641 (bvmul ?x1170 ?x1020)))
(let ((?x1083 (bvadd ?x2641 (_ bv16384 64))))
(let ((?x1085 (bvashr ?x1083 (_ bv15 64))))
(let (($x262 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1224 (and (distinct (bvadd ((_ sign_extend 1) ?x2641) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x1083)) true)))
(let (($x2599 (and (distinct (bvmul ((_ sign_extend 64) ?x1170) ((_ sign_extend 64) ?x1020)) ((_ sign_extend 64) ?x2641)) true)))
(let (($x8 (or false false)))
(let (($x802 (or $x8 $x8 (or $x2599))))
(let (($x185 (or $x802 false (or $x1224))))
(let (($x884 (or (or $x185 false false) $x262)))
(and (not $x884) (or $x884 (and (distinct ?x1085 ?x1085) true))))))))))))))))
(check-sat)
; query 127: function Short_term_synthesis_filtering, block 60, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(declare-fun in20_16 () (_ BitVec 16))
(assert
 (let ((?x1020 ((_ sign_extend 48) in53_16)))
(let ((?x1170 ((_ sign_extend 48) in20_16)))
(let ((?x2641 (bvmul ?x1170 ?x1020)))
(let ((?x1083 (bvadd ?x2641 (_ bv16384 64))))
(let ((?x1085 (bvashr ?x1083 (_ bv15 64))))
(let ((?x344 (bvand (_ bv65535 64) ?x1085)))
(let (($x262 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1224 (and (distinct (bvadd ((_ sign_extend 1) ?x2641) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x1083)) true)))
(let (($x2599 (and (distinct (bvmul ((_ sign_extend 64) ?x1170) ((_ sign_extend 64) ?x1020)) ((_ sign_extend 64) ?x2641)) true)))
(let (($x8 (or false false)))
(let (($x802 (or $x8 $x8 (or $x2599))))
(let (($x185 (or $x802 false (or $x1224))))
(let (($x884 (or (or $x185 false false) $x262)))
(let (($x1057 (or false $x884 false)))
(and (not $x1057) (or $x1057 (and (distinct ?x344 ?x344) true))))))))))))))))))
(check-sat)
; query 128: function Short_term_synthesis_filtering, block 78, name %79
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in75_64 () (_ BitVec 64))
(assert
 (let ((?x677 (ite (bvslt (_ bv0 64) in75_64) (_ bv1 1) (_ bv0 1))))
(let (($x118 (or false false false)))
(let (($x91 (not $x118)))
(and $x91 (or $x118 (and (distinct ?x677 ?x677) true)))))))
(check-sat)
; query 129: function Short_term_synthesis_filtering, block 78, name %80
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in75_64 () (_ BitVec 64))
(assert
 (let ((?x677 (ite (bvslt (_ bv0 64) in75_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1022 ((_ zero_extend 63) ?x677)))
(let (($x118 (or false false false)))
(let (($x420 (or $x118 false)))
(let (($x1168 (not $x420)))
(and $x1168 (or $x420 (and (distinct ?x1022 ?x1022) true)))))))))
(check-sat)
; query 130: function Short_term_synthesis_filtering, block 78, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in75_64 () (_ BitVec 64))
(assert
 (let ((?x677 (ite (bvslt (_ bv0 64) in75_64) (_ bv1 1) (_ bv0 1))))
(let (($x271 (= (_ bv1 1) ?x677)))
(let ((?x1392 (ite $x271 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x118 (or false false false)))
(let (($x1281 (or $x118 (ite $x271 false false))))
(and (not $x1281) (or $x1281 (and (distinct ?x1392 ?x1392) true)))))))))
(check-sat)
; query 131: function Short_term_synthesis_filtering, block 78, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in75_64 () (_ BitVec 64))
(assert
 (let ((?x677 (ite (bvslt (_ bv0 64) in75_64) (_ bv1 1) (_ bv0 1))))
(let (($x271 (= (_ bv1 1) ?x677)))
(let ((?x1392 (ite $x271 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x1615 ((_ sign_extend 32) ?x1392)))
(let (($x118 (or false false false)))
(let (($x1281 (or $x118 (ite $x271 false false))))
(let (($x2602 (or $x1281 false)))
(and (not $x2602) (or $x2602 (and (distinct ?x1615 ?x1615) true)))))))))))
(check-sat)
; query 132: function Transformation_to_Log_Area_Ratios, block 12, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_16 () (_ BitVec 16))
(assert
 (let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x8 (and (distinct ((_ sign_extend 16) in5_16) ((_ sign_extend 16) in5_16)) true))))))
(check-sat)
; query 133: function Transformation_to_Log_Area_Ratios, block 12, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_16 () (_ BitVec 16))
(assert
 (let ((?x2802 ((_ sign_extend 16) in5_16)))
(let ((?x2805 (bvsub (_ bv0 32) ?x2802)))
(let (($x1075 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x2802)) ((_ sign_extend 1) ?x2805)) true)))
(let (($x8 (or false false)))
(let (($x2804 (or false $x8 (or $x1075))))
(and (not $x2804) (or $x2804 (and (distinct ?x2805 ?x2805) true)))))))))
(check-sat)
; query 134: function Transformation_to_Log_Area_Ratios, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_16 () (_ BitVec 16))
(assert
 (let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x8 (and (distinct ((_ sign_extend 16) in5_16) ((_ sign_extend 16) in5_16)) true))))))
(check-sat)
; query 135: function Transformation_to_Log_Area_Ratios, block 77, name %78
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x8 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 136: function Transformation_to_Log_Area_Ratios, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_16 () (_ BitVec 16))
(assert
 (let ((?x2725 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in5_16)) (_ bv1 1) (_ bv0 1))))
(let (($x8 (or false false)))
(let (($x253 (or $x8 false false)))
(let (($x122 (not $x253)))
(and $x122 (or $x253 (and (distinct ?x2725 ?x2725) true))))))))
(check-sat)
; query 137: function Transformation_to_Log_Area_Ratios, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_16 () (_ BitVec 16))
(assert
 (let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x8 (and (distinct ((_ sign_extend 16) in5_16) ((_ sign_extend 16) in5_16)) true))))))
(check-sat)
; query 138: function Weighting_filter, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in70_64 () (_ BitVec 64))
(assert
 (let ((?x143 (ite (bvslt (_ bv32767 64) in70_64) (_ bv1 1) (_ bv0 1))))
(let (($x118 (or false false false)))
(let (($x91 (not $x118)))
(and $x91 (or $x118 (and (distinct ?x143 ?x143) true)))))))
(check-sat)
; query 139: function Weighting_filter, block 84, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1935 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x1177 (or false false (or $x1935))))
(and (not $x1177) (or $x1177 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 140: function alaw_input, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x257 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x412 (or false false (or $x257))))
(and (not $x412) (or $x412 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 141: function alaw_input, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let ((?x1882 (ite (= (_ bv4294967295 32) in.1_32) (_ bv1 1) (_ bv0 1))))
(let (($x118 (or false false false)))
(let (($x91 (not $x118)))
(and $x91 (or $x118 (and (distinct ?x1882 ?x1882) true)))))))
(check-sat)
; query 142: function gsm_L_add, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_64 () (_ BitVec 64))
(assert
 (let ((?x224 (bvsub (_ bv0 64) in13_64)))
(let ((?x1217 ((_ sign_extend 1) ?x224)))
(let (($x1192 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in13_64)) ?x1217) true)))))
(and (not $x1192) (or $x1192 (and (distinct ?x224 ?x224) true)))))))
(check-sat)
; query 143: function gsm_L_add, block 16, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_64 () (_ BitVec 64))
(assert
 (let ((?x224 (bvsub (_ bv0 64) in13_64)))
(let ((?x1638 (bvsub ?x224 (_ bv2 64))))
(let (($x139 (and (distinct (bvsub ((_ sign_extend 1) ?x224) ((_ sign_extend 1) (_ bv2 64))) ((_ sign_extend 1) ?x1638)) true)))
(let ((?x1217 ((_ sign_extend 1) ?x224)))
(let (($x1192 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in13_64)) ?x1217) true)))))
(let (($x85 (or $x1192 false (or $x139))))
(and (not $x85) (or $x85 (and (distinct ?x1638 ?x1638) true))))))))))
(check-sat)
; query 144: function gsm_L_add, block 21, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x240 (ite (bvsge (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x118 (or false false false)))
(let (($x91 (not $x118)))
(and $x91 (or $x118 (and (distinct ?x240 ?x240) true)))))))
(check-sat)
; query 145: function gsm_L_add, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2650 (bvadd in0_64 in1_64)))
(let (($x1836 (and (distinct ?x2650 ?x2650) true)))
(let (($x1318 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) ?x2650)) true)))
(let (($x1576 (or false false (or $x1318))))
(and (not $x1576) (or $x1576 $x1836)))))))
(check-sat)
; query 146: function gsm_L_add, block 25, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2650 (bvadd in0_64 in1_64)))
(let (($x1836 (and (distinct ?x2650 ?x2650) true)))
(let (($x38 (and (distinct (bvadd ((_ zero_extend 1) in0_64) ((_ zero_extend 1) in1_64)) ((_ zero_extend 1) ?x2650)) true)))
(let (($x572 (or false false (or $x38))))
(let (($x118 (or false false false)))
(let (($x91 (not $x118)))
(and $x91 (or $x572 $x1836)))))))))
(check-sat)
; query 147: function gsm_L_add, block 25, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x558 (ite (bvugt (bvadd in0_64 in1_64) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x38 (and (distinct (bvadd ((_ zero_extend 1) in0_64) ((_ zero_extend 1) in1_64)) ((_ zero_extend 1) (bvadd in0_64 in1_64))) true)))
(let (($x572 (or false false (or $x38))))
(let (($x118 (or false false false)))
(let (($x446 (or $x118 false false)))
(let (($x585 (not $x446)))
(and $x585 (or (or $x572 false false) (and (distinct ?x558 ?x558) true))))))))))
(check-sat)
; query 148: function gsm_L_add, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x2066 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x118 (or false false false)))
(let (($x91 (not $x118)))
(and $x91 (or $x118 (and (distinct ?x2066 ?x2066) true)))))))
(check-sat)
; query 149: function gsm_L_add, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2650 (bvadd in0_64 in1_64)))
(let (($x1836 (and (distinct ?x2650 ?x2650) true)))
(let (($x1318 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) ?x2650)) true)))
(let (($x1576 (or false false (or $x1318))))
(and (not $x1576) (or $x1576 $x1836)))))))
(check-sat)
; query 150: function gsm_L_add, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1851 (bvadd in0_64 (_ bv1 64))))
(let ((?x1734 (bvsub (_ bv0 64) ?x1851)))
(let (($x1421 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1851)) ((_ sign_extend 1) ?x1734)) true)))
(let ((?x1471 ((_ sign_extend 1) ?x1851)))
(let (($x1517 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1471) true)))))
(let (($x1560 (or false $x1517 (or $x1421))))
(and (not $x1560) (or $x1560 (and (distinct ?x1734 ?x1734) true))))))))))
(check-sat)
; query 151: function gsm_L_add, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x145 (bvadd in1_64 (_ bv1 64))))
(let ((?x1415 ((_ sign_extend 1) ?x145)))
(let (($x697 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1415) true)))))
(and (not $x697) (or $x697 (and (distinct ?x145 ?x145) true)))))))
(check-sat)
; query 152: function gsm_L_add, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x145 (bvadd in1_64 (_ bv1 64))))
(let ((?x1785 (bvsub (_ bv0 64) ?x145)))
(let (($x1513 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x145)) ((_ sign_extend 1) ?x1785)) true)))
(let ((?x1415 ((_ sign_extend 1) ?x145)))
(let (($x697 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1415) true)))))
(let (($x192 (or false $x697 (or $x1513))))
(and (not $x192) (or $x192 (and (distinct ?x1785 ?x1785) true))))))))))
(check-sat)
; query 153: function gsm_L_add, block 8, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x145 (bvadd in1_64 (_ bv1 64))))
(let ((?x1785 (bvsub (_ bv0 64) ?x145)))
(let ((?x1851 (bvadd in0_64 (_ bv1 64))))
(let ((?x1734 (bvsub (_ bv0 64) ?x1851)))
(let ((?x667 (bvadd ?x1734 ?x1785)))
(let (($x1858 (and (distinct (bvadd ((_ zero_extend 1) ?x1734) ((_ zero_extend 1) ?x1785)) ((_ zero_extend 1) ?x667)) true)))
(let (($x1513 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x145)) ((_ sign_extend 1) ?x1785)) true)))
(let ((?x1415 ((_ sign_extend 1) ?x145)))
(let (($x697 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1415) true)))))
(let (($x192 (or false $x697 (or $x1513))))
(let (($x1421 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1851)) ((_ sign_extend 1) ?x1734)) true)))
(let ((?x1471 ((_ sign_extend 1) ?x1851)))
(let (($x1517 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1471) true)))))
(let (($x1560 (or false $x1517 (or $x1421))))
(let (($x626 (or $x1560 $x192 (or $x1858))))
(and (not (or $x1560 $x192 false)) (or $x626 (and (distinct ?x667 ?x667) true)))))))))))))))))))
(check-sat)
; query 154: function gsm_L_add, block 8, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x145 (bvadd in1_64 (_ bv1 64))))
(let ((?x1785 (bvsub (_ bv0 64) ?x145)))
(let ((?x1851 (bvadd in0_64 (_ bv1 64))))
(let ((?x1734 (bvsub (_ bv0 64) ?x1851)))
(let ((?x667 (bvadd ?x1734 ?x1785)))
(let ((?x1389 (ite (bvuge ?x667 (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x1858 (and (distinct (bvadd ((_ zero_extend 1) ?x1734) ((_ zero_extend 1) ?x1785)) ((_ zero_extend 1) ?x667)) true)))
(let (($x1513 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x145)) ((_ sign_extend 1) ?x1785)) true)))
(let ((?x1415 ((_ sign_extend 1) ?x145)))
(let (($x697 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1415) true)))))
(let (($x192 (or false $x697 (or $x1513))))
(let (($x1421 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1851)) ((_ sign_extend 1) ?x1734)) true)))
(let ((?x1471 ((_ sign_extend 1) ?x1851)))
(let (($x1517 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1471) true)))))
(let (($x1560 (or false $x1517 (or $x1421))))
(let (($x626 (or $x1560 $x192 (or $x1858))))
(and (not (or (or $x1560 $x192 false) false false)) (or (or $x626 false false) (and (distinct ?x1389 ?x1389) true))))))))))))))))))))
(check-sat)
; query 155: function gsm_L_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1851 (bvadd in0_64 (_ bv1 64))))
(let ((?x1471 ((_ sign_extend 1) ?x1851)))
(let (($x1517 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1471) true)))))
(and (not $x1517) (or $x1517 (and (distinct ?x1851 ?x1851) true)))))))
(check-sat)
; query 156: function gsm_L_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x662 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x118 (or false false false)))
(let (($x91 (not $x118)))
(and $x91 (or $x118 (and (distinct ?x662 ?x662) true)))))))
(check-sat)
; query 157: function gsm_L_asl, block 12, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x346 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x118 (or false false false)))
(let (($x91 (not $x118)))
(and $x91 (or $x118 (and (distinct ?x346 ?x346) true)))))))
(check-sat)
; query 158: function gsm_L_asl, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x2774 (or false (or (= ((_ extract 31 31) in1_32) (_ bv1 1))))))
(let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x2774 (and (distinct ((_ zero_extend 32) in1_32) ((_ zero_extend 32) in1_32)) true)))))))
(check-sat)
; query 159: function gsm_L_asl, block 17, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2674 ((_ zero_extend 32) in1_32)))
(let ((?x2619 (bvshl in0_64 ?x2674)))
(let (($x547 (bvuge ?x2674 (_ bv64 64))))
(let (($x1371 (or (or false (or false (or (= ((_ extract 31 31) in1_32) (_ bv1 1)))) false) $x547)))
(let (($x1440 (not (or (or false (or false false) false) $x547))))
(and $x1440 (or $x1371 (and (distinct ?x2619 ?x2619) true)))))))))
(check-sat)
; query 160: function gsm_L_asl, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1679 (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x118 (or false false false)))
(let (($x91 (not $x118)))
(and $x91 (or $x118 (and (distinct ?x1679 ?x1679) true)))))))
(check-sat)
; query 161: function gsm_L_asl, block 7, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x662 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x971 ((_ zero_extend 31) ?x662)))
(let ((?x2773 (bvsub (_ bv0 32) ?x971)))
(let (($x631 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x971)) ((_ sign_extend 1) ?x2773)) true)))
(let (($x118 (or false false false)))
(let (($x420 (or $x118 false)))
(let (($x751 (or false $x420 (or $x631))))
(and (not $x751) (or $x751 (and (distinct ?x2773 ?x2773) true)))))))))))
(check-sat)
; query 162: function gsm_L_asl, block 7, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x662 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x971 ((_ zero_extend 31) ?x662)))
(let ((?x2773 (bvsub (_ bv0 32) ?x971)))
(let ((?x1930 ((_ sign_extend 32) ?x2773)))
(let (($x631 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x971)) ((_ sign_extend 1) ?x2773)) true)))
(let (($x118 (or false false false)))
(let (($x420 (or $x118 false)))
(let (($x751 (or false $x420 (or $x631))))
(let (($x1944 (or $x751 false)))
(and (not $x1944) (or $x1944 (and (distinct ?x1930 ?x1930) true)))))))))))))
(check-sat)
; query 163: function gsm_L_asl, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x662 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x118 (or false false false)))
(let (($x91 (not $x118)))
(and $x91 (or $x118 (and (distinct ?x662 ?x662) true)))))))
(check-sat)
; query 164: function gsm_L_asl, block 7, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x662 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x971 ((_ zero_extend 31) ?x662)))
(let (($x118 (or false false false)))
(let (($x420 (or $x118 false)))
(let (($x1168 (not $x420)))
(and $x1168 (or $x420 (and (distinct ?x971 ?x971) true)))))))))
(check-sat)
; query 165: function gsm_L_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1982 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x118 (or false false false)))
(let (($x91 (not $x118)))
(and $x91 (or $x118 (and (distinct ?x1982 ?x1982) true)))))))
(check-sat)
; query 166: function gsm_L_asr, block 12, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x346 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x118 (or false false false)))
(let (($x91 (not $x118)))
(and $x91 (or $x118 (and (distinct ?x346 ?x346) true)))))))
(check-sat)
; query 167: function gsm_L_asr, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x2389 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in1_32))) true)))
(let (($x2222 (or false false (or $x2389))))
(and (not $x2222) (or $x2222 (and (distinct (bvsub (_ bv0 32) in1_32) (bvsub (_ bv0 32) in1_32)) true))))))
(check-sat)
; query 168: function gsm_L_asr, block 14, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x339 (bvsub (_ bv0 32) in1_32)))
(let ((?x2610 ((_ zero_extend 32) ?x339)))
(let (($x2389 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x339)) true)))
(let (($x2222 (or false false (or $x2389))))
(let (($x1657 (or $x2222 (or (= ((_ extract 31 31) ?x339) (_ bv1 1))))))
(and (not (or $x2222 false)) (or $x1657 (and (distinct ?x2610 ?x2610) true)))))))))
(check-sat)
; query 169: function gsm_L_asr, block 14, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x339 (bvsub (_ bv0 32) in1_32)))
(let ((?x2610 ((_ zero_extend 32) ?x339)))
(let ((?x2691 (bvshl in0_64 ?x2610)))
(let (($x741 (bvuge ?x2610 (_ bv64 64))))
(let (($x2389 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x339)) true)))
(let (($x2222 (or false false (or $x2389))))
(let (($x1657 (or $x2222 (or (= ((_ extract 31 31) ?x339) (_ bv1 1))))))
(and (not (or (or false (or $x2222 false) false) $x741)) (or (or (or false $x1657 false) $x741) (and (distinct ?x2691 ?x2691) true)))))))))))
(check-sat)
; query 170: function gsm_L_asr, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x2774 (or false (or (= ((_ extract 31 31) in1_32) (_ bv1 1))))))
(let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x2774 (and (distinct ((_ zero_extend 32) in1_32) ((_ zero_extend 32) in1_32)) true)))))))
(check-sat)
; query 171: function gsm_L_asr, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2674 ((_ zero_extend 32) in1_32)))
(let ((?x2615 (bvashr in0_64 ?x2674)))
(let (($x547 (bvuge ?x2674 (_ bv64 64))))
(let (($x1371 (or (or false (or false (or (= ((_ extract 31 31) in1_32) (_ bv1 1)))) false) $x547)))
(let (($x1440 (not (or (or false (or false false) false) $x547))))
(and $x1440 (or $x1371 (and (distinct ?x2615 ?x2615) true)))))))))
(check-sat)
; query 172: function gsm_L_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x662 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x118 (or false false false)))
(let (($x91 (not $x118)))
(and $x91 (or $x118 (and (distinct ?x662 ?x662) true)))))))
(check-sat)
; query 173: function gsm_L_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x662 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x971 ((_ zero_extend 31) ?x662)))
(let (($x118 (or false false false)))
(let (($x420 (or $x118 false)))
(let (($x1168 (not $x420)))
(and $x1168 (or $x420 (and (distinct ?x971 ?x971) true)))))))))
(check-sat)
; query 174: function gsm_L_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x662 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x971 ((_ zero_extend 31) ?x662)))
(let ((?x2773 (bvsub (_ bv0 32) ?x971)))
(let (($x631 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x971)) ((_ sign_extend 1) ?x2773)) true)))
(let (($x118 (or false false false)))
(let (($x420 (or $x118 false)))
(let (($x751 (or false $x420 (or $x631))))
(and (not $x751) (or $x751 (and (distinct ?x2773 ?x2773) true)))))))))))
(check-sat)
; query 175: function gsm_L_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x662 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x971 ((_ zero_extend 31) ?x662)))
(let ((?x2773 (bvsub (_ bv0 32) ?x971)))
(let ((?x1930 ((_ sign_extend 32) ?x2773)))
(let (($x631 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x971)) ((_ sign_extend 1) ?x2773)) true)))
(let (($x118 (or false false false)))
(let (($x420 (or $x118 false)))
(let (($x751 (or false $x420 (or $x631))))
(let (($x1944 (or $x751 false)))
(and (not $x1944) (or $x1944 (and (distinct ?x1930 ?x1930) true)))))))))))))
(check-sat)
; query 176: function gsm_L_asr, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1679 (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x118 (or false false false)))
(let (($x91 (not $x118)))
(and $x91 (or $x118 (and (distinct ?x1679 ?x1679) true)))))))
(check-sat)
; query 177: function gsm_L_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1982 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x118 (or false false false)))
(let (($x91 (not $x118)))
(and $x91 (or $x118 (and (distinct ?x1982 ?x1982) true)))))))
(check-sat)
; query 178: function gsm_L_mult, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x8 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 179: function gsm_L_mult, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x2616 (ite (and (distinct (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) true) (_ bv1 1) (_ bv0 1))))
(let (($x8 (or false false)))
(let (($x253 (or $x8 false false)))
(let (($x122 (not $x253)))
(and $x122 (or $x253 (and (distinct ?x2616 ?x2616) true))))))))
(check-sat)
; query 180: function gsm_L_mult, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x8 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 181: function gsm_L_mult, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1828 (ite (and (distinct (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) true) (_ bv1 1) (_ bv0 1))))
(let (($x8 (or false false)))
(let (($x253 (or $x8 false false)))
(let (($x122 (not $x253)))
(and $x122 (or $x253 (and (distinct ?x1828 ?x1828) true))))))))
(check-sat)
; query 182: function gsm_L_sub, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in11_64 () (_ BitVec 64))
(assert
 (let (($x109 (and (distinct (bvadd ((_ zero_extend 1) in11_64) ((_ zero_extend 1) (_ bv1 64))) ((_ zero_extend 1) (bvadd in11_64 (_ bv1 64)))) true)))
(let (($x1403 (and (distinct (bvadd ((_ sign_extend 1) in11_64) ((_ sign_extend 1) (_ bv1 64))) ((_ sign_extend 1) (bvadd in11_64 (_ bv1 64)))) true)))
(let (($x1690 (or (or false false (or $x1403 $x109)) (and (distinct (bvadd in11_64 (_ bv1 64)) (bvadd in11_64 (_ bv1 64))) true))))
(let (($x118 (or false false false)))
(let (($x91 (not $x118)))
(and $x91 $x1690)))))))
(check-sat)
; query 183: function gsm_L_sub, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x240 (ite (bvsge (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x118 (or false false false)))
(let (($x91 (not $x118)))
(and $x91 (or $x118 (and (distinct ?x240 ?x240) true)))))))
(check-sat)
; query 184: function gsm_L_sub, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x2707 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvsub in0_64 in1_64))) true)))
(let (($x1033 (or false false (or $x2707))))
(let (($x2687 (or $x1033 (and (distinct (bvsub in0_64 in1_64) (bvsub in0_64 in1_64)) true))))
(and (not $x1033) $x2687)))))
(check-sat)
; query 185: function gsm_L_sub, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1851 (bvadd in0_64 (_ bv1 64))))
(let ((?x1471 ((_ sign_extend 1) ?x1851)))
(let (($x1517 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1471) true)))))
(and (not $x1517) (or $x1517 (and (distinct ?x1851 ?x1851) true)))))))
(check-sat)
; query 186: function gsm_L_sub, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1851 (bvadd in0_64 (_ bv1 64))))
(let ((?x1734 (bvsub (_ bv0 64) ?x1851)))
(let (($x1421 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1851)) ((_ sign_extend 1) ?x1734)) true)))
(let ((?x1471 ((_ sign_extend 1) ?x1851)))
(let (($x1517 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1471) true)))))
(let (($x1560 (or false $x1517 (or $x1421))))
(and (not $x1560) (or $x1560 (and (distinct ?x1734 ?x1734) true))))))))))
(check-sat)
; query 187: function gsm_L_sub, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1851 (bvadd in0_64 (_ bv1 64))))
(let ((?x1734 (bvsub (_ bv0 64) ?x1851)))
(let ((?x803 (bvadd ?x1734 in1_64)))
(let (($x1053 (and (distinct (bvadd ((_ zero_extend 1) ?x1734) ((_ zero_extend 1) in1_64)) ((_ zero_extend 1) ?x803)) true)))
(let (($x1421 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1851)) ((_ sign_extend 1) ?x1734)) true)))
(let ((?x1471 ((_ sign_extend 1) ?x1851)))
(let (($x1517 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1471) true)))))
(let (($x1560 (or false $x1517 (or $x1421))))
(let (($x1721 (or $x1560 false (or $x1053))))
(and (not (or $x1560 false false)) (or $x1721 (and (distinct ?x803 ?x803) true)))))))))))))
(check-sat)
; query 188: function gsm_L_sub, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1730 (ite (bvuge (bvadd (bvsub (_ bv0 64) (bvadd in0_64 (_ bv1 64))) in1_64) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let ((?x424 ((_ zero_extend 1) in1_64)))
(let ((?x1851 (bvadd in0_64 (_ bv1 64))))
(let ((?x1734 (bvsub (_ bv0 64) ?x1851)))
(let ((?x1273 ((_ zero_extend 1) ?x1734)))
(let (($x1421 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1851)) ((_ sign_extend 1) ?x1734)) true)))
(let ((?x1471 ((_ sign_extend 1) ?x1851)))
(let (($x1517 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1471) true)))))
(let (($x1560 (or false $x1517 (or $x1421))))
(let (($x1721 (or $x1560 false (or (and (distinct (bvadd ?x1273 ?x424) ((_ zero_extend 1) (bvadd ?x1734 in1_64))) true)))))
(and (not (or (or $x1560 false false) false false)) (or (or $x1721 false false) (and (distinct ?x1730 ?x1730) true))))))))))))))
(check-sat)
; query 189: function gsm_L_sub, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_64 () (_ BitVec 64))
(assert
 (let ((?x514 (bvsub (_ bv0 64) in25_64)))
(let ((?x1051 ((_ sign_extend 1) ?x514)))
(let (($x1120 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in25_64)) ?x1051) true)))))
(and (not $x1120) (or $x1120 (and (distinct ?x514 ?x514) true)))))))
(check-sat)
; query 190: function gsm_L_sub, block 28, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_64 () (_ BitVec 64))
(assert
 (let ((?x514 (bvsub (_ bv0 64) in25_64)))
(let ((?x1437 (bvsub ?x514 (_ bv1 64))))
(let (($x663 (and (distinct (bvsub ((_ zero_extend 1) ?x514) ((_ zero_extend 1) (_ bv1 64))) ((_ zero_extend 1) ?x1437)) true)))
(let (($x1842 (and (distinct (bvsub ((_ sign_extend 1) ?x514) ((_ sign_extend 1) (_ bv1 64))) ((_ sign_extend 1) ?x1437)) true)))
(let ((?x1051 ((_ sign_extend 1) ?x514)))
(let (($x1120 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in25_64)) ?x1051) true)))))
(and (not (or $x1120 false (or $x1842))) (or (or $x1120 false (or $x1842 $x663)) (and (distinct ?x1437 ?x1437) true))))))))))
(check-sat)
; query 191: function gsm_L_sub, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x2066 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x118 (or false false false)))
(let (($x91 (not $x118)))
(and $x91 (or $x118 (and (distinct ?x2066 ?x2066) true)))))))
(check-sat)
; query 192: function gsm_L_sub, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x2707 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvsub in0_64 in1_64))) true)))
(let (($x1033 (or false false (or $x2707))))
(let (($x2687 (or $x1033 (and (distinct (bvsub in0_64 in1_64) (bvsub in0_64 in1_64)) true))))
(and (not $x1033) $x2687)))))
(check-sat)
; query 193: function gsm_L_sub, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x145 (bvadd in1_64 (_ bv1 64))))
(let ((?x1785 (bvsub (_ bv0 64) ?x145)))
(let (($x1513 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x145)) ((_ sign_extend 1) ?x1785)) true)))
(let ((?x1415 ((_ sign_extend 1) ?x145)))
(let (($x697 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1415) true)))))
(let (($x192 (or false $x697 (or $x1513))))
(and (not $x192) (or $x192 (and (distinct ?x1785 ?x1785) true))))))))))
(check-sat)
; query 194: function gsm_L_sub, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x145 (bvadd in1_64 (_ bv1 64))))
(let ((?x1785 (bvsub (_ bv0 64) ?x145)))
(let ((?x2671 (bvadd in0_64 ?x1785)))
(let (($x1265 (and (distinct (bvadd ((_ zero_extend 1) in0_64) ((_ zero_extend 1) ?x1785)) ((_ zero_extend 1) ?x2671)) true)))
(let (($x1513 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x145)) ((_ sign_extend 1) ?x1785)) true)))
(let ((?x1415 ((_ sign_extend 1) ?x145)))
(let (($x697 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1415) true)))))
(let (($x192 (or false $x697 (or $x1513))))
(let (($x550 (or false $x192 (or $x1265))))
(and (not (or false $x192 false)) (or $x550 (and (distinct ?x2671 ?x2671) true)))))))))))))
(check-sat)
; query 195: function gsm_L_sub, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1815 (ite (bvuge (bvadd in0_64 (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64)))) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let ((?x145 (bvadd in1_64 (_ bv1 64))))
(let ((?x1785 (bvsub (_ bv0 64) ?x145)))
(let ((?x123 ((_ zero_extend 1) ?x1785)))
(let ((?x581 ((_ zero_extend 1) in0_64)))
(let (($x1513 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x145)) ((_ sign_extend 1) ?x1785)) true)))
(let ((?x1415 ((_ sign_extend 1) ?x145)))
(let (($x697 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1415) true)))))
(let (($x192 (or false $x697 (or $x1513))))
(let (($x550 (or false $x192 (or (and (distinct (bvadd ?x581 ?x123) ((_ zero_extend 1) (bvadd in0_64 ?x1785))) true)))))
(and (not (or (or false $x192 false) false false)) (or (or $x550 false false) (and (distinct ?x1815 ?x1815) true))))))))))))))
(check-sat)
; query 196: function gsm_L_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x145 (bvadd in1_64 (_ bv1 64))))
(let ((?x1415 ((_ sign_extend 1) ?x145)))
(let (($x697 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1415) true)))))
(and (not $x697) (or $x697 (and (distinct ?x145 ?x145) true)))))))
(check-sat)
; query 197: function gsm_L_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1055 (ite (bvsle (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x118 (or false false false)))
(let (($x91 (not $x118)))
(and $x91 (or $x118 (and (distinct ?x1055 ?x1055) true)))))))
(check-sat)
; query 198: function gsm_abs, block 13, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x8 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 199: function gsm_abs, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x8 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 200: function gsm_abs, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x722 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x8 (or false false)))
(let (($x253 (or $x8 false false)))
(let (($x122 (not $x253)))
(and $x122 (or $x253 (and (distinct ?x722 ?x722) true))))))))
(check-sat)
; query 201: function gsm_abs, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x627 ((_ sign_extend 16) in0_16)))
(let ((?x1411 (bvsub (_ bv0 32) ?x627)))
(let (($x1703 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x627)) ((_ sign_extend 1) ?x1411)) true)))
(let (($x8 (or false false)))
(let (($x1829 (or false $x8 (or $x1703))))
(and (not $x1829) (or $x1829 (and (distinct ?x1411 ?x1411) true)))))))))
(check-sat)
; query 202: function gsm_abs, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x8 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 203: function gsm_abs, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x8 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 204: function gsm_abs, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x520 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x8 (or false false)))
(let (($x253 (or $x8 false false)))
(let (($x122 (not $x253)))
(and $x122 (or $x253 (and (distinct ?x520 ?x520) true))))))))
(check-sat)
; query 205: function gsm_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_64 () (_ BitVec 64))
(assert
 (let ((?x471 (ite (bvslt (_ bv32767 64) in5_64) (_ bv1 1) (_ bv0 1))))
(let (($x118 (or false false false)))
(let (($x91 (not $x118)))
(and $x91 (or $x118 (and (distinct ?x471 ?x471) true)))))))
(check-sat)
; query 206: function gsm_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x8 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 207: function gsm_add, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x8 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 208: function gsm_add, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1555 ((_ sign_extend 48) in1_16)))
(let ((?x1204 ((_ sign_extend 48) in0_16)))
(let ((?x367 (bvadd ?x1204 ?x1555)))
(let (($x1182 (and (distinct (bvadd ((_ sign_extend 1) ?x1204) ((_ sign_extend 1) ?x1555)) ((_ sign_extend 1) ?x367)) true)))
(let (($x8 (or false false)))
(let (($x1544 (or $x8 $x8 (or $x1182))))
(and (not $x1544) (or $x1544 (and (distinct ?x367 ?x367) true))))))))))
(check-sat)
; query 209: function gsm_add, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1327 (ite (bvsgt (_ bv18446744073709518848 64) (bvadd ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x1555 ((_ sign_extend 48) in1_16)))
(let ((?x854 ((_ sign_extend 1) ?x1555)))
(let ((?x1204 ((_ sign_extend 48) in0_16)))
(let ((?x244 ((_ sign_extend 1) ?x1204)))
(let (($x8 (or false false)))
(let (($x1544 (or $x8 $x8 (or (and (distinct (bvadd ?x244 ?x854) ((_ sign_extend 1) (bvadd ?x1204 ?x1555))) true)))))
(let (($x1509 (or $x1544 false false)))
(and (not $x1509) (or $x1509 (and (distinct ?x1327 ?x1327) true))))))))))))
(check-sat)
; query 210: function gsm_asl, block 13, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x346 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x118 (or false false false)))
(let (($x91 (not $x118)))
(and $x91 (or $x118 (and (distinct ?x346 ?x346) true)))))))
(check-sat)
; query 211: function gsm_asl, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x8 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 212: function gsm_asl, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x627 ((_ sign_extend 16) in0_16)))
(let ((?x961 (bvshl ?x627 in1_32)))
(let (($x1406 (bvuge in1_32 (_ bv32 32))))
(let (($x8 (or false false)))
(let (($x1142 (or (or $x8 false (or (and (distinct (bvashr ?x961 in1_32) ?x627) true))) $x1406)))
(let (($x253 (or $x8 false false)))
(let (($x376 (or $x253 $x1406)))
(let (($x641 (not $x376)))
(and $x641 (or $x1142 (and (distinct ?x961 ?x961) true))))))))))))
(check-sat)
; query 213: function gsm_asl, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x627 ((_ sign_extend 16) in0_16)))
(let ((?x961 (bvshl ?x627 in1_32)))
(let ((?x798 ((_ extract 15 0) ?x961)))
(let (($x1406 (bvuge in1_32 (_ bv32 32))))
(let (($x8 (or false false)))
(let (($x1142 (or (or $x8 false (or (and (distinct (bvashr ?x961 in1_32) ?x627) true))) $x1406)))
(let (($x1283 (not (or (or (or $x8 false false) $x1406) false))))
(and $x1283 (or (or $x1142 false) (and (distinct ?x798 ?x798) true)))))))))))
(check-sat)
; query 214: function gsm_asl, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x2013 (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x118 (or false false false)))
(let (($x91 (not $x118)))
(and $x91 (or $x118 (and (distinct ?x2013 ?x2013) true)))))))
(check-sat)
; query 215: function gsm_asl, block 7, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x520 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x297 ((_ zero_extend 31) ?x520)))
(let (($x8 (or false false)))
(let (($x253 (or $x8 false false)))
(let (($x1359 (or $x253 false)))
(and (not $x1359) (or $x1359 (and (distinct ?x297 ?x297) true)))))))))
(check-sat)
; query 216: function gsm_asl, block 7, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x520 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x297 ((_ zero_extend 31) ?x520)))
(let ((?x405 (bvsub (_ bv0 32) ?x297)))
(let (($x718 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x297)) ((_ sign_extend 1) ?x405)) true)))
(let (($x8 (or false false)))
(let (($x253 (or $x8 false false)))
(let (($x1359 (or $x253 false)))
(let (($x996 (or false $x1359 (or $x718))))
(and (not $x996) (or $x996 (and (distinct ?x405 ?x405) true))))))))))))
(check-sat)
; query 217: function gsm_asl, block 7, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x520 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x297 ((_ zero_extend 31) ?x520)))
(let ((?x405 (bvsub (_ bv0 32) ?x297)))
(let ((?x1613 ((_ extract 15 0) ?x405)))
(let (($x718 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x297)) ((_ sign_extend 1) ?x405)) true)))
(let (($x8 (or false false)))
(let (($x253 (or $x8 false false)))
(let (($x1359 (or $x253 false)))
(let (($x996 (or false $x1359 (or $x718))))
(let (($x1200 (or (or $x996 (or (and (distinct ((_ sign_extend 16) ?x1613) ?x405) true))) (and (distinct ?x1613 ?x1613) true))))
(and (not (or $x996 false)) $x1200))))))))))))
(check-sat)
; query 218: function gsm_asl, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x8 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 219: function gsm_asl, block 7, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x520 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x8 (or false false)))
(let (($x253 (or $x8 false false)))
(let (($x122 (not $x253)))
(and $x122 (or $x253 (and (distinct ?x520 ?x520) true))))))))
(check-sat)
; query 220: function gsm_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x767 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x118 (or false false false)))
(let (($x91 (not $x118)))
(and $x91 (or $x118 (and (distinct ?x767 ?x767) true)))))))
(check-sat)
; query 221: function gsm_asr, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x2013 (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x118 (or false false false)))
(let (($x91 (not $x118)))
(and $x91 (or $x118 (and (distinct ?x2013 ?x2013) true)))))))
(check-sat)
; query 222: function gsm_asr, block 13, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x346 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x118 (or false false false)))
(let (($x91 (not $x118)))
(and $x91 (or $x118 (and (distinct ?x346 ?x346) true)))))))
(check-sat)
; query 223: function gsm_asr, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x8 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 224: function gsm_asr, block 15, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x2389 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in1_32))) true)))
(let (($x2222 (or false false (or $x2389))))
(and (not $x2222) (or $x2222 (and (distinct (bvsub (_ bv0 32) in1_32) (bvsub (_ bv0 32) in1_32)) true))))))
(check-sat)
; query 225: function gsm_asr, block 15, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x339 (bvsub (_ bv0 32) in1_32)))
(let ((?x627 ((_ sign_extend 16) in0_16)))
(let ((?x1019 (bvshl ?x627 ?x339)))
(let (($x577 (bvuge ?x339 (_ bv32 32))))
(let (($x2389 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x339)) true)))
(let (($x2222 (or false false (or $x2389))))
(let (($x8 (or false false)))
(let (($x1216 (or (or $x8 $x2222 (or (and (distinct (bvashr ?x1019 ?x339) ?x627) true))) $x577)))
(and (not (or (or $x8 $x2222 false) $x577)) (or $x1216 (and (distinct ?x1019 ?x1019) true))))))))))))
(check-sat)
; query 226: function gsm_asr, block 15, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x339 (bvsub (_ bv0 32) in1_32)))
(let ((?x627 ((_ sign_extend 16) in0_16)))
(let ((?x1019 (bvshl ?x627 ?x339)))
(let ((?x863 ((_ extract 15 0) ?x1019)))
(let (($x577 (bvuge ?x339 (_ bv32 32))))
(let (($x2389 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x339)) true)))
(let (($x2222 (or false false (or $x2389))))
(let (($x8 (or false false)))
(let (($x1216 (or (or $x8 $x2222 (or (and (distinct (bvashr ?x1019 ?x339) ?x627) true))) $x577)))
(and (not (or (or (or $x8 $x2222 false) $x577) false)) (or (or $x1216 false) (and (distinct ?x863 ?x863) true)))))))))))))
(check-sat)
; query 227: function gsm_asr, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x8 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 228: function gsm_asr, block 20, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x627 ((_ sign_extend 16) in0_16)))
(let ((?x1098 (bvashr ?x627 in1_32)))
(let (($x1406 (bvuge in1_32 (_ bv32 32))))
(let (($x8 (or false false)))
(let (($x253 (or $x8 false false)))
(let (($x376 (or $x253 $x1406)))
(let (($x641 (not $x376)))
(and $x641 (or $x376 (and (distinct ?x1098 ?x1098) true)))))))))))
(check-sat)
; query 229: function gsm_asr, block 20, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x627 ((_ sign_extend 16) in0_16)))
(let ((?x1098 (bvashr ?x627 in1_32)))
(let ((?x542 ((_ extract 15 0) ?x1098)))
(let (($x1406 (bvuge in1_32 (_ bv32 32))))
(let (($x8 (or false false)))
(let (($x253 (or $x8 false false)))
(let (($x376 (or $x253 $x1406)))
(let (($x1507 (or (or $x376 (or (and (distinct ((_ sign_extend 16) ?x542) ?x1098) true))) (and (distinct ?x542 ?x542) true))))
(let (($x1283 (not (or $x376 false))))
(and $x1283 $x1507)))))))))))
(check-sat)
; query 230: function gsm_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x8 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 231: function gsm_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x520 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x8 (or false false)))
(let (($x253 (or $x8 false false)))
(let (($x122 (not $x253)))
(and $x122 (or $x253 (and (distinct ?x520 ?x520) true))))))))
(check-sat)
; query 232: function gsm_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x520 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x297 ((_ zero_extend 31) ?x520)))
(let (($x8 (or false false)))
(let (($x253 (or $x8 false false)))
(let (($x1359 (or $x253 false)))
(and (not $x1359) (or $x1359 (and (distinct ?x297 ?x297) true)))))))))
(check-sat)
; query 233: function gsm_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x520 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x297 ((_ zero_extend 31) ?x520)))
(let ((?x405 (bvsub (_ bv0 32) ?x297)))
(let (($x718 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x297)) ((_ sign_extend 1) ?x405)) true)))
(let (($x8 (or false false)))
(let (($x253 (or $x8 false false)))
(let (($x1359 (or $x253 false)))
(let (($x996 (or false $x1359 (or $x718))))
(and (not $x996) (or $x996 (and (distinct ?x405 ?x405) true))))))))))))
(check-sat)
; query 234: function gsm_asr, block 4, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x520 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x297 ((_ zero_extend 31) ?x520)))
(let ((?x405 (bvsub (_ bv0 32) ?x297)))
(let ((?x1613 ((_ extract 15 0) ?x405)))
(let (($x718 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x297)) ((_ sign_extend 1) ?x405)) true)))
(let (($x8 (or false false)))
(let (($x253 (or $x8 false false)))
(let (($x1359 (or $x253 false)))
(let (($x996 (or false $x1359 (or $x718))))
(let (($x1200 (or (or $x996 (or (and (distinct ((_ sign_extend 16) ?x1613) ?x405) true))) (and (distinct ?x1613 ?x1613) true))))
(and (not (or $x996 false)) $x1200))))))))))))
(check-sat)
; query 235: function gsm_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x767 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x118 (or false false false)))
(let (($x91 (not $x118)))
(and $x91 (or $x118 (and (distinct ?x767 ?x767) true)))))))
(check-sat)
; query 236: function gsm_debug_longwords, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in15_32 () (_ BitVec 32))
(assert
 (let ((?x270 (ite (bvslt in15_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x118 (or false false false)))
(let (($x91 (not $x118)))
(and $x91 (or $x118 (and (distinct ?x270 ?x270) true)))))))
(check-sat)
; query 237: function gsm_debug_words, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in16_32 () (_ BitVec 32))
(assert
 (let ((?x1023 (ite (bvslt in16_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x118 (or false false false)))
(let (($x91 (not $x118)))
(and $x91 (or $x118 (and (distinct ?x1023 ?x1023) true)))))))
(check-sat)
; query 238: function gsm_div, block 7, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x236 (ite (bvsge ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x8 (or false false)))
(let (($x1553 (or $x8 $x8 false)))
(and (not $x1553) (or $x1553 (and (distinct ?x236 ?x236) true)))))))
(check-sat)
; query 239: function gsm_div, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x8 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 240: function gsm_div, block 7, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x8 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 241: function gsm_div, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x8 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 242: function gsm_div, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x8 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 243: function gsm_div, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x8 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 244: function gsm_div, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1096 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1015 (and (distinct ?x1096 ?x1096) true)))
(let (($x8 (or false false)))
(let (($x253 (or $x8 false false)))
(let (($x122 (not $x253)))
(and $x122 (or $x253 $x1015))))))))
(check-sat)
; query 245: function gsm_mult, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x8 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 246: function gsm_mult, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1138 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x8 (or false false)))
(let (($x253 (or $x8 false false)))
(let (($x122 (not $x253)))
(and $x122 (or $x253 (and (distinct ?x1138 ?x1138) true))))))))
(check-sat)
; query 247: function gsm_mult, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x8 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 248: function gsm_mult, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x8 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 249: function gsm_mult, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1555 ((_ sign_extend 48) in1_16)))
(let ((?x1204 ((_ sign_extend 48) in0_16)))
(let ((?x2057 (bvmul ?x1204 ?x1555)))
(let (($x347 (and (distinct (bvmul ((_ sign_extend 64) ?x1204) ((_ sign_extend 64) ?x1555)) ((_ sign_extend 64) ?x2057)) true)))
(let (($x8 (or false false)))
(let (($x212 (or $x8 $x8 (or $x347))))
(and (not $x212) (or $x212 (and (distinct ?x2057 ?x2057) true))))))))))
(check-sat)
; query 250: function gsm_mult, block 9, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1555 ((_ sign_extend 48) in1_16)))
(let ((?x1204 ((_ sign_extend 48) in0_16)))
(let ((?x2057 (bvmul ?x1204 ?x1555)))
(let ((?x806 (bvashr ?x2057 (_ bv15 64))))
(let (($x262 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x347 (and (distinct (bvmul ((_ sign_extend 64) ?x1204) ((_ sign_extend 64) ?x1555)) ((_ sign_extend 64) ?x2057)) true)))
(let (($x8 (or false false)))
(let (($x212 (or $x8 $x8 (or $x347))))
(let (($x1212 (or (or $x212 false false) $x262)))
(and (not $x1212) (or $x1212 (and (distinct ?x806 ?x806) true)))))))))))))
(check-sat)
; query 251: function gsm_mult, block 9, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1555 ((_ sign_extend 48) in1_16)))
(let ((?x1204 ((_ sign_extend 48) in0_16)))
(let ((?x2057 (bvmul ?x1204 ?x1555)))
(let ((?x806 (bvashr ?x2057 (_ bv15 64))))
(let ((?x65 ((_ extract 15 0) ?x806)))
(let (($x262 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x347 (and (distinct (bvmul ((_ sign_extend 64) ?x1204) ((_ sign_extend 64) ?x1555)) ((_ sign_extend 64) ?x2057)) true)))
(let (($x8 (or false false)))
(let (($x212 (or $x8 $x8 (or $x347))))
(let (($x1212 (or (or $x212 false false) $x262)))
(let (($x1890 (or $x1212 false)))
(and (not $x1890) (or $x1890 (and (distinct ?x65 ?x65) true)))))))))))))))
(check-sat)
; query 252: function gsm_mult, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x8 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 253: function gsm_mult, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x722 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x8 (or false false)))
(let (($x253 (or $x8 false false)))
(let (($x122 (not $x253)))
(and $x122 (or $x253 (and (distinct ?x722 ?x722) true))))))))
(check-sat)
; query 254: function gsm_mult_r, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x8 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 255: function gsm_mult_r, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x722 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x8 (or false false)))
(let (($x253 (or $x8 false false)))
(let (($x122 (not $x253)))
(and $x122 (or $x253 (and (distinct ?x722 ?x722) true))))))))
(check-sat)
; query 256: function gsm_mult_r, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x8 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 257: function gsm_mult_r, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x8 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 258: function gsm_mult_r, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1555 ((_ sign_extend 48) in1_16)))
(let ((?x1204 ((_ sign_extend 48) in0_16)))
(let ((?x2057 (bvmul ?x1204 ?x1555)))
(let (($x347 (and (distinct (bvmul ((_ sign_extend 64) ?x1204) ((_ sign_extend 64) ?x1555)) ((_ sign_extend 64) ?x2057)) true)))
(let (($x8 (or false false)))
(let (($x212 (or $x8 $x8 (or $x347))))
(and (not $x212) (or $x212 (and (distinct ?x2057 ?x2057) true))))))))))
(check-sat)
; query 259: function gsm_mult_r, block 9, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1555 ((_ sign_extend 48) in1_16)))
(let ((?x1204 ((_ sign_extend 48) in0_16)))
(let ((?x2057 (bvmul ?x1204 ?x1555)))
(let ((?x1807 (bvadd ?x2057 (_ bv16384 64))))
(let (($x40 (and (distinct (bvadd ((_ sign_extend 1) ?x2057) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x1807)) true)))
(let (($x347 (and (distinct (bvmul ((_ sign_extend 64) ?x1204) ((_ sign_extend 64) ?x1555)) ((_ sign_extend 64) ?x2057)) true)))
(let (($x8 (or false false)))
(let (($x212 (or $x8 $x8 (or $x347))))
(let (($x791 (or $x212 false (or $x40))))
(and (not $x791) (or $x791 (and (distinct ?x1807 ?x1807) true)))))))))))))
(check-sat)
; query 260: function gsm_mult_r, block 9, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1555 ((_ sign_extend 48) in1_16)))
(let ((?x1204 ((_ sign_extend 48) in0_16)))
(let ((?x2057 (bvmul ?x1204 ?x1555)))
(let ((?x1807 (bvadd ?x2057 (_ bv16384 64))))
(let ((?x1332 (bvashr ?x1807 (_ bv15 64))))
(let (($x262 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x40 (and (distinct (bvadd ((_ sign_extend 1) ?x2057) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x1807)) true)))
(let (($x347 (and (distinct (bvmul ((_ sign_extend 64) ?x1204) ((_ sign_extend 64) ?x1555)) ((_ sign_extend 64) ?x2057)) true)))
(let (($x8 (or false false)))
(let (($x212 (or $x8 $x8 (or $x347))))
(let (($x791 (or $x212 false (or $x40))))
(let (($x247 (or (or $x791 false false) $x262)))
(and (not $x247) (or $x247 (and (distinct ?x1332 ?x1332) true))))))))))))))))
(check-sat)
; query 261: function gsm_mult_r, block 9, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1555 ((_ sign_extend 48) in1_16)))
(let ((?x1204 ((_ sign_extend 48) in0_16)))
(let ((?x2057 (bvmul ?x1204 ?x1555)))
(let ((?x1807 (bvadd ?x2057 (_ bv16384 64))))
(let ((?x1332 (bvashr ?x1807 (_ bv15 64))))
(let ((?x1765 (bvand ?x1332 (_ bv65535 64))))
(let (($x262 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x40 (and (distinct (bvadd ((_ sign_extend 1) ?x2057) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x1807)) true)))
(let (($x347 (and (distinct (bvmul ((_ sign_extend 64) ?x1204) ((_ sign_extend 64) ?x1555)) ((_ sign_extend 64) ?x2057)) true)))
(let (($x8 (or false false)))
(let (($x212 (or $x8 $x8 (or $x347))))
(let (($x791 (or $x212 false (or $x40))))
(let (($x247 (or (or $x791 false false) $x262)))
(let (($x1305 (or $x247 false false)))
(and (not $x1305) (or $x1305 (and (distinct ?x1765 ?x1765) true))))))))))))))))))
(check-sat)
; query 262: function gsm_mult_r, block 9, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1555 ((_ sign_extend 48) in1_16)))
(let ((?x1204 ((_ sign_extend 48) in0_16)))
(let ((?x2057 (bvmul ?x1204 ?x1555)))
(let ((?x1807 (bvadd ?x2057 (_ bv16384 64))))
(let ((?x1332 (bvashr ?x1807 (_ bv15 64))))
(let ((?x1765 (bvand ?x1332 (_ bv65535 64))))
(let ((?x1082 ((_ extract 15 0) ?x1765)))
(let (($x262 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x40 (and (distinct (bvadd ((_ sign_extend 1) ?x2057) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x1807)) true)))
(let (($x347 (and (distinct (bvmul ((_ sign_extend 64) ?x1204) ((_ sign_extend 64) ?x1555)) ((_ sign_extend 64) ?x2057)) true)))
(let (($x8 (or false false)))
(let (($x212 (or $x8 $x8 (or $x347))))
(let (($x791 (or $x212 false (or $x40))))
(let (($x247 (or (or $x791 false false) $x262)))
(let (($x1305 (or $x247 false false)))
(let (($x1886 (or (or $x1305 (or (and (distinct ((_ zero_extend 48) ?x1082) ?x1765) true))) (and (distinct ?x1082 ?x1082) true))))
(and (not (or $x1305 false)) $x1886))))))))))))))))))
(check-sat)
; query 263: function gsm_mult_r, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x8 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 264: function gsm_mult_r, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1138 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x8 (or false false)))
(let (($x253 (or $x8 false false)))
(let (($x122 (not $x253)))
(and $x122 (or $x253 (and (distinct ?x1138 ?x1138) true))))))))
(check-sat)
; query 265: function gsm_norm, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x350 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x118 (or false false false)))
(let (($x91 (not $x118)))
(and $x91 (or $x118 (and (distinct ?x350 ?x350) true)))))))
(check-sat)
; query 266: function gsm_norm, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x350 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x317 (bvxor ?x350 (_ bv1 1))))
(let (($x118 (or false false false)))
(let (($x446 (or $x118 false false)))
(let (($x585 (not $x446)))
(and $x585 (or $x446 (and (distinct ?x317 ?x317) true)))))))))
(check-sat)
; query 267: function gsm_norm, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x350 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x317 (bvxor ?x350 (_ bv1 1))))
(let ((?x1481 ((_ zero_extend 31) ?x317)))
(let (($x118 (or false false false)))
(let (($x446 (or $x118 false false)))
(let (($x1709 (or $x446 false)))
(and (not $x1709) (or $x1709 (and (distinct ?x1481 ?x1481) true))))))))))
(check-sat)
; query 268: function gsm_norm, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x350 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x317 (bvxor ?x350 (_ bv1 1))))
(let ((?x1481 ((_ zero_extend 31) ?x317)))
(let ((?x132 ((_ zero_extend 32) ?x1481)))
(let ((?x1714 ((_ sign_extend 32) ?x1481)))
(let (($x118 (or false false false)))
(let (($x446 (or $x118 false false)))
(let (($x1709 (or $x446 false)))
(let (($x197 (or $x1709 (or (= ((_ extract 31 31) ?x1481) (_ bv1 1))))))
(and (not (or $x1709 false)) (or $x197 (and (distinct ?x1714 ?x132) true)))))))))))))
(check-sat)
; query 269: function gsm_norm, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x350 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x317 (bvxor ?x350 (_ bv1 1))))
(let ((?x1481 ((_ zero_extend 31) ?x317)))
(let ((?x132 ((_ zero_extend 32) ?x1481)))
(let (($x1397 (and (distinct (ite (and (distinct (_ bv0 64) ((_ sign_extend 32) ?x1481)) true) (_ bv1 1) (_ bv0 1)) (ite (and (distinct (_ bv0 64) ?x132) true) (_ bv1 1) (_ bv0 1))) true)))
(let (($x118 (or false false false)))
(let (($x446 (or $x118 false false)))
(let (($x1709 (or $x446 false)))
(let (($x197 (or $x1709 (or (= ((_ extract 31 31) ?x1481) (_ bv1 1))))))
(and (not (or (or $x1709 false) false false)) (or (or $x197 false false) $x1397))))))))))))
(check-sat)
; query 270: function gsm_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_64 () (_ BitVec 64))
(assert
 (let ((?x471 (ite (bvslt (_ bv32767 64) in5_64) (_ bv1 1) (_ bv0 1))))
(let (($x118 (or false false false)))
(let (($x91 (not $x118)))
(and $x91 (or $x118 (and (distinct ?x471 ?x471) true)))))))
(check-sat)
; query 271: function gsm_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x8 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 272: function gsm_sub, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x8 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 273: function gsm_sub, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1555 ((_ sign_extend 48) in1_16)))
(let ((?x1204 ((_ sign_extend 48) in0_16)))
(let ((?x1918 (bvsub ?x1204 ?x1555)))
(let (($x1009 (and (distinct (bvsub ((_ sign_extend 1) ?x1204) ((_ sign_extend 1) ?x1555)) ((_ sign_extend 1) ?x1918)) true)))
(let (($x8 (or false false)))
(let (($x1337 (or $x8 $x8 (or $x1009))))
(and (not $x1337) (or $x1337 (and (distinct ?x1918 ?x1918) true))))))))))
(check-sat)
; query 274: function gsm_sub, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1476 (ite (bvsgt (_ bv18446744073709518848 64) (bvsub ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x1555 ((_ sign_extend 48) in1_16)))
(let ((?x854 ((_ sign_extend 1) ?x1555)))
(let ((?x1204 ((_ sign_extend 48) in0_16)))
(let ((?x244 ((_ sign_extend 1) ?x1204)))
(let (($x8 (or false false)))
(let (($x1337 (or $x8 $x8 (or (and (distinct (bvsub ?x244 ?x854) ((_ sign_extend 1) (bvsub ?x1204 ?x1555))) true)))))
(let (($x2070 (or $x1337 false false)))
(and (not $x2070) (or $x2070 (and (distinct ?x1476 ?x1476) true))))))))))))
(check-sat)
; query 275: function ok_to_replace, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x125 (ite (and (distinct (_ bv4294967295 32) in.01_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x118 (or false false false)))
(let (($x91 (not $x118)))
(and $x91 (or $x118 (and (distinct ?x125 ?x125) true)))))))
(check-sat)
; query 276: function ok_to_replace, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in16_32 () (_ BitVec 32))
(assert
 (let ((?x202 (ite (= (_ bv121 32) in16_32) (_ bv1 1) (_ bv0 1))))
(let (($x118 (or false false false)))
(let (($x91 (not $x118)))
(and $x91 (or $x118 (and (distinct ?x202 ?x202) true)))))))
(check-sat)
; query 277: function process_decode, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let (($x2585 (or false (or (= ((_ extract 31 31) in14_32) (_ bv1 1))))))
(let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x2585 (and (distinct ((_ sign_extend 32) in14_32) ((_ zero_extend 32) in14_32)) true)))))))
(check-sat)
; query 278: function process_decode, block 16, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let (($x993 (and (distinct (ite (and (distinct (_ bv33 64) ((_ sign_extend 32) in14_32)) true) (_ bv1 1) (_ bv0 1)) (ite (and (distinct (_ bv33 64) ((_ zero_extend 32) in14_32)) true) (_ bv1 1) (_ bv0 1))) true)))
(let (($x28 (or (or (or false (or (= ((_ extract 31 31) in14_32) (_ bv1 1)))) false false) $x993)))
(let (($x8 (or false false)))
(let (($x253 (or $x8 false false)))
(let (($x122 (not $x253)))
(and $x122 $x28)))))))
(check-sat)
; query 279: function process_encode, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_32 () (_ BitVec 32))
(assert
 (let (($x1584 (or false (or (= ((_ extract 31 31) in13_32) (_ bv1 1))))))
(let (($x8 (or false false)))
(let (($x541 (not $x8)))
(and $x541 (or $x1584 (and (distinct ((_ sign_extend 32) in13_32) ((_ zero_extend 32) in13_32)) true)))))))
(check-sat)
; query 280: function process_encode, block 15, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_32 () (_ BitVec 32))
(assert
 (let (($x1595 (and (distinct (ite (bvult ((_ sign_extend 32) in13_32) (_ bv160 64)) (_ bv1 1) (_ bv0 1)) (ite (bvult ((_ zero_extend 32) in13_32) (_ bv160 64)) (_ bv1 1) (_ bv0 1))) true)))
(let (($x787 (or (or (or false (or (= ((_ extract 31 31) in13_32) (_ bv1 1)))) false false) $x1595)))
(let (($x8 (or false false)))
(let (($x253 (or $x8 false false)))
(let (($x122 (not $x253)))
(and $x122 $x787)))))))
(check-sat)
; query 281: function process_encode, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_32 () (_ BitVec 32))
(assert
 (let ((?x1058 (ite (bvsgt (_ bv0 32) in13_32) (_ bv1 1) (_ bv0 1))))
(let (($x118 (or false false false)))
(let (($x91 (not $x118)))
(and $x91 (or $x118 (and (distinct ?x1058 ?x1058) true)))))))
(check-sat)
; query 282: function suffix, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_64 () (_ BitVec 64))
(declare-fun in3_64 () (_ BitVec 64))
(assert
 (let ((?x2064 (ite (bvule in3_64 in4_64) (_ bv1 1) (_ bv0 1))))
(let (($x118 (or false false false)))
(let (($x91 (not $x118)))
(and $x91 (or $x118 (and (distinct ?x2064 ?x2064) true)))))))
(check-sat)
; query 283: function ulaw_input, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x257 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x412 (or false false (or $x257))))
(and (not $x412) (or $x412 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 284: function ulaw_input, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let ((?x1882 (ite (= (_ bv4294967295 32) in.1_32) (_ bv1 1) (_ bv0 1))))
(let (($x118 (or false false false)))
(let (($x91 (not $x118)))
(and $x91 (or $x118 (and (distinct ?x1882 ?x1882) true)))))))
(check-sat)
