; OptiPhase-Sigma refinement certificate for sweep K40-R4-316
; query 0: function set_key, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let (($x375 (or false false false)))
(and (not $x375) (or $x375 (and (distinct (bvand in1_64 (_ bv7 64)) (bvand in1_64 (_ bv7 64))) true)))))
(check-sat)
; query 1: function set_key, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x136 (ite (and (distinct (_ bv0 64) (bvand in1_64 (_ bv7 64))) true) (_ bv1 1) (_ bv0 1))))
(let (($x375 (or false false false)))
(let (($x374 (or $x375 false false)))
(and (not $x374) (or $x374 (and (distinct ?x136 ?x136) true)))))))
(check-sat)
