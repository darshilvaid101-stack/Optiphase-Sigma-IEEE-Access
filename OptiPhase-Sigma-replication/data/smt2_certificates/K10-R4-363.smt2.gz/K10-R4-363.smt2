; OptiPhase-Sigma refinement certificate for sweep K10-R4-363
