; OptiPhase-Sigma refinement certificate for sweep K45-R1-001
; query 0: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x512 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x413 (or false false false)))
(let (($x276 (not $x413)))
(and $x276 (or $x413 (and (distinct ?x512 ?x512) true)))))))
(check-sat)
; query 1: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x703 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x413 (or false false false)))
(let (($x276 (not $x413)))
(and $x276 (or $x413 (and (distinct ?x703 ?x703) true)))))))
(check-sat)
