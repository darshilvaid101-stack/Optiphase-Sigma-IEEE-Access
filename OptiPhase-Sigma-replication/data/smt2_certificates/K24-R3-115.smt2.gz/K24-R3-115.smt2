; OptiPhase-Sigma refinement certificate for sweep K24-R3-115
