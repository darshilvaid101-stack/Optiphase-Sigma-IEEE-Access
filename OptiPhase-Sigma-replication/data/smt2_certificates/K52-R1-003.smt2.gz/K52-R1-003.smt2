; OptiPhase-Sigma refinement certificate for sweep K52-R1-003
