; OptiPhase-Sigma refinement certificate for sweep K35-R1-005
