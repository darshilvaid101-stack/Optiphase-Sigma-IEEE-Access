; OptiPhase-Sigma refinement certificate for sweep K02-R5-410
