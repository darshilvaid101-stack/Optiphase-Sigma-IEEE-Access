; OptiPhase-Sigma refinement certificate for sweep K59-R3-219
; query 0: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x33 (or false false false)))
(let (($x627 (not $x33)))
(and $x627 (or $x33 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x44055 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x33 (or false false false)))
(let (($x627 (not $x33)))
(and $x627 (or $x33 (and (distinct ?x44055 ?x44055) true)))))))
(check-sat)
; query 2: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x10658 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x33 (or false false false)))
(let (($x627 (not $x33)))
(and $x627 (or $x33 (and (distinct ?x10658 ?x10658) true)))))))
(check-sat)
; query 3: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x33 (or false false false)))
(let (($x627 (not $x33)))
(and $x627 (or $x33 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 4: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x155 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x336 (or false false (or $x155))))
(and (not $x336) (or $x336 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 5: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x781 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x33 (or false false false)))
(let (($x627 (not $x33)))
(and $x627 (or $x33 (and (distinct ?x781 ?x781) true)))))))
(check-sat)
; query 6: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x55 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x33 (or false false false)))
(let (($x627 (not $x33)))
(and $x627 (or $x33 (and (distinct ?x55 ?x55) true)))))))
(check-sat)
; query 7: function matrix_add_const, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x33 (or false false false)))
(let (($x627 (not $x33)))
(and $x627 (or $x33 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function matrix_add_const, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x33 (or false false false)))
(let (($x627 (not $x33)))
(and $x627 (or $x33 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 9: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x1338 (or false false)))
(and (not $x1338) (or $x1338 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true)))))
(check-sat)
; query 10: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x204 ((_ sign_extend 16) in.1_16)))
(let ((?x935 (bvadd ?x204 (_ bv10 32))))
(let (($x681 (and (distinct (bvadd ((_ sign_extend 1) ?x204) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x935)) true)))
(let (($x1338 (or false false)))
(let (($x60 (or $x1338 false (or $x681))))
(and (not $x60) (or $x60 (and (distinct ?x935 ?x935) true)))))))))
(check-sat)
; query 11: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x204 ((_ sign_extend 16) in.1_16)))
(let ((?x935 (bvadd ?x204 (_ bv10 32))))
(let ((?x269 ((_ extract 15 0) ?x935)))
(let (($x681 (and (distinct (bvadd ((_ sign_extend 1) ?x204) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x935)) true)))
(let (($x1338 (or false false)))
(let (($x60 (or $x1338 false (or $x681))))
(let (($x778 (or $x60 false)))
(and (not $x778) (or $x778 (and (distinct ?x269 ?x269) true)))))))))))
(check-sat)
