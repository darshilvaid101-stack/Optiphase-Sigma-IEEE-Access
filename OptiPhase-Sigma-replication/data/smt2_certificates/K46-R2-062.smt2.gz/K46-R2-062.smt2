; OptiPhase-Sigma refinement certificate for sweep K46-R2-062
; query 0: function adpcm_coder, block 25, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in20_32 () (_ BitVec 32))
(assert
 (let (($x599 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in20_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in20_32))) true)))
(let (($x96 (or false false (or $x599))))
(and (not $x96) (or $x96 (and (distinct (bvsub (_ bv0 32) in20_32) (bvsub (_ bv0 32) in20_32)) true))))))
(check-sat)
; query 1: function adpcm_coder, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(declare-fun in.017_32 () (_ BitVec 32))
(assert
 (let ((?x120 (bvsub in.017_32 in.020_32)))
(let (($x348 (and (distinct (bvsub ((_ sign_extend 1) in.017_32) ((_ sign_extend 1) in.020_32)) ((_ sign_extend 1) ?x120)) true)))
(let (($x340 (or false false (or $x348))))
(and (not $x340) (or $x340 (and (distinct ?x120 ?x120) true)))))))
(check-sat)
; query 2: function adpcm_coder, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(declare-fun in28_32 () (_ BitVec 32))
(assert
 (let (($x753 (and (distinct (bvadd ((_ sign_extend 1) in28_32) ((_ sign_extend 1) in.020_32)) ((_ sign_extend 1) (bvadd in28_32 in.020_32))) true)))
(let (($x405 (or false false (or $x753))))
(let (($x163 (or $x405 (and (distinct (bvadd in28_32 in.020_32) (bvadd in28_32 in.020_32)) true))))
(and (not $x405) $x163)))))
(check-sat)
; query 3: function adpcm_coder, block 36, name %37
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.014_32 () (_ BitVec 32))
(assert
 (let (($x474 (or false false false)))
(let (($x562 (not $x474)))
(and $x562 (or $x474 (and (distinct (bvor in.014_32 (_ bv2 32)) (bvor in.014_32 (_ bv2 32))) true))))))
(check-sat)
; query 4: function adpcm_coder, block 36, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in34_32 () (_ BitVec 32))
(declare-fun in.118_32 () (_ BitVec 32))
(assert
 (let (($x147 (and (distinct (bvsub ((_ sign_extend 1) in.118_32) ((_ sign_extend 1) in34_32)) ((_ sign_extend 1) (bvsub in.118_32 in34_32))) true)))
(let (($x374 (or false false (or $x147))))
(let (($x181 (or $x374 (and (distinct (bvsub in.118_32 in34_32) (bvsub in.118_32 in34_32)) true))))
(and (not $x374) $x181)))))
(check-sat)
; query 5: function adpcm_coder, block 36, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in34_32 () (_ BitVec 32))
(declare-fun in.08_32 () (_ BitVec 32))
(assert
 (let (($x133 (and (distinct (bvadd ((_ sign_extend 1) in.08_32) ((_ sign_extend 1) in34_32)) ((_ sign_extend 1) (bvadd in.08_32 in34_32))) true)))
(let (($x476 (or false false (or $x133))))
(let (($x758 (or $x476 (and (distinct (bvadd in.08_32 in34_32) (bvadd in.08_32 in34_32)) true))))
(and (not $x476) $x758)))))
(check-sat)
; query 6: function adpcm_coder, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.115_32 () (_ BitVec 32))
(assert
 (let (($x474 (or false false false)))
(let (($x562 (not $x474)))
(and $x562 (or $x474 (and (distinct (bvor in.115_32 (_ bv1 32)) (bvor in.115_32 (_ bv1 32))) true))))))
(check-sat)
; query 7: function adpcm_coder, block 43, name %45
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in41_32 () (_ BitVec 32))
(declare-fun in.19_32 () (_ BitVec 32))
(assert
 (let (($x88 (and (distinct (bvadd ((_ sign_extend 1) in.19_32) ((_ sign_extend 1) in41_32)) ((_ sign_extend 1) (bvadd in.19_32 in41_32))) true)))
(let (($x509 (or false false (or $x88))))
(let (($x790 (or $x509 (and (distinct (bvadd in.19_32 in41_32) (bvadd in.19_32 in41_32)) true))))
(and (not $x509) $x790)))))
(check-sat)
; query 8: function adpcm_coder, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.210_32 () (_ BitVec 32))
(declare-fun in.011_32 () (_ BitVec 32))
(assert
 (let ((?x392 (bvsub in.011_32 in.210_32)))
(let (($x447 (and (distinct (bvsub ((_ sign_extend 1) in.011_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x392)) true)))
(let (($x142 (or false false (or $x447))))
(and (not $x142) (or $x142 (and (distinct ?x392 ?x392) true)))))))
(check-sat)
; query 9: function adpcm_coder, block 50, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.210_32 () (_ BitVec 32))
(declare-fun in.011_32 () (_ BitVec 32))
(assert
 (let ((?x139 (bvadd in.011_32 in.210_32)))
(let (($x260 (and (distinct (bvadd ((_ sign_extend 1) in.011_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x139)) true)))
(let (($x407 (or false false (or $x260))))
(and (not $x407) (or $x407 (and (distinct ?x139 ?x139) true)))))))
(check-sat)
; query 10: function adpcm_coder, block 55, name %56
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.112_32 () (_ BitVec 32))
(assert
 (let ((?x245 (ite (bvsgt (_ bv4294934528 32) in.112_32) (_ bv1 1) (_ bv0 1))))
(let (($x474 (or false false false)))
(let (($x562 (not $x474)))
(and $x562 (or $x474 (and (distinct ?x245 ?x245) true)))))))
(check-sat)
; query 11: function adpcm_coder, block 75, name %76
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in60_32 () (_ BitVec 32))
(assert
 (let (($x474 (or false false false)))
(let (($x630 (or $x474 (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x630) (or $x630 (and (distinct (bvshl in60_32 (_ bv4 32)) (bvshl in60_32 (_ bv4 32))) true))))))
(check-sat)
; query 12: function adpcm_coder, block 75, name %77
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in60_32 () (_ BitVec 32))
(assert
 (let ((?x769 (bvshl in60_32 (_ bv4 32))))
(let ((?x411 (bvand ?x769 (_ bv240 32))))
(let (($x474 (or false false false)))
(let (($x630 (or $x474 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x103 (or $x630 false false)))
(and (not $x103) (or $x103 (and (distinct ?x411 ?x411) true)))))))))
(check-sat)
; query 13: function adpcm_coder, block 87, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x143 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv4294967295 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv4294967295 32)))) true)))
(let (($x104 (or false false (or $x143))))
(and (not $x104) (or $x104 (and (distinct (bvadd in.02_32 (_ bv4294967295 32)) (bvadd in.02_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 14: function adpcm_decoder, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x34 (ite (and (distinct (_ bv0 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x474 (or false false false)))
(let (($x562 (not $x474)))
(and $x562 (or $x474 (and (distinct ?x34 ?x34) true)))))))
(check-sat)
; query 15: function adpcm_decoder, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x474 (or false false false)))
(let (($x562 (not $x474)))
(and $x562 (or $x474 (and (distinct (bvand in.01_32 (_ bv15 32)) (bvand in.01_32 (_ bv15 32))) true))))))
(check-sat)
; query 16: function adpcm_decoder, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.012_32 () (_ BitVec 32))
(declare-fun in42_32 () (_ BitVec 32))
(assert
 (let (($x50 (and (distinct (bvadd ((_ sign_extend 1) in42_32) ((_ sign_extend 1) in.012_32)) ((_ sign_extend 1) (bvadd in42_32 in.012_32))) true)))
(let (($x490 (or false false (or $x50))))
(let (($x74 (or $x490 (and (distinct (bvadd in42_32 in.012_32) (bvadd in42_32 in.012_32)) true))))
(and (not $x490) $x74)))))
(check-sat)
; query 17: function adpcm_decoder, block 50, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.012_32 () (_ BitVec 32))
(assert
 (let (($x474 (or false false false)))
(let (($x109 (or $x474 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x121 (or $x109 (and (distinct (bvashr in.012_32 (_ bv1 32)) (bvashr in.012_32 (_ bv1 32))) true))))
(and (not $x109) $x121)))))
(check-sat)
; query 18: function adpcm_decoder, block 50, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.012_32 () (_ BitVec 32))
(declare-fun in.08_32 () (_ BitVec 32))
(assert
 (let ((?x48 (bvashr in.012_32 (_ bv1 32))))
(let ((?x151 (bvadd in.08_32 ?x48)))
(let (($x14 (and (distinct (bvadd ((_ sign_extend 1) in.08_32) ((_ sign_extend 1) ?x48)) ((_ sign_extend 1) ?x151)) true)))
(let (($x474 (or false false false)))
(let (($x109 (or $x474 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x148 (or false $x109 (or $x14))))
(and (not $x148) (or $x148 (and (distinct ?x151 ?x151) true))))))))))
(check-sat)
; query 19: function adpcm_decoder, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.012_32 () (_ BitVec 32))
(assert
 (let (($x474 (or false false false)))
(let (($x105 (or $x474 (bvuge (_ bv2 32) (_ bv32 32)))))
(let (($x290 (or $x105 (and (distinct (bvashr in.012_32 (_ bv2 32)) (bvashr in.012_32 (_ bv2 32))) true))))
(and (not $x105) $x290)))))
(check-sat)
; query 20: function adpcm_decoder, block 56, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.012_32 () (_ BitVec 32))
(declare-fun in.19_32 () (_ BitVec 32))
(assert
 (let ((?x497 (bvashr in.012_32 (_ bv2 32))))
(let ((?x544 (bvadd in.19_32 ?x497)))
(let (($x321 (and (distinct (bvadd ((_ sign_extend 1) in.19_32) ((_ sign_extend 1) ?x497)) ((_ sign_extend 1) ?x544)) true)))
(let (($x474 (or false false false)))
(let (($x105 (or $x474 (bvuge (_ bv2 32) (_ bv32 32)))))
(let (($x404 (or false $x105 (or $x321))))
(and (not $x404) (or $x404 (and (distinct ?x544 ?x544) true))))))))))
(check-sat)
; query 21: function adpcm_decoder, block 61, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.210_32 () (_ BitVec 32))
(declare-fun in.013_32 () (_ BitVec 32))
(assert
 (let ((?x101 (bvsub in.013_32 in.210_32)))
(let (($x512 (and (distinct (bvsub ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x101)) true)))
(let (($x637 (or false false (or $x512))))
(and (not $x637) (or $x637 (and (distinct ?x101 ?x101) true)))))))
(check-sat)
; query 22: function adpcm_decoder, block 63, name %64
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.210_32 () (_ BitVec 32))
(declare-fun in.013_32 () (_ BitVec 32))
(assert
 (let ((?x249 (bvadd in.013_32 in.210_32)))
(let (($x111 (and (distinct (bvadd ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x249)) true)))
(let (($x525 (or false false (or $x111))))
(and (not $x525) (or $x525 (and (distinct ?x249 ?x249) true)))))))
(check-sat)
; query 23: function adpcm_decoder, block 68, name %69
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.114_32 () (_ BitVec 32))
(assert
 (let ((?x259 (ite (bvsgt (_ bv4294934528 32) in.114_32) (_ bv1 1) (_ bv0 1))))
(let (($x474 (or false false false)))
(let (($x562 (not $x474)))
(and $x562 (or $x474 (and (distinct ?x259 ?x259) true)))))))
(check-sat)
; query 24: function adpcm_decoder, block 78, name %79
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x143 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv4294967295 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv4294967295 32)))) true)))
(let (($x104 (or false false (or $x143))))
(and (not $x104) (or $x104 (and (distinct (bvadd in.02_32 (_ bv4294967295 32)) (bvadd in.02_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 25: function main, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x266 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x474 (or false false false)))
(let (($x562 (not $x474)))
(and $x562 (or $x474 (and (distinct ?x266 ?x266) true)))))))
(check-sat)
