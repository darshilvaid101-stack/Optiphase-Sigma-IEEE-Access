; OptiPhase-Sigma refinement certificate for sweep K52-R3-164
; query 0: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x77 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x107 (or false false false)))
(let (($x164 (not $x107)))
(and $x164 (or $x107 (and (distinct ?x77 ?x77) true)))))))
(check-sat)
; query 1: function set1d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x83 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x107 (or false false false)))
(let (($x164 (not $x107)))
(and $x164 (or $x107 (and (distinct ?x83 ?x83) true)))))))
(check-sat)
; query 2: function set1ds, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x122 (ite (= (_ bv4294967295 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x107 (or false false false)))
(let (($x164 (not $x107)))
(and $x164 (or $x107 (and (distinct ?x122 ?x122) true)))))))
(check-sat)
; query 3: function set2d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x83 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x107 (or false false false)))
(let (($x164 (not $x107)))
(and $x164 (or $x107 (and (distinct ?x83 ?x83) true)))))))
(check-sat)
