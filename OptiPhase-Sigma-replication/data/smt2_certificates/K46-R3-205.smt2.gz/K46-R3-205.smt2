; OptiPhase-Sigma refinement certificate for sweep K46-R3-205
; query 0: function adpcm_decoder, block 61, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.210_32 () (_ BitVec 32))
(declare-fun in.013_32 () (_ BitVec 32))
(assert
 (let ((?x109 (bvadd in.013_32 in.210_32)))
(let ((?x655 (bvsub in.013_32 in.210_32)))
(let (($x965 (and (distinct (bvadd ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x109)) true)))
(let (($x319 (and (distinct (bvsub ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x655)) true)))
(and (not (or false false (or $x319))) (or (or false false (or $x965)) (and (distinct ?x655 ?x109) true))))))))
(check-sat)
; query 1: function main, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x103 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x143 (or false false false)))
(and (not $x143) (or $x143 (and (distinct ?x103 ?x103) true))))))
(check-sat)
