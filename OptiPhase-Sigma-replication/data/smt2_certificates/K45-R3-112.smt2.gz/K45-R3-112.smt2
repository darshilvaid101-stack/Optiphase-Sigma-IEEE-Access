; OptiPhase-Sigma refinement certificate for sweep K45-R3-112
; query 0: function IsPowerOfTwo, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x120 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x14 (or false false false)))
(let (($x306 (not $x14)))
(and $x306 (or $x14 (and (distinct ?x120 ?x120) true)))))))
(check-sat)
; query 1: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x120 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x14 (or false false false)))
(let (($x306 (not $x14)))
(and $x306 (or $x14 (and (distinct ?x120 ?x120) true)))))))
(check-sat)
; query 2: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x347 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x14 (or false false false)))
(let (($x306 (not $x14)))
(and $x306 (or $x14 (and (distinct ?x347 ?x347) true)))))))
(check-sat)
