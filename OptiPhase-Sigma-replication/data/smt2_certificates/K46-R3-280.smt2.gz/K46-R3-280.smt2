; OptiPhase-Sigma refinement certificate for sweep K46-R3-280
; query 0: function adpcm_decoder, block 61, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.013_32 () (_ BitVec 32))
(declare-fun in.210_32 () (_ BitVec 32))
(assert
 (let ((?x116 (bvadd in.210_32 in.013_32)))
(let ((?x62 (bvsub in.013_32 in.210_32)))
(let (($x1278 (and (distinct (bvadd ((_ sign_extend 1) in.210_32) ((_ sign_extend 1) in.013_32)) ((_ sign_extend 1) ?x116)) true)))
(let (($x63 (and (distinct (bvsub ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x62)) true)))
(and (not (or false false (or $x63))) (or (or false false (or $x1278)) (and (distinct ?x62 ?x116) true))))))))
(check-sat)
; query 1: function main, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x308 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x30 (or false false false)))
(and (not $x30) (or $x30 (and (distinct ?x308 ?x308) true))))))
(check-sat)
