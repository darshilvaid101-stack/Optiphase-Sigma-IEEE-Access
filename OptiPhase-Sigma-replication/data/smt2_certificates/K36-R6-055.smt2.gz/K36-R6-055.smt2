; OptiPhase-Sigma refinement certificate for sweep K36-R6-055
; query 0: function main, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x42 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x382 (or false false (or $x42))))
(and (not $x382) (or $x382 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function main, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x85 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x146 (or false false (or $x85))))
(and (not $x146) (or $x146 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function main, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x615 (and (distinct (bvadd ((_ sign_extend 1) in.12_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.12_32 (_ bv1 32)))) true)))
(let (($x53 (or false false (or $x615))))
(and (not $x53) (or $x53 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 3: function main, block 37, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in35_32 () (_ BitVec 32))
(assert
 (let (($x531 (and (distinct (bvadd ((_ sign_extend 1) in35_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in35_32 (_ bv1 32)))) true)))
(let (($x140 (or false false (or $x531))))
(and (not $x140) (or $x140 (and (distinct (bvadd in35_32 (_ bv1 32)) (bvadd in35_32 (_ bv1 32))) true))))))
(check-sat)
