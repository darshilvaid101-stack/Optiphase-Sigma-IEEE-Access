; OptiPhase-Sigma refinement certificate for sweep K16-R3-158
