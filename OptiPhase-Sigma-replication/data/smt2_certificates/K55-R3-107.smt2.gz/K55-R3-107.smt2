; OptiPhase-Sigma refinement certificate for sweep K55-R3-107
; query 0: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x562 (or false false)))
(let (($x148 (not $x562)))
(and $x148 (or $x562 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 1: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x18 ((_ sign_extend 16) in3_16)))
(let ((?x543 (bvand ?x18 (_ bv127 32))))
(let (($x562 (or false false)))
(let (($x517 (or $x562 false false)))
(let (($x120 (not $x517)))
(and $x120 (or $x517 (and (distinct ?x543 ?x543) true)))))))))
(check-sat)
; query 2: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x18 ((_ sign_extend 16) in3_16)))
(let ((?x543 (bvand ?x18 (_ bv127 32))))
(let ((?x28 ((_ extract 15 0) ?x543)))
(let (($x217 (or (and (distinct ((_ zero_extend 16) ?x28) ?x543) true) (and (distinct ((_ sign_extend 16) ?x28) ?x543) true))))
(let (($x562 (or false false)))
(let (($x517 (or $x562 false false)))
(let (($x70 (or $x517 false)))
(let (($x711 (not $x70)))
(and $x711 (or (or $x517 $x217) (and (distinct ?x28 ?x28) true))))))))))))
(check-sat)
; query 3: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x1357 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x604 (or false false false)))
(let (($x996 (not $x604)))
(and $x996 (or $x604 (and (distinct ?x1357 ?x1357) true)))))))
(check-sat)
; query 4: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x88 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x604 (or false false false)))
(let (($x996 (not $x604)))
(and $x996 (or $x604 (and (distinct ?x88 ?x88) true)))))))
(check-sat)
; query 5: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x604 (or false false false)))
(let (($x996 (not $x604)))
(and $x996 (or $x604 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 6: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x376 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x760 (or false false (or $x376))))
(and (not $x760) (or $x760 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 7: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x142 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x538 ((_ zero_extend 31) ?x142)))
(let ((?x434 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x509 ((_ zero_extend 31) ?x434)))
(let ((?x156 (bvand ?x509 ?x538)))
(let ((?x145 (ite (and (distinct (_ bv0 32) ?x156) true) (_ bv1 1) (_ bv0 1))))
(let ((?x114 ((_ zero_extend 63) ?x145)))
(let (($x562 (or false false)))
(let (($x517 (or $x562 false false)))
(let (($x70 (or $x517 false)))
(let (($x147 (or $x70 $x70 false)))
(let (($x54 (or $x147 false false)))
(let (($x8 (or $x54 false)))
(and (not $x8) (or $x8 (and (distinct ?x114 ?x114) true)))))))))))))))))
(check-sat)
; query 8: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x142 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x538 ((_ zero_extend 31) ?x142)))
(let ((?x434 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x509 ((_ zero_extend 31) ?x434)))
(let ((?x156 (bvand ?x509 ?x538)))
(let ((?x145 (ite (and (distinct (_ bv0 32) ?x156) true) (_ bv1 1) (_ bv0 1))))
(let (($x41 (= (_ bv1 1) ?x145)))
(let ((?x181 (ite $x41 (_ bv1 32) (_ bv0 32))))
(let (($x562 (or false false)))
(let (($x517 (or $x562 false false)))
(let (($x70 (or $x517 false)))
(let (($x147 (or $x70 $x70 false)))
(let (($x54 (or $x147 false false)))
(let (($x295 (or $x54 (ite $x41 false false))))
(and (not $x295) (or $x295 (and (distinct ?x181 ?x181) true))))))))))))))))))
(check-sat)
; query 9: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x142 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x538 ((_ zero_extend 31) ?x142)))
(let ((?x434 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x509 ((_ zero_extend 31) ?x434)))
(let ((?x156 (bvand ?x509 ?x538)))
(let ((?x145 (ite (and (distinct (_ bv0 32) ?x156) true) (_ bv1 1) (_ bv0 1))))
(let (($x41 (= (_ bv1 1) ?x145)))
(let ((?x181 (ite $x41 (_ bv1 32) (_ bv0 32))))
(let ((?x76 ((_ extract 7 0) ?x181)))
(let (($x1734 (or (and (distinct ((_ zero_extend 24) ?x76) ?x181) true) (and (distinct ((_ sign_extend 24) ?x76) ?x181) true))))
(let (($x562 (or false false)))
(let (($x517 (or $x562 false false)))
(let (($x70 (or $x517 false)))
(let (($x147 (or $x70 $x70 false)))
(let (($x54 (or $x147 false false)))
(let (($x295 (or $x54 (ite $x41 false false))))
(and (not (or $x295 false)) (or (or $x295 $x1734) (and (distinct ?x76 ?x76) true))))))))))))))))))))
(check-sat)
; query 10: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x562 (or false false)))
(let (($x148 (not $x562)))
(and $x148 (or $x562 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 11: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x434 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x562 (or false false)))
(let (($x517 (or $x562 false false)))
(let (($x120 (not $x517)))
(and $x120 (or $x517 (and (distinct ?x434 ?x434) true))))))))
(check-sat)
; query 12: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x434 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x509 ((_ zero_extend 31) ?x434)))
(let (($x562 (or false false)))
(let (($x517 (or $x562 false false)))
(let (($x70 (or $x517 false)))
(let (($x711 (not $x70)))
(and $x711 (or $x70 (and (distinct ?x509 ?x509) true))))))))))
(check-sat)
; query 13: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x562 (or false false)))
(let (($x148 (not $x562)))
(and $x148 (or $x562 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 14: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x142 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x562 (or false false)))
(let (($x517 (or $x562 false false)))
(let (($x120 (not $x517)))
(and $x120 (or $x517 (and (distinct ?x142 ?x142) true))))))))
(check-sat)
; query 15: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x142 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x538 ((_ zero_extend 31) ?x142)))
(let (($x562 (or false false)))
(let (($x517 (or $x562 false false)))
(let (($x70 (or $x517 false)))
(let (($x711 (not $x70)))
(and $x711 (or $x70 (and (distinct ?x538 ?x538) true))))))))))
(check-sat)
; query 16: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x142 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x538 ((_ zero_extend 31) ?x142)))
(let ((?x434 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x509 ((_ zero_extend 31) ?x434)))
(let ((?x156 (bvand ?x509 ?x538)))
(let (($x562 (or false false)))
(let (($x517 (or $x562 false false)))
(let (($x70 (or $x517 false)))
(let (($x147 (or $x70 $x70 false)))
(and (not $x147) (or $x147 (and (distinct ?x156 ?x156) true)))))))))))))
(check-sat)
; query 17: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x142 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x538 ((_ zero_extend 31) ?x142)))
(let ((?x434 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x509 ((_ zero_extend 31) ?x434)))
(let ((?x156 (bvand ?x509 ?x538)))
(let ((?x145 (ite (and (distinct (_ bv0 32) ?x156) true) (_ bv1 1) (_ bv0 1))))
(let (($x562 (or false false)))
(let (($x517 (or $x562 false false)))
(let (($x70 (or $x517 false)))
(let (($x147 (or $x70 $x70 false)))
(let (($x54 (or $x147 false false)))
(and (not $x54) (or $x54 (and (distinct ?x145 ?x145) true)))))))))))))))
(check-sat)
; query 18: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x190 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x604 (or false false false)))
(let (($x996 (not $x604)))
(and $x996 (or $x604 (and (distinct ?x190 ?x190) true)))))))
(check-sat)
