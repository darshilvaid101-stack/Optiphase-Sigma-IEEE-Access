; OptiPhase-Sigma refinement certificate for sweep K32-R3-085
