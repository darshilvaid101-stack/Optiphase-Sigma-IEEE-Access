; OptiPhase-Sigma refinement certificate for sweep K14-R5-399
