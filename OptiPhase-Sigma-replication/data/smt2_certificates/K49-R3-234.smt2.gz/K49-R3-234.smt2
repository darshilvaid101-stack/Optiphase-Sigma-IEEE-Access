; OptiPhase-Sigma refinement certificate for sweep K49-R3-234
; query 0: function APCM_inverse_quantization, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x484 (or false false)))
(let (($x1802 (not $x484)))
(and $x1802 (or $x484 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 1: function APCM_inverse_quantization, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1575 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x484 (or false false)))
(let (($x1640 (or $x484 false false)))
(let (($x274 (not $x1640)))
(and $x274 (or $x1640 (and (distinct ?x1575 ?x1575) true))))))))
(check-sat)
; query 2: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x484 (or false false)))
(let (($x1802 (not $x484)))
(and $x1802 (or $x484 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 3: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x7 (ite (bvslt (_ bv15 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x484 (or false false)))
(let (($x1640 (or $x484 false false)))
(let (($x274 (not $x1640)))
(and $x274 (or $x1640 (and (distinct ?x7 ?x7) true))))))))
(check-sat)
; query 4: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x484 (or false false)))
(let (($x1802 (not $x484)))
(and $x1802 (or $x484 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 5: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x71 (ite (bvsgt (_ bv40 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x484 (or false false)))
(let (($x1640 (or $x484 false false)))
(let (($x274 (not $x1640)))
(and $x274 (or $x1640 (and (distinct ?x71 ?x71) true))))))))
(check-sat)
; query 6: function RPE_grid_positioning, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x484 (or false false)))
(let (($x1802 (not $x484)))
(and $x1802 (or $x484 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 7: function RPE_grid_positioning, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x896 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x938 (and (distinct ?x896 ?x896) true)))
(let (($x484 (or false false)))
(let (($x33 (or false $x484 false)))
(and (not $x33) (or $x33 $x938)))))))
(check-sat)
; query 8: function alaw_input, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x541 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x364 (or false false (or $x541))))
(and (not $x364) (or $x364 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 9: function alaw_input, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let ((?x1077 (ite (= (_ bv4294967295 32) in.1_32) (_ bv1 1) (_ bv0 1))))
(let (($x531 (or false false false)))
(let (($x36 (not $x531)))
(and $x36 (or $x531 (and (distinct ?x1077 ?x1077) true)))))))
(check-sat)
; query 10: function gsm_L_add, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_64 () (_ BitVec 64))
(assert
 (let ((?x134 (bvsub (_ bv0 64) in13_64)))
(let ((?x130 ((_ sign_extend 1) ?x134)))
(let (($x381 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in13_64)) ?x130) true)))))
(and (not $x381) (or $x381 (and (distinct ?x134 ?x134) true)))))))
(check-sat)
; query 11: function gsm_L_add, block 16, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_64 () (_ BitVec 64))
(assert
 (let ((?x134 (bvsub (_ bv0 64) in13_64)))
(let ((?x516 (bvsub ?x134 (_ bv2 64))))
(let (($x91 (and (distinct (bvsub ((_ sign_extend 1) ?x134) ((_ sign_extend 1) (_ bv2 64))) ((_ sign_extend 1) ?x516)) true)))
(let ((?x130 ((_ sign_extend 1) ?x134)))
(let (($x381 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in13_64)) ?x130) true)))))
(let (($x32 (or $x381 false (or $x91))))
(and (not $x32) (or $x32 (and (distinct ?x516 ?x516) true))))))))))
(check-sat)
; query 12: function gsm_L_add, block 21, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x83 (ite (bvsge (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x531 (or false false false)))
(let (($x36 (not $x531)))
(and $x36 (or $x531 (and (distinct ?x83 ?x83) true)))))))
(check-sat)
; query 13: function gsm_L_add, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x82 (bvadd in0_64 in1_64)))
(let (($x11 (and (distinct ?x82 ?x82) true)))
(let (($x60 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) ?x82)) true)))
(let (($x95 (or false false (or $x60))))
(and (not $x95) (or $x95 $x11)))))))
(check-sat)
; query 14: function gsm_L_add, block 25, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x82 (bvadd in0_64 in1_64)))
(let (($x11 (and (distinct ?x82 ?x82) true)))
(let (($x128 (and (distinct (bvadd ((_ zero_extend 1) in0_64) ((_ zero_extend 1) in1_64)) ((_ zero_extend 1) ?x82)) true)))
(let (($x119 (or false false (or $x128))))
(let (($x531 (or false false false)))
(let (($x36 (not $x531)))
(and $x36 (or $x119 $x11)))))))))
(check-sat)
; query 15: function gsm_L_add, block 25, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x480 (ite (bvugt (bvadd in0_64 in1_64) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x128 (and (distinct (bvadd ((_ zero_extend 1) in0_64) ((_ zero_extend 1) in1_64)) ((_ zero_extend 1) (bvadd in0_64 in1_64))) true)))
(let (($x119 (or false false (or $x128))))
(let (($x531 (or false false false)))
(let (($x278 (or $x531 false false)))
(let (($x500 (not $x278)))
(and $x500 (or (or $x119 false false) (and (distinct ?x480 ?x480) true))))))))))
(check-sat)
; query 16: function gsm_L_add, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x103 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x531 (or false false false)))
(let (($x36 (not $x531)))
(and $x36 (or $x531 (and (distinct ?x103 ?x103) true)))))))
(check-sat)
; query 17: function gsm_L_add, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x82 (bvadd in0_64 in1_64)))
(let (($x11 (and (distinct ?x82 ?x82) true)))
(let (($x60 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) ?x82)) true)))
(let (($x95 (or false false (or $x60))))
(and (not $x95) (or $x95 $x11)))))))
(check-sat)
; query 18: function gsm_L_add, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x9 (bvadd in0_64 (_ bv1 64))))
(let ((?x72 (bvsub (_ bv0 64) ?x9)))
(let (($x1614 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x9)) ((_ sign_extend 1) ?x72)) true)))
(let ((?x456 ((_ sign_extend 1) ?x9)))
(let (($x991 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x456) true)))))
(let (($x2780 (or false $x991 (or $x1614))))
(and (not $x2780) (or $x2780 (and (distinct ?x72 ?x72) true))))))))))
(check-sat)
; query 19: function gsm_L_add, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x2634 (bvadd in1_64 (_ bv1 64))))
(let ((?x575 ((_ sign_extend 1) ?x2634)))
(let (($x1026 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x575) true)))))
(and (not $x1026) (or $x1026 (and (distinct ?x2634 ?x2634) true)))))))
(check-sat)
; query 20: function gsm_L_add, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x2634 (bvadd in1_64 (_ bv1 64))))
(let ((?x176 (bvsub (_ bv0 64) ?x2634)))
(let (($x1848 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x2634)) ((_ sign_extend 1) ?x176)) true)))
(let ((?x575 ((_ sign_extend 1) ?x2634)))
(let (($x1026 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x575) true)))))
(let (($x615 (or false $x1026 (or $x1848))))
(and (not $x615) (or $x615 (and (distinct ?x176 ?x176) true))))))))))
(check-sat)
; query 21: function gsm_L_add, block 8, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2634 (bvadd in1_64 (_ bv1 64))))
(let ((?x176 (bvsub (_ bv0 64) ?x2634)))
(let ((?x9 (bvadd in0_64 (_ bv1 64))))
(let ((?x72 (bvsub (_ bv0 64) ?x9)))
(let ((?x59 (bvadd ?x72 ?x176)))
(let (($x1512 (and (distinct (bvadd ((_ zero_extend 1) ?x72) ((_ zero_extend 1) ?x176)) ((_ zero_extend 1) ?x59)) true)))
(let (($x1848 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x2634)) ((_ sign_extend 1) ?x176)) true)))
(let ((?x575 ((_ sign_extend 1) ?x2634)))
(let (($x1026 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x575) true)))))
(let (($x615 (or false $x1026 (or $x1848))))
(let (($x1614 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x9)) ((_ sign_extend 1) ?x72)) true)))
(let ((?x456 ((_ sign_extend 1) ?x9)))
(let (($x991 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x456) true)))))
(let (($x2780 (or false $x991 (or $x1614))))
(let (($x1685 (or $x2780 $x615 (or $x1512))))
(and (not (or $x2780 $x615 false)) (or $x1685 (and (distinct ?x59 ?x59) true)))))))))))))))))))
(check-sat)
; query 22: function gsm_L_add, block 8, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2634 (bvadd in1_64 (_ bv1 64))))
(let ((?x176 (bvsub (_ bv0 64) ?x2634)))
(let ((?x9 (bvadd in0_64 (_ bv1 64))))
(let ((?x72 (bvsub (_ bv0 64) ?x9)))
(let ((?x59 (bvadd ?x72 ?x176)))
(let ((?x1791 (ite (bvuge ?x59 (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x1512 (and (distinct (bvadd ((_ zero_extend 1) ?x72) ((_ zero_extend 1) ?x176)) ((_ zero_extend 1) ?x59)) true)))
(let (($x1848 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x2634)) ((_ sign_extend 1) ?x176)) true)))
(let ((?x575 ((_ sign_extend 1) ?x2634)))
(let (($x1026 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x575) true)))))
(let (($x615 (or false $x1026 (or $x1848))))
(let (($x1614 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x9)) ((_ sign_extend 1) ?x72)) true)))
(let ((?x456 ((_ sign_extend 1) ?x9)))
(let (($x991 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x456) true)))))
(let (($x2780 (or false $x991 (or $x1614))))
(let (($x1685 (or $x2780 $x615 (or $x1512))))
(and (not (or (or $x2780 $x615 false) false false)) (or (or $x1685 false false) (and (distinct ?x1791 ?x1791) true))))))))))))))))))))
(check-sat)
; query 23: function gsm_L_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x9 (bvadd in0_64 (_ bv1 64))))
(let ((?x456 ((_ sign_extend 1) ?x9)))
(let (($x991 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x456) true)))))
(and (not $x991) (or $x991 (and (distinct ?x9 ?x9) true)))))))
(check-sat)
; query 24: function gsm_L_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x385 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x531 (or false false false)))
(let (($x36 (not $x531)))
(and $x36 (or $x531 (and (distinct ?x385 ?x385) true)))))))
(check-sat)
; query 25: function gsm_L_asl, block 12, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1348 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x531 (or false false false)))
(let (($x36 (not $x531)))
(and $x36 (or $x531 (and (distinct ?x1348 ?x1348) true)))))))
(check-sat)
; query 26: function gsm_L_asl, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x883 (or false (or (= ((_ extract 31 31) in1_32) (_ bv1 1))))))
(let (($x484 (or false false)))
(let (($x1802 (not $x484)))
(and $x1802 (or $x883 (and (distinct ((_ zero_extend 32) in1_32) ((_ zero_extend 32) in1_32)) true)))))))
(check-sat)
; query 27: function gsm_L_asl, block 17, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1435 ((_ zero_extend 32) in1_32)))
(let ((?x1689 (bvshl in0_64 ?x1435)))
(let (($x2063 (bvuge ?x1435 (_ bv64 64))))
(let (($x1837 (or (or false (or false (or (= ((_ extract 31 31) in1_32) (_ bv1 1)))) false) $x2063)))
(let (($x840 (not (or (or false (or false false) false) $x2063))))
(and $x840 (or $x1837 (and (distinct ?x1689 ?x1689) true)))))))))
(check-sat)
; query 28: function gsm_L_asl, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x704 (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x531 (or false false false)))
(let (($x36 (not $x531)))
(and $x36 (or $x531 (and (distinct ?x704 ?x704) true)))))))
(check-sat)
; query 29: function gsm_L_asl, block 7, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x385 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x218 ((_ zero_extend 31) ?x385)))
(let ((?x318 (bvsub (_ bv0 32) ?x218)))
(let (($x1875 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x218)) ((_ sign_extend 1) ?x318)) true)))
(let (($x531 (or false false false)))
(let (($x1351 (or $x531 false)))
(let (($x953 (or false $x1351 (or $x1875))))
(and (not $x953) (or $x953 (and (distinct ?x318 ?x318) true)))))))))))
(check-sat)
; query 30: function gsm_L_asl, block 7, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x385 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x218 ((_ zero_extend 31) ?x385)))
(let ((?x318 (bvsub (_ bv0 32) ?x218)))
(let ((?x1751 ((_ sign_extend 32) ?x318)))
(let (($x1875 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x218)) ((_ sign_extend 1) ?x318)) true)))
(let (($x531 (or false false false)))
(let (($x1351 (or $x531 false)))
(let (($x953 (or false $x1351 (or $x1875))))
(let (($x227 (or $x953 false)))
(and (not $x227) (or $x227 (and (distinct ?x1751 ?x1751) true)))))))))))))
(check-sat)
; query 31: function gsm_L_asl, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x385 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x531 (or false false false)))
(let (($x36 (not $x531)))
(and $x36 (or $x531 (and (distinct ?x385 ?x385) true)))))))
(check-sat)
; query 32: function gsm_L_asl, block 7, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x385 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x218 ((_ zero_extend 31) ?x385)))
(let (($x531 (or false false false)))
(let (($x1351 (or $x531 false)))
(and (not $x1351) (or $x1351 (and (distinct ?x218 ?x218) true))))))))
(check-sat)
; query 33: function gsm_L_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1887 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x531 (or false false false)))
(let (($x36 (not $x531)))
(and $x36 (or $x531 (and (distinct ?x1887 ?x1887) true)))))))
(check-sat)
; query 34: function gsm_L_asr, block 12, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1348 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x531 (or false false false)))
(let (($x36 (not $x531)))
(and $x36 (or $x531 (and (distinct ?x1348 ?x1348) true)))))))
(check-sat)
; query 35: function gsm_L_asr, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x1641 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in1_32))) true)))
(let (($x621 (or false false (or $x1641))))
(and (not $x621) (or $x621 (and (distinct (bvsub (_ bv0 32) in1_32) (bvsub (_ bv0 32) in1_32)) true))))))
(check-sat)
; query 36: function gsm_L_asr, block 14, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x758 (bvsub (_ bv0 32) in1_32)))
(let ((?x1237 ((_ zero_extend 32) ?x758)))
(let (($x1641 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x758)) true)))
(let (($x621 (or false false (or $x1641))))
(let (($x1480 (or $x621 (or (= ((_ extract 31 31) ?x758) (_ bv1 1))))))
(and (not (or $x621 false)) (or $x1480 (and (distinct ?x1237 ?x1237) true)))))))))
(check-sat)
; query 37: function gsm_L_asr, block 14, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x758 (bvsub (_ bv0 32) in1_32)))
(let ((?x1237 ((_ zero_extend 32) ?x758)))
(let ((?x692 (bvshl in0_64 ?x1237)))
(let (($x5 (bvuge ?x1237 (_ bv64 64))))
(let (($x1641 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x758)) true)))
(let (($x621 (or false false (or $x1641))))
(let (($x1480 (or $x621 (or (= ((_ extract 31 31) ?x758) (_ bv1 1))))))
(and (not (or (or false (or $x621 false) false) $x5)) (or (or (or false $x1480 false) $x5) (and (distinct ?x692 ?x692) true)))))))))))
(check-sat)
; query 38: function gsm_L_asr, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x883 (or false (or (= ((_ extract 31 31) in1_32) (_ bv1 1))))))
(let (($x484 (or false false)))
(let (($x1802 (not $x484)))
(and $x1802 (or $x883 (and (distinct ((_ zero_extend 32) in1_32) ((_ zero_extend 32) in1_32)) true)))))))
(check-sat)
; query 39: function gsm_L_asr, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1435 ((_ zero_extend 32) in1_32)))
(let ((?x94 (bvashr in0_64 ?x1435)))
(let (($x2063 (bvuge ?x1435 (_ bv64 64))))
(let (($x1837 (or (or false (or false (or (= ((_ extract 31 31) in1_32) (_ bv1 1)))) false) $x2063)))
(let (($x840 (not (or (or false (or false false) false) $x2063))))
(and $x840 (or $x1837 (and (distinct ?x94 ?x94) true)))))))))
(check-sat)
; query 40: function gsm_L_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x385 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x531 (or false false false)))
(let (($x36 (not $x531)))
(and $x36 (or $x531 (and (distinct ?x385 ?x385) true)))))))
(check-sat)
; query 41: function gsm_L_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x385 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x218 ((_ zero_extend 31) ?x385)))
(let (($x531 (or false false false)))
(let (($x1351 (or $x531 false)))
(and (not $x1351) (or $x1351 (and (distinct ?x218 ?x218) true))))))))
(check-sat)
; query 42: function gsm_L_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x385 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x218 ((_ zero_extend 31) ?x385)))
(let ((?x318 (bvsub (_ bv0 32) ?x218)))
(let (($x1875 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x218)) ((_ sign_extend 1) ?x318)) true)))
(let (($x531 (or false false false)))
(let (($x1351 (or $x531 false)))
(let (($x953 (or false $x1351 (or $x1875))))
(and (not $x953) (or $x953 (and (distinct ?x318 ?x318) true)))))))))))
(check-sat)
; query 43: function gsm_L_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x385 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x218 ((_ zero_extend 31) ?x385)))
(let ((?x318 (bvsub (_ bv0 32) ?x218)))
(let ((?x1751 ((_ sign_extend 32) ?x318)))
(let (($x1875 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x218)) ((_ sign_extend 1) ?x318)) true)))
(let (($x531 (or false false false)))
(let (($x1351 (or $x531 false)))
(let (($x953 (or false $x1351 (or $x1875))))
(let (($x227 (or $x953 false)))
(and (not $x227) (or $x227 (and (distinct ?x1751 ?x1751) true)))))))))))))
(check-sat)
; query 44: function gsm_L_asr, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x704 (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x531 (or false false false)))
(let (($x36 (not $x531)))
(and $x36 (or $x531 (and (distinct ?x704 ?x704) true)))))))
(check-sat)
; query 45: function gsm_L_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1887 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x531 (or false false false)))
(let (($x36 (not $x531)))
(and $x36 (or $x531 (and (distinct ?x1887 ?x1887) true)))))))
(check-sat)
; query 46: function gsm_L_mult, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x484 (or false false)))
(let (($x1802 (not $x484)))
(and $x1802 (or $x484 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 47: function gsm_L_mult, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1540 (ite (and (distinct (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) true) (_ bv1 1) (_ bv0 1))))
(let (($x484 (or false false)))
(let (($x1640 (or $x484 false false)))
(let (($x274 (not $x1640)))
(and $x274 (or $x1640 (and (distinct ?x1540 ?x1540) true))))))))
(check-sat)
; query 48: function gsm_L_mult, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x484 (or false false)))
(let (($x1802 (not $x484)))
(and $x1802 (or $x484 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 49: function gsm_L_mult, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1873 (ite (and (distinct (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) true) (_ bv1 1) (_ bv0 1))))
(let (($x484 (or false false)))
(let (($x1640 (or $x484 false false)))
(let (($x274 (not $x1640)))
(and $x274 (or $x1640 (and (distinct ?x1873 ?x1873) true))))))))
(check-sat)
; query 50: function gsm_L_sub, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in11_64 () (_ BitVec 64))
(assert
 (let (($x619 (and (distinct (bvadd ((_ zero_extend 1) in11_64) ((_ zero_extend 1) (_ bv1 64))) ((_ zero_extend 1) (bvadd in11_64 (_ bv1 64)))) true)))
(let (($x396 (and (distinct (bvadd ((_ sign_extend 1) in11_64) ((_ sign_extend 1) (_ bv1 64))) ((_ sign_extend 1) (bvadd in11_64 (_ bv1 64)))) true)))
(let (($x603 (or (or false false (or $x396 $x619)) (and (distinct (bvadd in11_64 (_ bv1 64)) (bvadd in11_64 (_ bv1 64))) true))))
(let (($x531 (or false false false)))
(let (($x36 (not $x531)))
(and $x36 $x603)))))))
(check-sat)
; query 51: function gsm_L_sub, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x83 (ite (bvsge (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x531 (or false false false)))
(let (($x36 (not $x531)))
(and $x36 (or $x531 (and (distinct ?x83 ?x83) true)))))))
(check-sat)
; query 52: function gsm_L_sub, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x311 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvsub in0_64 in1_64))) true)))
(let (($x912 (or false false (or $x311))))
(let (($x1088 (or $x912 (and (distinct (bvsub in0_64 in1_64) (bvsub in0_64 in1_64)) true))))
(and (not $x912) $x1088)))))
(check-sat)
; query 53: function gsm_L_sub, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x9 (bvadd in0_64 (_ bv1 64))))
(let ((?x456 ((_ sign_extend 1) ?x9)))
(let (($x991 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x456) true)))))
(and (not $x991) (or $x991 (and (distinct ?x9 ?x9) true)))))))
(check-sat)
; query 54: function gsm_L_sub, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x9 (bvadd in0_64 (_ bv1 64))))
(let ((?x72 (bvsub (_ bv0 64) ?x9)))
(let (($x1614 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x9)) ((_ sign_extend 1) ?x72)) true)))
(let ((?x456 ((_ sign_extend 1) ?x9)))
(let (($x991 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x456) true)))))
(let (($x2780 (or false $x991 (or $x1614))))
(and (not $x2780) (or $x2780 (and (distinct ?x72 ?x72) true))))))))))
(check-sat)
; query 55: function gsm_L_sub, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x9 (bvadd in0_64 (_ bv1 64))))
(let ((?x72 (bvsub (_ bv0 64) ?x9)))
(let ((?x1214 (bvadd ?x72 in1_64)))
(let (($x1683 (and (distinct (bvadd ((_ zero_extend 1) ?x72) ((_ zero_extend 1) in1_64)) ((_ zero_extend 1) ?x1214)) true)))
(let (($x1614 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x9)) ((_ sign_extend 1) ?x72)) true)))
(let ((?x456 ((_ sign_extend 1) ?x9)))
(let (($x991 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x456) true)))))
(let (($x2780 (or false $x991 (or $x1614))))
(let (($x852 (or $x2780 false (or $x1683))))
(and (not (or $x2780 false false)) (or $x852 (and (distinct ?x1214 ?x1214) true)))))))))))))
(check-sat)
; query 56: function gsm_L_sub, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1209 (ite (bvuge (bvadd (bvsub (_ bv0 64) (bvadd in0_64 (_ bv1 64))) in1_64) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let ((?x365 ((_ zero_extend 1) in1_64)))
(let ((?x9 (bvadd in0_64 (_ bv1 64))))
(let ((?x72 (bvsub (_ bv0 64) ?x9)))
(let ((?x96 ((_ zero_extend 1) ?x72)))
(let (($x1614 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x9)) ((_ sign_extend 1) ?x72)) true)))
(let ((?x456 ((_ sign_extend 1) ?x9)))
(let (($x991 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x456) true)))))
(let (($x2780 (or false $x991 (or $x1614))))
(let (($x852 (or $x2780 false (or (and (distinct (bvadd ?x96 ?x365) ((_ zero_extend 1) (bvadd ?x72 in1_64))) true)))))
(and (not (or (or $x2780 false false) false false)) (or (or $x852 false false) (and (distinct ?x1209 ?x1209) true))))))))))))))
(check-sat)
; query 57: function gsm_L_sub, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_64 () (_ BitVec 64))
(assert
 (let ((?x1774 (bvsub (_ bv0 64) in25_64)))
(let ((?x1514 ((_ sign_extend 1) ?x1774)))
(let (($x1559 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in25_64)) ?x1514) true)))))
(and (not $x1559) (or $x1559 (and (distinct ?x1774 ?x1774) true)))))))
(check-sat)
; query 58: function gsm_L_sub, block 28, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_64 () (_ BitVec 64))
(assert
 (let ((?x1774 (bvsub (_ bv0 64) in25_64)))
(let ((?x1151 (bvsub ?x1774 (_ bv1 64))))
(let (($x1935 (and (distinct (bvsub ((_ zero_extend 1) ?x1774) ((_ zero_extend 1) (_ bv1 64))) ((_ zero_extend 1) ?x1151)) true)))
(let (($x1194 (and (distinct (bvsub ((_ sign_extend 1) ?x1774) ((_ sign_extend 1) (_ bv1 64))) ((_ sign_extend 1) ?x1151)) true)))
(let ((?x1514 ((_ sign_extend 1) ?x1774)))
(let (($x1559 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in25_64)) ?x1514) true)))))
(and (not (or $x1559 false (or $x1194))) (or (or $x1559 false (or $x1194 $x1935)) (and (distinct ?x1151 ?x1151) true))))))))))
(check-sat)
; query 59: function gsm_L_sub, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x103 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x531 (or false false false)))
(let (($x36 (not $x531)))
(and $x36 (or $x531 (and (distinct ?x103 ?x103) true)))))))
(check-sat)
; query 60: function gsm_L_sub, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x311 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvsub in0_64 in1_64))) true)))
(let (($x912 (or false false (or $x311))))
(let (($x1088 (or $x912 (and (distinct (bvsub in0_64 in1_64) (bvsub in0_64 in1_64)) true))))
(and (not $x912) $x1088)))))
(check-sat)
; query 61: function gsm_L_sub, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x2634 (bvadd in1_64 (_ bv1 64))))
(let ((?x176 (bvsub (_ bv0 64) ?x2634)))
(let (($x1848 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x2634)) ((_ sign_extend 1) ?x176)) true)))
(let ((?x575 ((_ sign_extend 1) ?x2634)))
(let (($x1026 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x575) true)))))
(let (($x615 (or false $x1026 (or $x1848))))
(and (not $x615) (or $x615 (and (distinct ?x176 ?x176) true))))))))))
(check-sat)
; query 62: function gsm_L_sub, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2634 (bvadd in1_64 (_ bv1 64))))
(let ((?x176 (bvsub (_ bv0 64) ?x2634)))
(let ((?x1487 (bvadd in0_64 ?x176)))
(let (($x1826 (and (distinct (bvadd ((_ zero_extend 1) in0_64) ((_ zero_extend 1) ?x176)) ((_ zero_extend 1) ?x1487)) true)))
(let (($x1848 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x2634)) ((_ sign_extend 1) ?x176)) true)))
(let ((?x575 ((_ sign_extend 1) ?x2634)))
(let (($x1026 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x575) true)))))
(let (($x615 (or false $x1026 (or $x1848))))
(let (($x878 (or false $x615 (or $x1826))))
(and (not (or false $x615 false)) (or $x878 (and (distinct ?x1487 ?x1487) true)))))))))))))
(check-sat)
; query 63: function gsm_L_sub, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1661 (ite (bvuge (bvadd in0_64 (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64)))) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let ((?x2634 (bvadd in1_64 (_ bv1 64))))
(let ((?x176 (bvsub (_ bv0 64) ?x2634)))
(let ((?x1582 ((_ zero_extend 1) ?x176)))
(let ((?x12 ((_ zero_extend 1) in0_64)))
(let (($x1848 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x2634)) ((_ sign_extend 1) ?x176)) true)))
(let ((?x575 ((_ sign_extend 1) ?x2634)))
(let (($x1026 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x575) true)))))
(let (($x615 (or false $x1026 (or $x1848))))
(let (($x878 (or false $x615 (or (and (distinct (bvadd ?x12 ?x1582) ((_ zero_extend 1) (bvadd in0_64 ?x176))) true)))))
(and (not (or (or false $x615 false) false false)) (or (or $x878 false false) (and (distinct ?x1661 ?x1661) true))))))))))))))
(check-sat)
; query 64: function gsm_L_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x2634 (bvadd in1_64 (_ bv1 64))))
(let ((?x575 ((_ sign_extend 1) ?x2634)))
(let (($x1026 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x575) true)))))
(and (not $x1026) (or $x1026 (and (distinct ?x2634 ?x2634) true)))))))
(check-sat)
; query 65: function gsm_L_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1881 (ite (bvsle (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x531 (or false false false)))
(let (($x36 (not $x531)))
(and $x36 (or $x531 (and (distinct ?x1881 ?x1881) true)))))))
(check-sat)
; query 66: function gsm_abs, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x484 (or false false)))
(let (($x1802 (not $x484)))
(and $x1802 (or $x484 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 67: function gsm_abs, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1972 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x484 (or false false)))
(let (($x1640 (or $x484 false false)))
(let (($x274 (not $x1640)))
(and $x274 (or $x1640 (and (distinct ?x1972 ?x1972) true))))))))
(check-sat)
; query 68: function gsm_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_64 () (_ BitVec 64))
(assert
 (let ((?x1122 (ite (bvslt (_ bv32767 64) in5_64) (_ bv1 1) (_ bv0 1))))
(let (($x531 (or false false false)))
(let (($x36 (not $x531)))
(and $x36 (or $x531 (and (distinct ?x1122 ?x1122) true)))))))
(check-sat)
; query 69: function gsm_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x484 (or false false)))
(let (($x1802 (not $x484)))
(and $x1802 (or $x484 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 70: function gsm_add, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x484 (or false false)))
(let (($x1802 (not $x484)))
(and $x1802 (or $x484 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 71: function gsm_add, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1787 ((_ sign_extend 48) in1_16)))
(let ((?x812 ((_ sign_extend 48) in0_16)))
(let ((?x438 (bvadd ?x812 ?x1787)))
(let (($x1049 (and (distinct (bvadd ((_ sign_extend 1) ?x812) ((_ sign_extend 1) ?x1787)) ((_ sign_extend 1) ?x438)) true)))
(let (($x484 (or false false)))
(let (($x1410 (or $x484 $x484 (or $x1049))))
(and (not $x1410) (or $x1410 (and (distinct ?x438 ?x438) true))))))))))
(check-sat)
; query 72: function gsm_add, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x423 (ite (bvsgt (_ bv18446744073709518848 64) (bvadd ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x1787 ((_ sign_extend 48) in1_16)))
(let ((?x1344 ((_ sign_extend 1) ?x1787)))
(let ((?x812 ((_ sign_extend 48) in0_16)))
(let ((?x634 ((_ sign_extend 1) ?x812)))
(let (($x484 (or false false)))
(let (($x1410 (or $x484 $x484 (or (and (distinct (bvadd ?x634 ?x1344) ((_ sign_extend 1) (bvadd ?x812 ?x1787))) true)))))
(let (($x640 (or $x1410 false false)))
(and (not $x640) (or $x640 (and (distinct ?x423 ?x423) true))))))))))))
(check-sat)
; query 73: function gsm_asl, block 13, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1348 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x531 (or false false false)))
(let (($x36 (not $x531)))
(and $x36 (or $x531 (and (distinct ?x1348 ?x1348) true)))))))
(check-sat)
; query 74: function gsm_asl, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x484 (or false false)))
(let (($x1802 (not $x484)))
(and $x1802 (or $x484 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 75: function gsm_asl, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x296 ((_ sign_extend 16) in0_16)))
(let ((?x2515 (bvshl ?x296 in1_32)))
(let (($x1587 (bvuge in1_32 (_ bv32 32))))
(let (($x484 (or false false)))
(let (($x1271 (or (or $x484 false (or (and (distinct (bvashr ?x2515 in1_32) ?x296) true))) $x1587)))
(let (($x1640 (or $x484 false false)))
(let (($x151 (or $x1640 $x1587)))
(let (($x1899 (not $x151)))
(and $x1899 (or $x1271 (and (distinct ?x2515 ?x2515) true))))))))))))
(check-sat)
; query 76: function gsm_asl, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x296 ((_ sign_extend 16) in0_16)))
(let ((?x2515 (bvshl ?x296 in1_32)))
(let ((?x252 ((_ extract 15 0) ?x2515)))
(let (($x1587 (bvuge in1_32 (_ bv32 32))))
(let (($x484 (or false false)))
(let (($x1271 (or (or $x484 false (or (and (distinct (bvashr ?x2515 in1_32) ?x296) true))) $x1587)))
(let (($x1443 (not (or (or (or $x484 false false) $x1587) false))))
(and $x1443 (or (or $x1271 false) (and (distinct ?x252 ?x252) true)))))))))))
(check-sat)
; query 77: function gsm_asl, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1928 (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x531 (or false false false)))
(let (($x36 (not $x531)))
(and $x36 (or $x531 (and (distinct ?x1928 ?x1928) true)))))))
(check-sat)
; query 78: function gsm_asl, block 7, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1972 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x2788 ((_ zero_extend 31) ?x1972)))
(let (($x484 (or false false)))
(let (($x1640 (or $x484 false false)))
(let (($x2069 (or $x1640 false)))
(and (not $x2069) (or $x2069 (and (distinct ?x2788 ?x2788) true)))))))))
(check-sat)
; query 79: function gsm_asl, block 7, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1972 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x2788 ((_ zero_extend 31) ?x1972)))
(let ((?x1612 (bvsub (_ bv0 32) ?x2788)))
(let (($x1952 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x2788)) ((_ sign_extend 1) ?x1612)) true)))
(let (($x484 (or false false)))
(let (($x1640 (or $x484 false false)))
(let (($x2069 (or $x1640 false)))
(let (($x372 (or false $x2069 (or $x1952))))
(and (not $x372) (or $x372 (and (distinct ?x1612 ?x1612) true))))))))))))
(check-sat)
; query 80: function gsm_asl, block 7, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1972 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x2788 ((_ zero_extend 31) ?x1972)))
(let ((?x1612 (bvsub (_ bv0 32) ?x2788)))
(let ((?x1042 ((_ extract 15 0) ?x1612)))
(let (($x1952 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x2788)) ((_ sign_extend 1) ?x1612)) true)))
(let (($x484 (or false false)))
(let (($x1640 (or $x484 false false)))
(let (($x2069 (or $x1640 false)))
(let (($x372 (or false $x2069 (or $x1952))))
(let (($x2031 (or (or $x372 (or (and (distinct ((_ sign_extend 16) ?x1042) ?x1612) true))) (and (distinct ?x1042 ?x1042) true))))
(and (not (or $x372 false)) $x2031))))))))))))
(check-sat)
; query 81: function gsm_asl, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x484 (or false false)))
(let (($x1802 (not $x484)))
(and $x1802 (or $x484 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 82: function gsm_asl, block 7, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1972 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x484 (or false false)))
(let (($x1640 (or $x484 false false)))
(let (($x274 (not $x1640)))
(and $x274 (or $x1640 (and (distinct ?x1972 ?x1972) true))))))))
(check-sat)
; query 83: function gsm_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1079 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x531 (or false false false)))
(let (($x36 (not $x531)))
(and $x36 (or $x531 (and (distinct ?x1079 ?x1079) true)))))))
(check-sat)
; query 84: function gsm_asr, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1928 (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x531 (or false false false)))
(let (($x36 (not $x531)))
(and $x36 (or $x531 (and (distinct ?x1928 ?x1928) true)))))))
(check-sat)
; query 85: function gsm_asr, block 13, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1348 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x531 (or false false false)))
(let (($x36 (not $x531)))
(and $x36 (or $x531 (and (distinct ?x1348 ?x1348) true)))))))
(check-sat)
; query 86: function gsm_asr, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x484 (or false false)))
(let (($x1802 (not $x484)))
(and $x1802 (or $x484 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 87: function gsm_asr, block 15, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x1641 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in1_32))) true)))
(let (($x621 (or false false (or $x1641))))
(and (not $x621) (or $x621 (and (distinct (bvsub (_ bv0 32) in1_32) (bvsub (_ bv0 32) in1_32)) true))))))
(check-sat)
; query 88: function gsm_asr, block 15, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x758 (bvsub (_ bv0 32) in1_32)))
(let ((?x296 ((_ sign_extend 16) in0_16)))
(let ((?x850 (bvshl ?x296 ?x758)))
(let (($x1063 (bvuge ?x758 (_ bv32 32))))
(let (($x1641 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x758)) true)))
(let (($x621 (or false false (or $x1641))))
(let (($x484 (or false false)))
(let (($x1767 (or (or $x484 $x621 (or (and (distinct (bvashr ?x850 ?x758) ?x296) true))) $x1063)))
(and (not (or (or $x484 $x621 false) $x1063)) (or $x1767 (and (distinct ?x850 ?x850) true))))))))))))
(check-sat)
; query 89: function gsm_asr, block 15, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x758 (bvsub (_ bv0 32) in1_32)))
(let ((?x296 ((_ sign_extend 16) in0_16)))
(let ((?x850 (bvshl ?x296 ?x758)))
(let ((?x836 ((_ extract 15 0) ?x850)))
(let (($x1063 (bvuge ?x758 (_ bv32 32))))
(let (($x1641 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x758)) true)))
(let (($x621 (or false false (or $x1641))))
(let (($x484 (or false false)))
(let (($x1767 (or (or $x484 $x621 (or (and (distinct (bvashr ?x850 ?x758) ?x296) true))) $x1063)))
(and (not (or (or (or $x484 $x621 false) $x1063) false)) (or (or $x1767 false) (and (distinct ?x836 ?x836) true)))))))))))))
(check-sat)
; query 90: function gsm_asr, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x484 (or false false)))
(let (($x1802 (not $x484)))
(and $x1802 (or $x484 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 91: function gsm_asr, block 20, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x296 ((_ sign_extend 16) in0_16)))
(let ((?x1205 (bvashr ?x296 in1_32)))
(let (($x1587 (bvuge in1_32 (_ bv32 32))))
(let (($x484 (or false false)))
(let (($x1640 (or $x484 false false)))
(let (($x151 (or $x1640 $x1587)))
(let (($x1899 (not $x151)))
(and $x1899 (or $x151 (and (distinct ?x1205 ?x1205) true)))))))))))
(check-sat)
; query 92: function gsm_asr, block 20, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x296 ((_ sign_extend 16) in0_16)))
(let ((?x1205 (bvashr ?x296 in1_32)))
(let ((?x536 ((_ extract 15 0) ?x1205)))
(let (($x1587 (bvuge in1_32 (_ bv32 32))))
(let (($x484 (or false false)))
(let (($x1640 (or $x484 false false)))
(let (($x151 (or $x1640 $x1587)))
(let (($x1501 (or (or $x151 (or (and (distinct ((_ sign_extend 16) ?x536) ?x1205) true))) (and (distinct ?x536 ?x536) true))))
(let (($x1443 (not (or $x151 false))))
(and $x1443 $x1501)))))))))))
(check-sat)
; query 93: function gsm_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x484 (or false false)))
(let (($x1802 (not $x484)))
(and $x1802 (or $x484 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 94: function gsm_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1972 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x484 (or false false)))
(let (($x1640 (or $x484 false false)))
(let (($x274 (not $x1640)))
(and $x274 (or $x1640 (and (distinct ?x1972 ?x1972) true))))))))
(check-sat)
; query 95: function gsm_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1972 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x2788 ((_ zero_extend 31) ?x1972)))
(let (($x484 (or false false)))
(let (($x1640 (or $x484 false false)))
(let (($x2069 (or $x1640 false)))
(and (not $x2069) (or $x2069 (and (distinct ?x2788 ?x2788) true)))))))))
(check-sat)
; query 96: function gsm_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1972 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x2788 ((_ zero_extend 31) ?x1972)))
(let ((?x1612 (bvsub (_ bv0 32) ?x2788)))
(let (($x1952 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x2788)) ((_ sign_extend 1) ?x1612)) true)))
(let (($x484 (or false false)))
(let (($x1640 (or $x484 false false)))
(let (($x2069 (or $x1640 false)))
(let (($x372 (or false $x2069 (or $x1952))))
(and (not $x372) (or $x372 (and (distinct ?x1612 ?x1612) true))))))))))))
(check-sat)
; query 97: function gsm_asr, block 4, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1972 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x2788 ((_ zero_extend 31) ?x1972)))
(let ((?x1612 (bvsub (_ bv0 32) ?x2788)))
(let ((?x1042 ((_ extract 15 0) ?x1612)))
(let (($x1952 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x2788)) ((_ sign_extend 1) ?x1612)) true)))
(let (($x484 (or false false)))
(let (($x1640 (or $x484 false false)))
(let (($x2069 (or $x1640 false)))
(let (($x372 (or false $x2069 (or $x1952))))
(let (($x2031 (or (or $x372 (or (and (distinct ((_ sign_extend 16) ?x1042) ?x1612) true))) (and (distinct ?x1042 ?x1042) true))))
(and (not (or $x372 false)) $x2031))))))))))))
(check-sat)
; query 98: function gsm_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1079 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x531 (or false false false)))
(let (($x36 (not $x531)))
(and $x36 (or $x531 (and (distinct ?x1079 ?x1079) true)))))))
(check-sat)
; query 99: function gsm_debug_longwords, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in15_32 () (_ BitVec 32))
(assert
 (let ((?x512 (ite (bvslt in15_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x531 (or false false false)))
(let (($x36 (not $x531)))
(and $x36 (or $x531 (and (distinct ?x512 ?x512) true)))))))
(check-sat)
; query 100: function gsm_debug_words, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in16_32 () (_ BitVec 32))
(assert
 (let ((?x1894 (ite (bvslt in16_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x531 (or false false false)))
(let (($x36 (not $x531)))
(and $x36 (or $x531 (and (distinct ?x1894 ?x1894) true)))))))
(check-sat)
; query 101: function gsm_div, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x484 (or false false)))
(let (($x1802 (not $x484)))
(and $x1802 (or $x484 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 102: function gsm_div, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x484 (or false false)))
(let (($x1802 (not $x484)))
(and $x1802 (or $x484 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 103: function gsm_div, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x484 (or false false)))
(let (($x1802 (not $x484)))
(and $x1802 (or $x484 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 104: function gsm_div, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x896 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x938 (and (distinct ?x896 ?x896) true)))
(let (($x484 (or false false)))
(let (($x1640 (or $x484 false false)))
(let (($x274 (not $x1640)))
(and $x274 (or $x1640 $x938))))))))
(check-sat)
; query 105: function gsm_mult, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x484 (or false false)))
(let (($x1802 (not $x484)))
(and $x1802 (or $x484 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 106: function gsm_mult, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x556 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x484 (or false false)))
(let (($x1640 (or $x484 false false)))
(let (($x274 (not $x1640)))
(and $x274 (or $x1640 (and (distinct ?x556 ?x556) true))))))))
(check-sat)
; query 107: function gsm_mult, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x484 (or false false)))
(let (($x1802 (not $x484)))
(and $x1802 (or $x484 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 108: function gsm_mult, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x484 (or false false)))
(let (($x1802 (not $x484)))
(and $x1802 (or $x484 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 109: function gsm_mult, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1787 ((_ sign_extend 48) in1_16)))
(let ((?x812 ((_ sign_extend 48) in0_16)))
(let ((?x1499 (bvmul ?x812 ?x1787)))
(let (($x1868 (and (distinct (bvmul ((_ sign_extend 64) ?x812) ((_ sign_extend 64) ?x1787)) ((_ sign_extend 64) ?x1499)) true)))
(let (($x484 (or false false)))
(let (($x1603 (or $x484 $x484 (or $x1868))))
(and (not $x1603) (or $x1603 (and (distinct ?x1499 ?x1499) true))))))))))
(check-sat)
; query 110: function gsm_mult, block 9, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1787 ((_ sign_extend 48) in1_16)))
(let ((?x812 ((_ sign_extend 48) in0_16)))
(let ((?x1499 (bvmul ?x812 ?x1787)))
(let ((?x1532 (bvashr ?x1499 (_ bv15 64))))
(let (($x1458 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1868 (and (distinct (bvmul ((_ sign_extend 64) ?x812) ((_ sign_extend 64) ?x1787)) ((_ sign_extend 64) ?x1499)) true)))
(let (($x484 (or false false)))
(let (($x1603 (or $x484 $x484 (or $x1868))))
(let (($x808 (or (or $x1603 false false) $x1458)))
(and (not $x808) (or $x808 (and (distinct ?x1532 ?x1532) true)))))))))))))
(check-sat)
; query 111: function gsm_mult, block 9, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1787 ((_ sign_extend 48) in1_16)))
(let ((?x812 ((_ sign_extend 48) in0_16)))
(let ((?x1499 (bvmul ?x812 ?x1787)))
(let ((?x1532 (bvashr ?x1499 (_ bv15 64))))
(let ((?x327 ((_ extract 15 0) ?x1532)))
(let (($x1458 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1868 (and (distinct (bvmul ((_ sign_extend 64) ?x812) ((_ sign_extend 64) ?x1787)) ((_ sign_extend 64) ?x1499)) true)))
(let (($x484 (or false false)))
(let (($x1603 (or $x484 $x484 (or $x1868))))
(let (($x808 (or (or $x1603 false false) $x1458)))
(let (($x1820 (or $x808 false)))
(and (not $x1820) (or $x1820 (and (distinct ?x327 ?x327) true)))))))))))))))
(check-sat)
; query 112: function gsm_mult, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x484 (or false false)))
(let (($x1802 (not $x484)))
(and $x1802 (or $x484 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 113: function gsm_mult, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1725 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x484 (or false false)))
(let (($x1640 (or $x484 false false)))
(let (($x274 (not $x1640)))
(and $x274 (or $x1640 (and (distinct ?x1725 ?x1725) true))))))))
(check-sat)
; query 114: function gsm_mult_r, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x484 (or false false)))
(let (($x1802 (not $x484)))
(and $x1802 (or $x484 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 115: function gsm_mult_r, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1725 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x484 (or false false)))
(let (($x1640 (or $x484 false false)))
(let (($x274 (not $x1640)))
(and $x274 (or $x1640 (and (distinct ?x1725 ?x1725) true))))))))
(check-sat)
; query 116: function gsm_mult_r, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x484 (or false false)))
(let (($x1802 (not $x484)))
(and $x1802 (or $x484 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 117: function gsm_mult_r, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x484 (or false false)))
(let (($x1802 (not $x484)))
(and $x1802 (or $x484 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 118: function gsm_mult_r, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1787 ((_ sign_extend 48) in1_16)))
(let ((?x812 ((_ sign_extend 48) in0_16)))
(let ((?x1499 (bvmul ?x812 ?x1787)))
(let (($x1868 (and (distinct (bvmul ((_ sign_extend 64) ?x812) ((_ sign_extend 64) ?x1787)) ((_ sign_extend 64) ?x1499)) true)))
(let (($x484 (or false false)))
(let (($x1603 (or $x484 $x484 (or $x1868))))
(and (not $x1603) (or $x1603 (and (distinct ?x1499 ?x1499) true))))))))))
(check-sat)
; query 119: function gsm_mult_r, block 9, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1787 ((_ sign_extend 48) in1_16)))
(let ((?x812 ((_ sign_extend 48) in0_16)))
(let ((?x1499 (bvmul ?x812 ?x1787)))
(let ((?x1915 (bvadd ?x1499 (_ bv16384 64))))
(let (($x302 (and (distinct (bvadd ((_ sign_extend 1) ?x1499) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x1915)) true)))
(let (($x1868 (and (distinct (bvmul ((_ sign_extend 64) ?x812) ((_ sign_extend 64) ?x1787)) ((_ sign_extend 64) ?x1499)) true)))
(let (($x484 (or false false)))
(let (($x1603 (or $x484 $x484 (or $x1868))))
(let (($x2778 (or $x1603 false (or $x302))))
(and (not $x2778) (or $x2778 (and (distinct ?x1915 ?x1915) true)))))))))))))
(check-sat)
; query 120: function gsm_mult_r, block 9, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1787 ((_ sign_extend 48) in1_16)))
(let ((?x812 ((_ sign_extend 48) in0_16)))
(let ((?x1499 (bvmul ?x812 ?x1787)))
(let ((?x1915 (bvadd ?x1499 (_ bv16384 64))))
(let ((?x2758 (bvashr ?x1915 (_ bv15 64))))
(let (($x1458 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x302 (and (distinct (bvadd ((_ sign_extend 1) ?x1499) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x1915)) true)))
(let (($x1868 (and (distinct (bvmul ((_ sign_extend 64) ?x812) ((_ sign_extend 64) ?x1787)) ((_ sign_extend 64) ?x1499)) true)))
(let (($x484 (or false false)))
(let (($x1603 (or $x484 $x484 (or $x1868))))
(let (($x2778 (or $x1603 false (or $x302))))
(let (($x978 (or (or $x2778 false false) $x1458)))
(and (not $x978) (or $x978 (and (distinct ?x2758 ?x2758) true))))))))))))))))
(check-sat)
; query 121: function gsm_mult_r, block 9, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1787 ((_ sign_extend 48) in1_16)))
(let ((?x812 ((_ sign_extend 48) in0_16)))
(let ((?x1499 (bvmul ?x812 ?x1787)))
(let ((?x1915 (bvadd ?x1499 (_ bv16384 64))))
(let ((?x2758 (bvashr ?x1915 (_ bv15 64))))
(let ((?x909 (bvand ?x2758 (_ bv65535 64))))
(let (($x1458 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x302 (and (distinct (bvadd ((_ sign_extend 1) ?x1499) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x1915)) true)))
(let (($x1868 (and (distinct (bvmul ((_ sign_extend 64) ?x812) ((_ sign_extend 64) ?x1787)) ((_ sign_extend 64) ?x1499)) true)))
(let (($x484 (or false false)))
(let (($x1603 (or $x484 $x484 (or $x1868))))
(let (($x2778 (or $x1603 false (or $x302))))
(let (($x978 (or (or $x2778 false false) $x1458)))
(let (($x1096 (or $x978 false false)))
(and (not $x1096) (or $x1096 (and (distinct ?x909 ?x909) true))))))))))))))))))
(check-sat)
; query 122: function gsm_mult_r, block 9, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1787 ((_ sign_extend 48) in1_16)))
(let ((?x812 ((_ sign_extend 48) in0_16)))
(let ((?x1499 (bvmul ?x812 ?x1787)))
(let ((?x1915 (bvadd ?x1499 (_ bv16384 64))))
(let ((?x2758 (bvashr ?x1915 (_ bv15 64))))
(let ((?x909 (bvand ?x2758 (_ bv65535 64))))
(let ((?x2657 ((_ extract 15 0) ?x909)))
(let (($x1458 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x302 (and (distinct (bvadd ((_ sign_extend 1) ?x1499) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x1915)) true)))
(let (($x1868 (and (distinct (bvmul ((_ sign_extend 64) ?x812) ((_ sign_extend 64) ?x1787)) ((_ sign_extend 64) ?x1499)) true)))
(let (($x484 (or false false)))
(let (($x1603 (or $x484 $x484 (or $x1868))))
(let (($x2778 (or $x1603 false (or $x302))))
(let (($x978 (or (or $x2778 false false) $x1458)))
(let (($x1096 (or $x978 false false)))
(let (($x609 (or (or $x1096 (or (and (distinct ((_ zero_extend 48) ?x2657) ?x909) true))) (and (distinct ?x2657 ?x2657) true))))
(and (not (or $x1096 false)) $x609))))))))))))))))))
(check-sat)
; query 123: function gsm_mult_r, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x484 (or false false)))
(let (($x1802 (not $x484)))
(and $x1802 (or $x484 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 124: function gsm_mult_r, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x556 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x484 (or false false)))
(let (($x1640 (or $x484 false false)))
(let (($x274 (not $x1640)))
(and $x274 (or $x1640 (and (distinct ?x556 ?x556) true))))))))
(check-sat)
; query 125: function gsm_norm, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x385 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x531 (or false false false)))
(let (($x36 (not $x531)))
(and $x36 (or $x531 (and (distinct ?x385 (ite (bvsge (_ bv18446744072635809792 64) in0_64) (_ bv1 1) (_ bv0 1))) true)))))))
(check-sat)
; query 126: function gsm_norm, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x606 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x531 (or false false false)))
(let (($x36 (not $x531)))
(and $x36 (or $x531 (and (distinct ?x606 ?x606) true)))))))
(check-sat)
; query 127: function gsm_norm, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x606 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x1124 (bvxor ?x606 (_ bv1 1))))
(let (($x531 (or false false false)))
(let (($x278 (or $x531 false false)))
(let (($x500 (not $x278)))
(and $x500 (or $x278 (and (distinct ?x1124 ?x1124) true)))))))))
(check-sat)
; query 128: function gsm_norm, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x606 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x1124 (bvxor ?x606 (_ bv1 1))))
(let ((?x2803 ((_ zero_extend 31) ?x1124)))
(let (($x531 (or false false false)))
(let (($x278 (or $x531 false false)))
(let (($x2663 (or $x278 false)))
(and (not $x2663) (or $x2663 (and (distinct ?x2803 ?x2803) true))))))))))
(check-sat)
; query 129: function gsm_norm, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x606 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x1124 (bvxor ?x606 (_ bv1 1))))
(let ((?x2803 ((_ zero_extend 31) ?x1124)))
(let (($x531 (or false false false)))
(let (($x278 (or $x531 false false)))
(let (($x2663 (or $x278 false)))
(let (($x1390 (or (or $x2663 (or (= ((_ extract 31 31) ?x2803) (_ bv1 1)))) (and (distinct ((_ sign_extend 32) ?x2803) ((_ zero_extend 32) ?x2803)) true))))
(and (not (or $x2663 false)) $x1390)))))))))
(check-sat)
; query 130: function gsm_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_64 () (_ BitVec 64))
(assert
 (let ((?x1122 (ite (bvslt (_ bv32767 64) in5_64) (_ bv1 1) (_ bv0 1))))
(let (($x531 (or false false false)))
(let (($x36 (not $x531)))
(and $x36 (or $x531 (and (distinct ?x1122 ?x1122) true)))))))
(check-sat)
; query 131: function gsm_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x484 (or false false)))
(let (($x1802 (not $x484)))
(and $x1802 (or $x484 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 132: function gsm_sub, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x484 (or false false)))
(let (($x1802 (not $x484)))
(and $x1802 (or $x484 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 133: function gsm_sub, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1787 ((_ sign_extend 48) in1_16)))
(let ((?x812 ((_ sign_extend 48) in0_16)))
(let ((?x1635 (bvsub ?x812 ?x1787)))
(let (($x1905 (and (distinct (bvsub ((_ sign_extend 1) ?x812) ((_ sign_extend 1) ?x1787)) ((_ sign_extend 1) ?x1635)) true)))
(let (($x484 (or false false)))
(let (($x651 (or $x484 $x484 (or $x1905))))
(and (not $x651) (or $x651 (and (distinct ?x1635 ?x1635) true))))))))))
(check-sat)
; query 134: function gsm_sub, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1792 (ite (bvsgt (_ bv18446744073709518848 64) (bvsub ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x1787 ((_ sign_extend 48) in1_16)))
(let ((?x1344 ((_ sign_extend 1) ?x1787)))
(let ((?x812 ((_ sign_extend 48) in0_16)))
(let ((?x634 ((_ sign_extend 1) ?x812)))
(let (($x484 (or false false)))
(let (($x651 (or $x484 $x484 (or (and (distinct (bvsub ?x634 ?x1344) ((_ sign_extend 1) (bvsub ?x812 ?x1787))) true)))))
(let (($x511 (or $x651 false false)))
(and (not $x511) (or $x511 (and (distinct ?x1792 ?x1792) true))))))))))))
(check-sat)
; query 135: function ok_to_replace, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x623 (ite (and (distinct (_ bv4294967295 32) in.01_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x531 (or false false false)))
(let (($x36 (not $x531)))
(and $x36 (or $x531 (and (distinct ?x623 ?x623) true)))))))
(check-sat)
; query 136: function ok_to_replace, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in16_32 () (_ BitVec 32))
(assert
 (let ((?x2599 (ite (= (_ bv121 32) in16_32) (_ bv1 1) (_ bv0 1))))
(let (($x531 (or false false false)))
(let (($x36 (not $x531)))
(and $x36 (or $x531 (and (distinct ?x2599 ?x2599) true)))))))
(check-sat)
; query 137: function suffix, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_64 () (_ BitVec 64))
(declare-fun in3_64 () (_ BitVec 64))
(assert
 (let ((?x2618 (ite (bvule in3_64 in4_64) (_ bv1 1) (_ bv0 1))))
(let (($x531 (or false false false)))
(let (($x36 (not $x531)))
(and $x36 (or $x531 (and (distinct ?x2618 ?x2618) true)))))))
(check-sat)
; query 138: function ulaw_input, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x541 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x364 (or false false (or $x541))))
(and (not $x364) (or $x364 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 139: function ulaw_input, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let ((?x1077 (ite (= (_ bv4294967295 32) in.1_32) (_ bv1 1) (_ bv0 1))))
(let (($x531 (or false false false)))
(let (($x36 (not $x531)))
(and $x36 (or $x531 (and (distinct ?x1077 ?x1077) true)))))))
(check-sat)
