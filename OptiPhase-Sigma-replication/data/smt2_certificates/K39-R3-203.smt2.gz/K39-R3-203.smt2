; OptiPhase-Sigma refinement certificate for sweep K39-R3-203
; query 0: function BF_ofb64_encrypt, block 82, name %83
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x244 (ite (= (_ bv0 32) in.04_32) (_ bv1 1) (_ bv0 1))))
(let (($x545 (or false false false)))
(and (not $x545) (or $x545 (and (distinct ?x244 ?x244) true))))))
(check-sat)
