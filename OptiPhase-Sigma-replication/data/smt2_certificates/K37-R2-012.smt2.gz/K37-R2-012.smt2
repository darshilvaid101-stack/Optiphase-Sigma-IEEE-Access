; OptiPhase-Sigma refinement certificate for sweep K37-R2-012
; query 0: function bit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x485 (and (distinct (bvsub ((_ sign_extend 1) (_ bv31 32)) ((_ sign_extend 1) in0_32)) ((_ sign_extend 1) (bvsub (_ bv31 32) in0_32))) true)))
(let (($x95 (or false false (or $x485))))
(and (not $x95) (or $x95 (and (distinct (bvsub (_ bv31 32) in0_32) (bvsub (_ bv31 32) in0_32)) true))))))
(check-sat)
; query 1: function bit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x582 (bvsub (_ bv31 32) in0_32)))
(let ((?x33 (bvshl (_ bv1 32) ?x582)))
(let (($x485 (and (distinct (bvsub ((_ sign_extend 1) (_ bv31 32)) ((_ sign_extend 1) in0_32)) ((_ sign_extend 1) ?x582)) true)))
(let (($x95 (or false false (or $x485))))
(let (($x77 (or (or false $x95 false) (bvuge ?x582 (_ bv32 32)))))
(and (not $x77) (or $x77 (and (distinct ?x33 ?x33) true)))))))))
(check-sat)
; query 2: function bit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x582 (bvsub (_ bv31 32) in0_32)))
(let ((?x33 (bvshl (_ bv1 32) ?x582)))
(let ((?x386 ((_ sign_extend 32) ?x33)))
(let (($x485 (and (distinct (bvsub ((_ sign_extend 1) (_ bv31 32)) ((_ sign_extend 1) in0_32)) ((_ sign_extend 1) ?x582)) true)))
(let (($x95 (or false false (or $x485))))
(let (($x77 (or (or false $x95 false) (bvuge ?x582 (_ bv32 32)))))
(let (($x229 (or $x77 false)))
(and (not $x229) (or $x229 (and (distinct ?x386 ?x386) true)))))))))))
(check-sat)
; query 3: function bit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x582 (bvsub (_ bv31 32) in0_32)))
(let ((?x33 (bvshl (_ bv1 32) ?x582)))
(let ((?x386 ((_ sign_extend 32) ?x33)))
(let ((?x16 (bvand in1_64 ?x386)))
(let (($x485 (and (distinct (bvsub ((_ sign_extend 1) (_ bv31 32)) ((_ sign_extend 1) in0_32)) ((_ sign_extend 1) ?x582)) true)))
(let (($x95 (or false false (or $x485))))
(let (($x77 (or (or false $x95 false) (bvuge ?x582 (_ bv32 32)))))
(let (($x229 (or $x77 false)))
(let (($x427 (or false $x229 false)))
(and (not $x427) (or $x427 (and (distinct ?x16 ?x16) true)))))))))))))
(check-sat)
