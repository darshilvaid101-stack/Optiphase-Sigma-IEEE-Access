; OptiPhase-Sigma refinement certificate for sweep K27-R1-004
