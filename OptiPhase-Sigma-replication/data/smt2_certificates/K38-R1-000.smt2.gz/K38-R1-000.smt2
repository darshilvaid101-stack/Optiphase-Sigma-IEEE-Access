; OptiPhase-Sigma refinement certificate for sweep K38-R1-000
; query 0: function BF_cbc_encrypt, block 126, name %127
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.010_64 () (_ BitVec 64))
(assert
 (let (($x68 (and (distinct (bvsub ((_ sign_extend 1) in.010_64) ((_ sign_extend 1) (_ bv8 64))) ((_ sign_extend 1) (bvsub in.010_64 (_ bv8 64)))) true)))
(let (($x22 (or false false (or $x68))))
(and (not $x22) (or $x22 (and (distinct (bvsub in.010_64 (_ bv8 64)) (bvsub in.010_64 (_ bv8 64))) true))))))
(check-sat)
; query 1: function BF_cbc_encrypt, block 128, name %129
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.010_64 () (_ BitVec 64))
(assert
 (let ((?x168 (ite (and (distinct (_ bv18446744073709551608 64) in.010_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x24 (or false false false)))
(let (($x196 (not $x24)))
(and $x196 (or $x24 (and (distinct ?x168 ?x168) true)))))))
(check-sat)
; query 2: function BF_cbc_encrypt, block 366, name %367
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.111_64 () (_ BitVec 64))
(assert
 (let (($x427 (and (distinct (bvsub ((_ sign_extend 1) in.111_64) ((_ sign_extend 1) (_ bv8 64))) ((_ sign_extend 1) (bvsub in.111_64 (_ bv8 64)))) true)))
(let (($x441 (or false false (or $x427))))
(and (not $x441) (or $x441 (and (distinct (bvsub in.111_64 (_ bv8 64)) (bvsub in.111_64 (_ bv8 64))) true))))))
(check-sat)
; query 3: function BF_cbc_encrypt, block 368, name %369
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.111_64 () (_ BitVec 64))
(assert
 (let ((?x202 (ite (and (distinct (_ bv18446744073709551608 64) in.111_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x24 (or false false false)))
(let (($x196 (not $x24)))
(and $x196 (or $x24 (and (distinct ?x202 ?x202) true)))))))
(check-sat)
; query 4: function BF_cfb64_encrypt, block 111, name %112
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.18_32 () (_ BitVec 32))
(assert
 (let ((?x92 (ite (= (_ bv0 32) in.18_32) (_ bv1 1) (_ bv0 1))))
(let (($x24 (or false false false)))
(let (($x196 (not $x24)))
(and $x196 (or $x24 (and (distinct ?x92 ?x92) true)))))))
(check-sat)
; query 5: function BF_cfb64_encrypt, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.07_32 () (_ BitVec 32))
(assert
 (let ((?x79 (ite (= (_ bv0 32) in.07_32) (_ bv1 1) (_ bv0 1))))
(let (($x24 (or false false false)))
(let (($x196 (not $x24)))
(and $x196 (or $x24 (and (distinct ?x79 ?x79) true)))))))
(check-sat)
; query 6: function BF_ofb64_encrypt, block 135, name %136
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x458 (ite (and (distinct (_ bv0 32) in.02_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x24 (or false false false)))
(let (($x196 (not $x24)))
(and $x196 (or $x24 (and (distinct ?x458 ?x458) true)))))))
(check-sat)
; query 7: function BF_ofb64_encrypt, block 82, name %83
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x114 (ite (= (_ bv0 32) in.04_32) (_ bv1 1) (_ bv0 1))))
(let (($x24 (or false false false)))
(let (($x196 (not $x24)))
(and $x196 (or $x24 (and (distinct ?x114 ?x114) true)))))))
(check-sat)
; query 8: function BF_set_key, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x370 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x87 (or false false (or $x370))))
(and (not $x87) (or $x87 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 9: function BF_set_key, block 69, name %70
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.13_32 () (_ BitVec 32))
(assert
 (let (($x117 (and (distinct (bvadd ((_ sign_extend 1) in.13_32) ((_ sign_extend 1) (_ bv2 32))) ((_ sign_extend 1) (bvadd in.13_32 (_ bv2 32)))) true)))
(let (($x286 (or false false (or $x117))))
(and (not $x286) (or $x286 (and (distinct (bvadd in.13_32 (_ bv2 32)) (bvadd in.13_32 (_ bv2 32))) true))))))
(check-sat)
; query 10: function BF_set_key, block 87, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.24_32 () (_ BitVec 32))
(assert
 (let (($x100 (and (distinct (bvadd ((_ sign_extend 1) in.24_32) ((_ sign_extend 1) (_ bv2 32))) ((_ sign_extend 1) (bvadd in.24_32 (_ bv2 32)))) true)))
(let (($x328 (or false false (or $x100))))
(and (not $x328) (or $x328 (and (distinct (bvadd in.24_32 (_ bv2 32)) (bvadd in.24_32 (_ bv2 32))) true))))))
(check-sat)
; query 11: function main, block 124, name %125
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let ((?x404 (ite (bvsgt (_ bv40 32) in.2_32) (_ bv1 1) (_ bv0 1))))
(let (($x24 (or false false false)))
(let (($x196 (not $x24)))
(and $x196 (or $x24 (and (distinct ?x404 ?x404) true)))))))
(check-sat)
; query 12: function main, block 147, name %148
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x111 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x365 (or false false (or $x111))))
(and (not $x365) (or $x365 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 13: function main, block 60, name %61
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x432 (or false false)))
(and (not $x432) (or $x432 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 14: function main, block 60, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x181 (ite (bvsge (_ bv57 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x432 (or false false)))
(let (($x93 (or $x432 false false)))
(let (($x219 (not $x93)))
(and $x219 (or $x93 (and (distinct ?x181 ?x181) true))))))))
(check-sat)
; query 15: function main, block 63, name %64
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x24 (or false false false)))
(let (($x65 (or $x24 (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x65) (or $x65 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvshl in.01_32 (_ bv4 32))) true))))))
(check-sat)
; query 16: function main, block 63, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x432 (or false false)))
(and (not $x432) (or $x432 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 17: function main, block 63, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x125 ((_ sign_extend 24) in57_8)))
(let ((?x62 (bvshl in.01_32 (_ bv4 32))))
(let ((?x49 (bvadd ?x62 ?x125)))
(let ((?x333 ((_ sign_extend 1) ?x49)))
(let (($x432 (or false false)))
(let (($x24 (or false false false)))
(let (($x65 (or $x24 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x384 (or $x65 $x432 (or (and (distinct (bvadd ((_ sign_extend 1) ?x62) ((_ sign_extend 1) ?x125)) ?x333) true)))))
(and (not $x384) (or $x384 (and (distinct ?x49 ?x49) true))))))))))))
(check-sat)
; query 18: function main, block 63, name %67
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x125 ((_ sign_extend 24) in57_8)))
(let ((?x62 (bvshl in.01_32 (_ bv4 32))))
(let ((?x49 (bvadd ?x62 ?x125)))
(let ((?x359 (bvsub ?x49 (_ bv48 32))))
(let (($x438 (and (distinct (bvsub ((_ sign_extend 1) ?x49) ((_ sign_extend 1) (_ bv48 32))) ((_ sign_extend 1) ?x359)) true)))
(let ((?x333 ((_ sign_extend 1) ?x49)))
(let (($x432 (or false false)))
(let (($x24 (or false false false)))
(let (($x65 (or $x24 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x384 (or $x65 $x432 (or (and (distinct (bvadd ((_ sign_extend 1) ?x62) ((_ sign_extend 1) ?x125)) ?x333) true)))))
(let (($x310 (or $x384 false (or $x438))))
(and (not $x310) (or $x310 (and (distinct ?x359 ?x359) true)))))))))))))))
(check-sat)
; query 19: function main, block 68, name %69
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x432 (or false false)))
(and (not $x432) (or $x432 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 20: function main, block 68, name %70
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x56 (ite (bvsle (_ bv65 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x432 (or false false)))
(let (($x93 (or $x432 false false)))
(let (($x219 (not $x93)))
(and $x219 (or $x93 (and (distinct ?x56 ?x56) true))))))))
(check-sat)
; query 21: function main, block 71, name %72
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x432 (or false false)))
(and (not $x432) (or $x432 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 22: function main, block 71, name %73
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x433 (ite (bvsge (_ bv70 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x432 (or false false)))
(let (($x93 (or $x432 false false)))
(let (($x219 (not $x93)))
(and $x219 (or $x93 (and (distinct ?x433 ?x433) true))))))))
(check-sat)
; query 23: function main, block 74, name %75
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x24 (or false false false)))
(let (($x65 (or $x24 (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x65) (or $x65 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvshl in.01_32 (_ bv4 32))) true))))))
(check-sat)
; query 24: function main, block 74, name %76
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x432 (or false false)))
(and (not $x432) (or $x432 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 25: function main, block 74, name %77
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x125 ((_ sign_extend 24) in57_8)))
(let ((?x62 (bvshl in.01_32 (_ bv4 32))))
(let ((?x49 (bvadd ?x62 ?x125)))
(let ((?x333 ((_ sign_extend 1) ?x49)))
(let (($x432 (or false false)))
(let (($x24 (or false false false)))
(let (($x65 (or $x24 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x384 (or $x65 $x432 (or (and (distinct (bvadd ((_ sign_extend 1) ?x62) ((_ sign_extend 1) ?x125)) ?x333) true)))))
(and (not $x384) (or $x384 (and (distinct ?x49 ?x49) true))))))))))))
(check-sat)
; query 26: function main, block 74, name %78
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x125 ((_ sign_extend 24) in57_8)))
(let ((?x62 (bvshl in.01_32 (_ bv4 32))))
(let ((?x49 (bvadd ?x62 ?x125)))
(let ((?x244 (bvsub ?x49 (_ bv65 32))))
(let ((?x521 ((_ sign_extend 1) ?x244)))
(let ((?x333 ((_ sign_extend 1) ?x49)))
(let (($x432 (or false false)))
(let (($x24 (or false false false)))
(let (($x65 (or $x24 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x384 (or $x65 $x432 (or (and (distinct (bvadd ((_ sign_extend 1) ?x62) ((_ sign_extend 1) ?x125)) ?x333) true)))))
(let (($x149 (or $x384 false (or (and (distinct (bvsub ?x333 ((_ sign_extend 1) (_ bv65 32))) ?x521) true)))))
(and (not $x149) (or $x149 (and (distinct ?x244 ?x244) true)))))))))))))))
(check-sat)
; query 27: function main, block 74, name %79
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x125 ((_ sign_extend 24) in57_8)))
(let ((?x62 (bvshl in.01_32 (_ bv4 32))))
(let ((?x49 (bvadd ?x62 ?x125)))
(let ((?x244 (bvsub ?x49 (_ bv65 32))))
(let ((?x464 (bvadd ?x244 (_ bv10 32))))
(let (($x161 (and (distinct (bvadd ((_ sign_extend 1) ?x244) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x464)) true)))
(let ((?x521 ((_ sign_extend 1) ?x244)))
(let ((?x333 ((_ sign_extend 1) ?x49)))
(let (($x432 (or false false)))
(let (($x24 (or false false false)))
(let (($x65 (or $x24 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x384 (or $x65 $x432 (or (and (distinct (bvadd ((_ sign_extend 1) ?x62) ((_ sign_extend 1) ?x125)) ?x333) true)))))
(let (($x149 (or $x384 false (or (and (distinct (bvsub ?x333 ((_ sign_extend 1) (_ bv65 32))) ?x521) true)))))
(let (($x31 (or $x149 false (or $x161))))
(and (not $x31) (or $x31 (and (distinct ?x464 ?x464) true))))))))))))))))))
(check-sat)
