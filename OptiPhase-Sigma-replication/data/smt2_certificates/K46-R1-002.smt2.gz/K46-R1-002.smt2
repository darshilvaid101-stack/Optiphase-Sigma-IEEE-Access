; OptiPhase-Sigma refinement certificate for sweep K46-R1-002
