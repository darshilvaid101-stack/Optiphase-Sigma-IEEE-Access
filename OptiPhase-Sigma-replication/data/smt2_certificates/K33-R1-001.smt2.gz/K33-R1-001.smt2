; OptiPhase-Sigma refinement certificate for sweep K33-R1-001
; query 0: function edge_draw, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let ((?x147 (ite (= (_ bv0 32) in4_32) (_ bv1 1) (_ bv0 1))))
(let (($x334 (or false false false)))
(and (not $x334) (or $x334 (and (distinct ?x147 ?x147) true))))))
(check-sat)
