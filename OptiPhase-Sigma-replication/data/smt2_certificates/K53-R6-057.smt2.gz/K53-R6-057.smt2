; OptiPhase-Sigma refinement certificate for sweep K53-R6-057
