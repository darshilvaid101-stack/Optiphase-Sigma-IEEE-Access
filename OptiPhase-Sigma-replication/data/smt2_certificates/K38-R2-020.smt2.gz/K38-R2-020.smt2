; OptiPhase-Sigma refinement certificate for sweep K38-R2-020
; query 0: function BF_cbc_encrypt, block 126, name %127
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.010_64 () (_ BitVec 64))
(assert
 (let (($x27 (and (distinct (bvsub ((_ sign_extend 1) in.010_64) ((_ sign_extend 1) (_ bv8 64))) ((_ sign_extend 1) (bvsub in.010_64 (_ bv8 64)))) true)))
(let (($x196 (or false false (or $x27))))
(and (not $x196) (or $x196 (and (distinct (bvsub in.010_64 (_ bv8 64)) (bvsub in.010_64 (_ bv8 64))) true))))))
(check-sat)
; query 1: function BF_cbc_encrypt, block 366, name %367
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.111_64 () (_ BitVec 64))
(assert
 (let (($x96 (and (distinct (bvsub ((_ sign_extend 1) in.111_64) ((_ sign_extend 1) (_ bv8 64))) ((_ sign_extend 1) (bvsub in.111_64 (_ bv8 64)))) true)))
(let (($x50 (or false false (or $x96))))
(and (not $x50) (or $x50 (and (distinct (bvsub in.111_64 (_ bv8 64)) (bvsub in.111_64 (_ bv8 64))) true))))))
(check-sat)
; query 2: function BF_cfb64_encrypt, block 111, name %112
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.18_32 () (_ BitVec 32))
(assert
 (let ((?x193 (ite (= (_ bv0 32) in.18_32) (_ bv1 1) (_ bv0 1))))
(let (($x313 (or false false false)))
(let (($x130 (not $x313)))
(and $x130 (or $x313 (and (distinct ?x193 ?x193) true)))))))
(check-sat)
; query 3: function BF_cfb64_encrypt, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.07_32 () (_ BitVec 32))
(assert
 (let ((?x100 (ite (= (_ bv0 32) in.07_32) (_ bv1 1) (_ bv0 1))))
(let (($x313 (or false false false)))
(let (($x130 (not $x313)))
(and $x130 (or $x313 (and (distinct ?x100 ?x100) true)))))))
(check-sat)
; query 4: function BF_ofb64_encrypt, block 82, name %83
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x224 (ite (= (_ bv0 32) in.04_32) (_ bv1 1) (_ bv0 1))))
(let (($x313 (or false false false)))
(let (($x130 (not $x313)))
(and $x130 (or $x313 (and (distinct ?x224 ?x224) true)))))))
(check-sat)
; query 5: function BF_set_key, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x82 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x46 (or false false (or $x82))))
(and (not $x46) (or $x46 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 6: function BF_set_key, block 69, name %70
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.13_32 () (_ BitVec 32))
(assert
 (let (($x13 (and (distinct (bvadd ((_ sign_extend 1) in.13_32) ((_ sign_extend 1) (_ bv2 32))) ((_ sign_extend 1) (bvadd in.13_32 (_ bv2 32)))) true)))
(let (($x53 (or false false (or $x13))))
(and (not $x53) (or $x53 (and (distinct (bvadd in.13_32 (_ bv2 32)) (bvadd in.13_32 (_ bv2 32))) true))))))
(check-sat)
; query 7: function BF_set_key, block 87, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.24_32 () (_ BitVec 32))
(assert
 (let (($x122 (and (distinct (bvadd ((_ sign_extend 1) in.24_32) ((_ sign_extend 1) (_ bv2 32))) ((_ sign_extend 1) (bvadd in.24_32 (_ bv2 32)))) true)))
(let (($x90 (or false false (or $x122))))
(and (not $x90) (or $x90 (and (distinct (bvadd in.24_32 (_ bv2 32)) (bvadd in.24_32 (_ bv2 32))) true))))))
(check-sat)
; query 8: function main, block 124, name %125
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let ((?x117 (ite (bvsgt (_ bv40 32) in.2_32) (_ bv1 1) (_ bv0 1))))
(let (($x313 (or false false false)))
(let (($x130 (not $x313)))
(and $x130 (or $x313 (and (distinct ?x117 ?x117) true)))))))
(check-sat)
; query 9: function main, block 147, name %148
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x316 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x232 (or false false (or $x316))))
(and (not $x232) (or $x232 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 10: function main, block 60, name %61
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x63 (or false false)))
(and (not $x63) (or $x63 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 11: function main, block 60, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x105 (ite (bvsge (_ bv57 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x63 (or false false)))
(let (($x235 (or $x63 false false)))
(let (($x125 (not $x235)))
(and $x125 (or $x235 (and (distinct ?x105 ?x105) true))))))))
(check-sat)
; query 12: function main, block 63, name %64
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x313 (or false false false)))
(let (($x23 (or $x313 (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x23) (or $x23 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvshl in.01_32 (_ bv4 32))) true))))))
(check-sat)
; query 13: function main, block 63, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x63 (or false false)))
(and (not $x63) (or $x63 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 14: function main, block 63, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x36 ((_ sign_extend 24) in57_8)))
(let ((?x198 (bvshl in.01_32 (_ bv4 32))))
(let ((?x32 (bvadd ?x198 ?x36)))
(let ((?x47 ((_ sign_extend 1) ?x32)))
(let (($x63 (or false false)))
(let (($x313 (or false false false)))
(let (($x23 (or $x313 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x74 (or $x23 $x63 (or (and (distinct (bvadd ((_ sign_extend 1) ?x198) ((_ sign_extend 1) ?x36)) ?x47) true)))))
(and (not $x74) (or $x74 (and (distinct ?x32 ?x32) true))))))))))))
(check-sat)
; query 15: function main, block 63, name %67
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x36 ((_ sign_extend 24) in57_8)))
(let ((?x198 (bvshl in.01_32 (_ bv4 32))))
(let ((?x32 (bvadd ?x198 ?x36)))
(let ((?x170 (bvsub ?x32 (_ bv48 32))))
(let (($x171 (and (distinct (bvsub ((_ sign_extend 1) ?x32) ((_ sign_extend 1) (_ bv48 32))) ((_ sign_extend 1) ?x170)) true)))
(let ((?x47 ((_ sign_extend 1) ?x32)))
(let (($x63 (or false false)))
(let (($x313 (or false false false)))
(let (($x23 (or $x313 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x74 (or $x23 $x63 (or (and (distinct (bvadd ((_ sign_extend 1) ?x198) ((_ sign_extend 1) ?x36)) ?x47) true)))))
(let (($x26 (or $x74 false (or $x171))))
(and (not $x26) (or $x26 (and (distinct ?x170 ?x170) true)))))))))))))))
(check-sat)
; query 16: function main, block 68, name %69
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x63 (or false false)))
(and (not $x63) (or $x63 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 17: function main, block 68, name %70
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x98 (ite (bvsle (_ bv65 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x63 (or false false)))
(let (($x235 (or $x63 false false)))
(let (($x125 (not $x235)))
(and $x125 (or $x235 (and (distinct ?x98 ?x98) true))))))))
(check-sat)
; query 18: function main, block 71, name %72
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x63 (or false false)))
(and (not $x63) (or $x63 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 19: function main, block 71, name %73
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x182 (ite (bvsge (_ bv70 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x63 (or false false)))
(let (($x235 (or $x63 false false)))
(let (($x125 (not $x235)))
(and $x125 (or $x235 (and (distinct ?x182 ?x182) true))))))))
(check-sat)
; query 20: function main, block 74, name %75
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x313 (or false false false)))
(let (($x23 (or $x313 (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x23) (or $x23 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvshl in.01_32 (_ bv4 32))) true))))))
(check-sat)
; query 21: function main, block 74, name %76
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x63 (or false false)))
(and (not $x63) (or $x63 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 22: function main, block 74, name %77
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x36 ((_ sign_extend 24) in57_8)))
(let ((?x198 (bvshl in.01_32 (_ bv4 32))))
(let ((?x32 (bvadd ?x198 ?x36)))
(let ((?x47 ((_ sign_extend 1) ?x32)))
(let (($x63 (or false false)))
(let (($x313 (or false false false)))
(let (($x23 (or $x313 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x74 (or $x23 $x63 (or (and (distinct (bvadd ((_ sign_extend 1) ?x198) ((_ sign_extend 1) ?x36)) ?x47) true)))))
(and (not $x74) (or $x74 (and (distinct ?x32 ?x32) true))))))))))))
(check-sat)
; query 23: function main, block 74, name %78
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x36 ((_ sign_extend 24) in57_8)))
(let ((?x198 (bvshl in.01_32 (_ bv4 32))))
(let ((?x32 (bvadd ?x198 ?x36)))
(let ((?x745 (bvsub ?x32 (_ bv65 32))))
(let ((?x132 ((_ sign_extend 1) ?x745)))
(let ((?x47 ((_ sign_extend 1) ?x32)))
(let (($x63 (or false false)))
(let (($x313 (or false false false)))
(let (($x23 (or $x313 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x74 (or $x23 $x63 (or (and (distinct (bvadd ((_ sign_extend 1) ?x198) ((_ sign_extend 1) ?x36)) ?x47) true)))))
(let (($x383 (or $x74 false (or (and (distinct (bvsub ?x47 ((_ sign_extend 1) (_ bv65 32))) ?x132) true)))))
(and (not $x383) (or $x383 (and (distinct ?x745 ?x745) true)))))))))))))))
(check-sat)
; query 24: function main, block 74, name %79
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x36 ((_ sign_extend 24) in57_8)))
(let ((?x198 (bvshl in.01_32 (_ bv4 32))))
(let ((?x32 (bvadd ?x198 ?x36)))
(let ((?x745 (bvsub ?x32 (_ bv65 32))))
(let ((?x190 (bvadd ?x745 (_ bv10 32))))
(let (($x379 (and (distinct (bvadd ((_ sign_extend 1) ?x745) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x190)) true)))
(let ((?x132 ((_ sign_extend 1) ?x745)))
(let ((?x47 ((_ sign_extend 1) ?x32)))
(let (($x63 (or false false)))
(let (($x313 (or false false false)))
(let (($x23 (or $x313 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x74 (or $x23 $x63 (or (and (distinct (bvadd ((_ sign_extend 1) ?x198) ((_ sign_extend 1) ?x36)) ?x47) true)))))
(let (($x383 (or $x74 false (or (and (distinct (bvsub ?x47 ((_ sign_extend 1) (_ bv65 32))) ?x132) true)))))
(let (($x217 (or $x383 false (or $x379))))
(and (not $x217) (or $x217 (and (distinct ?x190 ?x190) true))))))))))))))))))
(check-sat)
