; OptiPhase-Sigma refinement certificate for sweep K23-R3-113
; query 0: function kernel_nussinov, block 11, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x222 (and (distinct (bvsub ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvsub in.01_32 (_ bv1 32)))) true)))
(let (($x541 (or false false (or $x222))))
(and (not $x541) (or $x541 (and (distinct (bvsub in.01_32 (_ bv1 32)) (bvsub in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function kernel_nussinov, block 11, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x28 (ite (bvsle (_ bv0 32) (bvsub in.01_32 (_ bv1 32))) (_ bv1 1) (_ bv0 1))))
(let (($x222 (and (distinct (bvsub ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvsub in.01_32 (_ bv1 32)))) true)))
(let (($x541 (or false false (or $x222))))
(let (($x148 (or $x541 false false)))
(and (not $x148) (or $x148 (and (distinct ?x28 ?x28) true))))))))
(check-sat)
; query 2: function kernel_nussinov, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x386 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x49 (or false false (or $x386))))
(and (not $x49) (or $x49 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 3: function kernel_nussinov, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x113 (and (distinct (bvsub ((_ sign_extend 1) in0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvsub in0_32 (_ bv1 32)))) true)))
(let (($x21 (or false false (or $x113))))
(and (not $x21) (or $x21 (and (distinct (bvsub in0_32 (_ bv1 32)) (bvsub in0_32 (_ bv1 32))) true))))))
(check-sat)
