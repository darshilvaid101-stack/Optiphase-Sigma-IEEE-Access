; OptiPhase-Sigma refinement certificate for sweep K59-R3-264
; query 0: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x308 (or false false false)))
(let (($x280 (not $x308)))
(and $x280 (or $x308 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x21 (bvadd in.01_32 (_ bv1 32))))
(let ((?x66 (bvmul ?x21 ?x21)))
(let (($x308 (or false false false)))
(let (($x27 (or $x308 $x308 false)))
(and (not $x27) (or $x27 (and (distinct ?x66 ?x66) true))))))))
(check-sat)
; query 2: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x21 (bvadd in.01_32 (_ bv1 32))))
(let ((?x66 (bvmul ?x21 ?x21)))
(let ((?x127 (bvmul ?x66 (_ bv2 32))))
(let (($x308 (or false false false)))
(let (($x27 (or $x308 $x308 false)))
(let (($x429 (or $x27 false false)))
(and (not $x429) (or $x429 (and (distinct ?x127 ?x127) true))))))))))
(check-sat)
; query 3: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x21 (bvadd in.01_32 (_ bv1 32))))
(let ((?x66 (bvmul ?x21 ?x21)))
(let ((?x127 (bvmul ?x66 (_ bv2 32))))
(let ((?x23 (bvmul ?x127 (_ bv4 32))))
(let (($x308 (or false false false)))
(let (($x27 (or $x308 $x308 false)))
(let (($x429 (or $x27 false false)))
(let (($x72 (or $x429 false false)))
(and (not $x72) (or $x72 (and (distinct ?x23 ?x23) true))))))))))))
(check-sat)
; query 4: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x130 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x308 (or false false false)))
(let (($x280 (not $x308)))
(and $x280 (or $x308 (and (distinct ?x130 ?x130) true)))))))
(check-sat)
; query 5: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x435 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x308 (or false false false)))
(let (($x280 (not $x308)))
(and $x280 (or $x308 (and (distinct ?x435 ?x435) true)))))))
(check-sat)
; query 6: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x308 (or false false false)))
(let (($x280 (not $x308)))
(and $x280 (or $x308 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 7: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x604 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x398 (or false false (or $x604))))
(and (not $x398) (or $x398 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x501 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x308 (or false false false)))
(let (($x280 (not $x308)))
(and $x280 (or $x308 (and (distinct ?x501 ?x501) true)))))))
(check-sat)
; query 9: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x882 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x308 (or false false false)))
(let (($x280 (not $x308)))
(and $x280 (or $x308 (and (distinct ?x882 ?x882) true)))))))
(check-sat)
; query 10: function matrix_add_const, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x308 (or false false false)))
(let (($x280 (not $x308)))
(and $x280 (or $x308 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 11: function matrix_add_const, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x308 (or false false false)))
(let (($x280 (not $x308)))
(and $x280 (or $x308 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 12: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x484 (or false false)))
(and (not $x484) (or $x484 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true)))))
(check-sat)
; query 13: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x646 ((_ sign_extend 16) in.1_16)))
(let ((?x12 (bvadd ?x646 (_ bv10 32))))
(let (($x1462 (and (distinct (bvadd ((_ sign_extend 1) ?x646) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x12)) true)))
(let (($x484 (or false false)))
(let (($x1941 (or $x484 false (or $x1462))))
(and (not $x1941) (or $x1941 (and (distinct ?x12 ?x12) true)))))))))
(check-sat)
; query 14: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x646 ((_ sign_extend 16) in.1_16)))
(let ((?x12 (bvadd ?x646 (_ bv10 32))))
(let ((?x15 ((_ extract 15 0) ?x12)))
(let (($x1462 (and (distinct (bvadd ((_ sign_extend 1) ?x646) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x12)) true)))
(let (($x484 (or false false)))
(let (($x1941 (or $x484 false (or $x1462))))
(let (($x52 (or $x1941 false)))
(and (not $x52) (or $x52 (and (distinct ?x15 ?x15) true)))))))))))
(check-sat)
