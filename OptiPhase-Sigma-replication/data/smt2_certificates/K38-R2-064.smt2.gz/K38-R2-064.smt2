; OptiPhase-Sigma refinement certificate for sweep K38-R2-064
