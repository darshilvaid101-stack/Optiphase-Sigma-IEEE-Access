; OptiPhase-Sigma refinement certificate for sweep K26-R6-025
; query 0: function xmalloc, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in7_32 () (_ BitVec 32))
(assert
 (let ((?x66 (ite (and (distinct (_ bv0 32) in7_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x39 (or false false false)))
(and (not $x39) (or $x39 (and (distinct ?x66 ?x66) true))))))
(check-sat)
