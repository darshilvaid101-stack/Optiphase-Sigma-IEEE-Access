; OptiPhase-Sigma refinement certificate for sweep K52-R3-085
; query 0: function check, block 103, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x703 (ite (= (_ bv22 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x2369 (or false false false)))
(let (($x1362 (not $x2369)))
(and $x1362 (or $x2369 (and (distinct ?x703 (ite (= (_ bv0 32) in0_32) (_ bv1 1) (_ bv0 1))) true)))))))
(check-sat)
; query 1: function check, block 109, name %110
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x1309 (ite (= (_ bv33 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x2369 (or false false false)))
(let (($x1362 (not $x2369)))
(and $x1362 (or $x2369 (and (distinct ?x1309 (ite (= (_ bv12 32) in0_32) (_ bv1 1) (_ bv0 1))) true)))))))
(check-sat)
; query 2: function check, block 67, name %68
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x2366 (ite (= (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x2369 (or false false false)))
(let (($x1362 (not $x2369)))
(and $x1362 (or $x2369 (and (distinct (ite (= (_ bv1 32) in0_32) (_ bv1 1) (_ bv0 1)) ?x2366) true)))))))
(check-sat)
; query 3: function check, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x2662 (ite (= (_ bv4 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x2369 (or false false false)))
(let (($x1362 (not $x2369)))
(and $x1362 (or $x2369 (and (distinct (ite (= (_ bv2 32) in0_32) (_ bv1 1) (_ bv0 1)) ?x2662) true)))))))
(check-sat)
; query 4: function check, block 79, name %80
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x2660 (ite (= (_ bv5 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let ((?x2366 (ite (= (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x2369 (or false false false)))
(let (($x1362 (not $x2369)))
(and $x1362 (or $x2369 (and (distinct ?x2366 ?x2660) true))))))))
(check-sat)
; query 5: function check, block 85, name %86
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x1924 (ite (= (_ bv11 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let ((?x2662 (ite (= (_ bv4 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x2369 (or false false false)))
(let (($x1362 (not $x2369)))
(and $x1362 (or $x2369 (and (distinct ?x2662 ?x1924) true))))))))
(check-sat)
; query 6: function check, block 91, name %92
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x703 (ite (= (_ bv22 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let ((?x2660 (ite (= (_ bv5 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x2369 (or false false false)))
(let (($x1362 (not $x2369)))
(and $x1362 (or $x2369 (and (distinct ?x2660 ?x703) true))))))))
(check-sat)
; query 7: function check, block 97, name %98
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x1309 (ite (= (_ bv33 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let ((?x1924 (ite (= (_ bv11 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x2369 (or false false false)))
(let (($x1362 (not $x2369)))
(and $x1362 (or $x2369 (and (distinct ?x1924 ?x1309) true))))))))
(check-sat)
; query 8: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x169 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x2369 (or false false false)))
(let (($x1362 (not $x2369)))
(and $x1362 (or $x2369 (and (distinct ?x169 ?x169) true)))))))
(check-sat)
; query 9: function s162, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x40 (ite (bvslt (_ bv0 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x2369 (or false false false)))
(let (($x1362 (not $x2369)))
(and $x1362 (or $x2369 (and (distinct ?x40 ?x40) true)))))))
(check-sat)
; query 10: function set1d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x77 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x2369 (or false false false)))
(let (($x1362 (not $x2369)))
(and $x1362 (or $x2369 (and (distinct ?x77 ?x77) true)))))))
(check-sat)
; query 11: function set1ds, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x1607 (ite (= (_ bv4294967295 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x2369 (or false false false)))
(let (($x1362 (not $x2369)))
(and $x1362 (or $x2369 (and (distinct ?x1607 ?x1607) true)))))))
(check-sat)
; query 12: function set2d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x77 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x2369 (or false false false)))
(let (($x1362 (not $x2369)))
(and $x1362 (or $x2369 (and (distinct ?x77 ?x77) true)))))))
(check-sat)
