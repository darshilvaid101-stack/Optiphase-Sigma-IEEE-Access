; OptiPhase-Sigma refinement certificate for sweep K07-R6-012
