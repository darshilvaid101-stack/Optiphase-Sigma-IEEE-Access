; OptiPhase-Sigma refinement certificate for sweep K58-R3-219
; query 0: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x712 (or false false false)))
(let (($x127 (not $x712)))
(and $x127 (or $x712 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x4450 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x712 (or false false false)))
(let (($x127 (not $x712)))
(and $x127 (or $x712 (and (distinct ?x4450 ?x4450) true)))))))
(check-sat)
; query 2: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x3860 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x712 (or false false false)))
(let (($x127 (not $x712)))
(and $x127 (or $x712 (and (distinct ?x3860 ?x3860) true)))))))
(check-sat)
; query 3: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x712 (or false false false)))
(let (($x127 (not $x712)))
(and $x127 (or $x712 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 4: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x85 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x1899 (or false false (or $x85))))
(and (not $x1899) (or $x1899 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 5: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x94 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x712 (or false false false)))
(let (($x127 (not $x712)))
(and $x127 (or $x712 (and (distinct ?x94 ?x94) true)))))))
(check-sat)
; query 6: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x16 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x712 (or false false false)))
(let (($x127 (not $x712)))
(and $x127 (or $x712 (and (distinct ?x16 ?x16) true)))))))
(check-sat)
; query 7: function matrix_add_const, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x712 (or false false false)))
(let (($x127 (not $x712)))
(and $x127 (or $x712 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function matrix_add_const, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x712 (or false false false)))
(let (($x127 (not $x712)))
(and $x127 (or $x712 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 9: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x324 (or false false)))
(and (not $x324) (or $x324 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true)))))
(check-sat)
; query 10: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x616 ((_ sign_extend 16) in.1_16)))
(let ((?x101 (bvadd ?x616 (_ bv10 32))))
(let (($x95 (and (distinct (bvadd ((_ sign_extend 1) ?x616) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x101)) true)))
(let (($x324 (or false false)))
(let (($x462 (or $x324 false (or $x95))))
(and (not $x462) (or $x462 (and (distinct ?x101 ?x101) true)))))))))
(check-sat)
; query 11: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x616 ((_ sign_extend 16) in.1_16)))
(let ((?x101 (bvadd ?x616 (_ bv10 32))))
(let ((?x331 ((_ extract 15 0) ?x101)))
(let (($x95 (and (distinct (bvadd ((_ sign_extend 1) ?x616) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x101)) true)))
(let (($x324 (or false false)))
(let (($x462 (or $x324 false (or $x95))))
(let (($x1926 (or $x462 false)))
(and (not $x1926) (or $x1926 (and (distinct ?x331 ?x331) true)))))))))))
(check-sat)
; query 12: function run_crc_loop, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x712 (or false false false)))
(let (($x127 (not $x712)))
(and $x127 (or $x712 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
