; OptiPhase-Sigma refinement certificate for sweep K23-R1-001
