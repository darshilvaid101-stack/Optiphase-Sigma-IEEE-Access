; OptiPhase-Sigma refinement certificate for sweep K42-R3-117
