; OptiPhase-Sigma refinement certificate for sweep K48-R6-015
; query 0: function Decoding_of_the_coded_Log_Area_Ratios, block 107, name %108
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in104_64 () (_ BitVec 64))
(assert
 (let ((?x1679 (ite (bvslt (_ bv0 64) in104_64) (_ bv1 1) (_ bv0 1))))
(let (($x676 (or false false false)))
(let (($x507 (not $x676)))
(and $x507 (or $x676 (and (distinct ?x1679 ?x1679) true)))))))
(check-sat)
; query 1: function Decoding_of_the_coded_Log_Area_Ratios, block 107, name %109
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in104_64 () (_ BitVec 64))
(assert
 (let (($x605 (and (distinct ((_ zero_extend 63) (ite (bvslt (_ bv0 64) in104_64) (_ bv1 1) (_ bv0 1))) (ite (= (_ bv1 1) (ite (bvslt (_ bv0 64) in104_64) (_ bv1 1) (_ bv0 1))) (_ bv32767 64) (_ bv18446744073709518848 64))) true)))
(let (($x676 (or false false false)))
(let (($x616 (or $x676 (ite (= (_ bv1 1) (ite (bvslt (_ bv0 64) in104_64) (_ bv1 1) (_ bv0 1))) false false))))
(and (not (or $x676 false)) (or $x616 $x605))))))
(check-sat)
; query 2: function Decoding_of_the_coded_Log_Area_Ratios, block 219, name %220
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in216_64 () (_ BitVec 64))
(assert
 (let (($x65 (and (distinct (ite (bvsge (_ bv18446744073709518848 64) in216_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv0 64) in216_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x676 (or false false false)))
(let (($x507 (not $x676)))
(and $x507 (or $x676 $x65))))))
(check-sat)
; query 3: function gsm_L_add, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let (($x16 (and (distinct (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv18446744073709551615 64) in1_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x676 (or false false false)))
(let (($x507 (not $x676)))
(and $x507 (or $x676 $x16))))))
(check-sat)
; query 4: function gsm_L_add, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x101 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvadd in0_64 in1_64))) true)))
(let (($x72 (or false false (or $x101))))
(let (($x92 (or $x72 (and (distinct (bvadd in0_64 in1_64) (bvadd in0_64 in1_64)) true))))
(and (not $x72) $x92)))))
(check-sat)
; query 5: function gsm_L_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x448 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x676 (or false false false)))
(let (($x507 (not $x676)))
(and $x507 (or $x676 (and (distinct ?x448 ?x448) true)))))))
(check-sat)
; query 6: function gsm_L_asl, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x96 (and (distinct (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvsgt (_ bv4294967265 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x676 (or false false false)))
(let (($x507 (not $x676)))
(and $x507 (or $x676 $x96))))))
(check-sat)
; query 7: function gsm_L_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x85 (and (distinct (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv31 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x676 (or false false false)))
(let (($x507 (not $x676)))
(and $x507 (or $x676 $x85))))))
(check-sat)
; query 8: function gsm_L_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x85 (and (distinct (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv31 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x676 (or false false false)))
(let (($x507 (not $x676)))
(and $x507 (or $x676 $x85))))))
(check-sat)
; query 9: function gsm_L_sub, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x202 (bvsub in0_64 in1_64)))
(let (($x24 (and (distinct ?x202 ?x202) true)))
(let (($x18 (and (distinct (bvsub ((_ zero_extend 1) in0_64) ((_ zero_extend 1) in1_64)) ((_ zero_extend 1) ?x202)) true)))
(let (($x418 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) ?x202)) true)))
(let (($x159 (or false false (or $x418))))
(let (($x113 (not $x159)))
(and $x113 (or (or false false (or $x18)) $x24)))))))))
(check-sat)
; query 10: function gsm_L_sub, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let (($x16 (and (distinct (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv18446744073709551615 64) in1_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x676 (or false false false)))
(let (($x507 (not $x676)))
(and $x507 (or $x676 $x16))))))
(check-sat)
; query 11: function gsm_L_sub, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x202 (bvsub in0_64 in1_64)))
(let (($x24 (and (distinct ?x202 ?x202) true)))
(let (($x418 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) ?x202)) true)))
(let (($x159 (or false false (or $x418))))
(let (($x113 (not $x159)))
(and $x113 (or $x159 $x24))))))))
(check-sat)
; query 12: function gsm_L_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x582 (and (distinct (ite (bvsle (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv18446744073709551615 64) in0_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x676 (or false false false)))
(let (($x507 (not $x676)))
(and $x507 (or $x676 $x582))))))
(check-sat)
; query 13: function gsm_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_64 () (_ BitVec 64))
(assert
 (let ((?x12 (ite (bvslt (_ bv32767 64) in5_64) (_ bv1 1) (_ bv0 1))))
(let (($x676 (or false false false)))
(let (($x507 (not $x676)))
(and $x507 (or $x676 (and (distinct ?x12 ?x12) true)))))))
(check-sat)
; query 14: function gsm_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x94 (or false false)))
(let (($x167 (not $x94)))
(and $x167 (or $x94 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 15: function gsm_add, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x94 (or false false)))
(let (($x167 (not $x94)))
(and $x167 (or $x94 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 16: function gsm_add, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x76 ((_ sign_extend 48) in1_16)))
(let ((?x43 ((_ sign_extend 48) in0_16)))
(let ((?x229 (bvadd ?x43 ?x76)))
(let (($x66 (and (distinct (bvadd ((_ sign_extend 1) ?x43) ((_ sign_extend 1) ?x76)) ((_ sign_extend 1) ?x229)) true)))
(let (($x94 (or false false)))
(let (($x34 (or $x94 $x94 (or $x66))))
(and (not $x34) (or $x34 (and (distinct ?x229 ?x229) true))))))))))
(check-sat)
; query 17: function gsm_add, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x335 (ite (bvsgt (_ bv18446744073709518848 64) (bvadd ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x76 ((_ sign_extend 48) in1_16)))
(let ((?x21 ((_ sign_extend 1) ?x76)))
(let ((?x43 ((_ sign_extend 48) in0_16)))
(let ((?x31 ((_ sign_extend 1) ?x43)))
(let (($x94 (or false false)))
(let (($x34 (or $x94 $x94 (or (and (distinct (bvadd ?x31 ?x21) ((_ sign_extend 1) (bvadd ?x43 ?x76))) true)))))
(let (($x47 (or $x34 false false)))
(and (not $x47) (or $x47 (and (distinct ?x335 ?x335) true))))))))))))
(check-sat)
; query 18: function gsm_asl, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x54 (and (distinct (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvsgt (_ bv4294967281 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x676 (or false false false)))
(let (($x507 (not $x676)))
(and $x507 (or $x676 $x54))))))
(check-sat)
; query 19: function gsm_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x27 (and (distinct (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv15 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x676 (or false false false)))
(let (($x507 (not $x676)))
(and $x507 (or $x676 $x27))))))
(check-sat)
; query 20: function gsm_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x27 (and (distinct (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv15 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x676 (or false false false)))
(let (($x507 (not $x676)))
(and $x507 (or $x676 $x27))))))
(check-sat)
; query 21: function gsm_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_64 () (_ BitVec 64))
(assert
 (let ((?x12 (ite (bvslt (_ bv32767 64) in5_64) (_ bv1 1) (_ bv0 1))))
(let (($x676 (or false false false)))
(let (($x507 (not $x676)))
(and $x507 (or $x676 (and (distinct ?x12 ?x12) true)))))))
(check-sat)
; query 22: function gsm_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x94 (or false false)))
(let (($x167 (not $x94)))
(and $x167 (or $x94 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 23: function gsm_sub, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x94 (or false false)))
(let (($x167 (not $x94)))
(and $x167 (or $x94 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 24: function gsm_sub, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x76 ((_ sign_extend 48) in1_16)))
(let ((?x43 ((_ sign_extend 48) in0_16)))
(let ((?x559 (bvsub ?x43 ?x76)))
(let (($x370 (and (distinct (bvsub ((_ sign_extend 1) ?x43) ((_ sign_extend 1) ?x76)) ((_ sign_extend 1) ?x559)) true)))
(let (($x94 (or false false)))
(let (($x60 (or $x94 $x94 (or $x370))))
(and (not $x60) (or $x60 (and (distinct ?x559 ?x559) true))))))))))
(check-sat)
; query 25: function gsm_sub, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x157 (ite (bvsgt (_ bv18446744073709518848 64) (bvsub ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x76 ((_ sign_extend 48) in1_16)))
(let ((?x21 ((_ sign_extend 1) ?x76)))
(let ((?x43 ((_ sign_extend 48) in0_16)))
(let ((?x31 ((_ sign_extend 1) ?x43)))
(let (($x94 (or false false)))
(let (($x60 (or $x94 $x94 (or (and (distinct (bvsub ?x31 ?x21) ((_ sign_extend 1) (bvsub ?x43 ?x76))) true)))))
(let (($x141 (or $x60 false false)))
(and (not $x141) (or $x141 (and (distinct ?x157 ?x157) true))))))))))))
(check-sat)
