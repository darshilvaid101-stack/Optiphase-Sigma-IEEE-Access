; OptiPhase-Sigma refinement certificate for sweep K45-R4-365
; query 0: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x53 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x14 (or false false false)))
(let (($x249 (not $x14)))
(and $x249 (or $x14 (and (distinct ?x53 ?x53) true)))))))
(check-sat)
; query 1: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x1498 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x14 (or false false false)))
(let (($x249 (not $x14)))
(and $x249 (or $x14 (and (distinct ?x1498 ?x1498) true)))))))
(check-sat)
