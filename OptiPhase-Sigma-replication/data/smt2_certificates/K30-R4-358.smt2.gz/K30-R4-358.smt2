; OptiPhase-Sigma refinement certificate for sweep K30-R4-358
; query 0: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x590 (ite (bvsgt (_ bv2 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x674 (or false false false)))
(and (not $x674) (or $x674 (and (distinct ?x590 ?x590) true))))))
(check-sat)
