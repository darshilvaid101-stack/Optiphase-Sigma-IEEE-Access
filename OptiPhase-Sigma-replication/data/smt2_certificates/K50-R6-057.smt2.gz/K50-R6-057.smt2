; OptiPhase-Sigma refinement certificate for sweep K50-R6-057
