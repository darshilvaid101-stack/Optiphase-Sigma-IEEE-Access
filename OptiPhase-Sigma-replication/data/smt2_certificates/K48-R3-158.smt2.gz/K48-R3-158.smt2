; OptiPhase-Sigma refinement certificate for sweep K48-R3-158
; query 0: function APCM_inverse_quantization, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x326 (or false false)))
(let (($x776 (not $x326)))
(and $x776 (or $x326 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 1: function APCM_inverse_quantization, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x51 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x326 (or false false)))
(let (($x161 (or $x326 false false)))
(let (($x68 (not $x161)))
(and $x68 (or $x161 (and (distinct ?x51 ?x51) true))))))))
(check-sat)
; query 2: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x326 (or false false)))
(let (($x776 (not $x326)))
(and $x776 (or $x326 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 3: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x428 (ite (bvslt (_ bv15 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x326 (or false false)))
(let (($x161 (or $x326 false false)))
(let (($x68 (not $x161)))
(and $x68 (or $x161 (and (distinct ?x428 ?x428) true))))))))
(check-sat)
; query 4: function Decoding_of_the_coded_Log_Area_Ratios, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in6_64 () (_ BitVec 64))
(assert
 (let ((?x274 (ite (bvslt (_ bv0 64) in6_64) (_ bv1 1) (_ bv0 1))))
(let (($x136 (or false false false)))
(let (($x642 (not $x136)))
(and $x642 (or $x136 (and (distinct ?x274 ?x274) true)))))))
(check-sat)
; query 5: function Decoding_of_the_coded_Log_Area_Ratios, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in6_64 () (_ BitVec 64))
(assert
 (let ((?x274 (ite (bvslt (_ bv0 64) in6_64) (_ bv1 1) (_ bv0 1))))
(let ((?x245 ((_ zero_extend 63) ?x274)))
(let (($x136 (or false false false)))
(let (($x411 (or $x136 false)))
(let (($x269 (not $x411)))
(and $x269 (or $x411 (and (distinct ?x245 ?x245) true)))))))))
(check-sat)
; query 6: function Decoding_of_the_coded_Log_Area_Ratios, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in6_64 () (_ BitVec 64))
(assert
 (let ((?x274 (ite (bvslt (_ bv0 64) in6_64) (_ bv1 1) (_ bv0 1))))
(let (($x422 (= (_ bv1 1) ?x274)))
(let ((?x5 (ite $x422 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x136 (or false false false)))
(let (($x76 (or $x136 (ite $x422 false false))))
(and (not $x76) (or $x76 (and (distinct ?x5 ?x5) true)))))))))
(check-sat)
; query 7: function Decoding_of_the_coded_Log_Area_Ratios, block 9, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in6_64 () (_ BitVec 64))
(assert
 (let ((?x274 (ite (bvslt (_ bv0 64) in6_64) (_ bv1 1) (_ bv0 1))))
(let (($x422 (= (_ bv1 1) ?x274)))
(let ((?x5 (ite $x422 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x24 ((_ sign_extend 32) ?x5)))
(let (($x136 (or false false false)))
(let (($x76 (or $x136 (ite $x422 false false))))
(let (($x6 (or $x76 false)))
(and (not $x6) (or $x6 (and (distinct ?x24 ?x24) true)))))))))))
(check-sat)
; query 8: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x326 (or false false)))
(let (($x776 (not $x326)))
(and $x776 (or $x326 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 9: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x626 (ite (bvsgt (_ bv40 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x326 (or false false)))
(let (($x161 (or $x326 false false)))
(let (($x68 (not $x161)))
(and $x68 (or $x161 (and (distinct ?x626 ?x626) true))))))))
(check-sat)
; query 10: function Quantization_and_coding, block 11, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in8_64 () (_ BitVec 64))
(assert
 (let ((?x126 (ite (bvslt (_ bv0 64) in8_64) (_ bv1 1) (_ bv0 1))))
(let (($x136 (or false false false)))
(let (($x642 (not $x136)))
(and $x642 (or $x136 (and (distinct ?x126 ?x126) true)))))))
(check-sat)
; query 11: function Quantization_and_coding, block 11, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in8_64 () (_ BitVec 64))
(assert
 (let ((?x126 (ite (bvslt (_ bv0 64) in8_64) (_ bv1 1) (_ bv0 1))))
(let ((?x216 ((_ zero_extend 63) ?x126)))
(let (($x136 (or false false false)))
(let (($x411 (or $x136 false)))
(let (($x269 (not $x411)))
(and $x269 (or $x411 (and (distinct ?x216 ?x216) true)))))))))
(check-sat)
; query 12: function Quantization_and_coding, block 11, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in8_64 () (_ BitVec 64))
(assert
 (let ((?x126 (ite (bvslt (_ bv0 64) in8_64) (_ bv1 1) (_ bv0 1))))
(let (($x514 (= (_ bv1 1) ?x126)))
(let ((?x106 (ite $x514 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x136 (or false false false)))
(let (($x375 (or $x136 (ite $x514 false false))))
(and (not $x375) (or $x375 (and (distinct ?x106 ?x106) true)))))))))
(check-sat)
; query 13: function Quantization_and_coding, block 11, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in8_64 () (_ BitVec 64))
(assert
 (let ((?x126 (ite (bvslt (_ bv0 64) in8_64) (_ bv1 1) (_ bv0 1))))
(let (($x514 (= (_ bv1 1) ?x126)))
(let ((?x106 (ite $x514 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x294 ((_ sign_extend 32) ?x106)))
(let (($x136 (or false false false)))
(let (($x375 (or $x136 (ite $x514 false false))))
(let (($x31 (or $x375 false)))
(and (not $x31) (or $x31 (and (distinct ?x294 ?x294) true)))))))))))
(check-sat)
; query 14: function Quantization_and_coding, block 111, name %112
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in108_64 () (_ BitVec 64))
(assert
 (let ((?x176 (ite (bvslt (_ bv0 64) in108_64) (_ bv1 1) (_ bv0 1))))
(let (($x136 (or false false false)))
(let (($x642 (not $x136)))
(and $x642 (or $x136 (and (distinct ?x176 ?x176) true)))))))
(check-sat)
; query 15: function Quantization_and_coding, block 111, name %113
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in108_64 () (_ BitVec 64))
(assert
 (let ((?x176 (ite (bvslt (_ bv0 64) in108_64) (_ bv1 1) (_ bv0 1))))
(let ((?x454 ((_ zero_extend 63) ?x176)))
(let (($x136 (or false false false)))
(let (($x411 (or $x136 false)))
(let (($x269 (not $x411)))
(and $x269 (or $x411 (and (distinct ?x454 ?x454) true)))))))))
(check-sat)
; query 16: function Quantization_and_coding, block 111, name %114
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in108_64 () (_ BitVec 64))
(assert
 (let ((?x176 (ite (bvslt (_ bv0 64) in108_64) (_ bv1 1) (_ bv0 1))))
(let (($x271 (= (_ bv1 1) ?x176)))
(let ((?x291 (ite $x271 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x136 (or false false false)))
(let (($x301 (or $x136 (ite $x271 false false))))
(and (not $x301) (or $x301 (and (distinct ?x291 ?x291) true)))))))))
(check-sat)
; query 17: function Quantization_and_coding, block 111, name %115
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in108_64 () (_ BitVec 64))
(assert
 (let ((?x176 (ite (bvslt (_ bv0 64) in108_64) (_ bv1 1) (_ bv0 1))))
(let (($x271 (= (_ bv1 1) ?x176)))
(let ((?x291 (ite $x271 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x140 ((_ sign_extend 32) ?x291)))
(let (($x136 (or false false false)))
(let (($x301 (or $x136 (ite $x271 false false))))
(let (($x65 (or $x301 false)))
(and (not $x65) (or $x65 (and (distinct ?x140 ?x140) true)))))))))))
(check-sat)
; query 18: function RPE_grid_positioning, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x326 (or false false)))
(let (($x776 (not $x326)))
(and $x776 (or $x326 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 19: function RPE_grid_positioning, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x62 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x125 (and (distinct ?x62 ?x62) true)))
(let (($x326 (or false false)))
(let (($x119 (or false $x326 false)))
(and (not $x119) (or $x119 $x125)))))))
(check-sat)
; query 20: function gsm_L_add, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x34 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x136 (or false false false)))
(let (($x642 (not $x136)))
(and $x642 (or $x136 (and (distinct ?x34 ?x34) true)))))))
(check-sat)
; query 21: function gsm_L_add, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x43 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvadd in0_64 in1_64))) true)))
(let (($x71 (or false false (or $x43))))
(let (($x15 (or $x71 (and (distinct (bvadd in0_64 in1_64) (bvadd in0_64 in1_64)) true))))
(and (not $x71) $x15)))))
(check-sat)
; query 22: function gsm_L_add, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x85 (bvadd in0_64 (_ bv1 64))))
(let ((?x79 (bvsub (_ bv0 64) ?x85)))
(let (($x103 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x85)) ((_ sign_extend 1) ?x79)) true)))
(let ((?x343 ((_ sign_extend 1) ?x85)))
(let (($x17 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x343) true)))))
(let (($x53 (or false $x17 (or $x103))))
(and (not $x53) (or $x53 (and (distinct ?x79 ?x79) true))))))))))
(check-sat)
; query 23: function gsm_L_add, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x449 (bvadd in1_64 (_ bv1 64))))
(let ((?x98 ((_ sign_extend 1) ?x449)))
(let (($x584 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x98) true)))))
(and (not $x584) (or $x584 (and (distinct ?x449 ?x449) true)))))))
(check-sat)
; query 24: function gsm_L_add, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x449 (bvadd in1_64 (_ bv1 64))))
(let ((?x590 (bvsub (_ bv0 64) ?x449)))
(let (($x649 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x449)) ((_ sign_extend 1) ?x590)) true)))
(let ((?x98 ((_ sign_extend 1) ?x449)))
(let (($x584 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x98) true)))))
(let (($x74 (or false $x584 (or $x649))))
(and (not $x74) (or $x74 (and (distinct ?x590 ?x590) true))))))))))
(check-sat)
; query 25: function gsm_L_add, block 8, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x449 (bvadd in1_64 (_ bv1 64))))
(let ((?x590 (bvsub (_ bv0 64) ?x449)))
(let ((?x85 (bvadd in0_64 (_ bv1 64))))
(let ((?x79 (bvsub (_ bv0 64) ?x85)))
(let ((?x661 (bvadd ?x79 ?x590)))
(let (($x649 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x449)) ((_ sign_extend 1) ?x590)) true)))
(let ((?x98 ((_ sign_extend 1) ?x449)))
(let (($x584 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x98) true)))))
(let (($x74 (or false $x584 (or $x649))))
(let (($x103 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x85)) ((_ sign_extend 1) ?x79)) true)))
(let ((?x343 ((_ sign_extend 1) ?x85)))
(let (($x17 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x343) true)))))
(let (($x53 (or false $x17 (or $x103))))
(let (($x612 (or $x53 $x74 false)))
(and (not $x612) (or $x612 (and (distinct ?x661 ?x661) true))))))))))))))))))
(check-sat)
; query 26: function gsm_L_add, block 8, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x449 (bvadd in1_64 (_ bv1 64))))
(let ((?x590 (bvsub (_ bv0 64) ?x449)))
(let ((?x85 (bvadd in0_64 (_ bv1 64))))
(let ((?x79 (bvsub (_ bv0 64) ?x85)))
(let ((?x661 (bvadd ?x79 ?x590)))
(let ((?x1924 (ite (bvuge ?x661 (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x649 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x449)) ((_ sign_extend 1) ?x590)) true)))
(let ((?x98 ((_ sign_extend 1) ?x449)))
(let (($x584 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x98) true)))))
(let (($x74 (or false $x584 (or $x649))))
(let (($x103 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x85)) ((_ sign_extend 1) ?x79)) true)))
(let ((?x343 ((_ sign_extend 1) ?x85)))
(let (($x17 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x343) true)))))
(let (($x53 (or false $x17 (or $x103))))
(let (($x612 (or $x53 $x74 false)))
(let (($x1934 (or $x612 false false)))
(and (not $x1934) (or $x1934 (and (distinct ?x1924 ?x1924) true))))))))))))))))))))
(check-sat)
; query 27: function gsm_L_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x85 (bvadd in0_64 (_ bv1 64))))
(let ((?x343 ((_ sign_extend 1) ?x85)))
(let (($x17 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x343) true)))))
(and (not $x17) (or $x17 (and (distinct ?x85 ?x85) true)))))))
(check-sat)
; query 28: function gsm_L_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1764 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x136 (or false false false)))
(let (($x642 (not $x136)))
(and $x642 (or $x136 (and (distinct ?x1764 ?x1764) true)))))))
(check-sat)
; query 29: function gsm_L_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1904 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x136 (or false false false)))
(let (($x642 (not $x136)))
(and $x642 (or $x136 (and (distinct ?x1904 ?x1904) true)))))))
(check-sat)
; query 30: function gsm_L_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1764 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x136 (or false false false)))
(let (($x642 (not $x136)))
(and $x642 (or $x136 (and (distinct ?x1764 ?x1764) true)))))))
(check-sat)
; query 31: function gsm_L_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1764 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1834 ((_ zero_extend 31) ?x1764)))
(let (($x136 (or false false false)))
(let (($x411 (or $x136 false)))
(let (($x269 (not $x411)))
(and $x269 (or $x411 (and (distinct ?x1834 ?x1834) true)))))))))
(check-sat)
; query 32: function gsm_L_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1764 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1834 ((_ zero_extend 31) ?x1764)))
(let ((?x1774 (bvsub (_ bv0 32) ?x1834)))
(let (($x1734 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1834)) ((_ sign_extend 1) ?x1774)) true)))
(let (($x136 (or false false false)))
(let (($x411 (or $x136 false)))
(let (($x1656 (or false $x411 (or $x1734))))
(and (not $x1656) (or $x1656 (and (distinct ?x1774 ?x1774) true)))))))))))
(check-sat)
; query 33: function gsm_L_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1764 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1834 ((_ zero_extend 31) ?x1764)))
(let ((?x1774 (bvsub (_ bv0 32) ?x1834)))
(let ((?x1652 ((_ sign_extend 32) ?x1774)))
(let (($x1734 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1834)) ((_ sign_extend 1) ?x1774)) true)))
(let (($x136 (or false false false)))
(let (($x411 (or $x136 false)))
(let (($x1656 (or false $x411 (or $x1734))))
(let (($x1653 (or $x1656 false)))
(and (not $x1653) (or $x1653 (and (distinct ?x1652 ?x1652) true)))))))))))))
(check-sat)
; query 34: function gsm_L_asr, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x408 (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x136 (or false false false)))
(let (($x642 (not $x136)))
(and $x642 (or $x136 (and (distinct ?x408 ?x408) true)))))))
(check-sat)
; query 35: function gsm_L_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1904 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x136 (or false false false)))
(let (($x642 (not $x136)))
(and $x642 (or $x136 (and (distinct ?x1904 ?x1904) true)))))))
(check-sat)
; query 36: function gsm_L_sub, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x34 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x136 (or false false false)))
(let (($x642 (not $x136)))
(and $x642 (or $x136 (and (distinct ?x34 ?x34) true)))))))
(check-sat)
; query 37: function gsm_L_sub, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x1680 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvsub in0_64 in1_64))) true)))
(let (($x382 (or false false (or $x1680))))
(let (($x1681 (or $x382 (and (distinct (bvsub in0_64 in1_64) (bvsub in0_64 in1_64)) true))))
(and (not $x382) $x1681)))))
(check-sat)
; query 38: function gsm_L_sub, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x449 (bvadd in1_64 (_ bv1 64))))
(let ((?x590 (bvsub (_ bv0 64) ?x449)))
(let (($x649 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x449)) ((_ sign_extend 1) ?x590)) true)))
(let ((?x98 ((_ sign_extend 1) ?x449)))
(let (($x584 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x98) true)))))
(let (($x74 (or false $x584 (or $x649))))
(and (not $x74) (or $x74 (and (distinct ?x590 ?x590) true))))))))))
(check-sat)
; query 39: function gsm_L_sub, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x449 (bvadd in1_64 (_ bv1 64))))
(let ((?x590 (bvsub (_ bv0 64) ?x449)))
(let ((?x1689 (bvadd in0_64 ?x590)))
(let (($x649 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x449)) ((_ sign_extend 1) ?x590)) true)))
(let ((?x98 ((_ sign_extend 1) ?x449)))
(let (($x584 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x98) true)))))
(let (($x74 (or false $x584 (or $x649))))
(let (($x1690 (or false $x74 false)))
(and (not $x1690) (or $x1690 (and (distinct ?x1689 ?x1689) true))))))))))))
(check-sat)
; query 40: function gsm_L_sub, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x390 (ite (bvuge (bvadd in0_64 (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64)))) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x649 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) (bvadd in1_64 (_ bv1 64)))) ((_ sign_extend 1) (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64))))) true)))
(let ((?x449 (bvadd in1_64 (_ bv1 64))))
(let ((?x98 ((_ sign_extend 1) ?x449)))
(let (($x584 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x98) true)))))
(let (($x74 (or false $x584 (or $x649))))
(let (($x1690 (or false $x74 false)))
(let (($x1698 (or $x1690 false false)))
(and (not $x1698) (or $x1698 (and (distinct ?x390 ?x390) true))))))))))))
(check-sat)
; query 41: function gsm_L_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x449 (bvadd in1_64 (_ bv1 64))))
(let ((?x98 ((_ sign_extend 1) ?x449)))
(let (($x584 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x98) true)))))
(and (not $x584) (or $x584 (and (distinct ?x449 ?x449) true)))))))
(check-sat)
; query 42: function gsm_L_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1696 (ite (bvsle (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x136 (or false false false)))
(let (($x642 (not $x136)))
(and $x642 (or $x136 (and (distinct ?x1696 ?x1696) true)))))))
(check-sat)
; query 43: function gsm_abs, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x326 (or false false)))
(let (($x776 (not $x326)))
(and $x776 (or $x326 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 44: function gsm_abs, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1710 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x326 (or false false)))
(let (($x161 (or $x326 false false)))
(let (($x68 (not $x161)))
(and $x68 (or $x161 (and (distinct ?x1710 ?x1710) true))))))))
(check-sat)
; query 45: function gsm_abs, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x326 (or false false)))
(let (($x776 (not $x326)))
(and $x776 (or $x326 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 46: function gsm_abs, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1715 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x326 (or false false)))
(let (($x161 (or $x326 false false)))
(let (($x68 (not $x161)))
(and $x68 (or $x161 (and (distinct ?x1715 ?x1715) true))))))))
(check-sat)
; query 47: function gsm_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x326 (or false false)))
(let (($x776 (not $x326)))
(and $x776 (or $x326 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 48: function gsm_add, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x326 (or false false)))
(let (($x776 (not $x326)))
(and $x776 (or $x326 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 49: function gsm_add, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1716 ((_ sign_extend 48) in1_16)))
(let ((?x1718 ((_ sign_extend 48) in0_16)))
(let ((?x1728 (bvadd ?x1718 ?x1716)))
(let (($x1722 (and (distinct (bvadd ((_ sign_extend 1) ?x1718) ((_ sign_extend 1) ?x1716)) ((_ sign_extend 1) ?x1728)) true)))
(let (($x326 (or false false)))
(let (($x1730 (or $x326 $x326 (or $x1722))))
(and (not $x1730) (or $x1730 (and (distinct ?x1728 ?x1728) true))))))))))
(check-sat)
; query 50: function gsm_add, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1735 (ite (bvsgt (_ bv18446744073709518848 64) (bvadd ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x1716 ((_ sign_extend 48) in1_16)))
(let ((?x1712 ((_ sign_extend 1) ?x1716)))
(let ((?x1718 ((_ sign_extend 48) in0_16)))
(let ((?x1711 ((_ sign_extend 1) ?x1718)))
(let (($x326 (or false false)))
(let (($x1730 (or $x326 $x326 (or (and (distinct (bvadd ?x1711 ?x1712) ((_ sign_extend 1) (bvadd ?x1718 ?x1716))) true)))))
(let (($x260 (or $x1730 false false)))
(and (not $x260) (or $x260 (and (distinct ?x1735 ?x1735) true))))))))))))
(check-sat)
; query 51: function gsm_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1731 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x136 (or false false false)))
(let (($x642 (not $x136)))
(and $x642 (or $x136 (and (distinct ?x1731 ?x1731) true)))))))
(check-sat)
; query 52: function gsm_asr, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1747 (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x136 (or false false false)))
(let (($x642 (not $x136)))
(and $x642 (or $x136 (and (distinct ?x1747 ?x1747) true)))))))
(check-sat)
; query 53: function gsm_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x326 (or false false)))
(let (($x776 (not $x326)))
(and $x776 (or $x326 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 54: function gsm_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1715 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x326 (or false false)))
(let (($x161 (or $x326 false false)))
(let (($x68 (not $x161)))
(and $x68 (or $x161 (and (distinct ?x1715 ?x1715) true))))))))
(check-sat)
; query 55: function gsm_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1715 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1749 ((_ zero_extend 31) ?x1715)))
(let (($x326 (or false false)))
(let (($x161 (or $x326 false false)))
(let (($x1766 (or $x161 false)))
(and (not $x1766) (or $x1766 (and (distinct ?x1749 ?x1749) true)))))))))
(check-sat)
; query 56: function gsm_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1715 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1749 ((_ zero_extend 31) ?x1715)))
(let ((?x1770 (bvsub (_ bv0 32) ?x1749)))
(let (($x1777 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1749)) ((_ sign_extend 1) ?x1770)) true)))
(let (($x326 (or false false)))
(let (($x161 (or $x326 false false)))
(let (($x1766 (or $x161 false)))
(let (($x857 (or false $x1766 (or $x1777))))
(and (not $x857) (or $x857 (and (distinct ?x1770 ?x1770) true))))))))))))
(check-sat)
; query 57: function gsm_asr, block 4, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1715 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1749 ((_ zero_extend 31) ?x1715)))
(let ((?x1770 (bvsub (_ bv0 32) ?x1749)))
(let ((?x1775 ((_ extract 15 0) ?x1770)))
(let (($x1777 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1749)) ((_ sign_extend 1) ?x1770)) true)))
(let (($x326 (or false false)))
(let (($x161 (or $x326 false false)))
(let (($x1766 (or $x161 false)))
(let (($x857 (or false $x1766 (or $x1777))))
(let (($x1776 (or $x857 false)))
(and (not $x1776) (or $x1776 (and (distinct ?x1775 ?x1775) true))))))))))))))
(check-sat)
; query 58: function gsm_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1731 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x136 (or false false false)))
(let (($x642 (not $x136)))
(and $x642 (or $x136 (and (distinct ?x1731 ?x1731) true)))))))
(check-sat)
; query 59: function gsm_div, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x326 (or false false)))
(let (($x776 (not $x326)))
(and $x776 (or $x326 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 60: function gsm_div, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x326 (or false false)))
(let (($x776 (not $x326)))
(and $x776 (or $x326 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 61: function gsm_div, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x326 (or false false)))
(let (($x776 (not $x326)))
(and $x776 (or $x326 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 62: function gsm_div, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x62 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x125 (and (distinct ?x62 ?x62) true)))
(let (($x326 (or false false)))
(let (($x161 (or $x326 false false)))
(let (($x68 (not $x161)))
(and $x68 (or $x161 $x125))))))))
(check-sat)
; query 63: function gsm_norm, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1764 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x136 (or false false false)))
(let (($x642 (not $x136)))
(and $x642 (or $x136 (and (distinct ?x1764 (ite (bvsge (_ bv18446744072635809792 64) in0_64) (_ bv1 1) (_ bv0 1))) true)))))))
(check-sat)
; query 64: function gsm_norm, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1805 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x136 (or false false false)))
(let (($x642 (not $x136)))
(and $x642 (or $x136 (and (distinct ?x1805 ?x1805) true)))))))
(check-sat)
; query 65: function gsm_norm, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1805 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x1797 (bvxor ?x1805 (_ bv1 1))))
(let (($x136 (or false false false)))
(let (($x1801 (or $x136 false false)))
(and (not $x1801) (or $x1801 (and (distinct ?x1797 ?x1797) true))))))))
(check-sat)
; query 66: function gsm_norm, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1805 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x1797 (bvxor ?x1805 (_ bv1 1))))
(let ((?x1796 ((_ zero_extend 31) ?x1797)))
(let (($x136 (or false false false)))
(let (($x1801 (or $x136 false false)))
(let (($x1791 (or $x1801 false)))
(and (not $x1791) (or $x1791 (and (distinct ?x1796 ?x1796) true))))))))))
(check-sat)
; query 67: function gsm_norm, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1805 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x1797 (bvxor ?x1805 (_ bv1 1))))
(let ((?x1796 ((_ zero_extend 31) ?x1797)))
(let ((?x1792 ((_ sign_extend 32) ?x1796)))
(let (($x136 (or false false false)))
(let (($x1801 (or $x136 false false)))
(let (($x1791 (or $x1801 false)))
(let (($x1807 (or $x1791 false)))
(and (not $x1807) (or $x1807 (and (distinct ?x1792 ?x1792) true))))))))))))
(check-sat)
; query 68: function gsm_norm, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1805 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x1797 (bvxor ?x1805 (_ bv1 1))))
(let ((?x1796 ((_ zero_extend 31) ?x1797)))
(let ((?x1792 ((_ sign_extend 32) ?x1796)))
(let ((?x1810 (ite (and (distinct (_ bv0 64) ?x1792) true) (_ bv1 1) (_ bv0 1))))
(let (($x136 (or false false false)))
(let (($x1801 (or $x136 false false)))
(let (($x1791 (or $x1801 false)))
(let (($x1807 (or $x1791 false)))
(let (($x1806 (or $x1807 false false)))
(and (not $x1806) (or $x1806 (and (distinct ?x1810 ?x1810) true))))))))))))))
(check-sat)
; query 69: function gsm_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x326 (or false false)))
(let (($x776 (not $x326)))
(and $x776 (or $x326 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 70: function gsm_sub, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x326 (or false false)))
(let (($x776 (not $x326)))
(and $x776 (or $x326 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 71: function gsm_sub, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1716 ((_ sign_extend 48) in1_16)))
(let ((?x1718 ((_ sign_extend 48) in0_16)))
(let ((?x167 (bvsub ?x1718 ?x1716)))
(let (($x1835 (and (distinct (bvsub ((_ sign_extend 1) ?x1718) ((_ sign_extend 1) ?x1716)) ((_ sign_extend 1) ?x167)) true)))
(let (($x326 (or false false)))
(let (($x1832 (or $x326 $x326 (or $x1835))))
(and (not $x1832) (or $x1832 (and (distinct ?x167 ?x167) true))))))))))
(check-sat)
; query 72: function gsm_sub, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1847 (ite (bvsgt (_ bv18446744073709518848 64) (bvsub ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x1716 ((_ sign_extend 48) in1_16)))
(let ((?x1712 ((_ sign_extend 1) ?x1716)))
(let ((?x1718 ((_ sign_extend 48) in0_16)))
(let ((?x1711 ((_ sign_extend 1) ?x1718)))
(let (($x326 (or false false)))
(let (($x1832 (or $x326 $x326 (or (and (distinct (bvsub ?x1711 ?x1712) ((_ sign_extend 1) (bvsub ?x1718 ?x1716))) true)))))
(let (($x1840 (or $x1832 false false)))
(and (not $x1840) (or $x1840 (and (distinct ?x1847 ?x1847) true))))))))))))
(check-sat)
