; OptiPhase-Sigma refinement certificate for sweep K52-R3-278
; query 0: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x132 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x38 (or false false false)))
(let (($x295 (not $x38)))
(and $x295 (or $x38 (and (distinct ?x132 ?x132) true)))))))
(check-sat)
; query 1: function s162, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x96 (ite (bvslt (_ bv0 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x38 (or false false false)))
(let (($x295 (not $x38)))
(and $x295 (or $x38 (and (distinct ?x96 ?x96) true)))))))
(check-sat)
