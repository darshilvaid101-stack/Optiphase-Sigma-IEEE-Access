; OptiPhase-Sigma refinement certificate for sweep K33-R4-324
; query 0: function edge_draw, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let ((?x90 (ite (= (_ bv0 32) in4_32) (_ bv1 1) (_ bv0 1))))
(let (($x326 (or false false false)))
(and (not $x326) (or $x326 (and (distinct ?x90 ?x90) true))))))
(check-sat)
