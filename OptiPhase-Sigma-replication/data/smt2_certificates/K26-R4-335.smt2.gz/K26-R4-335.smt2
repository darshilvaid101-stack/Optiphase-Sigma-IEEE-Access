; OptiPhase-Sigma refinement certificate for sweep K26-R4-335
