; OptiPhase-Sigma refinement certificate for sweep K39-R2-026
; query 0: function BF_cfb64_encrypt, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.07_32 () (_ BitVec 32))
(assert
 (let ((?x149 (ite (= (_ bv0 32) in.07_32) (_ bv1 1) (_ bv0 1))))
(let (($x118 (or false false false)))
(and (not $x118) (or $x118 (and (distinct ?x149 ?x149) true))))))
(check-sat)
; query 1: function BF_set_key, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x286 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x427 (or false false (or $x286))))
(and (not $x427) (or $x427 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function BF_set_key, block 69, name %70
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.13_32 () (_ BitVec 32))
(assert
 (let (($x58 (and (distinct (bvadd ((_ sign_extend 1) in.13_32) ((_ sign_extend 1) (_ bv2 32))) ((_ sign_extend 1) (bvadd in.13_32 (_ bv2 32)))) true)))
(let (($x117 (or false false (or $x58))))
(and (not $x117) (or $x117 (and (distinct (bvadd in.13_32 (_ bv2 32)) (bvadd in.13_32 (_ bv2 32))) true))))))
(check-sat)
; query 3: function BF_set_key, block 87, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.24_32 () (_ BitVec 32))
(assert
 (let (($x285 (and (distinct (bvadd ((_ sign_extend 1) in.24_32) ((_ sign_extend 1) (_ bv2 32))) ((_ sign_extend 1) (bvadd in.24_32 (_ bv2 32)))) true)))
(let (($x268 (or false false (or $x285))))
(and (not $x268) (or $x268 (and (distinct (bvadd in.24_32 (_ bv2 32)) (bvadd in.24_32 (_ bv2 32))) true))))))
(check-sat)
; query 4: function main, block 60, name %61
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x296 (or false false)))
(let (($x499 (not $x296)))
(and $x499 (or $x296 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true))))))
(check-sat)
; query 5: function main, block 60, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x429 (ite (bvsge (_ bv57 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x296 (or false false)))
(let (($x49 (or $x296 false false)))
(let (($x23 (not $x49)))
(and $x23 (or $x49 (and (distinct ?x429 ?x429) true))))))))
(check-sat)
; query 6: function main, block 63, name %64
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x118 (or false false false)))
(let (($x381 (or $x118 (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x381) (or $x381 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvshl in.01_32 (_ bv4 32))) true))))))
(check-sat)
; query 7: function main, block 63, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x296 (or false false)))
(let (($x499 (not $x296)))
(and $x499 (or $x296 (and (distinct ((_ sign_extend 24) in57_8) ((_ zero_extend 24) in57_8)) true))))))
(check-sat)
; query 8: function main, block 63, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x602 ((_ zero_extend 24) in57_8)))
(let ((?x321 (bvshl in.01_32 (_ bv4 32))))
(let ((?x480 (bvadd ?x321 ?x602)))
(let ((?x462 ((_ sign_extend 24) in57_8)))
(let ((?x124 (bvadd ?x321 ?x462)))
(let (($x296 (or false false)))
(let (($x118 (or false false false)))
(let (($x381 (or $x118 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x667 (or $x381 $x296 false)))
(let ((?x66 ((_ sign_extend 1) ?x124)))
(let (($x10 (or $x381 $x296 (or (and (distinct (bvadd ((_ sign_extend 1) ?x321) ((_ sign_extend 1) ?x462)) ?x66) true)))))
(and (not $x10) (or $x667 (and (distinct ?x124 ?x480) true)))))))))))))))
(check-sat)
; query 9: function main, block 63, name %67
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x462 ((_ sign_extend 24) in57_8)))
(let ((?x321 (bvshl in.01_32 (_ bv4 32))))
(let ((?x124 (bvadd ?x321 ?x462)))
(let ((?x5 (bvsub ?x124 (_ bv48 32))))
(let (($x296 (or false false)))
(let (($x118 (or false false false)))
(let (($x381 (or $x118 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x667 (or $x381 $x296 false)))
(let (($x64 (or $x667 false false)))
(let (($x774 (or $x64 (and (distinct ?x5 (bvsub (bvadd ?x321 ((_ zero_extend 24) in57_8)) (_ bv48 32))) true))))
(let (($x50 (and (distinct (bvsub ((_ sign_extend 1) ?x124) ((_ sign_extend 1) (_ bv48 32))) ((_ sign_extend 1) ?x5)) true)))
(let ((?x66 ((_ sign_extend 1) ?x124)))
(let (($x10 (or $x381 $x296 (or (and (distinct (bvadd ((_ sign_extend 1) ?x321) ((_ sign_extend 1) ?x462)) ?x66) true)))))
(and (not (or $x10 false (or $x50))) $x774)))))))))))))))
(check-sat)
; query 10: function main, block 68, name %69
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x296 (or false false)))
(let (($x499 (not $x296)))
(and $x499 (or $x296 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true))))))
(check-sat)
; query 11: function main, block 68, name %70
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x128 (ite (bvsle (_ bv65 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x296 (or false false)))
(let (($x49 (or $x296 false false)))
(let (($x23 (not $x49)))
(and $x23 (or $x49 (and (distinct ?x128 ?x128) true))))))))
(check-sat)
; query 12: function main, block 71, name %72
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x296 (or false false)))
(let (($x499 (not $x296)))
(and $x499 (or $x296 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true))))))
(check-sat)
; query 13: function main, block 71, name %73
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x113 (ite (bvsge (_ bv70 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x296 (or false false)))
(let (($x49 (or $x296 false false)))
(let (($x23 (not $x49)))
(and $x23 (or $x49 (and (distinct ?x113 ?x113) true))))))))
(check-sat)
; query 14: function main, block 74, name %75
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x118 (or false false false)))
(let (($x381 (or $x118 (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x381) (or $x381 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvshl in.01_32 (_ bv4 32))) true))))))
(check-sat)
; query 15: function main, block 74, name %76
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x296 (or false false)))
(let (($x499 (not $x296)))
(and $x499 (or $x296 (and (distinct ((_ sign_extend 24) in57_8) ((_ zero_extend 24) in57_8)) true))))))
(check-sat)
; query 16: function main, block 74, name %77
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x602 ((_ zero_extend 24) in57_8)))
(let ((?x321 (bvshl in.01_32 (_ bv4 32))))
(let ((?x480 (bvadd ?x321 ?x602)))
(let ((?x462 ((_ sign_extend 24) in57_8)))
(let ((?x124 (bvadd ?x321 ?x462)))
(let (($x296 (or false false)))
(let (($x118 (or false false false)))
(let (($x381 (or $x118 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x667 (or $x381 $x296 false)))
(let ((?x66 ((_ sign_extend 1) ?x124)))
(let (($x10 (or $x381 $x296 (or (and (distinct (bvadd ((_ sign_extend 1) ?x321) ((_ sign_extend 1) ?x462)) ?x66) true)))))
(and (not $x10) (or $x667 (and (distinct ?x124 ?x480) true)))))))))))))))
(check-sat)
; query 17: function main, block 74, name %78
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x602 ((_ zero_extend 24) in57_8)))
(let ((?x321 (bvshl in.01_32 (_ bv4 32))))
(let ((?x480 (bvadd ?x321 ?x602)))
(let ((?x171 (bvsub ?x480 (_ bv65 32))))
(let ((?x462 ((_ sign_extend 24) in57_8)))
(let ((?x124 (bvadd ?x321 ?x462)))
(let ((?x27 (bvsub ?x124 (_ bv65 32))))
(let (($x296 (or false false)))
(let (($x118 (or false false false)))
(let (($x381 (or $x118 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x667 (or $x381 $x296 false)))
(let (($x64 (or $x667 false false)))
(let ((?x172 ((_ sign_extend 1) ?x27)))
(let ((?x66 ((_ sign_extend 1) ?x124)))
(let (($x10 (or $x381 $x296 (or (and (distinct (bvadd ((_ sign_extend 1) ?x321) ((_ sign_extend 1) ?x462)) ?x66) true)))))
(let (($x116 (or $x10 false (or (and (distinct (bvsub ?x66 ((_ sign_extend 1) (_ bv65 32))) ?x172) true)))))
(and (not $x116) (or $x64 (and (distinct ?x27 ?x171) true))))))))))))))))))))
(check-sat)
; query 18: function main, block 74, name %79
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x602 ((_ zero_extend 24) in57_8)))
(let ((?x321 (bvshl in.01_32 (_ bv4 32))))
(let ((?x480 (bvadd ?x321 ?x602)))
(let ((?x171 (bvsub ?x480 (_ bv65 32))))
(let ((?x462 ((_ sign_extend 24) in57_8)))
(let ((?x124 (bvadd ?x321 ?x462)))
(let ((?x27 (bvsub ?x124 (_ bv65 32))))
(let ((?x400 (bvadd ?x27 (_ bv10 32))))
(let (($x296 (or false false)))
(let (($x118 (or false false false)))
(let (($x381 (or $x118 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x667 (or $x381 $x296 false)))
(let (($x64 (or $x667 false false)))
(let (($x364 (and (distinct (bvadd ((_ sign_extend 1) ?x27) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x400)) true)))
(let ((?x172 ((_ sign_extend 1) ?x27)))
(let ((?x66 ((_ sign_extend 1) ?x124)))
(let (($x10 (or $x381 $x296 (or (and (distinct (bvadd ((_ sign_extend 1) ?x321) ((_ sign_extend 1) ?x462)) ?x66) true)))))
(let (($x116 (or $x10 false (or (and (distinct (bvsub ?x66 ((_ sign_extend 1) (_ bv65 32))) ?x172) true)))))
(and (not (or $x116 false (or $x364))) (or (or $x64 false false) (and (distinct ?x400 (bvadd ?x171 (_ bv10 32))) true))))))))))))))))))))))
(check-sat)
