; OptiPhase-Sigma refinement certificate for sweep K56-R4-307
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x43 (not $x382)))
(and $x43 (or $x382 (and (distinct ((_ sign_extend 16) in25_16) ((_ sign_extend 16) in25_16)) true))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let ((?x516 (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))))
(let (($x382 (or false false)))
(let (($x621 (or $x382 false false)))
(let (($x712 (not $x621)))
(and $x712 (or $x621 (and (distinct ?x516 ?x516) true))))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x43 (not $x382)))
(and $x43 (or $x382 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x441 ((_ sign_extend 16) in3_16)))
(let ((?x51 (bvand ?x441 (_ bv127 32))))
(let (($x382 (or false false)))
(let (($x621 (or $x382 false false)))
(let (($x712 (not $x621)))
(and $x712 (or $x621 (and (distinct ?x51 ?x51) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x441 ((_ sign_extend 16) in3_16)))
(let ((?x51 (bvand ?x441 (_ bv127 32))))
(let ((?x44 ((_ extract 15 0) ?x51)))
(let (($x382 (or false false)))
(let (($x621 (or $x382 false false)))
(let (($x85 (or $x621 false)))
(let (($x908 (not $x85)))
(and $x908 (or $x85 (and (distinct ?x44 ?x44) true)))))))))))
(check-sat)
; query 5: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x382 (or false false)))
(let (($x43 (not $x382)))
(and $x43 (or $x382 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 6: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x139 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x382 (or false false)))
(let (($x621 (or $x382 false false)))
(let (($x712 (not $x621)))
(and $x712 (or $x621 (and (distinct ?x139 ?x139) true))))))))
(check-sat)
; query 7: function core_bench_list, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x1621 (or false false false)))
(let (($x384 (not $x1621)))
(and $x384 (or $x1621 (and (distinct (bvadd in.0_16 (_ bv1 16)) (bvadd in.0_16 (_ bv1 16))) true))))))
(check-sat)
; query 8: function core_bench_list, block 82, name %83
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x43 (not $x382)))
(and $x43 (or $x382 (and (distinct ((_ zero_extend 16) in.02_16) ((_ zero_extend 16) in.02_16)) true))))))
(check-sat)
; query 9: function core_bench_list, block 82, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x125 ((_ zero_extend 16) in.02_16)))
(let ((?x122 (bvmul ?x125 (_ bv4 32))))
(let (($x324 (and (distinct (bvmul ((_ sign_extend 32) ?x125) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x122)) true)))
(let (($x382 (or false false)))
(let (($x411 (or $x382 false (or $x324))))
(and (not $x411) (or $x411 (and (distinct ?x122 ?x122) true)))))))))
(check-sat)
; query 10: function core_bench_list, block 82, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x43 (not $x382)))
(and $x43 (or $x382 (and (distinct ((_ zero_extend 16) in.04_16) ((_ zero_extend 16) in.04_16)) true))))))
(check-sat)
; query 11: function core_bench_list, block 82, name %86
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x434 ((_ zero_extend 16) in.04_16)))
(let ((?x125 ((_ zero_extend 16) in.02_16)))
(let ((?x122 (bvmul ?x125 (_ bv4 32))))
(let ((?x462 (bvsub ?x122 ?x434)))
(let ((?x331 ((_ sign_extend 1) ?x462)))
(let (($x382 (or false false)))
(let (($x324 (and (distinct (bvmul ((_ sign_extend 32) ?x125) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x122)) true)))
(let (($x411 (or $x382 false (or $x324))))
(let (($x559 (or $x411 $x382 (or (and (distinct (bvsub ((_ sign_extend 1) ?x122) ((_ sign_extend 1) ?x434)) ?x331) true)))))
(and (not $x559) (or $x559 (and (distinct ?x462 ?x462) true)))))))))))))
(check-sat)
; query 12: function core_bench_list, block 82, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x43 (not $x382)))
(and $x43 (or $x382 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 13: function core_bench_list, block 82, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x434 ((_ zero_extend 16) in.04_16)))
(let ((?x125 ((_ zero_extend 16) in.02_16)))
(let ((?x122 (bvmul ?x125 (_ bv4 32))))
(let ((?x462 (bvsub ?x122 ?x434)))
(let ((?x142 ((_ zero_extend 16) in.01_16)))
(let ((?x1620 (bvadd ?x142 ?x462)))
(let (($x72 (and (distinct (bvadd ((_ sign_extend 1) ?x142) ((_ sign_extend 1) ?x462)) ((_ sign_extend 1) ?x1620)) true)))
(let ((?x331 ((_ sign_extend 1) ?x462)))
(let (($x382 (or false false)))
(let (($x324 (and (distinct (bvmul ((_ sign_extend 32) ?x125) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x122)) true)))
(let (($x411 (or $x382 false (or $x324))))
(let (($x559 (or $x411 $x382 (or (and (distinct (bvsub ((_ sign_extend 1) ?x122) ((_ sign_extend 1) ?x434)) ?x331) true)))))
(let (($x126 (or $x382 $x559 (or $x72))))
(and (not $x126) (or $x126 (and (distinct ?x1620 ?x1620) true)))))))))))))))))
(check-sat)
; query 14: function core_bench_list, block 82, name %89
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x434 ((_ zero_extend 16) in.04_16)))
(let ((?x125 ((_ zero_extend 16) in.02_16)))
(let ((?x122 (bvmul ?x125 (_ bv4 32))))
(let ((?x462 (bvsub ?x122 ?x434)))
(let ((?x142 ((_ zero_extend 16) in.01_16)))
(let ((?x1620 (bvadd ?x142 ?x462)))
(let ((?x365 ((_ extract 15 0) ?x1620)))
(let (($x72 (and (distinct (bvadd ((_ sign_extend 1) ?x142) ((_ sign_extend 1) ?x462)) ((_ sign_extend 1) ?x1620)) true)))
(let ((?x331 ((_ sign_extend 1) ?x462)))
(let (($x382 (or false false)))
(let (($x324 (and (distinct (bvmul ((_ sign_extend 32) ?x125) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x122)) true)))
(let (($x411 (or $x382 false (or $x324))))
(let (($x559 (or $x411 $x382 (or (and (distinct (bvsub ((_ sign_extend 1) ?x122) ((_ sign_extend 1) ?x434)) ?x331) true)))))
(let (($x126 (or $x382 $x559 (or $x72))))
(let (($x922 (or $x126 false)))
(and (not $x922) (or $x922 (and (distinct ?x365 ?x365) true)))))))))))))))))))
(check-sat)
; query 15: function core_bench_list, block 82, name %90
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x43 (not $x382)))
(and $x43 (or $x382 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 16: function core_bench_list, block 82, name %91
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x423 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x382 (or false false)))
(let (($x621 (or $x382 false false)))
(let (($x712 (not $x621)))
(and $x712 (or $x621 (and (distinct ?x423 ?x423) true))))))))
(check-sat)
; query 17: function core_bench_state, block 105, name %106
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x1621 (or false false false)))
(let (($x384 (not $x1621)))
(and $x384 (or $x1621 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 18: function core_bench_state, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1621 (or false false false)))
(let (($x384 (not $x1621)))
(and $x384 (or $x1621 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 19: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x362 (bvadd in.01_32 (_ bv1 32))))
(let (($x198 (and (distinct ?x362 ?x362) true)))
(let (($x1621 (or false false false)))
(let (($x384 (not $x1621)))
(and $x384 (or $x1621 $x198)))))))
(check-sat)
; query 20: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x362 (bvadd in.01_32 (_ bv1 32))))
(let ((?x143 (bvmul ?x362 ?x362)))
(let (($x1621 (or false false false)))
(let (($x5225 (or $x1621 $x1621 false)))
(and (not $x5225) (or $x5225 (and (distinct ?x143 ?x143) true))))))))
(check-sat)
; query 21: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x362 (bvadd in.01_32 (_ bv1 32))))
(let ((?x143 (bvmul ?x362 ?x362)))
(let ((?x676 (bvmul ?x143 (_ bv2 32))))
(let (($x1621 (or false false false)))
(let (($x5225 (or $x1621 $x1621 false)))
(let (($x464 (or $x5225 false false)))
(and (not $x464) (or $x464 (and (distinct ?x676 ?x676) true))))))))))
(check-sat)
; query 22: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x362 (bvadd in.01_32 (_ bv1 32))))
(let ((?x143 (bvmul ?x362 ?x362)))
(let ((?x676 (bvmul ?x143 (_ bv2 32))))
(let ((?x486 (bvmul ?x676 (_ bv4 32))))
(let (($x1621 (or false false false)))
(let (($x5225 (or $x1621 $x1621 false)))
(let (($x464 (or $x5225 false false)))
(let (($x1858 (or $x464 false false)))
(and (not $x1858) (or $x1858 (and (distinct ?x486 ?x486) true))))))))))))
(check-sat)
; query 23: function core_init_matrix, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x1621 (or false false false)))
(let (($x384 (not $x1621)))
(and $x384 (or $x1621 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 24: function core_init_matrix, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x1621 (or false false false)))
(let (($x384 (not $x1621)))
(and $x384 (or $x1621 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 25: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x982 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x1621 (or false false false)))
(let (($x384 (not $x1621)))
(and $x384 (or $x1621 (and (distinct ?x982 ?x982) true)))))))
(check-sat)
; query 26: function core_init_state, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_32 () (_ BitVec 32))
(assert
 (let (($x1621 (or false false false)))
(let (($x384 (not $x1621)))
(and $x384 (or $x1621 (and (distinct (bvadd in.06_32 (_ bv1 32)) (bvadd in.06_32 (_ bv1 32))) true))))))
(check-sat)
; query 27: function core_init_state, block 65, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let (($x1621 (or false false false)))
(let (($x384 (not $x1621)))
(and $x384 (or $x1621 (and (distinct (bvadd in4_32 (_ bv1 32)) (bvadd in4_32 (_ bv1 32))) true))))))
(check-sat)
; query 28: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x1144 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x1621 (or false false false)))
(let (($x384 (not $x1621)))
(and $x384 (or $x1621 (and (distinct ?x1144 ?x1144) true)))))))
(check-sat)
; query 29: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x1621 (or false false false)))
(let (($x384 (not $x1621)))
(and $x384 (or $x1621 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 30: function core_list_init, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x362 (bvadd in.01_32 (_ bv1 32))))
(let (($x198 (and (distinct ?x362 ?x362) true)))
(let (($x1621 (or false false false)))
(let (($x384 (not $x1621)))
(and $x384 (or $x1621 $x198)))))))
(check-sat)
; query 31: function core_list_mergesort, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x362 (bvadd in.01_32 (_ bv1 32))))
(let (($x198 (and (distinct ?x362 ?x362) true)))
(let (($x968 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x362)) true)))
(let (($x34 (or false false (or $x968))))
(and (not $x34) (or $x34 $x198)))))))
(check-sat)
; query 32: function core_list_mergesort, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x395 (ite (bvslt (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x1621 (or false false false)))
(let (($x384 (not $x1621)))
(and $x384 (or $x1621 (and (distinct ?x395 ?x395) true)))))))
(check-sat)
; query 33: function core_list_mergesort, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.224_32 () (_ BitVec 32))
(assert
 (let ((?x252 (ite (= (_ bv0 32) in.224_32) (_ bv1 1) (_ bv0 1))))
(let (($x1621 (or false false false)))
(let (($x384 (not $x1621)))
(and $x384 (or $x1621 (and (distinct ?x252 ?x252) true)))))))
(check-sat)
; query 34: function core_list_mergesort, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x1734 (ite (= (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x1621 (or false false false)))
(let (($x384 (not $x1621)))
(and $x384 (or $x1621 (and (distinct ?x1734 ?x1734) true)))))))
(check-sat)
; query 35: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x1566 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x276 (or false false (or $x1566))))
(and (not $x276) (or $x276 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 36: function core_list_mergesort, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x55 (and (distinct (bvmul ((_ sign_extend 32) in.020_32) ((_ sign_extend 32) (_ bv2 32))) ((_ sign_extend 32) (bvmul in.020_32 (_ bv2 32)))) true)))
(let (($x1340 (or false false (or $x55))))
(and (not $x1340) (or $x1340 (and (distinct (bvmul in.020_32 (_ bv2 32)) (bvmul in.020_32 (_ bv2 32))) true))))))
(check-sat)
; query 37: function core_state_transition, block 102, name %103
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x382 (or false false)))
(let (($x43 (not $x382)))
(and $x43 (or $x382 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 38: function core_state_transition, block 102, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x8013 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x382 (or false false)))
(let (($x621 (or $x382 false false)))
(let (($x712 (not $x621)))
(and $x712 (or $x621 (and (distinct ?x8013 ?x8013) true))))))))
(check-sat)
; query 39: function core_state_transition, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x382 (or false false)))
(let (($x43 (not $x382)))
(and $x43 (or $x382 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 40: function core_state_transition, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1038 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x382 (or false false)))
(let (($x621 (or $x382 false false)))
(let (($x712 (not $x621)))
(and $x712 (or $x621 (and (distinct ?x1038 ?x1038) true))))))))
(check-sat)
; query 41: function core_state_transition, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x382 (or false false)))
(let (($x43 (not $x382)))
(and $x43 (or $x382 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 42: function core_state_transition, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x8013 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x382 (or false false)))
(let (($x621 (or $x382 false false)))
(let (($x712 (not $x621)))
(and $x712 (or $x621 (and (distinct ?x8013 ?x8013) true))))))))
(check-sat)
; query 43: function core_state_transition, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x382 (or false false)))
(let (($x43 (not $x382)))
(and $x43 (or $x382 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 44: function core_state_transition, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x2043 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x382 (or false false)))
(let (($x621 (or $x382 false false)))
(let (($x712 (not $x621)))
(and $x712 (or $x621 (and (distinct ?x2043 ?x2043) true))))))))
(check-sat)
; query 45: function core_state_transition, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x382 (or false false)))
(let (($x43 (not $x382)))
(and $x43 (or $x382 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 46: function core_state_transition, block 51, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x2043 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x382 (or false false)))
(let (($x621 (or $x382 false false)))
(let (($x712 (not $x621)))
(and $x712 (or $x621 (and (distinct ?x2043 ?x2043) true))))))))
(check-sat)
; query 47: function core_state_transition, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x382 (or false false)))
(let (($x43 (not $x382)))
(and $x43 (or $x382 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 48: function core_state_transition, block 64, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x2043 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x382 (or false false)))
(let (($x621 (or $x382 false false)))
(let (($x712 (not $x621)))
(and $x712 (or $x621 (and (distinct ?x2043 ?x2043) true))))))))
(check-sat)
; query 49: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x2044 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x1621 (or false false false)))
(let (($x384 (not $x1621)))
(and $x384 (or $x1621 (and (distinct ?x2044 ?x2044) true)))))))
(check-sat)
; query 50: function core_state_transition, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x382 (or false false)))
(let (($x43 (not $x382)))
(and $x43 (or $x382 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 51: function core_state_transition, block 80, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x5081 (ite (= (_ bv69 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x382 (or false false)))
(let (($x621 (or $x382 false false)))
(let (($x712 (not $x621)))
(and $x712 (or $x621 (and (distinct ?x5081 ?x5081) true))))))))
(check-sat)
; query 52: function core_state_transition, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x382 (or false false)))
(let (($x43 (not $x382)))
(and $x43 (or $x382 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 53: function core_state_transition, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1531 (ite (= (_ bv101 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x382 (or false false)))
(let (($x621 (or $x382 false false)))
(let (($x712 (not $x621)))
(and $x712 (or $x621 (and (distinct ?x1531 ?x1531) true))))))))
(check-sat)
; query 54: function core_state_transition, block 99, name %100
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x382 (or false false)))
(let (($x43 (not $x382)))
(and $x43 (or $x382 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 55: function core_state_transition, block 99, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1038 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x382 (or false false)))
(let (($x621 (or $x382 false false)))
(let (($x712 (not $x621)))
(and $x712 (or $x621 (and (distinct ?x1038 ?x1038) true))))))))
(check-sat)
; query 56: function crcu8, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x43 (not $x382)))
(and $x43 (or $x382 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 57: function crcu8, block 19, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x142 ((_ zero_extend 16) in.01_16)))
(let ((?x1676 (bvxor ?x142 (_ bv16386 32))))
(let (($x382 (or false false)))
(let (($x621 (or $x382 false false)))
(let (($x712 (not $x621)))
(and $x712 (or $x621 (and (distinct ?x1676 ?x1676) true)))))))))
(check-sat)
; query 58: function crcu8, block 19, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x142 ((_ zero_extend 16) in.01_16)))
(let ((?x1676 (bvxor ?x142 (_ bv16386 32))))
(let ((?x1811 ((_ extract 15 0) ?x1676)))
(let (($x382 (or false false)))
(let (($x621 (or $x382 false false)))
(let (($x85 (or $x621 false)))
(let (($x908 (not $x85)))
(and $x908 (or $x85 (and (distinct ?x1811 ?x1811) true)))))))))))
(check-sat)
; query 59: function crcu8, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x43 (not $x382)))
(and $x43 (or $x382 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 60: function crcu8, block 29, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1981 ((_ zero_extend 16) in27_16)))
(let ((?x909 (bvor ?x1981 (_ bv32768 32))))
(let (($x382 (or false false)))
(let (($x621 (or $x382 false false)))
(let (($x712 (not $x621)))
(and $x712 (or $x621 (and (distinct ?x909 ?x909) true)))))))))
(check-sat)
; query 61: function crcu8, block 29, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1981 ((_ zero_extend 16) in27_16)))
(let ((?x909 (bvor ?x1981 (_ bv32768 32))))
(let ((?x1578 ((_ extract 15 0) ?x909)))
(let (($x382 (or false false)))
(let (($x621 (or $x382 false false)))
(let (($x85 (or $x621 false)))
(let (($x908 (not $x85)))
(and $x908 (or $x85 (and (distinct ?x1578 ?x1578) true)))))))))))
(check-sat)
; query 62: function crcu8, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x43 (not $x382)))
(and $x43 (or $x382 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 63: function crcu8, block 33, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1981 ((_ zero_extend 16) in27_16)))
(let ((?x3086 (bvand ?x1981 (_ bv32767 32))))
(let (($x382 (or false false)))
(let (($x621 (or $x382 false false)))
(let (($x712 (not $x621)))
(and $x712 (or $x621 (and (distinct ?x3086 ?x3086) true)))))))))
(check-sat)
; query 64: function crcu8, block 33, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1981 ((_ zero_extend 16) in27_16)))
(let ((?x3086 (bvand ?x1981 (_ bv32767 32))))
(let ((?x4135 ((_ extract 15 0) ?x3086)))
(let (($x382 (or false false)))
(let (($x621 (or $x382 false false)))
(let (($x85 (or $x621 false)))
(let (($x908 (not $x85)))
(and $x908 (or $x85 (and (distinct ?x4135 ?x4135) true)))))))))))
(check-sat)
; query 65: function crcu8, block 38, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_8 () (_ BitVec 8))
(assert
 (let (($x1621 (or false false false)))
(let (($x384 (not $x1621)))
(and $x384 (or $x1621 (and (distinct (bvadd in.02_8 (_ bv1 8)) (bvadd in.02_8 (_ bv1 8))) true))))))
(check-sat)
; query 66: function crcu8, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x4418 ((_ extract 7 0) in.01_16)))
(let ((?x5293 ((_ zero_extend 24) ?x4418)))
(let (($x382 (or false false)))
(let (($x7732 (or $x382 false)))
(and (not $x7732) (or $x7732 (and (distinct ?x5293 ?x5293) true))))))))
(check-sat)
; query 67: function crcu8, block 6, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x4418 ((_ extract 7 0) in.01_16)))
(let ((?x5293 ((_ zero_extend 24) ?x4418)))
(let ((?x144 (bvand ?x5293 (_ bv1 32))))
(let (($x382 (or false false)))
(let (($x7732 (or $x382 false)))
(let (($x5299 (or $x7732 false false)))
(and (not $x5299) (or $x5299 (and (distinct ?x144 ?x144) true))))))))))
(check-sat)
; query 68: function crcu8, block 6, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x4418 ((_ extract 7 0) in.01_16)))
(let ((?x5293 ((_ zero_extend 24) ?x4418)))
(let ((?x144 (bvand ?x5293 (_ bv1 32))))
(let ((?x2978 ((_ zero_extend 24) in.0_8)))
(let ((?x2007 (bvand ?x2978 (_ bv1 32))))
(let ((?x883 (bvxor ?x2007 ?x144)))
(let (($x382 (or false false)))
(let (($x7732 (or $x382 false)))
(let (($x5299 (or $x7732 false false)))
(let (($x621 (or $x382 false false)))
(let (($x3191 (or $x621 $x5299 false)))
(and (not $x3191) (or $x3191 (and (distinct ?x883 ?x883) true)))))))))))))))
(check-sat)
; query 69: function crcu8, block 6, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x4418 ((_ extract 7 0) in.01_16)))
(let ((?x5293 ((_ zero_extend 24) ?x4418)))
(let ((?x144 (bvand ?x5293 (_ bv1 32))))
(let ((?x2978 ((_ zero_extend 24) in.0_8)))
(let ((?x2007 (bvand ?x2978 (_ bv1 32))))
(let ((?x883 (bvxor ?x2007 ?x144)))
(let ((?x817 ((_ extract 7 0) ?x883)))
(let (($x382 (or false false)))
(let (($x7732 (or $x382 false)))
(let (($x5299 (or $x7732 false false)))
(let (($x621 (or $x382 false false)))
(let (($x3191 (or $x621 $x5299 false)))
(let (($x6161 (or $x3191 false)))
(and (not $x6161) (or $x6161 (and (distinct ?x817 ?x817) true)))))))))))))))))
(check-sat)
; query 70: function crcu8, block 6, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x382 (or false false)))
(let (($x43 (not $x382)))
(and $x43 (or $x382 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 71: function crcu8, block 6, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x2978 ((_ zero_extend 24) in.0_8)))
(let ((?x1823 (bvashr ?x2978 (_ bv1 32))))
(let (($x382 (or false false)))
(let (($x621 (or $x382 false false)))
(let (($x2479 (or $x621 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not $x2479) (or $x2479 (and (distinct ?x1823 ?x1823) true)))))))))
(check-sat)
; query 72: function crcu8, block 6, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x2978 ((_ zero_extend 24) in.0_8)))
(let ((?x1823 (bvashr ?x2978 (_ bv1 32))))
(let ((?x836 ((_ extract 7 0) ?x1823)))
(let (($x382 (or false false)))
(let (($x621 (or $x382 false false)))
(let (($x2479 (or $x621 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x1104 (or $x2479 false)))
(and (not $x1104) (or $x1104 (and (distinct ?x836 ?x836) true)))))))))))
(check-sat)
; query 73: function crcu8, block 6, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x4418 ((_ extract 7 0) in.01_16)))
(let ((?x5293 ((_ zero_extend 24) ?x4418)))
(let ((?x144 (bvand ?x5293 (_ bv1 32))))
(let ((?x2978 ((_ zero_extend 24) in.0_8)))
(let ((?x2007 (bvand ?x2978 (_ bv1 32))))
(let ((?x883 (bvxor ?x2007 ?x144)))
(let ((?x817 ((_ extract 7 0) ?x883)))
(let ((?x2021 ((_ zero_extend 24) ?x817)))
(let (($x382 (or false false)))
(let (($x7732 (or $x382 false)))
(let (($x5299 (or $x7732 false false)))
(let (($x621 (or $x382 false false)))
(let (($x3191 (or $x621 $x5299 false)))
(let (($x6161 (or $x3191 false)))
(let (($x1365 (or $x6161 false)))
(and (not $x1365) (or $x1365 (and (distinct ?x2021 ?x2021) true)))))))))))))))))))
(check-sat)
; query 74: function crcu8, block 6, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x4418 ((_ extract 7 0) in.01_16)))
(let ((?x5293 ((_ zero_extend 24) ?x4418)))
(let ((?x144 (bvand ?x5293 (_ bv1 32))))
(let ((?x2978 ((_ zero_extend 24) in.0_8)))
(let ((?x2007 (bvand ?x2978 (_ bv1 32))))
(let ((?x883 (bvxor ?x2007 ?x144)))
(let ((?x817 ((_ extract 7 0) ?x883)))
(let ((?x2021 ((_ zero_extend 24) ?x817)))
(let ((?x5201 (ite (= (_ bv1 32) ?x2021) (_ bv1 1) (_ bv0 1))))
(let (($x382 (or false false)))
(let (($x7732 (or $x382 false)))
(let (($x5299 (or $x7732 false false)))
(let (($x621 (or $x382 false false)))
(let (($x3191 (or $x621 $x5299 false)))
(let (($x6161 (or $x3191 false)))
(let (($x1365 (or $x6161 false)))
(let (($x2647 (or $x1365 false false)))
(and (not $x2647) (or $x2647 (and (distinct ?x5201 ?x5201) true)))))))))))))))))))))
(check-sat)
; query 75: function crcu8, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x382 (or false false)))
(let (($x43 (not $x382)))
(and $x43 (or $x382 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 76: function crcu8, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x2978 ((_ zero_extend 24) in.0_8)))
(let ((?x2007 (bvand ?x2978 (_ bv1 32))))
(let (($x382 (or false false)))
(let (($x621 (or $x382 false false)))
(let (($x712 (not $x621)))
(and $x712 (or $x621 (and (distinct ?x2007 ?x2007) true)))))))))
(check-sat)
; query 77: function crcu8, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x43 (not $x382)))
(and $x43 (or $x382 (and (distinct ((_ extract 7 0) in.01_16) ((_ extract 7 0) in.01_16)) true))))))
(check-sat)
; query 78: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x8137 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x952 ((_ zero_extend 31) ?x8137)))
(let ((?x175 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x356 ((_ zero_extend 31) ?x175)))
(let ((?x3243 (bvand ?x356 ?x952)))
(let ((?x3796 (ite (and (distinct (_ bv0 32) ?x3243) true) (_ bv1 1) (_ bv0 1))))
(let ((?x3572 ((_ zero_extend 63) ?x3796)))
(let (($x382 (or false false)))
(let (($x621 (or $x382 false false)))
(let (($x85 (or $x621 false)))
(let (($x2327 (or $x85 $x85 false)))
(let (($x590 (or $x2327 false false)))
(let (($x7809 (or $x590 false)))
(and (not $x7809) (or $x7809 (and (distinct ?x3572 ?x3572) true)))))))))))))))))
(check-sat)
; query 79: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x8137 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x952 ((_ zero_extend 31) ?x8137)))
(let ((?x175 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x356 ((_ zero_extend 31) ?x175)))
(let ((?x3243 (bvand ?x356 ?x952)))
(let ((?x3796 (ite (and (distinct (_ bv0 32) ?x3243) true) (_ bv1 1) (_ bv0 1))))
(let (($x7795 (= (_ bv1 1) ?x3796)))
(let ((?x1546 (ite $x7795 (_ bv1 32) (_ bv0 32))))
(let (($x382 (or false false)))
(let (($x621 (or $x382 false false)))
(let (($x85 (or $x621 false)))
(let (($x2327 (or $x85 $x85 false)))
(let (($x590 (or $x2327 false false)))
(let (($x4223 (or $x590 (ite $x7795 false false))))
(and (not $x4223) (or $x4223 (and (distinct ?x1546 ?x1546) true))))))))))))))))))
(check-sat)
; query 80: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x8137 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x952 ((_ zero_extend 31) ?x8137)))
(let ((?x175 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x356 ((_ zero_extend 31) ?x175)))
(let ((?x3243 (bvand ?x356 ?x952)))
(let ((?x3796 (ite (and (distinct (_ bv0 32) ?x3243) true) (_ bv1 1) (_ bv0 1))))
(let (($x7795 (= (_ bv1 1) ?x3796)))
(let ((?x1546 (ite $x7795 (_ bv1 32) (_ bv0 32))))
(let ((?x3738 ((_ extract 7 0) ?x1546)))
(let (($x382 (or false false)))
(let (($x621 (or $x382 false false)))
(let (($x85 (or $x621 false)))
(let (($x2327 (or $x85 $x85 false)))
(let (($x590 (or $x2327 false false)))
(let (($x4223 (or $x590 (ite $x7795 false false))))
(let (($x710 (or $x4223 false)))
(and (not $x710) (or $x710 (and (distinct ?x3738 ?x3738) true))))))))))))))))))))
(check-sat)
; query 81: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x382 (or false false)))
(let (($x43 (not $x382)))
(and $x43 (or $x382 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 82: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x175 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x382 (or false false)))
(let (($x621 (or $x382 false false)))
(let (($x712 (not $x621)))
(and $x712 (or $x621 (and (distinct ?x175 ?x175) true))))))))
(check-sat)
; query 83: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x175 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x356 ((_ zero_extend 31) ?x175)))
(let (($x382 (or false false)))
(let (($x621 (or $x382 false false)))
(let (($x85 (or $x621 false)))
(let (($x908 (not $x85)))
(and $x908 (or $x85 (and (distinct ?x356 ?x356) true))))))))))
(check-sat)
; query 84: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x382 (or false false)))
(let (($x43 (not $x382)))
(and $x43 (or $x382 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 85: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x8137 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x382 (or false false)))
(let (($x621 (or $x382 false false)))
(let (($x712 (not $x621)))
(and $x712 (or $x621 (and (distinct ?x8137 ?x8137) true))))))))
(check-sat)
; query 86: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x8137 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x952 ((_ zero_extend 31) ?x8137)))
(let (($x382 (or false false)))
(let (($x621 (or $x382 false false)))
(let (($x85 (or $x621 false)))
(let (($x908 (not $x85)))
(and $x908 (or $x85 (and (distinct ?x952 ?x952) true))))))))))
(check-sat)
; query 87: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x8137 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x952 ((_ zero_extend 31) ?x8137)))
(let ((?x175 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x356 ((_ zero_extend 31) ?x175)))
(let ((?x3243 (bvand ?x356 ?x952)))
(let (($x382 (or false false)))
(let (($x621 (or $x382 false false)))
(let (($x85 (or $x621 false)))
(let (($x2327 (or $x85 $x85 false)))
(and (not $x2327) (or $x2327 (and (distinct ?x3243 ?x3243) true)))))))))))))
(check-sat)
; query 88: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x8137 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x952 ((_ zero_extend 31) ?x8137)))
(let ((?x175 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x356 ((_ zero_extend 31) ?x175)))
(let ((?x3243 (bvand ?x356 ?x952)))
(let ((?x3796 (ite (and (distinct (_ bv0 32) ?x3243) true) (_ bv1 1) (_ bv0 1))))
(let (($x382 (or false false)))
(let (($x621 (or $x382 false false)))
(let (($x85 (or $x621 false)))
(let (($x2327 (or $x85 $x85 false)))
(let (($x590 (or $x2327 false false)))
(and (not $x590) (or $x590 (and (distinct ?x3796 ?x3796) true)))))))))))))))
(check-sat)
; query 89: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x4272 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x1621 (or false false false)))
(let (($x384 (not $x1621)))
(and $x384 (or $x1621 (and (distinct ?x4272 ?x4272) true)))))))
(check-sat)
; query 90: function matrix_add_const, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1621 (or false false false)))
(let (($x384 (not $x1621)))
(and $x384 (or $x1621 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 91: function matrix_add_const, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x362 (bvadd in.01_32 (_ bv1 32))))
(let (($x198 (and (distinct ?x362 ?x362) true)))
(let (($x1621 (or false false false)))
(let (($x384 (not $x1621)))
(and $x384 (or $x1621 $x198)))))))
(check-sat)
; query 92: function matrix_mul_const, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1621 (or false false false)))
(let (($x384 (not $x1621)))
(and $x384 (or $x1621 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 93: function matrix_mul_const, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x362 (bvadd in.01_32 (_ bv1 32))))
(let (($x198 (and (distinct ?x362 ?x362) true)))
(let (($x1621 (or false false false)))
(let (($x384 (not $x1621)))
(and $x384 (or $x1621 $x198)))))))
(check-sat)
; query 94: function matrix_mul_matrix, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1621 (or false false false)))
(let (($x384 (not $x1621)))
(and $x384 (or $x1621 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 95: function matrix_mul_matrix, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x362 (bvadd in.01_32 (_ bv1 32))))
(let (($x198 (and (distinct ?x362 ?x362) true)))
(let (($x1621 (or false false false)))
(let (($x384 (not $x1621)))
(and $x384 (or $x1621 $x198)))))))
(check-sat)
; query 96: function matrix_mul_matrix, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x1621 (or false false false)))
(let (($x384 (not $x1621)))
(and $x384 (or $x1621 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 97: function matrix_mul_matrix_bitextract, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1621 (or false false false)))
(let (($x384 (not $x1621)))
(and $x384 (or $x1621 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 98: function matrix_mul_matrix_bitextract, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x362 (bvadd in.01_32 (_ bv1 32))))
(let (($x198 (and (distinct ?x362 ?x362) true)))
(let (($x1621 (or false false false)))
(let (($x384 (not $x1621)))
(and $x384 (or $x1621 $x198)))))))
(check-sat)
; query 99: function matrix_mul_matrix_bitextract, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x1621 (or false false false)))
(let (($x384 (not $x1621)))
(and $x384 (or $x1621 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 100: function matrix_mul_vect, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1621 (or false false false)))
(let (($x384 (not $x1621)))
(and $x384 (or $x1621 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 101: function matrix_mul_vect, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x362 (bvadd in.01_32 (_ bv1 32))))
(let (($x198 (and (distinct ?x362 ?x362) true)))
(let (($x1621 (or false false false)))
(let (($x384 (not $x1621)))
(and $x384 (or $x1621 $x198)))))))
(check-sat)
; query 102: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x43 (not $x382)))
(and $x43 (or $x382 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 103: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x387 ((_ sign_extend 16) in.1_16)))
(let ((?x6164 (bvadd ?x387 (_ bv10 32))))
(let (($x1226 (and (distinct (bvadd ((_ sign_extend 1) ?x387) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x6164)) true)))
(let (($x382 (or false false)))
(let (($x4148 (or $x382 false (or $x1226))))
(and (not $x4148) (or $x4148 (and (distinct ?x6164 ?x6164) true)))))))))
(check-sat)
; query 104: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x387 ((_ sign_extend 16) in.1_16)))
(let ((?x6164 (bvadd ?x387 (_ bv10 32))))
(let ((?x2568 ((_ extract 15 0) ?x6164)))
(let (($x1226 (and (distinct (bvadd ((_ sign_extend 1) ?x387) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x6164)) true)))
(let (($x382 (or false false)))
(let (($x4148 (or $x382 false (or $x1226))))
(let (($x4248 (or $x4148 false)))
(and (not $x4248) (or $x4248 (and (distinct ?x2568 ?x2568) true)))))))))))
(check-sat)
; query 105: function matrix_sum, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x8037 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x1621 (or false false false)))
(let (($x384 (not $x1621)))
(and $x384 (or $x1621 (and (distinct ?x8037 ?x8037) true)))))))
(check-sat)
; query 106: function matrix_sum, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x8037 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let ((?x7866 ((_ zero_extend 63) ?x8037)))
(let (($x1621 (or false false false)))
(let (($x4478 (or $x1621 false)))
(and (not $x4478) (or $x4478 (and (distinct ?x7866 ?x7866) true))))))))
(check-sat)
; query 107: function matrix_sum, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x8037 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x6799 (= (_ bv1 1) ?x8037)))
(let ((?x5987 (ite $x6799 (_ bv1 32) (_ bv0 32))))
(let (($x1621 (or false false false)))
(let (($x4908 (or $x1621 (ite $x6799 false false))))
(and (not $x4908) (or $x4908 (and (distinct ?x5987 ?x5987) true)))))))))
(check-sat)
; query 108: function matrix_sum, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x43 (not $x382)))
(and $x43 (or $x382 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 109: function matrix_sum, block 22, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x8037 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x6799 (= (_ bv1 1) ?x8037)))
(let ((?x5987 (ite $x6799 (_ bv1 32) (_ bv0 32))))
(let ((?x387 ((_ sign_extend 16) in.1_16)))
(let ((?x6235 (bvadd ?x387 ?x5987)))
(let (($x3561 (and (distinct (bvadd ((_ sign_extend 1) ?x387) ((_ sign_extend 1) ?x5987)) ((_ sign_extend 1) ?x6235)) true)))
(let (($x1621 (or false false false)))
(let (($x4908 (or $x1621 (ite $x6799 false false))))
(let (($x382 (or false false)))
(let (($x5196 (or $x382 $x4908 (or $x3561))))
(and (not $x5196) (or $x5196 (and (distinct ?x6235 ?x6235) true))))))))))))))
(check-sat)
; query 110: function matrix_sum, block 22, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x8037 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x6799 (= (_ bv1 1) ?x8037)))
(let ((?x5987 (ite $x6799 (_ bv1 32) (_ bv0 32))))
(let ((?x387 ((_ sign_extend 16) in.1_16)))
(let ((?x6235 (bvadd ?x387 ?x5987)))
(let ((?x5687 ((_ extract 15 0) ?x6235)))
(let (($x3561 (and (distinct (bvadd ((_ sign_extend 1) ?x387) ((_ sign_extend 1) ?x5987)) ((_ sign_extend 1) ?x6235)) true)))
(let (($x1621 (or false false false)))
(let (($x4908 (or $x1621 (ite $x6799 false false))))
(let (($x382 (or false false)))
(let (($x5196 (or $x382 $x4908 (or $x3561))))
(let (($x6681 (or $x5196 false)))
(and (not $x6681) (or $x6681 (and (distinct ?x5687 ?x5687) true))))))))))))))))
(check-sat)
; query 111: function matrix_sum, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1621 (or false false false)))
(let (($x384 (not $x1621)))
(and $x384 (or $x1621 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 112: function matrix_sum, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x362 (bvadd in.01_32 (_ bv1 32))))
(let (($x198 (and (distinct ?x362 ?x362) true)))
(let (($x1621 (or false false false)))
(let (($x384 (not $x1621)))
(and $x384 (or $x1621 $x198)))))))
(check-sat)
; query 113: function parseval, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.23_32 () (_ BitVec 32))
(assert
 (let (($x3281 (and (distinct (bvmul ((_ sign_extend 32) in.23_32) ((_ sign_extend 32) (_ bv1024 32))) ((_ sign_extend 32) (bvmul in.23_32 (_ bv1024 32)))) true)))
(let (($x7748 (or false false (or $x3281))))
(and (not $x7748) (or $x7748 (and (distinct (bvmul in.23_32 (_ bv1024 32)) (bvmul in.23_32 (_ bv1024 32))) true))))))
(check-sat)
; query 114: function parseval, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.34_32 () (_ BitVec 32))
(assert
 (let (($x855 (and (distinct (bvmul ((_ sign_extend 32) in.34_32) ((_ sign_extend 32) (_ bv1048576 32))) ((_ sign_extend 32) (bvmul in.34_32 (_ bv1048576 32)))) true)))
(let (($x3307 (or false false (or $x855))))
(and (not $x3307) (or $x3307 (and (distinct (bvmul in.34_32 (_ bv1048576 32)) (bvmul in.34_32 (_ bv1048576 32))) true))))))
(check-sat)
; query 115: function partition_memory, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1621 (or false false false)))
(let (($x384 (not $x1621)))
(and $x384 (or $x1621 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
