; OptiPhase-Sigma refinement certificate for sweep K21-R4-308
; query 0: function init_array, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x135 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x19 (or false false (or $x135))))
(and (not $x19) (or $x19 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function init_array, block 25, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x42 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x137 (or false false (or $x42))))
(and (not $x137) (or $x137 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function kernel_deriche, block 102, name %103
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.112_32 () (_ BitVec 32))
(assert
 (let (($x147 (and (distinct (bvadd ((_ sign_extend 1) in.112_32) ((_ sign_extend 1) (_ bv4294967295 32))) ((_ sign_extend 1) (bvadd in.112_32 (_ bv4294967295 32)))) true)))
(let (($x5 (or false false (or $x147))))
(and (not $x5) (or $x5 (and (distinct (bvadd in.112_32 (_ bv4294967295 32)) (bvadd in.112_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 3: function kernel_deriche, block 105, name %106
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.110_32 () (_ BitVec 32))
(assert
 (let (($x87 (and (distinct (bvadd ((_ sign_extend 1) in.110_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.110_32 (_ bv1 32)))) true)))
(let (($x84 (or false false (or $x87))))
(and (not $x84) (or $x84 (and (distinct (bvadd in.110_32 (_ bv1 32)) (bvadd in.110_32 (_ bv1 32))) true))))))
(check-sat)
; query 4: function kernel_deriche, block 130, name %131
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.213_32 () (_ BitVec 32))
(assert
 (let (($x92 (and (distinct (bvadd ((_ sign_extend 1) in.213_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.213_32 (_ bv1 32)))) true)))
(let (($x25 (or false false (or $x92))))
(and (not $x25) (or $x25 (and (distinct (bvadd in.213_32 (_ bv1 32)) (bvadd in.213_32 (_ bv1 32))) true))))))
(check-sat)
; query 5: function kernel_deriche, block 133, name %134
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let (($x63 (and (distinct (bvadd ((_ sign_extend 1) in.2_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.2_32 (_ bv1 32)))) true)))
(let (($x37 (or false false (or $x63))))
(and (not $x37) (or $x37 (and (distinct (bvadd in.2_32 (_ bv1 32)) (bvadd in.2_32 (_ bv1 32))) true))))))
(check-sat)
; query 6: function kernel_deriche, block 165, name %166
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.3_32 () (_ BitVec 32))
(assert
 (let (($x80 (and (distinct (bvadd ((_ sign_extend 1) in.3_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.3_32 (_ bv1 32)))) true)))
(let (($x547 (or false false (or $x80))))
(and (not $x547) (or $x547 (and (distinct (bvadd in.3_32 (_ bv1 32)) (bvadd in.3_32 (_ bv1 32))) true))))))
(check-sat)
; query 7: function kernel_deriche, block 168, name %169
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.314_32 () (_ BitVec 32))
(assert
 (let (($x67 (and (distinct (bvadd ((_ sign_extend 1) in.314_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.314_32 (_ bv1 32)))) true)))
(let (($x55 (or false false (or $x67))))
(and (not $x55) (or $x55 (and (distinct (bvadd in.314_32 (_ bv1 32)) (bvadd in.314_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function kernel_deriche, block 173, name %174
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x105 (and (distinct (bvsub ((_ sign_extend 1) in0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvsub in0_32 (_ bv1 32)))) true)))
(let (($x77 (or false false (or $x105))))
(and (not $x77) (or $x77 (and (distinct (bvsub in0_32 (_ bv1 32)) (bvsub in0_32 (_ bv1 32))) true))))))
(check-sat)
; query 9: function kernel_deriche, block 196, name %197
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.4_32 () (_ BitVec 32))
(assert
 (let (($x115 (and (distinct (bvadd ((_ sign_extend 1) in.4_32) ((_ sign_extend 1) (_ bv4294967295 32))) ((_ sign_extend 1) (bvadd in.4_32 (_ bv4294967295 32)))) true)))
(let (($x20 (or false false (or $x115))))
(and (not $x20) (or $x20 (and (distinct (bvadd in.4_32 (_ bv4294967295 32)) (bvadd in.4_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 10: function kernel_deriche, block 199, name %200
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.415_32 () (_ BitVec 32))
(assert
 (let (($x68 (and (distinct (bvadd ((_ sign_extend 1) in.415_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.415_32 (_ bv1 32)))) true)))
(let (($x65 (or false false (or $x68))))
(and (not $x65) (or $x65 (and (distinct (bvadd in.415_32 (_ bv1 32)) (bvadd in.415_32 (_ bv1 32))) true))))))
(check-sat)
; query 11: function kernel_deriche, block 224, name %225
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.516_32 () (_ BitVec 32))
(assert
 (let (($x110 (and (distinct (bvadd ((_ sign_extend 1) in.516_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.516_32 (_ bv1 32)))) true)))
(let (($x120 (or false false (or $x110))))
(and (not $x120) (or $x120 (and (distinct (bvadd in.516_32 (_ bv1 32)) (bvadd in.516_32 (_ bv1 32))) true))))))
(check-sat)
; query 12: function kernel_deriche, block 227, name %228
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.5_32 () (_ BitVec 32))
(assert
 (let (($x395 (and (distinct (bvadd ((_ sign_extend 1) in.5_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.5_32 (_ bv1 32)))) true)))
(let (($x159 (or false false (or $x395))))
(and (not $x159) (or $x159 (and (distinct (bvadd in.5_32 (_ bv1 32)) (bvadd in.5_32 (_ bv1 32))) true))))))
(check-sat)
; query 13: function kernel_deriche, block 71, name %72
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.011_32 () (_ BitVec 32))
(assert
 (let (($x373 (and (distinct (bvadd ((_ sign_extend 1) in.011_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.011_32 (_ bv1 32)))) true)))
(let (($x420 (or false false (or $x373))))
(and (not $x420) (or $x420 (and (distinct (bvadd in.011_32 (_ bv1 32)) (bvadd in.011_32 (_ bv1 32))) true))))))
(check-sat)
; query 14: function kernel_deriche, block 74, name %75
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.09_32 () (_ BitVec 32))
(assert
 (let (($x457 (and (distinct (bvadd ((_ sign_extend 1) in.09_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.09_32 (_ bv1 32)))) true)))
(let (($x574 (or false false (or $x457))))
(and (not $x574) (or $x574 (and (distinct (bvadd in.09_32 (_ bv1 32)) (bvadd in.09_32 (_ bv1 32))) true))))))
(check-sat)
; query 15: function kernel_deriche, block 79, name %80
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x136 (and (distinct (bvsub ((_ sign_extend 1) in1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvsub in1_32 (_ bv1 32)))) true)))
(let (($x150 (or false false (or $x136))))
(and (not $x150) (or $x150 (and (distinct (bvsub in1_32 (_ bv1 32)) (bvsub in1_32 (_ bv1 32))) true))))))
(check-sat)
; query 16: function polybench_flush_cache, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x42 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x137 (or false false (or $x42))))
(and (not $x137) (or $x137 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 17: function print_array, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x135 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x19 (or false false (or $x135))))
(and (not $x19) (or $x19 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 18: function print_array, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x42 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x137 (or false false (or $x42))))
(and (not $x137) (or $x137 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 19: function xmalloc, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in7_32 () (_ BitVec 32))
(assert
 (let ((?x282 (ite (and (distinct (_ bv0 32) in7_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x389 (or false false false)))
(and (not $x389) (or $x389 (and (distinct ?x282 ?x282) true))))))
(check-sat)
