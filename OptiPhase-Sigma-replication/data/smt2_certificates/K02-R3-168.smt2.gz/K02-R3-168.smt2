; OptiPhase-Sigma refinement certificate for sweep K02-R3-168
; query 0: function xmalloc, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in7_32 () (_ BitVec 32))
(assert
 (let ((?x95 (ite (and (distinct (_ bv0 32) in7_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x94 (or false false false)))
(and (not $x94) (or $x94 (and (distinct ?x95 ?x95) true))))))
(check-sat)
