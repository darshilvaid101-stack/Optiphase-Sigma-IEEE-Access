; OptiPhase-Sigma refinement certificate for sweep K49-R3-101
; query 0: function APCM_inverse_quantization, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x308 (or false false)))
(let (($x1919 (not $x308)))
(and $x1919 (or $x308 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 1: function APCM_inverse_quantization, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x71 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x308 (or false false)))
(let (($x141 (or $x308 false false)))
(let (($x1681 (not $x141)))
(and $x1681 (or $x141 (and (distinct ?x71 ?x71) true))))))))
(check-sat)
; query 2: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x308 (or false false)))
(let (($x1919 (not $x308)))
(and $x1919 (or $x308 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 3: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x101 (ite (bvslt (_ bv15 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x308 (or false false)))
(let (($x141 (or $x308 false false)))
(let (($x1681 (not $x141)))
(and $x1681 (or $x141 (and (distinct ?x101 ?x101) true))))))))
(check-sat)
; query 4: function Decoding_of_the_coded_Log_Area_Ratios, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in6_64 () (_ BitVec 64))
(assert
 (let ((?x217 (ite (bvslt (_ bv0 64) in6_64) (_ bv1 1) (_ bv0 1))))
(let (($x423 (or false false false)))
(let (($x143 (not $x423)))
(and $x143 (or $x423 (and (distinct ?x217 ?x217) true)))))))
(check-sat)
; query 5: function Decoding_of_the_coded_Log_Area_Ratios, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in6_64 () (_ BitVec 64))
(assert
 (let ((?x217 (ite (bvslt (_ bv0 64) in6_64) (_ bv1 1) (_ bv0 1))))
(let ((?x851 ((_ zero_extend 63) ?x217)))
(let (($x423 (or false false false)))
(let (($x21 (or $x423 false)))
(let (($x120 (not $x21)))
(and $x120 (or $x21 (and (distinct ?x851 ?x851) true)))))))))
(check-sat)
; query 6: function Decoding_of_the_coded_Log_Area_Ratios, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in6_64 () (_ BitVec 64))
(assert
 (let ((?x217 (ite (bvslt (_ bv0 64) in6_64) (_ bv1 1) (_ bv0 1))))
(let (($x613 (= (_ bv1 1) ?x217)))
(let ((?x73 (ite $x613 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x423 (or false false false)))
(let (($x408 (or $x423 (ite $x613 false false))))
(and (not $x408) (or $x408 (and (distinct ?x73 ?x73) true)))))))))
(check-sat)
; query 7: function Decoding_of_the_coded_Log_Area_Ratios, block 9, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in6_64 () (_ BitVec 64))
(assert
 (let ((?x217 (ite (bvslt (_ bv0 64) in6_64) (_ bv1 1) (_ bv0 1))))
(let (($x613 (= (_ bv1 1) ?x217)))
(let ((?x73 (ite $x613 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x521 ((_ sign_extend 32) ?x73)))
(let (($x423 (or false false false)))
(let (($x408 (or $x423 (ite $x613 false false))))
(let (($x328 (or $x408 false)))
(and (not $x328) (or $x328 (and (distinct ?x521 ?x521) true)))))))))))
(check-sat)
; query 8: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x308 (or false false)))
(let (($x1919 (not $x308)))
(and $x1919 (or $x308 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 9: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x139 (ite (bvsgt (_ bv40 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x308 (or false false)))
(let (($x141 (or $x308 false false)))
(let (($x1681 (not $x141)))
(and $x1681 (or $x141 (and (distinct ?x139 ?x139) true))))))))
(check-sat)
; query 10: function Quantization_and_coding, block 11, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in8_64 () (_ BitVec 64))
(assert
 (let ((?x108 (ite (bvslt (_ bv0 64) in8_64) (_ bv1 1) (_ bv0 1))))
(let (($x423 (or false false false)))
(let (($x143 (not $x423)))
(and $x143 (or $x423 (and (distinct ?x108 ?x108) true)))))))
(check-sat)
; query 11: function Quantization_and_coding, block 11, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in8_64 () (_ BitVec 64))
(assert
 (let ((?x108 (ite (bvslt (_ bv0 64) in8_64) (_ bv1 1) (_ bv0 1))))
(let ((?x75 ((_ zero_extend 63) ?x108)))
(let (($x423 (or false false false)))
(let (($x21 (or $x423 false)))
(let (($x120 (not $x21)))
(and $x120 (or $x21 (and (distinct ?x75 ?x75) true)))))))))
(check-sat)
; query 12: function Quantization_and_coding, block 11, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in8_64 () (_ BitVec 64))
(assert
 (let ((?x108 (ite (bvslt (_ bv0 64) in8_64) (_ bv1 1) (_ bv0 1))))
(let (($x365 (= (_ bv1 1) ?x108)))
(let ((?x324 (ite $x365 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x423 (or false false false)))
(let (($x309 (or $x423 (ite $x365 false false))))
(and (not $x309) (or $x309 (and (distinct ?x324 ?x324) true)))))))))
(check-sat)
; query 13: function Quantization_and_coding, block 11, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in8_64 () (_ BitVec 64))
(assert
 (let ((?x108 (ite (bvslt (_ bv0 64) in8_64) (_ bv1 1) (_ bv0 1))))
(let (($x365 (= (_ bv1 1) ?x108)))
(let ((?x324 (ite $x365 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x712 ((_ sign_extend 32) ?x324)))
(let (($x423 (or false false false)))
(let (($x309 (or $x423 (ite $x365 false false))))
(let (($x1076 (or $x309 false)))
(and (not $x1076) (or $x1076 (and (distinct ?x712 ?x712) true)))))))))))
(check-sat)
; query 14: function Quantization_and_coding, block 111, name %112
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in108_64 () (_ BitVec 64))
(assert
 (let ((?x173 (ite (bvslt (_ bv0 64) in108_64) (_ bv1 1) (_ bv0 1))))
(let (($x423 (or false false false)))
(let (($x143 (not $x423)))
(and $x143 (or $x423 (and (distinct ?x173 ?x173) true)))))))
(check-sat)
; query 15: function Quantization_and_coding, block 111, name %113
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in108_64 () (_ BitVec 64))
(assert
 (let ((?x173 (ite (bvslt (_ bv0 64) in108_64) (_ bv1 1) (_ bv0 1))))
(let ((?x85 ((_ zero_extend 63) ?x173)))
(let (($x423 (or false false false)))
(let (($x21 (or $x423 false)))
(let (($x120 (not $x21)))
(and $x120 (or $x21 (and (distinct ?x85 ?x85) true)))))))))
(check-sat)
; query 16: function Quantization_and_coding, block 111, name %114
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in108_64 () (_ BitVec 64))
(assert
 (let ((?x173 (ite (bvslt (_ bv0 64) in108_64) (_ bv1 1) (_ bv0 1))))
(let (($x95 (= (_ bv1 1) ?x173)))
(let ((?x454 (ite $x95 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x423 (or false false false)))
(let (($x202 (or $x423 (ite $x95 false false))))
(and (not $x202) (or $x202 (and (distinct ?x454 ?x454) true)))))))))
(check-sat)
; query 17: function Quantization_and_coding, block 111, name %115
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in108_64 () (_ BitVec 64))
(assert
 (let ((?x173 (ite (bvslt (_ bv0 64) in108_64) (_ bv1 1) (_ bv0 1))))
(let (($x95 (= (_ bv1 1) ?x173)))
(let ((?x454 (ite $x95 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x262 ((_ sign_extend 32) ?x454)))
(let (($x423 (or false false false)))
(let (($x202 (or $x423 (ite $x95 false false))))
(let (($x418 (or $x202 false)))
(and (not $x418) (or $x418 (and (distinct ?x262 ?x262) true)))))))))))
(check-sat)
; query 18: function RPE_grid_positioning, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x308 (or false false)))
(let (($x1919 (not $x308)))
(and $x1919 (or $x308 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 19: function RPE_grid_positioning, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x167 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x196 (and (distinct ?x167 ?x167) true)))
(let (($x308 (or false false)))
(let (($x441 (or false $x308 false)))
(and (not $x441) (or $x441 $x196)))))))
(check-sat)
; query 20: function gsm_L_add, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x137 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x423 (or false false false)))
(let (($x143 (not $x423)))
(and $x143 (or $x423 (and (distinct ?x137 ?x137) true)))))))
(check-sat)
; query 21: function gsm_L_add, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x386 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvadd in0_64 in1_64))) true)))
(let (($x286 (or false false (or $x386))))
(let (($x432 (or $x286 (and (distinct (bvadd in0_64 in1_64) (bvadd in0_64 in1_64)) true))))
(and (not $x286) $x432)))))
(check-sat)
; query 22: function gsm_L_add, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x145 (bvadd in0_64 (_ bv1 64))))
(let ((?x9 (bvsub (_ bv0 64) ?x145)))
(let (($x422 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x145)) ((_ sign_extend 1) ?x9)) true)))
(let ((?x64 ((_ sign_extend 1) ?x145)))
(let (($x82 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x64) true)))))
(let (($x98 (or false $x82 (or $x422))))
(and (not $x98) (or $x98 (and (distinct ?x9 ?x9) true))))))))))
(check-sat)
; query 23: function gsm_L_add, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x115 (bvadd in1_64 (_ bv1 64))))
(let ((?x364 ((_ sign_extend 1) ?x115)))
(let (($x54 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x364) true)))))
(and (not $x54) (or $x54 (and (distinct ?x115 ?x115) true)))))))
(check-sat)
; query 24: function gsm_L_add, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x115 (bvadd in1_64 (_ bv1 64))))
(let ((?x6 (bvsub (_ bv0 64) ?x115)))
(let (($x80 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x115)) ((_ sign_extend 1) ?x6)) true)))
(let ((?x364 ((_ sign_extend 1) ?x115)))
(let (($x54 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x364) true)))))
(let (($x81 (or false $x54 (or $x80))))
(and (not $x81) (or $x81 (and (distinct ?x6 ?x6) true))))))))))
(check-sat)
; query 25: function gsm_L_add, block 8, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x115 (bvadd in1_64 (_ bv1 64))))
(let ((?x6 (bvsub (_ bv0 64) ?x115)))
(let ((?x145 (bvadd in0_64 (_ bv1 64))))
(let ((?x9 (bvsub (_ bv0 64) ?x145)))
(let ((?x52 (bvadd ?x9 ?x6)))
(let (($x80 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x115)) ((_ sign_extend 1) ?x6)) true)))
(let ((?x364 ((_ sign_extend 1) ?x115)))
(let (($x54 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x364) true)))))
(let (($x81 (or false $x54 (or $x80))))
(let (($x422 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x145)) ((_ sign_extend 1) ?x9)) true)))
(let ((?x64 ((_ sign_extend 1) ?x145)))
(let (($x82 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x64) true)))))
(let (($x98 (or false $x82 (or $x422))))
(let (($x99 (or $x98 $x81 false)))
(and (not $x99) (or $x99 (and (distinct ?x52 ?x52) true))))))))))))))))))
(check-sat)
; query 26: function gsm_L_add, block 8, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x115 (bvadd in1_64 (_ bv1 64))))
(let ((?x6 (bvsub (_ bv0 64) ?x115)))
(let ((?x145 (bvadd in0_64 (_ bv1 64))))
(let ((?x9 (bvsub (_ bv0 64) ?x145)))
(let ((?x52 (bvadd ?x9 ?x6)))
(let ((?x15 (ite (bvuge ?x52 (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x80 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x115)) ((_ sign_extend 1) ?x6)) true)))
(let ((?x364 ((_ sign_extend 1) ?x115)))
(let (($x54 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x364) true)))))
(let (($x81 (or false $x54 (or $x80))))
(let (($x422 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x145)) ((_ sign_extend 1) ?x9)) true)))
(let ((?x64 ((_ sign_extend 1) ?x145)))
(let (($x82 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x64) true)))))
(let (($x98 (or false $x82 (or $x422))))
(let (($x99 (or $x98 $x81 false)))
(let (($x78 (or $x99 false false)))
(and (not $x78) (or $x78 (and (distinct ?x15 ?x15) true))))))))))))))))))))
(check-sat)
; query 27: function gsm_L_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x145 (bvadd in0_64 (_ bv1 64))))
(let ((?x64 ((_ sign_extend 1) ?x145)))
(let (($x82 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x64) true)))))
(and (not $x82) (or $x82 (and (distinct ?x145 ?x145) true)))))))
(check-sat)
; query 28: function gsm_L_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x138 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x423 (or false false false)))
(let (($x143 (not $x423)))
(and $x143 (or $x423 (and (distinct ?x138 ?x138) true)))))))
(check-sat)
; query 29: function gsm_L_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x610 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x423 (or false false false)))
(let (($x143 (not $x423)))
(and $x143 (or $x423 (and (distinct ?x610 ?x610) true)))))))
(check-sat)
; query 30: function gsm_L_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x138 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x423 (or false false false)))
(let (($x143 (not $x423)))
(and $x143 (or $x423 (and (distinct ?x138 ?x138) true)))))))
(check-sat)
; query 31: function gsm_L_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x138 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x70 ((_ zero_extend 31) ?x138)))
(let (($x423 (or false false false)))
(let (($x21 (or $x423 false)))
(let (($x120 (not $x21)))
(and $x120 (or $x21 (and (distinct ?x70 ?x70) true)))))))))
(check-sat)
; query 32: function gsm_L_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x138 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x70 ((_ zero_extend 31) ?x138)))
(let ((?x150 (bvsub (_ bv0 32) ?x70)))
(let (($x359 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x70)) ((_ sign_extend 1) ?x150)) true)))
(let (($x423 (or false false false)))
(let (($x21 (or $x423 false)))
(let (($x433 (or false $x21 (or $x359))))
(and (not $x433) (or $x433 (and (distinct ?x150 ?x150) true)))))))))))
(check-sat)
; query 33: function gsm_L_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x138 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x70 ((_ zero_extend 31) ?x138)))
(let ((?x150 (bvsub (_ bv0 32) ?x70)))
(let ((?x131 ((_ sign_extend 32) ?x150)))
(let (($x359 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x70)) ((_ sign_extend 1) ?x150)) true)))
(let (($x423 (or false false false)))
(let (($x21 (or $x423 false)))
(let (($x433 (or false $x21 (or $x359))))
(let (($x26 (or $x433 false)))
(and (not $x26) (or $x26 (and (distinct ?x131 ?x131) true)))))))))))))
(check-sat)
; query 34: function gsm_L_asr, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x319 (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x423 (or false false false)))
(let (($x143 (not $x423)))
(and $x143 (or $x423 (and (distinct ?x319 ?x319) true)))))))
(check-sat)
; query 35: function gsm_L_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x610 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x423 (or false false false)))
(let (($x143 (not $x423)))
(and $x143 (or $x423 (and (distinct ?x610 ?x610) true)))))))
(check-sat)
; query 36: function gsm_L_sub, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x137 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x423 (or false false false)))
(let (($x143 (not $x423)))
(and $x143 (or $x423 (and (distinct ?x137 ?x137) true)))))))
(check-sat)
; query 37: function gsm_L_sub, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x37 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvsub in0_64 in1_64))) true)))
(let (($x431 (or false false (or $x37))))
(let (($x1813 (or $x431 (and (distinct (bvsub in0_64 in1_64) (bvsub in0_64 in1_64)) true))))
(and (not $x431) $x1813)))))
(check-sat)
; query 38: function gsm_L_sub, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x115 (bvadd in1_64 (_ bv1 64))))
(let ((?x6 (bvsub (_ bv0 64) ?x115)))
(let (($x80 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x115)) ((_ sign_extend 1) ?x6)) true)))
(let ((?x364 ((_ sign_extend 1) ?x115)))
(let (($x54 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x364) true)))))
(let (($x81 (or false $x54 (or $x80))))
(and (not $x81) (or $x81 (and (distinct ?x6 ?x6) true))))))))))
(check-sat)
; query 39: function gsm_L_sub, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x115 (bvadd in1_64 (_ bv1 64))))
(let ((?x6 (bvsub (_ bv0 64) ?x115)))
(let ((?x1856 (bvadd in0_64 ?x6)))
(let (($x80 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x115)) ((_ sign_extend 1) ?x6)) true)))
(let ((?x364 ((_ sign_extend 1) ?x115)))
(let (($x54 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x364) true)))))
(let (($x81 (or false $x54 (or $x80))))
(let (($x1846 (or false $x81 false)))
(and (not $x1846) (or $x1846 (and (distinct ?x1856 ?x1856) true))))))))))))
(check-sat)
; query 40: function gsm_L_sub, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x163 (ite (bvuge (bvadd in0_64 (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64)))) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x80 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) (bvadd in1_64 (_ bv1 64)))) ((_ sign_extend 1) (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64))))) true)))
(let ((?x115 (bvadd in1_64 (_ bv1 64))))
(let ((?x364 ((_ sign_extend 1) ?x115)))
(let (($x54 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x364) true)))))
(let (($x81 (or false $x54 (or $x80))))
(let (($x1846 (or false $x81 false)))
(let (($x235 (or $x1846 false false)))
(and (not $x235) (or $x235 (and (distinct ?x163 ?x163) true))))))))))))
(check-sat)
; query 41: function gsm_L_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x115 (bvadd in1_64 (_ bv1 64))))
(let ((?x364 ((_ sign_extend 1) ?x115)))
(let (($x54 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x364) true)))))
(and (not $x54) (or $x54 (and (distinct ?x115 ?x115) true)))))))
(check-sat)
; query 42: function gsm_L_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x554 (ite (bvsle (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x423 (or false false false)))
(let (($x143 (not $x423)))
(and $x143 (or $x423 (and (distinct ?x554 ?x554) true)))))))
(check-sat)
; query 43: function gsm_abs, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x308 (or false false)))
(let (($x1919 (not $x308)))
(and $x1919 (or $x308 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 44: function gsm_abs, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x300 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x308 (or false false)))
(let (($x141 (or $x308 false false)))
(let (($x1681 (not $x141)))
(and $x1681 (or $x141 (and (distinct ?x300 ?x300) true))))))))
(check-sat)
; query 45: function gsm_abs, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x308 (or false false)))
(let (($x1919 (not $x308)))
(and $x1919 (or $x308 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 46: function gsm_abs, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1825 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x308 (or false false)))
(let (($x141 (or $x308 false false)))
(let (($x1681 (not $x141)))
(and $x1681 (or $x141 (and (distinct ?x1825 ?x1825) true))))))))
(check-sat)
; query 47: function gsm_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x308 (or false false)))
(let (($x1919 (not $x308)))
(and $x1919 (or $x308 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 48: function gsm_add, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x308 (or false false)))
(let (($x1919 (not $x308)))
(and $x1919 (or $x308 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 49: function gsm_add, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1858 ((_ sign_extend 48) in1_16)))
(let ((?x1874 ((_ sign_extend 48) in0_16)))
(let ((?x1842 (bvadd ?x1874 ?x1858)))
(let (($x190 (and (distinct (bvadd ((_ sign_extend 1) ?x1874) ((_ sign_extend 1) ?x1858)) ((_ sign_extend 1) ?x1842)) true)))
(let (($x308 (or false false)))
(let (($x504 (or $x308 $x308 (or $x190))))
(and (not $x504) (or $x504 (and (distinct ?x1842 ?x1842) true))))))))))
(check-sat)
; query 50: function gsm_add, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x618 (ite (bvsgt (_ bv18446744073709518848 64) (bvadd ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x1858 ((_ sign_extend 48) in1_16)))
(let ((?x122 ((_ sign_extend 1) ?x1858)))
(let ((?x1874 ((_ sign_extend 48) in0_16)))
(let ((?x279 ((_ sign_extend 1) ?x1874)))
(let (($x308 (or false false)))
(let (($x504 (or $x308 $x308 (or (and (distinct (bvadd ?x279 ?x122) ((_ sign_extend 1) (bvadd ?x1874 ?x1858))) true)))))
(let (($x421 (or $x504 false false)))
(and (not $x421) (or $x421 (and (distinct ?x618 ?x618) true))))))))))))
(check-sat)
; query 51: function gsm_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x290 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x423 (or false false false)))
(let (($x143 (not $x423)))
(and $x143 (or $x423 (and (distinct ?x290 ?x290) true)))))))
(check-sat)
; query 52: function gsm_asr, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x28 (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x423 (or false false false)))
(let (($x143 (not $x423)))
(and $x143 (or $x423 (and (distinct ?x28 ?x28) true)))))))
(check-sat)
; query 53: function gsm_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x308 (or false false)))
(let (($x1919 (not $x308)))
(and $x1919 (or $x308 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 54: function gsm_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1825 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x308 (or false false)))
(let (($x141 (or $x308 false false)))
(let (($x1681 (not $x141)))
(and $x1681 (or $x141 (and (distinct ?x1825 ?x1825) true))))))))
(check-sat)
; query 55: function gsm_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1825 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1829 ((_ zero_extend 31) ?x1825)))
(let (($x308 (or false false)))
(let (($x141 (or $x308 false false)))
(let (($x1794 (or $x141 false)))
(and (not $x1794) (or $x1794 (and (distinct ?x1829 ?x1829) true)))))))))
(check-sat)
; query 56: function gsm_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1825 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1829 ((_ zero_extend 31) ?x1825)))
(let ((?x1786 (bvsub (_ bv0 32) ?x1829)))
(let (($x1861 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1829)) ((_ sign_extend 1) ?x1786)) true)))
(let (($x308 (or false false)))
(let (($x141 (or $x308 false false)))
(let (($x1794 (or $x141 false)))
(let (($x666 (or false $x1794 (or $x1861))))
(and (not $x666) (or $x666 (and (distinct ?x1786 ?x1786) true))))))))))))
(check-sat)
; query 57: function gsm_asr, block 4, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1825 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1829 ((_ zero_extend 31) ?x1825)))
(let ((?x1786 (bvsub (_ bv0 32) ?x1829)))
(let ((?x1901 ((_ extract 15 0) ?x1786)))
(let (($x1861 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1829)) ((_ sign_extend 1) ?x1786)) true)))
(let (($x308 (or false false)))
(let (($x141 (or $x308 false false)))
(let (($x1794 (or $x141 false)))
(let (($x666 (or false $x1794 (or $x1861))))
(let (($x1881 (or $x666 false)))
(and (not $x1881) (or $x1881 (and (distinct ?x1901 ?x1901) true))))))))))))))
(check-sat)
; query 58: function gsm_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x290 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x423 (or false false false)))
(let (($x143 (not $x423)))
(and $x143 (or $x423 (and (distinct ?x290 ?x290) true)))))))
(check-sat)
; query 59: function gsm_debug_longwords, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in15_32 () (_ BitVec 32))
(assert
 (let ((?x231 (ite (bvslt in15_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x423 (or false false false)))
(let (($x143 (not $x423)))
(and $x143 (or $x423 (and (distinct ?x231 ?x231) true)))))))
(check-sat)
; query 60: function gsm_debug_words, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in16_32 () (_ BitVec 32))
(assert
 (let ((?x797 (ite (bvslt in16_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x423 (or false false false)))
(let (($x143 (not $x423)))
(and $x143 (or $x423 (and (distinct ?x797 ?x797) true)))))))
(check-sat)
; query 61: function gsm_div, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x308 (or false false)))
(let (($x1919 (not $x308)))
(and $x1919 (or $x308 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 62: function gsm_div, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x308 (or false false)))
(let (($x1919 (not $x308)))
(and $x1919 (or $x308 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 63: function gsm_div, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x308 (or false false)))
(let (($x1919 (not $x308)))
(and $x1919 (or $x308 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 64: function gsm_div, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x167 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x196 (and (distinct ?x167 ?x167) true)))
(let (($x308 (or false false)))
(let (($x141 (or $x308 false false)))
(let (($x1681 (not $x141)))
(and $x1681 (or $x141 $x196))))))))
(check-sat)
; query 65: function gsm_norm, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x138 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x423 (or false false false)))
(let (($x143 (not $x423)))
(and $x143 (or $x423 (and (distinct ?x138 (ite (bvsge (_ bv18446744072635809792 64) in0_64) (_ bv1 1) (_ bv0 1))) true)))))))
(check-sat)
; query 66: function gsm_norm, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x469 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x423 (or false false false)))
(let (($x143 (not $x423)))
(and $x143 (or $x423 (and (distinct ?x469 ?x469) true)))))))
(check-sat)
; query 67: function gsm_norm, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x469 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x567 (bvxor ?x469 (_ bv1 1))))
(let (($x423 (or false false false)))
(let (($x102 (or $x423 false false)))
(and (not $x102) (or $x102 (and (distinct ?x567 ?x567) true))))))))
(check-sat)
; query 68: function gsm_norm, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x469 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x567 (bvxor ?x469 (_ bv1 1))))
(let ((?x2041 ((_ zero_extend 31) ?x567)))
(let (($x423 (or false false false)))
(let (($x102 (or $x423 false false)))
(let (($x378 (or $x102 false)))
(and (not $x378) (or $x378 (and (distinct ?x2041 ?x2041) true))))))))))
(check-sat)
; query 69: function gsm_norm, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x469 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x567 (bvxor ?x469 (_ bv1 1))))
(let ((?x2041 ((_ zero_extend 31) ?x567)))
(let ((?x317 ((_ sign_extend 32) ?x2041)))
(let (($x423 (or false false false)))
(let (($x102 (or $x423 false false)))
(let (($x378 (or $x102 false)))
(let (($x1991 (or $x378 false)))
(and (not $x1991) (or $x1991 (and (distinct ?x317 ?x317) true))))))))))))
(check-sat)
; query 70: function gsm_norm, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x469 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x567 (bvxor ?x469 (_ bv1 1))))
(let ((?x2041 ((_ zero_extend 31) ?x567)))
(let ((?x317 ((_ sign_extend 32) ?x2041)))
(let ((?x1789 (ite (and (distinct (_ bv0 64) ?x317) true) (_ bv1 1) (_ bv0 1))))
(let (($x423 (or false false false)))
(let (($x102 (or $x423 false false)))
(let (($x378 (or $x102 false)))
(let (($x1991 (or $x378 false)))
(let (($x1801 (or $x1991 false false)))
(and (not $x1801) (or $x1801 (and (distinct ?x1789 ?x1789) true))))))))))))))
(check-sat)
; query 71: function gsm_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x308 (or false false)))
(let (($x1919 (not $x308)))
(and $x1919 (or $x308 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 72: function gsm_sub, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x308 (or false false)))
(let (($x1919 (not $x308)))
(and $x1919 (or $x308 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 73: function gsm_sub, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1858 ((_ sign_extend 48) in1_16)))
(let ((?x1874 ((_ sign_extend 48) in0_16)))
(let ((?x1889 (bvsub ?x1874 ?x1858)))
(let (($x1899 (and (distinct (bvsub ((_ sign_extend 1) ?x1874) ((_ sign_extend 1) ?x1858)) ((_ sign_extend 1) ?x1889)) true)))
(let (($x308 (or false false)))
(let (($x1926 (or $x308 $x308 (or $x1899))))
(and (not $x1926) (or $x1926 (and (distinct ?x1889 ?x1889) true))))))))))
(check-sat)
; query 74: function gsm_sub, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1936 (ite (bvsgt (_ bv18446744073709518848 64) (bvsub ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x1858 ((_ sign_extend 48) in1_16)))
(let ((?x122 ((_ sign_extend 1) ?x1858)))
(let ((?x1874 ((_ sign_extend 48) in0_16)))
(let ((?x279 ((_ sign_extend 1) ?x1874)))
(let (($x308 (or false false)))
(let (($x1926 (or $x308 $x308 (or (and (distinct (bvsub ?x279 ?x122) ((_ sign_extend 1) (bvsub ?x1874 ?x1858))) true)))))
(let (($x1933 (or $x1926 false false)))
(and (not $x1933) (or $x1933 (and (distinct ?x1936 ?x1936) true))))))))))))
(check-sat)
