; OptiPhase-Sigma refinement certificate for sweep K52-R3-141
; query 0: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x467 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x2768 (or false false false)))
(let (($x1566 (not $x2768)))
(and $x1566 (or $x2768 (and (distinct ?x467 ?x467) true)))))))
(check-sat)
; query 1: function s162, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x701 (ite (bvslt (_ bv0 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x2768 (or false false false)))
(let (($x1566 (not $x2768)))
(and $x1566 (or $x2768 (and (distinct ?x701 ?x701) true)))))))
(check-sat)
; query 2: function s276, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x49 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x132 (or false false (or $x49))))
(and (not $x132) (or $x132 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 3: function s276, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x62 (ite (bvsgt (_ bv16000 32) (bvadd in.0_32 (_ bv1 32))) (_ bv1 1) (_ bv0 1))))
(let (($x49 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x132 (or false false (or $x49))))
(let (($x142 (or $x132 false false)))
(and (not $x142) (or $x142 (and (distinct ?x62 ?x62) true))))))))
(check-sat)
; query 4: function set1d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x1711 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x2768 (or false false false)))
(let (($x1566 (not $x2768)))
(and $x1566 (or $x2768 (and (distinct ?x1711 ?x1711) true)))))))
(check-sat)
; query 5: function set1ds, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x685 (ite (= (_ bv4294967295 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x2768 (or false false false)))
(let (($x1566 (not $x2768)))
(and $x1566 (or $x2768 (and (distinct ?x685 ?x685) true)))))))
(check-sat)
; query 6: function set2d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x1711 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x2768 (or false false false)))
(let (($x1566 (not $x2768)))
(and $x1566 (or $x2768 (and (distinct ?x1711 ?x1711) true)))))))
(check-sat)
