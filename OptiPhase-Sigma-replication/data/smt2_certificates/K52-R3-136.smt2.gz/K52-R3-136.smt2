; OptiPhase-Sigma refinement certificate for sweep K52-R3-136
; query 0: function check, block 103, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x1261 (ite (= (_ bv22 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x775 (or false false false)))
(let (($x606 (not $x775)))
(and $x606 (or $x775 (and (distinct ?x1261 (ite (= (_ bv0 32) in0_32) (_ bv1 1) (_ bv0 1))) true)))))))
(check-sat)
; query 1: function check, block 109, name %110
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x6 (ite (= (_ bv33 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x775 (or false false false)))
(let (($x606 (not $x775)))
(and $x606 (or $x775 (and (distinct ?x6 (ite (= (_ bv12 32) in0_32) (_ bv1 1) (_ bv0 1))) true)))))))
(check-sat)
; query 2: function check, block 67, name %68
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x2159 (ite (= (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x775 (or false false false)))
(let (($x606 (not $x775)))
(and $x606 (or $x775 (and (distinct (ite (= (_ bv1 32) in0_32) (_ bv1 1) (_ bv0 1)) ?x2159) true)))))))
(check-sat)
; query 3: function check, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x2657 (ite (= (_ bv4 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x775 (or false false false)))
(let (($x606 (not $x775)))
(and $x606 (or $x775 (and (distinct (ite (= (_ bv2 32) in0_32) (_ bv1 1) (_ bv0 1)) ?x2657) true)))))))
(check-sat)
; query 4: function check, block 79, name %80
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x2656 (ite (= (_ bv5 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let ((?x2159 (ite (= (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x775 (or false false false)))
(let (($x606 (not $x775)))
(and $x606 (or $x775 (and (distinct ?x2159 ?x2656) true))))))))
(check-sat)
; query 5: function check, block 85, name %86
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x550 (ite (= (_ bv11 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let ((?x2657 (ite (= (_ bv4 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x775 (or false false false)))
(let (($x606 (not $x775)))
(and $x606 (or $x775 (and (distinct ?x2657 ?x550) true))))))))
(check-sat)
; query 6: function check, block 91, name %92
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x1261 (ite (= (_ bv22 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let ((?x2656 (ite (= (_ bv5 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x775 (or false false false)))
(let (($x606 (not $x775)))
(and $x606 (or $x775 (and (distinct ?x2656 ?x1261) true))))))))
(check-sat)
; query 7: function check, block 97, name %98
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x6 (ite (= (_ bv33 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let ((?x550 (ite (= (_ bv11 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x775 (or false false false)))
(let (($x606 (not $x775)))
(and $x606 (or $x775 (and (distinct ?x550 ?x6) true))))))))
(check-sat)
; query 8: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x290 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x775 (or false false false)))
(let (($x606 (not $x775)))
(and $x606 (or $x775 (and (distinct ?x290 ?x290) true)))))))
(check-sat)
; query 9: function s162, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x362 (ite (bvslt (_ bv0 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x775 (or false false false)))
(let (($x606 (not $x775)))
(and $x606 (or $x775 (and (distinct ?x362 ?x362) true)))))))
(check-sat)
; query 10: function s276, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x178 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x343 (or false false (or $x178))))
(and (not $x343) (or $x343 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 11: function s276, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x576 (ite (bvsgt (_ bv16000 32) (bvadd in.0_32 (_ bv1 32))) (_ bv1 1) (_ bv0 1))))
(let (($x178 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x343 (or false false (or $x178))))
(let (($x1580 (or $x343 false false)))
(and (not $x1580) (or $x1580 (and (distinct ?x576 ?x576) true))))))))
(check-sat)
; query 12: function set1d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x467 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x775 (or false false false)))
(let (($x606 (not $x775)))
(and $x606 (or $x775 (and (distinct ?x467 ?x467) true)))))))
(check-sat)
; query 13: function set1ds, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x443 (ite (= (_ bv4294967295 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x775 (or false false false)))
(let (($x606 (not $x775)))
(and $x606 (or $x775 (and (distinct ?x443 ?x443) true)))))))
(check-sat)
; query 14: function set2d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x467 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x775 (or false false false)))
(let (($x606 (not $x775)))
(and $x606 (or $x775 (and (distinct ?x467 ?x467) true)))))))
(check-sat)
