; OptiPhase-Sigma refinement certificate for sweep K01-R3-297
; query 0: function xmalloc, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in7_32 () (_ BitVec 32))
(assert
 (let ((?x11 (ite (and (distinct (_ bv0 32) in7_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x116 (or false false false)))
(and (not $x116) (or $x116 (and (distinct ?x11 ?x11) true))))))
(check-sat)
