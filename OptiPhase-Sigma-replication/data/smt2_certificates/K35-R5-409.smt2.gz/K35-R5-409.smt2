; OptiPhase-Sigma refinement certificate for sweep K35-R5-409
; query 0: function getint, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x19 (and (distinct (ite (bvsle (_ bv48 32) in.02_32) (_ bv1 1) (_ bv0 1)) (ite (bvsgt (_ bv58 32) in.02_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x486 (or false false false)))
(and (not $x486) (or $x486 $x19)))))
(check-sat)
