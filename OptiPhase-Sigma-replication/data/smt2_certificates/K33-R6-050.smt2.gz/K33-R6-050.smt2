; OptiPhase-Sigma refinement certificate for sweep K33-R6-050
; query 0: function edge_draw, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let ((?x292 (ite (= (_ bv0 32) in4_32) (_ bv1 1) (_ bv0 1))))
(let (($x34 (or false false false)))
(let (($x307 (not $x34)))
(and $x307 (or $x34 (and (distinct ?x292 ?x292) true)))))))
(check-sat)
; query 1: function getint, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x371 (and (distinct (ite (bvsle (_ bv48 32) in.02_32) (_ bv1 1) (_ bv0 1)) (ite (bvsgt (_ bv58 32) in.02_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x34 (or false false false)))
(let (($x307 (not $x34)))
(and $x307 (or $x34 $x371))))))
(check-sat)
