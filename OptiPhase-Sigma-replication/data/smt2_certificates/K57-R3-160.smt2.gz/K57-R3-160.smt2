; OptiPhase-Sigma refinement certificate for sweep K57-R3-160
; query 0: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x1835 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x460 (or false false false)))
(let (($x404 (not $x460)))
(and $x404 (or $x460 (and (distinct ?x1835 ?x1835) true)))))))
(check-sat)
; query 1: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x460 (or false false false)))
(let (($x404 (not $x460)))
(and $x404 (or $x460 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 2: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x776 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x460 (or false false false)))
(let (($x404 (not $x460)))
(and $x404 (or $x460 (and (distinct ?x776 ?x776) true)))))))
(check-sat)
; query 3: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x192 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x460 (or false false false)))
(let (($x404 (not $x460)))
(and $x404 (or $x460 (and (distinct ?x192 ?x192) true)))))))
(check-sat)
