; OptiPhase-Sigma refinement certificate for sweep K39-R2-082
; query 0: function BF_cbc_encrypt, block 126, name %127
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.010_64 () (_ BitVec 64))
(assert
 (let (($x20 (and (distinct (bvsub ((_ sign_extend 1) in.010_64) ((_ sign_extend 1) (_ bv8 64))) ((_ sign_extend 1) (bvsub in.010_64 (_ bv8 64)))) true)))
(let (($x51 (or false false (or $x20))))
(and (not $x51) (or $x51 (and (distinct (bvsub in.010_64 (_ bv8 64)) (bvsub in.010_64 (_ bv8 64))) true))))))
(check-sat)
; query 1: function BF_cbc_encrypt, block 128, name %129
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.010_64 () (_ BitVec 64))
(assert
 (let ((?x143 (ite (and (distinct (_ bv18446744073709551608 64) in.010_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x7 (or false false false)))
(let (($x58 (not $x7)))
(and $x58 (or $x7 (and (distinct ?x143 ?x143) true)))))))
(check-sat)
; query 2: function BF_cbc_encrypt, block 366, name %367
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.111_64 () (_ BitVec 64))
(assert
 (let (($x329 (and (distinct (bvsub ((_ sign_extend 1) in.111_64) ((_ sign_extend 1) (_ bv8 64))) ((_ sign_extend 1) (bvsub in.111_64 (_ bv8 64)))) true)))
(let (($x18 (or false false (or $x329))))
(and (not $x18) (or $x18 (and (distinct (bvsub in.111_64 (_ bv8 64)) (bvsub in.111_64 (_ bv8 64))) true))))))
(check-sat)
; query 3: function BF_cbc_encrypt, block 368, name %369
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.111_64 () (_ BitVec 64))
(assert
 (let ((?x217 (ite (and (distinct (_ bv18446744073709551608 64) in.111_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x7 (or false false false)))
(let (($x58 (not $x7)))
(and $x58 (or $x7 (and (distinct ?x217 ?x217) true)))))))
(check-sat)
; query 4: function BF_cfb64_encrypt, block 111, name %112
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.18_32 () (_ BitVec 32))
(assert
 (let ((?x190 (ite (= (_ bv0 32) in.18_32) (_ bv1 1) (_ bv0 1))))
(let (($x7 (or false false false)))
(let (($x58 (not $x7)))
(and $x58 (or $x7 (and (distinct ?x190 ?x190) true)))))))
(check-sat)
; query 5: function BF_cfb64_encrypt, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.07_32 () (_ BitVec 32))
(assert
 (let ((?x39 (ite (= (_ bv0 32) in.07_32) (_ bv1 1) (_ bv0 1))))
(let (($x7 (or false false false)))
(let (($x58 (not $x7)))
(and $x58 (or $x7 (and (distinct ?x39 ?x39) true)))))))
(check-sat)
; query 6: function BF_ofb64_encrypt, block 135, name %136
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x1566 (ite (and (distinct (_ bv0 32) in.02_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x7 (or false false false)))
(let (($x58 (not $x7)))
(and $x58 (or $x7 (and (distinct ?x1566 ?x1566) true)))))))
(check-sat)
; query 7: function BF_ofb64_encrypt, block 82, name %83
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x205 (ite (= (_ bv0 32) in.04_32) (_ bv1 1) (_ bv0 1))))
(let (($x7 (or false false false)))
(let (($x58 (not $x7)))
(and $x58 (or $x7 (and (distinct ?x205 ?x205) true)))))))
(check-sat)
; query 8: function BF_set_key, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x414 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x252 (or false false (or $x414))))
(and (not $x252) (or $x252 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 9: function BF_set_key, block 69, name %70
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.13_32 () (_ BitVec 32))
(assert
 (let (($x624 (and (distinct (bvadd ((_ sign_extend 1) in.13_32) ((_ sign_extend 1) (_ bv2 32))) ((_ sign_extend 1) (bvadd in.13_32 (_ bv2 32)))) true)))
(let (($x170 (or false false (or $x624))))
(and (not $x170) (or $x170 (and (distinct (bvadd in.13_32 (_ bv2 32)) (bvadd in.13_32 (_ bv2 32))) true))))))
(check-sat)
; query 10: function BF_set_key, block 87, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.24_32 () (_ BitVec 32))
(assert
 (let (($x203 (and (distinct (bvadd ((_ sign_extend 1) in.24_32) ((_ sign_extend 1) (_ bv2 32))) ((_ sign_extend 1) (bvadd in.24_32 (_ bv2 32)))) true)))
(let (($x554 (or false false (or $x203))))
(and (not $x554) (or $x554 (and (distinct (bvadd in.24_32 (_ bv2 32)) (bvadd in.24_32 (_ bv2 32))) true))))))
(check-sat)
; query 11: function main, block 124, name %125
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let ((?x215 (ite (bvsgt (_ bv40 32) in.2_32) (_ bv1 1) (_ bv0 1))))
(let (($x7 (or false false false)))
(let (($x58 (not $x7)))
(and $x58 (or $x7 (and (distinct ?x215 ?x215) true)))))))
(check-sat)
; query 12: function main, block 147, name %148
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x85 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x191 (or false false (or $x85))))
(and (not $x191) (or $x191 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 13: function main, block 60, name %61
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x115 (or false false)))
(and (not $x115) (or $x115 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 14: function main, block 60, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x183 (ite (bvsge (_ bv57 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x115 (or false false)))
(let (($x32 (or $x115 false false)))
(let (($x502 (not $x32)))
(and $x502 (or $x32 (and (distinct ?x183 ?x183) true))))))))
(check-sat)
; query 15: function main, block 63, name %64
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x7 (or false false false)))
(let (($x56 (or $x7 (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x56) (or $x56 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvshl in.01_32 (_ bv4 32))) true))))))
(check-sat)
; query 16: function main, block 63, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x115 (or false false)))
(and (not $x115) (or $x115 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 17: function main, block 63, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x111 ((_ sign_extend 24) in57_8)))
(let ((?x258 (bvshl in.01_32 (_ bv4 32))))
(let ((?x72 (bvadd ?x258 ?x111)))
(let ((?x366 ((_ sign_extend 1) ?x72)))
(let (($x115 (or false false)))
(let (($x7 (or false false false)))
(let (($x56 (or $x7 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x130 (or $x56 $x115 (or (and (distinct (bvadd ((_ sign_extend 1) ?x258) ((_ sign_extend 1) ?x111)) ?x366) true)))))
(and (not $x130) (or $x130 (and (distinct ?x72 ?x72) true))))))))))))
(check-sat)
; query 18: function main, block 63, name %67
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x111 ((_ sign_extend 24) in57_8)))
(let ((?x258 (bvshl in.01_32 (_ bv4 32))))
(let ((?x72 (bvadd ?x258 ?x111)))
(let ((?x655 (bvsub ?x72 (_ bv48 32))))
(let (($x946 (and (distinct (bvsub ((_ sign_extend 1) ?x72) ((_ sign_extend 1) (_ bv48 32))) ((_ sign_extend 1) ?x655)) true)))
(let ((?x366 ((_ sign_extend 1) ?x72)))
(let (($x115 (or false false)))
(let (($x7 (or false false false)))
(let (($x56 (or $x7 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x130 (or $x56 $x115 (or (and (distinct (bvadd ((_ sign_extend 1) ?x258) ((_ sign_extend 1) ?x111)) ?x366) true)))))
(let (($x1551 (or $x130 false (or $x946))))
(and (not $x1551) (or $x1551 (and (distinct ?x655 ?x655) true)))))))))))))))
(check-sat)
; query 19: function main, block 68, name %69
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x115 (or false false)))
(and (not $x115) (or $x115 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 20: function main, block 68, name %70
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x1429 (ite (bvsle (_ bv65 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x115 (or false false)))
(let (($x32 (or $x115 false false)))
(let (($x502 (not $x32)))
(and $x502 (or $x32 (and (distinct ?x1429 ?x1429) true))))))))
(check-sat)
; query 21: function main, block 71, name %72
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x115 (or false false)))
(and (not $x115) (or $x115 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 22: function main, block 71, name %73
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x107 (ite (bvsge (_ bv70 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x115 (or false false)))
(let (($x32 (or $x115 false false)))
(let (($x502 (not $x32)))
(and $x502 (or $x32 (and (distinct ?x107 ?x107) true))))))))
(check-sat)
; query 23: function main, block 74, name %75
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x7 (or false false false)))
(let (($x56 (or $x7 (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x56) (or $x56 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvshl in.01_32 (_ bv4 32))) true))))))
(check-sat)
; query 24: function main, block 74, name %76
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x115 (or false false)))
(and (not $x115) (or $x115 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 25: function main, block 74, name %77
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x111 ((_ sign_extend 24) in57_8)))
(let ((?x258 (bvshl in.01_32 (_ bv4 32))))
(let ((?x72 (bvadd ?x258 ?x111)))
(let ((?x366 ((_ sign_extend 1) ?x72)))
(let (($x115 (or false false)))
(let (($x7 (or false false false)))
(let (($x56 (or $x7 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x130 (or $x56 $x115 (or (and (distinct (bvadd ((_ sign_extend 1) ?x258) ((_ sign_extend 1) ?x111)) ?x366) true)))))
(and (not $x130) (or $x130 (and (distinct ?x72 ?x72) true))))))))))))
(check-sat)
; query 26: function main, block 74, name %78
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x111 ((_ sign_extend 24) in57_8)))
(let ((?x258 (bvshl in.01_32 (_ bv4 32))))
(let ((?x72 (bvadd ?x258 ?x111)))
(let ((?x156 (bvsub ?x72 (_ bv65 32))))
(let ((?x1226 ((_ sign_extend 1) ?x156)))
(let ((?x366 ((_ sign_extend 1) ?x72)))
(let (($x115 (or false false)))
(let (($x7 (or false false false)))
(let (($x56 (or $x7 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x130 (or $x56 $x115 (or (and (distinct (bvadd ((_ sign_extend 1) ?x258) ((_ sign_extend 1) ?x111)) ?x366) true)))))
(let (($x817 (or $x130 false (or (and (distinct (bvsub ?x366 ((_ sign_extend 1) (_ bv65 32))) ?x1226) true)))))
(and (not $x817) (or $x817 (and (distinct ?x156 ?x156) true)))))))))))))))
(check-sat)
; query 27: function main, block 74, name %79
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x111 ((_ sign_extend 24) in57_8)))
(let ((?x258 (bvshl in.01_32 (_ bv4 32))))
(let ((?x72 (bvadd ?x258 ?x111)))
(let ((?x156 (bvsub ?x72 (_ bv65 32))))
(let ((?x1046 (bvadd ?x156 (_ bv10 32))))
(let (($x319 (and (distinct (bvadd ((_ sign_extend 1) ?x156) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x1046)) true)))
(let ((?x1226 ((_ sign_extend 1) ?x156)))
(let ((?x366 ((_ sign_extend 1) ?x72)))
(let (($x115 (or false false)))
(let (($x7 (or false false false)))
(let (($x56 (or $x7 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x130 (or $x56 $x115 (or (and (distinct (bvadd ((_ sign_extend 1) ?x258) ((_ sign_extend 1) ?x111)) ?x366) true)))))
(let (($x817 (or $x130 false (or (and (distinct (bvsub ?x366 ((_ sign_extend 1) (_ bv65 32))) ?x1226) true)))))
(let (($x385 (or $x817 false (or $x319))))
(and (not $x385) (or $x385 (and (distinct ?x1046 ?x1046) true))))))))))))))))))
(check-sat)
