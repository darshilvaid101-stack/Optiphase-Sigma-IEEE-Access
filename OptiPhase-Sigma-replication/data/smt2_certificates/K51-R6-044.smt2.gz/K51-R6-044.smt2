; OptiPhase-Sigma refinement certificate for sweep K51-R6-044
; query 0: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x74 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x94 (or false false false)))
(let (($x125 (not $x94)))
(and $x125 (or $x94 (and (distinct ?x74 ?x74) true)))))))
(check-sat)
; query 1: function set1d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x6 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x94 (or false false false)))
(let (($x125 (not $x94)))
(and $x125 (or $x94 (and (distinct ?x6 ?x6) true)))))))
(check-sat)
; query 2: function set1ds, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x2371 (ite (= (_ bv4294967295 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x94 (or false false false)))
(let (($x125 (not $x94)))
(and $x125 (or $x94 (and (distinct ?x2371 ?x2371) true)))))))
(check-sat)
; query 3: function set2d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x6 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x94 (or false false false)))
(let (($x125 (not $x94)))
(and $x125 (or $x94 (and (distinct ?x6 ?x6) true)))))))
(check-sat)
