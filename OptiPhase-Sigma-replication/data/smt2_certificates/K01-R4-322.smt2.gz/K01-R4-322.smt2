; OptiPhase-Sigma refinement certificate for sweep K01-R4-322
