; OptiPhase-Sigma refinement certificate for sweep K56-R4-314
; query 0: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x339 (or false false)))
(let (($x75 (not $x339)))
(and $x75 (or $x339 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 1: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x347 ((_ sign_extend 16) in3_16)))
(let ((?x110 (bvand ?x347 (_ bv127 32))))
(let (($x339 (or false false)))
(let (($x1287 (or $x339 false false)))
(let (($x24 (not $x1287)))
(and $x24 (or $x1287 (and (distinct ?x110 ?x110) true)))))))))
(check-sat)
; query 2: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x347 ((_ sign_extend 16) in3_16)))
(let ((?x110 (bvand ?x347 (_ bv127 32))))
(let ((?x1309 ((_ extract 15 0) ?x110)))
(let (($x339 (or false false)))
(let (($x1287 (or $x339 false false)))
(let (($x1284 (or $x1287 false)))
(let (($x173 (not $x1284)))
(and $x173 (or $x1284 (and (distinct ?x1309 ?x1309) true)))))))))))
(check-sat)
; query 3: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x339 (or false false)))
(let (($x75 (not $x339)))
(and $x75 (or $x339 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 4: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x50 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x339 (or false false)))
(let (($x1287 (or $x339 false false)))
(let (($x24 (not $x1287)))
(and $x24 (or $x1287 (and (distinct ?x50 ?x50) true))))))))
(check-sat)
; query 5: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x323 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x119 (or false false false)))
(let (($x7 (not $x119)))
(and $x7 (or $x119 (and (distinct ?x323 ?x323) true)))))))
(check-sat)
; query 6: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x141 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x119 (or false false false)))
(let (($x7 (not $x119)))
(and $x7 (or $x119 (and (distinct ?x141 ?x141) true)))))))
(check-sat)
; query 7: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x119 (or false false false)))
(let (($x7 (not $x119)))
(and $x7 (or $x119 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 8: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x558 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x494 (or false false (or $x558))))
(and (not $x494) (or $x494 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 9: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x180 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x746 ((_ zero_extend 31) ?x180)))
(let ((?x639 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x278 ((_ zero_extend 31) ?x639)))
(let ((?x102 (bvand ?x278 ?x746)))
(let ((?x42 (ite (and (distinct (_ bv0 32) ?x102) true) (_ bv1 1) (_ bv0 1))))
(let ((?x523 ((_ zero_extend 63) ?x42)))
(let (($x339 (or false false)))
(let (($x1287 (or $x339 false false)))
(let (($x1284 (or $x1287 false)))
(let (($x365 (or $x1284 $x1284 false)))
(let (($x868 (or $x365 false false)))
(let (($x832 (or $x868 false)))
(and (not $x832) (or $x832 (and (distinct ?x523 ?x523) true)))))))))))))))))
(check-sat)
; query 10: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x180 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x746 ((_ zero_extend 31) ?x180)))
(let ((?x639 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x278 ((_ zero_extend 31) ?x639)))
(let ((?x102 (bvand ?x278 ?x746)))
(let ((?x42 (ite (and (distinct (_ bv0 32) ?x102) true) (_ bv1 1) (_ bv0 1))))
(let (($x181 (= (_ bv1 1) ?x42)))
(let ((?x721 (ite $x181 (_ bv1 32) (_ bv0 32))))
(let (($x339 (or false false)))
(let (($x1287 (or $x339 false false)))
(let (($x1284 (or $x1287 false)))
(let (($x365 (or $x1284 $x1284 false)))
(let (($x868 (or $x365 false false)))
(let (($x423 (or $x868 (ite $x181 false false))))
(and (not $x423) (or $x423 (and (distinct ?x721 ?x721) true))))))))))))))))))
(check-sat)
; query 11: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x180 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x746 ((_ zero_extend 31) ?x180)))
(let ((?x639 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x278 ((_ zero_extend 31) ?x639)))
(let ((?x102 (bvand ?x278 ?x746)))
(let ((?x42 (ite (and (distinct (_ bv0 32) ?x102) true) (_ bv1 1) (_ bv0 1))))
(let (($x181 (= (_ bv1 1) ?x42)))
(let ((?x721 (ite $x181 (_ bv1 32) (_ bv0 32))))
(let ((?x16 ((_ extract 7 0) ?x721)))
(let (($x339 (or false false)))
(let (($x1287 (or $x339 false false)))
(let (($x1284 (or $x1287 false)))
(let (($x365 (or $x1284 $x1284 false)))
(let (($x868 (or $x365 false false)))
(let (($x423 (or $x868 (ite $x181 false false))))
(let (($x153 (or $x423 false)))
(and (not $x153) (or $x153 (and (distinct ?x16 ?x16) true))))))))))))))))))))
(check-sat)
; query 12: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x339 (or false false)))
(let (($x75 (not $x339)))
(and $x75 (or $x339 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 13: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x639 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x339 (or false false)))
(let (($x1287 (or $x339 false false)))
(let (($x24 (not $x1287)))
(and $x24 (or $x1287 (and (distinct ?x639 ?x639) true))))))))
(check-sat)
; query 14: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x639 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x278 ((_ zero_extend 31) ?x639)))
(let (($x339 (or false false)))
(let (($x1287 (or $x339 false false)))
(let (($x1284 (or $x1287 false)))
(let (($x173 (not $x1284)))
(and $x173 (or $x1284 (and (distinct ?x278 ?x278) true))))))))))
(check-sat)
; query 15: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x339 (or false false)))
(let (($x75 (not $x339)))
(and $x75 (or $x339 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 16: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x180 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x339 (or false false)))
(let (($x1287 (or $x339 false false)))
(let (($x24 (not $x1287)))
(and $x24 (or $x1287 (and (distinct ?x180 ?x180) true))))))))
(check-sat)
; query 17: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x180 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x746 ((_ zero_extend 31) ?x180)))
(let (($x339 (or false false)))
(let (($x1287 (or $x339 false false)))
(let (($x1284 (or $x1287 false)))
(let (($x173 (not $x1284)))
(and $x173 (or $x1284 (and (distinct ?x746 ?x746) true))))))))))
(check-sat)
; query 18: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x180 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x746 ((_ zero_extend 31) ?x180)))
(let ((?x639 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x278 ((_ zero_extend 31) ?x639)))
(let ((?x102 (bvand ?x278 ?x746)))
(let (($x339 (or false false)))
(let (($x1287 (or $x339 false false)))
(let (($x1284 (or $x1287 false)))
(let (($x365 (or $x1284 $x1284 false)))
(and (not $x365) (or $x365 (and (distinct ?x102 ?x102) true)))))))))))))
(check-sat)
; query 19: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x180 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x746 ((_ zero_extend 31) ?x180)))
(let ((?x639 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x278 ((_ zero_extend 31) ?x639)))
(let ((?x102 (bvand ?x278 ?x746)))
(let ((?x42 (ite (and (distinct (_ bv0 32) ?x102) true) (_ bv1 1) (_ bv0 1))))
(let (($x339 (or false false)))
(let (($x1287 (or $x339 false false)))
(let (($x1284 (or $x1287 false)))
(let (($x365 (or $x1284 $x1284 false)))
(let (($x868 (or $x365 false false)))
(and (not $x868) (or $x868 (and (distinct ?x42 ?x42) true)))))))))))))))
(check-sat)
; query 20: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x103 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x119 (or false false false)))
(let (($x7 (not $x119)))
(and $x7 (or $x119 (and (distinct ?x103 ?x103) true)))))))
(check-sat)
