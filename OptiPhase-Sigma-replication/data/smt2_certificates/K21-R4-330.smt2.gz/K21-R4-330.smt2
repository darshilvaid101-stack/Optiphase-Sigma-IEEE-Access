; OptiPhase-Sigma refinement certificate for sweep K21-R4-330
