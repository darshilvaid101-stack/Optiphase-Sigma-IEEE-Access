; OptiPhase-Sigma refinement certificate for sweep K43-R2-082
; query 0: function crc32buf, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_64 () (_ BitVec 64))
(assert
 (let (($x32 (or false false false)))
(let (($x342 (not $x32)))
(and $x342 (or $x32 (and (distinct (bvxor in.02_64 (_ bv18446744073709551615 64)) (bvxor in.02_64 (_ bv18446744073709551615 64))) true))))))
(check-sat)
; query 1: function main, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x640 (ite (and (distinct (_ bv0 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x32 (or false false false)))
(let (($x342 (not $x32)))
(and $x342 (or $x32 (and (distinct ?x640 ?x640) true)))))))
(check-sat)
; query 2: function main, block 17, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x640 (ite (and (distinct (_ bv0 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let ((?x90 ((_ zero_extend 31) ?x640)))
(let (($x32 (or false false false)))
(let (($x198 (or $x32 false)))
(and (not $x198) (or $x198 (and (distinct ?x90 ?x90) true))))))))
(check-sat)
