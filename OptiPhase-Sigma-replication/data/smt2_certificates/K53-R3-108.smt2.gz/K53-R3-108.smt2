; OptiPhase-Sigma refinement certificate for sweep K53-R3-108
; query 0: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x96 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x20 (or false false false)))
(and (not $x20) (or $x20 (and (distinct ?x96 ?x96) true))))))
(check-sat)
