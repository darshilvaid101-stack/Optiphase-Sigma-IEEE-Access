; OptiPhase-Sigma refinement certificate for sweep K45-R3-233
; query 0: function Index_to_frequency, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x69 (ite (bvuge in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x115 (or false false false)))
(let (($x168 (not $x115)))
(and $x168 (or $x115 (and (distinct ?x69 ?x69) true)))))))
(check-sat)
; query 1: function IsPowerOfTwo, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x35 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x115 (or false false false)))
(let (($x168 (not $x115)))
(and $x168 (or $x115 (and (distinct ?x35 ?x35) true)))))))
(check-sat)
; query 2: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x35 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x115 (or false false false)))
(let (($x168 (not $x115)))
(and $x168 (or $x115 (and (distinct ?x35 ?x35) true)))))))
(check-sat)
; query 3: function main, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x146 (ite (= (_ bv4 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x115 (or false false false)))
(let (($x168 (not $x115)))
(and $x168 (or $x115 (and (distinct ?x146 ?x146) true)))))))
(check-sat)
; query 4: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x40 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x115 (or false false false)))
(let (($x168 (not $x115)))
(and $x168 (or $x115 (and (distinct ?x40 ?x40) true)))))))
(check-sat)
