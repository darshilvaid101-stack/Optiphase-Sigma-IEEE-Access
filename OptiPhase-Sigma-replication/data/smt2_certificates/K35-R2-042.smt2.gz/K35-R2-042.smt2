; OptiPhase-Sigma refinement certificate for sweep K35-R2-042
; query 0: function corner_draw, block 11, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x693 (ite (= (_ bv0 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x292 (or false false false)))
(let (($x225 (not $x292)))
(and $x225 (or $x292 (and (distinct ?x693 ?x693) true)))))))
(check-sat)
; query 1: function edge_draw, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let ((?x37 (ite (= (_ bv0 32) in4_32) (_ bv1 1) (_ bv0 1))))
(let (($x292 (or false false false)))
(let (($x225 (not $x292)))
(and $x225 (or $x292 (and (distinct ?x37 ?x37) true)))))))
(check-sat)
; query 2: function enlarge, block 106, name %107
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x33 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x297 (or false false (or $x33))))
(and (not $x297) (or $x297 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 3: function enlarge, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x294 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x165 (or false false (or $x294))))
(and (not $x165) (or $x165 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 4: function getint, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x74 (ite (bvsle (_ bv48 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x292 (or false false false)))
(let (($x225 (not $x292)))
(and $x225 (or $x292 (and (distinct ?x74 ?x74) true)))))))
(check-sat)
; query 5: function getint, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x54 (ite (bvsge (_ bv57 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x292 (or false false false)))
(let (($x225 (not $x292)))
(and $x225 (or $x292 (and (distinct ?x54 ?x54) true)))))))
(check-sat)
; query 6: function getint, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in26_32 () (_ BitVec 32))
(assert
 (let ((?x175 (ite (bvsgt (_ bv48 32) in26_32) (_ bv1 1) (_ bv0 1))))
(let (($x292 (or false false false)))
(let (($x225 (not $x292)))
(and $x225 (or $x292 (and (distinct ?x175 ?x175) true)))))))
(check-sat)
; query 7: function getint, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in26_32 () (_ BitVec 32))
(assert
 (let ((?x155 (ite (bvslt (_ bv57 32) in26_32) (_ bv1 1) (_ bv0 1))))
(let (($x292 (or false false false)))
(let (($x225 (not $x292)))
(and $x225 (or $x292 (and (distinct ?x155 ?x155) true)))))))
(check-sat)
; query 8: function getint, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x16 (ite (= (_ bv4294967295 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x292 (or false false false)))
(let (($x225 (not $x292)))
(and $x225 (or $x292 (and (distinct ?x16 ?x16) true)))))))
(check-sat)
; query 9: function int_to_uchar, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_32 () (_ BitVec 32))
(assert
 (let (($x83 (and (distinct (bvadd ((_ sign_extend 1) in.03_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.03_32 (_ bv1 32)))) true)))
(let (($x25 (or false false (or $x83))))
(and (not $x25) (or $x25 (and (distinct (bvadd in.03_32 (_ bv1 32)) (bvadd in.03_32 (_ bv1 32))) true))))))
(check-sat)
; query 10: function int_to_uchar, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.14_32 () (_ BitVec 32))
(assert
 (let (($x77 (and (distinct (bvadd ((_ sign_extend 1) in.14_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.14_32 (_ bv1 32)))) true)))
(let (($x58 (or false false (or $x77))))
(and (not $x58) (or $x58 (and (distinct (bvadd in.14_32 (_ bv1 32)) (bvadd in.14_32 (_ bv1 32))) true))))))
(check-sat)
; query 11: function main, block 35, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x38 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x59 (or false false (or $x38))))
(and (not $x59) (or $x59 (and (distinct (bvadd in.020_32 (_ bv1 32)) (bvadd in.020_32 (_ bv1 32))) true))))))
(check-sat)
; query 12: function main, block 35, name %37
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let ((?x146 (ite (bvsge (bvadd in.020_32 (_ bv1 32)) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x38 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x59 (or false false (or $x38))))
(let (($x131 (or $x59 false false)))
(and (not $x131) (or $x131 (and (distinct ?x146 ?x146) true))))))))
(check-sat)
; query 13: function median, block 103, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x22 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x102 (or false false (or $x22))))
(and (not $x102) (or $x102 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 14: function median, block 106, name %107
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x294 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x165 (or false false (or $x294))))
(and (not $x165) (or $x165 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 15: function setup_brightness_lut, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x294 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x165 (or false false (or $x294))))
(and (not $x165) (or $x165 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 16: function susan_smoothing, block 21, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x107 (ite (= (_ bv0 32) (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x292 (or false false false)))
(let (($x225 (not $x292)))
(and $x225 (or $x292 (and (distinct ?x107 ?x107) true)))))))
(check-sat)
