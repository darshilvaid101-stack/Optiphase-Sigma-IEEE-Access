; OptiPhase-Sigma refinement certificate for sweep K48-R3-142
; query 0: function Decoding_of_the_coded_Log_Area_Ratios, block 107, name %108
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in104_64 () (_ BitVec 64))
(assert
 (let ((?x39 (ite (bvslt (_ bv0 64) in104_64) (_ bv1 1) (_ bv0 1))))
(let (($x29 (or false false false)))
(let (($x64 (not $x29)))
(and $x64 (or $x29 (and (distinct ?x39 ?x39) true)))))))
(check-sat)
; query 1: function Decoding_of_the_coded_Log_Area_Ratios, block 107, name %109
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in104_64 () (_ BitVec 64))
(assert
 (let (($x198 (and (distinct ((_ zero_extend 63) (ite (bvslt (_ bv0 64) in104_64) (_ bv1 1) (_ bv0 1))) (ite (= (_ bv1 1) (ite (bvslt (_ bv0 64) in104_64) (_ bv1 1) (_ bv0 1))) (_ bv32767 64) (_ bv18446744073709518848 64))) true)))
(let (($x29 (or false false false)))
(let (($x26 (or $x29 (ite (= (_ bv1 1) (ite (bvslt (_ bv0 64) in104_64) (_ bv1 1) (_ bv0 1))) false false))))
(and (not (or $x29 false)) (or $x26 $x198))))))
(check-sat)
; query 2: function Decoding_of_the_coded_Log_Area_Ratios, block 219, name %220
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in216_64 () (_ BitVec 64))
(assert
 (let (($x524 (and (distinct (ite (bvsge (_ bv18446744073709518848 64) in216_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv0 64) in216_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x29 (or false false false)))
(let (($x64 (not $x29)))
(and $x64 (or $x29 $x524))))))
(check-sat)
; query 3: function alaw_input, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x155 (and (distinct (bvadd ((_ zero_extend 1) in.02_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x418 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x269 (or (or false false (or $x418 $x155)) (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))
(and (not (or false false (or $x418))) $x269)))))
(check-sat)
; query 4: function alaw_input, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let ((?x130 (ite (= (_ bv4294967295 32) in.1_32) (_ bv1 1) (_ bv0 1))))
(let (($x29 (or false false false)))
(let (($x64 (not $x29)))
(and $x64 (or $x29 (and (distinct ?x130 ?x130) true)))))))
(check-sat)
; query 5: function gsm_L_add, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let (($x111 (and (distinct (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv18446744073709551615 64) in1_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x29 (or false false false)))
(let (($x64 (not $x29)))
(and $x64 (or $x29 $x111))))))
(check-sat)
; query 6: function gsm_L_add, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x66 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvadd in0_64 in1_64))) true)))
(let (($x71 (or false false (or $x66))))
(let (($x399 (or $x71 (and (distinct (bvadd in0_64 in1_64) (bvadd in0_64 in1_64)) true))))
(and (not $x71) $x399)))))
(check-sat)
; query 7: function gsm_L_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x566 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x29 (or false false false)))
(let (($x64 (not $x29)))
(and $x64 (or $x29 (and (distinct ?x566 ?x566) true)))))))
(check-sat)
; query 8: function gsm_L_asl, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x725 (and (distinct (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvsgt (_ bv4294967265 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x29 (or false false false)))
(let (($x64 (not $x29)))
(and $x64 (or $x29 $x725))))))
(check-sat)
; query 9: function gsm_L_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x392 (and (distinct (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv31 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x29 (or false false false)))
(let (($x64 (not $x29)))
(and $x64 (or $x29 $x392))))))
(check-sat)
; query 10: function gsm_L_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x392 (and (distinct (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv31 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x29 (or false false false)))
(let (($x64 (not $x29)))
(and $x64 (or $x29 $x392))))))
(check-sat)
; query 11: function gsm_L_sub, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x150 (bvsub in0_64 in1_64)))
(let (($x321 (and (distinct ?x150 ?x150) true)))
(let (($x94 (and (distinct (bvsub ((_ zero_extend 1) in0_64) ((_ zero_extend 1) in1_64)) ((_ zero_extend 1) ?x150)) true)))
(let (($x503 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) ?x150)) true)))
(let (($x126 (or false false (or $x503))))
(let (($x146 (not $x126)))
(and $x146 (or (or false false (or $x94)) $x321)))))))))
(check-sat)
; query 12: function gsm_L_sub, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let (($x111 (and (distinct (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv18446744073709551615 64) in1_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x29 (or false false false)))
(let (($x64 (not $x29)))
(and $x64 (or $x29 $x111))))))
(check-sat)
; query 13: function gsm_L_sub, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x150 (bvsub in0_64 in1_64)))
(let (($x321 (and (distinct ?x150 ?x150) true)))
(let (($x503 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) ?x150)) true)))
(let (($x126 (or false false (or $x503))))
(let (($x146 (not $x126)))
(and $x146 (or $x126 $x321))))))))
(check-sat)
; query 14: function gsm_L_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x614 (and (distinct (ite (bvsle (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv18446744073709551615 64) in0_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x29 (or false false false)))
(let (($x64 (not $x29)))
(and $x64 (or $x29 $x614))))))
(check-sat)
; query 15: function gsm_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_64 () (_ BitVec 64))
(assert
 (let ((?x309 (ite (bvslt (_ bv32767 64) in5_64) (_ bv1 1) (_ bv0 1))))
(let (($x29 (or false false false)))
(let (($x64 (not $x29)))
(and $x64 (or $x29 (and (distinct ?x309 ?x309) true)))))))
(check-sat)
; query 16: function gsm_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x165 (or false false)))
(let (($x51 (not $x165)))
(and $x51 (or $x165 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 17: function gsm_add, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x165 (or false false)))
(let (($x51 (not $x165)))
(and $x51 (or $x165 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 18: function gsm_add, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x17 ((_ sign_extend 48) in1_16)))
(let ((?x235 ((_ sign_extend 48) in0_16)))
(let ((?x650 (bvadd ?x235 ?x17)))
(let (($x23 (and (distinct (bvadd ((_ sign_extend 1) ?x235) ((_ sign_extend 1) ?x17)) ((_ sign_extend 1) ?x650)) true)))
(let (($x165 (or false false)))
(let (($x93 (or $x165 $x165 (or $x23))))
(and (not $x93) (or $x93 (and (distinct ?x650 ?x650) true))))))))))
(check-sat)
; query 19: function gsm_add, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x22 (ite (bvsgt (_ bv18446744073709518848 64) (bvadd ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x17 ((_ sign_extend 48) in1_16)))
(let ((?x386 ((_ sign_extend 1) ?x17)))
(let ((?x235 ((_ sign_extend 48) in0_16)))
(let ((?x33 ((_ sign_extend 1) ?x235)))
(let (($x165 (or false false)))
(let (($x93 (or $x165 $x165 (or (and (distinct (bvadd ?x33 ?x386) ((_ sign_extend 1) (bvadd ?x235 ?x17))) true)))))
(let (($x112 (or $x93 false false)))
(and (not $x112) (or $x112 (and (distinct ?x22 ?x22) true))))))))))))
(check-sat)
; query 20: function gsm_asl, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x341 (and (distinct (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvsgt (_ bv4294967281 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x29 (or false false false)))
(let (($x64 (not $x29)))
(and $x64 (or $x29 $x341))))))
(check-sat)
; query 21: function gsm_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x1579 (and (distinct (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv15 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x29 (or false false false)))
(let (($x64 (not $x29)))
(and $x64 (or $x29 $x1579))))))
(check-sat)
; query 22: function gsm_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x1579 (and (distinct (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv15 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x29 (or false false false)))
(let (($x64 (not $x29)))
(and $x64 (or $x29 $x1579))))))
(check-sat)
; query 23: function gsm_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_64 () (_ BitVec 64))
(assert
 (let ((?x309 (ite (bvslt (_ bv32767 64) in5_64) (_ bv1 1) (_ bv0 1))))
(let (($x29 (or false false false)))
(let (($x64 (not $x29)))
(and $x64 (or $x29 (and (distinct ?x309 ?x309) true)))))))
(check-sat)
; query 24: function gsm_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x165 (or false false)))
(let (($x51 (not $x165)))
(and $x51 (or $x165 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 25: function gsm_sub, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x165 (or false false)))
(let (($x51 (not $x165)))
(and $x51 (or $x165 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 26: function gsm_sub, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x17 ((_ sign_extend 48) in1_16)))
(let ((?x235 ((_ sign_extend 48) in0_16)))
(let ((?x240 (bvsub ?x235 ?x17)))
(let (($x315 (and (distinct (bvsub ((_ sign_extend 1) ?x235) ((_ sign_extend 1) ?x17)) ((_ sign_extend 1) ?x240)) true)))
(let (($x165 (or false false)))
(let (($x1442 (or $x165 $x165 (or $x315))))
(and (not $x1442) (or $x1442 (and (distinct ?x240 ?x240) true))))))))))
(check-sat)
; query 27: function gsm_sub, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x585 (ite (bvsgt (_ bv18446744073709518848 64) (bvsub ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x17 ((_ sign_extend 48) in1_16)))
(let ((?x386 ((_ sign_extend 1) ?x17)))
(let ((?x235 ((_ sign_extend 48) in0_16)))
(let ((?x33 ((_ sign_extend 1) ?x235)))
(let (($x165 (or false false)))
(let (($x1442 (or $x165 $x165 (or (and (distinct (bvsub ?x33 ?x386) ((_ sign_extend 1) (bvsub ?x235 ?x17))) true)))))
(let (($x602 (or $x1442 false false)))
(and (not $x602) (or $x602 (and (distinct ?x585 ?x585) true))))))))))))
(check-sat)
; query 28: function ulaw_input, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x155 (and (distinct (bvadd ((_ zero_extend 1) in.02_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x418 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x269 (or (or false false (or $x418 $x155)) (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))
(and (not (or false false (or $x418))) $x269)))))
(check-sat)
; query 29: function ulaw_input, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let ((?x130 (ite (= (_ bv4294967295 32) in.1_32) (_ bv1 1) (_ bv0 1))))
(let (($x29 (or false false false)))
(let (($x64 (not $x29)))
(and $x64 (or $x29 (and (distinct ?x130 ?x130) true)))))))
(check-sat)
