; OptiPhase-Sigma refinement certificate for sweep K44-R2-007
; query 0: function Index_to_frequency, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x120 (ite (bvuge in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x150 (or false false false)))
(let (($x71 (not $x150)))
(and $x71 (or $x150 (and (distinct ?x120 ?x120) true)))))))
(check-sat)
; query 1: function IsPowerOfTwo, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x150 (or false false false)))
(let (($x71 (not $x150)))
(and $x71 (or $x150 (and (distinct (bvsub in0_32 (_ bv1 32)) (bvsub in0_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function IsPowerOfTwo, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x98 (bvsub in0_32 (_ bv1 32))))
(let ((?x128 (bvand in0_32 ?x98)))
(let (($x150 (or false false false)))
(let (($x308 (or false $x150 false)))
(and (not $x308) (or $x308 (and (distinct ?x128 ?x128) true))))))))
(check-sat)
; query 3: function IsPowerOfTwo, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x26 (ite (and (distinct (_ bv0 32) (bvand in0_32 (bvsub in0_32 (_ bv1 32)))) true) (_ bv1 1) (_ bv0 1))))
(let (($x150 (or false false false)))
(let (($x308 (or false $x150 false)))
(let (($x173 (or $x308 false false)))
(and (not $x173) (or $x173 (and (distinct ?x26 ?x26) true))))))))
(check-sat)
; query 4: function IsPowerOfTwo, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x559 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x150 (or false false false)))
(let (($x71 (not $x150)))
(and $x71 (or $x150 (and (distinct ?x559 ?x559) true)))))))
(check-sat)
; query 5: function NumberOfBitsNeeded, block 13, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x150 (or false false false)))
(let (($x71 (not $x150)))
(and $x71 (or $x150 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 6: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x559 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x150 (or false false false)))
(let (($x71 (not $x150)))
(and $x71 (or $x150 (and (distinct ?x559 ?x559) true)))))))
(check-sat)
; query 7: function ReverseBits, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x150 (or false false false)))
(let (($x71 (not $x150)))
(and $x71 (or $x150 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function ReverseBits, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x150 (or false false false)))
(let (($x322 (or $x150 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x594 (not $x322)))
(and $x594 (or $x322 (and (distinct (bvshl in.01_32 (_ bv1 32)) (bvshl in.01_32 (_ bv1 32))) true)))))))
(check-sat)
; query 9: function ReverseBits, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x150 (or false false false)))
(let (($x71 (not $x150)))
(and $x71 (or $x150 (and (distinct (bvand in.0_32 (_ bv1 32)) (bvand in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 10: function ReverseBits, block 5, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x321 (bvand in.0_32 (_ bv1 32))))
(let ((?x90 (bvshl in.01_32 (_ bv1 32))))
(let ((?x196 (bvor ?x90 ?x321)))
(let (($x150 (or false false false)))
(let (($x322 (or $x150 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x366 (or $x322 $x150 false)))
(and (not $x366) (or $x366 (and (distinct ?x196 ?x196) true))))))))))
(check-sat)
; query 11: function ReverseBits, block 5, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x150 (or false false false)))
(let (($x322 (or $x150 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x594 (not $x322)))
(and $x594 (or $x322 (and (distinct (bvlshr in.0_32 (_ bv1 32)) (bvlshr in.0_32 (_ bv1 32))) true)))))))
(check-sat)
; query 12: function main, block 110, name %111
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x150 (or false false false)))
(let (($x71 (not $x150)))
(and $x71 (or $x150 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 13: function main, block 113, name %114
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x150 (or false false false)))
(let (($x71 (not $x150)))
(and $x71 (or $x150 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 14: function main, block 126, name %127
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let (($x150 (or false false false)))
(let (($x71 (not $x150)))
(and $x71 (or $x150 (and (distinct (bvadd in.2_32 (_ bv1 32)) (bvadd in.2_32 (_ bv1 32))) true))))))
(check-sat)
; query 15: function main, block 139, name %140
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.3_32 () (_ BitVec 32))
(assert
 (let (($x150 (or false false false)))
(let (($x71 (not $x150)))
(and $x71 (or $x150 (and (distinct (bvadd in.3_32 (_ bv1 32)) (bvadd in.3_32 (_ bv1 32))) true))))))
(check-sat)
; query 16: function main, block 57, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x150 (or false false false)))
(let (($x71 (not $x150)))
(and $x71 (or $x150 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 17: function main, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x64 (ite (= (_ bv4 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x150 (or false false false)))
(let (($x71 (not $x150)))
(and $x71 (or $x150 (and (distinct ?x64 ?x64) true)))))))
(check-sat)
; query 18: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x172 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x150 (or false false false)))
(let (($x71 (not $x150)))
(and $x71 (or $x150 (and (distinct ?x172 ?x172) true)))))))
(check-sat)
