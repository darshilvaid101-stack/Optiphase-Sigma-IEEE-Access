; OptiPhase-Sigma refinement certificate for sweep K38-R6-045
; query 0: function BF_cbc_encrypt, block 126, name %127
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.010_64 () (_ BitVec 64))
(assert
 (let (($x147 (and (distinct (bvsub ((_ sign_extend 1) in.010_64) ((_ sign_extend 1) (_ bv8 64))) ((_ sign_extend 1) (bvsub in.010_64 (_ bv8 64)))) true)))
(let (($x75 (or false false (or $x147))))
(and (not $x75) (or $x75 (and (distinct (bvsub in.010_64 (_ bv8 64)) (bvsub in.010_64 (_ bv8 64))) true))))))
(check-sat)
; query 1: function BF_cbc_encrypt, block 128, name %129
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.010_64 () (_ BitVec 64))
(assert
 (let ((?x26 (ite (and (distinct (_ bv18446744073709551608 64) in.010_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x39 (or false false false)))
(let (($x392 (not $x39)))
(and $x392 (or $x39 (and (distinct ?x26 ?x26) true)))))))
(check-sat)
; query 2: function BF_cfb64_encrypt, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.07_32 () (_ BitVec 32))
(assert
 (let ((?x29 (ite (= (_ bv0 32) in.07_32) (_ bv1 1) (_ bv0 1))))
(let (($x39 (or false false false)))
(let (($x392 (not $x39)))
(and $x392 (or $x39 (and (distinct ?x29 ?x29) true)))))))
(check-sat)
; query 3: function BF_set_key, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x321 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x95 (or false false (or $x321))))
(and (not $x95) (or $x95 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 4: function BF_set_key, block 69, name %70
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.13_32 () (_ BitVec 32))
(assert
 (let (($x269 (and (distinct (bvadd ((_ sign_extend 1) in.13_32) ((_ sign_extend 1) (_ bv2 32))) ((_ sign_extend 1) (bvadd in.13_32 (_ bv2 32)))) true)))
(let (($x555 (or false false (or $x269))))
(and (not $x555) (or $x555 (and (distinct (bvadd in.13_32 (_ bv2 32)) (bvadd in.13_32 (_ bv2 32))) true))))))
(check-sat)
; query 5: function BF_set_key, block 87, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.24_32 () (_ BitVec 32))
(assert
 (let (($x37 (and (distinct (bvadd ((_ sign_extend 1) in.24_32) ((_ sign_extend 1) (_ bv2 32))) ((_ sign_extend 1) (bvadd in.24_32 (_ bv2 32)))) true)))
(let (($x23 (or false false (or $x37))))
(and (not $x23) (or $x23 (and (distinct (bvadd in.24_32 (_ bv2 32)) (bvadd in.24_32 (_ bv2 32))) true))))))
(check-sat)
; query 6: function main, block 60, name %61
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x114 (or false false)))
(and (not $x114) (or $x114 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 7: function main, block 60, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x154 (ite (bvsge (_ bv57 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x114 (or false false)))
(let (($x17 (or $x114 false false)))
(let (($x98 (not $x17)))
(and $x98 (or $x17 (and (distinct ?x154 ?x154) true))))))))
(check-sat)
; query 8: function main, block 63, name %64
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x39 (or false false false)))
(and (not (or $x39 (bvuge (_ bv4 32) (_ bv32 32)))) (or $x39 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvmul in.01_32 (_ bv16 32))) true)))))
(check-sat)
; query 9: function main, block 63, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x114 (or false false)))
(and (not $x114) (or $x114 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 10: function main, block 63, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x86 (bvmul in.01_32 (_ bv16 32))))
(let ((?x34 (bvadd ?x86 (_ bv4294967248 32))))
(let ((?x270 ((_ sign_extend 24) in57_8)))
(let ((?x90 (bvshl in.01_32 (_ bv4 32))))
(let ((?x418 (bvadd ?x90 ?x270)))
(let (($x39 (or false false false)))
(let (($x446 (or $x39 false false)))
(let ((?x223 ((_ sign_extend 1) ?x418)))
(let (($x114 (or false false)))
(let (($x68 (or $x39 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x15 (or $x68 $x114 (or (and (distinct (bvadd ((_ sign_extend 1) ?x90) ((_ sign_extend 1) ?x270)) ?x223) true)))))
(let (($x123 (not $x15)))
(and $x123 (or $x446 (and (distinct ?x418 ?x34) true))))))))))))))))
(check-sat)
; query 11: function main, block 63, name %67
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x270 ((_ sign_extend 24) in57_8)))
(let ((?x90 (bvshl in.01_32 (_ bv4 32))))
(let ((?x418 (bvadd ?x90 ?x270)))
(let ((?x25 (bvsub ?x418 (_ bv48 32))))
(let (($x114 (or false false)))
(let (($x39 (or false false false)))
(let (($x446 (or $x39 false false)))
(let (($x82 (or $x446 $x114 false)))
(let (($x44 (or $x82 (and (distinct ?x25 (bvadd (bvadd (bvmul in.01_32 (_ bv16 32)) (_ bv4294967248 32)) ?x270)) true))))
(let (($x102 (and (distinct (bvsub ((_ sign_extend 1) ?x418) ((_ sign_extend 1) (_ bv48 32))) ((_ sign_extend 1) ?x25)) true)))
(let ((?x223 ((_ sign_extend 1) ?x418)))
(let (($x68 (or $x39 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x15 (or $x68 $x114 (or (and (distinct (bvadd ((_ sign_extend 1) ?x90) ((_ sign_extend 1) ?x270)) ?x223) true)))))
(and (not (or $x15 false (or $x102))) $x44)))))))))))))))
(check-sat)
; query 12: function main, block 68, name %69
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x114 (or false false)))
(and (not $x114) (or $x114 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 13: function main, block 68, name %70
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x109 (ite (bvsle (_ bv65 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x114 (or false false)))
(let (($x17 (or $x114 false false)))
(let (($x98 (not $x17)))
(and $x98 (or $x17 (and (distinct ?x109 ?x109) true))))))))
(check-sat)
; query 14: function main, block 71, name %72
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x114 (or false false)))
(and (not $x114) (or $x114 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 15: function main, block 71, name %73
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x151 (ite (bvsge (_ bv70 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x114 (or false false)))
(let (($x17 (or $x114 false false)))
(let (($x98 (not $x17)))
(and $x98 (or $x17 (and (distinct ?x151 ?x151) true))))))))
(check-sat)
; query 16: function main, block 74, name %75
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x39 (or false false false)))
(and (not (or $x39 (bvuge (_ bv4 32) (_ bv32 32)))) (or $x39 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvmul in.01_32 (_ bv16 32))) true)))))
(check-sat)
; query 17: function main, block 74, name %76
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x114 (or false false)))
(and (not $x114) (or $x114 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 18: function main, block 74, name %77
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x86 (bvmul in.01_32 (_ bv16 32))))
(let ((?x80 (bvadd ?x86 (_ bv4294967241 32))))
(let ((?x270 ((_ sign_extend 24) in57_8)))
(let ((?x90 (bvshl in.01_32 (_ bv4 32))))
(let ((?x418 (bvadd ?x90 ?x270)))
(let (($x39 (or false false false)))
(let (($x446 (or $x39 false false)))
(let ((?x223 ((_ sign_extend 1) ?x418)))
(let (($x114 (or false false)))
(let (($x68 (or $x39 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x15 (or $x68 $x114 (or (and (distinct (bvadd ((_ sign_extend 1) ?x90) ((_ sign_extend 1) ?x270)) ?x223) true)))))
(let (($x123 (not $x15)))
(and $x123 (or $x446 (and (distinct ?x418 ?x80) true))))))))))))))))
(check-sat)
; query 19: function main, block 74, name %78
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x270 ((_ sign_extend 24) in57_8)))
(let ((?x90 (bvshl in.01_32 (_ bv4 32))))
(let ((?x418 (bvadd ?x90 ?x270)))
(let ((?x122 (bvsub ?x418 (_ bv65 32))))
(let (($x114 (or false false)))
(let (($x39 (or false false false)))
(let (($x446 (or $x39 false false)))
(let (($x82 (or $x446 $x114 false)))
(let (($x11 (or $x82 (and (distinct ?x122 (bvadd (bvadd (bvmul in.01_32 (_ bv16 32)) (_ bv4294967241 32)) ?x270)) true))))
(let (($x487 (and (distinct (bvsub ((_ sign_extend 1) ?x418) ((_ sign_extend 1) (_ bv65 32))) ((_ sign_extend 1) ?x122)) true)))
(let ((?x223 ((_ sign_extend 1) ?x418)))
(let (($x68 (or $x39 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x15 (or $x68 $x114 (or (and (distinct (bvadd ((_ sign_extend 1) ?x90) ((_ sign_extend 1) ?x270)) ?x223) true)))))
(and (not (or $x15 false (or $x487))) $x11)))))))))))))))
(check-sat)
