; OptiPhase-Sigma refinement certificate for sweep K58-R2-085
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x183 (or false false)))
(let (($x3115 (not $x183)))
(and $x3115 (or $x183 (and (distinct ((_ sign_extend 16) in25_16) ((_ sign_extend 16) in25_16)) true))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let ((?x65 (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))))
(let (($x183 (or false false)))
(let (($x545 (or $x183 false false)))
(let (($x2383 (not $x545)))
(and $x2383 (or $x545 (and (distinct ?x65 ?x65) true))))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x183 (or false false)))
(let (($x3115 (not $x183)))
(and $x3115 (or $x183 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x3659 ((_ sign_extend 16) in3_16)))
(let ((?x2858 (bvand ?x3659 (_ bv127 32))))
(let (($x183 (or false false)))
(let (($x545 (or $x183 false false)))
(let (($x2383 (not $x545)))
(and $x2383 (or $x545 (and (distinct ?x2858 ?x2858) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x3659 ((_ sign_extend 16) in3_16)))
(let ((?x2858 (bvand ?x3659 (_ bv127 32))))
(let ((?x3662 ((_ extract 15 0) ?x2858)))
(let (($x183 (or false false)))
(let (($x545 (or $x183 false false)))
(let (($x2634 (or $x545 false)))
(let (($x3118 (not $x2634)))
(and $x3118 (or $x2634 (and (distinct ?x3662 ?x3662) true)))))))))))
(check-sat)
; query 5: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x183 (or false false)))
(let (($x3115 (not $x183)))
(and $x3115 (or $x183 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 6: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x2369 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x183 (or false false)))
(let (($x545 (or $x183 false false)))
(let (($x2383 (not $x545)))
(and $x2383 (or $x545 (and (distinct ?x2369 ?x2369) true))))))))
(check-sat)
; query 7: function core_bench_list, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x313 (or false false false)))
(let (($x3383 (not $x313)))
(and $x3383 (or $x313 (and (distinct (bvadd in.0_16 (_ bv1 16)) (bvadd in.0_16 (_ bv1 16))) true))))))
(check-sat)
; query 8: function core_bench_state, block 105, name %106
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x313 (or false false false)))
(let (($x3383 (not $x313)))
(and $x3383 (or $x313 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 9: function core_bench_state, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x313 (or false false false)))
(let (($x3383 (not $x313)))
(and $x3383 (or $x313 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 10: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x494 (bvadd in.01_32 (_ bv1 32))))
(let (($x339 (and (distinct ?x494 ?x494) true)))
(let (($x313 (or false false false)))
(let (($x3383 (not $x313)))
(and $x3383 (or $x313 $x339)))))))
(check-sat)
; query 11: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x494 (bvadd in.01_32 (_ bv1 32))))
(let ((?x944 (bvmul ?x494 ?x494)))
(let (($x313 (or false false false)))
(let (($x876 (or $x313 $x313 false)))
(and (not $x876) (or $x876 (and (distinct ?x944 ?x944) true))))))))
(check-sat)
; query 12: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x494 (bvadd in.01_32 (_ bv1 32))))
(let ((?x944 (bvmul ?x494 ?x494)))
(let ((?x12 (bvmul ?x944 (_ bv2 32))))
(let (($x313 (or false false false)))
(let (($x876 (or $x313 $x313 false)))
(let (($x52 (or $x876 false false)))
(and (not $x52) (or $x52 (and (distinct ?x12 ?x12) true))))))))))
(check-sat)
; query 13: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x494 (bvadd in.01_32 (_ bv1 32))))
(let ((?x944 (bvmul ?x494 ?x494)))
(let ((?x12 (bvmul ?x944 (_ bv2 32))))
(let ((?x871 (bvmul ?x12 (_ bv4 32))))
(let (($x313 (or false false false)))
(let (($x876 (or $x313 $x313 false)))
(let (($x52 (or $x876 false false)))
(let (($x310 (or $x52 false false)))
(and (not $x310) (or $x310 (and (distinct ?x871 ?x871) true))))))))))))
(check-sat)
; query 14: function core_init_matrix, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x313 (or false false false)))
(let (($x3383 (not $x313)))
(and $x3383 (or $x313 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 15: function core_init_matrix, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x313 (or false false false)))
(let (($x3383 (not $x313)))
(and $x3383 (or $x313 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 16: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x146 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x313 (or false false false)))
(let (($x3383 (not $x313)))
(and $x3383 (or $x313 (and (distinct ?x146 ?x146) true)))))))
(check-sat)
; query 17: function core_init_state, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_32 () (_ BitVec 32))
(assert
 (let (($x313 (or false false false)))
(let (($x3383 (not $x313)))
(and $x3383 (or $x313 (and (distinct (bvadd in.06_32 (_ bv1 32)) (bvadd in.06_32 (_ bv1 32))) true))))))
(check-sat)
; query 18: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x451 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x313 (or false false false)))
(let (($x3383 (not $x313)))
(and $x3383 (or $x313 (and (distinct ?x451 ?x451) true)))))))
(check-sat)
; query 19: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x313 (or false false false)))
(let (($x3383 (not $x313)))
(and $x3383 (or $x313 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 20: function core_list_init, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x494 (bvadd in.01_32 (_ bv1 32))))
(let (($x339 (and (distinct ?x494 ?x494) true)))
(let (($x313 (or false false false)))
(let (($x3383 (not $x313)))
(and $x3383 (or $x313 $x339)))))))
(check-sat)
; query 21: function core_list_mergesort, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x494 (bvadd in.01_32 (_ bv1 32))))
(let (($x339 (and (distinct ?x494 ?x494) true)))
(let (($x437 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x494)) true)))
(let (($x29 (or false false (or $x437))))
(and (not $x29) (or $x29 $x339)))))))
(check-sat)
; query 22: function core_list_mergesort, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x598 (ite (bvslt (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x313 (or false false false)))
(let (($x3383 (not $x313)))
(and $x3383 (or $x313 (and (distinct ?x598 ?x598) true)))))))
(check-sat)
; query 23: function core_list_mergesort, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.224_32 () (_ BitVec 32))
(assert
 (let ((?x476 (ite (= (_ bv0 32) in.224_32) (_ bv1 1) (_ bv0 1))))
(let (($x313 (or false false false)))
(let (($x3383 (not $x313)))
(and $x3383 (or $x313 (and (distinct ?x476 ?x476) true)))))))
(check-sat)
; query 24: function core_list_mergesort, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x119 (ite (= (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x313 (or false false false)))
(let (($x3383 (not $x313)))
(and $x3383 (or $x313 (and (distinct ?x119 ?x119) true)))))))
(check-sat)
; query 25: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x83 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x134 (or false false (or $x83))))
(and (not $x134) (or $x134 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 26: function core_list_mergesort, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x13 (and (distinct (bvmul ((_ sign_extend 32) in.020_32) ((_ sign_extend 32) (_ bv2 32))) ((_ sign_extend 32) (bvmul in.020_32 (_ bv2 32)))) true)))
(let (($x6 (or false false (or $x13))))
(and (not $x6) (or $x6 (and (distinct (bvmul in.020_32 (_ bv2 32)) (bvmul in.020_32 (_ bv2 32))) true))))))
(check-sat)
; query 27: function core_state_transition, block 102, name %103
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x183 (or false false)))
(let (($x3115 (not $x183)))
(and $x3115 (or $x183 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 28: function core_state_transition, block 102, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x503 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x183 (or false false)))
(let (($x545 (or $x183 false false)))
(let (($x2383 (not $x545)))
(and $x2383 (or $x545 (and (distinct ?x503 ?x503) true))))))))
(check-sat)
; query 29: function core_state_transition, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x183 (or false false)))
(let (($x3115 (not $x183)))
(and $x3115 (or $x183 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 30: function core_state_transition, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x655 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x183 (or false false)))
(let (($x545 (or $x183 false false)))
(let (($x2383 (not $x545)))
(and $x2383 (or $x545 (and (distinct ?x655 ?x655) true))))))))
(check-sat)
; query 31: function core_state_transition, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x183 (or false false)))
(let (($x3115 (not $x183)))
(and $x3115 (or $x183 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 32: function core_state_transition, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x503 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x183 (or false false)))
(let (($x545 (or $x183 false false)))
(let (($x2383 (not $x545)))
(and $x2383 (or $x545 (and (distinct ?x503 ?x503) true))))))))
(check-sat)
; query 33: function core_state_transition, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x183 (or false false)))
(let (($x3115 (not $x183)))
(and $x3115 (or $x183 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 34: function core_state_transition, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x574 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x183 (or false false)))
(let (($x545 (or $x183 false false)))
(let (($x2383 (not $x545)))
(and $x2383 (or $x545 (and (distinct ?x574 ?x574) true))))))))
(check-sat)
; query 35: function core_state_transition, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x183 (or false false)))
(let (($x3115 (not $x183)))
(and $x3115 (or $x183 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 36: function core_state_transition, block 51, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x574 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x183 (or false false)))
(let (($x545 (or $x183 false false)))
(let (($x2383 (not $x545)))
(and $x2383 (or $x545 (and (distinct ?x574 ?x574) true))))))))
(check-sat)
; query 37: function core_state_transition, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x183 (or false false)))
(let (($x3115 (not $x183)))
(and $x3115 (or $x183 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 38: function core_state_transition, block 64, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x574 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x183 (or false false)))
(let (($x545 (or $x183 false false)))
(let (($x2383 (not $x545)))
(and $x2383 (or $x545 (and (distinct ?x574 ?x574) true))))))))
(check-sat)
; query 39: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x3124 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x313 (or false false false)))
(let (($x3383 (not $x313)))
(and $x3383 (or $x313 (and (distinct ?x3124 ?x3124) true)))))))
(check-sat)
; query 40: function core_state_transition, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x183 (or false false)))
(let (($x3115 (not $x183)))
(and $x3115 (or $x183 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 41: function core_state_transition, block 80, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x2843 (ite (= (_ bv69 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x183 (or false false)))
(let (($x545 (or $x183 false false)))
(let (($x2383 (not $x545)))
(and $x2383 (or $x545 (and (distinct ?x2843 ?x2843) true))))))))
(check-sat)
; query 42: function core_state_transition, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x183 (or false false)))
(let (($x3115 (not $x183)))
(and $x3115 (or $x183 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 43: function core_state_transition, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x3329 (ite (= (_ bv101 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x183 (or false false)))
(let (($x545 (or $x183 false false)))
(let (($x2383 (not $x545)))
(and $x2383 (or $x545 (and (distinct ?x3329 ?x3329) true))))))))
(check-sat)
; query 44: function core_state_transition, block 99, name %100
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x183 (or false false)))
(let (($x3115 (not $x183)))
(and $x3115 (or $x183 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 45: function core_state_transition, block 99, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x655 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x183 (or false false)))
(let (($x545 (or $x183 false false)))
(let (($x2383 (not $x545)))
(and $x2383 (or $x545 (and (distinct ?x655 ?x655) true))))))))
(check-sat)
; query 46: function crcu8, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x183 (or false false)))
(let (($x3115 (not $x183)))
(and $x3115 (or $x183 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 47: function crcu8, block 19, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x947 ((_ zero_extend 16) in.01_16)))
(let ((?x3649 (bvxor ?x947 (_ bv16386 32))))
(let (($x183 (or false false)))
(let (($x545 (or $x183 false false)))
(let (($x2383 (not $x545)))
(and $x2383 (or $x545 (and (distinct ?x3649 ?x3649) true)))))))))
(check-sat)
; query 48: function crcu8, block 19, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x947 ((_ zero_extend 16) in.01_16)))
(let ((?x3649 (bvxor ?x947 (_ bv16386 32))))
(let ((?x453 ((_ extract 15 0) ?x3649)))
(let (($x183 (or false false)))
(let (($x545 (or $x183 false false)))
(let (($x2634 (or $x545 false)))
(let (($x3118 (not $x2634)))
(and $x3118 (or $x2634 (and (distinct ?x453 ?x453) true)))))))))))
(check-sat)
; query 49: function crcu8, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x183 (or false false)))
(let (($x3115 (not $x183)))
(and $x3115 (or $x183 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 50: function crcu8, block 29, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x3933 ((_ zero_extend 16) in27_16)))
(let ((?x3362 (bvor ?x3933 (_ bv32768 32))))
(let (($x183 (or false false)))
(let (($x545 (or $x183 false false)))
(let (($x2383 (not $x545)))
(and $x2383 (or $x545 (and (distinct ?x3362 ?x3362) true)))))))))
(check-sat)
; query 51: function crcu8, block 29, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x3933 ((_ zero_extend 16) in27_16)))
(let ((?x3362 (bvor ?x3933 (_ bv32768 32))))
(let ((?x3366 ((_ extract 15 0) ?x3362)))
(let (($x183 (or false false)))
(let (($x545 (or $x183 false false)))
(let (($x2634 (or $x545 false)))
(let (($x3118 (not $x2634)))
(and $x3118 (or $x2634 (and (distinct ?x3366 ?x3366) true)))))))))))
(check-sat)
; query 52: function crcu8, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x183 (or false false)))
(let (($x3115 (not $x183)))
(and $x3115 (or $x183 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 53: function crcu8, block 33, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x3933 ((_ zero_extend 16) in27_16)))
(let ((?x3374 (bvand ?x3933 (_ bv32767 32))))
(let (($x183 (or false false)))
(let (($x545 (or $x183 false false)))
(let (($x2383 (not $x545)))
(and $x2383 (or $x545 (and (distinct ?x3374 ?x3374) true)))))))))
(check-sat)
; query 54: function crcu8, block 33, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x3933 ((_ zero_extend 16) in27_16)))
(let ((?x3374 (bvand ?x3933 (_ bv32767 32))))
(let ((?x3125 ((_ extract 15 0) ?x3374)))
(let (($x183 (or false false)))
(let (($x545 (or $x183 false false)))
(let (($x2634 (or $x545 false)))
(let (($x3118 (not $x2634)))
(and $x3118 (or $x2634 (and (distinct ?x3125 ?x3125) true)))))))))))
(check-sat)
; query 55: function crcu8, block 38, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_8 () (_ BitVec 8))
(assert
 (let (($x313 (or false false false)))
(let (($x3383 (not $x313)))
(and $x3383 (or $x313 (and (distinct (bvadd in.02_8 (_ bv1 8)) (bvadd in.02_8 (_ bv1 8))) true))))))
(check-sat)
; query 56: function crcu8, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x3375 ((_ extract 7 0) in.01_16)))
(let ((?x2633 ((_ zero_extend 24) ?x3375)))
(let (($x183 (or false false)))
(let (($x2616 (or $x183 false)))
(and (not $x2616) (or $x2616 (and (distinct ?x2633 ?x2633) true))))))))
(check-sat)
; query 57: function crcu8, block 6, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x3375 ((_ extract 7 0) in.01_16)))
(let ((?x2633 ((_ zero_extend 24) ?x3375)))
(let ((?x2163 (bvand ?x2633 (_ bv1 32))))
(let (($x183 (or false false)))
(let (($x2616 (or $x183 false)))
(let (($x1952 (or $x2616 false false)))
(and (not $x1952) (or $x1952 (and (distinct ?x2163 ?x2163) true))))))))))
(check-sat)
; query 58: function crcu8, block 6, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x3375 ((_ extract 7 0) in.01_16)))
(let ((?x2633 ((_ zero_extend 24) ?x3375)))
(let ((?x2163 (bvand ?x2633 (_ bv1 32))))
(let ((?x2635 ((_ zero_extend 24) in.0_8)))
(let ((?x2386 (bvand ?x2635 (_ bv1 32))))
(let ((?x314 (bvxor ?x2386 ?x2163)))
(let (($x183 (or false false)))
(let (($x2616 (or $x183 false)))
(let (($x1952 (or $x2616 false false)))
(let (($x545 (or $x183 false false)))
(let (($x2618 (or $x545 $x1952 false)))
(and (not $x2618) (or $x2618 (and (distinct ?x314 ?x314) true)))))))))))))))
(check-sat)
; query 59: function crcu8, block 6, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x3375 ((_ extract 7 0) in.01_16)))
(let ((?x2633 ((_ zero_extend 24) ?x3375)))
(let ((?x2163 (bvand ?x2633 (_ bv1 32))))
(let ((?x2635 ((_ zero_extend 24) in.0_8)))
(let ((?x2386 (bvand ?x2635 (_ bv1 32))))
(let ((?x314 (bvxor ?x2386 ?x2163)))
(let ((?x3110 ((_ extract 7 0) ?x314)))
(let (($x183 (or false false)))
(let (($x2616 (or $x183 false)))
(let (($x1952 (or $x2616 false false)))
(let (($x545 (or $x183 false false)))
(let (($x2618 (or $x545 $x1952 false)))
(let (($x2605 (or $x2618 false)))
(and (not $x2605) (or $x2605 (and (distinct ?x3110 ?x3110) true)))))))))))))))))
(check-sat)
; query 60: function crcu8, block 6, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x183 (or false false)))
(let (($x3115 (not $x183)))
(and $x3115 (or $x183 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 61: function crcu8, block 6, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x2635 ((_ zero_extend 24) in.0_8)))
(let ((?x203 (bvashr ?x2635 (_ bv1 32))))
(let (($x183 (or false false)))
(let (($x545 (or $x183 false false)))
(let (($x2864 (or $x545 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not $x2864) (or $x2864 (and (distinct ?x203 ?x203) true)))))))))
(check-sat)
; query 62: function crcu8, block 6, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x2635 ((_ zero_extend 24) in.0_8)))
(let ((?x203 (bvashr ?x2635 (_ bv1 32))))
(let ((?x2388 ((_ extract 7 0) ?x203)))
(let (($x183 (or false false)))
(let (($x545 (or $x183 false false)))
(let (($x2864 (or $x545 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x517 (or $x2864 false)))
(and (not $x517) (or $x517 (and (distinct ?x2388 ?x2388) true)))))))))))
(check-sat)
; query 63: function crcu8, block 6, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x3375 ((_ extract 7 0) in.01_16)))
(let ((?x2633 ((_ zero_extend 24) ?x3375)))
(let ((?x2163 (bvand ?x2633 (_ bv1 32))))
(let ((?x2635 ((_ zero_extend 24) in.0_8)))
(let ((?x2386 (bvand ?x2635 (_ bv1 32))))
(let ((?x314 (bvxor ?x2386 ?x2163)))
(let ((?x3110 ((_ extract 7 0) ?x314)))
(let ((?x2387 ((_ zero_extend 24) ?x3110)))
(let (($x183 (or false false)))
(let (($x2616 (or $x183 false)))
(let (($x1952 (or $x2616 false false)))
(let (($x545 (or $x183 false false)))
(let (($x2618 (or $x545 $x1952 false)))
(let (($x2605 (or $x2618 false)))
(let (($x2853 (or $x2605 false)))
(and (not $x2853) (or $x2853 (and (distinct ?x2387 ?x2387) true)))))))))))))))))))
(check-sat)
; query 64: function crcu8, block 6, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x3375 ((_ extract 7 0) in.01_16)))
(let ((?x2633 ((_ zero_extend 24) ?x3375)))
(let ((?x2163 (bvand ?x2633 (_ bv1 32))))
(let ((?x2635 ((_ zero_extend 24) in.0_8)))
(let ((?x2386 (bvand ?x2635 (_ bv1 32))))
(let ((?x314 (bvxor ?x2386 ?x2163)))
(let ((?x3110 ((_ extract 7 0) ?x314)))
(let ((?x2387 ((_ zero_extend 24) ?x3110)))
(let ((?x2390 (ite (= (_ bv1 32) ?x2387) (_ bv1 1) (_ bv0 1))))
(let (($x183 (or false false)))
(let (($x2616 (or $x183 false)))
(let (($x1952 (or $x2616 false false)))
(let (($x545 (or $x183 false false)))
(let (($x2618 (or $x545 $x1952 false)))
(let (($x2605 (or $x2618 false)))
(let (($x2853 (or $x2605 false)))
(let (($x2631 (or $x2853 false false)))
(and (not $x2631) (or $x2631 (and (distinct ?x2390 ?x2390) true)))))))))))))))))))))
(check-sat)
; query 65: function crcu8, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x183 (or false false)))
(let (($x3115 (not $x183)))
(and $x3115 (or $x183 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 66: function crcu8, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x2635 ((_ zero_extend 24) in.0_8)))
(let ((?x2386 (bvand ?x2635 (_ bv1 32))))
(let (($x183 (or false false)))
(let (($x545 (or $x183 false false)))
(let (($x2383 (not $x545)))
(and $x2383 (or $x545 (and (distinct ?x2386 ?x2386) true)))))))))
(check-sat)
; query 67: function crcu8, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x183 (or false false)))
(let (($x3115 (not $x183)))
(and $x3115 (or $x183 (and (distinct ((_ extract 7 0) in.01_16) ((_ extract 7 0) in.01_16)) true))))))
(check-sat)
; query 68: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x2874 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x3108 ((_ zero_extend 31) ?x2874)))
(let ((?x1967 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2625 ((_ zero_extend 31) ?x1967)))
(let ((?x2848 (bvand ?x2625 ?x3108)))
(let ((?x1965 (ite (and (distinct (_ bv0 32) ?x2848) true) (_ bv1 1) (_ bv0 1))))
(let ((?x2608 ((_ zero_extend 63) ?x1965)))
(let (($x183 (or false false)))
(let (($x545 (or $x183 false false)))
(let (($x2634 (or $x545 false)))
(let (($x3122 (or $x2634 $x2634 false)))
(let (($x3105 (or $x3122 false false)))
(let (($x2370 (or $x3105 false)))
(and (not $x2370) (or $x2370 (and (distinct ?x2608 ?x2608) true)))))))))))))))))
(check-sat)
; query 69: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x2874 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x3108 ((_ zero_extend 31) ?x2874)))
(let ((?x1967 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2625 ((_ zero_extend 31) ?x1967)))
(let ((?x2848 (bvand ?x2625 ?x3108)))
(let ((?x1965 (ite (and (distinct (_ bv0 32) ?x2848) true) (_ bv1 1) (_ bv0 1))))
(let (($x2609 (= (_ bv1 1) ?x1965)))
(let ((?x3364 (ite $x2609 (_ bv1 32) (_ bv0 32))))
(let (($x183 (or false false)))
(let (($x545 (or $x183 false false)))
(let (($x2634 (or $x545 false)))
(let (($x3122 (or $x2634 $x2634 false)))
(let (($x3105 (or $x3122 false false)))
(let (($x2839 (or $x3105 (ite $x2609 false false))))
(and (not $x2839) (or $x2839 (and (distinct ?x3364 ?x3364) true))))))))))))))))))
(check-sat)
; query 70: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x2874 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x3108 ((_ zero_extend 31) ?x2874)))
(let ((?x1967 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2625 ((_ zero_extend 31) ?x1967)))
(let ((?x2848 (bvand ?x2625 ?x3108)))
(let ((?x1965 (ite (and (distinct (_ bv0 32) ?x2848) true) (_ bv1 1) (_ bv0 1))))
(let (($x2609 (= (_ bv1 1) ?x1965)))
(let ((?x3364 (ite $x2609 (_ bv1 32) (_ bv0 32))))
(let ((?x2398 ((_ extract 7 0) ?x3364)))
(let (($x183 (or false false)))
(let (($x545 (or $x183 false false)))
(let (($x2634 (or $x545 false)))
(let (($x3122 (or $x2634 $x2634 false)))
(let (($x3105 (or $x3122 false false)))
(let (($x2839 (or $x3105 (ite $x2609 false false))))
(let (($x2863 (or $x2839 false)))
(and (not $x2863) (or $x2863 (and (distinct ?x2398 ?x2398) true))))))))))))))))))))
(check-sat)
; query 71: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x183 (or false false)))
(let (($x3115 (not $x183)))
(and $x3115 (or $x183 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 72: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1967 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x183 (or false false)))
(let (($x545 (or $x183 false false)))
(let (($x2383 (not $x545)))
(and $x2383 (or $x545 (and (distinct ?x1967 ?x1967) true))))))))
(check-sat)
; query 73: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1967 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2625 ((_ zero_extend 31) ?x1967)))
(let (($x183 (or false false)))
(let (($x545 (or $x183 false false)))
(let (($x2634 (or $x545 false)))
(let (($x3118 (not $x2634)))
(and $x3118 (or $x2634 (and (distinct ?x2625 ?x2625) true))))))))))
(check-sat)
; query 74: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x183 (or false false)))
(let (($x3115 (not $x183)))
(and $x3115 (or $x183 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 75: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x2874 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x183 (or false false)))
(let (($x545 (or $x183 false false)))
(let (($x2383 (not $x545)))
(and $x2383 (or $x545 (and (distinct ?x2874 ?x2874) true))))))))
(check-sat)
; query 76: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x2874 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x3108 ((_ zero_extend 31) ?x2874)))
(let (($x183 (or false false)))
(let (($x545 (or $x183 false false)))
(let (($x2634 (or $x545 false)))
(let (($x3118 (not $x2634)))
(and $x3118 (or $x2634 (and (distinct ?x3108 ?x3108) true))))))))))
(check-sat)
; query 77: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x2874 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x3108 ((_ zero_extend 31) ?x2874)))
(let ((?x1967 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2625 ((_ zero_extend 31) ?x1967)))
(let ((?x2848 (bvand ?x2625 ?x3108)))
(let (($x183 (or false false)))
(let (($x545 (or $x183 false false)))
(let (($x2634 (or $x545 false)))
(let (($x3122 (or $x2634 $x2634 false)))
(and (not $x3122) (or $x3122 (and (distinct ?x2848 ?x2848) true)))))))))))))
(check-sat)
; query 78: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x2874 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x3108 ((_ zero_extend 31) ?x2874)))
(let ((?x1967 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2625 ((_ zero_extend 31) ?x1967)))
(let ((?x2848 (bvand ?x2625 ?x3108)))
(let ((?x1965 (ite (and (distinct (_ bv0 32) ?x2848) true) (_ bv1 1) (_ bv0 1))))
(let (($x183 (or false false)))
(let (($x545 (or $x183 false false)))
(let (($x2634 (or $x545 false)))
(let (($x3122 (or $x2634 $x2634 false)))
(let (($x3105 (or $x3122 false false)))
(and (not $x3105) (or $x3105 (and (distinct ?x1965 ?x1965) true)))))))))))))))
(check-sat)
; query 79: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x2636 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x313 (or false false false)))
(let (($x3383 (not $x313)))
(and $x3383 (or $x313 (and (distinct ?x2636 ?x2636) true)))))))
(check-sat)
; query 80: function matrix_add_const, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x313 (or false false false)))
(let (($x3383 (not $x313)))
(and $x3383 (or $x313 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 81: function matrix_add_const, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x494 (bvadd in.01_32 (_ bv1 32))))
(let (($x339 (and (distinct ?x494 ?x494) true)))
(let (($x313 (or false false false)))
(let (($x3383 (not $x313)))
(and $x3383 (or $x313 $x339)))))))
(check-sat)
; query 82: function matrix_mul_const, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x313 (or false false false)))
(let (($x3383 (not $x313)))
(and $x3383 (or $x313 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 83: function matrix_mul_const, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x494 (bvadd in.01_32 (_ bv1 32))))
(let (($x339 (and (distinct ?x494 ?x494) true)))
(let (($x313 (or false false false)))
(let (($x3383 (not $x313)))
(and $x3383 (or $x313 $x339)))))))
(check-sat)
; query 84: function matrix_mul_matrix, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x313 (or false false false)))
(let (($x3383 (not $x313)))
(and $x3383 (or $x313 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 85: function matrix_mul_matrix, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x494 (bvadd in.01_32 (_ bv1 32))))
(let (($x339 (and (distinct ?x494 ?x494) true)))
(let (($x313 (or false false false)))
(let (($x3383 (not $x313)))
(and $x3383 (or $x313 $x339)))))))
(check-sat)
; query 86: function matrix_mul_matrix, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x313 (or false false false)))
(let (($x3383 (not $x313)))
(and $x3383 (or $x313 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 87: function matrix_mul_matrix_bitextract, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x313 (or false false false)))
(let (($x3383 (not $x313)))
(and $x3383 (or $x313 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 88: function matrix_mul_matrix_bitextract, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x494 (bvadd in.01_32 (_ bv1 32))))
(let (($x339 (and (distinct ?x494 ?x494) true)))
(let (($x313 (or false false false)))
(let (($x3383 (not $x313)))
(and $x3383 (or $x313 $x339)))))))
(check-sat)
; query 89: function matrix_mul_matrix_bitextract, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x313 (or false false false)))
(let (($x3383 (not $x313)))
(and $x3383 (or $x313 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 90: function matrix_mul_vect, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x313 (or false false false)))
(let (($x3383 (not $x313)))
(and $x3383 (or $x313 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 91: function matrix_mul_vect, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x494 (bvadd in.01_32 (_ bv1 32))))
(let (($x339 (and (distinct ?x494 ?x494) true)))
(let (($x313 (or false false false)))
(let (($x3383 (not $x313)))
(and $x3383 (or $x313 $x339)))))))
(check-sat)
; query 92: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x183 (or false false)))
(let (($x3115 (not $x183)))
(and $x3115 (or $x183 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 93: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x2637 ((_ sign_extend 16) in.1_16)))
(let ((?x666 (bvadd ?x2637 (_ bv10 32))))
(let (($x1962 (and (distinct (bvadd ((_ sign_extend 1) ?x2637) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x666)) true)))
(let (($x183 (or false false)))
(let (($x2158 (or $x183 false (or $x1962))))
(and (not $x2158) (or $x2158 (and (distinct ?x666 ?x666) true)))))))))
(check-sat)
; query 94: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x2637 ((_ sign_extend 16) in.1_16)))
(let ((?x666 (bvadd ?x2637 (_ bv10 32))))
(let ((?x2176 ((_ extract 15 0) ?x666)))
(let (($x1962 (and (distinct (bvadd ((_ sign_extend 1) ?x2637) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x666)) true)))
(let (($x183 (or false false)))
(let (($x2158 (or $x183 false (or $x1962))))
(let (($x1949 (or $x2158 false)))
(and (not $x1949) (or $x1949 (and (distinct ?x2176 ?x2176) true)))))))))))
(check-sat)
; query 95: function matrix_sum, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x3665 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x313 (or false false false)))
(let (($x3383 (not $x313)))
(and $x3383 (or $x313 (and (distinct ?x3665 ?x3665) true)))))))
(check-sat)
; query 96: function matrix_sum, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x3665 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let ((?x3675 ((_ zero_extend 63) ?x3665)))
(let (($x313 (or false false false)))
(let (($x3402 (or $x313 false)))
(and (not $x3402) (or $x3402 (and (distinct ?x3675 ?x3675) true))))))))
(check-sat)
; query 97: function matrix_sum, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x3665 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x3956 (= (_ bv1 1) ?x3665)))
(let ((?x3113 (ite $x3956 (_ bv1 32) (_ bv0 32))))
(let (($x313 (or false false false)))
(let (($x3106 (or $x313 (ite $x3956 false false))))
(and (not $x3106) (or $x3106 (and (distinct ?x3113 ?x3113) true)))))))))
(check-sat)
; query 98: function matrix_sum, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x183 (or false false)))
(let (($x3115 (not $x183)))
(and $x3115 (or $x183 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 99: function matrix_sum, block 22, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x3665 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x3956 (= (_ bv1 1) ?x3665)))
(let ((?x3113 (ite $x3956 (_ bv1 32) (_ bv0 32))))
(let ((?x2637 ((_ sign_extend 16) in.1_16)))
(let ((?x337 (bvadd ?x2637 ?x3113)))
(let (($x3680 (and (distinct (bvadd ((_ sign_extend 1) ?x2637) ((_ sign_extend 1) ?x3113)) ((_ sign_extend 1) ?x337)) true)))
(let (($x313 (or false false false)))
(let (($x3106 (or $x313 (ite $x3956 false false))))
(let (($x183 (or false false)))
(let (($x1011 (or $x183 $x3106 (or $x3680))))
(and (not $x1011) (or $x1011 (and (distinct ?x337 ?x337) true))))))))))))))
(check-sat)
; query 100: function matrix_sum, block 22, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x3665 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x3956 (= (_ bv1 1) ?x3665)))
(let ((?x3113 (ite $x3956 (_ bv1 32) (_ bv0 32))))
(let ((?x2637 ((_ sign_extend 16) in.1_16)))
(let ((?x337 (bvadd ?x2637 ?x3113)))
(let ((?x3679 ((_ extract 15 0) ?x337)))
(let (($x3680 (and (distinct (bvadd ((_ sign_extend 1) ?x2637) ((_ sign_extend 1) ?x3113)) ((_ sign_extend 1) ?x337)) true)))
(let (($x313 (or false false false)))
(let (($x3106 (or $x313 (ite $x3956 false false))))
(let (($x183 (or false false)))
(let (($x1011 (or $x183 $x3106 (or $x3680))))
(let (($x976 (or $x1011 false)))
(and (not $x976) (or $x976 (and (distinct ?x3679 ?x3679) true))))))))))))))))
(check-sat)
; query 101: function matrix_sum, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x313 (or false false false)))
(let (($x3383 (not $x313)))
(and $x3383 (or $x313 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 102: function matrix_sum, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x494 (bvadd in.01_32 (_ bv1 32))))
(let (($x339 (and (distinct ?x494 ?x494) true)))
(let (($x313 (or false false false)))
(let (($x3383 (not $x313)))
(and $x3383 (or $x313 $x339)))))))
(check-sat)
; query 103: function parseval, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.23_32 () (_ BitVec 32))
(assert
 (let (($x825 (and (distinct (bvmul ((_ sign_extend 32) in.23_32) ((_ sign_extend 32) (_ bv1024 32))) ((_ sign_extend 32) (bvmul in.23_32 (_ bv1024 32)))) true)))
(let (($x872 (or false false (or $x825))))
(and (not $x872) (or $x872 (and (distinct (bvmul in.23_32 (_ bv1024 32)) (bvmul in.23_32 (_ bv1024 32))) true))))))
(check-sat)
; query 104: function parseval, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.34_32 () (_ BitVec 32))
(assert
 (let (($x143 (and (distinct (bvmul ((_ sign_extend 32) in.34_32) ((_ sign_extend 32) (_ bv1048576 32))) ((_ sign_extend 32) (bvmul in.34_32 (_ bv1048576 32)))) true)))
(let (($x948 (or false false (or $x143))))
(and (not $x948) (or $x948 (and (distinct (bvmul in.34_32 (_ bv1048576 32)) (bvmul in.34_32 (_ bv1048576 32))) true))))))
(check-sat)
; query 105: function partition_memory, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x313 (or false false false)))
(let (($x3383 (not $x313)))
(and $x3383 (or $x313 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 106: function run_crc_loop, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x494 (bvadd in.01_32 (_ bv1 32))))
(let (($x339 (and (distinct ?x494 ?x494) true)))
(let (($x313 (or false false false)))
(let (($x3383 (not $x313)))
(and $x3383 (or $x313 $x339)))))))
(check-sat)
