; OptiPhase-Sigma refinement certificate for sweep K59-R3-252
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x627 (or false false)))
(let (($x39241 (not $x627)))
(and $x39241 (or $x627 (and (distinct ((_ sign_extend 16) in25_16) ((_ sign_extend 16) in25_16)) true))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let ((?x176 (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))))
(let (($x627 (or false false)))
(let (($x144 (or $x627 false false)))
(let (($x204 (not $x144)))
(and $x204 (or $x144 (and (distinct ?x176 ?x176) true))))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x627 (or false false)))
(let (($x39241 (not $x627)))
(and $x39241 (or $x627 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x935 ((_ sign_extend 16) in3_16)))
(let ((?x681 (bvand ?x935 (_ bv127 32))))
(let (($x627 (or false false)))
(let (($x144 (or $x627 false false)))
(let (($x204 (not $x144)))
(and $x204 (or $x144 (and (distinct ?x681 ?x681) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x935 ((_ sign_extend 16) in3_16)))
(let ((?x681 (bvand ?x935 (_ bv127 32))))
(let ((?x342 ((_ extract 15 0) ?x681)))
(let (($x627 (or false false)))
(let (($x144 (or $x627 false false)))
(let (($x60 (or $x144 false)))
(and (not $x60) (or $x60 (and (distinct ?x342 ?x342) true))))))))))
(check-sat)
; query 5: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x627 (or false false)))
(let (($x39241 (not $x627)))
(and $x39241 (or $x627 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 6: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x9703 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x627 (or false false)))
(let (($x144 (or $x627 false false)))
(let (($x204 (not $x144)))
(and $x204 (or $x144 (and (distinct ?x9703 ?x9703) true))))))))
(check-sat)
; query 7: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x50 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x2117 (or false false false)))
(let (($x1239 (not $x2117)))
(and $x1239 (or $x2117 (and (distinct ?x50 ?x50) true)))))))
(check-sat)
; query 8: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x2117 (or false false false)))
(let (($x1239 (not $x2117)))
(and $x1239 (or $x2117 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 9: function core_state_transition, block 102, name %103
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x627 (or false false)))
(let (($x39241 (not $x627)))
(and $x39241 (or $x627 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 10: function core_state_transition, block 102, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x336 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x627 (or false false)))
(let (($x144 (or $x627 false false)))
(let (($x204 (not $x144)))
(and $x204 (or $x144 (and (distinct ?x336 ?x336) true))))))))
(check-sat)
; query 11: function core_state_transition, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x627 (or false false)))
(let (($x39241 (not $x627)))
(and $x39241 (or $x627 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 12: function core_state_transition, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1442 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x627 (or false false)))
(let (($x144 (or $x627 false false)))
(let (($x204 (not $x144)))
(and $x204 (or $x144 (and (distinct ?x1442 ?x1442) true))))))))
(check-sat)
; query 13: function core_state_transition, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x627 (or false false)))
(let (($x39241 (not $x627)))
(and $x39241 (or $x627 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 14: function core_state_transition, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x336 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x627 (or false false)))
(let (($x144 (or $x627 false false)))
(let (($x204 (not $x144)))
(and $x204 (or $x144 (and (distinct ?x336 ?x336) true))))))))
(check-sat)
; query 15: function core_state_transition, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x627 (or false false)))
(let (($x39241 (not $x627)))
(and $x39241 (or $x627 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 16: function core_state_transition, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x37 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x627 (or false false)))
(let (($x144 (or $x627 false false)))
(let (($x204 (not $x144)))
(and $x204 (or $x144 (and (distinct ?x37 ?x37) true))))))))
(check-sat)
; query 17: function core_state_transition, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x627 (or false false)))
(let (($x39241 (not $x627)))
(and $x39241 (or $x627 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 18: function core_state_transition, block 51, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x37 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x627 (or false false)))
(let (($x144 (or $x627 false false)))
(let (($x204 (not $x144)))
(and $x204 (or $x144 (and (distinct ?x37 ?x37) true))))))))
(check-sat)
; query 19: function core_state_transition, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x627 (or false false)))
(let (($x39241 (not $x627)))
(and $x39241 (or $x627 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 20: function core_state_transition, block 64, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x37 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x627 (or false false)))
(let (($x144 (or $x627 false false)))
(let (($x204 (not $x144)))
(and $x204 (or $x144 (and (distinct ?x37 ?x37) true))))))))
(check-sat)
; query 21: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x114 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x2117 (or false false false)))
(let (($x1239 (not $x2117)))
(and $x1239 (or $x2117 (and (distinct ?x114 ?x114) true)))))))
(check-sat)
; query 22: function core_state_transition, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x627 (or false false)))
(let (($x39241 (not $x627)))
(and $x39241 (or $x627 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 23: function core_state_transition, block 80, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x430 (ite (= (_ bv69 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x627 (or false false)))
(let (($x144 (or $x627 false false)))
(let (($x204 (not $x144)))
(and $x204 (or $x144 (and (distinct ?x430 ?x430) true))))))))
(check-sat)
; query 24: function core_state_transition, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x627 (or false false)))
(let (($x39241 (not $x627)))
(and $x39241 (or $x627 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 25: function core_state_transition, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1732 (ite (= (_ bv101 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x627 (or false false)))
(let (($x144 (or $x627 false false)))
(let (($x204 (not $x144)))
(and $x204 (or $x144 (and (distinct ?x1732 ?x1732) true))))))))
(check-sat)
; query 26: function core_state_transition, block 99, name %100
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x627 (or false false)))
(let (($x39241 (not $x627)))
(and $x39241 (or $x627 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 27: function core_state_transition, block 99, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1442 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x627 (or false false)))
(let (($x144 (or $x627 false false)))
(let (($x204 (not $x144)))
(and $x204 (or $x144 (and (distinct ?x1442 ?x1442) true))))))))
(check-sat)
; query 28: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x98 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x2117 (or false false false)))
(let (($x1239 (not $x2117)))
(and $x1239 (or $x2117 (and (distinct ?x98 ?x98) true)))))))
(check-sat)
; query 29: function parseval, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.23_32 () (_ BitVec 32))
(assert
 (let (($x320 (and (distinct (bvmul ((_ sign_extend 32) in.23_32) ((_ sign_extend 32) (_ bv1024 32))) ((_ sign_extend 32) (bvmul in.23_32 (_ bv1024 32)))) true)))
(let (($x45 (or false false (or $x320))))
(and (not $x45) (or $x45 (and (distinct (bvmul in.23_32 (_ bv1024 32)) (bvmul in.23_32 (_ bv1024 32))) true))))))
(check-sat)
; query 30: function parseval, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.34_32 () (_ BitVec 32))
(assert
 (let (($x94 (and (distinct (bvmul ((_ sign_extend 32) in.34_32) ((_ sign_extend 32) (_ bv1048576 32))) ((_ sign_extend 32) (bvmul in.34_32 (_ bv1048576 32)))) true)))
(let (($x42 (or false false (or $x94))))
(and (not $x42) (or $x42 (and (distinct (bvmul in.34_32 (_ bv1048576 32)) (bvmul in.34_32 (_ bv1048576 32))) true))))))
(check-sat)
