; OptiPhase-Sigma refinement certificate for sweep K49-R3-137
; query 0: function APCM_inverse_quantization, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x470 (or false false)))
(let (($x1042 (not $x470)))
(and $x1042 (or $x470 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 1: function APCM_inverse_quantization, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x737 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x470 (or false false)))
(let (($x1709 (or $x470 false false)))
(let (($x109 (not $x1709)))
(and $x109 (or $x1709 (and (distinct ?x737 ?x737) true))))))))
(check-sat)
; query 2: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x470 (or false false)))
(let (($x1042 (not $x470)))
(and $x1042 (or $x470 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 3: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x143 (ite (bvslt (_ bv15 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x470 (or false false)))
(let (($x1709 (or $x470 false false)))
(let (($x109 (not $x1709)))
(and $x109 (or $x1709 (and (distinct ?x143 ?x143) true))))))))
(check-sat)
; query 4: function Decoding_of_the_coded_Log_Area_Ratios, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in6_64 () (_ BitVec 64))
(assert
 (let ((?x2869 (ite (bvslt (_ bv0 64) in6_64) (_ bv1 1) (_ bv0 1))))
(let (($x965 (or false false false)))
(let (($x813 (not $x965)))
(and $x813 (or $x965 (and (distinct ?x2869 ?x2869) true)))))))
(check-sat)
; query 5: function Decoding_of_the_coded_Log_Area_Ratios, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in6_64 () (_ BitVec 64))
(assert
 (let ((?x2869 (ite (bvslt (_ bv0 64) in6_64) (_ bv1 1) (_ bv0 1))))
(let ((?x212 ((_ zero_extend 63) ?x2869)))
(let (($x965 (or false false false)))
(let (($x831 (or $x965 false)))
(let (($x655 (not $x831)))
(and $x655 (or $x831 (and (distinct ?x212 ?x212) true)))))))))
(check-sat)
; query 6: function Decoding_of_the_coded_Log_Area_Ratios, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in6_64 () (_ BitVec 64))
(assert
 (let ((?x2869 (ite (bvslt (_ bv0 64) in6_64) (_ bv1 1) (_ bv0 1))))
(let (($x765 (= (_ bv1 1) ?x2869)))
(let ((?x721 (ite $x765 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x965 (or false false false)))
(let (($x176 (or $x965 (ite $x765 false false))))
(and (not $x176) (or $x176 (and (distinct ?x721 ?x721) true)))))))))
(check-sat)
; query 7: function Decoding_of_the_coded_Log_Area_Ratios, block 9, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in6_64 () (_ BitVec 64))
(assert
 (let ((?x2869 (ite (bvslt (_ bv0 64) in6_64) (_ bv1 1) (_ bv0 1))))
(let (($x765 (= (_ bv1 1) ?x2869)))
(let ((?x721 (ite $x765 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x1541 ((_ sign_extend 32) ?x721)))
(let (($x965 (or false false false)))
(let (($x176 (or $x965 (ite $x765 false false))))
(let (($x1586 (or $x176 false)))
(and (not $x1586) (or $x1586 (and (distinct ?x1541 ?x1541) true)))))))))))
(check-sat)
; query 8: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x470 (or false false)))
(let (($x1042 (not $x470)))
(and $x1042 (or $x470 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 9: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x480 (ite (bvsgt (_ bv40 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x470 (or false false)))
(let (($x1709 (or $x470 false false)))
(let (($x109 (not $x1709)))
(and $x109 (or $x1709 (and (distinct ?x480 ?x480) true))))))))
(check-sat)
; query 10: function Postprocessing, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in17_64 () (_ BitVec 64))
(assert
 (let ((?x817 (ite (bvslt (_ bv0 64) in17_64) (_ bv1 1) (_ bv0 1))))
(let (($x965 (or false false false)))
(let (($x813 (not $x965)))
(and $x813 (or $x965 (and (distinct ?x817 ?x817) true)))))))
(check-sat)
; query 11: function Postprocessing, block 20, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in17_64 () (_ BitVec 64))
(assert
 (let ((?x817 (ite (bvslt (_ bv0 64) in17_64) (_ bv1 1) (_ bv0 1))))
(let ((?x28 ((_ zero_extend 63) ?x817)))
(let (($x965 (or false false false)))
(let (($x831 (or $x965 false)))
(let (($x655 (not $x831)))
(and $x655 (or $x831 (and (distinct ?x28 ?x28) true)))))))))
(check-sat)
; query 12: function Postprocessing, block 20, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in17_64 () (_ BitVec 64))
(assert
 (let ((?x817 (ite (bvslt (_ bv0 64) in17_64) (_ bv1 1) (_ bv0 1))))
(let (($x610 (= (_ bv1 1) ?x817)))
(let ((?x586 (ite $x610 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x965 (or false false false)))
(let (($x2872 (or $x965 (ite $x610 false false))))
(and (not $x2872) (or $x2872 (and (distinct ?x586 ?x586) true)))))))))
(check-sat)
; query 13: function Postprocessing, block 20, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in17_64 () (_ BitVec 64))
(assert
 (let ((?x817 (ite (bvslt (_ bv0 64) in17_64) (_ bv1 1) (_ bv0 1))))
(let (($x610 (= (_ bv1 1) ?x817)))
(let ((?x586 (ite $x610 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x38 ((_ sign_extend 32) ?x586)))
(let (($x965 (or false false false)))
(let (($x2872 (or $x965 (ite $x610 false false))))
(let (($x1226 (or $x2872 false)))
(and (not $x1226) (or $x1226 (and (distinct ?x38 ?x38) true)))))))))))
(check-sat)
; query 14: function Quantization_and_coding, block 24, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_32 () (_ BitVec 32))
(declare-fun in21_64 () (_ BitVec 64))
(assert
 (let (($x15 (and (distinct (ite (bvslt (_ bv0 64) in21_64) (_ bv1 1) (_ bv0 1)) (ite (bvsgt (_ bv4294967264 32) in21_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x965 (or false false false)))
(let (($x813 (not $x965)))
(and $x813 (or $x965 $x15))))))
(check-sat)
; query 15: function Quantization_and_coding, block 261, name %262
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in258_32 () (_ BitVec 32))
(declare-fun in258_64 () (_ BitVec 64))
(assert
 (let (($x51 (and (distinct (ite (bvslt (_ bv0 64) in258_64) (_ bv1 1) (_ bv0 1)) (ite (bvsgt (_ bv4294967292 32) in258_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x965 (or false false false)))
(let (($x813 (not $x965)))
(and $x813 (or $x965 $x51))))))
(check-sat)
; query 16: function RPE_grid_positioning, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x470 (or false false)))
(let (($x1042 (not $x470)))
(and $x1042 (or $x470 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 17: function RPE_grid_positioning, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x333 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x58 (and (distinct ?x333 ?x333) true)))
(let (($x470 (or false false)))
(let (($x562 (or false $x470 false)))
(and (not $x562) (or $x562 $x58)))))))
(check-sat)
; query 18: function gsm_L_add, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_64 () (_ BitVec 64))
(assert
 (let ((?x41 (bvsub (_ bv0 64) in13_64)))
(let ((?x60 ((_ sign_extend 1) ?x41)))
(let (($x163 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in13_64)) ?x60) true)))))
(and (not $x163) (or $x163 (and (distinct ?x41 ?x41) true)))))))
(check-sat)
; query 19: function gsm_L_add, block 16, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_64 () (_ BitVec 64))
(assert
 (let ((?x41 (bvsub (_ bv0 64) in13_64)))
(let ((?x155 (bvsub ?x41 (_ bv2 64))))
(let (($x314 (and (distinct (bvsub ((_ sign_extend 1) ?x41) ((_ sign_extend 1) (_ bv2 64))) ((_ sign_extend 1) ?x155)) true)))
(let ((?x60 ((_ sign_extend 1) ?x41)))
(let (($x163 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in13_64)) ?x60) true)))))
(let (($x569 (or $x163 false (or $x314))))
(and (not $x569) (or $x569 (and (distinct ?x155 ?x155) true))))))))))
(check-sat)
; query 20: function gsm_L_add, block 21, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x414 (ite (bvsge (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x965 (or false false false)))
(let (($x813 (not $x965)))
(and $x813 (or $x965 (and (distinct ?x414 ?x414) true)))))))
(check-sat)
; query 21: function gsm_L_add, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1102 (bvadd in0_64 in1_64)))
(let (($x1934 (and (distinct ?x1102 ?x1102) true)))
(let (($x660 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) ?x1102)) true)))
(let (($x1224 (or false false (or $x660))))
(and (not $x1224) (or $x1224 $x1934)))))))
(check-sat)
; query 22: function gsm_L_add, block 25, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1102 (bvadd in0_64 in1_64)))
(let (($x1934 (and (distinct ?x1102 ?x1102) true)))
(let (($x205 (and (distinct (bvadd ((_ zero_extend 1) in0_64) ((_ zero_extend 1) in1_64)) ((_ zero_extend 1) ?x1102)) true)))
(let (($x1590 (or false false (or $x205))))
(let (($x965 (or false false false)))
(let (($x813 (not $x965)))
(and $x813 (or $x1590 $x1934)))))))))
(check-sat)
; query 23: function gsm_L_add, block 25, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x123 (ite (bvugt (bvadd in0_64 in1_64) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x205 (and (distinct (bvadd ((_ zero_extend 1) in0_64) ((_ zero_extend 1) in1_64)) ((_ zero_extend 1) (bvadd in0_64 in1_64))) true)))
(let (($x1590 (or false false (or $x205))))
(let (($x965 (or false false false)))
(let (($x197 (or $x965 false false)))
(let (($x542 (not $x197)))
(and $x542 (or (or $x1590 false false) (and (distinct ?x123 ?x123) true))))))))))
(check-sat)
; query 24: function gsm_L_add, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x66 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x965 (or false false false)))
(let (($x813 (not $x965)))
(and $x813 (or $x965 (and (distinct ?x66 ?x66) true)))))))
(check-sat)
; query 25: function gsm_L_add, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1102 (bvadd in0_64 in1_64)))
(let (($x1934 (and (distinct ?x1102 ?x1102) true)))
(let (($x660 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) ?x1102)) true)))
(let (($x1224 (or false false (or $x660))))
(and (not $x1224) (or $x1224 $x1934)))))))
(check-sat)
; query 26: function gsm_L_add, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1122 (bvadd in0_64 (_ bv1 64))))
(let ((?x1854 (bvsub (_ bv0 64) ?x1122)))
(let (($x203 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1122)) ((_ sign_extend 1) ?x1854)) true)))
(let ((?x1035 ((_ sign_extend 1) ?x1122)))
(let (($x373 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1035) true)))))
(let (($x633 (or false $x373 (or $x203))))
(and (not $x633) (or $x633 (and (distinct ?x1854 ?x1854) true))))))))))
(check-sat)
; query 27: function gsm_L_add, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x946 (bvadd in1_64 (_ bv1 64))))
(let ((?x46 ((_ sign_extend 1) ?x946)))
(let (($x1551 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x46) true)))))
(and (not $x1551) (or $x1551 (and (distinct ?x946 ?x946) true)))))))
(check-sat)
; query 28: function gsm_L_add, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x946 (bvadd in1_64 (_ bv1 64))))
(let ((?x1080 (bvsub (_ bv0 64) ?x946)))
(let (($x1051 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x946)) ((_ sign_extend 1) ?x1080)) true)))
(let ((?x46 ((_ sign_extend 1) ?x946)))
(let (($x1551 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x46) true)))))
(let (($x1823 (or false $x1551 (or $x1051))))
(and (not $x1823) (or $x1823 (and (distinct ?x1080 ?x1080) true))))))))))
(check-sat)
; query 29: function gsm_L_add, block 8, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x946 (bvadd in1_64 (_ bv1 64))))
(let ((?x1080 (bvsub (_ bv0 64) ?x946)))
(let ((?x1122 (bvadd in0_64 (_ bv1 64))))
(let ((?x1854 (bvsub (_ bv0 64) ?x1122)))
(let ((?x117 (bvadd ?x1854 ?x1080)))
(let (($x1188 (and (distinct (bvadd ((_ zero_extend 1) ?x1854) ((_ zero_extend 1) ?x1080)) ((_ zero_extend 1) ?x117)) true)))
(let (($x1051 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x946)) ((_ sign_extend 1) ?x1080)) true)))
(let ((?x46 ((_ sign_extend 1) ?x946)))
(let (($x1551 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x46) true)))))
(let (($x1823 (or false $x1551 (or $x1051))))
(let (($x203 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1122)) ((_ sign_extend 1) ?x1854)) true)))
(let ((?x1035 ((_ sign_extend 1) ?x1122)))
(let (($x373 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1035) true)))))
(let (($x633 (or false $x373 (or $x203))))
(let (($x1490 (or $x633 $x1823 (or $x1188))))
(and (not (or $x633 $x1823 false)) (or $x1490 (and (distinct ?x117 ?x117) true)))))))))))))))))))
(check-sat)
; query 30: function gsm_L_add, block 8, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x946 (bvadd in1_64 (_ bv1 64))))
(let ((?x1080 (bvsub (_ bv0 64) ?x946)))
(let ((?x1122 (bvadd in0_64 (_ bv1 64))))
(let ((?x1854 (bvsub (_ bv0 64) ?x1122)))
(let ((?x117 (bvadd ?x1854 ?x1080)))
(let ((?x1489 (ite (bvuge ?x117 (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x1188 (and (distinct (bvadd ((_ zero_extend 1) ?x1854) ((_ zero_extend 1) ?x1080)) ((_ zero_extend 1) ?x117)) true)))
(let (($x1051 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x946)) ((_ sign_extend 1) ?x1080)) true)))
(let ((?x46 ((_ sign_extend 1) ?x946)))
(let (($x1551 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x46) true)))))
(let (($x1823 (or false $x1551 (or $x1051))))
(let (($x203 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1122)) ((_ sign_extend 1) ?x1854)) true)))
(let ((?x1035 ((_ sign_extend 1) ?x1122)))
(let (($x373 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1035) true)))))
(let (($x633 (or false $x373 (or $x203))))
(let (($x1490 (or $x633 $x1823 (or $x1188))))
(and (not (or (or $x633 $x1823 false) false false)) (or (or $x1490 false false) (and (distinct ?x1489 ?x1489) true))))))))))))))))))))
(check-sat)
; query 31: function gsm_L_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1122 (bvadd in0_64 (_ bv1 64))))
(let ((?x1035 ((_ sign_extend 1) ?x1122)))
(let (($x373 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1035) true)))))
(and (not $x373) (or $x373 (and (distinct ?x1122 ?x1122) true)))))))
(check-sat)
; query 32: function gsm_L_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1339 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x965 (or false false false)))
(let (($x813 (not $x965)))
(and $x813 (or $x965 (and (distinct ?x1339 ?x1339) true)))))))
(check-sat)
; query 33: function gsm_L_asl, block 12, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x303 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x965 (or false false false)))
(let (($x813 (not $x965)))
(and $x813 (or $x965 (and (distinct ?x303 ?x303) true)))))))
(check-sat)
; query 34: function gsm_L_asl, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x1001 (or false (or (= ((_ extract 31 31) in1_32) (_ bv1 1))))))
(let (($x470 (or false false)))
(let (($x1042 (not $x470)))
(and $x1042 (or $x1001 (and (distinct ((_ zero_extend 32) in1_32) ((_ zero_extend 32) in1_32)) true)))))))
(check-sat)
; query 35: function gsm_L_asl, block 17, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x432 ((_ zero_extend 32) in1_32)))
(let ((?x1014 (bvshl in0_64 ?x432)))
(let (($x981 (bvuge ?x432 (_ bv64 64))))
(let (($x374 (or (or false (or false (or (= ((_ extract 31 31) in1_32) (_ bv1 1)))) false) $x981)))
(let (($x226 (not (or (or false (or false false) false) $x981))))
(and $x226 (or $x374 (and (distinct ?x1014 ?x1014) true)))))))))
(check-sat)
; query 36: function gsm_L_asl, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1601 (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x965 (or false false false)))
(let (($x813 (not $x965)))
(and $x813 (or $x965 (and (distinct ?x1601 ?x1601) true)))))))
(check-sat)
; query 37: function gsm_L_asl, block 7, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1339 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x388 ((_ zero_extend 31) ?x1339)))
(let ((?x1335 (bvsub (_ bv0 32) ?x388)))
(let (($x1351 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x388)) ((_ sign_extend 1) ?x1335)) true)))
(let (($x965 (or false false false)))
(let (($x831 (or $x965 false)))
(let (($x429 (or false $x831 (or $x1351))))
(and (not $x429) (or $x429 (and (distinct ?x1335 ?x1335) true)))))))))))
(check-sat)
; query 38: function gsm_L_asl, block 7, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1339 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x388 ((_ zero_extend 31) ?x1339)))
(let ((?x1335 (bvsub (_ bv0 32) ?x388)))
(let ((?x1176 ((_ sign_extend 32) ?x1335)))
(let (($x1351 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x388)) ((_ sign_extend 1) ?x1335)) true)))
(let (($x965 (or false false false)))
(let (($x831 (or $x965 false)))
(let (($x429 (or false $x831 (or $x1351))))
(let (($x778 (or $x429 false)))
(and (not $x778) (or $x778 (and (distinct ?x1176 ?x1176) true)))))))))))))
(check-sat)
; query 39: function gsm_L_asl, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1339 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x965 (or false false false)))
(let (($x813 (not $x965)))
(and $x813 (or $x965 (and (distinct ?x1339 ?x1339) true)))))))
(check-sat)
; query 40: function gsm_L_asl, block 7, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1339 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x388 ((_ zero_extend 31) ?x1339)))
(let (($x965 (or false false false)))
(let (($x831 (or $x965 false)))
(let (($x655 (not $x831)))
(and $x655 (or $x831 (and (distinct ?x388 ?x388) true)))))))))
(check-sat)
; query 41: function gsm_L_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x547 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x965 (or false false false)))
(let (($x813 (not $x965)))
(and $x813 (or $x965 (and (distinct ?x547 ?x547) true)))))))
(check-sat)
; query 42: function gsm_L_asr, block 12, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x303 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x965 (or false false false)))
(let (($x813 (not $x965)))
(and $x813 (or $x965 (and (distinct ?x303 ?x303) true)))))))
(check-sat)
; query 43: function gsm_L_asr, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x2073 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in1_32))) true)))
(let (($x2035 (or false false (or $x2073))))
(and (not $x2035) (or $x2035 (and (distinct (bvsub (_ bv0 32) in1_32) (bvsub (_ bv0 32) in1_32)) true))))))
(check-sat)
; query 44: function gsm_L_asr, block 14, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x210 (bvsub (_ bv0 32) in1_32)))
(let ((?x344 ((_ zero_extend 32) ?x210)))
(let (($x2073 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x210)) true)))
(let (($x2035 (or false false (or $x2073))))
(let (($x2005 (or $x2035 (or (= ((_ extract 31 31) ?x210) (_ bv1 1))))))
(and (not (or $x2035 false)) (or $x2005 (and (distinct ?x344 ?x344) true)))))))))
(check-sat)
; query 45: function gsm_L_asr, block 14, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x210 (bvsub (_ bv0 32) in1_32)))
(let ((?x344 ((_ zero_extend 32) ?x210)))
(let ((?x1985 (bvshl in0_64 ?x344)))
(let (($x1206 (bvuge ?x344 (_ bv64 64))))
(let (($x2073 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x210)) true)))
(let (($x2035 (or false false (or $x2073))))
(let (($x2005 (or $x2035 (or (= ((_ extract 31 31) ?x210) (_ bv1 1))))))
(and (not (or (or false (or $x2035 false) false) $x1206)) (or (or (or false $x2005 false) $x1206) (and (distinct ?x1985 ?x1985) true)))))))))))
(check-sat)
; query 46: function gsm_L_asr, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x1001 (or false (or (= ((_ extract 31 31) in1_32) (_ bv1 1))))))
(let (($x470 (or false false)))
(let (($x1042 (not $x470)))
(and $x1042 (or $x1001 (and (distinct ((_ zero_extend 32) in1_32) ((_ zero_extend 32) in1_32)) true)))))))
(check-sat)
; query 47: function gsm_L_asr, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x432 ((_ zero_extend 32) in1_32)))
(let ((?x177 (bvashr in0_64 ?x432)))
(let (($x981 (bvuge ?x432 (_ bv64 64))))
(let (($x374 (or (or false (or false (or (= ((_ extract 31 31) in1_32) (_ bv1 1)))) false) $x981)))
(let (($x226 (not (or (or false (or false false) false) $x981))))
(and $x226 (or $x374 (and (distinct ?x177 ?x177) true)))))))))
(check-sat)
; query 48: function gsm_L_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1339 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x965 (or false false false)))
(let (($x813 (not $x965)))
(and $x813 (or $x965 (and (distinct ?x1339 ?x1339) true)))))))
(check-sat)
; query 49: function gsm_L_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1339 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x388 ((_ zero_extend 31) ?x1339)))
(let (($x965 (or false false false)))
(let (($x831 (or $x965 false)))
(let (($x655 (not $x831)))
(and $x655 (or $x831 (and (distinct ?x388 ?x388) true)))))))))
(check-sat)
; query 50: function gsm_L_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1339 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x388 ((_ zero_extend 31) ?x1339)))
(let ((?x1335 (bvsub (_ bv0 32) ?x388)))
(let (($x1351 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x388)) ((_ sign_extend 1) ?x1335)) true)))
(let (($x965 (or false false false)))
(let (($x831 (or $x965 false)))
(let (($x429 (or false $x831 (or $x1351))))
(and (not $x429) (or $x429 (and (distinct ?x1335 ?x1335) true)))))))))))
(check-sat)
; query 51: function gsm_L_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1339 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x388 ((_ zero_extend 31) ?x1339)))
(let ((?x1335 (bvsub (_ bv0 32) ?x388)))
(let ((?x1176 ((_ sign_extend 32) ?x1335)))
(let (($x1351 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x388)) ((_ sign_extend 1) ?x1335)) true)))
(let (($x965 (or false false false)))
(let (($x831 (or $x965 false)))
(let (($x429 (or false $x831 (or $x1351))))
(let (($x778 (or $x429 false)))
(and (not $x778) (or $x778 (and (distinct ?x1176 ?x1176) true)))))))))))))
(check-sat)
; query 52: function gsm_L_asr, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1601 (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x965 (or false false false)))
(let (($x813 (not $x965)))
(and $x813 (or $x965 (and (distinct ?x1601 ?x1601) true)))))))
(check-sat)
; query 53: function gsm_L_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x547 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x965 (or false false false)))
(let (($x813 (not $x965)))
(and $x813 (or $x965 (and (distinct ?x547 ?x547) true)))))))
(check-sat)
; query 54: function gsm_L_mult, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x470 (or false false)))
(let (($x1042 (not $x470)))
(and $x1042 (or $x470 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 55: function gsm_L_mult, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1236 (ite (and (distinct (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) true) (_ bv1 1) (_ bv0 1))))
(let (($x470 (or false false)))
(let (($x1709 (or $x470 false false)))
(let (($x109 (not $x1709)))
(and $x109 (or $x1709 (and (distinct ?x1236 ?x1236) true))))))))
(check-sat)
; query 56: function gsm_L_mult, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x470 (or false false)))
(let (($x1042 (not $x470)))
(and $x1042 (or $x470 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 57: function gsm_L_mult, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1079 (ite (and (distinct (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) true) (_ bv1 1) (_ bv0 1))))
(let (($x470 (or false false)))
(let (($x1709 (or $x470 false false)))
(let (($x109 (not $x1709)))
(and $x109 (or $x1709 (and (distinct ?x1079 ?x1079) true))))))))
(check-sat)
; query 58: function gsm_L_sub, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in11_64 () (_ BitVec 64))
(assert
 (let (($x1347 (and (distinct (bvadd ((_ zero_extend 1) in11_64) ((_ zero_extend 1) (_ bv1 64))) ((_ zero_extend 1) (bvadd in11_64 (_ bv1 64)))) true)))
(let (($x644 (and (distinct (bvadd ((_ sign_extend 1) in11_64) ((_ sign_extend 1) (_ bv1 64))) ((_ sign_extend 1) (bvadd in11_64 (_ bv1 64)))) true)))
(let (($x1856 (or (or false false (or $x644 $x1347)) (and (distinct (bvadd in11_64 (_ bv1 64)) (bvadd in11_64 (_ bv1 64))) true))))
(let (($x965 (or false false false)))
(let (($x813 (not $x965)))
(and $x813 $x1856)))))))
(check-sat)
; query 59: function gsm_L_sub, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x414 (ite (bvsge (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x965 (or false false false)))
(let (($x813 (not $x965)))
(and $x813 (or $x965 (and (distinct ?x414 ?x414) true)))))))
(check-sat)
; query 60: function gsm_L_sub, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x1414 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvsub in0_64 in1_64))) true)))
(let (($x445 (or false false (or $x1414))))
(let (($x560 (or $x445 (and (distinct (bvsub in0_64 in1_64) (bvsub in0_64 in1_64)) true))))
(and (not $x445) $x560)))))
(check-sat)
; query 61: function gsm_L_sub, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1122 (bvadd in0_64 (_ bv1 64))))
(let ((?x1035 ((_ sign_extend 1) ?x1122)))
(let (($x373 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1035) true)))))
(and (not $x373) (or $x373 (and (distinct ?x1122 ?x1122) true)))))))
(check-sat)
; query 62: function gsm_L_sub, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1122 (bvadd in0_64 (_ bv1 64))))
(let ((?x1854 (bvsub (_ bv0 64) ?x1122)))
(let (($x203 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1122)) ((_ sign_extend 1) ?x1854)) true)))
(let ((?x1035 ((_ sign_extend 1) ?x1122)))
(let (($x373 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1035) true)))))
(let (($x633 (or false $x373 (or $x203))))
(and (not $x633) (or $x633 (and (distinct ?x1854 ?x1854) true))))))))))
(check-sat)
; query 63: function gsm_L_sub, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1122 (bvadd in0_64 (_ bv1 64))))
(let ((?x1854 (bvsub (_ bv0 64) ?x1122)))
(let ((?x541 (bvadd ?x1854 in1_64)))
(let (($x1083 (and (distinct (bvadd ((_ zero_extend 1) ?x1854) ((_ zero_extend 1) in1_64)) ((_ zero_extend 1) ?x541)) true)))
(let (($x203 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1122)) ((_ sign_extend 1) ?x1854)) true)))
(let ((?x1035 ((_ sign_extend 1) ?x1122)))
(let (($x373 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1035) true)))))
(let (($x633 (or false $x373 (or $x203))))
(let (($x508 (or $x633 false (or $x1083))))
(and (not (or $x633 false false)) (or $x508 (and (distinct ?x541 ?x541) true)))))))))))))
(check-sat)
; query 64: function gsm_L_sub, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x170 (ite (bvuge (bvadd (bvsub (_ bv0 64) (bvadd in0_64 (_ bv1 64))) in1_64) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let ((?x1884 ((_ zero_extend 1) in1_64)))
(let ((?x1122 (bvadd in0_64 (_ bv1 64))))
(let ((?x1854 (bvsub (_ bv0 64) ?x1122)))
(let ((?x467 ((_ zero_extend 1) ?x1854)))
(let (($x203 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1122)) ((_ sign_extend 1) ?x1854)) true)))
(let ((?x1035 ((_ sign_extend 1) ?x1122)))
(let (($x373 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1035) true)))))
(let (($x633 (or false $x373 (or $x203))))
(let (($x508 (or $x633 false (or (and (distinct (bvadd ?x467 ?x1884) ((_ zero_extend 1) (bvadd ?x1854 in1_64))) true)))))
(and (not (or (or $x633 false false) false false)) (or (or $x508 false false) (and (distinct ?x170 ?x170) true))))))))))))))
(check-sat)
; query 65: function gsm_L_sub, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_64 () (_ BitVec 64))
(assert
 (let ((?x1265 (bvsub (_ bv0 64) in25_64)))
(let ((?x624 ((_ sign_extend 1) ?x1265)))
(let (($x1230 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in25_64)) ?x624) true)))))
(and (not $x1230) (or $x1230 (and (distinct ?x1265 ?x1265) true)))))))
(check-sat)
; query 66: function gsm_L_sub, block 28, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_64 () (_ BitVec 64))
(assert
 (let ((?x1265 (bvsub (_ bv0 64) in25_64)))
(let ((?x793 (bvsub ?x1265 (_ bv1 64))))
(let (($x1011 (and (distinct (bvsub ((_ zero_extend 1) ?x1265) ((_ zero_extend 1) (_ bv1 64))) ((_ zero_extend 1) ?x793)) true)))
(let (($x1506 (and (distinct (bvsub ((_ sign_extend 1) ?x1265) ((_ sign_extend 1) (_ bv1 64))) ((_ sign_extend 1) ?x793)) true)))
(let ((?x624 ((_ sign_extend 1) ?x1265)))
(let (($x1230 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in25_64)) ?x624) true)))))
(and (not (or $x1230 false (or $x1506))) (or (or $x1230 false (or $x1506 $x1011)) (and (distinct ?x793 ?x793) true))))))))))
(check-sat)
; query 67: function gsm_L_sub, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x66 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x965 (or false false false)))
(let (($x813 (not $x965)))
(and $x813 (or $x965 (and (distinct ?x66 ?x66) true)))))))
(check-sat)
; query 68: function gsm_L_sub, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x1414 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvsub in0_64 in1_64))) true)))
(let (($x445 (or false false (or $x1414))))
(let (($x560 (or $x445 (and (distinct (bvsub in0_64 in1_64) (bvsub in0_64 in1_64)) true))))
(and (not $x445) $x560)))))
(check-sat)
; query 69: function gsm_L_sub, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x946 (bvadd in1_64 (_ bv1 64))))
(let ((?x1080 (bvsub (_ bv0 64) ?x946)))
(let (($x1051 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x946)) ((_ sign_extend 1) ?x1080)) true)))
(let ((?x46 ((_ sign_extend 1) ?x946)))
(let (($x1551 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x46) true)))))
(let (($x1823 (or false $x1551 (or $x1051))))
(and (not $x1823) (or $x1823 (and (distinct ?x1080 ?x1080) true))))))))))
(check-sat)
; query 70: function gsm_L_sub, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x946 (bvadd in1_64 (_ bv1 64))))
(let ((?x1080 (bvsub (_ bv0 64) ?x946)))
(let ((?x17 (bvadd in0_64 ?x1080)))
(let (($x553 (and (distinct (bvadd ((_ zero_extend 1) in0_64) ((_ zero_extend 1) ?x1080)) ((_ zero_extend 1) ?x17)) true)))
(let (($x1051 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x946)) ((_ sign_extend 1) ?x1080)) true)))
(let ((?x46 ((_ sign_extend 1) ?x946)))
(let (($x1551 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x46) true)))))
(let (($x1823 (or false $x1551 (or $x1051))))
(let (($x369 (or false $x1823 (or $x553))))
(and (not (or false $x1823 false)) (or $x369 (and (distinct ?x17 ?x17) true)))))))))))))
(check-sat)
; query 71: function gsm_L_sub, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1383 (ite (bvuge (bvadd in0_64 (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64)))) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let ((?x946 (bvadd in1_64 (_ bv1 64))))
(let ((?x1080 (bvsub (_ bv0 64) ?x946)))
(let ((?x744 ((_ zero_extend 1) ?x1080)))
(let ((?x266 ((_ zero_extend 1) in0_64)))
(let (($x1051 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x946)) ((_ sign_extend 1) ?x1080)) true)))
(let ((?x46 ((_ sign_extend 1) ?x946)))
(let (($x1551 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x46) true)))))
(let (($x1823 (or false $x1551 (or $x1051))))
(let (($x369 (or false $x1823 (or (and (distinct (bvadd ?x266 ?x744) ((_ zero_extend 1) (bvadd in0_64 ?x1080))) true)))))
(and (not (or (or false $x1823 false) false false)) (or (or $x369 false false) (and (distinct ?x1383 ?x1383) true))))))))))))))
(check-sat)
; query 72: function gsm_L_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x946 (bvadd in1_64 (_ bv1 64))))
(let ((?x46 ((_ sign_extend 1) ?x946)))
(let (($x1551 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x46) true)))))
(and (not $x1551) (or $x1551 (and (distinct ?x946 ?x946) true)))))))
(check-sat)
; query 73: function gsm_L_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x173 (ite (bvsle (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x965 (or false false false)))
(let (($x813 (not $x965)))
(and $x813 (or $x965 (and (distinct ?x173 ?x173) true)))))))
(check-sat)
; query 74: function gsm_abs, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x470 (or false false)))
(let (($x1042 (not $x470)))
(and $x1042 (or $x470 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 75: function gsm_abs, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1536 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x470 (or false false)))
(let (($x1709 (or $x470 false false)))
(let (($x109 (not $x1709)))
(and $x109 (or $x1709 (and (distinct ?x1536 ?x1536) true))))))))
(check-sat)
; query 76: function gsm_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_64 () (_ BitVec 64))
(assert
 (let ((?x1048 (ite (bvslt (_ bv32767 64) in5_64) (_ bv1 1) (_ bv0 1))))
(let (($x965 (or false false false)))
(let (($x813 (not $x965)))
(and $x813 (or $x965 (and (distinct ?x1048 ?x1048) true)))))))
(check-sat)
; query 77: function gsm_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x470 (or false false)))
(let (($x1042 (not $x470)))
(and $x1042 (or $x470 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 78: function gsm_add, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x470 (or false false)))
(let (($x1042 (not $x470)))
(and $x1042 (or $x470 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 79: function gsm_add, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x773 ((_ sign_extend 48) in1_16)))
(let ((?x291 ((_ sign_extend 48) in0_16)))
(let ((?x923 (bvadd ?x291 ?x773)))
(let (($x423 (and (distinct (bvadd ((_ sign_extend 1) ?x291) ((_ sign_extend 1) ?x773)) ((_ sign_extend 1) ?x923)) true)))
(let (($x470 (or false false)))
(let (($x1318 (or $x470 $x470 (or $x423))))
(and (not $x1318) (or $x1318 (and (distinct ?x923 ?x923) true))))))))))
(check-sat)
; query 80: function gsm_add, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1564 (ite (bvsgt (_ bv18446744073709518848 64) (bvadd ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x773 ((_ sign_extend 48) in1_16)))
(let ((?x1030 ((_ sign_extend 1) ?x773)))
(let ((?x291 ((_ sign_extend 48) in0_16)))
(let ((?x1031 ((_ sign_extend 1) ?x291)))
(let (($x470 (or false false)))
(let (($x1318 (or $x470 $x470 (or (and (distinct (bvadd ?x1031 ?x1030) ((_ sign_extend 1) (bvadd ?x291 ?x773))) true)))))
(let (($x774 (or $x1318 false false)))
(and (not $x774) (or $x774 (and (distinct ?x1564 ?x1564) true))))))))))))
(check-sat)
; query 81: function gsm_asl, block 13, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x303 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x965 (or false false false)))
(let (($x813 (not $x965)))
(and $x813 (or $x965 (and (distinct ?x303 ?x303) true)))))))
(check-sat)
; query 82: function gsm_asl, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x470 (or false false)))
(let (($x1042 (not $x470)))
(and $x1042 (or $x470 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 83: function gsm_asl, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x220 ((_ sign_extend 16) in0_16)))
(let ((?x1853 (bvshl ?x220 in1_32)))
(let (($x1933 (bvuge in1_32 (_ bv32 32))))
(let (($x470 (or false false)))
(let (($x872 (or (or $x470 false (or (and (distinct (bvashr ?x1853 in1_32) ?x220) true))) $x1933)))
(let (($x1709 (or $x470 false false)))
(let (($x1923 (or $x1709 $x1933)))
(let (($x1017 (not $x1923)))
(and $x1017 (or $x872 (and (distinct ?x1853 ?x1853) true))))))))))))
(check-sat)
; query 84: function gsm_asl, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x220 ((_ sign_extend 16) in0_16)))
(let ((?x1853 (bvshl ?x220 in1_32)))
(let ((?x1903 ((_ extract 15 0) ?x1853)))
(let (($x1933 (bvuge in1_32 (_ bv32 32))))
(let (($x470 (or false false)))
(let (($x872 (or (or $x470 false (or (and (distinct (bvashr ?x1853 in1_32) ?x220) true))) $x1933)))
(let (($x573 (not (or (or (or $x470 false false) $x1933) false))))
(and $x573 (or (or $x872 false) (and (distinct ?x1903 ?x1903) true)))))))))))
(check-sat)
; query 85: function gsm_asl, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1863 (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x965 (or false false false)))
(let (($x813 (not $x965)))
(and $x813 (or $x965 (and (distinct ?x1863 ?x1863) true)))))))
(check-sat)
; query 86: function gsm_asl, block 7, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1536 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x223 ((_ zero_extend 31) ?x1536)))
(let (($x470 (or false false)))
(let (($x1709 (or $x470 false false)))
(let (($x1960 (or $x1709 false)))
(and (not $x1960) (or $x1960 (and (distinct ?x223 ?x223) true)))))))))
(check-sat)
; query 87: function gsm_asl, block 7, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1536 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x223 ((_ zero_extend 31) ?x1536)))
(let ((?x489 (bvsub (_ bv0 32) ?x223)))
(let (($x1966 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x223)) ((_ sign_extend 1) ?x489)) true)))
(let (($x470 (or false false)))
(let (($x1709 (or $x470 false false)))
(let (($x1960 (or $x1709 false)))
(let (($x1962 (or false $x1960 (or $x1966))))
(and (not $x1962) (or $x1962 (and (distinct ?x489 ?x489) true))))))))))))
(check-sat)
; query 88: function gsm_asl, block 7, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1536 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x223 ((_ zero_extend 31) ?x1536)))
(let ((?x489 (bvsub (_ bv0 32) ?x223)))
(let ((?x1963 ((_ extract 15 0) ?x489)))
(let (($x1966 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x223)) ((_ sign_extend 1) ?x489)) true)))
(let (($x470 (or false false)))
(let (($x1709 (or $x470 false false)))
(let (($x1960 (or $x1709 false)))
(let (($x1962 (or false $x1960 (or $x1966))))
(let (($x1987 (or (or $x1962 (or (and (distinct ((_ sign_extend 16) ?x1963) ?x489) true))) (and (distinct ?x1963 ?x1963) true))))
(and (not (or $x1962 false)) $x1987))))))))))))
(check-sat)
; query 89: function gsm_asl, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x470 (or false false)))
(let (($x1042 (not $x470)))
(and $x1042 (or $x470 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 90: function gsm_asl, block 7, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1536 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x470 (or false false)))
(let (($x1709 (or $x470 false false)))
(let (($x109 (not $x1709)))
(and $x109 (or $x1709 (and (distinct ?x1536 ?x1536) true))))))))
(check-sat)
; query 91: function gsm_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x92 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x965 (or false false false)))
(let (($x813 (not $x965)))
(and $x813 (or $x965 (and (distinct ?x92 ?x92) true)))))))
(check-sat)
; query 92: function gsm_asr, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1863 (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x965 (or false false false)))
(let (($x813 (not $x965)))
(and $x813 (or $x965 (and (distinct ?x1863 ?x1863) true)))))))
(check-sat)
; query 93: function gsm_asr, block 13, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x303 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x965 (or false false false)))
(let (($x813 (not $x965)))
(and $x813 (or $x965 (and (distinct ?x303 ?x303) true)))))))
(check-sat)
; query 94: function gsm_asr, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x470 (or false false)))
(let (($x1042 (not $x470)))
(and $x1042 (or $x470 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 95: function gsm_asr, block 15, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x2073 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in1_32))) true)))
(let (($x2035 (or false false (or $x2073))))
(and (not $x2035) (or $x2035 (and (distinct (bvsub (_ bv0 32) in1_32) (bvsub (_ bv0 32) in1_32)) true))))))
(check-sat)
; query 96: function gsm_asr, block 15, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x210 (bvsub (_ bv0 32) in1_32)))
(let ((?x220 ((_ sign_extend 16) in0_16)))
(let ((?x2008 (bvshl ?x220 ?x210)))
(let (($x1998 (bvuge ?x210 (_ bv32 32))))
(let (($x2073 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x210)) true)))
(let (($x2035 (or false false (or $x2073))))
(let (($x470 (or false false)))
(let (($x1992 (or (or $x470 $x2035 (or (and (distinct (bvashr ?x2008 ?x210) ?x220) true))) $x1998)))
(and (not (or (or $x470 $x2035 false) $x1998)) (or $x1992 (and (distinct ?x2008 ?x2008) true))))))))))))
(check-sat)
; query 97: function gsm_asr, block 15, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x210 (bvsub (_ bv0 32) in1_32)))
(let ((?x220 ((_ sign_extend 16) in0_16)))
(let ((?x2008 (bvshl ?x220 ?x210)))
(let ((?x1997 ((_ extract 15 0) ?x2008)))
(let (($x1998 (bvuge ?x210 (_ bv32 32))))
(let (($x2073 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x210)) true)))
(let (($x2035 (or false false (or $x2073))))
(let (($x470 (or false false)))
(let (($x1992 (or (or $x470 $x2035 (or (and (distinct (bvashr ?x2008 ?x210) ?x220) true))) $x1998)))
(and (not (or (or (or $x470 $x2035 false) $x1998) false)) (or (or $x1992 false) (and (distinct ?x1997 ?x1997) true)))))))))))))
(check-sat)
; query 98: function gsm_asr, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x470 (or false false)))
(let (($x1042 (not $x470)))
(and $x1042 (or $x470 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 99: function gsm_asr, block 20, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x220 ((_ sign_extend 16) in0_16)))
(let ((?x2002 (bvashr ?x220 in1_32)))
(let (($x1933 (bvuge in1_32 (_ bv32 32))))
(let (($x470 (or false false)))
(let (($x1709 (or $x470 false false)))
(let (($x1923 (or $x1709 $x1933)))
(let (($x1017 (not $x1923)))
(and $x1017 (or $x1923 (and (distinct ?x2002 ?x2002) true)))))))))))
(check-sat)
; query 100: function gsm_asr, block 20, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x220 ((_ sign_extend 16) in0_16)))
(let ((?x2002 (bvashr ?x220 in1_32)))
(let ((?x2021 ((_ extract 15 0) ?x2002)))
(let (($x1933 (bvuge in1_32 (_ bv32 32))))
(let (($x470 (or false false)))
(let (($x1709 (or $x470 false false)))
(let (($x1923 (or $x1709 $x1933)))
(let (($x2032 (or (or $x1923 (or (and (distinct ((_ sign_extend 16) ?x2021) ?x2002) true))) (and (distinct ?x2021 ?x2021) true))))
(let (($x573 (not (or $x1923 false))))
(and $x573 $x2032)))))))))))
(check-sat)
; query 101: function gsm_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x470 (or false false)))
(let (($x1042 (not $x470)))
(and $x1042 (or $x470 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 102: function gsm_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1536 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x470 (or false false)))
(let (($x1709 (or $x470 false false)))
(let (($x109 (not $x1709)))
(and $x109 (or $x1709 (and (distinct ?x1536 ?x1536) true))))))))
(check-sat)
; query 103: function gsm_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1536 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x223 ((_ zero_extend 31) ?x1536)))
(let (($x470 (or false false)))
(let (($x1709 (or $x470 false false)))
(let (($x1960 (or $x1709 false)))
(and (not $x1960) (or $x1960 (and (distinct ?x223 ?x223) true)))))))))
(check-sat)
; query 104: function gsm_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1536 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x223 ((_ zero_extend 31) ?x1536)))
(let ((?x489 (bvsub (_ bv0 32) ?x223)))
(let (($x1966 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x223)) ((_ sign_extend 1) ?x489)) true)))
(let (($x470 (or false false)))
(let (($x1709 (or $x470 false false)))
(let (($x1960 (or $x1709 false)))
(let (($x1962 (or false $x1960 (or $x1966))))
(and (not $x1962) (or $x1962 (and (distinct ?x489 ?x489) true))))))))))))
(check-sat)
; query 105: function gsm_asr, block 4, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1536 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x223 ((_ zero_extend 31) ?x1536)))
(let ((?x489 (bvsub (_ bv0 32) ?x223)))
(let ((?x1963 ((_ extract 15 0) ?x489)))
(let (($x1966 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x223)) ((_ sign_extend 1) ?x489)) true)))
(let (($x470 (or false false)))
(let (($x1709 (or $x470 false false)))
(let (($x1960 (or $x1709 false)))
(let (($x1962 (or false $x1960 (or $x1966))))
(let (($x1987 (or (or $x1962 (or (and (distinct ((_ sign_extend 16) ?x1963) ?x489) true))) (and (distinct ?x1963 ?x1963) true))))
(and (not (or $x1962 false)) $x1987))))))))))))
(check-sat)
; query 106: function gsm_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x92 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x965 (or false false false)))
(let (($x813 (not $x965)))
(and $x813 (or $x965 (and (distinct ?x92 ?x92) true)))))))
(check-sat)
; query 107: function gsm_debug_longwords, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in15_32 () (_ BitVec 32))
(assert
 (let ((?x2023 (ite (bvslt in15_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x965 (or false false false)))
(let (($x813 (not $x965)))
(and $x813 (or $x965 (and (distinct ?x2023 ?x2023) true)))))))
(check-sat)
; query 108: function gsm_debug_words, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in16_32 () (_ BitVec 32))
(assert
 (let ((?x2030 (ite (bvslt in16_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x965 (or false false false)))
(let (($x813 (not $x965)))
(and $x813 (or $x965 (and (distinct ?x2030 ?x2030) true)))))))
(check-sat)
; query 109: function gsm_div, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x470 (or false false)))
(let (($x1042 (not $x470)))
(and $x1042 (or $x470 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 110: function gsm_div, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x470 (or false false)))
(let (($x1042 (not $x470)))
(and $x1042 (or $x470 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 111: function gsm_div, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x470 (or false false)))
(let (($x1042 (not $x470)))
(and $x1042 (or $x470 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 112: function gsm_div, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x333 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x58 (and (distinct ?x333 ?x333) true)))
(let (($x470 (or false false)))
(let (($x1709 (or $x470 false false)))
(let (($x109 (not $x1709)))
(and $x109 (or $x1709 $x58))))))))
(check-sat)
; query 113: function gsm_mult, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x470 (or false false)))
(let (($x1042 (not $x470)))
(and $x1042 (or $x470 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 114: function gsm_mult, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x2039 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x470 (or false false)))
(let (($x1709 (or $x470 false false)))
(let (($x109 (not $x1709)))
(and $x109 (or $x1709 (and (distinct ?x2039 ?x2039) true))))))))
(check-sat)
; query 115: function gsm_mult, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x470 (or false false)))
(let (($x1042 (not $x470)))
(and $x1042 (or $x470 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 116: function gsm_mult, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x470 (or false false)))
(let (($x1042 (not $x470)))
(and $x1042 (or $x470 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 117: function gsm_mult, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x773 ((_ sign_extend 48) in1_16)))
(let ((?x291 ((_ sign_extend 48) in0_16)))
(let ((?x1003 (bvmul ?x291 ?x773)))
(let (($x2056 (and (distinct (bvmul ((_ sign_extend 64) ?x291) ((_ sign_extend 64) ?x773)) ((_ sign_extend 64) ?x1003)) true)))
(let (($x470 (or false false)))
(let (($x1091 (or $x470 $x470 (or $x2056))))
(and (not $x1091) (or $x1091 (and (distinct ?x1003 ?x1003) true))))))))))
(check-sat)
; query 118: function gsm_mult, block 9, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x773 ((_ sign_extend 48) in1_16)))
(let ((?x291 ((_ sign_extend 48) in0_16)))
(let ((?x1003 (bvmul ?x291 ?x773)))
(let ((?x2079 (bvashr ?x1003 (_ bv15 64))))
(let (($x2062 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x2056 (and (distinct (bvmul ((_ sign_extend 64) ?x291) ((_ sign_extend 64) ?x773)) ((_ sign_extend 64) ?x1003)) true)))
(let (($x470 (or false false)))
(let (($x1091 (or $x470 $x470 (or $x2056))))
(let (($x2057 (or (or $x1091 false false) $x2062)))
(and (not $x2057) (or $x2057 (and (distinct ?x2079 ?x2079) true)))))))))))))
(check-sat)
; query 119: function gsm_mult, block 9, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x773 ((_ sign_extend 48) in1_16)))
(let ((?x291 ((_ sign_extend 48) in0_16)))
(let ((?x1003 (bvmul ?x291 ?x773)))
(let ((?x2079 (bvashr ?x1003 (_ bv15 64))))
(let ((?x2067 ((_ extract 15 0) ?x2079)))
(let (($x2062 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x2056 (and (distinct (bvmul ((_ sign_extend 64) ?x291) ((_ sign_extend 64) ?x773)) ((_ sign_extend 64) ?x1003)) true)))
(let (($x470 (or false false)))
(let (($x1091 (or $x470 $x470 (or $x2056))))
(let (($x2057 (or (or $x1091 false false) $x2062)))
(let (($x2076 (or $x2057 false)))
(and (not $x2076) (or $x2076 (and (distinct ?x2067 ?x2067) true)))))))))))))))
(check-sat)
; query 120: function gsm_mult, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x470 (or false false)))
(let (($x1042 (not $x470)))
(and $x1042 (or $x470 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 121: function gsm_mult, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x2084 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x470 (or false false)))
(let (($x1709 (or $x470 false false)))
(let (($x109 (not $x1709)))
(and $x109 (or $x1709 (and (distinct ?x2084 ?x2084) true))))))))
(check-sat)
; query 122: function gsm_mult_r, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x470 (or false false)))
(let (($x1042 (not $x470)))
(and $x1042 (or $x470 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 123: function gsm_mult_r, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x2084 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x470 (or false false)))
(let (($x1709 (or $x470 false false)))
(let (($x109 (not $x1709)))
(and $x109 (or $x1709 (and (distinct ?x2084 ?x2084) true))))))))
(check-sat)
; query 124: function gsm_mult_r, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x470 (or false false)))
(let (($x1042 (not $x470)))
(and $x1042 (or $x470 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 125: function gsm_mult_r, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x470 (or false false)))
(let (($x1042 (not $x470)))
(and $x1042 (or $x470 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 126: function gsm_mult_r, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x773 ((_ sign_extend 48) in1_16)))
(let ((?x291 ((_ sign_extend 48) in0_16)))
(let ((?x1003 (bvmul ?x291 ?x773)))
(let (($x2056 (and (distinct (bvmul ((_ sign_extend 64) ?x291) ((_ sign_extend 64) ?x773)) ((_ sign_extend 64) ?x1003)) true)))
(let (($x470 (or false false)))
(let (($x1091 (or $x470 $x470 (or $x2056))))
(and (not $x1091) (or $x1091 (and (distinct ?x1003 ?x1003) true))))))))))
(check-sat)
; query 127: function gsm_mult_r, block 9, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x773 ((_ sign_extend 48) in1_16)))
(let ((?x291 ((_ sign_extend 48) in0_16)))
(let ((?x1003 (bvmul ?x291 ?x773)))
(let ((?x267 (bvadd ?x1003 (_ bv16384 64))))
(let (($x1373 (and (distinct (bvadd ((_ sign_extend 1) ?x1003) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x267)) true)))
(let (($x2056 (and (distinct (bvmul ((_ sign_extend 64) ?x291) ((_ sign_extend 64) ?x773)) ((_ sign_extend 64) ?x1003)) true)))
(let (($x470 (or false false)))
(let (($x1091 (or $x470 $x470 (or $x2056))))
(let (($x933 (or $x1091 false (or $x1373))))
(and (not $x933) (or $x933 (and (distinct ?x267 ?x267) true)))))))))))))
(check-sat)
; query 128: function gsm_mult_r, block 9, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x773 ((_ sign_extend 48) in1_16)))
(let ((?x291 ((_ sign_extend 48) in0_16)))
(let ((?x1003 (bvmul ?x291 ?x773)))
(let ((?x267 (bvadd ?x1003 (_ bv16384 64))))
(let ((?x478 (bvashr ?x267 (_ bv15 64))))
(let (($x2062 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1373 (and (distinct (bvadd ((_ sign_extend 1) ?x1003) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x267)) true)))
(let (($x2056 (and (distinct (bvmul ((_ sign_extend 64) ?x291) ((_ sign_extend 64) ?x773)) ((_ sign_extend 64) ?x1003)) true)))
(let (($x470 (or false false)))
(let (($x1091 (or $x470 $x470 (or $x2056))))
(let (($x933 (or $x1091 false (or $x1373))))
(let (($x763 (or (or $x933 false false) $x2062)))
(and (not $x763) (or $x763 (and (distinct ?x478 ?x478) true))))))))))))))))
(check-sat)
; query 129: function gsm_mult_r, block 9, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x773 ((_ sign_extend 48) in1_16)))
(let ((?x291 ((_ sign_extend 48) in0_16)))
(let ((?x1003 (bvmul ?x291 ?x773)))
(let ((?x267 (bvadd ?x1003 (_ bv16384 64))))
(let ((?x478 (bvashr ?x267 (_ bv15 64))))
(let ((?x221 (bvand ?x478 (_ bv65535 64))))
(let (($x2062 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1373 (and (distinct (bvadd ((_ sign_extend 1) ?x1003) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x267)) true)))
(let (($x2056 (and (distinct (bvmul ((_ sign_extend 64) ?x291) ((_ sign_extend 64) ?x773)) ((_ sign_extend 64) ?x1003)) true)))
(let (($x470 (or false false)))
(let (($x1091 (or $x470 $x470 (or $x2056))))
(let (($x933 (or $x1091 false (or $x1373))))
(let (($x763 (or (or $x933 false false) $x2062)))
(let (($x723 (or $x763 false false)))
(and (not $x723) (or $x723 (and (distinct ?x221 ?x221) true))))))))))))))))))
(check-sat)
; query 130: function gsm_mult_r, block 9, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x773 ((_ sign_extend 48) in1_16)))
(let ((?x291 ((_ sign_extend 48) in0_16)))
(let ((?x1003 (bvmul ?x291 ?x773)))
(let ((?x267 (bvadd ?x1003 (_ bv16384 64))))
(let ((?x478 (bvashr ?x267 (_ bv15 64))))
(let ((?x221 (bvand ?x478 (_ bv65535 64))))
(let ((?x308 ((_ extract 15 0) ?x221)))
(let (($x2062 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1373 (and (distinct (bvadd ((_ sign_extend 1) ?x1003) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x267)) true)))
(let (($x2056 (and (distinct (bvmul ((_ sign_extend 64) ?x291) ((_ sign_extend 64) ?x773)) ((_ sign_extend 64) ?x1003)) true)))
(let (($x470 (or false false)))
(let (($x1091 (or $x470 $x470 (or $x2056))))
(let (($x933 (or $x1091 false (or $x1373))))
(let (($x763 (or (or $x933 false false) $x2062)))
(let (($x723 (or $x763 false false)))
(let (($x1595 (or (or $x723 (or (and (distinct ((_ zero_extend 48) ?x308) ?x221) true))) (and (distinct ?x308 ?x308) true))))
(and (not (or $x723 false)) $x1595))))))))))))))))))
(check-sat)
; query 131: function gsm_mult_r, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x470 (or false false)))
(let (($x1042 (not $x470)))
(and $x1042 (or $x470 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 132: function gsm_mult_r, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x2039 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x470 (or false false)))
(let (($x1709 (or $x470 false false)))
(let (($x109 (not $x1709)))
(and $x109 (or $x1709 (and (distinct ?x2039 ?x2039) true))))))))
(check-sat)
; query 133: function gsm_norm, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1339 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x965 (or false false false)))
(let (($x813 (not $x965)))
(and $x813 (or $x965 (and (distinct ?x1339 (ite (bvsge (_ bv18446744072635809792 64) in0_64) (_ bv1 1) (_ bv0 1))) true)))))))
(check-sat)
; query 134: function gsm_norm, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1267 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x965 (or false false false)))
(let (($x813 (not $x965)))
(and $x813 (or $x965 (and (distinct ?x1267 ?x1267) true)))))))
(check-sat)
; query 135: function gsm_norm, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1267 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x474 (bvxor ?x1267 (_ bv1 1))))
(let (($x965 (or false false false)))
(let (($x197 (or $x965 false false)))
(let (($x542 (not $x197)))
(and $x542 (or $x197 (and (distinct ?x474 ?x474) true)))))))))
(check-sat)
; query 136: function gsm_norm, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1267 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x474 (bvxor ?x1267 (_ bv1 1))))
(let ((?x1330 ((_ zero_extend 31) ?x474)))
(let (($x965 (or false false false)))
(let (($x197 (or $x965 false false)))
(let (($x421 (or $x197 false)))
(and (not $x421) (or $x421 (and (distinct ?x1330 ?x1330) true))))))))))
(check-sat)
; query 137: function gsm_norm, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1267 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x474 (bvxor ?x1267 (_ bv1 1))))
(let ((?x1330 ((_ zero_extend 31) ?x474)))
(let (($x965 (or false false false)))
(let (($x197 (or $x965 false false)))
(let (($x421 (or $x197 false)))
(let (($x1870 (or (or $x421 (or (= ((_ extract 31 31) ?x1330) (_ bv1 1)))) (and (distinct ((_ sign_extend 32) ?x1330) ((_ zero_extend 32) ?x1330)) true))))
(and (not (or $x421 false)) $x1870)))))))))
(check-sat)
; query 138: function gsm_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_64 () (_ BitVec 64))
(assert
 (let ((?x1048 (ite (bvslt (_ bv32767 64) in5_64) (_ bv1 1) (_ bv0 1))))
(let (($x965 (or false false false)))
(let (($x813 (not $x965)))
(and $x813 (or $x965 (and (distinct ?x1048 ?x1048) true)))))))
(check-sat)
; query 139: function gsm_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x470 (or false false)))
(let (($x1042 (not $x470)))
(and $x1042 (or $x470 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 140: function gsm_sub, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x470 (or false false)))
(let (($x1042 (not $x470)))
(and $x1042 (or $x470 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 141: function gsm_sub, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x773 ((_ sign_extend 48) in1_16)))
(let ((?x291 ((_ sign_extend 48) in0_16)))
(let ((?x1560 (bvsub ?x291 ?x773)))
(let (($x1887 (and (distinct (bvsub ((_ sign_extend 1) ?x291) ((_ sign_extend 1) ?x773)) ((_ sign_extend 1) ?x1560)) true)))
(let (($x470 (or false false)))
(let (($x1474 (or $x470 $x470 (or $x1887))))
(and (not $x1474) (or $x1474 (and (distinct ?x1560 ?x1560) true))))))))))
(check-sat)
; query 142: function gsm_sub, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x475 (ite (bvsgt (_ bv18446744073709518848 64) (bvsub ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x773 ((_ sign_extend 48) in1_16)))
(let ((?x1030 ((_ sign_extend 1) ?x773)))
(let ((?x291 ((_ sign_extend 48) in0_16)))
(let ((?x1031 ((_ sign_extend 1) ?x291)))
(let (($x470 (or false false)))
(let (($x1474 (or $x470 $x470 (or (and (distinct (bvsub ?x1031 ?x1030) ((_ sign_extend 1) (bvsub ?x291 ?x773))) true)))))
(let (($x1450 (or $x1474 false false)))
(and (not $x1450) (or $x1450 (and (distinct ?x475 ?x475) true))))))))))))
(check-sat)
; query 143: function ok_to_replace, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x834 (ite (and (distinct (_ bv4294967295 32) in.01_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x965 (or false false false)))
(let (($x813 (not $x965)))
(and $x813 (or $x965 (and (distinct ?x834 ?x834) true)))))))
(check-sat)
; query 144: function suffix, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_64 () (_ BitVec 64))
(declare-fun in3_64 () (_ BitVec 64))
(assert
 (let ((?x805 (ite (bvule in3_64 in4_64) (_ bv1 1) (_ bv0 1))))
(let (($x965 (or false false false)))
(let (($x813 (not $x965)))
(and $x813 (or $x965 (and (distinct ?x805 ?x805) true)))))))
(check-sat)
