; OptiPhase-Sigma refinement certificate for sweep K49-R6-031
; query 0: function Decoding_of_the_coded_Log_Area_Ratios, block 107, name %108
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in104_64 () (_ BitVec 64))
(assert
 (let ((?x714 (ite (bvslt (_ bv0 64) in104_64) (_ bv1 1) (_ bv0 1))))
(let (($x1442 (or false false false)))
(let (($x1179 (not $x1442)))
(and $x1179 (or $x1442 (and (distinct ?x714 ?x714) true)))))))
(check-sat)
; query 1: function Decoding_of_the_coded_Log_Area_Ratios, block 107, name %109
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in104_64 () (_ BitVec 64))
(assert
 (let (($x528 (and (distinct ((_ zero_extend 63) (ite (bvslt (_ bv0 64) in104_64) (_ bv1 1) (_ bv0 1))) (ite (= (_ bv1 1) (ite (bvslt (_ bv0 64) in104_64) (_ bv1 1) (_ bv0 1))) (_ bv32767 64) (_ bv18446744073709518848 64))) true)))
(let (($x1442 (or false false false)))
(let (($x492 (or $x1442 (ite (= (_ bv1 1) (ite (bvslt (_ bv0 64) in104_64) (_ bv1 1) (_ bv0 1))) false false))))
(and (not (or $x1442 false)) (or $x492 $x528))))))
(check-sat)
; query 2: function Decoding_of_the_coded_Log_Area_Ratios, block 219, name %220
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in216_64 () (_ BitVec 64))
(assert
 (let (($x37 (and (distinct (ite (bvsge (_ bv18446744073709518848 64) in216_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv0 64) in216_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x1442 (or false false false)))
(let (($x1179 (not $x1442)))
(and $x1179 (or $x1442 $x37))))))
(check-sat)
; query 3: function gsm_L_add, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let (($x592 (and (distinct (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv18446744073709551615 64) in1_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x1442 (or false false false)))
(let (($x1179 (not $x1442)))
(and $x1179 (or $x1442 $x592))))))
(check-sat)
; query 4: function gsm_L_add, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x952 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvadd in0_64 in1_64))) true)))
(let (($x206 (or false false (or $x952))))
(let (($x411 (or $x206 (and (distinct (bvadd in0_64 in1_64) (bvadd in0_64 in1_64)) true))))
(and (not $x206) $x411)))))
(check-sat)
; query 5: function gsm_L_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x125 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x1442 (or false false false)))
(let (($x1179 (not $x1442)))
(and $x1179 (or $x1442 (and (distinct ?x125 ?x125) true)))))))
(check-sat)
; query 6: function gsm_L_asl, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x320 (and (distinct (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvsgt (_ bv4294967265 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x1442 (or false false false)))
(let (($x1179 (not $x1442)))
(and $x1179 (or $x1442 $x320))))))
(check-sat)
; query 7: function gsm_L_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x627 (and (distinct (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv31 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x1442 (or false false false)))
(let (($x1179 (not $x1442)))
(and $x1179 (or $x1442 $x627))))))
(check-sat)
; query 8: function gsm_L_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x627 (and (distinct (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv31 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x1442 (or false false false)))
(let (($x1179 (not $x1442)))
(and $x1179 (or $x1442 $x627))))))
(check-sat)
; query 9: function gsm_L_sub, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x90 (bvsub in0_64 in1_64)))
(let (($x29 (and (distinct ?x90 ?x90) true)))
(let (($x129 (and (distinct (bvsub ((_ zero_extend 1) in0_64) ((_ zero_extend 1) in1_64)) ((_ zero_extend 1) ?x90)) true)))
(let (($x639 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) ?x90)) true)))
(let (($x75 (or false false (or $x639))))
(let (($x55 (not $x75)))
(and $x55 (or (or false false (or $x129)) $x29)))))))))
(check-sat)
; query 10: function gsm_L_sub, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let (($x592 (and (distinct (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv18446744073709551615 64) in1_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x1442 (or false false false)))
(let (($x1179 (not $x1442)))
(and $x1179 (or $x1442 $x592))))))
(check-sat)
; query 11: function gsm_L_sub, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x90 (bvsub in0_64 in1_64)))
(let (($x29 (and (distinct ?x90 ?x90) true)))
(let (($x639 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) ?x90)) true)))
(let (($x75 (or false false (or $x639))))
(let (($x55 (not $x75)))
(and $x55 (or $x75 $x29))))))))
(check-sat)
; query 12: function gsm_L_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x116 (and (distinct (ite (bvsle (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv18446744073709551615 64) in0_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x1442 (or false false false)))
(let (($x1179 (not $x1442)))
(and $x1179 (or $x1442 $x116))))))
(check-sat)
; query 13: function gsm_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_64 () (_ BitVec 64))
(assert
 (let ((?x72 (ite (bvslt (_ bv32767 64) in5_64) (_ bv1 1) (_ bv0 1))))
(let (($x1442 (or false false false)))
(let (($x1179 (not $x1442)))
(and $x1179 (or $x1442 (and (distinct ?x72 ?x72) true)))))))
(check-sat)
; query 14: function gsm_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x781 (or false false)))
(let (($x362 (not $x781)))
(and $x362 (or $x781 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 15: function gsm_add, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x781 (or false false)))
(let (($x362 (not $x781)))
(and $x362 (or $x781 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 16: function gsm_add, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x74 ((_ sign_extend 48) in1_16)))
(let ((?x15 ((_ sign_extend 48) in0_16)))
(let ((?x82 (bvadd ?x15 ?x74)))
(let (($x79 (and (distinct (bvadd ((_ sign_extend 1) ?x15) ((_ sign_extend 1) ?x74)) ((_ sign_extend 1) ?x82)) true)))
(let (($x781 (or false false)))
(let (($x115 (or $x781 $x781 (or $x79))))
(and (not $x115) (or $x115 (and (distinct ?x82 ?x82) true))))))))))
(check-sat)
; query 17: function gsm_add, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x142 (ite (bvsgt (_ bv18446744073709518848 64) (bvadd ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x74 ((_ sign_extend 48) in1_16)))
(let ((?x223 ((_ sign_extend 1) ?x74)))
(let ((?x15 ((_ sign_extend 48) in0_16)))
(let ((?x68 ((_ sign_extend 1) ?x15)))
(let (($x781 (or false false)))
(let (($x115 (or $x781 $x781 (or (and (distinct (bvadd ?x68 ?x223) ((_ sign_extend 1) (bvadd ?x15 ?x74))) true)))))
(let (($x95 (or $x115 false false)))
(and (not $x95) (or $x95 (and (distinct ?x142 ?x142) true))))))))))))
(check-sat)
; query 18: function gsm_asl, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x27 (and (distinct (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvsgt (_ bv4294967281 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x1442 (or false false false)))
(let (($x1179 (not $x1442)))
(and $x1179 (or $x1442 $x27))))))
(check-sat)
; query 19: function gsm_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x619 (and (distinct (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv15 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x1442 (or false false false)))
(let (($x1179 (not $x1442)))
(and $x1179 (or $x1442 $x619))))))
(check-sat)
; query 20: function gsm_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x619 (and (distinct (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv15 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x1442 (or false false false)))
(let (($x1179 (not $x1442)))
(and $x1179 (or $x1442 $x619))))))
(check-sat)
; query 21: function gsm_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_64 () (_ BitVec 64))
(assert
 (let ((?x72 (ite (bvslt (_ bv32767 64) in5_64) (_ bv1 1) (_ bv0 1))))
(let (($x1442 (or false false false)))
(let (($x1179 (not $x1442)))
(and $x1179 (or $x1442 (and (distinct ?x72 ?x72) true)))))))
(check-sat)
; query 22: function gsm_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x781 (or false false)))
(let (($x362 (not $x781)))
(and $x362 (or $x781 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 23: function gsm_sub, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x781 (or false false)))
(let (($x362 (not $x781)))
(and $x362 (or $x781 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 24: function gsm_sub, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x74 ((_ sign_extend 48) in1_16)))
(let ((?x15 ((_ sign_extend 48) in0_16)))
(let ((?x204 (bvsub ?x15 ?x74)))
(let (($x83 (and (distinct (bvsub ((_ sign_extend 1) ?x15) ((_ sign_extend 1) ?x74)) ((_ sign_extend 1) ?x204)) true)))
(let (($x781 (or false false)))
(let (($x392 (or $x781 $x781 (or $x83))))
(and (not $x392) (or $x392 (and (distinct ?x204 ?x204) true))))))))))
(check-sat)
; query 25: function gsm_sub, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x446 (ite (bvsgt (_ bv18446744073709518848 64) (bvsub ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x74 ((_ sign_extend 48) in1_16)))
(let ((?x223 ((_ sign_extend 1) ?x74)))
(let ((?x15 ((_ sign_extend 48) in0_16)))
(let ((?x68 ((_ sign_extend 1) ?x15)))
(let (($x781 (or false false)))
(let (($x392 (or $x781 $x781 (or (and (distinct (bvsub ?x68 ?x223) ((_ sign_extend 1) (bvsub ?x15 ?x74))) true)))))
(let (($x235 (or $x392 false false)))
(and (not $x235) (or $x235 (and (distinct ?x446 ?x446) true))))))))))))
(check-sat)
