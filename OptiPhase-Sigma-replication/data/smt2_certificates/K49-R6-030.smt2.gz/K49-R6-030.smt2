; OptiPhase-Sigma refinement certificate for sweep K49-R6-030
; query 0: function APCM_inverse_quantization, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x604 (or false false)))
(let (($x308 (not $x604)))
(and $x308 (or $x604 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 1: function APCM_inverse_quantization, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x42 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x604 (or false false)))
(let (($x173 (or $x604 false false)))
(let (($x527 (not $x173)))
(and $x527 (or $x173 (and (distinct ?x42 ?x42) true))))))))
(check-sat)
; query 2: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x604 (or false false)))
(let (($x308 (not $x604)))
(and $x308 (or $x604 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 3: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x56 (ite (bvslt (_ bv15 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x604 (or false false)))
(let (($x173 (or $x604 false false)))
(let (($x527 (not $x173)))
(and $x527 (or $x173 (and (distinct ?x56 ?x56) true))))))))
(check-sat)
; query 4: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x604 (or false false)))
(let (($x308 (not $x604)))
(and $x308 (or $x604 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 5: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x71 (ite (bvsgt (_ bv40 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x604 (or false false)))
(let (($x173 (or $x604 false false)))
(let (($x527 (not $x173)))
(and $x527 (or $x173 (and (distinct ?x71 ?x71) true))))))))
(check-sat)
; query 6: function RPE_grid_positioning, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x604 (or false false)))
(let (($x308 (not $x604)))
(and $x308 (or $x604 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 7: function RPE_grid_positioning, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x100 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x696 (and (distinct ?x100 ?x100) true)))
(let (($x604 (or false false)))
(let (($x559 (or false $x604 false)))
(and (not $x559) (or $x559 $x696)))))))
(check-sat)
; query 8: function alaw_input, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x1248 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x594 (or false false (or $x1248))))
(and (not $x594) (or $x594 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 9: function gsm_L_add, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_64 () (_ BitVec 64))
(assert
 (let ((?x127 (bvsub (_ bv0 64) in13_64)))
(let ((?x49 ((_ sign_extend 1) ?x127)))
(let (($x1065 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in13_64)) ?x49) true)))))
(and (not $x1065) (or $x1065 (and (distinct ?x127 ?x127) true)))))))
(check-sat)
; query 10: function gsm_L_add, block 16, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_64 () (_ BitVec 64))
(assert
 (let ((?x127 (bvsub (_ bv0 64) in13_64)))
(let ((?x738 (bvsub ?x127 (_ bv2 64))))
(let (($x531 (and (distinct (bvsub ((_ sign_extend 1) ?x127) ((_ sign_extend 1) (_ bv2 64))) ((_ sign_extend 1) ?x738)) true)))
(let ((?x49 ((_ sign_extend 1) ?x127)))
(let (($x1065 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in13_64)) ?x49) true)))))
(let (($x612 (or $x1065 false (or $x531))))
(and (not $x612) (or $x612 (and (distinct ?x738 ?x738) true))))))))))
(check-sat)
; query 11: function gsm_L_add, block 21, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x515 (ite (bvsge (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x24 (or false false false)))
(let (($x882 (not $x24)))
(and $x882 (or $x24 (and (distinct ?x515 ?x515) true)))))))
(check-sat)
; query 12: function gsm_L_add, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x435 (bvadd in0_64 in1_64)))
(let (($x449 (and (distinct ?x435 ?x435) true)))
(let (($x116 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) ?x435)) true)))
(let (($x122 (or false false (or $x116))))
(and (not $x122) (or $x122 $x449)))))))
(check-sat)
; query 13: function gsm_L_add, block 25, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x435 (bvadd in0_64 in1_64)))
(let (($x449 (and (distinct ?x435 ?x435) true)))
(let (($x51 (and (distinct (bvadd ((_ zero_extend 1) in0_64) ((_ zero_extend 1) in1_64)) ((_ zero_extend 1) ?x435)) true)))
(let (($x119 (or false false (or $x51))))
(let (($x24 (or false false false)))
(let (($x882 (not $x24)))
(and $x882 (or $x119 $x449)))))))))
(check-sat)
; query 14: function gsm_L_add, block 25, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x26 (ite (bvugt (bvadd in0_64 in1_64) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x51 (and (distinct (bvadd ((_ zero_extend 1) in0_64) ((_ zero_extend 1) in1_64)) ((_ zero_extend 1) (bvadd in0_64 in1_64))) true)))
(let (($x119 (or false false (or $x51))))
(let (($x24 (or false false false)))
(let (($x95 (or $x24 false false)))
(let (($x500 (not $x95)))
(and $x500 (or (or $x119 false false) (and (distinct ?x26 ?x26) true))))))))))
(check-sat)
; query 15: function gsm_L_add, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x602 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x24 (or false false false)))
(let (($x882 (not $x24)))
(and $x882 (or $x24 (and (distinct ?x602 ?x602) true)))))))
(check-sat)
; query 16: function gsm_L_add, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x435 (bvadd in0_64 in1_64)))
(let (($x449 (and (distinct ?x435 ?x435) true)))
(let (($x116 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) ?x435)) true)))
(let (($x122 (or false false (or $x116))))
(and (not $x122) (or $x122 $x449)))))))
(check-sat)
; query 17: function gsm_L_add, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x268 (bvadd in0_64 (_ bv1 64))))
(let ((?x429 (bvsub (_ bv0 64) ?x268)))
(let (($x1614 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x268)) ((_ sign_extend 1) ?x429)) true)))
(let ((?x193 ((_ sign_extend 1) ?x268)))
(let (($x9 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x193) true)))))
(let (($x72 (or false $x9 (or $x1614))))
(and (not $x72) (or $x72 (and (distinct ?x429 ?x429) true))))))))))
(check-sat)
; query 18: function gsm_L_add, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x2780 (bvadd in1_64 (_ bv1 64))))
(let ((?x55 ((_ sign_extend 1) ?x2780)))
(let (($x1097 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x55) true)))))
(and (not $x1097) (or $x1097 (and (distinct ?x2780 ?x2780) true)))))))
(check-sat)
; query 19: function gsm_L_add, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x2780 (bvadd in1_64 (_ bv1 64))))
(let ((?x575 (bvsub (_ bv0 64) ?x2780)))
(let (($x155 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x2780)) ((_ sign_extend 1) ?x575)) true)))
(let ((?x55 ((_ sign_extend 1) ?x2780)))
(let (($x1097 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x55) true)))))
(let (($x1026 (or false $x1097 (or $x155))))
(and (not $x1026) (or $x1026 (and (distinct ?x575 ?x575) true))))))))))
(check-sat)
; query 20: function gsm_L_add, block 8, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2780 (bvadd in1_64 (_ bv1 64))))
(let ((?x575 (bvsub (_ bv0 64) ?x2780)))
(let ((?x268 (bvadd in0_64 (_ bv1 64))))
(let ((?x429 (bvsub (_ bv0 64) ?x268)))
(let ((?x126 (bvadd ?x429 ?x575)))
(let (($x63 (and (distinct (bvadd ((_ zero_extend 1) ?x429) ((_ zero_extend 1) ?x575)) ((_ zero_extend 1) ?x126)) true)))
(let (($x155 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x2780)) ((_ sign_extend 1) ?x575)) true)))
(let ((?x55 ((_ sign_extend 1) ?x2780)))
(let (($x1097 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x55) true)))))
(let (($x1026 (or false $x1097 (or $x155))))
(let (($x1614 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x268)) ((_ sign_extend 1) ?x429)) true)))
(let ((?x193 ((_ sign_extend 1) ?x268)))
(let (($x9 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x193) true)))))
(let (($x72 (or false $x9 (or $x1614))))
(let (($x206 (or $x72 $x1026 (or $x63))))
(and (not (or $x72 $x1026 false)) (or $x206 (and (distinct ?x126 ?x126) true)))))))))))))))))))
(check-sat)
; query 21: function gsm_L_add, block 8, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2780 (bvadd in1_64 (_ bv1 64))))
(let ((?x575 (bvsub (_ bv0 64) ?x2780)))
(let ((?x268 (bvadd in0_64 (_ bv1 64))))
(let ((?x429 (bvsub (_ bv0 64) ?x268)))
(let ((?x126 (bvadd ?x429 ?x575)))
(let ((?x1847 (ite (bvuge ?x126 (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x63 (and (distinct (bvadd ((_ zero_extend 1) ?x429) ((_ zero_extend 1) ?x575)) ((_ zero_extend 1) ?x126)) true)))
(let (($x155 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x2780)) ((_ sign_extend 1) ?x575)) true)))
(let ((?x55 ((_ sign_extend 1) ?x2780)))
(let (($x1097 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x55) true)))))
(let (($x1026 (or false $x1097 (or $x155))))
(let (($x1614 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x268)) ((_ sign_extend 1) ?x429)) true)))
(let ((?x193 ((_ sign_extend 1) ?x268)))
(let (($x9 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x193) true)))))
(let (($x72 (or false $x9 (or $x1614))))
(let (($x206 (or $x72 $x1026 (or $x63))))
(and (not (or (or $x72 $x1026 false) false false)) (or (or $x206 false false) (and (distinct ?x1847 ?x1847) true))))))))))))))))))))
(check-sat)
; query 22: function gsm_L_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x268 (bvadd in0_64 (_ bv1 64))))
(let ((?x193 ((_ sign_extend 1) ?x268)))
(let (($x9 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x193) true)))))
(and (not $x9) (or $x9 (and (distinct ?x268 ?x268) true)))))))
(check-sat)
; query 23: function gsm_L_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1623 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x24 (or false false false)))
(let (($x882 (not $x24)))
(and $x882 (or $x24 (and (distinct ?x1623 ?x1623) true)))))))
(check-sat)
; query 24: function gsm_L_asl, block 12, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x2221 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x24 (or false false false)))
(let (($x882 (not $x24)))
(and $x882 (or $x24 (and (distinct ?x2221 ?x2221) true)))))))
(check-sat)
; query 25: function gsm_L_asl, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x885 (or false (or (= ((_ extract 31 31) in1_32) (_ bv1 1))))))
(let (($x604 (or false false)))
(let (($x308 (not $x604)))
(and $x308 (or $x885 (and (distinct ((_ zero_extend 32) in1_32) ((_ zero_extend 32) in1_32)) true)))))))
(check-sat)
; query 26: function gsm_L_asl, block 17, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1634 ((_ zero_extend 32) in1_32)))
(let ((?x183 (bvshl in0_64 ?x1634)))
(let (($x397 (bvuge ?x1634 (_ bv64 64))))
(let (($x883 (or (or false (or false (or (= ((_ extract 31 31) in1_32) (_ bv1 1)))) false) $x397)))
(let (($x750 (not (or (or false (or false false) false) $x397))))
(and $x750 (or $x883 (and (distinct ?x183 ?x183) true)))))))))
(check-sat)
; query 27: function gsm_L_asl, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1837 (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x24 (or false false false)))
(let (($x882 (not $x24)))
(and $x882 (or $x24 (and (distinct ?x1837 ?x1837) true)))))))
(check-sat)
; query 28: function gsm_L_asl, block 7, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1623 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x669 ((_ zero_extend 31) ?x1623)))
(let ((?x70 (bvsub (_ bv0 32) ?x669)))
(let (($x1351 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x669)) ((_ sign_extend 1) ?x70)) true)))
(let (($x24 (or false false false)))
(let (($x1240 (or $x24 false)))
(let (($x218 (or false $x1240 (or $x1351))))
(and (not $x218) (or $x218 (and (distinct ?x70 ?x70) true)))))))))))
(check-sat)
; query 29: function gsm_L_asl, block 7, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1623 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x669 ((_ zero_extend 31) ?x1623)))
(let ((?x70 (bvsub (_ bv0 32) ?x669)))
(let ((?x1825 ((_ sign_extend 32) ?x70)))
(let (($x1351 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x669)) ((_ sign_extend 1) ?x70)) true)))
(let (($x24 (or false false false)))
(let (($x1240 (or $x24 false)))
(let (($x218 (or false $x1240 (or $x1351))))
(let (($x1530 (or $x218 false)))
(and (not $x1530) (or $x1530 (and (distinct ?x1825 ?x1825) true)))))))))))))
(check-sat)
; query 30: function gsm_L_asl, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1623 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x24 (or false false false)))
(let (($x882 (not $x24)))
(and $x882 (or $x24 (and (distinct ?x1623 ?x1623) true)))))))
(check-sat)
; query 31: function gsm_L_asl, block 7, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1623 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x669 ((_ zero_extend 31) ?x1623)))
(let (($x24 (or false false false)))
(let (($x1240 (or $x24 false)))
(and (not $x1240) (or $x1240 (and (distinct ?x669 ?x669) true))))))))
(check-sat)
; query 32: function gsm_L_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x742 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x24 (or false false false)))
(let (($x882 (not $x24)))
(and $x882 (or $x24 (and (distinct ?x742 ?x742) true)))))))
(check-sat)
; query 33: function gsm_L_asr, block 12, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x2221 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x24 (or false false false)))
(let (($x882 (not $x24)))
(and $x882 (or $x24 (and (distinct ?x2221 ?x2221) true)))))))
(check-sat)
; query 34: function gsm_L_asr, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x1246 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in1_32))) true)))
(let (($x819 (or false false (or $x1246))))
(and (not $x819) (or $x819 (and (distinct (bvsub (_ bv0 32) in1_32) (bvsub (_ bv0 32) in1_32)) true))))))
(check-sat)
; query 35: function gsm_L_asr, block 14, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1887 (bvsub (_ bv0 32) in1_32)))
(let ((?x1557 ((_ zero_extend 32) ?x1887)))
(let (($x1246 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x1887)) true)))
(let (($x819 (or false false (or $x1246))))
(let (($x393 (or $x819 (or (= ((_ extract 31 31) ?x1887) (_ bv1 1))))))
(and (not (or $x819 false)) (or $x393 (and (distinct ?x1557 ?x1557) true)))))))))
(check-sat)
; query 36: function gsm_L_asr, block 14, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1887 (bvsub (_ bv0 32) in1_32)))
(let ((?x1557 ((_ zero_extend 32) ?x1887)))
(let ((?x723 (bvshl in0_64 ?x1557)))
(let (($x758 (bvuge ?x1557 (_ bv64 64))))
(let (($x1246 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x1887)) true)))
(let (($x819 (or false false (or $x1246))))
(let (($x393 (or $x819 (or (= ((_ extract 31 31) ?x1887) (_ bv1 1))))))
(and (not (or (or false (or $x819 false) false) $x758)) (or (or (or false $x393 false) $x758) (and (distinct ?x723 ?x723) true)))))))))))
(check-sat)
; query 37: function gsm_L_asr, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x885 (or false (or (= ((_ extract 31 31) in1_32) (_ bv1 1))))))
(let (($x604 (or false false)))
(let (($x308 (not $x604)))
(and $x308 (or $x885 (and (distinct ((_ zero_extend 32) in1_32) ((_ zero_extend 32) in1_32)) true)))))))
(check-sat)
; query 38: function gsm_L_asr, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1634 ((_ zero_extend 32) in1_32)))
(let ((?x146 (bvashr in0_64 ?x1634)))
(let (($x397 (bvuge ?x1634 (_ bv64 64))))
(let (($x883 (or (or false (or false (or (= ((_ extract 31 31) in1_32) (_ bv1 1)))) false) $x397)))
(let (($x750 (not (or (or false (or false false) false) $x397))))
(and $x750 (or $x883 (and (distinct ?x146 ?x146) true)))))))))
(check-sat)
; query 39: function gsm_L_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1623 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x24 (or false false false)))
(let (($x882 (not $x24)))
(and $x882 (or $x24 (and (distinct ?x1623 ?x1623) true)))))))
(check-sat)
; query 40: function gsm_L_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1623 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x669 ((_ zero_extend 31) ?x1623)))
(let (($x24 (or false false false)))
(let (($x1240 (or $x24 false)))
(and (not $x1240) (or $x1240 (and (distinct ?x669 ?x669) true))))))))
(check-sat)
; query 41: function gsm_L_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1623 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x669 ((_ zero_extend 31) ?x1623)))
(let ((?x70 (bvsub (_ bv0 32) ?x669)))
(let (($x1351 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x669)) ((_ sign_extend 1) ?x70)) true)))
(let (($x24 (or false false false)))
(let (($x1240 (or $x24 false)))
(let (($x218 (or false $x1240 (or $x1351))))
(and (not $x218) (or $x218 (and (distinct ?x70 ?x70) true)))))))))))
(check-sat)
; query 42: function gsm_L_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1623 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x669 ((_ zero_extend 31) ?x1623)))
(let ((?x70 (bvsub (_ bv0 32) ?x669)))
(let ((?x1825 ((_ sign_extend 32) ?x70)))
(let (($x1351 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x669)) ((_ sign_extend 1) ?x70)) true)))
(let (($x24 (or false false false)))
(let (($x1240 (or $x24 false)))
(let (($x218 (or false $x1240 (or $x1351))))
(let (($x1530 (or $x218 false)))
(and (not $x1530) (or $x1530 (and (distinct ?x1825 ?x1825) true)))))))))))))
(check-sat)
; query 43: function gsm_L_asr, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1837 (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x24 (or false false false)))
(let (($x882 (not $x24)))
(and $x882 (or $x24 (and (distinct ?x1837 ?x1837) true)))))))
(check-sat)
; query 44: function gsm_L_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x742 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x24 (or false false false)))
(let (($x882 (not $x24)))
(and $x882 (or $x24 (and (distinct ?x742 ?x742) true)))))))
(check-sat)
; query 45: function gsm_L_mult, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x604 (or false false)))
(let (($x308 (not $x604)))
(and $x308 (or $x604 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 46: function gsm_L_mult, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x45 (ite (and (distinct (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) true) (_ bv1 1) (_ bv0 1))))
(let (($x604 (or false false)))
(let (($x173 (or $x604 false false)))
(let (($x527 (not $x173)))
(and $x527 (or $x173 (and (distinct ?x45 ?x45) true))))))))
(check-sat)
; query 47: function gsm_L_mult, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x604 (or false false)))
(let (($x308 (not $x604)))
(and $x308 (or $x604 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 48: function gsm_L_mult, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x303 (ite (and (distinct (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) true) (_ bv1 1) (_ bv0 1))))
(let (($x604 (or false false)))
(let (($x173 (or $x604 false false)))
(let (($x527 (not $x173)))
(and $x527 (or $x173 (and (distinct ?x303 ?x303) true))))))))
(check-sat)
; query 49: function gsm_L_sub, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in11_64 () (_ BitVec 64))
(assert
 (let (($x895 (and (distinct (bvadd ((_ zero_extend 1) in11_64) ((_ zero_extend 1) (_ bv1 64))) ((_ zero_extend 1) (bvadd in11_64 (_ bv1 64)))) true)))
(let (($x749 (and (distinct (bvadd ((_ sign_extend 1) in11_64) ((_ sign_extend 1) (_ bv1 64))) ((_ sign_extend 1) (bvadd in11_64 (_ bv1 64)))) true)))
(let (($x1686 (or (or false false (or $x749 $x895)) (and (distinct (bvadd in11_64 (_ bv1 64)) (bvadd in11_64 (_ bv1 64))) true))))
(let (($x24 (or false false false)))
(let (($x882 (not $x24)))
(and $x882 $x1686)))))))
(check-sat)
; query 50: function gsm_L_sub, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x515 (ite (bvsge (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x24 (or false false false)))
(let (($x882 (not $x24)))
(and $x882 (or $x24 (and (distinct ?x515 ?x515) true)))))))
(check-sat)
; query 51: function gsm_L_sub, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x1732 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvsub in0_64 in1_64))) true)))
(let (($x603 (or false false (or $x1732))))
(let (($x142 (or $x603 (and (distinct (bvsub in0_64 in1_64) (bvsub in0_64 in1_64)) true))))
(and (not $x603) $x142)))))
(check-sat)
; query 52: function gsm_L_sub, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x268 (bvadd in0_64 (_ bv1 64))))
(let ((?x193 ((_ sign_extend 1) ?x268)))
(let (($x9 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x193) true)))))
(and (not $x9) (or $x9 (and (distinct ?x268 ?x268) true)))))))
(check-sat)
; query 53: function gsm_L_sub, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x268 (bvadd in0_64 (_ bv1 64))))
(let ((?x429 (bvsub (_ bv0 64) ?x268)))
(let (($x1614 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x268)) ((_ sign_extend 1) ?x429)) true)))
(let ((?x193 ((_ sign_extend 1) ?x268)))
(let (($x9 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x193) true)))))
(let (($x72 (or false $x9 (or $x1614))))
(and (not $x72) (or $x72 (and (distinct ?x429 ?x429) true))))))))))
(check-sat)
; query 54: function gsm_L_sub, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x268 (bvadd in0_64 (_ bv1 64))))
(let ((?x429 (bvsub (_ bv0 64) ?x268)))
(let ((?x311 (bvadd ?x429 in1_64)))
(let (($x1088 (and (distinct (bvadd ((_ zero_extend 1) ?x429) ((_ zero_extend 1) in1_64)) ((_ zero_extend 1) ?x311)) true)))
(let (($x1614 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x268)) ((_ sign_extend 1) ?x429)) true)))
(let ((?x193 ((_ sign_extend 1) ?x268)))
(let (($x9 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x193) true)))))
(let (($x72 (or false $x9 (or $x1614))))
(let (($x1094 (or $x72 false (or $x1088))))
(and (not (or $x72 false false)) (or $x1094 (and (distinct ?x311 ?x311) true)))))))))))))
(check-sat)
; query 55: function gsm_L_sub, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1052 (ite (bvuge (bvadd (bvsub (_ bv0 64) (bvadd in0_64 (_ bv1 64))) in1_64) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let ((?x365 ((_ zero_extend 1) in1_64)))
(let ((?x268 (bvadd in0_64 (_ bv1 64))))
(let ((?x429 (bvsub (_ bv0 64) ?x268)))
(let ((?x176 ((_ zero_extend 1) ?x429)))
(let (($x1614 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x268)) ((_ sign_extend 1) ?x429)) true)))
(let ((?x193 ((_ sign_extend 1) ?x268)))
(let (($x9 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x193) true)))))
(let (($x72 (or false $x9 (or $x1614))))
(let (($x1094 (or $x72 false (or (and (distinct (bvadd ?x176 ?x365) ((_ zero_extend 1) (bvadd ?x429 in1_64))) true)))))
(and (not (or (or $x72 false false) false false)) (or (or $x1094 false false) (and (distinct ?x1052 ?x1052) true))))))))))))))
(check-sat)
; query 56: function gsm_L_sub, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_64 () (_ BitVec 64))
(assert
 (let ((?x1000 (bvsub (_ bv0 64) in25_64)))
(let ((?x1031 ((_ sign_extend 1) ?x1000)))
(let (($x624 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in25_64)) ?x1031) true)))))
(and (not $x624) (or $x624 (and (distinct ?x1000 ?x1000) true)))))))
(check-sat)
; query 57: function gsm_L_sub, block 28, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_64 () (_ BitVec 64))
(assert
 (let ((?x1000 (bvsub (_ bv0 64) in25_64)))
(let ((?x1774 (bvsub ?x1000 (_ bv1 64))))
(let (($x637 (and (distinct (bvsub ((_ zero_extend 1) ?x1000) ((_ zero_extend 1) (_ bv1 64))) ((_ zero_extend 1) ?x1774)) true)))
(let (($x1514 (and (distinct (bvsub ((_ sign_extend 1) ?x1000) ((_ sign_extend 1) (_ bv1 64))) ((_ sign_extend 1) ?x1774)) true)))
(let ((?x1031 ((_ sign_extend 1) ?x1000)))
(let (($x624 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in25_64)) ?x1031) true)))))
(and (not (or $x624 false (or $x1514))) (or (or $x624 false (or $x1514 $x637)) (and (distinct ?x1774 ?x1774) true))))))))))
(check-sat)
; query 58: function gsm_L_sub, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x602 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x24 (or false false false)))
(let (($x882 (not $x24)))
(and $x882 (or $x24 (and (distinct ?x602 ?x602) true)))))))
(check-sat)
; query 59: function gsm_L_sub, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x1732 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvsub in0_64 in1_64))) true)))
(let (($x603 (or false false (or $x1732))))
(let (($x142 (or $x603 (and (distinct (bvsub in0_64 in1_64) (bvsub in0_64 in1_64)) true))))
(and (not $x603) $x142)))))
(check-sat)
; query 60: function gsm_L_sub, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x2780 (bvadd in1_64 (_ bv1 64))))
(let ((?x575 (bvsub (_ bv0 64) ?x2780)))
(let (($x155 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x2780)) ((_ sign_extend 1) ?x575)) true)))
(let ((?x55 ((_ sign_extend 1) ?x2780)))
(let (($x1097 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x55) true)))))
(let (($x1026 (or false $x1097 (or $x155))))
(and (not $x1026) (or $x1026 (and (distinct ?x575 ?x575) true))))))))))
(check-sat)
; query 61: function gsm_L_sub, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2780 (bvadd in1_64 (_ bv1 64))))
(let ((?x575 (bvsub (_ bv0 64) ?x2780)))
(let ((?x1155 (bvadd in0_64 ?x575)))
(let (($x1199 (and (distinct (bvadd ((_ zero_extend 1) in0_64) ((_ zero_extend 1) ?x575)) ((_ zero_extend 1) ?x1155)) true)))
(let (($x155 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x2780)) ((_ sign_extend 1) ?x575)) true)))
(let ((?x55 ((_ sign_extend 1) ?x2780)))
(let (($x1097 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x55) true)))))
(let (($x1026 (or false $x1097 (or $x155))))
(let (($x386 (or false $x1026 (or $x1199))))
(and (not (or false $x1026 false)) (or $x386 (and (distinct ?x1155 ?x1155) true)))))))))))))
(check-sat)
; query 62: function gsm_L_sub, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1715 (ite (bvuge (bvadd in0_64 (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64)))) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let ((?x2780 (bvadd in1_64 (_ bv1 64))))
(let ((?x575 (bvsub (_ bv0 64) ?x2780)))
(let ((?x1558 ((_ zero_extend 1) ?x575)))
(let ((?x12 ((_ zero_extend 1) in0_64)))
(let (($x155 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x2780)) ((_ sign_extend 1) ?x575)) true)))
(let ((?x55 ((_ sign_extend 1) ?x2780)))
(let (($x1097 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x55) true)))))
(let (($x1026 (or false $x1097 (or $x155))))
(let (($x386 (or false $x1026 (or (and (distinct (bvadd ?x12 ?x1558) ((_ zero_extend 1) (bvadd in0_64 ?x575))) true)))))
(and (not (or (or false $x1026 false) false false)) (or (or $x386 false false) (and (distinct ?x1715 ?x1715) true))))))))))))))
(check-sat)
; query 63: function gsm_L_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x2780 (bvadd in1_64 (_ bv1 64))))
(let ((?x55 ((_ sign_extend 1) ?x2780)))
(let (($x1097 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x55) true)))))
(and (not $x1097) (or $x1097 (and (distinct ?x2780 ?x2780) true)))))))
(check-sat)
; query 64: function gsm_L_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x982 (ite (bvsle (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x24 (or false false false)))
(let (($x882 (not $x24)))
(and $x882 (or $x24 (and (distinct ?x982 ?x982) true)))))))
(check-sat)
; query 65: function gsm_abs, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x604 (or false false)))
(let (($x308 (not $x604)))
(and $x308 (or $x604 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 66: function gsm_abs, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1870 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x604 (or false false)))
(let (($x173 (or $x604 false false)))
(let (($x527 (not $x173)))
(and $x527 (or $x173 (and (distinct ?x1870 ?x1870) true))))))))
(check-sat)
; query 67: function gsm_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_64 () (_ BitVec 64))
(assert
 (let ((?x1972 (ite (bvslt (_ bv32767 64) in5_64) (_ bv1 1) (_ bv0 1))))
(let (($x24 (or false false false)))
(let (($x882 (not $x24)))
(and $x882 (or $x24 (and (distinct ?x1972 ?x1972) true)))))))
(check-sat)
; query 68: function gsm_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x604 (or false false)))
(let (($x308 (not $x604)))
(and $x308 (or $x604 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 69: function gsm_add, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x604 (or false false)))
(let (($x308 (not $x604)))
(and $x308 (or $x604 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 70: function gsm_add, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1773 ((_ sign_extend 48) in1_16)))
(let ((?x467 ((_ sign_extend 48) in0_16)))
(let ((?x795 (bvadd ?x467 ?x1773)))
(let (($x812 (and (distinct (bvadd ((_ sign_extend 1) ?x467) ((_ sign_extend 1) ?x1773)) ((_ sign_extend 1) ?x795)) true)))
(let (($x604 (or false false)))
(let (($x1093 (or $x604 $x604 (or $x812))))
(and (not $x1093) (or $x1093 (and (distinct ?x795 ?x795) true))))))))))
(check-sat)
; query 71: function gsm_add, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1116 (ite (bvsgt (_ bv18446744073709518848 64) (bvadd ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x1773 ((_ sign_extend 48) in1_16)))
(let ((?x1122 ((_ sign_extend 1) ?x1773)))
(let ((?x467 ((_ sign_extend 48) in0_16)))
(let ((?x665 ((_ sign_extend 1) ?x467)))
(let (($x604 (or false false)))
(let (($x1093 (or $x604 $x604 (or (and (distinct (bvadd ?x665 ?x1122) ((_ sign_extend 1) (bvadd ?x467 ?x1773))) true)))))
(let (($x1308 (or $x1093 false false)))
(and (not $x1308) (or $x1308 (and (distinct ?x1116 ?x1116) true))))))))))))
(check-sat)
; query 72: function gsm_asl, block 13, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x2221 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x24 (or false false false)))
(let (($x882 (not $x24)))
(and $x882 (or $x24 (and (distinct ?x2221 ?x2221) true)))))))
(check-sat)
; query 73: function gsm_asl, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x604 (or false false)))
(let (($x308 (not $x604)))
(and $x308 (or $x604 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 74: function gsm_asl, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x813 ((_ sign_extend 16) in0_16)))
(let ((?x180 (bvshl ?x813 in1_32)))
(let (($x2147 (bvuge in1_32 (_ bv32 32))))
(let (($x604 (or false false)))
(let (($x1899 (or (or $x604 false (or (and (distinct (bvashr ?x180 in1_32) ?x813) true))) $x2147)))
(let (($x173 (or $x604 false false)))
(let (($x502 (or $x173 $x2147)))
(let (($x1186 (not $x502)))
(and $x1186 (or $x1899 (and (distinct ?x180 ?x180) true))))))))))))
(check-sat)
; query 75: function gsm_asl, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x813 ((_ sign_extend 16) in0_16)))
(let ((?x180 (bvshl ?x813 in1_32)))
(let ((?x423 ((_ extract 15 0) ?x180)))
(let (($x2147 (bvuge in1_32 (_ bv32 32))))
(let (($x604 (or false false)))
(let (($x1899 (or (or $x604 false (or (and (distinct (bvashr ?x180 in1_32) ?x813) true))) $x2147)))
(let (($x1271 (not (or (or (or $x604 false false) $x2147) false))))
(and $x1271 (or (or $x1899 false) (and (distinct ?x423 ?x423) true)))))))))))
(check-sat)
; query 76: function gsm_asl, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x855 (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x24 (or false false false)))
(let (($x882 (not $x24)))
(and $x882 (or $x24 (and (distinct ?x855 ?x855) true)))))))
(check-sat)
; query 77: function gsm_asl, block 7, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1870 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x983 ((_ zero_extend 31) ?x1870)))
(let (($x604 (or false false)))
(let (($x173 (or $x604 false false)))
(let (($x394 (or $x173 false)))
(and (not $x394) (or $x394 (and (distinct ?x983 ?x983) true)))))))))
(check-sat)
; query 78: function gsm_asl, block 7, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1870 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x983 ((_ zero_extend 31) ?x1870)))
(let ((?x2361 (bvsub (_ bv0 32) ?x983)))
(let (($x1940 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x983)) ((_ sign_extend 1) ?x2361)) true)))
(let (($x604 (or false false)))
(let (($x173 (or $x604 false false)))
(let (($x394 (or $x173 false)))
(let (($x1964 (or false $x394 (or $x1940))))
(and (not $x1964) (or $x1964 (and (distinct ?x2361 ?x2361) true))))))))))))
(check-sat)
; query 79: function gsm_asl, block 7, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1870 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x983 ((_ zero_extend 31) ?x1870)))
(let ((?x2361 (bvsub (_ bv0 32) ?x983)))
(let ((?x2788 ((_ extract 15 0) ?x2361)))
(let (($x1940 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x983)) ((_ sign_extend 1) ?x2361)) true)))
(let (($x604 (or false false)))
(let (($x173 (or $x604 false false)))
(let (($x394 (or $x173 false)))
(let (($x1964 (or false $x394 (or $x1940))))
(let (($x2734 (or (or $x1964 (or (and (distinct ((_ sign_extend 16) ?x2788) ?x2361) true))) (and (distinct ?x2788 ?x2788) true))))
(and (not (or $x1964 false)) $x2734))))))))))))
(check-sat)
; query 80: function gsm_asl, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x604 (or false false)))
(let (($x308 (not $x604)))
(and $x308 (or $x604 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 81: function gsm_asl, block 7, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1870 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x604 (or false false)))
(let (($x173 (or $x604 false false)))
(let (($x527 (not $x173)))
(and $x527 (or $x173 (and (distinct ?x1870 ?x1870) true))))))))
(check-sat)
; query 82: function gsm_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1345 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x24 (or false false false)))
(let (($x882 (not $x24)))
(and $x882 (or $x24 (and (distinct ?x1345 ?x1345) true)))))))
(check-sat)
; query 83: function gsm_asr, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x855 (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x24 (or false false false)))
(let (($x882 (not $x24)))
(and $x882 (or $x24 (and (distinct ?x855 ?x855) true)))))))
(check-sat)
; query 84: function gsm_asr, block 13, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x2221 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x24 (or false false false)))
(let (($x882 (not $x24)))
(and $x882 (or $x24 (and (distinct ?x2221 ?x2221) true)))))))
(check-sat)
; query 85: function gsm_asr, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x604 (or false false)))
(let (($x308 (not $x604)))
(and $x308 (or $x604 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 86: function gsm_asr, block 15, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x1246 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in1_32))) true)))
(let (($x819 (or false false (or $x1246))))
(and (not $x819) (or $x819 (and (distinct (bvsub (_ bv0 32) in1_32) (bvsub (_ bv0 32) in1_32)) true))))))
(check-sat)
; query 87: function gsm_asr, block 15, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1887 (bvsub (_ bv0 32) in1_32)))
(let ((?x813 ((_ sign_extend 16) in0_16)))
(let ((?x1079 (bvshl ?x813 ?x1887)))
(let (($x1029 (bvuge ?x1887 (_ bv32 32))))
(let (($x1246 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x1887)) true)))
(let (($x819 (or false false (or $x1246))))
(let (($x604 (or false false)))
(let (($x783 (or (or $x604 $x819 (or (and (distinct (bvashr ?x1079 ?x1887) ?x813) true))) $x1029)))
(and (not (or (or $x604 $x819 false) $x1029)) (or $x783 (and (distinct ?x1079 ?x1079) true))))))))))))
(check-sat)
; query 88: function gsm_asr, block 15, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1887 (bvsub (_ bv0 32) in1_32)))
(let ((?x813 ((_ sign_extend 16) in0_16)))
(let ((?x1079 (bvshl ?x813 ?x1887)))
(let ((?x1864 ((_ extract 15 0) ?x1079)))
(let (($x1029 (bvuge ?x1887 (_ bv32 32))))
(let (($x1246 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x1887)) true)))
(let (($x819 (or false false (or $x1246))))
(let (($x604 (or false false)))
(let (($x783 (or (or $x604 $x819 (or (and (distinct (bvashr ?x1079 ?x1887) ?x813) true))) $x1029)))
(and (not (or (or (or $x604 $x819 false) $x1029) false)) (or (or $x783 false) (and (distinct ?x1864 ?x1864) true)))))))))))))
(check-sat)
; query 89: function gsm_asr, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x604 (or false false)))
(let (($x308 (not $x604)))
(and $x308 (or $x604 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 90: function gsm_asr, block 20, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x813 ((_ sign_extend 16) in0_16)))
(let ((?x2032 (bvashr ?x813 in1_32)))
(let (($x2147 (bvuge in1_32 (_ bv32 32))))
(let (($x604 (or false false)))
(let (($x173 (or $x604 false false)))
(let (($x502 (or $x173 $x2147)))
(let (($x1186 (not $x502)))
(and $x1186 (or $x502 (and (distinct ?x2032 ?x2032) true)))))))))))
(check-sat)
; query 91: function gsm_asr, block 20, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x813 ((_ sign_extend 16) in0_16)))
(let ((?x2032 (bvashr ?x813 in1_32)))
(let ((?x888 ((_ extract 15 0) ?x2032)))
(let (($x2147 (bvuge in1_32 (_ bv32 32))))
(let (($x604 (or false false)))
(let (($x173 (or $x604 false false)))
(let (($x502 (or $x173 $x2147)))
(let (($x1912 (or (or $x502 (or (and (distinct ((_ sign_extend 16) ?x888) ?x2032) true))) (and (distinct ?x888 ?x888) true))))
(let (($x1271 (not (or $x502 false))))
(and $x1271 $x1912)))))))))))
(check-sat)
; query 92: function gsm_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x604 (or false false)))
(let (($x308 (not $x604)))
(and $x308 (or $x604 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 93: function gsm_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1870 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x604 (or false false)))
(let (($x173 (or $x604 false false)))
(let (($x527 (not $x173)))
(and $x527 (or $x173 (and (distinct ?x1870 ?x1870) true))))))))
(check-sat)
; query 94: function gsm_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1870 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x983 ((_ zero_extend 31) ?x1870)))
(let (($x604 (or false false)))
(let (($x173 (or $x604 false false)))
(let (($x394 (or $x173 false)))
(and (not $x394) (or $x394 (and (distinct ?x983 ?x983) true)))))))))
(check-sat)
; query 95: function gsm_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1870 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x983 ((_ zero_extend 31) ?x1870)))
(let ((?x2361 (bvsub (_ bv0 32) ?x983)))
(let (($x1940 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x983)) ((_ sign_extend 1) ?x2361)) true)))
(let (($x604 (or false false)))
(let (($x173 (or $x604 false false)))
(let (($x394 (or $x173 false)))
(let (($x1964 (or false $x394 (or $x1940))))
(and (not $x1964) (or $x1964 (and (distinct ?x2361 ?x2361) true))))))))))))
(check-sat)
; query 96: function gsm_asr, block 4, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1870 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x983 ((_ zero_extend 31) ?x1870)))
(let ((?x2361 (bvsub (_ bv0 32) ?x983)))
(let ((?x2788 ((_ extract 15 0) ?x2361)))
(let (($x1940 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x983)) ((_ sign_extend 1) ?x2361)) true)))
(let (($x604 (or false false)))
(let (($x173 (or $x604 false false)))
(let (($x394 (or $x173 false)))
(let (($x1964 (or false $x394 (or $x1940))))
(let (($x2734 (or (or $x1964 (or (and (distinct ((_ sign_extend 16) ?x2788) ?x2361) true))) (and (distinct ?x2788 ?x2788) true))))
(and (not (or $x1964 false)) $x2734))))))))))))
(check-sat)
; query 97: function gsm_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1345 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x24 (or false false false)))
(let (($x882 (not $x24)))
(and $x882 (or $x24 (and (distinct ?x1345 ?x1345) true)))))))
(check-sat)
; query 98: function gsm_debug_longwords, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in15_32 () (_ BitVec 32))
(assert
 (let ((?x1731 (ite (bvslt in15_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x24 (or false false false)))
(let (($x882 (not $x24)))
(and $x882 (or $x24 (and (distinct ?x1731 ?x1731) true)))))))
(check-sat)
; query 99: function gsm_debug_words, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in16_32 () (_ BitVec 32))
(assert
 (let ((?x190 (ite (bvslt in16_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x24 (or false false false)))
(let (($x882 (not $x24)))
(and $x882 (or $x24 (and (distinct ?x190 ?x190) true)))))))
(check-sat)
; query 100: function gsm_div, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x604 (or false false)))
(let (($x308 (not $x604)))
(and $x308 (or $x604 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 101: function gsm_div, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x604 (or false false)))
(let (($x308 (not $x604)))
(and $x308 (or $x604 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 102: function gsm_div, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x604 (or false false)))
(let (($x308 (not $x604)))
(and $x308 (or $x604 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 103: function gsm_div, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x100 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x696 (and (distinct ?x100 ?x100) true)))
(let (($x604 (or false false)))
(let (($x173 (or $x604 false false)))
(let (($x527 (not $x173)))
(and $x527 (or $x173 $x696))))))))
(check-sat)
; query 104: function gsm_mult, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x604 (or false false)))
(let (($x308 (not $x604)))
(and $x308 (or $x604 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 105: function gsm_mult, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1894 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x604 (or false false)))
(let (($x173 (or $x604 false false)))
(let (($x527 (not $x173)))
(and $x527 (or $x173 (and (distinct ?x1894 ?x1894) true))))))))
(check-sat)
; query 106: function gsm_mult, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x604 (or false false)))
(let (($x308 (not $x604)))
(and $x308 (or $x604 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 107: function gsm_mult, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x604 (or false false)))
(let (($x308 (not $x604)))
(and $x308 (or $x604 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 108: function gsm_mult, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1773 ((_ sign_extend 48) in1_16)))
(let ((?x467 ((_ sign_extend 48) in0_16)))
(let ((?x1399 (bvmul ?x467 ?x1773)))
(let (($x1892 (and (distinct (bvmul ((_ sign_extend 64) ?x467) ((_ sign_extend 64) ?x1773)) ((_ sign_extend 64) ?x1399)) true)))
(let (($x604 (or false false)))
(let (($x255 (or $x604 $x604 (or $x1892))))
(and (not $x255) (or $x255 (and (distinct ?x1399 ?x1399) true))))))))))
(check-sat)
; query 109: function gsm_mult, block 9, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1773 ((_ sign_extend 48) in1_16)))
(let ((?x467 ((_ sign_extend 48) in0_16)))
(let ((?x1399 (bvmul ?x467 ?x1773)))
(let ((?x1868 (bvashr ?x1399 (_ bv15 64))))
(let (($x1499 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1892 (and (distinct (bvmul ((_ sign_extend 64) ?x467) ((_ sign_extend 64) ?x1773)) ((_ sign_extend 64) ?x1399)) true)))
(let (($x604 (or false false)))
(let (($x255 (or $x604 $x604 (or $x1892))))
(let (($x1464 (or (or $x255 false false) $x1499)))
(and (not $x1464) (or $x1464 (and (distinct ?x1868 ?x1868) true)))))))))))))
(check-sat)
; query 110: function gsm_mult, block 9, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1773 ((_ sign_extend 48) in1_16)))
(let ((?x467 ((_ sign_extend 48) in0_16)))
(let ((?x1399 (bvmul ?x467 ?x1773)))
(let ((?x1868 (bvashr ?x1399 (_ bv15 64))))
(let ((?x1919 ((_ extract 15 0) ?x1868)))
(let (($x1499 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1892 (and (distinct (bvmul ((_ sign_extend 64) ?x467) ((_ sign_extend 64) ?x1773)) ((_ sign_extend 64) ?x1399)) true)))
(let (($x604 (or false false)))
(let (($x255 (or $x604 $x604 (or $x1892))))
(let (($x1464 (or (or $x255 false false) $x1499)))
(let (($x1603 (or $x1464 false)))
(and (not $x1603) (or $x1603 (and (distinct ?x1919 ?x1919) true)))))))))))))))
(check-sat)
; query 111: function gsm_mult, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x604 (or false false)))
(let (($x308 (not $x604)))
(and $x308 (or $x604 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 112: function gsm_mult, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1820 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x604 (or false false)))
(let (($x173 (or $x604 false false)))
(let (($x527 (not $x173)))
(and $x527 (or $x173 (and (distinct ?x1820 ?x1820) true))))))))
(check-sat)
; query 113: function gsm_mult_r, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x604 (or false false)))
(let (($x308 (not $x604)))
(and $x308 (or $x604 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 114: function gsm_mult_r, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1820 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x604 (or false false)))
(let (($x173 (or $x604 false false)))
(let (($x527 (not $x173)))
(and $x527 (or $x173 (and (distinct ?x1820 ?x1820) true))))))))
(check-sat)
; query 115: function gsm_mult_r, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x604 (or false false)))
(let (($x308 (not $x604)))
(and $x308 (or $x604 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 116: function gsm_mult_r, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x604 (or false false)))
(let (($x308 (not $x604)))
(and $x308 (or $x604 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 117: function gsm_mult_r, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1773 ((_ sign_extend 48) in1_16)))
(let ((?x467 ((_ sign_extend 48) in0_16)))
(let ((?x1399 (bvmul ?x467 ?x1773)))
(let (($x1892 (and (distinct (bvmul ((_ sign_extend 64) ?x467) ((_ sign_extend 64) ?x1773)) ((_ sign_extend 64) ?x1399)) true)))
(let (($x604 (or false false)))
(let (($x255 (or $x604 $x604 (or $x1892))))
(and (not $x255) (or $x255 (and (distinct ?x1399 ?x1399) true))))))))))
(check-sat)
; query 118: function gsm_mult_r, block 9, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1773 ((_ sign_extend 48) in1_16)))
(let ((?x467 ((_ sign_extend 48) in0_16)))
(let ((?x1399 (bvmul ?x467 ?x1773)))
(let ((?x451 (bvadd ?x1399 (_ bv16384 64))))
(let (($x1456 (and (distinct (bvadd ((_ sign_extend 1) ?x1399) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x451)) true)))
(let (($x1892 (and (distinct (bvmul ((_ sign_extend 64) ?x467) ((_ sign_extend 64) ?x1773)) ((_ sign_extend 64) ?x1399)) true)))
(let (($x604 (or false false)))
(let (($x255 (or $x604 $x604 (or $x1892))))
(let (($x1215 (or $x255 false (or $x1456))))
(and (not $x1215) (or $x1215 (and (distinct ?x451 ?x451) true)))))))))))))
(check-sat)
; query 119: function gsm_mult_r, block 9, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1773 ((_ sign_extend 48) in1_16)))
(let ((?x467 ((_ sign_extend 48) in0_16)))
(let ((?x1399 (bvmul ?x467 ?x1773)))
(let ((?x451 (bvadd ?x1399 (_ bv16384 64))))
(let ((?x1915 (bvashr ?x451 (_ bv15 64))))
(let (($x1499 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1456 (and (distinct (bvadd ((_ sign_extend 1) ?x1399) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x451)) true)))
(let (($x1892 (and (distinct (bvmul ((_ sign_extend 64) ?x467) ((_ sign_extend 64) ?x1773)) ((_ sign_extend 64) ?x1399)) true)))
(let (($x604 (or false false)))
(let (($x255 (or $x604 $x604 (or $x1892))))
(let (($x1215 (or $x255 false (or $x1456))))
(let (($x654 (or (or $x1215 false false) $x1499)))
(and (not $x654) (or $x654 (and (distinct ?x1915 ?x1915) true))))))))))))))))
(check-sat)
; query 120: function gsm_mult_r, block 9, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1773 ((_ sign_extend 48) in1_16)))
(let ((?x467 ((_ sign_extend 48) in0_16)))
(let ((?x1399 (bvmul ?x467 ?x1773)))
(let ((?x451 (bvadd ?x1399 (_ bv16384 64))))
(let ((?x1915 (bvashr ?x451 (_ bv15 64))))
(let ((?x1140 (bvand ?x1915 (_ bv65535 64))))
(let (($x1499 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1456 (and (distinct (bvadd ((_ sign_extend 1) ?x1399) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x451)) true)))
(let (($x1892 (and (distinct (bvmul ((_ sign_extend 64) ?x467) ((_ sign_extend 64) ?x1773)) ((_ sign_extend 64) ?x1399)) true)))
(let (($x604 (or false false)))
(let (($x255 (or $x604 $x604 (or $x1892))))
(let (($x1215 (or $x255 false (or $x1456))))
(let (($x654 (or (or $x1215 false false) $x1499)))
(let (($x302 (or $x654 false false)))
(and (not $x302) (or $x302 (and (distinct ?x1140 ?x1140) true))))))))))))))))))
(check-sat)
; query 121: function gsm_mult_r, block 9, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1773 ((_ sign_extend 48) in1_16)))
(let ((?x467 ((_ sign_extend 48) in0_16)))
(let ((?x1399 (bvmul ?x467 ?x1773)))
(let ((?x451 (bvadd ?x1399 (_ bv16384 64))))
(let ((?x1915 (bvashr ?x451 (_ bv15 64))))
(let ((?x1140 (bvand ?x1915 (_ bv65535 64))))
(let ((?x2778 ((_ extract 15 0) ?x1140)))
(let (($x1499 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1456 (and (distinct (bvadd ((_ sign_extend 1) ?x1399) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x451)) true)))
(let (($x1892 (and (distinct (bvmul ((_ sign_extend 64) ?x467) ((_ sign_extend 64) ?x1773)) ((_ sign_extend 64) ?x1399)) true)))
(let (($x604 (or false false)))
(let (($x255 (or $x604 $x604 (or $x1892))))
(let (($x1215 (or $x255 false (or $x1456))))
(let (($x654 (or (or $x1215 false false) $x1499)))
(let (($x302 (or $x654 false false)))
(let (($x2777 (or (or $x302 (or (and (distinct ((_ zero_extend 48) ?x2778) ?x1140) true))) (and (distinct ?x2778 ?x2778) true))))
(and (not (or $x302 false)) $x2777))))))))))))))))))
(check-sat)
; query 122: function gsm_mult_r, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x604 (or false false)))
(let (($x308 (not $x604)))
(and $x308 (or $x604 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 123: function gsm_mult_r, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1894 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x604 (or false false)))
(let (($x173 (or $x604 false false)))
(let (($x527 (not $x173)))
(and $x527 (or $x173 (and (distinct ?x1894 ?x1894) true))))))))
(check-sat)
; query 124: function gsm_norm, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1623 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x24 (or false false false)))
(let (($x882 (not $x24)))
(and $x882 (or $x24 (and (distinct ?x1623 (ite (bvsge (_ bv18446744072635809792 64) in0_64) (_ bv1 1) (_ bv0 1))) true)))))))
(check-sat)
; query 125: function gsm_norm, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2603 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x24 (or false false false)))
(let (($x882 (not $x24)))
(and $x882 (or $x24 (and (distinct ?x2603 ?x2603) true)))))))
(check-sat)
; query 126: function gsm_norm, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2603 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x1393 (bvxor ?x2603 (_ bv1 1))))
(let (($x24 (or false false false)))
(let (($x95 (or $x24 false false)))
(let (($x500 (not $x95)))
(and $x500 (or $x95 (and (distinct ?x1393 ?x1393) true)))))))))
(check-sat)
; query 127: function gsm_norm, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2603 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x1393 (bvxor ?x2603 (_ bv1 1))))
(let ((?x2797 ((_ zero_extend 31) ?x1393)))
(let (($x24 (or false false false)))
(let (($x95 (or $x24 false false)))
(let (($x777 (or $x95 false)))
(and (not $x777) (or $x777 (and (distinct ?x2797 ?x2797) true))))))))))
(check-sat)
; query 128: function gsm_norm, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2603 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x1393 (bvxor ?x2603 (_ bv1 1))))
(let ((?x2797 ((_ zero_extend 31) ?x1393)))
(let (($x24 (or false false false)))
(let (($x95 (or $x24 false false)))
(let (($x777 (or $x95 false)))
(let (($x635 (or (or $x777 (or (= ((_ extract 31 31) ?x2797) (_ bv1 1)))) (and (distinct ((_ sign_extend 32) ?x2797) ((_ zero_extend 32) ?x2797)) true))))
(and (not (or $x777 false)) $x635)))))))))
(check-sat)
; query 129: function gsm_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_64 () (_ BitVec 64))
(assert
 (let ((?x1972 (ite (bvslt (_ bv32767 64) in5_64) (_ bv1 1) (_ bv0 1))))
(let (($x24 (or false false false)))
(let (($x882 (not $x24)))
(and $x882 (or $x24 (and (distinct ?x1972 ?x1972) true)))))))
(check-sat)
; query 130: function gsm_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x604 (or false false)))
(let (($x308 (not $x604)))
(and $x308 (or $x604 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 131: function gsm_sub, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x604 (or false false)))
(let (($x308 (not $x604)))
(and $x308 (or $x604 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 132: function gsm_sub, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1773 ((_ sign_extend 48) in1_16)))
(let ((?x467 ((_ sign_extend 48) in0_16)))
(let ((?x1909 (bvsub ?x467 ?x1773)))
(let (($x431 (and (distinct (bvsub ((_ sign_extend 1) ?x467) ((_ sign_extend 1) ?x1773)) ((_ sign_extend 1) ?x1909)) true)))
(let (($x604 (or false false)))
(let (($x1390 (or $x604 $x604 (or $x431))))
(and (not $x1390) (or $x1390 (and (distinct ?x1909 ?x1909) true))))))))))
(check-sat)
; query 133: function gsm_sub, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1635 (ite (bvsgt (_ bv18446744073709518848 64) (bvsub ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x1773 ((_ sign_extend 48) in1_16)))
(let ((?x1122 ((_ sign_extend 1) ?x1773)))
(let ((?x467 ((_ sign_extend 48) in0_16)))
(let ((?x665 ((_ sign_extend 1) ?x467)))
(let (($x604 (or false false)))
(let (($x1390 (or $x604 $x604 (or (and (distinct (bvsub ?x665 ?x1122) ((_ sign_extend 1) (bvsub ?x467 ?x1773))) true)))))
(let (($x1541 (or $x1390 false false)))
(and (not $x1541) (or $x1541 (and (distinct ?x1635 ?x1635) true))))))))))))
(check-sat)
; query 134: function ok_to_replace, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1792 (ite (and (distinct (_ bv4294967295 32) in.01_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x24 (or false false false)))
(let (($x882 (not $x24)))
(and $x882 (or $x24 (and (distinct ?x1792 ?x1792) true)))))))
(check-sat)
; query 135: function ok_to_replace, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in16_32 () (_ BitVec 32))
(assert
 (let ((?x623 (ite (= (_ bv121 32) in16_32) (_ bv1 1) (_ bv0 1))))
(let (($x24 (or false false false)))
(let (($x882 (not $x24)))
(and $x882 (or $x24 (and (distinct ?x623 ?x623) true)))))))
(check-sat)
; query 136: function suffix, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_64 () (_ BitVec 64))
(declare-fun in3_64 () (_ BitVec 64))
(assert
 (let ((?x1671 (ite (bvule in3_64 in4_64) (_ bv1 1) (_ bv0 1))))
(let (($x24 (or false false false)))
(let (($x882 (not $x24)))
(and $x882 (or $x24 (and (distinct ?x1671 ?x1671) true)))))))
(check-sat)
; query 137: function ulaw_input, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x1248 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x594 (or false false (or $x1248))))
(and (not $x594) (or $x594 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
