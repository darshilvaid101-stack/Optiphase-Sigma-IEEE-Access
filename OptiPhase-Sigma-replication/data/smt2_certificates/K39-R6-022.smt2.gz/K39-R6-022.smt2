; OptiPhase-Sigma refinement certificate for sweep K39-R6-022
; query 0: function BF_cfb64_encrypt, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.07_32 () (_ BitVec 32))
(assert
 (let ((?x415 (ite (= (_ bv0 32) in.07_32) (_ bv1 1) (_ bv0 1))))
(let (($x298 (or false false false)))
(and (not $x298) (or $x298 (and (distinct ?x415 ?x415) true))))))
(check-sat)
