; OptiPhase-Sigma refinement certificate for sweep K51-R1-004
