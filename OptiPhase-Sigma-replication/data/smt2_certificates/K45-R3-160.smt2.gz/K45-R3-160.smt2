; OptiPhase-Sigma refinement certificate for sweep K45-R3-160
; query 0: function Index_to_frequency, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1498 (ite (bvuge in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x868 (or false false false)))
(let (($x53 (not $x868)))
(and $x53 (or $x868 (and (distinct ?x1498 ?x1498) true)))))))
(check-sat)
; query 1: function IsPowerOfTwo, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x868 (or false false false)))
(let (($x53 (not $x868)))
(and $x53 (or $x868 (and (distinct (bvsub in0_32 (_ bv1 32)) (bvsub in0_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function IsPowerOfTwo, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x1497 (bvsub in0_32 (_ bv1 32))))
(let ((?x703 (bvand in0_32 ?x1497)))
(let (($x868 (or false false false)))
(let (($x320 (or false $x868 false)))
(and (not $x320) (or $x320 (and (distinct ?x703 ?x703) true))))))))
(check-sat)
; query 3: function IsPowerOfTwo, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x20 (ite (and (distinct (_ bv0 32) (bvand in0_32 (bvsub in0_32 (_ bv1 32)))) true) (_ bv1 1) (_ bv0 1))))
(let (($x868 (or false false false)))
(let (($x320 (or false $x868 false)))
(let (($x382 (or $x320 false false)))
(and (not $x382) (or $x382 (and (distinct ?x20 ?x20) true))))))))
(check-sat)
; query 4: function IsPowerOfTwo, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x713 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x868 (or false false false)))
(let (($x53 (not $x868)))
(and $x53 (or $x868 (and (distinct ?x713 ?x713) true)))))))
(check-sat)
; query 5: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x713 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x868 (or false false false)))
(let (($x53 (not $x868)))
(and $x53 (or $x868 (and (distinct ?x713 ?x713) true)))))))
(check-sat)
; query 6: function fft_float, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x150 (ite (and (distinct (_ bv0 32) in1_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x868 (or false false false)))
(let (($x53 (not $x868)))
(and $x53 (or $x868 (and (distinct ?x150 ?x150) true)))))))
(check-sat)
; query 7: function main, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x80 (ite (= (_ bv4 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x868 (or false false false)))
(let (($x53 (not $x868)))
(and $x53 (or $x868 (and (distinct ?x80 ?x80) true)))))))
(check-sat)
; query 8: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x104 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x868 (or false false false)))
(let (($x53 (not $x868)))
(and $x53 (or $x868 (and (distinct ?x104 ?x104) true)))))))
(check-sat)
