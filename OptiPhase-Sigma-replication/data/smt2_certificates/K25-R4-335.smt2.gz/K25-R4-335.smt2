; OptiPhase-Sigma refinement certificate for sweep K25-R4-335
