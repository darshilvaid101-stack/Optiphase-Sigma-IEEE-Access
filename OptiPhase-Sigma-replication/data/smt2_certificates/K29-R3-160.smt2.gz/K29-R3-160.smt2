; OptiPhase-Sigma refinement certificate for sweep K29-R3-160
