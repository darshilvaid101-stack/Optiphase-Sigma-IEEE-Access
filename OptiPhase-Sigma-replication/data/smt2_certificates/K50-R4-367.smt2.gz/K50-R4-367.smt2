; OptiPhase-Sigma refinement certificate for sweep K50-R4-367
