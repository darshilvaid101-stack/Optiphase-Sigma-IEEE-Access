; OptiPhase-Sigma refinement certificate for sweep K45-R3-144
; query 0: function Index_to_frequency, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x308 (ite (bvuge in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x86 (or false false false)))
(let (($x145 (not $x86)))
(and $x145 (or $x86 (and (distinct ?x308 ?x308) true)))))))
(check-sat)
; query 1: function IsPowerOfTwo, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x86 (or false false false)))
(let (($x145 (not $x86)))
(and $x145 (or $x86 (and (distinct (bvsub in0_32 (_ bv1 32)) (bvsub in0_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function IsPowerOfTwo, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x111 (bvsub in0_32 (_ bv1 32))))
(let ((?x84 (bvand in0_32 ?x111)))
(let (($x86 (or false false false)))
(let (($x44 (or false $x86 false)))
(and (not $x44) (or $x44 (and (distinct ?x84 ?x84) true))))))))
(check-sat)
; query 3: function IsPowerOfTwo, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x300 (ite (and (distinct (_ bv0 32) (bvand in0_32 (bvsub in0_32 (_ bv1 32)))) true) (_ bv1 1) (_ bv0 1))))
(let (($x86 (or false false false)))
(let (($x44 (or false $x86 false)))
(let (($x555 (or $x44 false false)))
(and (not $x555) (or $x555 (and (distinct ?x300 ?x300) true))))))))
(check-sat)
; query 4: function IsPowerOfTwo, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x250 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x86 (or false false false)))
(let (($x145 (not $x86)))
(and $x145 (or $x86 (and (distinct ?x250 ?x250) true)))))))
(check-sat)
; query 5: function NumberOfBitsNeeded, block 13, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x86 (or false false false)))
(let (($x145 (not $x86)))
(and $x145 (or $x86 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 6: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x250 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x86 (or false false false)))
(let (($x145 (not $x86)))
(and $x145 (or $x86 (and (distinct ?x250 ?x250) true)))))))
(check-sat)
; query 7: function ReverseBits, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x86 (or false false false)))
(let (($x145 (not $x86)))
(and $x145 (or $x86 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function ReverseBits, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x86 (or false false false)))
(let (($x1193 (or $x86 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x235 (not $x1193)))
(and $x235 (or $x1193 (and (distinct (bvshl in.01_32 (_ bv1 32)) (bvshl in.01_32 (_ bv1 32))) true)))))))
(check-sat)
; query 9: function ReverseBits, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x86 (or false false false)))
(let (($x145 (not $x86)))
(and $x145 (or $x86 (and (distinct (bvand in.0_32 (_ bv1 32)) (bvand in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 10: function ReverseBits, block 5, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x190 (bvand in.0_32 (_ bv1 32))))
(let ((?x69 (bvshl in.01_32 (_ bv1 32))))
(let ((?x10 (bvor ?x69 ?x190)))
(let (($x86 (or false false false)))
(let (($x1193 (or $x86 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x79 (or $x1193 $x86 false)))
(and (not $x79) (or $x79 (and (distinct ?x10 ?x10) true))))))))))
(check-sat)
; query 11: function ReverseBits, block 5, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x86 (or false false false)))
(let (($x1193 (or $x86 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x235 (not $x1193)))
(and $x235 (or $x1193 (and (distinct (bvlshr in.0_32 (_ bv1 32)) (bvlshr in.0_32 (_ bv1 32))) true)))))))
(check-sat)
; query 12: function fft_float, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x89 (ite (and (distinct (_ bv0 32) in1_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x86 (or false false false)))
(let (($x145 (not $x86)))
(and $x145 (or $x86 (and (distinct ?x89 ?x89) true)))))))
(check-sat)
; query 13: function main, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x46 (ite (= (_ bv4 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x86 (or false false false)))
(let (($x145 (not $x86)))
(and $x145 (or $x86 (and (distinct ?x46 ?x46) true)))))))
(check-sat)
; query 14: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x83 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x86 (or false false false)))
(let (($x145 (not $x86)))
(and $x145 (or $x86 (and (distinct ?x83 ?x83) true)))))))
(check-sat)
