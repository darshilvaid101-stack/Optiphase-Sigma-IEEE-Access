; OptiPhase-Sigma refinement certificate for sweep K31-R5-380
