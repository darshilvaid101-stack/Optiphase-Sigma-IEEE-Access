; OptiPhase-Sigma refinement certificate for sweep K55-R3-111
; query 0: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x1111 (or false false)))
(let (($x51 (not $x1111)))
(and $x51 (or $x1111 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 1: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x171 ((_ sign_extend 16) in3_16)))
(let ((?x478 (bvand ?x171 (_ bv127 32))))
(let (($x1111 (or false false)))
(let (($x86 (or $x1111 false false)))
(let (($x31 (not $x86)))
(and $x31 (or $x86 (and (distinct ?x478 ?x478) true)))))))))
(check-sat)
; query 2: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x171 ((_ sign_extend 16) in3_16)))
(let ((?x478 (bvand ?x171 (_ bv127 32))))
(let ((?x69 ((_ extract 15 0) ?x478)))
(let (($x1111 (or false false)))
(let (($x86 (or $x1111 false false)))
(let (($x555 (or $x86 false)))
(let (($x1034 (not $x555)))
(and $x1034 (or $x555 (and (distinct ?x69 ?x69) true)))))))))))
(check-sat)
; query 3: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x1111 (or false false)))
(let (($x51 (not $x1111)))
(and $x51 (or $x1111 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 4: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x696 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x1111 (or false false)))
(let (($x86 (or $x1111 false false)))
(let (($x31 (not $x86)))
(and $x31 (or $x86 (and (distinct ?x696 ?x696) true))))))))
(check-sat)
; query 5: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x30 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x538 (or false false false)))
(let (($x1103 (not $x538)))
(and $x1103 (or $x538 (and (distinct ?x30 ?x30) true)))))))
(check-sat)
; query 6: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x669 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x538 (or false false false)))
(let (($x1103 (not $x538)))
(and $x1103 (or $x538 (and (distinct ?x669 ?x669) true)))))))
(check-sat)
; query 7: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x538 (or false false false)))
(let (($x1103 (not $x538)))
(and $x1103 (or $x538 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 8: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x275 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x35 (or false false (or $x275))))
(and (not $x35) (or $x35 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 9: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x17 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x409 ((_ zero_extend 31) ?x17)))
(let ((?x28 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x43 ((_ zero_extend 31) ?x28)))
(let ((?x54 (bvand ?x43 ?x409)))
(let ((?x369 (ite (and (distinct (_ bv0 32) ?x54) true) (_ bv1 1) (_ bv0 1))))
(let ((?x294 ((_ zero_extend 63) ?x369)))
(let (($x1111 (or false false)))
(let (($x86 (or $x1111 false false)))
(let (($x555 (or $x86 false)))
(let (($x75 (or $x555 $x555 false)))
(let (($x244 (or $x75 false false)))
(let (($x9 (or $x244 false)))
(and (not $x9) (or $x9 (and (distinct ?x294 ?x294) true)))))))))))))))))
(check-sat)
; query 10: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x17 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x409 ((_ zero_extend 31) ?x17)))
(let ((?x28 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x43 ((_ zero_extend 31) ?x28)))
(let ((?x54 (bvand ?x43 ?x409)))
(let ((?x369 (ite (and (distinct (_ bv0 32) ?x54) true) (_ bv1 1) (_ bv0 1))))
(let (($x724 (= (_ bv1 1) ?x369)))
(let ((?x199 (ite $x724 (_ bv1 32) (_ bv0 32))))
(let (($x1111 (or false false)))
(let (($x86 (or $x1111 false false)))
(let (($x555 (or $x86 false)))
(let (($x75 (or $x555 $x555 false)))
(let (($x244 (or $x75 false false)))
(let (($x117 (or $x244 (ite $x724 false false))))
(and (not $x117) (or $x117 (and (distinct ?x199 ?x199) true))))))))))))))))))
(check-sat)
; query 11: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x17 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x409 ((_ zero_extend 31) ?x17)))
(let ((?x28 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x43 ((_ zero_extend 31) ?x28)))
(let ((?x54 (bvand ?x43 ?x409)))
(let ((?x369 (ite (and (distinct (_ bv0 32) ?x54) true) (_ bv1 1) (_ bv0 1))))
(let (($x724 (= (_ bv1 1) ?x369)))
(let ((?x199 (ite $x724 (_ bv1 32) (_ bv0 32))))
(let ((?x90 ((_ extract 7 0) ?x199)))
(let (($x1111 (or false false)))
(let (($x86 (or $x1111 false false)))
(let (($x555 (or $x86 false)))
(let (($x75 (or $x555 $x555 false)))
(let (($x244 (or $x75 false false)))
(let (($x117 (or $x244 (ite $x724 false false))))
(let (($x309 (or $x117 false)))
(and (not $x309) (or $x309 (and (distinct ?x90 ?x90) true))))))))))))))))))))
(check-sat)
; query 12: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x1111 (or false false)))
(let (($x51 (not $x1111)))
(and $x51 (or $x1111 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 13: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x28 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1111 (or false false)))
(let (($x86 (or $x1111 false false)))
(let (($x31 (not $x86)))
(and $x31 (or $x86 (and (distinct ?x28 ?x28) true))))))))
(check-sat)
; query 14: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x28 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x43 ((_ zero_extend 31) ?x28)))
(let (($x1111 (or false false)))
(let (($x86 (or $x1111 false false)))
(let (($x555 (or $x86 false)))
(let (($x1034 (not $x555)))
(and $x1034 (or $x555 (and (distinct ?x43 ?x43) true))))))))))
(check-sat)
; query 15: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x1111 (or false false)))
(let (($x51 (not $x1111)))
(and $x51 (or $x1111 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 16: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x17 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1111 (or false false)))
(let (($x86 (or $x1111 false false)))
(let (($x31 (not $x86)))
(and $x31 (or $x86 (and (distinct ?x17 ?x17) true))))))))
(check-sat)
; query 17: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x17 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x409 ((_ zero_extend 31) ?x17)))
(let (($x1111 (or false false)))
(let (($x86 (or $x1111 false false)))
(let (($x555 (or $x86 false)))
(let (($x1034 (not $x555)))
(and $x1034 (or $x555 (and (distinct ?x409 ?x409) true))))))))))
(check-sat)
; query 18: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x17 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x409 ((_ zero_extend 31) ?x17)))
(let ((?x28 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x43 ((_ zero_extend 31) ?x28)))
(let ((?x54 (bvand ?x43 ?x409)))
(let (($x1111 (or false false)))
(let (($x86 (or $x1111 false false)))
(let (($x555 (or $x86 false)))
(let (($x75 (or $x555 $x555 false)))
(and (not $x75) (or $x75 (and (distinct ?x54 ?x54) true)))))))))))))
(check-sat)
; query 19: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x17 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x409 ((_ zero_extend 31) ?x17)))
(let ((?x28 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x43 ((_ zero_extend 31) ?x28)))
(let ((?x54 (bvand ?x43 ?x409)))
(let ((?x369 (ite (and (distinct (_ bv0 32) ?x54) true) (_ bv1 1) (_ bv0 1))))
(let (($x1111 (or false false)))
(let (($x86 (or $x1111 false false)))
(let (($x555 (or $x86 false)))
(let (($x75 (or $x555 $x555 false)))
(let (($x244 (or $x75 false false)))
(and (not $x244) (or $x244 (and (distinct ?x369 ?x369) true)))))))))))))))
(check-sat)
; query 20: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x393 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x538 (or false false false)))
(let (($x1103 (not $x538)))
(and $x1103 (or $x538 (and (distinct ?x393 ?x393) true)))))))
(check-sat)
