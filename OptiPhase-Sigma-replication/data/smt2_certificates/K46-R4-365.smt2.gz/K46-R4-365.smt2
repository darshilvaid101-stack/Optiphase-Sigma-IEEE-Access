; OptiPhase-Sigma refinement certificate for sweep K46-R4-365
