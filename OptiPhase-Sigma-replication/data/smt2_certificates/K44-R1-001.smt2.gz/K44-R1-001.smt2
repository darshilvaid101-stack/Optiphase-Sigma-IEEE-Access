; OptiPhase-Sigma refinement certificate for sweep K44-R1-001
; query 0: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x410 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x95 (or false false false)))
(let (($x126 (not $x95)))
(and $x126 (or $x95 (and (distinct ?x410 ?x410) true)))))))
(check-sat)
; query 1: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x306 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x95 (or false false false)))
(let (($x126 (not $x95)))
(and $x126 (or $x95 (and (distinct ?x306 ?x306) true)))))))
(check-sat)
