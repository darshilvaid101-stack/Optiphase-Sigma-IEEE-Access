; OptiPhase-Sigma refinement certificate for sweep K14-R3-099
