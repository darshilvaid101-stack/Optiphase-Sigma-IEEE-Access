; OptiPhase-Sigma refinement certificate for sweep K45-R3-097
; query 0: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x110 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x92 (or false false false)))
(let (($x36 (not $x92)))
(and $x36 (or $x92 (and (distinct ?x110 ?x110) true)))))))
(check-sat)
; query 1: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x90 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x92 (or false false false)))
(let (($x36 (not $x92)))
(and $x36 (or $x92 (and (distinct ?x90 ?x90) true)))))))
(check-sat)
