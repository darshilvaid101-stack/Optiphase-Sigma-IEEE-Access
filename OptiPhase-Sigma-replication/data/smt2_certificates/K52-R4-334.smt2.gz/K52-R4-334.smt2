; OptiPhase-Sigma refinement certificate for sweep K52-R4-334
; query 0: function s162, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x83 (ite (bvslt (_ bv0 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x233 (or false false false)))
(and (not $x233) (or $x233 (and (distinct ?x83 ?x83) true))))))
(check-sat)
