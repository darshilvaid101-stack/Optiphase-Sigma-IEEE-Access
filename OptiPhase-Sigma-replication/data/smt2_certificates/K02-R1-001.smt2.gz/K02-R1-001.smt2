; OptiPhase-Sigma refinement certificate for sweep K02-R1-001
