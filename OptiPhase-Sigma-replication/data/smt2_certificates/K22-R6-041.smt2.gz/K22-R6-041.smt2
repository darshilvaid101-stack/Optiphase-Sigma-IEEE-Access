; OptiPhase-Sigma refinement certificate for sweep K22-R6-041
