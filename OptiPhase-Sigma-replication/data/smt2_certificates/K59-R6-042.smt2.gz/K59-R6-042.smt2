; OptiPhase-Sigma refinement certificate for sweep K59-R6-042
; query 0: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x62 (or false false false)))
(let (($x695 (not $x62)))
(and $x695 (or $x62 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1923 (bvadd in.01_32 (_ bv1 32))))
(let ((?x106 (bvmul ?x1923 ?x1923)))
(let (($x62 (or false false false)))
(let (($x40 (or $x62 $x62 false)))
(and (not $x40) (or $x40 (and (distinct ?x106 ?x106) true))))))))
(check-sat)
; query 2: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1923 (bvadd in.01_32 (_ bv1 32))))
(let ((?x106 (bvmul ?x1923 ?x1923)))
(let ((?x102 (bvmul ?x106 (_ bv2 32))))
(let (($x62 (or false false false)))
(let (($x40 (or $x62 $x62 false)))
(let (($x409 (or $x40 false false)))
(and (not $x409) (or $x409 (and (distinct ?x102 ?x102) true))))))))))
(check-sat)
; query 3: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1923 (bvadd in.01_32 (_ bv1 32))))
(let ((?x106 (bvmul ?x1923 ?x1923)))
(let ((?x102 (bvmul ?x106 (_ bv2 32))))
(let ((?x98 (bvmul ?x102 (_ bv4 32))))
(let (($x62 (or false false false)))
(let (($x40 (or $x62 $x62 false)))
(let (($x409 (or $x40 false false)))
(let (($x103 (or $x409 false false)))
(and (not $x103) (or $x103 (and (distinct ?x98 ?x98) true))))))))))))
(check-sat)
; query 4: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x225 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x62 (or false false false)))
(let (($x695 (not $x62)))
(and $x695 (or $x62 (and (distinct ?x225 ?x225) true)))))))
(check-sat)
; query 5: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x188 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x83 (or false false (or $x188))))
(and (not $x83) (or $x83 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 6: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x121 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x62 (or false false false)))
(let (($x695 (not $x62)))
(and $x695 (or $x62 (and (distinct ?x121 ?x121) true)))))))
(check-sat)
; query 7: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x10 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x62 (or false false false)))
(let (($x695 (not $x62)))
(and $x695 (or $x62 (and (distinct ?x10 ?x10) true)))))))
(check-sat)
; query 8: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x69 (or false false)))
(and (not $x69) (or $x69 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true)))))
(check-sat)
; query 9: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x48 ((_ sign_extend 16) in.1_16)))
(let ((?x671 (bvadd ?x48 (_ bv10 32))))
(let (($x67 (and (distinct (bvadd ((_ sign_extend 1) ?x48) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x671)) true)))
(let (($x69 (or false false)))
(let (($x1675 (or $x69 false (or $x67))))
(and (not $x1675) (or $x1675 (and (distinct ?x671 ?x671) true)))))))))
(check-sat)
; query 10: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x48 ((_ sign_extend 16) in.1_16)))
(let ((?x671 (bvadd ?x48 (_ bv10 32))))
(let ((?x173 ((_ extract 15 0) ?x671)))
(let (($x67 (and (distinct (bvadd ((_ sign_extend 1) ?x48) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x671)) true)))
(let (($x69 (or false false)))
(let (($x1675 (or $x69 false (or $x67))))
(let (($x138 (or $x1675 false)))
(and (not $x138) (or $x138 (and (distinct ?x173 ?x173) true)))))))))))
(check-sat)
; query 11: function matrix_sum, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x3581 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x62 (or false false false)))
(let (($x695 (not $x62)))
(and $x695 (or $x62 (and (distinct ?x3581 ?x3581) true)))))))
(check-sat)
; query 12: function matrix_sum, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x3581 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let ((?x1374 ((_ zero_extend 63) ?x3581)))
(let (($x62 (or false false false)))
(let (($x586 (or $x62 false)))
(and (not $x586) (or $x586 (and (distinct ?x1374 ?x1374) true))))))))
(check-sat)
; query 13: function matrix_sum, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x3581 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x97 (= (_ bv1 1) ?x3581)))
(let ((?x152 (ite $x97 (_ bv1 32) (_ bv0 32))))
(let (($x62 (or false false false)))
(let (($x170 (or $x62 (ite $x97 false false))))
(and (not $x170) (or $x170 (and (distinct ?x152 ?x152) true)))))))))
(check-sat)
; query 14: function matrix_sum, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x69 (or false false)))
(and (not $x69) (or $x69 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true)))))
(check-sat)
; query 15: function matrix_sum, block 22, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x3581 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x97 (= (_ bv1 1) ?x3581)))
(let ((?x152 (ite $x97 (_ bv1 32) (_ bv0 32))))
(let ((?x48 ((_ sign_extend 16) in.1_16)))
(let ((?x192 (bvadd ?x48 ?x152)))
(let (($x43 (and (distinct (bvadd ((_ sign_extend 1) ?x48) ((_ sign_extend 1) ?x152)) ((_ sign_extend 1) ?x192)) true)))
(let (($x62 (or false false false)))
(let (($x170 (or $x62 (ite $x97 false false))))
(let (($x69 (or false false)))
(let (($x216 (or $x69 $x170 (or $x43))))
(and (not $x216) (or $x216 (and (distinct ?x192 ?x192) true))))))))))))))
(check-sat)
; query 16: function matrix_sum, block 22, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x3581 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x97 (= (_ bv1 1) ?x3581)))
(let ((?x152 (ite $x97 (_ bv1 32) (_ bv0 32))))
(let ((?x48 ((_ sign_extend 16) in.1_16)))
(let ((?x192 (bvadd ?x48 ?x152)))
(let ((?x2078 ((_ extract 15 0) ?x192)))
(let (($x43 (and (distinct (bvadd ((_ sign_extend 1) ?x48) ((_ sign_extend 1) ?x152)) ((_ sign_extend 1) ?x192)) true)))
(let (($x62 (or false false false)))
(let (($x170 (or $x62 (ite $x97 false false))))
(let (($x69 (or false false)))
(let (($x216 (or $x69 $x170 (or $x43))))
(let (($x246 (or $x216 false)))
(and (not $x246) (or $x246 (and (distinct ?x2078 ?x2078) true))))))))))))))))
(check-sat)
