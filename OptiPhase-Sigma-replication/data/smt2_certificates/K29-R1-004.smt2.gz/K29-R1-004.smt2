; OptiPhase-Sigma refinement certificate for sweep K29-R1-004
