; OptiPhase-Sigma refinement certificate for sweep K43-R3-288
; query 0: function crc32buf, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_64 () (_ BitVec 64))
(assert
 (let (($x35 (or false false false)))
(let (($x39 (not $x35)))
(and $x39 (or $x35 (and (distinct (bvxor in.02_64 (_ bv18446744073709551615 64)) (bvxor in.02_64 (_ bv18446744073709551615 64))) true))))))
(check-sat)
; query 1: function main, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x149 (ite (and (distinct (_ bv0 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x35 (or false false false)))
(let (($x39 (not $x35)))
(and $x39 (or $x35 (and (distinct ?x149 ?x149) true)))))))
(check-sat)
; query 2: function main, block 17, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x149 (ite (and (distinct (_ bv0 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let ((?x418 ((_ zero_extend 31) ?x149)))
(let (($x35 (or false false false)))
(let (($x161 (or $x35 false)))
(and (not $x161) (or $x161 (and (distinct ?x418 ?x418) true))))))))
(check-sat)
