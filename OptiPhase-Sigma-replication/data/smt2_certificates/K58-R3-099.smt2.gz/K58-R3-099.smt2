; OptiPhase-Sigma refinement certificate for sweep K58-R3-099
; query 0: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x79 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x818 (or false false false)))
(let (($x17 (not $x818)))
(and $x17 (or $x818 (and (distinct ?x79 ?x79) true)))))))
(check-sat)
; query 1: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x479 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x818 (or false false false)))
(let (($x17 (not $x818)))
(and $x17 (or $x818 (and (distinct ?x479 ?x479) true)))))))
(check-sat)
; query 2: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x818 (or false false false)))
(let (($x17 (not $x818)))
(and $x17 (or $x818 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 3: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x1395 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x1333 (or false false (or $x1395))))
(and (not $x1333) (or $x1333 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 4: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1097 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x818 (or false false false)))
(let (($x17 (not $x818)))
(and $x17 (or $x818 (and (distinct ?x1097 ?x1097) true)))))))
(check-sat)
