; OptiPhase-Sigma refinement certificate for sweep K20-R4-370
