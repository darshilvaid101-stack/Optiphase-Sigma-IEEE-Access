; OptiPhase-Sigma refinement certificate for sweep K57-R3-296
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x759 (or false false)))
(let (($x123 (not $x759)))
(and $x123 (or $x759 (and (distinct ((_ sign_extend 16) in25_16) ((_ sign_extend 16) in25_16)) true))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let ((?x243 (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))))
(let (($x759 (or false false)))
(let (($x107 (or $x759 false false)))
(let (($x111 (not $x107)))
(and $x111 (or $x107 (and (distinct ?x243 ?x243) true))))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x759 (or false false)))
(let (($x123 (not $x759)))
(and $x123 (or $x759 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x668 ((_ sign_extend 16) in3_16)))
(let ((?x293 (bvand ?x668 (_ bv127 32))))
(let (($x759 (or false false)))
(let (($x107 (or $x759 false false)))
(let (($x111 (not $x107)))
(and $x111 (or $x107 (and (distinct ?x293 ?x293) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x668 ((_ sign_extend 16) in3_16)))
(let ((?x293 (bvand ?x668 (_ bv127 32))))
(let ((?x22 ((_ extract 15 0) ?x293)))
(let (($x759 (or false false)))
(let (($x107 (or $x759 false false)))
(let (($x263 (or $x107 false)))
(let (($x149 (not $x263)))
(and $x149 (or $x263 (and (distinct ?x22 ?x22) true)))))))))))
(check-sat)
; query 5: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x759 (or false false)))
(let (($x123 (not $x759)))
(and $x123 (or $x759 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 6: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x506 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x759 (or false false)))
(let (($x107 (or $x759 false false)))
(let (($x111 (not $x107)))
(and $x111 (or $x107 (and (distinct ?x506 ?x506) true))))))))
(check-sat)
; query 7: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x836 (or false false false)))
(let (($x552 (not $x836)))
(and $x552 (or $x836 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x426 (bvadd in.01_32 (_ bv1 32))))
(let ((?x54 (bvmul ?x426 ?x426)))
(let (($x836 (or false false false)))
(let (($x138 (or $x836 $x836 false)))
(and (not $x138) (or $x138 (and (distinct ?x54 ?x54) true))))))))
(check-sat)
; query 9: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x61 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x836 (or false false false)))
(let (($x552 (not $x836)))
(and $x552 (or $x836 (and (distinct ?x61 ?x61) true)))))))
(check-sat)
; query 10: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x12 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x836 (or false false false)))
(let (($x552 (not $x836)))
(and $x552 (or $x836 (and (distinct ?x12 ?x12) true)))))))
(check-sat)
; query 11: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x836 (or false false false)))
(let (($x552 (not $x836)))
(and $x552 (or $x836 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 12: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x124 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x855 (or false false (or $x124))))
(and (not $x855) (or $x855 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 13: function crcu8, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x759 (or false false)))
(let (($x123 (not $x759)))
(and $x123 (or $x759 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 14: function crcu8, block 19, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x77 ((_ zero_extend 16) in.01_16)))
(let ((?x235 (bvxor ?x77 (_ bv16386 32))))
(let (($x759 (or false false)))
(let (($x107 (or $x759 false false)))
(let (($x111 (not $x107)))
(and $x111 (or $x107 (and (distinct ?x235 ?x235) true)))))))))
(check-sat)
; query 15: function crcu8, block 19, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x77 ((_ zero_extend 16) in.01_16)))
(let ((?x235 (bvxor ?x77 (_ bv16386 32))))
(let ((?x663 ((_ extract 15 0) ?x235)))
(let (($x759 (or false false)))
(let (($x107 (or $x759 false false)))
(let (($x263 (or $x107 false)))
(let (($x149 (not $x263)))
(and $x149 (or $x263 (and (distinct ?x663 ?x663) true)))))))))))
(check-sat)
; query 16: function crcu8, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x100 ((_ extract 7 0) in.01_16)))
(let ((?x50 ((_ zero_extend 24) ?x100)))
(let (($x759 (or false false)))
(let (($x135 (or $x759 false)))
(and (not $x135) (or $x135 (and (distinct ?x50 ?x50) true))))))))
(check-sat)
; query 17: function crcu8, block 6, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x100 ((_ extract 7 0) in.01_16)))
(let ((?x50 ((_ zero_extend 24) ?x100)))
(let ((?x271 (bvand ?x50 (_ bv1 32))))
(let (($x759 (or false false)))
(let (($x135 (or $x759 false)))
(let (($x450 (or $x135 false false)))
(and (not $x450) (or $x450 (and (distinct ?x271 ?x271) true))))))))))
(check-sat)
; query 18: function crcu8, block 6, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x100 ((_ extract 7 0) in.01_16)))
(let ((?x50 ((_ zero_extend 24) ?x100)))
(let ((?x271 (bvand ?x50 (_ bv1 32))))
(let ((?x851 ((_ zero_extend 24) in.0_8)))
(let ((?x230 (bvand ?x851 (_ bv1 32))))
(let ((?x1944 (bvxor ?x230 ?x271)))
(let (($x759 (or false false)))
(let (($x135 (or $x759 false)))
(let (($x450 (or $x135 false false)))
(let (($x107 (or $x759 false false)))
(let (($x151 (or $x107 $x450 false)))
(and (not $x151) (or $x151 (and (distinct ?x1944 ?x1944) true)))))))))))))))
(check-sat)
; query 19: function crcu8, block 6, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x100 ((_ extract 7 0) in.01_16)))
(let ((?x50 ((_ zero_extend 24) ?x100)))
(let ((?x271 (bvand ?x50 (_ bv1 32))))
(let ((?x851 ((_ zero_extend 24) in.0_8)))
(let ((?x230 (bvand ?x851 (_ bv1 32))))
(let ((?x1944 (bvxor ?x230 ?x271)))
(let ((?x1857 ((_ extract 7 0) ?x1944)))
(let (($x759 (or false false)))
(let (($x135 (or $x759 false)))
(let (($x450 (or $x135 false false)))
(let (($x107 (or $x759 false false)))
(let (($x151 (or $x107 $x450 false)))
(let (($x1927 (or $x151 false)))
(and (not $x1927) (or $x1927 (and (distinct ?x1857 ?x1857) true)))))))))))))))))
(check-sat)
; query 20: function crcu8, block 6, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x759 (or false false)))
(let (($x123 (not $x759)))
(and $x123 (or $x759 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 21: function crcu8, block 6, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x851 ((_ zero_extend 24) in.0_8)))
(let ((?x583 (bvashr ?x851 (_ bv1 32))))
(let (($x759 (or false false)))
(let (($x107 (or $x759 false false)))
(let (($x117 (or $x107 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not $x117) (or $x117 (and (distinct ?x583 ?x583) true)))))))))
(check-sat)
; query 22: function crcu8, block 6, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x851 ((_ zero_extend 24) in.0_8)))
(let ((?x583 (bvashr ?x851 (_ bv1 32))))
(let ((?x26 ((_ extract 7 0) ?x583)))
(let (($x759 (or false false)))
(let (($x107 (or $x759 false false)))
(let (($x117 (or $x107 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x19 (or $x117 false)))
(and (not $x19) (or $x19 (and (distinct ?x26 ?x26) true)))))))))))
(check-sat)
; query 23: function crcu8, block 6, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x100 ((_ extract 7 0) in.01_16)))
(let ((?x50 ((_ zero_extend 24) ?x100)))
(let ((?x271 (bvand ?x50 (_ bv1 32))))
(let ((?x851 ((_ zero_extend 24) in.0_8)))
(let ((?x230 (bvand ?x851 (_ bv1 32))))
(let ((?x1944 (bvxor ?x230 ?x271)))
(let ((?x1857 ((_ extract 7 0) ?x1944)))
(let ((?x281 ((_ zero_extend 24) ?x1857)))
(let (($x759 (or false false)))
(let (($x135 (or $x759 false)))
(let (($x450 (or $x135 false false)))
(let (($x107 (or $x759 false false)))
(let (($x151 (or $x107 $x450 false)))
(let (($x1927 (or $x151 false)))
(let (($x56 (or $x1927 false)))
(and (not $x56) (or $x56 (and (distinct ?x281 ?x281) true)))))))))))))))))))
(check-sat)
; query 24: function crcu8, block 6, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x100 ((_ extract 7 0) in.01_16)))
(let ((?x50 ((_ zero_extend 24) ?x100)))
(let ((?x271 (bvand ?x50 (_ bv1 32))))
(let ((?x851 ((_ zero_extend 24) in.0_8)))
(let ((?x230 (bvand ?x851 (_ bv1 32))))
(let ((?x1944 (bvxor ?x230 ?x271)))
(let ((?x1857 ((_ extract 7 0) ?x1944)))
(let ((?x281 ((_ zero_extend 24) ?x1857)))
(let ((?x1886 (ite (= (_ bv1 32) ?x281) (_ bv1 1) (_ bv0 1))))
(let (($x759 (or false false)))
(let (($x135 (or $x759 false)))
(let (($x450 (or $x135 false false)))
(let (($x107 (or $x759 false false)))
(let (($x151 (or $x107 $x450 false)))
(let (($x1927 (or $x151 false)))
(let (($x56 (or $x1927 false)))
(let (($x35 (or $x56 false false)))
(and (not $x35) (or $x35 (and (distinct ?x1886 ?x1886) true)))))))))))))))))))))
(check-sat)
; query 25: function crcu8, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x759 (or false false)))
(let (($x123 (not $x759)))
(and $x123 (or $x759 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 26: function crcu8, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x851 ((_ zero_extend 24) in.0_8)))
(let ((?x230 (bvand ?x851 (_ bv1 32))))
(let (($x759 (or false false)))
(let (($x107 (or $x759 false false)))
(let (($x111 (not $x107)))
(and $x111 (or $x107 (and (distinct ?x230 ?x230) true)))))))))
(check-sat)
; query 27: function crcu8, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x759 (or false false)))
(let (($x123 (not $x759)))
(and $x123 (or $x759 (and (distinct ((_ extract 7 0) in.01_16) ((_ extract 7 0) in.01_16)) true))))))
(check-sat)
; query 28: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x3341 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2814 ((_ zero_extend 31) ?x3341)))
(let ((?x2880 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2848 ((_ zero_extend 31) ?x2880)))
(let ((?x2373 (bvand ?x2848 ?x2814)))
(let ((?x110 (ite (and (distinct (_ bv0 32) ?x2373) true) (_ bv1 1) (_ bv0 1))))
(let ((?x2605 ((_ zero_extend 63) ?x110)))
(let (($x759 (or false false)))
(let (($x107 (or $x759 false false)))
(let (($x263 (or $x107 false)))
(let (($x3105 (or $x263 $x263 false)))
(let (($x2877 (or $x3105 false false)))
(let (($x2615 (or $x2877 false)))
(and (not $x2615) (or $x2615 (and (distinct ?x2605 ?x2605) true)))))))))))))))))
(check-sat)
; query 29: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x3341 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2814 ((_ zero_extend 31) ?x3341)))
(let ((?x2880 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2848 ((_ zero_extend 31) ?x2880)))
(let ((?x2373 (bvand ?x2848 ?x2814)))
(let ((?x110 (ite (and (distinct (_ bv0 32) ?x2373) true) (_ bv1 1) (_ bv0 1))))
(let (($x3121 (= (_ bv1 1) ?x110)))
(let ((?x2844 (ite $x3121 (_ bv1 32) (_ bv0 32))))
(let (($x759 (or false false)))
(let (($x107 (or $x759 false false)))
(let (($x263 (or $x107 false)))
(let (($x3105 (or $x263 $x263 false)))
(let (($x2877 (or $x3105 false false)))
(let (($x3372 (or $x2877 (ite $x3121 false false))))
(and (not $x3372) (or $x3372 (and (distinct ?x2844 ?x2844) true))))))))))))))))))
(check-sat)
; query 30: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x3341 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2814 ((_ zero_extend 31) ?x3341)))
(let ((?x2880 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2848 ((_ zero_extend 31) ?x2880)))
(let ((?x2373 (bvand ?x2848 ?x2814)))
(let ((?x110 (ite (and (distinct (_ bv0 32) ?x2373) true) (_ bv1 1) (_ bv0 1))))
(let (($x3121 (= (_ bv1 1) ?x110)))
(let ((?x2844 (ite $x3121 (_ bv1 32) (_ bv0 32))))
(let ((?x3373 ((_ extract 7 0) ?x2844)))
(let (($x759 (or false false)))
(let (($x107 (or $x759 false false)))
(let (($x263 (or $x107 false)))
(let (($x3105 (or $x263 $x263 false)))
(let (($x2877 (or $x3105 false false)))
(let (($x3372 (or $x2877 (ite $x3121 false false))))
(let (($x589 (or $x3372 false)))
(and (not $x589) (or $x589 (and (distinct ?x3373 ?x3373) true))))))))))))))))))))
(check-sat)
; query 31: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x759 (or false false)))
(let (($x123 (not $x759)))
(and $x123 (or $x759 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 32: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x2880 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x759 (or false false)))
(let (($x107 (or $x759 false false)))
(let (($x111 (not $x107)))
(and $x111 (or $x107 (and (distinct ?x2880 ?x2880) true))))))))
(check-sat)
; query 33: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x2880 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2848 ((_ zero_extend 31) ?x2880)))
(let (($x759 (or false false)))
(let (($x107 (or $x759 false false)))
(let (($x263 (or $x107 false)))
(let (($x149 (not $x263)))
(and $x149 (or $x263 (and (distinct ?x2848 ?x2848) true))))))))))
(check-sat)
; query 34: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x759 (or false false)))
(let (($x123 (not $x759)))
(and $x123 (or $x759 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 35: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x3341 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x759 (or false false)))
(let (($x107 (or $x759 false false)))
(let (($x111 (not $x107)))
(and $x111 (or $x107 (and (distinct ?x3341 ?x3341) true))))))))
(check-sat)
; query 36: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x3341 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2814 ((_ zero_extend 31) ?x3341)))
(let (($x759 (or false false)))
(let (($x107 (or $x759 false false)))
(let (($x263 (or $x107 false)))
(let (($x149 (not $x263)))
(and $x149 (or $x263 (and (distinct ?x2814 ?x2814) true))))))))))
(check-sat)
; query 37: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x3341 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2814 ((_ zero_extend 31) ?x3341)))
(let ((?x2880 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2848 ((_ zero_extend 31) ?x2880)))
(let ((?x2373 (bvand ?x2848 ?x2814)))
(let (($x759 (or false false)))
(let (($x107 (or $x759 false false)))
(let (($x263 (or $x107 false)))
(let (($x3105 (or $x263 $x263 false)))
(and (not $x3105) (or $x3105 (and (distinct ?x2373 ?x2373) true)))))))))))))
(check-sat)
; query 38: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x3341 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2814 ((_ zero_extend 31) ?x3341)))
(let ((?x2880 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2848 ((_ zero_extend 31) ?x2880)))
(let ((?x2373 (bvand ?x2848 ?x2814)))
(let ((?x110 (ite (and (distinct (_ bv0 32) ?x2373) true) (_ bv1 1) (_ bv0 1))))
(let (($x759 (or false false)))
(let (($x107 (or $x759 false false)))
(let (($x263 (or $x107 false)))
(let (($x3105 (or $x263 $x263 false)))
(let (($x2877 (or $x3105 false false)))
(and (not $x2877) (or $x2877 (and (distinct ?x110 ?x110) true)))))))))))))))
(check-sat)
; query 39: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1889 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x836 (or false false false)))
(let (($x552 (not $x836)))
(and $x552 (or $x836 (and (distinct ?x1889 ?x1889) true)))))))
(check-sat)
; query 40: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x759 (or false false)))
(let (($x123 (not $x759)))
(and $x123 (or $x759 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 41: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x104 ((_ sign_extend 16) in.1_16)))
(let ((?x2399 (bvadd ?x104 (_ bv10 32))))
(let (($x176 (and (distinct (bvadd ((_ sign_extend 1) ?x104) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x2399)) true)))
(let (($x759 (or false false)))
(let (($x3123 (or $x759 false (or $x176))))
(and (not $x3123) (or $x3123 (and (distinct ?x2399 ?x2399) true)))))))))
(check-sat)
; query 42: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x104 ((_ sign_extend 16) in.1_16)))
(let ((?x2399 (bvadd ?x104 (_ bv10 32))))
(let ((?x3122 ((_ extract 15 0) ?x2399)))
(let (($x176 (and (distinct (bvadd ((_ sign_extend 1) ?x104) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x2399)) true)))
(let (($x759 (or false false)))
(let (($x3123 (or $x759 false (or $x176))))
(let (($x3124 (or $x3123 false)))
(and (not $x3124) (or $x3124 (and (distinct ?x3122 ?x3122) true)))))))))))
(check-sat)
