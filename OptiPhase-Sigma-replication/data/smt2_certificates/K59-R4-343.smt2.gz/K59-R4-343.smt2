; OptiPhase-Sigma refinement certificate for sweep K59-R4-343
; query 0: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x466 (or false false false)))
(let (($x166 (not $x466)))
(and $x166 (or $x466 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 1: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1334 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x466 (or false false false)))
(let (($x166 (not $x466)))
(and $x166 (or $x466 (and (distinct ?x1334 ?x1334) true)))))))
(check-sat)
