; OptiPhase-Sigma refinement certificate for sweep K56-R3-244
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x137 (or false (or (= ((_ extract 15 15) in25_16) (_ bv1 1))))))
(let (($x110 (or false false)))
(let (($x1675 (not $x110)))
(and $x1675 (or $x137 (and (distinct ((_ sign_extend 16) in25_16) ((_ zero_extend 16) in25_16)) true)))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x13 (and (distinct (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1)) (ite (bvsgt (_ bv34 32) ((_ zero_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))) true)))
(let (($x1658 (or (or (or false (or (= ((_ extract 15 15) in25_16) (_ bv1 1)))) false false) $x13)))
(let (($x110 (or false false)))
(let (($x161 (or $x110 false false)))
(let (($x78 (not $x161)))
(and $x78 $x1658)))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x110 (or false false)))
(let (($x1675 (not $x110)))
(and $x1675 (or $x110 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x368 ((_ sign_extend 16) in3_16)))
(let ((?x44 (bvand ?x368 (_ bv127 32))))
(let (($x110 (or false false)))
(let (($x161 (or $x110 false false)))
(let (($x78 (not $x161)))
(and $x78 (or $x161 (and (distinct ?x44 ?x44) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x368 ((_ sign_extend 16) in3_16)))
(let ((?x44 (bvand ?x368 (_ bv127 32))))
(let ((?x190 ((_ extract 15 0) ?x44)))
(let (($x2851 (or (and (distinct ((_ zero_extend 16) ?x190) ?x44) true) (and (distinct ((_ sign_extend 16) ?x190) ?x44) true))))
(let (($x110 (or false false)))
(let (($x161 (or $x110 false false)))
(let (($x33 (or $x161 false)))
(let (($x671 (not $x33)))
(and $x671 (or (or $x161 $x2851) (and (distinct ?x190 ?x190) true))))))))))))
(check-sat)
; query 5: function core_bench_list, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x67 (or false false false)))
(let (($x1892 (not $x67)))
(and $x1892 (or $x67 (and (distinct (bvadd in.0_16 (_ bv1 16)) (bvadd in.0_16 (_ bv1 16))) true))))))
(check-sat)
; query 6: function core_bench_list, block 82, name %83
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let (($x110 (or false false)))
(let (($x1675 (not $x110)))
(and $x1675 (or $x110 (and (distinct ((_ zero_extend 16) in.02_16) ((_ zero_extend 16) in.02_16)) true))))))
(check-sat)
; query 7: function core_bench_list, block 82, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x206 ((_ zero_extend 16) in.02_16)))
(let ((?x2149 (bvmul ?x206 (_ bv4 32))))
(let (($x15 (and (distinct (bvmul ((_ zero_extend 32) ?x206) ((_ zero_extend 32) (_ bv4 32))) ((_ zero_extend 32) ?x2149)) true)))
(let (($x246 (and (distinct (bvmul ((_ sign_extend 32) ?x206) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x2149)) true)))
(let (($x110 (or false false)))
(let (($x695 (or $x110 false (or $x246 $x15))))
(and (not (or $x110 false (or $x246))) (or $x695 (and (distinct ?x2149 ?x2149) true))))))))))
(check-sat)
; query 8: function core_bench_list, block 82, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let (($x110 (or false false)))
(let (($x1675 (not $x110)))
(and $x1675 (or $x110 (and (distinct ((_ zero_extend 16) in.04_16) ((_ zero_extend 16) in.04_16)) true))))))
(check-sat)
; query 9: function core_bench_list, block 82, name %86
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x685 ((_ zero_extend 16) in.04_16)))
(let ((?x206 ((_ zero_extend 16) in.02_16)))
(let ((?x2149 (bvmul ?x206 (_ bv4 32))))
(let ((?x1566 (bvsub ?x2149 ?x685)))
(let ((?x491 ((_ sign_extend 1) ?x1566)))
(let (($x442 (or (and (distinct (bvsub ((_ sign_extend 1) ?x2149) ((_ sign_extend 1) ?x685)) ?x491) true))))
(let (($x110 (or false false)))
(let (($x15 (and (distinct (bvmul ((_ zero_extend 32) ?x206) ((_ zero_extend 32) (_ bv4 32))) ((_ zero_extend 32) ?x2149)) true)))
(let (($x246 (and (distinct (bvmul ((_ sign_extend 32) ?x206) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x2149)) true)))
(let (($x695 (or $x110 false (or $x246 $x15))))
(let (($x666 (or $x695 $x110 $x442)))
(and (not (or (or $x110 false (or $x246)) $x110 $x442)) (or $x666 (and (distinct ?x1566 ?x1566) true)))))))))))))))
(check-sat)
; query 10: function core_bench_list, block 82, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x110 (or false false)))
(let (($x1675 (not $x110)))
(and $x1675 (or $x110 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 11: function core_bench_list, block 82, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x685 ((_ zero_extend 16) in.04_16)))
(let ((?x206 ((_ zero_extend 16) in.02_16)))
(let ((?x2149 (bvmul ?x206 (_ bv4 32))))
(let ((?x1566 (bvsub ?x2149 ?x685)))
(let ((?x158 ((_ zero_extend 16) in.01_16)))
(let ((?x41 (bvadd ?x158 ?x1566)))
(let (($x57 (and (distinct (bvadd ((_ sign_extend 1) ?x158) ((_ sign_extend 1) ?x1566)) ((_ sign_extend 1) ?x41)) true)))
(let (($x1374 (or $x57)))
(let ((?x491 ((_ sign_extend 1) ?x1566)))
(let (($x442 (or (and (distinct (bvsub ((_ sign_extend 1) ?x2149) ((_ sign_extend 1) ?x685)) ?x491) true))))
(let (($x110 (or false false)))
(let (($x15 (and (distinct (bvmul ((_ zero_extend 32) ?x206) ((_ zero_extend 32) (_ bv4 32))) ((_ zero_extend 32) ?x2149)) true)))
(let (($x246 (and (distinct (bvmul ((_ sign_extend 32) ?x206) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x2149)) true)))
(let (($x695 (or $x110 false (or $x246 $x15))))
(let (($x666 (or $x695 $x110 $x442)))
(let (($x1528 (or $x110 $x666 $x1374)))
(and (not (or $x110 (or (or $x110 false (or $x246)) $x110 $x442) $x1374)) (or $x1528 (and (distinct ?x41 ?x41) true))))))))))))))))))))
(check-sat)
; query 12: function core_bench_list, block 82, name %89
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x685 ((_ zero_extend 16) in.04_16)))
(let ((?x206 ((_ zero_extend 16) in.02_16)))
(let ((?x2149 (bvmul ?x206 (_ bv4 32))))
(let ((?x1566 (bvsub ?x2149 ?x685)))
(let ((?x158 ((_ zero_extend 16) in.01_16)))
(let ((?x41 (bvadd ?x158 ?x1566)))
(let ((?x3581 ((_ extract 15 0) ?x41)))
(let (($x57 (and (distinct (bvadd ((_ sign_extend 1) ?x158) ((_ sign_extend 1) ?x1566)) ((_ sign_extend 1) ?x41)) true)))
(let (($x1374 (or $x57)))
(let ((?x491 ((_ sign_extend 1) ?x1566)))
(let (($x442 (or (and (distinct (bvsub ((_ sign_extend 1) ?x2149) ((_ sign_extend 1) ?x685)) ?x491) true))))
(let (($x110 (or false false)))
(let (($x15 (and (distinct (bvmul ((_ zero_extend 32) ?x206) ((_ zero_extend 32) (_ bv4 32))) ((_ zero_extend 32) ?x2149)) true)))
(let (($x246 (and (distinct (bvmul ((_ sign_extend 32) ?x206) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x2149)) true)))
(let (($x695 (or $x110 false (or $x246 $x15))))
(let (($x666 (or $x695 $x110 $x442)))
(let (($x1528 (or $x110 $x666 $x1374)))
(let (($x62 (or $x110 false (or $x246))))
(let (($x31 (or $x62 $x110 $x442)))
(let (($x68 (or $x110 $x31 $x1374)))
(and (not (or $x68 false)) (or (or $x1528 false) (and (distinct ?x3581 ?x3581) true))))))))))))))))))))))))
(check-sat)
; query 13: function core_bench_list, block 82, name %90
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x110 (or false false)))
(let (($x1675 (not $x110)))
(and $x1675 (or $x110 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 14: function core_bench_list, block 82, name %91
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x674 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x110 (or false false)))
(let (($x161 (or $x110 false false)))
(let (($x78 (not $x161)))
(and $x78 (or $x161 (and (distinct ?x674 ?x674) true))))))))
(check-sat)
; query 15: function core_bench_state, block 105, name %106
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let ((?x83 (bvadd in.1_32 (_ bv1 32))))
(let (($x19 (and (distinct ?x83 ?x83) true)))
(let (($x2724 (and (distinct (bvadd ((_ zero_extend 1) in.1_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) ?x83)) true)))
(let (($x50 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x83)) true)))
(let (($x67 (or false false false)))
(let (($x1892 (not $x67)))
(and $x1892 (or (or false false (or $x50 $x2724)) $x19)))))))))
(check-sat)
; query 16: function core_bench_state, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x111 (bvadd in.0_32 (_ bv1 32))))
(let (($x156 (and (distinct ?x111 ?x111) true)))
(let (($x48 (and (distinct (bvadd ((_ zero_extend 1) in.0_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) ?x111)) true)))
(let (($x170 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x111)) true)))
(let (($x67 (or false false false)))
(let (($x1892 (not $x67)))
(and $x1892 (or (or false false (or $x170 $x48)) $x156)))))))))
(check-sat)
; query 17: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x228 (bvadd in.01_32 (_ bv1 32))))
(let (($x347 (and (distinct ?x228 ?x228) true)))
(let (($x67 (or false false false)))
(let (($x1892 (not $x67)))
(and $x1892 (or $x67 $x347)))))))
(check-sat)
; query 18: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x228 (bvadd in.01_32 (_ bv1 32))))
(let ((?x302 (bvmul ?x228 ?x228)))
(let (($x67 (or false false false)))
(let (($x232 (or $x67 $x67 false)))
(and (not $x232) (or $x232 (and (distinct ?x302 ?x302) true))))))))
(check-sat)
; query 19: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x228 (bvadd in.01_32 (_ bv1 32))))
(let ((?x302 (bvmul ?x228 ?x228)))
(let ((?x647 (bvmul ?x302 (_ bv2 32))))
(let (($x67 (or false false false)))
(let (($x232 (or $x67 $x67 false)))
(let (($x615 (or $x232 false false)))
(and (not $x615) (or $x615 (and (distinct ?x647 ?x647) true))))))))))
(check-sat)
; query 20: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x228 (bvadd in.01_32 (_ bv1 32))))
(let ((?x302 (bvmul ?x228 ?x228)))
(let ((?x647 (bvmul ?x302 (_ bv2 32))))
(let ((?x311 (bvmul ?x647 (_ bv4 32))))
(let (($x67 (or false false false)))
(let (($x232 (or $x67 $x67 false)))
(let (($x615 (or $x232 false false)))
(let (($x7 (or $x615 false false)))
(and (not $x7) (or $x7 (and (distinct ?x311 ?x311) true))))))))))))
(check-sat)
; query 21: function core_init_matrix, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let ((?x83 (bvadd in.1_32 (_ bv1 32))))
(let (($x19 (and (distinct ?x83 ?x83) true)))
(let (($x67 (or false false false)))
(let (($x1892 (not $x67)))
(and $x1892 (or $x67 $x19)))))))
(check-sat)
; query 22: function core_init_matrix, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x67 (or false false false)))
(let (($x1892 (not $x67)))
(and $x1892 (or $x67 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 23: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x3088 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x67 (or false false false)))
(let (($x1892 (not $x67)))
(and $x1892 (or $x67 (and (distinct ?x3088 ?x3088) true)))))))
(check-sat)
; query 24: function core_init_state, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_32 () (_ BitVec 32))
(assert
 (let (($x3334 (and (distinct (bvadd ((_ zero_extend 1) in.06_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.06_32 (_ bv1 32)))) true)))
(let (($x5841 (and (distinct (bvadd ((_ sign_extend 1) in.06_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.06_32 (_ bv1 32)))) true)))
(let (($x7408 (or (or false false (or $x5841 $x3334)) (and (distinct (bvadd in.06_32 (_ bv1 32)) (bvadd in.06_32 (_ bv1 32))) true))))
(let (($x67 (or false false false)))
(let (($x1892 (not $x67)))
(and $x1892 $x7408)))))))
(check-sat)
; query 25: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x2189 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x67 (or false false false)))
(let (($x1892 (not $x67)))
(and $x1892 (or $x67 (and (distinct ?x2189 ?x2189) true)))))))
(check-sat)
; query 26: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x67 (or false false false)))
(let (($x1892 (not $x67)))
(and $x1892 (or $x67 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 27: function core_list_init, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x228 (bvadd in.01_32 (_ bv1 32))))
(let (($x347 (and (distinct ?x228 ?x228) true)))
(let (($x3134 (and (distinct (bvadd ((_ zero_extend 1) in.01_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) ?x228)) true)))
(let (($x67 (or false false false)))
(let (($x1892 (not $x67)))
(and $x1892 (or (or false false (or $x3134)) $x347))))))))
(check-sat)
; query 28: function core_list_mergesort, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x228 (bvadd in.01_32 (_ bv1 32))))
(let (($x347 (and (distinct ?x228 ?x228) true)))
(let (($x6029 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x228)) true)))
(let (($x2759 (or false false (or $x6029))))
(and (not $x2759) (or $x2759 $x347)))))))
(check-sat)
; query 29: function core_list_mergesort, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x3758 (ite (bvslt (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x67 (or false false false)))
(let (($x1892 (not $x67)))
(and $x1892 (or $x67 (and (distinct ?x3758 ?x3758) true)))))))
(check-sat)
; query 30: function core_list_mergesort, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.224_32 () (_ BitVec 32))
(assert
 (let ((?x1780 (ite (= (_ bv0 32) in.224_32) (_ bv1 1) (_ bv0 1))))
(let (($x67 (or false false false)))
(let (($x1892 (not $x67)))
(and $x1892 (or $x67 (and (distinct ?x1780 ?x1780) true)))))))
(check-sat)
; query 31: function core_list_mergesort, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x5009 (ite (= (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x67 (or false false false)))
(let (($x1892 (not $x67)))
(and $x1892 (or $x67 (and (distinct ?x5009 ?x5009) true)))))))
(check-sat)
; query 32: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x7157 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x2656 (or false false (or $x7157))))
(and (not $x2656) (or $x2656 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 33: function core_list_mergesort, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x5689 (and (distinct (bvmul ((_ sign_extend 32) in.020_32) ((_ sign_extend 32) (_ bv2 32))) ((_ sign_extend 32) (bvmul in.020_32 (_ bv2 32)))) true)))
(let (($x917 (or false false (or $x5689))))
(and (not $x917) (or $x917 (and (distinct (bvmul in.020_32 (_ bv2 32)) (bvmul in.020_32 (_ bv2 32))) true))))))
(check-sat)
; query 34: function core_state_transition, block 102, name %103
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x110 (or false false)))
(let (($x1675 (not $x110)))
(and $x1675 (or $x110 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 35: function core_state_transition, block 102, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1142 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x110 (or false false)))
(let (($x161 (or $x110 false false)))
(let (($x78 (not $x161)))
(and $x78 (or $x161 (and (distinct ?x1142 ?x1142) true))))))))
(check-sat)
; query 36: function core_state_transition, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x110 (or false false)))
(let (($x1675 (not $x110)))
(and $x1675 (or $x110 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 37: function core_state_transition, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x2165 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x110 (or false false)))
(let (($x161 (or $x110 false false)))
(let (($x78 (not $x161)))
(and $x78 (or $x161 (and (distinct ?x2165 ?x2165) true))))))))
(check-sat)
; query 38: function core_state_transition, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x110 (or false false)))
(let (($x1675 (not $x110)))
(and $x1675 (or $x110 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 39: function core_state_transition, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1142 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x110 (or false false)))
(let (($x161 (or $x110 false false)))
(let (($x78 (not $x161)))
(and $x78 (or $x161 (and (distinct ?x1142 ?x1142) true))))))))
(check-sat)
; query 40: function core_state_transition, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x110 (or false false)))
(let (($x1675 (not $x110)))
(and $x1675 (or $x110 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 41: function core_state_transition, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x7367 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x110 (or false false)))
(let (($x161 (or $x110 false false)))
(let (($x78 (not $x161)))
(and $x78 (or $x161 (and (distinct ?x7367 ?x7367) true))))))))
(check-sat)
; query 42: function core_state_transition, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x110 (or false false)))
(let (($x1675 (not $x110)))
(and $x1675 (or $x110 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 43: function core_state_transition, block 51, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x7367 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x110 (or false false)))
(let (($x161 (or $x110 false false)))
(let (($x78 (not $x161)))
(and $x78 (or $x161 (and (distinct ?x7367 ?x7367) true))))))))
(check-sat)
; query 44: function core_state_transition, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x110 (or false false)))
(let (($x1675 (not $x110)))
(and $x1675 (or $x110 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 45: function core_state_transition, block 64, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x7367 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x110 (or false false)))
(let (($x161 (or $x110 false false)))
(let (($x78 (not $x161)))
(and $x78 (or $x161 (and (distinct ?x7367 ?x7367) true))))))))
(check-sat)
; query 46: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x4178 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x67 (or false false false)))
(let (($x1892 (not $x67)))
(and $x1892 (or $x67 (and (distinct ?x4178 ?x4178) true)))))))
(check-sat)
; query 47: function core_state_transition, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x110 (or false false)))
(let (($x1675 (not $x110)))
(and $x1675 (or $x110 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 48: function core_state_transition, block 80, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x3121 (ite (= (_ bv69 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x110 (or false false)))
(let (($x161 (or $x110 false false)))
(let (($x78 (not $x161)))
(and $x78 (or $x161 (and (distinct ?x3121 ?x3121) true))))))))
(check-sat)
; query 49: function core_state_transition, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x110 (or false false)))
(let (($x1675 (not $x110)))
(and $x1675 (or $x110 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 50: function core_state_transition, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x7485 (ite (= (_ bv101 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x110 (or false false)))
(let (($x161 (or $x110 false false)))
(let (($x78 (not $x161)))
(and $x78 (or $x161 (and (distinct ?x7485 ?x7485) true))))))))
(check-sat)
; query 51: function core_state_transition, block 99, name %100
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x110 (or false false)))
(let (($x1675 (not $x110)))
(and $x1675 (or $x110 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 52: function core_state_transition, block 99, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x2165 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x110 (or false false)))
(let (($x161 (or $x110 false false)))
(let (($x78 (not $x161)))
(and $x78 (or $x161 (and (distinct ?x2165 ?x2165) true))))))))
(check-sat)
; query 53: function crcu8, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x110 (or false false)))
(let (($x1675 (not $x110)))
(and $x1675 (or $x110 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 54: function crcu8, block 19, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x158 ((_ zero_extend 16) in.01_16)))
(let ((?x2496 (bvxor ?x158 (_ bv16386 32))))
(let (($x110 (or false false)))
(let (($x161 (or $x110 false false)))
(let (($x78 (not $x161)))
(and $x78 (or $x161 (and (distinct ?x2496 ?x2496) true)))))))))
(check-sat)
; query 55: function crcu8, block 19, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x158 ((_ zero_extend 16) in.01_16)))
(let ((?x2496 (bvxor ?x158 (_ bv16386 32))))
(let ((?x626 ((_ extract 15 0) ?x2496)))
(let (($x110 (or false false)))
(let (($x161 (or $x110 false false)))
(let (($x3842 (or (or $x161 (or (and (distinct ((_ zero_extend 16) ?x626) ?x2496) true))) (and (distinct ?x626 ?x626) true))))
(let (($x33 (or $x161 false)))
(let (($x671 (not $x33)))
(and $x671 $x3842))))))))))
(check-sat)
; query 56: function crcu8, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x3454 (or false (or (= ((_ extract 15 15) in27_16) (_ bv1 1))))))
(let (($x110 (or false false)))
(let (($x1675 (not $x110)))
(and $x1675 (or $x3454 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true)))))))
(check-sat)
; query 57: function crcu8, block 29, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1459 ((_ zero_extend 16) in27_16)))
(let ((?x5040 (bvor ?x1459 (_ bv32768 32))))
(let (($x3454 (or false (or (= ((_ extract 15 15) in27_16) (_ bv1 1))))))
(let (($x2411 (or $x3454 false false)))
(let (($x110 (or false false)))
(let (($x161 (or $x110 false false)))
(let (($x78 (not $x161)))
(and $x78 (or $x2411 (and (distinct ?x5040 ?x5040) true)))))))))))
(check-sat)
; query 58: function crcu8, block 29, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1459 ((_ zero_extend 16) in27_16)))
(let ((?x5040 (bvor ?x1459 (_ bv32768 32))))
(let ((?x3547 ((_ extract 15 0) ?x5040)))
(let (($x3454 (or false (or (= ((_ extract 15 15) in27_16) (_ bv1 1))))))
(let (($x2411 (or $x3454 false false)))
(let (($x4409 (or (or $x2411 (or (and (distinct ((_ zero_extend 16) ?x3547) ?x5040) true))) (and (distinct ?x3547 ?x3547) true))))
(let (($x110 (or false false)))
(let (($x161 (or $x110 false false)))
(let (($x33 (or $x161 false)))
(let (($x671 (not $x33)))
(and $x671 $x4409))))))))))))
(check-sat)
; query 59: function crcu8, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x877 ((_ extract 7 0) in.01_16)))
(let ((?x3230 ((_ zero_extend 24) ?x877)))
(let (($x110 (or false false)))
(let (($x4597 (or $x110 false)))
(and (not $x4597) (or $x4597 (and (distinct ?x3230 ?x3230) true))))))))
(check-sat)
; query 60: function crcu8, block 6, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x877 ((_ extract 7 0) in.01_16)))
(let ((?x3230 ((_ zero_extend 24) ?x877)))
(let ((?x4110 (bvand ?x3230 (_ bv1 32))))
(let (($x110 (or false false)))
(let (($x4597 (or $x110 false)))
(let (($x5522 (or $x4597 false false)))
(and (not $x5522) (or $x5522 (and (distinct ?x4110 ?x4110) true))))))))))
(check-sat)
; query 61: function crcu8, block 6, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x877 ((_ extract 7 0) in.01_16)))
(let ((?x3230 ((_ zero_extend 24) ?x877)))
(let ((?x4110 (bvand ?x3230 (_ bv1 32))))
(let ((?x7520 ((_ zero_extend 24) in.0_8)))
(let ((?x7247 (bvand ?x7520 (_ bv1 32))))
(let ((?x5980 (bvxor ?x7247 ?x4110)))
(let (($x110 (or false false)))
(let (($x4597 (or $x110 false)))
(let (($x5522 (or $x4597 false false)))
(let (($x161 (or $x110 false false)))
(let (($x1920 (or $x161 $x5522 false)))
(and (not $x1920) (or $x1920 (and (distinct ?x5980 ?x5980) true)))))))))))))))
(check-sat)
; query 62: function crcu8, block 6, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x877 ((_ extract 7 0) in.01_16)))
(let ((?x3230 ((_ zero_extend 24) ?x877)))
(let ((?x4110 (bvand ?x3230 (_ bv1 32))))
(let ((?x7520 ((_ zero_extend 24) in.0_8)))
(let ((?x7247 (bvand ?x7520 (_ bv1 32))))
(let ((?x5980 (bvxor ?x7247 ?x4110)))
(let ((?x1638 ((_ extract 7 0) ?x5980)))
(let (($x7027 (or (and (distinct ((_ zero_extend 24) ?x1638) ?x5980) true) (and (distinct ((_ sign_extend 24) ?x1638) ?x5980) true))))
(let (($x110 (or false false)))
(let (($x4597 (or $x110 false)))
(let (($x5522 (or $x4597 false false)))
(let (($x161 (or $x110 false false)))
(let (($x1920 (or $x161 $x5522 false)))
(let (($x4361 (or $x1920 $x7027)))
(and (not (or $x1920 false)) (or $x4361 (and (distinct ?x1638 ?x1638) true))))))))))))))))))
(check-sat)
; query 63: function crcu8, block 6, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x110 (or false false)))
(let (($x1675 (not $x110)))
(and $x1675 (or $x110 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 64: function crcu8, block 6, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x7520 ((_ zero_extend 24) in.0_8)))
(let ((?x1273 (bvlshr ?x7520 (_ bv1 32))))
(let ((?x3734 (bvashr ?x7520 (_ bv1 32))))
(let (($x110 (or false false)))
(let (($x161 (or $x110 false false)))
(let (($x5446 (or $x161 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not $x5446) (or $x5446 (and (distinct ?x3734 ?x1273) true))))))))))
(check-sat)
; query 65: function crcu8, block 6, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x533 (and (distinct ((_ extract 7 0) (bvashr ((_ zero_extend 24) in.0_8) (_ bv1 32))) ((_ extract 7 0) (bvlshr ((_ zero_extend 24) in.0_8) (_ bv1 32)))) true)))
(let (($x110 (or false false)))
(let (($x161 (or $x110 false false)))
(let (($x5446 (or $x161 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x279 (or $x5446 false)))
(and (not $x279) (or $x279 $x533))))))))
(check-sat)
; query 66: function crcu8, block 6, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x877 ((_ extract 7 0) in.01_16)))
(let ((?x3230 ((_ zero_extend 24) ?x877)))
(let ((?x4110 (bvand ?x3230 (_ bv1 32))))
(let ((?x7520 ((_ zero_extend 24) in.0_8)))
(let ((?x7247 (bvand ?x7520 (_ bv1 32))))
(let ((?x5980 (bvxor ?x7247 ?x4110)))
(let ((?x1638 ((_ extract 7 0) ?x5980)))
(let ((?x404 ((_ zero_extend 24) ?x1638)))
(let (($x110 (or false false)))
(let (($x4597 (or $x110 false)))
(let (($x5522 (or $x4597 false false)))
(let (($x161 (or $x110 false false)))
(let (($x1920 (or $x161 $x5522 false)))
(let (($x4361 (or $x1920 (or (and (distinct ?x404 ?x5980) true) (and (distinct ((_ sign_extend 24) ?x1638) ?x5980) true)))))
(let (($x1664 (or $x4361 (or (= ((_ extract 7 7) ?x1638) (_ bv1 1))))))
(and (not (or (or $x1920 false) false)) (or $x1664 (and (distinct ?x404 ?x404) true)))))))))))))))))))
(check-sat)
; query 67: function crcu8, block 6, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x877 ((_ extract 7 0) in.01_16)))
(let ((?x3230 ((_ zero_extend 24) ?x877)))
(let ((?x4110 (bvand ?x3230 (_ bv1 32))))
(let ((?x7520 ((_ zero_extend 24) in.0_8)))
(let ((?x7247 (bvand ?x7520 (_ bv1 32))))
(let ((?x5980 (bvxor ?x7247 ?x4110)))
(let ((?x1638 ((_ extract 7 0) ?x5980)))
(let ((?x404 ((_ zero_extend 24) ?x1638)))
(let ((?x7130 (ite (= (_ bv1 32) ?x404) (_ bv1 1) (_ bv0 1))))
(let (($x110 (or false false)))
(let (($x4597 (or $x110 false)))
(let (($x5522 (or $x4597 false false)))
(let (($x161 (or $x110 false false)))
(let (($x1920 (or $x161 $x5522 false)))
(let (($x4361 (or $x1920 (or (and (distinct ?x404 ?x5980) true) (and (distinct ((_ sign_extend 24) ?x1638) ?x5980) true)))))
(let (($x1664 (or $x4361 (or (= ((_ extract 7 7) ?x1638) (_ bv1 1))))))
(and (not (or (or (or $x1920 false) false) false false)) (or (or $x1664 false false) (and (distinct ?x7130 ?x7130) true))))))))))))))))))))
(check-sat)
; query 68: function crcu8, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x110 (or false false)))
(let (($x1675 (not $x110)))
(and $x1675 (or $x110 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 69: function crcu8, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x7520 ((_ zero_extend 24) in.0_8)))
(let ((?x7247 (bvand ?x7520 (_ bv1 32))))
(let (($x110 (or false false)))
(let (($x161 (or $x110 false false)))
(let (($x78 (not $x161)))
(and $x78 (or $x161 (and (distinct ?x7247 ?x7247) true)))))))))
(check-sat)
; query 70: function crcu8, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x110 (or false false)))
(let (($x1675 (not $x110)))
(and $x1675 (or $x110 (and (distinct ((_ extract 7 0) in.01_16) ((_ extract 7 0) in.01_16)) true))))))
(check-sat)
; query 71: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x5838 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1274 ((_ zero_extend 31) ?x5838)))
(let ((?x5361 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2215 ((_ zero_extend 31) ?x5361)))
(let ((?x350 (bvand ?x2215 ?x1274)))
(let ((?x7276 (ite (and (distinct (_ bv0 32) ?x350) true) (_ bv1 1) (_ bv0 1))))
(let ((?x3260 ((_ zero_extend 63) ?x7276)))
(let (($x110 (or false false)))
(let (($x161 (or $x110 false false)))
(let (($x33 (or $x161 false)))
(let (($x1739 (or $x33 $x33 false)))
(let (($x3709 (or $x1739 false false)))
(let (($x5153 (or $x3709 false)))
(and (not $x5153) (or $x5153 (and (distinct ?x3260 ?x3260) true)))))))))))))))))
(check-sat)
; query 72: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x5838 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1274 ((_ zero_extend 31) ?x5838)))
(let ((?x5361 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2215 ((_ zero_extend 31) ?x5361)))
(let ((?x350 (bvand ?x2215 ?x1274)))
(let ((?x7276 (ite (and (distinct (_ bv0 32) ?x350) true) (_ bv1 1) (_ bv0 1))))
(let (($x5989 (= (_ bv1 1) ?x7276)))
(let ((?x7429 (ite $x5989 (_ bv1 32) (_ bv0 32))))
(let (($x110 (or false false)))
(let (($x161 (or $x110 false false)))
(let (($x33 (or $x161 false)))
(let (($x1739 (or $x33 $x33 false)))
(let (($x3709 (or $x1739 false false)))
(let (($x7097 (or $x3709 (ite $x5989 false false))))
(and (not $x7097) (or $x7097 (and (distinct ?x7429 ?x7429) true))))))))))))))))))
(check-sat)
; query 73: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x5838 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1274 ((_ zero_extend 31) ?x5838)))
(let ((?x5361 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2215 ((_ zero_extend 31) ?x5361)))
(let ((?x350 (bvand ?x2215 ?x1274)))
(let ((?x7276 (ite (and (distinct (_ bv0 32) ?x350) true) (_ bv1 1) (_ bv0 1))))
(let (($x5989 (= (_ bv1 1) ?x7276)))
(let ((?x7429 (ite $x5989 (_ bv1 32) (_ bv0 32))))
(let ((?x5027 ((_ extract 7 0) ?x7429)))
(let (($x4926 (or (and (distinct ((_ zero_extend 24) ?x5027) ?x7429) true) (and (distinct ((_ sign_extend 24) ?x5027) ?x7429) true))))
(let (($x110 (or false false)))
(let (($x161 (or $x110 false false)))
(let (($x33 (or $x161 false)))
(let (($x1739 (or $x33 $x33 false)))
(let (($x3709 (or $x1739 false false)))
(let (($x7097 (or $x3709 (ite $x5989 false false))))
(and (not (or $x7097 false)) (or (or $x7097 $x4926) (and (distinct ?x5027 ?x5027) true))))))))))))))))))))
(check-sat)
; query 74: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x110 (or false false)))
(let (($x1675 (not $x110)))
(and $x1675 (or $x110 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 75: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x5361 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x110 (or false false)))
(let (($x161 (or $x110 false false)))
(let (($x78 (not $x161)))
(and $x78 (or $x161 (and (distinct ?x5361 ?x5361) true))))))))
(check-sat)
; query 76: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x5361 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2215 ((_ zero_extend 31) ?x5361)))
(let (($x110 (or false false)))
(let (($x161 (or $x110 false false)))
(let (($x33 (or $x161 false)))
(let (($x671 (not $x33)))
(and $x671 (or $x33 (and (distinct ?x2215 ?x2215) true))))))))))
(check-sat)
; query 77: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x110 (or false false)))
(let (($x1675 (not $x110)))
(and $x1675 (or $x110 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 78: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x5838 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x110 (or false false)))
(let (($x161 (or $x110 false false)))
(let (($x78 (not $x161)))
(and $x78 (or $x161 (and (distinct ?x5838 ?x5838) true))))))))
(check-sat)
; query 79: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x5838 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1274 ((_ zero_extend 31) ?x5838)))
(let (($x110 (or false false)))
(let (($x161 (or $x110 false false)))
(let (($x33 (or $x161 false)))
(let (($x671 (not $x33)))
(and $x671 (or $x33 (and (distinct ?x1274 ?x1274) true))))))))))
(check-sat)
; query 80: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x5838 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1274 ((_ zero_extend 31) ?x5838)))
(let ((?x5361 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2215 ((_ zero_extend 31) ?x5361)))
(let ((?x350 (bvand ?x2215 ?x1274)))
(let (($x110 (or false false)))
(let (($x161 (or $x110 false false)))
(let (($x33 (or $x161 false)))
(let (($x1739 (or $x33 $x33 false)))
(and (not $x1739) (or $x1739 (and (distinct ?x350 ?x350) true)))))))))))))
(check-sat)
; query 81: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x5838 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1274 ((_ zero_extend 31) ?x5838)))
(let ((?x5361 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2215 ((_ zero_extend 31) ?x5361)))
(let ((?x350 (bvand ?x2215 ?x1274)))
(let ((?x7276 (ite (and (distinct (_ bv0 32) ?x350) true) (_ bv1 1) (_ bv0 1))))
(let (($x110 (or false false)))
(let (($x161 (or $x110 false false)))
(let (($x33 (or $x161 false)))
(let (($x1739 (or $x33 $x33 false)))
(let (($x3709 (or $x1739 false false)))
(and (not $x3709) (or $x3709 (and (distinct ?x7276 ?x7276) true)))))))))))))))
(check-sat)
; query 82: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x2298 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x67 (or false false false)))
(let (($x1892 (not $x67)))
(and $x1892 (or $x67 (and (distinct ?x2298 ?x2298) true)))))))
(check-sat)
; query 83: function matrix_add_const, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x111 (bvadd in.0_32 (_ bv1 32))))
(let (($x156 (and (distinct ?x111 ?x111) true)))
(let (($x67 (or false false false)))
(let (($x1892 (not $x67)))
(and $x1892 (or $x67 $x156)))))))
(check-sat)
; query 84: function matrix_add_const, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x228 (bvadd in.01_32 (_ bv1 32))))
(let (($x347 (and (distinct ?x228 ?x228) true)))
(let (($x67 (or false false false)))
(let (($x1892 (not $x67)))
(and $x1892 (or $x67 $x347)))))))
(check-sat)
; query 85: function matrix_mul_const, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x111 (bvadd in.0_32 (_ bv1 32))))
(let (($x156 (and (distinct ?x111 ?x111) true)))
(let (($x67 (or false false false)))
(let (($x1892 (not $x67)))
(and $x1892 (or $x67 $x156)))))))
(check-sat)
; query 86: function matrix_mul_const, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x228 (bvadd in.01_32 (_ bv1 32))))
(let (($x347 (and (distinct ?x228 ?x228) true)))
(let (($x67 (or false false false)))
(let (($x1892 (not $x67)))
(and $x1892 (or $x67 $x347)))))))
(check-sat)
; query 87: function matrix_mul_matrix, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x111 (bvadd in.0_32 (_ bv1 32))))
(let (($x156 (and (distinct ?x111 ?x111) true)))
(let (($x67 (or false false false)))
(let (($x1892 (not $x67)))
(and $x1892 (or $x67 $x156)))))))
(check-sat)
; query 88: function matrix_mul_matrix, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x228 (bvadd in.01_32 (_ bv1 32))))
(let (($x347 (and (distinct ?x228 ?x228) true)))
(let (($x67 (or false false false)))
(let (($x1892 (not $x67)))
(and $x1892 (or $x67 $x347)))))))
(check-sat)
; query 89: function matrix_mul_matrix, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x67 (or false false false)))
(let (($x1892 (not $x67)))
(and $x1892 (or $x67 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 90: function matrix_mul_matrix_bitextract, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x111 (bvadd in.0_32 (_ bv1 32))))
(let (($x156 (and (distinct ?x111 ?x111) true)))
(let (($x67 (or false false false)))
(let (($x1892 (not $x67)))
(and $x1892 (or $x67 $x156)))))))
(check-sat)
; query 91: function matrix_mul_matrix_bitextract, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x228 (bvadd in.01_32 (_ bv1 32))))
(let (($x347 (and (distinct ?x228 ?x228) true)))
(let (($x67 (or false false false)))
(let (($x1892 (not $x67)))
(and $x1892 (or $x67 $x347)))))))
(check-sat)
; query 92: function matrix_mul_matrix_bitextract, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x67 (or false false false)))
(let (($x1892 (not $x67)))
(and $x1892 (or $x67 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 93: function matrix_mul_vect, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x111 (bvadd in.0_32 (_ bv1 32))))
(let (($x156 (and (distinct ?x111 ?x111) true)))
(let (($x67 (or false false false)))
(let (($x1892 (not $x67)))
(and $x1892 (or $x67 $x156)))))))
(check-sat)
; query 94: function matrix_mul_vect, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x228 (bvadd in.01_32 (_ bv1 32))))
(let (($x347 (and (distinct ?x228 ?x228) true)))
(let (($x67 (or false false false)))
(let (($x1892 (not $x67)))
(and $x1892 (or $x67 $x347)))))))
(check-sat)
; query 95: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x110 (or false false)))
(let (($x1675 (not $x110)))
(and $x1675 (or $x110 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 96: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x7123 ((_ sign_extend 16) in.1_16)))
(let ((?x5313 (bvadd ?x7123 (_ bv10 32))))
(let (($x860 (and (distinct (bvadd ((_ sign_extend 1) ?x7123) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x5313)) true)))
(let (($x110 (or false false)))
(let (($x2425 (or $x110 false (or $x860))))
(and (not $x2425) (or $x2425 (and (distinct ?x5313 ?x5313) true)))))))))
(check-sat)
; query 97: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x7123 ((_ sign_extend 16) in.1_16)))
(let ((?x5313 (bvadd ?x7123 (_ bv10 32))))
(let ((?x1191 ((_ extract 15 0) ?x5313)))
(let (($x860 (and (distinct (bvadd ((_ sign_extend 1) ?x7123) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x5313)) true)))
(let (($x110 (or false false)))
(let (($x2425 (or $x110 false (or $x860))))
(let (($x5670 (or $x2425 false)))
(and (not $x5670) (or $x5670 (and (distinct ?x1191 ?x1191) true)))))))))))
(check-sat)
; query 98: function matrix_sum, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x4355 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x67 (or false false false)))
(let (($x1892 (not $x67)))
(and $x1892 (or $x67 (and (distinct ?x4355 ?x4355) true)))))))
(check-sat)
; query 99: function matrix_sum, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x4355 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let ((?x4685 ((_ zero_extend 63) ?x4355)))
(let (($x67 (or false false false)))
(let (($x5675 (or $x67 false)))
(and (not $x5675) (or $x5675 (and (distinct ?x4685 ?x4685) true))))))))
(check-sat)
; query 100: function matrix_sum, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x4355 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x2867 (= (_ bv1 1) ?x4355)))
(let ((?x2978 (ite $x2867 (_ bv1 32) (_ bv0 32))))
(let (($x67 (or false false false)))
(let (($x3460 (or $x67 (ite $x2867 false false))))
(and (not $x3460) (or $x3460 (and (distinct ?x2978 ?x2978) true)))))))))
(check-sat)
; query 101: function matrix_sum, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x110 (or false false)))
(let (($x1675 (not $x110)))
(and $x1675 (or $x110 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 102: function matrix_sum, block 22, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x4355 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x2867 (= (_ bv1 1) ?x4355)))
(let ((?x2978 (ite $x2867 (_ bv1 32) (_ bv0 32))))
(let ((?x7123 ((_ sign_extend 16) in.1_16)))
(let ((?x802 (bvadd ?x7123 ?x2978)))
(let (($x2642 (and (distinct (bvadd ((_ sign_extend 1) ?x7123) ((_ sign_extend 1) ?x2978)) ((_ sign_extend 1) ?x802)) true)))
(let (($x67 (or false false false)))
(let (($x3460 (or $x67 (ite $x2867 false false))))
(let (($x110 (or false false)))
(let (($x4437 (or $x110 $x3460 (or $x2642))))
(and (not $x4437) (or $x4437 (and (distinct ?x802 ?x802) true))))))))))))))
(check-sat)
; query 103: function matrix_sum, block 22, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x4355 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x2867 (= (_ bv1 1) ?x4355)))
(let ((?x2978 (ite $x2867 (_ bv1 32) (_ bv0 32))))
(let ((?x7123 ((_ sign_extend 16) in.1_16)))
(let ((?x802 (bvadd ?x7123 ?x2978)))
(let ((?x5133 ((_ extract 15 0) ?x802)))
(let (($x2642 (and (distinct (bvadd ((_ sign_extend 1) ?x7123) ((_ sign_extend 1) ?x2978)) ((_ sign_extend 1) ?x802)) true)))
(let (($x67 (or false false false)))
(let (($x3460 (or $x67 (ite $x2867 false false))))
(let (($x110 (or false false)))
(let (($x4437 (or $x110 $x3460 (or $x2642))))
(let (($x4840 (or $x4437 false)))
(and (not $x4840) (or $x4840 (and (distinct ?x5133 ?x5133) true))))))))))))))))
(check-sat)
; query 104: function matrix_sum, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x111 (bvadd in.0_32 (_ bv1 32))))
(let (($x156 (and (distinct ?x111 ?x111) true)))
(let (($x67 (or false false false)))
(let (($x1892 (not $x67)))
(and $x1892 (or $x67 $x156)))))))
(check-sat)
; query 105: function matrix_sum, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x228 (bvadd in.01_32 (_ bv1 32))))
(let (($x347 (and (distinct ?x228 ?x228) true)))
(let (($x67 (or false false false)))
(let (($x1892 (not $x67)))
(and $x1892 (or $x67 $x347)))))))
(check-sat)
; query 106: function parseval, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.23_32 () (_ BitVec 32))
(assert
 (let (($x6944 (and (distinct (bvmul ((_ sign_extend 32) in.23_32) ((_ sign_extend 32) (_ bv1024 32))) ((_ sign_extend 32) (bvmul in.23_32 (_ bv1024 32)))) true)))
(let (($x4209 (or false false (or $x6944))))
(and (not $x4209) (or $x4209 (and (distinct (bvmul in.23_32 (_ bv1024 32)) (bvmul in.23_32 (_ bv1024 32))) true))))))
(check-sat)
; query 107: function parseval, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.34_32 () (_ BitVec 32))
(assert
 (let (($x7070 (and (distinct (bvmul ((_ sign_extend 32) in.34_32) ((_ sign_extend 32) (_ bv1048576 32))) ((_ sign_extend 32) (bvmul in.34_32 (_ bv1048576 32)))) true)))
(let (($x4009 (or false false (or $x7070))))
(and (not $x4009) (or $x4009 (and (distinct (bvmul in.34_32 (_ bv1048576 32)) (bvmul in.34_32 (_ bv1048576 32))) true))))))
(check-sat)
; query 108: function partition_memory, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x111 (bvadd in.0_32 (_ bv1 32))))
(let (($x156 (and (distinct ?x111 ?x111) true)))
(let (($x48 (and (distinct (bvadd ((_ zero_extend 1) in.0_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) ?x111)) true)))
(let (($x170 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x111)) true)))
(let (($x67 (or false false false)))
(let (($x1892 (not $x67)))
(and $x1892 (or (or false false (or $x170 $x48)) $x156)))))))))
(check-sat)
