; OptiPhase-Sigma refinement certificate for sweep K35-R4-335
; query 0: function edge_draw, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let ((?x326 (ite (= (_ bv0 32) in4_32) (_ bv1 1) (_ bv0 1))))
(let (($x120 (or false false false)))
(and (not $x120) (or $x120 (and (distinct ?x326 ?x326) true))))))
(check-sat)
