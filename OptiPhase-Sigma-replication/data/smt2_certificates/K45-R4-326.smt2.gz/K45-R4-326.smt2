; OptiPhase-Sigma refinement certificate for sweep K45-R4-326
; query 0: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x73 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x120 (or false false false)))
(let (($x127 (not $x120)))
(and $x127 (or $x120 (and (distinct ?x73 ?x73) true)))))))
(check-sat)
; query 1: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x62 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x120 (or false false false)))
(let (($x127 (not $x120)))
(and $x127 (or $x120 (and (distinct ?x62 ?x62) true)))))))
(check-sat)
