; OptiPhase-Sigma refinement certificate for sweep K41-R3-140
; query 0: function set_key, block 11, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let (($x191 (or false false false)))
(let (($x379 (not $x191)))
(and $x379 (or $x191 (and (distinct (bvand in2_32 (_ bv1 32)) (bvand in2_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function set_key, block 11, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x46 (ite (and (distinct (_ bv0 32) (bvand in2_32 (_ bv1 32))) true) (_ bv1 1) (_ bv0 1))))
(let (($x191 (or false false false)))
(let (($x462 (or $x191 false false)))
(let (($x77 (not $x462)))
(and $x77 (or $x462 (and (distinct ?x46 ?x46) true))))))))
(check-sat)
; query 2: function set_key, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let (($x191 (or false false false)))
(let (($x379 (not $x191)))
(and $x379 (or $x191 (and (distinct (bvand in2_32 (_ bv2 32)) (bvand in2_32 (_ bv2 32))) true))))))
(check-sat)
; query 3: function set_key, block 14, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x316 (ite (and (distinct (_ bv0 32) (bvand in2_32 (_ bv2 32))) true) (_ bv1 1) (_ bv0 1))))
(let (($x191 (or false false false)))
(let (($x462 (or $x191 false false)))
(let (($x77 (not $x462)))
(and $x77 (or $x462 (and (distinct ?x316 ?x316) true))))))))
(check-sat)
; query 4: function set_key, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x391 (ite (and (distinct (_ bv0 64) in1_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x191 (or false false false)))
(let (($x379 (not $x191)))
(and $x379 (or $x191 (and (distinct ?x391 ?x391) true)))))))
(check-sat)
; query 5: function set_key, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x821 (ite (bvult in1_64 (_ bv16 64)) (_ bv1 1) (_ bv0 1))))
(let (($x191 (or false false false)))
(let (($x379 (not $x191)))
(and $x379 (or $x191 (and (distinct ?x821 ?x821) true)))))))
(check-sat)
; query 6: function set_key, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x116 (ite (bvugt in1_64 (_ bv32 64)) (_ bv1 1) (_ bv0 1))))
(let (($x191 (or false false false)))
(let (($x379 (not $x191)))
(and $x379 (or $x191 (and (distinct ?x116 ?x116) true)))))))
(check-sat)
; query 7: function set_key, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let (($x191 (or false false false)))
(let (($x379 (not $x191)))
(and $x379 (or $x191 (and (distinct (bvand in1_64 (_ bv7 64)) (bvand in1_64 (_ bv7 64))) true))))))
(check-sat)
; query 8: function set_key, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x51 (ite (and (distinct (_ bv0 64) (bvand in1_64 (_ bv7 64))) true) (_ bv1 1) (_ bv0 1))))
(let (($x191 (or false false false)))
(let (($x462 (or $x191 false false)))
(let (($x77 (not $x462)))
(and $x77 (or $x462 (and (distinct ?x51 ?x51) true))))))))
(check-sat)
