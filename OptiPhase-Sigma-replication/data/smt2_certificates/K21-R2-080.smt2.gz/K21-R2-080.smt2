; OptiPhase-Sigma refinement certificate for sweep K21-R2-080
; query 0: function init_array, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x323 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x135 (or false false (or $x323))))
(and (not $x135) (or $x135 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function init_array, block 25, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x49 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x27 (or false false (or $x49))))
(and (not $x27) (or $x27 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function kernel_deriche, block 102, name %103
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.112_32 () (_ BitVec 32))
(assert
 (let (($x38 (and (distinct (bvadd ((_ sign_extend 1) in.112_32) ((_ sign_extend 1) (_ bv4294967295 32))) ((_ sign_extend 1) (bvadd in.112_32 (_ bv4294967295 32)))) true)))
(let (($x95 (or false false (or $x38))))
(and (not $x95) (or $x95 (and (distinct (bvadd in.112_32 (_ bv4294967295 32)) (bvadd in.112_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 3: function kernel_deriche, block 105, name %106
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.110_32 () (_ BitVec 32))
(assert
 (let (($x6 (and (distinct (bvadd ((_ sign_extend 1) in.110_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.110_32 (_ bv1 32)))) true)))
(let (($x74 (or false false (or $x6))))
(and (not $x74) (or $x74 (and (distinct (bvadd in.110_32 (_ bv1 32)) (bvadd in.110_32 (_ bv1 32))) true))))))
(check-sat)
; query 4: function kernel_deriche, block 130, name %131
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.213_32 () (_ BitVec 32))
(assert
 (let (($x29 (and (distinct (bvadd ((_ sign_extend 1) in.213_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.213_32 (_ bv1 32)))) true)))
(let (($x12 (or false false (or $x29))))
(and (not $x12) (or $x12 (and (distinct (bvadd in.213_32 (_ bv1 32)) (bvadd in.213_32 (_ bv1 32))) true))))))
(check-sat)
; query 5: function kernel_deriche, block 133, name %134
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let (($x111 (and (distinct (bvadd ((_ sign_extend 1) in.2_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.2_32 (_ bv1 32)))) true)))
(let (($x93 (or false false (or $x111))))
(and (not $x93) (or $x93 (and (distinct (bvadd in.2_32 (_ bv1 32)) (bvadd in.2_32 (_ bv1 32))) true))))))
(check-sat)
; query 6: function kernel_deriche, block 165, name %166
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.3_32 () (_ BitVec 32))
(assert
 (let (($x66 (and (distinct (bvadd ((_ sign_extend 1) in.3_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.3_32 (_ bv1 32)))) true)))
(let (($x85 (or false false (or $x66))))
(and (not $x85) (or $x85 (and (distinct (bvadd in.3_32 (_ bv1 32)) (bvadd in.3_32 (_ bv1 32))) true))))))
(check-sat)
; query 7: function kernel_deriche, block 168, name %169
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.314_32 () (_ BitVec 32))
(assert
 (let (($x8 (and (distinct (bvadd ((_ sign_extend 1) in.314_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.314_32 (_ bv1 32)))) true)))
(let (($x55 (or false false (or $x8))))
(and (not $x55) (or $x55 (and (distinct (bvadd in.314_32 (_ bv1 32)) (bvadd in.314_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function kernel_deriche, block 173, name %174
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x114 (and (distinct (bvsub ((_ sign_extend 1) in0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvsub in0_32 (_ bv1 32)))) true)))
(let (($x80 (or false false (or $x114))))
(and (not $x80) (or $x80 (and (distinct (bvsub in0_32 (_ bv1 32)) (bvsub in0_32 (_ bv1 32))) true))))))
(check-sat)
; query 9: function kernel_deriche, block 196, name %197
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.4_32 () (_ BitVec 32))
(assert
 (let (($x498 (and (distinct (bvadd ((_ sign_extend 1) in.4_32) ((_ sign_extend 1) (_ bv4294967295 32))) ((_ sign_extend 1) (bvadd in.4_32 (_ bv4294967295 32)))) true)))
(let (($x58 (or false false (or $x498))))
(and (not $x58) (or $x58 (and (distinct (bvadd in.4_32 (_ bv4294967295 32)) (bvadd in.4_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 10: function kernel_deriche, block 199, name %200
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.415_32 () (_ BitVec 32))
(assert
 (let (($x59 (and (distinct (bvadd ((_ sign_extend 1) in.415_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.415_32 (_ bv1 32)))) true)))
(let (($x46 (or false false (or $x59))))
(and (not $x46) (or $x46 (and (distinct (bvadd in.415_32 (_ bv1 32)) (bvadd in.415_32 (_ bv1 32))) true))))))
(check-sat)
; query 11: function kernel_deriche, block 224, name %225
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.516_32 () (_ BitVec 32))
(assert
 (let (($x91 (and (distinct (bvadd ((_ sign_extend 1) in.516_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.516_32 (_ bv1 32)))) true)))
(let (($x157 (or false false (or $x91))))
(and (not $x157) (or $x157 (and (distinct (bvadd in.516_32 (_ bv1 32)) (bvadd in.516_32 (_ bv1 32))) true))))))
(check-sat)
; query 12: function kernel_deriche, block 227, name %228
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.5_32 () (_ BitVec 32))
(assert
 (let (($x140 (and (distinct (bvadd ((_ sign_extend 1) in.5_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.5_32 (_ bv1 32)))) true)))
(let (($x280 (or false false (or $x140))))
(and (not $x280) (or $x280 (and (distinct (bvadd in.5_32 (_ bv1 32)) (bvadd in.5_32 (_ bv1 32))) true))))))
(check-sat)
; query 13: function kernel_deriche, block 71, name %72
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.011_32 () (_ BitVec 32))
(assert
 (let (($x160 (and (distinct (bvadd ((_ sign_extend 1) in.011_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.011_32 (_ bv1 32)))) true)))
(let (($x162 (or false false (or $x160))))
(and (not $x162) (or $x162 (and (distinct (bvadd in.011_32 (_ bv1 32)) (bvadd in.011_32 (_ bv1 32))) true))))))
(check-sat)
; query 14: function kernel_deriche, block 74, name %75
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.09_32 () (_ BitVec 32))
(assert
 (let (($x172 (and (distinct (bvadd ((_ sign_extend 1) in.09_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.09_32 (_ bv1 32)))) true)))
(let (($x174 (or false false (or $x172))))
(and (not $x174) (or $x174 (and (distinct (bvadd in.09_32 (_ bv1 32)) (bvadd in.09_32 (_ bv1 32))) true))))))
(check-sat)
; query 15: function kernel_deriche, block 79, name %80
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x303 (and (distinct (bvsub ((_ sign_extend 1) in1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvsub in1_32 (_ bv1 32)))) true)))
(let (($x652 (or false false (or $x303))))
(and (not $x652) (or $x652 (and (distinct (bvsub in1_32 (_ bv1 32)) (bvsub in1_32 (_ bv1 32))) true))))))
(check-sat)
; query 16: function polybench_flush_cache, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x49 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x27 (or false false (or $x49))))
(and (not $x27) (or $x27 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 17: function print_array, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x323 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x135 (or false false (or $x323))))
(and (not $x135) (or $x135 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 18: function print_array, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x49 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x27 (or false false (or $x49))))
(and (not $x27) (or $x27 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 19: function xmalloc, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in7_32 () (_ BitVec 32))
(assert
 (let ((?x362 (ite (and (distinct (_ bv0 32) in7_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x322 (or false false false)))
(and (not $x322) (or $x322 (and (distinct ?x362 ?x362) true))))))
(check-sat)
