; OptiPhase-Sigma refinement certificate for sweep K03-R6-019
