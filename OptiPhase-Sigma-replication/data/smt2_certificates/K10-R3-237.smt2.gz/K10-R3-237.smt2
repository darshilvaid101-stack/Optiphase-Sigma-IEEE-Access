; OptiPhase-Sigma refinement certificate for sweep K10-R3-237
; query 0: function xmalloc, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in7_32 () (_ BitVec 32))
(assert
 (let ((?x323 (ite (and (distinct (_ bv0 32) in7_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x343 (or false false false)))
(and (not $x343) (or $x343 (and (distinct ?x323 ?x323) true))))))
(check-sat)
