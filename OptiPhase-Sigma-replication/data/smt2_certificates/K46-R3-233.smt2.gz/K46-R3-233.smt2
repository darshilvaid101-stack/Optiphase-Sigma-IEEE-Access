; OptiPhase-Sigma refinement certificate for sweep K46-R3-233
; query 0: function adpcm_decoder, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x40 (ite (and (distinct (_ bv0 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x19 (or false false false)))
(let (($x25 (not $x19)))
(and $x25 (or $x19 (and (distinct ?x40 ?x40) true)))))))
(check-sat)
; query 1: function adpcm_decoder, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x19 (or false false false)))
(let (($x25 (not $x19)))
(and $x25 (or $x19 (and (distinct (bvand in.01_32 (_ bv15 32)) (bvand in.01_32 (_ bv15 32))) true))))))
(check-sat)
; query 2: function main, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x38 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x19 (or false false false)))
(let (($x25 (not $x19)))
(and $x25 (or $x19 (and (distinct ?x38 ?x38) true)))))))
(check-sat)
