; OptiPhase-Sigma refinement certificate for sweep K38-R3-208
; query 0: function BF_cfb64_encrypt, block 111, name %112
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.18_32 () (_ BitVec 32))
(assert
 (let ((?x576 (ite (= (_ bv0 32) in.18_32) (_ bv1 1) (_ bv0 1))))
(let (($x163 (or false false false)))
(let (($x110 (not $x163)))
(and $x110 (or $x163 (and (distinct ?x576 ?x576) true)))))))
(check-sat)
; query 1: function BF_cfb64_encrypt, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.07_32 () (_ BitVec 32))
(assert
 (let ((?x16 (ite (= (_ bv0 32) in.07_32) (_ bv1 1) (_ bv0 1))))
(let (($x163 (or false false false)))
(let (($x110 (not $x163)))
(and $x110 (or $x163 (and (distinct ?x16 ?x16) true)))))))
(check-sat)
; query 2: function main, block 60, name %61
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x265 (or false false)))
(and (not $x265) (or $x265 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 3: function main, block 60, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x467 (ite (bvsge (_ bv57 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x265 (or false false)))
(let (($x75 (or $x265 false false)))
(let (($x139 (not $x75)))
(and $x139 (or $x75 (and (distinct ?x467 ?x467) true))))))))
(check-sat)
; query 4: function main, block 63, name %64
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x163 (or false false false)))
(let (($x234 (or $x163 (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x234) (or $x234 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvshl in.01_32 (_ bv4 32))) true))))))
(check-sat)
; query 5: function main, block 63, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x265 (or false false)))
(and (not $x265) (or $x265 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 6: function main, block 63, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x138 ((_ sign_extend 24) in57_8)))
(let ((?x83 (bvshl in.01_32 (_ bv4 32))))
(let ((?x177 (bvadd ?x83 ?x138)))
(let ((?x168 ((_ sign_extend 1) ?x177)))
(let (($x265 (or false false)))
(let (($x163 (or false false false)))
(let (($x234 (or $x163 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x189 (or $x234 $x265 (or (and (distinct (bvadd ((_ sign_extend 1) ?x83) ((_ sign_extend 1) ?x138)) ?x168) true)))))
(and (not $x189) (or $x189 (and (distinct ?x177 ?x177) true))))))))))))
(check-sat)
; query 7: function main, block 63, name %67
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x138 ((_ sign_extend 24) in57_8)))
(let ((?x83 (bvshl in.01_32 (_ bv4 32))))
(let ((?x177 (bvadd ?x83 ?x138)))
(let ((?x113 (bvsub ?x177 (_ bv48 32))))
(let (($x102 (and (distinct (bvsub ((_ sign_extend 1) ?x177) ((_ sign_extend 1) (_ bv48 32))) ((_ sign_extend 1) ?x113)) true)))
(let ((?x168 ((_ sign_extend 1) ?x177)))
(let (($x265 (or false false)))
(let (($x163 (or false false false)))
(let (($x234 (or $x163 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x189 (or $x234 $x265 (or (and (distinct (bvadd ((_ sign_extend 1) ?x83) ((_ sign_extend 1) ?x138)) ?x168) true)))))
(let (($x114 (or $x189 false (or $x102))))
(and (not $x114) (or $x114 (and (distinct ?x113 ?x113) true)))))))))))))))
(check-sat)
; query 8: function main, block 68, name %69
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x265 (or false false)))
(and (not $x265) (or $x265 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 9: function main, block 68, name %70
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x148 (ite (bvsle (_ bv65 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x265 (or false false)))
(let (($x75 (or $x265 false false)))
(let (($x139 (not $x75)))
(and $x139 (or $x75 (and (distinct ?x148 ?x148) true))))))))
(check-sat)
; query 10: function main, block 71, name %72
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x265 (or false false)))
(and (not $x265) (or $x265 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 11: function main, block 71, name %73
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x50 (ite (bvsge (_ bv70 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x265 (or false false)))
(let (($x75 (or $x265 false false)))
(let (($x139 (not $x75)))
(and $x139 (or $x75 (and (distinct ?x50 ?x50) true))))))))
(check-sat)
; query 12: function main, block 74, name %75
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x163 (or false false false)))
(let (($x234 (or $x163 (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x234) (or $x234 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvshl in.01_32 (_ bv4 32))) true))))))
(check-sat)
; query 13: function main, block 74, name %76
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x265 (or false false)))
(and (not $x265) (or $x265 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 14: function main, block 74, name %77
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x138 ((_ sign_extend 24) in57_8)))
(let ((?x83 (bvshl in.01_32 (_ bv4 32))))
(let ((?x177 (bvadd ?x83 ?x138)))
(let ((?x168 ((_ sign_extend 1) ?x177)))
(let (($x265 (or false false)))
(let (($x163 (or false false false)))
(let (($x234 (or $x163 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x189 (or $x234 $x265 (or (and (distinct (bvadd ((_ sign_extend 1) ?x83) ((_ sign_extend 1) ?x138)) ?x168) true)))))
(and (not $x189) (or $x189 (and (distinct ?x177 ?x177) true))))))))))))
(check-sat)
; query 15: function main, block 74, name %78
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x138 ((_ sign_extend 24) in57_8)))
(let ((?x83 (bvshl in.01_32 (_ bv4 32))))
(let ((?x177 (bvadd ?x83 ?x138)))
(let ((?x575 (bvsub ?x177 (_ bv65 32))))
(let ((?x31 ((_ sign_extend 1) ?x575)))
(let ((?x168 ((_ sign_extend 1) ?x177)))
(let (($x265 (or false false)))
(let (($x163 (or false false false)))
(let (($x234 (or $x163 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x189 (or $x234 $x265 (or (and (distinct (bvadd ((_ sign_extend 1) ?x83) ((_ sign_extend 1) ?x138)) ?x168) true)))))
(let (($x111 (or $x189 false (or (and (distinct (bvsub ?x168 ((_ sign_extend 1) (_ bv65 32))) ?x31) true)))))
(and (not $x111) (or $x111 (and (distinct ?x575 ?x575) true)))))))))))))))
(check-sat)
; query 16: function main, block 74, name %79
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x138 ((_ sign_extend 24) in57_8)))
(let ((?x83 (bvshl in.01_32 (_ bv4 32))))
(let ((?x177 (bvadd ?x83 ?x138)))
(let ((?x575 (bvsub ?x177 (_ bv65 32))))
(let ((?x123 (bvadd ?x575 (_ bv10 32))))
(let (($x156 (and (distinct (bvadd ((_ sign_extend 1) ?x575) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x123)) true)))
(let ((?x31 ((_ sign_extend 1) ?x575)))
(let ((?x168 ((_ sign_extend 1) ?x177)))
(let (($x265 (or false false)))
(let (($x163 (or false false false)))
(let (($x234 (or $x163 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x189 (or $x234 $x265 (or (and (distinct (bvadd ((_ sign_extend 1) ?x83) ((_ sign_extend 1) ?x138)) ?x168) true)))))
(let (($x111 (or $x189 false (or (and (distinct (bvsub ?x168 ((_ sign_extend 1) (_ bv65 32))) ?x31) true)))))
(let (($x112 (or $x111 false (or $x156))))
(and (not $x112) (or $x112 (and (distinct ?x123 ?x123) true))))))))))))))))))
(check-sat)
