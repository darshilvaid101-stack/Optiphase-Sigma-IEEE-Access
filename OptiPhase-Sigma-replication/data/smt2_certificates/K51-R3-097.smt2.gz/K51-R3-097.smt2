; OptiPhase-Sigma refinement certificate for sweep K51-R3-097
