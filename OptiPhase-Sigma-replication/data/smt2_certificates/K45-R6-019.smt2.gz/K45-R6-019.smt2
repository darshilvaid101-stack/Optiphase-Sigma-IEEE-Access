; OptiPhase-Sigma refinement certificate for sweep K45-R6-019
; query 0: function Index_to_frequency, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x229 (ite (bvuge in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x68 (or false false false)))
(let (($x163 (not $x68)))
(and $x163 (or $x68 (and (distinct ?x229 ?x229) true)))))))
(check-sat)
; query 1: function IsPowerOfTwo, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x68 (or false false false)))
(let (($x163 (not $x68)))
(and $x163 (or $x68 (and (distinct (bvsub in0_32 (_ bv1 32)) (bvsub in0_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function IsPowerOfTwo, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x135 (bvsub in0_32 (_ bv1 32))))
(let ((?x22 (bvand in0_32 ?x135)))
(let (($x68 (or false false false)))
(let (($x281 (or false $x68 false)))
(and (not $x281) (or $x281 (and (distinct ?x22 ?x22) true))))))))
(check-sat)
; query 3: function IsPowerOfTwo, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x471 (ite (and (distinct (_ bv0 32) (bvand in0_32 (bvsub in0_32 (_ bv1 32)))) true) (_ bv1 1) (_ bv0 1))))
(let (($x68 (or false false false)))
(let (($x281 (or false $x68 false)))
(let (($x583 (or $x281 false false)))
(and (not $x583) (or $x583 (and (distinct ?x471 ?x471) true))))))))
(check-sat)
; query 4: function IsPowerOfTwo, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x99 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x68 (or false false false)))
(let (($x163 (not $x68)))
(and $x163 (or $x68 (and (distinct ?x99 ?x99) true)))))))
(check-sat)
; query 5: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x99 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x68 (or false false false)))
(let (($x163 (not $x68)))
(and $x163 (or $x68 (and (distinct ?x99 ?x99) true)))))))
(check-sat)
; query 6: function fft_float, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x836 (ite (and (distinct (_ bv0 32) in1_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x68 (or false false false)))
(let (($x163 (not $x68)))
(and $x163 (or $x68 (and (distinct ?x836 ?x836) true)))))))
(check-sat)
; query 7: function main, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x12 (ite (= (_ bv4 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x68 (or false false false)))
(let (($x163 (not $x68)))
(and $x163 (or $x68 (and (distinct ?x12 ?x12) true)))))))
(check-sat)
; query 8: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x612 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x68 (or false false false)))
(let (($x163 (not $x68)))
(and $x163 (or $x68 (and (distinct ?x612 ?x612) true)))))))
(check-sat)
