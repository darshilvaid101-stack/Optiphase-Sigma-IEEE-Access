; OptiPhase-Sigma refinement certificate for sweep K47-R3-288
; query 0: function adpcm_decoder, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x99 (ite (and (distinct (_ bv0 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x837 (or false false false)))
(let (($x100 (not $x837)))
(and $x100 (or $x837 (and (distinct ?x99 ?x99) true)))))))
(check-sat)
; query 1: function adpcm_decoder, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x837 (or false false false)))
(let (($x100 (not $x837)))
(and $x100 (or $x837 (and (distinct (bvand in.01_32 (_ bv15 32)) (bvand in.01_32 (_ bv15 32))) true))))))
(check-sat)
; query 2: function adpcm_decoder, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.012_32 () (_ BitVec 32))
(declare-fun in42_32 () (_ BitVec 32))
(assert
 (let (($x366 (and (distinct (bvadd ((_ sign_extend 1) in42_32) ((_ sign_extend 1) in.012_32)) ((_ sign_extend 1) (bvadd in42_32 in.012_32))) true)))
(let (($x777 (or false false (or $x366))))
(let (($x76 (or $x777 (and (distinct (bvadd in42_32 in.012_32) (bvadd in42_32 in.012_32)) true))))
(and (not $x777) $x76)))))
(check-sat)
; query 3: function adpcm_decoder, block 50, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.012_32 () (_ BitVec 32))
(assert
 (let (($x837 (or false false false)))
(let (($x239 (or $x837 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x98 (or $x239 (and (distinct (bvashr in.012_32 (_ bv1 32)) (bvashr in.012_32 (_ bv1 32))) true))))
(and (not $x239) $x98)))))
(check-sat)
; query 4: function adpcm_decoder, block 50, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.012_32 () (_ BitVec 32))
(declare-fun in.08_32 () (_ BitVec 32))
(assert
 (let ((?x893 (bvashr in.012_32 (_ bv1 32))))
(let ((?x813 (bvadd in.08_32 ?x893)))
(let (($x79 (and (distinct (bvadd ((_ sign_extend 1) in.08_32) ((_ sign_extend 1) ?x893)) ((_ sign_extend 1) ?x813)) true)))
(let (($x837 (or false false false)))
(let (($x239 (or $x837 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x156 (or false $x239 (or $x79))))
(and (not $x156) (or $x156 (and (distinct ?x813 ?x813) true))))))))))
(check-sat)
; query 5: function adpcm_decoder, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.012_32 () (_ BitVec 32))
(assert
 (let (($x837 (or false false false)))
(let (($x194 (or $x837 (bvuge (_ bv2 32) (_ bv32 32)))))
(let (($x707 (or $x194 (and (distinct (bvashr in.012_32 (_ bv2 32)) (bvashr in.012_32 (_ bv2 32))) true))))
(and (not $x194) $x707)))))
(check-sat)
; query 6: function adpcm_decoder, block 56, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.012_32 () (_ BitVec 32))
(declare-fun in.19_32 () (_ BitVec 32))
(assert
 (let ((?x32 (bvashr in.012_32 (_ bv2 32))))
(let ((?x18 (bvadd in.19_32 ?x32)))
(let (($x96 (and (distinct (bvadd ((_ sign_extend 1) in.19_32) ((_ sign_extend 1) ?x32)) ((_ sign_extend 1) ?x18)) true)))
(let (($x837 (or false false false)))
(let (($x194 (or $x837 (bvuge (_ bv2 32) (_ bv32 32)))))
(let (($x249 (or false $x194 (or $x96))))
(and (not $x249) (or $x249 (and (distinct ?x18 ?x18) true))))))))))
(check-sat)
; query 7: function adpcm_decoder, block 61, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.210_32 () (_ BitVec 32))
(declare-fun in.013_32 () (_ BitVec 32))
(assert
 (let ((?x115 (bvsub in.013_32 in.210_32)))
(let (($x131 (and (distinct (bvsub ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x115)) true)))
(let (($x256 (or false false (or $x131))))
(and (not $x256) (or $x256 (and (distinct ?x115 ?x115) true)))))))
(check-sat)
; query 8: function adpcm_decoder, block 63, name %64
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.013_32 () (_ BitVec 32))
(declare-fun in.210_32 () (_ BitVec 32))
(assert
 (let ((?x176 (bvadd in.210_32 in.013_32)))
(let ((?x610 (bvadd in.013_32 in.210_32)))
(let (($x217 (and (distinct (bvadd ((_ sign_extend 1) in.210_32) ((_ sign_extend 1) in.013_32)) ((_ sign_extend 1) ?x176)) true)))
(let (($x817 (and (distinct (bvadd ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x610)) true)))
(and (not (or false false (or $x817))) (or (or false false (or $x217)) (and (distinct ?x610 ?x176) true))))))))
(check-sat)
; query 9: function adpcm_decoder, block 68, name %69
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.114_32 () (_ BitVec 32))
(assert
 (let ((?x287 (ite (bvsgt (_ bv4294934528 32) in.114_32) (_ bv1 1) (_ bv0 1))))
(let (($x837 (or false false false)))
(let (($x100 (not $x837)))
(and $x100 (or $x837 (and (distinct ?x287 ?x287) true)))))))
(check-sat)
; query 10: function adpcm_decoder, block 78, name %79
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x314 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv4294967295 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv4294967295 32)))) true)))
(let (($x1134 (or false false (or $x314))))
(and (not $x1134) (or $x1134 (and (distinct (bvadd in.02_32 (_ bv4294967295 32)) (bvadd in.02_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 11: function main, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x470 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x837 (or false false false)))
(let (($x100 (not $x837)))
(and $x100 (or $x837 (and (distinct ?x470 ?x470) true)))))))
(check-sat)
