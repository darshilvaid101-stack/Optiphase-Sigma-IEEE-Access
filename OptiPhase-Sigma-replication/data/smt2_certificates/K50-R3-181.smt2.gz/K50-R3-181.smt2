; OptiPhase-Sigma refinement certificate for sweep K50-R3-181
; query 0: function check, block 115, name %116
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x83 (and (distinct (ite (= (_ bv0 32) in0_32) (_ bv1 1) (_ bv0 1)) (ite (= (_ bv13 32) in0_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x15 (or false false false)))
(let (($x681 (not $x15)))
(and $x681 (or $x15 $x83))))))
(check-sat)
; query 1: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x187 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x15 (or false false false)))
(let (($x681 (not $x15)))
(and $x681 (or $x15 (and (distinct ?x187 ?x187) true)))))))
(check-sat)
; query 2: function set1d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x73 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x15 (or false false false)))
(let (($x681 (not $x15)))
(and $x681 (or $x15 (and (distinct ?x73 ?x73) true)))))))
(check-sat)
; query 3: function set1ds, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x77 (ite (= (_ bv4294967295 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x15 (or false false false)))
(let (($x681 (not $x15)))
(and $x681 (or $x15 (and (distinct ?x77 ?x77) true)))))))
(check-sat)
; query 4: function set2d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x73 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x15 (or false false false)))
(let (($x681 (not $x15)))
(and $x681 (or $x15 (and (distinct ?x73 ?x73) true)))))))
(check-sat)
