; OptiPhase-Sigma refinement certificate for sweep K41-R2-042
; query 0: function decfile, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in17_32 () (_ BitVec 32))
(assert
 (let ((?x375 (ite (and (distinct (_ bv16 32) in17_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x36 (or false false false)))
(let (($x80 (not $x36)))
(and $x80 (or $x36 (and (distinct ?x375 ?x375) true)))))))
(check-sat)
; query 1: function decfile, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x156 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x111 (or false false (or $x156))))
(and (not $x111) (or $x111 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function decfile, block 82, name %83
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x827 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x12 (or false false (or $x827))))
(and (not $x12) (or $x12 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 3: function decfile, block 85, name %86
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x403 (ite (= (_ bv15 32) in.01.lcssa_32) (_ bv1 1) (_ bv0 1))))
(let (($x36 (or false false false)))
(let (($x80 (not $x36)))
(and $x80 (or $x36 (and (distinct ?x403 ?x403) true)))))))
(check-sat)
; query 4: function decfile, block 85, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x403 (ite (= (_ bv15 32) in.01.lcssa_32) (_ bv1 1) (_ bv0 1))))
(let ((?x146 ((_ zero_extend 63) ?x403)))
(let (($x36 (or false false false)))
(let (($x51 (or $x36 false)))
(and (not $x51) (or $x51 (and (distinct ?x146 ?x146) true))))))))
(check-sat)
; query 5: function decfile, block 85, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x403 (ite (= (_ bv15 32) in.01.lcssa_32) (_ bv1 1) (_ bv0 1))))
(let (($x10 (= (_ bv1 1) ?x403)))
(let ((?x475 (ite $x10 (_ bv1 32) (_ bv0 32))))
(let (($x36 (or false false false)))
(let (($x411 (or $x36 (ite $x10 false false))))
(and (not $x411) (or $x411 (and (distinct ?x475 ?x475) true)))))))))
(check-sat)
; query 6: function decfile, block 85, name %89
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x403 (ite (= (_ bv15 32) in.01.lcssa_32) (_ bv1 1) (_ bv0 1))))
(let (($x10 (= (_ bv1 1) ?x403)))
(let ((?x475 (ite $x10 (_ bv1 32) (_ bv0 32))))
(let ((?x110 (bvsub (_ bv1 32) ?x475)))
(let ((?x56 ((_ sign_extend 1) ?x110)))
(let (($x36 (or false false false)))
(let (($x411 (or $x36 (ite $x10 false false))))
(let (($x436 (or false $x411 (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv1 32)) ((_ sign_extend 1) ?x475)) ?x56) true)))))
(and (not $x436) (or $x436 (and (distinct ?x110 ?x110) true))))))))))))
(check-sat)
; query 7: function decfile, block 85, name %90
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01.lcssa_32 () (_ BitVec 32))
(declare-fun in46_32 () (_ BitVec 32))
(assert
 (let ((?x403 (ite (= (_ bv15 32) in.01.lcssa_32) (_ bv1 1) (_ bv0 1))))
(let (($x10 (= (_ bv1 1) ?x403)))
(let ((?x475 (ite $x10 (_ bv1 32) (_ bv0 32))))
(let ((?x110 (bvsub (_ bv1 32) ?x475)))
(let ((?x106 (bvadd in46_32 ?x110)))
(let (($x611 (and (distinct (bvadd ((_ sign_extend 1) in46_32) ((_ sign_extend 1) ?x110)) ((_ sign_extend 1) ?x106)) true)))
(let ((?x56 ((_ sign_extend 1) ?x110)))
(let (($x36 (or false false false)))
(let (($x411 (or $x36 (ite $x10 false false))))
(let (($x436 (or false $x411 (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv1 32)) ((_ sign_extend 1) ?x475)) ?x56) true)))))
(let (($x82 (or false $x436 (or $x611))))
(and (not $x82) (or $x82 (and (distinct ?x106 ?x106) true)))))))))))))))
(check-sat)
; query 8: function decfile, block 85, name %91
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01.lcssa_32 () (_ BitVec 32))
(declare-fun in46_32 () (_ BitVec 32))
(assert
 (let ((?x403 (ite (= (_ bv15 32) in.01.lcssa_32) (_ bv1 1) (_ bv0 1))))
(let (($x10 (= (_ bv1 1) ?x403)))
(let ((?x475 (ite $x10 (_ bv1 32) (_ bv0 32))))
(let ((?x110 (bvsub (_ bv1 32) ?x475)))
(let ((?x106 (bvadd in46_32 ?x110)))
(let ((?x790 (ite (and (distinct (_ bv0 32) ?x106) true) (_ bv1 1) (_ bv0 1))))
(let (($x611 (and (distinct (bvadd ((_ sign_extend 1) in46_32) ((_ sign_extend 1) ?x110)) ((_ sign_extend 1) ?x106)) true)))
(let ((?x56 ((_ sign_extend 1) ?x110)))
(let (($x36 (or false false false)))
(let (($x411 (or $x36 (ite $x10 false false))))
(let (($x436 (or false $x411 (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv1 32)) ((_ sign_extend 1) ?x475)) ?x56) true)))))
(let (($x82 (or false $x436 (or $x611))))
(let (($x291 (or $x82 false false)))
(and (not $x291) (or $x291 (and (distinct ?x790 ?x790) true)))))))))))))))))
(check-sat)
; query 9: function encfile, block 50, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_64 () (_ BitVec 64))
(assert
 (let (($x36 (or false false false)))
(let (($x80 (not $x36)))
(and $x80 (or $x36 (and (distinct (bvadd in.1_64 (_ bv1 64)) (bvadd in.1_64 (_ bv1 64))) true))))))
(check-sat)
; query 10: function encfile, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_64 () (_ BitVec 64))
(assert
 (let (($x36 (or false false false)))
(let (($x80 (not $x36)))
(and $x80 (or $x36 (and (distinct (bvadd in.2_64 (_ bv1 64)) (bvadd in.2_64 (_ bv1 64))) true))))))
(check-sat)
; query 11: function encfile, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.5_64 () (_ BitVec 64))
(assert
 (let (($x36 (or false false false)))
(let (($x80 (not $x36)))
(and $x80 (or $x36 (and (distinct (bvadd in.5_64 (_ bv1 64)) (bvadd in.5_64 (_ bv1 64))) true))))))
(check-sat)
; query 12: function fillrand, block 34, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x125 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x139 (or false false (or $x125))))
(and (not $x139) (or $x139 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 13: function main, block 41, name %42
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let (($x62 (or false false)))
(and (not $x62) (or $x62 (and (distinct ((_ sign_extend 24) in38_8) ((_ sign_extend 24) in38_8)) true)))))
(check-sat)
; query 14: function main, block 41, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let ((?x366 (ite (bvsge (_ bv57 32) ((_ sign_extend 24) in38_8)) (_ bv1 1) (_ bv0 1))))
(let (($x62 (or false false)))
(let (($x21 (or $x62 false false)))
(let (($x43 (not $x21)))
(and $x43 (or $x21 (and (distinct ?x366 ?x366) true))))))))
(check-sat)
; query 15: function main, block 44, name %45
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x36 (or false false false)))
(let (($x68 (or $x36 (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x68) (or $x68 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvshl in.01_32 (_ bv4 32))) true))))))
(check-sat)
; query 16: function main, block 44, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let (($x62 (or false false)))
(and (not $x62) (or $x62 (and (distinct ((_ sign_extend 24) in38_8) ((_ sign_extend 24) in38_8)) true)))))
(check-sat)
; query 17: function main, block 44, name %47
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x168 ((_ sign_extend 24) in38_8)))
(let ((?x145 (bvshl in.01_32 (_ bv4 32))))
(let ((?x496 (bvadd ?x145 ?x168)))
(let ((?x124 ((_ sign_extend 1) ?x496)))
(let (($x62 (or false false)))
(let (($x36 (or false false false)))
(let (($x68 (or $x36 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x20 (or $x68 $x62 (or (and (distinct (bvadd ((_ sign_extend 1) ?x145) ((_ sign_extend 1) ?x168)) ?x124) true)))))
(and (not $x20) (or $x20 (and (distinct ?x496 ?x496) true))))))))))))
(check-sat)
; query 18: function main, block 44, name %48
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x168 ((_ sign_extend 24) in38_8)))
(let ((?x145 (bvshl in.01_32 (_ bv4 32))))
(let ((?x496 (bvadd ?x145 ?x168)))
(let ((?x142 (bvsub ?x496 (_ bv48 32))))
(let (($x86 (and (distinct (bvsub ((_ sign_extend 1) ?x496) ((_ sign_extend 1) (_ bv48 32))) ((_ sign_extend 1) ?x142)) true)))
(let ((?x124 ((_ sign_extend 1) ?x496)))
(let (($x62 (or false false)))
(let (($x36 (or false false false)))
(let (($x68 (or $x36 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x20 (or $x68 $x62 (or (and (distinct (bvadd ((_ sign_extend 1) ?x145) ((_ sign_extend 1) ?x168)) ?x124) true)))))
(let (($x44 (or $x20 false (or $x86))))
(and (not $x44) (or $x44 (and (distinct ?x142 ?x142) true)))))))))))))))
(check-sat)
; query 19: function main, block 49, name %50
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let (($x62 (or false false)))
(and (not $x62) (or $x62 (and (distinct ((_ sign_extend 24) in38_8) ((_ sign_extend 24) in38_8)) true)))))
(check-sat)
; query 20: function main, block 49, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let ((?x103 (ite (bvsle (_ bv65 32) ((_ sign_extend 24) in38_8)) (_ bv1 1) (_ bv0 1))))
(let (($x62 (or false false)))
(let (($x21 (or $x62 false false)))
(let (($x43 (not $x21)))
(and $x43 (or $x21 (and (distinct ?x103 ?x103) true))))))))
(check-sat)
; query 21: function main, block 52, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let (($x62 (or false false)))
(and (not $x62) (or $x62 (and (distinct ((_ sign_extend 24) in38_8) ((_ sign_extend 24) in38_8)) true)))))
(check-sat)
; query 22: function main, block 52, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let ((?x17 (ite (bvsge (_ bv70 32) ((_ sign_extend 24) in38_8)) (_ bv1 1) (_ bv0 1))))
(let (($x62 (or false false)))
(let (($x21 (or $x62 false false)))
(let (($x43 (not $x21)))
(and $x43 (or $x21 (and (distinct ?x17 ?x17) true))))))))
(check-sat)
; query 23: function main, block 55, name %56
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x36 (or false false false)))
(let (($x68 (or $x36 (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x68) (or $x68 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvshl in.01_32 (_ bv4 32))) true))))))
(check-sat)
; query 24: function main, block 55, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let (($x62 (or false false)))
(and (not $x62) (or $x62 (and (distinct ((_ sign_extend 24) in38_8) ((_ sign_extend 24) in38_8)) true)))))
(check-sat)
; query 25: function main, block 55, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x168 ((_ sign_extend 24) in38_8)))
(let ((?x145 (bvshl in.01_32 (_ bv4 32))))
(let ((?x496 (bvadd ?x145 ?x168)))
(let ((?x124 ((_ sign_extend 1) ?x496)))
(let (($x62 (or false false)))
(let (($x36 (or false false false)))
(let (($x68 (or $x36 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x20 (or $x68 $x62 (or (and (distinct (bvadd ((_ sign_extend 1) ?x145) ((_ sign_extend 1) ?x168)) ?x124) true)))))
(and (not $x20) (or $x20 (and (distinct ?x496 ?x496) true))))))))))))
(check-sat)
; query 26: function main, block 55, name %59
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x168 ((_ sign_extend 24) in38_8)))
(let ((?x145 (bvshl in.01_32 (_ bv4 32))))
(let ((?x496 (bvadd ?x145 ?x168)))
(let ((?x23 (bvsub ?x496 (_ bv65 32))))
(let ((?x55 ((_ sign_extend 1) ?x23)))
(let ((?x124 ((_ sign_extend 1) ?x496)))
(let (($x62 (or false false)))
(let (($x36 (or false false false)))
(let (($x68 (or $x36 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x20 (or $x68 $x62 (or (and (distinct (bvadd ((_ sign_extend 1) ?x145) ((_ sign_extend 1) ?x168)) ?x124) true)))))
(let (($x202 (or $x20 false (or (and (distinct (bvsub ?x124 ((_ sign_extend 1) (_ bv65 32))) ?x55) true)))))
(and (not $x202) (or $x202 (and (distinct ?x23 ?x23) true)))))))))))))))
(check-sat)
; query 27: function main, block 55, name %60
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x168 ((_ sign_extend 24) in38_8)))
(let ((?x145 (bvshl in.01_32 (_ bv4 32))))
(let ((?x496 (bvadd ?x145 ?x168)))
(let ((?x23 (bvsub ?x496 (_ bv65 32))))
(let ((?x100 (bvadd ?x23 (_ bv10 32))))
(let (($x14 (and (distinct (bvadd ((_ sign_extend 1) ?x23) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x100)) true)))
(let ((?x55 ((_ sign_extend 1) ?x23)))
(let ((?x124 ((_ sign_extend 1) ?x496)))
(let (($x62 (or false false)))
(let (($x36 (or false false false)))
(let (($x68 (or $x36 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x20 (or $x68 $x62 (or (and (distinct (bvadd ((_ sign_extend 1) ?x145) ((_ sign_extend 1) ?x168)) ?x124) true)))))
(let (($x202 (or $x20 false (or (and (distinct (bvsub ?x124 ((_ sign_extend 1) (_ bv65 32))) ?x55) true)))))
(let (($x316 (or $x202 false (or $x14))))
(and (not $x316) (or $x316 (and (distinct ?x100 ?x100) true))))))))))))))))))
(check-sat)
; query 28: function main, block 81, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x631 (ite (bvsgt (_ bv32 32) in.06.lcssa_32) (_ bv1 1) (_ bv0 1))))
(let (($x36 (or false false false)))
(let (($x80 (not $x36)))
(and $x80 (or $x36 (and (distinct ?x631 ?x631) true)))))))
(check-sat)
; query 29: function main, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06.lcssa_32 () (_ BitVec 32))
(assert
 (let (($x36 (or false false false)))
(let (($x450 (or $x36 (and (distinct (bvand in.06.lcssa_32 (_ bv15 32)) (bvand in.06.lcssa_32 (_ bv15 32))) true))))
(let (($x80 (not $x36)))
(and $x80 $x450)))))
(check-sat)
; query 30: function main, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x381 (ite (and (distinct (_ bv0 32) (bvand in.06.lcssa_32 (_ bv15 32))) true) (_ bv1 1) (_ bv0 1))))
(let (($x36 (or false false false)))
(let (($x58 (or $x36 false false)))
(let (($x642 (not $x58)))
(and $x642 (or $x58 (and (distinct ?x381 ?x381) true))))))))
(check-sat)
; query 31: function set_key, block 11, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let (($x36 (or false false false)))
(let (($x80 (not $x36)))
(and $x80 (or $x36 (and (distinct (bvand in2_32 (_ bv1 32)) (bvand in2_32 (_ bv1 32))) true))))))
(check-sat)
; query 32: function set_key, block 11, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x306 (ite (and (distinct (_ bv0 32) (bvand in2_32 (_ bv1 32))) true) (_ bv1 1) (_ bv0 1))))
(let (($x36 (or false false false)))
(let (($x58 (or $x36 false false)))
(let (($x642 (not $x58)))
(and $x642 (or $x58 (and (distinct ?x306 ?x306) true))))))))
(check-sat)
; query 33: function set_key, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let (($x36 (or false false false)))
(let (($x80 (not $x36)))
(and $x80 (or $x36 (and (distinct (bvand in2_32 (_ bv2 32)) (bvand in2_32 (_ bv2 32))) true))))))
(check-sat)
; query 34: function set_key, block 14, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x38 (ite (and (distinct (_ bv0 32) (bvand in2_32 (_ bv2 32))) true) (_ bv1 1) (_ bv0 1))))
(let (($x36 (or false false false)))
(let (($x58 (or $x36 false false)))
(let (($x642 (not $x58)))
(and $x642 (or $x58 (and (distinct ?x38 ?x38) true))))))))
(check-sat)
; query 35: function set_key, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x41 (ite (and (distinct (_ bv0 64) in1_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x36 (or false false false)))
(let (($x80 (not $x36)))
(and $x80 (or $x36 (and (distinct ?x41 ?x41) true)))))))
(check-sat)
; query 36: function set_key, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x471 (ite (bvult in1_64 (_ bv16 64)) (_ bv1 1) (_ bv0 1))))
(let (($x36 (or false false false)))
(let (($x80 (not $x36)))
(and $x80 (or $x36 (and (distinct ?x471 ?x471) true)))))))
(check-sat)
; query 37: function set_key, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x581 (ite (bvugt in1_64 (_ bv32 64)) (_ bv1 1) (_ bv0 1))))
(let (($x36 (or false false false)))
(let (($x80 (not $x36)))
(and $x80 (or $x36 (and (distinct ?x581 ?x581) true)))))))
(check-sat)
; query 38: function set_key, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let (($x36 (or false false false)))
(let (($x80 (not $x36)))
(and $x80 (or $x36 (and (distinct (bvand in1_64 (_ bv7 64)) (bvand in1_64 (_ bv7 64))) true))))))
(check-sat)
; query 39: function set_key, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x383 (ite (and (distinct (_ bv0 64) (bvand in1_64 (_ bv7 64))) true) (_ bv1 1) (_ bv0 1))))
(let (($x36 (or false false false)))
(let (($x58 (or $x36 false false)))
(let (($x642 (not $x58)))
(and $x642 (or $x58 (and (distinct ?x383 ?x383) true))))))))
(check-sat)
