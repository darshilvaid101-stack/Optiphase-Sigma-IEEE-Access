; OptiPhase-Sigma refinement certificate for sweep K55-R6-019
; query 0: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x586 (or false false false)))
(let (($x100 (not $x586)))
(and $x100 (or $x586 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1042 (bvadd in.01_32 (_ bv1 32))))
(let ((?x116 (bvmul ?x1042 ?x1042)))
(let (($x586 (or false false false)))
(let (($x1599 (or $x586 $x586 false)))
(and (not $x1599) (or $x1599 (and (distinct ?x116 ?x116) true))))))))
(check-sat)
; query 2: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1042 (bvadd in.01_32 (_ bv1 32))))
(let ((?x116 (bvmul ?x1042 ?x1042)))
(let ((?x362 (bvmul ?x116 (_ bv2 32))))
(let (($x586 (or false false false)))
(let (($x1599 (or $x586 $x586 false)))
(let (($x665 (or $x1599 false false)))
(and (not $x665) (or $x665 (and (distinct ?x362 ?x362) true))))))))))
(check-sat)
; query 3: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1042 (bvadd in.01_32 (_ bv1 32))))
(let ((?x116 (bvmul ?x1042 ?x1042)))
(let ((?x362 (bvmul ?x116 (_ bv2 32))))
(let ((?x796 (bvmul ?x362 (_ bv4 32))))
(let (($x586 (or false false false)))
(let (($x1599 (or $x586 $x586 false)))
(let (($x665 (or $x1599 false false)))
(let (($x1473 (or $x665 false false)))
(and (not $x1473) (or $x1473 (and (distinct ?x796 ?x796) true))))))))))))
(check-sat)
; query 4: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x2080 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x586 (or false false false)))
(let (($x100 (not $x586)))
(and $x100 (or $x586 (and (distinct ?x2080 ?x2080) true)))))))
(check-sat)
; query 5: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x2070 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x586 (or false false false)))
(let (($x100 (not $x586)))
(and $x100 (or $x586 (and (distinct ?x2070 ?x2070) true)))))))
(check-sat)
; query 6: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x586 (or false false false)))
(let (($x100 (not $x586)))
(and $x100 (or $x586 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 7: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x258 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x534 (or false false (or $x258))))
(and (not $x534) (or $x534 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x1435 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x586 (or false false false)))
(let (($x100 (not $x586)))
(and $x100 (or $x586 (and (distinct ?x1435 ?x1435) true)))))))
(check-sat)
; query 9: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x789 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x586 (or false false false)))
(let (($x100 (not $x586)))
(and $x100 (or $x586 (and (distinct ?x789 ?x789) true)))))))
(check-sat)
; query 10: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x765 (or false false)))
(and (not $x765) (or $x765 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true)))))
(check-sat)
; query 11: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x86 ((_ sign_extend 16) in.1_16)))
(let ((?x1156 (bvadd ?x86 (_ bv10 32))))
(let (($x1575 (and (distinct (bvadd ((_ sign_extend 1) ?x86) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x1156)) true)))
(let (($x765 (or false false)))
(let (($x62 (or $x765 false (or $x1575))))
(and (not $x62) (or $x62 (and (distinct ?x1156 ?x1156) true)))))))))
(check-sat)
; query 12: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x86 ((_ sign_extend 16) in.1_16)))
(let ((?x1156 (bvadd ?x86 (_ bv10 32))))
(let ((?x2871 ((_ extract 15 0) ?x1156)))
(let (($x1575 (and (distinct (bvadd ((_ sign_extend 1) ?x86) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x1156)) true)))
(let (($x765 (or false false)))
(let (($x62 (or $x765 false (or $x1575))))
(let (($x949 (or $x62 false)))
(and (not $x949) (or $x949 (and (distinct ?x2871 ?x2871) true)))))))))))
(check-sat)
; query 13: function matrix_sum, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x156 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x586 (or false false false)))
(let (($x100 (not $x586)))
(and $x100 (or $x586 (and (distinct ?x156 ?x156) true)))))))
(check-sat)
; query 14: function matrix_sum, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x156 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let ((?x1596 ((_ zero_extend 63) ?x156)))
(let (($x586 (or false false false)))
(let (($x1586 (or $x586 false)))
(and (not $x1586) (or $x1586 (and (distinct ?x1596 ?x1596) true))))))))
(check-sat)
; query 15: function matrix_sum, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x156 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x20 (= (_ bv1 1) ?x156)))
(let ((?x733 (ite $x20 (_ bv1 32) (_ bv0 32))))
(let (($x586 (or false false false)))
(let (($x212 (or $x586 (ite $x20 false false))))
(and (not $x212) (or $x212 (and (distinct ?x733 ?x733) true)))))))))
(check-sat)
; query 16: function matrix_sum, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x765 (or false false)))
(and (not $x765) (or $x765 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true)))))
(check-sat)
; query 17: function matrix_sum, block 22, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x156 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x20 (= (_ bv1 1) ?x156)))
(let ((?x733 (ite $x20 (_ bv1 32) (_ bv0 32))))
(let ((?x86 ((_ sign_extend 16) in.1_16)))
(let ((?x256 (bvadd ?x86 ?x733)))
(let (($x1117 (and (distinct (bvadd ((_ sign_extend 1) ?x86) ((_ sign_extend 1) ?x733)) ((_ sign_extend 1) ?x256)) true)))
(let (($x586 (or false false false)))
(let (($x212 (or $x586 (ite $x20 false false))))
(let (($x765 (or false false)))
(let (($x2870 (or $x765 $x212 (or $x1117))))
(and (not $x2870) (or $x2870 (and (distinct ?x256 ?x256) true))))))))))))))
(check-sat)
; query 18: function matrix_sum, block 22, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x156 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x20 (= (_ bv1 1) ?x156)))
(let ((?x733 (ite $x20 (_ bv1 32) (_ bv0 32))))
(let ((?x86 ((_ sign_extend 16) in.1_16)))
(let ((?x256 (bvadd ?x86 ?x733)))
(let ((?x786 ((_ extract 15 0) ?x256)))
(let (($x1117 (and (distinct (bvadd ((_ sign_extend 1) ?x86) ((_ sign_extend 1) ?x733)) ((_ sign_extend 1) ?x256)) true)))
(let (($x586 (or false false false)))
(let (($x212 (or $x586 (ite $x20 false false))))
(let (($x765 (or false false)))
(let (($x2870 (or $x765 $x212 (or $x1117))))
(let (($x115 (or $x2870 false)))
(and (not $x115) (or $x115 (and (distinct ?x786 ?x786) true))))))))))))))))
(check-sat)
