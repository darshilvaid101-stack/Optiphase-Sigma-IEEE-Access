; OptiPhase-Sigma refinement certificate for sweep K57-R3-111
; query 0: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x384 (or false false)))
(let (($x108 (not $x384)))
(and $x108 (or $x384 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 1: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x591 ((_ sign_extend 16) in3_16)))
(let ((?x457 (bvand ?x591 (_ bv127 32))))
(let (($x384 (or false false)))
(let (($x53 (or $x384 false false)))
(let (($x22 (not $x53)))
(and $x22 (or $x53 (and (distinct ?x457 ?x457) true)))))))))
(check-sat)
; query 2: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x591 ((_ sign_extend 16) in3_16)))
(let ((?x457 (bvand ?x591 (_ bv127 32))))
(let ((?x6 ((_ extract 15 0) ?x457)))
(let (($x384 (or false false)))
(let (($x53 (or $x384 false false)))
(let (($x114 (or $x53 false)))
(let (($x703 (not $x114)))
(and $x703 (or $x114 (and (distinct ?x6 ?x6) true)))))))))))
(check-sat)
; query 3: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x384 (or false false)))
(let (($x108 (not $x384)))
(and $x108 (or $x384 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 4: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x257 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x384 (or false false)))
(let (($x53 (or $x384 false false)))
(let (($x22 (not $x53)))
(and $x22 (or $x53 (and (distinct ?x257 ?x257) true))))))))
(check-sat)
; query 5: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x12 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x99 (or false false false)))
(let (($x701 (not $x99)))
(and $x701 (or $x99 (and (distinct ?x12 ?x12) true)))))))
(check-sat)
; query 6: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x100 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x99 (or false false false)))
(let (($x701 (not $x99)))
(and $x701 (or $x99 (and (distinct ?x100 ?x100) true)))))))
(check-sat)
; query 7: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x99 (or false false false)))
(let (($x701 (not $x99)))
(and $x701 (or $x99 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 8: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x89 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x1346 (or false false (or $x89))))
(and (not $x1346) (or $x1346 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 9: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x765 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x516 ((_ zero_extend 31) ?x765)))
(let ((?x1335 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x122 ((_ zero_extend 31) ?x1335)))
(let ((?x553 (bvand ?x122 ?x516)))
(let ((?x1343 (ite (and (distinct (_ bv0 32) ?x553) true) (_ bv1 1) (_ bv0 1))))
(let ((?x64 ((_ zero_extend 63) ?x1343)))
(let (($x384 (or false false)))
(let (($x53 (or $x384 false false)))
(let (($x114 (or $x53 false)))
(let (($x462 (or $x114 $x114 false)))
(let (($x1391 (or $x462 false false)))
(let (($x618 (or $x1391 false)))
(and (not $x618) (or $x618 (and (distinct ?x64 ?x64) true)))))))))))))))))
(check-sat)
; query 10: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x765 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x516 ((_ zero_extend 31) ?x765)))
(let ((?x1335 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x122 ((_ zero_extend 31) ?x1335)))
(let ((?x553 (bvand ?x122 ?x516)))
(let ((?x1343 (ite (and (distinct (_ bv0 32) ?x553) true) (_ bv1 1) (_ bv0 1))))
(let (($x851 (= (_ bv1 1) ?x1343)))
(let ((?x410 (ite $x851 (_ bv1 32) (_ bv0 32))))
(let (($x384 (or false false)))
(let (($x53 (or $x384 false false)))
(let (($x114 (or $x53 false)))
(let (($x462 (or $x114 $x114 false)))
(let (($x1391 (or $x462 false false)))
(let (($x98 (or $x1391 (ite $x851 false false))))
(and (not $x98) (or $x98 (and (distinct ?x410 ?x410) true))))))))))))))))))
(check-sat)
; query 11: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x765 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x516 ((_ zero_extend 31) ?x765)))
(let ((?x1335 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x122 ((_ zero_extend 31) ?x1335)))
(let ((?x553 (bvand ?x122 ?x516)))
(let ((?x1343 (ite (and (distinct (_ bv0 32) ?x553) true) (_ bv1 1) (_ bv0 1))))
(let (($x851 (= (_ bv1 1) ?x1343)))
(let ((?x410 (ite $x851 (_ bv1 32) (_ bv0 32))))
(let ((?x500 ((_ extract 7 0) ?x410)))
(let (($x384 (or false false)))
(let (($x53 (or $x384 false false)))
(let (($x114 (or $x53 false)))
(let (($x462 (or $x114 $x114 false)))
(let (($x1391 (or $x462 false false)))
(let (($x98 (or $x1391 (ite $x851 false false))))
(let (($x341 (or $x98 false)))
(and (not $x341) (or $x341 (and (distinct ?x500 ?x500) true))))))))))))))))))))
(check-sat)
; query 12: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x384 (or false false)))
(let (($x108 (not $x384)))
(and $x108 (or $x384 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 13: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1335 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x384 (or false false)))
(let (($x53 (or $x384 false false)))
(let (($x22 (not $x53)))
(and $x22 (or $x53 (and (distinct ?x1335 ?x1335) true))))))))
(check-sat)
; query 14: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1335 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x122 ((_ zero_extend 31) ?x1335)))
(let (($x384 (or false false)))
(let (($x53 (or $x384 false false)))
(let (($x114 (or $x53 false)))
(let (($x703 (not $x114)))
(and $x703 (or $x114 (and (distinct ?x122 ?x122) true))))))))))
(check-sat)
; query 15: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x384 (or false false)))
(let (($x108 (not $x384)))
(and $x108 (or $x384 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 16: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x765 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x384 (or false false)))
(let (($x53 (or $x384 false false)))
(let (($x22 (not $x53)))
(and $x22 (or $x53 (and (distinct ?x765 ?x765) true))))))))
(check-sat)
; query 17: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x765 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x516 ((_ zero_extend 31) ?x765)))
(let (($x384 (or false false)))
(let (($x53 (or $x384 false false)))
(let (($x114 (or $x53 false)))
(let (($x703 (not $x114)))
(and $x703 (or $x114 (and (distinct ?x516 ?x516) true))))))))))
(check-sat)
; query 18: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x765 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x516 ((_ zero_extend 31) ?x765)))
(let ((?x1335 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x122 ((_ zero_extend 31) ?x1335)))
(let ((?x553 (bvand ?x122 ?x516)))
(let (($x384 (or false false)))
(let (($x53 (or $x384 false false)))
(let (($x114 (or $x53 false)))
(let (($x462 (or $x114 $x114 false)))
(and (not $x462) (or $x462 (and (distinct ?x553 ?x553) true)))))))))))))
(check-sat)
; query 19: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x765 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x516 ((_ zero_extend 31) ?x765)))
(let ((?x1335 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x122 ((_ zero_extend 31) ?x1335)))
(let ((?x553 (bvand ?x122 ?x516)))
(let ((?x1343 (ite (and (distinct (_ bv0 32) ?x553) true) (_ bv1 1) (_ bv0 1))))
(let (($x384 (or false false)))
(let (($x53 (or $x384 false false)))
(let (($x114 (or $x53 false)))
(let (($x462 (or $x114 $x114 false)))
(let (($x1391 (or $x462 false false)))
(and (not $x1391) (or $x1391 (and (distinct ?x1343 ?x1343) true)))))))))))))))
(check-sat)
; query 20: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x351 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x99 (or false false false)))
(let (($x701 (not $x99)))
(and $x701 (or $x99 (and (distinct ?x351 ?x351) true)))))))
(check-sat)
