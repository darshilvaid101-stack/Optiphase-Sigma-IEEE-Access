; OptiPhase-Sigma refinement certificate for sweep K16-R3-252
; query 0: function xmalloc, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in7_32 () (_ BitVec 32))
(assert
 (let ((?x130 (ite (and (distinct (_ bv0 32) in7_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x132 (or false false false)))
(and (not $x132) (or $x132 (and (distinct ?x130 ?x130) true))))))
(check-sat)
