; OptiPhase-Sigma refinement certificate for sweep K37-R1-004
