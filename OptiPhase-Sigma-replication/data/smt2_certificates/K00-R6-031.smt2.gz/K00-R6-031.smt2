; OptiPhase-Sigma refinement certificate for sweep K00-R6-031
