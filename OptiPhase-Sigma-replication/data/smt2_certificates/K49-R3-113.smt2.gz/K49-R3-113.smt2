; OptiPhase-Sigma refinement certificate for sweep K49-R3-113
; query 0: function APCM_inverse_quantization, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x279 (or false false)))
(let (($x1094 (not $x279)))
(and $x1094 (or $x279 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 1: function APCM_inverse_quantization, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x86 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x279 (or false false)))
(let (($x785 (or $x279 false false)))
(let (($x76 (not $x785)))
(and $x76 (or $x785 (and (distinct ?x86 ?x86) true))))))))
(check-sat)
; query 2: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x279 (or false false)))
(let (($x1094 (not $x279)))
(and $x1094 (or $x279 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 3: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x181 (ite (bvslt (_ bv15 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x279 (or false false)))
(let (($x785 (or $x279 false false)))
(let (($x76 (not $x785)))
(and $x76 (or $x785 (and (distinct ?x181 ?x181) true))))))))
(check-sat)
; query 4: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x279 (or false false)))
(let (($x1094 (not $x279)))
(and $x1094 (or $x279 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 5: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x61 (ite (bvsgt (_ bv40 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x279 (or false false)))
(let (($x785 (or $x279 false false)))
(let (($x76 (not $x785)))
(and $x76 (or $x785 (and (distinct ?x61 ?x61) true))))))))
(check-sat)
; query 6: function RPE_grid_positioning, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x279 (or false false)))
(let (($x1094 (not $x279)))
(and $x1094 (or $x279 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 7: function RPE_grid_positioning, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x109 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x139 (and (distinct ?x109 ?x109) true)))
(let (($x279 (or false false)))
(let (($x281 (or false $x279 false)))
(and (not $x281) (or $x281 $x139)))))))
(check-sat)
; query 8: function gsm_L_add, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x173 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x156 (or false false false)))
(let (($x326 (not $x156)))
(and $x326 (or $x156 (and (distinct ?x173 ?x173) true)))))))
(check-sat)
; query 9: function gsm_L_add, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x798 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvadd in0_64 in1_64))) true)))
(let (($x153 (or false false (or $x798))))
(let (($x180 (or $x153 (and (distinct (bvadd in0_64 in1_64) (bvadd in0_64 in1_64)) true))))
(and (not $x153) $x180)))))
(check-sat)
; query 10: function gsm_L_add, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x12 (bvadd in0_64 (_ bv1 64))))
(let ((?x226 (bvsub (_ bv0 64) ?x12)))
(let (($x224 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x12)) ((_ sign_extend 1) ?x226)) true)))
(let ((?x547 ((_ sign_extend 1) ?x12)))
(let (($x495 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x547) true)))))
(let (($x11 (or false $x495 (or $x224))))
(and (not $x11) (or $x11 (and (distinct ?x226 ?x226) true))))))))))
(check-sat)
; query 11: function gsm_L_add, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x501 (bvadd in1_64 (_ bv1 64))))
(let ((?x117 ((_ sign_extend 1) ?x501)))
(let (($x341 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x117) true)))))
(and (not $x341) (or $x341 (and (distinct ?x501 ?x501) true)))))))
(check-sat)
; query 12: function gsm_L_add, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x501 (bvadd in1_64 (_ bv1 64))))
(let ((?x50 (bvsub (_ bv0 64) ?x501)))
(let (($x131 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x501)) ((_ sign_extend 1) ?x50)) true)))
(let ((?x117 ((_ sign_extend 1) ?x501)))
(let (($x341 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x117) true)))))
(let (($x553 (or false $x341 (or $x131))))
(and (not $x553) (or $x553 (and (distinct ?x50 ?x50) true))))))))))
(check-sat)
; query 13: function gsm_L_add, block 8, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x501 (bvadd in1_64 (_ bv1 64))))
(let ((?x50 (bvsub (_ bv0 64) ?x501)))
(let ((?x12 (bvadd in0_64 (_ bv1 64))))
(let ((?x226 (bvsub (_ bv0 64) ?x12)))
(let ((?x36 (bvadd ?x226 ?x50)))
(let (($x131 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x501)) ((_ sign_extend 1) ?x50)) true)))
(let ((?x117 ((_ sign_extend 1) ?x501)))
(let (($x341 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x117) true)))))
(let (($x553 (or false $x341 (or $x131))))
(let (($x224 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x12)) ((_ sign_extend 1) ?x226)) true)))
(let ((?x547 ((_ sign_extend 1) ?x12)))
(let (($x495 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x547) true)))))
(let (($x11 (or false $x495 (or $x224))))
(let (($x34 (or $x11 $x553 false)))
(and (not $x34) (or $x34 (and (distinct ?x36 ?x36) true))))))))))))))))))
(check-sat)
; query 14: function gsm_L_add, block 8, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x501 (bvadd in1_64 (_ bv1 64))))
(let ((?x50 (bvsub (_ bv0 64) ?x501)))
(let ((?x12 (bvadd in0_64 (_ bv1 64))))
(let ((?x226 (bvsub (_ bv0 64) ?x12)))
(let ((?x36 (bvadd ?x226 ?x50)))
(let ((?x59 (ite (bvuge ?x36 (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x131 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x501)) ((_ sign_extend 1) ?x50)) true)))
(let ((?x117 ((_ sign_extend 1) ?x501)))
(let (($x341 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x117) true)))))
(let (($x553 (or false $x341 (or $x131))))
(let (($x224 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x12)) ((_ sign_extend 1) ?x226)) true)))
(let ((?x547 ((_ sign_extend 1) ?x12)))
(let (($x495 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x547) true)))))
(let (($x11 (or false $x495 (or $x224))))
(let (($x34 (or $x11 $x553 false)))
(let (($x14 (or $x34 false false)))
(and (not $x14) (or $x14 (and (distinct ?x59 ?x59) true))))))))))))))))))))
(check-sat)
; query 15: function gsm_L_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x12 (bvadd in0_64 (_ bv1 64))))
(let ((?x547 ((_ sign_extend 1) ?x12)))
(let (($x495 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x547) true)))))
(and (not $x495) (or $x495 (and (distinct ?x12 ?x12) true)))))))
(check-sat)
; query 16: function gsm_L_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x22 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x156 (or false false false)))
(let (($x326 (not $x156)))
(and $x326 (or $x156 (and (distinct ?x22 ?x22) true)))))))
(check-sat)
; query 17: function gsm_L_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x40 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x156 (or false false false)))
(let (($x326 (not $x156)))
(and $x326 (or $x156 (and (distinct ?x40 ?x40) true)))))))
(check-sat)
; query 18: function gsm_L_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x22 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x156 (or false false false)))
(let (($x326 (not $x156)))
(and $x326 (or $x156 (and (distinct ?x22 ?x22) true)))))))
(check-sat)
; query 19: function gsm_L_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x22 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x497 ((_ zero_extend 31) ?x22)))
(let (($x156 (or false false false)))
(let (($x113 (or $x156 false)))
(and (not $x113) (or $x113 (and (distinct ?x497 ?x497) true))))))))
(check-sat)
; query 20: function gsm_L_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x22 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x497 ((_ zero_extend 31) ?x22)))
(let ((?x45 (bvsub (_ bv0 32) ?x497)))
(let (($x30 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x497)) ((_ sign_extend 1) ?x45)) true)))
(let (($x156 (or false false false)))
(let (($x113 (or $x156 false)))
(let (($x531 (or false $x113 (or $x30))))
(and (not $x531) (or $x531 (and (distinct ?x45 ?x45) true)))))))))))
(check-sat)
; query 21: function gsm_L_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x22 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x497 ((_ zero_extend 31) ?x22)))
(let ((?x45 (bvsub (_ bv0 32) ?x497)))
(let ((?x292 ((_ sign_extend 32) ?x45)))
(let (($x30 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x497)) ((_ sign_extend 1) ?x45)) true)))
(let (($x156 (or false false false)))
(let (($x113 (or $x156 false)))
(let (($x531 (or false $x113 (or $x30))))
(let (($x148 (or $x531 false)))
(and (not $x148) (or $x148 (and (distinct ?x292 ?x292) true)))))))))))))
(check-sat)
; query 22: function gsm_L_asr, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x182 (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x156 (or false false false)))
(let (($x326 (not $x156)))
(and $x326 (or $x156 (and (distinct ?x182 ?x182) true)))))))
(check-sat)
; query 23: function gsm_L_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x40 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x156 (or false false false)))
(let (($x326 (not $x156)))
(and $x326 (or $x156 (and (distinct ?x40 ?x40) true)))))))
(check-sat)
; query 24: function gsm_L_sub, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x173 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x156 (or false false false)))
(let (($x326 (not $x156)))
(and $x326 (or $x156 (and (distinct ?x173 ?x173) true)))))))
(check-sat)
; query 25: function gsm_L_sub, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x522 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvsub in0_64 in1_64))) true)))
(let (($x614 (or false false (or $x522))))
(let (($x147 (or $x614 (and (distinct (bvsub in0_64 in1_64) (bvsub in0_64 in1_64)) true))))
(and (not $x614) $x147)))))
(check-sat)
; query 26: function gsm_L_sub, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x501 (bvadd in1_64 (_ bv1 64))))
(let ((?x50 (bvsub (_ bv0 64) ?x501)))
(let (($x131 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x501)) ((_ sign_extend 1) ?x50)) true)))
(let ((?x117 ((_ sign_extend 1) ?x501)))
(let (($x341 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x117) true)))))
(let (($x553 (or false $x341 (or $x131))))
(and (not $x553) (or $x553 (and (distinct ?x50 ?x50) true))))))))))
(check-sat)
; query 27: function gsm_L_sub, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x501 (bvadd in1_64 (_ bv1 64))))
(let ((?x50 (bvsub (_ bv0 64) ?x501)))
(let ((?x70 (bvadd in0_64 ?x50)))
(let (($x131 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x501)) ((_ sign_extend 1) ?x50)) true)))
(let ((?x117 ((_ sign_extend 1) ?x501)))
(let (($x341 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x117) true)))))
(let (($x553 (or false $x341 (or $x131))))
(let (($x256 (or false $x553 false)))
(and (not $x256) (or $x256 (and (distinct ?x70 ?x70) true))))))))))))
(check-sat)
; query 28: function gsm_L_sub, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x5 (ite (bvuge (bvadd in0_64 (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64)))) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x131 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) (bvadd in1_64 (_ bv1 64)))) ((_ sign_extend 1) (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64))))) true)))
(let ((?x501 (bvadd in1_64 (_ bv1 64))))
(let ((?x117 ((_ sign_extend 1) ?x501)))
(let (($x341 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x117) true)))))
(let (($x553 (or false $x341 (or $x131))))
(let (($x256 (or false $x553 false)))
(let (($x105 (or $x256 false false)))
(and (not $x105) (or $x105 (and (distinct ?x5 ?x5) true))))))))))))
(check-sat)
; query 29: function gsm_L_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x501 (bvadd in1_64 (_ bv1 64))))
(let ((?x117 ((_ sign_extend 1) ?x501)))
(let (($x341 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x117) true)))))
(and (not $x341) (or $x341 (and (distinct ?x501 ?x501) true)))))))
(check-sat)
; query 30: function gsm_L_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x89 (ite (bvsle (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x156 (or false false false)))
(let (($x326 (not $x156)))
(and $x326 (or $x156 (and (distinct ?x89 ?x89) true)))))))
(check-sat)
; query 31: function gsm_abs, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x279 (or false false)))
(let (($x1094 (not $x279)))
(and $x1094 (or $x279 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 32: function gsm_abs, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x164 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x279 (or false false)))
(let (($x785 (or $x279 false false)))
(let (($x76 (not $x785)))
(and $x76 (or $x785 (and (distinct ?x164 ?x164) true))))))))
(check-sat)
; query 33: function gsm_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x279 (or false false)))
(let (($x1094 (not $x279)))
(and $x1094 (or $x279 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 34: function gsm_add, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x279 (or false false)))
(let (($x1094 (not $x279)))
(and $x1094 (or $x279 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 35: function gsm_add, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x93 ((_ sign_extend 48) in1_16)))
(let ((?x130 ((_ sign_extend 48) in0_16)))
(let ((?x46 (bvadd ?x130 ?x93)))
(let (($x77 (and (distinct (bvadd ((_ sign_extend 1) ?x130) ((_ sign_extend 1) ?x93)) ((_ sign_extend 1) ?x46)) true)))
(let (($x279 (or false false)))
(let (($x54 (or $x279 $x279 (or $x77))))
(and (not $x54) (or $x54 (and (distinct ?x46 ?x46) true))))))))))
(check-sat)
; query 36: function gsm_add, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x244 (ite (bvsgt (_ bv18446744073709518848 64) (bvadd ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x93 ((_ sign_extend 48) in1_16)))
(let ((?x21 ((_ sign_extend 1) ?x93)))
(let ((?x130 ((_ sign_extend 48) in0_16)))
(let ((?x99 ((_ sign_extend 1) ?x130)))
(let (($x279 (or false false)))
(let (($x54 (or $x279 $x279 (or (and (distinct (bvadd ?x99 ?x21) ((_ sign_extend 1) (bvadd ?x130 ?x93))) true)))))
(let (($x31 (or $x54 false false)))
(and (not $x31) (or $x31 (and (distinct ?x244 ?x244) true))))))))))))
(check-sat)
; query 37: function gsm_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x68 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x156 (or false false false)))
(let (($x326 (not $x156)))
(and $x326 (or $x156 (and (distinct ?x68 ?x68) true)))))))
(check-sat)
; query 38: function gsm_asr, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x190 (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x156 (or false false false)))
(let (($x326 (not $x156)))
(and $x326 (or $x156 (and (distinct ?x190 ?x190) true)))))))
(check-sat)
; query 39: function gsm_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x279 (or false false)))
(let (($x1094 (not $x279)))
(and $x1094 (or $x279 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 40: function gsm_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x164 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x279 (or false false)))
(let (($x785 (or $x279 false false)))
(let (($x76 (not $x785)))
(and $x76 (or $x785 (and (distinct ?x164 ?x164) true))))))))
(check-sat)
; query 41: function gsm_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x164 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x290 ((_ zero_extend 31) ?x164)))
(let (($x279 (or false false)))
(let (($x785 (or $x279 false false)))
(let (($x129 (or $x785 false)))
(and (not $x129) (or $x129 (and (distinct ?x290 ?x290) true)))))))))
(check-sat)
; query 42: function gsm_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x164 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x290 ((_ zero_extend 31) ?x164)))
(let ((?x188 (bvsub (_ bv0 32) ?x290)))
(let (($x26 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x290)) ((_ sign_extend 1) ?x188)) true)))
(let (($x279 (or false false)))
(let (($x785 (or $x279 false false)))
(let (($x129 (or $x785 false)))
(let (($x91 (or false $x129 (or $x26))))
(and (not $x91) (or $x91 (and (distinct ?x188 ?x188) true))))))))))))
(check-sat)
; query 43: function gsm_asr, block 4, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x164 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x290 ((_ zero_extend 31) ?x164)))
(let ((?x188 (bvsub (_ bv0 32) ?x290)))
(let ((?x838 ((_ extract 15 0) ?x188)))
(let (($x26 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x290)) ((_ sign_extend 1) ?x188)) true)))
(let (($x279 (or false false)))
(let (($x785 (or $x279 false false)))
(let (($x129 (or $x785 false)))
(let (($x91 (or false $x129 (or $x26))))
(let (($x280 (or $x91 false)))
(and (not $x280) (or $x280 (and (distinct ?x838 ?x838) true))))))))))))))
(check-sat)
; query 44: function gsm_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x68 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x156 (or false false false)))
(let (($x326 (not $x156)))
(and $x326 (or $x156 (and (distinct ?x68 ?x68) true)))))))
(check-sat)
; query 45: function gsm_debug_longwords, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in15_32 () (_ BitVec 32))
(assert
 (let ((?x575 (ite (bvslt in15_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x156 (or false false false)))
(let (($x326 (not $x156)))
(and $x326 (or $x156 (and (distinct ?x575 ?x575) true)))))))
(check-sat)
; query 46: function gsm_debug_words, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in16_32 () (_ BitVec 32))
(assert
 (let ((?x392 (ite (bvslt in16_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x156 (or false false false)))
(let (($x326 (not $x156)))
(and $x326 (or $x156 (and (distinct ?x392 ?x392) true)))))))
(check-sat)
; query 47: function gsm_div, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x279 (or false false)))
(let (($x1094 (not $x279)))
(and $x1094 (or $x279 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 48: function gsm_div, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x279 (or false false)))
(let (($x1094 (not $x279)))
(and $x1094 (or $x279 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 49: function gsm_div, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x279 (or false false)))
(let (($x1094 (not $x279)))
(and $x1094 (or $x279 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 50: function gsm_div, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x109 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x139 (and (distinct ?x109 ?x109) true)))
(let (($x279 (or false false)))
(let (($x785 (or $x279 false false)))
(let (($x76 (not $x785)))
(and $x76 (or $x785 $x139))))))))
(check-sat)
; query 51: function gsm_norm, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x907 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x156 (or false false false)))
(let (($x326 (not $x156)))
(and $x326 (or $x156 (and (distinct ?x907 ?x907) true)))))))
(check-sat)
; query 52: function gsm_norm, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x907 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x85 (bvxor ?x907 (_ bv1 1))))
(let (($x156 (or false false false)))
(let (($x489 (or $x156 false false)))
(and (not $x489) (or $x489 (and (distinct ?x85 ?x85) true))))))))
(check-sat)
; query 53: function gsm_norm, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x907 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x85 (bvxor ?x907 (_ bv1 1))))
(let ((?x724 ((_ zero_extend 31) ?x85)))
(let (($x156 (or false false false)))
(let (($x489 (or $x156 false false)))
(let (($x234 (or $x489 false)))
(and (not $x234) (or $x234 (and (distinct ?x724 ?x724) true))))))))))
(check-sat)
; query 54: function gsm_norm, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x907 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x85 (bvxor ?x907 (_ bv1 1))))
(let ((?x724 ((_ zero_extend 31) ?x85)))
(let ((?x452 ((_ sign_extend 32) ?x724)))
(let (($x156 (or false false false)))
(let (($x489 (or $x156 false false)))
(let (($x234 (or $x489 false)))
(let (($x535 (or $x234 false)))
(and (not $x535) (or $x535 (and (distinct ?x452 ?x452) true))))))))))))
(check-sat)
; query 55: function gsm_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x279 (or false false)))
(let (($x1094 (not $x279)))
(and $x1094 (or $x279 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 56: function gsm_sub, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x279 (or false false)))
(let (($x1094 (not $x279)))
(and $x1094 (or $x279 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 57: function gsm_sub, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x93 ((_ sign_extend 48) in1_16)))
(let ((?x130 ((_ sign_extend 48) in0_16)))
(let ((?x423 (bvsub ?x130 ?x93)))
(let (($x893 (and (distinct (bvsub ((_ sign_extend 1) ?x130) ((_ sign_extend 1) ?x93)) ((_ sign_extend 1) ?x423)) true)))
(let (($x279 (or false false)))
(let (($x762 (or $x279 $x279 (or $x893))))
(and (not $x762) (or $x762 (and (distinct ?x423 ?x423) true))))))))))
(check-sat)
; query 58: function gsm_sub, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x275 (ite (bvsgt (_ bv18446744073709518848 64) (bvsub ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x93 ((_ sign_extend 48) in1_16)))
(let ((?x21 ((_ sign_extend 1) ?x93)))
(let ((?x130 ((_ sign_extend 48) in0_16)))
(let ((?x99 ((_ sign_extend 1) ?x130)))
(let (($x279 (or false false)))
(let (($x762 (or $x279 $x279 (or (and (distinct (bvsub ?x99 ?x21) ((_ sign_extend 1) (bvsub ?x130 ?x93))) true)))))
(let (($x523 (or $x762 false false)))
(and (not $x523) (or $x523 (and (distinct ?x275 ?x275) true))))))))))))
(check-sat)
