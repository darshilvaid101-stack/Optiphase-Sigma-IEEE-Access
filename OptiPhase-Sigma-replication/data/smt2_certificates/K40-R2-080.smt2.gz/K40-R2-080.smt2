; OptiPhase-Sigma refinement certificate for sweep K40-R2-080
; query 0: function decfile, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in17_32 () (_ BitVec 32))
(assert
 (let ((?x262 (ite (and (distinct (_ bv16 32) in17_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x21 (or false false false)))
(let (($x159 (not $x21)))
(and $x159 (or $x21 (and (distinct ?x262 ?x262) true)))))))
(check-sat)
; query 1: function decfile, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x386 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x101 (or false false (or $x386))))
(and (not $x101) (or $x101 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function decfile, block 82, name %83
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x202 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x454 (or false false (or $x202))))
(and (not $x454) (or $x454 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 3: function decfile, block 85, name %86
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x137 (ite (= (_ bv15 32) in.01_32) (_ bv1 1) (_ bv0 1))))
(let (($x21 (or false false false)))
(let (($x159 (not $x21)))
(and $x159 (or $x21 (and (distinct ?x137 ?x137) true)))))))
(check-sat)
; query 4: function decfile, block 85, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x137 (ite (= (_ bv15 32) in.01_32) (_ bv1 1) (_ bv0 1))))
(let ((?x411 ((_ zero_extend 63) ?x137)))
(let (($x21 (or false false false)))
(let (($x65 (or $x21 false)))
(and (not $x65) (or $x65 (and (distinct ?x411 ?x411) true))))))))
(check-sat)
; query 5: function decfile, block 85, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x137 (ite (= (_ bv15 32) in.01_32) (_ bv1 1) (_ bv0 1))))
(let (($x287 (= (_ bv1 1) ?x137)))
(let ((?x127 (ite $x287 (_ bv1 32) (_ bv0 32))))
(let (($x21 (or false false false)))
(let (($x226 (or $x21 (ite $x287 false false))))
(and (not $x226) (or $x226 (and (distinct ?x127 ?x127) true)))))))))
(check-sat)
; query 6: function decfile, block 85, name %89
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x137 (ite (= (_ bv15 32) in.01_32) (_ bv1 1) (_ bv0 1))))
(let (($x287 (= (_ bv1 1) ?x137)))
(let ((?x127 (ite $x287 (_ bv1 32) (_ bv0 32))))
(let ((?x98 (bvsub (_ bv1 32) ?x127)))
(let ((?x333 ((_ sign_extend 1) ?x98)))
(let (($x21 (or false false false)))
(let (($x226 (or $x21 (ite $x287 false false))))
(let (($x582 (or false $x226 (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv1 32)) ((_ sign_extend 1) ?x127)) ?x333) true)))))
(and (not $x582) (or $x582 (and (distinct ?x98 ?x98) true))))))))))))
(check-sat)
; query 7: function decfile, block 85, name %90
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(declare-fun in46_32 () (_ BitVec 32))
(assert
 (let ((?x137 (ite (= (_ bv15 32) in.01_32) (_ bv1 1) (_ bv0 1))))
(let (($x287 (= (_ bv1 1) ?x137)))
(let ((?x127 (ite $x287 (_ bv1 32) (_ bv0 32))))
(let ((?x98 (bvsub (_ bv1 32) ?x127)))
(let ((?x485 (bvadd in46_32 ?x98)))
(let (($x43 (and (distinct (bvadd ((_ sign_extend 1) in46_32) ((_ sign_extend 1) ?x98)) ((_ sign_extend 1) ?x485)) true)))
(let ((?x333 ((_ sign_extend 1) ?x98)))
(let (($x21 (or false false false)))
(let (($x226 (or $x21 (ite $x287 false false))))
(let (($x582 (or false $x226 (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv1 32)) ((_ sign_extend 1) ?x127)) ?x333) true)))))
(let (($x58 (or false $x582 (or $x43))))
(and (not $x58) (or $x58 (and (distinct ?x485 ?x485) true)))))))))))))))
(check-sat)
; query 8: function decfile, block 85, name %91
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(declare-fun in46_32 () (_ BitVec 32))
(assert
 (let ((?x137 (ite (= (_ bv15 32) in.01_32) (_ bv1 1) (_ bv0 1))))
(let (($x287 (= (_ bv1 1) ?x137)))
(let ((?x127 (ite $x287 (_ bv1 32) (_ bv0 32))))
(let ((?x98 (bvsub (_ bv1 32) ?x127)))
(let ((?x485 (bvadd in46_32 ?x98)))
(let ((?x34 (ite (and (distinct (_ bv0 32) ?x485) true) (_ bv1 1) (_ bv0 1))))
(let (($x43 (and (distinct (bvadd ((_ sign_extend 1) in46_32) ((_ sign_extend 1) ?x98)) ((_ sign_extend 1) ?x485)) true)))
(let ((?x333 ((_ sign_extend 1) ?x98)))
(let (($x21 (or false false false)))
(let (($x226 (or $x21 (ite $x287 false false))))
(let (($x582 (or false $x226 (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv1 32)) ((_ sign_extend 1) ?x127)) ?x333) true)))))
(let (($x58 (or false $x582 (or $x43))))
(let (($x76 (or $x58 false false)))
(and (not $x76) (or $x76 (and (distinct ?x34 ?x34) true)))))))))))))))))
(check-sat)
; query 9: function encfile, block 50, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_64 () (_ BitVec 64))
(assert
 (let (($x21 (or false false false)))
(let (($x159 (not $x21)))
(and $x159 (or $x21 (and (distinct (bvadd in.1_64 (_ bv1 64)) (bvadd in.1_64 (_ bv1 64))) true))))))
(check-sat)
; query 10: function encfile, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_64 () (_ BitVec 64))
(assert
 (let (($x21 (or false false false)))
(let (($x159 (not $x21)))
(and $x159 (or $x21 (and (distinct (bvadd in.2_64 (_ bv1 64)) (bvadd in.2_64 (_ bv1 64))) true))))))
(check-sat)
; query 11: function encfile, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.5_64 () (_ BitVec 64))
(assert
 (let (($x21 (or false false false)))
(let (($x159 (not $x21)))
(and $x159 (or $x21 (and (distinct (bvadd in.5_64 (_ bv1 64)) (bvadd in.5_64 (_ bv1 64))) true))))))
(check-sat)
; query 12: function fillrand, block 34, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x370 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x120 (or false false (or $x370))))
(and (not $x120) (or $x120 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 13: function main, block 41, name %42
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let (($x141 (or false false)))
(and (not $x141) (or $x141 (and (distinct ((_ sign_extend 24) in38_8) ((_ sign_extend 24) in38_8)) true)))))
(check-sat)
; query 14: function main, block 41, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let ((?x143 (ite (bvsge (_ bv57 32) ((_ sign_extend 24) in38_8)) (_ bv1 1) (_ bv0 1))))
(let (($x141 (or false false)))
(let (($x80 (or $x141 false false)))
(let (($x15 (not $x80)))
(and $x15 (or $x80 (and (distinct ?x143 ?x143) true))))))))
(check-sat)
; query 15: function main, block 44, name %45
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x21 (or false false false)))
(let (($x217 (or $x21 (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x217) (or $x217 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvshl in.01_32 (_ bv4 32))) true))))))
(check-sat)
; query 16: function main, block 44, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let (($x141 (or false false)))
(and (not $x141) (or $x141 (and (distinct ((_ sign_extend 24) in38_8) ((_ sign_extend 24) in38_8)) true)))))
(check-sat)
; query 17: function main, block 44, name %47
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x434 ((_ sign_extend 24) in38_8)))
(let ((?x131 (bvshl in.01_32 (_ bv4 32))))
(let ((?x124 (bvadd ?x131 ?x434)))
(let ((?x157 ((_ sign_extend 1) ?x124)))
(let (($x141 (or false false)))
(let (($x21 (or false false false)))
(let (($x217 (or $x21 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x136 (or $x217 $x141 (or (and (distinct (bvadd ((_ sign_extend 1) ?x131) ((_ sign_extend 1) ?x434)) ?x157) true)))))
(and (not $x136) (or $x136 (and (distinct ?x124 ?x124) true))))))))))))
(check-sat)
; query 18: function main, block 44, name %48
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x434 ((_ sign_extend 24) in38_8)))
(let ((?x131 (bvshl in.01_32 (_ bv4 32))))
(let ((?x124 (bvadd ?x131 ?x434)))
(let ((?x114 (bvsub ?x124 (_ bv48 32))))
(let (($x67 (and (distinct (bvsub ((_ sign_extend 1) ?x124) ((_ sign_extend 1) (_ bv48 32))) ((_ sign_extend 1) ?x114)) true)))
(let ((?x157 ((_ sign_extend 1) ?x124)))
(let (($x141 (or false false)))
(let (($x21 (or false false false)))
(let (($x217 (or $x21 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x136 (or $x217 $x141 (or (and (distinct (bvadd ((_ sign_extend 1) ?x131) ((_ sign_extend 1) ?x434)) ?x157) true)))))
(let (($x263 (or $x136 false (or $x67))))
(and (not $x263) (or $x263 (and (distinct ?x114 ?x114) true)))))))))))))))
(check-sat)
; query 19: function main, block 49, name %50
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let (($x141 (or false false)))
(and (not $x141) (or $x141 (and (distinct ((_ sign_extend 24) in38_8) ((_ sign_extend 24) in38_8)) true)))))
(check-sat)
; query 20: function main, block 49, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let ((?x122 (ite (bvsle (_ bv65 32) ((_ sign_extend 24) in38_8)) (_ bv1 1) (_ bv0 1))))
(let (($x141 (or false false)))
(let (($x80 (or $x141 false false)))
(let (($x15 (not $x80)))
(and $x15 (or $x80 (and (distinct ?x122 ?x122) true))))))))
(check-sat)
; query 21: function main, block 52, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let (($x141 (or false false)))
(and (not $x141) (or $x141 (and (distinct ((_ sign_extend 24) in38_8) ((_ sign_extend 24) in38_8)) true)))))
(check-sat)
; query 22: function main, block 52, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let ((?x618 (ite (bvsge (_ bv70 32) ((_ sign_extend 24) in38_8)) (_ bv1 1) (_ bv0 1))))
(let (($x141 (or false false)))
(let (($x80 (or $x141 false false)))
(let (($x15 (not $x80)))
(and $x15 (or $x80 (and (distinct ?x618 ?x618) true))))))))
(check-sat)
; query 23: function main, block 55, name %56
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x21 (or false false false)))
(let (($x217 (or $x21 (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x217) (or $x217 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvshl in.01_32 (_ bv4 32))) true))))))
(check-sat)
; query 24: function main, block 55, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let (($x141 (or false false)))
(and (not $x141) (or $x141 (and (distinct ((_ sign_extend 24) in38_8) ((_ sign_extend 24) in38_8)) true)))))
(check-sat)
; query 25: function main, block 55, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x434 ((_ sign_extend 24) in38_8)))
(let ((?x131 (bvshl in.01_32 (_ bv4 32))))
(let ((?x124 (bvadd ?x131 ?x434)))
(let ((?x157 ((_ sign_extend 1) ?x124)))
(let (($x141 (or false false)))
(let (($x21 (or false false false)))
(let (($x217 (or $x21 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x136 (or $x217 $x141 (or (and (distinct (bvadd ((_ sign_extend 1) ?x131) ((_ sign_extend 1) ?x434)) ?x157) true)))))
(and (not $x136) (or $x136 (and (distinct ?x124 ?x124) true))))))))))))
(check-sat)
; query 26: function main, block 55, name %59
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x434 ((_ sign_extend 24) in38_8)))
(let ((?x131 (bvshl in.01_32 (_ bv4 32))))
(let ((?x124 (bvadd ?x131 ?x434)))
(let ((?x26 (bvsub ?x124 (_ bv65 32))))
(let ((?x10 ((_ sign_extend 1) ?x26)))
(let ((?x157 ((_ sign_extend 1) ?x124)))
(let (($x141 (or false false)))
(let (($x21 (or false false false)))
(let (($x217 (or $x21 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x136 (or $x217 $x141 (or (and (distinct (bvadd ((_ sign_extend 1) ?x131) ((_ sign_extend 1) ?x434)) ?x157) true)))))
(let (($x319 (or $x136 false (or (and (distinct (bvsub ?x157 ((_ sign_extend 1) (_ bv65 32))) ?x10) true)))))
(and (not $x319) (or $x319 (and (distinct ?x26 ?x26) true)))))))))))))))
(check-sat)
; query 27: function main, block 55, name %60
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x434 ((_ sign_extend 24) in38_8)))
(let ((?x131 (bvshl in.01_32 (_ bv4 32))))
(let ((?x124 (bvadd ?x131 ?x434)))
(let ((?x26 (bvsub ?x124 (_ bv65 32))))
(let ((?x252 (bvadd ?x26 (_ bv10 32))))
(let (($x11 (and (distinct (bvadd ((_ sign_extend 1) ?x26) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x252)) true)))
(let ((?x10 ((_ sign_extend 1) ?x26)))
(let ((?x157 ((_ sign_extend 1) ?x124)))
(let (($x141 (or false false)))
(let (($x21 (or false false false)))
(let (($x217 (or $x21 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x136 (or $x217 $x141 (or (and (distinct (bvadd ((_ sign_extend 1) ?x131) ((_ sign_extend 1) ?x434)) ?x157) true)))))
(let (($x319 (or $x136 false (or (and (distinct (bvsub ?x157 ((_ sign_extend 1) (_ bv65 32))) ?x10) true)))))
(let (($x616 (or $x319 false (or $x11))))
(and (not $x616) (or $x616 (and (distinct ?x252 ?x252) true))))))))))))))))))
(check-sat)
; query 28: function main, block 81, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_32 () (_ BitVec 32))
(assert
 (let ((?x223 (ite (bvsgt (_ bv32 32) in.06_32) (_ bv1 1) (_ bv0 1))))
(let (($x21 (or false false false)))
(let (($x159 (not $x21)))
(and $x159 (or $x21 (and (distinct ?x223 ?x223) true)))))))
(check-sat)
; query 29: function main, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_32 () (_ BitVec 32))
(assert
 (let (($x21 (or false false false)))
(let (($x159 (not $x21)))
(and $x159 (or $x21 (and (distinct (bvand in.06_32 (_ bv15 32)) (bvand in.06_32 (_ bv15 32))) true))))))
(check-sat)
; query 30: function main, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_32 () (_ BitVec 32))
(assert
 (let ((?x339 (ite (and (distinct (_ bv0 32) (bvand in.06_32 (_ bv15 32))) true) (_ bv1 1) (_ bv0 1))))
(let (($x21 (or false false false)))
(let (($x86 (or $x21 false false)))
(let (($x167 (not $x86)))
(and $x167 (or $x86 (and (distinct ?x339 ?x339) true))))))))
(check-sat)
; query 31: function set_key, block 11, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let (($x21 (or false false false)))
(let (($x159 (not $x21)))
(and $x159 (or $x21 (and (distinct (bvand in2_32 (_ bv1 32)) (bvand in2_32 (_ bv1 32))) true))))))
(check-sat)
; query 32: function set_key, block 11, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x55 (ite (and (distinct (_ bv0 32) (bvand in2_32 (_ bv1 32))) true) (_ bv1 1) (_ bv0 1))))
(let (($x21 (or false false false)))
(let (($x86 (or $x21 false false)))
(let (($x167 (not $x86)))
(and $x167 (or $x86 (and (distinct ?x55 ?x55) true))))))))
(check-sat)
; query 33: function set_key, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let (($x21 (or false false false)))
(let (($x159 (not $x21)))
(and $x159 (or $x21 (and (distinct (bvand in2_32 (_ bv2 32)) (bvand in2_32 (_ bv2 32))) true))))))
(check-sat)
; query 34: function set_key, block 14, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x379 (ite (and (distinct (_ bv0 32) (bvand in2_32 (_ bv2 32))) true) (_ bv1 1) (_ bv0 1))))
(let (($x21 (or false false false)))
(let (($x86 (or $x21 false false)))
(let (($x167 (not $x86)))
(and $x167 (or $x86 (and (distinct ?x379 ?x379) true))))))))
(check-sat)
; query 35: function set_key, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x179 (ite (and (distinct (_ bv0 64) in1_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x21 (or false false false)))
(let (($x159 (not $x21)))
(and $x159 (or $x21 (and (distinct ?x179 ?x179) true)))))))
(check-sat)
; query 36: function set_key, block 514, name %515
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_64 () (_ BitVec 64))
(assert
 (let (($x21 (or false false false)))
(let (($x159 (not $x21)))
(and $x159 (or $x21 (and (distinct (bvadd in.01_64 (_ bv1 64)) (bvadd in.01_64 (_ bv1 64))) true))))))
(check-sat)
; query 37: function set_key, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x154 (ite (bvult in1_64 (_ bv16 64)) (_ bv1 1) (_ bv0 1))))
(let (($x21 (or false false false)))
(let (($x159 (not $x21)))
(and $x159 (or $x21 (and (distinct ?x154 ?x154) true)))))))
(check-sat)
; query 38: function set_key, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x554 (ite (bvugt in1_64 (_ bv32 64)) (_ bv1 1) (_ bv0 1))))
(let (($x21 (or false false false)))
(let (($x159 (not $x21)))
(and $x159 (or $x21 (and (distinct ?x554 ?x554) true)))))))
(check-sat)
; query 39: function set_key, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let (($x21 (or false false false)))
(let (($x159 (not $x21)))
(and $x159 (or $x21 (and (distinct (bvand in1_64 (_ bv7 64)) (bvand in1_64 (_ bv7 64))) true))))))
(check-sat)
; query 40: function set_key, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x462 (ite (and (distinct (_ bv0 64) (bvand in1_64 (_ bv7 64))) true) (_ bv1 1) (_ bv0 1))))
(let (($x21 (or false false false)))
(let (($x86 (or $x21 false false)))
(let (($x167 (not $x86)))
(and $x167 (or $x86 (and (distinct ?x462 ?x462) true))))))))
(check-sat)
