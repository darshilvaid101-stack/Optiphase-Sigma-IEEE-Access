; OptiPhase-Sigma refinement certificate for sweep K00-R4-325
