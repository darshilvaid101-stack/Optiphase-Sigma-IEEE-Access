; OptiPhase-Sigma refinement certificate for sweep K57-R3-295
; query 0: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x6 (or false false false)))
(let (($x2655 (not $x6)))
(and $x2655 (or $x6 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x118 (bvadd in.01_32 (_ bv1 32))))
(let ((?x62 (bvmul ?x118 ?x118)))
(let (($x6 (or false false false)))
(let (($x1607 (or $x6 $x6 false)))
(and (not $x1607) (or $x1607 (and (distinct ?x62 ?x62) true))))))))
(check-sat)
; query 2: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x118 (bvadd in.01_32 (_ bv1 32))))
(let ((?x62 (bvmul ?x118 ?x118)))
(let ((?x2372 (bvmul ?x62 (_ bv2 32))))
(let (($x6 (or false false false)))
(let (($x1607 (or $x6 $x6 false)))
(let (($x13 (or $x1607 false false)))
(and (not $x13) (or $x13 (and (distinct ?x2372 ?x2372) true))))))))))
(check-sat)
; query 3: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x118 (bvadd in.01_32 (_ bv1 32))))
(let ((?x62 (bvmul ?x118 ?x118)))
(let ((?x2372 (bvmul ?x62 (_ bv2 32))))
(let ((?x1319 (bvmul ?x2372 (_ bv4 32))))
(let (($x6 (or false false false)))
(let (($x1607 (or $x6 $x6 false)))
(let (($x13 (or $x1607 false false)))
(let (($x208 (or $x13 false false)))
(and (not $x208) (or $x208 (and (distinct ?x1319 ?x1319) true))))))))))))
(check-sat)
; query 4: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x121 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x6 (or false false false)))
(let (($x2655 (not $x6)))
(and $x2655 (or $x6 (and (distinct ?x121 ?x121) true)))))))
(check-sat)
; query 5: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x734 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x6 (or false false false)))
(let (($x2655 (not $x6)))
(and $x2655 (or $x6 (and (distinct ?x734 ?x734) true)))))))
(check-sat)
; query 6: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x6 (or false false false)))
(let (($x2655 (not $x6)))
(and $x2655 (or $x6 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 7: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x631 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x983 (or false false (or $x631))))
(and (not $x983) (or $x983 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x1119 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x6 (or false false false)))
(let (($x2655 (not $x6)))
(and $x2655 (or $x6 (and (distinct ?x1119 ?x1119) true)))))))
(check-sat)
; query 9: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x885 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x6 (or false false false)))
(let (($x2655 (not $x6)))
(and $x2655 (or $x6 (and (distinct ?x885 ?x885) true)))))))
(check-sat)
; query 10: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x362 (or false false)))
(and (not $x362) (or $x362 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true)))))
(check-sat)
; query 11: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x94 ((_ sign_extend 16) in.1_16)))
(let ((?x126 (bvadd ?x94 (_ bv10 32))))
(let (($x89 (and (distinct (bvadd ((_ sign_extend 1) ?x94) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x126)) true)))
(let (($x362 (or false false)))
(let (($x473 (or $x362 false (or $x89))))
(and (not $x473) (or $x473 (and (distinct ?x126 ?x126) true)))))))))
(check-sat)
; query 12: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x94 ((_ sign_extend 16) in.1_16)))
(let ((?x126 (bvadd ?x94 (_ bv10 32))))
(let ((?x842 ((_ extract 15 0) ?x126)))
(let (($x89 (and (distinct (bvadd ((_ sign_extend 1) ?x94) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x126)) true)))
(let (($x362 (or false false)))
(let (($x473 (or $x362 false (or $x89))))
(let (($x101 (or $x473 false)))
(and (not $x101) (or $x101 (and (distinct ?x842 ?x842) true)))))))))))
(check-sat)
; query 13: function matrix_sum, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x92 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x6 (or false false false)))
(let (($x2655 (not $x6)))
(and $x2655 (or $x6 (and (distinct ?x92 ?x92) true)))))))
(check-sat)
; query 14: function matrix_sum, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x92 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let ((?x656 ((_ zero_extend 63) ?x92)))
(let (($x6 (or false false false)))
(let (($x1633 (or $x6 false)))
(and (not $x1633) (or $x1633 (and (distinct ?x656 ?x656) true))))))))
(check-sat)
; query 15: function matrix_sum, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x92 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x213 (= (_ bv1 1) ?x92)))
(let ((?x43 (ite $x213 (_ bv1 32) (_ bv0 32))))
(let (($x6 (or false false false)))
(let (($x83 (or $x6 (ite $x213 false false))))
(and (not $x83) (or $x83 (and (distinct ?x43 ?x43) true)))))))))
(check-sat)
; query 16: function matrix_sum, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x362 (or false false)))
(and (not $x362) (or $x362 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true)))))
(check-sat)
; query 17: function matrix_sum, block 22, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x92 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x213 (= (_ bv1 1) ?x92)))
(let ((?x43 (ite $x213 (_ bv1 32) (_ bv0 32))))
(let ((?x94 ((_ sign_extend 16) in.1_16)))
(let ((?x494 (bvadd ?x94 ?x43)))
(let (($x1108 (and (distinct (bvadd ((_ sign_extend 1) ?x94) ((_ sign_extend 1) ?x43)) ((_ sign_extend 1) ?x494)) true)))
(let (($x6 (or false false false)))
(let (($x83 (or $x6 (ite $x213 false false))))
(let (($x362 (or false false)))
(let (($x70 (or $x362 $x83 (or $x1108))))
(and (not $x70) (or $x70 (and (distinct ?x494 ?x494) true))))))))))))))
(check-sat)
; query 18: function matrix_sum, block 22, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x92 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x213 (= (_ bv1 1) ?x92)))
(let ((?x43 (ite $x213 (_ bv1 32) (_ bv0 32))))
(let ((?x94 ((_ sign_extend 16) in.1_16)))
(let ((?x494 (bvadd ?x94 ?x43)))
(let ((?x125 ((_ extract 15 0) ?x494)))
(let (($x1108 (and (distinct (bvadd ((_ sign_extend 1) ?x94) ((_ sign_extend 1) ?x43)) ((_ sign_extend 1) ?x494)) true)))
(let (($x6 (or false false false)))
(let (($x83 (or $x6 (ite $x213 false false))))
(let (($x362 (or false false)))
(let (($x70 (or $x362 $x83 (or $x1108))))
(let (($x74 (or $x70 false)))
(and (not $x74) (or $x74 (and (distinct ?x125 ?x125) true))))))))))))))))
(check-sat)
