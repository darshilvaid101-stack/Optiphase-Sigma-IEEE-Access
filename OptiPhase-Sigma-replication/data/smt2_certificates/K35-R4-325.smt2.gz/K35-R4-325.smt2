; OptiPhase-Sigma refinement certificate for sweep K35-R4-325
; query 0: function edge_draw, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let ((?x458 (ite (= (_ bv0 32) in4_32) (_ bv1 1) (_ bv0 1))))
(let (($x602 (or false false false)))
(and (not $x602) (or $x602 (and (distinct ?x458 ?x458) true))))))
(check-sat)
