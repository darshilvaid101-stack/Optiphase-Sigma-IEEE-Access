; OptiPhase-Sigma refinement certificate for sweep K45-R3-102
; query 0: function Index_to_frequency, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x415 (ite (bvuge in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x170 (or false false false)))
(let (($x25 (not $x170)))
(and $x25 (or $x170 (and (distinct ?x415 ?x415) true)))))))
(check-sat)
; query 1: function IsPowerOfTwo, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x219 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x170 (or false false false)))
(let (($x25 (not $x170)))
(and $x25 (or $x170 (and (distinct ?x219 ?x219) true)))))))
(check-sat)
; query 2: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x219 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x170 (or false false false)))
(let (($x25 (not $x170)))
(and $x25 (or $x170 (and (distinct ?x219 ?x219) true)))))))
(check-sat)
; query 3: function main, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x22 (ite (= (_ bv4 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x170 (or false false false)))
(let (($x25 (not $x170)))
(and $x25 (or $x170 (and (distinct ?x22 ?x22) true)))))))
(check-sat)
; query 4: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x52 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x170 (or false false false)))
(let (($x25 (not $x170)))
(and $x25 (or $x170 (and (distinct ?x52 ?x52) true)))))))
(check-sat)
