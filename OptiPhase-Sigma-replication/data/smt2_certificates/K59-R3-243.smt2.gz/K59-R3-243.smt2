; OptiPhase-Sigma refinement certificate for sweep K59-R3-243
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x9000 (or false (or (= ((_ extract 15 15) in25_16) (_ bv1 1))))))
(let (($x85 (or false false)))
(let (($x24 (not $x85)))
(and $x24 (or $x9000 (and (distinct ((_ sign_extend 16) in25_16) ((_ zero_extend 16) in25_16)) true)))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x30 (and (distinct (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1)) (ite (bvsgt (_ bv34 32) ((_ zero_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))) true)))
(let (($x43 (or (or (or false (or (= ((_ extract 15 15) in25_16) (_ bv1 1)))) false false) $x30)))
(let (($x85 (or false false)))
(let (($x286 (or $x85 false false)))
(let (($x122 (not $x286)))
(and $x122 $x43)))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x85 (or false false)))
(let (($x24 (not $x85)))
(and $x24 (or $x85 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x383 ((_ sign_extend 16) in3_16)))
(let ((?x84 (bvand ?x383 (_ bv127 32))))
(let (($x85 (or false false)))
(let (($x286 (or $x85 false false)))
(let (($x122 (not $x286)))
(and $x122 (or $x286 (and (distinct ?x84 ?x84) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x383 ((_ sign_extend 16) in3_16)))
(let ((?x84 (bvand ?x383 (_ bv127 32))))
(let ((?x3860 ((_ extract 15 0) ?x84)))
(let (($x4450 (or (and (distinct ((_ zero_extend 16) ?x3860) ?x84) true) (and (distinct ((_ sign_extend 16) ?x3860) ?x84) true))))
(let (($x85 (or false false)))
(let (($x286 (or $x85 false false)))
(let (($x333 (not (or $x286 false))))
(and $x333 (or (or $x286 $x4450) (and (distinct ?x3860 ?x3860) true)))))))))))
(check-sat)
; query 5: function core_bench_list, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x521 (or false false false)))
(let (($x206 (not $x521)))
(and $x206 (or $x521 (and (distinct (bvadd in.0_16 (_ bv1 16)) (bvadd in.0_16 (_ bv1 16))) true))))))
(check-sat)
; query 6: function core_bench_list, block 82, name %83
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let (($x85 (or false false)))
(let (($x24 (not $x85)))
(and $x24 (or $x85 (and (distinct ((_ zero_extend 16) in.02_16) ((_ zero_extend 16) in.02_16)) true))))))
(check-sat)
; query 7: function core_bench_list, block 82, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x1621 ((_ zero_extend 16) in.02_16)))
(let ((?x448 (bvmul ?x1621 (_ bv4 32))))
(let (($x192 (and (distinct (bvmul ((_ zero_extend 32) ?x1621) ((_ zero_extend 32) (_ bv4 32))) ((_ zero_extend 32) ?x448)) true)))
(let (($x616 (and (distinct (bvmul ((_ sign_extend 32) ?x1621) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x448)) true)))
(let (($x85 (or false false)))
(let (($x183 (or $x85 false (or $x616 $x192))))
(and (not (or $x85 false (or $x616))) (or $x183 (and (distinct ?x448 ?x448) true))))))))))
(check-sat)
; query 8: function core_bench_list, block 82, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let (($x85 (or false false)))
(let (($x24 (not $x85)))
(and $x24 (or $x85 (and (distinct ((_ zero_extend 16) in.04_16) ((_ zero_extend 16) in.04_16)) true))))))
(check-sat)
; query 9: function core_bench_list, block 82, name %86
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x54 ((_ zero_extend 16) in.04_16)))
(let ((?x1621 ((_ zero_extend 16) in.02_16)))
(let ((?x448 (bvmul ?x1621 (_ bv4 32))))
(let ((?x458 (bvsub ?x448 ?x54)))
(let ((?x141 ((_ sign_extend 1) ?x458)))
(let (($x234 (or (and (distinct (bvsub ((_ sign_extend 1) ?x448) ((_ sign_extend 1) ?x54)) ?x141) true))))
(let (($x85 (or false false)))
(let (($x192 (and (distinct (bvmul ((_ zero_extend 32) ?x1621) ((_ zero_extend 32) (_ bv4 32))) ((_ zero_extend 32) ?x448)) true)))
(let (($x616 (and (distinct (bvmul ((_ sign_extend 32) ?x1621) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x448)) true)))
(let (($x183 (or $x85 false (or $x616 $x192))))
(let (($x540 (or $x183 $x85 $x234)))
(and (not (or (or $x85 false (or $x616)) $x85 $x234)) (or $x540 (and (distinct ?x458 ?x458) true)))))))))))))))
(check-sat)
; query 10: function core_bench_list, block 82, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x85 (or false false)))
(let (($x24 (not $x85)))
(and $x24 (or $x85 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 11: function core_bench_list, block 82, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x54 ((_ zero_extend 16) in.04_16)))
(let ((?x1621 ((_ zero_extend 16) in.02_16)))
(let ((?x448 (bvmul ?x1621 (_ bv4 32))))
(let ((?x458 (bvsub ?x448 ?x54)))
(let ((?x370 ((_ zero_extend 16) in.01_16)))
(let ((?x331 (bvadd ?x370 ?x458)))
(let (($x1679 (and (distinct (bvadd ((_ sign_extend 1) ?x370) ((_ sign_extend 1) ?x458)) ((_ sign_extend 1) ?x331)) true)))
(let (($x613 (or $x1679)))
(let ((?x141 ((_ sign_extend 1) ?x458)))
(let (($x234 (or (and (distinct (bvsub ((_ sign_extend 1) ?x448) ((_ sign_extend 1) ?x54)) ?x141) true))))
(let (($x85 (or false false)))
(let (($x192 (and (distinct (bvmul ((_ zero_extend 32) ?x1621) ((_ zero_extend 32) (_ bv4 32))) ((_ zero_extend 32) ?x448)) true)))
(let (($x616 (and (distinct (bvmul ((_ sign_extend 32) ?x1621) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x448)) true)))
(let (($x183 (or $x85 false (or $x616 $x192))))
(let (($x540 (or $x183 $x85 $x234)))
(let (($x328 (or $x85 $x540 $x613)))
(and (not (or $x85 (or (or $x85 false (or $x616)) $x85 $x234) $x613)) (or $x328 (and (distinct ?x331 ?x331) true))))))))))))))))))))
(check-sat)
; query 12: function core_bench_list, block 82, name %89
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x54 ((_ zero_extend 16) in.04_16)))
(let ((?x1621 ((_ zero_extend 16) in.02_16)))
(let ((?x448 (bvmul ?x1621 (_ bv4 32))))
(let ((?x458 (bvsub ?x448 ?x54)))
(let ((?x370 ((_ zero_extend 16) in.01_16)))
(let ((?x331 (bvadd ?x370 ?x458)))
(let ((?x142 ((_ extract 15 0) ?x331)))
(let (($x1679 (and (distinct (bvadd ((_ sign_extend 1) ?x370) ((_ sign_extend 1) ?x458)) ((_ sign_extend 1) ?x331)) true)))
(let (($x613 (or $x1679)))
(let ((?x141 ((_ sign_extend 1) ?x458)))
(let (($x234 (or (and (distinct (bvsub ((_ sign_extend 1) ?x448) ((_ sign_extend 1) ?x54)) ?x141) true))))
(let (($x85 (or false false)))
(let (($x192 (and (distinct (bvmul ((_ zero_extend 32) ?x1621) ((_ zero_extend 32) (_ bv4 32))) ((_ zero_extend 32) ?x448)) true)))
(let (($x616 (and (distinct (bvmul ((_ sign_extend 32) ?x1621) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x448)) true)))
(let (($x183 (or $x85 false (or $x616 $x192))))
(let (($x540 (or $x183 $x85 $x234)))
(let (($x328 (or $x85 $x540 $x613)))
(let (($x39 (or $x85 false (or $x616))))
(let (($x71 (or $x39 $x85 $x234)))
(let (($x72 (or $x85 $x71 $x613)))
(and (not (or $x72 false)) (or (or $x328 false) (and (distinct ?x142 ?x142) true))))))))))))))))))))))))
(check-sat)
; query 13: function core_bench_list, block 82, name %90
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x85 (or false false)))
(let (($x24 (not $x85)))
(and $x24 (or $x85 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 14: function core_bench_list, block 82, name %91
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x519 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x85 (or false false)))
(let (($x286 (or $x85 false false)))
(let (($x122 (not $x286)))
(and $x122 (or $x286 (and (distinct ?x519 ?x519) true))))))))
(check-sat)
; query 15: function core_bench_state, block 105, name %106
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let ((?x8722 (bvadd in.1_32 (_ bv1 32))))
(let (($x2953 (and (distinct ?x8722 ?x8722) true)))
(let (($x229 (and (distinct (bvadd ((_ zero_extend 1) in.1_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) ?x8722)) true)))
(let (($x3237 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x8722)) true)))
(let (($x521 (or false false false)))
(let (($x206 (not $x521)))
(and $x206 (or (or false false (or $x3237 $x229)) $x2953)))))))))
(check-sat)
; query 16: function core_bench_state, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x6800 (bvadd in.0_32 (_ bv1 32))))
(let (($x173 (and (distinct ?x6800 ?x6800) true)))
(let (($x1742 (and (distinct (bvadd ((_ zero_extend 1) in.0_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) ?x6800)) true)))
(let (($x161 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x6800)) true)))
(let (($x521 (or false false false)))
(let (($x206 (not $x521)))
(and $x206 (or (or false false (or $x161 $x1742)) $x173)))))))))
(check-sat)
; query 17: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x198 (bvadd in.01_32 (_ bv1 32))))
(let (($x1785 (and (distinct ?x198 ?x198) true)))
(let (($x521 (or false false false)))
(let (($x206 (not $x521)))
(and $x206 (or $x521 $x1785)))))))
(check-sat)
; query 18: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x198 (bvadd in.01_32 (_ bv1 32))))
(let ((?x1858 (bvmul ?x198 ?x198)))
(let (($x521 (or false false false)))
(let (($x305 (or $x521 $x521 false)))
(and (not $x305) (or $x305 (and (distinct ?x1858 ?x1858) true))))))))
(check-sat)
; query 19: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x198 (bvadd in.01_32 (_ bv1 32))))
(let ((?x1858 (bvmul ?x198 ?x198)))
(let ((?x196 (bvmul ?x1858 (_ bv2 32))))
(let (($x521 (or false false false)))
(let (($x305 (or $x521 $x521 false)))
(let (($x7726 (or $x305 false false)))
(and (not $x7726) (or $x7726 (and (distinct ?x196 ?x196) true))))))))))
(check-sat)
; query 20: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x198 (bvadd in.01_32 (_ bv1 32))))
(let ((?x1858 (bvmul ?x198 ?x198)))
(let ((?x196 (bvmul ?x1858 (_ bv2 32))))
(let ((?x386 (bvmul ?x196 (_ bv4 32))))
(let (($x521 (or false false false)))
(let (($x305 (or $x521 $x521 false)))
(let (($x7726 (or $x305 false false)))
(let (($x840 (or $x7726 false false)))
(and (not $x840) (or $x840 (and (distinct ?x386 ?x386) true))))))))))))
(check-sat)
; query 21: function core_init_matrix, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let ((?x8722 (bvadd in.1_32 (_ bv1 32))))
(let (($x2953 (and (distinct ?x8722 ?x8722) true)))
(let (($x521 (or false false false)))
(let (($x206 (not $x521)))
(and $x206 (or $x521 $x2953)))))))
(check-sat)
; query 22: function core_init_matrix, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x521 (or false false false)))
(let (($x206 (not $x521)))
(and $x206 (or $x521 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 23: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x6741 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x521 (or false false false)))
(let (($x206 (not $x521)))
(and $x206 (or $x521 (and (distinct ?x6741 ?x6741) true)))))))
(check-sat)
; query 24: function core_init_state, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_32 () (_ BitVec 32))
(assert
 (let (($x1125 (and (distinct (bvadd ((_ zero_extend 1) in.06_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.06_32 (_ bv1 32)))) true)))
(let (($x9522 (and (distinct (bvadd ((_ sign_extend 1) in.06_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.06_32 (_ bv1 32)))) true)))
(let (($x8384 (or (or false false (or $x9522 $x1125)) (and (distinct (bvadd in.06_32 (_ bv1 32)) (bvadd in.06_32 (_ bv1 32))) true))))
(let (($x521 (or false false false)))
(let (($x206 (not $x521)))
(and $x206 $x8384)))))))
(check-sat)
; query 25: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x1124 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x521 (or false false false)))
(let (($x206 (not $x521)))
(and $x206 (or $x521 (and (distinct ?x1124 ?x1124) true)))))))
(check-sat)
; query 26: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x521 (or false false false)))
(let (($x206 (not $x521)))
(and $x206 (or $x521 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 27: function core_list_init, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x198 (bvadd in.01_32 (_ bv1 32))))
(let (($x1785 (and (distinct ?x198 ?x198) true)))
(let (($x2529 (and (distinct (bvadd ((_ zero_extend 1) in.01_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) ?x198)) true)))
(let (($x521 (or false false false)))
(let (($x206 (not $x521)))
(and $x206 (or (or false false (or $x2529)) $x1785))))))))
(check-sat)
; query 28: function core_list_mergesort, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x198 (bvadd in.01_32 (_ bv1 32))))
(let (($x1785 (and (distinct ?x198 ?x198) true)))
(let (($x3489 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x198)) true)))
(let (($x8895 (or false false (or $x3489))))
(and (not $x8895) (or $x8895 $x1785)))))))
(check-sat)
; query 29: function core_list_mergesort, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x5538 (ite (bvslt (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x521 (or false false false)))
(let (($x206 (not $x521)))
(and $x206 (or $x521 (and (distinct ?x5538 ?x5538) true)))))))
(check-sat)
; query 30: function core_list_mergesort, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.224_32 () (_ BitVec 32))
(assert
 (let ((?x5560 (ite (= (_ bv0 32) in.224_32) (_ bv1 1) (_ bv0 1))))
(let (($x521 (or false false false)))
(let (($x206 (not $x521)))
(and $x206 (or $x521 (and (distinct ?x5560 ?x5560) true)))))))
(check-sat)
; query 31: function core_list_mergesort, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x9624 (ite (= (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x521 (or false false false)))
(let (($x206 (not $x521)))
(and $x206 (or $x521 (and (distinct ?x9624 ?x9624) true)))))))
(check-sat)
; query 32: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x1513 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x2323 (or false false (or $x1513))))
(and (not $x2323) (or $x2323 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 33: function core_list_mergesort, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x8528 (and (distinct (bvmul ((_ sign_extend 32) in.020_32) ((_ sign_extend 32) (_ bv2 32))) ((_ sign_extend 32) (bvmul in.020_32 (_ bv2 32)))) true)))
(let (($x9342 (or false false (or $x8528))))
(and (not $x9342) (or $x9342 (and (distinct (bvmul in.020_32 (_ bv2 32)) (bvmul in.020_32 (_ bv2 32))) true))))))
(check-sat)
; query 34: function core_state_transition, block 102, name %103
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x85 (or false false)))
(let (($x24 (not $x85)))
(and $x24 (or $x85 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 35: function core_state_transition, block 102, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1612 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x85 (or false false)))
(let (($x286 (or $x85 false false)))
(let (($x122 (not $x286)))
(and $x122 (or $x286 (and (distinct ?x1612 ?x1612) true))))))))
(check-sat)
; query 36: function core_state_transition, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x85 (or false false)))
(let (($x24 (not $x85)))
(and $x24 (or $x85 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 37: function core_state_transition, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x5471 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x85 (or false false)))
(let (($x286 (or $x85 false false)))
(let (($x122 (not $x286)))
(and $x122 (or $x286 (and (distinct ?x5471 ?x5471) true))))))))
(check-sat)
; query 38: function core_state_transition, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x85 (or false false)))
(let (($x24 (not $x85)))
(and $x24 (or $x85 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 39: function core_state_transition, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1612 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x85 (or false false)))
(let (($x286 (or $x85 false false)))
(let (($x122 (not $x286)))
(and $x122 (or $x286 (and (distinct ?x1612 ?x1612) true))))))))
(check-sat)
; query 40: function core_state_transition, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x85 (or false false)))
(let (($x24 (not $x85)))
(and $x24 (or $x85 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 41: function core_state_transition, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x9142 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x85 (or false false)))
(let (($x286 (or $x85 false false)))
(let (($x122 (not $x286)))
(and $x122 (or $x286 (and (distinct ?x9142 ?x9142) true))))))))
(check-sat)
; query 42: function core_state_transition, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x85 (or false false)))
(let (($x24 (not $x85)))
(and $x24 (or $x85 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 43: function core_state_transition, block 51, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x9142 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x85 (or false false)))
(let (($x286 (or $x85 false false)))
(let (($x122 (not $x286)))
(and $x122 (or $x286 (and (distinct ?x9142 ?x9142) true))))))))
(check-sat)
; query 44: function core_state_transition, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x85 (or false false)))
(let (($x24 (not $x85)))
(and $x24 (or $x85 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 45: function core_state_transition, block 64, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x9142 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x85 (or false false)))
(let (($x286 (or $x85 false false)))
(let (($x122 (not $x286)))
(and $x122 (or $x286 (and (distinct ?x9142 ?x9142) true))))))))
(check-sat)
; query 46: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x2872 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x521 (or false false false)))
(let (($x206 (not $x521)))
(and $x206 (or $x521 (and (distinct ?x2872 ?x2872) true)))))))
(check-sat)
; query 47: function core_state_transition, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x85 (or false false)))
(let (($x24 (not $x85)))
(and $x24 (or $x85 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 48: function core_state_transition, block 80, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x2640 (ite (= (_ bv69 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x85 (or false false)))
(let (($x286 (or $x85 false false)))
(let (($x122 (not $x286)))
(and $x122 (or $x286 (and (distinct ?x2640 ?x2640) true))))))))
(check-sat)
; query 49: function core_state_transition, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x85 (or false false)))
(let (($x24 (not $x85)))
(and $x24 (or $x85 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 50: function core_state_transition, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x5487 (ite (= (_ bv101 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x85 (or false false)))
(let (($x286 (or $x85 false false)))
(let (($x122 (not $x286)))
(and $x122 (or $x286 (and (distinct ?x5487 ?x5487) true))))))))
(check-sat)
; query 51: function core_state_transition, block 99, name %100
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x85 (or false false)))
(let (($x24 (not $x85)))
(and $x24 (or $x85 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 52: function core_state_transition, block 99, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x5471 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x85 (or false false)))
(let (($x286 (or $x85 false false)))
(let (($x122 (not $x286)))
(and $x122 (or $x286 (and (distinct ?x5471 ?x5471) true))))))))
(check-sat)
; query 53: function crcu8, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x85 (or false false)))
(let (($x24 (not $x85)))
(and $x24 (or $x85 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 54: function crcu8, block 19, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x370 ((_ zero_extend 16) in.01_16)))
(let ((?x119 (bvxor ?x370 (_ bv16386 32))))
(let (($x85 (or false false)))
(let (($x286 (or $x85 false false)))
(let (($x122 (not $x286)))
(and $x122 (or $x286 (and (distinct ?x119 ?x119) true)))))))))
(check-sat)
; query 55: function crcu8, block 19, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x370 ((_ zero_extend 16) in.01_16)))
(let ((?x119 (bvxor ?x370 (_ bv16386 32))))
(let ((?x5311 ((_ extract 15 0) ?x119)))
(let (($x85 (or false false)))
(let (($x286 (or $x85 false false)))
(let (($x10008 (or (or $x286 (or (and (distinct ((_ zero_extend 16) ?x5311) ?x119) true))) (and (distinct ?x5311 ?x5311) true))))
(let (($x333 (not (or $x286 false))))
(and $x333 $x10008)))))))))
(check-sat)
; query 56: function crcu8, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x4280 (or false (or (= ((_ extract 15 15) in27_16) (_ bv1 1))))))
(let (($x85 (or false false)))
(let (($x24 (not $x85)))
(and $x24 (or $x4280 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true)))))))
(check-sat)
; query 57: function crcu8, block 29, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x743 ((_ zero_extend 16) in27_16)))
(let ((?x6750 (bvor ?x743 (_ bv32768 32))))
(let (($x4280 (or false (or (= ((_ extract 15 15) in27_16) (_ bv1 1))))))
(let (($x1405 (or $x4280 false false)))
(let (($x85 (or false false)))
(let (($x286 (or $x85 false false)))
(let (($x122 (not $x286)))
(and $x122 (or $x1405 (and (distinct ?x6750 ?x6750) true)))))))))))
(check-sat)
; query 58: function crcu8, block 29, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x743 ((_ zero_extend 16) in27_16)))
(let ((?x6750 (bvor ?x743 (_ bv32768 32))))
(let ((?x1875 ((_ extract 15 0) ?x6750)))
(let (($x4280 (or false (or (= ((_ extract 15 15) in27_16) (_ bv1 1))))))
(let (($x1405 (or $x4280 false false)))
(let (($x1824 (or (or $x1405 (or (and (distinct ((_ zero_extend 16) ?x1875) ?x6750) true))) (and (distinct ?x1875 ?x1875) true))))
(let (($x333 (not (or (or (or false false) false false) false))))
(and $x333 $x1824)))))))))
(check-sat)
; query 59: function crcu8, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x9003 ((_ extract 7 0) in.01_16)))
(let ((?x2602 ((_ zero_extend 24) ?x9003)))
(let (($x85 (or false false)))
(let (($x5641 (or $x85 false)))
(and (not $x5641) (or $x5641 (and (distinct ?x2602 ?x2602) true))))))))
(check-sat)
; query 60: function crcu8, block 6, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x9003 ((_ extract 7 0) in.01_16)))
(let ((?x2602 ((_ zero_extend 24) ?x9003)))
(let ((?x8849 (bvand ?x2602 (_ bv1 32))))
(let (($x85 (or false false)))
(let (($x5641 (or $x85 false)))
(let (($x310 (or $x5641 false false)))
(and (not $x310) (or $x310 (and (distinct ?x8849 ?x8849) true))))))))))
(check-sat)
; query 61: function crcu8, block 6, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x9003 ((_ extract 7 0) in.01_16)))
(let ((?x2602 ((_ zero_extend 24) ?x9003)))
(let ((?x8849 (bvand ?x2602 (_ bv1 32))))
(let ((?x4740 ((_ zero_extend 24) in.0_8)))
(let ((?x1131 (bvand ?x4740 (_ bv1 32))))
(let ((?x9791 (bvxor ?x1131 ?x8849)))
(let (($x85 (or false false)))
(let (($x5641 (or $x85 false)))
(let (($x310 (or $x5641 false false)))
(let (($x286 (or $x85 false false)))
(let (($x5616 (or $x286 $x310 false)))
(and (not $x5616) (or $x5616 (and (distinct ?x9791 ?x9791) true)))))))))))))))
(check-sat)
; query 62: function crcu8, block 6, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x9003 ((_ extract 7 0) in.01_16)))
(let ((?x2602 ((_ zero_extend 24) ?x9003)))
(let ((?x8849 (bvand ?x2602 (_ bv1 32))))
(let ((?x4740 ((_ zero_extend 24) in.0_8)))
(let ((?x1131 (bvand ?x4740 (_ bv1 32))))
(let ((?x9791 (bvxor ?x1131 ?x8849)))
(let ((?x1987 ((_ extract 7 0) ?x9791)))
(let (($x9151 (or (and (distinct ((_ zero_extend 24) ?x1987) ?x9791) true) (and (distinct ((_ sign_extend 24) ?x1987) ?x9791) true))))
(let (($x85 (or false false)))
(let (($x5641 (or $x85 false)))
(let (($x310 (or $x5641 false false)))
(let (($x286 (or $x85 false false)))
(let (($x5616 (or $x286 $x310 false)))
(let (($x9148 (or $x5616 $x9151)))
(and (not (or $x5616 false)) (or $x9148 (and (distinct ?x1987 ?x1987) true))))))))))))))))))
(check-sat)
; query 63: function crcu8, block 6, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x85 (or false false)))
(let (($x24 (not $x85)))
(and $x24 (or $x85 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 64: function crcu8, block 6, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x4740 ((_ zero_extend 24) in.0_8)))
(let ((?x8245 (bvlshr ?x4740 (_ bv1 32))))
(let ((?x8540 (bvashr ?x4740 (_ bv1 32))))
(let (($x85 (or false false)))
(let (($x286 (or $x85 false false)))
(let (($x3310 (or $x286 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not $x3310) (or $x3310 (and (distinct ?x8540 ?x8245) true))))))))))
(check-sat)
; query 65: function crcu8, block 6, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x100 (and (distinct ((_ extract 7 0) (bvashr ((_ zero_extend 24) in.0_8) (_ bv1 32))) ((_ extract 7 0) (bvlshr ((_ zero_extend 24) in.0_8) (_ bv1 32)))) true)))
(let (($x85 (or false false)))
(let (($x286 (or $x85 false false)))
(let (($x3310 (or $x286 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x9701 (or $x3310 false)))
(and (not $x9701) (or $x9701 $x100))))))))
(check-sat)
; query 66: function crcu8, block 6, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x9003 ((_ extract 7 0) in.01_16)))
(let ((?x2602 ((_ zero_extend 24) ?x9003)))
(let ((?x8849 (bvand ?x2602 (_ bv1 32))))
(let ((?x4740 ((_ zero_extend 24) in.0_8)))
(let ((?x1131 (bvand ?x4740 (_ bv1 32))))
(let ((?x9791 (bvxor ?x1131 ?x8849)))
(let ((?x1987 ((_ extract 7 0) ?x9791)))
(let ((?x2171 ((_ zero_extend 24) ?x1987)))
(let (($x85 (or false false)))
(let (($x5641 (or $x85 false)))
(let (($x310 (or $x5641 false false)))
(let (($x286 (or $x85 false false)))
(let (($x5616 (or $x286 $x310 false)))
(let (($x9148 (or $x5616 (or (and (distinct ?x2171 ?x9791) true) (and (distinct ((_ sign_extend 24) ?x1987) ?x9791) true)))))
(let (($x289 (or $x9148 (or (= ((_ extract 7 7) ?x1987) (_ bv1 1))))))
(and (not (or (or $x5616 false) false)) (or $x289 (and (distinct ?x2171 ?x2171) true)))))))))))))))))))
(check-sat)
; query 67: function crcu8, block 6, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x9003 ((_ extract 7 0) in.01_16)))
(let ((?x2602 ((_ zero_extend 24) ?x9003)))
(let ((?x8849 (bvand ?x2602 (_ bv1 32))))
(let ((?x4740 ((_ zero_extend 24) in.0_8)))
(let ((?x1131 (bvand ?x4740 (_ bv1 32))))
(let ((?x9791 (bvxor ?x1131 ?x8849)))
(let ((?x1987 ((_ extract 7 0) ?x9791)))
(let ((?x2171 ((_ zero_extend 24) ?x1987)))
(let ((?x8659 (ite (= (_ bv1 32) ?x2171) (_ bv1 1) (_ bv0 1))))
(let (($x85 (or false false)))
(let (($x5641 (or $x85 false)))
(let (($x310 (or $x5641 false false)))
(let (($x286 (or $x85 false false)))
(let (($x5616 (or $x286 $x310 false)))
(let (($x9148 (or $x5616 (or (and (distinct ?x2171 ?x9791) true) (and (distinct ((_ sign_extend 24) ?x1987) ?x9791) true)))))
(let (($x289 (or $x9148 (or (= ((_ extract 7 7) ?x1987) (_ bv1 1))))))
(and (not (or (or (or $x5616 false) false) false false)) (or (or $x289 false false) (and (distinct ?x8659 ?x8659) true))))))))))))))))))))
(check-sat)
; query 68: function crcu8, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x85 (or false false)))
(let (($x24 (not $x85)))
(and $x24 (or $x85 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 69: function crcu8, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x4740 ((_ zero_extend 24) in.0_8)))
(let ((?x1131 (bvand ?x4740 (_ bv1 32))))
(let (($x85 (or false false)))
(let (($x286 (or $x85 false false)))
(let (($x122 (not $x286)))
(and $x122 (or $x286 (and (distinct ?x1131 ?x1131) true)))))))))
(check-sat)
; query 70: function crcu8, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x85 (or false false)))
(let (($x24 (not $x85)))
(and $x24 (or $x85 (and (distinct ((_ extract 7 0) in.01_16) ((_ extract 7 0) in.01_16)) true))))))
(check-sat)
; query 71: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x883 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x521 (or false false false)))
(let (($x206 (not $x521)))
(and $x206 (or $x521 (and (distinct ?x883 ?x883) true)))))))
(check-sat)
; query 72: function matrix_add_const, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x6800 (bvadd in.0_32 (_ bv1 32))))
(let (($x173 (and (distinct ?x6800 ?x6800) true)))
(let (($x521 (or false false false)))
(let (($x206 (not $x521)))
(and $x206 (or $x521 $x173)))))))
(check-sat)
; query 73: function matrix_add_const, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x198 (bvadd in.01_32 (_ bv1 32))))
(let (($x1785 (and (distinct ?x198 ?x198) true)))
(let (($x521 (or false false false)))
(let (($x206 (not $x521)))
(and $x206 (or $x521 $x1785)))))))
(check-sat)
; query 74: function matrix_mul_const, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x6800 (bvadd in.0_32 (_ bv1 32))))
(let (($x173 (and (distinct ?x6800 ?x6800) true)))
(let (($x521 (or false false false)))
(let (($x206 (not $x521)))
(and $x206 (or $x521 $x173)))))))
(check-sat)
; query 75: function matrix_mul_const, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x198 (bvadd in.01_32 (_ bv1 32))))
(let (($x1785 (and (distinct ?x198 ?x198) true)))
(let (($x521 (or false false false)))
(let (($x206 (not $x521)))
(and $x206 (or $x521 $x1785)))))))
(check-sat)
; query 76: function matrix_mul_matrix, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x6800 (bvadd in.0_32 (_ bv1 32))))
(let (($x173 (and (distinct ?x6800 ?x6800) true)))
(let (($x521 (or false false false)))
(let (($x206 (not $x521)))
(and $x206 (or $x521 $x173)))))))
(check-sat)
; query 77: function matrix_mul_matrix, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x198 (bvadd in.01_32 (_ bv1 32))))
(let (($x1785 (and (distinct ?x198 ?x198) true)))
(let (($x521 (or false false false)))
(let (($x206 (not $x521)))
(and $x206 (or $x521 $x1785)))))))
(check-sat)
; query 78: function matrix_mul_matrix, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x521 (or false false false)))
(let (($x206 (not $x521)))
(and $x206 (or $x521 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 79: function matrix_mul_matrix_bitextract, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x6800 (bvadd in.0_32 (_ bv1 32))))
(let (($x173 (and (distinct ?x6800 ?x6800) true)))
(let (($x521 (or false false false)))
(let (($x206 (not $x521)))
(and $x206 (or $x521 $x173)))))))
(check-sat)
; query 80: function matrix_mul_matrix_bitextract, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x198 (bvadd in.01_32 (_ bv1 32))))
(let (($x1785 (and (distinct ?x198 ?x198) true)))
(let (($x521 (or false false false)))
(let (($x206 (not $x521)))
(and $x206 (or $x521 $x1785)))))))
(check-sat)
; query 81: function matrix_mul_matrix_bitextract, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x521 (or false false false)))
(let (($x206 (not $x521)))
(and $x206 (or $x521 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 82: function matrix_mul_vect, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x6800 (bvadd in.0_32 (_ bv1 32))))
(let (($x173 (and (distinct ?x6800 ?x6800) true)))
(let (($x521 (or false false false)))
(let (($x206 (not $x521)))
(and $x206 (or $x521 $x173)))))))
(check-sat)
; query 83: function matrix_mul_vect, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x198 (bvadd in.01_32 (_ bv1 32))))
(let (($x1785 (and (distinct ?x198 ?x198) true)))
(let (($x521 (or false false false)))
(let (($x206 (not $x521)))
(and $x206 (or $x521 $x1785)))))))
(check-sat)
; query 84: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x85 (or false false)))
(let (($x24 (not $x85)))
(and $x24 (or $x85 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 85: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x8023 ((_ sign_extend 16) in.1_16)))
(let ((?x98 (bvadd ?x8023 (_ bv10 32))))
(let (($x6161 (and (distinct (bvadd ((_ sign_extend 1) ?x8023) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x98)) true)))
(let (($x85 (or false false)))
(let (($x993 (or $x85 false (or $x6161))))
(and (not $x993) (or $x993 (and (distinct ?x98 ?x98) true)))))))))
(check-sat)
; query 86: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x8023 ((_ sign_extend 16) in.1_16)))
(let ((?x98 (bvadd ?x8023 (_ bv10 32))))
(let ((?x4789 ((_ extract 15 0) ?x98)))
(let (($x6161 (and (distinct (bvadd ((_ sign_extend 1) ?x8023) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x98)) true)))
(let (($x85 (or false false)))
(let (($x993 (or $x85 false (or $x6161))))
(let (($x1335 (or $x993 false)))
(and (not $x1335) (or $x1335 (and (distinct ?x4789 ?x4789) true)))))))))))
(check-sat)
; query 87: function parseval, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.23_32 () (_ BitVec 32))
(assert
 (let (($x973 (and (distinct (bvmul ((_ sign_extend 32) in.23_32) ((_ sign_extend 32) (_ bv1024 32))) ((_ sign_extend 32) (bvmul in.23_32 (_ bv1024 32)))) true)))
(let (($x2376 (or false false (or $x973))))
(and (not $x2376) (or $x2376 (and (distinct (bvmul in.23_32 (_ bv1024 32)) (bvmul in.23_32 (_ bv1024 32))) true))))))
(check-sat)
; query 88: function parseval, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.34_32 () (_ BitVec 32))
(assert
 (let (($x9251 (and (distinct (bvmul ((_ sign_extend 32) in.34_32) ((_ sign_extend 32) (_ bv1048576 32))) ((_ sign_extend 32) (bvmul in.34_32 (_ bv1048576 32)))) true)))
(let (($x1669 (or false false (or $x9251))))
(and (not $x1669) (or $x1669 (and (distinct (bvmul in.34_32 (_ bv1048576 32)) (bvmul in.34_32 (_ bv1048576 32))) true))))))
(check-sat)
; query 89: function partition_memory, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x6800 (bvadd in.0_32 (_ bv1 32))))
(let (($x173 (and (distinct ?x6800 ?x6800) true)))
(let (($x1742 (and (distinct (bvadd ((_ zero_extend 1) in.0_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) ?x6800)) true)))
(let (($x161 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x6800)) true)))
(let (($x521 (or false false false)))
(let (($x206 (not $x521)))
(and $x206 (or (or false false (or $x161 $x1742)) $x173)))))))))
(check-sat)
; query 90: function run_matrix_multiply, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x521 (or false false false)))
(let (($x206 (not $x521)))
(and $x206 (or $x521 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 91: function run_matrix_multiply, block 34, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x198 (bvadd in.01_32 (_ bv1 32))))
(let (($x1785 (and (distinct ?x198 ?x198) true)))
(let (($x521 (or false false false)))
(let (($x206 (not $x521)))
(and $x206 (or $x521 $x1785)))))))
(check-sat)
