; OptiPhase-Sigma refinement certificate for sweep K45-R4-366
; query 0: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x555 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x139 (or false false false)))
(let (($x75 (not $x139)))
(and $x75 (or $x139 (and (distinct ?x555 ?x555) true)))))))
(check-sat)
; query 1: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x36 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x139 (or false false false)))
(let (($x75 (not $x139)))
(and $x75 (or $x139 (and (distinct ?x36 ?x36) true)))))))
(check-sat)
