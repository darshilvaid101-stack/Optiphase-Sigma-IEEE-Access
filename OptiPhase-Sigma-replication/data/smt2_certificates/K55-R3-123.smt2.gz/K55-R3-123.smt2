; OptiPhase-Sigma refinement certificate for sweep K55-R3-123
; query 0: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x996 (or false false false)))
(let (($x148 (not $x996)))
(and $x148 (or $x996 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x609 (bvadd in.01_32 (_ bv1 32))))
(let ((?x96 (bvmul ?x609 ?x609)))
(let (($x996 (or false false false)))
(let (($x45 (or $x996 $x996 false)))
(and (not $x45) (or $x45 (and (distinct ?x96 ?x96) true))))))))
(check-sat)
; query 2: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x609 (bvadd in.01_32 (_ bv1 32))))
(let ((?x96 (bvmul ?x609 ?x609)))
(let ((?x190 (bvmul ?x96 (_ bv2 32))))
(let (($x996 (or false false false)))
(let (($x45 (or $x996 $x996 false)))
(let (($x490 (or $x45 false false)))
(and (not $x490) (or $x490 (and (distinct ?x190 ?x190) true))))))))))
(check-sat)
; query 3: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x609 (bvadd in.01_32 (_ bv1 32))))
(let ((?x96 (bvmul ?x609 ?x609)))
(let ((?x190 (bvmul ?x96 (_ bv2 32))))
(let ((?x599 (bvmul ?x190 (_ bv4 32))))
(let (($x996 (or false false false)))
(let (($x45 (or $x996 $x996 false)))
(let (($x490 (or $x45 false false)))
(let (($x90 (or $x490 false false)))
(and (not $x90) (or $x90 (and (distinct ?x599 ?x599) true))))))))))))
(check-sat)
; query 4: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x77 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x996 (or false false false)))
(let (($x148 (not $x996)))
(and $x148 (or $x996 (and (distinct ?x77 ?x77) true)))))))
(check-sat)
; query 5: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x159 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x996 (or false false false)))
(let (($x148 (not $x996)))
(and $x148 (or $x996 (and (distinct ?x159 ?x159) true)))))))
(check-sat)
; query 6: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x996 (or false false false)))
(let (($x148 (not $x996)))
(and $x148 (or $x996 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 7: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x662 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x59 (or false false (or $x662))))
(and (not $x59) (or $x59 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x760 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x996 (or false false false)))
(let (($x148 (not $x996)))
(and $x148 (or $x996 (and (distinct ?x760 ?x760) true)))))))
(check-sat)
; query 9: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x544 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x996 (or false false false)))
(let (($x148 (not $x996)))
(and $x148 (or $x996 (and (distinct ?x544 ?x544) true)))))))
(check-sat)
; query 10: function matrix_add_const, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x996 (or false false false)))
(let (($x148 (not $x996)))
(and $x148 (or $x996 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 11: function matrix_add_const, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x996 (or false false false)))
(let (($x148 (not $x996)))
(and $x148 (or $x996 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 12: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x114 (or false false)))
(and (not $x114) (or $x114 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true)))))
(check-sat)
; query 13: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x420 ((_ sign_extend 16) in.1_16)))
(let ((?x181 (bvadd ?x420 (_ bv10 32))))
(let (($x24 (and (distinct (bvadd ((_ sign_extend 1) ?x420) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x181)) true)))
(let (($x114 (or false false)))
(let (($x25 (or $x114 false (or $x24))))
(and (not $x25) (or $x25 (and (distinct ?x181 ?x181) true)))))))))
(check-sat)
; query 14: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x420 ((_ sign_extend 16) in.1_16)))
(let ((?x181 (bvadd ?x420 (_ bv10 32))))
(let ((?x927 ((_ extract 15 0) ?x181)))
(let (($x24 (and (distinct (bvadd ((_ sign_extend 1) ?x420) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x181)) true)))
(let (($x114 (or false false)))
(let (($x25 (or $x114 false (or $x24))))
(let (($x509 (or $x25 false)))
(and (not $x509) (or $x509 (and (distinct ?x927 ?x927) true)))))))))))
(check-sat)
