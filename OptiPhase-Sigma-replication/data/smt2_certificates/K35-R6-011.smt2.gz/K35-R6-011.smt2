; OptiPhase-Sigma refinement certificate for sweep K35-R6-011
; query 0: function corner_draw, block 11, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x759 (ite (= (_ bv0 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x54 (or false false false)))
(let (($x12 (not $x54)))
(and $x12 (or $x54 (and (distinct ?x759 ?x759) true)))))))
(check-sat)
; query 1: function edge_draw, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let ((?x228 (ite (= (_ bv0 32) in4_32) (_ bv1 1) (_ bv0 1))))
(let (($x54 (or false false false)))
(let (($x12 (not $x54)))
(and $x12 (or $x54 (and (distinct ?x228 ?x228) true)))))))
(check-sat)
; query 2: function getint, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x552 (and (distinct (ite (bvsle (_ bv48 32) in.02_32) (_ bv1 1) (_ bv0 1)) (ite (bvsge (_ bv57 32) in.02_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x54 (or false false false)))
(let (($x12 (not $x54)))
(and $x12 (or $x54 $x552))))))
(check-sat)
; query 3: function main, block 35, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x271 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x326 (or false false (or $x271))))
(and (not $x326) (or $x326 (and (distinct (bvadd in.020_32 (_ bv1 32)) (bvadd in.020_32 (_ bv1 32))) true))))))
(check-sat)
; query 4: function main, block 35, name %37
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let ((?x583 (ite (bvsge (bvadd in.020_32 (_ bv1 32)) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x271 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x326 (or false false (or $x271))))
(let (($x35 (or $x326 false false)))
(and (not $x35) (or $x35 (and (distinct ?x583 ?x583) true))))))))
(check-sat)
