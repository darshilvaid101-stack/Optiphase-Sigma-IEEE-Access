; OptiPhase-Sigma refinement certificate for sweep K49-R5-401
; query 0: function Decoding_of_the_coded_Log_Area_Ratios, block 107, name %108
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in104_64 () (_ BitVec 64))
(assert
 (let ((?x564 (ite (bvslt (_ bv0 64) in104_64) (_ bv1 1) (_ bv0 1))))
(let (($x622 (or false false false)))
(let (($x37 (not $x622)))
(and $x37 (or $x622 (and (distinct ?x564 ?x564) true)))))))
(check-sat)
; query 1: function Decoding_of_the_coded_Log_Area_Ratios, block 107, name %109
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in104_64 () (_ BitVec 64))
(assert
 (let (($x514 (and (distinct ((_ zero_extend 63) (ite (bvslt (_ bv0 64) in104_64) (_ bv1 1) (_ bv0 1))) (ite (= (_ bv1 1) (ite (bvslt (_ bv0 64) in104_64) (_ bv1 1) (_ bv0 1))) (_ bv32767 64) (_ bv18446744073709518848 64))) true)))
(let (($x622 (or false false false)))
(let (($x426 (or $x622 (ite (= (_ bv1 1) (ite (bvslt (_ bv0 64) in104_64) (_ bv1 1) (_ bv0 1))) false false))))
(and (not (or $x622 false)) (or $x426 $x514))))))
(check-sat)
; query 2: function Decoding_of_the_coded_Log_Area_Ratios, block 219, name %220
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in216_64 () (_ BitVec 64))
(assert
 (let (($x2784 (and (distinct (ite (bvsge (_ bv18446744073709518848 64) in216_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv0 64) in216_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x622 (or false false false)))
(let (($x37 (not $x622)))
(and $x37 (or $x622 $x2784))))))
(check-sat)
; query 3: function alaw_input, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x226 (and (distinct (bvadd ((_ zero_extend 1) in.02_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x572 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x159 (or (or false false (or $x572 $x226)) (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))
(and (not (or false false (or $x572))) $x159)))))
(check-sat)
; query 4: function gsm_L_add, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let (($x405 (and (distinct (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv18446744073709551615 64) in1_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x622 (or false false false)))
(let (($x37 (not $x622)))
(and $x37 (or $x622 $x405))))))
(check-sat)
; query 5: function gsm_L_add, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x753 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvadd in0_64 in1_64))) true)))
(let (($x63 (or false false (or $x753))))
(let (($x96 (or $x63 (and (distinct (bvadd in0_64 in1_64) (bvadd in0_64 in1_64)) true))))
(and (not $x63) $x96)))))
(check-sat)
; query 6: function gsm_L_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x543 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x622 (or false false false)))
(let (($x37 (not $x622)))
(and $x37 (or $x622 (and (distinct ?x543 ?x543) true)))))))
(check-sat)
; query 7: function gsm_L_asl, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x51 (and (distinct (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvsgt (_ bv4294967265 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x622 (or false false false)))
(let (($x37 (not $x622)))
(and $x37 (or $x622 $x51))))))
(check-sat)
; query 8: function gsm_L_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x389 (and (distinct (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv31 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x622 (or false false false)))
(let (($x37 (not $x622)))
(and $x37 (or $x622 $x389))))))
(check-sat)
; query 9: function gsm_L_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x389 (and (distinct (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv31 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x622 (or false false false)))
(let (($x37 (not $x622)))
(and $x37 (or $x622 $x389))))))
(check-sat)
; query 10: function gsm_L_sub, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x70 (bvsub in0_64 in1_64)))
(let (($x509 (and (distinct ?x70 ?x70) true)))
(let (($x33 (and (distinct (bvsub ((_ zero_extend 1) in0_64) ((_ zero_extend 1) in1_64)) ((_ zero_extend 1) ?x70)) true)))
(let (($x616 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) ?x70)) true)))
(let (($x760 (or false false (or $x616))))
(let (($x178 (not $x760)))
(and $x178 (or (or false false (or $x33)) $x509)))))))))
(check-sat)
; query 11: function gsm_L_sub, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let (($x405 (and (distinct (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv18446744073709551615 64) in1_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x622 (or false false false)))
(let (($x37 (not $x622)))
(and $x37 (or $x622 $x405))))))
(check-sat)
; query 12: function gsm_L_sub, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x70 (bvsub in0_64 in1_64)))
(let (($x509 (and (distinct ?x70 ?x70) true)))
(let (($x616 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) ?x70)) true)))
(let (($x760 (or false false (or $x616))))
(let (($x178 (not $x760)))
(and $x178 (or $x760 $x509))))))))
(check-sat)
; query 13: function gsm_L_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x407 (and (distinct (ite (bvsle (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv18446744073709551615 64) in0_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x622 (or false false false)))
(let (($x37 (not $x622)))
(and $x37 (or $x622 $x407))))))
(check-sat)
; query 14: function gsm_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_64 () (_ BitVec 64))
(assert
 (let ((?x83 (ite (bvslt (_ bv32767 64) in5_64) (_ bv1 1) (_ bv0 1))))
(let (($x622 (or false false false)))
(let (($x37 (not $x622)))
(and $x37 (or $x622 (and (distinct ?x83 ?x83) true)))))))
(check-sat)
; query 15: function gsm_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x281 (or false false)))
(let (($x153 (not $x281)))
(and $x153 (or $x281 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 16: function gsm_add, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x281 (or false false)))
(let (($x153 (not $x281)))
(and $x153 (or $x281 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 17: function gsm_add, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x146 ((_ sign_extend 48) in1_16)))
(let ((?x62 ((_ sign_extend 48) in0_16)))
(let ((?x2313 (bvadd ?x62 ?x146)))
(let (($x704 (and (distinct (bvadd ((_ sign_extend 1) ?x62) ((_ sign_extend 1) ?x146)) ((_ sign_extend 1) ?x2313)) true)))
(let (($x281 (or false false)))
(let (($x166 (or $x281 $x281 (or $x704))))
(and (not $x166) (or $x166 (and (distinct ?x2313 ?x2313) true))))))))))
(check-sat)
; query 18: function gsm_add, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x202 (ite (bvsgt (_ bv18446744073709518848 64) (bvadd ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x146 ((_ sign_extend 48) in1_16)))
(let ((?x313 ((_ sign_extend 1) ?x146)))
(let ((?x62 ((_ sign_extend 48) in0_16)))
(let ((?x2783 ((_ sign_extend 1) ?x62)))
(let (($x281 (or false false)))
(let (($x166 (or $x281 $x281 (or (and (distinct (bvadd ?x2783 ?x313) ((_ sign_extend 1) (bvadd ?x62 ?x146))) true)))))
(let (($x59 (or $x166 false false)))
(and (not $x59) (or $x59 (and (distinct ?x202 ?x202) true))))))))))))
(check-sat)
; query 19: function gsm_asl, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x309 (and (distinct (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvsgt (_ bv4294967281 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x622 (or false false false)))
(let (($x37 (not $x622)))
(and $x37 (or $x622 $x309))))))
(check-sat)
; query 20: function gsm_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x920 (and (distinct (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv15 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x622 (or false false false)))
(let (($x37 (not $x622)))
(and $x37 (or $x622 $x920))))))
(check-sat)
; query 21: function gsm_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x920 (and (distinct (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv15 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x622 (or false false false)))
(let (($x37 (not $x622)))
(and $x37 (or $x622 $x920))))))
(check-sat)
; query 22: function gsm_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_64 () (_ BitVec 64))
(assert
 (let ((?x83 (ite (bvslt (_ bv32767 64) in5_64) (_ bv1 1) (_ bv0 1))))
(let (($x622 (or false false false)))
(let (($x37 (not $x622)))
(and $x37 (or $x622 (and (distinct ?x83 ?x83) true)))))))
(check-sat)
; query 23: function gsm_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x281 (or false false)))
(let (($x153 (not $x281)))
(and $x153 (or $x281 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 24: function gsm_sub, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x281 (or false false)))
(let (($x153 (not $x281)))
(and $x153 (or $x281 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 25: function gsm_sub, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x146 ((_ sign_extend 48) in1_16)))
(let ((?x62 ((_ sign_extend 48) in0_16)))
(let ((?x348 (bvsub ?x62 ?x146)))
(let (($x912 (and (distinct (bvsub ((_ sign_extend 1) ?x62) ((_ sign_extend 1) ?x146)) ((_ sign_extend 1) ?x348)) true)))
(let (($x281 (or false false)))
(let (($x724 (or $x281 $x281 (or $x912))))
(and (not $x724) (or $x724 (and (distinct ?x348 ?x348) true))))))))))
(check-sat)
; query 26: function gsm_sub, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x259 (ite (bvsgt (_ bv18446744073709518848 64) (bvsub ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x146 ((_ sign_extend 48) in1_16)))
(let ((?x313 ((_ sign_extend 1) ?x146)))
(let ((?x62 ((_ sign_extend 48) in0_16)))
(let ((?x2783 ((_ sign_extend 1) ?x62)))
(let (($x281 (or false false)))
(let (($x724 (or $x281 $x281 (or (and (distinct (bvsub ?x2783 ?x313) ((_ sign_extend 1) (bvsub ?x62 ?x146))) true)))))
(let (($x490 (or $x724 false false)))
(and (not $x490) (or $x490 (and (distinct ?x259 ?x259) true))))))))))))
(check-sat)
; query 27: function ulaw_input, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x226 (and (distinct (bvadd ((_ zero_extend 1) in.02_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x572 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x159 (or (or false false (or $x572 $x226)) (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))
(and (not (or false false (or $x572))) $x159)))))
(check-sat)
