; OptiPhase-Sigma refinement certificate for sweep K34-R4-338
; query 0: function edge_draw, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let ((?x884 (ite (= (_ bv0 32) in4_32) (_ bv1 1) (_ bv0 1))))
(let (($x450 (or false false false)))
(and (not $x450) (or $x450 (and (distinct ?x884 ?x884) true))))))
(check-sat)
