; OptiPhase-Sigma refinement certificate for sweep K13-R3-166
; query 0: function xmalloc, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in7_32 () (_ BitVec 32))
(assert
 (let ((?x123 (ite (and (distinct (_ bv0 32) in7_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x11 (or false false false)))
(and (not $x11) (or $x11 (and (distinct ?x123 ?x123) true))))))
(check-sat)
