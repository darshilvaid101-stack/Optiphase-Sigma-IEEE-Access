; OptiPhase-Sigma refinement certificate for sweep K37-R6-011
; query 0: function bit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x326 (and (distinct (bvsub ((_ sign_extend 1) (_ bv31 32)) ((_ sign_extend 1) in0_32)) ((_ sign_extend 1) (bvsub (_ bv31 32) in0_32))) true)))
(let (($x134 (or false false (or $x326))))
(and (not $x134) (or $x134 (and (distinct (bvsub (_ bv31 32) in0_32) (bvsub (_ bv31 32) in0_32)) true))))))
(check-sat)
; query 1: function bit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x286 (bvsub (_ bv31 32) in0_32)))
(let ((?x12 (bvshl (_ bv1 32) ?x286)))
(let (($x326 (and (distinct (bvsub ((_ sign_extend 1) (_ bv31 32)) ((_ sign_extend 1) in0_32)) ((_ sign_extend 1) ?x286)) true)))
(let (($x134 (or false false (or $x326))))
(let (($x235 (or (or false $x134 false) (bvuge ?x286 (_ bv32 32)))))
(and (not $x235) (or $x235 (and (distinct ?x12 ?x12) true)))))))))
(check-sat)
; query 2: function bit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x286 (bvsub (_ bv31 32) in0_32)))
(let ((?x12 (bvshl (_ bv1 32) ?x286)))
(let ((?x450 ((_ sign_extend 32) ?x12)))
(let (($x326 (and (distinct (bvsub ((_ sign_extend 1) (_ bv31 32)) ((_ sign_extend 1) in0_32)) ((_ sign_extend 1) ?x286)) true)))
(let (($x134 (or false false (or $x326))))
(let (($x235 (or (or false $x134 false) (bvuge ?x286 (_ bv32 32)))))
(let (($x506 (or $x235 false)))
(and (not $x506) (or $x506 (and (distinct ?x450 ?x450) true)))))))))))
(check-sat)
; query 3: function bit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x286 (bvsub (_ bv31 32) in0_32)))
(let ((?x12 (bvshl (_ bv1 32) ?x286)))
(let ((?x450 ((_ sign_extend 32) ?x12)))
(let ((?x99 (bvand in1_64 ?x450)))
(let (($x326 (and (distinct (bvsub ((_ sign_extend 1) (_ bv31 32)) ((_ sign_extend 1) in0_32)) ((_ sign_extend 1) ?x286)) true)))
(let (($x134 (or false false (or $x326))))
(let (($x235 (or (or false $x134 false) (bvuge ?x286 (_ bv32 32)))))
(let (($x506 (or $x235 false)))
(let (($x759 (or false $x506 false)))
(and (not $x759) (or $x759 (and (distinct ?x99 ?x99) true)))))))))))))
(check-sat)
