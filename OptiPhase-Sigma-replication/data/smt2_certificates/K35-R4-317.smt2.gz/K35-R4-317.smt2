; OptiPhase-Sigma refinement certificate for sweep K35-R4-317
; query 0: function corner_draw, block 11, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x70 (ite (= (_ bv0 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x112 (or false false false)))
(let (($x423 (not $x112)))
(and $x423 (or $x112 (and (distinct ?x70 ?x70) true)))))))
(check-sat)
; query 1: function edge_draw, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let ((?x114 (ite (= (_ bv0 32) in4_32) (_ bv1 1) (_ bv0 1))))
(let (($x112 (or false false false)))
(let (($x423 (not $x112)))
(and $x423 (or $x112 (and (distinct ?x114 ?x114) true)))))))
(check-sat)
; query 2: function main, block 35, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x196 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x993 (or false false (or $x196))))
(and (not $x993) (or $x993 (and (distinct (bvadd in.020_32 (_ bv1 32)) (bvadd in.020_32 (_ bv1 32))) true))))))
(check-sat)
; query 3: function main, block 35, name %37
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let ((?x247 (ite (bvsge (bvadd in.020_32 (_ bv1 32)) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x196 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x993 (or false false (or $x196))))
(let (($x350 (or $x993 false false)))
(and (not $x350) (or $x350 (and (distinct ?x247 ?x247) true))))))))
(check-sat)
