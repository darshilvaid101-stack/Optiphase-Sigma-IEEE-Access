; OptiPhase-Sigma refinement certificate for sweep K51-R3-160
; query 0: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x65 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x397 (or false false false)))
(let (($x545 (not $x397)))
(and $x545 (or $x397 (and (distinct ?x65 ?x65) true)))))))
(check-sat)
; query 1: function set1d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x944 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x397 (or false false false)))
(let (($x545 (not $x397)))
(and $x545 (or $x397 (and (distinct ?x944 ?x944) true)))))))
(check-sat)
; query 2: function set1ds, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x385 (ite (= (_ bv4294967295 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x397 (or false false false)))
(let (($x545 (not $x397)))
(and $x545 (or $x397 (and (distinct ?x385 ?x385) true)))))))
(check-sat)
; query 3: function set2d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x944 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x397 (or false false false)))
(let (($x545 (not $x397)))
(and $x545 (or $x397 (and (distinct ?x944 ?x944) true)))))))
(check-sat)
