; OptiPhase-Sigma refinement certificate for sweep K48-R3-286
; query 0: function APCM_inverse_quantization, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in53_16) ((_ sign_extend 16) in53_16)) true))))))
(check-sat)
; query 1: function APCM_inverse_quantization, block 56, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let ((?x130 (ite (bvsle (_ bv4294967289 32) ((_ sign_extend 16) in53_16)) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x140 (not $x640)))
(and $x140 (or $x640 (and (distinct ?x130 ?x130) true))))))))
(check-sat)
; query 2: function APCM_inverse_quantization, block 68, name %69
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in53_16) ((_ sign_extend 16) in53_16)) true))))))
(check-sat)
; query 3: function APCM_inverse_quantization, block 68, name %70
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let ((?x29 ((_ sign_extend 16) in53_16)))
(let ((?x313 (bvshl ?x29 (_ bv12 32))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x67 (or $x640 (bvuge (_ bv12 32) (_ bv32 32)))))
(and (not $x67) (or $x67 (and (distinct ?x313 ?x313) true)))))))))
(check-sat)
; query 4: function APCM_inverse_quantization, block 68, name %71
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let ((?x29 ((_ sign_extend 16) in53_16)))
(let ((?x313 (bvshl ?x29 (_ bv12 32))))
(let ((?x26 ((_ extract 15 0) ?x313)))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x67 (or $x640 (bvuge (_ bv12 32) (_ bv32 32)))))
(let (($x1429 (or $x67 false)))
(and (not $x1429) (or $x1429 (and (distinct ?x26 ?x26) true)))))))))))
(check-sat)
; query 5: function APCM_inverse_quantization, block 68, name %72
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in22_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 48) in22_16) ((_ sign_extend 48) in22_16)) true))))))
(check-sat)
; query 6: function APCM_inverse_quantization, block 68, name %73
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let ((?x29 ((_ sign_extend 16) in53_16)))
(let ((?x313 (bvshl ?x29 (_ bv12 32))))
(let ((?x26 ((_ extract 15 0) ?x313)))
(let ((?x82 ((_ sign_extend 48) ?x26)))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x67 (or $x640 (bvuge (_ bv12 32) (_ bv32 32)))))
(let (($x1429 (or $x67 false)))
(let (($x198 (or $x1429 false)))
(and (not $x198) (or $x198 (and (distinct ?x82 ?x82) true)))))))))))))
(check-sat)
; query 7: function APCM_inverse_quantization, block 68, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in22_16 () (_ BitVec 16))
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let ((?x24 ((_ sign_extend 48) in22_16)))
(let ((?x29 ((_ sign_extend 16) in53_16)))
(let ((?x313 (bvshl ?x29 (_ bv12 32))))
(let ((?x26 ((_ extract 15 0) ?x313)))
(let ((?x82 ((_ sign_extend 48) ?x26)))
(let ((?x147 (bvmul ?x82 ?x24)))
(let ((?x90 (bvmul ?x24 ?x82)))
(let (($x74 (and (distinct (bvmul ((_ sign_extend 64) ?x82) ((_ sign_extend 64) ?x24)) ((_ sign_extend 64) ?x147)) true)))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x67 (or $x640 (bvuge (_ bv12 32) (_ bv32 32)))))
(let (($x1429 (or $x67 false)))
(let (($x198 (or $x1429 false)))
(let (($x566 (or $x198 $x64 (or $x74))))
(let (($x336 (and (distinct (bvmul ((_ sign_extend 64) ?x24) ((_ sign_extend 64) ?x82)) ((_ sign_extend 64) ?x90)) true)))
(let (($x524 (or $x64 $x198 (or $x336))))
(and (not $x524) (or $x566 (and (distinct ?x90 ?x147) true))))))))))))))))))))
(check-sat)
; query 8: function APCM_inverse_quantization, block 68, name %75
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in22_16 () (_ BitVec 16))
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let ((?x24 ((_ sign_extend 48) in22_16)))
(let ((?x29 ((_ sign_extend 16) in53_16)))
(let ((?x313 (bvshl ?x29 (_ bv12 32))))
(let ((?x26 ((_ extract 15 0) ?x313)))
(let ((?x82 ((_ sign_extend 48) ?x26)))
(let ((?x147 (bvmul ?x82 ?x24)))
(let ((?x227 (bvadd ?x147 (_ bv16384 64))))
(let ((?x90 (bvmul ?x24 ?x82)))
(let ((?x411 (bvadd ?x90 (_ bv16384 64))))
(let (($x359 (and (distinct (bvadd ((_ sign_extend 1) ?x147) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x227)) true)))
(let (($x74 (and (distinct (bvmul ((_ sign_extend 64) ?x82) ((_ sign_extend 64) ?x24)) ((_ sign_extend 64) ?x147)) true)))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x67 (or $x640 (bvuge (_ bv12 32) (_ bv32 32)))))
(let (($x1429 (or $x67 false)))
(let (($x198 (or $x1429 false)))
(let (($x566 (or $x198 $x64 (or $x74))))
(let (($x645 (or $x566 false (or $x359))))
(let (($x487 (and (distinct (bvadd ((_ sign_extend 1) ?x90) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x411)) true)))
(let (($x336 (and (distinct (bvmul ((_ sign_extend 64) ?x24) ((_ sign_extend 64) ?x82)) ((_ sign_extend 64) ?x90)) true)))
(let (($x524 (or $x64 $x198 (or $x336))))
(let (($x778 (or $x524 false (or $x487))))
(and (not $x778) (or $x645 (and (distinct ?x411 ?x227) true))))))))))))))))))))))))))
(check-sat)
; query 9: function APCM_inverse_quantization, block 68, name %76
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in22_16 () (_ BitVec 16))
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let ((?x24 ((_ sign_extend 48) in22_16)))
(let ((?x29 ((_ sign_extend 16) in53_16)))
(let ((?x313 (bvshl ?x29 (_ bv12 32))))
(let ((?x26 ((_ extract 15 0) ?x313)))
(let ((?x82 ((_ sign_extend 48) ?x26)))
(let ((?x147 (bvmul ?x82 ?x24)))
(let ((?x227 (bvadd ?x147 (_ bv16384 64))))
(let ((?x488 (bvashr ?x227 (_ bv15 64))))
(let ((?x90 (bvmul ?x24 ?x82)))
(let ((?x411 (bvadd ?x90 (_ bv16384 64))))
(let ((?x759 (bvashr ?x411 (_ bv15 64))))
(let (($x114 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x359 (and (distinct (bvadd ((_ sign_extend 1) ?x147) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x227)) true)))
(let (($x74 (and (distinct (bvmul ((_ sign_extend 64) ?x82) ((_ sign_extend 64) ?x24)) ((_ sign_extend 64) ?x147)) true)))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x67 (or $x640 (bvuge (_ bv12 32) (_ bv32 32)))))
(let (($x1429 (or $x67 false)))
(let (($x198 (or $x1429 false)))
(let (($x566 (or $x198 $x64 (or $x74))))
(let (($x645 (or $x566 false (or $x359))))
(let (($x7 (or (or $x645 false false) $x114)))
(let (($x487 (and (distinct (bvadd ((_ sign_extend 1) ?x90) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x411)) true)))
(let (($x336 (and (distinct (bvmul ((_ sign_extend 64) ?x24) ((_ sign_extend 64) ?x82)) ((_ sign_extend 64) ?x90)) true)))
(let (($x524 (or $x64 $x198 (or $x336))))
(let (($x778 (or $x524 false (or $x487))))
(let (($x117 (or (or $x778 false false) $x114)))
(and (not $x117) (or $x7 (and (distinct ?x759 ?x488) true)))))))))))))))))))))))))))))))
(check-sat)
; query 10: function APCM_inverse_quantization, block 68, name %77
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in22_16 () (_ BitVec 16))
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let ((?x24 ((_ sign_extend 48) in22_16)))
(let ((?x29 ((_ sign_extend 16) in53_16)))
(let ((?x313 (bvshl ?x29 (_ bv12 32))))
(let ((?x26 ((_ extract 15 0) ?x313)))
(let ((?x82 ((_ sign_extend 48) ?x26)))
(let ((?x147 (bvmul ?x82 ?x24)))
(let ((?x227 (bvadd ?x147 (_ bv16384 64))))
(let ((?x488 (bvashr ?x227 (_ bv15 64))))
(let ((?x725 ((_ extract 15 0) ?x488)))
(let ((?x90 (bvmul ?x24 ?x82)))
(let ((?x411 (bvadd ?x90 (_ bv16384 64))))
(let ((?x759 (bvashr ?x411 (_ bv15 64))))
(let ((?x327 ((_ extract 15 0) ?x759)))
(let (($x114 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x359 (and (distinct (bvadd ((_ sign_extend 1) ?x147) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x227)) true)))
(let (($x74 (and (distinct (bvmul ((_ sign_extend 64) ?x82) ((_ sign_extend 64) ?x24)) ((_ sign_extend 64) ?x147)) true)))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x67 (or $x640 (bvuge (_ bv12 32) (_ bv32 32)))))
(let (($x1429 (or $x67 false)))
(let (($x198 (or $x1429 false)))
(let (($x566 (or $x198 $x64 (or $x74))))
(let (($x645 (or $x566 false (or $x359))))
(let (($x7 (or (or $x645 false false) $x114)))
(let (($x368 (or $x7 false)))
(let (($x487 (and (distinct (bvadd ((_ sign_extend 1) ?x90) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x411)) true)))
(let (($x336 (and (distinct (bvmul ((_ sign_extend 64) ?x24) ((_ sign_extend 64) ?x82)) ((_ sign_extend 64) ?x90)) true)))
(let (($x524 (or $x64 $x198 (or $x336))))
(let (($x778 (or $x524 false (or $x487))))
(let (($x117 (or (or $x778 false false) $x114)))
(let (($x339 (or $x117 false)))
(and (not $x339) (or $x368 (and (distinct ?x327 ?x725) true)))))))))))))))))))))))))))))))))))
(check-sat)
; query 11: function APCM_inverse_quantization, block 68, name %78
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in22_16 () (_ BitVec 16))
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let ((?x24 ((_ sign_extend 48) in22_16)))
(let ((?x29 ((_ sign_extend 16) in53_16)))
(let ((?x313 (bvshl ?x29 (_ bv12 32))))
(let ((?x26 ((_ extract 15 0) ?x313)))
(let ((?x82 ((_ sign_extend 48) ?x26)))
(let ((?x147 (bvmul ?x82 ?x24)))
(let ((?x227 (bvadd ?x147 (_ bv16384 64))))
(let ((?x488 (bvashr ?x227 (_ bv15 64))))
(let ((?x725 ((_ extract 15 0) ?x488)))
(let ((?x619 ((_ sign_extend 48) ?x725)))
(let ((?x90 (bvmul ?x24 ?x82)))
(let ((?x411 (bvadd ?x90 (_ bv16384 64))))
(let ((?x759 (bvashr ?x411 (_ bv15 64))))
(let ((?x327 ((_ extract 15 0) ?x759)))
(let ((?x155 ((_ sign_extend 48) ?x327)))
(let (($x114 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x359 (and (distinct (bvadd ((_ sign_extend 1) ?x147) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x227)) true)))
(let (($x74 (and (distinct (bvmul ((_ sign_extend 64) ?x82) ((_ sign_extend 64) ?x24)) ((_ sign_extend 64) ?x147)) true)))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x67 (or $x640 (bvuge (_ bv12 32) (_ bv32 32)))))
(let (($x1429 (or $x67 false)))
(let (($x198 (or $x1429 false)))
(let (($x566 (or $x198 $x64 (or $x74))))
(let (($x645 (or $x566 false (or $x359))))
(let (($x7 (or (or $x645 false false) $x114)))
(let (($x368 (or $x7 false)))
(let (($x343 (or $x368 false)))
(let (($x487 (and (distinct (bvadd ((_ sign_extend 1) ?x90) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x411)) true)))
(let (($x336 (and (distinct (bvmul ((_ sign_extend 64) ?x24) ((_ sign_extend 64) ?x82)) ((_ sign_extend 64) ?x90)) true)))
(let (($x524 (or $x64 $x198 (or $x336))))
(let (($x778 (or $x524 false (or $x487))))
(let (($x117 (or (or $x778 false false) $x114)))
(let (($x339 (or $x117 false)))
(let (($x1151 (or $x339 false)))
(and (not $x1151) (or $x343 (and (distinct ?x155 ?x619) true)))))))))))))))))))))))))))))))))))))))
(check-sat)
; query 12: function APCM_inverse_quantization, block 68, name %79
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in26_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 48) in26_16) ((_ sign_extend 48) in26_16)) true))))))
(check-sat)
; query 13: function APCM_inverse_quantization, block 68, name %80
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in26_16 () (_ BitVec 16))
(declare-fun in22_16 () (_ BitVec 16))
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let ((?x27 ((_ sign_extend 48) in26_16)))
(let ((?x24 ((_ sign_extend 48) in22_16)))
(let ((?x29 ((_ sign_extend 16) in53_16)))
(let ((?x313 (bvshl ?x29 (_ bv12 32))))
(let ((?x26 ((_ extract 15 0) ?x313)))
(let ((?x82 ((_ sign_extend 48) ?x26)))
(let ((?x147 (bvmul ?x82 ?x24)))
(let ((?x227 (bvadd ?x147 (_ bv16384 64))))
(let ((?x488 (bvashr ?x227 (_ bv15 64))))
(let ((?x725 ((_ extract 15 0) ?x488)))
(let ((?x619 ((_ sign_extend 48) ?x725)))
(let ((?x60 (bvadd ?x619 ?x27)))
(let ((?x90 (bvmul ?x24 ?x82)))
(let ((?x411 (bvadd ?x90 (_ bv16384 64))))
(let ((?x759 (bvashr ?x411 (_ bv15 64))))
(let ((?x327 ((_ extract 15 0) ?x759)))
(let ((?x155 ((_ sign_extend 48) ?x327)))
(let ((?x15 (bvadd ?x155 ?x27)))
(let ((?x72 ((_ sign_extend 1) ?x60)))
(let (($x64 (or false false)))
(let (($x114 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x359 (and (distinct (bvadd ((_ sign_extend 1) ?x147) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x227)) true)))
(let (($x74 (and (distinct (bvmul ((_ sign_extend 64) ?x82) ((_ sign_extend 64) ?x24)) ((_ sign_extend 64) ?x147)) true)))
(let (($x640 (or $x64 false false)))
(let (($x67 (or $x640 (bvuge (_ bv12 32) (_ bv32 32)))))
(let (($x1429 (or $x67 false)))
(let (($x198 (or $x1429 false)))
(let (($x566 (or $x198 $x64 (or $x74))))
(let (($x645 (or $x566 false (or $x359))))
(let (($x7 (or (or $x645 false false) $x114)))
(let (($x368 (or $x7 false)))
(let (($x343 (or $x368 false)))
(let (($x50 (or $x343 $x64 (or (and (distinct (bvadd ((_ sign_extend 1) ?x619) ((_ sign_extend 1) ?x27)) ?x72) true)))))
(let ((?x223 ((_ sign_extend 1) ?x15)))
(let (($x487 (and (distinct (bvadd ((_ sign_extend 1) ?x90) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x411)) true)))
(let (($x336 (and (distinct (bvmul ((_ sign_extend 64) ?x24) ((_ sign_extend 64) ?x82)) ((_ sign_extend 64) ?x90)) true)))
(let (($x524 (or $x64 $x198 (or $x336))))
(let (($x778 (or $x524 false (or $x487))))
(let (($x117 (or (or $x778 false false) $x114)))
(let (($x339 (or $x117 false)))
(let (($x1151 (or $x339 false)))
(let (($x79 (or $x1151 $x64 (or (and (distinct (bvadd ((_ sign_extend 1) ?x155) ((_ sign_extend 1) ?x27)) ?x223) true)))))
(and (not $x79) (or $x50 (and (distinct ?x15 ?x60) true))))))))))))))))))))))))))))))))))))))))))))))
(check-sat)
; query 14: function APCM_inverse_quantization, block 68, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in26_16 () (_ BitVec 16))
(declare-fun in22_16 () (_ BitVec 16))
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let ((?x27 ((_ sign_extend 48) in26_16)))
(let ((?x24 ((_ sign_extend 48) in22_16)))
(let ((?x29 ((_ sign_extend 16) in53_16)))
(let ((?x313 (bvshl ?x29 (_ bv12 32))))
(let ((?x26 ((_ extract 15 0) ?x313)))
(let ((?x82 ((_ sign_extend 48) ?x26)))
(let ((?x147 (bvmul ?x82 ?x24)))
(let ((?x227 (bvadd ?x147 (_ bv16384 64))))
(let ((?x488 (bvashr ?x227 (_ bv15 64))))
(let ((?x725 ((_ extract 15 0) ?x488)))
(let ((?x619 ((_ sign_extend 48) ?x725)))
(let ((?x60 (bvadd ?x619 ?x27)))
(let ((?x150 (bvsub ?x60 (_ bv18446744073709518848 64))))
(let ((?x90 (bvmul ?x24 ?x82)))
(let ((?x411 (bvadd ?x90 (_ bv16384 64))))
(let ((?x759 (bvashr ?x411 (_ bv15 64))))
(let ((?x327 ((_ extract 15 0) ?x759)))
(let ((?x155 ((_ sign_extend 48) ?x327)))
(let ((?x15 (bvadd ?x155 ?x27)))
(let ((?x45 (bvsub ?x15 (_ bv18446744073709518848 64))))
(let (($x446 (and (distinct (bvsub ((_ sign_extend 1) ?x60) ((_ sign_extend 1) (_ bv18446744073709518848 64))) ((_ sign_extend 1) ?x150)) true)))
(let ((?x72 ((_ sign_extend 1) ?x60)))
(let (($x64 (or false false)))
(let (($x114 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x359 (and (distinct (bvadd ((_ sign_extend 1) ?x147) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x227)) true)))
(let (($x74 (and (distinct (bvmul ((_ sign_extend 64) ?x82) ((_ sign_extend 64) ?x24)) ((_ sign_extend 64) ?x147)) true)))
(let (($x640 (or $x64 false false)))
(let (($x67 (or $x640 (bvuge (_ bv12 32) (_ bv32 32)))))
(let (($x1429 (or $x67 false)))
(let (($x198 (or $x1429 false)))
(let (($x566 (or $x198 $x64 (or $x74))))
(let (($x645 (or $x566 false (or $x359))))
(let (($x7 (or (or $x645 false false) $x114)))
(let (($x368 (or $x7 false)))
(let (($x343 (or $x368 false)))
(let (($x50 (or $x343 $x64 (or (and (distinct (bvadd ((_ sign_extend 1) ?x619) ((_ sign_extend 1) ?x27)) ?x72) true)))))
(let (($x18 (or $x50 false (or $x446))))
(let (($x104 (and (distinct (bvsub ((_ sign_extend 1) ?x15) ((_ sign_extend 1) (_ bv18446744073709518848 64))) ((_ sign_extend 1) ?x45)) true)))
(let ((?x223 ((_ sign_extend 1) ?x15)))
(let (($x487 (and (distinct (bvadd ((_ sign_extend 1) ?x90) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x411)) true)))
(let (($x336 (and (distinct (bvmul ((_ sign_extend 64) ?x24) ((_ sign_extend 64) ?x82)) ((_ sign_extend 64) ?x90)) true)))
(let (($x524 (or $x64 $x198 (or $x336))))
(let (($x778 (or $x524 false (or $x487))))
(let (($x117 (or (or $x778 false false) $x114)))
(let (($x339 (or $x117 false)))
(let (($x1151 (or $x339 false)))
(let (($x79 (or $x1151 $x64 (or (and (distinct (bvadd ((_ sign_extend 1) ?x155) ((_ sign_extend 1) ?x27)) ?x223) true)))))
(let (($x32 (or $x79 false (or $x104))))
(and (not $x32) (or $x18 (and (distinct ?x45 ?x150) true))))))))))))))))))))))))))))))))))))))))))))))))))))
(check-sat)
; query 15: function APCM_inverse_quantization, block 68, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in26_16 () (_ BitVec 16))
(declare-fun in22_16 () (_ BitVec 16))
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let ((?x27 ((_ sign_extend 48) in26_16)))
(let ((?x24 ((_ sign_extend 48) in22_16)))
(let ((?x29 ((_ sign_extend 16) in53_16)))
(let ((?x313 (bvshl ?x29 (_ bv12 32))))
(let ((?x26 ((_ extract 15 0) ?x313)))
(let ((?x82 ((_ sign_extend 48) ?x26)))
(let ((?x147 (bvmul ?x82 ?x24)))
(let ((?x227 (bvadd ?x147 (_ bv16384 64))))
(let ((?x488 (bvashr ?x227 (_ bv15 64))))
(let ((?x725 ((_ extract 15 0) ?x488)))
(let ((?x619 ((_ sign_extend 48) ?x725)))
(let ((?x60 (bvadd ?x619 ?x27)))
(let ((?x150 (bvsub ?x60 (_ bv18446744073709518848 64))))
(let ((?x90 (bvmul ?x24 ?x82)))
(let ((?x411 (bvadd ?x90 (_ bv16384 64))))
(let ((?x759 (bvashr ?x411 (_ bv15 64))))
(let ((?x327 ((_ extract 15 0) ?x759)))
(let ((?x155 ((_ sign_extend 48) ?x327)))
(let ((?x15 (bvadd ?x155 ?x27)))
(let ((?x45 (bvsub ?x15 (_ bv18446744073709518848 64))))
(let (($x983 (and (distinct (ite (bvugt ?x45 (_ bv65535 64)) (_ bv1 1) (_ bv0 1)) (ite (bvugt ?x150 (_ bv65535 64)) (_ bv1 1) (_ bv0 1))) true)))
(let (($x446 (and (distinct (bvsub ((_ sign_extend 1) ?x60) ((_ sign_extend 1) (_ bv18446744073709518848 64))) ((_ sign_extend 1) ?x150)) true)))
(let ((?x72 ((_ sign_extend 1) ?x60)))
(let (($x64 (or false false)))
(let (($x114 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x359 (and (distinct (bvadd ((_ sign_extend 1) ?x147) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x227)) true)))
(let (($x74 (and (distinct (bvmul ((_ sign_extend 64) ?x82) ((_ sign_extend 64) ?x24)) ((_ sign_extend 64) ?x147)) true)))
(let (($x640 (or $x64 false false)))
(let (($x67 (or $x640 (bvuge (_ bv12 32) (_ bv32 32)))))
(let (($x1429 (or $x67 false)))
(let (($x198 (or $x1429 false)))
(let (($x566 (or $x198 $x64 (or $x74))))
(let (($x645 (or $x566 false (or $x359))))
(let (($x7 (or (or $x645 false false) $x114)))
(let (($x368 (or $x7 false)))
(let (($x343 (or $x368 false)))
(let (($x50 (or $x343 $x64 (or (and (distinct (bvadd ((_ sign_extend 1) ?x619) ((_ sign_extend 1) ?x27)) ?x72) true)))))
(let (($x18 (or $x50 false (or $x446))))
(let (($x104 (and (distinct (bvsub ((_ sign_extend 1) ?x15) ((_ sign_extend 1) (_ bv18446744073709518848 64))) ((_ sign_extend 1) ?x45)) true)))
(let ((?x223 ((_ sign_extend 1) ?x15)))
(let (($x487 (and (distinct (bvadd ((_ sign_extend 1) ?x90) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x411)) true)))
(let (($x336 (and (distinct (bvmul ((_ sign_extend 64) ?x24) ((_ sign_extend 64) ?x82)) ((_ sign_extend 64) ?x90)) true)))
(let (($x524 (or $x64 $x198 (or $x336))))
(let (($x778 (or $x524 false (or $x487))))
(let (($x117 (or (or $x778 false false) $x114)))
(let (($x339 (or $x117 false)))
(let (($x1151 (or $x339 false)))
(let (($x79 (or $x1151 $x64 (or (and (distinct (bvadd ((_ sign_extend 1) ?x155) ((_ sign_extend 1) ?x27)) ?x223) true)))))
(let (($x32 (or $x79 false (or $x104))))
(and (not (or $x32 false false)) (or (or $x18 false false) $x983))))))))))))))))))))))))))))))))))))))))))))))))))))
(check-sat)
; query 16: function APCM_inverse_quantization, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 17: function APCM_inverse_quantization, block 7, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1658 (ite (bvsge (_ bv7 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x140 (not $x640)))
(and $x140 (or $x640 (and (distinct ?x1658 ?x1658) true))))))))
(check-sat)
; query 18: function APCM_inverse_quantization, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 19: function APCM_inverse_quantization, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x78 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x140 (not $x640)))
(and $x140 (or $x640 (and (distinct ?x78 ?x78) true))))))))
(check-sat)
; query 20: function APCM_quantization, block 159, name %160
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in152_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in152_16) ((_ sign_extend 16) in152_16)) true))))))
(check-sat)
; query 21: function APCM_quantization, block 159, name %161
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in152_16 () (_ BitVec 16))
(assert
 (let ((?x1579 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in152_16)) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x140 (not $x640)))
(and $x140 (or $x640 (and (distinct ?x1579 ?x1579) true))))))))
(check-sat)
; query 22: function APCM_quantization, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in13_16) ((_ sign_extend 16) in13_16)) true))))))
(check-sat)
; query 23: function APCM_quantization, block 16, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_16 () (_ BitVec 16))
(assert
 (let ((?x1196 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in13_16)) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x140 (not $x640)))
(and $x140 (or $x640 (and (distinct ?x1196 ?x1196) true))))))))
(check-sat)
; query 24: function APCM_quantization, block 162, name %163
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in152_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in152_16) ((_ sign_extend 16) in152_16)) true))))))
(check-sat)
; query 25: function APCM_quantization, block 162, name %164
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in152_16 () (_ BitVec 16))
(assert
 (let ((?x1126 (ite (bvsgt (_ bv16 32) ((_ sign_extend 16) in152_16)) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x140 (not $x640)))
(and $x140 (or $x640 (and (distinct ?x1126 ?x1126) true))))))))
(check-sat)
; query 26: function APCM_quantization, block 195, name %196
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let (($x1161 (and (distinct (bvadd ((_ sign_extend 1) in.2_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.2_32 (_ bv1 32)))) true)))
(let (($x648 (or false false (or $x1161))))
(and (not $x648) (or $x648 (and (distinct (bvadd in.2_32 (_ bv1 32)) (bvadd in.2_32 (_ bv1 32))) true))))))
(check-sat)
; query 27: function APCM_quantization, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in13_16) ((_ sign_extend 16) in13_16)) true))))))
(check-sat)
; query 28: function APCM_quantization, block 20, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_16 () (_ BitVec 16))
(assert
 (let ((?x240 ((_ sign_extend 16) in13_16)))
(let ((?x1282 (bvsub (_ bv0 32) ?x240)))
(let (($x91 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x240)) ((_ sign_extend 1) ?x1282)) true)))
(let (($x64 (or false false)))
(let (($x1238 (or false $x64 (or $x91))))
(and (not $x1238) (or $x1238 (and (distinct ?x1282 ?x1282) true)))))))))
(check-sat)
; query 29: function APCM_quantization, block 25, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in13_16) ((_ sign_extend 16) in13_16)) true))))))
(check-sat)
; query 30: function APCM_quantization, block 35, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_32 () (_ BitVec 32))
(assert
 (let (($x1278 (and (distinct (bvadd ((_ sign_extend 1) in.03_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.03_32 (_ bv1 32)))) true)))
(let (($x1119 (or false false (or $x1278))))
(and (not $x1119) (or $x1119 (and (distinct (bvadd in.03_32 (_ bv1 32)) (bvadd in.03_32 (_ bv1 32))) true))))))
(check-sat)
; query 31: function APCM_quantization, block 61, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in47_32 () (_ BitVec 32))
(assert
 (let ((?x1131 (ite (= (_ bv0 32) in47_32) (_ bv1 1) (_ bv0 1))))
(let (($x1338 (or false false false)))
(let (($x1128 (not $x1338)))
(and $x1128 (or $x1338 (and (distinct ?x1131 ?x1131) true)))))))
(check-sat)
; query 32: function APCM_quantization, block 67, name %68
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.14_32 () (_ BitVec 32))
(assert
 (let (($x875 (and (distinct (bvadd ((_ sign_extend 1) in.14_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.14_32 (_ bv1 32)))) true)))
(let (($x352 (or false false (or $x875))))
(and (not $x352) (or $x352 (and (distinct (bvadd in.14_32 (_ bv1 32)) (bvadd in.14_32 (_ bv1 32))) true))))))
(check-sat)
; query 33: function APCM_quantization, block 93, name %94
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in90_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in90_16) ((_ sign_extend 16) in90_16)) true))))))
(check-sat)
; query 34: function APCM_quantization, block 93, name %95
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in90_16 () (_ BitVec 16))
(assert
 (let ((?x1112 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in90_16)) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x140 (not $x640)))
(and $x140 (or $x640 (and (distinct ?x1112 ?x1112) true))))))))
(check-sat)
; query 35: function APCM_quantization_xmaxc_to_exp_mant, block 24, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in.0_16) ((_ sign_extend 16) in.0_16)) true))))))
(check-sat)
; query 36: function APCM_quantization_xmaxc_to_exp_mant, block 24, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let ((?x419 ((_ sign_extend 16) in.0_16)))
(let ((?x1337 (bvshl ?x419 (_ bv1 32))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x2058 (or $x640 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x984 (not $x2058)))
(and $x984 (or $x2058 (and (distinct ?x1337 ?x1337) true))))))))))
(check-sat)
; query 37: function APCM_quantization_xmaxc_to_exp_mant, block 24, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let ((?x419 ((_ sign_extend 16) in.0_16)))
(let ((?x1337 (bvshl ?x419 (_ bv1 32))))
(let ((?x1219 (bvadd ?x1337 (_ bv1 32))))
(let ((?x1284 (bvor ?x1337 (_ bv1 32))))
(let (($x1235 (and (distinct (bvadd ((_ zero_extend 1) ?x1337) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) ?x1219)) true)))
(let (($x1913 (and (distinct (bvadd ((_ sign_extend 1) ?x1337) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x1219)) true)))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x2058 (or $x640 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x490 (or $x2058 false (or $x1913 $x1235))))
(and (not (or $x2058 false false)) (or $x490 (and (distinct ?x1284 ?x1219) true))))))))))))))
(check-sat)
; query 38: function APCM_quantization_xmaxc_to_exp_mant, block 24, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x986 (and (distinct ((_ extract 15 0) (bvor (bvshl ((_ sign_extend 16) in.0_16) (_ bv1 32)) (_ bv1 32))) ((_ extract 15 0) (bvadd (bvshl ((_ sign_extend 16) in.0_16) (_ bv1 32)) (_ bv1 32)))) true)))
(let ((?x1206 (bvadd ((_ zero_extend 1) (bvshl ((_ sign_extend 16) in.0_16) (_ bv1 32))) ((_ zero_extend 1) (_ bv1 32)))))
(let (($x1235 (and (distinct ?x1206 ((_ zero_extend 1) (bvadd (bvshl ((_ sign_extend 16) in.0_16) (_ bv1 32)) (_ bv1 32)))) true)))
(let ((?x1534 ((_ sign_extend 1) (_ bv1 32))))
(let (($x1913 (and (distinct (bvadd ((_ sign_extend 1) (bvshl ((_ sign_extend 16) in.0_16) (_ bv1 32))) ?x1534) ((_ sign_extend 1) (bvadd (bvshl ((_ sign_extend 16) in.0_16) (_ bv1 32)) (_ bv1 32)))) true)))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x2058 (or $x640 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x490 (or $x2058 false (or $x1913 $x1235))))
(and (not (or (or $x2058 false false) false)) (or (or $x490 false) $x986))))))))))))
(check-sat)
; query 39: function APCM_quantization_xmaxc_to_exp_mant, block 24, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_16 () (_ BitVec 16))
(assert
 (let (($x1338 (or false false false)))
(let (($x1128 (not $x1338)))
(and $x1128 (or $x1338 (and (distinct (bvadd in.12_16 (_ bv65535 16)) (bvadd in.12_16 (_ bv65535 16))) true))))))
(check-sat)
; query 40: function APCM_quantization_xmaxc_to_exp_mant, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in.0_16) ((_ sign_extend 16) in.0_16)) true))))))
(check-sat)
; query 41: function APCM_quantization_xmaxc_to_exp_mant, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let ((?x419 ((_ sign_extend 16) in.0_16)))
(let ((?x1833 (bvsub ?x419 (_ bv8 32))))
(let (($x139 (and (distinct (bvsub ((_ sign_extend 1) ?x419) ((_ sign_extend 1) (_ bv8 32))) ((_ sign_extend 1) ?x1833)) true)))
(let (($x64 (or false false)))
(let (($x724 (or $x64 false (or $x139))))
(and (not $x724) (or $x724 (and (distinct ?x1833 ?x1833) true)))))))))
(check-sat)
; query 42: function APCM_quantization_xmaxc_to_exp_mant, block 30, name %33
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let ((?x419 ((_ sign_extend 16) in.0_16)))
(let ((?x1833 (bvsub ?x419 (_ bv8 32))))
(let ((?x971 ((_ extract 15 0) ?x1833)))
(let (($x139 (and (distinct (bvsub ((_ sign_extend 1) ?x419) ((_ sign_extend 1) (_ bv8 32))) ((_ sign_extend 1) ?x1833)) true)))
(let (($x64 (or false false)))
(let (($x724 (or $x64 false (or $x139))))
(let (($x1819 (or $x724 false)))
(and (not $x1819) (or $x1819 (and (distinct ?x971 ?x971) true)))))))))))
(check-sat)
; query 43: function APCM_quantization_xmaxc_to_exp_mant, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in.2_16) ((_ sign_extend 16) in.2_16)) true))))))
(check-sat)
; query 44: function APCM_quantization_xmaxc_to_exp_mant, block 37, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_16 () (_ BitVec 16))
(assert
 (let ((?x662 (ite (bvsge (_ bv6 32) ((_ sign_extend 16) in.2_16)) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x140 (not $x640)))
(and $x140 (or $x640 (and (distinct ?x662 ?x662) true))))))))
(check-sat)
; query 45: function APCM_quantization_xmaxc_to_exp_mant, block 49, name %50
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 46: function APCM_quantization_xmaxc_to_exp_mant, block 49, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x783 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in.1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x140 (not $x640)))
(and $x140 (or $x640 (and (distinct ?x783 ?x783) true))))))))
(check-sat)
; query 47: function APCM_quantization_xmaxc_to_exp_mant, block 52, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 48: function APCM_quantization_xmaxc_to_exp_mant, block 52, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x1620 (ite (bvsge (_ bv7 32) ((_ sign_extend 16) in.1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x140 (not $x640)))
(and $x140 (or $x640 (and (distinct ?x1620 ?x1620) true))))))))
(check-sat)
; query 49: function APCM_quantization_xmaxc_to_exp_mant, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x332 ((_ sign_extend 16) in0_16)))
(let ((?x1060 (bvashr ?x332 (_ bv3 32))))
(let ((?x2087 (bvsub ?x1060 (_ bv1 32))))
(let ((?x2032 ((_ extract 15 0) ?x2087)))
(let (($x849 (and (distinct (bvsub ((_ sign_extend 1) ?x1060) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x2087)) true)))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x1273 (or $x640 (bvuge (_ bv3 32) (_ bv32 32)))))
(let (($x369 (or $x1273 false (or $x849))))
(let (($x853 (or $x369 false)))
(and (not $x853) (or $x853 (and (distinct ?x2032 ?x2032) true))))))))))))))
(check-sat)
; query 50: function APCM_quantization_xmaxc_to_exp_mant, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 51: function APCM_quantization_xmaxc_to_exp_mant, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x332 ((_ sign_extend 16) in0_16)))
(let ((?x1060 (bvashr ?x332 (_ bv3 32))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x1273 (or $x640 (bvuge (_ bv3 32) (_ bv32 32)))))
(and (not $x1273) (or $x1273 (and (distinct ?x1060 ?x1060) true)))))))))
(check-sat)
; query 52: function APCM_quantization_xmaxc_to_exp_mant, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x332 ((_ sign_extend 16) in0_16)))
(let ((?x1060 (bvashr ?x332 (_ bv3 32))))
(let ((?x2087 (bvsub ?x1060 (_ bv1 32))))
(let (($x849 (and (distinct (bvsub ((_ sign_extend 1) ?x1060) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x2087)) true)))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x1273 (or $x640 (bvuge (_ bv3 32) (_ bv32 32)))))
(let (($x369 (or $x1273 false (or $x849))))
(and (not $x369) (or $x369 (and (distinct ?x2087 ?x2087) true))))))))))))
(check-sat)
; query 53: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 54: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1023 (ite (bvslt (_ bv15 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x140 (not $x640)))
(and $x140 (or $x640 (and (distinct ?x1023 ?x1023) true))))))))
(check-sat)
; query 55: function Autocorrelation, block 115, name %116
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.3_32 () (_ BitVec 32))
(assert
 (let (($x1191 (and (distinct (bvadd ((_ sign_extend 1) in.3_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.3_32 (_ bv1 32)))) true)))
(let (($x569 (or false false (or $x1191))))
(and (not $x569) (or $x569 (and (distinct (bvadd in.3_32 (_ bv1 32)) (bvadd in.3_32 (_ bv1 32))) true))))))
(check-sat)
; query 56: function Autocorrelation, block 132, name %133
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.4_32 () (_ BitVec 32))
(assert
 (let (($x1561 (and (distinct (bvadd ((_ sign_extend 1) in.4_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.4_32 (_ bv1 32)))) true)))
(let (($x1631 (or false false (or $x1561))))
(and (not $x1631) (or $x1631 (and (distinct (bvadd in.4_32 (_ bv1 32)) (bvadd in.4_32 (_ bv1 32))) true))))))
(check-sat)
; query 57: function Autocorrelation, block 39, name %40
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x372 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x514 (or false false (or $x372))))
(and (not $x514) (or $x514 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 58: function Autocorrelation, block 41, name %42
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in.04_16) ((_ sign_extend 16) in.04_16)) true))))))
(check-sat)
; query 59: function Autocorrelation, block 41, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let ((?x1618 (ite (= (_ bv0 32) ((_ sign_extend 16) in.04_16)) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x140 (not $x640)))
(and $x140 (or $x640 (and (distinct ?x1618 ?x1618) true))))))))
(check-sat)
; query 60: function Autocorrelation, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in.04_16) ((_ sign_extend 16) in.04_16)) true))))))
(check-sat)
; query 61: function Autocorrelation, block 45, name %47
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let ((?x479 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.04_16)) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x140 (not $x640)))
(and $x140 (or $x640 (and (distinct ?x479 ?x479) true))))))))
(check-sat)
; query 62: function Autocorrelation, block 45, name %48
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let ((?x479 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.04_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x766 (bvxor ?x479 (_ bv1 1))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x793 (or $x640 false false)))
(let (($x836 (not $x793)))
(and $x836 (or $x793 (and (distinct ?x766 ?x766) true))))))))))
(check-sat)
; query 63: function Autocorrelation, block 45, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let ((?x479 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.04_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x766 (bvxor ?x479 (_ bv1 1))))
(let ((?x611 ((_ zero_extend 31) ?x766)))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x793 (or $x640 false false)))
(let (($x361 (or $x793 false)))
(let (($x609 (not $x361)))
(and $x609 (or $x361 (and (distinct ?x611 ?x611) true))))))))))))
(check-sat)
; query 64: function Autocorrelation, block 45, name %50
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let ((?x479 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.04_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x766 (bvxor ?x479 (_ bv1 1))))
(let ((?x611 ((_ zero_extend 31) ?x766)))
(let ((?x1649 ((_ sign_extend 32) ?x611)))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x793 (or $x640 false false)))
(let (($x361 (or $x793 false)))
(let (($x886 (or $x361 false)))
(let (($x1357 (not $x886)))
(and $x1357 (or $x886 (and (distinct ?x1649 ?x1649) true))))))))))))))
(check-sat)
; query 65: function Autocorrelation, block 45, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let ((?x479 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.04_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x766 (bvxor ?x479 (_ bv1 1))))
(let ((?x611 ((_ zero_extend 31) ?x766)))
(let ((?x1649 ((_ sign_extend 32) ?x611)))
(let ((?x1003 (ite (and (distinct (_ bv0 64) ?x1649) true) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x793 (or $x640 false false)))
(let (($x361 (or $x793 false)))
(let (($x886 (or $x361 false)))
(let (($x2084 (or $x886 false false)))
(let (($x1528 (not $x2084)))
(and $x1528 (or $x2084 (and (distinct ?x1003 ?x1003) true))))))))))))))))
(check-sat)
; query 66: function Autocorrelation, block 525, name %526
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x1567 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x1440 (or false false (or $x1567))))
(and (not $x1440) (or $x1440 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 67: function Autocorrelation, block 537, name %538
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in.06_16) ((_ sign_extend 16) in.06_16)) true))))))
(check-sat)
; query 68: function Autocorrelation, block 537, name %539
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_16 () (_ BitVec 16))
(assert
 (let ((?x881 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.06_16)) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x140 (not $x640)))
(and $x140 (or $x640 (and (distinct ?x881 ?x881) true))))))))
(check-sat)
; query 69: function Autocorrelation, block 540, name %541
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in.06_16) ((_ sign_extend 16) in.06_16)) true))))))
(check-sat)
; query 70: function Autocorrelation, block 540, name %542
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_16 () (_ BitVec 16))
(assert
 (let ((?x1938 (ite (bvsge (_ bv4 32) ((_ sign_extend 16) in.06_16)) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x140 (not $x640)))
(and $x140 (or $x640 (and (distinct ?x1938 ?x1938) true))))))))
(check-sat)
; query 71: function Autocorrelation, block 540, name %543
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_16 () (_ BitVec 16))
(assert
 (let ((?x1938 (ite (bvsge (_ bv4 32) ((_ sign_extend 16) in.06_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1788 (bvxor ?x1938 (_ bv1 1))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x793 (or $x640 false false)))
(let (($x836 (not $x793)))
(and $x836 (or $x793 (and (distinct ?x1788 ?x1788) true))))))))))
(check-sat)
; query 72: function Autocorrelation, block 540, name %544
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_16 () (_ BitVec 16))
(assert
 (let ((?x1938 (ite (bvsge (_ bv4 32) ((_ sign_extend 16) in.06_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1788 (bvxor ?x1938 (_ bv1 1))))
(let ((?x462 ((_ zero_extend 31) ?x1788)))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x793 (or $x640 false false)))
(let (($x361 (or $x793 false)))
(let (($x609 (not $x361)))
(and $x609 (or $x361 (and (distinct ?x462 ?x462) true))))))))))))
(check-sat)
; query 73: function Autocorrelation, block 540, name %545
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_16 () (_ BitVec 16))
(assert
 (let ((?x1938 (ite (bvsge (_ bv4 32) ((_ sign_extend 16) in.06_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1788 (bvxor ?x1938 (_ bv1 1))))
(let ((?x462 ((_ zero_extend 31) ?x1788)))
(let ((?x1714 ((_ sign_extend 32) ?x462)))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x793 (or $x640 false false)))
(let (($x361 (or $x793 false)))
(let (($x886 (or $x361 false)))
(let (($x1357 (not $x886)))
(and $x1357 (or $x886 (and (distinct ?x1714 ?x1714) true))))))))))))))
(check-sat)
; query 74: function Autocorrelation, block 540, name %546
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_16 () (_ BitVec 16))
(assert
 (let ((?x1938 (ite (bvsge (_ bv4 32) ((_ sign_extend 16) in.06_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1788 (bvxor ?x1938 (_ bv1 1))))
(let ((?x462 ((_ zero_extend 31) ?x1788)))
(let ((?x1714 ((_ sign_extend 32) ?x462)))
(let ((?x1716 (ite (and (distinct (_ bv0 64) ?x1714) true) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x793 (or $x640 false false)))
(let (($x361 (or $x793 false)))
(let (($x886 (or $x361 false)))
(let (($x2084 (or $x886 false false)))
(let (($x1528 (not $x2084)))
(and $x1528 (or $x2084 (and (distinct ?x1716 ?x1716) true))))))))))))))))
(check-sat)
; query 75: function Autocorrelation, block 81, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x809 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x1013 (or false false (or $x809))))
(and (not $x1013) (or $x1013 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 76: function Autocorrelation, block 98, name %99
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let (($x1161 (and (distinct (bvadd ((_ sign_extend 1) in.2_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.2_32 (_ bv1 32)))) true)))
(let (($x648 (or false false (or $x1161))))
(and (not $x648) (or $x648 (and (distinct (bvadd in.2_32 (_ bv1 32)) (bvadd in.2_32 (_ bv1 32))) true))))))
(check-sat)
; query 77: function Calculation_of_the_LTP_parameters, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in11_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in11_16) ((_ sign_extend 16) in11_16)) true))))))
(check-sat)
; query 78: function Calculation_of_the_LTP_parameters, block 14, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in11_16 () (_ BitVec 16))
(assert
 (let ((?x579 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in11_16)) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x140 (not $x640)))
(and $x140 (or $x640 (and (distinct ?x579 ?x579) true))))))))
(check-sat)
; query 79: function Calculation_of_the_LTP_parameters, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in11_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in11_16) ((_ sign_extend 16) in11_16)) true))))))
(check-sat)
; query 80: function Calculation_of_the_LTP_parameters, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in11_16 () (_ BitVec 16))
(assert
 (let ((?x1832 ((_ sign_extend 16) in11_16)))
(let ((?x188 (bvsub (_ bv0 32) ?x1832)))
(let (($x981 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1832)) ((_ sign_extend 1) ?x188)) true)))
(let (($x64 (or false false)))
(let (($x1316 (or false $x64 (or $x981))))
(and (not $x1316) (or $x1316 (and (distinct ?x188 ?x188) true)))))))))
(check-sat)
; query 81: function Calculation_of_the_LTP_parameters, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in11_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in11_16) ((_ sign_extend 16) in11_16)) true))))))
(check-sat)
; query 82: function Calculation_of_the_LTP_parameters, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_32 () (_ BitVec 32))
(assert
 (let (($x1278 (and (distinct (bvadd ((_ sign_extend 1) in.03_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.03_32 (_ bv1 32)))) true)))
(let (($x1119 (or false false (or $x1278))))
(and (not $x1119) (or $x1119 (and (distinct (bvadd in.03_32 (_ bv1 32)) (bvadd in.03_32 (_ bv1 32))) true))))))
(check-sat)
; query 83: function Calculation_of_the_LTP_parameters, block 35, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in.02_16) ((_ sign_extend 16) in.02_16)) true))))))
(check-sat)
; query 84: function Calculation_of_the_LTP_parameters, block 35, name %37
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x371 (ite (= (_ bv0 32) ((_ sign_extend 16) in.02_16)) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x140 (not $x640)))
(and $x140 (or $x640 (and (distinct ?x371 ?x371) true))))))))
(check-sat)
; query 85: function Calculation_of_the_LTP_parameters, block 39, name %40
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in.02_16) ((_ sign_extend 16) in.02_16)) true))))))
(check-sat)
; query 86: function Calculation_of_the_LTP_parameters, block 39, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x687 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.02_16)) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x140 (not $x640)))
(and $x140 (or $x640 (and (distinct ?x687 ?x687) true))))))))
(check-sat)
; query 87: function Calculation_of_the_LTP_parameters, block 39, name %42
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x687 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.02_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x12 (bvxor ?x687 (_ bv1 1))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x793 (or $x640 false false)))
(let (($x836 (not $x793)))
(and $x836 (or $x793 (and (distinct ?x12 ?x12) true))))))))))
(check-sat)
; query 88: function Calculation_of_the_LTP_parameters, block 39, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x687 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.02_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x12 (bvxor ?x687 (_ bv1 1))))
(let ((?x1251 ((_ zero_extend 31) ?x12)))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x793 (or $x640 false false)))
(let (($x361 (or $x793 false)))
(let (($x609 (not $x361)))
(and $x609 (or $x361 (and (distinct ?x1251 ?x1251) true))))))))))))
(check-sat)
; query 89: function Calculation_of_the_LTP_parameters, block 39, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x687 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.02_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x12 (bvxor ?x687 (_ bv1 1))))
(let ((?x1251 ((_ zero_extend 31) ?x12)))
(let ((?x516 ((_ sign_extend 32) ?x1251)))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x793 (or $x640 false false)))
(let (($x361 (or $x793 false)))
(let (($x886 (or $x361 false)))
(let (($x1357 (not $x886)))
(and $x1357 (or $x886 (and (distinct ?x516 ?x516) true))))))))))))))
(check-sat)
; query 90: function Calculation_of_the_LTP_parameters, block 39, name %45
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x687 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.02_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x12 (bvxor ?x687 (_ bv1 1))))
(let ((?x1251 ((_ zero_extend 31) ?x12)))
(let ((?x516 ((_ sign_extend 32) ?x1251)))
(let ((?x396 (ite (and (distinct (_ bv0 64) ?x516) true) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x793 (or $x640 false false)))
(let (($x361 (or $x793 false)))
(let (($x886 (or $x361 false)))
(let (($x2084 (or $x886 false false)))
(let (($x1528 (not $x2084)))
(and $x1528 (or $x2084 (and (distinct ?x396 ?x396) true))))))))))))))))
(check-sat)
; query 91: function Calculation_of_the_LTP_parameters, block 57, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in.0_16) ((_ sign_extend 16) in.0_16)) true))))))
(check-sat)
; query 92: function Calculation_of_the_LTP_parameters, block 57, name %59
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let ((?x419 ((_ sign_extend 16) in.0_16)))
(let ((?x242 (bvsub (_ bv6 32) ?x419)))
(let (($x387 (and (distinct (bvsub ((_ sign_extend 1) (_ bv6 32)) ((_ sign_extend 1) ?x419)) ((_ sign_extend 1) ?x242)) true)))
(let (($x64 (or false false)))
(let (($x460 (or false $x64 (or $x387))))
(and (not $x460) (or $x460 (and (distinct ?x242 ?x242) true)))))))))
(check-sat)
; query 93: function Calculation_of_the_LTP_parameters, block 57, name %60
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let ((?x419 ((_ sign_extend 16) in.0_16)))
(let ((?x242 (bvsub (_ bv6 32) ?x419)))
(let ((?x500 ((_ extract 15 0) ?x242)))
(let (($x387 (and (distinct (bvsub ((_ sign_extend 1) (_ bv6 32)) ((_ sign_extend 1) ?x419)) ((_ sign_extend 1) ?x242)) true)))
(let (($x64 (or false false)))
(let (($x460 (or false $x64 (or $x387))))
(let (($x715 (or $x460 false)))
(and (not $x715) (or $x715 (and (distinct ?x500 ?x500) true)))))))))))
(check-sat)
; query 94: function Calculation_of_the_LTP_parameters, block 84, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.14_32 () (_ BitVec 32))
(assert
 (let (($x875 (and (distinct (bvadd ((_ sign_extend 1) in.14_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.14_32 (_ bv1 32)))) true)))
(let (($x352 (or false false (or $x875))))
(and (not $x352) (or $x352 (and (distinct (bvadd in.14_32 (_ bv1 32)) (bvadd in.14_32 (_ bv1 32))) true))))))
(check-sat)
; query 95: function Gsm_Decoder, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1141 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x1619 (or false false (or $x1141))))
(and (not $x1619) (or $x1619 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 96: function Gsm_Long_Term_Synthesis_Filtering, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 97: function Gsm_Long_Term_Synthesis_Filtering, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in19_16) ((_ sign_extend 16) in19_16)) true))))))
(check-sat)
; query 98: function Gsm_Long_Term_Synthesis_Filtering, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x1881 (ite (bvsge (_ bv120 32) ((_ sign_extend 16) in19_16)) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x140 (not $x640)))
(and $x140 (or $x640 (and (distinct ?x1881 ?x1881) true))))))))
(check-sat)
; query 99: function Gsm_Long_Term_Synthesis_Filtering, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1148 (ite (bvslt (_ bv120 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x140 (not $x640)))
(and $x140 (or $x640 (and (distinct ?x1148 ?x1148) true))))))))
(check-sat)
; query 100: function Gsm_Long_Term_Synthesis_Filtering, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 101: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 102: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x2092 (ite (bvsgt (_ bv40 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x140 (not $x640)))
(and $x140 (or $x640 (and (distinct ?x2092 ?x2092) true))))))))
(check-sat)
; query 103: function Gsm_Preprocess, block 106, name %107
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in104_64 () (_ BitVec 64))
(assert
 (let ((?x1076 (bvadd in104_64 (_ bv16384 64))))
(let (($x1486 (and (distinct ?x1076 ?x1076) true)))
(let (($x1968 (and (distinct (bvadd ((_ sign_extend 1) in104_64) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x1076)) true)))
(let (($x195 (or false false (or $x1968))))
(and (not $x195) (or $x195 $x1486)))))))
(check-sat)
; query 104: function Gsm_Preprocess, block 108, name %109
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in104_64 () (_ BitVec 64))
(assert
 (let ((?x1076 (bvadd in104_64 (_ bv16384 64))))
(let (($x1486 (and (distinct ?x1076 ?x1076) true)))
(let (($x1338 (or false false false)))
(let (($x1128 (not $x1338)))
(and $x1128 (or $x1338 $x1486)))))))
(check-sat)
; query 105: function Gsm_Preprocess, block 108, name %110
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in104_64 () (_ BitVec 64))
(assert
 (let ((?x92 (ite (bvuge (bvadd in104_64 (_ bv16384 64)) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x1338 (or false false false)))
(let (($x1599 (or $x1338 false false)))
(let (($x635 (not $x1599)))
(and $x635 (or $x1599 (and (distinct ?x92 ?x92) true))))))))
(check-sat)
; query 106: function Gsm_Preprocess, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in19_16) ((_ sign_extend 16) in19_16)) true))))))
(check-sat)
; query 107: function Gsm_Preprocess, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x1899 (ite (bvsge (_ bv16380 32) ((_ sign_extend 16) in19_16)) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x140 (not $x640)))
(and $x140 (or $x640 (and (distinct ?x1899 ?x1899) true))))))))
(check-sat)
; query 108: function Gsm_Preprocess, block 30, name %33
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x1899 (ite (bvsge (_ bv16380 32) ((_ sign_extend 16) in19_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x621 (bvxor ?x1899 (_ bv1 1))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x793 (or $x640 false false)))
(let (($x836 (not $x793)))
(and $x836 (or $x793 (and (distinct ?x621 ?x621) true))))))))))
(check-sat)
; query 109: function Gsm_Preprocess, block 30, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x1899 (ite (bvsge (_ bv16380 32) ((_ sign_extend 16) in19_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x621 (bvxor ?x1899 (_ bv1 1))))
(let ((?x1407 ((_ zero_extend 31) ?x621)))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x793 (or $x640 false false)))
(let (($x361 (or $x793 false)))
(let (($x609 (not $x361)))
(and $x609 (or $x361 (and (distinct ?x1407 ?x1407) true))))))))))))
(check-sat)
; query 110: function Gsm_Preprocess, block 30, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x1899 (ite (bvsge (_ bv16380 32) ((_ sign_extend 16) in19_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x621 (bvxor ?x1899 (_ bv1 1))))
(let ((?x1407 ((_ zero_extend 31) ?x621)))
(let ((?x1099 ((_ sign_extend 32) ?x1407)))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x793 (or $x640 false false)))
(let (($x361 (or $x793 false)))
(let (($x886 (or $x361 false)))
(let (($x1357 (not $x886)))
(and $x1357 (or $x886 (and (distinct ?x1099 ?x1099) true))))))))))))))
(check-sat)
; query 111: function Gsm_Preprocess, block 30, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x1899 (ite (bvsge (_ bv16380 32) ((_ sign_extend 16) in19_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x621 (bvxor ?x1899 (_ bv1 1))))
(let ((?x1407 ((_ zero_extend 31) ?x621)))
(let ((?x1099 ((_ sign_extend 32) ?x1407)))
(let ((?x461 (ite (and (distinct (_ bv0 64) ?x1099) true) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x793 (or $x640 false false)))
(let (($x361 (or $x793 false)))
(let (($x886 (or $x361 false)))
(let (($x2084 (or $x886 false false)))
(let (($x1528 (not $x2084)))
(and $x1528 (or $x2084 (and (distinct ?x461 ?x461) true))))))))))))))))
(check-sat)
; query 112: function Gsm_Preprocess, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in19_16) ((_ sign_extend 16) in19_16)) true))))))
(check-sat)
; query 113: function Gsm_Preprocess, block 40, name %42
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in.03_16) ((_ sign_extend 16) in.03_16)) true))))))
(check-sat)
; query 114: function Gsm_Preprocess, block 40, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_16 () (_ BitVec 16))
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x991 ((_ sign_extend 16) in.03_16)))
(let ((?x1452 ((_ sign_extend 16) in19_16)))
(let ((?x1608 (bvsub ?x1452 ?x991)))
(let (($x1088 (and (distinct (bvsub ((_ sign_extend 1) ?x1452) ((_ sign_extend 1) ?x991)) ((_ sign_extend 1) ?x1608)) true)))
(let (($x64 (or false false)))
(let (($x929 (or $x64 $x64 (or $x1088))))
(and (not $x929) (or $x929 (and (distinct ?x1608 ?x1608) true))))))))))
(check-sat)
; query 115: function Gsm_Preprocess, block 40, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_16 () (_ BitVec 16))
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x991 ((_ sign_extend 16) in.03_16)))
(let ((?x1452 ((_ sign_extend 16) in19_16)))
(let ((?x1608 (bvsub ?x1452 ?x991)))
(let ((?x1921 ((_ extract 15 0) ?x1608)))
(let (($x1088 (and (distinct (bvsub ((_ sign_extend 1) ?x1452) ((_ sign_extend 1) ?x991)) ((_ sign_extend 1) ?x1608)) true)))
(let (($x64 (or false false)))
(let (($x929 (or $x64 $x64 (or $x1088))))
(let (($x802 (or $x929 false)))
(and (not $x802) (or $x802 (and (distinct ?x1921 ?x1921) true))))))))))))
(check-sat)
; query 116: function Gsm_Preprocess, block 40, name %45
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_16 () (_ BitVec 16))
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x991 ((_ sign_extend 16) in.03_16)))
(let ((?x1452 ((_ sign_extend 16) in19_16)))
(let ((?x1608 (bvsub ?x1452 ?x991)))
(let ((?x1921 ((_ extract 15 0) ?x1608)))
(let ((?x1379 ((_ sign_extend 16) ?x1921)))
(let (($x1088 (and (distinct (bvsub ((_ sign_extend 1) ?x1452) ((_ sign_extend 1) ?x991)) ((_ sign_extend 1) ?x1608)) true)))
(let (($x64 (or false false)))
(let (($x929 (or $x64 $x64 (or $x1088))))
(let (($x802 (or $x929 false)))
(let (($x993 (or $x802 false)))
(and (not $x993) (or $x993 (and (distinct ?x1379 ?x1379) true))))))))))))))
(check-sat)
; query 117: function Gsm_Preprocess, block 40, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_16 () (_ BitVec 16))
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x991 ((_ sign_extend 16) in.03_16)))
(let ((?x1452 ((_ sign_extend 16) in19_16)))
(let ((?x1608 (bvsub ?x1452 ?x991)))
(let ((?x1921 ((_ extract 15 0) ?x1608)))
(let ((?x1379 ((_ sign_extend 16) ?x1921)))
(let ((?x694 (ite (and (distinct (_ bv4294934528 32) ?x1379) true) (_ bv1 1) (_ bv0 1))))
(let (($x1088 (and (distinct (bvsub ((_ sign_extend 1) ?x1452) ((_ sign_extend 1) ?x991)) ((_ sign_extend 1) ?x1608)) true)))
(let (($x64 (or false false)))
(let (($x929 (or $x64 $x64 (or $x1088))))
(let (($x802 (or $x929 false)))
(let (($x993 (or $x802 false)))
(let (($x902 (or $x993 false false)))
(and (not $x902) (or $x902 (and (distinct ?x694 ?x694) true))))))))))))))))
(check-sat)
; query 118: function Gsm_Preprocess, block 40, name %47
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_16 () (_ BitVec 16))
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x991 ((_ sign_extend 16) in.03_16)))
(let ((?x1452 ((_ sign_extend 16) in19_16)))
(let ((?x1608 (bvsub ?x1452 ?x991)))
(let ((?x1921 ((_ extract 15 0) ?x1608)))
(let ((?x1379 ((_ sign_extend 16) ?x1921)))
(let ((?x694 (ite (and (distinct (_ bv4294934528 32) ?x1379) true) (_ bv1 1) (_ bv0 1))))
(let ((?x1231 (bvxor ?x694 (_ bv1 1))))
(let (($x1088 (and (distinct (bvsub ((_ sign_extend 1) ?x1452) ((_ sign_extend 1) ?x991)) ((_ sign_extend 1) ?x1608)) true)))
(let (($x64 (or false false)))
(let (($x929 (or $x64 $x64 (or $x1088))))
(let (($x802 (or $x929 false)))
(let (($x993 (or $x802 false)))
(let (($x902 (or $x993 false false)))
(let (($x348 (or $x902 false false)))
(and (not $x348) (or $x348 (and (distinct ?x1231 ?x1231) true))))))))))))))))))
(check-sat)
; query 119: function Gsm_Preprocess, block 40, name %48
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_16 () (_ BitVec 16))
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x991 ((_ sign_extend 16) in.03_16)))
(let ((?x1452 ((_ sign_extend 16) in19_16)))
(let ((?x1608 (bvsub ?x1452 ?x991)))
(let ((?x1921 ((_ extract 15 0) ?x1608)))
(let ((?x1379 ((_ sign_extend 16) ?x1921)))
(let ((?x694 (ite (and (distinct (_ bv4294934528 32) ?x1379) true) (_ bv1 1) (_ bv0 1))))
(let ((?x1231 (bvxor ?x694 (_ bv1 1))))
(let ((?x1195 ((_ zero_extend 31) ?x1231)))
(let (($x1088 (and (distinct (bvsub ((_ sign_extend 1) ?x1452) ((_ sign_extend 1) ?x991)) ((_ sign_extend 1) ?x1608)) true)))
(let (($x64 (or false false)))
(let (($x929 (or $x64 $x64 (or $x1088))))
(let (($x802 (or $x929 false)))
(let (($x993 (or $x802 false)))
(let (($x902 (or $x993 false false)))
(let (($x348 (or $x902 false false)))
(let (($x1015 (or $x348 false)))
(and (not $x1015) (or $x1015 (and (distinct ?x1195 ?x1195) true))))))))))))))))))))
(check-sat)
; query 120: function Gsm_Preprocess, block 40, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_16 () (_ BitVec 16))
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x991 ((_ sign_extend 16) in.03_16)))
(let ((?x1452 ((_ sign_extend 16) in19_16)))
(let ((?x1608 (bvsub ?x1452 ?x991)))
(let ((?x1921 ((_ extract 15 0) ?x1608)))
(let ((?x1379 ((_ sign_extend 16) ?x1921)))
(let ((?x694 (ite (and (distinct (_ bv4294934528 32) ?x1379) true) (_ bv1 1) (_ bv0 1))))
(let ((?x1231 (bvxor ?x694 (_ bv1 1))))
(let ((?x1195 ((_ zero_extend 31) ?x1231)))
(let ((?x340 ((_ sign_extend 32) ?x1195)))
(let (($x1088 (and (distinct (bvsub ((_ sign_extend 1) ?x1452) ((_ sign_extend 1) ?x991)) ((_ sign_extend 1) ?x1608)) true)))
(let (($x64 (or false false)))
(let (($x929 (or $x64 $x64 (or $x1088))))
(let (($x802 (or $x929 false)))
(let (($x993 (or $x802 false)))
(let (($x902 (or $x993 false false)))
(let (($x348 (or $x902 false false)))
(let (($x1015 (or $x348 false)))
(let (($x10 (or $x1015 false)))
(and (not $x10) (or $x10 (and (distinct ?x340 ?x340) true))))))))))))))))))))))
(check-sat)
; query 121: function Gsm_Preprocess, block 40, name %50
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_16 () (_ BitVec 16))
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x991 ((_ sign_extend 16) in.03_16)))
(let ((?x1452 ((_ sign_extend 16) in19_16)))
(let ((?x1608 (bvsub ?x1452 ?x991)))
(let ((?x1921 ((_ extract 15 0) ?x1608)))
(let ((?x1379 ((_ sign_extend 16) ?x1921)))
(let ((?x694 (ite (and (distinct (_ bv4294934528 32) ?x1379) true) (_ bv1 1) (_ bv0 1))))
(let ((?x1231 (bvxor ?x694 (_ bv1 1))))
(let ((?x1195 ((_ zero_extend 31) ?x1231)))
(let ((?x340 ((_ sign_extend 32) ?x1195)))
(let ((?x257 (ite (and (distinct (_ bv0 64) ?x340) true) (_ bv1 1) (_ bv0 1))))
(let (($x1088 (and (distinct (bvsub ((_ sign_extend 1) ?x1452) ((_ sign_extend 1) ?x991)) ((_ sign_extend 1) ?x1608)) true)))
(let (($x64 (or false false)))
(let (($x929 (or $x64 $x64 (or $x1088))))
(let (($x802 (or $x929 false)))
(let (($x993 (or $x802 false)))
(let (($x902 (or $x993 false false)))
(let (($x348 (or $x902 false false)))
(let (($x1015 (or $x348 false)))
(let (($x10 (or $x1015 false)))
(let (($x36 (or $x10 false false)))
(and (not $x36) (or $x36 (and (distinct ?x257 ?x257) true))))))))))))))))))))))))
(check-sat)
; query 122: function Gsm_Preprocess, block 54, name %55
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in44_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 48) in44_16) ((_ sign_extend 48) in44_16)) true))))))
(check-sat)
; query 123: function Gsm_Preprocess, block 54, name %56
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in44_16 () (_ BitVec 16))
(assert
 (let ((?x1982 ((_ sign_extend 48) in44_16)))
(let ((?x200 (bvshl ?x1982 (_ bv15 64))))
(let (($x114 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x149 (or $x640 $x114)))
(and (not $x149) (or $x149 (and (distinct ?x200 ?x200) true))))))))))
(check-sat)
; query 124: function Gsm_Preprocess, block 54, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_64 () (_ BitVec 64))
(assert
 (let (($x114 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1338 (or false false false)))
(let (($x484 (or $x1338 $x114)))
(and (not $x484) (or $x484 (and (distinct (bvashr in.04_64 (_ bv15 64)) (bvashr in.04_64 (_ bv15 64))) true)))))))
(check-sat)
; query 125: function Gsm_Preprocess, block 54, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_64 () (_ BitVec 64))
(assert
 (let ((?x384 (bvashr in.04_64 (_ bv15 64))))
(let ((?x977 ((_ extract 15 0) ?x384)))
(let (($x114 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1338 (or false false false)))
(let (($x484 (or $x1338 $x114)))
(let (($x565 (or $x484 false)))
(and (not $x565) (or $x565 (and (distinct ?x977 ?x977) true))))))))))
(check-sat)
; query 126: function Gsm_Preprocess, block 54, name %59
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_64 () (_ BitVec 64))
(assert
 (let ((?x384 (bvashr in.04_64 (_ bv15 64))))
(let ((?x977 ((_ extract 15 0) ?x384)))
(let ((?x274 ((_ sign_extend 48) ?x977)))
(let (($x114 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1338 (or false false false)))
(let (($x484 (or $x1338 $x114)))
(let (($x565 (or $x484 false)))
(let (($x888 (or $x565 false)))
(and (not $x888) (or $x888 (and (distinct ?x274 ?x274) true))))))))))))
(check-sat)
; query 127: function Gsm_Preprocess, block 54, name %60
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_64 () (_ BitVec 64))
(assert
 (let ((?x384 (bvashr in.04_64 (_ bv15 64))))
(let ((?x977 ((_ extract 15 0) ?x384)))
(let ((?x274 ((_ sign_extend 48) ?x977)))
(let ((?x277 (bvshl ?x274 (_ bv15 64))))
(let (($x114 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1338 (or false false false)))
(let (($x484 (or $x1338 $x114)))
(let (($x565 (or $x484 false)))
(let (($x888 (or $x565 false)))
(let (($x947 (or (or $x888 false false) $x114)))
(and (not $x947) (or $x947 (and (distinct ?x277 ?x277) true))))))))))))))
(check-sat)
; query 128: function Gsm_Preprocess, block 54, name %61
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_64 () (_ BitVec 64))
(assert
 (let ((?x384 (bvashr in.04_64 (_ bv15 64))))
(let ((?x977 ((_ extract 15 0) ?x384)))
(let ((?x274 ((_ sign_extend 48) ?x977)))
(let ((?x277 (bvshl ?x274 (_ bv15 64))))
(let ((?x1717 (bvsub in.04_64 ?x277)))
(let (($x1718 (and (distinct (bvsub ((_ sign_extend 1) in.04_64) ((_ sign_extend 1) ?x277)) ((_ sign_extend 1) ?x1717)) true)))
(let (($x114 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1338 (or false false false)))
(let (($x484 (or $x1338 $x114)))
(let (($x565 (or $x484 false)))
(let (($x888 (or $x565 false)))
(let (($x947 (or (or $x888 false false) $x114)))
(let (($x1781 (or false $x947 (or $x1718))))
(and (not $x1781) (or $x1781 (and (distinct ?x1717 ?x1717) true)))))))))))))))))
(check-sat)
; query 129: function Gsm_Preprocess, block 54, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_64 () (_ BitVec 64))
(assert
 (let ((?x384 (bvashr in.04_64 (_ bv15 64))))
(let ((?x977 ((_ extract 15 0) ?x384)))
(let ((?x274 ((_ sign_extend 48) ?x977)))
(let ((?x277 (bvshl ?x274 (_ bv15 64))))
(let ((?x1717 (bvsub in.04_64 ?x277)))
(let ((?x1588 ((_ extract 15 0) ?x1717)))
(let (($x1718 (and (distinct (bvsub ((_ sign_extend 1) in.04_64) ((_ sign_extend 1) ?x277)) ((_ sign_extend 1) ?x1717)) true)))
(let (($x114 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1338 (or false false false)))
(let (($x484 (or $x1338 $x114)))
(let (($x565 (or $x484 false)))
(let (($x888 (or $x565 false)))
(let (($x947 (or (or $x888 false false) $x114)))
(let (($x1781 (or false $x947 (or $x1718))))
(let (($x299 (or $x1781 false)))
(and (not $x299) (or $x299 (and (distinct ?x1588 ?x1588) true)))))))))))))))))))
(check-sat)
; query 130: function Gsm_Preprocess, block 54, name %63
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_64 () (_ BitVec 64))
(assert
 (let ((?x384 (bvashr in.04_64 (_ bv15 64))))
(let ((?x977 ((_ extract 15 0) ?x384)))
(let ((?x274 ((_ sign_extend 48) ?x977)))
(let ((?x277 (bvshl ?x274 (_ bv15 64))))
(let ((?x1717 (bvsub in.04_64 ?x277)))
(let ((?x1588 ((_ extract 15 0) ?x1717)))
(let ((?x453 ((_ sign_extend 48) ?x1588)))
(let (($x1718 (and (distinct (bvsub ((_ sign_extend 1) in.04_64) ((_ sign_extend 1) ?x277)) ((_ sign_extend 1) ?x1717)) true)))
(let (($x114 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1338 (or false false false)))
(let (($x484 (or $x1338 $x114)))
(let (($x565 (or $x484 false)))
(let (($x888 (or $x565 false)))
(let (($x947 (or (or $x888 false false) $x114)))
(let (($x1781 (or false $x947 (or $x1718))))
(let (($x299 (or $x1781 false)))
(let (($x531 (or $x299 false)))
(and (not $x531) (or $x531 (and (distinct ?x453 ?x453) true)))))))))))))))))))))
(check-sat)
; query 131: function Gsm_Preprocess, block 54, name %64
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_64 () (_ BitVec 64))
(assert
 (let ((?x384 (bvashr in.04_64 (_ bv15 64))))
(let ((?x977 ((_ extract 15 0) ?x384)))
(let ((?x274 ((_ sign_extend 48) ?x977)))
(let ((?x277 (bvshl ?x274 (_ bv15 64))))
(let ((?x1717 (bvsub in.04_64 ?x277)))
(let ((?x1588 ((_ extract 15 0) ?x1717)))
(let ((?x453 ((_ sign_extend 48) ?x1588)))
(let ((?x513 (bvmul ?x453 (_ bv32735 64))))
(let (($x1039 (and (distinct (bvmul ((_ sign_extend 64) ?x453) ((_ sign_extend 64) (_ bv32735 64))) ((_ sign_extend 64) ?x513)) true)))
(let (($x1718 (and (distinct (bvsub ((_ sign_extend 1) in.04_64) ((_ sign_extend 1) ?x277)) ((_ sign_extend 1) ?x1717)) true)))
(let (($x114 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1338 (or false false false)))
(let (($x484 (or $x1338 $x114)))
(let (($x565 (or $x484 false)))
(let (($x888 (or $x565 false)))
(let (($x947 (or (or $x888 false false) $x114)))
(let (($x1781 (or false $x947 (or $x1718))))
(let (($x299 (or $x1781 false)))
(let (($x531 (or $x299 false)))
(let (($x179 (or $x531 false (or $x1039))))
(and (not $x179) (or $x179 (and (distinct ?x513 ?x513) true))))))))))))))))))))))))
(check-sat)
; query 132: function Gsm_Preprocess, block 54, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_64 () (_ BitVec 64))
(assert
 (let ((?x384 (bvashr in.04_64 (_ bv15 64))))
(let ((?x977 ((_ extract 15 0) ?x384)))
(let ((?x274 ((_ sign_extend 48) ?x977)))
(let ((?x277 (bvshl ?x274 (_ bv15 64))))
(let ((?x1717 (bvsub in.04_64 ?x277)))
(let ((?x1588 ((_ extract 15 0) ?x1717)))
(let ((?x453 ((_ sign_extend 48) ?x1588)))
(let ((?x513 (bvmul ?x453 (_ bv32735 64))))
(let ((?x338 (bvadd ?x513 (_ bv16384 64))))
(let (($x701 (and (distinct (bvadd ((_ sign_extend 1) ?x513) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x338)) true)))
(let (($x1039 (and (distinct (bvmul ((_ sign_extend 64) ?x453) ((_ sign_extend 64) (_ bv32735 64))) ((_ sign_extend 64) ?x513)) true)))
(let (($x1718 (and (distinct (bvsub ((_ sign_extend 1) in.04_64) ((_ sign_extend 1) ?x277)) ((_ sign_extend 1) ?x1717)) true)))
(let (($x114 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1338 (or false false false)))
(let (($x484 (or $x1338 $x114)))
(let (($x565 (or $x484 false)))
(let (($x888 (or $x565 false)))
(let (($x947 (or (or $x888 false false) $x114)))
(let (($x1781 (or false $x947 (or $x1718))))
(let (($x299 (or $x1781 false)))
(let (($x531 (or $x299 false)))
(let (($x179 (or $x531 false (or $x1039))))
(let (($x1648 (or $x179 false (or $x701))))
(and (not $x1648) (or $x1648 (and (distinct ?x338 ?x338) true)))))))))))))))))))))))))))
(check-sat)
; query 133: function Gsm_Preprocess, block 54, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_64 () (_ BitVec 64))
(assert
 (let ((?x384 (bvashr in.04_64 (_ bv15 64))))
(let ((?x977 ((_ extract 15 0) ?x384)))
(let ((?x274 ((_ sign_extend 48) ?x977)))
(let ((?x277 (bvshl ?x274 (_ bv15 64))))
(let ((?x1717 (bvsub in.04_64 ?x277)))
(let ((?x1588 ((_ extract 15 0) ?x1717)))
(let ((?x453 ((_ sign_extend 48) ?x1588)))
(let ((?x513 (bvmul ?x453 (_ bv32735 64))))
(let ((?x338 (bvadd ?x513 (_ bv16384 64))))
(let ((?x1621 (bvashr ?x338 (_ bv15 64))))
(let (($x114 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x701 (and (distinct (bvadd ((_ sign_extend 1) ?x513) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x338)) true)))
(let (($x1039 (and (distinct (bvmul ((_ sign_extend 64) ?x453) ((_ sign_extend 64) (_ bv32735 64))) ((_ sign_extend 64) ?x513)) true)))
(let (($x1718 (and (distinct (bvsub ((_ sign_extend 1) in.04_64) ((_ sign_extend 1) ?x277)) ((_ sign_extend 1) ?x1717)) true)))
(let (($x1338 (or false false false)))
(let (($x484 (or $x1338 $x114)))
(let (($x565 (or $x484 false)))
(let (($x888 (or $x565 false)))
(let (($x947 (or (or $x888 false false) $x114)))
(let (($x1781 (or false $x947 (or $x1718))))
(let (($x299 (or $x1781 false)))
(let (($x531 (or $x299 false)))
(let (($x179 (or $x531 false (or $x1039))))
(let (($x1648 (or $x179 false (or $x701))))
(let (($x457 (or (or $x1648 false false) $x114)))
(and (not $x457) (or $x457 (and (distinct ?x1621 ?x1621) true)))))))))))))))))))))))))))))
(check-sat)
; query 134: function Gsm_Preprocess, block 54, name %67
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_64 () (_ BitVec 64))
(declare-fun in44_16 () (_ BitVec 16))
(assert
 (let ((?x384 (bvashr in.04_64 (_ bv15 64))))
(let ((?x977 ((_ extract 15 0) ?x384)))
(let ((?x274 ((_ sign_extend 48) ?x977)))
(let ((?x277 (bvshl ?x274 (_ bv15 64))))
(let ((?x1717 (bvsub in.04_64 ?x277)))
(let ((?x1588 ((_ extract 15 0) ?x1717)))
(let ((?x453 ((_ sign_extend 48) ?x1588)))
(let ((?x513 (bvmul ?x453 (_ bv32735 64))))
(let ((?x338 (bvadd ?x513 (_ bv16384 64))))
(let ((?x1621 (bvashr ?x338 (_ bv15 64))))
(let ((?x1982 ((_ sign_extend 48) in44_16)))
(let ((?x200 (bvshl ?x1982 (_ bv15 64))))
(let ((?x1577 (bvadd ?x200 ?x1621)))
(let (($x921 (and (distinct (bvadd ((_ sign_extend 1) ?x200) ((_ sign_extend 1) ?x1621)) ((_ sign_extend 1) ?x1577)) true)))
(let (($x114 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x701 (and (distinct (bvadd ((_ sign_extend 1) ?x513) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x338)) true)))
(let (($x1039 (and (distinct (bvmul ((_ sign_extend 64) ?x453) ((_ sign_extend 64) (_ bv32735 64))) ((_ sign_extend 64) ?x513)) true)))
(let (($x1718 (and (distinct (bvsub ((_ sign_extend 1) in.04_64) ((_ sign_extend 1) ?x277)) ((_ sign_extend 1) ?x1717)) true)))
(let (($x1338 (or false false false)))
(let (($x484 (or $x1338 $x114)))
(let (($x565 (or $x484 false)))
(let (($x888 (or $x565 false)))
(let (($x947 (or (or $x888 false false) $x114)))
(let (($x1781 (or false $x947 (or $x1718))))
(let (($x299 (or $x1781 false)))
(let (($x531 (or $x299 false)))
(let (($x179 (or $x531 false (or $x1039))))
(let (($x1648 (or $x179 false (or $x701))))
(let (($x457 (or (or $x1648 false false) $x114)))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x149 (or $x640 $x114)))
(let (($x1085 (or $x149 $x457 (or $x921))))
(and (not $x1085) (or $x1085 (and (distinct ?x1577 ?x1577) true)))))))))))))))))))))))))))))))))))))
(check-sat)
; query 135: function Gsm_Preprocess, block 54, name %68
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_64 () (_ BitVec 64))
(assert
 (let ((?x384 (bvashr in.04_64 (_ bv15 64))))
(let ((?x977 ((_ extract 15 0) ?x384)))
(let ((?x274 ((_ sign_extend 48) ?x977)))
(let (($x114 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1338 (or false false false)))
(let (($x484 (or $x1338 $x114)))
(let (($x565 (or $x484 false)))
(let (($x888 (or $x565 false)))
(and (not $x888) (or $x888 (and (distinct ?x274 ?x274) true))))))))))))
(check-sat)
; query 136: function Gsm_Preprocess, block 54, name %69
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_64 () (_ BitVec 64))
(assert
 (let ((?x384 (bvashr in.04_64 (_ bv15 64))))
(let ((?x977 ((_ extract 15 0) ?x384)))
(let ((?x274 ((_ sign_extend 48) ?x977)))
(let ((?x354 (bvmul ?x274 (_ bv32735 64))))
(let (($x865 (and (distinct (bvmul ((_ sign_extend 64) ?x274) ((_ sign_extend 64) (_ bv32735 64))) ((_ sign_extend 64) ?x354)) true)))
(let (($x114 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1338 (or false false false)))
(let (($x484 (or $x1338 $x114)))
(let (($x565 (or $x484 false)))
(let (($x888 (or $x565 false)))
(let (($x507 (or $x888 false (or $x865))))
(and (not $x507) (or $x507 (and (distinct ?x354 ?x354) true)))))))))))))))
(check-sat)
; query 137: function Gsm_Preprocess, block 54, name %70
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_64 () (_ BitVec 64))
(assert
 (let ((?x384 (bvashr in.04_64 (_ bv15 64))))
(let ((?x977 ((_ extract 15 0) ?x384)))
(let ((?x274 ((_ sign_extend 48) ?x977)))
(let ((?x354 (bvmul ?x274 (_ bv32735 64))))
(let ((?x923 (ite (bvsgt (_ bv0 64) ?x354) (_ bv1 1) (_ bv0 1))))
(let (($x865 (and (distinct (bvmul ((_ sign_extend 64) ?x274) ((_ sign_extend 64) (_ bv32735 64))) ((_ sign_extend 64) ?x354)) true)))
(let (($x114 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1338 (or false false false)))
(let (($x484 (or $x1338 $x114)))
(let (($x565 (or $x484 false)))
(let (($x888 (or $x565 false)))
(let (($x507 (or $x888 false (or $x865))))
(let (($x422 (or $x507 false false)))
(and (not $x422) (or $x422 (and (distinct ?x923 ?x923) true)))))))))))))))))
(check-sat)
; query 138: function Gsm_Preprocess, block 71, name %72
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in67_64 () (_ BitVec 64))
(assert
 (let ((?x634 (ite (bvsle (_ bv0 64) in67_64) (_ bv1 1) (_ bv0 1))))
(let (($x1338 (or false false false)))
(let (($x1128 (not $x1338)))
(and $x1128 (or $x1338 (and (distinct ?x634 ?x634) true)))))))
(check-sat)
; query 139: function Gsm_Preprocess, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in69_64 () (_ BitVec 64))
(declare-fun in67_64 () (_ BitVec 64))
(assert
 (let ((?x1785 (bvadd in67_64 in69_64)))
(let ((?x1795 (bvadd in69_64 in67_64)))
(let (($x1811 (and (distinct ?x1795 ?x1785) true)))
(let (($x1016 (and (distinct (bvadd ((_ sign_extend 1) in67_64) ((_ sign_extend 1) in69_64)) ((_ sign_extend 1) ?x1785)) true)))
(let (($x1762 (and (distinct (bvadd ((_ sign_extend 1) in69_64) ((_ sign_extend 1) in67_64)) ((_ sign_extend 1) ?x1795)) true)))
(and (not (or false false (or $x1762))) (or (or false false (or $x1016)) $x1811))))))))
(check-sat)
; query 140: function Gsm_Preprocess, block 75, name %76
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in69_64 () (_ BitVec 64))
(assert
 (let ((?x1300 (bvadd in69_64 (_ bv1 64))))
(let ((?x554 ((_ sign_extend 1) ?x1300)))
(let (($x171 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in69_64) ((_ sign_extend 1) (_ bv1 64))) ?x554) true)))))
(and (not $x171) (or $x171 (and (distinct ?x1300 ?x1300) true)))))))
(check-sat)
; query 141: function Gsm_Preprocess, block 75, name %77
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in69_64 () (_ BitVec 64))
(assert
 (let ((?x1300 (bvadd in69_64 (_ bv1 64))))
(let ((?x1315 (bvsub (_ bv0 64) ?x1300)))
(let (($x329 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1300)) ((_ sign_extend 1) ?x1315)) true)))
(let ((?x554 ((_ sign_extend 1) ?x1300)))
(let (($x171 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in69_64) ((_ sign_extend 1) (_ bv1 64))) ?x554) true)))))
(let (($x1309 (or false $x171 (or $x329))))
(and (not $x1309) (or $x1309 (and (distinct ?x1315 ?x1315) true))))))))))
(check-sat)
; query 142: function Gsm_Preprocess, block 75, name %78
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in67_64 () (_ BitVec 64))
(assert
 (let ((?x1295 (bvadd in67_64 (_ bv1 64))))
(let ((?x472 ((_ sign_extend 1) ?x1295)))
(let (($x1328 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in67_64) ((_ sign_extend 1) (_ bv1 64))) ?x472) true)))))
(and (not $x1328) (or $x1328 (and (distinct ?x1295 ?x1295) true)))))))
(check-sat)
; query 143: function Gsm_Preprocess, block 75, name %79
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in67_64 () (_ BitVec 64))
(assert
 (let ((?x1295 (bvadd in67_64 (_ bv1 64))))
(let ((?x1322 (bvsub (_ bv0 64) ?x1295)))
(let (($x212 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1295)) ((_ sign_extend 1) ?x1322)) true)))
(let ((?x472 ((_ sign_extend 1) ?x1295)))
(let (($x1328 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in67_64) ((_ sign_extend 1) (_ bv1 64))) ?x472) true)))))
(let (($x1314 (or false $x1328 (or $x212))))
(and (not $x1314) (or $x1314 (and (distinct ?x1322 ?x1322) true))))))))))
(check-sat)
; query 144: function Gsm_Preprocess, block 75, name %80
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in69_64 () (_ BitVec 64))
(declare-fun in67_64 () (_ BitVec 64))
(assert
 (let ((?x1300 (bvadd in69_64 (_ bv1 64))))
(let ((?x1315 (bvsub (_ bv0 64) ?x1300)))
(let ((?x1295 (bvadd in67_64 (_ bv1 64))))
(let ((?x1322 (bvsub (_ bv0 64) ?x1295)))
(let ((?x1342 (bvadd ?x1322 ?x1315)))
(let ((?x1341 (bvadd ?x1315 ?x1322)))
(let (($x329 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1300)) ((_ sign_extend 1) ?x1315)) true)))
(let ((?x554 ((_ sign_extend 1) ?x1300)))
(let (($x171 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in69_64) ((_ sign_extend 1) (_ bv1 64))) ?x554) true)))))
(let (($x1309 (or false $x171 (or $x329))))
(let (($x212 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1295)) ((_ sign_extend 1) ?x1322)) true)))
(let ((?x472 ((_ sign_extend 1) ?x1295)))
(let (($x1328 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in67_64) ((_ sign_extend 1) (_ bv1 64))) ?x472) true)))))
(let (($x1314 (or false $x1328 (or $x212))))
(let (($x1327 (or $x1314 $x1309 false)))
(and (not (or $x1309 $x1314 false)) (or $x1327 (and (distinct ?x1341 ?x1342) true)))))))))))))))))))
(check-sat)
; query 145: function Gsm_Preprocess, block 75, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in69_64 () (_ BitVec 64))
(declare-fun in67_64 () (_ BitVec 64))
(assert
 (let ((?x1300 (bvadd in69_64 (_ bv1 64))))
(let ((?x1315 (bvsub (_ bv0 64) ?x1300)))
(let ((?x1295 (bvadd in67_64 (_ bv1 64))))
(let ((?x1322 (bvsub (_ bv0 64) ?x1295)))
(let ((?x1342 (bvadd ?x1322 ?x1315)))
(let (($x1512 (and (distinct (ite (bvuge (bvadd ?x1315 ?x1322) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1)) (ite (bvuge ?x1342 (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))) true)))
(let (($x329 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1300)) ((_ sign_extend 1) ?x1315)) true)))
(let ((?x554 ((_ sign_extend 1) ?x1300)))
(let (($x171 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in69_64) ((_ sign_extend 1) (_ bv1 64))) ?x554) true)))))
(let (($x1309 (or false $x171 (or $x329))))
(let (($x212 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1295)) ((_ sign_extend 1) ?x1322)) true)))
(let ((?x472 ((_ sign_extend 1) ?x1295)))
(let (($x1328 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in67_64) ((_ sign_extend 1) (_ bv1 64))) ?x472) true)))))
(let (($x1314 (or false $x1328 (or $x212))))
(let (($x1327 (or $x1314 $x1309 false)))
(and (not (or (or $x1309 $x1314 false) false false)) (or (or $x1327 false false) $x1512))))))))))))))))))
(check-sat)
; query 146: function Gsm_Preprocess, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in80_64 () (_ BitVec 64))
(assert
 (let ((?x1416 (bvsub (_ bv0 64) in80_64)))
(let ((?x1403 ((_ sign_extend 1) ?x1416)))
(let (($x1102 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in80_64)) ?x1403) true)))))
(and (not $x1102) (or $x1102 (and (distinct ?x1416 ?x1416) true)))))))
(check-sat)
; query 147: function Gsm_Preprocess, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in80_64 () (_ BitVec 64))
(assert
 (let ((?x1416 (bvsub (_ bv0 64) in80_64)))
(let ((?x1419 (bvsub ?x1416 (_ bv2 64))))
(let ((?x1403 ((_ sign_extend 1) ?x1416)))
(let (($x1102 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in80_64)) ?x1403) true)))))
(let (($x1333 (or $x1102 false (or (and (distinct (bvsub ?x1403 ((_ sign_extend 1) (_ bv2 64))) ((_ sign_extend 1) ?x1419)) true)))))
(and (not $x1333) (or (or $x1102 false false) (and (distinct ?x1419 (bvadd ?x1416 (_ bv18446744073709551614 64))) true)))))))))
(check-sat)
; query 148: function Gsm_Preprocess, block 90, name %91
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in67_64 () (_ BitVec 64))
(assert
 (let ((?x1450 (ite (bvsge (_ bv0 64) in67_64) (_ bv1 1) (_ bv0 1))))
(let (($x1338 (or false false false)))
(let (($x1128 (not $x1338)))
(and $x1128 (or $x1338 (and (distinct ?x1450 ?x1450) true)))))))
(check-sat)
; query 149: function Gsm_Preprocess, block 92, name %93
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in69_64 () (_ BitVec 64))
(declare-fun in67_64 () (_ BitVec 64))
(assert
 (let ((?x1785 (bvadd in67_64 in69_64)))
(let ((?x1795 (bvadd in69_64 in67_64)))
(let (($x1811 (and (distinct ?x1795 ?x1785) true)))
(let (($x1016 (and (distinct (bvadd ((_ sign_extend 1) in67_64) ((_ sign_extend 1) in69_64)) ((_ sign_extend 1) ?x1785)) true)))
(let (($x1762 (and (distinct (bvadd ((_ sign_extend 1) in69_64) ((_ sign_extend 1) in67_64)) ((_ sign_extend 1) ?x1795)) true)))
(and (not (or false false (or $x1762))) (or (or false false (or $x1016)) $x1811))))))))
(check-sat)
; query 150: function Gsm_Preprocess, block 94, name %95
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in69_64 () (_ BitVec 64))
(declare-fun in67_64 () (_ BitVec 64))
(assert
 (let ((?x1785 (bvadd in67_64 in69_64)))
(let ((?x1795 (bvadd in69_64 in67_64)))
(let (($x1811 (and (distinct ?x1795 ?x1785) true)))
(let (($x1338 (or false false false)))
(let (($x1128 (not $x1338)))
(and $x1128 (or $x1338 $x1811))))))))
(check-sat)
; query 151: function Gsm_Preprocess, block 94, name %96
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in69_64 () (_ BitVec 64))
(declare-fun in67_64 () (_ BitVec 64))
(assert
 (let (($x1476 (and (distinct (ite (bvuge (bvadd in69_64 in67_64) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1)) (ite (bvuge (bvadd in67_64 in69_64) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))) true)))
(let (($x1338 (or false false false)))
(let (($x1599 (or $x1338 false false)))
(let (($x635 (not $x1599)))
(and $x635 (or $x1599 $x1476)))))))
(check-sat)
; query 152: function LARp_to_rp, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in19_16) ((_ sign_extend 16) in19_16)) true))))))
(check-sat)
; query 153: function LARp_to_rp, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x1452 ((_ sign_extend 16) in19_16)))
(let ((?x1506 (bvshl ?x1452 (_ bv1 32))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x2058 (or $x640 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x984 (not $x2058)))
(and $x984 (or $x2058 (and (distinct ?x1506 ?x1506) true))))))))))
(check-sat)
; query 154: function LARp_to_rp, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x1452 ((_ sign_extend 16) in19_16)))
(let ((?x1506 (bvshl ?x1452 (_ bv1 32))))
(let ((?x1484 ((_ sign_extend 32) ?x1506)))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x2058 (or $x640 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x1495 (or $x2058 false)))
(let (($x1677 (not $x1495)))
(and $x1677 (or $x1495 (and (distinct ?x1484 ?x1484) true))))))))))))
(check-sat)
; query 155: function LARp_to_rp, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in19_16) ((_ sign_extend 16) in19_16)) true))))))
(check-sat)
; query 156: function LARp_to_rp, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x496 (ite (bvsgt (_ bv20070 32) ((_ sign_extend 16) in19_16)) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x140 (not $x640)))
(and $x140 (or $x640 (and (distinct ?x496 ?x496) true))))))))
(check-sat)
; query 157: function LARp_to_rp, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in19_16) ((_ sign_extend 16) in19_16)) true))))))
(check-sat)
; query 158: function LARp_to_rp, block 29, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x1452 ((_ sign_extend 16) in19_16)))
(let ((?x1029 (bvadd ?x1452 (_ bv11059 32))))
(let (($x1537 (and (distinct (bvadd ((_ sign_extend 1) ?x1452) ((_ sign_extend 1) (_ bv11059 32))) ((_ sign_extend 1) ?x1029)) true)))
(let (($x64 (or false false)))
(let (($x1524 (or $x64 false (or $x1537))))
(and (not $x1524) (or $x1524 (and (distinct ?x1029 ?x1029) true)))))))))
(check-sat)
; query 159: function LARp_to_rp, block 29, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x1452 ((_ sign_extend 16) in19_16)))
(let ((?x1029 (bvadd ?x1452 (_ bv11059 32))))
(let ((?x1045 ((_ sign_extend 32) ?x1029)))
(let (($x1537 (and (distinct (bvadd ((_ sign_extend 1) ?x1452) ((_ sign_extend 1) (_ bv11059 32))) ((_ sign_extend 1) ?x1029)) true)))
(let (($x64 (or false false)))
(let (($x1524 (or $x64 false (or $x1537))))
(let (($x294 (or $x1524 false)))
(and (not $x294) (or $x294 (and (distinct ?x1045 ?x1045) true)))))))))))
(check-sat)
; query 160: function LARp_to_rp, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in19_16) ((_ sign_extend 16) in19_16)) true))))))
(check-sat)
; query 161: function LARp_to_rp, block 33, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x1452 ((_ sign_extend 16) in19_16)))
(let ((?x664 (bvashr ?x1452 (_ bv2 32))))
(let (($x2049 (bvuge (_ bv2 32) (_ bv32 32))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x1636 (or $x640 $x2049)))
(and (not $x1636) (or $x1636 (and (distinct ?x664 ?x664) true))))))))))
(check-sat)
; query 162: function LARp_to_rp, block 33, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x1452 ((_ sign_extend 16) in19_16)))
(let ((?x664 (bvashr ?x1452 (_ bv2 32))))
(let ((?x1645 ((_ sign_extend 32) ?x664)))
(let (($x2049 (bvuge (_ bv2 32) (_ bv32 32))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x1636 (or $x640 $x2049)))
(let (($x2048 (or $x1636 false)))
(and (not $x2048) (or $x2048 (and (distinct ?x1645 ?x1645) true))))))))))))
(check-sat)
; query 163: function LARp_to_rp, block 33, name %37
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x1452 ((_ sign_extend 16) in19_16)))
(let ((?x664 (bvashr ?x1452 (_ bv2 32))))
(let ((?x1645 ((_ sign_extend 32) ?x664)))
(let ((?x1657 (bvadd ?x1645 (_ bv26112 64))))
(let ((?x1983 ((_ sign_extend 1) ?x1657)))
(let (($x2049 (bvuge (_ bv2 32) (_ bv32 32))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x1636 (or $x640 $x2049)))
(let (($x2048 (or $x1636 false)))
(let (($x2009 (or $x2048 false (or (and (distinct (bvadd ((_ sign_extend 1) ?x1645) ((_ sign_extend 1) (_ bv26112 64))) ?x1983) true)))))
(and (not $x2009) (or $x2009 (and (distinct ?x1657 ?x1657) true)))))))))))))))
(check-sat)
; query 164: function LARp_to_rp, block 33, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x1452 ((_ sign_extend 16) in19_16)))
(let ((?x664 (bvashr ?x1452 (_ bv2 32))))
(let ((?x1645 ((_ sign_extend 32) ?x664)))
(let ((?x1657 (bvadd ?x1645 (_ bv26112 64))))
(let ((?x1990 (bvsub ?x1657 (_ bv18446744073709518848 64))))
(let (($x1252 (and (distinct (bvsub ((_ sign_extend 1) ?x1657) ((_ sign_extend 1) (_ bv18446744073709518848 64))) ((_ sign_extend 1) ?x1990)) true)))
(let ((?x1983 ((_ sign_extend 1) ?x1657)))
(let (($x2049 (bvuge (_ bv2 32) (_ bv32 32))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x1636 (or $x640 $x2049)))
(let (($x2048 (or $x1636 false)))
(let (($x2009 (or $x2048 false (or (and (distinct (bvadd ((_ sign_extend 1) ?x1645) ((_ sign_extend 1) (_ bv26112 64))) ?x1983) true)))))
(let (($x1950 (or $x2009 false (or $x1252))))
(and (not $x1950) (or $x1950 (and (distinct ?x1990 ?x1990) true))))))))))))))))))
(check-sat)
; query 165: function LARp_to_rp, block 33, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x1452 ((_ sign_extend 16) in19_16)))
(let ((?x664 (bvashr ?x1452 (_ bv2 32))))
(let ((?x1645 ((_ sign_extend 32) ?x664)))
(let ((?x1657 (bvadd ?x1645 (_ bv26112 64))))
(let ((?x1990 (bvsub ?x1657 (_ bv18446744073709518848 64))))
(let ((?x469 (ite (bvugt ?x1990 (_ bv65535 64)) (_ bv1 1) (_ bv0 1))))
(let (($x1252 (and (distinct (bvsub ((_ sign_extend 1) ?x1657) ((_ sign_extend 1) (_ bv18446744073709518848 64))) ((_ sign_extend 1) ?x1990)) true)))
(let ((?x1983 ((_ sign_extend 1) ?x1657)))
(let (($x2049 (bvuge (_ bv2 32) (_ bv32 32))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x1636 (or $x640 $x2049)))
(let (($x2048 (or $x1636 false)))
(let (($x2009 (or $x2048 false (or (and (distinct (bvadd ((_ sign_extend 1) ?x1645) ((_ sign_extend 1) (_ bv26112 64))) ?x1983) true)))))
(let (($x1950 (or $x2009 false (or $x1252))))
(let (($x1969 (or $x1950 false false)))
(and (not $x1969) (or $x1969 (and (distinct ?x469 ?x469) true))))))))))))))))))))
(check-sat)
; query 166: function Long_term_analysis_filtering, block 117, name %118
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in114_64 () (_ BitVec 64))
(assert
 (let ((?x1863 (ite (bvsge (_ bv18446744073709518848 64) in114_64) (_ bv1 1) (_ bv0 1))))
(let (($x1338 (or false false false)))
(let (($x1128 (not $x1338)))
(and $x1128 (or $x1338 (and (distinct ?x1863 ?x1863) true)))))))
(check-sat)
; query 167: function Long_term_analysis_filtering, block 128, name %129
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let (($x1161 (and (distinct (bvadd ((_ sign_extend 1) in.2_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.2_32 (_ bv1 32)))) true)))
(let (($x648 (or false false (or $x1161))))
(and (not $x648) (or $x648 (and (distinct (bvadd in.2_32 (_ bv1 32)) (bvadd in.2_32 (_ bv1 32))) true))))))
(check-sat)
; query 168: function Long_term_analysis_filtering, block 158, name %159
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in155_64 () (_ BitVec 64))
(assert
 (let ((?x1767 (ite (bvsge (_ bv18446744073709518848 64) in155_64) (_ bv1 1) (_ bv0 1))))
(let (($x1338 (or false false false)))
(let (($x1128 (not $x1338)))
(and $x1128 (or $x1338 (and (distinct ?x1767 ?x1767) true)))))))
(check-sat)
; query 169: function Long_term_analysis_filtering, block 169, name %170
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.3_32 () (_ BitVec 32))
(assert
 (let (($x1191 (and (distinct (bvadd ((_ sign_extend 1) in.3_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.3_32 (_ bv1 32)))) true)))
(let (($x569 (or false false (or $x1191))))
(and (not $x569) (or $x569 (and (distinct (bvadd in.3_32 (_ bv1 32)) (bvadd in.3_32 (_ bv1 32))) true))))))
(check-sat)
; query 170: function Long_term_analysis_filtering, block 35, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in32_64 () (_ BitVec 64))
(assert
 (let ((?x1848 (ite (bvsge (_ bv18446744073709518848 64) in32_64) (_ bv1 1) (_ bv0 1))))
(let (($x1338 (or false false false)))
(let (($x1128 (not $x1338)))
(and $x1128 (or $x1338 (and (distinct ?x1848 ?x1848) true)))))))
(check-sat)
; query 171: function Long_term_analysis_filtering, block 46, name %47
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1141 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x1619 (or false false (or $x1141))))
(and (not $x1619) (or $x1619 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 172: function Long_term_analysis_filtering, block 76, name %77
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in73_64 () (_ BitVec 64))
(assert
 (let ((?x1745 (ite (bvsge (_ bv18446744073709518848 64) in73_64) (_ bv1 1) (_ bv0 1))))
(let (($x1338 (or false false false)))
(let (($x1128 (not $x1338)))
(and $x1128 (or $x1338 (and (distinct ?x1745 ?x1745) true)))))))
(check-sat)
; query 173: function Long_term_analysis_filtering, block 87, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x809 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x1013 (or false false (or $x809))))
(and (not $x1013) (or $x1013 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 174: function RPE_grid_positioning, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.27_32 () (_ BitVec 32))
(assert
 (let (($x985 (and (distinct (bvadd ((_ sign_extend 1) in.27_32) ((_ sign_extend 1) (_ bv4294967295 32))) ((_ sign_extend 1) (bvadd in.27_32 (_ bv4294967295 32)))) true)))
(let (($x728 (or false false (or $x985))))
(and (not $x728) (or $x728 (and (distinct (bvadd in.27_32 (_ bv4294967295 32)) (bvadd in.27_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 175: function RPE_grid_positioning, block 31, name %33
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.27_32 () (_ BitVec 32))
(assert
 (let ((?x976 (ite (and (distinct (_ bv0 32) (bvadd in.27_32 (_ bv4294967295 32))) true) (_ bv1 1) (_ bv0 1))))
(let (($x985 (and (distinct (bvadd ((_ sign_extend 1) in.27_32) ((_ sign_extend 1) (_ bv4294967295 32))) ((_ sign_extend 1) (bvadd in.27_32 (_ bv4294967295 32)))) true)))
(let (($x728 (or false false (or $x985))))
(let (($x721 (or $x728 false false)))
(and (not $x721) (or $x721 (and (distinct ?x976 ?x976) true))))))))
(check-sat)
; query 176: function RPE_grid_positioning, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 177: function RPE_grid_positioning, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x960 (ite (bvsge (_ bv3 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x140 (not $x640)))
(and $x140 (or $x640 (and (distinct ?x960 ?x960) true))))))))
(check-sat)
; query 178: function RPE_grid_positioning, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 179: function RPE_grid_positioning, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1393 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1497 (and (distinct ?x1393 ?x1393) true)))
(let (($x64 (or false false)))
(let (($x1378 (or false $x64 false)))
(and (not $x1378) (or $x1378 $x1497)))))))
(check-sat)
; query 180: function Reflection_coefficients, block 101, name %102
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in89_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in89_16) ((_ sign_extend 16) in89_16)) true))))))
(check-sat)
; query 181: function Reflection_coefficients, block 116, name %117
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.4_32 () (_ BitVec 32))
(assert
 (let (($x1561 (and (distinct (bvadd ((_ sign_extend 1) in.4_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.4_32 (_ bv1 32)))) true)))
(let (($x1631 (or false false (or $x1561))))
(and (not $x1631) (or $x1631 (and (distinct (bvadd in.4_32 (_ bv1 32)) (bvadd in.4_32 (_ bv1 32))) true))))))
(check-sat)
; query 182: function Reflection_coefficients, block 154, name %155
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.05_32 () (_ BitVec 32))
(assert
 (let ((?x1289 (ite (= (_ bv8 32) in.05_32) (_ bv1 1) (_ bv0 1))))
(let (($x1338 (or false false false)))
(let (($x1128 (not $x1338)))
(and $x1128 (or $x1338 (and (distinct ?x1289 ?x1289) true)))))))
(check-sat)
; query 183: function Reflection_coefficients, block 34, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in31_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in31_16) ((_ sign_extend 16) in31_16)) true))))))
(check-sat)
; query 184: function Reflection_coefficients, block 34, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in31_16 () (_ BitVec 16))
(assert
 (let ((?x638 (ite (bvsgt (_ bv32 32) ((_ sign_extend 16) in31_16)) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x140 (not $x640)))
(and $x140 (or $x640 (and (distinct ?x638 ?x638) true))))))))
(check-sat)
; query 185: function Reflection_coefficients, block 60, name %61
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x1623 (and (distinct (bvadd ((_ sign_extend 1) in.12_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.12_32 (_ bv1 32)))) true)))
(let (($x216 (or false false (or $x1623))))
(and (not $x216) (or $x216 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 186: function Reflection_coefficients, block 71, name %72
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.23_32 () (_ BitVec 32))
(assert
 (let (($x1137 (and (distinct (bvadd ((_ sign_extend 1) in.23_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.23_32 (_ bv1 32)))) true)))
(let (($x997 (or false false (or $x1137))))
(and (not $x997) (or $x997 (and (distinct (bvadd in.23_32 (_ bv1 32)) (bvadd in.23_32 (_ bv1 32))) true))))))
(check-sat)
; query 187: function Reflection_coefficients, block 82, name %83
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.3_32 () (_ BitVec 32))
(assert
 (let (($x1191 (and (distinct (bvadd ((_ sign_extend 1) in.3_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.3_32 (_ bv1 32)))) true)))
(let (($x569 (or false false (or $x1191))))
(and (not $x569) (or $x569 (and (distinct (bvadd in.3_32 (_ bv1 32)) (bvadd in.3_32 (_ bv1 32))) true))))))
(check-sat)
; query 188: function Reflection_coefficients, block 92, name %93
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in89_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in89_16) ((_ sign_extend 16) in89_16)) true))))))
(check-sat)
; query 189: function Reflection_coefficients, block 92, name %94
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in89_16 () (_ BitVec 16))
(assert
 (let ((?x413 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in89_16)) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x140 (not $x640)))
(and $x140 (or $x640 (and (distinct ?x413 ?x413) true))))))))
(check-sat)
; query 190: function Reflection_coefficients, block 96, name %97
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in89_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in89_16) ((_ sign_extend 16) in89_16)) true))))))
(check-sat)
; query 191: function Reflection_coefficients, block 96, name %98
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in89_16 () (_ BitVec 16))
(assert
 (let ((?x633 ((_ sign_extend 16) in89_16)))
(let ((?x1483 (bvsub (_ bv0 32) ?x633)))
(let (($x168 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x633)) ((_ sign_extend 1) ?x1483)) true)))
(let (($x64 (or false false)))
(let (($x2098 (or false $x64 (or $x168))))
(and (not $x2098) (or $x2098 (and (distinct ?x1483 ?x1483) true)))))))))
(check-sat)
; query 192: function Short_term_synthesis_filtering, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in23_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in23_16) ((_ sign_extend 16) in23_16)) true))))))
(check-sat)
; query 193: function Short_term_synthesis_filtering, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in23_16 () (_ BitVec 16))
(assert
 (let ((?x1098 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in23_16)) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x140 (not $x640)))
(and $x140 (or $x640 (and (distinct ?x1098 ?x1098) true))))))))
(check-sat)
; query 194: function Short_term_synthesis_filtering, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in20_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 48) in20_16) ((_ sign_extend 48) in20_16)) true))))))
(check-sat)
; query 195: function Short_term_synthesis_filtering, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in23_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 48) in23_16) ((_ sign_extend 48) in23_16)) true))))))
(check-sat)
; query 196: function Short_term_synthesis_filtering, block 30, name %33
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in20_16 () (_ BitVec 16))
(declare-fun in23_16 () (_ BitVec 16))
(assert
 (let ((?x738 ((_ sign_extend 48) in20_16)))
(let ((?x103 ((_ sign_extend 48) in23_16)))
(let ((?x878 (bvmul ?x103 ?x738)))
(let ((?x586 (bvmul ?x738 ?x103)))
(let (($x1038 (and (distinct (bvmul ((_ sign_extend 64) ?x103) ((_ sign_extend 64) ?x738)) ((_ sign_extend 64) ?x878)) true)))
(let (($x64 (or false false)))
(let (($x763 (or $x64 $x64 (or $x1038))))
(let (($x97 (and (distinct (bvmul ((_ sign_extend 64) ?x738) ((_ sign_extend 64) ?x103)) ((_ sign_extend 64) ?x586)) true)))
(let (($x1108 (or $x64 $x64 (or $x97))))
(and (not $x1108) (or $x763 (and (distinct ?x586 ?x878) true)))))))))))))
(check-sat)
; query 197: function Short_term_synthesis_filtering, block 30, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in20_16 () (_ BitVec 16))
(declare-fun in23_16 () (_ BitVec 16))
(assert
 (let ((?x738 ((_ sign_extend 48) in20_16)))
(let ((?x103 ((_ sign_extend 48) in23_16)))
(let ((?x878 (bvmul ?x103 ?x738)))
(let ((?x1633 (bvadd ?x878 (_ bv16384 64))))
(let ((?x586 (bvmul ?x738 ?x103)))
(let ((?x1018 (bvadd ?x586 (_ bv16384 64))))
(let (($x1127 (and (distinct (bvadd ((_ sign_extend 1) ?x878) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x1633)) true)))
(let (($x1038 (and (distinct (bvmul ((_ sign_extend 64) ?x103) ((_ sign_extend 64) ?x738)) ((_ sign_extend 64) ?x878)) true)))
(let (($x64 (or false false)))
(let (($x763 (or $x64 $x64 (or $x1038))))
(let (($x1971 (or $x763 false (or $x1127))))
(let (($x924 (and (distinct (bvadd ((_ sign_extend 1) ?x586) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x1018)) true)))
(let (($x97 (and (distinct (bvmul ((_ sign_extend 64) ?x738) ((_ sign_extend 64) ?x103)) ((_ sign_extend 64) ?x586)) true)))
(let (($x1108 (or $x64 $x64 (or $x97))))
(let (($x1674 (or $x1108 false (or $x924))))
(and (not $x1674) (or $x1971 (and (distinct ?x1018 ?x1633) true)))))))))))))))))))
(check-sat)
; query 198: function Short_term_synthesis_filtering, block 30, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in20_16 () (_ BitVec 16))
(declare-fun in23_16 () (_ BitVec 16))
(assert
 (let ((?x738 ((_ sign_extend 48) in20_16)))
(let ((?x103 ((_ sign_extend 48) in23_16)))
(let ((?x878 (bvmul ?x103 ?x738)))
(let ((?x1633 (bvadd ?x878 (_ bv16384 64))))
(let ((?x776 (bvashr ?x1633 (_ bv15 64))))
(let ((?x586 (bvmul ?x738 ?x103)))
(let ((?x1018 (bvadd ?x586 (_ bv16384 64))))
(let ((?x942 (bvashr ?x1018 (_ bv15 64))))
(let (($x114 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1127 (and (distinct (bvadd ((_ sign_extend 1) ?x878) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x1633)) true)))
(let (($x1038 (and (distinct (bvmul ((_ sign_extend 64) ?x103) ((_ sign_extend 64) ?x738)) ((_ sign_extend 64) ?x878)) true)))
(let (($x64 (or false false)))
(let (($x763 (or $x64 $x64 (or $x1038))))
(let (($x1971 (or $x763 false (or $x1127))))
(let (($x761 (or (or $x1971 false false) $x114)))
(let (($x924 (and (distinct (bvadd ((_ sign_extend 1) ?x586) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x1018)) true)))
(let (($x97 (and (distinct (bvmul ((_ sign_extend 64) ?x738) ((_ sign_extend 64) ?x103)) ((_ sign_extend 64) ?x586)) true)))
(let (($x1108 (or $x64 $x64 (or $x97))))
(let (($x1674 (or $x1108 false (or $x924))))
(let (($x685 (or (or $x1674 false false) $x114)))
(and (not $x685) (or $x761 (and (distinct ?x942 ?x776) true))))))))))))))))))))))))
(check-sat)
; query 199: function Short_term_synthesis_filtering, block 30, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in20_16 () (_ BitVec 16))
(declare-fun in23_16 () (_ BitVec 16))
(assert
 (let ((?x738 ((_ sign_extend 48) in20_16)))
(let ((?x103 ((_ sign_extend 48) in23_16)))
(let ((?x878 (bvmul ?x103 ?x738)))
(let ((?x1633 (bvadd ?x878 (_ bv16384 64))))
(let ((?x776 (bvashr ?x1633 (_ bv15 64))))
(let (($x1270 (and (distinct (bvand (_ bv65535 64) (bvashr (bvadd (bvmul ?x738 ?x103) (_ bv16384 64)) (_ bv15 64))) (bvand ?x776 (_ bv65535 64))) true)))
(let (($x114 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1127 (and (distinct (bvadd ((_ sign_extend 1) ?x878) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x1633)) true)))
(let (($x1038 (and (distinct (bvmul ((_ sign_extend 64) ?x103) ((_ sign_extend 64) ?x738)) ((_ sign_extend 64) ?x878)) true)))
(let (($x64 (or false false)))
(let (($x763 (or $x64 $x64 (or $x1038))))
(let (($x1971 (or $x763 false (or $x1127))))
(let (($x761 (or (or $x1971 false false) $x114)))
(let (($x924 (and (distinct (bvadd ((_ sign_extend 1) (bvmul ?x738 ?x103)) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) (bvadd (bvmul ?x738 ?x103) (_ bv16384 64)))) true)))
(let (($x97 (and (distinct (bvmul ((_ sign_extend 64) ?x738) ((_ sign_extend 64) ?x103)) ((_ sign_extend 64) (bvmul ?x738 ?x103))) true)))
(let (($x1108 (or $x64 $x64 (or $x97))))
(let (($x1674 (or $x1108 false (or $x924))))
(let (($x685 (or (or $x1674 false false) $x114)))
(and (not (or false $x685 false)) (or (or $x761 false false) $x1270)))))))))))))))))))))
(check-sat)
; query 200: function Short_term_synthesis_filtering, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in42_64 () (_ BitVec 64))
(assert
 (let ((?x1628 (ite (bvsge (_ bv18446744073709518848 64) in42_64) (_ bv1 1) (_ bv0 1))))
(let (($x1338 (or false false false)))
(let (($x1128 (not $x1338)))
(and $x1128 (or $x1338 (and (distinct ?x1628 ?x1628) true)))))))
(check-sat)
; query 201: function Short_term_synthesis_filtering, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in53_16) ((_ sign_extend 16) in53_16)) true))))))
(check-sat)
; query 202: function Short_term_synthesis_filtering, block 56, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let ((?x1307 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in53_16)) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x140 (not $x640)))
(and $x140 (or $x640 (and (distinct ?x1307 ?x1307) true))))))))
(check-sat)
; query 203: function Short_term_synthesis_filtering, block 60, name %61
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in20_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 48) in20_16) ((_ sign_extend 48) in20_16)) true))))))
(check-sat)
; query 204: function Short_term_synthesis_filtering, block 60, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 48) in53_16) ((_ sign_extend 48) in53_16)) true))))))
(check-sat)
; query 205: function Short_term_synthesis_filtering, block 60, name %63
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in20_16 () (_ BitVec 16))
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let ((?x738 ((_ sign_extend 48) in20_16)))
(let ((?x2051 ((_ sign_extend 48) in53_16)))
(let ((?x1947 (bvmul ?x2051 ?x738)))
(let ((?x1190 (bvmul ?x738 ?x2051)))
(let (($x1840 (and (distinct (bvmul ((_ sign_extend 64) ?x2051) ((_ sign_extend 64) ?x738)) ((_ sign_extend 64) ?x1947)) true)))
(let (($x64 (or false false)))
(let (($x2019 (or $x64 $x64 (or $x1840))))
(let (($x1845 (and (distinct (bvmul ((_ sign_extend 64) ?x738) ((_ sign_extend 64) ?x2051)) ((_ sign_extend 64) ?x1190)) true)))
(let (($x2040 (or $x64 $x64 (or $x1845))))
(and (not $x2040) (or $x2019 (and (distinct ?x1190 ?x1947) true)))))))))))))
(check-sat)
; query 206: function Short_term_synthesis_filtering, block 60, name %64
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in20_16 () (_ BitVec 16))
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let ((?x738 ((_ sign_extend 48) in20_16)))
(let ((?x2051 ((_ sign_extend 48) in53_16)))
(let ((?x1947 (bvmul ?x2051 ?x738)))
(let ((?x818 (bvadd ?x1947 (_ bv16384 64))))
(let ((?x1190 (bvmul ?x738 ?x2051)))
(let ((?x438 (bvadd ?x1190 (_ bv16384 64))))
(let (($x1748 (and (distinct (bvadd ((_ sign_extend 1) ?x1947) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x818)) true)))
(let (($x1840 (and (distinct (bvmul ((_ sign_extend 64) ?x2051) ((_ sign_extend 64) ?x738)) ((_ sign_extend 64) ?x1947)) true)))
(let (($x64 (or false false)))
(let (($x2019 (or $x64 $x64 (or $x1840))))
(let (($x1813 (or $x2019 false (or $x1748))))
(let (($x733 (and (distinct (bvadd ((_ sign_extend 1) ?x1190) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x438)) true)))
(let (($x1845 (and (distinct (bvmul ((_ sign_extend 64) ?x738) ((_ sign_extend 64) ?x2051)) ((_ sign_extend 64) ?x1190)) true)))
(let (($x2040 (or $x64 $x64 (or $x1845))))
(let (($x860 (or $x2040 false (or $x733))))
(and (not $x860) (or $x1813 (and (distinct ?x438 ?x818) true)))))))))))))))))))
(check-sat)
; query 207: function Short_term_synthesis_filtering, block 60, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in20_16 () (_ BitVec 16))
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let ((?x738 ((_ sign_extend 48) in20_16)))
(let ((?x2051 ((_ sign_extend 48) in53_16)))
(let ((?x1947 (bvmul ?x2051 ?x738)))
(let ((?x818 (bvadd ?x1947 (_ bv16384 64))))
(let ((?x1247 (bvashr ?x818 (_ bv15 64))))
(let ((?x1190 (bvmul ?x738 ?x2051)))
(let ((?x438 (bvadd ?x1190 (_ bv16384 64))))
(let ((?x1773 (bvashr ?x438 (_ bv15 64))))
(let (($x114 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1748 (and (distinct (bvadd ((_ sign_extend 1) ?x1947) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x818)) true)))
(let (($x1840 (and (distinct (bvmul ((_ sign_extend 64) ?x2051) ((_ sign_extend 64) ?x738)) ((_ sign_extend 64) ?x1947)) true)))
(let (($x64 (or false false)))
(let (($x2019 (or $x64 $x64 (or $x1840))))
(let (($x1813 (or $x2019 false (or $x1748))))
(let (($x1268 (or (or $x1813 false false) $x114)))
(let (($x733 (and (distinct (bvadd ((_ sign_extend 1) ?x1190) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x438)) true)))
(let (($x1845 (and (distinct (bvmul ((_ sign_extend 64) ?x738) ((_ sign_extend 64) ?x2051)) ((_ sign_extend 64) ?x1190)) true)))
(let (($x2040 (or $x64 $x64 (or $x1845))))
(let (($x860 (or $x2040 false (or $x733))))
(let (($x1709 (or (or $x860 false false) $x114)))
(and (not $x1709) (or $x1268 (and (distinct ?x1773 ?x1247) true))))))))))))))))))))))))
(check-sat)
; query 208: function Short_term_synthesis_filtering, block 60, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in20_16 () (_ BitVec 16))
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let ((?x738 ((_ sign_extend 48) in20_16)))
(let ((?x2051 ((_ sign_extend 48) in53_16)))
(let ((?x1947 (bvmul ?x2051 ?x738)))
(let ((?x818 (bvadd ?x1947 (_ bv16384 64))))
(let ((?x1247 (bvashr ?x818 (_ bv15 64))))
(let (($x1814 (and (distinct (bvand (_ bv65535 64) (bvashr (bvadd (bvmul ?x738 ?x2051) (_ bv16384 64)) (_ bv15 64))) (bvand ?x1247 (_ bv65535 64))) true)))
(let (($x114 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1748 (and (distinct (bvadd ((_ sign_extend 1) ?x1947) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x818)) true)))
(let (($x1840 (and (distinct (bvmul ((_ sign_extend 64) ?x2051) ((_ sign_extend 64) ?x738)) ((_ sign_extend 64) ?x1947)) true)))
(let (($x64 (or false false)))
(let (($x2019 (or $x64 $x64 (or $x1840))))
(let (($x1813 (or $x2019 false (or $x1748))))
(let (($x1268 (or (or $x1813 false false) $x114)))
(let (($x733 (and (distinct (bvadd ((_ sign_extend 1) (bvmul ?x738 ?x2051)) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) (bvadd (bvmul ?x738 ?x2051) (_ bv16384 64)))) true)))
(let (($x1845 (and (distinct (bvmul ((_ sign_extend 64) ?x738) ((_ sign_extend 64) ?x2051)) ((_ sign_extend 64) (bvmul ?x738 ?x2051))) true)))
(let (($x2040 (or $x64 $x64 (or $x1845))))
(let (($x860 (or $x2040 false (or $x733))))
(let (($x1709 (or (or $x860 false false) $x114)))
(and (not (or false $x1709 false)) (or (or $x1268 false false) $x1814)))))))))))))))))))))
(check-sat)
; query 209: function Transformation_to_Log_Area_Ratios, block 12, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in5_16) ((_ sign_extend 16) in5_16)) true))))))
(check-sat)
; query 210: function Transformation_to_Log_Area_Ratios, block 12, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_16 () (_ BitVec 16))
(assert
 (let ((?x772 ((_ sign_extend 16) in5_16)))
(let ((?x851 (bvsub (_ bv0 32) ?x772)))
(let (($x867 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x772)) ((_ sign_extend 1) ?x851)) true)))
(let (($x64 (or false false)))
(let (($x160 (or false $x64 (or $x867))))
(and (not $x160) (or $x160 (and (distinct ?x851 ?x851) true)))))))))
(check-sat)
; query 211: function Transformation_to_Log_Area_Ratios, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in5_16) ((_ sign_extend 16) in5_16)) true))))))
(check-sat)
; query 212: function Transformation_to_Log_Area_Ratios, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in21_16) ((_ sign_extend 16) in21_16)) true))))))
(check-sat)
; query 213: function Transformation_to_Log_Area_Ratios, block 31, name %33
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let ((?x1182 (ite (bvsgt (_ bv22118 32) ((_ sign_extend 16) in21_16)) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x140 (not $x640)))
(and $x140 (or $x640 (and (distinct ?x1182 ?x1182) true))))))))
(check-sat)
; query 214: function Transformation_to_Log_Area_Ratios, block 34, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in21_16) ((_ sign_extend 16) in21_16)) true))))))
(check-sat)
; query 215: function Transformation_to_Log_Area_Ratios, block 34, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let ((?x1142 ((_ sign_extend 16) in21_16)))
(let ((?x1697 (bvashr ?x1142 (_ bv1 32))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x2058 (or $x640 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x984 (not $x2058)))
(and $x984 (or $x2058 (and (distinct ?x1697 ?x1697) true))))))))))
(check-sat)
; query 216: function Transformation_to_Log_Area_Ratios, block 34, name %37
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let ((?x1142 ((_ sign_extend 16) in21_16)))
(let ((?x1697 (bvashr ?x1142 (_ bv1 32))))
(let ((?x1779 ((_ extract 15 0) ?x1697)))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x2058 (or $x640 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x1495 (or $x2058 false)))
(let (($x1677 (not $x1495)))
(and $x1677 (or $x1495 (and (distinct ?x1779 ?x1779) true))))))))))))
(check-sat)
; query 217: function Transformation_to_Log_Area_Ratios, block 38, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in21_16) ((_ sign_extend 16) in21_16)) true))))))
(check-sat)
; query 218: function Transformation_to_Log_Area_Ratios, block 38, name %40
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let ((?x850 (ite (bvsgt (_ bv31130 32) ((_ sign_extend 16) in21_16)) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x140 (not $x640)))
(and $x140 (or $x640 (and (distinct ?x850 ?x850) true))))))))
(check-sat)
; query 219: function Transformation_to_Log_Area_Ratios, block 41, name %42
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in21_16) ((_ sign_extend 16) in21_16)) true))))))
(check-sat)
; query 220: function Transformation_to_Log_Area_Ratios, block 41, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let ((?x325 (ite (bvsle (_ bv11059 32) ((_ sign_extend 16) in21_16)) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x140 (not $x640)))
(and $x140 (or $x640 (and (distinct ?x325 ?x325) true))))))))
(check-sat)
; query 221: function Transformation_to_Log_Area_Ratios, block 41, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let ((?x325 (ite (bvsle (_ bv11059 32) ((_ sign_extend 16) in21_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x448 (bvxor ?x325 (_ bv1 1))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x793 (or $x640 false false)))
(let (($x836 (not $x793)))
(and $x836 (or $x793 (and (distinct ?x448 ?x448) true))))))))))
(check-sat)
; query 222: function Transformation_to_Log_Area_Ratios, block 41, name %45
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let ((?x325 (ite (bvsle (_ bv11059 32) ((_ sign_extend 16) in21_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x448 (bvxor ?x325 (_ bv1 1))))
(let ((?x1035 ((_ zero_extend 31) ?x448)))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x793 (or $x640 false false)))
(let (($x361 (or $x793 false)))
(let (($x609 (not $x361)))
(and $x609 (or $x361 (and (distinct ?x1035 ?x1035) true))))))))))))
(check-sat)
; query 223: function Transformation_to_Log_Area_Ratios, block 41, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let ((?x325 (ite (bvsle (_ bv11059 32) ((_ sign_extend 16) in21_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x448 (bvxor ?x325 (_ bv1 1))))
(let ((?x1035 ((_ zero_extend 31) ?x448)))
(let ((?x1090 ((_ sign_extend 32) ?x1035)))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x793 (or $x640 false false)))
(let (($x361 (or $x793 false)))
(let (($x886 (or $x361 false)))
(let (($x1357 (not $x886)))
(and $x1357 (or $x886 (and (distinct ?x1090 ?x1090) true))))))))))))))
(check-sat)
; query 224: function Transformation_to_Log_Area_Ratios, block 41, name %47
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let ((?x325 (ite (bvsle (_ bv11059 32) ((_ sign_extend 16) in21_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x448 (bvxor ?x325 (_ bv1 1))))
(let ((?x1035 ((_ zero_extend 31) ?x448)))
(let ((?x1090 ((_ sign_extend 32) ?x1035)))
(let ((?x273 (ite (and (distinct (_ bv0 64) ?x1090) true) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x793 (or $x640 false false)))
(let (($x361 (or $x793 false)))
(let (($x886 (or $x361 false)))
(let (($x2084 (or $x886 false false)))
(let (($x1528 (not $x2084)))
(and $x1528 (or $x2084 (and (distinct ?x273 ?x273) true))))))))))))))))
(check-sat)
; query 225: function Transformation_to_Log_Area_Ratios, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in21_16) ((_ sign_extend 16) in21_16)) true))))))
(check-sat)
; query 226: function Transformation_to_Log_Area_Ratios, block 51, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let ((?x1142 ((_ sign_extend 16) in21_16)))
(let ((?x846 (bvsub ?x1142 (_ bv11059 32))))
(let (($x1782 (and (distinct (bvsub ((_ sign_extend 1) ?x1142) ((_ sign_extend 1) (_ bv11059 32))) ((_ sign_extend 1) ?x846)) true)))
(let (($x64 (or false false)))
(let (($x744 (or $x64 false (or $x1782))))
(and (not $x744) (or $x744 (and (distinct ?x846 ?x846) true)))))))))
(check-sat)
; query 227: function Transformation_to_Log_Area_Ratios, block 51, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let ((?x1142 ((_ sign_extend 16) in21_16)))
(let ((?x846 (bvsub ?x1142 (_ bv11059 32))))
(let ((?x1740 ((_ extract 15 0) ?x846)))
(let (($x1782 (and (distinct (bvsub ((_ sign_extend 1) ?x1142) ((_ sign_extend 1) (_ bv11059 32))) ((_ sign_extend 1) ?x846)) true)))
(let (($x64 (or false false)))
(let (($x744 (or $x64 false (or $x1782))))
(let (($x1030 (or $x744 false)))
(and (not $x1030) (or $x1030 (and (distinct ?x1740 ?x1740) true)))))))))))
(check-sat)
; query 228: function Transformation_to_Log_Area_Ratios, block 55, name %56
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in21_16) ((_ sign_extend 16) in21_16)) true))))))
(check-sat)
; query 229: function Transformation_to_Log_Area_Ratios, block 55, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let ((?x205 (ite (bvsle (_ bv26112 32) ((_ sign_extend 16) in21_16)) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x140 (not $x640)))
(and $x140 (or $x640 (and (distinct ?x205 ?x205) true))))))))
(check-sat)
; query 230: function Transformation_to_Log_Area_Ratios, block 55, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let ((?x205 (ite (bvsle (_ bv26112 32) ((_ sign_extend 16) in21_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x444 (bvxor ?x205 (_ bv1 1))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x793 (or $x640 false false)))
(let (($x836 (not $x793)))
(and $x836 (or $x793 (and (distinct ?x444 ?x444) true))))))))))
(check-sat)
; query 231: function Transformation_to_Log_Area_Ratios, block 55, name %59
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let ((?x205 (ite (bvsle (_ bv26112 32) ((_ sign_extend 16) in21_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x444 (bvxor ?x205 (_ bv1 1))))
(let ((?x331 ((_ zero_extend 31) ?x444)))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x793 (or $x640 false false)))
(let (($x361 (or $x793 false)))
(let (($x609 (not $x361)))
(and $x609 (or $x361 (and (distinct ?x331 ?x331) true))))))))))))
(check-sat)
; query 232: function Transformation_to_Log_Area_Ratios, block 55, name %60
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let ((?x205 (ite (bvsle (_ bv26112 32) ((_ sign_extend 16) in21_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x444 (bvxor ?x205 (_ bv1 1))))
(let ((?x331 ((_ zero_extend 31) ?x444)))
(let ((?x394 ((_ sign_extend 32) ?x331)))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x793 (or $x640 false false)))
(let (($x361 (or $x793 false)))
(let (($x886 (or $x361 false)))
(let (($x1357 (not $x886)))
(and $x1357 (or $x886 (and (distinct ?x394 ?x394) true))))))))))))))
(check-sat)
; query 233: function Transformation_to_Log_Area_Ratios, block 55, name %61
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let ((?x205 (ite (bvsle (_ bv26112 32) ((_ sign_extend 16) in21_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x444 (bvxor ?x205 (_ bv1 1))))
(let ((?x331 ((_ zero_extend 31) ?x444)))
(let ((?x394 ((_ sign_extend 32) ?x331)))
(let ((?x307 (ite (and (distinct (_ bv0 64) ?x394) true) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x793 (or $x640 false false)))
(let (($x361 (or $x793 false)))
(let (($x886 (or $x361 false)))
(let (($x2084 (or $x886 false false)))
(let (($x1528 (not $x2084)))
(and $x1528 (or $x2084 (and (distinct ?x307 ?x307) true))))))))))))))))
(check-sat)
; query 234: function Transformation_to_Log_Area_Ratios, block 65, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in21_16) ((_ sign_extend 16) in21_16)) true))))))
(check-sat)
; query 235: function Transformation_to_Log_Area_Ratios, block 65, name %67
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let ((?x1142 ((_ sign_extend 16) in21_16)))
(let ((?x937 (bvsub ?x1142 (_ bv26112 32))))
(let (($x822 (and (distinct (bvsub ((_ sign_extend 1) ?x1142) ((_ sign_extend 1) (_ bv26112 32))) ((_ sign_extend 1) ?x937)) true)))
(let (($x64 (or false false)))
(let (($x192 (or $x64 false (or $x822))))
(and (not $x192) (or $x192 (and (distinct ?x937 ?x937) true)))))))))
(check-sat)
; query 236: function Transformation_to_Log_Area_Ratios, block 65, name %68
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let ((?x1142 ((_ sign_extend 16) in21_16)))
(let ((?x937 (bvsub ?x1142 (_ bv26112 32))))
(let ((?x351 ((_ extract 15 0) ?x937)))
(let (($x822 (and (distinct (bvsub ((_ sign_extend 1) ?x1142) ((_ sign_extend 1) (_ bv26112 32))) ((_ sign_extend 1) ?x937)) true)))
(let (($x64 (or false false)))
(let (($x192 (or $x64 false (or $x822))))
(let (($x795 (or $x192 false)))
(and (not $x795) (or $x795 (and (distinct ?x351 ?x351) true)))))))))))
(check-sat)
; query 237: function Transformation_to_Log_Area_Ratios, block 65, name %69
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let ((?x1142 ((_ sign_extend 16) in21_16)))
(let ((?x937 (bvsub ?x1142 (_ bv26112 32))))
(let ((?x351 ((_ extract 15 0) ?x937)))
(let ((?x893 ((_ sign_extend 16) ?x351)))
(let (($x822 (and (distinct (bvsub ((_ sign_extend 1) ?x1142) ((_ sign_extend 1) (_ bv26112 32))) ((_ sign_extend 1) ?x937)) true)))
(let (($x64 (or false false)))
(let (($x192 (or $x64 false (or $x822))))
(let (($x795 (or $x192 false)))
(let (($x253 (or $x795 false)))
(and (not $x253) (or $x253 (and (distinct ?x893 ?x893) true)))))))))))))
(check-sat)
; query 238: function Transformation_to_Log_Area_Ratios, block 65, name %70
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let ((?x1142 ((_ sign_extend 16) in21_16)))
(let ((?x937 (bvsub ?x1142 (_ bv26112 32))))
(let ((?x351 ((_ extract 15 0) ?x937)))
(let ((?x893 ((_ sign_extend 16) ?x351)))
(let ((?x936 (bvshl ?x893 (_ bv2 32))))
(let (($x2049 (bvuge (_ bv2 32) (_ bv32 32))))
(let (($x822 (and (distinct (bvsub ((_ sign_extend 1) ?x1142) ((_ sign_extend 1) (_ bv26112 32))) ((_ sign_extend 1) ?x937)) true)))
(let (($x64 (or false false)))
(let (($x192 (or $x64 false (or $x822))))
(let (($x795 (or $x192 false)))
(let (($x253 (or $x795 false)))
(let (($x279 (or (or $x253 false false) $x2049)))
(and (not $x279) (or $x279 (and (distinct ?x936 ?x936) true))))))))))))))))
(check-sat)
; query 239: function Transformation_to_Log_Area_Ratios, block 65, name %71
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let ((?x1142 ((_ sign_extend 16) in21_16)))
(let ((?x937 (bvsub ?x1142 (_ bv26112 32))))
(let ((?x351 ((_ extract 15 0) ?x937)))
(let ((?x893 ((_ sign_extend 16) ?x351)))
(let ((?x936 (bvshl ?x893 (_ bv2 32))))
(let ((?x739 ((_ extract 15 0) ?x936)))
(let (($x2049 (bvuge (_ bv2 32) (_ bv32 32))))
(let (($x822 (and (distinct (bvsub ((_ sign_extend 1) ?x1142) ((_ sign_extend 1) (_ bv26112 32))) ((_ sign_extend 1) ?x937)) true)))
(let (($x64 (or false false)))
(let (($x192 (or $x64 false (or $x822))))
(let (($x795 (or $x192 false)))
(let (($x253 (or $x795 false)))
(let (($x279 (or (or $x253 false false) $x2049)))
(let (($x820 (or $x279 false)))
(and (not $x820) (or $x820 (and (distinct ?x739 ?x739) true))))))))))))))))))
(check-sat)
; query 240: function Transformation_to_Log_Area_Ratios, block 77, name %78
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 241: function Transformation_to_Log_Area_Ratios, block 77, name %79
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x1083 ((_ sign_extend 16) in.1_16)))
(let ((?x317 (bvsub (_ bv0 32) ?x1083)))
(let (($x604 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1083)) ((_ sign_extend 1) ?x317)) true)))
(let (($x64 (or false false)))
(let (($x647 (or false $x64 (or $x604))))
(and (not $x647) (or $x647 (and (distinct ?x317 ?x317) true)))))))))
(check-sat)
; query 242: function Transformation_to_Log_Area_Ratios, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_16 () (_ BitVec 16))
(assert
 (let ((?x578 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in5_16)) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x140 (not $x640)))
(and $x140 (or $x640 (and (distinct ?x578 ?x578) true))))))))
(check-sat)
; query 243: function Transformation_to_Log_Area_Ratios, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in5_16) ((_ sign_extend 16) in5_16)) true))))))
(check-sat)
; query 244: function Transformation_to_Log_Area_Ratios, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 245: function alaw_input, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x1567 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x1440 (or false false (or $x1567))))
(and (not $x1440) (or $x1440 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 246: function alaw_input, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let ((?x166 (ite (= (_ bv4294967295 32) in.1_32) (_ bv1 1) (_ bv0 1))))
(let (($x1338 (or false false false)))
(let (($x1128 (not $x1338)))
(and $x1128 (or $x1338 (and (distinct ?x166 ?x166) true)))))))
(check-sat)
; query 247: function gsm_L_add, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_64 () (_ BitVec 64))
(assert
 (let ((?x410 (bvsub (_ bv0 64) in13_64)))
(let ((?x828 ((_ sign_extend 1) ?x410)))
(let (($x843 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in13_64)) ?x828) true)))))
(and (not $x843) (or $x843 (and (distinct ?x410 ?x410) true)))))))
(check-sat)
; query 248: function gsm_L_add, block 16, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_64 () (_ BitVec 64))
(assert
 (let ((?x410 (bvsub (_ bv0 64) in13_64)))
(let ((?x283 (bvsub ?x410 (_ bv2 64))))
(let ((?x828 ((_ sign_extend 1) ?x410)))
(let (($x843 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in13_64)) ?x828) true)))))
(let (($x370 (or $x843 false (or (and (distinct (bvsub ?x828 ((_ sign_extend 1) (_ bv2 64))) ((_ sign_extend 1) ?x283)) true)))))
(and (not $x370) (or (or $x843 false false) (and (distinct ?x283 (bvadd ?x410 (_ bv18446744073709551614 64))) true)))))))))
(check-sat)
; query 249: function gsm_L_add, block 21, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x298 (ite (bvsge (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x1338 (or false false false)))
(let (($x1128 (not $x1338)))
(and $x1128 (or $x1338 (and (distinct ?x298 ?x298) true)))))))
(check-sat)
; query 250: function gsm_L_add, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x268 (bvadd in1_64 in0_64)))
(let ((?x293 (bvadd in0_64 in1_64)))
(let (($x1245 (and (distinct ?x293 ?x268) true)))
(let (($x378 (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) in0_64)) ((_ sign_extend 1) ?x268)) true)))
(let (($x562 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) ?x293)) true)))
(and (not (or false false (or $x562))) (or (or false false (or $x378)) $x1245))))))))
(check-sat)
; query 251: function gsm_L_add, block 25, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x268 (bvadd in1_64 in0_64)))
(let ((?x293 (bvadd in0_64 in1_64)))
(let (($x1245 (and (distinct ?x293 ?x268) true)))
(let (($x1338 (or false false false)))
(let (($x1128 (not $x1338)))
(and $x1128 (or $x1338 $x1245))))))))
(check-sat)
; query 252: function gsm_L_add, block 25, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let (($x1500 (and (distinct (ite (bvugt (bvadd in0_64 in1_64) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1)) (ite (bvugt (bvadd in1_64 in0_64) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))) true)))
(let (($x1338 (or false false false)))
(let (($x1599 (or $x1338 false false)))
(let (($x635 (not $x1599)))
(and $x635 (or $x1599 $x1500)))))))
(check-sat)
; query 253: function gsm_L_add, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x979 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x1338 (or false false false)))
(let (($x1128 (not $x1338)))
(and $x1128 (or $x1338 (and (distinct ?x979 ?x979) true)))))))
(check-sat)
; query 254: function gsm_L_add, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x268 (bvadd in1_64 in0_64)))
(let ((?x293 (bvadd in0_64 in1_64)))
(let (($x1245 (and (distinct ?x293 ?x268) true)))
(let (($x378 (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) in0_64)) ((_ sign_extend 1) ?x268)) true)))
(let (($x562 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) ?x293)) true)))
(and (not (or false false (or $x562))) (or (or false false (or $x378)) $x1245))))))))
(check-sat)
; query 255: function gsm_L_add, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1468 (bvadd in0_64 (_ bv1 64))))
(let ((?x1165 (bvsub (_ bv0 64) ?x1468)))
(let (($x1526 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1468)) ((_ sign_extend 1) ?x1165)) true)))
(let ((?x1451 ((_ sign_extend 1) ?x1468)))
(let (($x1541 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1451) true)))))
(let (($x1542 (or false $x1541 (or $x1526))))
(and (not $x1542) (or $x1542 (and (distinct ?x1165 ?x1165) true))))))))))
(check-sat)
; query 256: function gsm_L_add, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1436 (bvadd in1_64 (_ bv1 64))))
(let ((?x1437 ((_ sign_extend 1) ?x1436)))
(let (($x1423 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1437) true)))))
(and (not $x1423) (or $x1423 (and (distinct ?x1436 ?x1436) true)))))))
(check-sat)
; query 257: function gsm_L_add, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1436 (bvadd in1_64 (_ bv1 64))))
(let ((?x1377 (bvsub (_ bv0 64) ?x1436)))
(let (($x1332 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1436)) ((_ sign_extend 1) ?x1377)) true)))
(let ((?x1437 ((_ sign_extend 1) ?x1436)))
(let (($x1423 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1437) true)))))
(let (($x1363 (or false $x1423 (or $x1332))))
(and (not $x1363) (or $x1363 (and (distinct ?x1377 ?x1377) true))))))))))
(check-sat)
; query 258: function gsm_L_add, block 8, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1468 (bvadd in0_64 (_ bv1 64))))
(let ((?x1165 (bvsub (_ bv0 64) ?x1468)))
(let ((?x1436 (bvadd in1_64 (_ bv1 64))))
(let ((?x1377 (bvsub (_ bv0 64) ?x1436)))
(let ((?x390 (bvadd ?x1377 ?x1165)))
(let ((?x1242 (bvadd ?x1165 ?x1377)))
(let (($x1526 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1468)) ((_ sign_extend 1) ?x1165)) true)))
(let ((?x1451 ((_ sign_extend 1) ?x1468)))
(let (($x1541 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1451) true)))))
(let (($x1542 (or false $x1541 (or $x1526))))
(let (($x1332 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1436)) ((_ sign_extend 1) ?x1377)) true)))
(let ((?x1437 ((_ sign_extend 1) ?x1436)))
(let (($x1423 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1437) true)))))
(let (($x1363 (or false $x1423 (or $x1332))))
(let (($x1194 (or $x1363 $x1542 false)))
(and (not (or $x1542 $x1363 false)) (or $x1194 (and (distinct ?x1242 ?x390) true)))))))))))))))))))
(check-sat)
; query 259: function gsm_L_add, block 8, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1468 (bvadd in0_64 (_ bv1 64))))
(let ((?x1165 (bvsub (_ bv0 64) ?x1468)))
(let ((?x1436 (bvadd in1_64 (_ bv1 64))))
(let ((?x1377 (bvsub (_ bv0 64) ?x1436)))
(let ((?x390 (bvadd ?x1377 ?x1165)))
(let (($x1057 (and (distinct (ite (bvuge (bvadd ?x1165 ?x1377) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1)) (ite (bvuge ?x390 (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))) true)))
(let (($x1526 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1468)) ((_ sign_extend 1) ?x1165)) true)))
(let ((?x1451 ((_ sign_extend 1) ?x1468)))
(let (($x1541 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1451) true)))))
(let (($x1542 (or false $x1541 (or $x1526))))
(let (($x1332 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1436)) ((_ sign_extend 1) ?x1377)) true)))
(let ((?x1437 ((_ sign_extend 1) ?x1436)))
(let (($x1423 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1437) true)))))
(let (($x1363 (or false $x1423 (or $x1332))))
(let (($x1194 (or $x1363 $x1542 false)))
(and (not (or (or $x1542 $x1363 false) false false)) (or (or $x1194 false false) $x1057))))))))))))))))))
(check-sat)
; query 260: function gsm_L_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1468 (bvadd in0_64 (_ bv1 64))))
(let ((?x1451 ((_ sign_extend 1) ?x1468)))
(let (($x1541 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1451) true)))))
(and (not $x1541) (or $x1541 (and (distinct ?x1468 ?x1468) true)))))))
(check-sat)
; query 261: function gsm_L_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1396 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x1338 (or false false false)))
(let (($x1128 (not $x1338)))
(and $x1128 (or $x1338 (and (distinct ?x1396 ?x1396) true)))))))
(check-sat)
; query 262: function gsm_L_asl, block 12, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1291 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x1338 (or false false false)))
(let (($x1128 (not $x1338)))
(and $x1128 (or $x1338 (and (distinct ?x1291 ?x1291) true)))))))
(check-sat)
; query 263: function gsm_L_asl, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ zero_extend 32) in1_32) ((_ zero_extend 32) in1_32)) true))))))
(check-sat)
; query 264: function gsm_L_asl, block 17, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x131 ((_ zero_extend 32) in1_32)))
(let ((?x1186 (bvshl in0_64 ?x131)))
(let (($x64 (or false false)))
(let (($x1378 (or false $x64 false)))
(let (($x1246 (or $x1378 (bvuge ?x131 (_ bv64 64)))))
(let (($x1040 (not $x1246)))
(and $x1040 (or $x1246 (and (distinct ?x1186 ?x1186) true))))))))))
(check-sat)
; query 265: function gsm_L_asl, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x271 (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x1338 (or false false false)))
(let (($x1128 (not $x1338)))
(and $x1128 (or $x1338 (and (distinct ?x271 ?x271) true)))))))
(check-sat)
; query 266: function gsm_L_asl, block 7, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1396 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1759 ((_ zero_extend 31) ?x1396)))
(let ((?x1111 (bvsub (_ bv0 32) ?x1759)))
(let (($x1005 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1759)) ((_ sign_extend 1) ?x1111)) true)))
(let (($x1338 (or false false false)))
(let (($x885 (or $x1338 false)))
(let (($x970 (or false $x885 (or $x1005))))
(and (not $x970) (or $x970 (and (distinct ?x1111 ?x1111) true)))))))))))
(check-sat)
; query 267: function gsm_L_asl, block 7, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1396 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1759 ((_ zero_extend 31) ?x1396)))
(let ((?x1111 (bvsub (_ bv0 32) ?x1759)))
(let ((?x377 ((_ sign_extend 32) ?x1111)))
(let (($x1005 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1759)) ((_ sign_extend 1) ?x1111)) true)))
(let (($x1338 (or false false false)))
(let (($x885 (or $x1338 false)))
(let (($x970 (or false $x885 (or $x1005))))
(let (($x561 (or $x970 false)))
(and (not $x561) (or $x561 (and (distinct ?x377 ?x377) true)))))))))))))
(check-sat)
; query 268: function gsm_L_asl, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1396 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x1338 (or false false false)))
(let (($x1128 (not $x1338)))
(and $x1128 (or $x1338 (and (distinct ?x1396 ?x1396) true)))))))
(check-sat)
; query 269: function gsm_L_asl, block 7, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1396 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1759 ((_ zero_extend 31) ?x1396)))
(let (($x1338 (or false false false)))
(let (($x885 (or $x1338 false)))
(and (not $x885) (or $x885 (and (distinct ?x1759 ?x1759) true))))))))
(check-sat)
; query 270: function gsm_L_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x2056 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x1338 (or false false false)))
(let (($x1128 (not $x1338)))
(and $x1128 (or $x1338 (and (distinct ?x2056 ?x2056) true)))))))
(check-sat)
; query 271: function gsm_L_asr, block 12, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1291 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x1338 (or false false false)))
(let (($x1128 (not $x1338)))
(and $x1128 (or $x1338 (and (distinct ?x1291 ?x1291) true)))))))
(check-sat)
; query 272: function gsm_L_asr, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x1155 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in1_32))) true)))
(let (($x806 (or false false (or $x1155))))
(and (not $x806) (or $x806 (and (distinct (bvsub (_ bv0 32) in1_32) (bvsub (_ bv0 32) in1_32)) true))))))
(check-sat)
; query 273: function gsm_L_asr, block 14, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1446 (bvsub (_ bv0 32) in1_32)))
(let ((?x1356 ((_ zero_extend 32) ?x1446)))
(let (($x1155 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x1446)) true)))
(let (($x806 (or false false (or $x1155))))
(let (($x1330 (or $x806 false)))
(and (not $x1330) (or $x1330 (and (distinct ?x1356 ?x1356) true)))))))))
(check-sat)
; query 274: function gsm_L_asr, block 14, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1446 (bvsub (_ bv0 32) in1_32)))
(let ((?x1356 ((_ zero_extend 32) ?x1446)))
(let ((?x1806 (bvshl in0_64 ?x1356)))
(let (($x1155 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x1446)) true)))
(let (($x806 (or false false (or $x1155))))
(let (($x1330 (or $x806 false)))
(let (($x256 (or (or false $x1330 false) (bvuge ?x1356 (_ bv64 64)))))
(and (not $x256) (or $x256 (and (distinct ?x1806 ?x1806) true)))))))))))
(check-sat)
; query 275: function gsm_L_asr, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ zero_extend 32) in1_32) ((_ zero_extend 32) in1_32)) true))))))
(check-sat)
; query 276: function gsm_L_asr, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x131 ((_ zero_extend 32) in1_32)))
(let ((?x716 (bvashr in0_64 ?x131)))
(let (($x64 (or false false)))
(let (($x1378 (or false $x64 false)))
(let (($x1246 (or $x1378 (bvuge ?x131 (_ bv64 64)))))
(let (($x1040 (not $x1246)))
(and $x1040 (or $x1246 (and (distinct ?x716 ?x716) true))))))))))
(check-sat)
; query 277: function gsm_L_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1396 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x1338 (or false false false)))
(let (($x1128 (not $x1338)))
(and $x1128 (or $x1338 (and (distinct ?x1396 ?x1396) true)))))))
(check-sat)
; query 278: function gsm_L_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1396 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1759 ((_ zero_extend 31) ?x1396)))
(let (($x1338 (or false false false)))
(let (($x885 (or $x1338 false)))
(and (not $x885) (or $x885 (and (distinct ?x1759 ?x1759) true))))))))
(check-sat)
; query 279: function gsm_L_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1396 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1759 ((_ zero_extend 31) ?x1396)))
(let ((?x1111 (bvsub (_ bv0 32) ?x1759)))
(let (($x1005 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1759)) ((_ sign_extend 1) ?x1111)) true)))
(let (($x1338 (or false false false)))
(let (($x885 (or $x1338 false)))
(let (($x970 (or false $x885 (or $x1005))))
(and (not $x970) (or $x970 (and (distinct ?x1111 ?x1111) true)))))))))))
(check-sat)
; query 280: function gsm_L_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1396 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1759 ((_ zero_extend 31) ?x1396)))
(let ((?x1111 (bvsub (_ bv0 32) ?x1759)))
(let ((?x377 ((_ sign_extend 32) ?x1111)))
(let (($x1005 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1759)) ((_ sign_extend 1) ?x1111)) true)))
(let (($x1338 (or false false false)))
(let (($x885 (or $x1338 false)))
(let (($x970 (or false $x885 (or $x1005))))
(let (($x561 (or $x970 false)))
(and (not $x561) (or $x561 (and (distinct ?x377 ?x377) true)))))))))))))
(check-sat)
; query 281: function gsm_L_asr, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x271 (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x1338 (or false false false)))
(let (($x1128 (not $x1338)))
(and $x1128 (or $x1338 (and (distinct ?x271 ?x271) true)))))))
(check-sat)
; query 282: function gsm_L_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x2056 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x1338 (or false false false)))
(let (($x1128 (not $x1338)))
(and $x1128 (or $x1338 (and (distinct ?x2056 ?x2056) true)))))))
(check-sat)
; query 283: function gsm_L_mult, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 284: function gsm_L_mult, block 17, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 285: function gsm_L_mult, block 17, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x727 ((_ sign_extend 48) in0_16)))
(let ((?x774 (bvmul ?x727 (_ bv2 64))))
(let ((?x452 ((_ sign_extend 48) in1_16)))
(let ((?x558 (bvmul ?x727 ?x452)))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x1334 (and (distinct (bvmul ((_ sign_extend 64) ?x727) ((_ sign_extend 64) ?x452)) ((_ sign_extend 64) ?x558)) true)))
(let (($x871 (or $x64 $x64 (or $x1334))))
(let (($x1516 (not $x871)))
(and $x1516 (or $x640 (and (distinct ?x558 ?x774) true)))))))))))))
(check-sat)
; query 286: function gsm_L_mult, block 17, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x119 (and (distinct (bvshl (bvmul ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16)) (_ bv1 64)) (bvmul (bvmul ((_ sign_extend 48) in0_16) (_ bv2 64)) ((_ sign_extend 48) in1_16))) true)))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x9 (bvuge (_ bv1 64) (_ bv64 64))))
(let ((?x452 ((_ sign_extend 48) in1_16)))
(let ((?x1234 ((_ sign_extend 64) ?x452)))
(let ((?x727 ((_ sign_extend 48) in0_16)))
(let ((?x665 ((_ sign_extend 64) ?x727)))
(let (($x871 (or $x64 $x64 (or (and (distinct (bvmul ?x665 ?x1234) ((_ sign_extend 64) (bvmul ?x727 ?x452))) true)))))
(let (($x425 (or $x871 false false)))
(and (not (or $x425 $x9)) (or (or $x640 $x64 false) $x119)))))))))))))
(check-sat)
; query 287: function gsm_L_mult, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 288: function gsm_L_mult, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1925 (ite (and (distinct (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) true) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x140 (not $x640)))
(and $x140 (or $x640 (and (distinct ?x1925 ?x1925) true))))))))
(check-sat)
; query 289: function gsm_L_mult, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 290: function gsm_L_mult, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x536 (ite (and (distinct (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) true) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x140 (not $x640)))
(and $x140 (or $x640 (and (distinct ?x536 ?x536) true))))))))
(check-sat)
; query 291: function gsm_L_sub, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in11_64 () (_ BitVec 64))
(assert
 (let (($x1338 (or false false false)))
(let (($x1128 (not $x1338)))
(and $x1128 (or $x1338 (and (distinct (bvadd in11_64 (_ bv1 64)) (bvadd in11_64 (_ bv1 64))) true))))))
(check-sat)
; query 292: function gsm_L_sub, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x298 (ite (bvsge (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x1338 (or false false false)))
(let (($x1128 (not $x1338)))
(and $x1128 (or $x1338 (and (distinct ?x298 ?x298) true)))))))
(check-sat)
; query 293: function gsm_L_sub, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x765 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvsub in0_64 in1_64))) true)))
(let (($x753 (or false false (or $x765))))
(let (($x1582 (or $x753 (and (distinct (bvsub in0_64 in1_64) (bvsub in0_64 in1_64)) true))))
(and (not $x753) $x1582)))))
(check-sat)
; query 294: function gsm_L_sub, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1468 (bvadd in0_64 (_ bv1 64))))
(let ((?x1451 ((_ sign_extend 1) ?x1468)))
(let (($x1541 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1451) true)))))
(and (not $x1541) (or $x1541 (and (distinct ?x1468 ?x1468) true)))))))
(check-sat)
; query 295: function gsm_L_sub, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1468 (bvadd in0_64 (_ bv1 64))))
(let ((?x1165 (bvsub (_ bv0 64) ?x1468)))
(let (($x1526 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1468)) ((_ sign_extend 1) ?x1165)) true)))
(let ((?x1451 ((_ sign_extend 1) ?x1468)))
(let (($x1541 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1451) true)))))
(let (($x1542 (or false $x1541 (or $x1526))))
(and (not $x1542) (or $x1542 (and (distinct ?x1165 ?x1165) true))))))))))
(check-sat)
; query 296: function gsm_L_sub, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1468 (bvadd in0_64 (_ bv1 64))))
(let ((?x1165 (bvsub (_ bv0 64) ?x1468)))
(let ((?x811 (bvadd ?x1165 in1_64)))
(let (($x1526 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1468)) ((_ sign_extend 1) ?x1165)) true)))
(let ((?x1451 ((_ sign_extend 1) ?x1468)))
(let (($x1541 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1451) true)))))
(let (($x1542 (or false $x1541 (or $x1526))))
(let (($x1248 (or $x1542 false false)))
(and (not $x1248) (or $x1248 (and (distinct ?x811 ?x811) true))))))))))))
(check-sat)
; query 297: function gsm_L_sub, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x671 (ite (bvuge (bvadd (bvsub (_ bv0 64) (bvadd in0_64 (_ bv1 64))) in1_64) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x1526 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) (bvadd in0_64 (_ bv1 64)))) ((_ sign_extend 1) (bvsub (_ bv0 64) (bvadd in0_64 (_ bv1 64))))) true)))
(let ((?x1468 (bvadd in0_64 (_ bv1 64))))
(let ((?x1451 ((_ sign_extend 1) ?x1468)))
(let (($x1541 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1451) true)))))
(let (($x1542 (or false $x1541 (or $x1526))))
(let (($x1248 (or $x1542 false false)))
(let (($x711 (or $x1248 false false)))
(and (not $x711) (or $x711 (and (distinct ?x671 ?x671) true))))))))))))
(check-sat)
; query 298: function gsm_L_sub, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_64 () (_ BitVec 64))
(assert
 (let ((?x1905 (bvsub (_ bv0 64) in25_64)))
(let ((?x1985 ((_ sign_extend 1) ?x1905)))
(let (($x1875 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in25_64)) ?x1985) true)))))
(and (not $x1875) (or $x1875 (and (distinct ?x1905 ?x1905) true)))))))
(check-sat)
; query 299: function gsm_L_sub, block 28, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_64 () (_ BitVec 64))
(assert
 (let ((?x1905 (bvsub (_ bv0 64) in25_64)))
(let ((?x963 (bvsub ?x1905 (_ bv1 64))))
(let ((?x1985 ((_ sign_extend 1) ?x1905)))
(let (($x1875 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in25_64)) ?x1985) true)))))
(let (($x1519 (or $x1875 false (or (and (distinct (bvsub ?x1985 ((_ sign_extend 1) (_ bv1 64))) ((_ sign_extend 1) ?x963)) true)))))
(and (not $x1519) (or (or $x1875 false false) (and (distinct ?x963 (bvadd ?x1905 (_ bv18446744073709551615 64))) true)))))))))
(check-sat)
; query 300: function gsm_L_sub, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x979 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x1338 (or false false false)))
(let (($x1128 (not $x1338)))
(and $x1128 (or $x1338 (and (distinct ?x979 ?x979) true)))))))
(check-sat)
; query 301: function gsm_L_sub, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x765 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvsub in0_64 in1_64))) true)))
(let (($x753 (or false false (or $x765))))
(let (($x1582 (or $x753 (and (distinct (bvsub in0_64 in1_64) (bvsub in0_64 in1_64)) true))))
(and (not $x753) $x1582)))))
(check-sat)
; query 302: function gsm_L_sub, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1436 (bvadd in1_64 (_ bv1 64))))
(let ((?x1377 (bvsub (_ bv0 64) ?x1436)))
(let (($x1332 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1436)) ((_ sign_extend 1) ?x1377)) true)))
(let ((?x1437 ((_ sign_extend 1) ?x1436)))
(let (($x1423 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1437) true)))))
(let (($x1363 (or false $x1423 (or $x1332))))
(and (not $x1363) (or $x1363 (and (distinct ?x1377 ?x1377) true))))))))))
(check-sat)
; query 303: function gsm_L_sub, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1436 (bvadd in1_64 (_ bv1 64))))
(let ((?x1377 (bvsub (_ bv0 64) ?x1436)))
(let ((?x597 (bvadd ?x1377 in0_64)))
(let ((?x1731 (bvadd in0_64 ?x1377)))
(let (($x1332 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1436)) ((_ sign_extend 1) ?x1377)) true)))
(let ((?x1437 ((_ sign_extend 1) ?x1436)))
(let (($x1423 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1437) true)))))
(let (($x1363 (or false $x1423 (or $x1332))))
(let (($x526 (or $x1363 false false)))
(and (not (or false $x1363 false)) (or $x526 (and (distinct ?x1731 ?x597) true)))))))))))))
(check-sat)
; query 304: function gsm_L_sub, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1831 (ite (bvuge (bvadd (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64))) in0_64) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let ((?x873 (ite (bvuge (bvadd in0_64 (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64)))) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x1332 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) (bvadd in1_64 (_ bv1 64)))) ((_ sign_extend 1) (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64))))) true)))
(let ((?x1436 (bvadd in1_64 (_ bv1 64))))
(let ((?x1437 ((_ sign_extend 1) ?x1436)))
(let (($x1423 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1437) true)))))
(let (($x1363 (or false $x1423 (or $x1332))))
(let (($x526 (or $x1363 false false)))
(and (not (or (or false $x1363 false) false false)) (or (or $x526 false false) (and (distinct ?x873 ?x1831) true))))))))))))
(check-sat)
; query 305: function gsm_L_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1436 (bvadd in1_64 (_ bv1 64))))
(let ((?x1437 ((_ sign_extend 1) ?x1436)))
(let (($x1423 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1437) true)))))
(and (not $x1423) (or $x1423 (and (distinct ?x1436 ?x1436) true)))))))
(check-sat)
; query 306: function gsm_L_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1843 (ite (bvsle (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x1338 (or false false false)))
(let (($x1128 (not $x1338)))
(and $x1128 (or $x1338 (and (distinct ?x1843 ?x1843) true)))))))
(check-sat)
; query 307: function gsm_abs, block 13, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 308: function gsm_abs, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 309: function gsm_abs, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1861 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x140 (not $x640)))
(and $x140 (or $x640 (and (distinct ?x1861 ?x1861) true))))))))
(check-sat)
; query 310: function gsm_abs, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x332 ((_ sign_extend 16) in0_16)))
(let ((?x1876 (bvsub (_ bv0 32) ?x332)))
(let (($x1877 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x332)) ((_ sign_extend 1) ?x1876)) true)))
(let (($x64 (or false false)))
(let (($x1886 (or false $x64 (or $x1877))))
(and (not $x1886) (or $x1886 (and (distinct ?x1876 ?x1876) true)))))))))
(check-sat)
; query 311: function gsm_abs, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 312: function gsm_abs, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 313: function gsm_abs, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1893 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x140 (not $x640)))
(and $x140 (or $x640 (and (distinct ?x1893 ?x1893) true))))))))
(check-sat)
; query 314: function gsm_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_64 () (_ BitVec 64))
(assert
 (let ((?x1919 (ite (bvslt (_ bv32767 64) in5_64) (_ bv1 1) (_ bv0 1))))
(let (($x1338 (or false false false)))
(let (($x1128 (not $x1338)))
(and $x1128 (or $x1338 (and (distinct ?x1919 ?x1919) true)))))))
(check-sat)
; query 315: function gsm_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 316: function gsm_add, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 317: function gsm_add, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x727 ((_ sign_extend 48) in0_16)))
(let ((?x452 ((_ sign_extend 48) in1_16)))
(let ((?x1951 (bvadd ?x452 ?x727)))
(let ((?x1922 (bvadd ?x727 ?x452)))
(let (($x1959 (and (distinct (bvadd ((_ sign_extend 1) ?x452) ((_ sign_extend 1) ?x727)) ((_ sign_extend 1) ?x1951)) true)))
(let (($x64 (or false false)))
(let (($x1956 (or $x64 $x64 (or $x1959))))
(let (($x1930 (and (distinct (bvadd ((_ sign_extend 1) ?x727) ((_ sign_extend 1) ?x452)) ((_ sign_extend 1) ?x1922)) true)))
(let (($x1933 (or $x64 $x64 (or $x1930))))
(and (not $x1933) (or $x1956 (and (distinct ?x1922 ?x1951) true)))))))))))))
(check-sat)
; query 318: function gsm_add, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1966 (ite (bvsgt (_ bv18446744073709518848 64) (bvadd ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in0_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x1948 (ite (bvsgt (_ bv18446744073709518848 64) (bvadd ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x727 ((_ sign_extend 48) in0_16)))
(let ((?x31 ((_ sign_extend 1) ?x727)))
(let ((?x452 ((_ sign_extend 48) in1_16)))
(let ((?x1926 ((_ sign_extend 1) ?x452)))
(let (($x64 (or false false)))
(let (($x1956 (or $x64 $x64 (or (and (distinct (bvadd ?x1926 ?x31) ((_ sign_extend 1) (bvadd ?x452 ?x727))) true)))))
(let (($x1933 (or $x64 $x64 (or (and (distinct (bvadd ?x31 ?x1926) ((_ sign_extend 1) (bvadd ?x727 ?x452))) true)))))
(and (not (or $x1933 false false)) (or (or $x1956 false false) (and (distinct ?x1948 ?x1966) true)))))))))))))
(check-sat)
; query 319: function gsm_asl, block 13, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1291 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x1338 (or false false false)))
(let (($x1128 (not $x1338)))
(and $x1128 (or $x1338 (and (distinct ?x1291 ?x1291) true)))))))
(check-sat)
; query 320: function gsm_asl, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 321: function gsm_asl, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x332 ((_ sign_extend 16) in0_16)))
(let ((?x1991 (bvshl ?x332 in1_32)))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x1989 (or $x640 (bvuge in1_32 (_ bv32 32)))))
(let (($x1721 (not $x1989)))
(and $x1721 (or $x1989 (and (distinct ?x1991 ?x1991) true))))))))))
(check-sat)
; query 322: function gsm_asl, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x332 ((_ sign_extend 16) in0_16)))
(let ((?x1991 (bvshl ?x332 in1_32)))
(let ((?x1998 ((_ extract 15 0) ?x1991)))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x1989 (or $x640 (bvuge in1_32 (_ bv32 32)))))
(let (($x1999 (or $x1989 false)))
(let (($x2006 (not $x1999)))
(and $x2006 (or $x1999 (and (distinct ?x1998 ?x1998) true))))))))))))
(check-sat)
; query 323: function gsm_asl, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x2013 (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x1338 (or false false false)))
(let (($x1128 (not $x1338)))
(and $x1128 (or $x1338 (and (distinct ?x2013 ?x2013) true)))))))
(check-sat)
; query 324: function gsm_asl, block 7, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1893 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x2029 ((_ zero_extend 31) ?x1893)))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x2031 (or $x640 false)))
(and (not $x2031) (or $x2031 (and (distinct ?x2029 ?x2029) true)))))))))
(check-sat)
; query 325: function gsm_asl, block 7, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1893 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x2029 ((_ zero_extend 31) ?x1893)))
(let ((?x2036 (bvsub (_ bv0 32) ?x2029)))
(let (($x2037 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x2029)) ((_ sign_extend 1) ?x2036)) true)))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x2031 (or $x640 false)))
(let (($x2046 (or false $x2031 (or $x2037))))
(and (not $x2046) (or $x2046 (and (distinct ?x2036 ?x2036) true))))))))))))
(check-sat)
; query 326: function gsm_asl, block 7, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1893 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x2029 ((_ zero_extend 31) ?x1893)))
(let ((?x2036 (bvsub (_ bv0 32) ?x2029)))
(let ((?x2047 ((_ extract 15 0) ?x2036)))
(let (($x2037 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x2029)) ((_ sign_extend 1) ?x2036)) true)))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x2031 (or $x640 false)))
(let (($x2046 (or false $x2031 (or $x2037))))
(let (($x2042 (or $x2046 false)))
(and (not $x2042) (or $x2042 (and (distinct ?x2047 ?x2047) true))))))))))))))
(check-sat)
; query 327: function gsm_asl, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 328: function gsm_asl, block 7, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1893 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x140 (not $x640)))
(and $x140 (or $x640 (and (distinct ?x1893 ?x1893) true))))))))
(check-sat)
; query 329: function gsm_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x2077 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x1338 (or false false false)))
(let (($x1128 (not $x1338)))
(and $x1128 (or $x1338 (and (distinct ?x2077 ?x2077) true)))))))
(check-sat)
; query 330: function gsm_asr, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x2013 (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x1338 (or false false false)))
(let (($x1128 (not $x1338)))
(and $x1128 (or $x1338 (and (distinct ?x2013 ?x2013) true)))))))
(check-sat)
; query 331: function gsm_asr, block 13, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1291 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x1338 (or false false false)))
(let (($x1128 (not $x1338)))
(and $x1128 (or $x1338 (and (distinct ?x1291 ?x1291) true)))))))
(check-sat)
; query 332: function gsm_asr, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 333: function gsm_asr, block 15, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x1155 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in1_32))) true)))
(let (($x806 (or false false (or $x1155))))
(and (not $x806) (or $x806 (and (distinct (bvsub (_ bv0 32) in1_32) (bvsub (_ bv0 32) in1_32)) true))))))
(check-sat)
; query 334: function gsm_asr, block 15, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1446 (bvsub (_ bv0 32) in1_32)))
(let ((?x332 ((_ sign_extend 16) in0_16)))
(let ((?x2096 (bvshl ?x332 ?x1446)))
(let (($x1155 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x1446)) true)))
(let (($x806 (or false false (or $x1155))))
(let (($x64 (or false false)))
(let (($x106 (or (or $x64 $x806 false) (bvuge ?x1446 (_ bv32 32)))))
(and (not $x106) (or $x106 (and (distinct ?x2096 ?x2096) true)))))))))))
(check-sat)
; query 335: function gsm_asr, block 15, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1446 (bvsub (_ bv0 32) in1_32)))
(let ((?x332 ((_ sign_extend 16) in0_16)))
(let ((?x2096 (bvshl ?x332 ?x1446)))
(let ((?x2097 ((_ extract 15 0) ?x2096)))
(let (($x1155 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x1446)) true)))
(let (($x806 (or false false (or $x1155))))
(let (($x64 (or false false)))
(let (($x106 (or (or $x64 $x806 false) (bvuge ?x1446 (_ bv32 32)))))
(let (($x310 (or $x106 false)))
(and (not $x310) (or $x310 (and (distinct ?x2097 ?x2097) true)))))))))))))
(check-sat)
; query 336: function gsm_asr, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 337: function gsm_asr, block 20, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x332 ((_ sign_extend 16) in0_16)))
(let ((?x1144 (bvashr ?x332 in1_32)))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x1989 (or $x640 (bvuge in1_32 (_ bv32 32)))))
(let (($x1721 (not $x1989)))
(and $x1721 (or $x1989 (and (distinct ?x1144 ?x1144) true))))))))))
(check-sat)
; query 338: function gsm_asr, block 20, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x332 ((_ sign_extend 16) in0_16)))
(let ((?x1144 (bvashr ?x332 in1_32)))
(let ((?x1662 ((_ extract 15 0) ?x1144)))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x1989 (or $x640 (bvuge in1_32 (_ bv32 32)))))
(let (($x1999 (or $x1989 false)))
(let (($x2006 (not $x1999)))
(and $x2006 (or $x1999 (and (distinct ?x1662 ?x1662) true))))))))))))
(check-sat)
; query 339: function gsm_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 340: function gsm_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1893 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x140 (not $x640)))
(and $x140 (or $x640 (and (distinct ?x1893 ?x1893) true))))))))
(check-sat)
; query 341: function gsm_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1893 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x2029 ((_ zero_extend 31) ?x1893)))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x2031 (or $x640 false)))
(and (not $x2031) (or $x2031 (and (distinct ?x2029 ?x2029) true)))))))))
(check-sat)
; query 342: function gsm_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1893 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x2029 ((_ zero_extend 31) ?x1893)))
(let ((?x2036 (bvsub (_ bv0 32) ?x2029)))
(let (($x2037 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x2029)) ((_ sign_extend 1) ?x2036)) true)))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x2031 (or $x640 false)))
(let (($x2046 (or false $x2031 (or $x2037))))
(and (not $x2046) (or $x2046 (and (distinct ?x2036 ?x2036) true))))))))))))
(check-sat)
; query 343: function gsm_asr, block 4, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1893 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x2029 ((_ zero_extend 31) ?x1893)))
(let ((?x2036 (bvsub (_ bv0 32) ?x2029)))
(let ((?x2047 ((_ extract 15 0) ?x2036)))
(let (($x2037 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x2029)) ((_ sign_extend 1) ?x2036)) true)))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x2031 (or $x640 false)))
(let (($x2046 (or false $x2031 (or $x2037))))
(let (($x2042 (or $x2046 false)))
(and (not $x2042) (or $x2042 (and (distinct ?x2047 ?x2047) true))))))))))))))
(check-sat)
; query 344: function gsm_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x2077 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x1338 (or false false false)))
(let (($x1128 (not $x1338)))
(and $x1128 (or $x1338 (and (distinct ?x2077 ?x2077) true)))))))
(check-sat)
; query 345: function gsm_debug_longwords, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in15_32 () (_ BitVec 32))
(assert
 (let ((?x808 (ite (bvslt in15_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x1338 (or false false false)))
(let (($x1128 (not $x1338)))
(and $x1128 (or $x1338 (and (distinct ?x808 ?x808) true)))))))
(check-sat)
; query 346: function gsm_debug_words, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in16_32 () (_ BitVec 32))
(assert
 (let ((?x495 (ite (bvslt in16_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x1338 (or false false false)))
(let (($x1128 (not $x1338)))
(and $x1128 (or $x1338 (and (distinct ?x495 ?x495) true)))))))
(check-sat)
; query 347: function gsm_div, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 348: function gsm_div, block 20, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x238 (ite (= (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x140 (not $x640)))
(and $x140 (or $x640 (and (distinct ?x238 ?x238) true))))))))
(check-sat)
; query 349: function gsm_div, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in.02_16) ((_ sign_extend 16) in.02_16)) true))))))
(check-sat)
; query 350: function gsm_div, block 28, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x780 ((_ sign_extend 16) in.02_16)))
(let ((?x1236 (bvshl ?x780 (_ bv1 32))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x2058 (or $x640 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x984 (not $x2058)))
(and $x984 (or $x2058 (and (distinct ?x1236 ?x1236) true))))))))))
(check-sat)
; query 351: function gsm_div, block 28, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x780 ((_ sign_extend 16) in.02_16)))
(let ((?x1236 (bvshl ?x780 (_ bv1 32))))
(let ((?x1209 ((_ extract 15 0) ?x1236)))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x2058 (or $x640 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x1495 (or $x2058 false)))
(let (($x1677 (not $x1495)))
(and $x1677 (or $x1495 (and (distinct ?x1209 ?x1209) true))))))))))))
(check-sat)
; query 352: function gsm_div, block 28, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_64 () (_ BitVec 64))
(assert
 (let (($x9 (bvuge (_ bv1 64) (_ bv64 64))))
(let (($x1338 (or false false false)))
(let (($x799 (or $x1338 $x9)))
(and (not $x799) (or $x799 (and (distinct (bvshl in.03_64 (_ bv1 64)) (bvshl in.03_64 (_ bv1 64))) true)))))))
(check-sat)
; query 353: function gsm_div, block 28, name %33
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_64 () (_ BitVec 64))
(declare-fun in.03_64 () (_ BitVec 64))
(assert
 (let ((?x1503 (ite (bvsge (bvshl in.03_64 (_ bv1 64)) in4_64) (_ bv1 1) (_ bv0 1))))
(let (($x9 (bvuge (_ bv1 64) (_ bv64 64))))
(let (($x1338 (or false false false)))
(let (($x799 (or $x1338 $x9)))
(let (($x1163 (or $x799 false false)))
(and (not $x1163) (or $x1163 (and (distinct ?x1503 ?x1503) true)))))))))
(check-sat)
; query 354: function gsm_div, block 34, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_64 () (_ BitVec 64))
(declare-fun in32_64 () (_ BitVec 64))
(assert
 (let (($x1703 (and (distinct (bvsub ((_ sign_extend 1) in32_64) ((_ sign_extend 1) in4_64)) ((_ sign_extend 1) (bvsub in32_64 in4_64))) true)))
(let (($x1701 (or false false (or $x1703))))
(let (($x1726 (or $x1701 (and (distinct (bvsub in32_64 in4_64) (bvsub in32_64 in4_64)) true))))
(and (not $x1701) $x1726)))))
(check-sat)
; query 355: function gsm_div, block 34, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in31_16 () (_ BitVec 16))
(assert
 (let (($x1338 (or false false false)))
(let (($x1128 (not $x1338)))
(and $x1128 (or $x1338 (and (distinct (bvadd in31_16 (_ bv1 16)) (bvadd in31_16 (_ bv1 16))) true))))))
(check-sat)
; query 356: function gsm_div, block 7, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1746 (ite (bvsge ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x1743 (or $x64 $x64 false)))
(and (not $x1743) (or $x1743 (and (distinct ?x1746 ?x1746) true)))))))
(check-sat)
; query 357: function gsm_div, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 358: function gsm_div, block 7, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 359: function gsm_div, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 360: function gsm_div, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 361: function gsm_div, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 362: function gsm_div, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1393 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1497 (and (distinct ?x1393 ?x1393) true)))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x140 (not $x640)))
(and $x140 (or $x640 $x1497))))))))
(check-sat)
; query 363: function gsm_mult, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 364: function gsm_mult, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1763 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x140 (not $x640)))
(and $x140 (or $x640 (and (distinct ?x1763 ?x1763) true))))))))
(check-sat)
; query 365: function gsm_mult, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 366: function gsm_mult, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 367: function gsm_mult, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x727 ((_ sign_extend 48) in0_16)))
(let ((?x452 ((_ sign_extend 48) in1_16)))
(let ((?x1787 (bvmul ?x452 ?x727)))
(let ((?x558 (bvmul ?x727 ?x452)))
(let (($x1790 (and (distinct (bvmul ((_ sign_extend 64) ?x452) ((_ sign_extend 64) ?x727)) ((_ sign_extend 64) ?x1787)) true)))
(let (($x64 (or false false)))
(let (($x1791 (or $x64 $x64 (or $x1790))))
(let (($x1334 (and (distinct (bvmul ((_ sign_extend 64) ?x727) ((_ sign_extend 64) ?x452)) ((_ sign_extend 64) ?x558)) true)))
(let (($x871 (or $x64 $x64 (or $x1334))))
(let (($x1516 (not $x871)))
(and $x1516 (or $x1791 (and (distinct ?x558 ?x1787) true))))))))))))))
(check-sat)
; query 368: function gsm_mult, block 9, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x727 ((_ sign_extend 48) in0_16)))
(let ((?x452 ((_ sign_extend 48) in1_16)))
(let ((?x1787 (bvmul ?x452 ?x727)))
(let ((?x1804 (bvashr ?x1787 (_ bv15 64))))
(let ((?x558 (bvmul ?x727 ?x452)))
(let ((?x1775 (bvashr ?x558 (_ bv15 64))))
(let (($x114 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1790 (and (distinct (bvmul ((_ sign_extend 64) ?x452) ((_ sign_extend 64) ?x727)) ((_ sign_extend 64) ?x1787)) true)))
(let (($x64 (or false false)))
(let (($x1791 (or $x64 $x64 (or $x1790))))
(let (($x1810 (or (or $x1791 false false) $x114)))
(let (($x1334 (and (distinct (bvmul ((_ sign_extend 64) ?x727) ((_ sign_extend 64) ?x452)) ((_ sign_extend 64) ?x558)) true)))
(let (($x871 (or $x64 $x64 (or $x1334))))
(let (($x425 (or $x871 false false)))
(let (($x1778 (or $x425 $x114)))
(and (not $x1778) (or $x1810 (and (distinct ?x1775 ?x1804) true)))))))))))))))))))
(check-sat)
; query 369: function gsm_mult, block 9, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x727 ((_ sign_extend 48) in0_16)))
(let ((?x452 ((_ sign_extend 48) in1_16)))
(let ((?x1787 (bvmul ?x452 ?x727)))
(let ((?x1804 (bvashr ?x1787 (_ bv15 64))))
(let (($x114 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1790 (and (distinct (bvmul ((_ sign_extend 64) ?x452) ((_ sign_extend 64) ?x727)) ((_ sign_extend 64) ?x1787)) true)))
(let (($x64 (or false false)))
(let (($x1791 (or $x64 $x64 (or $x1790))))
(let (($x1810 (or (or $x1791 false false) $x114)))
(let (($x1037 (or (or $x1810 false) (and (distinct ((_ extract 15 0) (bvashr (bvmul ?x727 ?x452) (_ bv15 64))) ((_ extract 15 0) ?x1804)) true))))
(let (($x1334 (and (distinct (bvmul ((_ sign_extend 64) ?x727) ((_ sign_extend 64) ?x452)) ((_ sign_extend 64) (bvmul ?x727 ?x452))) true)))
(let (($x871 (or $x64 $x64 (or $x1334))))
(let (($x425 (or $x871 false false)))
(let (($x1778 (or $x425 $x114)))
(and (not (or $x1778 false)) $x1037))))))))))))))))
(check-sat)
; query 370: function gsm_mult, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 371: function gsm_mult, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1861 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x140 (not $x640)))
(and $x140 (or $x640 (and (distinct ?x1861 ?x1861) true))))))))
(check-sat)
; query 372: function gsm_mult_r, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 373: function gsm_mult_r, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1861 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x140 (not $x640)))
(and $x140 (or $x640 (and (distinct ?x1861 ?x1861) true))))))))
(check-sat)
; query 374: function gsm_mult_r, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 375: function gsm_mult_r, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 376: function gsm_mult_r, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x727 ((_ sign_extend 48) in0_16)))
(let ((?x452 ((_ sign_extend 48) in1_16)))
(let ((?x1787 (bvmul ?x452 ?x727)))
(let ((?x558 (bvmul ?x727 ?x452)))
(let (($x1790 (and (distinct (bvmul ((_ sign_extend 64) ?x452) ((_ sign_extend 64) ?x727)) ((_ sign_extend 64) ?x1787)) true)))
(let (($x64 (or false false)))
(let (($x1791 (or $x64 $x64 (or $x1790))))
(let (($x1334 (and (distinct (bvmul ((_ sign_extend 64) ?x727) ((_ sign_extend 64) ?x452)) ((_ sign_extend 64) ?x558)) true)))
(let (($x871 (or $x64 $x64 (or $x1334))))
(let (($x1516 (not $x871)))
(and $x1516 (or $x1791 (and (distinct ?x558 ?x1787) true))))))))))))))
(check-sat)
; query 377: function gsm_mult_r, block 9, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x727 ((_ sign_extend 48) in0_16)))
(let ((?x452 ((_ sign_extend 48) in1_16)))
(let ((?x1787 (bvmul ?x452 ?x727)))
(let ((?x1107 (bvadd ?x1787 (_ bv16384 64))))
(let ((?x558 (bvmul ?x727 ?x452)))
(let ((?x335 (bvadd ?x558 (_ bv16384 64))))
(let (($x233 (and (distinct (bvadd ((_ sign_extend 1) ?x1787) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x1107)) true)))
(let (($x1790 (and (distinct (bvmul ((_ sign_extend 64) ?x452) ((_ sign_extend 64) ?x727)) ((_ sign_extend 64) ?x1787)) true)))
(let (($x64 (or false false)))
(let (($x1791 (or $x64 $x64 (or $x1790))))
(let (($x225 (or $x1791 false (or $x233))))
(let (($x735 (and (distinct (bvadd ((_ sign_extend 1) ?x558) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x335)) true)))
(let (($x1334 (and (distinct (bvmul ((_ sign_extend 64) ?x727) ((_ sign_extend 64) ?x452)) ((_ sign_extend 64) ?x558)) true)))
(let (($x871 (or $x64 $x64 (or $x1334))))
(let (($x1036 (or $x871 false (or $x735))))
(and (not $x1036) (or $x225 (and (distinct ?x335 ?x1107) true)))))))))))))))))))
(check-sat)
; query 378: function gsm_mult_r, block 9, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x727 ((_ sign_extend 48) in0_16)))
(let ((?x452 ((_ sign_extend 48) in1_16)))
(let ((?x1787 (bvmul ?x452 ?x727)))
(let ((?x1107 (bvadd ?x1787 (_ bv16384 64))))
(let ((?x62 (bvashr ?x1107 (_ bv15 64))))
(let ((?x558 (bvmul ?x727 ?x452)))
(let ((?x335 (bvadd ?x558 (_ bv16384 64))))
(let ((?x1063 (bvashr ?x335 (_ bv15 64))))
(let (($x114 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x233 (and (distinct (bvadd ((_ sign_extend 1) ?x1787) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x1107)) true)))
(let (($x1790 (and (distinct (bvmul ((_ sign_extend 64) ?x452) ((_ sign_extend 64) ?x727)) ((_ sign_extend 64) ?x1787)) true)))
(let (($x64 (or false false)))
(let (($x1791 (or $x64 $x64 (or $x1790))))
(let (($x225 (or $x1791 false (or $x233))))
(let (($x1100 (or (or $x225 false false) $x114)))
(let (($x735 (and (distinct (bvadd ((_ sign_extend 1) ?x558) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x335)) true)))
(let (($x1334 (and (distinct (bvmul ((_ sign_extend 64) ?x727) ((_ sign_extend 64) ?x452)) ((_ sign_extend 64) ?x558)) true)))
(let (($x871 (or $x64 $x64 (or $x1334))))
(let (($x1036 (or $x871 false (or $x735))))
(let (($x437 (or (or $x1036 false false) $x114)))
(and (not $x437) (or $x1100 (and (distinct ?x1063 ?x62) true))))))))))))))))))))))))
(check-sat)
; query 379: function gsm_mult_r, block 9, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x727 ((_ sign_extend 48) in0_16)))
(let ((?x452 ((_ sign_extend 48) in1_16)))
(let ((?x1787 (bvmul ?x452 ?x727)))
(let ((?x1107 (bvadd ?x1787 (_ bv16384 64))))
(let ((?x62 (bvashr ?x1107 (_ bv15 64))))
(let ((?x1069 (bvand ?x62 (_ bv65535 64))))
(let ((?x558 (bvmul ?x727 ?x452)))
(let ((?x335 (bvadd ?x558 (_ bv16384 64))))
(let ((?x1063 (bvashr ?x335 (_ bv15 64))))
(let ((?x243 (bvand ?x1063 (_ bv65535 64))))
(let (($x114 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x233 (and (distinct (bvadd ((_ sign_extend 1) ?x1787) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x1107)) true)))
(let (($x1790 (and (distinct (bvmul ((_ sign_extend 64) ?x452) ((_ sign_extend 64) ?x727)) ((_ sign_extend 64) ?x1787)) true)))
(let (($x64 (or false false)))
(let (($x1791 (or $x64 $x64 (or $x1790))))
(let (($x225 (or $x1791 false (or $x233))))
(let (($x1100 (or (or $x225 false false) $x114)))
(let (($x2099 (or $x1100 false false)))
(let (($x735 (and (distinct (bvadd ((_ sign_extend 1) ?x558) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x335)) true)))
(let (($x1334 (and (distinct (bvmul ((_ sign_extend 64) ?x727) ((_ sign_extend 64) ?x452)) ((_ sign_extend 64) ?x558)) true)))
(let (($x871 (or $x64 $x64 (or $x1334))))
(let (($x1036 (or $x871 false (or $x735))))
(let (($x437 (or (or $x1036 false false) $x114)))
(let (($x222 (or $x437 false false)))
(and (not $x222) (or $x2099 (and (distinct ?x243 ?x1069) true))))))))))))))))))))))))))))
(check-sat)
; query 380: function gsm_mult_r, block 9, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x727 ((_ sign_extend 48) in0_16)))
(let ((?x452 ((_ sign_extend 48) in1_16)))
(let ((?x1787 (bvmul ?x452 ?x727)))
(let ((?x1107 (bvadd ?x1787 (_ bv16384 64))))
(let ((?x62 (bvashr ?x1107 (_ bv15 64))))
(let ((?x1069 (bvand ?x62 (_ bv65535 64))))
(let (($x1964 (and (distinct ((_ extract 15 0) (bvand (bvashr (bvadd (bvmul ?x727 ?x452) (_ bv16384 64)) (_ bv15 64)) (_ bv65535 64))) ((_ extract 15 0) ?x1069)) true)))
(let (($x114 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x233 (and (distinct (bvadd ((_ sign_extend 1) ?x1787) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x1107)) true)))
(let (($x1790 (and (distinct (bvmul ((_ sign_extend 64) ?x452) ((_ sign_extend 64) ?x727)) ((_ sign_extend 64) ?x1787)) true)))
(let (($x64 (or false false)))
(let (($x1791 (or $x64 $x64 (or $x1790))))
(let (($x225 (or $x1791 false (or $x233))))
(let (($x1100 (or (or $x225 false false) $x114)))
(let (($x2099 (or $x1100 false false)))
(let (($x735 (and (distinct (bvadd ((_ sign_extend 1) (bvmul ?x727 ?x452)) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) (bvadd (bvmul ?x727 ?x452) (_ bv16384 64)))) true)))
(let (($x1334 (and (distinct (bvmul ((_ sign_extend 64) ?x727) ((_ sign_extend 64) ?x452)) ((_ sign_extend 64) (bvmul ?x727 ?x452))) true)))
(let (($x871 (or $x64 $x64 (or $x1334))))
(let (($x1036 (or $x871 false (or $x735))))
(let (($x437 (or (or $x1036 false false) $x114)))
(let (($x222 (or $x437 false false)))
(and (not (or $x222 false)) (or (or $x2099 false) $x1964))))))))))))))))))))))))
(check-sat)
; query 381: function gsm_mult_r, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 382: function gsm_mult_r, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1763 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x140 (not $x640)))
(and $x140 (or $x640 (and (distinct ?x1763 ?x1763) true))))))))
(check-sat)
; query 383: function gsm_norm, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1396 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x1338 (or false false false)))
(let (($x1128 (not $x1338)))
(and $x1128 (or $x1338 (and (distinct ?x1396 ?x1396) true)))))))
(check-sat)
; query 384: function gsm_norm, block 12, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1914 (ite (bvsge (_ bv18446744072635809792 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x1338 (or false false false)))
(let (($x1128 (not $x1338)))
(and $x1128 (or $x1338 (and (distinct ?x1914 ?x1914) true)))))))
(check-sat)
; query 385: function gsm_norm, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x1338 (or false false false)))
(let (($x1128 (not $x1338)))
(and $x1128 (or $x1338 (and (distinct (bvxor in0_64 (_ bv18446744073709551615 64)) (bvxor in0_64 (_ bv18446744073709551615 64))) true))))))
(check-sat)
; query 386: function gsm_norm, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_64 () (_ BitVec 64))
(assert
 (let (($x1338 (or false false false)))
(let (($x1128 (not $x1338)))
(and $x1128 (or $x1338 (and (distinct (bvand in.01_64 (_ bv4278190080 64)) (bvand in.01_64 (_ bv4278190080 64))) true))))))
(check-sat)
; query 387: function gsm_norm, block 20, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_64 () (_ BitVec 64))
(assert
 (let ((?x221 (ite (and (distinct (_ bv0 64) (bvand in.01_64 (_ bv4278190080 64))) true) (_ bv1 1) (_ bv0 1))))
(let (($x1338 (or false false false)))
(let (($x1599 (or $x1338 false false)))
(let (($x635 (not $x1599)))
(and $x635 (or $x1599 (and (distinct ?x221 ?x221) true))))))))
(check-sat)
; query 388: function gsm_norm, block 39, name %40
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_64 () (_ BitVec 64))
(assert
 (let (($x1338 (or false false false)))
(let (($x1128 (not $x1338)))
(and $x1128 (or $x1338 (and (distinct (bvand in.01_64 (_ bv65280 64)) (bvand in.01_64 (_ bv65280 64))) true))))))
(check-sat)
; query 389: function gsm_norm, block 39, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_64 () (_ BitVec 64))
(assert
 (let ((?x2109 (ite (and (distinct (_ bv0 64) (bvand in.01_64 (_ bv65280 64))) true) (_ bv1 1) (_ bv0 1))))
(let (($x1338 (or false false false)))
(let (($x1599 (or $x1338 false false)))
(let (($x635 (not $x1599)))
(and $x635 (or $x1599 (and (distinct ?x2109 ?x2109) true))))))))
(check-sat)
; query 390: function gsm_norm, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2117 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x1338 (or false false false)))
(let (($x1128 (not $x1338)))
(and $x1128 (or $x1338 (and (distinct ?x2117 ?x2117) true)))))))
(check-sat)
; query 391: function gsm_norm, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2117 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x2118 (bvxor ?x2117 (_ bv1 1))))
(let (($x1338 (or false false false)))
(let (($x1599 (or $x1338 false false)))
(let (($x635 (not $x1599)))
(and $x635 (or $x1599 (and (distinct ?x2118 ?x2118) true)))))))))
(check-sat)
; query 392: function gsm_norm, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2117 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x2118 (bvxor ?x2117 (_ bv1 1))))
(let ((?x2119 ((_ zero_extend 31) ?x2118)))
(let (($x1338 (or false false false)))
(let (($x1599 (or $x1338 false false)))
(let (($x2120 (or $x1599 false)))
(and (not $x2120) (or $x2120 (and (distinct ?x2119 ?x2119) true))))))))))
(check-sat)
; query 393: function gsm_norm, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2117 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x2118 (bvxor ?x2117 (_ bv1 1))))
(let ((?x2119 ((_ zero_extend 31) ?x2118)))
(let ((?x2121 ((_ sign_extend 32) ?x2119)))
(let (($x1338 (or false false false)))
(let (($x1599 (or $x1338 false false)))
(let (($x2120 (or $x1599 false)))
(let (($x2122 (or $x2120 false)))
(and (not $x2122) (or $x2122 (and (distinct ?x2121 ?x2121) true))))))))))))
(check-sat)
; query 394: function gsm_norm, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2117 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x2118 (bvxor ?x2117 (_ bv1 1))))
(let ((?x2119 ((_ zero_extend 31) ?x2118)))
(let ((?x2121 ((_ sign_extend 32) ?x2119)))
(let ((?x2125 (ite (and (distinct (_ bv0 64) ?x2121) true) (_ bv1 1) (_ bv0 1))))
(let (($x1338 (or false false false)))
(let (($x1599 (or $x1338 false false)))
(let (($x2120 (or $x1599 false)))
(let (($x2122 (or $x2120 false)))
(let (($x2124 (or $x2122 false false)))
(and (not $x2124) (or $x2124 (and (distinct ?x2125 ?x2125) true))))))))))))))
(check-sat)
; query 395: function gsm_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_64 () (_ BitVec 64))
(assert
 (let ((?x1919 (ite (bvslt (_ bv32767 64) in5_64) (_ bv1 1) (_ bv0 1))))
(let (($x1338 (or false false false)))
(let (($x1128 (not $x1338)))
(and $x1128 (or $x1338 (and (distinct ?x1919 ?x1919) true)))))))
(check-sat)
; query 396: function gsm_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 397: function gsm_sub, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 398: function gsm_sub, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x452 ((_ sign_extend 48) in1_16)))
(let ((?x727 ((_ sign_extend 48) in0_16)))
(let ((?x2145 (bvsub ?x727 ?x452)))
(let (($x2147 (and (distinct (bvsub ((_ sign_extend 1) ?x727) ((_ sign_extend 1) ?x452)) ((_ sign_extend 1) ?x2145)) true)))
(let (($x64 (or false false)))
(let (($x2149 (or $x64 $x64 (or $x2147))))
(and (not $x2149) (or $x2149 (and (distinct ?x2145 ?x2145) true))))))))))
(check-sat)
; query 399: function gsm_sub, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x2152 (ite (bvsgt (_ bv18446744073709518848 64) (bvsub ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x452 ((_ sign_extend 48) in1_16)))
(let ((?x1926 ((_ sign_extend 1) ?x452)))
(let ((?x727 ((_ sign_extend 48) in0_16)))
(let ((?x31 ((_ sign_extend 1) ?x727)))
(let (($x64 (or false false)))
(let (($x2149 (or $x64 $x64 (or (and (distinct (bvsub ?x31 ?x1926) ((_ sign_extend 1) (bvsub ?x727 ?x452))) true)))))
(let (($x2151 (or $x2149 false false)))
(and (not $x2151) (or $x2151 (and (distinct ?x2152 ?x2152) true))))))))))))
(check-sat)
; query 400: function ok_to_replace, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x2162 (ite (and (distinct (_ bv4294967295 32) in.01_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x1338 (or false false false)))
(let (($x1128 (not $x1338)))
(and $x1128 (or $x1338 (and (distinct ?x2162 ?x2162) true)))))))
(check-sat)
; query 401: function ok_to_replace, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in16_32 () (_ BitVec 32))
(assert
 (let ((?x2168 (ite (= (_ bv121 32) in16_32) (_ bv1 1) (_ bv0 1))))
(let (($x1338 (or false false false)))
(let (($x1128 (not $x1338)))
(and $x1128 (or $x1338 (and (distinct ?x2168 ?x2168) true)))))))
(check-sat)
; query 402: function process_decode, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 32) in14_32) ((_ sign_extend 32) in14_32)) true))))))
(check-sat)
; query 403: function process_decode, block 16, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x2176 (ite (and (distinct (_ bv33 64) ((_ sign_extend 32) in14_32)) true) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x140 (not $x640)))
(and $x140 (or $x640 (and (distinct ?x2176 ?x2176) true))))))))
(check-sat)
; query 404: function process_decode, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x2184 (ite (bvsle (_ bv0 32) in14_32) (_ bv1 1) (_ bv0 1))))
(let (($x1338 (or false false false)))
(let (($x1128 (not $x1338)))
(and $x1128 (or $x1338 (and (distinct ?x2184 ?x2184) true)))))))
(check-sat)
; query 405: function process_decode, block 71, name %72
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x2189 (ite (bvsgt (_ bv0 32) in14_32) (_ bv1 1) (_ bv0 1))))
(let (($x1338 (or false false false)))
(let (($x1128 (not $x1338)))
(and $x1128 (or $x1338 (and (distinct ?x2189 ?x2189) true)))))))
(check-sat)
; query 406: function process_encode, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_32 () (_ BitVec 32))
(assert
 (let (($x64 (or false false)))
(let (($x206 (not $x64)))
(and $x206 (or $x64 (and (distinct ((_ sign_extend 32) in13_32) ((_ sign_extend 32) in13_32)) true))))))
(check-sat)
; query 407: function process_encode, block 15, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_32 () (_ BitVec 32))
(assert
 (let ((?x2197 (ite (bvult ((_ sign_extend 32) in13_32) (_ bv160 64)) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x640 (or $x64 false false)))
(let (($x140 (not $x640)))
(and $x140 (or $x640 (and (distinct ?x2197 ?x2197) true))))))))
(check-sat)
; query 408: function process_encode, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_32 () (_ BitVec 32))
(assert
 (let ((?x2205 (ite (bvsgt (_ bv0 32) in13_32) (_ bv1 1) (_ bv0 1))))
(let (($x1338 (or false false false)))
(let (($x1128 (not $x1338)))
(and $x1128 (or $x1338 (and (distinct ?x2205 ?x2205) true)))))))
(check-sat)
; query 409: function suffix, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_64 () (_ BitVec 64))
(declare-fun in3_64 () (_ BitVec 64))
(assert
 (let ((?x2211 (ite (bvule in3_64 in4_64) (_ bv1 1) (_ bv0 1))))
(let (($x1338 (or false false false)))
(let (($x1128 (not $x1338)))
(and $x1128 (or $x1338 (and (distinct ?x2211 ?x2211) true)))))))
(check-sat)
; query 410: function ulaw_input, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x1567 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x1440 (or false false (or $x1567))))
(and (not $x1440) (or $x1440 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 411: function ulaw_input, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let ((?x166 (ite (= (_ bv4294967295 32) in.1_32) (_ bv1 1) (_ bv0 1))))
(let (($x1338 (or false false false)))
(let (($x1128 (not $x1338)))
(and $x1128 (or $x1338 (and (distinct ?x166 ?x166) true)))))))
(check-sat)
