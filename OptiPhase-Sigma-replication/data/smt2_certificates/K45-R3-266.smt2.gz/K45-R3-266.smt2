; OptiPhase-Sigma refinement certificate for sweep K45-R3-266
; query 0: function Index_to_frequency, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1321 (ite (bvuge in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x97 (or false false false)))
(let (($x90 (not $x97)))
(and $x90 (or $x97 (and (distinct ?x1321 ?x1321) true)))))))
(check-sat)
; query 1: function IsPowerOfTwo, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x97 (or false false false)))
(let (($x90 (not $x97)))
(and $x90 (or $x97 (and (distinct (bvsub in0_32 (_ bv1 32)) (bvsub in0_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function IsPowerOfTwo, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x125 (bvsub in0_32 (_ bv1 32))))
(let ((?x81 (bvand in0_32 ?x125)))
(let (($x97 (or false false false)))
(let (($x33 (or false $x97 false)))
(and (not $x33) (or $x33 (and (distinct ?x81 ?x81) true))))))))
(check-sat)
; query 3: function IsPowerOfTwo, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x126 (ite (and (distinct (_ bv0 32) (bvand in0_32 (bvsub in0_32 (_ bv1 32)))) true) (_ bv1 1) (_ bv0 1))))
(let (($x97 (or false false false)))
(let (($x33 (or false $x97 false)))
(let (($x142 (or $x33 false false)))
(and (not $x142) (or $x142 (and (distinct ?x126 ?x126) true))))))))
(check-sat)
; query 4: function IsPowerOfTwo, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x2791 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x97 (or false false false)))
(let (($x90 (not $x97)))
(and $x90 (or $x97 (and (distinct ?x2791 ?x2791) true)))))))
(check-sat)
; query 5: function NumberOfBitsNeeded, block 13, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x97 (or false false false)))
(let (($x90 (not $x97)))
(and $x90 (or $x97 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 6: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x2791 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x97 (or false false false)))
(let (($x90 (not $x97)))
(and $x90 (or $x97 (and (distinct ?x2791 ?x2791) true)))))))
(check-sat)
; query 7: function ReverseBits, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x97 (or false false false)))
(let (($x90 (not $x97)))
(and $x90 (or $x97 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function ReverseBits, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x97 (or false false false)))
(let (($x61 (or $x97 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x189 (not $x61)))
(and $x189 (or $x61 (and (distinct (bvshl in.01_32 (_ bv1 32)) (bvshl in.01_32 (_ bv1 32))) true)))))))
(check-sat)
; query 9: function ReverseBits, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x97 (or false false false)))
(let (($x90 (not $x97)))
(and $x90 (or $x97 (and (distinct (bvand in.0_32 (_ bv1 32)) (bvand in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 10: function ReverseBits, block 5, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x140 (bvand in.0_32 (_ bv1 32))))
(let ((?x467 (bvshl in.01_32 (_ bv1 32))))
(let ((?x131 (bvor ?x467 ?x140)))
(let (($x97 (or false false false)))
(let (($x61 (or $x97 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x139 (or $x61 $x97 false)))
(and (not $x139) (or $x139 (and (distinct ?x131 ?x131) true))))))))))
(check-sat)
; query 11: function ReverseBits, block 5, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x97 (or false false false)))
(let (($x61 (or $x97 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x189 (not $x61)))
(and $x189 (or $x61 (and (distinct (bvlshr in.0_32 (_ bv1 32)) (bvlshr in.0_32 (_ bv1 32))) true)))))))
(check-sat)
; query 12: function fft_float, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x77 (ite (and (distinct (_ bv0 32) in1_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x97 (or false false false)))
(let (($x90 (not $x97)))
(and $x90 (or $x97 (and (distinct ?x77 ?x77) true)))))))
(check-sat)
; query 13: function fft_float, block 41, name %42
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.05_32 () (_ BitVec 32))
(assert
 (let (($x97 (or false false false)))
(let (($x90 (not $x97)))
(and $x90 (or $x97 (and (distinct (bvadd in.05_32 (_ bv1 32)) (bvadd in.05_32 (_ bv1 32))) true))))))
(check-sat)
; query 14: function main, block 110, name %111
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x97 (or false false false)))
(let (($x90 (not $x97)))
(and $x90 (or $x97 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 15: function main, block 113, name %114
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x97 (or false false false)))
(let (($x90 (not $x97)))
(and $x90 (or $x97 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 16: function main, block 126, name %127
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let (($x97 (or false false false)))
(let (($x90 (not $x97)))
(and $x90 (or $x97 (and (distinct (bvadd in.2_32 (_ bv1 32)) (bvadd in.2_32 (_ bv1 32))) true))))))
(check-sat)
; query 17: function main, block 139, name %140
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.3_32 () (_ BitVec 32))
(assert
 (let (($x97 (or false false false)))
(let (($x90 (not $x97)))
(and $x90 (or $x97 (and (distinct (bvadd in.3_32 (_ bv1 32)) (bvadd in.3_32 (_ bv1 32))) true))))))
(check-sat)
; query 18: function main, block 57, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x97 (or false false false)))
(let (($x90 (not $x97)))
(and $x90 (or $x97 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 19: function main, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x491 (ite (= (_ bv4 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x97 (or false false false)))
(let (($x90 (not $x97)))
(and $x90 (or $x97 (and (distinct ?x491 ?x491) true)))))))
(check-sat)
; query 20: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x94 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x97 (or false false false)))
(let (($x90 (not $x97)))
(and $x90 (or $x97 (and (distinct ?x94 ?x94) true)))))))
(check-sat)
