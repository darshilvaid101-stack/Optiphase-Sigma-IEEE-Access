; OptiPhase-Sigma refinement certificate for sweep K15-R3-171
; query 0: function xmalloc, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in7_32 () (_ BitVec 32))
(assert
 (let ((?x298 (ite (and (distinct (_ bv0 32) in7_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x5 (or false false false)))
(and (not $x5) (or $x5 (and (distinct ?x298 ?x298) true))))))
(check-sat)
