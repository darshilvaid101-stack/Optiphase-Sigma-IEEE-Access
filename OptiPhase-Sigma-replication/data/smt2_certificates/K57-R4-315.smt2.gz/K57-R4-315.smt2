; OptiPhase-Sigma refinement certificate for sweep K57-R4-315
; query 0: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x346 (or false false)))
(let (($x1104 (not $x346)))
(and $x1104 (or $x346 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 1: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x115 ((_ sign_extend 16) in3_16)))
(let ((?x60 (bvand ?x115 (_ bv127 32))))
(let (($x346 (or false false)))
(let (($x434 (or $x346 false false)))
(let (($x539 (not $x434)))
(and $x539 (or $x434 (and (distinct ?x60 ?x60) true)))))))))
(check-sat)
; query 2: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x115 ((_ sign_extend 16) in3_16)))
(let ((?x60 (bvand ?x115 (_ bv127 32))))
(let ((?x100 ((_ extract 15 0) ?x60)))
(let (($x346 (or false false)))
(let (($x434 (or $x346 false false)))
(let (($x849 (or $x434 false)))
(let (($x1549 (not $x849)))
(and $x1549 (or $x849 (and (distinct ?x100 ?x100) true)))))))))))
(check-sat)
; query 3: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x346 (or false false)))
(let (($x1104 (not $x346)))
(and $x1104 (or $x346 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 4: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x343 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x346 (or false false)))
(let (($x434 (or $x346 false false)))
(let (($x539 (not $x434)))
(and $x539 (or $x434 (and (distinct ?x343 ?x343) true))))))))
(check-sat)
; query 5: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x113 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x63 (or false false false)))
(let (($x805 (not $x63)))
(and $x805 (or $x63 (and (distinct ?x113 ?x113) true)))))))
(check-sat)
; query 6: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x796 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x63 (or false false false)))
(let (($x805 (not $x63)))
(and $x805 (or $x63 (and (distinct ?x796 ?x796) true)))))))
(check-sat)
; query 7: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x63 (or false false false)))
(let (($x805 (not $x63)))
(and $x805 (or $x63 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 8: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x1042 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x20 (or false false (or $x1042))))
(and (not $x20) (or $x20 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 9: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1021 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1599 ((_ zero_extend 31) ?x1021)))
(let ((?x259 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x765 ((_ zero_extend 31) ?x259)))
(let ((?x66 (bvand ?x765 ?x1599)))
(let ((?x1224 (ite (and (distinct (_ bv0 32) ?x66) true) (_ bv1 1) (_ bv0 1))))
(let ((?x99 ((_ zero_extend 63) ?x1224)))
(let (($x346 (or false false)))
(let (($x434 (or $x346 false false)))
(let (($x849 (or $x434 false)))
(let (($x1161 (or $x849 $x849 false)))
(let (($x2062 (or $x1161 false false)))
(let (($x329 (or $x2062 false)))
(and (not $x329) (or $x329 (and (distinct ?x99 ?x99) true)))))))))))))))))
(check-sat)
; query 10: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1021 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1599 ((_ zero_extend 31) ?x1021)))
(let ((?x259 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x765 ((_ zero_extend 31) ?x259)))
(let ((?x66 (bvand ?x765 ?x1599)))
(let ((?x1224 (ite (and (distinct (_ bv0 32) ?x66) true) (_ bv1 1) (_ bv0 1))))
(let (($x58 (= (_ bv1 1) ?x1224)))
(let ((?x1435 (ite $x58 (_ bv1 32) (_ bv0 32))))
(let (($x346 (or false false)))
(let (($x434 (or $x346 false false)))
(let (($x849 (or $x434 false)))
(let (($x1161 (or $x849 $x849 false)))
(let (($x2062 (or $x1161 false false)))
(let (($x18 (or $x2062 (ite $x58 false false))))
(and (not $x18) (or $x18 (and (distinct ?x1435 ?x1435) true))))))))))))))))))
(check-sat)
; query 11: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1021 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1599 ((_ zero_extend 31) ?x1021)))
(let ((?x259 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x765 ((_ zero_extend 31) ?x259)))
(let ((?x66 (bvand ?x765 ?x1599)))
(let ((?x1224 (ite (and (distinct (_ bv0 32) ?x66) true) (_ bv1 1) (_ bv0 1))))
(let (($x58 (= (_ bv1 1) ?x1224)))
(let ((?x1435 (ite $x58 (_ bv1 32) (_ bv0 32))))
(let ((?x328 ((_ extract 7 0) ?x1435)))
(let (($x346 (or false false)))
(let (($x434 (or $x346 false false)))
(let (($x849 (or $x434 false)))
(let (($x1161 (or $x849 $x849 false)))
(let (($x2062 (or $x1161 false false)))
(let (($x18 (or $x2062 (ite $x58 false false))))
(let (($x2872 (or $x18 false)))
(and (not $x2872) (or $x2872 (and (distinct ?x328 ?x328) true))))))))))))))))))))
(check-sat)
; query 12: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x346 (or false false)))
(let (($x1104 (not $x346)))
(and $x1104 (or $x346 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 13: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x259 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x346 (or false false)))
(let (($x434 (or $x346 false false)))
(let (($x539 (not $x434)))
(and $x539 (or $x434 (and (distinct ?x259 ?x259) true))))))))
(check-sat)
; query 14: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x259 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x765 ((_ zero_extend 31) ?x259)))
(let (($x346 (or false false)))
(let (($x434 (or $x346 false false)))
(let (($x849 (or $x434 false)))
(let (($x1549 (not $x849)))
(and $x1549 (or $x849 (and (distinct ?x765 ?x765) true))))))))))
(check-sat)
; query 15: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x346 (or false false)))
(let (($x1104 (not $x346)))
(and $x1104 (or $x346 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 16: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1021 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x346 (or false false)))
(let (($x434 (or $x346 false false)))
(let (($x539 (not $x434)))
(and $x539 (or $x434 (and (distinct ?x1021 ?x1021) true))))))))
(check-sat)
; query 17: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1021 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1599 ((_ zero_extend 31) ?x1021)))
(let (($x346 (or false false)))
(let (($x434 (or $x346 false false)))
(let (($x849 (or $x434 false)))
(let (($x1549 (not $x849)))
(and $x1549 (or $x849 (and (distinct ?x1599 ?x1599) true))))))))))
(check-sat)
; query 18: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1021 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1599 ((_ zero_extend 31) ?x1021)))
(let ((?x259 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x765 ((_ zero_extend 31) ?x259)))
(let ((?x66 (bvand ?x765 ?x1599)))
(let (($x346 (or false false)))
(let (($x434 (or $x346 false false)))
(let (($x849 (or $x434 false)))
(let (($x1161 (or $x849 $x849 false)))
(and (not $x1161) (or $x1161 (and (distinct ?x66 ?x66) true)))))))))))))
(check-sat)
; query 19: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1021 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1599 ((_ zero_extend 31) ?x1021)))
(let ((?x259 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x765 ((_ zero_extend 31) ?x259)))
(let ((?x66 (bvand ?x765 ?x1599)))
(let ((?x1224 (ite (and (distinct (_ bv0 32) ?x66) true) (_ bv1 1) (_ bv0 1))))
(let (($x346 (or false false)))
(let (($x434 (or $x346 false false)))
(let (($x849 (or $x434 false)))
(let (($x1161 (or $x849 $x849 false)))
(let (($x2062 (or $x1161 false false)))
(and (not $x2062) (or $x2062 (and (distinct ?x1224 ?x1224) true)))))))))))))))
(check-sat)
; query 20: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x2871 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x63 (or false false false)))
(let (($x805 (not $x63)))
(and $x805 (or $x63 (and (distinct ?x2871 ?x2871) true)))))))
(check-sat)
