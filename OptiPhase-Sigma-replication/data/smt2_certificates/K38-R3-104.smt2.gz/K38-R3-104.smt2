; OptiPhase-Sigma refinement certificate for sweep K38-R3-104
; query 0: function BF_ofb64_encrypt, block 82, name %83
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x178 (ite (= (_ bv0 32) in.04_32) (_ bv1 1) (_ bv0 1))))
(let (($x84 (or false false false)))
(and (not $x84) (or $x84 (and (distinct ?x178 ?x178) true))))))
(check-sat)
