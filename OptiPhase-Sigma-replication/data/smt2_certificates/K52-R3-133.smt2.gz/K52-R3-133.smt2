; OptiPhase-Sigma refinement certificate for sweep K52-R3-133
; query 0: function check, block 67, name %68
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x33 (ite (= (_ bv5 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x1703 (or false false false)))
(let (($x58 (not $x1703)))
(and $x58 (or $x1703 (and (distinct (ite (= (_ bv1 32) in0_32) (_ bv1 1) (_ bv0 1)) ?x33) true)))))))
(check-sat)
; query 1: function check, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x765 (ite (= (_ bv11 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x1703 (or false false false)))
(let (($x58 (not $x1703)))
(and $x58 (or $x1703 (and (distinct (ite (= (_ bv2 32) in0_32) (_ bv1 1) (_ bv0 1)) ?x765) true)))))))
(check-sat)
; query 2: function check, block 79, name %80
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x1590 (and (distinct (ite (= (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1)) (ite (= (_ bv22 32) in0_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x1703 (or false false false)))
(let (($x58 (not $x1703)))
(and $x58 (or $x1703 $x1590))))))
(check-sat)
; query 3: function check, block 85, name %86
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x1565 (and (distinct (ite (= (_ bv4 32) in0_32) (_ bv1 1) (_ bv0 1)) (ite (= (_ bv33 32) in0_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x1703 (or false false false)))
(let (($x58 (not $x1703)))
(and $x58 (or $x1703 $x1565))))))
(check-sat)
; query 4: function check, block 91, name %92
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x33 (ite (= (_ bv5 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x1703 (or false false false)))
(let (($x58 (not $x1703)))
(and $x58 (or $x1703 (and (distinct ?x33 (ite (= (_ bv0 32) in0_32) (_ bv1 1) (_ bv0 1))) true)))))))
(check-sat)
; query 5: function check, block 97, name %98
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x765 (ite (= (_ bv11 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x1703 (or false false false)))
(let (($x58 (not $x1703)))
(and $x58 (or $x1703 (and (distinct ?x765 (ite (= (_ bv12 32) in0_32) (_ bv1 1) (_ bv0 1))) true)))))))
(check-sat)
; query 6: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x239 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x1703 (or false false false)))
(let (($x58 (not $x1703)))
(and $x58 (or $x1703 (and (distinct ?x239 ?x239) true)))))))
(check-sat)
; query 7: function set1d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x362 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x1703 (or false false false)))
(let (($x58 (not $x1703)))
(and $x58 (or $x1703 (and (distinct ?x362 ?x362) true)))))))
(check-sat)
; query 8: function set1ds, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x97 (ite (= (_ bv4294967295 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x1703 (or false false false)))
(let (($x58 (not $x1703)))
(and $x58 (or $x1703 (and (distinct ?x97 ?x97) true)))))))
(check-sat)
; query 9: function set2d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x362 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x1703 (or false false false)))
(let (($x58 (not $x1703)))
(and $x58 (or $x1703 (and (distinct ?x362 ?x362) true)))))))
(check-sat)
