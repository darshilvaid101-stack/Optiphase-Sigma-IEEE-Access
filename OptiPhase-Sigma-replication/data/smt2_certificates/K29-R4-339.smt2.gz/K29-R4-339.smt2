; OptiPhase-Sigma refinement certificate for sweep K29-R4-339
