; OptiPhase-Sigma refinement certificate for sweep K59-R2-075
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x606 (or false false)))
(let (($x6 (not $x606)))
(and $x6 (or $x606 (and (distinct ((_ sign_extend 16) in25_16) ((_ sign_extend 16) in25_16)) true))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let ((?x10 (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))))
(let (($x606 (or false false)))
(let (($x1362 (or $x606 false false)))
(let (($x2372 (not $x1362)))
(and $x2372 (or $x1362 (and (distinct ?x10 ?x10) true))))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x606 (or false false)))
(let (($x6 (not $x606)))
(and $x6 (or $x606 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x574 ((_ sign_extend 16) in3_16)))
(let ((?x2370 (bvand ?x574 (_ bv127 32))))
(let (($x606 (or false false)))
(let (($x1362 (or $x606 false false)))
(let (($x2372 (not $x1362)))
(and $x2372 (or $x1362 (and (distinct ?x2370 ?x2370) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x574 ((_ sign_extend 16) in3_16)))
(let ((?x2370 (bvand ?x574 (_ bv127 32))))
(let ((?x494 ((_ extract 15 0) ?x2370)))
(let (($x606 (or false false)))
(let (($x1362 (or $x606 false false)))
(let (($x2348 (or $x1362 false)))
(let (($x1278 (not $x2348)))
(and $x1278 (or $x2348 (and (distinct ?x494 ?x494) true)))))))))))
(check-sat)
; query 5: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x606 (or false false)))
(let (($x6 (not $x606)))
(and $x6 (or $x606 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 6: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x62 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x606 (or false false)))
(let (($x1362 (or $x606 false false)))
(let (($x2372 (not $x1362)))
(and $x2372 (or $x1362 (and (distinct ?x62 ?x62) true))))))))
(check-sat)
; query 7: function core_bench_list, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x1448 (or false false false)))
(let (($x126 (not $x1448)))
(and $x126 (or $x1448 (and (distinct (bvadd in.0_16 (_ bv1 16)) (bvadd in.0_16 (_ bv1 16))) true))))))
(check-sat)
; query 8: function core_bench_state, block 105, name %106
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x1448 (or false false false)))
(let (($x126 (not $x1448)))
(and $x126 (or $x1448 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 9: function core_bench_state, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1448 (or false false false)))
(let (($x126 (not $x1448)))
(and $x126 (or $x1448 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 10: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x74 (bvadd in.01_32 (_ bv1 32))))
(let (($x361 (and (distinct ?x74 ?x74) true)))
(let (($x1448 (or false false false)))
(let (($x126 (not $x1448)))
(and $x126 (or $x1448 $x361)))))))
(check-sat)
; query 11: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x74 (bvadd in.01_32 (_ bv1 32))))
(let ((?x78 (bvmul ?x74 ?x74)))
(let (($x1448 (or false false false)))
(let (($x885 (or $x1448 $x1448 false)))
(and (not $x885) (or $x885 (and (distinct ?x78 ?x78) true))))))))
(check-sat)
; query 12: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x74 (bvadd in.01_32 (_ bv1 32))))
(let ((?x78 (bvmul ?x74 ?x74)))
(let ((?x1319 (bvmul ?x78 (_ bv2 32))))
(let (($x1448 (or false false false)))
(let (($x885 (or $x1448 $x1448 false)))
(let (($x1309 (or $x885 false false)))
(and (not $x1309) (or $x1309 (and (distinct ?x1319 ?x1319) true))))))))))
(check-sat)
; query 13: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x74 (bvadd in.01_32 (_ bv1 32))))
(let ((?x78 (bvmul ?x74 ?x74)))
(let ((?x1319 (bvmul ?x78 (_ bv2 32))))
(let ((?x7 (bvmul ?x1319 (_ bv4 32))))
(let (($x1448 (or false false false)))
(let (($x885 (or $x1448 $x1448 false)))
(let (($x1309 (or $x885 false false)))
(let (($x1119 (or $x1309 false false)))
(and (not $x1119) (or $x1119 (and (distinct ?x7 ?x7) true))))))))))))
(check-sat)
; query 14: function core_init_matrix, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x1448 (or false false false)))
(let (($x126 (not $x1448)))
(and $x126 (or $x1448 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 15: function core_init_matrix, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x1448 (or false false false)))
(let (($x126 (not $x1448)))
(and $x126 (or $x1448 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 16: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x13 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x1448 (or false false false)))
(let (($x126 (not $x1448)))
(and $x126 (or $x1448 (and (distinct ?x13 ?x13) true)))))))
(check-sat)
; query 17: function core_init_state, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_32 () (_ BitVec 32))
(assert
 (let (($x1448 (or false false false)))
(let (($x126 (not $x1448)))
(and $x126 (or $x1448 (and (distinct (bvadd in.06_32 (_ bv1 32)) (bvadd in.06_32 (_ bv1 32))) true))))))
(check-sat)
; query 18: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x1651 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x1448 (or false false false)))
(let (($x126 (not $x1448)))
(and $x126 (or $x1448 (and (distinct ?x1651 ?x1651) true)))))))
(check-sat)
; query 19: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x1448 (or false false false)))
(let (($x126 (not $x1448)))
(and $x126 (or $x1448 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 20: function core_list_init, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x74 (bvadd in.01_32 (_ bv1 32))))
(let (($x361 (and (distinct ?x74 ?x74) true)))
(let (($x1448 (or false false false)))
(let (($x126 (not $x1448)))
(and $x126 (or $x1448 $x361)))))))
(check-sat)
; query 21: function core_list_mergesort, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x74 (bvadd in.01_32 (_ bv1 32))))
(let (($x361 (and (distinct ?x74 ?x74) true)))
(let (($x101 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x74)) true)))
(let (($x1230 (or false false (or $x101))))
(and (not $x1230) (or $x1230 $x361)))))))
(check-sat)
; query 22: function core_list_mergesort, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x61 (ite (bvslt (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x1448 (or false false false)))
(let (($x126 (not $x1448)))
(and $x126 (or $x1448 (and (distinct ?x61 ?x61) true)))))))
(check-sat)
; query 23: function core_list_mergesort, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.224_32 () (_ BitVec 32))
(assert
 (let ((?x633 (ite (= (_ bv0 32) in.224_32) (_ bv1 1) (_ bv0 1))))
(let (($x1448 (or false false false)))
(let (($x126 (not $x1448)))
(and $x126 (or $x1448 (and (distinct ?x633 ?x633) true)))))))
(check-sat)
; query 24: function core_list_mergesort, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x307 (ite (= (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x1448 (or false false false)))
(let (($x126 (not $x1448)))
(and $x126 (or $x1448 (and (distinct ?x307 ?x307) true)))))))
(check-sat)
; query 25: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x9031 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x2354 (or false false (or $x9031))))
(and (not $x2354) (or $x2354 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 26: function core_list_mergesort, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x5004 (and (distinct (bvmul ((_ sign_extend 32) in.020_32) ((_ sign_extend 32) (_ bv2 32))) ((_ sign_extend 32) (bvmul in.020_32 (_ bv2 32)))) true)))
(let (($x2204 (or false false (or $x5004))))
(and (not $x2204) (or $x2204 (and (distinct (bvmul in.020_32 (_ bv2 32)) (bvmul in.020_32 (_ bv2 32))) true))))))
(check-sat)
; query 27: function core_state_transition, block 102, name %103
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x606 (or false false)))
(let (($x6 (not $x606)))
(and $x6 (or $x606 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 28: function core_state_transition, block 102, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x9316 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x606 (or false false)))
(let (($x1362 (or $x606 false false)))
(let (($x2372 (not $x1362)))
(and $x2372 (or $x1362 (and (distinct ?x9316 ?x9316) true))))))))
(check-sat)
; query 29: function core_state_transition, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x606 (or false false)))
(let (($x6 (not $x606)))
(and $x6 (or $x606 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 30: function core_state_transition, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x2392 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x606 (or false false)))
(let (($x1362 (or $x606 false false)))
(let (($x2372 (not $x1362)))
(and $x2372 (or $x1362 (and (distinct ?x2392 ?x2392) true))))))))
(check-sat)
; query 31: function core_state_transition, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x606 (or false false)))
(let (($x6 (not $x606)))
(and $x6 (or $x606 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 32: function core_state_transition, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x9316 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x606 (or false false)))
(let (($x1362 (or $x606 false false)))
(let (($x2372 (not $x1362)))
(and $x2372 (or $x1362 (and (distinct ?x9316 ?x9316) true))))))))
(check-sat)
; query 33: function core_state_transition, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x606 (or false false)))
(let (($x6 (not $x606)))
(and $x6 (or $x606 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 34: function core_state_transition, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x2600 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x606 (or false false)))
(let (($x1362 (or $x606 false false)))
(let (($x2372 (not $x1362)))
(and $x2372 (or $x1362 (and (distinct ?x2600 ?x2600) true))))))))
(check-sat)
; query 35: function core_state_transition, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x606 (or false false)))
(let (($x6 (not $x606)))
(and $x6 (or $x606 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 36: function core_state_transition, block 51, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x2600 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x606 (or false false)))
(let (($x1362 (or $x606 false false)))
(let (($x2372 (not $x1362)))
(and $x2372 (or $x1362 (and (distinct ?x2600 ?x2600) true))))))))
(check-sat)
; query 37: function core_state_transition, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x606 (or false false)))
(let (($x6 (not $x606)))
(and $x6 (or $x606 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 38: function core_state_transition, block 64, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x2600 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x606 (or false false)))
(let (($x1362 (or $x606 false false)))
(let (($x2372 (not $x1362)))
(and $x2372 (or $x1362 (and (distinct ?x2600 ?x2600) true))))))))
(check-sat)
; query 39: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x2144 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x1448 (or false false false)))
(let (($x126 (not $x1448)))
(and $x126 (or $x1448 (and (distinct ?x2144 ?x2144) true)))))))
(check-sat)
; query 40: function core_state_transition, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x606 (or false false)))
(let (($x6 (not $x606)))
(and $x6 (or $x606 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 41: function core_state_transition, block 80, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x9274 (ite (= (_ bv69 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x606 (or false false)))
(let (($x1362 (or $x606 false false)))
(let (($x2372 (not $x1362)))
(and $x2372 (or $x1362 (and (distinct ?x9274 ?x9274) true))))))))
(check-sat)
; query 42: function core_state_transition, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x606 (or false false)))
(let (($x6 (not $x606)))
(and $x6 (or $x606 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 43: function core_state_transition, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x839 (ite (= (_ bv101 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x606 (or false false)))
(let (($x1362 (or $x606 false false)))
(let (($x2372 (not $x1362)))
(and $x2372 (or $x1362 (and (distinct ?x839 ?x839) true))))))))
(check-sat)
; query 44: function core_state_transition, block 99, name %100
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x606 (or false false)))
(let (($x6 (not $x606)))
(and $x6 (or $x606 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 45: function core_state_transition, block 99, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x2392 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x606 (or false false)))
(let (($x1362 (or $x606 false false)))
(let (($x2372 (not $x1362)))
(and $x2372 (or $x1362 (and (distinct ?x2392 ?x2392) true))))))))
(check-sat)
; query 46: function crcu8, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x606 (or false false)))
(let (($x6 (not $x606)))
(and $x6 (or $x606 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 47: function crcu8, block 19, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x59 ((_ zero_extend 16) in.01_16)))
(let ((?x1015 (bvxor ?x59 (_ bv16386 32))))
(let (($x606 (or false false)))
(let (($x1362 (or $x606 false false)))
(let (($x2372 (not $x1362)))
(and $x2372 (or $x1362 (and (distinct ?x1015 ?x1015) true)))))))))
(check-sat)
; query 48: function crcu8, block 19, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x59 ((_ zero_extend 16) in.01_16)))
(let ((?x1015 (bvxor ?x59 (_ bv16386 32))))
(let ((?x5132 ((_ extract 15 0) ?x1015)))
(let (($x606 (or false false)))
(let (($x1362 (or $x606 false false)))
(let (($x2348 (or $x1362 false)))
(let (($x1278 (not $x2348)))
(and $x1278 (or $x2348 (and (distinct ?x5132 ?x5132) true)))))))))))
(check-sat)
; query 49: function crcu8, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x606 (or false false)))
(let (($x6 (not $x606)))
(and $x6 (or $x606 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 50: function crcu8, block 29, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x151 ((_ zero_extend 16) in27_16)))
(let ((?x3920 (bvor ?x151 (_ bv32768 32))))
(let (($x606 (or false false)))
(let (($x1362 (or $x606 false false)))
(let (($x2372 (not $x1362)))
(and $x2372 (or $x1362 (and (distinct ?x3920 ?x3920) true)))))))))
(check-sat)
; query 51: function crcu8, block 29, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x151 ((_ zero_extend 16) in27_16)))
(let ((?x3920 (bvor ?x151 (_ bv32768 32))))
(let ((?x4552 ((_ extract 15 0) ?x3920)))
(let (($x606 (or false false)))
(let (($x1362 (or $x606 false false)))
(let (($x2348 (or $x1362 false)))
(let (($x1278 (not $x2348)))
(and $x1278 (or $x2348 (and (distinct ?x4552 ?x4552) true)))))))))))
(check-sat)
; query 52: function crcu8, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x606 (or false false)))
(let (($x6 (not $x606)))
(and $x6 (or $x606 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 53: function crcu8, block 33, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x151 ((_ zero_extend 16) in27_16)))
(let ((?x452 (bvand ?x151 (_ bv32767 32))))
(let (($x606 (or false false)))
(let (($x1362 (or $x606 false false)))
(let (($x2372 (not $x1362)))
(and $x2372 (or $x1362 (and (distinct ?x452 ?x452) true)))))))))
(check-sat)
; query 54: function crcu8, block 33, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x151 ((_ zero_extend 16) in27_16)))
(let ((?x452 (bvand ?x151 (_ bv32767 32))))
(let ((?x8261 ((_ extract 15 0) ?x452)))
(let (($x606 (or false false)))
(let (($x1362 (or $x606 false false)))
(let (($x2348 (or $x1362 false)))
(let (($x1278 (not $x2348)))
(and $x1278 (or $x2348 (and (distinct ?x8261 ?x8261) true)))))))))))
(check-sat)
; query 55: function crcu8, block 38, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_8 () (_ BitVec 8))
(assert
 (let (($x1448 (or false false false)))
(let (($x126 (not $x1448)))
(and $x126 (or $x1448 (and (distinct (bvadd in.02_8 (_ bv1 8)) (bvadd in.02_8 (_ bv1 8))) true))))))
(check-sat)
; query 56: function crcu8, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x12 ((_ extract 7 0) in.01_16)))
(let ((?x725 ((_ zero_extend 24) ?x12)))
(let (($x606 (or false false)))
(let (($x2047 (or $x606 false)))
(and (not $x2047) (or $x2047 (and (distinct ?x725 ?x725) true))))))))
(check-sat)
; query 57: function crcu8, block 6, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x12 ((_ extract 7 0) in.01_16)))
(let ((?x725 ((_ zero_extend 24) ?x12)))
(let ((?x811 (bvand ?x725 (_ bv1 32))))
(let (($x606 (or false false)))
(let (($x2047 (or $x606 false)))
(let (($x958 (or $x2047 false false)))
(and (not $x958) (or $x958 (and (distinct ?x811 ?x811) true))))))))))
(check-sat)
; query 58: function crcu8, block 6, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x12 ((_ extract 7 0) in.01_16)))
(let ((?x725 ((_ zero_extend 24) ?x12)))
(let ((?x811 (bvand ?x725 (_ bv1 32))))
(let ((?x487 ((_ zero_extend 24) in.0_8)))
(let ((?x3985 (bvand ?x487 (_ bv1 32))))
(let ((?x8013 (bvxor ?x3985 ?x811)))
(let (($x606 (or false false)))
(let (($x2047 (or $x606 false)))
(let (($x958 (or $x2047 false false)))
(let (($x1362 (or $x606 false false)))
(let (($x636 (or $x1362 $x958 false)))
(and (not $x636) (or $x636 (and (distinct ?x8013 ?x8013) true)))))))))))))))
(check-sat)
; query 59: function crcu8, block 6, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x12 ((_ extract 7 0) in.01_16)))
(let ((?x725 ((_ zero_extend 24) ?x12)))
(let ((?x811 (bvand ?x725 (_ bv1 32))))
(let ((?x487 ((_ zero_extend 24) in.0_8)))
(let ((?x3985 (bvand ?x487 (_ bv1 32))))
(let ((?x8013 (bvxor ?x3985 ?x811)))
(let ((?x7989 ((_ extract 7 0) ?x8013)))
(let (($x606 (or false false)))
(let (($x2047 (or $x606 false)))
(let (($x958 (or $x2047 false false)))
(let (($x1362 (or $x606 false false)))
(let (($x636 (or $x1362 $x958 false)))
(let (($x2750 (or $x636 false)))
(and (not $x2750) (or $x2750 (and (distinct ?x7989 ?x7989) true)))))))))))))))))
(check-sat)
; query 60: function crcu8, block 6, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x606 (or false false)))
(let (($x6 (not $x606)))
(and $x6 (or $x606 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 61: function crcu8, block 6, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x487 ((_ zero_extend 24) in.0_8)))
(let ((?x8555 (bvashr ?x487 (_ bv1 32))))
(let (($x606 (or false false)))
(let (($x1362 (or $x606 false false)))
(let (($x8550 (or $x1362 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not $x8550) (or $x8550 (and (distinct ?x8555 ?x8555) true)))))))))
(check-sat)
; query 62: function crcu8, block 6, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x487 ((_ zero_extend 24) in.0_8)))
(let ((?x8555 (bvashr ?x487 (_ bv1 32))))
(let ((?x3222 ((_ extract 7 0) ?x8555)))
(let (($x606 (or false false)))
(let (($x1362 (or $x606 false false)))
(let (($x8550 (or $x1362 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x1982 (or $x8550 false)))
(and (not $x1982) (or $x1982 (and (distinct ?x3222 ?x3222) true)))))))))))
(check-sat)
; query 63: function crcu8, block 6, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x12 ((_ extract 7 0) in.01_16)))
(let ((?x725 ((_ zero_extend 24) ?x12)))
(let ((?x811 (bvand ?x725 (_ bv1 32))))
(let ((?x487 ((_ zero_extend 24) in.0_8)))
(let ((?x3985 (bvand ?x487 (_ bv1 32))))
(let ((?x8013 (bvxor ?x3985 ?x811)))
(let ((?x7989 ((_ extract 7 0) ?x8013)))
(let ((?x1160 ((_ zero_extend 24) ?x7989)))
(let (($x606 (or false false)))
(let (($x2047 (or $x606 false)))
(let (($x958 (or $x2047 false false)))
(let (($x1362 (or $x606 false false)))
(let (($x636 (or $x1362 $x958 false)))
(let (($x2750 (or $x636 false)))
(let (($x1899 (or $x2750 false)))
(and (not $x1899) (or $x1899 (and (distinct ?x1160 ?x1160) true)))))))))))))))))))
(check-sat)
; query 64: function crcu8, block 6, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x12 ((_ extract 7 0) in.01_16)))
(let ((?x725 ((_ zero_extend 24) ?x12)))
(let ((?x811 (bvand ?x725 (_ bv1 32))))
(let ((?x487 ((_ zero_extend 24) in.0_8)))
(let ((?x3985 (bvand ?x487 (_ bv1 32))))
(let ((?x8013 (bvxor ?x3985 ?x811)))
(let ((?x7989 ((_ extract 7 0) ?x8013)))
(let ((?x1160 ((_ zero_extend 24) ?x7989)))
(let ((?x2378 (ite (= (_ bv1 32) ?x1160) (_ bv1 1) (_ bv0 1))))
(let (($x606 (or false false)))
(let (($x2047 (or $x606 false)))
(let (($x958 (or $x2047 false false)))
(let (($x1362 (or $x606 false false)))
(let (($x636 (or $x1362 $x958 false)))
(let (($x2750 (or $x636 false)))
(let (($x1899 (or $x2750 false)))
(let (($x3631 (or $x1899 false false)))
(and (not $x3631) (or $x3631 (and (distinct ?x2378 ?x2378) true)))))))))))))))))))))
(check-sat)
; query 65: function crcu8, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x606 (or false false)))
(let (($x6 (not $x606)))
(and $x6 (or $x606 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 66: function crcu8, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x487 ((_ zero_extend 24) in.0_8)))
(let ((?x3985 (bvand ?x487 (_ bv1 32))))
(let (($x606 (or false false)))
(let (($x1362 (or $x606 false false)))
(let (($x2372 (not $x1362)))
(and $x2372 (or $x1362 (and (distinct ?x3985 ?x3985) true)))))))))
(check-sat)
; query 67: function crcu8, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x606 (or false false)))
(let (($x6 (not $x606)))
(and $x6 (or $x606 (and (distinct ((_ extract 7 0) in.01_16) ((_ extract 7 0) in.01_16)) true))))))
(check-sat)
; query 68: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x3082 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x8305 ((_ zero_extend 31) ?x3082)))
(let ((?x8299 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x3462 ((_ zero_extend 31) ?x8299)))
(let ((?x8293 (bvand ?x3462 ?x8305)))
(let ((?x4631 (ite (and (distinct (_ bv0 32) ?x8293) true) (_ bv1 1) (_ bv0 1))))
(let ((?x1670 ((_ zero_extend 63) ?x4631)))
(let (($x606 (or false false)))
(let (($x1362 (or $x606 false false)))
(let (($x2348 (or $x1362 false)))
(let (($x3032 (or $x2348 $x2348 false)))
(let (($x1334 (or $x3032 false false)))
(let (($x985 (or $x1334 false)))
(and (not $x985) (or $x985 (and (distinct ?x1670 ?x1670) true)))))))))))))))))
(check-sat)
; query 69: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x3082 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x8305 ((_ zero_extend 31) ?x3082)))
(let ((?x8299 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x3462 ((_ zero_extend 31) ?x8299)))
(let ((?x8293 (bvand ?x3462 ?x8305)))
(let ((?x4631 (ite (and (distinct (_ bv0 32) ?x8293) true) (_ bv1 1) (_ bv0 1))))
(let (($x507 (= (_ bv1 1) ?x4631)))
(let ((?x1205 (ite $x507 (_ bv1 32) (_ bv0 32))))
(let (($x606 (or false false)))
(let (($x1362 (or $x606 false false)))
(let (($x2348 (or $x1362 false)))
(let (($x3032 (or $x2348 $x2348 false)))
(let (($x1334 (or $x3032 false false)))
(let (($x1974 (or $x1334 (ite $x507 false false))))
(and (not $x1974) (or $x1974 (and (distinct ?x1205 ?x1205) true))))))))))))))))))
(check-sat)
; query 70: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x3082 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x8305 ((_ zero_extend 31) ?x3082)))
(let ((?x8299 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x3462 ((_ zero_extend 31) ?x8299)))
(let ((?x8293 (bvand ?x3462 ?x8305)))
(let ((?x4631 (ite (and (distinct (_ bv0 32) ?x8293) true) (_ bv1 1) (_ bv0 1))))
(let (($x507 (= (_ bv1 1) ?x4631)))
(let ((?x1205 (ite $x507 (_ bv1 32) (_ bv0 32))))
(let ((?x3015 ((_ extract 7 0) ?x1205)))
(let (($x606 (or false false)))
(let (($x1362 (or $x606 false false)))
(let (($x2348 (or $x1362 false)))
(let (($x3032 (or $x2348 $x2348 false)))
(let (($x1334 (or $x3032 false false)))
(let (($x1974 (or $x1334 (ite $x507 false false))))
(let (($x8287 (or $x1974 false)))
(and (not $x8287) (or $x8287 (and (distinct ?x3015 ?x3015) true))))))))))))))))))))
(check-sat)
; query 71: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x606 (or false false)))
(let (($x6 (not $x606)))
(and $x6 (or $x606 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 72: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x8299 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x606 (or false false)))
(let (($x1362 (or $x606 false false)))
(let (($x2372 (not $x1362)))
(and $x2372 (or $x1362 (and (distinct ?x8299 ?x8299) true))))))))
(check-sat)
; query 73: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x8299 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x3462 ((_ zero_extend 31) ?x8299)))
(let (($x606 (or false false)))
(let (($x1362 (or $x606 false false)))
(let (($x2348 (or $x1362 false)))
(let (($x1278 (not $x2348)))
(and $x1278 (or $x2348 (and (distinct ?x3462 ?x3462) true))))))))))
(check-sat)
; query 74: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x606 (or false false)))
(let (($x6 (not $x606)))
(and $x6 (or $x606 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 75: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x3082 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x606 (or false false)))
(let (($x1362 (or $x606 false false)))
(let (($x2372 (not $x1362)))
(and $x2372 (or $x1362 (and (distinct ?x3082 ?x3082) true))))))))
(check-sat)
; query 76: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x3082 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x8305 ((_ zero_extend 31) ?x3082)))
(let (($x606 (or false false)))
(let (($x1362 (or $x606 false false)))
(let (($x2348 (or $x1362 false)))
(let (($x1278 (not $x2348)))
(and $x1278 (or $x2348 (and (distinct ?x8305 ?x8305) true))))))))))
(check-sat)
; query 77: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x3082 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x8305 ((_ zero_extend 31) ?x3082)))
(let ((?x8299 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x3462 ((_ zero_extend 31) ?x8299)))
(let ((?x8293 (bvand ?x3462 ?x8305)))
(let (($x606 (or false false)))
(let (($x1362 (or $x606 false false)))
(let (($x2348 (or $x1362 false)))
(let (($x3032 (or $x2348 $x2348 false)))
(and (not $x3032) (or $x3032 (and (distinct ?x8293 ?x8293) true)))))))))))))
(check-sat)
; query 78: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x3082 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x8305 ((_ zero_extend 31) ?x3082)))
(let ((?x8299 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x3462 ((_ zero_extend 31) ?x8299)))
(let ((?x8293 (bvand ?x3462 ?x8305)))
(let ((?x4631 (ite (and (distinct (_ bv0 32) ?x8293) true) (_ bv1 1) (_ bv0 1))))
(let (($x606 (or false false)))
(let (($x1362 (or $x606 false false)))
(let (($x2348 (or $x1362 false)))
(let (($x3032 (or $x2348 $x2348 false)))
(let (($x1334 (or $x3032 false false)))
(and (not $x1334) (or $x1334 (and (distinct ?x4631 ?x4631) true)))))))))))))))
(check-sat)
; query 79: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x8645 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x1448 (or false false false)))
(let (($x126 (not $x1448)))
(and $x126 (or $x1448 (and (distinct ?x8645 ?x8645) true)))))))
(check-sat)
; query 80: function matrix_add_const, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1448 (or false false false)))
(let (($x126 (not $x1448)))
(and $x126 (or $x1448 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 81: function matrix_add_const, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x74 (bvadd in.01_32 (_ bv1 32))))
(let (($x361 (and (distinct ?x74 ?x74) true)))
(let (($x1448 (or false false false)))
(let (($x126 (not $x1448)))
(and $x126 (or $x1448 $x361)))))))
(check-sat)
; query 82: function matrix_mul_const, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1448 (or false false false)))
(let (($x126 (not $x1448)))
(and $x126 (or $x1448 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 83: function matrix_mul_const, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x74 (bvadd in.01_32 (_ bv1 32))))
(let (($x361 (and (distinct ?x74 ?x74) true)))
(let (($x1448 (or false false false)))
(let (($x126 (not $x1448)))
(and $x126 (or $x1448 $x361)))))))
(check-sat)
; query 84: function matrix_mul_matrix, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1448 (or false false false)))
(let (($x126 (not $x1448)))
(and $x126 (or $x1448 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 85: function matrix_mul_matrix, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x74 (bvadd in.01_32 (_ bv1 32))))
(let (($x361 (and (distinct ?x74 ?x74) true)))
(let (($x1448 (or false false false)))
(let (($x126 (not $x1448)))
(and $x126 (or $x1448 $x361)))))))
(check-sat)
; query 86: function matrix_mul_matrix, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x1448 (or false false false)))
(let (($x126 (not $x1448)))
(and $x126 (or $x1448 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 87: function matrix_mul_matrix_bitextract, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1448 (or false false false)))
(let (($x126 (not $x1448)))
(and $x126 (or $x1448 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 88: function matrix_mul_matrix_bitextract, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x74 (bvadd in.01_32 (_ bv1 32))))
(let (($x361 (and (distinct ?x74 ?x74) true)))
(let (($x1448 (or false false false)))
(let (($x126 (not $x1448)))
(and $x126 (or $x1448 $x361)))))))
(check-sat)
; query 89: function matrix_mul_matrix_bitextract, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x1448 (or false false false)))
(let (($x126 (not $x1448)))
(and $x126 (or $x1448 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 90: function matrix_mul_vect, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1448 (or false false false)))
(let (($x126 (not $x1448)))
(and $x126 (or $x1448 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 91: function matrix_mul_vect, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x74 (bvadd in.01_32 (_ bv1 32))))
(let (($x361 (and (distinct ?x74 ?x74) true)))
(let (($x1448 (or false false false)))
(let (($x126 (not $x1448)))
(and $x126 (or $x1448 $x361)))))))
(check-sat)
; query 92: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x606 (or false false)))
(let (($x6 (not $x606)))
(and $x6 (or $x606 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 93: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x8650 ((_ sign_extend 16) in.1_16)))
(let ((?x1455 (bvadd ?x8650 (_ bv10 32))))
(let (($x1424 (and (distinct (bvadd ((_ sign_extend 1) ?x8650) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x1455)) true)))
(let (($x606 (or false false)))
(let (($x1900 (or $x606 false (or $x1424))))
(and (not $x1900) (or $x1900 (and (distinct ?x1455 ?x1455) true)))))))))
(check-sat)
; query 94: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x8650 ((_ sign_extend 16) in.1_16)))
(let ((?x1455 (bvadd ?x8650 (_ bv10 32))))
(let ((?x8347 ((_ extract 15 0) ?x1455)))
(let (($x1424 (and (distinct (bvadd ((_ sign_extend 1) ?x8650) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x1455)) true)))
(let (($x606 (or false false)))
(let (($x1900 (or $x606 false (or $x1424))))
(let (($x8348 (or $x1900 false)))
(and (not $x8348) (or $x8348 (and (distinct ?x8347 ?x8347) true)))))))))))
(check-sat)
; query 95: function matrix_sum, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x9205 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x1448 (or false false false)))
(let (($x126 (not $x1448)))
(and $x126 (or $x1448 (and (distinct ?x9205 ?x9205) true)))))))
(check-sat)
; query 96: function matrix_sum, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x9205 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let ((?x1981 ((_ zero_extend 63) ?x9205)))
(let (($x1448 (or false false false)))
(let (($x970 (or $x1448 false)))
(and (not $x970) (or $x970 (and (distinct ?x1981 ?x1981) true))))))))
(check-sat)
; query 97: function matrix_sum, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x9205 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x9303 (= (_ bv1 1) ?x9205)))
(let ((?x9297 (ite $x9303 (_ bv1 32) (_ bv0 32))))
(let (($x1448 (or false false false)))
(let (($x8982 (or $x1448 (ite $x9303 false false))))
(and (not $x8982) (or $x8982 (and (distinct ?x9297 ?x9297) true)))))))))
(check-sat)
; query 98: function matrix_sum, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x606 (or false false)))
(let (($x6 (not $x606)))
(and $x6 (or $x606 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 99: function matrix_sum, block 22, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x9205 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x9303 (= (_ bv1 1) ?x9205)))
(let ((?x9297 (ite $x9303 (_ bv1 32) (_ bv0 32))))
(let ((?x8650 ((_ sign_extend 16) in.1_16)))
(let ((?x2408 (bvadd ?x8650 ?x9297)))
(let (($x3916 (and (distinct (bvadd ((_ sign_extend 1) ?x8650) ((_ sign_extend 1) ?x9297)) ((_ sign_extend 1) ?x2408)) true)))
(let (($x1448 (or false false false)))
(let (($x8982 (or $x1448 (ite $x9303 false false))))
(let (($x606 (or false false)))
(let (($x8676 (or $x606 $x8982 (or $x3916))))
(and (not $x8676) (or $x8676 (and (distinct ?x2408 ?x2408) true))))))))))))))
(check-sat)
; query 100: function matrix_sum, block 22, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x9205 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x9303 (= (_ bv1 1) ?x9205)))
(let ((?x9297 (ite $x9303 (_ bv1 32) (_ bv0 32))))
(let ((?x8650 ((_ sign_extend 16) in.1_16)))
(let ((?x2408 (bvadd ?x8650 ?x9297)))
(let ((?x8889 ((_ extract 15 0) ?x2408)))
(let (($x3916 (and (distinct (bvadd ((_ sign_extend 1) ?x8650) ((_ sign_extend 1) ?x9297)) ((_ sign_extend 1) ?x2408)) true)))
(let (($x1448 (or false false false)))
(let (($x8982 (or $x1448 (ite $x9303 false false))))
(let (($x606 (or false false)))
(let (($x8676 (or $x606 $x8982 (or $x3916))))
(let (($x8677 (or $x8676 false)))
(and (not $x8677) (or $x8677 (and (distinct ?x8889 ?x8889) true))))))))))))))))
(check-sat)
; query 101: function matrix_sum, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1448 (or false false false)))
(let (($x126 (not $x1448)))
(and $x126 (or $x1448 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 102: function matrix_sum, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x74 (bvadd in.01_32 (_ bv1 32))))
(let (($x361 (and (distinct ?x74 ?x74) true)))
(let (($x1448 (or false false false)))
(let (($x126 (not $x1448)))
(and $x126 (or $x1448 $x361)))))))
(check-sat)
; query 103: function parseval, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.23_32 () (_ BitVec 32))
(assert
 (let (($x8954 (and (distinct (bvmul ((_ sign_extend 32) in.23_32) ((_ sign_extend 32) (_ bv1024 32))) ((_ sign_extend 32) (bvmul in.23_32 (_ bv1024 32)))) true)))
(let (($x9517 (or false false (or $x8954))))
(and (not $x9517) (or $x9517 (and (distinct (bvmul in.23_32 (_ bv1024 32)) (bvmul in.23_32 (_ bv1024 32))) true))))))
(check-sat)
; query 104: function parseval, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.34_32 () (_ BitVec 32))
(assert
 (let (($x3649 (and (distinct (bvmul ((_ sign_extend 32) in.34_32) ((_ sign_extend 32) (_ bv1048576 32))) ((_ sign_extend 32) (bvmul in.34_32 (_ bv1048576 32)))) true)))
(let (($x9972 (or false false (or $x3649))))
(and (not $x9972) (or $x9972 (and (distinct (bvmul in.34_32 (_ bv1048576 32)) (bvmul in.34_32 (_ bv1048576 32))) true))))))
(check-sat)
; query 105: function partition_memory, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1448 (or false false false)))
(let (($x126 (not $x1448)))
(and $x126 (or $x1448 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 106: function run_matrix_multiply, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x1448 (or false false false)))
(let (($x126 (not $x1448)))
(and $x126 (or $x1448 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 107: function run_matrix_multiply, block 34, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x74 (bvadd in.01_32 (_ bv1 32))))
(let (($x361 (and (distinct ?x74 ?x74) true)))
(let (($x1448 (or false false false)))
(let (($x126 (not $x1448)))
(and $x126 (or $x1448 $x361)))))))
(check-sat)
