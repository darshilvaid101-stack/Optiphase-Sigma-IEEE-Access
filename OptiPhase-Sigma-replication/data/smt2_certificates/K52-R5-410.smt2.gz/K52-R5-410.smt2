; OptiPhase-Sigma refinement certificate for sweep K52-R5-410
; query 0: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x710 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x207 (or false false false)))
(let (($x337 (not $x207)))
(and $x337 (or $x207 (and (distinct ?x710 ?x710) true)))))))
(check-sat)
; query 1: function s162, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x478 (ite (bvslt (_ bv0 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x207 (or false false false)))
(let (($x337 (not $x207)))
(and $x337 (or $x207 (and (distinct ?x478 ?x478) true)))))))
(check-sat)
; query 2: function set1d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x1111 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x207 (or false false false)))
(let (($x337 (not $x207)))
(and $x337 (or $x207 (and (distinct ?x1111 ?x1111) true)))))))
(check-sat)
; query 3: function set1ds, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x291 (ite (= (_ bv4294967295 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x207 (or false false false)))
(let (($x337 (not $x207)))
(and $x337 (or $x207 (and (distinct ?x291 ?x291) true)))))))
(check-sat)
; query 4: function set2d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x1111 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x207 (or false false false)))
(let (($x337 (not $x207)))
(and $x337 (or $x207 (and (distinct ?x1111 ?x1111) true)))))))
(check-sat)
