; OptiPhase-Sigma refinement certificate for sweep K58-R2-078
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x586 (or false false)))
(let (($x28 (not $x586)))
(and $x28 (or $x586 (and (distinct ((_ sign_extend 16) in25_16) ((_ sign_extend 16) in25_16)) true))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let ((?x1549 (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))))
(let (($x586 (or false false)))
(let (($x109 (or $x586 false false)))
(let (($x79 (not $x109)))
(and $x79 (or $x109 (and (distinct ?x1549 ?x1549) true))))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x586 (or false false)))
(let (($x28 (not $x586)))
(and $x28 (or $x586 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x297 ((_ sign_extend 16) in3_16)))
(let ((?x63 (bvand ?x297 (_ bv127 32))))
(let (($x586 (or false false)))
(let (($x109 (or $x586 false false)))
(let (($x79 (not $x109)))
(and $x79 (or $x109 (and (distinct ?x63 ?x63) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x297 ((_ sign_extend 16) in3_16)))
(let ((?x63 (bvand ?x297 (_ bv127 32))))
(let ((?x1575 ((_ extract 15 0) ?x63)))
(let (($x586 (or false false)))
(let (($x109 (or $x586 false false)))
(let (($x362 (or $x109 false)))
(let (($x197 (not $x362)))
(and $x197 (or $x362 (and (distinct ?x1575 ?x1575) true)))))))))))
(check-sat)
; query 5: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x586 (or false false)))
(let (($x28 (not $x586)))
(and $x28 (or $x586 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 6: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x657 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x586 (or false false)))
(let (($x109 (or $x586 false false)))
(let (($x79 (not $x109)))
(and $x79 (or $x109 (and (distinct ?x657 ?x657) true))))))))
(check-sat)
; query 7: function core_bench_list, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x88 (or false false false)))
(let (($x100 (not $x88)))
(and $x100 (or $x88 (and (distinct (bvadd in.0_16 (_ bv1 16)) (bvadd in.0_16 (_ bv1 16))) true))))))
(check-sat)
; query 8: function core_bench_state, block 105, name %106
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x88 (or false false false)))
(let (($x100 (not $x88)))
(and $x100 (or $x88 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 9: function core_bench_state, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x88 (or false false false)))
(let (($x100 (not $x88)))
(and $x100 (or $x88 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 10: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x98 (bvadd in.01_32 (_ bv1 32))))
(let (($x1042 (and (distinct ?x98 ?x98) true)))
(let (($x88 (or false false false)))
(let (($x100 (not $x88)))
(and $x100 (or $x88 $x1042)))))))
(check-sat)
; query 11: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x98 (bvadd in.01_32 (_ bv1 32))))
(let ((?x86 (bvmul ?x98 ?x98)))
(let (($x88 (or false false false)))
(let (($x132 (or $x88 $x88 false)))
(and (not $x132) (or $x132 (and (distinct ?x86 ?x86) true))))))))
(check-sat)
; query 12: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x98 (bvadd in.01_32 (_ bv1 32))))
(let ((?x86 (bvmul ?x98 ?x98)))
(let ((?x12 (bvmul ?x86 (_ bv2 32))))
(let (($x88 (or false false false)))
(let (($x132 (or $x88 $x88 false)))
(let (($x83 (or $x132 false false)))
(and (not $x83) (or $x83 (and (distinct ?x12 ?x12) true))))))))))
(check-sat)
; query 13: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x98 (bvadd in.01_32 (_ bv1 32))))
(let ((?x86 (bvmul ?x98 ?x98)))
(let ((?x12 (bvmul ?x86 (_ bv2 32))))
(let ((?x156 (bvmul ?x12 (_ bv4 32))))
(let (($x88 (or false false false)))
(let (($x132 (or $x88 $x88 false)))
(let (($x83 (or $x132 false false)))
(let (($x21 (or $x83 false false)))
(and (not $x21) (or $x21 (and (distinct ?x156 ?x156) true))))))))))))
(check-sat)
; query 14: function core_init_matrix, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x88 (or false false false)))
(let (($x100 (not $x88)))
(and $x100 (or $x88 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 15: function core_init_matrix, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x88 (or false false false)))
(let (($x100 (not $x88)))
(and $x100 (or $x88 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 16: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x99 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x88 (or false false false)))
(let (($x100 (not $x88)))
(and $x100 (or $x88 (and (distinct ?x99 ?x99) true)))))))
(check-sat)
; query 17: function core_init_state, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_32 () (_ BitVec 32))
(assert
 (let (($x88 (or false false false)))
(let (($x100 (not $x88)))
(and $x100 (or $x88 (and (distinct (bvadd in.06_32 (_ bv1 32)) (bvadd in.06_32 (_ bv1 32))) true))))))
(check-sat)
; query 18: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x258 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x88 (or false false false)))
(let (($x100 (not $x88)))
(and $x100 (or $x88 (and (distinct ?x258 ?x258) true)))))))
(check-sat)
; query 19: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x88 (or false false false)))
(let (($x100 (not $x88)))
(and $x100 (or $x88 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 20: function core_list_init, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x98 (bvadd in.01_32 (_ bv1 32))))
(let (($x1042 (and (distinct ?x98 ?x98) true)))
(let (($x88 (or false false false)))
(let (($x100 (not $x88)))
(and $x100 (or $x88 $x1042)))))))
(check-sat)
; query 21: function core_list_mergesort, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x98 (bvadd in.01_32 (_ bv1 32))))
(let (($x1042 (and (distinct ?x98 ?x98) true)))
(let (($x1091 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x98)) true)))
(let (($x401 (or false false (or $x1091))))
(and (not $x401) (or $x401 $x1042)))))))
(check-sat)
; query 22: function core_list_mergesort, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x97 (ite (bvslt (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x88 (or false false false)))
(let (($x100 (not $x88)))
(and $x100 (or $x88 (and (distinct ?x97 ?x97) true)))))))
(check-sat)
; query 23: function core_list_mergesort, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.224_32 () (_ BitVec 32))
(assert
 (let ((?x424 (ite (= (_ bv0 32) in.224_32) (_ bv1 1) (_ bv0 1))))
(let (($x88 (or false false false)))
(let (($x100 (not $x88)))
(and $x100 (or $x88 (and (distinct ?x424 ?x424) true)))))))
(check-sat)
; query 24: function core_list_mergesort, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x1538 (ite (= (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x88 (or false false false)))
(let (($x100 (not $x88)))
(and $x100 (or $x88 (and (distinct ?x1538 ?x1538) true)))))))
(check-sat)
; query 25: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x2008 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x8216 (or false false (or $x2008))))
(and (not $x8216) (or $x8216 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 26: function core_list_mergesort, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x5517 (and (distinct (bvmul ((_ sign_extend 32) in.020_32) ((_ sign_extend 32) (_ bv2 32))) ((_ sign_extend 32) (bvmul in.020_32 (_ bv2 32)))) true)))
(let (($x8203 (or false false (or $x5517))))
(and (not $x8203) (or $x8203 (and (distinct (bvmul in.020_32 (_ bv2 32)) (bvmul in.020_32 (_ bv2 32))) true))))))
(check-sat)
; query 27: function core_state_transition, block 102, name %103
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x586 (or false false)))
(let (($x28 (not $x586)))
(and $x28 (or $x586 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 28: function core_state_transition, block 102, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x8196 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x586 (or false false)))
(let (($x109 (or $x586 false false)))
(let (($x79 (not $x109)))
(and $x79 (or $x109 (and (distinct ?x8196 ?x8196) true))))))))
(check-sat)
; query 29: function core_state_transition, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x586 (or false false)))
(let (($x28 (not $x586)))
(and $x28 (or $x586 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 30: function core_state_transition, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x8189 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x586 (or false false)))
(let (($x109 (or $x586 false false)))
(let (($x79 (not $x109)))
(and $x79 (or $x109 (and (distinct ?x8189 ?x8189) true))))))))
(check-sat)
; query 31: function core_state_transition, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x586 (or false false)))
(let (($x28 (not $x586)))
(and $x28 (or $x586 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 32: function core_state_transition, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x8196 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x586 (or false false)))
(let (($x109 (or $x586 false false)))
(let (($x79 (not $x109)))
(and $x79 (or $x109 (and (distinct ?x8196 ?x8196) true))))))))
(check-sat)
; query 33: function core_state_transition, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x586 (or false false)))
(let (($x28 (not $x586)))
(and $x28 (or $x586 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 34: function core_state_transition, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x4157 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x586 (or false false)))
(let (($x109 (or $x586 false false)))
(let (($x79 (not $x109)))
(and $x79 (or $x109 (and (distinct ?x4157 ?x4157) true))))))))
(check-sat)
; query 35: function core_state_transition, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x586 (or false false)))
(let (($x28 (not $x586)))
(and $x28 (or $x586 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 36: function core_state_transition, block 51, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x4157 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x586 (or false false)))
(let (($x109 (or $x586 false false)))
(let (($x79 (not $x109)))
(and $x79 (or $x109 (and (distinct ?x4157 ?x4157) true))))))))
(check-sat)
; query 37: function core_state_transition, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x586 (or false false)))
(let (($x28 (not $x586)))
(and $x28 (or $x586 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 38: function core_state_transition, block 64, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x4157 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x586 (or false false)))
(let (($x109 (or $x586 false false)))
(let (($x79 (not $x109)))
(and $x79 (or $x109 (and (distinct ?x4157 ?x4157) true))))))))
(check-sat)
; query 39: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x1211 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x88 (or false false false)))
(let (($x100 (not $x88)))
(and $x100 (or $x88 (and (distinct ?x1211 ?x1211) true)))))))
(check-sat)
; query 40: function core_state_transition, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x586 (or false false)))
(let (($x28 (not $x586)))
(and $x28 (or $x586 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 41: function core_state_transition, block 80, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x8176 (ite (= (_ bv69 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x586 (or false false)))
(let (($x109 (or $x586 false false)))
(let (($x79 (not $x109)))
(and $x79 (or $x109 (and (distinct ?x8176 ?x8176) true))))))))
(check-sat)
; query 42: function core_state_transition, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x586 (or false false)))
(let (($x28 (not $x586)))
(and $x28 (or $x586 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 43: function core_state_transition, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x8168 (ite (= (_ bv101 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x586 (or false false)))
(let (($x109 (or $x586 false false)))
(let (($x79 (not $x109)))
(and $x79 (or $x109 (and (distinct ?x8168 ?x8168) true))))))))
(check-sat)
; query 44: function core_state_transition, block 99, name %100
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x586 (or false false)))
(let (($x28 (not $x586)))
(and $x28 (or $x586 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 45: function core_state_transition, block 99, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x8189 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x586 (or false false)))
(let (($x109 (or $x586 false false)))
(let (($x79 (not $x109)))
(and $x79 (or $x109 (and (distinct ?x8189 ?x8189) true))))))))
(check-sat)
; query 46: function crcu8, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x586 (or false false)))
(let (($x28 (not $x586)))
(and $x28 (or $x586 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 47: function crcu8, block 19, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x344 ((_ zero_extend 16) in.01_16)))
(let ((?x8161 (bvxor ?x344 (_ bv16386 32))))
(let (($x586 (or false false)))
(let (($x109 (or $x586 false false)))
(let (($x79 (not $x109)))
(and $x79 (or $x109 (and (distinct ?x8161 ?x8161) true)))))))))
(check-sat)
; query 48: function crcu8, block 19, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x344 ((_ zero_extend 16) in.01_16)))
(let ((?x8161 (bvxor ?x344 (_ bv16386 32))))
(let ((?x8162 ((_ extract 15 0) ?x8161)))
(let (($x586 (or false false)))
(let (($x109 (or $x586 false false)))
(let (($x362 (or $x109 false)))
(let (($x197 (not $x362)))
(and $x197 (or $x362 (and (distinct ?x8162 ?x8162) true)))))))))))
(check-sat)
; query 49: function crcu8, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x586 (or false false)))
(let (($x28 (not $x586)))
(and $x28 (or $x586 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 50: function crcu8, block 29, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1886 ((_ zero_extend 16) in27_16)))
(let ((?x821 (bvor ?x1886 (_ bv32768 32))))
(let (($x586 (or false false)))
(let (($x109 (or $x586 false false)))
(let (($x79 (not $x109)))
(and $x79 (or $x109 (and (distinct ?x821 ?x821) true)))))))))
(check-sat)
; query 51: function crcu8, block 29, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1886 ((_ zero_extend 16) in27_16)))
(let ((?x821 (bvor ?x1886 (_ bv32768 32))))
(let ((?x759 ((_ extract 15 0) ?x821)))
(let (($x586 (or false false)))
(let (($x109 (or $x586 false false)))
(let (($x362 (or $x109 false)))
(let (($x197 (not $x362)))
(and $x197 (or $x362 (and (distinct ?x759 ?x759) true)))))))))))
(check-sat)
; query 52: function crcu8, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x586 (or false false)))
(let (($x28 (not $x586)))
(and $x28 (or $x586 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 53: function crcu8, block 33, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1886 ((_ zero_extend 16) in27_16)))
(let ((?x8143 (bvand ?x1886 (_ bv32767 32))))
(let (($x586 (or false false)))
(let (($x109 (or $x586 false false)))
(let (($x79 (not $x109)))
(and $x79 (or $x109 (and (distinct ?x8143 ?x8143) true)))))))))
(check-sat)
; query 54: function crcu8, block 33, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1886 ((_ zero_extend 16) in27_16)))
(let ((?x8143 (bvand ?x1886 (_ bv32767 32))))
(let ((?x8144 ((_ extract 15 0) ?x8143)))
(let (($x586 (or false false)))
(let (($x109 (or $x586 false false)))
(let (($x362 (or $x109 false)))
(let (($x197 (not $x362)))
(and $x197 (or $x362 (and (distinct ?x8144 ?x8144) true)))))))))))
(check-sat)
; query 55: function crcu8, block 38, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_8 () (_ BitVec 8))
(assert
 (let (($x88 (or false false false)))
(let (($x100 (not $x88)))
(and $x100 (or $x88 (and (distinct (bvadd in.02_8 (_ bv1 8)) (bvadd in.02_8 (_ bv1 8))) true))))))
(check-sat)
; query 56: function crcu8, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x8132 ((_ extract 7 0) in.01_16)))
(let ((?x8129 ((_ zero_extend 24) ?x8132)))
(let (($x586 (or false false)))
(let (($x8130 (or $x586 false)))
(and (not $x8130) (or $x8130 (and (distinct ?x8129 ?x8129) true))))))))
(check-sat)
; query 57: function crcu8, block 6, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x8132 ((_ extract 7 0) in.01_16)))
(let ((?x8129 ((_ zero_extend 24) ?x8132)))
(let ((?x8153 (bvand ?x8129 (_ bv1 32))))
(let (($x586 (or false false)))
(let (($x8130 (or $x586 false)))
(let (($x8135 (or $x8130 false false)))
(and (not $x8135) (or $x8135 (and (distinct ?x8153 ?x8153) true))))))))))
(check-sat)
; query 58: function crcu8, block 6, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x8132 ((_ extract 7 0) in.01_16)))
(let ((?x8129 ((_ zero_extend 24) ?x8132)))
(let ((?x8153 (bvand ?x8129 (_ bv1 32))))
(let ((?x1372 ((_ zero_extend 24) in.0_8)))
(let ((?x8131 (bvand ?x1372 (_ bv1 32))))
(let ((?x8157 (bvxor ?x8131 ?x8153)))
(let (($x586 (or false false)))
(let (($x8130 (or $x586 false)))
(let (($x8135 (or $x8130 false false)))
(let (($x109 (or $x586 false false)))
(let (($x8156 (or $x109 $x8135 false)))
(and (not $x8156) (or $x8156 (and (distinct ?x8157 ?x8157) true)))))))))))))))
(check-sat)
; query 59: function crcu8, block 6, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x8132 ((_ extract 7 0) in.01_16)))
(let ((?x8129 ((_ zero_extend 24) ?x8132)))
(let ((?x8153 (bvand ?x8129 (_ bv1 32))))
(let ((?x1372 ((_ zero_extend 24) in.0_8)))
(let ((?x8131 (bvand ?x1372 (_ bv1 32))))
(let ((?x8157 (bvxor ?x8131 ?x8153)))
(let ((?x3659 ((_ extract 7 0) ?x8157)))
(let (($x586 (or false false)))
(let (($x8130 (or $x586 false)))
(let (($x8135 (or $x8130 false false)))
(let (($x109 (or $x586 false false)))
(let (($x8156 (or $x109 $x8135 false)))
(let (($x5406 (or $x8156 false)))
(and (not $x5406) (or $x5406 (and (distinct ?x3659 ?x3659) true)))))))))))))))))
(check-sat)
; query 60: function crcu8, block 6, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x586 (or false false)))
(let (($x28 (not $x586)))
(and $x28 (or $x586 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 61: function crcu8, block 6, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1372 ((_ zero_extend 24) in.0_8)))
(let ((?x6995 (bvashr ?x1372 (_ bv1 32))))
(let (($x586 (or false false)))
(let (($x109 (or $x586 false false)))
(let (($x876 (or $x109 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not $x876) (or $x876 (and (distinct ?x6995 ?x6995) true)))))))))
(check-sat)
; query 62: function crcu8, block 6, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1372 ((_ zero_extend 24) in.0_8)))
(let ((?x6995 (bvashr ?x1372 (_ bv1 32))))
(let ((?x4933 ((_ extract 7 0) ?x6995)))
(let (($x586 (or false false)))
(let (($x109 (or $x586 false false)))
(let (($x876 (or $x109 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x2483 (or $x876 false)))
(and (not $x2483) (or $x2483 (and (distinct ?x4933 ?x4933) true)))))))))))
(check-sat)
; query 63: function crcu8, block 6, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x8132 ((_ extract 7 0) in.01_16)))
(let ((?x8129 ((_ zero_extend 24) ?x8132)))
(let ((?x8153 (bvand ?x8129 (_ bv1 32))))
(let ((?x1372 ((_ zero_extend 24) in.0_8)))
(let ((?x8131 (bvand ?x1372 (_ bv1 32))))
(let ((?x8157 (bvxor ?x8131 ?x8153)))
(let ((?x3659 ((_ extract 7 0) ?x8157)))
(let ((?x4970 ((_ zero_extend 24) ?x3659)))
(let (($x586 (or false false)))
(let (($x8130 (or $x586 false)))
(let (($x8135 (or $x8130 false false)))
(let (($x109 (or $x586 false false)))
(let (($x8156 (or $x109 $x8135 false)))
(let (($x5406 (or $x8156 false)))
(let (($x4563 (or $x5406 false)))
(and (not $x4563) (or $x4563 (and (distinct ?x4970 ?x4970) true)))))))))))))))))))
(check-sat)
; query 64: function crcu8, block 6, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x8132 ((_ extract 7 0) in.01_16)))
(let ((?x8129 ((_ zero_extend 24) ?x8132)))
(let ((?x8153 (bvand ?x8129 (_ bv1 32))))
(let ((?x1372 ((_ zero_extend 24) in.0_8)))
(let ((?x8131 (bvand ?x1372 (_ bv1 32))))
(let ((?x8157 (bvxor ?x8131 ?x8153)))
(let ((?x3659 ((_ extract 7 0) ?x8157)))
(let ((?x4970 ((_ zero_extend 24) ?x3659)))
(let ((?x2618 (ite (= (_ bv1 32) ?x4970) (_ bv1 1) (_ bv0 1))))
(let (($x586 (or false false)))
(let (($x8130 (or $x586 false)))
(let (($x8135 (or $x8130 false false)))
(let (($x109 (or $x586 false false)))
(let (($x8156 (or $x109 $x8135 false)))
(let (($x5406 (or $x8156 false)))
(let (($x4563 (or $x5406 false)))
(let (($x61 (or $x4563 false false)))
(and (not $x61) (or $x61 (and (distinct ?x2618 ?x2618) true)))))))))))))))))))))
(check-sat)
; query 65: function crcu8, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x586 (or false false)))
(let (($x28 (not $x586)))
(and $x28 (or $x586 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 66: function crcu8, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1372 ((_ zero_extend 24) in.0_8)))
(let ((?x8131 (bvand ?x1372 (_ bv1 32))))
(let (($x586 (or false false)))
(let (($x109 (or $x586 false false)))
(let (($x79 (not $x109)))
(and $x79 (or $x109 (and (distinct ?x8131 ?x8131) true)))))))))
(check-sat)
; query 67: function crcu8, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x586 (or false false)))
(let (($x28 (not $x586)))
(and $x28 (or $x586 (and (distinct ((_ extract 7 0) in.01_16) ((_ extract 7 0) in.01_16)) true))))))
(check-sat)
; query 68: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x8116 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x4650 ((_ zero_extend 31) ?x8116)))
(let ((?x3588 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x4580 ((_ zero_extend 31) ?x3588)))
(let ((?x6031 (bvand ?x4580 ?x4650)))
(let ((?x8113 (ite (and (distinct (_ bv0 32) ?x6031) true) (_ bv1 1) (_ bv0 1))))
(let ((?x8114 ((_ zero_extend 63) ?x8113)))
(let (($x586 (or false false)))
(let (($x109 (or $x586 false false)))
(let (($x362 (or $x109 false)))
(let (($x3645 (or $x362 $x362 false)))
(let (($x8110 (or $x3645 false false)))
(let (($x8111 (or $x8110 false)))
(and (not $x8111) (or $x8111 (and (distinct ?x8114 ?x8114) true)))))))))))))))))
(check-sat)
; query 69: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x8116 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x4650 ((_ zero_extend 31) ?x8116)))
(let ((?x3588 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x4580 ((_ zero_extend 31) ?x3588)))
(let ((?x6031 (bvand ?x4580 ?x4650)))
(let ((?x8113 (ite (and (distinct (_ bv0 32) ?x6031) true) (_ bv1 1) (_ bv0 1))))
(let (($x8112 (= (_ bv1 1) ?x8113)))
(let ((?x8117 (ite $x8112 (_ bv1 32) (_ bv0 32))))
(let (($x586 (or false false)))
(let (($x109 (or $x586 false false)))
(let (($x362 (or $x109 false)))
(let (($x3645 (or $x362 $x362 false)))
(let (($x8110 (or $x3645 false false)))
(let (($x8163 (or $x8110 (ite $x8112 false false))))
(and (not $x8163) (or $x8163 (and (distinct ?x8117 ?x8117) true))))))))))))))))))
(check-sat)
; query 70: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x8116 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x4650 ((_ zero_extend 31) ?x8116)))
(let ((?x3588 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x4580 ((_ zero_extend 31) ?x3588)))
(let ((?x6031 (bvand ?x4580 ?x4650)))
(let ((?x8113 (ite (and (distinct (_ bv0 32) ?x6031) true) (_ bv1 1) (_ bv0 1))))
(let (($x8112 (= (_ bv1 1) ?x8113)))
(let ((?x8117 (ite $x8112 (_ bv1 32) (_ bv0 32))))
(let ((?x8164 ((_ extract 7 0) ?x8117)))
(let (($x586 (or false false)))
(let (($x109 (or $x586 false false)))
(let (($x362 (or $x109 false)))
(let (($x3645 (or $x362 $x362 false)))
(let (($x8110 (or $x3645 false false)))
(let (($x8163 (or $x8110 (ite $x8112 false false))))
(let (($x4352 (or $x8163 false)))
(and (not $x4352) (or $x4352 (and (distinct ?x8164 ?x8164) true))))))))))))))))))))
(check-sat)
; query 71: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x586 (or false false)))
(let (($x28 (not $x586)))
(and $x28 (or $x586 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 72: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x3588 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x586 (or false false)))
(let (($x109 (or $x586 false false)))
(let (($x79 (not $x109)))
(and $x79 (or $x109 (and (distinct ?x3588 ?x3588) true))))))))
(check-sat)
; query 73: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x3588 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x4580 ((_ zero_extend 31) ?x3588)))
(let (($x586 (or false false)))
(let (($x109 (or $x586 false false)))
(let (($x362 (or $x109 false)))
(let (($x197 (not $x362)))
(and $x197 (or $x362 (and (distinct ?x4580 ?x4580) true))))))))))
(check-sat)
; query 74: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x586 (or false false)))
(let (($x28 (not $x586)))
(and $x28 (or $x586 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 75: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x8116 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x586 (or false false)))
(let (($x109 (or $x586 false false)))
(let (($x79 (not $x109)))
(and $x79 (or $x109 (and (distinct ?x8116 ?x8116) true))))))))
(check-sat)
; query 76: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x8116 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x4650 ((_ zero_extend 31) ?x8116)))
(let (($x586 (or false false)))
(let (($x109 (or $x586 false false)))
(let (($x362 (or $x109 false)))
(let (($x197 (not $x362)))
(and $x197 (or $x362 (and (distinct ?x4650 ?x4650) true))))))))))
(check-sat)
; query 77: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x8116 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x4650 ((_ zero_extend 31) ?x8116)))
(let ((?x3588 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x4580 ((_ zero_extend 31) ?x3588)))
(let ((?x6031 (bvand ?x4580 ?x4650)))
(let (($x586 (or false false)))
(let (($x109 (or $x586 false false)))
(let (($x362 (or $x109 false)))
(let (($x3645 (or $x362 $x362 false)))
(and (not $x3645) (or $x3645 (and (distinct ?x6031 ?x6031) true)))))))))))))
(check-sat)
; query 78: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x8116 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x4650 ((_ zero_extend 31) ?x8116)))
(let ((?x3588 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x4580 ((_ zero_extend 31) ?x3588)))
(let ((?x6031 (bvand ?x4580 ?x4650)))
(let ((?x8113 (ite (and (distinct (_ bv0 32) ?x6031) true) (_ bv1 1) (_ bv0 1))))
(let (($x586 (or false false)))
(let (($x109 (or $x586 false false)))
(let (($x362 (or $x109 false)))
(let (($x3645 (or $x362 $x362 false)))
(let (($x8110 (or $x3645 false false)))
(and (not $x8110) (or $x8110 (and (distinct ?x8113 ?x8113) true)))))))))))))))
(check-sat)
; query 79: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x5369 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x88 (or false false false)))
(let (($x100 (not $x88)))
(and $x100 (or $x88 (and (distinct ?x5369 ?x5369) true)))))))
(check-sat)
; query 80: function matrix_add_const, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x88 (or false false false)))
(let (($x100 (not $x88)))
(and $x100 (or $x88 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 81: function matrix_add_const, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x98 (bvadd in.01_32 (_ bv1 32))))
(let (($x1042 (and (distinct ?x98 ?x98) true)))
(let (($x88 (or false false false)))
(let (($x100 (not $x88)))
(and $x100 (or $x88 $x1042)))))))
(check-sat)
; query 82: function matrix_mul_const, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x88 (or false false false)))
(let (($x100 (not $x88)))
(and $x100 (or $x88 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 83: function matrix_mul_const, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x98 (bvadd in.01_32 (_ bv1 32))))
(let (($x1042 (and (distinct ?x98 ?x98) true)))
(let (($x88 (or false false false)))
(let (($x100 (not $x88)))
(and $x100 (or $x88 $x1042)))))))
(check-sat)
; query 84: function matrix_mul_matrix, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x88 (or false false false)))
(let (($x100 (not $x88)))
(and $x100 (or $x88 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 85: function matrix_mul_matrix, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x98 (bvadd in.01_32 (_ bv1 32))))
(let (($x1042 (and (distinct ?x98 ?x98) true)))
(let (($x88 (or false false false)))
(let (($x100 (not $x88)))
(and $x100 (or $x88 $x1042)))))))
(check-sat)
; query 86: function matrix_mul_matrix, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x88 (or false false false)))
(let (($x100 (not $x88)))
(and $x100 (or $x88 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 87: function matrix_mul_matrix_bitextract, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x88 (or false false false)))
(let (($x100 (not $x88)))
(and $x100 (or $x88 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 88: function matrix_mul_matrix_bitextract, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x98 (bvadd in.01_32 (_ bv1 32))))
(let (($x1042 (and (distinct ?x98 ?x98) true)))
(let (($x88 (or false false false)))
(let (($x100 (not $x88)))
(and $x100 (or $x88 $x1042)))))))
(check-sat)
; query 89: function matrix_mul_matrix_bitextract, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x88 (or false false false)))
(let (($x100 (not $x88)))
(and $x100 (or $x88 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 90: function matrix_mul_vect, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x88 (or false false false)))
(let (($x100 (not $x88)))
(and $x100 (or $x88 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 91: function matrix_mul_vect, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x98 (bvadd in.01_32 (_ bv1 32))))
(let (($x1042 (and (distinct ?x98 ?x98) true)))
(let (($x88 (or false false false)))
(let (($x100 (not $x88)))
(and $x100 (or $x88 $x1042)))))))
(check-sat)
; query 92: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x586 (or false false)))
(let (($x28 (not $x586)))
(and $x28 (or $x586 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 93: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x8107 ((_ sign_extend 16) in.1_16)))
(let ((?x8104 (bvadd ?x8107 (_ bv10 32))))
(let (($x8102 (and (distinct (bvadd ((_ sign_extend 1) ?x8107) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x8104)) true)))
(let (($x586 (or false false)))
(let (($x8108 (or $x586 false (or $x8102))))
(and (not $x8108) (or $x8108 (and (distinct ?x8104 ?x8104) true)))))))))
(check-sat)
; query 94: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x8107 ((_ sign_extend 16) in.1_16)))
(let ((?x8104 (bvadd ?x8107 (_ bv10 32))))
(let ((?x8165 ((_ extract 15 0) ?x8104)))
(let (($x8102 (and (distinct (bvadd ((_ sign_extend 1) ?x8107) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x8104)) true)))
(let (($x586 (or false false)))
(let (($x8108 (or $x586 false (or $x8102))))
(let (($x8100 (or $x8108 false)))
(and (not $x8100) (or $x8100 (and (distinct ?x8165 ?x8165) true)))))))))))
(check-sat)
; query 95: function matrix_sum, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x4338 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x88 (or false false false)))
(let (($x100 (not $x88)))
(and $x100 (or $x88 (and (distinct ?x4338 ?x4338) true)))))))
(check-sat)
; query 96: function matrix_sum, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x4338 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let ((?x5999 ((_ zero_extend 63) ?x4338)))
(let (($x88 (or false false false)))
(let (($x1339 (or $x88 false)))
(and (not $x1339) (or $x1339 (and (distinct ?x5999 ?x5999) true))))))))
(check-sat)
; query 97: function matrix_sum, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x4338 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x5309 (= (_ bv1 1) ?x4338)))
(let ((?x527 (ite $x5309 (_ bv1 32) (_ bv0 32))))
(let (($x88 (or false false false)))
(let (($x1696 (or $x88 (ite $x5309 false false))))
(and (not $x1696) (or $x1696 (and (distinct ?x527 ?x527) true)))))))))
(check-sat)
; query 98: function matrix_sum, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x586 (or false false)))
(let (($x28 (not $x586)))
(and $x28 (or $x586 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 99: function matrix_sum, block 22, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x4338 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x5309 (= (_ bv1 1) ?x4338)))
(let ((?x527 (ite $x5309 (_ bv1 32) (_ bv0 32))))
(let ((?x8107 ((_ sign_extend 16) in.1_16)))
(let ((?x2071 (bvadd ?x8107 ?x527)))
(let (($x4282 (and (distinct (bvadd ((_ sign_extend 1) ?x8107) ((_ sign_extend 1) ?x527)) ((_ sign_extend 1) ?x2071)) true)))
(let (($x88 (or false false false)))
(let (($x1696 (or $x88 (ite $x5309 false false))))
(let (($x586 (or false false)))
(let (($x1524 (or $x586 $x1696 (or $x4282))))
(and (not $x1524) (or $x1524 (and (distinct ?x2071 ?x2071) true))))))))))))))
(check-sat)
; query 100: function matrix_sum, block 22, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x4338 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x5309 (= (_ bv1 1) ?x4338)))
(let ((?x527 (ite $x5309 (_ bv1 32) (_ bv0 32))))
(let ((?x8107 ((_ sign_extend 16) in.1_16)))
(let ((?x2071 (bvadd ?x8107 ?x527)))
(let ((?x1290 ((_ extract 15 0) ?x2071)))
(let (($x4282 (and (distinct (bvadd ((_ sign_extend 1) ?x8107) ((_ sign_extend 1) ?x527)) ((_ sign_extend 1) ?x2071)) true)))
(let (($x88 (or false false false)))
(let (($x1696 (or $x88 (ite $x5309 false false))))
(let (($x586 (or false false)))
(let (($x1524 (or $x586 $x1696 (or $x4282))))
(let (($x262 (or $x1524 false)))
(and (not $x262) (or $x262 (and (distinct ?x1290 ?x1290) true))))))))))))))))
(check-sat)
; query 101: function matrix_sum, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x88 (or false false false)))
(let (($x100 (not $x88)))
(and $x100 (or $x88 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 102: function matrix_sum, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x98 (bvadd in.01_32 (_ bv1 32))))
(let (($x1042 (and (distinct ?x98 ?x98) true)))
(let (($x88 (or false false false)))
(let (($x100 (not $x88)))
(and $x100 (or $x88 $x1042)))))))
(check-sat)
; query 103: function parseval, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.23_32 () (_ BitVec 32))
(assert
 (let (($x5383 (and (distinct (bvmul ((_ sign_extend 32) in.23_32) ((_ sign_extend 32) (_ bv1024 32))) ((_ sign_extend 32) (bvmul in.23_32 (_ bv1024 32)))) true)))
(let (($x6980 (or false false (or $x5383))))
(and (not $x6980) (or $x6980 (and (distinct (bvmul in.23_32 (_ bv1024 32)) (bvmul in.23_32 (_ bv1024 32))) true))))))
(check-sat)
; query 104: function parseval, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.34_32 () (_ BitVec 32))
(assert
 (let (($x8095 (and (distinct (bvmul ((_ sign_extend 32) in.34_32) ((_ sign_extend 32) (_ bv1048576 32))) ((_ sign_extend 32) (bvmul in.34_32 (_ bv1048576 32)))) true)))
(let (($x8167 (or false false (or $x8095))))
(and (not $x8167) (or $x8167 (and (distinct (bvmul in.34_32 (_ bv1048576 32)) (bvmul in.34_32 (_ bv1048576 32))) true))))))
(check-sat)
; query 105: function partition_memory, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x88 (or false false false)))
(let (($x100 (not $x88)))
(and $x100 (or $x88 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 106: function run_crc_loop, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x98 (bvadd in.01_32 (_ bv1 32))))
(let (($x1042 (and (distinct ?x98 ?x98) true)))
(let (($x88 (or false false false)))
(let (($x100 (not $x88)))
(and $x100 (or $x88 $x1042)))))))
(check-sat)
