; OptiPhase-Sigma refinement certificate for sweep K58-R3-260
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x176 (or false false)))
(let (($x10 (not $x176)))
(and $x10 (or $x176 (and (distinct ((_ sign_extend 16) in25_16) ((_ sign_extend 16) in25_16)) true))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let ((?x328 (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))))
(let (($x176 (or false false)))
(let (($x2401 (or $x176 false false)))
(let (($x2179 (not $x2401)))
(and $x2179 (or $x2401 (and (distinct ?x328 ?x328) true))))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x176 (or false false)))
(let (($x10 (not $x176)))
(and $x10 (or $x176 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x86 ((_ sign_extend 16) in3_16)))
(let ((?x836 (bvand ?x86 (_ bv127 32))))
(let (($x176 (or false false)))
(let (($x2401 (or $x176 false false)))
(let (($x2179 (not $x2401)))
(and $x2179 (or $x2401 (and (distinct ?x836 ?x836) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x86 ((_ sign_extend 16) in3_16)))
(let ((?x836 (bvand ?x86 (_ bv127 32))))
(let ((?x552 ((_ extract 15 0) ?x836)))
(let (($x176 (or false false)))
(let (($x2401 (or $x176 false false)))
(let (($x139 (or $x2401 false)))
(let (($x320 (not $x139)))
(and $x320 (or $x139 (and (distinct ?x552 ?x552) true)))))))))))
(check-sat)
; query 5: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x176 (or false false)))
(let (($x10 (not $x176)))
(and $x10 (or $x176 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 6: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x81 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x176 (or false false)))
(let (($x2401 (or $x176 false false)))
(let (($x2179 (not $x2401)))
(and $x2179 (or $x2401 (and (distinct ?x81 ?x81) true))))))))
(check-sat)
; query 7: function core_bench_list, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x170 (or false false false)))
(let (($x668 (not $x170)))
(and $x668 (or $x170 (and (distinct (bvadd in.0_16 (_ bv1 16)) (bvadd in.0_16 (_ bv1 16))) true))))))
(check-sat)
; query 8: function core_bench_state, block 105, name %106
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x170 (or false false false)))
(let (($x668 (not $x170)))
(and $x668 (or $x170 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 9: function core_bench_state, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x170 (or false false false)))
(let (($x668 (not $x170)))
(and $x668 (or $x170 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 10: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x68 (bvadd in.01_32 (_ bv1 32))))
(let (($x20 (and (distinct ?x68 ?x68) true)))
(let (($x170 (or false false false)))
(let (($x668 (not $x170)))
(and $x668 (or $x170 $x20)))))))
(check-sat)
; query 11: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x68 (bvadd in.01_32 (_ bv1 32))))
(let ((?x121 (bvmul ?x68 (_ bv8 32))))
(let ((?x61 (bvmul ?x68 ?x68)))
(let (($x170 (or false false false)))
(let (($x313 (or $x170 false false)))
(and (not (or $x170 $x170 false)) (or $x313 (and (distinct ?x61 ?x121) true)))))))))
(check-sat)
; query 12: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x1874 (and (distinct (bvmul (bvmul (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) (_ bv2 32)) (bvmul (bvmul (bvadd in.01_32 (_ bv1 32)) (_ bv8 32)) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x170 (or false false false)))
(let (($x313 (or $x170 false false)))
(and (not (or (or $x170 $x170 false) false false)) (or (or $x313 $x170 false) $x1874))))))
(check-sat)
; query 13: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x283 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x170 (or false false false)))
(let (($x668 (not $x170)))
(and $x668 (or $x170 (and (distinct ?x283 ?x283) true)))))))
(check-sat)
; query 14: function core_init_state, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_32 () (_ BitVec 32))
(assert
 (let (($x170 (or false false false)))
(let (($x668 (not $x170)))
(and $x668 (or $x170 (and (distinct (bvadd in.06_32 (_ bv1 32)) (bvadd in.06_32 (_ bv1 32))) true))))))
(check-sat)
; query 15: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x540 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x170 (or false false false)))
(let (($x668 (not $x170)))
(and $x668 (or $x170 (and (distinct ?x540 ?x540) true)))))))
(check-sat)
; query 16: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x170 (or false false false)))
(let (($x668 (not $x170)))
(and $x668 (or $x170 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 17: function core_list_init, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x68 (bvadd in.01_32 (_ bv1 32))))
(let (($x20 (and (distinct ?x68 ?x68) true)))
(let (($x170 (or false false false)))
(let (($x668 (not $x170)))
(and $x668 (or $x170 $x20)))))))
(check-sat)
; query 18: function core_list_mergesort, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x68 (bvadd in.01_32 (_ bv1 32))))
(let (($x20 (and (distinct ?x68 ?x68) true)))
(let (($x235 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x68)) true)))
(let (($x1906 (or false false (or $x235))))
(and (not $x1906) (or $x1906 $x20)))))))
(check-sat)
; query 19: function core_list_mergesort, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x1859 (ite (bvslt (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x170 (or false false false)))
(let (($x668 (not $x170)))
(and $x668 (or $x170 (and (distinct ?x1859 ?x1859) true)))))))
(check-sat)
; query 20: function core_list_mergesort, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.224_32 () (_ BitVec 32))
(assert
 (let ((?x450 (ite (= (_ bv0 32) in.224_32) (_ bv1 1) (_ bv0 1))))
(let (($x170 (or false false false)))
(let (($x668 (not $x170)))
(and $x668 (or $x170 (and (distinct ?x450 ?x450) true)))))))
(check-sat)
; query 21: function core_list_mergesort, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x130 (ite (= (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x170 (or false false false)))
(let (($x668 (not $x170)))
(and $x668 (or $x170 (and (distinct ?x130 ?x130) true)))))))
(check-sat)
; query 22: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x388 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x424 (or false false (or $x388))))
(and (not $x424) (or $x424 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 23: function core_list_mergesort, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x164 (and (distinct (bvmul ((_ sign_extend 32) in.020_32) ((_ sign_extend 32) (_ bv2 32))) ((_ sign_extend 32) (bvmul in.020_32 (_ bv2 32)))) true)))
(let (($x142 (or false false (or $x164))))
(and (not $x142) (or $x142 (and (distinct (bvmul in.020_32 (_ bv2 32)) (bvmul in.020_32 (_ bv2 32))) true))))))
(check-sat)
; query 24: function core_state_transition, block 102, name %103
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x176 (or false false)))
(let (($x10 (not $x176)))
(and $x10 (or $x176 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 25: function core_state_transition, block 102, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x56 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x176 (or false false)))
(let (($x2401 (or $x176 false false)))
(let (($x2179 (not $x2401)))
(and $x2179 (or $x2401 (and (distinct ?x56 ?x56) true))))))))
(check-sat)
; query 26: function core_state_transition, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x176 (or false false)))
(let (($x10 (not $x176)))
(and $x10 (or $x176 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 27: function core_state_transition, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1886 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x176 (or false false)))
(let (($x2401 (or $x176 false false)))
(let (($x2179 (not $x2401)))
(and $x2179 (or $x2401 (and (distinct ?x1886 ?x1886) true))))))))
(check-sat)
; query 28: function core_state_transition, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x176 (or false false)))
(let (($x10 (not $x176)))
(and $x10 (or $x176 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 29: function core_state_transition, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x56 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x176 (or false false)))
(let (($x2401 (or $x176 false false)))
(let (($x2179 (not $x2401)))
(and $x2179 (or $x2401 (and (distinct ?x56 ?x56) true))))))))
(check-sat)
; query 30: function core_state_transition, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x176 (or false false)))
(let (($x10 (not $x176)))
(and $x10 (or $x176 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 31: function core_state_transition, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x2839 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x176 (or false false)))
(let (($x2401 (or $x176 false false)))
(let (($x2179 (not $x2401)))
(and $x2179 (or $x2401 (and (distinct ?x2839 ?x2839) true))))))))
(check-sat)
; query 32: function core_state_transition, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x176 (or false false)))
(let (($x10 (not $x176)))
(and $x10 (or $x176 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 33: function core_state_transition, block 51, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x2839 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x176 (or false false)))
(let (($x2401 (or $x176 false false)))
(let (($x2179 (not $x2401)))
(and $x2179 (or $x2401 (and (distinct ?x2839 ?x2839) true))))))))
(check-sat)
; query 34: function core_state_transition, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x176 (or false false)))
(let (($x10 (not $x176)))
(and $x10 (or $x176 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 35: function core_state_transition, block 64, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x2839 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x176 (or false false)))
(let (($x2401 (or $x176 false false)))
(let (($x2179 (not $x2401)))
(and $x2179 (or $x2401 (and (distinct ?x2839 ?x2839) true))))))))
(check-sat)
; query 36: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x2877 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x170 (or false false false)))
(let (($x668 (not $x170)))
(and $x668 (or $x170 (and (distinct ?x2877 ?x2877) true)))))))
(check-sat)
; query 37: function core_state_transition, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x176 (or false false)))
(let (($x10 (not $x176)))
(and $x10 (or $x176 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 38: function core_state_transition, block 80, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x2629 (ite (= (_ bv69 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x176 (or false false)))
(let (($x2401 (or $x176 false false)))
(let (($x2179 (not $x2401)))
(and $x2179 (or $x2401 (and (distinct ?x2629 ?x2629) true))))))))
(check-sat)
; query 39: function core_state_transition, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x176 (or false false)))
(let (($x10 (not $x176)))
(and $x10 (or $x176 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 40: function core_state_transition, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x2814 (ite (= (_ bv101 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x176 (or false false)))
(let (($x2401 (or $x176 false false)))
(let (($x2179 (not $x2401)))
(and $x2179 (or $x2401 (and (distinct ?x2814 ?x2814) true))))))))
(check-sat)
; query 41: function core_state_transition, block 99, name %100
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x176 (or false false)))
(let (($x10 (not $x176)))
(and $x10 (or $x176 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 42: function core_state_transition, block 99, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1886 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x176 (or false false)))
(let (($x2401 (or $x176 false false)))
(let (($x2179 (not $x2401)))
(and $x2179 (or $x2401 (and (distinct ?x1886 ?x1886) true))))))))
(check-sat)
; query 43: function crcu8, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x176 (or false false)))
(let (($x10 (not $x176)))
(and $x10 (or $x176 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 44: function crcu8, block 19, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x326 ((_ zero_extend 16) in.01_16)))
(let ((?x418 (bvxor ?x326 (_ bv16386 32))))
(let (($x176 (or false false)))
(let (($x2401 (or $x176 false false)))
(let (($x2179 (not $x2401)))
(and $x2179 (or $x2401 (and (distinct ?x418 ?x418) true)))))))))
(check-sat)
; query 45: function crcu8, block 19, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x326 ((_ zero_extend 16) in.01_16)))
(let ((?x418 (bvxor ?x326 (_ bv16386 32))))
(let ((?x3121 ((_ extract 15 0) ?x418)))
(let (($x176 (or false false)))
(let (($x2401 (or $x176 false false)))
(let (($x139 (or $x2401 false)))
(let (($x320 (not $x139)))
(and $x320 (or $x139 (and (distinct ?x3121 ?x3121) true)))))))))))
(check-sat)
; query 46: function crcu8, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x176 (or false false)))
(let (($x10 (not $x176)))
(and $x10 (or $x176 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 47: function crcu8, block 29, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x3120 ((_ zero_extend 16) in27_16)))
(let ((?x2842 (bvor ?x3120 (_ bv32768 32))))
(let (($x176 (or false false)))
(let (($x2401 (or $x176 false false)))
(let (($x2179 (not $x2401)))
(and $x2179 (or $x2401 (and (distinct ?x2842 ?x2842) true)))))))))
(check-sat)
; query 48: function crcu8, block 29, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x3120 ((_ zero_extend 16) in27_16)))
(let ((?x2842 (bvor ?x3120 (_ bv32768 32))))
(let ((?x2862 ((_ extract 15 0) ?x2842)))
(let (($x176 (or false false)))
(let (($x2401 (or $x176 false false)))
(let (($x139 (or $x2401 false)))
(let (($x320 (not $x139)))
(and $x320 (or $x139 (and (distinct ?x2862 ?x2862) true)))))))))))
(check-sat)
; query 49: function crcu8, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x176 (or false false)))
(let (($x10 (not $x176)))
(and $x10 (or $x176 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 50: function crcu8, block 33, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x3120 ((_ zero_extend 16) in27_16)))
(let ((?x2611 (bvand ?x3120 (_ bv32767 32))))
(let (($x176 (or false false)))
(let (($x2401 (or $x176 false false)))
(let (($x2179 (not $x2401)))
(and $x2179 (or $x2401 (and (distinct ?x2611 ?x2611) true)))))))))
(check-sat)
; query 51: function crcu8, block 33, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x3120 ((_ zero_extend 16) in27_16)))
(let ((?x2611 (bvand ?x3120 (_ bv32767 32))))
(let ((?x2616 ((_ extract 15 0) ?x2611)))
(let (($x176 (or false false)))
(let (($x2401 (or $x176 false false)))
(let (($x139 (or $x2401 false)))
(let (($x320 (not $x139)))
(and $x320 (or $x139 (and (distinct ?x2616 ?x2616) true)))))))))))
(check-sat)
; query 52: function crcu8, block 38, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_8 () (_ BitVec 8))
(assert
 (let (($x170 (or false false false)))
(let (($x668 (not $x170)))
(and $x668 (or $x170 (and (distinct (bvadd in.02_8 (_ bv1 8)) (bvadd in.02_8 (_ bv1 8))) true))))))
(check-sat)
; query 53: function crcu8, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x2180 ((_ extract 7 0) in.01_16)))
(let ((?x1818 ((_ zero_extend 24) ?x2180)))
(let (($x176 (or false false)))
(let (($x632 (or $x176 false)))
(and (not $x632) (or $x632 (and (distinct ?x1818 ?x1818) true))))))))
(check-sat)
; query 54: function crcu8, block 6, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x2180 ((_ extract 7 0) in.01_16)))
(let ((?x1818 ((_ zero_extend 24) ?x2180)))
(let ((?x2868 (bvand ?x1818 (_ bv1 32))))
(let (($x176 (or false false)))
(let (($x632 (or $x176 false)))
(let (($x2166 (or $x632 false false)))
(and (not $x2166) (or $x2166 (and (distinct ?x2868 ?x2868) true))))))))))
(check-sat)
; query 55: function crcu8, block 6, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x2180 ((_ extract 7 0) in.01_16)))
(let ((?x1818 ((_ zero_extend 24) ?x2180)))
(let ((?x2868 (bvand ?x1818 (_ bv1 32))))
(let ((?x2398 ((_ zero_extend 24) in.0_8)))
(let ((?x1024 (bvand ?x2398 (_ bv1 32))))
(let ((?x554 (bvxor ?x1024 ?x2868)))
(let (($x176 (or false false)))
(let (($x632 (or $x176 false)))
(let (($x2166 (or $x632 false false)))
(let (($x2401 (or $x176 false false)))
(let (($x411 (or $x2401 $x2166 false)))
(and (not $x411) (or $x411 (and (distinct ?x554 ?x554) true)))))))))))))))
(check-sat)
; query 56: function crcu8, block 6, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x2180 ((_ extract 7 0) in.01_16)))
(let ((?x1818 ((_ zero_extend 24) ?x2180)))
(let ((?x2868 (bvand ?x1818 (_ bv1 32))))
(let ((?x2398 ((_ zero_extend 24) in.0_8)))
(let ((?x1024 (bvand ?x2398 (_ bv1 32))))
(let ((?x554 (bvxor ?x1024 ?x2868)))
(let ((?x893 ((_ extract 7 0) ?x554)))
(let (($x176 (or false false)))
(let (($x632 (or $x176 false)))
(let (($x2166 (or $x632 false false)))
(let (($x2401 (or $x176 false false)))
(let (($x411 (or $x2401 $x2166 false)))
(let (($x2385 (or $x411 false)))
(and (not $x2385) (or $x2385 (and (distinct ?x893 ?x893) true)))))))))))))))))
(check-sat)
; query 57: function crcu8, block 6, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x176 (or false false)))
(let (($x10 (not $x176)))
(and $x10 (or $x176 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 58: function crcu8, block 6, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x2398 ((_ zero_extend 24) in.0_8)))
(let ((?x2618 (bvashr ?x2398 (_ bv1 32))))
(let (($x176 (or false false)))
(let (($x2401 (or $x176 false false)))
(let (($x1401 (or $x2401 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not $x1401) (or $x1401 (and (distinct ?x2618 ?x2618) true)))))))))
(check-sat)
; query 59: function crcu8, block 6, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x2398 ((_ zero_extend 24) in.0_8)))
(let ((?x2618 (bvashr ?x2398 (_ bv1 32))))
(let ((?x2389 ((_ extract 7 0) ?x2618)))
(let (($x176 (or false false)))
(let (($x2401 (or $x176 false false)))
(let (($x1401 (or $x2401 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x3388 (or $x1401 false)))
(and (not $x3388) (or $x3388 (and (distinct ?x2389 ?x2389) true)))))))))))
(check-sat)
; query 60: function crcu8, block 6, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x2180 ((_ extract 7 0) in.01_16)))
(let ((?x1818 ((_ zero_extend 24) ?x2180)))
(let ((?x2868 (bvand ?x1818 (_ bv1 32))))
(let ((?x2398 ((_ zero_extend 24) in.0_8)))
(let ((?x1024 (bvand ?x2398 (_ bv1 32))))
(let ((?x554 (bvxor ?x1024 ?x2868)))
(let ((?x893 ((_ extract 7 0) ?x554)))
(let ((?x2865 ((_ zero_extend 24) ?x893)))
(let (($x176 (or false false)))
(let (($x632 (or $x176 false)))
(let (($x2166 (or $x632 false false)))
(let (($x2401 (or $x176 false false)))
(let (($x411 (or $x2401 $x2166 false)))
(let (($x2385 (or $x411 false)))
(let (($x542 (or $x2385 false)))
(and (not $x542) (or $x542 (and (distinct ?x2865 ?x2865) true)))))))))))))))))))
(check-sat)
; query 61: function crcu8, block 6, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x2180 ((_ extract 7 0) in.01_16)))
(let ((?x1818 ((_ zero_extend 24) ?x2180)))
(let ((?x2868 (bvand ?x1818 (_ bv1 32))))
(let ((?x2398 ((_ zero_extend 24) in.0_8)))
(let ((?x1024 (bvand ?x2398 (_ bv1 32))))
(let ((?x554 (bvxor ?x1024 ?x2868)))
(let ((?x893 ((_ extract 7 0) ?x554)))
(let ((?x2865 ((_ zero_extend 24) ?x893)))
(let ((?x2175 (ite (= (_ bv1 32) ?x2865) (_ bv1 1) (_ bv0 1))))
(let (($x176 (or false false)))
(let (($x632 (or $x176 false)))
(let (($x2166 (or $x632 false false)))
(let (($x2401 (or $x176 false false)))
(let (($x411 (or $x2401 $x2166 false)))
(let (($x2385 (or $x411 false)))
(let (($x542 (or $x2385 false)))
(let (($x3387 (or $x542 false false)))
(and (not $x3387) (or $x3387 (and (distinct ?x2175 ?x2175) true)))))))))))))))))))))
(check-sat)
; query 62: function crcu8, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x176 (or false false)))
(let (($x10 (not $x176)))
(and $x10 (or $x176 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 63: function crcu8, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x2398 ((_ zero_extend 24) in.0_8)))
(let ((?x1024 (bvand ?x2398 (_ bv1 32))))
(let (($x176 (or false false)))
(let (($x2401 (or $x176 false false)))
(let (($x2179 (not $x2401)))
(and $x2179 (or $x2401 (and (distinct ?x1024 ?x1024) true)))))))))
(check-sat)
; query 64: function crcu8, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x176 (or false false)))
(let (($x10 (not $x176)))
(and $x10 (or $x176 (and (distinct ((_ extract 7 0) in.01_16) ((_ extract 7 0) in.01_16)) true))))))
(check-sat)
; query 65: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1410 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x170 (or false false false)))
(let (($x668 (not $x170)))
(and $x668 (or $x170 (and (distinct ?x1410 ?x1410) true)))))))
(check-sat)
; query 66: function matrix_add_const, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x170 (or false false false)))
(let (($x668 (not $x170)))
(and $x668 (or $x170 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 67: function matrix_add_const, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x68 (bvadd in.01_32 (_ bv1 32))))
(let (($x20 (and (distinct ?x68 ?x68) true)))
(let (($x170 (or false false false)))
(let (($x668 (not $x170)))
(and $x668 (or $x170 $x20)))))))
(check-sat)
; query 68: function matrix_mul_const, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x170 (or false false false)))
(let (($x668 (not $x170)))
(and $x668 (or $x170 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 69: function matrix_mul_const, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x68 (bvadd in.01_32 (_ bv1 32))))
(let (($x20 (and (distinct ?x68 ?x68) true)))
(let (($x170 (or false false false)))
(let (($x668 (not $x170)))
(and $x668 (or $x170 $x20)))))))
(check-sat)
; query 70: function matrix_mul_matrix, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x170 (or false false false)))
(let (($x668 (not $x170)))
(and $x668 (or $x170 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 71: function matrix_mul_matrix, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x68 (bvadd in.01_32 (_ bv1 32))))
(let (($x20 (and (distinct ?x68 ?x68) true)))
(let (($x170 (or false false false)))
(let (($x668 (not $x170)))
(and $x668 (or $x170 $x20)))))))
(check-sat)
; query 72: function matrix_mul_matrix, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x170 (or false false false)))
(let (($x668 (not $x170)))
(and $x668 (or $x170 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 73: function matrix_mul_matrix_bitextract, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x170 (or false false false)))
(let (($x668 (not $x170)))
(and $x668 (or $x170 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 74: function matrix_mul_matrix_bitextract, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x68 (bvadd in.01_32 (_ bv1 32))))
(let (($x20 (and (distinct ?x68 ?x68) true)))
(let (($x170 (or false false false)))
(let (($x668 (not $x170)))
(and $x668 (or $x170 $x20)))))))
(check-sat)
; query 75: function matrix_mul_matrix_bitextract, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x170 (or false false false)))
(let (($x668 (not $x170)))
(and $x668 (or $x170 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 76: function matrix_mul_vect, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x170 (or false false false)))
(let (($x668 (not $x170)))
(and $x668 (or $x170 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 77: function matrix_mul_vect, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x68 (bvadd in.01_32 (_ bv1 32))))
(let (($x20 (and (distinct ?x68 ?x68) true)))
(let (($x170 (or false false false)))
(let (($x668 (not $x170)))
(and $x668 (or $x170 $x20)))))))
(check-sat)
; query 78: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x176 (or false false)))
(let (($x10 (not $x176)))
(and $x10 (or $x176 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 79: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x1236 ((_ sign_extend 16) in.1_16)))
(let ((?x2390 (bvadd ?x1236 (_ bv10 32))))
(let (($x790 (and (distinct (bvadd ((_ sign_extend 1) ?x1236) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x2390)) true)))
(let (($x176 (or false false)))
(let (($x2866 (or $x176 false (or $x790))))
(and (not $x2866) (or $x2866 (and (distinct ?x2390 ?x2390) true)))))))))
(check-sat)
; query 80: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x1236 ((_ sign_extend 16) in.1_16)))
(let ((?x2390 (bvadd ?x1236 (_ bv10 32))))
(let ((?x2617 ((_ extract 15 0) ?x2390)))
(let (($x790 (and (distinct (bvadd ((_ sign_extend 1) ?x1236) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x2390)) true)))
(let (($x176 (or false false)))
(let (($x2866 (or $x176 false (or $x790))))
(let (($x2391 (or $x2866 false)))
(and (not $x2391) (or $x2391 (and (distinct ?x2617 ?x2617) true)))))))))))
(check-sat)
; query 81: function partition_memory, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x170 (or false false false)))
(let (($x668 (not $x170)))
(and $x668 (or $x170 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 82: function run_crc_loop, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x68 (bvadd in.01_32 (_ bv1 32))))
(let (($x20 (and (distinct ?x68 ?x68) true)))
(let (($x170 (or false false false)))
(let (($x668 (not $x170)))
(and $x668 (or $x170 $x20)))))))
(check-sat)
