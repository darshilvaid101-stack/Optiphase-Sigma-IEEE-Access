; OptiPhase-Sigma refinement certificate for sweep K30-R4-353
; query 0: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x369 (ite (bvsgt (_ bv2 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x114 (or false false false)))
(and (not $x114) (or $x114 (and (distinct ?x369 ?x369) true))))))
(check-sat)
