; OptiPhase-Sigma refinement certificate for sweep K19-R3-106
