; OptiPhase-Sigma refinement certificate for sweep K48-R2-090
; query 0: function APCM_inverse_quantization, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x23 (or false false)))
(let (($x1580 (not $x23)))
(and $x1580 (or $x23 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 1: function APCM_inverse_quantization, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x219 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x23 (or false false)))
(let (($x1435 (or $x23 false false)))
(let (($x1864 (not $x1435)))
(and $x1864 (or $x1435 (and (distinct ?x219 ?x219) true))))))))
(check-sat)
; query 2: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x23 (or false false)))
(let (($x1580 (not $x23)))
(and $x1580 (or $x23 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 3: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1651 (ite (bvslt (_ bv15 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x23 (or false false)))
(let (($x1435 (or $x23 false false)))
(let (($x1864 (not $x1435)))
(and $x1864 (or $x1435 (and (distinct ?x1651 ?x1651) true))))))))
(check-sat)
; query 4: function Decoding_of_the_coded_Log_Area_Ratios, block 268, name %269
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in265_64 () (_ BitVec 64))
(assert
 (let (($x12 (and (distinct (ite (bvsge (_ bv18446744073709518848 64) in265_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv0 64) in265_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x7 (or false false false)))
(let (($x576 (not $x7)))
(and $x576 (or $x7 $x12))))))
(check-sat)
; query 5: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x23 (or false false)))
(let (($x1580 (not $x23)))
(and $x1580 (or $x23 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 6: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x308 (ite (bvsgt (_ bv40 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x23 (or false false)))
(let (($x1435 (or $x23 false false)))
(let (($x1864 (not $x1435)))
(and $x1864 (or $x1435 (and (distinct ?x308 ?x308) true))))))))
(check-sat)
; query 7: function Quantization_and_coding, block 311, name %312
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in308_32 () (_ BitVec 32))
(declare-fun in308_64 () (_ BitVec 64))
(assert
 (let (($x443 (and (distinct (ite (bvslt (_ bv0 64) in308_64) (_ bv1 1) (_ bv0 1)) (ite (bvsgt (_ bv4294967292 32) in308_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x7 (or false false false)))
(let (($x576 (not $x7)))
(and $x576 (or $x7 $x443))))))
(check-sat)
; query 8: function RPE_grid_positioning, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x23 (or false false)))
(let (($x1580 (not $x23)))
(and $x1580 (or $x23 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 9: function RPE_grid_positioning, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x52 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x208 (and (distinct ?x52 ?x52) true)))
(let (($x23 (or false false)))
(let (($x383 (or false $x23 false)))
(and (not $x383) (or $x383 $x208)))))))
(check-sat)
; query 10: function alaw_input, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x39 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x1193 (or false false (or $x39))))
(and (not $x1193) (or $x1193 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 11: function alaw_input, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let ((?x235 (ite (= (_ bv4294967295 32) in.1_32) (_ bv1 1) (_ bv0 1))))
(let (($x7 (or false false false)))
(let (($x576 (not $x7)))
(and $x576 (or $x7 (and (distinct ?x235 ?x235) true)))))))
(check-sat)
; query 12: function gsm_L_add, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_64 () (_ BitVec 64))
(assert
 (let ((?x395 (bvsub (_ bv0 64) in13_64)))
(let ((?x5 ((_ sign_extend 1) ?x395)))
(let (($x190 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in13_64)) ?x5) true)))))
(and (not $x190) (or $x190 (and (distinct ?x395 ?x395) true)))))))
(check-sat)
; query 13: function gsm_L_add, block 16, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_64 () (_ BitVec 64))
(assert
 (let ((?x395 (bvsub (_ bv0 64) in13_64)))
(let ((?x94 (bvsub ?x395 (_ bv2 64))))
(let (($x89 (and (distinct (bvsub ((_ sign_extend 1) ?x395) ((_ sign_extend 1) (_ bv2 64))) ((_ sign_extend 1) ?x94)) true)))
(let ((?x5 ((_ sign_extend 1) ?x395)))
(let (($x190 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in13_64)) ?x5) true)))))
(let (($x50 (or $x190 false (or $x89))))
(and (not $x50) (or $x50 (and (distinct ?x94 ?x94) true))))))))))
(check-sat)
; query 14: function gsm_L_add, block 21, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x49 (ite (bvsge (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x7 (or false false false)))
(let (($x576 (not $x7)))
(and $x576 (or $x7 (and (distinct ?x49 ?x49) true)))))))
(check-sat)
; query 15: function gsm_L_add, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x473 (bvadd in0_64 in1_64)))
(let (($x9 (and (distinct ?x473 ?x473) true)))
(let (($x307 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) ?x473)) true)))
(let (($x28 (or false false (or $x307))))
(and (not $x28) (or $x28 $x9)))))))
(check-sat)
; query 16: function gsm_L_add, block 25, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x473 (bvadd in0_64 in1_64)))
(let (($x9 (and (distinct ?x473 ?x473) true)))
(let (($x7 (or false false false)))
(let (($x576 (not $x7)))
(and $x576 (or $x7 $x9)))))))
(check-sat)
; query 17: function gsm_L_add, block 25, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x392 (ite (bvugt (bvadd in0_64 in1_64) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x7 (or false false false)))
(let (($x330 (or $x7 false false)))
(let (($x1319 (not $x330)))
(and $x1319 (or $x330 (and (distinct ?x392 ?x392) true))))))))
(check-sat)
; query 18: function gsm_L_add, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x912 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x7 (or false false false)))
(let (($x576 (not $x7)))
(and $x576 (or $x7 (and (distinct ?x912 ?x912) true)))))))
(check-sat)
; query 19: function gsm_L_add, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x473 (bvadd in0_64 in1_64)))
(let (($x9 (and (distinct ?x473 ?x473) true)))
(let (($x307 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) ?x473)) true)))
(let (($x28 (or false false (or $x307))))
(and (not $x28) (or $x28 $x9)))))))
(check-sat)
; query 20: function gsm_L_add, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x122 (bvadd in0_64 (_ bv1 64))))
(let ((?x1448 (bvsub (_ bv0 64) ?x122)))
(let (($x1125 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x122)) ((_ sign_extend 1) ?x1448)) true)))
(let ((?x177 ((_ sign_extend 1) ?x122)))
(let (($x890 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x177) true)))))
(let (($x1309 (or false $x890 (or $x1125))))
(and (not $x1309) (or $x1309 (and (distinct ?x1448 ?x1448) true))))))))))
(check-sat)
; query 21: function gsm_L_add, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x593 (bvadd in1_64 (_ bv1 64))))
(let ((?x983 ((_ sign_extend 1) ?x593)))
(let (($x1090 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x983) true)))))
(and (not $x1090) (or $x1090 (and (distinct ?x593 ?x593) true)))))))
(check-sat)
; query 22: function gsm_L_add, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x593 (bvadd in1_64 (_ bv1 64))))
(let ((?x181 (bvsub (_ bv0 64) ?x593)))
(let (($x107 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x593)) ((_ sign_extend 1) ?x181)) true)))
(let ((?x983 ((_ sign_extend 1) ?x593)))
(let (($x1090 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x983) true)))))
(let (($x504 (or false $x1090 (or $x107))))
(and (not $x504) (or $x504 (and (distinct ?x181 ?x181) true))))))))))
(check-sat)
; query 23: function gsm_L_add, block 8, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x593 (bvadd in1_64 (_ bv1 64))))
(let ((?x181 (bvsub (_ bv0 64) ?x593)))
(let ((?x122 (bvadd in0_64 (_ bv1 64))))
(let ((?x1448 (bvsub (_ bv0 64) ?x122)))
(let ((?x744 (bvadd ?x1448 ?x181)))
(let (($x107 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x593)) ((_ sign_extend 1) ?x181)) true)))
(let ((?x983 ((_ sign_extend 1) ?x593)))
(let (($x1090 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x983) true)))))
(let (($x504 (or false $x1090 (or $x107))))
(let (($x1125 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x122)) ((_ sign_extend 1) ?x1448)) true)))
(let ((?x177 ((_ sign_extend 1) ?x122)))
(let (($x890 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x177) true)))))
(let (($x1309 (or false $x890 (or $x1125))))
(let (($x173 (or $x1309 $x504 false)))
(and (not $x173) (or $x173 (and (distinct ?x744 ?x744) true))))))))))))))))))
(check-sat)
; query 24: function gsm_L_add, block 8, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x593 (bvadd in1_64 (_ bv1 64))))
(let ((?x181 (bvsub (_ bv0 64) ?x593)))
(let ((?x122 (bvadd in0_64 (_ bv1 64))))
(let ((?x1448 (bvsub (_ bv0 64) ?x122)))
(let ((?x744 (bvadd ?x1448 ?x181)))
(let ((?x1596 (ite (bvuge ?x744 (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x107 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x593)) ((_ sign_extend 1) ?x181)) true)))
(let ((?x983 ((_ sign_extend 1) ?x593)))
(let (($x1090 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x983) true)))))
(let (($x504 (or false $x1090 (or $x107))))
(let (($x1125 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x122)) ((_ sign_extend 1) ?x1448)) true)))
(let ((?x177 ((_ sign_extend 1) ?x122)))
(let (($x890 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x177) true)))))
(let (($x1309 (or false $x890 (or $x1125))))
(let (($x173 (or $x1309 $x504 false)))
(let (($x1181 (or $x173 false false)))
(and (not $x1181) (or $x1181 (and (distinct ?x1596 ?x1596) true))))))))))))))))))))
(check-sat)
; query 25: function gsm_L_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x122 (bvadd in0_64 (_ bv1 64))))
(let ((?x177 ((_ sign_extend 1) ?x122)))
(let (($x890 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x177) true)))))
(and (not $x890) (or $x890 (and (distinct ?x122 ?x122) true)))))))
(check-sat)
; query 26: function gsm_L_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1461 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x7 (or false false false)))
(let (($x576 (not $x7)))
(and $x576 (or $x7 (and (distinct ?x1461 ?x1461) true)))))))
(check-sat)
; query 27: function gsm_L_asl, block 12, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1349 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x7 (or false false false)))
(let (($x576 (not $x7)))
(and $x576 (or $x7 (and (distinct ?x1349 ?x1349) true)))))))
(check-sat)
; query 28: function gsm_L_asl, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x23 (or false false)))
(let (($x1580 (not $x23)))
(and $x1580 (or $x23 (and (distinct ((_ zero_extend 32) in1_32) ((_ zero_extend 32) in1_32)) true))))))
(check-sat)
; query 29: function gsm_L_asl, block 17, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1706 ((_ zero_extend 32) in1_32)))
(let ((?x550 (bvshl in0_64 ?x1706)))
(let (($x23 (or false false)))
(let (($x383 (or false $x23 false)))
(let (($x369 (or $x383 (bvuge ?x1706 (_ bv64 64)))))
(let (($x1244 (not $x369)))
(and $x1244 (or $x369 (and (distinct ?x550 ?x550) true))))))))))
(check-sat)
; query 30: function gsm_L_asl, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x345 (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x7 (or false false false)))
(let (($x576 (not $x7)))
(and $x576 (or $x7 (and (distinct ?x345 ?x345) true)))))))
(check-sat)
; query 31: function gsm_L_asl, block 7, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1461 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1361 ((_ zero_extend 31) ?x1461)))
(let ((?x1039 (bvsub (_ bv0 32) ?x1361)))
(let (($x1600 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1361)) ((_ sign_extend 1) ?x1039)) true)))
(let (($x7 (or false false false)))
(let (($x1128 (or $x7 false)))
(let (($x125 (or false $x1128 (or $x1600))))
(and (not $x125) (or $x125 (and (distinct ?x1039 ?x1039) true)))))))))))
(check-sat)
; query 32: function gsm_L_asl, block 7, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1461 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1361 ((_ zero_extend 31) ?x1461)))
(let ((?x1039 (bvsub (_ bv0 32) ?x1361)))
(let ((?x972 ((_ sign_extend 32) ?x1039)))
(let (($x1600 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1361)) ((_ sign_extend 1) ?x1039)) true)))
(let (($x7 (or false false false)))
(let (($x1128 (or $x7 false)))
(let (($x125 (or false $x1128 (or $x1600))))
(let (($x1765 (or $x125 false)))
(and (not $x1765) (or $x1765 (and (distinct ?x972 ?x972) true)))))))))))))
(check-sat)
; query 33: function gsm_L_asl, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1461 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x7 (or false false false)))
(let (($x576 (not $x7)))
(and $x576 (or $x7 (and (distinct ?x1461 ?x1461) true)))))))
(check-sat)
; query 34: function gsm_L_asl, block 7, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1461 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1361 ((_ zero_extend 31) ?x1461)))
(let (($x7 (or false false false)))
(let (($x1128 (or $x7 false)))
(and (not $x1128) (or $x1128 (and (distinct ?x1361 ?x1361) true))))))))
(check-sat)
; query 35: function gsm_L_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x294 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x7 (or false false false)))
(let (($x576 (not $x7)))
(and $x576 (or $x7 (and (distinct ?x294 ?x294) true)))))))
(check-sat)
; query 36: function gsm_L_asr, block 12, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1349 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x7 (or false false false)))
(let (($x576 (not $x7)))
(and $x576 (or $x7 (and (distinct ?x1349 ?x1349) true)))))))
(check-sat)
; query 37: function gsm_L_asr, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x261 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in1_32))) true)))
(let (($x142 (or false false (or $x261))))
(and (not $x142) (or $x142 (and (distinct (bvsub (_ bv0 32) in1_32) (bvsub (_ bv0 32) in1_32)) true))))))
(check-sat)
; query 38: function gsm_L_asr, block 14, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x813 (bvsub (_ bv0 32) in1_32)))
(let ((?x1394 ((_ zero_extend 32) ?x813)))
(let (($x261 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x813)) true)))
(let (($x142 (or false false (or $x261))))
(let (($x419 (or $x142 false)))
(and (not $x419) (or $x419 (and (distinct ?x1394 ?x1394) true)))))))))
(check-sat)
; query 39: function gsm_L_asr, block 14, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x813 (bvsub (_ bv0 32) in1_32)))
(let ((?x1394 ((_ zero_extend 32) ?x813)))
(let ((?x686 (bvshl in0_64 ?x1394)))
(let (($x261 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x813)) true)))
(let (($x142 (or false false (or $x261))))
(let (($x419 (or $x142 false)))
(let (($x2081 (or (or false $x419 false) (bvuge ?x1394 (_ bv64 64)))))
(and (not $x2081) (or $x2081 (and (distinct ?x686 ?x686) true)))))))))))
(check-sat)
; query 40: function gsm_L_asr, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x23 (or false false)))
(let (($x1580 (not $x23)))
(and $x1580 (or $x23 (and (distinct ((_ zero_extend 32) in1_32) ((_ zero_extend 32) in1_32)) true))))))
(check-sat)
; query 41: function gsm_L_asr, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1706 ((_ zero_extend 32) in1_32)))
(let ((?x339 (bvashr in0_64 ?x1706)))
(let (($x23 (or false false)))
(let (($x383 (or false $x23 false)))
(let (($x369 (or $x383 (bvuge ?x1706 (_ bv64 64)))))
(let (($x1244 (not $x369)))
(and $x1244 (or $x369 (and (distinct ?x339 ?x339) true))))))))))
(check-sat)
; query 42: function gsm_L_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1461 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x7 (or false false false)))
(let (($x576 (not $x7)))
(and $x576 (or $x7 (and (distinct ?x1461 ?x1461) true)))))))
(check-sat)
; query 43: function gsm_L_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1461 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1361 ((_ zero_extend 31) ?x1461)))
(let (($x7 (or false false false)))
(let (($x1128 (or $x7 false)))
(and (not $x1128) (or $x1128 (and (distinct ?x1361 ?x1361) true))))))))
(check-sat)
; query 44: function gsm_L_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1461 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1361 ((_ zero_extend 31) ?x1461)))
(let ((?x1039 (bvsub (_ bv0 32) ?x1361)))
(let (($x1600 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1361)) ((_ sign_extend 1) ?x1039)) true)))
(let (($x7 (or false false false)))
(let (($x1128 (or $x7 false)))
(let (($x125 (or false $x1128 (or $x1600))))
(and (not $x125) (or $x125 (and (distinct ?x1039 ?x1039) true)))))))))))
(check-sat)
; query 45: function gsm_L_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1461 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1361 ((_ zero_extend 31) ?x1461)))
(let ((?x1039 (bvsub (_ bv0 32) ?x1361)))
(let ((?x972 ((_ sign_extend 32) ?x1039)))
(let (($x1600 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1361)) ((_ sign_extend 1) ?x1039)) true)))
(let (($x7 (or false false false)))
(let (($x1128 (or $x7 false)))
(let (($x125 (or false $x1128 (or $x1600))))
(let (($x1765 (or $x125 false)))
(and (not $x1765) (or $x1765 (and (distinct ?x972 ?x972) true)))))))))))))
(check-sat)
; query 46: function gsm_L_asr, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x345 (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x7 (or false false false)))
(let (($x576 (not $x7)))
(and $x576 (or $x7 (and (distinct ?x345 ?x345) true)))))))
(check-sat)
; query 47: function gsm_L_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x294 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x7 (or false false false)))
(let (($x576 (not $x7)))
(and $x576 (or $x7 (and (distinct ?x294 ?x294) true)))))))
(check-sat)
; query 48: function gsm_L_mult, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x23 (or false false)))
(let (($x1580 (not $x23)))
(and $x1580 (or $x23 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 49: function gsm_L_mult, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x726 (ite (and (distinct (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) true) (_ bv1 1) (_ bv0 1))))
(let (($x23 (or false false)))
(let (($x1435 (or $x23 false false)))
(let (($x1864 (not $x1435)))
(and $x1864 (or $x1435 (and (distinct ?x726 ?x726) true))))))))
(check-sat)
; query 50: function gsm_L_mult, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x23 (or false false)))
(let (($x1580 (not $x23)))
(and $x1580 (or $x23 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 51: function gsm_L_mult, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x444 (ite (and (distinct (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) true) (_ bv1 1) (_ bv0 1))))
(let (($x23 (or false false)))
(let (($x1435 (or $x23 false false)))
(let (($x1864 (not $x1435)))
(and $x1864 (or $x1435 (and (distinct ?x444 ?x444) true))))))))
(check-sat)
; query 52: function gsm_L_sub, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in11_64 () (_ BitVec 64))
(assert
 (let (($x7 (or false false false)))
(let (($x576 (not $x7)))
(and $x576 (or $x7 (and (distinct (bvadd in11_64 (_ bv1 64)) (bvadd in11_64 (_ bv1 64))) true))))))
(check-sat)
; query 53: function gsm_L_sub, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x49 (ite (bvsge (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x7 (or false false false)))
(let (($x576 (not $x7)))
(and $x576 (or $x7 (and (distinct ?x49 ?x49) true)))))))
(check-sat)
; query 54: function gsm_L_sub, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x1471 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvsub in0_64 in1_64))) true)))
(let (($x191 (or false false (or $x1471))))
(let (($x284 (or $x191 (and (distinct (bvsub in0_64 in1_64) (bvsub in0_64 in1_64)) true))))
(and (not $x191) $x284)))))
(check-sat)
; query 55: function gsm_L_sub, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x122 (bvadd in0_64 (_ bv1 64))))
(let ((?x177 ((_ sign_extend 1) ?x122)))
(let (($x890 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x177) true)))))
(and (not $x890) (or $x890 (and (distinct ?x122 ?x122) true)))))))
(check-sat)
; query 56: function gsm_L_sub, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x122 (bvadd in0_64 (_ bv1 64))))
(let ((?x1448 (bvsub (_ bv0 64) ?x122)))
(let (($x1125 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x122)) ((_ sign_extend 1) ?x1448)) true)))
(let ((?x177 ((_ sign_extend 1) ?x122)))
(let (($x890 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x177) true)))))
(let (($x1309 (or false $x890 (or $x1125))))
(and (not $x1309) (or $x1309 (and (distinct ?x1448 ?x1448) true))))))))))
(check-sat)
; query 57: function gsm_L_sub, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x122 (bvadd in0_64 (_ bv1 64))))
(let ((?x1448 (bvsub (_ bv0 64) ?x122)))
(let ((?x448 (bvadd ?x1448 in1_64)))
(let (($x1125 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x122)) ((_ sign_extend 1) ?x1448)) true)))
(let ((?x177 ((_ sign_extend 1) ?x122)))
(let (($x890 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x177) true)))))
(let (($x1309 (or false $x890 (or $x1125))))
(let (($x2031 (or $x1309 false false)))
(and (not $x2031) (or $x2031 (and (distinct ?x448 ?x448) true))))))))))))
(check-sat)
; query 58: function gsm_L_sub, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2001 (ite (bvuge (bvadd (bvsub (_ bv0 64) (bvadd in0_64 (_ bv1 64))) in1_64) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x1125 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) (bvadd in0_64 (_ bv1 64)))) ((_ sign_extend 1) (bvsub (_ bv0 64) (bvadd in0_64 (_ bv1 64))))) true)))
(let ((?x122 (bvadd in0_64 (_ bv1 64))))
(let ((?x177 ((_ sign_extend 1) ?x122)))
(let (($x890 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x177) true)))))
(let (($x1309 (or false $x890 (or $x1125))))
(let (($x2031 (or $x1309 false false)))
(let (($x2011 (or $x2031 false false)))
(and (not $x2011) (or $x2011 (and (distinct ?x2001 ?x2001) true))))))))))))
(check-sat)
; query 59: function gsm_L_sub, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_64 () (_ BitVec 64))
(assert
 (let ((?x243 (bvsub (_ bv0 64) in25_64)))
(let ((?x950 ((_ sign_extend 1) ?x243)))
(let (($x1752 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in25_64)) ?x950) true)))))
(and (not $x1752) (or $x1752 (and (distinct ?x243 ?x243) true)))))))
(check-sat)
; query 60: function gsm_L_sub, block 28, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_64 () (_ BitVec 64))
(assert
 (let ((?x243 (bvsub (_ bv0 64) in25_64)))
(let ((?x1950 (bvsub ?x243 (_ bv1 64))))
(let (($x1774 (and (distinct (bvsub ((_ sign_extend 1) ?x243) ((_ sign_extend 1) (_ bv1 64))) ((_ sign_extend 1) ?x1950)) true)))
(let ((?x950 ((_ sign_extend 1) ?x243)))
(let (($x1752 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in25_64)) ?x950) true)))))
(let (($x1887 (or $x1752 false (or $x1774))))
(and (not $x1887) (or $x1887 (and (distinct ?x1950 ?x1950) true))))))))))
(check-sat)
; query 61: function gsm_L_sub, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x912 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x7 (or false false false)))
(let (($x576 (not $x7)))
(and $x576 (or $x7 (and (distinct ?x912 ?x912) true)))))))
(check-sat)
; query 62: function gsm_L_sub, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x1471 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvsub in0_64 in1_64))) true)))
(let (($x191 (or false false (or $x1471))))
(let (($x284 (or $x191 (and (distinct (bvsub in0_64 in1_64) (bvsub in0_64 in1_64)) true))))
(and (not $x191) $x284)))))
(check-sat)
; query 63: function gsm_L_sub, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x593 (bvadd in1_64 (_ bv1 64))))
(let ((?x181 (bvsub (_ bv0 64) ?x593)))
(let (($x107 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x593)) ((_ sign_extend 1) ?x181)) true)))
(let ((?x983 ((_ sign_extend 1) ?x593)))
(let (($x1090 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x983) true)))))
(let (($x504 (or false $x1090 (or $x107))))
(and (not $x504) (or $x504 (and (distinct ?x181 ?x181) true))))))))))
(check-sat)
; query 64: function gsm_L_sub, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x593 (bvadd in1_64 (_ bv1 64))))
(let ((?x181 (bvsub (_ bv0 64) ?x593)))
(let ((?x1786 (bvadd in0_64 ?x181)))
(let (($x107 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x593)) ((_ sign_extend 1) ?x181)) true)))
(let ((?x983 ((_ sign_extend 1) ?x593)))
(let (($x1090 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x983) true)))))
(let (($x504 (or false $x1090 (or $x107))))
(let (($x2041 (or false $x504 false)))
(and (not $x2041) (or $x2041 (and (distinct ?x1786 ?x1786) true))))))))))))
(check-sat)
; query 65: function gsm_L_sub, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x391 (ite (bvuge (bvadd in0_64 (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64)))) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x107 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) (bvadd in1_64 (_ bv1 64)))) ((_ sign_extend 1) (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64))))) true)))
(let ((?x593 (bvadd in1_64 (_ bv1 64))))
(let ((?x983 ((_ sign_extend 1) ?x593)))
(let (($x1090 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x983) true)))))
(let (($x504 (or false $x1090 (or $x107))))
(let (($x2041 (or false $x504 false)))
(let (($x1689 (or $x2041 false false)))
(and (not $x1689) (or $x1689 (and (distinct ?x391 ?x391) true))))))))))))
(check-sat)
; query 66: function gsm_L_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x593 (bvadd in1_64 (_ bv1 64))))
(let ((?x983 ((_ sign_extend 1) ?x593)))
(let (($x1090 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x983) true)))))
(and (not $x1090) (or $x1090 (and (distinct ?x593 ?x593) true)))))))
(check-sat)
; query 67: function gsm_L_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x132 (ite (bvsle (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x7 (or false false false)))
(let (($x576 (not $x7)))
(and $x576 (or $x7 (and (distinct ?x132 ?x132) true)))))))
(check-sat)
; query 68: function gsm_abs, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x23 (or false false)))
(let (($x1580 (not $x23)))
(and $x1580 (or $x23 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 69: function gsm_abs, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1858 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x23 (or false false)))
(let (($x1435 (or $x23 false false)))
(let (($x1864 (not $x1435)))
(and $x1864 (or $x1435 (and (distinct ?x1858 ?x1858) true))))))))
(check-sat)
; query 70: function gsm_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_64 () (_ BitVec 64))
(assert
 (let ((?x1855 (ite (bvslt (_ bv32767 64) in5_64) (_ bv1 1) (_ bv0 1))))
(let (($x7 (or false false false)))
(let (($x576 (not $x7)))
(and $x576 (or $x7 (and (distinct ?x1855 ?x1855) true)))))))
(check-sat)
; query 71: function gsm_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x23 (or false false)))
(let (($x1580 (not $x23)))
(and $x1580 (or $x23 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 72: function gsm_add, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x23 (or false false)))
(let (($x1580 (not $x23)))
(and $x1580 (or $x23 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 73: function gsm_add, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1404 ((_ sign_extend 48) in1_16)))
(let ((?x1898 ((_ sign_extend 48) in0_16)))
(let ((?x1879 (bvadd ?x1898 ?x1404)))
(let (($x1895 (and (distinct (bvadd ((_ sign_extend 1) ?x1898) ((_ sign_extend 1) ?x1404)) ((_ sign_extend 1) ?x1879)) true)))
(let (($x23 (or false false)))
(let (($x1911 (or $x23 $x23 (or $x1895))))
(and (not $x1911) (or $x1911 (and (distinct ?x1879 ?x1879) true))))))))))
(check-sat)
; query 74: function gsm_add, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1902 (ite (bvsgt (_ bv18446744073709518848 64) (bvadd ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x1404 ((_ sign_extend 48) in1_16)))
(let ((?x1890 ((_ sign_extend 1) ?x1404)))
(let ((?x1898 ((_ sign_extend 48) in0_16)))
(let ((?x1888 ((_ sign_extend 1) ?x1898)))
(let (($x23 (or false false)))
(let (($x1911 (or $x23 $x23 (or (and (distinct (bvadd ?x1888 ?x1890) ((_ sign_extend 1) (bvadd ?x1898 ?x1404))) true)))))
(let (($x1901 (or $x1911 false false)))
(and (not $x1901) (or $x1901 (and (distinct ?x1902 ?x1902) true))))))))))))
(check-sat)
; query 75: function gsm_asl, block 13, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1349 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x7 (or false false false)))
(let (($x576 (not $x7)))
(and $x576 (or $x7 (and (distinct ?x1349 ?x1349) true)))))))
(check-sat)
; query 76: function gsm_asl, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x23 (or false false)))
(let (($x1580 (not $x23)))
(and $x1580 (or $x23 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 77: function gsm_asl, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x402 ((_ sign_extend 16) in0_16)))
(let ((?x1625 (bvshl ?x402 in1_32)))
(let (($x23 (or false false)))
(let (($x1435 (or $x23 false false)))
(let (($x1903 (or $x1435 (bvuge in1_32 (_ bv32 32)))))
(let (($x1940 (not $x1903)))
(and $x1940 (or $x1903 (and (distinct ?x1625 ?x1625) true))))))))))
(check-sat)
; query 78: function gsm_asl, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x402 ((_ sign_extend 16) in0_16)))
(let ((?x1625 (bvshl ?x402 in1_32)))
(let ((?x1955 ((_ extract 15 0) ?x1625)))
(let (($x23 (or false false)))
(let (($x1435 (or $x23 false false)))
(let (($x1903 (or $x1435 (bvuge in1_32 (_ bv32 32)))))
(let (($x1954 (or $x1903 false)))
(let (($x414 (not $x1954)))
(and $x414 (or $x1954 (and (distinct ?x1955 ?x1955) true))))))))))))
(check-sat)
; query 79: function gsm_asl, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x241 (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x7 (or false false false)))
(let (($x576 (not $x7)))
(and $x576 (or $x7 (and (distinct ?x241 ?x241) true)))))))
(check-sat)
; query 80: function gsm_asl, block 7, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1858 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1962 ((_ zero_extend 31) ?x1858)))
(let (($x23 (or false false)))
(let (($x1435 (or $x23 false false)))
(let (($x1066 (or $x1435 false)))
(and (not $x1066) (or $x1066 (and (distinct ?x1962 ?x1962) true)))))))))
(check-sat)
; query 81: function gsm_asl, block 7, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1858 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1962 ((_ zero_extend 31) ?x1858)))
(let ((?x507 (bvsub (_ bv0 32) ?x1962)))
(let (($x276 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1962)) ((_ sign_extend 1) ?x507)) true)))
(let (($x23 (or false false)))
(let (($x1435 (or $x23 false false)))
(let (($x1066 (or $x1435 false)))
(let (($x641 (or false $x1066 (or $x276))))
(and (not $x641) (or $x641 (and (distinct ?x507 ?x507) true))))))))))))
(check-sat)
; query 82: function gsm_asl, block 7, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1858 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1962 ((_ zero_extend 31) ?x1858)))
(let ((?x507 (bvsub (_ bv0 32) ?x1962)))
(let ((?x1684 ((_ extract 15 0) ?x507)))
(let (($x276 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1962)) ((_ sign_extend 1) ?x507)) true)))
(let (($x23 (or false false)))
(let (($x1435 (or $x23 false false)))
(let (($x1066 (or $x1435 false)))
(let (($x641 (or false $x1066 (or $x276))))
(let (($x722 (or $x641 false)))
(and (not $x722) (or $x722 (and (distinct ?x1684 ?x1684) true))))))))))))))
(check-sat)
; query 83: function gsm_asl, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x23 (or false false)))
(let (($x1580 (not $x23)))
(and $x1580 (or $x23 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 84: function gsm_asl, block 7, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1858 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x23 (or false false)))
(let (($x1435 (or $x23 false false)))
(let (($x1864 (not $x1435)))
(and $x1864 (or $x1435 (and (distinct ?x1858 ?x1858) true))))))))
(check-sat)
; query 85: function gsm_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x109 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x7 (or false false false)))
(let (($x576 (not $x7)))
(and $x576 (or $x7 (and (distinct ?x109 ?x109) true)))))))
(check-sat)
; query 86: function gsm_asr, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x241 (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x7 (or false false false)))
(let (($x576 (not $x7)))
(and $x576 (or $x7 (and (distinct ?x241 ?x241) true)))))))
(check-sat)
; query 87: function gsm_asr, block 13, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1349 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x7 (or false false false)))
(let (($x576 (not $x7)))
(and $x576 (or $x7 (and (distinct ?x1349 ?x1349) true)))))))
(check-sat)
; query 88: function gsm_asr, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x23 (or false false)))
(let (($x1580 (not $x23)))
(and $x1580 (or $x23 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 89: function gsm_asr, block 15, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x261 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in1_32))) true)))
(let (($x142 (or false false (or $x261))))
(and (not $x142) (or $x142 (and (distinct (bvsub (_ bv0 32) in1_32) (bvsub (_ bv0 32) in1_32)) true))))))
(check-sat)
; query 90: function gsm_asr, block 15, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x813 (bvsub (_ bv0 32) in1_32)))
(let ((?x402 ((_ sign_extend 16) in0_16)))
(let ((?x905 (bvshl ?x402 ?x813)))
(let (($x261 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x813)) true)))
(let (($x142 (or false false (or $x261))))
(let (($x23 (or false false)))
(let (($x815 (or (or $x23 $x142 false) (bvuge ?x813 (_ bv32 32)))))
(and (not $x815) (or $x815 (and (distinct ?x905 ?x905) true)))))))))))
(check-sat)
; query 91: function gsm_asr, block 15, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x813 (bvsub (_ bv0 32) in1_32)))
(let ((?x402 ((_ sign_extend 16) in0_16)))
(let ((?x905 (bvshl ?x402 ?x813)))
(let ((?x164 ((_ extract 15 0) ?x905)))
(let (($x261 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x813)) true)))
(let (($x142 (or false false (or $x261))))
(let (($x23 (or false false)))
(let (($x815 (or (or $x23 $x142 false) (bvuge ?x813 (_ bv32 32)))))
(let (($x1629 (or $x815 false)))
(and (not $x1629) (or $x1629 (and (distinct ?x164 ?x164) true)))))))))))))
(check-sat)
; query 92: function gsm_asr, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x23 (or false false)))
(let (($x1580 (not $x23)))
(and $x1580 (or $x23 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 93: function gsm_asr, block 20, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x402 ((_ sign_extend 16) in0_16)))
(let ((?x232 (bvashr ?x402 in1_32)))
(let (($x23 (or false false)))
(let (($x1435 (or $x23 false false)))
(let (($x1903 (or $x1435 (bvuge in1_32 (_ bv32 32)))))
(let (($x1940 (not $x1903)))
(and $x1940 (or $x1903 (and (distinct ?x232 ?x232) true))))))))))
(check-sat)
; query 94: function gsm_asr, block 20, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x402 ((_ sign_extend 16) in0_16)))
(let ((?x232 (bvashr ?x402 in1_32)))
(let ((?x1969 ((_ extract 15 0) ?x232)))
(let (($x23 (or false false)))
(let (($x1435 (or $x23 false false)))
(let (($x1903 (or $x1435 (bvuge in1_32 (_ bv32 32)))))
(let (($x1954 (or $x1903 false)))
(let (($x414 (not $x1954)))
(and $x414 (or $x1954 (and (distinct ?x1969 ?x1969) true))))))))))))
(check-sat)
; query 95: function gsm_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x23 (or false false)))
(let (($x1580 (not $x23)))
(and $x1580 (or $x23 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 96: function gsm_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1858 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x23 (or false false)))
(let (($x1435 (or $x23 false false)))
(let (($x1864 (not $x1435)))
(and $x1864 (or $x1435 (and (distinct ?x1858 ?x1858) true))))))))
(check-sat)
; query 97: function gsm_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1858 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1962 ((_ zero_extend 31) ?x1858)))
(let (($x23 (or false false)))
(let (($x1435 (or $x23 false false)))
(let (($x1066 (or $x1435 false)))
(and (not $x1066) (or $x1066 (and (distinct ?x1962 ?x1962) true)))))))))
(check-sat)
; query 98: function gsm_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1858 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1962 ((_ zero_extend 31) ?x1858)))
(let ((?x507 (bvsub (_ bv0 32) ?x1962)))
(let (($x276 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1962)) ((_ sign_extend 1) ?x507)) true)))
(let (($x23 (or false false)))
(let (($x1435 (or $x23 false false)))
(let (($x1066 (or $x1435 false)))
(let (($x641 (or false $x1066 (or $x276))))
(and (not $x641) (or $x641 (and (distinct ?x507 ?x507) true))))))))))))
(check-sat)
; query 99: function gsm_asr, block 4, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1858 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1962 ((_ zero_extend 31) ?x1858)))
(let ((?x507 (bvsub (_ bv0 32) ?x1962)))
(let ((?x1684 ((_ extract 15 0) ?x507)))
(let (($x276 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1962)) ((_ sign_extend 1) ?x507)) true)))
(let (($x23 (or false false)))
(let (($x1435 (or $x23 false false)))
(let (($x1066 (or $x1435 false)))
(let (($x641 (or false $x1066 (or $x276))))
(let (($x722 (or $x641 false)))
(and (not $x722) (or $x722 (and (distinct ?x1684 ?x1684) true))))))))))))))
(check-sat)
; query 100: function gsm_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x109 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x7 (or false false false)))
(let (($x576 (not $x7)))
(and $x576 (or $x7 (and (distinct ?x109 ?x109) true)))))))
(check-sat)
; query 101: function gsm_debug_longwords, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in15_32 () (_ BitVec 32))
(assert
 (let ((?x1475 (ite (bvslt in15_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x7 (or false false false)))
(let (($x576 (not $x7)))
(and $x576 (or $x7 (and (distinct ?x1475 ?x1475) true)))))))
(check-sat)
; query 102: function gsm_debug_words, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in16_32 () (_ BitVec 32))
(assert
 (let ((?x665 (ite (bvslt in16_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x7 (or false false false)))
(let (($x576 (not $x7)))
(and $x576 (or $x7 (and (distinct ?x665 ?x665) true)))))))
(check-sat)
; query 103: function gsm_div, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x23 (or false false)))
(let (($x1580 (not $x23)))
(and $x1580 (or $x23 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 104: function gsm_div, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x23 (or false false)))
(let (($x1580 (not $x23)))
(and $x1580 (or $x23 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 105: function gsm_div, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x23 (or false false)))
(let (($x1580 (not $x23)))
(and $x1580 (or $x23 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 106: function gsm_div, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x52 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x208 (and (distinct ?x52 ?x52) true)))
(let (($x23 (or false false)))
(let (($x1435 (or $x23 false false)))
(let (($x1864 (not $x1435)))
(and $x1864 (or $x1435 $x208))))))))
(check-sat)
; query 107: function gsm_mult, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x23 (or false false)))
(let (($x1580 (not $x23)))
(and $x1580 (or $x23 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 108: function gsm_mult, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x948 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x23 (or false false)))
(let (($x1435 (or $x23 false false)))
(let (($x1864 (not $x1435)))
(and $x1864 (or $x1435 (and (distinct ?x948 ?x948) true))))))))
(check-sat)
; query 109: function gsm_mult, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x23 (or false false)))
(let (($x1580 (not $x23)))
(and $x1580 (or $x23 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 110: function gsm_mult, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x23 (or false false)))
(let (($x1580 (not $x23)))
(and $x1580 (or $x23 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 111: function gsm_mult, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1404 ((_ sign_extend 48) in1_16)))
(let ((?x1898 ((_ sign_extend 48) in0_16)))
(let ((?x1122 (bvmul ?x1898 ?x1404)))
(let (($x1346 (and (distinct (bvmul ((_ sign_extend 64) ?x1898) ((_ sign_extend 64) ?x1404)) ((_ sign_extend 64) ?x1122)) true)))
(let (($x23 (or false false)))
(let (($x571 (or $x23 $x23 (or $x1346))))
(and (not $x571) (or $x571 (and (distinct ?x1122 ?x1122) true))))))))))
(check-sat)
; query 112: function gsm_mult, block 9, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1404 ((_ sign_extend 48) in1_16)))
(let ((?x1898 ((_ sign_extend 48) in0_16)))
(let ((?x1122 (bvmul ?x1898 ?x1404)))
(let ((?x1973 (bvashr ?x1122 (_ bv15 64))))
(let (($x636 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1346 (and (distinct (bvmul ((_ sign_extend 64) ?x1898) ((_ sign_extend 64) ?x1404)) ((_ sign_extend 64) ?x1122)) true)))
(let (($x23 (or false false)))
(let (($x571 (or $x23 $x23 (or $x1346))))
(let (($x1972 (or (or $x571 false false) $x636)))
(and (not $x1972) (or $x1972 (and (distinct ?x1973 ?x1973) true)))))))))))))
(check-sat)
; query 113: function gsm_mult, block 9, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1404 ((_ sign_extend 48) in1_16)))
(let ((?x1898 ((_ sign_extend 48) in0_16)))
(let ((?x1122 (bvmul ?x1898 ?x1404)))
(let ((?x1973 (bvashr ?x1122 (_ bv15 64))))
(let ((?x754 ((_ extract 15 0) ?x1973)))
(let (($x636 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1346 (and (distinct (bvmul ((_ sign_extend 64) ?x1898) ((_ sign_extend 64) ?x1404)) ((_ sign_extend 64) ?x1122)) true)))
(let (($x23 (or false false)))
(let (($x571 (or $x23 $x23 (or $x1346))))
(let (($x1972 (or (or $x571 false false) $x636)))
(let (($x316 (or $x1972 false)))
(and (not $x316) (or $x316 (and (distinct ?x754 ?x754) true)))))))))))))))
(check-sat)
; query 114: function gsm_mult, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x23 (or false false)))
(let (($x1580 (not $x23)))
(and $x1580 (or $x23 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 115: function gsm_mult, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x997 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x23 (or false false)))
(let (($x1435 (or $x23 false false)))
(let (($x1864 (not $x1435)))
(and $x1864 (or $x1435 (and (distinct ?x997 ?x997) true))))))))
(check-sat)
; query 116: function gsm_mult_r, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x23 (or false false)))
(let (($x1580 (not $x23)))
(and $x1580 (or $x23 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 117: function gsm_mult_r, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x997 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x23 (or false false)))
(let (($x1435 (or $x23 false false)))
(let (($x1864 (not $x1435)))
(and $x1864 (or $x1435 (and (distinct ?x997 ?x997) true))))))))
(check-sat)
; query 118: function gsm_mult_r, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x23 (or false false)))
(let (($x1580 (not $x23)))
(and $x1580 (or $x23 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 119: function gsm_mult_r, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x23 (or false false)))
(let (($x1580 (not $x23)))
(and $x1580 (or $x23 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 120: function gsm_mult_r, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1404 ((_ sign_extend 48) in1_16)))
(let ((?x1898 ((_ sign_extend 48) in0_16)))
(let ((?x1122 (bvmul ?x1898 ?x1404)))
(let (($x1346 (and (distinct (bvmul ((_ sign_extend 64) ?x1898) ((_ sign_extend 64) ?x1404)) ((_ sign_extend 64) ?x1122)) true)))
(let (($x23 (or false false)))
(let (($x571 (or $x23 $x23 (or $x1346))))
(and (not $x571) (or $x571 (and (distinct ?x1122 ?x1122) true))))))))))
(check-sat)
; query 121: function gsm_mult_r, block 9, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1404 ((_ sign_extend 48) in1_16)))
(let ((?x1898 ((_ sign_extend 48) in0_16)))
(let ((?x1122 (bvmul ?x1898 ?x1404)))
(let ((?x2005 (bvadd ?x1122 (_ bv16384 64))))
(let (($x2002 (and (distinct (bvadd ((_ sign_extend 1) ?x1122) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x2005)) true)))
(let (($x1346 (and (distinct (bvmul ((_ sign_extend 64) ?x1898) ((_ sign_extend 64) ?x1404)) ((_ sign_extend 64) ?x1122)) true)))
(let (($x23 (or false false)))
(let (($x571 (or $x23 $x23 (or $x1346))))
(let (($x1998 (or $x571 false (or $x2002))))
(and (not $x1998) (or $x1998 (and (distinct ?x2005 ?x2005) true)))))))))))))
(check-sat)
; query 122: function gsm_mult_r, block 9, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1404 ((_ sign_extend 48) in1_16)))
(let ((?x1898 ((_ sign_extend 48) in0_16)))
(let ((?x1122 (bvmul ?x1898 ?x1404)))
(let ((?x2005 (bvadd ?x1122 (_ bv16384 64))))
(let ((?x2007 (bvashr ?x2005 (_ bv15 64))))
(let (($x636 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x2002 (and (distinct (bvadd ((_ sign_extend 1) ?x1122) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x2005)) true)))
(let (($x1346 (and (distinct (bvmul ((_ sign_extend 64) ?x1898) ((_ sign_extend 64) ?x1404)) ((_ sign_extend 64) ?x1122)) true)))
(let (($x23 (or false false)))
(let (($x571 (or $x23 $x23 (or $x1346))))
(let (($x1998 (or $x571 false (or $x2002))))
(let (($x2006 (or (or $x1998 false false) $x636)))
(and (not $x2006) (or $x2006 (and (distinct ?x2007 ?x2007) true))))))))))))))))
(check-sat)
; query 123: function gsm_mult_r, block 9, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1404 ((_ sign_extend 48) in1_16)))
(let ((?x1898 ((_ sign_extend 48) in0_16)))
(let ((?x1122 (bvmul ?x1898 ?x1404)))
(let ((?x2005 (bvadd ?x1122 (_ bv16384 64))))
(let ((?x2007 (bvashr ?x2005 (_ bv15 64))))
(let ((?x483 (bvand ?x2007 (_ bv65535 64))))
(let (($x636 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x2002 (and (distinct (bvadd ((_ sign_extend 1) ?x1122) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x2005)) true)))
(let (($x1346 (and (distinct (bvmul ((_ sign_extend 64) ?x1898) ((_ sign_extend 64) ?x1404)) ((_ sign_extend 64) ?x1122)) true)))
(let (($x23 (or false false)))
(let (($x571 (or $x23 $x23 (or $x1346))))
(let (($x1998 (or $x571 false (or $x2002))))
(let (($x2006 (or (or $x1998 false false) $x636)))
(let (($x2015 (or $x2006 false false)))
(and (not $x2015) (or $x2015 (and (distinct ?x483 ?x483) true))))))))))))))))))
(check-sat)
; query 124: function gsm_mult_r, block 9, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1404 ((_ sign_extend 48) in1_16)))
(let ((?x1898 ((_ sign_extend 48) in0_16)))
(let ((?x1122 (bvmul ?x1898 ?x1404)))
(let ((?x2005 (bvadd ?x1122 (_ bv16384 64))))
(let ((?x2007 (bvashr ?x2005 (_ bv15 64))))
(let ((?x483 (bvand ?x2007 (_ bv65535 64))))
(let ((?x2012 ((_ extract 15 0) ?x483)))
(let (($x636 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x2002 (and (distinct (bvadd ((_ sign_extend 1) ?x1122) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x2005)) true)))
(let (($x1346 (and (distinct (bvmul ((_ sign_extend 64) ?x1898) ((_ sign_extend 64) ?x1404)) ((_ sign_extend 64) ?x1122)) true)))
(let (($x23 (or false false)))
(let (($x571 (or $x23 $x23 (or $x1346))))
(let (($x1998 (or $x571 false (or $x2002))))
(let (($x2006 (or (or $x1998 false false) $x636)))
(let (($x2015 (or $x2006 false false)))
(let (($x2013 (or $x2015 false)))
(and (not $x2013) (or $x2013 (and (distinct ?x2012 ?x2012) true))))))))))))))))))))
(check-sat)
; query 125: function gsm_mult_r, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x23 (or false false)))
(let (($x1580 (not $x23)))
(and $x1580 (or $x23 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 126: function gsm_mult_r, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x948 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x23 (or false false)))
(let (($x1435 (or $x23 false false)))
(let (($x1864 (not $x1435)))
(and $x1864 (or $x1435 (and (distinct ?x948 ?x948) true))))))))
(check-sat)
; query 127: function gsm_norm, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2033 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x7 (or false false false)))
(let (($x576 (not $x7)))
(and $x576 (or $x7 (and (distinct ?x2033 ?x2033) true)))))))
(check-sat)
; query 128: function gsm_norm, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2033 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x2028 (bvxor ?x2033 (_ bv1 1))))
(let (($x7 (or false false false)))
(let (($x330 (or $x7 false false)))
(let (($x1319 (not $x330)))
(and $x1319 (or $x330 (and (distinct ?x2028 ?x2028) true)))))))))
(check-sat)
; query 129: function gsm_norm, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2033 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x2028 (bvxor ?x2033 (_ bv1 1))))
(let ((?x2029 ((_ zero_extend 31) ?x2028)))
(let (($x7 (or false false false)))
(let (($x330 (or $x7 false false)))
(let (($x2036 (or $x330 false)))
(and (not $x2036) (or $x2036 (and (distinct ?x2029 ?x2029) true))))))))))
(check-sat)
; query 130: function gsm_norm, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2033 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x2028 (bvxor ?x2033 (_ bv1 1))))
(let ((?x2029 ((_ zero_extend 31) ?x2028)))
(let ((?x2037 ((_ sign_extend 32) ?x2029)))
(let (($x7 (or false false false)))
(let (($x330 (or $x7 false false)))
(let (($x2036 (or $x330 false)))
(let (($x2044 (or $x2036 false)))
(and (not $x2044) (or $x2044 (and (distinct ?x2037 ?x2037) true))))))))))))
(check-sat)
; query 131: function gsm_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_64 () (_ BitVec 64))
(assert
 (let ((?x1855 (ite (bvslt (_ bv32767 64) in5_64) (_ bv1 1) (_ bv0 1))))
(let (($x7 (or false false false)))
(let (($x576 (not $x7)))
(and $x576 (or $x7 (and (distinct ?x1855 ?x1855) true)))))))
(check-sat)
; query 132: function gsm_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x23 (or false false)))
(let (($x1580 (not $x23)))
(and $x1580 (or $x23 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 133: function gsm_sub, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x23 (or false false)))
(let (($x1580 (not $x23)))
(and $x1580 (or $x23 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 134: function gsm_sub, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1404 ((_ sign_extend 48) in1_16)))
(let ((?x1898 ((_ sign_extend 48) in0_16)))
(let ((?x2042 (bvsub ?x1898 ?x1404)))
(let (($x2064 (and (distinct (bvsub ((_ sign_extend 1) ?x1898) ((_ sign_extend 1) ?x1404)) ((_ sign_extend 1) ?x2042)) true)))
(let (($x23 (or false false)))
(let (($x713 (or $x23 $x23 (or $x2064))))
(and (not $x713) (or $x713 (and (distinct ?x2042 ?x2042) true))))))))))
(check-sat)
; query 135: function gsm_sub, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x2058 (ite (bvsgt (_ bv18446744073709518848 64) (bvsub ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x1404 ((_ sign_extend 48) in1_16)))
(let ((?x1890 ((_ sign_extend 1) ?x1404)))
(let ((?x1898 ((_ sign_extend 48) in0_16)))
(let ((?x1888 ((_ sign_extend 1) ?x1898)))
(let (($x23 (or false false)))
(let (($x713 (or $x23 $x23 (or (and (distinct (bvsub ?x1888 ?x1890) ((_ sign_extend 1) (bvsub ?x1898 ?x1404))) true)))))
(let (($x2063 (or $x713 false false)))
(and (not $x2063) (or $x2063 (and (distinct ?x2058 ?x2058) true))))))))))))
(check-sat)
; query 136: function ok_to_replace, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x2076 (ite (and (distinct (_ bv4294967295 32) in.01_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x7 (or false false false)))
(let (($x576 (not $x7)))
(and $x576 (or $x7 (and (distinct ?x2076 ?x2076) true)))))))
(check-sat)
; query 137: function ok_to_replace, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in16_32 () (_ BitVec 32))
(assert
 (let ((?x2083 (ite (= (_ bv121 32) in16_32) (_ bv1 1) (_ bv0 1))))
(let (($x7 (or false false false)))
(let (($x576 (not $x7)))
(and $x576 (or $x7 (and (distinct ?x2083 ?x2083) true)))))))
(check-sat)
; query 138: function suffix, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_64 () (_ BitVec 64))
(declare-fun in3_64 () (_ BitVec 64))
(assert
 (let ((?x2100 (ite (bvule in3_64 in4_64) (_ bv1 1) (_ bv0 1))))
(let (($x7 (or false false false)))
(let (($x576 (not $x7)))
(and $x576 (or $x7 (and (distinct ?x2100 ?x2100) true)))))))
(check-sat)
; query 139: function ulaw_input, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x39 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x1193 (or false false (or $x39))))
(and (not $x1193) (or $x1193 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 140: function ulaw_input, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let ((?x235 (ite (= (_ bv4294967295 32) in.1_32) (_ bv1 1) (_ bv0 1))))
(let (($x7 (or false false false)))
(let (($x576 (not $x7)))
(and $x576 (or $x7 (and (distinct ?x235 ?x235) true)))))))
(check-sat)
