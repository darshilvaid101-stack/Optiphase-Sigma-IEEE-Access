; OptiPhase-Sigma refinement certificate for sweep K48-R2-022
; query 0: function APCM_inverse_quantization, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in53_16) ((_ sign_extend 16) in53_16)) true))))))
(check-sat)
; query 1: function APCM_inverse_quantization, block 56, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let ((?x127 (ite (bvsle (_ bv4294967289 32) ((_ sign_extend 16) in53_16)) (_ bv1 1) (_ bv0 1))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x128 (not $x145)))
(and $x128 (or $x145 (and (distinct ?x127 ?x127) true))))))))
(check-sat)
; query 2: function APCM_inverse_quantization, block 68, name %69
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in53_16) ((_ sign_extend 16) in53_16)) true))))))
(check-sat)
; query 3: function APCM_inverse_quantization, block 68, name %70
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let ((?x859 ((_ sign_extend 16) in53_16)))
(let ((?x241 (bvshl ?x859 (_ bv12 32))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x65 (or $x145 (bvuge (_ bv12 32) (_ bv32 32)))))
(and (not $x65) (or $x65 (and (distinct ?x241 ?x241) true)))))))))
(check-sat)
; query 4: function APCM_inverse_quantization, block 68, name %71
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let ((?x859 ((_ sign_extend 16) in53_16)))
(let ((?x241 (bvshl ?x859 (_ bv12 32))))
(let ((?x79 ((_ extract 15 0) ?x241)))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x65 (or $x145 (bvuge (_ bv12 32) (_ bv32 32)))))
(let (($x75 (or $x65 false)))
(and (not $x75) (or $x75 (and (distinct ?x79 ?x79) true)))))))))))
(check-sat)
; query 5: function APCM_inverse_quantization, block 68, name %72
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in22_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 48) in22_16) ((_ sign_extend 48) in22_16)) true))))))
(check-sat)
; query 6: function APCM_inverse_quantization, block 68, name %73
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let ((?x859 ((_ sign_extend 16) in53_16)))
(let ((?x241 (bvshl ?x859 (_ bv12 32))))
(let ((?x79 ((_ extract 15 0) ?x241)))
(let ((?x222 ((_ sign_extend 48) ?x79)))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x65 (or $x145 (bvuge (_ bv12 32) (_ bv32 32)))))
(let (($x75 (or $x65 false)))
(let (($x36 (or $x75 false)))
(and (not $x36) (or $x36 (and (distinct ?x222 ?x222) true)))))))))))))
(check-sat)
; query 7: function APCM_inverse_quantization, block 68, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in22_16 () (_ BitVec 16))
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let ((?x55 ((_ sign_extend 48) in22_16)))
(let ((?x859 ((_ sign_extend 16) in53_16)))
(let ((?x241 (bvshl ?x859 (_ bv12 32))))
(let ((?x79 ((_ extract 15 0) ?x241)))
(let ((?x222 ((_ sign_extend 48) ?x79)))
(let ((?x87 (bvmul ?x222 ?x55)))
(let ((?x323 (bvmul ?x55 ?x222)))
(let (($x1011 (and (distinct (bvmul ((_ sign_extend 64) ?x222) ((_ sign_extend 64) ?x55)) ((_ sign_extend 64) ?x87)) true)))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x65 (or $x145 (bvuge (_ bv12 32) (_ bv32 32)))))
(let (($x75 (or $x65 false)))
(let (($x36 (or $x75 false)))
(let (($x50 (or $x36 $x16 (or $x1011))))
(let (($x224 (and (distinct (bvmul ((_ sign_extend 64) ?x55) ((_ sign_extend 64) ?x222)) ((_ sign_extend 64) ?x323)) true)))
(let (($x56 (or $x16 $x36 (or $x224))))
(and (not $x56) (or $x50 (and (distinct ?x323 ?x87) true))))))))))))))))))))
(check-sat)
; query 8: function APCM_inverse_quantization, block 68, name %75
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in22_16 () (_ BitVec 16))
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let ((?x55 ((_ sign_extend 48) in22_16)))
(let ((?x859 ((_ sign_extend 16) in53_16)))
(let ((?x241 (bvshl ?x859 (_ bv12 32))))
(let ((?x79 ((_ extract 15 0) ?x241)))
(let ((?x222 ((_ sign_extend 48) ?x79)))
(let ((?x87 (bvmul ?x222 ?x55)))
(let ((?x644 (bvadd ?x87 (_ bv16384 64))))
(let ((?x323 (bvmul ?x55 ?x222)))
(let ((?x181 (bvadd ?x323 (_ bv16384 64))))
(let (($x306 (and (distinct (bvadd ((_ sign_extend 1) ?x87) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x644)) true)))
(let (($x1011 (and (distinct (bvmul ((_ sign_extend 64) ?x222) ((_ sign_extend 64) ?x55)) ((_ sign_extend 64) ?x87)) true)))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x65 (or $x145 (bvuge (_ bv12 32) (_ bv32 32)))))
(let (($x75 (or $x65 false)))
(let (($x36 (or $x75 false)))
(let (($x50 (or $x36 $x16 (or $x1011))))
(let (($x281 (or $x50 false (or $x306))))
(let (($x11 (and (distinct (bvadd ((_ sign_extend 1) ?x323) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x181)) true)))
(let (($x224 (and (distinct (bvmul ((_ sign_extend 64) ?x55) ((_ sign_extend 64) ?x222)) ((_ sign_extend 64) ?x323)) true)))
(let (($x56 (or $x16 $x36 (or $x224))))
(let (($x61 (or $x56 false (or $x11))))
(and (not $x61) (or $x281 (and (distinct ?x181 ?x644) true))))))))))))))))))))))))))
(check-sat)
; query 9: function APCM_inverse_quantization, block 68, name %76
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in22_16 () (_ BitVec 16))
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let ((?x55 ((_ sign_extend 48) in22_16)))
(let ((?x859 ((_ sign_extend 16) in53_16)))
(let ((?x241 (bvshl ?x859 (_ bv12 32))))
(let ((?x79 ((_ extract 15 0) ?x241)))
(let ((?x222 ((_ sign_extend 48) ?x79)))
(let ((?x87 (bvmul ?x222 ?x55)))
(let ((?x644 (bvadd ?x87 (_ bv16384 64))))
(let ((?x133 (bvashr ?x644 (_ bv15 64))))
(let ((?x323 (bvmul ?x55 ?x222)))
(let ((?x181 (bvadd ?x323 (_ bv16384 64))))
(let ((?x273 (bvashr ?x181 (_ bv15 64))))
(let (($x131 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x306 (and (distinct (bvadd ((_ sign_extend 1) ?x87) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x644)) true)))
(let (($x1011 (and (distinct (bvmul ((_ sign_extend 64) ?x222) ((_ sign_extend 64) ?x55)) ((_ sign_extend 64) ?x87)) true)))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x65 (or $x145 (bvuge (_ bv12 32) (_ bv32 32)))))
(let (($x75 (or $x65 false)))
(let (($x36 (or $x75 false)))
(let (($x50 (or $x36 $x16 (or $x1011))))
(let (($x281 (or $x50 false (or $x306))))
(let (($x638 (or (or $x281 false false) $x131)))
(let (($x11 (and (distinct (bvadd ((_ sign_extend 1) ?x323) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x181)) true)))
(let (($x224 (and (distinct (bvmul ((_ sign_extend 64) ?x55) ((_ sign_extend 64) ?x222)) ((_ sign_extend 64) ?x323)) true)))
(let (($x56 (or $x16 $x36 (or $x224))))
(let (($x61 (or $x56 false (or $x11))))
(let (($x331 (or (or $x61 false false) $x131)))
(and (not $x331) (or $x638 (and (distinct ?x273 ?x133) true)))))))))))))))))))))))))))))))
(check-sat)
; query 10: function APCM_inverse_quantization, block 68, name %77
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in22_16 () (_ BitVec 16))
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let ((?x55 ((_ sign_extend 48) in22_16)))
(let ((?x859 ((_ sign_extend 16) in53_16)))
(let ((?x241 (bvshl ?x859 (_ bv12 32))))
(let ((?x79 ((_ extract 15 0) ?x241)))
(let ((?x222 ((_ sign_extend 48) ?x79)))
(let ((?x87 (bvmul ?x222 ?x55)))
(let ((?x644 (bvadd ?x87 (_ bv16384 64))))
(let ((?x133 (bvashr ?x644 (_ bv15 64))))
(let ((?x223 ((_ extract 15 0) ?x133)))
(let ((?x323 (bvmul ?x55 ?x222)))
(let ((?x181 (bvadd ?x323 (_ bv16384 64))))
(let ((?x273 (bvashr ?x181 (_ bv15 64))))
(let ((?x105 ((_ extract 15 0) ?x273)))
(let (($x131 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x306 (and (distinct (bvadd ((_ sign_extend 1) ?x87) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x644)) true)))
(let (($x1011 (and (distinct (bvmul ((_ sign_extend 64) ?x222) ((_ sign_extend 64) ?x55)) ((_ sign_extend 64) ?x87)) true)))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x65 (or $x145 (bvuge (_ bv12 32) (_ bv32 32)))))
(let (($x75 (or $x65 false)))
(let (($x36 (or $x75 false)))
(let (($x50 (or $x36 $x16 (or $x1011))))
(let (($x281 (or $x50 false (or $x306))))
(let (($x638 (or (or $x281 false false) $x131)))
(let (($x552 (or $x638 false)))
(let (($x11 (and (distinct (bvadd ((_ sign_extend 1) ?x323) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x181)) true)))
(let (($x224 (and (distinct (bvmul ((_ sign_extend 64) ?x55) ((_ sign_extend 64) ?x222)) ((_ sign_extend 64) ?x323)) true)))
(let (($x56 (or $x16 $x36 (or $x224))))
(let (($x61 (or $x56 false (or $x11))))
(let (($x331 (or (or $x61 false false) $x131)))
(let (($x124 (or $x331 false)))
(and (not $x124) (or $x552 (and (distinct ?x105 ?x223) true)))))))))))))))))))))))))))))))))))
(check-sat)
; query 11: function APCM_inverse_quantization, block 68, name %78
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in22_16 () (_ BitVec 16))
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let ((?x55 ((_ sign_extend 48) in22_16)))
(let ((?x859 ((_ sign_extend 16) in53_16)))
(let ((?x241 (bvshl ?x859 (_ bv12 32))))
(let ((?x79 ((_ extract 15 0) ?x241)))
(let ((?x222 ((_ sign_extend 48) ?x79)))
(let ((?x87 (bvmul ?x222 ?x55)))
(let ((?x644 (bvadd ?x87 (_ bv16384 64))))
(let ((?x133 (bvashr ?x644 (_ bv15 64))))
(let ((?x223 ((_ extract 15 0) ?x133)))
(let ((?x22 ((_ sign_extend 48) ?x223)))
(let ((?x323 (bvmul ?x55 ?x222)))
(let ((?x181 (bvadd ?x323 (_ bv16384 64))))
(let ((?x273 (bvashr ?x181 (_ bv15 64))))
(let ((?x105 ((_ extract 15 0) ?x273)))
(let ((?x1019 ((_ sign_extend 48) ?x105)))
(let (($x131 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x306 (and (distinct (bvadd ((_ sign_extend 1) ?x87) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x644)) true)))
(let (($x1011 (and (distinct (bvmul ((_ sign_extend 64) ?x222) ((_ sign_extend 64) ?x55)) ((_ sign_extend 64) ?x87)) true)))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x65 (or $x145 (bvuge (_ bv12 32) (_ bv32 32)))))
(let (($x75 (or $x65 false)))
(let (($x36 (or $x75 false)))
(let (($x50 (or $x36 $x16 (or $x1011))))
(let (($x281 (or $x50 false (or $x306))))
(let (($x638 (or (or $x281 false false) $x131)))
(let (($x552 (or $x638 false)))
(let (($x94 (or $x552 false)))
(let (($x11 (and (distinct (bvadd ((_ sign_extend 1) ?x323) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x181)) true)))
(let (($x224 (and (distinct (bvmul ((_ sign_extend 64) ?x55) ((_ sign_extend 64) ?x222)) ((_ sign_extend 64) ?x323)) true)))
(let (($x56 (or $x16 $x36 (or $x224))))
(let (($x61 (or $x56 false (or $x11))))
(let (($x331 (or (or $x61 false false) $x131)))
(let (($x124 (or $x331 false)))
(let (($x9 (or $x124 false)))
(and (not $x9) (or $x94 (and (distinct ?x1019 ?x22) true)))))))))))))))))))))))))))))))))))))))
(check-sat)
; query 12: function APCM_inverse_quantization, block 68, name %79
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in26_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 48) in26_16) ((_ sign_extend 48) in26_16)) true))))))
(check-sat)
; query 13: function APCM_inverse_quantization, block 68, name %80
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in26_16 () (_ BitVec 16))
(declare-fun in22_16 () (_ BitVec 16))
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let ((?x112 ((_ sign_extend 48) in26_16)))
(let ((?x55 ((_ sign_extend 48) in22_16)))
(let ((?x859 ((_ sign_extend 16) in53_16)))
(let ((?x241 (bvshl ?x859 (_ bv12 32))))
(let ((?x79 ((_ extract 15 0) ?x241)))
(let ((?x222 ((_ sign_extend 48) ?x79)))
(let ((?x87 (bvmul ?x222 ?x55)))
(let ((?x644 (bvadd ?x87 (_ bv16384 64))))
(let ((?x133 (bvashr ?x644 (_ bv15 64))))
(let ((?x223 ((_ extract 15 0) ?x133)))
(let ((?x22 ((_ sign_extend 48) ?x223)))
(let ((?x23 (bvadd ?x22 ?x112)))
(let ((?x323 (bvmul ?x55 ?x222)))
(let ((?x181 (bvadd ?x323 (_ bv16384 64))))
(let ((?x273 (bvashr ?x181 (_ bv15 64))))
(let ((?x105 ((_ extract 15 0) ?x273)))
(let ((?x1019 ((_ sign_extend 48) ?x105)))
(let ((?x514 (bvadd ?x1019 ?x112)))
(let ((?x733 ((_ sign_extend 1) ?x23)))
(let (($x16 (or false false)))
(let (($x131 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x306 (and (distinct (bvadd ((_ sign_extend 1) ?x87) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x644)) true)))
(let (($x1011 (and (distinct (bvmul ((_ sign_extend 64) ?x222) ((_ sign_extend 64) ?x55)) ((_ sign_extend 64) ?x87)) true)))
(let (($x145 (or $x16 false false)))
(let (($x65 (or $x145 (bvuge (_ bv12 32) (_ bv32 32)))))
(let (($x75 (or $x65 false)))
(let (($x36 (or $x75 false)))
(let (($x50 (or $x36 $x16 (or $x1011))))
(let (($x281 (or $x50 false (or $x306))))
(let (($x638 (or (or $x281 false false) $x131)))
(let (($x552 (or $x638 false)))
(let (($x94 (or $x552 false)))
(let (($x494 (or $x94 $x16 (or (and (distinct (bvadd ((_ sign_extend 1) ?x22) ((_ sign_extend 1) ?x112)) ?x733) true)))))
(let ((?x135 ((_ sign_extend 1) ?x514)))
(let (($x11 (and (distinct (bvadd ((_ sign_extend 1) ?x323) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x181)) true)))
(let (($x224 (and (distinct (bvmul ((_ sign_extend 64) ?x55) ((_ sign_extend 64) ?x222)) ((_ sign_extend 64) ?x323)) true)))
(let (($x56 (or $x16 $x36 (or $x224))))
(let (($x61 (or $x56 false (or $x11))))
(let (($x331 (or (or $x61 false false) $x131)))
(let (($x124 (or $x331 false)))
(let (($x9 (or $x124 false)))
(let (($x413 (or $x9 $x16 (or (and (distinct (bvadd ((_ sign_extend 1) ?x1019) ((_ sign_extend 1) ?x112)) ?x135) true)))))
(and (not $x413) (or $x494 (and (distinct ?x514 ?x23) true))))))))))))))))))))))))))))))))))))))))))))))
(check-sat)
; query 14: function APCM_inverse_quantization, block 68, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in26_16 () (_ BitVec 16))
(declare-fun in22_16 () (_ BitVec 16))
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let ((?x112 ((_ sign_extend 48) in26_16)))
(let ((?x55 ((_ sign_extend 48) in22_16)))
(let ((?x859 ((_ sign_extend 16) in53_16)))
(let ((?x241 (bvshl ?x859 (_ bv12 32))))
(let ((?x79 ((_ extract 15 0) ?x241)))
(let ((?x222 ((_ sign_extend 48) ?x79)))
(let ((?x87 (bvmul ?x222 ?x55)))
(let ((?x644 (bvadd ?x87 (_ bv16384 64))))
(let ((?x133 (bvashr ?x644 (_ bv15 64))))
(let ((?x223 ((_ extract 15 0) ?x133)))
(let ((?x22 ((_ sign_extend 48) ?x223)))
(let ((?x23 (bvadd ?x22 ?x112)))
(let ((?x148 (bvsub ?x23 (_ bv18446744073709518848 64))))
(let ((?x323 (bvmul ?x55 ?x222)))
(let ((?x181 (bvadd ?x323 (_ bv16384 64))))
(let ((?x273 (bvashr ?x181 (_ bv15 64))))
(let ((?x105 ((_ extract 15 0) ?x273)))
(let ((?x1019 ((_ sign_extend 48) ?x105)))
(let ((?x514 (bvadd ?x1019 ?x112)))
(let ((?x107 (bvsub ?x514 (_ bv18446744073709518848 64))))
(let (($x151 (and (distinct (bvsub ((_ sign_extend 1) ?x23) ((_ sign_extend 1) (_ bv18446744073709518848 64))) ((_ sign_extend 1) ?x148)) true)))
(let ((?x733 ((_ sign_extend 1) ?x23)))
(let (($x16 (or false false)))
(let (($x131 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x306 (and (distinct (bvadd ((_ sign_extend 1) ?x87) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x644)) true)))
(let (($x1011 (and (distinct (bvmul ((_ sign_extend 64) ?x222) ((_ sign_extend 64) ?x55)) ((_ sign_extend 64) ?x87)) true)))
(let (($x145 (or $x16 false false)))
(let (($x65 (or $x145 (bvuge (_ bv12 32) (_ bv32 32)))))
(let (($x75 (or $x65 false)))
(let (($x36 (or $x75 false)))
(let (($x50 (or $x36 $x16 (or $x1011))))
(let (($x281 (or $x50 false (or $x306))))
(let (($x638 (or (or $x281 false false) $x131)))
(let (($x552 (or $x638 false)))
(let (($x94 (or $x552 false)))
(let (($x494 (or $x94 $x16 (or (and (distinct (bvadd ((_ sign_extend 1) ?x22) ((_ sign_extend 1) ?x112)) ?x733) true)))))
(let (($x211 (or $x494 false (or $x151))))
(let (($x152 (and (distinct (bvsub ((_ sign_extend 1) ?x514) ((_ sign_extend 1) (_ bv18446744073709518848 64))) ((_ sign_extend 1) ?x107)) true)))
(let ((?x135 ((_ sign_extend 1) ?x514)))
(let (($x11 (and (distinct (bvadd ((_ sign_extend 1) ?x323) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x181)) true)))
(let (($x224 (and (distinct (bvmul ((_ sign_extend 64) ?x55) ((_ sign_extend 64) ?x222)) ((_ sign_extend 64) ?x323)) true)))
(let (($x56 (or $x16 $x36 (or $x224))))
(let (($x61 (or $x56 false (or $x11))))
(let (($x331 (or (or $x61 false false) $x131)))
(let (($x124 (or $x331 false)))
(let (($x9 (or $x124 false)))
(let (($x413 (or $x9 $x16 (or (and (distinct (bvadd ((_ sign_extend 1) ?x1019) ((_ sign_extend 1) ?x112)) ?x135) true)))))
(let (($x292 (or $x413 false (or $x152))))
(and (not $x292) (or $x211 (and (distinct ?x107 ?x148) true))))))))))))))))))))))))))))))))))))))))))))))))))))
(check-sat)
; query 15: function APCM_inverse_quantization, block 68, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in26_16 () (_ BitVec 16))
(declare-fun in22_16 () (_ BitVec 16))
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let ((?x112 ((_ sign_extend 48) in26_16)))
(let ((?x55 ((_ sign_extend 48) in22_16)))
(let ((?x859 ((_ sign_extend 16) in53_16)))
(let ((?x241 (bvshl ?x859 (_ bv12 32))))
(let ((?x79 ((_ extract 15 0) ?x241)))
(let ((?x222 ((_ sign_extend 48) ?x79)))
(let ((?x87 (bvmul ?x222 ?x55)))
(let ((?x644 (bvadd ?x87 (_ bv16384 64))))
(let ((?x133 (bvashr ?x644 (_ bv15 64))))
(let ((?x223 ((_ extract 15 0) ?x133)))
(let ((?x22 ((_ sign_extend 48) ?x223)))
(let ((?x23 (bvadd ?x22 ?x112)))
(let ((?x148 (bvsub ?x23 (_ bv18446744073709518848 64))))
(let ((?x323 (bvmul ?x55 ?x222)))
(let ((?x181 (bvadd ?x323 (_ bv16384 64))))
(let ((?x273 (bvashr ?x181 (_ bv15 64))))
(let ((?x105 ((_ extract 15 0) ?x273)))
(let ((?x1019 ((_ sign_extend 48) ?x105)))
(let ((?x514 (bvadd ?x1019 ?x112)))
(let ((?x107 (bvsub ?x514 (_ bv18446744073709518848 64))))
(let (($x229 (and (distinct (ite (bvugt ?x107 (_ bv65535 64)) (_ bv1 1) (_ bv0 1)) (ite (bvugt ?x148 (_ bv65535 64)) (_ bv1 1) (_ bv0 1))) true)))
(let (($x151 (and (distinct (bvsub ((_ sign_extend 1) ?x23) ((_ sign_extend 1) (_ bv18446744073709518848 64))) ((_ sign_extend 1) ?x148)) true)))
(let ((?x733 ((_ sign_extend 1) ?x23)))
(let (($x16 (or false false)))
(let (($x131 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x306 (and (distinct (bvadd ((_ sign_extend 1) ?x87) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x644)) true)))
(let (($x1011 (and (distinct (bvmul ((_ sign_extend 64) ?x222) ((_ sign_extend 64) ?x55)) ((_ sign_extend 64) ?x87)) true)))
(let (($x145 (or $x16 false false)))
(let (($x65 (or $x145 (bvuge (_ bv12 32) (_ bv32 32)))))
(let (($x75 (or $x65 false)))
(let (($x36 (or $x75 false)))
(let (($x50 (or $x36 $x16 (or $x1011))))
(let (($x281 (or $x50 false (or $x306))))
(let (($x638 (or (or $x281 false false) $x131)))
(let (($x552 (or $x638 false)))
(let (($x94 (or $x552 false)))
(let (($x494 (or $x94 $x16 (or (and (distinct (bvadd ((_ sign_extend 1) ?x22) ((_ sign_extend 1) ?x112)) ?x733) true)))))
(let (($x211 (or $x494 false (or $x151))))
(let (($x152 (and (distinct (bvsub ((_ sign_extend 1) ?x514) ((_ sign_extend 1) (_ bv18446744073709518848 64))) ((_ sign_extend 1) ?x107)) true)))
(let ((?x135 ((_ sign_extend 1) ?x514)))
(let (($x11 (and (distinct (bvadd ((_ sign_extend 1) ?x323) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x181)) true)))
(let (($x224 (and (distinct (bvmul ((_ sign_extend 64) ?x55) ((_ sign_extend 64) ?x222)) ((_ sign_extend 64) ?x323)) true)))
(let (($x56 (or $x16 $x36 (or $x224))))
(let (($x61 (or $x56 false (or $x11))))
(let (($x331 (or (or $x61 false false) $x131)))
(let (($x124 (or $x331 false)))
(let (($x9 (or $x124 false)))
(let (($x413 (or $x9 $x16 (or (and (distinct (bvadd ((_ sign_extend 1) ?x1019) ((_ sign_extend 1) ?x112)) ?x135) true)))))
(let (($x292 (or $x413 false (or $x152))))
(and (not (or $x292 false false)) (or (or $x211 false false) $x229))))))))))))))))))))))))))))))))))))))))))))))))))))
(check-sat)
; query 16: function APCM_inverse_quantization, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 17: function APCM_inverse_quantization, block 7, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x62 (ite (bvsge (_ bv7 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x128 (not $x145)))
(and $x128 (or $x145 (and (distinct ?x62 ?x62) true))))))))
(check-sat)
; query 18: function APCM_inverse_quantization, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 19: function APCM_inverse_quantization, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x219 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x128 (not $x145)))
(and $x128 (or $x145 (and (distinct ?x219 ?x219) true))))))))
(check-sat)
; query 20: function APCM_quantization, block 159, name %160
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in152_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in152_16) ((_ sign_extend 16) in152_16)) true))))))
(check-sat)
; query 21: function APCM_quantization, block 159, name %161
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in152_16 () (_ BitVec 16))
(assert
 (let ((?x33 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in152_16)) (_ bv1 1) (_ bv0 1))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x128 (not $x145)))
(and $x128 (or $x145 (and (distinct ?x33 ?x33) true))))))))
(check-sat)
; query 22: function APCM_quantization, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in13_16) ((_ sign_extend 16) in13_16)) true))))))
(check-sat)
; query 23: function APCM_quantization, block 16, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_16 () (_ BitVec 16))
(assert
 (let ((?x54 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in13_16)) (_ bv1 1) (_ bv0 1))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x128 (not $x145)))
(and $x128 (or $x145 (and (distinct ?x54 ?x54) true))))))))
(check-sat)
; query 24: function APCM_quantization, block 162, name %163
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in152_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in152_16) ((_ sign_extend 16) in152_16)) true))))))
(check-sat)
; query 25: function APCM_quantization, block 162, name %164
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in152_16 () (_ BitVec 16))
(assert
 (let ((?x171 (ite (bvsgt (_ bv16 32) ((_ sign_extend 16) in152_16)) (_ bv1 1) (_ bv0 1))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x128 (not $x145)))
(and $x128 (or $x145 (and (distinct ?x171 ?x171) true))))))))
(check-sat)
; query 26: function APCM_quantization, block 195, name %196
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let (($x1049 (and (distinct (bvadd ((_ sign_extend 1) in.2_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.2_32 (_ bv1 32)))) true)))
(let (($x250 (or false false (or $x1049))))
(and (not $x250) (or $x250 (and (distinct (bvadd in.2_32 (_ bv1 32)) (bvadd in.2_32 (_ bv1 32))) true))))))
(check-sat)
; query 27: function APCM_quantization, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in13_16) ((_ sign_extend 16) in13_16)) true))))))
(check-sat)
; query 28: function APCM_quantization, block 20, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_16 () (_ BitVec 16))
(assert
 (let ((?x176 ((_ sign_extend 16) in13_16)))
(let ((?x129 (bvsub (_ bv0 32) ?x176)))
(let (($x862 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x176)) ((_ sign_extend 1) ?x129)) true)))
(let (($x16 (or false false)))
(let (($x188 (or false $x16 (or $x862))))
(and (not $x188) (or $x188 (and (distinct ?x129 ?x129) true)))))))))
(check-sat)
; query 29: function APCM_quantization, block 25, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in13_16) ((_ sign_extend 16) in13_16)) true))))))
(check-sat)
; query 30: function APCM_quantization, block 35, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_32 () (_ BitVec 32))
(assert
 (let (($x84 (and (distinct (bvadd ((_ sign_extend 1) in.03_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.03_32 (_ bv1 32)))) true)))
(let (($x895 (or false false (or $x84))))
(and (not $x895) (or $x895 (and (distinct (bvadd in.03_32 (_ bv1 32)) (bvadd in.03_32 (_ bv1 32))) true))))))
(check-sat)
; query 31: function APCM_quantization, block 61, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in47_32 () (_ BitVec 32))
(assert
 (let ((?x575 (ite (= (_ bv0 32) in47_32) (_ bv1 1) (_ bv0 1))))
(let (($x484 (or false false false)))
(let (($x225 (not $x484)))
(and $x225 (or $x484 (and (distinct ?x575 ?x575) true)))))))
(check-sat)
; query 32: function APCM_quantization, block 67, name %68
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.14_32 () (_ BitVec 32))
(assert
 (let (($x872 (and (distinct (bvadd ((_ sign_extend 1) in.14_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.14_32 (_ bv1 32)))) true)))
(let (($x535 (or false false (or $x872))))
(and (not $x535) (or $x535 (and (distinct (bvadd in.14_32 (_ bv1 32)) (bvadd in.14_32 (_ bv1 32))) true))))))
(check-sat)
; query 33: function APCM_quantization, block 93, name %94
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in90_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in90_16) ((_ sign_extend 16) in90_16)) true))))))
(check-sat)
; query 34: function APCM_quantization, block 93, name %95
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in90_16 () (_ BitVec 16))
(assert
 (let ((?x524 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in90_16)) (_ bv1 1) (_ bv0 1))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x128 (not $x145)))
(and $x128 (or $x145 (and (distinct ?x524 ?x524) true))))))))
(check-sat)
; query 35: function APCM_quantization_xmaxc_to_exp_mant, block 24, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in.0_16) ((_ sign_extend 16) in.0_16)) true))))))
(check-sat)
; query 36: function APCM_quantization_xmaxc_to_exp_mant, block 24, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let ((?x235 ((_ sign_extend 16) in.0_16)))
(let ((?x385 (bvshl ?x235 (_ bv1 32))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x408 (or $x145 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x426 (not $x408)))
(and $x426 (or $x408 (and (distinct ?x385 ?x385) true))))))))))
(check-sat)
; query 37: function APCM_quantization_xmaxc_to_exp_mant, block 24, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let ((?x235 ((_ sign_extend 16) in.0_16)))
(let ((?x385 (bvshl ?x235 (_ bv1 32))))
(let ((?x523 (bvadd ?x385 (_ bv1 32))))
(let ((?x537 (bvor ?x385 (_ bv1 32))))
(let (($x179 (and (distinct (bvadd ((_ zero_extend 1) ?x385) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) ?x523)) true)))
(let (($x168 (and (distinct (bvadd ((_ sign_extend 1) ?x385) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x523)) true)))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x408 (or $x145 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x578 (or $x408 false (or $x168 $x179))))
(and (not (or $x408 false false)) (or $x578 (and (distinct ?x537 ?x523) true))))))))))))))
(check-sat)
; query 38: function APCM_quantization_xmaxc_to_exp_mant, block 24, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x374 (and (distinct ((_ extract 15 0) (bvor (bvshl ((_ sign_extend 16) in.0_16) (_ bv1 32)) (_ bv1 32))) ((_ extract 15 0) (bvadd (bvshl ((_ sign_extend 16) in.0_16) (_ bv1 32)) (_ bv1 32)))) true)))
(let ((?x462 (bvadd ((_ zero_extend 1) (bvshl ((_ sign_extend 16) in.0_16) (_ bv1 32))) ((_ zero_extend 1) (_ bv1 32)))))
(let (($x179 (and (distinct ?x462 ((_ zero_extend 1) (bvadd (bvshl ((_ sign_extend 16) in.0_16) (_ bv1 32)) (_ bv1 32)))) true)))
(let ((?x76 ((_ sign_extend 1) (_ bv1 32))))
(let (($x168 (and (distinct (bvadd ((_ sign_extend 1) (bvshl ((_ sign_extend 16) in.0_16) (_ bv1 32))) ?x76) ((_ sign_extend 1) (bvadd (bvshl ((_ sign_extend 16) in.0_16) (_ bv1 32)) (_ bv1 32)))) true)))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x408 (or $x145 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x578 (or $x408 false (or $x168 $x179))))
(and (not (or (or $x408 false false) false)) (or (or $x578 false) $x374))))))))))))
(check-sat)
; query 39: function APCM_quantization_xmaxc_to_exp_mant, block 24, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_16 () (_ BitVec 16))
(assert
 (let (($x484 (or false false false)))
(let (($x225 (not $x484)))
(and $x225 (or $x484 (and (distinct (bvadd in.12_16 (_ bv65535 16)) (bvadd in.12_16 (_ bv65535 16))) true))))))
(check-sat)
; query 40: function APCM_quantization_xmaxc_to_exp_mant, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in.2_16) ((_ sign_extend 16) in.2_16)) true))))))
(check-sat)
; query 41: function APCM_quantization_xmaxc_to_exp_mant, block 37, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_16 () (_ BitVec 16))
(assert
 (let ((?x242 (ite (bvsge (_ bv6 32) ((_ sign_extend 16) in.2_16)) (_ bv1 1) (_ bv0 1))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x128 (not $x145)))
(and $x128 (or $x145 (and (distinct ?x242 ?x242) true))))))))
(check-sat)
; query 42: function APCM_quantization_xmaxc_to_exp_mant, block 49, name %50
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 43: function APCM_quantization_xmaxc_to_exp_mant, block 49, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x348 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in.1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x128 (not $x145)))
(and $x128 (or $x145 (and (distinct ?x348 ?x348) true))))))))
(check-sat)
; query 44: function APCM_quantization_xmaxc_to_exp_mant, block 52, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 45: function APCM_quantization_xmaxc_to_exp_mant, block 52, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x896 (ite (bvsge (_ bv7 32) ((_ sign_extend 16) in.1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x128 (not $x145)))
(and $x128 (or $x145 (and (distinct ?x896 ?x896) true))))))))
(check-sat)
; query 46: function APCM_quantization_xmaxc_to_exp_mant, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x465 ((_ sign_extend 16) in0_16)))
(let ((?x447 (bvashr ?x465 (_ bv3 32))))
(let ((?x1010 (bvsub ?x447 (_ bv1 32))))
(let ((?x571 ((_ extract 15 0) ?x1010)))
(let (($x917 (and (distinct (bvsub ((_ sign_extend 1) ?x447) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x1010)) true)))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x350 (or $x145 (bvuge (_ bv3 32) (_ bv32 32)))))
(let (($x710 (or $x350 false (or $x917))))
(let (($x1009 (or $x710 false)))
(and (not $x1009) (or $x1009 (and (distinct ?x571 ?x571) true))))))))))))))
(check-sat)
; query 47: function APCM_quantization_xmaxc_to_exp_mant, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 48: function APCM_quantization_xmaxc_to_exp_mant, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x465 ((_ sign_extend 16) in0_16)))
(let ((?x447 (bvashr ?x465 (_ bv3 32))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x350 (or $x145 (bvuge (_ bv3 32) (_ bv32 32)))))
(and (not $x350) (or $x350 (and (distinct ?x447 ?x447) true)))))))))
(check-sat)
; query 49: function APCM_quantization_xmaxc_to_exp_mant, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x465 ((_ sign_extend 16) in0_16)))
(let ((?x447 (bvashr ?x465 (_ bv3 32))))
(let ((?x1010 (bvsub ?x447 (_ bv1 32))))
(let (($x917 (and (distinct (bvsub ((_ sign_extend 1) ?x447) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x1010)) true)))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x350 (or $x145 (bvuge (_ bv3 32) (_ bv32 32)))))
(let (($x710 (or $x350 false (or $x917))))
(and (not $x710) (or $x710 (and (distinct ?x1010 ?x1010) true))))))))))))
(check-sat)
; query 50: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 51: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x282 (ite (bvslt (_ bv15 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x128 (not $x145)))
(and $x128 (or $x145 (and (distinct ?x282 ?x282) true))))))))
(check-sat)
; query 52: function Autocorrelation, block 115, name %116
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.3_32 () (_ BitVec 32))
(assert
 (let (($x43 (and (distinct (bvadd ((_ sign_extend 1) in.3_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.3_32 (_ bv1 32)))) true)))
(let (($x381 (or false false (or $x43))))
(and (not $x381) (or $x381 (and (distinct (bvadd in.3_32 (_ bv1 32)) (bvadd in.3_32 (_ bv1 32))) true))))))
(check-sat)
; query 53: function Autocorrelation, block 132, name %133
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.4_32 () (_ BitVec 32))
(assert
 (let (($x49 (and (distinct (bvadd ((_ sign_extend 1) in.4_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.4_32 (_ bv1 32)))) true)))
(let (($x95 (or false false (or $x49))))
(and (not $x95) (or $x95 (and (distinct (bvadd in.4_32 (_ bv1 32)) (bvadd in.4_32 (_ bv1 32))) true))))))
(check-sat)
; query 54: function Autocorrelation, block 39, name %40
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x415 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x380 (or false false (or $x415))))
(and (not $x380) (or $x380 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 55: function Autocorrelation, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04.lcssa_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x203 (or $x16 (and (distinct ((_ sign_extend 16) in.04.lcssa_16) ((_ sign_extend 16) in.04.lcssa_16)) true))))
(let (($x554 (not $x16)))
(and $x554 $x203)))))
(check-sat)
; query 56: function Autocorrelation, block 45, name %47
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04.lcssa_16 () (_ BitVec 16))
(assert
 (let ((?x563 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.04.lcssa_16)) (_ bv1 1) (_ bv0 1))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x128 (not $x145)))
(and $x128 (or $x145 (and (distinct ?x563 ?x563) true))))))))
(check-sat)
; query 57: function Autocorrelation, block 45, name %48
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04.lcssa_16 () (_ BitVec 16))
(assert
 (let ((?x563 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.04.lcssa_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x307 (bvxor ?x563 (_ bv1 1))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x694 (or $x145 false false)))
(let (($x430 (not $x694)))
(and $x430 (or $x694 (and (distinct ?x307 ?x307) true))))))))))
(check-sat)
; query 58: function Autocorrelation, block 45, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04.lcssa_16 () (_ BitVec 16))
(assert
 (let ((?x563 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.04.lcssa_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x307 (bvxor ?x563 (_ bv1 1))))
(let ((?x508 ((_ zero_extend 31) ?x307)))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x694 (or $x145 false false)))
(let (($x749 (or $x694 false)))
(let (($x104 (not $x749)))
(and $x104 (or $x749 (and (distinct ?x508 ?x508) true))))))))))))
(check-sat)
; query 59: function Autocorrelation, block 45, name %50
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04.lcssa_16 () (_ BitVec 16))
(assert
 (let ((?x563 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.04.lcssa_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x307 (bvxor ?x563 (_ bv1 1))))
(let ((?x508 ((_ zero_extend 31) ?x307)))
(let ((?x761 ((_ sign_extend 32) ?x508)))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x694 (or $x145 false false)))
(let (($x749 (or $x694 false)))
(let (($x687 (or $x749 false)))
(let (($x624 (not $x687)))
(and $x624 (or $x687 (and (distinct ?x761 ?x761) true))))))))))))))
(check-sat)
; query 60: function Autocorrelation, block 45, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04.lcssa_16 () (_ BitVec 16))
(assert
 (let ((?x563 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.04.lcssa_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x307 (bvxor ?x563 (_ bv1 1))))
(let ((?x508 ((_ zero_extend 31) ?x307)))
(let ((?x761 ((_ sign_extend 32) ?x508)))
(let ((?x302 (ite (and (distinct (_ bv0 64) ?x761) true) (_ bv1 1) (_ bv0 1))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x694 (or $x145 false false)))
(let (($x749 (or $x694 false)))
(let (($x687 (or $x749 false)))
(let (($x813 (or $x687 false false)))
(let (($x212 (not $x813)))
(and $x212 (or $x813 (and (distinct ?x302 ?x302) true))))))))))))))))
(check-sat)
; query 61: function Autocorrelation, block 525, name %526
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x490 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x806 (or false false (or $x490))))
(and (not $x806) (or $x806 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 62: function Autocorrelation, block 537, name %538
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in.06_16) ((_ sign_extend 16) in.06_16)) true))))))
(check-sat)
; query 63: function Autocorrelation, block 537, name %539
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_16 () (_ BitVec 16))
(assert
 (let ((?x629 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.06_16)) (_ bv1 1) (_ bv0 1))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x128 (not $x145)))
(and $x128 (or $x145 (and (distinct ?x629 ?x629) true))))))))
(check-sat)
; query 64: function Autocorrelation, block 540, name %541
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in.06_16) ((_ sign_extend 16) in.06_16)) true))))))
(check-sat)
; query 65: function Autocorrelation, block 540, name %542
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_16 () (_ BitVec 16))
(assert
 (let ((?x310 (ite (bvsge (_ bv4 32) ((_ sign_extend 16) in.06_16)) (_ bv1 1) (_ bv0 1))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x128 (not $x145)))
(and $x128 (or $x145 (and (distinct ?x310 ?x310) true))))))))
(check-sat)
; query 66: function Autocorrelation, block 540, name %543
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_16 () (_ BitVec 16))
(assert
 (let ((?x310 (ite (bvsge (_ bv4 32) ((_ sign_extend 16) in.06_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x351 (bvxor ?x310 (_ bv1 1))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x694 (or $x145 false false)))
(let (($x430 (not $x694)))
(and $x430 (or $x694 (and (distinct ?x351 ?x351) true))))))))))
(check-sat)
; query 67: function Autocorrelation, block 540, name %544
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_16 () (_ BitVec 16))
(assert
 (let ((?x310 (ite (bvsge (_ bv4 32) ((_ sign_extend 16) in.06_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x351 (bvxor ?x310 (_ bv1 1))))
(let ((?x511 ((_ zero_extend 31) ?x351)))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x694 (or $x145 false false)))
(let (($x749 (or $x694 false)))
(let (($x104 (not $x749)))
(and $x104 (or $x749 (and (distinct ?x511 ?x511) true))))))))))))
(check-sat)
; query 68: function Autocorrelation, block 540, name %545
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_16 () (_ BitVec 16))
(assert
 (let ((?x310 (ite (bvsge (_ bv4 32) ((_ sign_extend 16) in.06_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x351 (bvxor ?x310 (_ bv1 1))))
(let ((?x511 ((_ zero_extend 31) ?x351)))
(let ((?x880 ((_ sign_extend 32) ?x511)))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x694 (or $x145 false false)))
(let (($x749 (or $x694 false)))
(let (($x687 (or $x749 false)))
(let (($x624 (not $x687)))
(and $x624 (or $x687 (and (distinct ?x880 ?x880) true))))))))))))))
(check-sat)
; query 69: function Autocorrelation, block 540, name %546
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_16 () (_ BitVec 16))
(assert
 (let ((?x310 (ite (bvsge (_ bv4 32) ((_ sign_extend 16) in.06_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x351 (bvxor ?x310 (_ bv1 1))))
(let ((?x511 ((_ zero_extend 31) ?x351)))
(let ((?x880 ((_ sign_extend 32) ?x511)))
(let ((?x108 (ite (and (distinct (_ bv0 64) ?x880) true) (_ bv1 1) (_ bv0 1))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x694 (or $x145 false false)))
(let (($x749 (or $x694 false)))
(let (($x687 (or $x749 false)))
(let (($x813 (or $x687 false false)))
(let (($x212 (not $x813)))
(and $x212 (or $x813 (and (distinct ?x108 ?x108) true))))))))))))))))
(check-sat)
; query 70: function Autocorrelation, block 81, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x254 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x646 (or false false (or $x254))))
(and (not $x646) (or $x646 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 71: function Autocorrelation, block 98, name %99
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let (($x1049 (and (distinct (bvadd ((_ sign_extend 1) in.2_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.2_32 (_ bv1 32)))) true)))
(let (($x250 (or false false (or $x1049))))
(and (not $x250) (or $x250 (and (distinct (bvadd in.2_32 (_ bv1 32)) (bvadd in.2_32 (_ bv1 32))) true))))))
(check-sat)
; query 72: function Calculation_of_the_LTP_parameters, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in11_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in11_16) ((_ sign_extend 16) in11_16)) true))))))
(check-sat)
; query 73: function Calculation_of_the_LTP_parameters, block 14, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in11_16 () (_ BitVec 16))
(assert
 (let ((?x781 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in11_16)) (_ bv1 1) (_ bv0 1))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x128 (not $x145)))
(and $x128 (or $x145 (and (distinct ?x781 ?x781) true))))))))
(check-sat)
; query 74: function Calculation_of_the_LTP_parameters, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in11_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in11_16) ((_ sign_extend 16) in11_16)) true))))))
(check-sat)
; query 75: function Calculation_of_the_LTP_parameters, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in11_16 () (_ BitVec 16))
(assert
 (let ((?x245 ((_ sign_extend 16) in11_16)))
(let ((?x28 (bvsub (_ bv0 32) ?x245)))
(let (($x373 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x245)) ((_ sign_extend 1) ?x28)) true)))
(let (($x16 (or false false)))
(let (($x199 (or false $x16 (or $x373))))
(and (not $x199) (or $x199 (and (distinct ?x28 ?x28) true)))))))))
(check-sat)
; query 76: function Calculation_of_the_LTP_parameters, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in11_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in11_16) ((_ sign_extend 16) in11_16)) true))))))
(check-sat)
; query 77: function Calculation_of_the_LTP_parameters, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_32 () (_ BitVec 32))
(assert
 (let (($x84 (and (distinct (bvadd ((_ sign_extend 1) in.03_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.03_32 (_ bv1 32)))) true)))
(let (($x895 (or false false (or $x84))))
(and (not $x895) (or $x895 (and (distinct (bvadd in.03_32 (_ bv1 32)) (bvadd in.03_32 (_ bv1 32))) true))))))
(check-sat)
; query 78: function Calculation_of_the_LTP_parameters, block 39, name %40
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02.lcssa_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x391 (or $x16 (and (distinct ((_ sign_extend 16) in.02.lcssa_16) ((_ sign_extend 16) in.02.lcssa_16)) true))))
(let (($x554 (not $x16)))
(and $x554 $x391)))))
(check-sat)
; query 79: function Calculation_of_the_LTP_parameters, block 39, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02.lcssa_16 () (_ BitVec 16))
(assert
 (let ((?x533 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.02.lcssa_16)) (_ bv1 1) (_ bv0 1))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x128 (not $x145)))
(and $x128 (or $x145 (and (distinct ?x533 ?x533) true))))))))
(check-sat)
; query 80: function Calculation_of_the_LTP_parameters, block 39, name %42
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02.lcssa_16 () (_ BitVec 16))
(assert
 (let ((?x533 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.02.lcssa_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x345 (bvxor ?x533 (_ bv1 1))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x694 (or $x145 false false)))
(let (($x430 (not $x694)))
(and $x430 (or $x694 (and (distinct ?x345 ?x345) true))))))))))
(check-sat)
; query 81: function Calculation_of_the_LTP_parameters, block 39, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02.lcssa_16 () (_ BitVec 16))
(assert
 (let ((?x533 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.02.lcssa_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x345 (bvxor ?x533 (_ bv1 1))))
(let ((?x236 ((_ zero_extend 31) ?x345)))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x694 (or $x145 false false)))
(let (($x749 (or $x694 false)))
(let (($x104 (not $x749)))
(and $x104 (or $x749 (and (distinct ?x236 ?x236) true))))))))))))
(check-sat)
; query 82: function Calculation_of_the_LTP_parameters, block 39, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02.lcssa_16 () (_ BitVec 16))
(assert
 (let ((?x533 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.02.lcssa_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x345 (bvxor ?x533 (_ bv1 1))))
(let ((?x236 ((_ zero_extend 31) ?x345)))
(let ((?x754 ((_ sign_extend 32) ?x236)))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x694 (or $x145 false false)))
(let (($x749 (or $x694 false)))
(let (($x687 (or $x749 false)))
(let (($x624 (not $x687)))
(and $x624 (or $x687 (and (distinct ?x754 ?x754) true))))))))))))))
(check-sat)
; query 83: function Calculation_of_the_LTP_parameters, block 39, name %45
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02.lcssa_16 () (_ BitVec 16))
(assert
 (let ((?x533 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.02.lcssa_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x345 (bvxor ?x533 (_ bv1 1))))
(let ((?x236 ((_ zero_extend 31) ?x345)))
(let ((?x754 ((_ sign_extend 32) ?x236)))
(let ((?x488 (ite (and (distinct (_ bv0 64) ?x754) true) (_ bv1 1) (_ bv0 1))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x694 (or $x145 false false)))
(let (($x749 (or $x694 false)))
(let (($x687 (or $x749 false)))
(let (($x813 (or $x687 false false)))
(let (($x212 (not $x813)))
(and $x212 (or $x813 (and (distinct ?x488 ?x488) true))))))))))))))))
(check-sat)
; query 84: function Calculation_of_the_LTP_parameters, block 530, name %531
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.05_32 () (_ BitVec 32))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ extract 15 0) in.05_32) ((_ extract 15 0) in.05_32)) true))))))
(check-sat)
; query 85: function Calculation_of_the_LTP_parameters, block 533, name %534
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.05_32 () (_ BitVec 32))
(assert
 (let (($x812 (and (distinct (bvadd ((_ sign_extend 1) in.05_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.05_32 (_ bv1 32)))) true)))
(let (($x436 (or false false (or $x812))))
(and (not $x436) (or $x436 (and (distinct (bvadd in.05_32 (_ bv1 32)) (bvadd in.05_32 (_ bv1 32))) true))))))
(check-sat)
; query 86: function Calculation_of_the_LTP_parameters, block 539, name %540
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in.01_16) ((_ sign_extend 16) in.01_16)) true))))))
(check-sat)
; query 87: function Calculation_of_the_LTP_parameters, block 539, name %541
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x356 (ite (bvsle (_ bv4294967196 32) ((_ sign_extend 16) in.01_16)) (_ bv1 1) (_ bv0 1))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x128 (not $x145)))
(and $x128 (or $x145 (and (distinct ?x356 ?x356) true))))))))
(check-sat)
; query 88: function Calculation_of_the_LTP_parameters, block 551, name %552
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in.01_16) ((_ sign_extend 16) in.01_16)) true))))))
(check-sat)
; query 89: function Calculation_of_the_LTP_parameters, block 551, name %553
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x581 ((_ sign_extend 16) in.01_16)))
(let ((?x175 (bvsub (_ bv6 32) ?x581)))
(let (($x658 (and (distinct (bvsub ((_ sign_extend 1) (_ bv6 32)) ((_ sign_extend 1) ?x581)) ((_ sign_extend 1) ?x175)) true)))
(let (($x16 (or false false)))
(let (($x556 (or false $x16 (or $x658))))
(and (not $x556) (or $x556 (and (distinct ?x175 ?x175) true)))))))))
(check-sat)
; query 90: function Calculation_of_the_LTP_parameters, block 551, name %554
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x581 ((_ sign_extend 16) in.01_16)))
(let ((?x175 (bvsub (_ bv6 32) ?x581)))
(let ((?x674 ((_ zero_extend 32) ?x175)))
(let (($x658 (and (distinct (bvsub ((_ sign_extend 1) (_ bv6 32)) ((_ sign_extend 1) ?x581)) ((_ sign_extend 1) ?x175)) true)))
(let (($x16 (or false false)))
(let (($x556 (or false $x16 (or $x658))))
(let (($x634 (or $x556 false)))
(and (not $x634) (or $x634 (and (distinct ?x674 ?x674) true)))))))))))
(check-sat)
; query 91: function Calculation_of_the_LTP_parameters, block 551, name %555
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in536_64 () (_ BitVec 64))
(assert
 (let ((?x581 ((_ sign_extend 16) in.01_16)))
(let ((?x175 (bvsub (_ bv6 32) ?x581)))
(let ((?x674 ((_ zero_extend 32) ?x175)))
(let ((?x1012 (bvashr in536_64 ?x674)))
(let (($x658 (and (distinct (bvsub ((_ sign_extend 1) (_ bv6 32)) ((_ sign_extend 1) ?x581)) ((_ sign_extend 1) ?x175)) true)))
(let (($x16 (or false false)))
(let (($x556 (or false $x16 (or $x658))))
(let (($x634 (or $x556 false)))
(let (($x1048 (or (or false $x634 false) (bvuge ?x674 (_ bv64 64)))))
(and (not $x1048) (or $x1048 (and (distinct ?x1012 ?x1012) true)))))))))))))
(check-sat)
; query 92: function Calculation_of_the_LTP_parameters, block 551, name %556
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06.lcssa_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x521 (or $x16 (and (distinct ((_ sign_extend 16) in.06.lcssa_16) ((_ sign_extend 16) in.06.lcssa_16)) true))))
(let (($x554 (not $x16)))
(and $x554 $x521)))))
(check-sat)
; query 93: function Calculation_of_the_LTP_parameters, block 551, name %557
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06.lcssa_16 () (_ BitVec 16))
(assert
 (let ((?x313 (ite (bvsge (_ bv120 32) ((_ sign_extend 16) in.06.lcssa_16)) (_ bv1 1) (_ bv0 1))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x128 (not $x145)))
(and $x128 (or $x145 (and (distinct ?x313 ?x313) true))))))))
(check-sat)
; query 94: function Calculation_of_the_LTP_parameters, block 558, name %559
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06.lcssa_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x521 (or $x16 (and (distinct ((_ sign_extend 16) in.06.lcssa_16) ((_ sign_extend 16) in.06.lcssa_16)) true))))
(let (($x554 (not $x16)))
(and $x554 $x521)))))
(check-sat)
; query 95: function Calculation_of_the_LTP_parameters, block 558, name %560
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06.lcssa_16 () (_ BitVec 16))
(assert
 (let ((?x804 (ite (bvsle (_ bv40 32) ((_ sign_extend 16) in.06.lcssa_16)) (_ bv1 1) (_ bv0 1))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x128 (not $x145)))
(and $x128 (or $x145 (and (distinct ?x804 ?x804) true))))))))
(check-sat)
; query 96: function Calculation_of_the_LTP_parameters, block 57, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in.0_16) ((_ sign_extend 16) in.0_16)) true))))))
(check-sat)
; query 97: function Calculation_of_the_LTP_parameters, block 57, name %59
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let ((?x235 ((_ sign_extend 16) in.0_16)))
(let ((?x266 (bvsub (_ bv6 32) ?x235)))
(let (($x368 (and (distinct (bvsub ((_ sign_extend 1) (_ bv6 32)) ((_ sign_extend 1) ?x235)) ((_ sign_extend 1) ?x266)) true)))
(let (($x16 (or false false)))
(let (($x827 (or false $x16 (or $x368))))
(and (not $x827) (or $x827 (and (distinct ?x266 ?x266) true)))))))))
(check-sat)
; query 98: function Calculation_of_the_LTP_parameters, block 57, name %60
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let ((?x235 ((_ sign_extend 16) in.0_16)))
(let ((?x266 (bvsub (_ bv6 32) ?x235)))
(let ((?x52 ((_ extract 15 0) ?x266)))
(let (($x368 (and (distinct (bvsub ((_ sign_extend 1) (_ bv6 32)) ((_ sign_extend 1) ?x235)) ((_ sign_extend 1) ?x266)) true)))
(let (($x16 (or false false)))
(let (($x827 (or false $x16 (or $x368))))
(let (($x1103 (or $x827 false)))
(and (not $x1103) (or $x1103 (and (distinct ?x52 ?x52) true)))))))))))
(check-sat)
; query 99: function Calculation_of_the_LTP_parameters, block 584, name %585
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let (($x1049 (and (distinct (bvadd ((_ sign_extend 1) in.2_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.2_32 (_ bv1 32)))) true)))
(let (($x250 (or false false (or $x1049))))
(and (not $x250) (or $x250 (and (distinct (bvadd in.2_32 (_ bv1 32)) (bvadd in.2_32 (_ bv1 32))) true))))))
(check-sat)
; query 100: function Calculation_of_the_LTP_parameters, block 590, name %591
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in587_64 () (_ BitVec 64))
(declare-fun in555_64 () (_ BitVec 64))
(assert
 (let ((?x200 (ite (bvsge in555_64 in587_64) (_ bv1 1) (_ bv0 1))))
(let (($x484 (or false false false)))
(let (($x225 (not $x484)))
(and $x225 (or $x484 (and (distinct ?x200 ?x200) true)))))))
(check-sat)
; query 101: function Calculation_of_the_LTP_parameters, block 618, name %619
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.08_16 () (_ BitVec 16))
(assert
 (let (($x484 (or false false false)))
(let (($x225 (not $x484)))
(and $x225 (or $x484 (and (distinct (bvadd in.08_16 (_ bv1 16)) (bvadd in.08_16 (_ bv1 16))) true))))))
(check-sat)
; query 102: function Calculation_of_the_LTP_parameters, block 84, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.14_32 () (_ BitVec 32))
(assert
 (let (($x872 (and (distinct (bvadd ((_ sign_extend 1) in.14_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.14_32 (_ bv1 32)))) true)))
(let (($x535 (or false false (or $x872))))
(and (not $x535) (or $x535 (and (distinct (bvadd in.14_32 (_ bv1 32)) (bvadd in.14_32 (_ bv1 32))) true))))))
(check-sat)
; query 103: function Gsm_Decoder, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x398 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x839 (or false false (or $x398))))
(and (not $x839) (or $x839 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 104: function Gsm_Long_Term_Synthesis_Filtering, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 105: function Gsm_Long_Term_Synthesis_Filtering, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in19_16) ((_ sign_extend 16) in19_16)) true))))))
(check-sat)
; query 106: function Gsm_Long_Term_Synthesis_Filtering, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x828 (ite (bvsge (_ bv120 32) ((_ sign_extend 16) in19_16)) (_ bv1 1) (_ bv0 1))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x128 (not $x145)))
(and $x128 (or $x145 (and (distinct ?x828 ?x828) true))))))))
(check-sat)
; query 107: function Gsm_Long_Term_Synthesis_Filtering, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x628 (ite (bvslt (_ bv120 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x128 (not $x145)))
(and $x128 (or $x145 (and (distinct ?x628 ?x628) true))))))))
(check-sat)
; query 108: function Gsm_Long_Term_Synthesis_Filtering, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 109: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 110: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x132 (ite (bvsgt (_ bv40 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x128 (not $x145)))
(and $x128 (or $x145 (and (distinct ?x132 ?x132) true))))))))
(check-sat)
; query 111: function Gsm_Preprocess, block 106, name %107
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in104_64 () (_ BitVec 64))
(assert
 (let ((?x475 (bvadd in104_64 (_ bv16384 64))))
(let (($x470 (and (distinct ?x475 ?x475) true)))
(let (($x260 (and (distinct (bvadd ((_ sign_extend 1) in104_64) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x475)) true)))
(let (($x904 (or false false (or $x260))))
(and (not $x904) (or $x904 $x470)))))))
(check-sat)
; query 112: function Gsm_Preprocess, block 108, name %109
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in104_64 () (_ BitVec 64))
(assert
 (let ((?x475 (bvadd in104_64 (_ bv16384 64))))
(let (($x470 (and (distinct ?x475 ?x475) true)))
(let (($x484 (or false false false)))
(let (($x225 (not $x484)))
(and $x225 (or $x484 $x470)))))))
(check-sat)
; query 113: function Gsm_Preprocess, block 108, name %110
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in104_64 () (_ BitVec 64))
(assert
 (let ((?x599 (ite (bvuge (bvadd in104_64 (_ bv16384 64)) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x484 (or false false false)))
(let (($x595 (or $x484 false false)))
(let (($x652 (not $x595)))
(and $x652 (or $x595 (and (distinct ?x599 ?x599) true))))))))
(check-sat)
; query 114: function Gsm_Preprocess, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in19_16) ((_ sign_extend 16) in19_16)) true))))))
(check-sat)
; query 115: function Gsm_Preprocess, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x696 (ite (bvsge (_ bv16380 32) ((_ sign_extend 16) in19_16)) (_ bv1 1) (_ bv0 1))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x128 (not $x145)))
(and $x128 (or $x145 (and (distinct ?x696 ?x696) true))))))))
(check-sat)
; query 116: function Gsm_Preprocess, block 30, name %33
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x696 (ite (bvsge (_ bv16380 32) ((_ sign_extend 16) in19_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x653 (bvxor ?x696 (_ bv1 1))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x694 (or $x145 false false)))
(let (($x430 (not $x694)))
(and $x430 (or $x694 (and (distinct ?x653 ?x653) true))))))))))
(check-sat)
; query 117: function Gsm_Preprocess, block 30, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x696 (ite (bvsge (_ bv16380 32) ((_ sign_extend 16) in19_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x653 (bvxor ?x696 (_ bv1 1))))
(let ((?x609 ((_ zero_extend 31) ?x653)))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x694 (or $x145 false false)))
(let (($x749 (or $x694 false)))
(let (($x104 (not $x749)))
(and $x104 (or $x749 (and (distinct ?x609 ?x609) true))))))))))))
(check-sat)
; query 118: function Gsm_Preprocess, block 30, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x696 (ite (bvsge (_ bv16380 32) ((_ sign_extend 16) in19_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x653 (bvxor ?x696 (_ bv1 1))))
(let ((?x609 ((_ zero_extend 31) ?x653)))
(let ((?x1018 ((_ sign_extend 32) ?x609)))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x694 (or $x145 false false)))
(let (($x749 (or $x694 false)))
(let (($x687 (or $x749 false)))
(let (($x624 (not $x687)))
(and $x624 (or $x687 (and (distinct ?x1018 ?x1018) true))))))))))))))
(check-sat)
; query 119: function Gsm_Preprocess, block 30, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x696 (ite (bvsge (_ bv16380 32) ((_ sign_extend 16) in19_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x653 (bvxor ?x696 (_ bv1 1))))
(let ((?x609 ((_ zero_extend 31) ?x653)))
(let ((?x1018 ((_ sign_extend 32) ?x609)))
(let ((?x929 (ite (and (distinct (_ bv0 64) ?x1018) true) (_ bv1 1) (_ bv0 1))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x694 (or $x145 false false)))
(let (($x749 (or $x694 false)))
(let (($x687 (or $x749 false)))
(let (($x813 (or $x687 false false)))
(let (($x212 (not $x813)))
(and $x212 (or $x813 (and (distinct ?x929 ?x929) true))))))))))))))))
(check-sat)
; query 120: function Gsm_Preprocess, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in19_16) ((_ sign_extend 16) in19_16)) true))))))
(check-sat)
; query 121: function Gsm_Preprocess, block 40, name %42
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in.03_16) ((_ sign_extend 16) in.03_16)) true))))))
(check-sat)
; query 122: function Gsm_Preprocess, block 40, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_16 () (_ BitVec 16))
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x442 ((_ sign_extend 16) in.03_16)))
(let ((?x885 ((_ sign_extend 16) in19_16)))
(let ((?x663 (bvsub ?x885 ?x442)))
(let (($x1096 (and (distinct (bvsub ((_ sign_extend 1) ?x885) ((_ sign_extend 1) ?x442)) ((_ sign_extend 1) ?x663)) true)))
(let (($x16 (or false false)))
(let (($x679 (or $x16 $x16 (or $x1096))))
(and (not $x679) (or $x679 (and (distinct ?x663 ?x663) true))))))))))
(check-sat)
; query 123: function Gsm_Preprocess, block 40, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_16 () (_ BitVec 16))
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x442 ((_ sign_extend 16) in.03_16)))
(let ((?x885 ((_ sign_extend 16) in19_16)))
(let ((?x663 (bvsub ?x885 ?x442)))
(let ((?x915 ((_ extract 15 0) ?x663)))
(let (($x1096 (and (distinct (bvsub ((_ sign_extend 1) ?x885) ((_ sign_extend 1) ?x442)) ((_ sign_extend 1) ?x663)) true)))
(let (($x16 (or false false)))
(let (($x679 (or $x16 $x16 (or $x1096))))
(let (($x794 (or $x679 false)))
(and (not $x794) (or $x794 (and (distinct ?x915 ?x915) true))))))))))))
(check-sat)
; query 124: function Gsm_Preprocess, block 40, name %45
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_16 () (_ BitVec 16))
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x442 ((_ sign_extend 16) in.03_16)))
(let ((?x885 ((_ sign_extend 16) in19_16)))
(let ((?x663 (bvsub ?x885 ?x442)))
(let ((?x915 ((_ extract 15 0) ?x663)))
(let ((?x821 ((_ sign_extend 16) ?x915)))
(let (($x1096 (and (distinct (bvsub ((_ sign_extend 1) ?x885) ((_ sign_extend 1) ?x442)) ((_ sign_extend 1) ?x663)) true)))
(let (($x16 (or false false)))
(let (($x679 (or $x16 $x16 (or $x1096))))
(let (($x794 (or $x679 false)))
(let (($x987 (or $x794 false)))
(and (not $x987) (or $x987 (and (distinct ?x821 ?x821) true))))))))))))))
(check-sat)
; query 125: function Gsm_Preprocess, block 40, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_16 () (_ BitVec 16))
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x442 ((_ sign_extend 16) in.03_16)))
(let ((?x885 ((_ sign_extend 16) in19_16)))
(let ((?x663 (bvsub ?x885 ?x442)))
(let ((?x915 ((_ extract 15 0) ?x663)))
(let ((?x821 ((_ sign_extend 16) ?x915)))
(let ((?x1115 (ite (and (distinct (_ bv4294934528 32) ?x821) true) (_ bv1 1) (_ bv0 1))))
(let (($x1096 (and (distinct (bvsub ((_ sign_extend 1) ?x885) ((_ sign_extend 1) ?x442)) ((_ sign_extend 1) ?x663)) true)))
(let (($x16 (or false false)))
(let (($x679 (or $x16 $x16 (or $x1096))))
(let (($x794 (or $x679 false)))
(let (($x987 (or $x794 false)))
(let (($x992 (or $x987 false false)))
(and (not $x992) (or $x992 (and (distinct ?x1115 ?x1115) true))))))))))))))))
(check-sat)
; query 126: function Gsm_Preprocess, block 40, name %47
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_16 () (_ BitVec 16))
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x442 ((_ sign_extend 16) in.03_16)))
(let ((?x885 ((_ sign_extend 16) in19_16)))
(let ((?x663 (bvsub ?x885 ?x442)))
(let ((?x915 ((_ extract 15 0) ?x663)))
(let ((?x821 ((_ sign_extend 16) ?x915)))
(let ((?x1115 (ite (and (distinct (_ bv4294934528 32) ?x821) true) (_ bv1 1) (_ bv0 1))))
(let ((?x1027 (bvxor ?x1115 (_ bv1 1))))
(let (($x1096 (and (distinct (bvsub ((_ sign_extend 1) ?x885) ((_ sign_extend 1) ?x442)) ((_ sign_extend 1) ?x663)) true)))
(let (($x16 (or false false)))
(let (($x679 (or $x16 $x16 (or $x1096))))
(let (($x794 (or $x679 false)))
(let (($x987 (or $x794 false)))
(let (($x992 (or $x987 false false)))
(let (($x1075 (or $x992 false false)))
(and (not $x1075) (or $x1075 (and (distinct ?x1027 ?x1027) true))))))))))))))))))
(check-sat)
; query 127: function Gsm_Preprocess, block 40, name %48
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_16 () (_ BitVec 16))
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x442 ((_ sign_extend 16) in.03_16)))
(let ((?x885 ((_ sign_extend 16) in19_16)))
(let ((?x663 (bvsub ?x885 ?x442)))
(let ((?x915 ((_ extract 15 0) ?x663)))
(let ((?x821 ((_ sign_extend 16) ?x915)))
(let ((?x1115 (ite (and (distinct (_ bv4294934528 32) ?x821) true) (_ bv1 1) (_ bv0 1))))
(let ((?x1027 (bvxor ?x1115 (_ bv1 1))))
(let ((?x1002 ((_ zero_extend 31) ?x1027)))
(let (($x1096 (and (distinct (bvsub ((_ sign_extend 1) ?x885) ((_ sign_extend 1) ?x442)) ((_ sign_extend 1) ?x663)) true)))
(let (($x16 (or false false)))
(let (($x679 (or $x16 $x16 (or $x1096))))
(let (($x794 (or $x679 false)))
(let (($x987 (or $x794 false)))
(let (($x992 (or $x987 false false)))
(let (($x1075 (or $x992 false false)))
(let (($x941 (or $x1075 false)))
(and (not $x941) (or $x941 (and (distinct ?x1002 ?x1002) true))))))))))))))))))))
(check-sat)
; query 128: function Gsm_Preprocess, block 40, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_16 () (_ BitVec 16))
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x442 ((_ sign_extend 16) in.03_16)))
(let ((?x885 ((_ sign_extend 16) in19_16)))
(let ((?x663 (bvsub ?x885 ?x442)))
(let ((?x915 ((_ extract 15 0) ?x663)))
(let ((?x821 ((_ sign_extend 16) ?x915)))
(let ((?x1115 (ite (and (distinct (_ bv4294934528 32) ?x821) true) (_ bv1 1) (_ bv0 1))))
(let ((?x1027 (bvxor ?x1115 (_ bv1 1))))
(let ((?x1002 ((_ zero_extend 31) ?x1027)))
(let ((?x792 ((_ sign_extend 32) ?x1002)))
(let (($x1096 (and (distinct (bvsub ((_ sign_extend 1) ?x885) ((_ sign_extend 1) ?x442)) ((_ sign_extend 1) ?x663)) true)))
(let (($x16 (or false false)))
(let (($x679 (or $x16 $x16 (or $x1096))))
(let (($x794 (or $x679 false)))
(let (($x987 (or $x794 false)))
(let (($x992 (or $x987 false false)))
(let (($x1075 (or $x992 false false)))
(let (($x941 (or $x1075 false)))
(let (($x976 (or $x941 false)))
(and (not $x976) (or $x976 (and (distinct ?x792 ?x792) true))))))))))))))))))))))
(check-sat)
; query 129: function Gsm_Preprocess, block 40, name %50
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_16 () (_ BitVec 16))
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x442 ((_ sign_extend 16) in.03_16)))
(let ((?x885 ((_ sign_extend 16) in19_16)))
(let ((?x663 (bvsub ?x885 ?x442)))
(let ((?x915 ((_ extract 15 0) ?x663)))
(let ((?x821 ((_ sign_extend 16) ?x915)))
(let ((?x1115 (ite (and (distinct (_ bv4294934528 32) ?x821) true) (_ bv1 1) (_ bv0 1))))
(let ((?x1027 (bvxor ?x1115 (_ bv1 1))))
(let ((?x1002 ((_ zero_extend 31) ?x1027)))
(let ((?x792 ((_ sign_extend 32) ?x1002)))
(let ((?x833 (ite (and (distinct (_ bv0 64) ?x792) true) (_ bv1 1) (_ bv0 1))))
(let (($x1096 (and (distinct (bvsub ((_ sign_extend 1) ?x885) ((_ sign_extend 1) ?x442)) ((_ sign_extend 1) ?x663)) true)))
(let (($x16 (or false false)))
(let (($x679 (or $x16 $x16 (or $x1096))))
(let (($x794 (or $x679 false)))
(let (($x987 (or $x794 false)))
(let (($x992 (or $x987 false false)))
(let (($x1075 (or $x992 false false)))
(let (($x941 (or $x1075 false)))
(let (($x976 (or $x941 false)))
(let (($x999 (or $x976 false false)))
(and (not $x999) (or $x999 (and (distinct ?x833 ?x833) true))))))))))))))))))))))))
(check-sat)
; query 130: function Gsm_Preprocess, block 54, name %55
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in44_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 48) in44_16) ((_ sign_extend 48) in44_16)) true))))))
(check-sat)
; query 131: function Gsm_Preprocess, block 54, name %56
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in44_16 () (_ BitVec 16))
(assert
 (let ((?x353 ((_ sign_extend 48) in44_16)))
(let ((?x935 (bvshl ?x353 (_ bv15 64))))
(let (($x131 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x432 (or $x145 $x131)))
(and (not $x432) (or $x432 (and (distinct ?x935 ?x935) true))))))))))
(check-sat)
; query 132: function Gsm_Preprocess, block 54, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_64 () (_ BitVec 64))
(assert
 (let (($x131 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x484 (or false false false)))
(let (($x459 (or $x484 $x131)))
(and (not $x459) (or $x459 (and (distinct (bvashr in.04_64 (_ bv15 64)) (bvashr in.04_64 (_ bv15 64))) true)))))))
(check-sat)
; query 133: function Gsm_Preprocess, block 54, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_64 () (_ BitVec 64))
(assert
 (let ((?x847 (bvashr in.04_64 (_ bv15 64))))
(let ((?x471 ((_ extract 15 0) ?x847)))
(let (($x131 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x484 (or false false false)))
(let (($x459 (or $x484 $x131)))
(let (($x727 (or $x459 false)))
(and (not $x727) (or $x727 (and (distinct ?x471 ?x471) true))))))))))
(check-sat)
; query 134: function Gsm_Preprocess, block 54, name %59
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_64 () (_ BitVec 64))
(assert
 (let ((?x847 (bvashr in.04_64 (_ bv15 64))))
(let ((?x471 ((_ extract 15 0) ?x847)))
(let ((?x857 ((_ sign_extend 48) ?x471)))
(let (($x131 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x484 (or false false false)))
(let (($x459 (or $x484 $x131)))
(let (($x727 (or $x459 false)))
(let (($x739 (or $x727 false)))
(and (not $x739) (or $x739 (and (distinct ?x857 ?x857) true))))))))))))
(check-sat)
; query 135: function Gsm_Preprocess, block 54, name %60
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_64 () (_ BitVec 64))
(assert
 (let ((?x847 (bvashr in.04_64 (_ bv15 64))))
(let ((?x471 ((_ extract 15 0) ?x847)))
(let ((?x857 ((_ sign_extend 48) ?x471)))
(let ((?x1111 (bvshl ?x857 (_ bv15 64))))
(let (($x131 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x484 (or false false false)))
(let (($x459 (or $x484 $x131)))
(let (($x727 (or $x459 false)))
(let (($x739 (or $x727 false)))
(let (($x1109 (or (or $x739 false false) $x131)))
(and (not $x1109) (or $x1109 (and (distinct ?x1111 ?x1111) true))))))))))))))
(check-sat)
; query 136: function Gsm_Preprocess, block 54, name %61
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_64 () (_ BitVec 64))
(assert
 (let ((?x847 (bvashr in.04_64 (_ bv15 64))))
(let ((?x471 ((_ extract 15 0) ?x847)))
(let ((?x857 ((_ sign_extend 48) ?x471)))
(let ((?x1111 (bvshl ?x857 (_ bv15 64))))
(let ((?x972 (bvsub in.04_64 ?x1111)))
(let (($x1065 (and (distinct (bvsub ((_ sign_extend 1) in.04_64) ((_ sign_extend 1) ?x1111)) ((_ sign_extend 1) ?x972)) true)))
(let (($x131 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x484 (or false false false)))
(let (($x459 (or $x484 $x131)))
(let (($x727 (or $x459 false)))
(let (($x739 (or $x727 false)))
(let (($x1109 (or (or $x739 false false) $x131)))
(let (($x808 (or false $x1109 (or $x1065))))
(and (not $x808) (or $x808 (and (distinct ?x972 ?x972) true)))))))))))))))))
(check-sat)
; query 137: function Gsm_Preprocess, block 54, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_64 () (_ BitVec 64))
(assert
 (let ((?x847 (bvashr in.04_64 (_ bv15 64))))
(let ((?x471 ((_ extract 15 0) ?x847)))
(let ((?x857 ((_ sign_extend 48) ?x471)))
(let ((?x1111 (bvshl ?x857 (_ bv15 64))))
(let ((?x972 (bvsub in.04_64 ?x1111)))
(let ((?x441 ((_ extract 15 0) ?x972)))
(let (($x1065 (and (distinct (bvsub ((_ sign_extend 1) in.04_64) ((_ sign_extend 1) ?x1111)) ((_ sign_extend 1) ?x972)) true)))
(let (($x131 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x484 (or false false false)))
(let (($x459 (or $x484 $x131)))
(let (($x727 (or $x459 false)))
(let (($x739 (or $x727 false)))
(let (($x1109 (or (or $x739 false false) $x131)))
(let (($x808 (or false $x1109 (or $x1065))))
(let (($x981 (or $x808 false)))
(and (not $x981) (or $x981 (and (distinct ?x441 ?x441) true)))))))))))))))))))
(check-sat)
; query 138: function Gsm_Preprocess, block 54, name %63
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_64 () (_ BitVec 64))
(assert
 (let ((?x847 (bvashr in.04_64 (_ bv15 64))))
(let ((?x471 ((_ extract 15 0) ?x847)))
(let ((?x857 ((_ sign_extend 48) ?x471)))
(let ((?x1111 (bvshl ?x857 (_ bv15 64))))
(let ((?x972 (bvsub in.04_64 ?x1111)))
(let ((?x441 ((_ extract 15 0) ?x972)))
(let ((?x142 ((_ sign_extend 48) ?x441)))
(let (($x1065 (and (distinct (bvsub ((_ sign_extend 1) in.04_64) ((_ sign_extend 1) ?x1111)) ((_ sign_extend 1) ?x972)) true)))
(let (($x131 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x484 (or false false false)))
(let (($x459 (or $x484 $x131)))
(let (($x727 (or $x459 false)))
(let (($x739 (or $x727 false)))
(let (($x1109 (or (or $x739 false false) $x131)))
(let (($x808 (or false $x1109 (or $x1065))))
(let (($x981 (or $x808 false)))
(let (($x997 (or $x981 false)))
(and (not $x997) (or $x997 (and (distinct ?x142 ?x142) true)))))))))))))))))))))
(check-sat)
; query 139: function Gsm_Preprocess, block 54, name %64
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_64 () (_ BitVec 64))
(assert
 (let ((?x847 (bvashr in.04_64 (_ bv15 64))))
(let ((?x471 ((_ extract 15 0) ?x847)))
(let ((?x857 ((_ sign_extend 48) ?x471)))
(let ((?x1111 (bvshl ?x857 (_ bv15 64))))
(let ((?x972 (bvsub in.04_64 ?x1111)))
(let ((?x441 ((_ extract 15 0) ?x972)))
(let ((?x142 ((_ sign_extend 48) ?x441)))
(let ((?x566 (bvmul ?x142 (_ bv32735 64))))
(let (($x1069 (and (distinct (bvmul ((_ sign_extend 64) ?x142) ((_ sign_extend 64) (_ bv32735 64))) ((_ sign_extend 64) ?x566)) true)))
(let (($x1065 (and (distinct (bvsub ((_ sign_extend 1) in.04_64) ((_ sign_extend 1) ?x1111)) ((_ sign_extend 1) ?x972)) true)))
(let (($x131 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x484 (or false false false)))
(let (($x459 (or $x484 $x131)))
(let (($x727 (or $x459 false)))
(let (($x739 (or $x727 false)))
(let (($x1109 (or (or $x739 false false) $x131)))
(let (($x808 (or false $x1109 (or $x1065))))
(let (($x981 (or $x808 false)))
(let (($x997 (or $x981 false)))
(let (($x1050 (or $x997 false (or $x1069))))
(and (not $x1050) (or $x1050 (and (distinct ?x566 ?x566) true))))))))))))))))))))))))
(check-sat)
; query 140: function Gsm_Preprocess, block 54, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_64 () (_ BitVec 64))
(assert
 (let ((?x847 (bvashr in.04_64 (_ bv15 64))))
(let ((?x471 ((_ extract 15 0) ?x847)))
(let ((?x857 ((_ sign_extend 48) ?x471)))
(let ((?x1111 (bvshl ?x857 (_ bv15 64))))
(let ((?x972 (bvsub in.04_64 ?x1111)))
(let ((?x441 ((_ extract 15 0) ?x972)))
(let ((?x142 ((_ sign_extend 48) ?x441)))
(let ((?x566 (bvmul ?x142 (_ bv32735 64))))
(let ((?x655 (bvadd ?x566 (_ bv16384 64))))
(let (($x848 (and (distinct (bvadd ((_ sign_extend 1) ?x566) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x655)) true)))
(let (($x1069 (and (distinct (bvmul ((_ sign_extend 64) ?x142) ((_ sign_extend 64) (_ bv32735 64))) ((_ sign_extend 64) ?x566)) true)))
(let (($x1065 (and (distinct (bvsub ((_ sign_extend 1) in.04_64) ((_ sign_extend 1) ?x1111)) ((_ sign_extend 1) ?x972)) true)))
(let (($x131 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x484 (or false false false)))
(let (($x459 (or $x484 $x131)))
(let (($x727 (or $x459 false)))
(let (($x739 (or $x727 false)))
(let (($x1109 (or (or $x739 false false) $x131)))
(let (($x808 (or false $x1109 (or $x1065))))
(let (($x981 (or $x808 false)))
(let (($x997 (or $x981 false)))
(let (($x1050 (or $x997 false (or $x1069))))
(let (($x993 (or $x1050 false (or $x848))))
(and (not $x993) (or $x993 (and (distinct ?x655 ?x655) true)))))))))))))))))))))))))))
(check-sat)
; query 141: function Gsm_Preprocess, block 54, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_64 () (_ BitVec 64))
(assert
 (let ((?x847 (bvashr in.04_64 (_ bv15 64))))
(let ((?x471 ((_ extract 15 0) ?x847)))
(let ((?x857 ((_ sign_extend 48) ?x471)))
(let ((?x1111 (bvshl ?x857 (_ bv15 64))))
(let ((?x972 (bvsub in.04_64 ?x1111)))
(let ((?x441 ((_ extract 15 0) ?x972)))
(let ((?x142 ((_ sign_extend 48) ?x441)))
(let ((?x566 (bvmul ?x142 (_ bv32735 64))))
(let ((?x655 (bvadd ?x566 (_ bv16384 64))))
(let ((?x866 (bvashr ?x655 (_ bv15 64))))
(let (($x131 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x848 (and (distinct (bvadd ((_ sign_extend 1) ?x566) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x655)) true)))
(let (($x1069 (and (distinct (bvmul ((_ sign_extend 64) ?x142) ((_ sign_extend 64) (_ bv32735 64))) ((_ sign_extend 64) ?x566)) true)))
(let (($x1065 (and (distinct (bvsub ((_ sign_extend 1) in.04_64) ((_ sign_extend 1) ?x1111)) ((_ sign_extend 1) ?x972)) true)))
(let (($x484 (or false false false)))
(let (($x459 (or $x484 $x131)))
(let (($x727 (or $x459 false)))
(let (($x739 (or $x727 false)))
(let (($x1109 (or (or $x739 false false) $x131)))
(let (($x808 (or false $x1109 (or $x1065))))
(let (($x981 (or $x808 false)))
(let (($x997 (or $x981 false)))
(let (($x1050 (or $x997 false (or $x1069))))
(let (($x993 (or $x1050 false (or $x848))))
(let (($x664 (or (or $x993 false false) $x131)))
(and (not $x664) (or $x664 (and (distinct ?x866 ?x866) true)))))))))))))))))))))))))))))
(check-sat)
; query 142: function Gsm_Preprocess, block 54, name %67
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_64 () (_ BitVec 64))
(declare-fun in44_16 () (_ BitVec 16))
(assert
 (let ((?x847 (bvashr in.04_64 (_ bv15 64))))
(let ((?x471 ((_ extract 15 0) ?x847)))
(let ((?x857 ((_ sign_extend 48) ?x471)))
(let ((?x1111 (bvshl ?x857 (_ bv15 64))))
(let ((?x972 (bvsub in.04_64 ?x1111)))
(let ((?x441 ((_ extract 15 0) ?x972)))
(let ((?x142 ((_ sign_extend 48) ?x441)))
(let ((?x566 (bvmul ?x142 (_ bv32735 64))))
(let ((?x655 (bvadd ?x566 (_ bv16384 64))))
(let ((?x866 (bvashr ?x655 (_ bv15 64))))
(let ((?x353 ((_ sign_extend 48) in44_16)))
(let ((?x935 (bvshl ?x353 (_ bv15 64))))
(let ((?x836 (bvadd ?x935 ?x866)))
(let (($x1099 (and (distinct (bvadd ((_ sign_extend 1) ?x935) ((_ sign_extend 1) ?x866)) ((_ sign_extend 1) ?x836)) true)))
(let (($x131 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x848 (and (distinct (bvadd ((_ sign_extend 1) ?x566) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x655)) true)))
(let (($x1069 (and (distinct (bvmul ((_ sign_extend 64) ?x142) ((_ sign_extend 64) (_ bv32735 64))) ((_ sign_extend 64) ?x566)) true)))
(let (($x1065 (and (distinct (bvsub ((_ sign_extend 1) in.04_64) ((_ sign_extend 1) ?x1111)) ((_ sign_extend 1) ?x972)) true)))
(let (($x484 (or false false false)))
(let (($x459 (or $x484 $x131)))
(let (($x727 (or $x459 false)))
(let (($x739 (or $x727 false)))
(let (($x1109 (or (or $x739 false false) $x131)))
(let (($x808 (or false $x1109 (or $x1065))))
(let (($x981 (or $x808 false)))
(let (($x997 (or $x981 false)))
(let (($x1050 (or $x997 false (or $x1069))))
(let (($x993 (or $x1050 false (or $x848))))
(let (($x664 (or (or $x993 false false) $x131)))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x432 (or $x145 $x131)))
(let (($x1005 (or $x432 $x664 (or $x1099))))
(and (not $x1005) (or $x1005 (and (distinct ?x836 ?x836) true)))))))))))))))))))))))))))))))))))))
(check-sat)
; query 143: function Gsm_Preprocess, block 54, name %68
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_64 () (_ BitVec 64))
(assert
 (let ((?x847 (bvashr in.04_64 (_ bv15 64))))
(let ((?x471 ((_ extract 15 0) ?x847)))
(let ((?x857 ((_ sign_extend 48) ?x471)))
(let (($x131 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x484 (or false false false)))
(let (($x459 (or $x484 $x131)))
(let (($x727 (or $x459 false)))
(let (($x739 (or $x727 false)))
(and (not $x739) (or $x739 (and (distinct ?x857 ?x857) true))))))))))))
(check-sat)
; query 144: function Gsm_Preprocess, block 54, name %69
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_64 () (_ BitVec 64))
(assert
 (let ((?x847 (bvashr in.04_64 (_ bv15 64))))
(let ((?x471 ((_ extract 15 0) ?x847)))
(let ((?x857 ((_ sign_extend 48) ?x471)))
(let ((?x903 (bvmul ?x857 (_ bv32735 64))))
(let (($x944 (and (distinct (bvmul ((_ sign_extend 64) ?x857) ((_ sign_extend 64) (_ bv32735 64))) ((_ sign_extend 64) ?x903)) true)))
(let (($x131 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x484 (or false false false)))
(let (($x459 (or $x484 $x131)))
(let (($x727 (or $x459 false)))
(let (($x739 (or $x727 false)))
(let (($x752 (or $x739 false (or $x944))))
(and (not $x752) (or $x752 (and (distinct ?x903 ?x903) true)))))))))))))))
(check-sat)
; query 145: function Gsm_Preprocess, block 54, name %70
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_64 () (_ BitVec 64))
(assert
 (let ((?x847 (bvashr in.04_64 (_ bv15 64))))
(let ((?x471 ((_ extract 15 0) ?x847)))
(let ((?x857 ((_ sign_extend 48) ?x471)))
(let ((?x903 (bvmul ?x857 (_ bv32735 64))))
(let ((?x1017 (ite (bvsgt (_ bv0 64) ?x903) (_ bv1 1) (_ bv0 1))))
(let (($x944 (and (distinct (bvmul ((_ sign_extend 64) ?x857) ((_ sign_extend 64) (_ bv32735 64))) ((_ sign_extend 64) ?x903)) true)))
(let (($x131 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x484 (or false false false)))
(let (($x459 (or $x484 $x131)))
(let (($x727 (or $x459 false)))
(let (($x739 (or $x727 false)))
(let (($x752 (or $x739 false (or $x944))))
(let (($x1104 (or $x752 false false)))
(and (not $x1104) (or $x1104 (and (distinct ?x1017 ?x1017) true)))))))))))))))))
(check-sat)
; query 146: function Gsm_Preprocess, block 71, name %72
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in67_64 () (_ BitVec 64))
(assert
 (let ((?x144 (ite (bvsle (_ bv0 64) in67_64) (_ bv1 1) (_ bv0 1))))
(let (($x484 (or false false false)))
(let (($x225 (not $x484)))
(and $x225 (or $x484 (and (distinct ?x144 ?x144) true)))))))
(check-sat)
; query 147: function Gsm_Preprocess, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in69_64 () (_ BitVec 64))
(declare-fun in67_64 () (_ BitVec 64))
(assert
 (let ((?x943 (bvadd in67_64 in69_64)))
(let ((?x480 (bvadd in69_64 in67_64)))
(let (($x1097 (and (distinct ?x480 ?x943) true)))
(let (($x598 (and (distinct (bvadd ((_ sign_extend 1) in67_64) ((_ sign_extend 1) in69_64)) ((_ sign_extend 1) ?x943)) true)))
(let (($x765 (and (distinct (bvadd ((_ sign_extend 1) in69_64) ((_ sign_extend 1) in67_64)) ((_ sign_extend 1) ?x480)) true)))
(and (not (or false false (or $x765))) (or (or false false (or $x598)) $x1097))))))))
(check-sat)
; query 148: function Gsm_Preprocess, block 75, name %76
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in69_64 () (_ BitVec 64))
(assert
 (let ((?x189 (bvadd in69_64 (_ bv1 64))))
(let ((?x1029 ((_ sign_extend 1) ?x189)))
(let (($x587 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in69_64) ((_ sign_extend 1) (_ bv1 64))) ?x1029) true)))))
(and (not $x587) (or $x587 (and (distinct ?x189 ?x189) true)))))))
(check-sat)
; query 149: function Gsm_Preprocess, block 75, name %77
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in69_64 () (_ BitVec 64))
(assert
 (let ((?x189 (bvadd in69_64 (_ bv1 64))))
(let ((?x304 (bvsub (_ bv0 64) ?x189)))
(let (($x579 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x189)) ((_ sign_extend 1) ?x304)) true)))
(let ((?x1029 ((_ sign_extend 1) ?x189)))
(let (($x587 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in69_64) ((_ sign_extend 1) (_ bv1 64))) ?x1029) true)))))
(let (($x450 (or false $x587 (or $x579))))
(and (not $x450) (or $x450 (and (distinct ?x304 ?x304) true))))))))))
(check-sat)
; query 150: function Gsm_Preprocess, block 75, name %78
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in67_64 () (_ BitVec 64))
(assert
 (let ((?x822 (bvadd in67_64 (_ bv1 64))))
(let ((?x1044 ((_ sign_extend 1) ?x822)))
(let (($x959 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in67_64) ((_ sign_extend 1) (_ bv1 64))) ?x1044) true)))))
(and (not $x959) (or $x959 (and (distinct ?x822 ?x822) true)))))))
(check-sat)
; query 151: function Gsm_Preprocess, block 75, name %79
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in67_64 () (_ BitVec 64))
(assert
 (let ((?x822 (bvadd in67_64 (_ bv1 64))))
(let ((?x1013 (bvsub (_ bv0 64) ?x822)))
(let (($x994 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x822)) ((_ sign_extend 1) ?x1013)) true)))
(let ((?x1044 ((_ sign_extend 1) ?x822)))
(let (($x959 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in67_64) ((_ sign_extend 1) (_ bv1 64))) ?x1044) true)))))
(let (($x890 (or false $x959 (or $x994))))
(and (not $x890) (or $x890 (and (distinct ?x1013 ?x1013) true))))))))))
(check-sat)
; query 152: function Gsm_Preprocess, block 75, name %80
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in69_64 () (_ BitVec 64))
(declare-fun in67_64 () (_ BitVec 64))
(assert
 (let ((?x189 (bvadd in69_64 (_ bv1 64))))
(let ((?x304 (bvsub (_ bv0 64) ?x189)))
(let ((?x822 (bvadd in67_64 (_ bv1 64))))
(let ((?x1013 (bvsub (_ bv0 64) ?x822)))
(let ((?x811 (bvadd ?x1013 ?x304)))
(let ((?x735 (bvadd ?x304 ?x1013)))
(let (($x579 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x189)) ((_ sign_extend 1) ?x304)) true)))
(let ((?x1029 ((_ sign_extend 1) ?x189)))
(let (($x587 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in69_64) ((_ sign_extend 1) (_ bv1 64))) ?x1029) true)))))
(let (($x450 (or false $x587 (or $x579))))
(let (($x994 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x822)) ((_ sign_extend 1) ?x1013)) true)))
(let ((?x1044 ((_ sign_extend 1) ?x822)))
(let (($x959 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in67_64) ((_ sign_extend 1) (_ bv1 64))) ?x1044) true)))))
(let (($x890 (or false $x959 (or $x994))))
(let (($x841 (or $x890 $x450 false)))
(and (not (or $x450 $x890 false)) (or $x841 (and (distinct ?x735 ?x811) true)))))))))))))))))))
(check-sat)
; query 153: function Gsm_Preprocess, block 75, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in69_64 () (_ BitVec 64))
(declare-fun in67_64 () (_ BitVec 64))
(assert
 (let ((?x189 (bvadd in69_64 (_ bv1 64))))
(let ((?x304 (bvsub (_ bv0 64) ?x189)))
(let ((?x822 (bvadd in67_64 (_ bv1 64))))
(let ((?x1013 (bvsub (_ bv0 64) ?x822)))
(let ((?x811 (bvadd ?x1013 ?x304)))
(let (($x751 (and (distinct (ite (bvuge (bvadd ?x304 ?x1013) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1)) (ite (bvuge ?x811 (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))) true)))
(let (($x579 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x189)) ((_ sign_extend 1) ?x304)) true)))
(let ((?x1029 ((_ sign_extend 1) ?x189)))
(let (($x587 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in69_64) ((_ sign_extend 1) (_ bv1 64))) ?x1029) true)))))
(let (($x450 (or false $x587 (or $x579))))
(let (($x994 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x822)) ((_ sign_extend 1) ?x1013)) true)))
(let ((?x1044 ((_ sign_extend 1) ?x822)))
(let (($x959 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in67_64) ((_ sign_extend 1) (_ bv1 64))) ?x1044) true)))))
(let (($x890 (or false $x959 (or $x994))))
(let (($x841 (or $x890 $x450 false)))
(and (not (or (or $x450 $x890 false) false false)) (or (or $x841 false false) $x751))))))))))))))))))
(check-sat)
; query 154: function Gsm_Preprocess, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in80_64 () (_ BitVec 64))
(assert
 (let ((?x1089 (bvsub (_ bv0 64) in80_64)))
(let ((?x1036 ((_ sign_extend 1) ?x1089)))
(let (($x690 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in80_64)) ?x1036) true)))))
(and (not $x690) (or $x690 (and (distinct ?x1089 ?x1089) true)))))))
(check-sat)
; query 155: function Gsm_Preprocess, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in80_64 () (_ BitVec 64))
(assert
 (let ((?x1089 (bvsub (_ bv0 64) in80_64)))
(let ((?x845 (bvsub ?x1089 (_ bv2 64))))
(let ((?x1036 ((_ sign_extend 1) ?x1089)))
(let (($x690 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in80_64)) ?x1036) true)))))
(let (($x805 (or $x690 false (or (and (distinct (bvsub ?x1036 ((_ sign_extend 1) (_ bv2 64))) ((_ sign_extend 1) ?x845)) true)))))
(and (not $x805) (or (or $x690 false false) (and (distinct ?x845 (bvadd ?x1089 (_ bv18446744073709551614 64))) true)))))))))
(check-sat)
; query 156: function Gsm_Preprocess, block 90, name %91
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in67_64 () (_ BitVec 64))
(assert
 (let ((?x1106 (ite (bvsge (_ bv0 64) in67_64) (_ bv1 1) (_ bv0 1))))
(let (($x484 (or false false false)))
(let (($x225 (not $x484)))
(and $x225 (or $x484 (and (distinct ?x1106 ?x1106) true)))))))
(check-sat)
; query 157: function Gsm_Preprocess, block 92, name %93
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in69_64 () (_ BitVec 64))
(declare-fun in67_64 () (_ BitVec 64))
(assert
 (let ((?x943 (bvadd in67_64 in69_64)))
(let ((?x480 (bvadd in69_64 in67_64)))
(let (($x1097 (and (distinct ?x480 ?x943) true)))
(let (($x598 (and (distinct (bvadd ((_ sign_extend 1) in67_64) ((_ sign_extend 1) in69_64)) ((_ sign_extend 1) ?x943)) true)))
(let (($x765 (and (distinct (bvadd ((_ sign_extend 1) in69_64) ((_ sign_extend 1) in67_64)) ((_ sign_extend 1) ?x480)) true)))
(and (not (or false false (or $x765))) (or (or false false (or $x598)) $x1097))))))))
(check-sat)
; query 158: function Gsm_Preprocess, block 94, name %95
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in69_64 () (_ BitVec 64))
(declare-fun in67_64 () (_ BitVec 64))
(assert
 (let ((?x943 (bvadd in67_64 in69_64)))
(let ((?x480 (bvadd in69_64 in67_64)))
(let (($x1097 (and (distinct ?x480 ?x943) true)))
(let (($x484 (or false false false)))
(let (($x225 (not $x484)))
(and $x225 (or $x484 $x1097))))))))
(check-sat)
; query 159: function Gsm_Preprocess, block 94, name %96
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in69_64 () (_ BitVec 64))
(declare-fun in67_64 () (_ BitVec 64))
(assert
 (let (($x1060 (and (distinct (ite (bvuge (bvadd in69_64 in67_64) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1)) (ite (bvuge (bvadd in67_64 in69_64) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))) true)))
(let (($x484 (or false false false)))
(let (($x595 (or $x484 false false)))
(let (($x652 (not $x595)))
(and $x652 (or $x595 $x1060)))))))
(check-sat)
; query 160: function LARp_to_rp, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in19_16) ((_ sign_extend 16) in19_16)) true))))))
(check-sat)
; query 161: function LARp_to_rp, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x885 ((_ sign_extend 16) in19_16)))
(let ((?x996 (bvshl ?x885 (_ bv1 32))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x408 (or $x145 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x426 (not $x408)))
(and $x426 (or $x408 (and (distinct ?x996 ?x996) true))))))))))
(check-sat)
; query 162: function LARp_to_rp, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x885 ((_ sign_extend 16) in19_16)))
(let ((?x996 (bvshl ?x885 (_ bv1 32))))
(let ((?x910 ((_ sign_extend 32) ?x996)))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x408 (or $x145 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x1047 (or $x408 false)))
(let (($x788 (not $x1047)))
(and $x788 (or $x1047 (and (distinct ?x910 ?x910) true))))))))))))
(check-sat)
; query 163: function LARp_to_rp, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in19_16) ((_ sign_extend 16) in19_16)) true))))))
(check-sat)
; query 164: function LARp_to_rp, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x673 (ite (bvsgt (_ bv20070 32) ((_ sign_extend 16) in19_16)) (_ bv1 1) (_ bv0 1))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x128 (not $x145)))
(and $x128 (or $x145 (and (distinct ?x673 ?x673) true))))))))
(check-sat)
; query 165: function LARp_to_rp, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in19_16) ((_ sign_extend 16) in19_16)) true))))))
(check-sat)
; query 166: function LARp_to_rp, block 29, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x885 ((_ sign_extend 16) in19_16)))
(let ((?x982 (bvadd ?x885 (_ bv11059 32))))
(let (($x973 (and (distinct (bvadd ((_ sign_extend 1) ?x885) ((_ sign_extend 1) (_ bv11059 32))) ((_ sign_extend 1) ?x982)) true)))
(let (($x16 (or false false)))
(let (($x901 (or $x16 false (or $x973))))
(and (not $x901) (or $x901 (and (distinct ?x982 ?x982) true)))))))))
(check-sat)
; query 167: function LARp_to_rp, block 29, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x885 ((_ sign_extend 16) in19_16)))
(let ((?x982 (bvadd ?x885 (_ bv11059 32))))
(let ((?x1045 ((_ sign_extend 32) ?x982)))
(let (($x973 (and (distinct (bvadd ((_ sign_extend 1) ?x885) ((_ sign_extend 1) (_ bv11059 32))) ((_ sign_extend 1) ?x982)) true)))
(let (($x16 (or false false)))
(let (($x901 (or $x16 false (or $x973))))
(let (($x1082 (or $x901 false)))
(and (not $x1082) (or $x1082 (and (distinct ?x1045 ?x1045) true)))))))))))
(check-sat)
; query 168: function LARp_to_rp, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in19_16) ((_ sign_extend 16) in19_16)) true))))))
(check-sat)
; query 169: function LARp_to_rp, block 33, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x885 ((_ sign_extend 16) in19_16)))
(let ((?x1113 (bvashr ?x885 (_ bv2 32))))
(let (($x810 (bvuge (_ bv2 32) (_ bv32 32))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x933 (or $x145 $x810)))
(and (not $x933) (or $x933 (and (distinct ?x1113 ?x1113) true))))))))))
(check-sat)
; query 170: function LARp_to_rp, block 33, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x885 ((_ sign_extend 16) in19_16)))
(let ((?x1113 (bvashr ?x885 (_ bv2 32))))
(let ((?x850 ((_ sign_extend 32) ?x1113)))
(let (($x810 (bvuge (_ bv2 32) (_ bv32 32))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x933 (or $x145 $x810)))
(let (($x960 (or $x933 false)))
(and (not $x960) (or $x960 (and (distinct ?x850 ?x850) true))))))))))))
(check-sat)
; query 171: function LARp_to_rp, block 33, name %37
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x885 ((_ sign_extend 16) in19_16)))
(let ((?x1113 (bvashr ?x885 (_ bv2 32))))
(let ((?x850 ((_ sign_extend 32) ?x1113)))
(let ((?x906 (bvadd ?x850 (_ bv26112 64))))
(let ((?x717 ((_ sign_extend 1) ?x906)))
(let (($x810 (bvuge (_ bv2 32) (_ bv32 32))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x933 (or $x145 $x810)))
(let (($x960 (or $x933 false)))
(let (($x1046 (or $x960 false (or (and (distinct (bvadd ((_ sign_extend 1) ?x850) ((_ sign_extend 1) (_ bv26112 64))) ?x717) true)))))
(and (not $x1046) (or $x1046 (and (distinct ?x906 ?x906) true)))))))))))))))
(check-sat)
; query 172: function LARp_to_rp, block 33, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x885 ((_ sign_extend 16) in19_16)))
(let ((?x1113 (bvashr ?x885 (_ bv2 32))))
(let ((?x850 ((_ sign_extend 32) ?x1113)))
(let ((?x906 (bvadd ?x850 (_ bv26112 64))))
(let ((?x782 (bvsub ?x906 (_ bv18446744073709518848 64))))
(let (($x930 (and (distinct (bvsub ((_ sign_extend 1) ?x906) ((_ sign_extend 1) (_ bv18446744073709518848 64))) ((_ sign_extend 1) ?x782)) true)))
(let ((?x717 ((_ sign_extend 1) ?x906)))
(let (($x810 (bvuge (_ bv2 32) (_ bv32 32))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x933 (or $x145 $x810)))
(let (($x960 (or $x933 false)))
(let (($x1046 (or $x960 false (or (and (distinct (bvadd ((_ sign_extend 1) ?x850) ((_ sign_extend 1) (_ bv26112 64))) ?x717) true)))))
(let (($x783 (or $x1046 false (or $x930))))
(and (not $x783) (or $x783 (and (distinct ?x782 ?x782) true))))))))))))))))))
(check-sat)
; query 173: function LARp_to_rp, block 33, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x885 ((_ sign_extend 16) in19_16)))
(let ((?x1113 (bvashr ?x885 (_ bv2 32))))
(let ((?x850 ((_ sign_extend 32) ?x1113)))
(let ((?x906 (bvadd ?x850 (_ bv26112 64))))
(let ((?x782 (bvsub ?x906 (_ bv18446744073709518848 64))))
(let ((?x928 (ite (bvugt ?x782 (_ bv65535 64)) (_ bv1 1) (_ bv0 1))))
(let (($x930 (and (distinct (bvsub ((_ sign_extend 1) ?x906) ((_ sign_extend 1) (_ bv18446744073709518848 64))) ((_ sign_extend 1) ?x782)) true)))
(let ((?x717 ((_ sign_extend 1) ?x906)))
(let (($x810 (bvuge (_ bv2 32) (_ bv32 32))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x933 (or $x145 $x810)))
(let (($x960 (or $x933 false)))
(let (($x1046 (or $x960 false (or (and (distinct (bvadd ((_ sign_extend 1) ?x850) ((_ sign_extend 1) (_ bv26112 64))) ?x717) true)))))
(let (($x783 (or $x1046 false (or $x930))))
(let (($x956 (or $x783 false false)))
(and (not $x956) (or $x956 (and (distinct ?x928 ?x928) true))))))))))))))))))))
(check-sat)
; query 174: function Long_term_analysis_filtering, block 117, name %118
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in114_64 () (_ BitVec 64))
(assert
 (let ((?x1130 (ite (bvsge (_ bv18446744073709518848 64) in114_64) (_ bv1 1) (_ bv0 1))))
(let (($x484 (or false false false)))
(let (($x225 (not $x484)))
(and $x225 (or $x484 (and (distinct ?x1130 ?x1130) true)))))))
(check-sat)
; query 175: function Long_term_analysis_filtering, block 128, name %129
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let (($x1049 (and (distinct (bvadd ((_ sign_extend 1) in.2_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.2_32 (_ bv1 32)))) true)))
(let (($x250 (or false false (or $x1049))))
(and (not $x250) (or $x250 (and (distinct (bvadd in.2_32 (_ bv1 32)) (bvadd in.2_32 (_ bv1 32))) true))))))
(check-sat)
; query 176: function Long_term_analysis_filtering, block 158, name %159
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in155_64 () (_ BitVec 64))
(assert
 (let ((?x1138 (ite (bvsge (_ bv18446744073709518848 64) in155_64) (_ bv1 1) (_ bv0 1))))
(let (($x484 (or false false false)))
(let (($x225 (not $x484)))
(and $x225 (or $x484 (and (distinct ?x1138 ?x1138) true)))))))
(check-sat)
; query 177: function Long_term_analysis_filtering, block 169, name %170
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.3_32 () (_ BitVec 32))
(assert
 (let (($x43 (and (distinct (bvadd ((_ sign_extend 1) in.3_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.3_32 (_ bv1 32)))) true)))
(let (($x381 (or false false (or $x43))))
(and (not $x381) (or $x381 (and (distinct (bvadd in.3_32 (_ bv1 32)) (bvadd in.3_32 (_ bv1 32))) true))))))
(check-sat)
; query 178: function Long_term_analysis_filtering, block 35, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in32_64 () (_ BitVec 64))
(assert
 (let ((?x1140 (ite (bvsge (_ bv18446744073709518848 64) in32_64) (_ bv1 1) (_ bv0 1))))
(let (($x484 (or false false false)))
(let (($x225 (not $x484)))
(and $x225 (or $x484 (and (distinct ?x1140 ?x1140) true)))))))
(check-sat)
; query 179: function Long_term_analysis_filtering, block 46, name %47
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x398 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x839 (or false false (or $x398))))
(and (not $x839) (or $x839 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 180: function Long_term_analysis_filtering, block 76, name %77
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in73_64 () (_ BitVec 64))
(assert
 (let ((?x1149 (ite (bvsge (_ bv18446744073709518848 64) in73_64) (_ bv1 1) (_ bv0 1))))
(let (($x484 (or false false false)))
(let (($x225 (not $x484)))
(and $x225 (or $x484 (and (distinct ?x1149 ?x1149) true)))))))
(check-sat)
; query 181: function Long_term_analysis_filtering, block 87, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x254 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x646 (or false false (or $x254))))
(and (not $x646) (or $x646 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 182: function RPE_grid_positioning, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.27_32 () (_ BitVec 32))
(assert
 (let (($x1162 (and (distinct (bvadd ((_ sign_extend 1) in.27_32) ((_ sign_extend 1) (_ bv4294967295 32))) ((_ sign_extend 1) (bvadd in.27_32 (_ bv4294967295 32)))) true)))
(let (($x1166 (or false false (or $x1162))))
(and (not $x1166) (or $x1166 (and (distinct (bvadd in.27_32 (_ bv4294967295 32)) (bvadd in.27_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 183: function RPE_grid_positioning, block 31, name %33
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.27_32 () (_ BitVec 32))
(assert
 (let ((?x1155 (ite (and (distinct (_ bv0 32) (bvadd in.27_32 (_ bv4294967295 32))) true) (_ bv1 1) (_ bv0 1))))
(let (($x1162 (and (distinct (bvadd ((_ sign_extend 1) in.27_32) ((_ sign_extend 1) (_ bv4294967295 32))) ((_ sign_extend 1) (bvadd in.27_32 (_ bv4294967295 32)))) true)))
(let (($x1166 (or false false (or $x1162))))
(let (($x1165 (or $x1166 false false)))
(and (not $x1165) (or $x1165 (and (distinct ?x1155 ?x1155) true))))))))
(check-sat)
; query 184: function RPE_grid_positioning, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 185: function RPE_grid_positioning, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1175 (ite (bvsge (_ bv3 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x128 (not $x145)))
(and $x128 (or $x145 (and (distinct ?x1175 ?x1175) true))))))))
(check-sat)
; query 186: function RPE_grid_positioning, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 187: function RPE_grid_positioning, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1181 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1183 (and (distinct ?x1181 ?x1181) true)))
(let (($x16 (or false false)))
(let (($x1180 (or false $x16 false)))
(and (not $x1180) (or $x1180 $x1183)))))))
(check-sat)
; query 188: function Reflection_coefficients, block 101, name %102
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in89_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in89_16) ((_ sign_extend 16) in89_16)) true))))))
(check-sat)
; query 189: function Reflection_coefficients, block 116, name %117
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.4_32 () (_ BitVec 32))
(assert
 (let (($x49 (and (distinct (bvadd ((_ sign_extend 1) in.4_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.4_32 (_ bv1 32)))) true)))
(let (($x95 (or false false (or $x49))))
(and (not $x95) (or $x95 (and (distinct (bvadd in.4_32 (_ bv1 32)) (bvadd in.4_32 (_ bv1 32))) true))))))
(check-sat)
; query 190: function Reflection_coefficients, block 154, name %155
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.05_32 () (_ BitVec 32))
(assert
 (let ((?x1193 (ite (= (_ bv8 32) in.05_32) (_ bv1 1) (_ bv0 1))))
(let (($x484 (or false false false)))
(let (($x225 (not $x484)))
(and $x225 (or $x484 (and (distinct ?x1193 ?x1193) true)))))))
(check-sat)
; query 191: function Reflection_coefficients, block 34, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in31_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in31_16) ((_ sign_extend 16) in31_16)) true))))))
(check-sat)
; query 192: function Reflection_coefficients, block 34, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in31_16 () (_ BitVec 16))
(assert
 (let ((?x1199 (ite (bvsgt (_ bv32 32) ((_ sign_extend 16) in31_16)) (_ bv1 1) (_ bv0 1))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x128 (not $x145)))
(and $x128 (or $x145 (and (distinct ?x1199 ?x1199) true))))))))
(check-sat)
; query 193: function Reflection_coefficients, block 60, name %61
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x1212 (and (distinct (bvadd ((_ sign_extend 1) in.12_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.12_32 (_ bv1 32)))) true)))
(let (($x1214 (or false false (or $x1212))))
(and (not $x1214) (or $x1214 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 194: function Reflection_coefficients, block 71, name %72
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.23_32 () (_ BitVec 32))
(assert
 (let (($x1224 (and (distinct (bvadd ((_ sign_extend 1) in.23_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.23_32 (_ bv1 32)))) true)))
(let (($x1226 (or false false (or $x1224))))
(and (not $x1226) (or $x1226 (and (distinct (bvadd in.23_32 (_ bv1 32)) (bvadd in.23_32 (_ bv1 32))) true))))))
(check-sat)
; query 195: function Reflection_coefficients, block 82, name %83
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.3_32 () (_ BitVec 32))
(assert
 (let (($x43 (and (distinct (bvadd ((_ sign_extend 1) in.3_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.3_32 (_ bv1 32)))) true)))
(let (($x381 (or false false (or $x43))))
(and (not $x381) (or $x381 (and (distinct (bvadd in.3_32 (_ bv1 32)) (bvadd in.3_32 (_ bv1 32))) true))))))
(check-sat)
; query 196: function Reflection_coefficients, block 92, name %93
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in89_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in89_16) ((_ sign_extend 16) in89_16)) true))))))
(check-sat)
; query 197: function Reflection_coefficients, block 92, name %94
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in89_16 () (_ BitVec 16))
(assert
 (let ((?x1232 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in89_16)) (_ bv1 1) (_ bv0 1))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x128 (not $x145)))
(and $x128 (or $x145 (and (distinct ?x1232 ?x1232) true))))))))
(check-sat)
; query 198: function Reflection_coefficients, block 96, name %97
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in89_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in89_16) ((_ sign_extend 16) in89_16)) true))))))
(check-sat)
; query 199: function Reflection_coefficients, block 96, name %98
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in89_16 () (_ BitVec 16))
(assert
 (let ((?x1187 ((_ sign_extend 16) in89_16)))
(let ((?x1239 (bvsub (_ bv0 32) ?x1187)))
(let (($x1240 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1187)) ((_ sign_extend 1) ?x1239)) true)))
(let (($x16 (or false false)))
(let (($x1242 (or false $x16 (or $x1240))))
(and (not $x1242) (or $x1242 (and (distinct ?x1239 ?x1239) true)))))))))
(check-sat)
; query 200: function Short_term_synthesis_filtering, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in23_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in23_16) ((_ sign_extend 16) in23_16)) true))))))
(check-sat)
; query 201: function Short_term_synthesis_filtering, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in23_16 () (_ BitVec 16))
(assert
 (let ((?x1249 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in23_16)) (_ bv1 1) (_ bv0 1))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x128 (not $x145)))
(and $x128 (or $x145 (and (distinct ?x1249 ?x1249) true))))))))
(check-sat)
; query 202: function Short_term_synthesis_filtering, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in20_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 48) in20_16) ((_ sign_extend 48) in20_16)) true))))))
(check-sat)
; query 203: function Short_term_synthesis_filtering, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in23_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 48) in23_16) ((_ sign_extend 48) in23_16)) true))))))
(check-sat)
; query 204: function Short_term_synthesis_filtering, block 30, name %33
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in20_16 () (_ BitVec 16))
(declare-fun in23_16 () (_ BitVec 16))
(assert
 (let ((?x1251 ((_ sign_extend 48) in20_16)))
(let ((?x1250 ((_ sign_extend 48) in23_16)))
(let ((?x1283 (bvmul ?x1250 ?x1251)))
(let ((?x1265 (bvmul ?x1251 ?x1250)))
(let (($x1281 (and (distinct (bvmul ((_ sign_extend 64) ?x1250) ((_ sign_extend 64) ?x1251)) ((_ sign_extend 64) ?x1283)) true)))
(let (($x16 (or false false)))
(let (($x1285 (or $x16 $x16 (or $x1281))))
(let (($x1263 (and (distinct (bvmul ((_ sign_extend 64) ?x1251) ((_ sign_extend 64) ?x1250)) ((_ sign_extend 64) ?x1265)) true)))
(let (($x1267 (or $x16 $x16 (or $x1263))))
(and (not $x1267) (or $x1285 (and (distinct ?x1265 ?x1283) true)))))))))))))
(check-sat)
; query 205: function Short_term_synthesis_filtering, block 30, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in20_16 () (_ BitVec 16))
(declare-fun in23_16 () (_ BitVec 16))
(assert
 (let ((?x1251 ((_ sign_extend 48) in20_16)))
(let ((?x1250 ((_ sign_extend 48) in23_16)))
(let ((?x1283 (bvmul ?x1250 ?x1251)))
(let ((?x1288 (bvadd ?x1283 (_ bv16384 64))))
(let ((?x1265 (bvmul ?x1251 ?x1250)))
(let ((?x1270 (bvadd ?x1265 (_ bv16384 64))))
(let (($x1290 (and (distinct (bvadd ((_ sign_extend 1) ?x1283) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x1288)) true)))
(let (($x1281 (and (distinct (bvmul ((_ sign_extend 64) ?x1250) ((_ sign_extend 64) ?x1251)) ((_ sign_extend 64) ?x1283)) true)))
(let (($x16 (or false false)))
(let (($x1285 (or $x16 $x16 (or $x1281))))
(let (($x1292 (or $x1285 false (or $x1290))))
(let (($x1272 (and (distinct (bvadd ((_ sign_extend 1) ?x1265) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x1270)) true)))
(let (($x1263 (and (distinct (bvmul ((_ sign_extend 64) ?x1251) ((_ sign_extend 64) ?x1250)) ((_ sign_extend 64) ?x1265)) true)))
(let (($x1267 (or $x16 $x16 (or $x1263))))
(let (($x1274 (or $x1267 false (or $x1272))))
(and (not $x1274) (or $x1292 (and (distinct ?x1270 ?x1288) true)))))))))))))))))))
(check-sat)
; query 206: function Short_term_synthesis_filtering, block 30, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in20_16 () (_ BitVec 16))
(declare-fun in23_16 () (_ BitVec 16))
(assert
 (let ((?x1251 ((_ sign_extend 48) in20_16)))
(let ((?x1250 ((_ sign_extend 48) in23_16)))
(let ((?x1283 (bvmul ?x1250 ?x1251)))
(let ((?x1288 (bvadd ?x1283 (_ bv16384 64))))
(let ((?x1295 (bvashr ?x1288 (_ bv15 64))))
(let ((?x1265 (bvmul ?x1251 ?x1250)))
(let ((?x1270 (bvadd ?x1265 (_ bv16384 64))))
(let ((?x1277 (bvashr ?x1270 (_ bv15 64))))
(let (($x131 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1290 (and (distinct (bvadd ((_ sign_extend 1) ?x1283) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x1288)) true)))
(let (($x1281 (and (distinct (bvmul ((_ sign_extend 64) ?x1250) ((_ sign_extend 64) ?x1251)) ((_ sign_extend 64) ?x1283)) true)))
(let (($x16 (or false false)))
(let (($x1285 (or $x16 $x16 (or $x1281))))
(let (($x1292 (or $x1285 false (or $x1290))))
(let (($x1294 (or (or $x1292 false false) $x131)))
(let (($x1272 (and (distinct (bvadd ((_ sign_extend 1) ?x1265) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x1270)) true)))
(let (($x1263 (and (distinct (bvmul ((_ sign_extend 64) ?x1251) ((_ sign_extend 64) ?x1250)) ((_ sign_extend 64) ?x1265)) true)))
(let (($x1267 (or $x16 $x16 (or $x1263))))
(let (($x1274 (or $x1267 false (or $x1272))))
(let (($x1276 (or (or $x1274 false false) $x131)))
(and (not $x1276) (or $x1294 (and (distinct ?x1277 ?x1295) true))))))))))))))))))))))))
(check-sat)
; query 207: function Short_term_synthesis_filtering, block 30, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in20_16 () (_ BitVec 16))
(declare-fun in23_16 () (_ BitVec 16))
(assert
 (let ((?x1251 ((_ sign_extend 48) in20_16)))
(let ((?x1250 ((_ sign_extend 48) in23_16)))
(let ((?x1283 (bvmul ?x1250 ?x1251)))
(let ((?x1288 (bvadd ?x1283 (_ bv16384 64))))
(let ((?x1295 (bvashr ?x1288 (_ bv15 64))))
(let (($x1317 (and (distinct (bvand (_ bv65535 64) (bvashr (bvadd (bvmul ?x1251 ?x1250) (_ bv16384 64)) (_ bv15 64))) (bvand ?x1295 (_ bv65535 64))) true)))
(let (($x131 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1290 (and (distinct (bvadd ((_ sign_extend 1) ?x1283) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x1288)) true)))
(let (($x1281 (and (distinct (bvmul ((_ sign_extend 64) ?x1250) ((_ sign_extend 64) ?x1251)) ((_ sign_extend 64) ?x1283)) true)))
(let (($x16 (or false false)))
(let (($x1285 (or $x16 $x16 (or $x1281))))
(let (($x1292 (or $x1285 false (or $x1290))))
(let (($x1294 (or (or $x1292 false false) $x131)))
(let (($x1272 (and (distinct (bvadd ((_ sign_extend 1) (bvmul ?x1251 ?x1250)) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) (bvadd (bvmul ?x1251 ?x1250) (_ bv16384 64)))) true)))
(let (($x1263 (and (distinct (bvmul ((_ sign_extend 64) ?x1251) ((_ sign_extend 64) ?x1250)) ((_ sign_extend 64) (bvmul ?x1251 ?x1250))) true)))
(let (($x1267 (or $x16 $x16 (or $x1263))))
(let (($x1274 (or $x1267 false (or $x1272))))
(let (($x1276 (or (or $x1274 false false) $x131)))
(and (not (or false $x1276 false)) (or (or $x1294 false false) $x1317)))))))))))))))))))))
(check-sat)
; query 208: function Short_term_synthesis_filtering, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in42_64 () (_ BitVec 64))
(assert
 (let ((?x1322 (ite (bvsge (_ bv18446744073709518848 64) in42_64) (_ bv1 1) (_ bv0 1))))
(let (($x484 (or false false false)))
(let (($x225 (not $x484)))
(and $x225 (or $x484 (and (distinct ?x1322 ?x1322) true)))))))
(check-sat)
; query 209: function Short_term_synthesis_filtering, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in53_16) ((_ sign_extend 16) in53_16)) true))))))
(check-sat)
; query 210: function Short_term_synthesis_filtering, block 56, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let ((?x1327 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in53_16)) (_ bv1 1) (_ bv0 1))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x128 (not $x145)))
(and $x128 (or $x145 (and (distinct ?x1327 ?x1327) true))))))))
(check-sat)
; query 211: function Short_term_synthesis_filtering, block 60, name %61
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in20_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 48) in20_16) ((_ sign_extend 48) in20_16)) true))))))
(check-sat)
; query 212: function Short_term_synthesis_filtering, block 60, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 48) in53_16) ((_ sign_extend 48) in53_16)) true))))))
(check-sat)
; query 213: function Short_term_synthesis_filtering, block 60, name %63
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in20_16 () (_ BitVec 16))
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let ((?x1251 ((_ sign_extend 48) in20_16)))
(let ((?x1331 ((_ sign_extend 48) in53_16)))
(let ((?x1354 (bvmul ?x1331 ?x1251)))
(let ((?x1336 (bvmul ?x1251 ?x1331)))
(let (($x1352 (and (distinct (bvmul ((_ sign_extend 64) ?x1331) ((_ sign_extend 64) ?x1251)) ((_ sign_extend 64) ?x1354)) true)))
(let (($x16 (or false false)))
(let (($x1356 (or $x16 $x16 (or $x1352))))
(let (($x1334 (and (distinct (bvmul ((_ sign_extend 64) ?x1251) ((_ sign_extend 64) ?x1331)) ((_ sign_extend 64) ?x1336)) true)))
(let (($x1338 (or $x16 $x16 (or $x1334))))
(and (not $x1338) (or $x1356 (and (distinct ?x1336 ?x1354) true)))))))))))))
(check-sat)
; query 214: function Short_term_synthesis_filtering, block 60, name %64
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in20_16 () (_ BitVec 16))
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let ((?x1251 ((_ sign_extend 48) in20_16)))
(let ((?x1331 ((_ sign_extend 48) in53_16)))
(let ((?x1354 (bvmul ?x1331 ?x1251)))
(let ((?x1359 (bvadd ?x1354 (_ bv16384 64))))
(let ((?x1336 (bvmul ?x1251 ?x1331)))
(let ((?x1341 (bvadd ?x1336 (_ bv16384 64))))
(let (($x1361 (and (distinct (bvadd ((_ sign_extend 1) ?x1354) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x1359)) true)))
(let (($x1352 (and (distinct (bvmul ((_ sign_extend 64) ?x1331) ((_ sign_extend 64) ?x1251)) ((_ sign_extend 64) ?x1354)) true)))
(let (($x16 (or false false)))
(let (($x1356 (or $x16 $x16 (or $x1352))))
(let (($x1363 (or $x1356 false (or $x1361))))
(let (($x1343 (and (distinct (bvadd ((_ sign_extend 1) ?x1336) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x1341)) true)))
(let (($x1334 (and (distinct (bvmul ((_ sign_extend 64) ?x1251) ((_ sign_extend 64) ?x1331)) ((_ sign_extend 64) ?x1336)) true)))
(let (($x1338 (or $x16 $x16 (or $x1334))))
(let (($x1345 (or $x1338 false (or $x1343))))
(and (not $x1345) (or $x1363 (and (distinct ?x1341 ?x1359) true)))))))))))))))))))
(check-sat)
; query 215: function Short_term_synthesis_filtering, block 60, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in20_16 () (_ BitVec 16))
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let ((?x1251 ((_ sign_extend 48) in20_16)))
(let ((?x1331 ((_ sign_extend 48) in53_16)))
(let ((?x1354 (bvmul ?x1331 ?x1251)))
(let ((?x1359 (bvadd ?x1354 (_ bv16384 64))))
(let ((?x1366 (bvashr ?x1359 (_ bv15 64))))
(let ((?x1336 (bvmul ?x1251 ?x1331)))
(let ((?x1341 (bvadd ?x1336 (_ bv16384 64))))
(let ((?x1348 (bvashr ?x1341 (_ bv15 64))))
(let (($x131 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1361 (and (distinct (bvadd ((_ sign_extend 1) ?x1354) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x1359)) true)))
(let (($x1352 (and (distinct (bvmul ((_ sign_extend 64) ?x1331) ((_ sign_extend 64) ?x1251)) ((_ sign_extend 64) ?x1354)) true)))
(let (($x16 (or false false)))
(let (($x1356 (or $x16 $x16 (or $x1352))))
(let (($x1363 (or $x1356 false (or $x1361))))
(let (($x1365 (or (or $x1363 false false) $x131)))
(let (($x1343 (and (distinct (bvadd ((_ sign_extend 1) ?x1336) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x1341)) true)))
(let (($x1334 (and (distinct (bvmul ((_ sign_extend 64) ?x1251) ((_ sign_extend 64) ?x1331)) ((_ sign_extend 64) ?x1336)) true)))
(let (($x1338 (or $x16 $x16 (or $x1334))))
(let (($x1345 (or $x1338 false (or $x1343))))
(let (($x1347 (or (or $x1345 false false) $x131)))
(and (not $x1347) (or $x1365 (and (distinct ?x1348 ?x1366) true))))))))))))))))))))))))
(check-sat)
; query 216: function Short_term_synthesis_filtering, block 60, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in20_16 () (_ BitVec 16))
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let ((?x1251 ((_ sign_extend 48) in20_16)))
(let ((?x1331 ((_ sign_extend 48) in53_16)))
(let ((?x1354 (bvmul ?x1331 ?x1251)))
(let ((?x1359 (bvadd ?x1354 (_ bv16384 64))))
(let ((?x1366 (bvashr ?x1359 (_ bv15 64))))
(let (($x1385 (and (distinct (bvand (_ bv65535 64) (bvashr (bvadd (bvmul ?x1251 ?x1331) (_ bv16384 64)) (_ bv15 64))) (bvand ?x1366 (_ bv65535 64))) true)))
(let (($x131 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1361 (and (distinct (bvadd ((_ sign_extend 1) ?x1354) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x1359)) true)))
(let (($x1352 (and (distinct (bvmul ((_ sign_extend 64) ?x1331) ((_ sign_extend 64) ?x1251)) ((_ sign_extend 64) ?x1354)) true)))
(let (($x16 (or false false)))
(let (($x1356 (or $x16 $x16 (or $x1352))))
(let (($x1363 (or $x1356 false (or $x1361))))
(let (($x1365 (or (or $x1363 false false) $x131)))
(let (($x1343 (and (distinct (bvadd ((_ sign_extend 1) (bvmul ?x1251 ?x1331)) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) (bvadd (bvmul ?x1251 ?x1331) (_ bv16384 64)))) true)))
(let (($x1334 (and (distinct (bvmul ((_ sign_extend 64) ?x1251) ((_ sign_extend 64) ?x1331)) ((_ sign_extend 64) (bvmul ?x1251 ?x1331))) true)))
(let (($x1338 (or $x16 $x16 (or $x1334))))
(let (($x1345 (or $x1338 false (or $x1343))))
(let (($x1347 (or (or $x1345 false false) $x131)))
(and (not (or false $x1347 false)) (or (or $x1365 false false) $x1385)))))))))))))))))))))
(check-sat)
; query 217: function Transformation_to_Log_Area_Ratios, block 12, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in5_16) ((_ sign_extend 16) in5_16)) true))))))
(check-sat)
; query 218: function Transformation_to_Log_Area_Ratios, block 12, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_16 () (_ BitVec 16))
(assert
 (let ((?x1388 ((_ sign_extend 16) in5_16)))
(let ((?x1401 (bvsub (_ bv0 32) ?x1388)))
(let (($x1402 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1388)) ((_ sign_extend 1) ?x1401)) true)))
(let (($x16 (or false false)))
(let (($x1397 (or false $x16 (or $x1402))))
(and (not $x1397) (or $x1397 (and (distinct ?x1401 ?x1401) true)))))))))
(check-sat)
; query 219: function Transformation_to_Log_Area_Ratios, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in5_16) ((_ sign_extend 16) in5_16)) true))))))
(check-sat)
; query 220: function Transformation_to_Log_Area_Ratios, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in21_16) ((_ sign_extend 16) in21_16)) true))))))
(check-sat)
; query 221: function Transformation_to_Log_Area_Ratios, block 31, name %33
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let ((?x1408 (ite (bvsgt (_ bv22118 32) ((_ sign_extend 16) in21_16)) (_ bv1 1) (_ bv0 1))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x128 (not $x145)))
(and $x128 (or $x145 (and (distinct ?x1408 ?x1408) true))))))))
(check-sat)
; query 222: function Transformation_to_Log_Area_Ratios, block 34, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in21_16) ((_ sign_extend 16) in21_16)) true))))))
(check-sat)
; query 223: function Transformation_to_Log_Area_Ratios, block 34, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let ((?x1405 ((_ sign_extend 16) in21_16)))
(let ((?x1415 (bvashr ?x1405 (_ bv1 32))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x408 (or $x145 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x426 (not $x408)))
(and $x426 (or $x408 (and (distinct ?x1415 ?x1415) true))))))))))
(check-sat)
; query 224: function Transformation_to_Log_Area_Ratios, block 34, name %37
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let ((?x1405 ((_ sign_extend 16) in21_16)))
(let ((?x1415 (bvashr ?x1405 (_ bv1 32))))
(let ((?x1416 ((_ extract 15 0) ?x1415)))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x408 (or $x145 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x1047 (or $x408 false)))
(let (($x788 (not $x1047)))
(and $x788 (or $x1047 (and (distinct ?x1416 ?x1416) true))))))))))))
(check-sat)
; query 225: function Transformation_to_Log_Area_Ratios, block 38, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in21_16) ((_ sign_extend 16) in21_16)) true))))))
(check-sat)
; query 226: function Transformation_to_Log_Area_Ratios, block 38, name %40
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let ((?x1425 (ite (bvsgt (_ bv31130 32) ((_ sign_extend 16) in21_16)) (_ bv1 1) (_ bv0 1))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x128 (not $x145)))
(and $x128 (or $x145 (and (distinct ?x1425 ?x1425) true))))))))
(check-sat)
; query 227: function Transformation_to_Log_Area_Ratios, block 41, name %42
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in21_16) ((_ sign_extend 16) in21_16)) true))))))
(check-sat)
; query 228: function Transformation_to_Log_Area_Ratios, block 41, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let ((?x1430 (ite (bvsle (_ bv11059 32) ((_ sign_extend 16) in21_16)) (_ bv1 1) (_ bv0 1))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x128 (not $x145)))
(and $x128 (or $x145 (and (distinct ?x1430 ?x1430) true))))))))
(check-sat)
; query 229: function Transformation_to_Log_Area_Ratios, block 41, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let ((?x1430 (ite (bvsle (_ bv11059 32) ((_ sign_extend 16) in21_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1431 (bvxor ?x1430 (_ bv1 1))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x694 (or $x145 false false)))
(let (($x430 (not $x694)))
(and $x430 (or $x694 (and (distinct ?x1431 ?x1431) true))))))))))
(check-sat)
; query 230: function Transformation_to_Log_Area_Ratios, block 41, name %45
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let ((?x1430 (ite (bvsle (_ bv11059 32) ((_ sign_extend 16) in21_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1431 (bvxor ?x1430 (_ bv1 1))))
(let ((?x1432 ((_ zero_extend 31) ?x1431)))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x694 (or $x145 false false)))
(let (($x749 (or $x694 false)))
(let (($x104 (not $x749)))
(and $x104 (or $x749 (and (distinct ?x1432 ?x1432) true))))))))))))
(check-sat)
; query 231: function Transformation_to_Log_Area_Ratios, block 41, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let ((?x1430 (ite (bvsle (_ bv11059 32) ((_ sign_extend 16) in21_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1431 (bvxor ?x1430 (_ bv1 1))))
(let ((?x1432 ((_ zero_extend 31) ?x1431)))
(let ((?x1433 ((_ sign_extend 32) ?x1432)))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x694 (or $x145 false false)))
(let (($x749 (or $x694 false)))
(let (($x687 (or $x749 false)))
(let (($x624 (not $x687)))
(and $x624 (or $x687 (and (distinct ?x1433 ?x1433) true))))))))))))))
(check-sat)
; query 232: function Transformation_to_Log_Area_Ratios, block 41, name %47
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let ((?x1430 (ite (bvsle (_ bv11059 32) ((_ sign_extend 16) in21_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1431 (bvxor ?x1430 (_ bv1 1))))
(let ((?x1432 ((_ zero_extend 31) ?x1431)))
(let ((?x1433 ((_ sign_extend 32) ?x1432)))
(let ((?x1435 (ite (and (distinct (_ bv0 64) ?x1433) true) (_ bv1 1) (_ bv0 1))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x694 (or $x145 false false)))
(let (($x749 (or $x694 false)))
(let (($x687 (or $x749 false)))
(let (($x813 (or $x687 false false)))
(let (($x212 (not $x813)))
(and $x212 (or $x813 (and (distinct ?x1435 ?x1435) true))))))))))))))))
(check-sat)
; query 233: function Transformation_to_Log_Area_Ratios, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in21_16) ((_ sign_extend 16) in21_16)) true))))))
(check-sat)
; query 234: function Transformation_to_Log_Area_Ratios, block 51, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let ((?x1405 ((_ sign_extend 16) in21_16)))
(let ((?x1454 (bvsub ?x1405 (_ bv11059 32))))
(let (($x1455 (and (distinct (bvsub ((_ sign_extend 1) ?x1405) ((_ sign_extend 1) (_ bv11059 32))) ((_ sign_extend 1) ?x1454)) true)))
(let (($x16 (or false false)))
(let (($x1457 (or $x16 false (or $x1455))))
(and (not $x1457) (or $x1457 (and (distinct ?x1454 ?x1454) true)))))))))
(check-sat)
; query 235: function Transformation_to_Log_Area_Ratios, block 51, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let ((?x1405 ((_ sign_extend 16) in21_16)))
(let ((?x1454 (bvsub ?x1405 (_ bv11059 32))))
(let ((?x1458 ((_ extract 15 0) ?x1454)))
(let (($x1455 (and (distinct (bvsub ((_ sign_extend 1) ?x1405) ((_ sign_extend 1) (_ bv11059 32))) ((_ sign_extend 1) ?x1454)) true)))
(let (($x16 (or false false)))
(let (($x1457 (or $x16 false (or $x1455))))
(let (($x1459 (or $x1457 false)))
(and (not $x1459) (or $x1459 (and (distinct ?x1458 ?x1458) true)))))))))))
(check-sat)
; query 236: function Transformation_to_Log_Area_Ratios, block 55, name %56
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in21_16) ((_ sign_extend 16) in21_16)) true))))))
(check-sat)
; query 237: function Transformation_to_Log_Area_Ratios, block 55, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let ((?x1470 (ite (bvsle (_ bv26112 32) ((_ sign_extend 16) in21_16)) (_ bv1 1) (_ bv0 1))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x128 (not $x145)))
(and $x128 (or $x145 (and (distinct ?x1470 ?x1470) true))))))))
(check-sat)
; query 238: function Transformation_to_Log_Area_Ratios, block 55, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let ((?x1470 (ite (bvsle (_ bv26112 32) ((_ sign_extend 16) in21_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1471 (bvxor ?x1470 (_ bv1 1))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x694 (or $x145 false false)))
(let (($x430 (not $x694)))
(and $x430 (or $x694 (and (distinct ?x1471 ?x1471) true))))))))))
(check-sat)
; query 239: function Transformation_to_Log_Area_Ratios, block 55, name %59
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let ((?x1470 (ite (bvsle (_ bv26112 32) ((_ sign_extend 16) in21_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1471 (bvxor ?x1470 (_ bv1 1))))
(let ((?x1472 ((_ zero_extend 31) ?x1471)))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x694 (or $x145 false false)))
(let (($x749 (or $x694 false)))
(let (($x104 (not $x749)))
(and $x104 (or $x749 (and (distinct ?x1472 ?x1472) true))))))))))))
(check-sat)
; query 240: function Transformation_to_Log_Area_Ratios, block 55, name %60
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let ((?x1470 (ite (bvsle (_ bv26112 32) ((_ sign_extend 16) in21_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1471 (bvxor ?x1470 (_ bv1 1))))
(let ((?x1472 ((_ zero_extend 31) ?x1471)))
(let ((?x1473 ((_ sign_extend 32) ?x1472)))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x694 (or $x145 false false)))
(let (($x749 (or $x694 false)))
(let (($x687 (or $x749 false)))
(let (($x624 (not $x687)))
(and $x624 (or $x687 (and (distinct ?x1473 ?x1473) true))))))))))))))
(check-sat)
; query 241: function Transformation_to_Log_Area_Ratios, block 55, name %61
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let ((?x1470 (ite (bvsle (_ bv26112 32) ((_ sign_extend 16) in21_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1471 (bvxor ?x1470 (_ bv1 1))))
(let ((?x1472 ((_ zero_extend 31) ?x1471)))
(let ((?x1473 ((_ sign_extend 32) ?x1472)))
(let ((?x1475 (ite (and (distinct (_ bv0 64) ?x1473) true) (_ bv1 1) (_ bv0 1))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x694 (or $x145 false false)))
(let (($x749 (or $x694 false)))
(let (($x687 (or $x749 false)))
(let (($x813 (or $x687 false false)))
(let (($x212 (not $x813)))
(and $x212 (or $x813 (and (distinct ?x1475 ?x1475) true))))))))))))))))
(check-sat)
; query 242: function Transformation_to_Log_Area_Ratios, block 65, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in21_16) ((_ sign_extend 16) in21_16)) true))))))
(check-sat)
; query 243: function Transformation_to_Log_Area_Ratios, block 65, name %67
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let ((?x1405 ((_ sign_extend 16) in21_16)))
(let ((?x1494 (bvsub ?x1405 (_ bv26112 32))))
(let (($x1495 (and (distinct (bvsub ((_ sign_extend 1) ?x1405) ((_ sign_extend 1) (_ bv26112 32))) ((_ sign_extend 1) ?x1494)) true)))
(let (($x16 (or false false)))
(let (($x1497 (or $x16 false (or $x1495))))
(and (not $x1497) (or $x1497 (and (distinct ?x1494 ?x1494) true)))))))))
(check-sat)
; query 244: function Transformation_to_Log_Area_Ratios, block 65, name %68
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let ((?x1405 ((_ sign_extend 16) in21_16)))
(let ((?x1494 (bvsub ?x1405 (_ bv26112 32))))
(let ((?x1498 ((_ extract 15 0) ?x1494)))
(let (($x1495 (and (distinct (bvsub ((_ sign_extend 1) ?x1405) ((_ sign_extend 1) (_ bv26112 32))) ((_ sign_extend 1) ?x1494)) true)))
(let (($x16 (or false false)))
(let (($x1497 (or $x16 false (or $x1495))))
(let (($x1499 (or $x1497 false)))
(and (not $x1499) (or $x1499 (and (distinct ?x1498 ?x1498) true)))))))))))
(check-sat)
; query 245: function Transformation_to_Log_Area_Ratios, block 65, name %69
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let ((?x1405 ((_ sign_extend 16) in21_16)))
(let ((?x1494 (bvsub ?x1405 (_ bv26112 32))))
(let ((?x1498 ((_ extract 15 0) ?x1494)))
(let ((?x1500 ((_ sign_extend 16) ?x1498)))
(let (($x1495 (and (distinct (bvsub ((_ sign_extend 1) ?x1405) ((_ sign_extend 1) (_ bv26112 32))) ((_ sign_extend 1) ?x1494)) true)))
(let (($x16 (or false false)))
(let (($x1497 (or $x16 false (or $x1495))))
(let (($x1499 (or $x1497 false)))
(let (($x1501 (or $x1499 false)))
(and (not $x1501) (or $x1501 (and (distinct ?x1500 ?x1500) true)))))))))))))
(check-sat)
; query 246: function Transformation_to_Log_Area_Ratios, block 65, name %70
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let ((?x1405 ((_ sign_extend 16) in21_16)))
(let ((?x1494 (bvsub ?x1405 (_ bv26112 32))))
(let ((?x1498 ((_ extract 15 0) ?x1494)))
(let ((?x1500 ((_ sign_extend 16) ?x1498)))
(let ((?x1504 (bvshl ?x1500 (_ bv2 32))))
(let (($x810 (bvuge (_ bv2 32) (_ bv32 32))))
(let (($x1495 (and (distinct (bvsub ((_ sign_extend 1) ?x1405) ((_ sign_extend 1) (_ bv26112 32))) ((_ sign_extend 1) ?x1494)) true)))
(let (($x16 (or false false)))
(let (($x1497 (or $x16 false (or $x1495))))
(let (($x1499 (or $x1497 false)))
(let (($x1501 (or $x1499 false)))
(let (($x1502 (or (or $x1501 false false) $x810)))
(and (not $x1502) (or $x1502 (and (distinct ?x1504 ?x1504) true))))))))))))))))
(check-sat)
; query 247: function Transformation_to_Log_Area_Ratios, block 65, name %71
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_16 () (_ BitVec 16))
(assert
 (let ((?x1405 ((_ sign_extend 16) in21_16)))
(let ((?x1494 (bvsub ?x1405 (_ bv26112 32))))
(let ((?x1498 ((_ extract 15 0) ?x1494)))
(let ((?x1500 ((_ sign_extend 16) ?x1498)))
(let ((?x1504 (bvshl ?x1500 (_ bv2 32))))
(let ((?x1505 ((_ extract 15 0) ?x1504)))
(let (($x810 (bvuge (_ bv2 32) (_ bv32 32))))
(let (($x1495 (and (distinct (bvsub ((_ sign_extend 1) ?x1405) ((_ sign_extend 1) (_ bv26112 32))) ((_ sign_extend 1) ?x1494)) true)))
(let (($x16 (or false false)))
(let (($x1497 (or $x16 false (or $x1495))))
(let (($x1499 (or $x1497 false)))
(let (($x1501 (or $x1499 false)))
(let (($x1502 (or (or $x1501 false false) $x810)))
(let (($x1506 (or $x1502 false)))
(and (not $x1506) (or $x1506 (and (distinct ?x1505 ?x1505) true))))))))))))))))))
(check-sat)
; query 248: function Transformation_to_Log_Area_Ratios, block 77, name %78
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 249: function Transformation_to_Log_Area_Ratios, block 77, name %79
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x492 ((_ sign_extend 16) in.1_16)))
(let ((?x1530 (bvsub (_ bv0 32) ?x492)))
(let (($x1531 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x492)) ((_ sign_extend 1) ?x1530)) true)))
(let (($x16 (or false false)))
(let (($x1533 (or false $x16 (or $x1531))))
(and (not $x1533) (or $x1533 (and (distinct ?x1530 ?x1530) true)))))))))
(check-sat)
; query 250: function Transformation_to_Log_Area_Ratios, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_16 () (_ BitVec 16))
(assert
 (let ((?x1539 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in5_16)) (_ bv1 1) (_ bv0 1))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x128 (not $x145)))
(and $x128 (or $x145 (and (distinct ?x1539 ?x1539) true))))))))
(check-sat)
; query 251: function Transformation_to_Log_Area_Ratios, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in5_16) ((_ sign_extend 16) in5_16)) true))))))
(check-sat)
; query 252: function Transformation_to_Log_Area_Ratios, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 253: function alaw_input, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x490 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x806 (or false false (or $x490))))
(and (not $x806) (or $x806 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 254: function gsm_L_add, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_64 () (_ BitVec 64))
(assert
 (let ((?x1547 (bvsub (_ bv0 64) in13_64)))
(let ((?x1545 ((_ sign_extend 1) ?x1547)))
(let (($x1550 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in13_64)) ?x1545) true)))))
(and (not $x1550) (or $x1550 (and (distinct ?x1547 ?x1547) true)))))))
(check-sat)
; query 255: function gsm_L_add, block 16, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_64 () (_ BitVec 64))
(assert
 (let ((?x1547 (bvsub (_ bv0 64) in13_64)))
(let ((?x1553 (bvsub ?x1547 (_ bv2 64))))
(let ((?x1545 ((_ sign_extend 1) ?x1547)))
(let (($x1550 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in13_64)) ?x1545) true)))))
(let (($x1556 (or $x1550 false (or (and (distinct (bvsub ?x1545 ((_ sign_extend 1) (_ bv2 64))) ((_ sign_extend 1) ?x1553)) true)))))
(and (not $x1556) (or (or $x1550 false false) (and (distinct ?x1553 (bvadd ?x1547 (_ bv18446744073709551614 64))) true)))))))))
(check-sat)
; query 256: function gsm_L_add, block 21, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1569 (ite (bvsge (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x484 (or false false false)))
(let (($x225 (not $x484)))
(and $x225 (or $x484 (and (distinct ?x1569 ?x1569) true)))))))
(check-sat)
; query 257: function gsm_L_add, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1583 (bvadd in1_64 in0_64)))
(let ((?x1577 (bvadd in0_64 in1_64)))
(let (($x1589 (and (distinct ?x1577 ?x1583) true)))
(let (($x1585 (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) in0_64)) ((_ sign_extend 1) ?x1583)) true)))
(let (($x1579 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) ?x1577)) true)))
(and (not (or false false (or $x1579))) (or (or false false (or $x1585)) $x1589))))))))
(check-sat)
; query 258: function gsm_L_add, block 25, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1583 (bvadd in1_64 in0_64)))
(let ((?x1577 (bvadd in0_64 in1_64)))
(let (($x1589 (and (distinct ?x1577 ?x1583) true)))
(let (($x484 (or false false false)))
(let (($x225 (not $x484)))
(and $x225 (or $x484 $x1589))))))))
(check-sat)
; query 259: function gsm_L_add, block 25, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let (($x1598 (and (distinct (ite (bvugt (bvadd in0_64 in1_64) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1)) (ite (bvugt (bvadd in1_64 in0_64) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))) true)))
(let (($x484 (or false false false)))
(let (($x595 (or $x484 false false)))
(let (($x652 (not $x595)))
(and $x652 (or $x595 $x1598)))))))
(check-sat)
; query 260: function gsm_L_add, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1602 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x484 (or false false false)))
(let (($x225 (not $x484)))
(and $x225 (or $x484 (and (distinct ?x1602 ?x1602) true)))))))
(check-sat)
; query 261: function gsm_L_add, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1583 (bvadd in1_64 in0_64)))
(let ((?x1577 (bvadd in0_64 in1_64)))
(let (($x1589 (and (distinct ?x1577 ?x1583) true)))
(let (($x1585 (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) in0_64)) ((_ sign_extend 1) ?x1583)) true)))
(let (($x1579 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) ?x1577)) true)))
(and (not (or false false (or $x1579))) (or (or false false (or $x1585)) $x1589))))))))
(check-sat)
; query 262: function gsm_L_add, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1607 (bvadd in0_64 (_ bv1 64))))
(let ((?x1614 (bvsub (_ bv0 64) ?x1607)))
(let (($x1615 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1607)) ((_ sign_extend 1) ?x1614)) true)))
(let ((?x1608 ((_ sign_extend 1) ?x1607)))
(let (($x1611 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1608) true)))))
(let (($x1617 (or false $x1611 (or $x1615))))
(and (not $x1617) (or $x1617 (and (distinct ?x1614 ?x1614) true))))))))))
(check-sat)
; query 263: function gsm_L_add, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1619 (bvadd in1_64 (_ bv1 64))))
(let ((?x1620 ((_ sign_extend 1) ?x1619)))
(let (($x1623 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1620) true)))))
(and (not $x1623) (or $x1623 (and (distinct ?x1619 ?x1619) true)))))))
(check-sat)
; query 264: function gsm_L_add, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1619 (bvadd in1_64 (_ bv1 64))))
(let ((?x1626 (bvsub (_ bv0 64) ?x1619)))
(let (($x1627 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1619)) ((_ sign_extend 1) ?x1626)) true)))
(let ((?x1620 ((_ sign_extend 1) ?x1619)))
(let (($x1623 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1620) true)))))
(let (($x1629 (or false $x1623 (or $x1627))))
(and (not $x1629) (or $x1629 (and (distinct ?x1626 ?x1626) true))))))))))
(check-sat)
; query 265: function gsm_L_add, block 8, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1607 (bvadd in0_64 (_ bv1 64))))
(let ((?x1614 (bvsub (_ bv0 64) ?x1607)))
(let ((?x1619 (bvadd in1_64 (_ bv1 64))))
(let ((?x1626 (bvsub (_ bv0 64) ?x1619)))
(let ((?x1636 (bvadd ?x1626 ?x1614)))
(let ((?x1631 (bvadd ?x1614 ?x1626)))
(let (($x1615 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1607)) ((_ sign_extend 1) ?x1614)) true)))
(let ((?x1608 ((_ sign_extend 1) ?x1607)))
(let (($x1611 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1608) true)))))
(let (($x1617 (or false $x1611 (or $x1615))))
(let (($x1627 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1619)) ((_ sign_extend 1) ?x1626)) true)))
(let ((?x1620 ((_ sign_extend 1) ?x1619)))
(let (($x1623 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1620) true)))))
(let (($x1629 (or false $x1623 (or $x1627))))
(let (($x1635 (or $x1629 $x1617 false)))
(and (not (or $x1617 $x1629 false)) (or $x1635 (and (distinct ?x1631 ?x1636) true)))))))))))))))))))
(check-sat)
; query 266: function gsm_L_add, block 8, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1607 (bvadd in0_64 (_ bv1 64))))
(let ((?x1614 (bvsub (_ bv0 64) ?x1607)))
(let ((?x1619 (bvadd in1_64 (_ bv1 64))))
(let ((?x1626 (bvsub (_ bv0 64) ?x1619)))
(let ((?x1636 (bvadd ?x1626 ?x1614)))
(let (($x1657 (and (distinct (ite (bvuge (bvadd ?x1614 ?x1626) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1)) (ite (bvuge ?x1636 (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))) true)))
(let (($x1615 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1607)) ((_ sign_extend 1) ?x1614)) true)))
(let ((?x1608 ((_ sign_extend 1) ?x1607)))
(let (($x1611 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1608) true)))))
(let (($x1617 (or false $x1611 (or $x1615))))
(let (($x1627 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1619)) ((_ sign_extend 1) ?x1626)) true)))
(let ((?x1620 ((_ sign_extend 1) ?x1619)))
(let (($x1623 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1620) true)))))
(let (($x1629 (or false $x1623 (or $x1627))))
(let (($x1635 (or $x1629 $x1617 false)))
(and (not (or (or $x1617 $x1629 false) false false)) (or (or $x1635 false false) $x1657))))))))))))))))))
(check-sat)
; query 267: function gsm_L_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1607 (bvadd in0_64 (_ bv1 64))))
(let ((?x1608 ((_ sign_extend 1) ?x1607)))
(let (($x1611 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1608) true)))))
(and (not $x1611) (or $x1611 (and (distinct ?x1607 ?x1607) true)))))))
(check-sat)
; query 268: function gsm_L_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1665 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x484 (or false false false)))
(let (($x225 (not $x484)))
(and $x225 (or $x484 (and (distinct ?x1665 ?x1665) true)))))))
(check-sat)
; query 269: function gsm_L_asl, block 12, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1671 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x484 (or false false false)))
(let (($x225 (not $x484)))
(and $x225 (or $x484 (and (distinct ?x1671 ?x1671) true)))))))
(check-sat)
; query 270: function gsm_L_asl, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ zero_extend 32) in1_32) ((_ zero_extend 32) in1_32)) true))))))
(check-sat)
; query 271: function gsm_L_asl, block 17, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1675 ((_ zero_extend 32) in1_32)))
(let ((?x1678 (bvshl in0_64 ?x1675)))
(let (($x16 (or false false)))
(let (($x1180 (or false $x16 false)))
(let (($x1677 (or $x1180 (bvuge ?x1675 (_ bv64 64)))))
(let (($x1682 (not $x1677)))
(and $x1682 (or $x1677 (and (distinct ?x1678 ?x1678) true))))))))))
(check-sat)
; query 272: function gsm_L_asl, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1688 (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x484 (or false false false)))
(let (($x225 (not $x484)))
(and $x225 (or $x484 (and (distinct ?x1688 ?x1688) true)))))))
(check-sat)
; query 273: function gsm_L_asl, block 7, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1665 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1692 ((_ zero_extend 31) ?x1665)))
(let ((?x1697 (bvsub (_ bv0 32) ?x1692)))
(let (($x1698 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1692)) ((_ sign_extend 1) ?x1697)) true)))
(let (($x484 (or false false false)))
(let (($x1693 (or $x484 false)))
(let (($x1700 (or false $x1693 (or $x1698))))
(and (not $x1700) (or $x1700 (and (distinct ?x1697 ?x1697) true)))))))))))
(check-sat)
; query 274: function gsm_L_asl, block 7, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1665 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1692 ((_ zero_extend 31) ?x1665)))
(let ((?x1697 (bvsub (_ bv0 32) ?x1692)))
(let ((?x1701 ((_ sign_extend 32) ?x1697)))
(let (($x1698 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1692)) ((_ sign_extend 1) ?x1697)) true)))
(let (($x484 (or false false false)))
(let (($x1693 (or $x484 false)))
(let (($x1700 (or false $x1693 (or $x1698))))
(let (($x1702 (or $x1700 false)))
(and (not $x1702) (or $x1702 (and (distinct ?x1701 ?x1701) true)))))))))))))
(check-sat)
; query 275: function gsm_L_asl, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1665 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x484 (or false false false)))
(let (($x225 (not $x484)))
(and $x225 (or $x484 (and (distinct ?x1665 ?x1665) true)))))))
(check-sat)
; query 276: function gsm_L_asl, block 7, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1665 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1692 ((_ zero_extend 31) ?x1665)))
(let (($x484 (or false false false)))
(let (($x1693 (or $x484 false)))
(and (not $x1693) (or $x1693 (and (distinct ?x1692 ?x1692) true))))))))
(check-sat)
; query 277: function gsm_L_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1716 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x484 (or false false false)))
(let (($x225 (not $x484)))
(and $x225 (or $x484 (and (distinct ?x1716 ?x1716) true)))))))
(check-sat)
; query 278: function gsm_L_asr, block 12, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1671 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x484 (or false false false)))
(let (($x225 (not $x484)))
(and $x225 (or $x484 (and (distinct ?x1671 ?x1671) true)))))))
(check-sat)
; query 279: function gsm_L_asr, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x1724 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in1_32))) true)))
(let (($x1726 (or false false (or $x1724))))
(and (not $x1726) (or $x1726 (and (distinct (bvsub (_ bv0 32) in1_32) (bvsub (_ bv0 32) in1_32)) true))))))
(check-sat)
; query 280: function gsm_L_asr, block 14, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1723 (bvsub (_ bv0 32) in1_32)))
(let ((?x1727 ((_ zero_extend 32) ?x1723)))
(let (($x1724 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x1723)) true)))
(let (($x1726 (or false false (or $x1724))))
(let (($x1728 (or $x1726 false)))
(and (not $x1728) (or $x1728 (and (distinct ?x1727 ?x1727) true)))))))))
(check-sat)
; query 281: function gsm_L_asr, block 14, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1723 (bvsub (_ bv0 32) in1_32)))
(let ((?x1727 ((_ zero_extend 32) ?x1723)))
(let ((?x1732 (bvshl in0_64 ?x1727)))
(let (($x1724 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x1723)) true)))
(let (($x1726 (or false false (or $x1724))))
(let (($x1728 (or $x1726 false)))
(let (($x1731 (or (or false $x1728 false) (bvuge ?x1727 (_ bv64 64)))))
(and (not $x1731) (or $x1731 (and (distinct ?x1732 ?x1732) true)))))))))))
(check-sat)
; query 282: function gsm_L_asr, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ zero_extend 32) in1_32) ((_ zero_extend 32) in1_32)) true))))))
(check-sat)
; query 283: function gsm_L_asr, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1675 ((_ zero_extend 32) in1_32)))
(let ((?x1745 (bvashr in0_64 ?x1675)))
(let (($x16 (or false false)))
(let (($x1180 (or false $x16 false)))
(let (($x1677 (or $x1180 (bvuge ?x1675 (_ bv64 64)))))
(let (($x1682 (not $x1677)))
(and $x1682 (or $x1677 (and (distinct ?x1745 ?x1745) true))))))))))
(check-sat)
; query 284: function gsm_L_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1665 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x484 (or false false false)))
(let (($x225 (not $x484)))
(and $x225 (or $x484 (and (distinct ?x1665 ?x1665) true)))))))
(check-sat)
; query 285: function gsm_L_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1665 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1692 ((_ zero_extend 31) ?x1665)))
(let (($x484 (or false false false)))
(let (($x1693 (or $x484 false)))
(and (not $x1693) (or $x1693 (and (distinct ?x1692 ?x1692) true))))))))
(check-sat)
; query 286: function gsm_L_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1665 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1692 ((_ zero_extend 31) ?x1665)))
(let ((?x1697 (bvsub (_ bv0 32) ?x1692)))
(let (($x1698 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1692)) ((_ sign_extend 1) ?x1697)) true)))
(let (($x484 (or false false false)))
(let (($x1693 (or $x484 false)))
(let (($x1700 (or false $x1693 (or $x1698))))
(and (not $x1700) (or $x1700 (and (distinct ?x1697 ?x1697) true)))))))))))
(check-sat)
; query 287: function gsm_L_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1665 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1692 ((_ zero_extend 31) ?x1665)))
(let ((?x1697 (bvsub (_ bv0 32) ?x1692)))
(let ((?x1701 ((_ sign_extend 32) ?x1697)))
(let (($x1698 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1692)) ((_ sign_extend 1) ?x1697)) true)))
(let (($x484 (or false false false)))
(let (($x1693 (or $x484 false)))
(let (($x1700 (or false $x1693 (or $x1698))))
(let (($x1702 (or $x1700 false)))
(and (not $x1702) (or $x1702 (and (distinct ?x1701 ?x1701) true)))))))))))))
(check-sat)
; query 288: function gsm_L_asr, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1688 (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x484 (or false false false)))
(let (($x225 (not $x484)))
(and $x225 (or $x484 (and (distinct ?x1688 ?x1688) true)))))))
(check-sat)
; query 289: function gsm_L_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1716 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x484 (or false false false)))
(let (($x225 (not $x484)))
(and $x225 (or $x484 (and (distinct ?x1716 ?x1716) true)))))))
(check-sat)
; query 290: function gsm_L_mult, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 291: function gsm_L_mult, block 17, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 292: function gsm_L_mult, block 17, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1749 ((_ sign_extend 48) in0_16)))
(let ((?x1763 (bvmul ?x1749 (_ bv2 64))))
(let ((?x1750 ((_ sign_extend 48) in1_16)))
(let ((?x1756 (bvmul ?x1749 ?x1750)))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x1754 (and (distinct (bvmul ((_ sign_extend 64) ?x1749) ((_ sign_extend 64) ?x1750)) ((_ sign_extend 64) ?x1756)) true)))
(let (($x1758 (or $x16 $x16 (or $x1754))))
(let (($x1772 (not $x1758)))
(and $x1772 (or $x145 (and (distinct ?x1756 ?x1763) true)))))))))))))
(check-sat)
; query 293: function gsm_L_mult, block 17, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x1777 (and (distinct (bvshl (bvmul ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16)) (_ bv1 64)) (bvmul (bvmul ((_ sign_extend 48) in0_16) (_ bv2 64)) ((_ sign_extend 48) in1_16))) true)))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x1759 (bvuge (_ bv1 64) (_ bv64 64))))
(let ((?x1750 ((_ sign_extend 48) in1_16)))
(let ((?x1752 ((_ sign_extend 64) ?x1750)))
(let ((?x1749 ((_ sign_extend 48) in0_16)))
(let ((?x1751 ((_ sign_extend 64) ?x1749)))
(let (($x1758 (or $x16 $x16 (or (and (distinct (bvmul ?x1751 ?x1752) ((_ sign_extend 64) (bvmul ?x1749 ?x1750))) true)))))
(let (($x1760 (or $x1758 false false)))
(and (not (or $x1760 $x1759)) (or (or $x145 $x16 false) $x1777)))))))))))))
(check-sat)
; query 294: function gsm_L_mult, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 295: function gsm_L_mult, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1781 (ite (and (distinct (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) true) (_ bv1 1) (_ bv0 1))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x128 (not $x145)))
(and $x128 (or $x145 (and (distinct ?x1781 ?x1781) true))))))))
(check-sat)
; query 296: function gsm_L_mult, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 297: function gsm_L_mult, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1786 (ite (and (distinct (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) true) (_ bv1 1) (_ bv0 1))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x128 (not $x145)))
(and $x128 (or $x145 (and (distinct ?x1786 ?x1786) true))))))))
(check-sat)
; query 298: function gsm_L_sub, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in11_64 () (_ BitVec 64))
(assert
 (let (($x484 (or false false false)))
(let (($x225 (not $x484)))
(and $x225 (or $x484 (and (distinct (bvadd in11_64 (_ bv1 64)) (bvadd in11_64 (_ bv1 64))) true))))))
(check-sat)
; query 299: function gsm_L_sub, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1569 (ite (bvsge (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x484 (or false false false)))
(let (($x225 (not $x484)))
(and $x225 (or $x484 (and (distinct ?x1569 ?x1569) true)))))))
(check-sat)
; query 300: function gsm_L_sub, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x1797 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvsub in0_64 in1_64))) true)))
(let (($x1800 (or false false (or $x1797))))
(let (($x1803 (or $x1800 (and (distinct (bvsub in0_64 in1_64) (bvsub in0_64 in1_64)) true))))
(and (not $x1800) $x1803)))))
(check-sat)
; query 301: function gsm_L_sub, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1607 (bvadd in0_64 (_ bv1 64))))
(let ((?x1608 ((_ sign_extend 1) ?x1607)))
(let (($x1611 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1608) true)))))
(and (not $x1611) (or $x1611 (and (distinct ?x1607 ?x1607) true)))))))
(check-sat)
; query 302: function gsm_L_sub, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1607 (bvadd in0_64 (_ bv1 64))))
(let ((?x1614 (bvsub (_ bv0 64) ?x1607)))
(let (($x1615 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1607)) ((_ sign_extend 1) ?x1614)) true)))
(let ((?x1608 ((_ sign_extend 1) ?x1607)))
(let (($x1611 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1608) true)))))
(let (($x1617 (or false $x1611 (or $x1615))))
(and (not $x1617) (or $x1617 (and (distinct ?x1614 ?x1614) true))))))))))
(check-sat)
; query 303: function gsm_L_sub, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1607 (bvadd in0_64 (_ bv1 64))))
(let ((?x1614 (bvsub (_ bv0 64) ?x1607)))
(let ((?x1805 (bvadd ?x1614 in1_64)))
(let (($x1615 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1607)) ((_ sign_extend 1) ?x1614)) true)))
(let ((?x1608 ((_ sign_extend 1) ?x1607)))
(let (($x1611 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1608) true)))))
(let (($x1617 (or false $x1611 (or $x1615))))
(let (($x1806 (or $x1617 false false)))
(and (not $x1806) (or $x1806 (and (distinct ?x1805 ?x1805) true))))))))))))
(check-sat)
; query 304: function gsm_L_sub, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1809 (ite (bvuge (bvadd (bvsub (_ bv0 64) (bvadd in0_64 (_ bv1 64))) in1_64) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x1615 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) (bvadd in0_64 (_ bv1 64)))) ((_ sign_extend 1) (bvsub (_ bv0 64) (bvadd in0_64 (_ bv1 64))))) true)))
(let ((?x1607 (bvadd in0_64 (_ bv1 64))))
(let ((?x1608 ((_ sign_extend 1) ?x1607)))
(let (($x1611 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1608) true)))))
(let (($x1617 (or false $x1611 (or $x1615))))
(let (($x1806 (or $x1617 false false)))
(let (($x1808 (or $x1806 false false)))
(and (not $x1808) (or $x1808 (and (distinct ?x1809 ?x1809) true))))))))))))
(check-sat)
; query 305: function gsm_L_sub, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_64 () (_ BitVec 64))
(assert
 (let ((?x1822 (bvsub (_ bv0 64) in25_64)))
(let ((?x1820 ((_ sign_extend 1) ?x1822)))
(let (($x1825 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in25_64)) ?x1820) true)))))
(and (not $x1825) (or $x1825 (and (distinct ?x1822 ?x1822) true)))))))
(check-sat)
; query 306: function gsm_L_sub, block 28, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_64 () (_ BitVec 64))
(assert
 (let ((?x1822 (bvsub (_ bv0 64) in25_64)))
(let ((?x1828 (bvsub ?x1822 (_ bv1 64))))
(let ((?x1820 ((_ sign_extend 1) ?x1822)))
(let (($x1825 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in25_64)) ?x1820) true)))))
(let (($x1831 (or $x1825 false (or (and (distinct (bvsub ?x1820 ((_ sign_extend 1) (_ bv1 64))) ((_ sign_extend 1) ?x1828)) true)))))
(and (not $x1831) (or (or $x1825 false false) (and (distinct ?x1828 (bvadd ?x1822 (_ bv18446744073709551615 64))) true)))))))))
(check-sat)
; query 307: function gsm_L_sub, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1602 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x484 (or false false false)))
(let (($x225 (not $x484)))
(and $x225 (or $x484 (and (distinct ?x1602 ?x1602) true)))))))
(check-sat)
; query 308: function gsm_L_sub, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x1797 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvsub in0_64 in1_64))) true)))
(let (($x1800 (or false false (or $x1797))))
(let (($x1803 (or $x1800 (and (distinct (bvsub in0_64 in1_64) (bvsub in0_64 in1_64)) true))))
(and (not $x1800) $x1803)))))
(check-sat)
; query 309: function gsm_L_sub, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1619 (bvadd in1_64 (_ bv1 64))))
(let ((?x1626 (bvsub (_ bv0 64) ?x1619)))
(let (($x1627 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1619)) ((_ sign_extend 1) ?x1626)) true)))
(let ((?x1620 ((_ sign_extend 1) ?x1619)))
(let (($x1623 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1620) true)))))
(let (($x1629 (or false $x1623 (or $x1627))))
(and (not $x1629) (or $x1629 (and (distinct ?x1626 ?x1626) true))))))))))
(check-sat)
; query 310: function gsm_L_sub, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1619 (bvadd in1_64 (_ bv1 64))))
(let ((?x1626 (bvsub (_ bv0 64) ?x1619)))
(let ((?x1848 (bvadd ?x1626 in0_64)))
(let ((?x1843 (bvadd in0_64 ?x1626)))
(let (($x1627 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1619)) ((_ sign_extend 1) ?x1626)) true)))
(let ((?x1620 ((_ sign_extend 1) ?x1619)))
(let (($x1623 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1620) true)))))
(let (($x1629 (or false $x1623 (or $x1627))))
(let (($x1849 (or $x1629 false false)))
(and (not (or false $x1629 false)) (or $x1849 (and (distinct ?x1843 ?x1848) true)))))))))))))
(check-sat)
; query 311: function gsm_L_sub, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1852 (ite (bvuge (bvadd (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64))) in0_64) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let ((?x1847 (ite (bvuge (bvadd in0_64 (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64)))) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x1627 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) (bvadd in1_64 (_ bv1 64)))) ((_ sign_extend 1) (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64))))) true)))
(let ((?x1619 (bvadd in1_64 (_ bv1 64))))
(let ((?x1620 ((_ sign_extend 1) ?x1619)))
(let (($x1623 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1620) true)))))
(let (($x1629 (or false $x1623 (or $x1627))))
(let (($x1849 (or $x1629 false false)))
(and (not (or (or false $x1629 false) false false)) (or (or $x1849 false false) (and (distinct ?x1847 ?x1852) true))))))))))))
(check-sat)
; query 312: function gsm_L_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1619 (bvadd in1_64 (_ bv1 64))))
(let ((?x1620 ((_ sign_extend 1) ?x1619)))
(let (($x1623 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1620) true)))))
(and (not $x1623) (or $x1623 (and (distinct ?x1619 ?x1619) true)))))))
(check-sat)
; query 313: function gsm_L_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1862 (ite (bvsle (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x484 (or false false false)))
(let (($x225 (not $x484)))
(and $x225 (or $x484 (and (distinct ?x1862 ?x1862) true)))))))
(check-sat)
; query 314: function gsm_abs, block 13, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 315: function gsm_abs, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 316: function gsm_abs, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1867 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x128 (not $x145)))
(and $x128 (or $x145 (and (distinct ?x1867 ?x1867) true))))))))
(check-sat)
; query 317: function gsm_abs, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x465 ((_ sign_extend 16) in0_16)))
(let ((?x1874 (bvsub (_ bv0 32) ?x465)))
(let (($x1875 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x465)) ((_ sign_extend 1) ?x1874)) true)))
(let (($x16 (or false false)))
(let (($x1877 (or false $x16 (or $x1875))))
(and (not $x1877) (or $x1877 (and (distinct ?x1874 ?x1874) true)))))))))
(check-sat)
; query 318: function gsm_abs, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 319: function gsm_abs, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 320: function gsm_abs, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1883 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x128 (not $x145)))
(and $x128 (or $x145 (and (distinct ?x1883 ?x1883) true))))))))
(check-sat)
; query 321: function gsm_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_64 () (_ BitVec 64))
(assert
 (let ((?x1890 (ite (bvslt (_ bv32767 64) in5_64) (_ bv1 1) (_ bv0 1))))
(let (($x484 (or false false false)))
(let (($x225 (not $x484)))
(and $x225 (or $x484 (and (distinct ?x1890 ?x1890) true)))))))
(check-sat)
; query 322: function gsm_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 323: function gsm_add, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 324: function gsm_add, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1749 ((_ sign_extend 48) in0_16)))
(let ((?x1750 ((_ sign_extend 48) in1_16)))
(let ((?x1906 (bvadd ?x1750 ?x1749)))
(let ((?x1897 (bvadd ?x1749 ?x1750)))
(let (($x1908 (and (distinct (bvadd ((_ sign_extend 1) ?x1750) ((_ sign_extend 1) ?x1749)) ((_ sign_extend 1) ?x1906)) true)))
(let (($x16 (or false false)))
(let (($x1910 (or $x16 $x16 (or $x1908))))
(let (($x1899 (and (distinct (bvadd ((_ sign_extend 1) ?x1749) ((_ sign_extend 1) ?x1750)) ((_ sign_extend 1) ?x1897)) true)))
(let (($x1901 (or $x16 $x16 (or $x1899))))
(and (not $x1901) (or $x1910 (and (distinct ?x1897 ?x1906) true)))))))))))))
(check-sat)
; query 325: function gsm_add, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1913 (ite (bvsgt (_ bv18446744073709518848 64) (bvadd ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in0_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x1904 (ite (bvsgt (_ bv18446744073709518848 64) (bvadd ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x1749 ((_ sign_extend 48) in0_16)))
(let ((?x1894 ((_ sign_extend 1) ?x1749)))
(let ((?x1750 ((_ sign_extend 48) in1_16)))
(let ((?x1895 ((_ sign_extend 1) ?x1750)))
(let (($x16 (or false false)))
(let (($x1910 (or $x16 $x16 (or (and (distinct (bvadd ?x1895 ?x1894) ((_ sign_extend 1) (bvadd ?x1750 ?x1749))) true)))))
(let (($x1901 (or $x16 $x16 (or (and (distinct (bvadd ?x1894 ?x1895) ((_ sign_extend 1) (bvadd ?x1749 ?x1750))) true)))))
(and (not (or $x1901 false false)) (or (or $x1910 false false) (and (distinct ?x1904 ?x1913) true)))))))))))))
(check-sat)
; query 326: function gsm_asl, block 13, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1671 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x484 (or false false false)))
(let (($x225 (not $x484)))
(and $x225 (or $x484 (and (distinct ?x1671 ?x1671) true)))))))
(check-sat)
; query 327: function gsm_asl, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 328: function gsm_asl, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x465 ((_ sign_extend 16) in0_16)))
(let ((?x1924 (bvshl ?x465 in1_32)))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x1923 (or $x145 (bvuge in1_32 (_ bv32 32)))))
(let (($x1927 (not $x1923)))
(and $x1927 (or $x1923 (and (distinct ?x1924 ?x1924) true))))))))))
(check-sat)
; query 329: function gsm_asl, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x465 ((_ sign_extend 16) in0_16)))
(let ((?x1924 (bvshl ?x465 in1_32)))
(let ((?x1925 ((_ extract 15 0) ?x1924)))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x1923 (or $x145 (bvuge in1_32 (_ bv32 32)))))
(let (($x1926 (or $x1923 false)))
(let (($x1931 (not $x1926)))
(and $x1931 (or $x1926 (and (distinct ?x1925 ?x1925) true))))))))))))
(check-sat)
; query 330: function gsm_asl, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1937 (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x484 (or false false false)))
(let (($x225 (not $x484)))
(and $x225 (or $x484 (and (distinct ?x1937 ?x1937) true)))))))
(check-sat)
; query 331: function gsm_asl, block 7, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1883 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1941 ((_ zero_extend 31) ?x1883)))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x1942 (or $x145 false)))
(and (not $x1942) (or $x1942 (and (distinct ?x1941 ?x1941) true)))))))))
(check-sat)
; query 332: function gsm_asl, block 7, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1883 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1941 ((_ zero_extend 31) ?x1883)))
(let ((?x1946 (bvsub (_ bv0 32) ?x1941)))
(let (($x1947 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1941)) ((_ sign_extend 1) ?x1946)) true)))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x1942 (or $x145 false)))
(let (($x1949 (or false $x1942 (or $x1947))))
(and (not $x1949) (or $x1949 (and (distinct ?x1946 ?x1946) true))))))))))))
(check-sat)
; query 333: function gsm_asl, block 7, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1883 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1941 ((_ zero_extend 31) ?x1883)))
(let ((?x1946 (bvsub (_ bv0 32) ?x1941)))
(let ((?x1950 ((_ extract 15 0) ?x1946)))
(let (($x1947 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1941)) ((_ sign_extend 1) ?x1946)) true)))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x1942 (or $x145 false)))
(let (($x1949 (or false $x1942 (or $x1947))))
(let (($x1951 (or $x1949 false)))
(and (not $x1951) (or $x1951 (and (distinct ?x1950 ?x1950) true))))))))))))))
(check-sat)
; query 334: function gsm_asl, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 335: function gsm_asl, block 7, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1883 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x128 (not $x145)))
(and $x128 (or $x145 (and (distinct ?x1883 ?x1883) true))))))))
(check-sat)
; query 336: function gsm_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1965 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x484 (or false false false)))
(let (($x225 (not $x484)))
(and $x225 (or $x484 (and (distinct ?x1965 ?x1965) true)))))))
(check-sat)
; query 337: function gsm_asr, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1937 (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x484 (or false false false)))
(let (($x225 (not $x484)))
(and $x225 (or $x484 (and (distinct ?x1937 ?x1937) true)))))))
(check-sat)
; query 338: function gsm_asr, block 13, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1671 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x484 (or false false false)))
(let (($x225 (not $x484)))
(and $x225 (or $x484 (and (distinct ?x1671 ?x1671) true)))))))
(check-sat)
; query 339: function gsm_asr, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 340: function gsm_asr, block 15, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x1724 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in1_32))) true)))
(let (($x1726 (or false false (or $x1724))))
(and (not $x1726) (or $x1726 (and (distinct (bvsub (_ bv0 32) in1_32) (bvsub (_ bv0 32) in1_32)) true))))))
(check-sat)
; query 341: function gsm_asr, block 15, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1723 (bvsub (_ bv0 32) in1_32)))
(let ((?x465 ((_ sign_extend 16) in0_16)))
(let ((?x1972 (bvshl ?x465 ?x1723)))
(let (($x1724 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x1723)) true)))
(let (($x1726 (or false false (or $x1724))))
(let (($x16 (or false false)))
(let (($x1971 (or (or $x16 $x1726 false) (bvuge ?x1723 (_ bv32 32)))))
(and (not $x1971) (or $x1971 (and (distinct ?x1972 ?x1972) true)))))))))))
(check-sat)
; query 342: function gsm_asr, block 15, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1723 (bvsub (_ bv0 32) in1_32)))
(let ((?x465 ((_ sign_extend 16) in0_16)))
(let ((?x1972 (bvshl ?x465 ?x1723)))
(let ((?x1973 ((_ extract 15 0) ?x1972)))
(let (($x1724 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x1723)) true)))
(let (($x1726 (or false false (or $x1724))))
(let (($x16 (or false false)))
(let (($x1971 (or (or $x16 $x1726 false) (bvuge ?x1723 (_ bv32 32)))))
(let (($x1974 (or $x1971 false)))
(and (not $x1974) (or $x1974 (and (distinct ?x1973 ?x1973) true)))))))))))))
(check-sat)
; query 343: function gsm_asr, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 344: function gsm_asr, block 20, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x465 ((_ sign_extend 16) in0_16)))
(let ((?x1983 (bvashr ?x465 in1_32)))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x1923 (or $x145 (bvuge in1_32 (_ bv32 32)))))
(let (($x1927 (not $x1923)))
(and $x1927 (or $x1923 (and (distinct ?x1983 ?x1983) true))))))))))
(check-sat)
; query 345: function gsm_asr, block 20, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x465 ((_ sign_extend 16) in0_16)))
(let ((?x1983 (bvashr ?x465 in1_32)))
(let ((?x1984 ((_ extract 15 0) ?x1983)))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x1923 (or $x145 (bvuge in1_32 (_ bv32 32)))))
(let (($x1926 (or $x1923 false)))
(let (($x1931 (not $x1926)))
(and $x1931 (or $x1926 (and (distinct ?x1984 ?x1984) true))))))))))))
(check-sat)
; query 346: function gsm_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 347: function gsm_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1883 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x128 (not $x145)))
(and $x128 (or $x145 (and (distinct ?x1883 ?x1883) true))))))))
(check-sat)
; query 348: function gsm_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1883 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1941 ((_ zero_extend 31) ?x1883)))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x1942 (or $x145 false)))
(and (not $x1942) (or $x1942 (and (distinct ?x1941 ?x1941) true)))))))))
(check-sat)
; query 349: function gsm_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1883 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1941 ((_ zero_extend 31) ?x1883)))
(let ((?x1946 (bvsub (_ bv0 32) ?x1941)))
(let (($x1947 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1941)) ((_ sign_extend 1) ?x1946)) true)))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x1942 (or $x145 false)))
(let (($x1949 (or false $x1942 (or $x1947))))
(and (not $x1949) (or $x1949 (and (distinct ?x1946 ?x1946) true))))))))))))
(check-sat)
; query 350: function gsm_asr, block 4, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1883 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1941 ((_ zero_extend 31) ?x1883)))
(let ((?x1946 (bvsub (_ bv0 32) ?x1941)))
(let ((?x1950 ((_ extract 15 0) ?x1946)))
(let (($x1947 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1941)) ((_ sign_extend 1) ?x1946)) true)))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x1942 (or $x145 false)))
(let (($x1949 (or false $x1942 (or $x1947))))
(let (($x1951 (or $x1949 false)))
(and (not $x1951) (or $x1951 (and (distinct ?x1950 ?x1950) true))))))))))))))
(check-sat)
; query 351: function gsm_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1965 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x484 (or false false false)))
(let (($x225 (not $x484)))
(and $x225 (or $x484 (and (distinct ?x1965 ?x1965) true)))))))
(check-sat)
; query 352: function gsm_debug_longwords, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in15_32 () (_ BitVec 32))
(assert
 (let ((?x1994 (ite (bvslt in15_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x484 (or false false false)))
(let (($x225 (not $x484)))
(and $x225 (or $x484 (and (distinct ?x1994 ?x1994) true)))))))
(check-sat)
; query 353: function gsm_debug_words, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in16_32 () (_ BitVec 32))
(assert
 (let ((?x2000 (ite (bvslt in16_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x484 (or false false false)))
(let (($x225 (not $x484)))
(and $x225 (or $x484 (and (distinct ?x2000 ?x2000) true)))))))
(check-sat)
; query 354: function gsm_div, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 355: function gsm_div, block 20, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x2005 (ite (= (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x128 (not $x145)))
(and $x128 (or $x145 (and (distinct ?x2005 ?x2005) true))))))))
(check-sat)
; query 356: function gsm_div, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in.02_16) ((_ sign_extend 16) in.02_16)) true))))))
(check-sat)
; query 357: function gsm_div, block 28, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x2010 ((_ sign_extend 16) in.02_16)))
(let ((?x2011 (bvshl ?x2010 (_ bv1 32))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x408 (or $x145 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x426 (not $x408)))
(and $x426 (or $x408 (and (distinct ?x2011 ?x2011) true))))))))))
(check-sat)
; query 358: function gsm_div, block 28, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x2010 ((_ sign_extend 16) in.02_16)))
(let ((?x2011 (bvshl ?x2010 (_ bv1 32))))
(let ((?x2012 ((_ extract 15 0) ?x2011)))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x408 (or $x145 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x1047 (or $x408 false)))
(let (($x788 (not $x1047)))
(and $x788 (or $x1047 (and (distinct ?x2012 ?x2012) true))))))))))))
(check-sat)
; query 359: function gsm_div, block 28, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_64 () (_ BitVec 64))
(assert
 (let (($x1759 (bvuge (_ bv1 64) (_ bv64 64))))
(let (($x484 (or false false false)))
(let (($x2014 (or $x484 $x1759)))
(and (not $x2014) (or $x2014 (and (distinct (bvshl in.03_64 (_ bv1 64)) (bvshl in.03_64 (_ bv1 64))) true)))))))
(check-sat)
; query 360: function gsm_div, block 28, name %33
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_64 () (_ BitVec 64))
(declare-fun in.03_64 () (_ BitVec 64))
(assert
 (let ((?x2019 (ite (bvsge (bvshl in.03_64 (_ bv1 64)) in4_64) (_ bv1 1) (_ bv0 1))))
(let (($x1759 (bvuge (_ bv1 64) (_ bv64 64))))
(let (($x484 (or false false false)))
(let (($x2014 (or $x484 $x1759)))
(let (($x2018 (or $x2014 false false)))
(and (not $x2018) (or $x2018 (and (distinct ?x2019 ?x2019) true)))))))))
(check-sat)
; query 361: function gsm_div, block 34, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_64 () (_ BitVec 64))
(declare-fun in32_64 () (_ BitVec 64))
(assert
 (let (($x2042 (and (distinct (bvsub ((_ sign_extend 1) in32_64) ((_ sign_extend 1) in4_64)) ((_ sign_extend 1) (bvsub in32_64 in4_64))) true)))
(let (($x2044 (or false false (or $x2042))))
(let (($x2048 (or $x2044 (and (distinct (bvsub in32_64 in4_64) (bvsub in32_64 in4_64)) true))))
(and (not $x2044) $x2048)))))
(check-sat)
; query 362: function gsm_div, block 34, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in31_16 () (_ BitVec 16))
(assert
 (let (($x484 (or false false false)))
(let (($x225 (not $x484)))
(and $x225 (or $x484 (and (distinct (bvadd in31_16 (_ bv1 16)) (bvadd in31_16 (_ bv1 16))) true))))))
(check-sat)
; query 363: function gsm_div, block 7, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x2055 (ite (bvsge ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x16 (or false false)))
(let (($x2054 (or $x16 $x16 false)))
(and (not $x2054) (or $x2054 (and (distinct ?x2055 ?x2055) true)))))))
(check-sat)
; query 364: function gsm_div, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 365: function gsm_div, block 7, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 366: function gsm_div, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 367: function gsm_div, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 368: function gsm_div, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 369: function gsm_div, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1181 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1183 (and (distinct ?x1181 ?x1181) true)))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x128 (not $x145)))
(and $x128 (or $x145 $x1183))))))))
(check-sat)
; query 370: function gsm_mult, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 371: function gsm_mult, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x2063 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x128 (not $x145)))
(and $x128 (or $x145 (and (distinct ?x2063 ?x2063) true))))))))
(check-sat)
; query 372: function gsm_mult, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 373: function gsm_mult, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 374: function gsm_mult, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1749 ((_ sign_extend 48) in0_16)))
(let ((?x1750 ((_ sign_extend 48) in1_16)))
(let ((?x2071 (bvmul ?x1750 ?x1749)))
(let ((?x1756 (bvmul ?x1749 ?x1750)))
(let (($x2074 (and (distinct (bvmul ((_ sign_extend 64) ?x1750) ((_ sign_extend 64) ?x1749)) ((_ sign_extend 64) ?x2071)) true)))
(let (($x16 (or false false)))
(let (($x2076 (or $x16 $x16 (or $x2074))))
(let (($x1754 (and (distinct (bvmul ((_ sign_extend 64) ?x1749) ((_ sign_extend 64) ?x1750)) ((_ sign_extend 64) ?x1756)) true)))
(let (($x1758 (or $x16 $x16 (or $x1754))))
(let (($x1772 (not $x1758)))
(and $x1772 (or $x2076 (and (distinct ?x1756 ?x2071) true))))))))))))))
(check-sat)
; query 375: function gsm_mult, block 9, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1749 ((_ sign_extend 48) in0_16)))
(let ((?x1750 ((_ sign_extend 48) in1_16)))
(let ((?x2071 (bvmul ?x1750 ?x1749)))
(let ((?x2079 (bvashr ?x2071 (_ bv15 64))))
(let ((?x1756 (bvmul ?x1749 ?x1750)))
(let ((?x2067 (bvashr ?x1756 (_ bv15 64))))
(let (($x131 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x2074 (and (distinct (bvmul ((_ sign_extend 64) ?x1750) ((_ sign_extend 64) ?x1749)) ((_ sign_extend 64) ?x2071)) true)))
(let (($x16 (or false false)))
(let (($x2076 (or $x16 $x16 (or $x2074))))
(let (($x2078 (or (or $x2076 false false) $x131)))
(let (($x1754 (and (distinct (bvmul ((_ sign_extend 64) ?x1749) ((_ sign_extend 64) ?x1750)) ((_ sign_extend 64) ?x1756)) true)))
(let (($x1758 (or $x16 $x16 (or $x1754))))
(let (($x1760 (or $x1758 false false)))
(let (($x2068 (or $x1760 $x131)))
(and (not $x2068) (or $x2078 (and (distinct ?x2067 ?x2079) true)))))))))))))))))))
(check-sat)
; query 376: function gsm_mult, block 9, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1749 ((_ sign_extend 48) in0_16)))
(let ((?x1750 ((_ sign_extend 48) in1_16)))
(let ((?x2071 (bvmul ?x1750 ?x1749)))
(let ((?x2079 (bvashr ?x2071 (_ bv15 64))))
(let (($x131 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x2074 (and (distinct (bvmul ((_ sign_extend 64) ?x1750) ((_ sign_extend 64) ?x1749)) ((_ sign_extend 64) ?x2071)) true)))
(let (($x16 (or false false)))
(let (($x2076 (or $x16 $x16 (or $x2074))))
(let (($x2078 (or (or $x2076 false false) $x131)))
(let (($x2091 (or (or $x2078 false) (and (distinct ((_ extract 15 0) (bvashr (bvmul ?x1749 ?x1750) (_ bv15 64))) ((_ extract 15 0) ?x2079)) true))))
(let (($x1754 (and (distinct (bvmul ((_ sign_extend 64) ?x1749) ((_ sign_extend 64) ?x1750)) ((_ sign_extend 64) (bvmul ?x1749 ?x1750))) true)))
(let (($x1758 (or $x16 $x16 (or $x1754))))
(let (($x1760 (or $x1758 false false)))
(let (($x2068 (or $x1760 $x131)))
(and (not (or $x2068 false)) $x2091))))))))))))))))
(check-sat)
; query 377: function gsm_mult, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 378: function gsm_mult, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1867 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x128 (not $x145)))
(and $x128 (or $x145 (and (distinct ?x1867 ?x1867) true))))))))
(check-sat)
; query 379: function gsm_mult_r, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 380: function gsm_mult_r, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1867 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x128 (not $x145)))
(and $x128 (or $x145 (and (distinct ?x1867 ?x1867) true))))))))
(check-sat)
; query 381: function gsm_mult_r, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 382: function gsm_mult_r, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 383: function gsm_mult_r, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1749 ((_ sign_extend 48) in0_16)))
(let ((?x1750 ((_ sign_extend 48) in1_16)))
(let ((?x2071 (bvmul ?x1750 ?x1749)))
(let ((?x1756 (bvmul ?x1749 ?x1750)))
(let (($x2074 (and (distinct (bvmul ((_ sign_extend 64) ?x1750) ((_ sign_extend 64) ?x1749)) ((_ sign_extend 64) ?x2071)) true)))
(let (($x16 (or false false)))
(let (($x2076 (or $x16 $x16 (or $x2074))))
(let (($x1754 (and (distinct (bvmul ((_ sign_extend 64) ?x1749) ((_ sign_extend 64) ?x1750)) ((_ sign_extend 64) ?x1756)) true)))
(let (($x1758 (or $x16 $x16 (or $x1754))))
(let (($x1772 (not $x1758)))
(and $x1772 (or $x2076 (and (distinct ?x1756 ?x2071) true))))))))))))))
(check-sat)
; query 384: function gsm_mult_r, block 9, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1749 ((_ sign_extend 48) in0_16)))
(let ((?x1750 ((_ sign_extend 48) in1_16)))
(let ((?x2071 (bvmul ?x1750 ?x1749)))
(let ((?x2109 (bvadd ?x2071 (_ bv16384 64))))
(let ((?x1756 (bvmul ?x1749 ?x1750)))
(let ((?x2095 (bvadd ?x1756 (_ bv16384 64))))
(let (($x2111 (and (distinct (bvadd ((_ sign_extend 1) ?x2071) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x2109)) true)))
(let (($x2074 (and (distinct (bvmul ((_ sign_extend 64) ?x1750) ((_ sign_extend 64) ?x1749)) ((_ sign_extend 64) ?x2071)) true)))
(let (($x16 (or false false)))
(let (($x2076 (or $x16 $x16 (or $x2074))))
(let (($x2113 (or $x2076 false (or $x2111))))
(let (($x2097 (and (distinct (bvadd ((_ sign_extend 1) ?x1756) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x2095)) true)))
(let (($x1754 (and (distinct (bvmul ((_ sign_extend 64) ?x1749) ((_ sign_extend 64) ?x1750)) ((_ sign_extend 64) ?x1756)) true)))
(let (($x1758 (or $x16 $x16 (or $x1754))))
(let (($x2099 (or $x1758 false (or $x2097))))
(and (not $x2099) (or $x2113 (and (distinct ?x2095 ?x2109) true)))))))))))))))))))
(check-sat)
; query 385: function gsm_mult_r, block 9, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1749 ((_ sign_extend 48) in0_16)))
(let ((?x1750 ((_ sign_extend 48) in1_16)))
(let ((?x2071 (bvmul ?x1750 ?x1749)))
(let ((?x2109 (bvadd ?x2071 (_ bv16384 64))))
(let ((?x2116 (bvashr ?x2109 (_ bv15 64))))
(let ((?x1756 (bvmul ?x1749 ?x1750)))
(let ((?x2095 (bvadd ?x1756 (_ bv16384 64))))
(let ((?x2102 (bvashr ?x2095 (_ bv15 64))))
(let (($x131 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x2111 (and (distinct (bvadd ((_ sign_extend 1) ?x2071) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x2109)) true)))
(let (($x2074 (and (distinct (bvmul ((_ sign_extend 64) ?x1750) ((_ sign_extend 64) ?x1749)) ((_ sign_extend 64) ?x2071)) true)))
(let (($x16 (or false false)))
(let (($x2076 (or $x16 $x16 (or $x2074))))
(let (($x2113 (or $x2076 false (or $x2111))))
(let (($x2115 (or (or $x2113 false false) $x131)))
(let (($x2097 (and (distinct (bvadd ((_ sign_extend 1) ?x1756) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x2095)) true)))
(let (($x1754 (and (distinct (bvmul ((_ sign_extend 64) ?x1749) ((_ sign_extend 64) ?x1750)) ((_ sign_extend 64) ?x1756)) true)))
(let (($x1758 (or $x16 $x16 (or $x1754))))
(let (($x2099 (or $x1758 false (or $x2097))))
(let (($x2101 (or (or $x2099 false false) $x131)))
(and (not $x2101) (or $x2115 (and (distinct ?x2102 ?x2116) true))))))))))))))))))))))))
(check-sat)
; query 386: function gsm_mult_r, block 9, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1749 ((_ sign_extend 48) in0_16)))
(let ((?x1750 ((_ sign_extend 48) in1_16)))
(let ((?x2071 (bvmul ?x1750 ?x1749)))
(let ((?x2109 (bvadd ?x2071 (_ bv16384 64))))
(let ((?x2116 (bvashr ?x2109 (_ bv15 64))))
(let ((?x2118 (bvand ?x2116 (_ bv65535 64))))
(let ((?x1756 (bvmul ?x1749 ?x1750)))
(let ((?x2095 (bvadd ?x1756 (_ bv16384 64))))
(let ((?x2102 (bvashr ?x2095 (_ bv15 64))))
(let ((?x2104 (bvand ?x2102 (_ bv65535 64))))
(let (($x131 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x2111 (and (distinct (bvadd ((_ sign_extend 1) ?x2071) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x2109)) true)))
(let (($x2074 (and (distinct (bvmul ((_ sign_extend 64) ?x1750) ((_ sign_extend 64) ?x1749)) ((_ sign_extend 64) ?x2071)) true)))
(let (($x16 (or false false)))
(let (($x2076 (or $x16 $x16 (or $x2074))))
(let (($x2113 (or $x2076 false (or $x2111))))
(let (($x2115 (or (or $x2113 false false) $x131)))
(let (($x2117 (or $x2115 false false)))
(let (($x2097 (and (distinct (bvadd ((_ sign_extend 1) ?x1756) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x2095)) true)))
(let (($x1754 (and (distinct (bvmul ((_ sign_extend 64) ?x1749) ((_ sign_extend 64) ?x1750)) ((_ sign_extend 64) ?x1756)) true)))
(let (($x1758 (or $x16 $x16 (or $x1754))))
(let (($x2099 (or $x1758 false (or $x2097))))
(let (($x2101 (or (or $x2099 false false) $x131)))
(let (($x2103 (or $x2101 false false)))
(and (not $x2103) (or $x2117 (and (distinct ?x2104 ?x2118) true))))))))))))))))))))))))))))
(check-sat)
; query 387: function gsm_mult_r, block 9, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1749 ((_ sign_extend 48) in0_16)))
(let ((?x1750 ((_ sign_extend 48) in1_16)))
(let ((?x2071 (bvmul ?x1750 ?x1749)))
(let ((?x2109 (bvadd ?x2071 (_ bv16384 64))))
(let ((?x2116 (bvashr ?x2109 (_ bv15 64))))
(let ((?x2118 (bvand ?x2116 (_ bv65535 64))))
(let (($x2134 (and (distinct ((_ extract 15 0) (bvand (bvashr (bvadd (bvmul ?x1749 ?x1750) (_ bv16384 64)) (_ bv15 64)) (_ bv65535 64))) ((_ extract 15 0) ?x2118)) true)))
(let (($x131 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x2111 (and (distinct (bvadd ((_ sign_extend 1) ?x2071) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x2109)) true)))
(let (($x2074 (and (distinct (bvmul ((_ sign_extend 64) ?x1750) ((_ sign_extend 64) ?x1749)) ((_ sign_extend 64) ?x2071)) true)))
(let (($x16 (or false false)))
(let (($x2076 (or $x16 $x16 (or $x2074))))
(let (($x2113 (or $x2076 false (or $x2111))))
(let (($x2115 (or (or $x2113 false false) $x131)))
(let (($x2117 (or $x2115 false false)))
(let (($x2097 (and (distinct (bvadd ((_ sign_extend 1) (bvmul ?x1749 ?x1750)) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) (bvadd (bvmul ?x1749 ?x1750) (_ bv16384 64)))) true)))
(let (($x1754 (and (distinct (bvmul ((_ sign_extend 64) ?x1749) ((_ sign_extend 64) ?x1750)) ((_ sign_extend 64) (bvmul ?x1749 ?x1750))) true)))
(let (($x1758 (or $x16 $x16 (or $x1754))))
(let (($x2099 (or $x1758 false (or $x2097))))
(let (($x2101 (or (or $x2099 false false) $x131)))
(let (($x2103 (or $x2101 false false)))
(and (not (or $x2103 false)) (or (or $x2117 false) $x2134))))))))))))))))))))))))
(check-sat)
; query 388: function gsm_mult_r, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 389: function gsm_mult_r, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x2063 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x128 (not $x145)))
(and $x128 (or $x145 (and (distinct ?x2063 ?x2063) true))))))))
(check-sat)
; query 390: function gsm_norm, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1665 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x484 (or false false false)))
(let (($x225 (not $x484)))
(and $x225 (or $x484 (and (distinct ?x1665 ?x1665) true)))))))
(check-sat)
; query 391: function gsm_norm, block 12, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2139 (ite (bvsge (_ bv18446744072635809792 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x484 (or false false false)))
(let (($x225 (not $x484)))
(and $x225 (or $x484 (and (distinct ?x2139 ?x2139) true)))))))
(check-sat)
; query 392: function gsm_norm, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x484 (or false false false)))
(let (($x225 (not $x484)))
(and $x225 (or $x484 (and (distinct (bvxor in0_64 (_ bv18446744073709551615 64)) (bvxor in0_64 (_ bv18446744073709551615 64))) true))))))
(check-sat)
; query 393: function gsm_norm, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_64 () (_ BitVec 64))
(assert
 (let (($x484 (or false false false)))
(let (($x225 (not $x484)))
(and $x225 (or $x484 (and (distinct (bvand in.01_64 (_ bv4278190080 64)) (bvand in.01_64 (_ bv4278190080 64))) true))))))
(check-sat)
; query 394: function gsm_norm, block 20, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_64 () (_ BitVec 64))
(assert
 (let ((?x2151 (ite (and (distinct (_ bv0 64) (bvand in.01_64 (_ bv4278190080 64))) true) (_ bv1 1) (_ bv0 1))))
(let (($x484 (or false false false)))
(let (($x595 (or $x484 false false)))
(let (($x652 (not $x595)))
(and $x652 (or $x595 (and (distinct ?x2151 ?x2151) true))))))))
(check-sat)
; query 395: function gsm_norm, block 39, name %40
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_64 () (_ BitVec 64))
(assert
 (let (($x484 (or false false false)))
(let (($x225 (not $x484)))
(and $x225 (or $x484 (and (distinct (bvand in.01_64 (_ bv65280 64)) (bvand in.01_64 (_ bv65280 64))) true))))))
(check-sat)
; query 396: function gsm_norm, block 39, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_64 () (_ BitVec 64))
(assert
 (let ((?x2161 (ite (and (distinct (_ bv0 64) (bvand in.01_64 (_ bv65280 64))) true) (_ bv1 1) (_ bv0 1))))
(let (($x484 (or false false false)))
(let (($x595 (or $x484 false false)))
(let (($x652 (not $x595)))
(and $x652 (or $x595 (and (distinct ?x2161 ?x2161) true))))))))
(check-sat)
; query 397: function gsm_norm, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2169 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x484 (or false false false)))
(let (($x225 (not $x484)))
(and $x225 (or $x484 (and (distinct ?x2169 ?x2169) true)))))))
(check-sat)
; query 398: function gsm_norm, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2169 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x2170 (bvxor ?x2169 (_ bv1 1))))
(let (($x484 (or false false false)))
(let (($x595 (or $x484 false false)))
(let (($x652 (not $x595)))
(and $x652 (or $x595 (and (distinct ?x2170 ?x2170) true)))))))))
(check-sat)
; query 399: function gsm_norm, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2169 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x2170 (bvxor ?x2169 (_ bv1 1))))
(let ((?x2171 ((_ zero_extend 31) ?x2170)))
(let (($x484 (or false false false)))
(let (($x595 (or $x484 false false)))
(let (($x2172 (or $x595 false)))
(and (not $x2172) (or $x2172 (and (distinct ?x2171 ?x2171) true))))))))))
(check-sat)
; query 400: function gsm_norm, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2169 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x2170 (bvxor ?x2169 (_ bv1 1))))
(let ((?x2171 ((_ zero_extend 31) ?x2170)))
(let ((?x2173 ((_ sign_extend 32) ?x2171)))
(let (($x484 (or false false false)))
(let (($x595 (or $x484 false false)))
(let (($x2172 (or $x595 false)))
(let (($x2174 (or $x2172 false)))
(and (not $x2174) (or $x2174 (and (distinct ?x2173 ?x2173) true))))))))))))
(check-sat)
; query 401: function gsm_norm, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2169 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x2170 (bvxor ?x2169 (_ bv1 1))))
(let ((?x2171 ((_ zero_extend 31) ?x2170)))
(let ((?x2173 ((_ sign_extend 32) ?x2171)))
(let ((?x2177 (ite (and (distinct (_ bv0 64) ?x2173) true) (_ bv1 1) (_ bv0 1))))
(let (($x484 (or false false false)))
(let (($x595 (or $x484 false false)))
(let (($x2172 (or $x595 false)))
(let (($x2174 (or $x2172 false)))
(let (($x2176 (or $x2174 false false)))
(and (not $x2176) (or $x2176 (and (distinct ?x2177 ?x2177) true))))))))))))))
(check-sat)
; query 402: function gsm_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_64 () (_ BitVec 64))
(assert
 (let ((?x1890 (ite (bvslt (_ bv32767 64) in5_64) (_ bv1 1) (_ bv0 1))))
(let (($x484 (or false false false)))
(let (($x225 (not $x484)))
(and $x225 (or $x484 (and (distinct ?x1890 ?x1890) true)))))))
(check-sat)
; query 403: function gsm_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 404: function gsm_sub, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 405: function gsm_sub, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1750 ((_ sign_extend 48) in1_16)))
(let ((?x1749 ((_ sign_extend 48) in0_16)))
(let ((?x2197 (bvsub ?x1749 ?x1750)))
(let (($x2199 (and (distinct (bvsub ((_ sign_extend 1) ?x1749) ((_ sign_extend 1) ?x1750)) ((_ sign_extend 1) ?x2197)) true)))
(let (($x16 (or false false)))
(let (($x2201 (or $x16 $x16 (or $x2199))))
(and (not $x2201) (or $x2201 (and (distinct ?x2197 ?x2197) true))))))))))
(check-sat)
; query 406: function gsm_sub, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x2204 (ite (bvsgt (_ bv18446744073709518848 64) (bvsub ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x1750 ((_ sign_extend 48) in1_16)))
(let ((?x1895 ((_ sign_extend 1) ?x1750)))
(let ((?x1749 ((_ sign_extend 48) in0_16)))
(let ((?x1894 ((_ sign_extend 1) ?x1749)))
(let (($x16 (or false false)))
(let (($x2201 (or $x16 $x16 (or (and (distinct (bvsub ?x1894 ?x1895) ((_ sign_extend 1) (bvsub ?x1749 ?x1750))) true)))))
(let (($x2203 (or $x2201 false false)))
(and (not $x2203) (or $x2203 (and (distinct ?x2204 ?x2204) true))))))))))))
(check-sat)
; query 407: function ok_to_replace, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x2214 (ite (and (distinct (_ bv4294967295 32) in.01_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x484 (or false false false)))
(let (($x225 (not $x484)))
(and $x225 (or $x484 (and (distinct ?x2214 ?x2214) true)))))))
(check-sat)
; query 408: function ok_to_replace, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in16_32 () (_ BitVec 32))
(assert
 (let ((?x2220 (ite (= (_ bv121 32) in16_32) (_ bv1 1) (_ bv0 1))))
(let (($x484 (or false false false)))
(let (($x225 (not $x484)))
(and $x225 (or $x484 (and (distinct ?x2220 ?x2220) true)))))))
(check-sat)
; query 409: function process_decode, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 32) in14_32) ((_ sign_extend 32) in14_32)) true))))))
(check-sat)
; query 410: function process_decode, block 16, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x2228 (ite (and (distinct (_ bv33 64) ((_ sign_extend 32) in14_32)) true) (_ bv1 1) (_ bv0 1))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x128 (not $x145)))
(and $x128 (or $x145 (and (distinct ?x2228 ?x2228) true))))))))
(check-sat)
; query 411: function process_encode, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_32 () (_ BitVec 32))
(assert
 (let (($x16 (or false false)))
(let (($x554 (not $x16)))
(and $x554 (or $x16 (and (distinct ((_ sign_extend 32) in13_32) ((_ sign_extend 32) in13_32)) true))))))
(check-sat)
; query 412: function process_encode, block 15, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_32 () (_ BitVec 32))
(assert
 (let ((?x2239 (ite (bvult ((_ sign_extend 32) in13_32) (_ bv160 64)) (_ bv1 1) (_ bv0 1))))
(let (($x16 (or false false)))
(let (($x145 (or $x16 false false)))
(let (($x128 (not $x145)))
(and $x128 (or $x145 (and (distinct ?x2239 ?x2239) true))))))))
(check-sat)
; query 413: function suffix, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_64 () (_ BitVec 64))
(declare-fun in3_64 () (_ BitVec 64))
(assert
 (let ((?x2248 (ite (bvule in3_64 in4_64) (_ bv1 1) (_ bv0 1))))
(let (($x484 (or false false false)))
(let (($x225 (not $x484)))
(and $x225 (or $x484 (and (distinct ?x2248 ?x2248) true)))))))
(check-sat)
; query 414: function ulaw_input, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x490 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x806 (or false false (or $x490))))
(and (not $x806) (or $x806 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
