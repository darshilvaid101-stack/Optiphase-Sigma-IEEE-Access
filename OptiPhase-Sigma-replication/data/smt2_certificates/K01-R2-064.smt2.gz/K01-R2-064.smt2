; OptiPhase-Sigma refinement certificate for sweep K01-R2-064
