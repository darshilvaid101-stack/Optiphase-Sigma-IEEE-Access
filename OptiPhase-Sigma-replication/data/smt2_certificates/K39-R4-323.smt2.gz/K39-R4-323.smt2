; OptiPhase-Sigma refinement certificate for sweep K39-R4-323
