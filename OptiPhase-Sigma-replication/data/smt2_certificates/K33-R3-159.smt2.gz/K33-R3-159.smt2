; OptiPhase-Sigma refinement certificate for sweep K33-R3-159
; query 0: function edge_draw, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let ((?x73 (ite (= (_ bv0 32) in4_32) (_ bv1 1) (_ bv0 1))))
(let (($x101 (or false false false)))
(let (($x261 (not $x101)))
(and $x261 (or $x101 (and (distinct ?x73 ?x73) true)))))))
(check-sat)
; query 1: function main, block 129, name %130
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.011.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x531 (ite (and (distinct (_ bv0 32) in.011.lcssa_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x101 (or false false false)))
(let (($x261 (not $x101)))
(and $x261 (or $x101 (and (distinct ?x531 ?x531) true)))))))
(check-sat)
; query 2: function main, block 160, name %161
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x117 (ite (and (distinct (_ bv0 32) in.01.lcssa_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x101 (or false false false)))
(let (($x261 (not $x101)))
(and $x261 (or $x101 (and (distinct ?x117 ?x117) true)))))))
(check-sat)
; query 3: function main, block 66, name %67
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x18 (ite (= (_ bv0 32) in.0.lcssa_32) (_ bv1 1) (_ bv0 1))))
(let (($x101 (or false false false)))
(let (($x261 (not $x101)))
(and $x261 (or $x101 (and (distinct ?x18 ?x18) true)))))))
(check-sat)
; query 4: function main, block 84, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.07.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x341 (ite (and (distinct (_ bv0 32) in.07.lcssa_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x101 (or false false false)))
(let (($x261 (not $x101)))
(and $x261 (or $x101 (and (distinct ?x341 ?x341) true)))))))
(check-sat)
