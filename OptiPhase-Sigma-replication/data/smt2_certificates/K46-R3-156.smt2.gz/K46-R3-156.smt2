; OptiPhase-Sigma refinement certificate for sweep K46-R3-156
; query 0: function adpcm_decoder, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x40 (ite (and (distinct (_ bv0 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x144 (or false false false)))
(let (($x169 (not $x144)))
(and $x169 (or $x144 (and (distinct ?x40 ?x40) true)))))))
(check-sat)
; query 1: function adpcm_decoder, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x144 (or false false false)))
(let (($x169 (not $x144)))
(and $x169 (or $x144 (and (distinct (bvand in.01_32 (_ bv15 32)) (bvand in.01_32 (_ bv15 32))) true))))))
(check-sat)
; query 2: function adpcm_decoder, block 61, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.210_32 () (_ BitVec 32))
(declare-fun in.013_32 () (_ BitVec 32))
(assert
 (let ((?x311 (bvadd in.013_32 in.210_32)))
(let ((?x48 (bvsub in.013_32 in.210_32)))
(let (($x384 (and (distinct (bvadd ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x311)) true)))
(let (($x249 (and (distinct (bvsub ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x48)) true)))
(and (not (or false false (or $x249))) (or (or false false (or $x384)) (and (distinct ?x48 ?x311) true))))))))
(check-sat)
; query 3: function main, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x129 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x144 (or false false false)))
(let (($x169 (not $x144)))
(and $x169 (or $x144 (and (distinct ?x129 ?x129) true)))))))
(check-sat)
