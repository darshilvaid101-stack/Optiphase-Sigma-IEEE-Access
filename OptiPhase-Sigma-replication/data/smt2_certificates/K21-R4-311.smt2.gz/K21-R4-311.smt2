; OptiPhase-Sigma refinement certificate for sweep K21-R4-311
; query 0: function init_array, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x92 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x58 (or false false (or $x92))))
(and (not $x58) (or $x58 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function init_array, block 25, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x21 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x9 (or false false (or $x21))))
(and (not $x9) (or $x9 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function kernel_deriche, block 102, name %103
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.112_32 () (_ BitVec 32))
(assert
 (let (($x43 (and (distinct (bvadd ((_ sign_extend 1) in.112_32) ((_ sign_extend 1) (_ bv4294967295 32))) ((_ sign_extend 1) (bvadd in.112_32 (_ bv4294967295 32)))) true)))
(let (($x5 (or false false (or $x43))))
(and (not $x5) (or $x5 (and (distinct (bvadd in.112_32 (_ bv4294967295 32)) (bvadd in.112_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 3: function kernel_deriche, block 105, name %106
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.110_32 () (_ BitVec 32))
(assert
 (let (($x39 (and (distinct (bvadd ((_ sign_extend 1) in.110_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.110_32 (_ bv1 32)))) true)))
(let (($x97 (or false false (or $x39))))
(and (not $x97) (or $x97 (and (distinct (bvadd in.110_32 (_ bv1 32)) (bvadd in.110_32 (_ bv1 32))) true))))))
(check-sat)
; query 4: function kernel_deriche, block 130, name %131
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.213_32 () (_ BitVec 32))
(assert
 (let (($x37 (and (distinct (bvadd ((_ sign_extend 1) in.213_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.213_32 (_ bv1 32)))) true)))
(let (($x15 (or false false (or $x37))))
(and (not $x15) (or $x15 (and (distinct (bvadd in.213_32 (_ bv1 32)) (bvadd in.213_32 (_ bv1 32))) true))))))
(check-sat)
; query 5: function kernel_deriche, block 133, name %134
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let (($x74 (and (distinct (bvadd ((_ sign_extend 1) in.2_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.2_32 (_ bv1 32)))) true)))
(let (($x309 (or false false (or $x74))))
(and (not $x309) (or $x309 (and (distinct (bvadd in.2_32 (_ bv1 32)) (bvadd in.2_32 (_ bv1 32))) true))))))
(check-sat)
; query 6: function kernel_deriche, block 165, name %166
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.3_32 () (_ BitVec 32))
(assert
 (let (($x34 (and (distinct (bvadd ((_ sign_extend 1) in.3_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.3_32 (_ bv1 32)))) true)))
(let (($x11 (or false false (or $x34))))
(and (not $x11) (or $x11 (and (distinct (bvadd in.3_32 (_ bv1 32)) (bvadd in.3_32 (_ bv1 32))) true))))))
(check-sat)
; query 7: function kernel_deriche, block 168, name %169
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.314_32 () (_ BitVec 32))
(assert
 (let (($x76 (and (distinct (bvadd ((_ sign_extend 1) in.314_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.314_32 (_ bv1 32)))) true)))
(let (($x40 (or false false (or $x76))))
(and (not $x40) (or $x40 (and (distinct (bvadd in.314_32 (_ bv1 32)) (bvadd in.314_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function kernel_deriche, block 173, name %174
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x127 (and (distinct (bvsub ((_ sign_extend 1) in0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvsub in0_32 (_ bv1 32)))) true)))
(let (($x128 (or false false (or $x127))))
(and (not $x128) (or $x128 (and (distinct (bvsub in0_32 (_ bv1 32)) (bvsub in0_32 (_ bv1 32))) true))))))
(check-sat)
; query 9: function kernel_deriche, block 196, name %197
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.4_32 () (_ BitVec 32))
(assert
 (let (($x126 (and (distinct (bvadd ((_ sign_extend 1) in.4_32) ((_ sign_extend 1) (_ bv4294967295 32))) ((_ sign_extend 1) (bvadd in.4_32 (_ bv4294967295 32)))) true)))
(let (($x109 (or false false (or $x126))))
(and (not $x109) (or $x109 (and (distinct (bvadd in.4_32 (_ bv4294967295 32)) (bvadd in.4_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 10: function kernel_deriche, block 199, name %200
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.415_32 () (_ BitVec 32))
(assert
 (let (($x155 (and (distinct (bvadd ((_ sign_extend 1) in.415_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.415_32 (_ bv1 32)))) true)))
(let (($x465 (or false false (or $x155))))
(and (not $x465) (or $x465 (and (distinct (bvadd in.415_32 (_ bv1 32)) (bvadd in.415_32 (_ bv1 32))) true))))))
(check-sat)
; query 11: function kernel_deriche, block 224, name %225
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.516_32 () (_ BitVec 32))
(assert
 (let (($x300 (and (distinct (bvadd ((_ sign_extend 1) in.516_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.516_32 (_ bv1 32)))) true)))
(let (($x139 (or false false (or $x300))))
(and (not $x139) (or $x139 (and (distinct (bvadd in.516_32 (_ bv1 32)) (bvadd in.516_32 (_ bv1 32))) true))))))
(check-sat)
; query 12: function kernel_deriche, block 227, name %228
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.5_32 () (_ BitVec 32))
(assert
 (let (($x478 (and (distinct (bvadd ((_ sign_extend 1) in.5_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.5_32 (_ bv1 32)))) true)))
(let (($x503 (or false false (or $x478))))
(and (not $x503) (or $x503 (and (distinct (bvadd in.5_32 (_ bv1 32)) (bvadd in.5_32 (_ bv1 32))) true))))))
(check-sat)
; query 13: function kernel_deriche, block 71, name %72
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.011_32 () (_ BitVec 32))
(assert
 (let (($x396 (and (distinct (bvadd ((_ sign_extend 1) in.011_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.011_32 (_ bv1 32)))) true)))
(let (($x474 (or false false (or $x396))))
(and (not $x474) (or $x474 (and (distinct (bvadd in.011_32 (_ bv1 32)) (bvadd in.011_32 (_ bv1 32))) true))))))
(check-sat)
; query 14: function kernel_deriche, block 74, name %75
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.09_32 () (_ BitVec 32))
(assert
 (let (($x180 (and (distinct (bvadd ((_ sign_extend 1) in.09_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.09_32 (_ bv1 32)))) true)))
(let (($x149 (or false false (or $x180))))
(and (not $x149) (or $x149 (and (distinct (bvadd in.09_32 (_ bv1 32)) (bvadd in.09_32 (_ bv1 32))) true))))))
(check-sat)
; query 15: function kernel_deriche, block 79, name %80
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x263 (and (distinct (bvsub ((_ sign_extend 1) in1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvsub in1_32 (_ bv1 32)))) true)))
(let (($x107 (or false false (or $x263))))
(and (not $x107) (or $x107 (and (distinct (bvsub in1_32 (_ bv1 32)) (bvsub in1_32 (_ bv1 32))) true))))))
(check-sat)
; query 16: function polybench_flush_cache, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x21 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x9 (or false false (or $x21))))
(and (not $x9) (or $x9 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 17: function print_array, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x92 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x58 (or false false (or $x92))))
(and (not $x58) (or $x58 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 18: function print_array, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x21 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x9 (or false false (or $x21))))
(and (not $x9) (or $x9 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 19: function xmalloc, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in7_32 () (_ BitVec 32))
(assert
 (let ((?x541 (ite (and (distinct (_ bv0 32) in7_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x280 (or false false false)))
(and (not $x280) (or $x280 (and (distinct ?x541 ?x541) true))))))
(check-sat)
