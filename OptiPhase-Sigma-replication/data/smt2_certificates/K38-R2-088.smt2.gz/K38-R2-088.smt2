; OptiPhase-Sigma refinement certificate for sweep K38-R2-088
; query 0: function BF_cbc_encrypt, block 126, name %127
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.010_64 () (_ BitVec 64))
(assert
 (let (($x39 (and (distinct (bvsub ((_ sign_extend 1) in.010_64) ((_ sign_extend 1) (_ bv8 64))) ((_ sign_extend 1) (bvsub in.010_64 (_ bv8 64)))) true)))
(let (($x531 (or false false (or $x39))))
(and (not $x531) (or $x531 (and (distinct (bvsub in.010_64 (_ bv8 64)) (bvsub in.010_64 (_ bv8 64))) true))))))
(check-sat)
; query 1: function BF_cbc_encrypt, block 128, name %129
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.010_64 () (_ BitVec 64))
(assert
 (let ((?x501 (ite (and (distinct (_ bv18446744073709551608 64) in.010_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x196 (or false false false)))
(let (($x499 (not $x196)))
(and $x499 (or $x196 (and (distinct ?x501 ?x501) true)))))))
(check-sat)
; query 2: function BF_cbc_encrypt, block 366, name %367
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.111_64 () (_ BitVec 64))
(assert
 (let (($x42 (and (distinct (bvsub ((_ sign_extend 1) in.111_64) ((_ sign_extend 1) (_ bv8 64))) ((_ sign_extend 1) (bvsub in.111_64 (_ bv8 64)))) true)))
(let (($x627 (or false false (or $x42))))
(and (not $x627) (or $x627 (and (distinct (bvsub in.111_64 (_ bv8 64)) (bvsub in.111_64 (_ bv8 64))) true))))))
(check-sat)
; query 3: function BF_cbc_encrypt, block 368, name %369
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.111_64 () (_ BitVec 64))
(assert
 (let ((?x120 (ite (and (distinct (_ bv18446744073709551608 64) in.111_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x196 (or false false false)))
(let (($x499 (not $x196)))
(and $x499 (or $x196 (and (distinct ?x120 ?x120) true)))))))
(check-sat)
; query 4: function BF_cfb64_encrypt, block 111, name %112
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.18_32 () (_ BitVec 32))
(assert
 (let ((?x37 (ite (= (_ bv0 32) in.18_32) (_ bv1 1) (_ bv0 1))))
(let (($x196 (or false false false)))
(let (($x499 (not $x196)))
(and $x499 (or $x196 (and (distinct ?x37 ?x37) true)))))))
(check-sat)
; query 5: function BF_cfb64_encrypt, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.07_32 () (_ BitVec 32))
(assert
 (let ((?x54 (ite (= (_ bv0 32) in.07_32) (_ bv1 1) (_ bv0 1))))
(let (($x196 (or false false false)))
(let (($x499 (not $x196)))
(and $x499 (or $x196 (and (distinct ?x54 ?x54) true)))))))
(check-sat)
; query 6: function BF_ofb64_encrypt, block 135, name %136
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x79 (ite (and (distinct (_ bv0 32) in.02_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x196 (or false false false)))
(let (($x499 (not $x196)))
(and $x499 (or $x196 (and (distinct ?x79 ?x79) true)))))))
(check-sat)
; query 7: function BF_ofb64_encrypt, block 82, name %83
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x26 (ite (= (_ bv0 32) in.04_32) (_ bv1 1) (_ bv0 1))))
(let (($x196 (or false false false)))
(let (($x499 (not $x196)))
(and $x499 (or $x196 (and (distinct ?x26 ?x26) true)))))))
(check-sat)
; query 8: function BF_set_key, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x9 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x91 (or false false (or $x9))))
(and (not $x91) (or $x91 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 9: function BF_set_key, block 69, name %70
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.13_32 () (_ BitVec 32))
(assert
 (let (($x16 (and (distinct (bvadd ((_ sign_extend 1) in.13_32) ((_ sign_extend 1) (_ bv2 32))) ((_ sign_extend 1) (bvadd in.13_32 (_ bv2 32)))) true)))
(let (($x130 (or false false (or $x16))))
(and (not $x130) (or $x130 (and (distinct (bvadd in.13_32 (_ bv2 32)) (bvadd in.13_32 (_ bv2 32))) true))))))
(check-sat)
; query 10: function BF_set_key, block 87, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.24_32 () (_ BitVec 32))
(assert
 (let (($x514 (and (distinct (bvadd ((_ sign_extend 1) in.24_32) ((_ sign_extend 1) (_ bv2 32))) ((_ sign_extend 1) (bvadd in.24_32 (_ bv2 32)))) true)))
(let (($x86 (or false false (or $x514))))
(and (not $x86) (or $x86 (and (distinct (bvadd in.24_32 (_ bv2 32)) (bvadd in.24_32 (_ bv2 32))) true))))))
(check-sat)
; query 11: function main, block 124, name %125
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let ((?x155 (ite (bvsgt (_ bv40 32) in.2_32) (_ bv1 1) (_ bv0 1))))
(let (($x196 (or false false false)))
(let (($x499 (not $x196)))
(and $x499 (or $x196 (and (distinct ?x155 ?x155) true)))))))
(check-sat)
; query 12: function main, block 147, name %148
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x107 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x36 (or false false (or $x107))))
(and (not $x36) (or $x36 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 13: function main, block 60, name %61
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x71 (or false false)))
(and (not $x71) (or $x71 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 14: function main, block 60, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x94 (ite (bvsge (_ bv57 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x71 (or false false)))
(let (($x524 (or $x71 false false)))
(let (($x563 (not $x524)))
(and $x563 (or $x524 (and (distinct ?x94 ?x94) true))))))))
(check-sat)
; query 15: function main, block 63, name %64
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x196 (or false false false)))
(let (($x175 (or $x196 (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x175) (or $x175 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvshl in.01_32 (_ bv4 32))) true))))))
(check-sat)
; query 16: function main, block 63, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x71 (or false false)))
(and (not $x71) (or $x71 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 17: function main, block 63, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x7 ((_ sign_extend 24) in57_8)))
(let ((?x20 (bvshl in.01_32 (_ bv4 32))))
(let ((?x365 (bvadd ?x20 ?x7)))
(let ((?x105 ((_ sign_extend 1) ?x365)))
(let (($x71 (or false false)))
(let (($x196 (or false false false)))
(let (($x175 (or $x196 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x604 (or $x175 $x71 (or (and (distinct (bvadd ((_ sign_extend 1) ?x20) ((_ sign_extend 1) ?x7)) ?x105) true)))))
(and (not $x604) (or $x604 (and (distinct ?x365 ?x365) true))))))))))))
(check-sat)
; query 18: function main, block 63, name %67
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x7 ((_ sign_extend 24) in57_8)))
(let ((?x20 (bvshl in.01_32 (_ bv4 32))))
(let ((?x365 (bvadd ?x20 ?x7)))
(let ((?x508 (bvsub ?x365 (_ bv48 32))))
(let (($x439 (and (distinct (bvsub ((_ sign_extend 1) ?x365) ((_ sign_extend 1) (_ bv48 32))) ((_ sign_extend 1) ?x508)) true)))
(let ((?x105 ((_ sign_extend 1) ?x365)))
(let (($x71 (or false false)))
(let (($x196 (or false false false)))
(let (($x175 (or $x196 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x604 (or $x175 $x71 (or (and (distinct (bvadd ((_ sign_extend 1) ?x20) ((_ sign_extend 1) ?x7)) ?x105) true)))))
(let (($x363 (or $x604 false (or $x439))))
(and (not $x363) (or $x363 (and (distinct ?x508 ?x508) true)))))))))))))))
(check-sat)
; query 19: function main, block 68, name %69
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x71 (or false false)))
(and (not $x71) (or $x71 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 20: function main, block 68, name %70
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x153 (ite (bvsle (_ bv65 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x71 (or false false)))
(let (($x524 (or $x71 false false)))
(let (($x563 (not $x524)))
(and $x563 (or $x524 (and (distinct ?x153 ?x153) true))))))))
(check-sat)
; query 21: function main, block 71, name %72
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x71 (or false false)))
(and (not $x71) (or $x71 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 22: function main, block 71, name %73
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x109 (ite (bvsge (_ bv70 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x71 (or false false)))
(let (($x524 (or $x71 false false)))
(let (($x563 (not $x524)))
(and $x563 (or $x524 (and (distinct ?x109 ?x109) true))))))))
(check-sat)
; query 23: function main, block 74, name %75
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x196 (or false false false)))
(let (($x175 (or $x196 (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x175) (or $x175 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvshl in.01_32 (_ bv4 32))) true))))))
(check-sat)
; query 24: function main, block 74, name %76
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x71 (or false false)))
(and (not $x71) (or $x71 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 25: function main, block 74, name %77
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x7 ((_ sign_extend 24) in57_8)))
(let ((?x20 (bvshl in.01_32 (_ bv4 32))))
(let ((?x365 (bvadd ?x20 ?x7)))
(let ((?x105 ((_ sign_extend 1) ?x365)))
(let (($x71 (or false false)))
(let (($x196 (or false false false)))
(let (($x175 (or $x196 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x604 (or $x175 $x71 (or (and (distinct (bvadd ((_ sign_extend 1) ?x20) ((_ sign_extend 1) ?x7)) ?x105) true)))))
(and (not $x604) (or $x604 (and (distinct ?x365 ?x365) true))))))))))))
(check-sat)
; query 26: function main, block 74, name %78
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x7 ((_ sign_extend 24) in57_8)))
(let ((?x20 (bvshl in.01_32 (_ bv4 32))))
(let ((?x365 (bvadd ?x20 ?x7)))
(let ((?x322 (bvsub ?x365 (_ bv65 32))))
(let ((?x366 ((_ sign_extend 1) ?x322)))
(let ((?x105 ((_ sign_extend 1) ?x365)))
(let (($x71 (or false false)))
(let (($x196 (or false false false)))
(let (($x175 (or $x196 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x604 (or $x175 $x71 (or (and (distinct (bvadd ((_ sign_extend 1) ?x20) ((_ sign_extend 1) ?x7)) ?x105) true)))))
(let (($x483 (or $x604 false (or (and (distinct (bvsub ?x105 ((_ sign_extend 1) (_ bv65 32))) ?x366) true)))))
(and (not $x483) (or $x483 (and (distinct ?x322 ?x322) true)))))))))))))))
(check-sat)
; query 27: function main, block 74, name %79
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x7 ((_ sign_extend 24) in57_8)))
(let ((?x20 (bvshl in.01_32 (_ bv4 32))))
(let ((?x365 (bvadd ?x20 ?x7)))
(let ((?x322 (bvsub ?x365 (_ bv65 32))))
(let ((?x127 (bvadd ?x322 (_ bv10 32))))
(let (($x286 (and (distinct (bvadd ((_ sign_extend 1) ?x322) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x127)) true)))
(let ((?x366 ((_ sign_extend 1) ?x322)))
(let ((?x105 ((_ sign_extend 1) ?x365)))
(let (($x71 (or false false)))
(let (($x196 (or false false false)))
(let (($x175 (or $x196 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x604 (or $x175 $x71 (or (and (distinct (bvadd ((_ sign_extend 1) ?x20) ((_ sign_extend 1) ?x7)) ?x105) true)))))
(let (($x483 (or $x604 false (or (and (distinct (bvsub ?x105 ((_ sign_extend 1) (_ bv65 32))) ?x366) true)))))
(let (($x23 (or $x483 false (or $x286))))
(and (not $x23) (or $x23 (and (distinct ?x127 ?x127) true))))))))))))))))))
(check-sat)
