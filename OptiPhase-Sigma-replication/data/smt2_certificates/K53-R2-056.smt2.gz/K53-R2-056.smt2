; OptiPhase-Sigma refinement certificate for sweep K53-R2-056
; query 0: function check, block 103, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x273 (ite (= (_ bv22 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x99 (or false false false)))
(let (($x756 (not $x99)))
(and $x756 (or $x99 (and (distinct ?x273 ?x273) true)))))))
(check-sat)
; query 1: function check, block 109, name %110
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x41 (ite (= (_ bv33 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x99 (or false false false)))
(let (($x756 (not $x99)))
(and $x756 (or $x99 (and (distinct ?x41 ?x41) true)))))))
(check-sat)
; query 2: function check, block 115, name %116
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x488 (ite (= (_ bv0 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x99 (or false false false)))
(let (($x756 (not $x99)))
(and $x756 (or $x99 (and (distinct ?x488 ?x488) true)))))))
(check-sat)
; query 3: function check, block 121, name %122
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x51 (ite (= (_ bv12 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x99 (or false false false)))
(let (($x756 (not $x99)))
(and $x756 (or $x99 (and (distinct ?x51 ?x51) true)))))))
(check-sat)
; query 4: function check, block 128, name %129
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x224 (ite (= (_ bv25 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x99 (or false false false)))
(let (($x756 (not $x99)))
(and $x756 (or $x99 (and (distinct ?x224 ?x224) true)))))))
(check-sat)
; query 5: function check, block 135, name %136
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x69 (ite (= (_ bv13 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x99 (or false false false)))
(let (($x756 (not $x99)))
(and $x756 (or $x99 (and (distinct ?x69 ?x69) true)))))))
(check-sat)
; query 6: function check, block 142, name %143
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x6 (ite (= (_ bv123 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x99 (or false false false)))
(let (($x756 (not $x99)))
(and $x756 (or $x99 (and (distinct ?x6 ?x6) true)))))))
(check-sat)
; query 7: function check, block 150, name %151
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x361 (ite (= (_ bv1122 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x99 (or false false false)))
(let (($x756 (not $x99)))
(and $x756 (or $x99 (and (distinct ?x361 ?x361) true)))))))
(check-sat)
; query 8: function check, block 157, name %158
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x266 (ite (= (_ bv112233 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x99 (or false false false)))
(let (($x756 (not $x99)))
(and $x756 (or $x99 (and (distinct ?x266 ?x266) true)))))))
(check-sat)
; query 9: function check, block 165, name %166
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x17 (ite (= (_ bv111 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x99 (or false false false)))
(let (($x756 (not $x99)))
(and $x756 (or $x99 (and (distinct ?x17 ?x17) true)))))))
(check-sat)
; query 10: function check, block 172, name %173
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x369 (ite (= (_ bv4294967295 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x99 (or false false false)))
(let (($x756 (not $x99)))
(and $x756 (or $x99 (and (distinct ?x369 ?x369) true)))))))
(check-sat)
; query 11: function check, block 179, name %180
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x117 (ite (= (_ bv4294967284 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x99 (or false false false)))
(let (($x756 (not $x99)))
(and $x756 (or $x99 (and (distinct ?x117 ?x117) true)))))))
(check-sat)
; query 12: function check, block 25, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_32 () (_ BitVec 32))
(assert
 (let (($x880 (and (distinct (bvadd ((_ sign_extend 1) in.06_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.06_32 (_ bv1 32)))) true)))
(let (($x26 (or false false (or $x880))))
(and (not $x26) (or $x26 (and (distinct (bvadd in.06_32 (_ bv1 32)) (bvadd in.06_32 (_ bv1 32))) true))))))
(check-sat)
; query 13: function check, block 52, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.013_32 () (_ BitVec 32))
(assert
 (let (($x484 (and (distinct (bvadd ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.013_32 (_ bv1 32)))) true)))
(let (($x517 (or false false (or $x484))))
(and (not $x517) (or $x517 (and (distinct (bvadd in.013_32 (_ bv1 32)) (bvadd in.013_32 (_ bv1 32))) true))))))
(check-sat)
; query 14: function check, block 55, name %56
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.012_32 () (_ BitVec 32))
(assert
 (let (($x34 (and (distinct (bvadd ((_ sign_extend 1) in.012_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.012_32 (_ bv1 32)))) true)))
(let (($x446 (or false false (or $x34))))
(and (not $x446) (or $x446 (and (distinct (bvadd in.012_32 (_ bv1 32)) (bvadd in.012_32 (_ bv1 32))) true))))))
(check-sat)
; query 15: function check, block 65, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x429 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x72 (or false false (or $x429))))
(and (not $x72) (or $x72 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 16: function check, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x7 (ite (= (_ bv2 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x99 (or false false false)))
(let (($x756 (not $x99)))
(and $x756 (or $x99 (and (distinct ?x7 ?x7) true)))))))
(check-sat)
; query 17: function check, block 79, name %80
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x149 (ite (= (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x99 (or false false false)))
(let (($x756 (not $x99)))
(and $x756 (or $x99 (and (distinct ?x149 ?x149) true)))))))
(check-sat)
; query 18: function check, block 85, name %86
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x289 (ite (= (_ bv4 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x99 (or false false false)))
(let (($x756 (not $x99)))
(and $x756 (or $x99 (and (distinct ?x289 ?x289) true)))))))
(check-sat)
; query 19: function check, block 91, name %92
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x406 (ite (= (_ bv5 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x99 (or false false false)))
(let (($x756 (not $x99)))
(and $x756 (or $x99 (and (distinct ?x406 ?x406) true)))))))
(check-sat)
; query 20: function check, block 97, name %98
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x592 (ite (= (_ bv11 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x99 (or false false false)))
(let (($x756 (not $x99)))
(and $x756 (or $x99 (and (distinct ?x592 ?x592) true)))))))
(check-sat)
; query 21: function init, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x429 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x72 (or false false (or $x429))))
(and (not $x72) (or $x72 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 22: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x1060 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x99 (or false false false)))
(let (($x756 (not $x99)))
(and $x756 (or $x99 (and (distinct ?x1060 ?x1060) true)))))))
(check-sat)
; query 23: function s13110, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x429 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x72 (or false false (or $x429))))
(and (not $x72) (or $x72 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 24: function s13110, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x675 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x222 (or false false (or $x675))))
(and (not $x222) (or $x222 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 25: function s13110, block 39, name %40
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x401 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x82 (or false false (or $x401))))
(and (not $x82) (or $x82 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 26: function s311, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x429 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x72 (or false false (or $x429))))
(and (not $x72) (or $x72 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 27: function s311, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x675 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x222 (or false false (or $x675))))
(and (not $x222) (or $x222 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 28: function s3110, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x429 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x72 (or false false (or $x429))))
(and (not $x72) (or $x72 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 29: function s3110, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x675 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x222 (or false false (or $x675))))
(and (not $x222) (or $x222 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 30: function s3110, block 39, name %40
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x401 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x82 (or false false (or $x401))))
(and (not $x82) (or $x82 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 31: function s3111, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x429 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x72 (or false false (or $x429))))
(and (not $x72) (or $x72 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 32: function s3111, block 24, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x675 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x222 (or false false (or $x675))))
(and (not $x222) (or $x222 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 33: function s31111, block 24, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x429 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x72 (or false false (or $x429))))
(and (not $x72) (or $x72 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 34: function s3112, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x429 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x72 (or false false (or $x429))))
(and (not $x72) (or $x72 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 35: function s3112, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x675 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x222 (or false false (or $x675))))
(and (not $x222) (or $x222 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 36: function s3113, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x429 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x72 (or false false (or $x429))))
(and (not $x72) (or $x72 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 37: function s3113, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x675 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x222 (or false false (or $x675))))
(and (not $x222) (or $x222 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 38: function s312, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x429 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x72 (or false false (or $x429))))
(and (not $x72) (or $x72 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 39: function s312, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x675 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x222 (or false false (or $x675))))
(and (not $x222) (or $x222 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 40: function s313, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x429 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x72 (or false false (or $x429))))
(and (not $x72) (or $x72 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 41: function s313, block 21, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x675 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x222 (or false false (or $x675))))
(and (not $x222) (or $x222 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 42: function s314, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x429 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x72 (or false false (or $x429))))
(and (not $x72) (or $x72 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 43: function s314, block 24, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x675 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x222 (or false false (or $x675))))
(and (not $x222) (or $x222 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 44: function s315, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_32 () (_ BitVec 32))
(assert
 (let (($x880 (and (distinct (bvadd ((_ sign_extend 1) in.06_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.06_32 (_ bv1 32)))) true)))
(let (($x26 (or false false (or $x880))))
(and (not $x26) (or $x26 (and (distinct (bvadd in.06_32 (_ bv1 32)) (bvadd in.06_32 (_ bv1 32))) true))))))
(check-sat)
; query 45: function s315, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x429 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x72 (or false false (or $x429))))
(and (not $x72) (or $x72 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 46: function s315, block 36, name %37
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x675 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x222 (or false false (or $x675))))
(and (not $x222) (or $x222 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 47: function s316, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x429 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x72 (or false false (or $x429))))
(and (not $x72) (or $x72 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 48: function s316, block 24, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x675 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x222 (or false false (or $x675))))
(and (not $x222) (or $x222 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 49: function s317, block 11, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x429 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x72 (or false false (or $x429))))
(and (not $x72) (or $x72 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 50: function s317, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x675 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x222 (or false false (or $x675))))
(and (not $x222) (or $x222 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 51: function s318, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x429 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x72 (or false false (or $x429))))
(and (not $x72) (or $x72 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 52: function s318, block 39, name %40
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x675 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x222 (or false false (or $x675))))
(and (not $x222) (or $x222 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 53: function s319, block 36, name %37
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x429 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x72 (or false false (or $x429))))
(and (not $x72) (or $x72 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 54: function s319, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x675 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x222 (or false false (or $x675))))
(and (not $x222) (or $x222 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 55: function set, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x421 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv5 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv5 32)))) true)))
(let (($x559 (or false false (or $x421))))
(and (not $x559) (or $x559 (and (distinct (bvadd in.01_32 (_ bv5 32)) (bvadd in.01_32 (_ bv5 32))) true))))))
(check-sat)
; query 56: function set, block 46, name %47
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x429 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x72 (or false false (or $x429))))
(and (not $x72) (or $x72 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 57: function set1d, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x401 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x82 (or false false (or $x401))))
(and (not $x82) (or $x82 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 58: function set1d, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x164 (ite (= (_ bv4294967294 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x99 (or false false false)))
(let (($x756 (not $x99)))
(and $x756 (or $x99 (and (distinct ?x164 ?x164) true)))))))
(check-sat)
; query 59: function set1d, block 34, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x675 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x222 (or false false (or $x675))))
(and (not $x222) (or $x222 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 60: function set1d, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x628 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) in2_32)) ((_ sign_extend 1) (bvadd in.0_32 in2_32))) true)))
(let (($x53 (or false false (or $x628))))
(let (($x179 (or $x53 (and (distinct (bvadd in.0_32 in2_32) (bvadd in.0_32 in2_32)) true))))
(and (not $x53) $x179)))))
(check-sat)
; query 61: function set1d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x684 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x99 (or false false false)))
(let (($x756 (not $x99)))
(and $x756 (or $x99 (and (distinct ?x684 ?x684) true)))))))
(check-sat)
; query 62: function set1ds, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x401 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x82 (or false false (or $x401))))
(and (not $x82) (or $x82 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 63: function set1ds, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x715 (ite (= (_ bv4294967294 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x99 (or false false false)))
(let (($x756 (not $x99)))
(and $x756 (or $x99 (and (distinct ?x715 ?x715) true)))))))
(check-sat)
; query 64: function set1ds, block 35, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x675 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x222 (or false false (or $x675))))
(and (not $x222) (or $x222 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 65: function set1ds, block 44, name %45
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x183 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) in3_32)) ((_ sign_extend 1) (bvadd in.0_32 in3_32))) true)))
(let (($x330 (or false false (or $x183))))
(let (($x203 (or $x330 (and (distinct (bvadd in.0_32 in3_32) (bvadd in.0_32 in3_32)) true))))
(and (not $x330) $x203)))))
(check-sat)
; query 66: function set1ds, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x908 (ite (= (_ bv4294967295 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x99 (or false false false)))
(let (($x756 (not $x99)))
(and $x756 (or $x99 (and (distinct ?x908 ?x908) true)))))))
(check-sat)
; query 67: function set2d, block 21, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let (($x704 (and (distinct (bvadd ((_ sign_extend 1) in.04_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.04_32 (_ bv1 32)))) true)))
(let (($x522 (or false false (or $x704))))
(and (not $x522) (or $x522 (and (distinct (bvadd in.04_32 (_ bv1 32)) (bvadd in.04_32 (_ bv1 32))) true))))))
(check-sat)
; query 68: function set2d, block 24, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_32 () (_ BitVec 32))
(assert
 (let (($x376 (and (distinct (bvadd ((_ sign_extend 1) in.03_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.03_32 (_ bv1 32)))) true)))
(let (($x575 (or false false (or $x376))))
(and (not $x575) (or $x575 (and (distinct (bvadd in.03_32 (_ bv1 32)) (bvadd in.03_32 (_ bv1 32))) true))))))
(check-sat)
; query 69: function set2d, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x164 (ite (= (_ bv4294967294 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x99 (or false false false)))
(let (($x756 (not $x99)))
(and $x756 (or $x99 (and (distinct ?x164 ?x164) true)))))))
(check-sat)
; query 70: function set2d, block 47, name %48
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x401 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x82 (or false false (or $x401))))
(and (not $x82) (or $x82 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 71: function set2d, block 50, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.05_32 () (_ BitVec 32))
(assert
 (let (($x746 (and (distinct (bvadd ((_ sign_extend 1) in.05_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.05_32 (_ bv1 32)))) true)))
(let (($x455 (or false false (or $x746))))
(and (not $x455) (or $x455 (and (distinct (bvadd in.05_32 (_ bv1 32)) (bvadd in.05_32 (_ bv1 32))) true))))))
(check-sat)
; query 72: function set2d, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x628 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) in2_32)) ((_ sign_extend 1) (bvadd in.0_32 in2_32))) true)))
(let (($x53 (or false false (or $x628))))
(let (($x179 (or $x53 (and (distinct (bvadd in.0_32 in2_32) (bvadd in.0_32 in2_32)) true))))
(and (not $x53) $x179)))))
(check-sat)
; query 73: function set2d, block 67, name %68
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x675 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x222 (or false false (or $x675))))
(and (not $x222) (or $x222 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 74: function set2d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x684 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x99 (or false false false)))
(let (($x756 (not $x99)))
(and $x756 (or $x99 (and (distinct ?x684 ?x684) true)))))))
(check-sat)
; query 75: function sum1d, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x429 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x72 (or false false (or $x429))))
(and (not $x72) (or $x72 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 76: function test, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x429 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x72 (or false false (or $x429))))
(and (not $x72) (or $x72 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
