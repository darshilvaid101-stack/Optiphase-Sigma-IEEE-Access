; OptiPhase-Sigma refinement certificate for sweep K06-R2-012
