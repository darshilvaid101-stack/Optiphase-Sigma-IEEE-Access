; OptiPhase-Sigma refinement certificate for sweep K38-R3-146
; query 0: function BF_cbc_encrypt, block 126, name %127
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.010_64 () (_ BitVec 64))
(assert
 (let (($x91 (and (distinct (bvsub ((_ sign_extend 1) in.010_64) ((_ sign_extend 1) (_ bv8 64))) ((_ sign_extend 1) (bvsub in.010_64 (_ bv8 64)))) true)))
(let (($x51 (or false false (or $x91))))
(and (not $x51) (or $x51 (and (distinct (bvsub in.010_64 (_ bv8 64)) (bvsub in.010_64 (_ bv8 64))) true))))))
(check-sat)
; query 1: function BF_cbc_encrypt, block 366, name %367
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.111_64 () (_ BitVec 64))
(assert
 (let (($x70 (and (distinct (bvsub ((_ sign_extend 1) in.111_64) ((_ sign_extend 1) (_ bv8 64))) ((_ sign_extend 1) (bvsub in.111_64 (_ bv8 64)))) true)))
(let (($x38 (or false false (or $x70))))
(and (not $x38) (or $x38 (and (distinct (bvsub in.111_64 (_ bv8 64)) (bvsub in.111_64 (_ bv8 64))) true))))))
(check-sat)
; query 2: function BF_set_key, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x126 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x20 (or false false (or $x126))))
(and (not $x20) (or $x20 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 3: function BF_set_key, block 69, name %70
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.13_32 () (_ BitVec 32))
(assert
 (let (($x55 (and (distinct (bvadd ((_ sign_extend 1) in.13_32) ((_ sign_extend 1) (_ bv2 32))) ((_ sign_extend 1) (bvadd in.13_32 (_ bv2 32)))) true)))
(let (($x295 (or false false (or $x55))))
(and (not $x295) (or $x295 (and (distinct (bvadd in.13_32 (_ bv2 32)) (bvadd in.13_32 (_ bv2 32))) true))))))
(check-sat)
; query 4: function BF_set_key, block 87, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.24_32 () (_ BitVec 32))
(assert
 (let (($x920 (and (distinct (bvadd ((_ sign_extend 1) in.24_32) ((_ sign_extend 1) (_ bv2 32))) ((_ sign_extend 1) (bvadd in.24_32 (_ bv2 32)))) true)))
(let (($x85 (or false false (or $x920))))
(and (not $x85) (or $x85 (and (distinct (bvadd in.24_32 (_ bv2 32)) (bvadd in.24_32 (_ bv2 32))) true))))))
(check-sat)
; query 5: function main, block 60, name %61
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x18 (or false false)))
(and (not $x18) (or $x18 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 6: function main, block 60, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x411 (ite (bvsge (_ bv57 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x18 (or false false)))
(let (($x927 (or $x18 false false)))
(let (($x481 (not $x927)))
(and $x481 (or $x927 (and (distinct ?x411 ?x411) true))))))))
(check-sat)
; query 7: function main, block 63, name %64
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x12 (or (or false false false) (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x12) (or $x12 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvshl in.01_32 (_ bv4 32))) true)))))
(check-sat)
; query 8: function main, block 63, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x18 (or false false)))
(and (not $x18) (or $x18 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 9: function main, block 63, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x124 ((_ sign_extend 24) in57_8)))
(let ((?x281 (bvshl in.01_32 (_ bv4 32))))
(let ((?x28 (bvadd ?x281 ?x124)))
(let ((?x44 ((_ sign_extend 1) ?x28)))
(let (($x18 (or false false)))
(let (($x12 (or (or false false false) (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x59 (or $x12 $x18 (or (and (distinct (bvadd ((_ sign_extend 1) ?x281) ((_ sign_extend 1) ?x124)) ?x44) true)))))
(and (not $x59) (or $x59 (and (distinct ?x28 ?x28) true)))))))))))
(check-sat)
; query 10: function main, block 63, name %67
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x124 ((_ sign_extend 24) in57_8)))
(let ((?x281 (bvshl in.01_32 (_ bv4 32))))
(let ((?x28 (bvadd ?x281 ?x124)))
(let ((?x87 (bvsub ?x28 (_ bv48 32))))
(let (($x17 (and (distinct (bvsub ((_ sign_extend 1) ?x28) ((_ sign_extend 1) (_ bv48 32))) ((_ sign_extend 1) ?x87)) true)))
(let ((?x44 ((_ sign_extend 1) ?x28)))
(let (($x18 (or false false)))
(let (($x12 (or (or false false false) (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x59 (or $x12 $x18 (or (and (distinct (bvadd ((_ sign_extend 1) ?x281) ((_ sign_extend 1) ?x124)) ?x44) true)))))
(let (($x123 (or $x59 false (or $x17))))
(and (not $x123) (or $x123 (and (distinct ?x87 ?x87) true))))))))))))))
(check-sat)
; query 11: function main, block 68, name %69
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x18 (or false false)))
(and (not $x18) (or $x18 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 12: function main, block 68, name %70
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x514 (ite (bvsle (_ bv65 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x18 (or false false)))
(let (($x927 (or $x18 false false)))
(let (($x481 (not $x927)))
(and $x481 (or $x927 (and (distinct ?x514 ?x514) true))))))))
(check-sat)
; query 13: function main, block 71, name %72
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x18 (or false false)))
(and (not $x18) (or $x18 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 14: function main, block 71, name %73
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x460 (ite (bvsge (_ bv70 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x18 (or false false)))
(let (($x927 (or $x18 false false)))
(let (($x481 (not $x927)))
(and $x481 (or $x927 (and (distinct ?x460 ?x460) true))))))))
(check-sat)
; query 15: function main, block 74, name %75
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x12 (or (or false false false) (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x12) (or $x12 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvshl in.01_32 (_ bv4 32))) true)))))
(check-sat)
; query 16: function main, block 74, name %76
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x18 (or false false)))
(and (not $x18) (or $x18 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 17: function main, block 74, name %77
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x124 ((_ sign_extend 24) in57_8)))
(let ((?x281 (bvshl in.01_32 (_ bv4 32))))
(let ((?x28 (bvadd ?x281 ?x124)))
(let ((?x44 ((_ sign_extend 1) ?x28)))
(let (($x18 (or false false)))
(let (($x12 (or (or false false false) (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x59 (or $x12 $x18 (or (and (distinct (bvadd ((_ sign_extend 1) ?x281) ((_ sign_extend 1) ?x124)) ?x44) true)))))
(and (not $x59) (or $x59 (and (distinct ?x28 ?x28) true)))))))))))
(check-sat)
