; OptiPhase-Sigma refinement certificate for sweep K54-R3-159
; query 0: function check, block 103, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x59 (ite (= (_ bv22 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x426 (or false false false)))
(let (($x476 (not $x426)))
(and $x476 (or $x426 (and (distinct ?x59 (ite (= (_ bv0 32) in0_32) (_ bv1 1) (_ bv0 1))) true)))))))
(check-sat)
; query 1: function check, block 109, name %110
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x20 (ite (= (_ bv33 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x426 (or false false false)))
(let (($x476 (not $x426)))
(and $x476 (or $x426 (and (distinct ?x20 (ite (= (_ bv12 32) in0_32) (_ bv1 1) (_ bv0 1))) true)))))))
(check-sat)
; query 2: function check, block 67, name %68
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x376 (ite (= (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x426 (or false false false)))
(let (($x476 (not $x426)))
(and $x476 (or $x426 (and (distinct (ite (= (_ bv1 32) in0_32) (_ bv1 1) (_ bv0 1)) ?x376) true)))))))
(check-sat)
; query 3: function check, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x33 (ite (= (_ bv4 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x426 (or false false false)))
(let (($x476 (not $x426)))
(and $x476 (or $x426 (and (distinct (ite (= (_ bv2 32) in0_32) (_ bv1 1) (_ bv0 1)) ?x33) true)))))))
(check-sat)
; query 4: function check, block 79, name %80
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x86 (ite (= (_ bv5 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let ((?x376 (ite (= (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x426 (or false false false)))
(let (($x476 (not $x426)))
(and $x476 (or $x426 (and (distinct ?x376 ?x86) true))))))))
(check-sat)
; query 5: function check, block 85, name %86
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x562 (ite (= (_ bv11 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let ((?x33 (ite (= (_ bv4 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x426 (or false false false)))
(let (($x476 (not $x426)))
(and $x476 (or $x426 (and (distinct ?x33 ?x562) true))))))))
(check-sat)
; query 6: function check, block 91, name %92
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x59 (ite (= (_ bv22 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let ((?x86 (ite (= (_ bv5 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x426 (or false false false)))
(let (($x476 (not $x426)))
(and $x476 (or $x426 (and (distinct ?x86 ?x59) true))))))))
(check-sat)
; query 7: function check, block 97, name %98
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x20 (ite (= (_ bv33 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let ((?x562 (ite (= (_ bv11 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x426 (or false false false)))
(let (($x476 (not $x426)))
(and $x476 (or $x426 (and (distinct ?x562 ?x20) true))))))))
(check-sat)
; query 8: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x758 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x426 (or false false false)))
(let (($x476 (not $x426)))
(and $x476 (or $x426 (and (distinct ?x758 ?x758) true)))))))
(check-sat)
; query 9: function set1d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x622 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x426 (or false false false)))
(let (($x476 (not $x426)))
(and $x476 (or $x426 (and (distinct ?x622 ?x622) true)))))))
(check-sat)
; query 10: function set1ds, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x2781 (ite (= (_ bv4294967295 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x426 (or false false false)))
(let (($x476 (not $x426)))
(and $x476 (or $x426 (and (distinct ?x2781 ?x2781) true)))))))
(check-sat)
; query 11: function set2d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x622 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x426 (or false false false)))
(let (($x476 (not $x426)))
(and $x476 (or $x426 (and (distinct ?x622 ?x622) true)))))))
(check-sat)
