; OptiPhase-Sigma refinement certificate for sweep K43-R2-072
; query 0: function crc32buf, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_64 () (_ BitVec 64))
(assert
 (let (($x7 (or false false false)))
(let (($x1278 (not $x7)))
(and $x1278 (or $x7 (and (distinct (bvxor in.02_64 (_ bv18446744073709551615 64)) (bvxor in.02_64 (_ bv18446744073709551615 64))) true))))))
(check-sat)
; query 1: function main, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x84 (ite (and (distinct (_ bv0 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x7 (or false false false)))
(let (($x1278 (not $x7)))
(and $x1278 (or $x7 (and (distinct ?x84 ?x84) true)))))))
(check-sat)
; query 2: function main, block 17, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x84 (ite (and (distinct (_ bv0 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let ((?x310 ((_ zero_extend 31) ?x84)))
(let (($x7 (or false false false)))
(let (($x308 (or $x7 false)))
(and (not $x308) (or $x308 (and (distinct ?x310 ?x310) true))))))))
(check-sat)
