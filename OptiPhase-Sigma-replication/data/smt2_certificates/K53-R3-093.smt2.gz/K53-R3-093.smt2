; OptiPhase-Sigma refinement certificate for sweep K53-R3-093
; query 0: function check, block 103, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x461 (ite (= (_ bv22 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x1346 (or false false false)))
(let (($x89 (not $x1346)))
(and $x89 (or $x1346 (and (distinct ?x461 ?x461) true)))))))
(check-sat)
; query 1: function check, block 109, name %110
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x413 (ite (= (_ bv33 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x1346 (or false false false)))
(let (($x89 (not $x1346)))
(and $x89 (or $x1346 (and (distinct ?x413 ?x413) true)))))))
(check-sat)
; query 2: function check, block 115, name %116
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x93 (ite (= (_ bv0 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x1346 (or false false false)))
(let (($x89 (not $x1346)))
(and $x89 (or $x1346 (and (distinct ?x93 ?x93) true)))))))
(check-sat)
; query 3: function check, block 121, name %122
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x268 (ite (= (_ bv12 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x1346 (or false false false)))
(let (($x89 (not $x1346)))
(and $x89 (or $x1346 (and (distinct ?x268 ?x268) true)))))))
(check-sat)
; query 4: function check, block 128, name %129
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x40 (ite (= (_ bv25 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x1346 (or false false false)))
(let (($x89 (not $x1346)))
(and $x89 (or $x1346 (and (distinct ?x40 ?x40) true)))))))
(check-sat)
; query 5: function check, block 135, name %136
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x1343 (ite (= (_ bv13 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x1346 (or false false false)))
(let (($x89 (not $x1346)))
(and $x89 (or $x1346 (and (distinct ?x1343 ?x1343) true)))))))
(check-sat)
; query 6: function check, block 142, name %143
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x63 (ite (= (_ bv123 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x1346 (or false false false)))
(let (($x89 (not $x1346)))
(and $x89 (or $x1346 (and (distinct ?x63 ?x63) true)))))))
(check-sat)
; query 7: function check, block 150, name %151
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x27 (ite (= (_ bv1122 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x1346 (or false false false)))
(let (($x89 (not $x1346)))
(and $x89 (or $x1346 (and (distinct ?x27 ?x27) true)))))))
(check-sat)
; query 8: function check, block 157, name %158
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x298 (ite (= (_ bv112233 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x1346 (or false false false)))
(let (($x89 (not $x1346)))
(and $x89 (or $x1346 (and (distinct ?x298 ?x298) true)))))))
(check-sat)
; query 9: function check, block 165, name %166
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x87 (ite (= (_ bv111 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x1346 (or false false false)))
(let (($x89 (not $x1346)))
(and $x89 (or $x1346 (and (distinct ?x87 ?x87) true)))))))
(check-sat)
; query 10: function check, block 172, name %173
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x38 (ite (= (_ bv4294967295 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x1346 (or false false false)))
(let (($x89 (not $x1346)))
(and $x89 (or $x1346 (and (distinct ?x38 ?x38) true)))))))
(check-sat)
; query 11: function check, block 179, name %180
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x140 (ite (= (_ bv4294967284 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x1346 (or false false false)))
(let (($x89 (not $x1346)))
(and $x89 (or $x1346 (and (distinct ?x140 ?x140) true)))))))
(check-sat)
; query 12: function check, block 55, name %56
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.012_32 () (_ BitVec 32))
(assert
 (let (($x351 (and (distinct (bvadd ((_ zero_extend 1) in.012_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.012_32 (_ bv1 32)))) true)))
(let (($x144 (and (distinct (bvadd ((_ sign_extend 1) in.012_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.012_32 (_ bv1 32)))) true)))
(let (($x114 (or (or false false (or $x144 $x351)) (and (distinct (bvadd in.012_32 (_ bv1 32)) (bvadd in.012_32 (_ bv1 32))) true))))
(and (not (or false false (or $x144))) $x114)))))
(check-sat)
; query 13: function check, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x108 (ite (= (_ bv2 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x1346 (or false false false)))
(let (($x89 (not $x1346)))
(and $x89 (or $x1346 (and (distinct ?x108 ?x108) true)))))))
(check-sat)
; query 14: function check, block 79, name %80
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x67 (ite (= (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x1346 (or false false false)))
(let (($x89 (not $x1346)))
(and $x89 (or $x1346 (and (distinct ?x67 ?x67) true)))))))
(check-sat)
; query 15: function check, block 85, name %86
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x128 (ite (= (_ bv4 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x1346 (or false false false)))
(let (($x89 (not $x1346)))
(and $x89 (or $x1346 (and (distinct ?x128 ?x128) true)))))))
(check-sat)
; query 16: function check, block 91, name %92
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x400 (ite (= (_ bv5 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x1346 (or false false false)))
(let (($x89 (not $x1346)))
(and $x89 (or $x1346 (and (distinct ?x400 ?x400) true)))))))
(check-sat)
; query 17: function check, block 97, name %98
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x77 (ite (= (_ bv11 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x1346 (or false false false)))
(let (($x89 (not $x1346)))
(and $x89 (or $x1346 (and (distinct ?x77 ?x77) true)))))))
(check-sat)
; query 18: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x80 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x1346 (or false false false)))
(let (($x89 (not $x1346)))
(and $x89 (or $x1346 (and (distinct ?x80 ?x80) true)))))))
(check-sat)
; query 19: function s13110, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x14 (and (distinct (bvadd ((_ zero_extend 1) in.0_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x232 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x207 (or (or false false (or $x232 $x14)) (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))
(and (not (or false false (or $x232))) $x207)))))
(check-sat)
; query 20: function s13110, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x507 (and (distinct (bvadd ((_ zero_extend 1) in.01_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x74 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x575 (or (or false false (or $x74 $x507)) (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))
(and (not (or false false (or $x74))) $x575)))))
(check-sat)
; query 21: function s311, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x507 (and (distinct (bvadd ((_ zero_extend 1) in.01_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x74 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x575 (or (or false false (or $x74 $x507)) (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))
(and (not (or false false (or $x74))) $x575)))))
(check-sat)
; query 22: function s3110, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x14 (and (distinct (bvadd ((_ zero_extend 1) in.0_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x232 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x207 (or (or false false (or $x232 $x14)) (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))
(and (not (or false false (or $x232))) $x207)))))
(check-sat)
; query 23: function s3110, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x507 (and (distinct (bvadd ((_ zero_extend 1) in.01_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x74 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x575 (or (or false false (or $x74 $x507)) (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))
(and (not (or false false (or $x74))) $x575)))))
(check-sat)
; query 24: function s3110, block 39, name %40
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x309 (and (distinct (bvadd ((_ zero_extend 1) in.02_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x152 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x432 (or (or false false (or $x152 $x309)) (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))
(and (not (or false false (or $x152))) $x432)))))
(check-sat)
; query 25: function s3111, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x14 (and (distinct (bvadd ((_ zero_extend 1) in.0_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x232 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x207 (or (or false false (or $x232 $x14)) (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))
(and (not (or false false (or $x232))) $x207)))))
(check-sat)
; query 26: function s3111, block 24, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x507 (and (distinct (bvadd ((_ zero_extend 1) in.01_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x74 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x575 (or (or false false (or $x74 $x507)) (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))
(and (not (or false false (or $x74))) $x575)))))
(check-sat)
; query 27: function s31111, block 24, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x14 (and (distinct (bvadd ((_ zero_extend 1) in.0_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x232 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x207 (or (or false false (or $x232 $x14)) (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))
(and (not (or false false (or $x232))) $x207)))))
(check-sat)
; query 28: function s3112, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x14 (and (distinct (bvadd ((_ zero_extend 1) in.0_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x232 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x207 (or (or false false (or $x232 $x14)) (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))
(and (not (or false false (or $x232))) $x207)))))
(check-sat)
; query 29: function s3112, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x507 (and (distinct (bvadd ((_ zero_extend 1) in.01_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x74 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x575 (or (or false false (or $x74 $x507)) (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))
(and (not (or false false (or $x74))) $x575)))))
(check-sat)
; query 30: function s312, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x507 (and (distinct (bvadd ((_ zero_extend 1) in.01_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x74 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x575 (or (or false false (or $x74 $x507)) (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))
(and (not (or false false (or $x74))) $x575)))))
(check-sat)
; query 31: function s313, block 21, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x507 (and (distinct (bvadd ((_ zero_extend 1) in.01_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x74 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x575 (or (or false false (or $x74 $x507)) (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))
(and (not (or false false (or $x74))) $x575)))))
(check-sat)
; query 32: function s314, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x14 (and (distinct (bvadd ((_ zero_extend 1) in.0_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x232 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x207 (or (or false false (or $x232 $x14)) (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))
(and (not (or false false (or $x232))) $x207)))))
(check-sat)
; query 33: function s314, block 24, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x507 (and (distinct (bvadd ((_ zero_extend 1) in.01_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x74 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x575 (or (or false false (or $x74 $x507)) (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))
(and (not (or false false (or $x74))) $x575)))))
(check-sat)
; query 34: function s315, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_32 () (_ BitVec 32))
(assert
 (let (($x395 (and (distinct (bvadd ((_ zero_extend 1) in.06_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.06_32 (_ bv1 32)))) true)))
(let (($x1312 (and (distinct (bvadd ((_ sign_extend 1) in.06_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.06_32 (_ bv1 32)))) true)))
(let (($x54 (or (or false false (or $x1312 $x395)) (and (distinct (bvadd in.06_32 (_ bv1 32)) (bvadd in.06_32 (_ bv1 32))) true))))
(and (not (or false false (or $x1312))) $x54)))))
(check-sat)
; query 35: function s315, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x14 (and (distinct (bvadd ((_ zero_extend 1) in.0_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x232 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x207 (or (or false false (or $x232 $x14)) (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))
(and (not (or false false (or $x232))) $x207)))))
(check-sat)
; query 36: function s315, block 36, name %37
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x507 (and (distinct (bvadd ((_ zero_extend 1) in.01_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x74 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x575 (or (or false false (or $x74 $x507)) (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))
(and (not (or false false (or $x74))) $x575)))))
(check-sat)
; query 37: function s316, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x14 (and (distinct (bvadd ((_ zero_extend 1) in.0_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x232 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x207 (or (or false false (or $x232 $x14)) (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))
(and (not (or false false (or $x232))) $x207)))))
(check-sat)
; query 38: function s316, block 24, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x507 (and (distinct (bvadd ((_ zero_extend 1) in.01_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x74 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x575 (or (or false false (or $x74 $x507)) (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))
(and (not (or false false (or $x74))) $x575)))))
(check-sat)
; query 39: function s317, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x507 (and (distinct (bvadd ((_ zero_extend 1) in.01_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x74 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x575 (or (or false false (or $x74 $x507)) (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))
(and (not (or false false (or $x74))) $x575)))))
(check-sat)
; query 40: function s319, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x507 (and (distinct (bvadd ((_ zero_extend 1) in.01_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x74 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x575 (or (or false false (or $x74 $x507)) (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))
(and (not (or false false (or $x74))) $x575)))))
(check-sat)
; query 41: function set1d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x175 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x1346 (or false false false)))
(let (($x89 (not $x1346)))
(and $x89 (or $x1346 (and (distinct ?x175 ?x175) true)))))))
(check-sat)
; query 42: function set1ds, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x9 (ite (= (_ bv4294967295 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x1346 (or false false false)))
(let (($x89 (not $x1346)))
(and $x89 (or $x1346 (and (distinct ?x9 ?x9) true)))))))
(check-sat)
; query 43: function set2d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x175 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x1346 (or false false false)))
(let (($x89 (not $x1346)))
(and $x89 (or $x1346 (and (distinct ?x175 ?x175) true)))))))
(check-sat)
