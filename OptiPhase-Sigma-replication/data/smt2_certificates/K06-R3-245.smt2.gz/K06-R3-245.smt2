; OptiPhase-Sigma refinement certificate for sweep K06-R3-245
; query 0: function init_array, block 34, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x11 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x95 (or false false (or $x11))))
(and (not $x95) (or $x95 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function init_array, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x15 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x21 (or false false (or $x15))))
(and (not $x21) (or $x21 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function init_array, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x30 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x74 (or false false (or $x30))))
(and (not $x74) (or $x74 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 3: function init_array, block 59, name %60
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x58 (and (distinct (bvadd ((_ sign_extend 1) in.12_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.12_32 (_ bv1 32)))) true)))
(let (($x289 (or false false (or $x58))))
(and (not $x289) (or $x289 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 4: function kernel_syr2k, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x15 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x21 (or false false (or $x15))))
(and (not $x21) (or $x21 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 5: function kernel_syr2k, block 59, name %60
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x30 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x74 (or false false (or $x30))))
(and (not $x74) (or $x74 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 6: function kernel_syr2k, block 62, name %63
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x11 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x95 (or false false (or $x11))))
(and (not $x95) (or $x95 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 7: function kernel_syr2k, block 65, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x19 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x57 (or false false (or $x19))))
(and (not $x57) (or $x57 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function print_array, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x11 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x95 (or false false (or $x11))))
(and (not $x95) (or $x95 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 9: function print_array, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x15 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x21 (or false false (or $x15))))
(and (not $x21) (or $x21 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
