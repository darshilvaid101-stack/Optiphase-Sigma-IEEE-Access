; OptiPhase-Sigma refinement certificate for sweep K56-R2-027
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x111 (or false false)))
(let (($x1915 (not $x111)))
(and $x1915 (or $x111 (and (distinct ((_ sign_extend 16) in25_16) ((_ sign_extend 16) in25_16)) true))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let ((?x516 (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))))
(let (($x111 (or false false)))
(let (($x1928 (or $x111 false false)))
(let (($x94 (not $x1928)))
(and $x94 (or $x1928 (and (distinct ?x516 ?x516) true))))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x111 (or false false)))
(let (($x1915 (not $x111)))
(and $x1915 (or $x111 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x1844 ((_ sign_extend 16) in3_16)))
(let ((?x2031 (bvand ?x1844 (_ bv127 32))))
(let (($x111 (or false false)))
(let (($x1928 (or $x111 false false)))
(let (($x94 (not $x1928)))
(and $x94 (or $x1928 (and (distinct ?x2031 ?x2031) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x1844 ((_ sign_extend 16) in3_16)))
(let ((?x2031 (bvand ?x1844 (_ bv127 32))))
(let ((?x10 ((_ extract 15 0) ?x2031)))
(let (($x111 (or false false)))
(let (($x1928 (or $x111 false false)))
(let (($x77 (or $x1928 false)))
(let (($x134 (not $x77)))
(and $x134 (or $x77 (and (distinct ?x10 ?x10) true)))))))))))
(check-sat)
; query 5: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x111 (or false false)))
(let (($x1915 (not $x111)))
(and $x1915 (or $x111 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 6: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x170 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x111 (or false false)))
(let (($x1928 (or $x111 false false)))
(let (($x94 (not $x1928)))
(and $x94 (or $x1928 (and (distinct ?x170 ?x170) true))))))))
(check-sat)
; query 7: function core_bench_list, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x87 (or false false false)))
(let (($x53 (not $x87)))
(and $x53 (or $x87 (and (distinct (bvadd in.0_16 (_ bv1 16)) (bvadd in.0_16 (_ bv1 16))) true))))))
(check-sat)
; query 8: function core_bench_state, block 105, name %106
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x87 (or false false false)))
(let (($x53 (not $x87)))
(and $x53 (or $x87 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 9: function core_bench_state, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x87 (or false false false)))
(let (($x53 (not $x87)))
(and $x53 (or $x87 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 10: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x254 (bvadd in.01_32 (_ bv1 32))))
(let (($x292 (and (distinct ?x254 ?x254) true)))
(let (($x87 (or false false false)))
(let (($x53 (not $x87)))
(and $x53 (or $x87 $x292)))))))
(check-sat)
; query 11: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x254 (bvadd in.01_32 (_ bv1 32))))
(let ((?x29 (bvmul ?x254 ?x254)))
(let (($x87 (or false false false)))
(let (($x329 (or $x87 $x87 false)))
(and (not $x329) (or $x329 (and (distinct ?x29 ?x29) true))))))))
(check-sat)
; query 12: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x254 (bvadd in.01_32 (_ bv1 32))))
(let ((?x29 (bvmul ?x254 ?x254)))
(let ((?x125 (bvmul ?x29 (_ bv2 32))))
(let (($x87 (or false false false)))
(let (($x329 (or $x87 $x87 false)))
(let (($x232 (or $x329 false false)))
(and (not $x232) (or $x232 (and (distinct ?x125 ?x125) true))))))))))
(check-sat)
; query 13: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x254 (bvadd in.01_32 (_ bv1 32))))
(let ((?x29 (bvmul ?x254 ?x254)))
(let ((?x125 (bvmul ?x29 (_ bv2 32))))
(let ((?x884 (bvmul ?x125 (_ bv4 32))))
(let (($x87 (or false false false)))
(let (($x329 (or $x87 $x87 false)))
(let (($x232 (or $x329 false false)))
(let (($x1946 (or $x232 false false)))
(and (not $x1946) (or $x1946 (and (distinct ?x884 ?x884) true))))))))))))
(check-sat)
; query 14: function core_init_matrix, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x87 (or false false false)))
(let (($x53 (not $x87)))
(and $x53 (or $x87 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 15: function core_init_matrix, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x87 (or false false false)))
(let (($x53 (not $x87)))
(and $x53 (or $x87 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 16: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x450 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x87 (or false false false)))
(let (($x53 (not $x87)))
(and $x53 (or $x87 (and (distinct ?x450 ?x450) true)))))))
(check-sat)
; query 17: function core_init_state, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_32 () (_ BitVec 32))
(assert
 (let (($x87 (or false false false)))
(let (($x53 (not $x87)))
(and $x53 (or $x87 (and (distinct (bvadd in.06_32 (_ bv1 32)) (bvadd in.06_32 (_ bv1 32))) true))))))
(check-sat)
; query 18: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x263 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x87 (or false false false)))
(let (($x53 (not $x87)))
(and $x53 (or $x87 (and (distinct ?x263 ?x263) true)))))))
(check-sat)
; query 19: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x87 (or false false false)))
(let (($x53 (not $x87)))
(and $x53 (or $x87 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 20: function core_list_init, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x254 (bvadd in.01_32 (_ bv1 32))))
(let (($x292 (and (distinct ?x254 ?x254) true)))
(let (($x87 (or false false false)))
(let (($x53 (not $x87)))
(and $x53 (or $x87 $x292)))))))
(check-sat)
; query 21: function core_list_mergesort, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x254 (bvadd in.01_32 (_ bv1 32))))
(let (($x292 (and (distinct ?x254 ?x254) true)))
(let (($x612 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x254)) true)))
(let (($x214 (or false false (or $x612))))
(and (not $x214) (or $x214 $x292)))))))
(check-sat)
; query 22: function core_list_mergesort, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x1852 (ite (bvslt (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x87 (or false false false)))
(let (($x53 (not $x87)))
(and $x53 (or $x87 (and (distinct ?x1852 ?x1852) true)))))))
(check-sat)
; query 23: function core_list_mergesort, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.224_32 () (_ BitVec 32))
(assert
 (let ((?x107 (ite (= (_ bv0 32) in.224_32) (_ bv1 1) (_ bv0 1))))
(let (($x87 (or false false false)))
(let (($x53 (not $x87)))
(and $x53 (or $x87 (and (distinct ?x107 ?x107) true)))))))
(check-sat)
; query 24: function core_list_mergesort, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x28 (ite (= (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x87 (or false false false)))
(let (($x53 (not $x87)))
(and $x53 (or $x87 (and (distinct ?x28 ?x28) true)))))))
(check-sat)
; query 25: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x250 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x326 (or false false (or $x250))))
(and (not $x326) (or $x326 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 26: function core_list_mergesort, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x228 (and (distinct (bvmul ((_ sign_extend 32) in.020_32) ((_ sign_extend 32) (_ bv2 32))) ((_ sign_extend 32) (bvmul in.020_32 (_ bv2 32)))) true)))
(let (($x364 (or false false (or $x228))))
(and (not $x364) (or $x364 (and (distinct (bvmul in.020_32 (_ bv2 32)) (bvmul in.020_32 (_ bv2 32))) true))))))
(check-sat)
; query 27: function core_state_transition, block 102, name %103
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x111 (or false false)))
(let (($x1915 (not $x111)))
(and $x1915 (or $x111 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 28: function core_state_transition, block 102, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x72 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x111 (or false false)))
(let (($x1928 (or $x111 false false)))
(let (($x94 (not $x1928)))
(and $x94 (or $x1928 (and (distinct ?x72 ?x72) true))))))))
(check-sat)
; query 29: function core_state_transition, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x111 (or false false)))
(let (($x1915 (not $x111)))
(and $x1915 (or $x111 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 30: function core_state_transition, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x154 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x111 (or false false)))
(let (($x1928 (or $x111 false false)))
(let (($x94 (not $x1928)))
(and $x94 (or $x1928 (and (distinct ?x154 ?x154) true))))))))
(check-sat)
; query 31: function core_state_transition, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x111 (or false false)))
(let (($x1915 (not $x111)))
(and $x1915 (or $x111 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 32: function core_state_transition, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x72 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x111 (or false false)))
(let (($x1928 (or $x111 false false)))
(let (($x94 (not $x1928)))
(and $x94 (or $x1928 (and (distinct ?x72 ?x72) true))))))))
(check-sat)
; query 33: function core_state_transition, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x111 (or false false)))
(let (($x1915 (not $x111)))
(and $x1915 (or $x111 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 34: function core_state_transition, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x388 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x111 (or false false)))
(let (($x1928 (or $x111 false false)))
(let (($x94 (not $x1928)))
(and $x94 (or $x1928 (and (distinct ?x388 ?x388) true))))))))
(check-sat)
; query 35: function core_state_transition, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x111 (or false false)))
(let (($x1915 (not $x111)))
(and $x1915 (or $x111 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 36: function core_state_transition, block 51, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x388 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x111 (or false false)))
(let (($x1928 (or $x111 false false)))
(let (($x94 (not $x1928)))
(and $x94 (or $x1928 (and (distinct ?x388 ?x388) true))))))))
(check-sat)
; query 37: function core_state_transition, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x111 (or false false)))
(let (($x1915 (not $x111)))
(and $x1915 (or $x111 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 38: function core_state_transition, block 64, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x388 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x111 (or false false)))
(let (($x1928 (or $x111 false false)))
(let (($x94 (not $x1928)))
(and $x94 (or $x1928 (and (distinct ?x388 ?x388) true))))))))
(check-sat)
; query 39: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x99 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x87 (or false false false)))
(let (($x53 (not $x87)))
(and $x53 (or $x87 (and (distinct ?x99 ?x99) true)))))))
(check-sat)
; query 40: function core_state_transition, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x111 (or false false)))
(let (($x1915 (not $x111)))
(and $x1915 (or $x111 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 41: function core_state_transition, block 80, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x302 (ite (= (_ bv69 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x111 (or false false)))
(let (($x1928 (or $x111 false false)))
(let (($x94 (not $x1928)))
(and $x94 (or $x1928 (and (distinct ?x302 ?x302) true))))))))
(check-sat)
; query 42: function core_state_transition, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x111 (or false false)))
(let (($x1915 (not $x111)))
(and $x1915 (or $x111 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 43: function core_state_transition, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x366 (ite (= (_ bv101 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x111 (or false false)))
(let (($x1928 (or $x111 false false)))
(let (($x94 (not $x1928)))
(and $x94 (or $x1928 (and (distinct ?x366 ?x366) true))))))))
(check-sat)
; query 44: function core_state_transition, block 99, name %100
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x111 (or false false)))
(let (($x1915 (not $x111)))
(and $x1915 (or $x111 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 45: function core_state_transition, block 99, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x154 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x111 (or false false)))
(let (($x1928 (or $x111 false false)))
(let (($x94 (not $x1928)))
(and $x94 (or $x1928 (and (distinct ?x154 ?x154) true))))))))
(check-sat)
; query 46: function crcu8, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x111 (or false false)))
(let (($x1915 (not $x111)))
(and $x1915 (or $x111 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 47: function crcu8, block 19, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x365 ((_ zero_extend 16) in.01_16)))
(let ((?x231 (bvxor ?x365 (_ bv16386 32))))
(let (($x111 (or false false)))
(let (($x1928 (or $x111 false false)))
(let (($x94 (not $x1928)))
(and $x94 (or $x1928 (and (distinct ?x231 ?x231) true)))))))))
(check-sat)
; query 48: function crcu8, block 19, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x365 ((_ zero_extend 16) in.01_16)))
(let ((?x231 (bvxor ?x365 (_ bv16386 32))))
(let ((?x166 ((_ extract 15 0) ?x231)))
(let (($x111 (or false false)))
(let (($x1928 (or $x111 false false)))
(let (($x77 (or $x1928 false)))
(let (($x134 (not $x77)))
(and $x134 (or $x77 (and (distinct ?x166 ?x166) true)))))))))))
(check-sat)
; query 49: function crcu8, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x111 (or false false)))
(let (($x1915 (not $x111)))
(and $x1915 (or $x111 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 50: function crcu8, block 29, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x52 ((_ zero_extend 16) in27_16)))
(let ((?x345 (bvor ?x52 (_ bv32768 32))))
(let (($x111 (or false false)))
(let (($x1928 (or $x111 false false)))
(let (($x94 (not $x1928)))
(and $x94 (or $x1928 (and (distinct ?x345 ?x345) true)))))))))
(check-sat)
; query 51: function crcu8, block 29, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x52 ((_ zero_extend 16) in27_16)))
(let ((?x345 (bvor ?x52 (_ bv32768 32))))
(let ((?x686 ((_ extract 15 0) ?x345)))
(let (($x111 (or false false)))
(let (($x1928 (or $x111 false false)))
(let (($x77 (or $x1928 false)))
(let (($x134 (not $x77)))
(and $x134 (or $x77 (and (distinct ?x686 ?x686) true)))))))))))
(check-sat)
; query 52: function crcu8, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x111 (or false false)))
(let (($x1915 (not $x111)))
(and $x1915 (or $x111 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 53: function crcu8, block 33, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x52 ((_ zero_extend 16) in27_16)))
(let ((?x303 (bvand ?x52 (_ bv32767 32))))
(let (($x111 (or false false)))
(let (($x1928 (or $x111 false false)))
(let (($x94 (not $x1928)))
(and $x94 (or $x1928 (and (distinct ?x303 ?x303) true)))))))))
(check-sat)
; query 54: function crcu8, block 33, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x52 ((_ zero_extend 16) in27_16)))
(let ((?x303 (bvand ?x52 (_ bv32767 32))))
(let ((?x188 ((_ extract 15 0) ?x303)))
(let (($x111 (or false false)))
(let (($x1928 (or $x111 false false)))
(let (($x77 (or $x1928 false)))
(let (($x134 (not $x77)))
(and $x134 (or $x77 (and (distinct ?x188 ?x188) true)))))))))))
(check-sat)
; query 55: function crcu8, block 38, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_8 () (_ BitVec 8))
(assert
 (let (($x87 (or false false false)))
(let (($x53 (not $x87)))
(and $x53 (or $x87 (and (distinct (bvadd in.02_8 (_ bv1 8)) (bvadd in.02_8 (_ bv1 8))) true))))))
(check-sat)
; query 56: function crcu8, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x382 ((_ extract 7 0) in.01_16)))
(let ((?x331 ((_ zero_extend 24) ?x382)))
(let (($x111 (or false false)))
(let (($x392 (or $x111 false)))
(and (not $x392) (or $x392 (and (distinct ?x331 ?x331) true))))))))
(check-sat)
; query 57: function crcu8, block 6, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x382 ((_ extract 7 0) in.01_16)))
(let ((?x331 ((_ zero_extend 24) ?x382)))
(let ((?x60 (bvand ?x331 (_ bv1 32))))
(let (($x111 (or false false)))
(let (($x392 (or $x111 false)))
(let (($x289 (or $x392 false false)))
(and (not $x289) (or $x289 (and (distinct ?x60 ?x60) true))))))))))
(check-sat)
; query 58: function crcu8, block 6, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x382 ((_ extract 7 0) in.01_16)))
(let ((?x331 ((_ zero_extend 24) ?x382)))
(let ((?x60 (bvand ?x331 (_ bv1 32))))
(let ((?x32 ((_ zero_extend 24) in.0_8)))
(let ((?x58 (bvand ?x32 (_ bv1 32))))
(let ((?x264 (bvxor ?x58 ?x60)))
(let (($x111 (or false false)))
(let (($x392 (or $x111 false)))
(let (($x289 (or $x392 false false)))
(let (($x1928 (or $x111 false false)))
(let (($x717 (or $x1928 $x289 false)))
(and (not $x717) (or $x717 (and (distinct ?x264 ?x264) true)))))))))))))))
(check-sat)
; query 59: function crcu8, block 6, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x382 ((_ extract 7 0) in.01_16)))
(let ((?x331 ((_ zero_extend 24) ?x382)))
(let ((?x60 (bvand ?x331 (_ bv1 32))))
(let ((?x32 ((_ zero_extend 24) in.0_8)))
(let ((?x58 (bvand ?x32 (_ bv1 32))))
(let ((?x264 (bvxor ?x58 ?x60)))
(let ((?x122 ((_ extract 7 0) ?x264)))
(let (($x111 (or false false)))
(let (($x392 (or $x111 false)))
(let (($x289 (or $x392 false false)))
(let (($x1928 (or $x111 false false)))
(let (($x717 (or $x1928 $x289 false)))
(let (($x346 (or $x717 false)))
(and (not $x346) (or $x346 (and (distinct ?x122 ?x122) true)))))))))))))))))
(check-sat)
; query 60: function crcu8, block 6, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x111 (or false false)))
(let (($x1915 (not $x111)))
(and $x1915 (or $x111 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 61: function crcu8, block 6, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x32 ((_ zero_extend 24) in.0_8)))
(let ((?x618 (bvashr ?x32 (_ bv1 32))))
(let (($x111 (or false false)))
(let (($x1928 (or $x111 false false)))
(let (($x826 (or $x1928 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not $x826) (or $x826 (and (distinct ?x618 ?x618) true)))))))))
(check-sat)
; query 62: function crcu8, block 6, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x32 ((_ zero_extend 24) in.0_8)))
(let ((?x618 (bvashr ?x32 (_ bv1 32))))
(let ((?x103 ((_ extract 7 0) ?x618)))
(let (($x111 (or false false)))
(let (($x1928 (or $x111 false false)))
(let (($x826 (or $x1928 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x2062 (or $x826 false)))
(and (not $x2062) (or $x2062 (and (distinct ?x103 ?x103) true)))))))))))
(check-sat)
; query 63: function crcu8, block 6, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x382 ((_ extract 7 0) in.01_16)))
(let ((?x331 ((_ zero_extend 24) ?x382)))
(let ((?x60 (bvand ?x331 (_ bv1 32))))
(let ((?x32 ((_ zero_extend 24) in.0_8)))
(let ((?x58 (bvand ?x32 (_ bv1 32))))
(let ((?x264 (bvxor ?x58 ?x60)))
(let ((?x122 ((_ extract 7 0) ?x264)))
(let ((?x1821 ((_ zero_extend 24) ?x122)))
(let (($x111 (or false false)))
(let (($x392 (or $x111 false)))
(let (($x289 (or $x392 false false)))
(let (($x1928 (or $x111 false false)))
(let (($x717 (or $x1928 $x289 false)))
(let (($x346 (or $x717 false)))
(let (($x1902 (or $x346 false)))
(and (not $x1902) (or $x1902 (and (distinct ?x1821 ?x1821) true)))))))))))))))))))
(check-sat)
; query 64: function crcu8, block 6, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x382 ((_ extract 7 0) in.01_16)))
(let ((?x331 ((_ zero_extend 24) ?x382)))
(let ((?x60 (bvand ?x331 (_ bv1 32))))
(let ((?x32 ((_ zero_extend 24) in.0_8)))
(let ((?x58 (bvand ?x32 (_ bv1 32))))
(let ((?x264 (bvxor ?x58 ?x60)))
(let ((?x122 ((_ extract 7 0) ?x264)))
(let ((?x1821 ((_ zero_extend 24) ?x122)))
(let ((?x335 (ite (= (_ bv1 32) ?x1821) (_ bv1 1) (_ bv0 1))))
(let (($x111 (or false false)))
(let (($x392 (or $x111 false)))
(let (($x289 (or $x392 false false)))
(let (($x1928 (or $x111 false false)))
(let (($x717 (or $x1928 $x289 false)))
(let (($x346 (or $x717 false)))
(let (($x1902 (or $x346 false)))
(let (($x1917 (or $x1902 false false)))
(and (not $x1917) (or $x1917 (and (distinct ?x335 ?x335) true)))))))))))))))))))))
(check-sat)
; query 65: function crcu8, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x111 (or false false)))
(let (($x1915 (not $x111)))
(and $x1915 (or $x111 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 66: function crcu8, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x32 ((_ zero_extend 24) in.0_8)))
(let ((?x58 (bvand ?x32 (_ bv1 32))))
(let (($x111 (or false false)))
(let (($x1928 (or $x111 false false)))
(let (($x94 (not $x1928)))
(and $x94 (or $x1928 (and (distinct ?x58 ?x58) true)))))))))
(check-sat)
; query 67: function crcu8, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x111 (or false false)))
(let (($x1915 (not $x111)))
(and $x1915 (or $x111 (and (distinct ((_ extract 7 0) in.01_16) ((_ extract 7 0) in.01_16)) true))))))
(check-sat)
; query 68: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1012 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1962 ((_ zero_extend 31) ?x1012)))
(let ((?x476 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1057 ((_ zero_extend 31) ?x476)))
(let ((?x378 (bvand ?x1057 ?x1962)))
(let ((?x399 (ite (and (distinct (_ bv0 32) ?x378) true) (_ bv1 1) (_ bv0 1))))
(let ((?x2024 ((_ zero_extend 63) ?x399)))
(let (($x111 (or false false)))
(let (($x1928 (or $x111 false false)))
(let (($x77 (or $x1928 false)))
(let (($x1534 (or $x77 $x77 false)))
(let (($x192 (or $x1534 false false)))
(let (($x1889 (or $x192 false)))
(and (not $x1889) (or $x1889 (and (distinct ?x2024 ?x2024) true)))))))))))))))))
(check-sat)
; query 69: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1012 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1962 ((_ zero_extend 31) ?x1012)))
(let ((?x476 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1057 ((_ zero_extend 31) ?x476)))
(let ((?x378 (bvand ?x1057 ?x1962)))
(let ((?x399 (ite (and (distinct (_ bv0 32) ?x378) true) (_ bv1 1) (_ bv0 1))))
(let (($x1965 (= (_ bv1 1) ?x399)))
(let ((?x647 (ite $x1965 (_ bv1 32) (_ bv0 32))))
(let (($x111 (or false false)))
(let (($x1928 (or $x111 false false)))
(let (($x77 (or $x1928 false)))
(let (($x1534 (or $x77 $x77 false)))
(let (($x192 (or $x1534 false false)))
(let (($x1964 (or $x192 (ite $x1965 false false))))
(and (not $x1964) (or $x1964 (and (distinct ?x647 ?x647) true))))))))))))))))))
(check-sat)
; query 70: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1012 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1962 ((_ zero_extend 31) ?x1012)))
(let ((?x476 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1057 ((_ zero_extend 31) ?x476)))
(let ((?x378 (bvand ?x1057 ?x1962)))
(let ((?x399 (ite (and (distinct (_ bv0 32) ?x378) true) (_ bv1 1) (_ bv0 1))))
(let (($x1965 (= (_ bv1 1) ?x399)))
(let ((?x647 (ite $x1965 (_ bv1 32) (_ bv0 32))))
(let ((?x1885 ((_ extract 7 0) ?x647)))
(let (($x111 (or false false)))
(let (($x1928 (or $x111 false false)))
(let (($x77 (or $x1928 false)))
(let (($x1534 (or $x77 $x77 false)))
(let (($x192 (or $x1534 false false)))
(let (($x1964 (or $x192 (ite $x1965 false false))))
(let (($x1873 (or $x1964 false)))
(and (not $x1873) (or $x1873 (and (distinct ?x1885 ?x1885) true))))))))))))))))))))
(check-sat)
; query 71: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x111 (or false false)))
(let (($x1915 (not $x111)))
(and $x1915 (or $x111 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 72: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x476 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x111 (or false false)))
(let (($x1928 (or $x111 false false)))
(let (($x94 (not $x1928)))
(and $x94 (or $x1928 (and (distinct ?x476 ?x476) true))))))))
(check-sat)
; query 73: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x476 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1057 ((_ zero_extend 31) ?x476)))
(let (($x111 (or false false)))
(let (($x1928 (or $x111 false false)))
(let (($x77 (or $x1928 false)))
(let (($x134 (not $x77)))
(and $x134 (or $x77 (and (distinct ?x1057 ?x1057) true))))))))))
(check-sat)
; query 74: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x111 (or false false)))
(let (($x1915 (not $x111)))
(and $x1915 (or $x111 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 75: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1012 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x111 (or false false)))
(let (($x1928 (or $x111 false false)))
(let (($x94 (not $x1928)))
(and $x94 (or $x1928 (and (distinct ?x1012 ?x1012) true))))))))
(check-sat)
; query 76: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1012 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1962 ((_ zero_extend 31) ?x1012)))
(let (($x111 (or false false)))
(let (($x1928 (or $x111 false false)))
(let (($x77 (or $x1928 false)))
(let (($x134 (not $x77)))
(and $x134 (or $x77 (and (distinct ?x1962 ?x1962) true))))))))))
(check-sat)
; query 77: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1012 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1962 ((_ zero_extend 31) ?x1012)))
(let ((?x476 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1057 ((_ zero_extend 31) ?x476)))
(let ((?x378 (bvand ?x1057 ?x1962)))
(let (($x111 (or false false)))
(let (($x1928 (or $x111 false false)))
(let (($x77 (or $x1928 false)))
(let (($x1534 (or $x77 $x77 false)))
(and (not $x1534) (or $x1534 (and (distinct ?x378 ?x378) true)))))))))))))
(check-sat)
; query 78: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1012 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1962 ((_ zero_extend 31) ?x1012)))
(let ((?x476 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1057 ((_ zero_extend 31) ?x476)))
(let ((?x378 (bvand ?x1057 ?x1962)))
(let ((?x399 (ite (and (distinct (_ bv0 32) ?x378) true) (_ bv1 1) (_ bv0 1))))
(let (($x111 (or false false)))
(let (($x1928 (or $x111 false false)))
(let (($x77 (or $x1928 false)))
(let (($x1534 (or $x77 $x77 false)))
(let (($x192 (or $x1534 false false)))
(and (not $x192) (or $x192 (and (distinct ?x399 ?x399) true)))))))))))))))
(check-sat)
; query 79: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1111 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x87 (or false false false)))
(let (($x53 (not $x87)))
(and $x53 (or $x87 (and (distinct ?x1111 ?x1111) true)))))))
(check-sat)
; query 80: function matrix_add_const, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x87 (or false false false)))
(let (($x53 (not $x87)))
(and $x53 (or $x87 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 81: function matrix_add_const, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x254 (bvadd in.01_32 (_ bv1 32))))
(let (($x292 (and (distinct ?x254 ?x254) true)))
(let (($x87 (or false false false)))
(let (($x53 (not $x87)))
(and $x53 (or $x87 $x292)))))))
(check-sat)
; query 82: function matrix_mul_const, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x87 (or false false false)))
(let (($x53 (not $x87)))
(and $x53 (or $x87 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 83: function matrix_mul_const, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x254 (bvadd in.01_32 (_ bv1 32))))
(let (($x292 (and (distinct ?x254 ?x254) true)))
(let (($x87 (or false false false)))
(let (($x53 (not $x87)))
(and $x53 (or $x87 $x292)))))))
(check-sat)
; query 84: function matrix_mul_matrix, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x87 (or false false false)))
(let (($x53 (not $x87)))
(and $x53 (or $x87 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 85: function matrix_mul_matrix, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x254 (bvadd in.01_32 (_ bv1 32))))
(let (($x292 (and (distinct ?x254 ?x254) true)))
(let (($x87 (or false false false)))
(let (($x53 (not $x87)))
(and $x53 (or $x87 $x292)))))))
(check-sat)
; query 86: function matrix_mul_matrix, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x87 (or false false false)))
(let (($x53 (not $x87)))
(and $x53 (or $x87 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 87: function matrix_mul_matrix_bitextract, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x87 (or false false false)))
(let (($x53 (not $x87)))
(and $x53 (or $x87 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 88: function matrix_mul_matrix_bitextract, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x254 (bvadd in.01_32 (_ bv1 32))))
(let (($x292 (and (distinct ?x254 ?x254) true)))
(let (($x87 (or false false false)))
(let (($x53 (not $x87)))
(and $x53 (or $x87 $x292)))))))
(check-sat)
; query 89: function matrix_mul_matrix_bitextract, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x87 (or false false false)))
(let (($x53 (not $x87)))
(and $x53 (or $x87 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 90: function matrix_mul_vect, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x87 (or false false false)))
(let (($x53 (not $x87)))
(and $x53 (or $x87 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 91: function matrix_mul_vect, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x254 (bvadd in.01_32 (_ bv1 32))))
(let (($x292 (and (distinct ?x254 ?x254) true)))
(let (($x87 (or false false false)))
(let (($x53 (not $x87)))
(and $x53 (or $x87 $x292)))))))
(check-sat)
; query 92: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x111 (or false false)))
(let (($x1915 (not $x111)))
(and $x1915 (or $x111 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 93: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x2058 ((_ sign_extend 16) in.1_16)))
(let ((?x442 (bvadd ?x2058 (_ bv10 32))))
(let (($x203 (and (distinct (bvadd ((_ sign_extend 1) ?x2058) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x442)) true)))
(let (($x111 (or false false)))
(let (($x1892 (or $x111 false (or $x203))))
(and (not $x1892) (or $x1892 (and (distinct ?x442 ?x442) true)))))))))
(check-sat)
; query 94: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x2058 ((_ sign_extend 16) in.1_16)))
(let ((?x442 (bvadd ?x2058 (_ bv10 32))))
(let ((?x729 ((_ extract 15 0) ?x442)))
(let (($x203 (and (distinct (bvadd ((_ sign_extend 1) ?x2058) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x442)) true)))
(let (($x111 (or false false)))
(let (($x1892 (or $x111 false (or $x203))))
(let (($x42 (or $x1892 false)))
(and (not $x42) (or $x42 (and (distinct ?x729 ?x729) true)))))))))))
(check-sat)
; query 95: function matrix_sum, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x1894 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x87 (or false false false)))
(let (($x53 (not $x87)))
(and $x53 (or $x87 (and (distinct ?x1894 ?x1894) true)))))))
(check-sat)
; query 96: function matrix_sum, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x1894 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let ((?x615 ((_ zero_extend 63) ?x1894)))
(let (($x87 (or false false false)))
(let (($x815 (or $x87 false)))
(and (not $x815) (or $x815 (and (distinct ?x615 ?x615) true))))))))
(check-sat)
; query 97: function matrix_sum, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x1894 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x868 (= (_ bv1 1) ?x1894)))
(let ((?x688 (ite $x868 (_ bv1 32) (_ bv0 32))))
(let (($x87 (or false false false)))
(let (($x532 (or $x87 (ite $x868 false false))))
(and (not $x532) (or $x532 (and (distinct ?x688 ?x688) true)))))))))
(check-sat)
; query 98: function matrix_sum, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x111 (or false false)))
(let (($x1915 (not $x111)))
(and $x1915 (or $x111 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 99: function matrix_sum, block 22, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x1894 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x868 (= (_ bv1 1) ?x1894)))
(let ((?x688 (ite $x868 (_ bv1 32) (_ bv0 32))))
(let ((?x2058 ((_ sign_extend 16) in.1_16)))
(let ((?x1996 (bvadd ?x2058 ?x688)))
(let (($x398 (and (distinct (bvadd ((_ sign_extend 1) ?x2058) ((_ sign_extend 1) ?x688)) ((_ sign_extend 1) ?x1996)) true)))
(let (($x87 (or false false false)))
(let (($x532 (or $x87 (ite $x868 false false))))
(let (($x111 (or false false)))
(let (($x407 (or $x111 $x532 (or $x398))))
(and (not $x407) (or $x407 (and (distinct ?x1996 ?x1996) true))))))))))))))
(check-sat)
; query 100: function matrix_sum, block 22, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x1894 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x868 (= (_ bv1 1) ?x1894)))
(let ((?x688 (ite $x868 (_ bv1 32) (_ bv0 32))))
(let ((?x2058 ((_ sign_extend 16) in.1_16)))
(let ((?x1996 (bvadd ?x2058 ?x688)))
(let ((?x1876 ((_ extract 15 0) ?x1996)))
(let (($x398 (and (distinct (bvadd ((_ sign_extend 1) ?x2058) ((_ sign_extend 1) ?x688)) ((_ sign_extend 1) ?x1996)) true)))
(let (($x87 (or false false false)))
(let (($x532 (or $x87 (ite $x868 false false))))
(let (($x111 (or false false)))
(let (($x407 (or $x111 $x532 (or $x398))))
(let (($x1945 (or $x407 false)))
(and (not $x1945) (or $x1945 (and (distinct ?x1876 ?x1876) true))))))))))))))))
(check-sat)
; query 101: function matrix_sum, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x87 (or false false false)))
(let (($x53 (not $x87)))
(and $x53 (or $x87 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 102: function matrix_sum, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x254 (bvadd in.01_32 (_ bv1 32))))
(let (($x292 (and (distinct ?x254 ?x254) true)))
(let (($x87 (or false false false)))
(let (($x53 (not $x87)))
(and $x53 (or $x87 $x292)))))))
(check-sat)
; query 103: function parseval, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.23_32 () (_ BitVec 32))
(assert
 (let (($x2083 (and (distinct (bvmul ((_ sign_extend 32) in.23_32) ((_ sign_extend 32) (_ bv1024 32))) ((_ sign_extend 32) (bvmul in.23_32 (_ bv1024 32)))) true)))
(let (($x864 (or false false (or $x2083))))
(and (not $x864) (or $x864 (and (distinct (bvmul in.23_32 (_ bv1024 32)) (bvmul in.23_32 (_ bv1024 32))) true))))))
(check-sat)
; query 104: function parseval, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.34_32 () (_ BitVec 32))
(assert
 (let (($x417 (and (distinct (bvmul ((_ sign_extend 32) in.34_32) ((_ sign_extend 32) (_ bv1048576 32))) ((_ sign_extend 32) (bvmul in.34_32 (_ bv1048576 32)))) true)))
(let (($x1913 (or false false (or $x417))))
(and (not $x1913) (or $x1913 (and (distinct (bvmul in.34_32 (_ bv1048576 32)) (bvmul in.34_32 (_ bv1048576 32))) true))))))
(check-sat)
; query 105: function partition_memory, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x87 (or false false false)))
(let (($x53 (not $x87)))
(and $x53 (or $x87 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
