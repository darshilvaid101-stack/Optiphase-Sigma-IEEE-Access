; OptiPhase-Sigma refinement certificate for sweep K28-R3-210
; query 0: function polybench_flush_cache, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x113 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x382 (or false false (or $x113))))
(and (not $x382) (or $x382 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function print_array, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x29 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x63 (or false false (or $x29))))
(and (not $x63) (or $x63 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function print_array, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x113 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x382 (or false false (or $x113))))
(and (not $x382) (or $x382 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 3: function xmalloc, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in7_32 () (_ BitVec 32))
(assert
 (let ((?x30 (ite (and (distinct (_ bv0 32) in7_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false false)))
(and (not $x64) (or $x64 (and (distinct ?x30 ?x30) true))))))
(check-sat)
