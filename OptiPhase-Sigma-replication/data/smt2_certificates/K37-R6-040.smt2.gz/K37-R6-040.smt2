; OptiPhase-Sigma refinement certificate for sweep K37-R6-040
; query 0: function bit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x72 (and (distinct (bvsub ((_ sign_extend 1) (_ bv31 32)) ((_ sign_extend 1) in0_32)) ((_ sign_extend 1) (bvsub (_ bv31 32) in0_32))) true)))
(let (($x19 (or false false (or $x72))))
(and (not $x19) (or $x19 (and (distinct (bvsub (_ bv31 32) in0_32) (bvsub (_ bv31 32) in0_32)) true))))))
(check-sat)
; query 1: function bit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x21 (bvsub (_ bv31 32) in0_32)))
(let ((?x51 (bvshl (_ bv1 32) ?x21)))
(let (($x72 (and (distinct (bvsub ((_ sign_extend 1) (_ bv31 32)) ((_ sign_extend 1) in0_32)) ((_ sign_extend 1) ?x21)) true)))
(let (($x19 (or false false (or $x72))))
(let (($x621 (or (or false $x19 false) (bvuge ?x21 (_ bv32 32)))))
(and (not $x621) (or $x621 (and (distinct ?x51 ?x51) true)))))))))
(check-sat)
; query 2: function bit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x21 (bvsub (_ bv31 32) in0_32)))
(let ((?x51 (bvshl (_ bv1 32) ?x21)))
(let ((?x170 ((_ sign_extend 32) ?x51)))
(let (($x72 (and (distinct (bvsub ((_ sign_extend 1) (_ bv31 32)) ((_ sign_extend 1) in0_32)) ((_ sign_extend 1) ?x21)) true)))
(let (($x19 (or false false (or $x72))))
(let (($x621 (or (or false $x19 false) (bvuge ?x21 (_ bv32 32)))))
(let (($x33 (or $x621 false)))
(and (not $x33) (or $x33 (and (distinct ?x170 ?x170) true)))))))))))
(check-sat)
; query 3: function bit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x21 (bvsub (_ bv31 32) in0_32)))
(let ((?x51 (bvshl (_ bv1 32) ?x21)))
(let ((?x170 ((_ sign_extend 32) ?x51)))
(let ((?x266 (bvand in1_64 ?x170)))
(let (($x72 (and (distinct (bvsub ((_ sign_extend 1) (_ bv31 32)) ((_ sign_extend 1) in0_32)) ((_ sign_extend 1) ?x21)) true)))
(let (($x19 (or false false (or $x72))))
(let (($x621 (or (or false $x19 false) (bvuge ?x21 (_ bv32 32)))))
(let (($x33 (or $x621 false)))
(let (($x63 (or false $x33 false)))
(and (not $x63) (or $x63 (and (distinct ?x266 ?x266) true)))))))))))))
(check-sat)
