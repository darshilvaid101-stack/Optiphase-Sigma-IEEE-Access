; OptiPhase-Sigma refinement certificate for sweep K14-R6-053
