; OptiPhase-Sigma refinement certificate for sweep K50-R1-001
