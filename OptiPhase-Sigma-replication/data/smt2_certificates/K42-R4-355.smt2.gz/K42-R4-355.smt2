; OptiPhase-Sigma refinement certificate for sweep K42-R4-355
