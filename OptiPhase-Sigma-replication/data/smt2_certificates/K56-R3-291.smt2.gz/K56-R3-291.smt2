; OptiPhase-Sigma refinement certificate for sweep K56-R3-291
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x718 (or false false)))
(let (($x110 (not $x718)))
(and $x110 (or $x718 (and (distinct ((_ sign_extend 16) in25_16) ((_ sign_extend 16) in25_16)) true))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let ((?x864 (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))))
(let (($x718 (or false false)))
(let (($x727 (or $x718 false false)))
(let (($x1042 (not $x727)))
(and $x1042 (or $x727 (and (distinct ?x864 ?x864) true))))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x718 (or false false)))
(let (($x110 (not $x718)))
(and $x110 (or $x718 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x669 ((_ sign_extend 16) in3_16)))
(let ((?x52 (bvand ?x669 (_ bv127 32))))
(let (($x718 (or false false)))
(let (($x727 (or $x718 false false)))
(let (($x1042 (not $x727)))
(and $x1042 (or $x727 (and (distinct ?x52 ?x52) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x669 ((_ sign_extend 16) in3_16)))
(let ((?x52 (bvand ?x669 (_ bv127 32))))
(let ((?x207 ((_ extract 15 0) ?x52)))
(let (($x718 (or false false)))
(let (($x727 (or $x718 false false)))
(let (($x337 (or $x727 false)))
(let (($x1022 (not $x337)))
(and $x1022 (or $x337 (and (distinct ?x207 ?x207) true)))))))))))
(check-sat)
; query 5: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x718 (or false false)))
(let (($x110 (not $x718)))
(and $x110 (or $x718 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 6: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x538 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x718 (or false false)))
(let (($x727 (or $x718 false false)))
(let (($x1042 (not $x727)))
(and $x1042 (or $x727 (and (distinct ?x538 ?x538) true))))))))
(check-sat)
; query 7: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x167 (or false false false)))
(let (($x854 (not $x167)))
(and $x854 (or $x167 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1111 (bvadd in.01_32 (_ bv1 32))))
(let ((?x98 (bvmul ?x1111 (_ bv8 32))))
(let ((?x179 (bvmul ?x1111 ?x1111)))
(let (($x167 (or false false false)))
(let (($x1103 (or $x167 false false)))
(and (not (or $x167 $x167 false)) (or $x1103 (and (distinct ?x179 ?x98) true)))))))))
(check-sat)
; query 9: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x21 (and (distinct (bvmul (bvmul (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) (_ bv2 32)) (bvmul (bvmul (bvadd in.01_32 (_ bv1 32)) (_ bv8 32)) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x167 (or false false false)))
(let (($x1103 (or $x167 false false)))
(and (not (or (or $x167 $x167 false) false false)) (or (or $x1103 $x167 false) $x21))))))
(check-sat)
; query 10: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x809 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x167 (or false false false)))
(let (($x854 (not $x167)))
(and $x854 (or $x167 (and (distinct ?x809 ?x809) true)))))))
(check-sat)
; query 11: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x219 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x167 (or false false false)))
(let (($x854 (not $x167)))
(and $x854 (or $x167 (and (distinct ?x219 ?x219) true)))))))
(check-sat)
; query 12: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x167 (or false false false)))
(let (($x854 (not $x167)))
(and $x854 (or $x167 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 13: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x54 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x28 (or false false (or $x54))))
(and (not $x28) (or $x28 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 14: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x369 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x167 (or false false false)))
(let (($x854 (not $x167)))
(and $x854 (or $x167 (and (distinct ?x369 ?x369) true)))))))
(check-sat)
; query 15: function crcu8, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x718 (or false false)))
(let (($x110 (not $x718)))
(and $x110 (or $x718 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 16: function crcu8, block 19, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x360 ((_ zero_extend 16) in.01_16)))
(let ((?x77 (bvxor ?x360 (_ bv16386 32))))
(let (($x718 (or false false)))
(let (($x727 (or $x718 false false)))
(let (($x1042 (not $x727)))
(and $x1042 (or $x727 (and (distinct ?x77 ?x77) true)))))))))
(check-sat)
; query 17: function crcu8, block 19, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x360 ((_ zero_extend 16) in.01_16)))
(let ((?x77 (bvxor ?x360 (_ bv16386 32))))
(let ((?x724 ((_ extract 15 0) ?x77)))
(let (($x718 (or false false)))
(let (($x727 (or $x718 false false)))
(let (($x337 (or $x727 false)))
(let (($x1022 (not $x337)))
(and $x1022 (or $x337 (and (distinct ?x724 ?x724) true)))))))))))
(check-sat)
; query 18: function crcu8, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x437 ((_ extract 7 0) in.01_16)))
(let ((?x739 ((_ zero_extend 24) ?x437)))
(let (($x718 (or false false)))
(let (($x289 (or $x718 false)))
(and (not $x289) (or $x289 (and (distinct ?x739 ?x739) true))))))))
(check-sat)
; query 19: function crcu8, block 6, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x437 ((_ extract 7 0) in.01_16)))
(let ((?x739 ((_ zero_extend 24) ?x437)))
(let ((?x386 (bvand ?x739 (_ bv1 32))))
(let (($x718 (or false false)))
(let (($x289 (or $x718 false)))
(let (($x22 (or $x289 false false)))
(and (not $x22) (or $x22 (and (distinct ?x386 ?x386) true))))))))))
(check-sat)
; query 20: function crcu8, block 6, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x437 ((_ extract 7 0) in.01_16)))
(let ((?x739 ((_ zero_extend 24) ?x437)))
(let ((?x386 (bvand ?x739 (_ bv1 32))))
(let ((?x90 ((_ zero_extend 24) in.0_8)))
(let ((?x130 (bvand ?x90 (_ bv1 32))))
(let ((?x431 (bvxor ?x130 ?x386)))
(let (($x718 (or false false)))
(let (($x289 (or $x718 false)))
(let (($x22 (or $x289 false false)))
(let (($x727 (or $x718 false false)))
(let (($x880 (or $x727 $x22 false)))
(and (not $x880) (or $x880 (and (distinct ?x431 ?x431) true)))))))))))))))
(check-sat)
; query 21: function crcu8, block 6, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x437 ((_ extract 7 0) in.01_16)))
(let ((?x739 ((_ zero_extend 24) ?x437)))
(let ((?x386 (bvand ?x739 (_ bv1 32))))
(let ((?x90 ((_ zero_extend 24) in.0_8)))
(let ((?x130 (bvand ?x90 (_ bv1 32))))
(let ((?x431 (bvxor ?x130 ?x386)))
(let ((?x309 ((_ extract 7 0) ?x431)))
(let (($x718 (or false false)))
(let (($x289 (or $x718 false)))
(let (($x22 (or $x289 false false)))
(let (($x727 (or $x718 false false)))
(let (($x880 (or $x727 $x22 false)))
(let (($x26 (or $x880 false)))
(and (not $x26) (or $x26 (and (distinct ?x309 ?x309) true)))))))))))))))))
(check-sat)
; query 22: function crcu8, block 6, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x718 (or false false)))
(let (($x110 (not $x718)))
(and $x110 (or $x718 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 23: function crcu8, block 6, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x90 ((_ zero_extend 24) in.0_8)))
(let ((?x19 (bvashr ?x90 (_ bv1 32))))
(let (($x718 (or false false)))
(let (($x727 (or $x718 false false)))
(let (($x12 (or $x727 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not $x12) (or $x12 (and (distinct ?x19 ?x19) true)))))))))
(check-sat)
; query 24: function crcu8, block 6, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x90 ((_ zero_extend 24) in.0_8)))
(let ((?x19 (bvashr ?x90 (_ bv1 32))))
(let ((?x380 ((_ extract 7 0) ?x19)))
(let (($x718 (or false false)))
(let (($x727 (or $x718 false false)))
(let (($x12 (or $x727 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x70 (or $x12 false)))
(and (not $x70) (or $x70 (and (distinct ?x380 ?x380) true)))))))))))
(check-sat)
; query 25: function crcu8, block 6, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x437 ((_ extract 7 0) in.01_16)))
(let ((?x739 ((_ zero_extend 24) ?x437)))
(let ((?x386 (bvand ?x739 (_ bv1 32))))
(let ((?x90 ((_ zero_extend 24) in.0_8)))
(let ((?x130 (bvand ?x90 (_ bv1 32))))
(let ((?x431 (bvxor ?x130 ?x386)))
(let ((?x309 ((_ extract 7 0) ?x431)))
(let ((?x286 ((_ zero_extend 24) ?x309)))
(let (($x718 (or false false)))
(let (($x289 (or $x718 false)))
(let (($x22 (or $x289 false false)))
(let (($x727 (or $x718 false false)))
(let (($x880 (or $x727 $x22 false)))
(let (($x26 (or $x880 false)))
(let (($x79 (or $x26 false)))
(and (not $x79) (or $x79 (and (distinct ?x286 ?x286) true)))))))))))))))))))
(check-sat)
; query 26: function crcu8, block 6, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x437 ((_ extract 7 0) in.01_16)))
(let ((?x739 ((_ zero_extend 24) ?x437)))
(let ((?x386 (bvand ?x739 (_ bv1 32))))
(let ((?x90 ((_ zero_extend 24) in.0_8)))
(let ((?x130 (bvand ?x90 (_ bv1 32))))
(let ((?x431 (bvxor ?x130 ?x386)))
(let ((?x309 ((_ extract 7 0) ?x431)))
(let ((?x286 ((_ zero_extend 24) ?x309)))
(let ((?x223 (ite (= (_ bv1 32) ?x286) (_ bv1 1) (_ bv0 1))))
(let (($x718 (or false false)))
(let (($x289 (or $x718 false)))
(let (($x22 (or $x289 false false)))
(let (($x727 (or $x718 false false)))
(let (($x880 (or $x727 $x22 false)))
(let (($x26 (or $x880 false)))
(let (($x79 (or $x26 false)))
(let (($x92 (or $x79 false false)))
(and (not $x92) (or $x92 (and (distinct ?x223 ?x223) true)))))))))))))))))))))
(check-sat)
; query 27: function crcu8, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x718 (or false false)))
(let (($x110 (not $x718)))
(and $x110 (or $x718 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 28: function crcu8, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x90 ((_ zero_extend 24) in.0_8)))
(let ((?x130 (bvand ?x90 (_ bv1 32))))
(let (($x718 (or false false)))
(let (($x727 (or $x718 false false)))
(let (($x1042 (not $x727)))
(and $x1042 (or $x727 (and (distinct ?x130 ?x130) true)))))))))
(check-sat)
; query 29: function crcu8, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x718 (or false false)))
(let (($x110 (not $x718)))
(and $x110 (or $x718 (and (distinct ((_ extract 7 0) in.01_16) ((_ extract 7 0) in.01_16)) true))))))
(check-sat)
; query 30: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x404 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x167 (or false false false)))
(let (($x854 (not $x167)))
(and $x854 (or $x167 (and (distinct ?x404 ?x404) true)))))))
(check-sat)
; query 31: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x718 (or false false)))
(let (($x110 (not $x718)))
(and $x110 (or $x718 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 32: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x81 ((_ sign_extend 16) in.1_16)))
(let ((?x623 (bvadd ?x81 (_ bv10 32))))
(let (($x45 (and (distinct (bvadd ((_ sign_extend 1) ?x81) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x623)) true)))
(let (($x718 (or false false)))
(let (($x34 (or $x718 false (or $x45))))
(and (not $x34) (or $x34 (and (distinct ?x623 ?x623) true)))))))))
(check-sat)
; query 33: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x81 ((_ sign_extend 16) in.1_16)))
(let ((?x623 (bvadd ?x81 (_ bv10 32))))
(let ((?x20 ((_ extract 15 0) ?x623)))
(let (($x45 (and (distinct (bvadd ((_ sign_extend 1) ?x81) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x623)) true)))
(let (($x718 (or false false)))
(let (($x34 (or $x718 false (or $x45))))
(let (($x1181 (or $x34 false)))
(and (not $x1181) (or $x1181 (and (distinct ?x20 ?x20) true)))))))))))
(check-sat)
