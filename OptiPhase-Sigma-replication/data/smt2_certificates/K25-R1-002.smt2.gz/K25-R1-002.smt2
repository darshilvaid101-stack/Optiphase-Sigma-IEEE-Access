; OptiPhase-Sigma refinement certificate for sweep K25-R1-002
