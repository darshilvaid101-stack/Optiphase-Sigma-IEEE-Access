; OptiPhase-Sigma refinement certificate for sweep K55-R6-015
; query 0: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x28 (or false false false)))
(let (($x42008 (not $x28)))
(and $x42008 (or $x28 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1429 (bvadd in.01_32 (_ bv1 32))))
(let ((?x426 (bvmul ?x1429 ?x1429)))
(let (($x28 (or false false false)))
(let (($x759 (or $x28 $x28 false)))
(and (not $x759) (or $x759 (and (distinct ?x426 ?x426) true))))))))
(check-sat)
; query 2: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x1022 (and (distinct (bvmul (bvmul (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) (_ bv2 32)) (bvshl (bvmul (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) (_ bv3 32))) true)))
(let (($x28 (or false false false)))
(let (($x759 (or $x28 $x28 false)))
(let (($x339 (or $x759 false false)))
(and (not $x339) (or (or $x339 (bvuge (_ bv3 32) (_ bv32 32))) $x1022)))))))
(check-sat)
; query 3: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x320 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x28 (or false false false)))
(let (($x42008 (not $x28)))
(and $x42008 (or $x28 (and (distinct ?x320 ?x320) true)))))))
(check-sat)
; query 4: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x28 (or false false false)))
(let (($x42008 (not $x28)))
(and $x42008 (or $x28 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 5: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1128 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x28 (or false false false)))
(let (($x42008 (not $x28)))
(and $x42008 (or $x28 (and (distinct ?x1128 ?x1128) true)))))))
(check-sat)
