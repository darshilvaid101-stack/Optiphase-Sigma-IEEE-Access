; OptiPhase-Sigma refinement certificate for sweep K45-R6-027
; query 0: function Index_to_frequency, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x40 (ite (bvuge in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x355 (or false false false)))
(let (($x9 (not $x355)))
(and $x9 (or $x355 (and (distinct ?x40 ?x40) true)))))))
(check-sat)
; query 1: function IsPowerOfTwo, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x79 (and (distinct (bvsub ((_ zero_extend 1) in0_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvsub in0_32 (_ bv1 32)))) true)))
(let (($x871 (or false false (or $x79))))
(let (($x355 (or false false false)))
(let (($x9 (not $x355)))
(and $x9 (or $x871 (and (distinct (bvsub in0_32 (_ bv1 32)) (bvsub in0_32 (_ bv1 32))) true))))))))
(check-sat)
; query 2: function IsPowerOfTwo, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x280 (bvsub in0_32 (_ bv1 32))))
(let ((?x51 (bvand in0_32 ?x280)))
(let (($x79 (and (distinct (bvsub ((_ zero_extend 1) in0_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) ?x280)) true)))
(let (($x871 (or false false (or $x79))))
(let (($x127 (or false $x871 false)))
(and (not (or false (or false false false) false)) (or $x127 (and (distinct ?x51 ?x51) true)))))))))
(check-sat)
; query 3: function IsPowerOfTwo, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x93 (ite (and (distinct (_ bv0 32) (bvand in0_32 (bvsub in0_32 (_ bv1 32)))) true) (_ bv1 1) (_ bv0 1))))
(let (($x79 (and (distinct (bvsub ((_ zero_extend 1) in0_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvsub in0_32 (_ bv1 32)))) true)))
(let (($x871 (or false false (or $x79))))
(let (($x127 (or false $x871 false)))
(let (($x146 (not (or (or false (or false false false) false) false false))))
(and $x146 (or (or $x127 false false) (and (distinct ?x93 ?x93) true)))))))))
(check-sat)
; query 4: function IsPowerOfTwo, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x276 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x355 (or false false false)))
(let (($x9 (not $x355)))
(and $x9 (or $x355 (and (distinct ?x276 ?x276) true)))))))
(check-sat)
; query 5: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x276 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x355 (or false false false)))
(let (($x9 (not $x355)))
(and $x9 (or $x355 (and (distinct ?x276 ?x276) true)))))))
(check-sat)
; query 6: function fft_float, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x80 (ite (and (distinct (_ bv0 32) in1_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x355 (or false false false)))
(let (($x9 (not $x355)))
(and $x9 (or $x355 (and (distinct ?x80 ?x80) true)))))))
(check-sat)
; query 7: function main, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x609 (ite (= (_ bv4 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x355 (or false false false)))
(let (($x9 (not $x355)))
(and $x9 (or $x355 (and (distinct ?x609 ?x609) true)))))))
(check-sat)
; query 8: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x372 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x355 (or false false false)))
(let (($x9 (not $x355)))
(and $x9 (or $x355 (and (distinct ?x372 ?x372) true)))))))
(check-sat)
