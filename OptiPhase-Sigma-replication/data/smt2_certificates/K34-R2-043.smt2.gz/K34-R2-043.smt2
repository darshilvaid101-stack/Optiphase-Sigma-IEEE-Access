; OptiPhase-Sigma refinement certificate for sweep K34-R2-043
; query 0: function corner_draw, block 11, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x98 (ite (= (_ bv0 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x152 (or false false false)))
(let (($x365 (not $x152)))
(and $x365 (or $x152 (and (distinct ?x98 ?x98) true)))))))
(check-sat)
; query 1: function edge_draw, block 39, name %40
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x44 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x34 (or false false (or $x44))))
(and (not $x34) (or $x34 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function edge_draw, block 57, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x626 (and (distinct (bvadd ((_ sign_extend 1) in.12_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.12_32 (_ bv1 32)))) true)))
(let (($x399 (or false false (or $x626))))
(and (not $x399) (or $x399 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 3: function edge_draw, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let ((?x392 (ite (= (_ bv0 32) in4_32) (_ bv1 1) (_ bv0 1))))
(let (($x152 (or false false false)))
(let (($x365 (not $x152)))
(and $x365 (or $x152 (and (distinct ?x392 ?x392) true)))))))
(check-sat)
; query 4: function enlarge, block 106, name %107
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x15 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x101 (or false false (or $x15))))
(and (not $x101) (or $x101 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 5: function enlarge, block 158, name %159
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x111 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x25 (or false false (or $x111))))
(and (not $x25) (or $x25 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 6: function enlarge, block 161, name %162
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let (($x76 (and (distinct (bvadd ((_ sign_extend 1) in.2_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.2_32 (_ bv1 32)))) true)))
(let (($x83 (or false false (or $x76))))
(and (not $x83) (or $x83 (and (distinct (bvadd in.2_32 (_ bv1 32)) (bvadd in.2_32 (_ bv1 32))) true))))))
(check-sat)
; query 7: function enlarge, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x44 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x34 (or false false (or $x44))))
(and (not $x34) (or $x34 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function getint, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x488 (ite (bvsle (_ bv48 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x152 (or false false false)))
(let (($x365 (not $x152)))
(and $x365 (or $x152 (and (distinct ?x488 ?x488) true)))))))
(check-sat)
; query 9: function getint, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x24 (ite (bvsge (_ bv57 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x152 (or false false false)))
(let (($x365 (not $x152)))
(and $x365 (or $x152 (and (distinct ?x24 ?x24) true)))))))
(check-sat)
; query 10: function getint, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in26_32 () (_ BitVec 32))
(assert
 (let ((?x56 (ite (bvsgt (_ bv48 32) in26_32) (_ bv1 1) (_ bv0 1))))
(let (($x152 (or false false false)))
(let (($x365 (not $x152)))
(and $x365 (or $x152 (and (distinct ?x56 ?x56) true)))))))
(check-sat)
; query 11: function getint, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in26_32 () (_ BitVec 32))
(assert
 (let ((?x139 (ite (bvslt (_ bv57 32) in26_32) (_ bv1 1) (_ bv0 1))))
(let (($x152 (or false false false)))
(let (($x365 (not $x152)))
(and $x365 (or $x152 (and (distinct ?x139 ?x139) true)))))))
(check-sat)
; query 12: function getint, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x129 (ite (= (_ bv4294967295 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x152 (or false false false)))
(let (($x365 (not $x152)))
(and $x365 (or $x152 (and (distinct ?x129 ?x129) true)))))))
(check-sat)
; query 13: function int_to_uchar, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_32 () (_ BitVec 32))
(assert
 (let (($x117 (and (distinct (bvadd ((_ sign_extend 1) in.03_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.03_32 (_ bv1 32)))) true)))
(let (($x130 (or false false (or $x117))))
(and (not $x130) (or $x130 (and (distinct (bvadd in.03_32 (_ bv1 32)) (bvadd in.03_32 (_ bv1 32))) true))))))
(check-sat)
; query 14: function int_to_uchar, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x498 (and (distinct (bvsub ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) in.0_32)) ((_ sign_extend 1) (bvsub in.01_32 in.0_32))) true)))
(let (($x566 (or false false (or $x498))))
(let (($x321 (or $x566 (and (distinct (bvsub in.01_32 in.0_32) (bvsub in.01_32 in.0_32)) true))))
(and (not $x566) $x321)))))
(check-sat)
; query 15: function int_to_uchar, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.14_32 () (_ BitVec 32))
(assert
 (let (($x75 (and (distinct (bvadd ((_ sign_extend 1) in.14_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.14_32 (_ bv1 32)))) true)))
(let (($x68 (or false false (or $x75))))
(and (not $x68) (or $x68 (and (distinct (bvadd in.14_32 (_ bv1 32)) (bvadd in.14_32 (_ bv1 32))) true))))))
(check-sat)
; query 16: function main, block 129, name %130
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.011_32 () (_ BitVec 32))
(assert
 (let ((?x133 (ite (and (distinct (_ bv0 32) in.011_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x152 (or false false false)))
(let (($x365 (not $x152)))
(and $x365 (or $x152 (and (distinct ?x133 ?x133) true)))))))
(check-sat)
; query 17: function main, block 160, name %161
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x120 (ite (and (distinct (_ bv0 32) in.01_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x152 (or false false false)))
(let (($x365 (not $x152)))
(and $x365 (or $x152 (and (distinct ?x120 ?x120) true)))))))
(check-sat)
; query 18: function main, block 35, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x115 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x48 (or false false (or $x115))))
(and (not $x48) (or $x48 (and (distinct (bvadd in.020_32 (_ bv1 32)) (bvadd in.020_32 (_ bv1 32))) true))))))
(check-sat)
; query 19: function main, block 35, name %37
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let ((?x424 (ite (bvsge (bvadd in.020_32 (_ bv1 32)) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x115 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x48 (or false false (or $x115))))
(let (($x114 (or $x48 false false)))
(and (not $x114) (or $x114 (and (distinct ?x424 ?x424) true))))))))
(check-sat)
; query 20: function main, block 49, name %50
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x115 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x48 (or false false (or $x115))))
(and (not $x48) (or $x48 (and (distinct (bvadd in.020_32 (_ bv1 32)) (bvadd in.020_32 (_ bv1 32))) true))))))
(check-sat)
; query 21: function main, block 49, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let ((?x424 (ite (bvsge (bvadd in.020_32 (_ bv1 32)) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x115 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x48 (or false false (or $x115))))
(let (($x114 (or $x48 false false)))
(and (not $x114) (or $x114 (and (distinct ?x424 ?x424) true))))))))
(check-sat)
; query 22: function main, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.014_32 () (_ BitVec 32))
(assert
 (let ((?x400 (ite (= (_ bv1 32) in.014_32) (_ bv1 1) (_ bv0 1))))
(let (($x152 (or false false false)))
(let (($x365 (not $x152)))
(and $x365 (or $x152 (and (distinct ?x400 ?x400) true)))))))
(check-sat)
; query 23: function main, block 66, name %67
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x103 (ite (= (_ bv0 32) in.0_32) (_ bv1 1) (_ bv0 1))))
(let (($x152 (or false false false)))
(let (($x365 (not $x152)))
(and $x365 (or $x152 (and (distinct ?x103 ?x103) true)))))))
(check-sat)
; query 24: function main, block 84, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.07_32 () (_ BitVec 32))
(assert
 (let ((?x859 (ite (and (distinct (_ bv0 32) in.07_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x152 (or false false false)))
(let (($x365 (not $x152)))
(and $x365 (or $x152 (and (distinct ?x859 ?x859) true)))))))
(check-sat)
; query 25: function median, block 103, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x111 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x25 (or false false (or $x111))))
(and (not $x25) (or $x25 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 26: function median, block 106, name %107
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x44 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x34 (or false false (or $x44))))
(and (not $x34) (or $x34 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 27: function setup_brightness_lut, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x44 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x34 (or false false (or $x44))))
(and (not $x34) (or $x34 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 28: function susan_corners, block 1066, name %1067
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x111 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x25 (or false false (or $x111))))
(and (not $x25) (or $x25 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 29: function susan_corners, block 1069, name %1070
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x44 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x34 (or false false (or $x44))))
(and (not $x34) (or $x34 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 30: function susan_corners, block 1549, name %1550
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x15 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x101 (or false false (or $x15))))
(and (not $x101) (or $x101 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 31: function susan_corners, block 1552, name %1553
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x626 (and (distinct (bvadd ((_ sign_extend 1) in.12_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.12_32 (_ bv1 32)))) true)))
(let (($x399 (or false false (or $x626))))
(and (not $x399) (or $x399 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 32: function susan_corners, block 845, name %846
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in839_32 () (_ BitVec 32))
(declare-fun in840_32 () (_ BitVec 32))
(assert
 (let ((?x759 (ite (bvslt in840_32 in839_32) (_ bv1 1) (_ bv0 1))))
(let (($x152 (or false false false)))
(let (($x365 (not $x152)))
(and $x365 (or $x152 (and (distinct ?x759 ?x759) true)))))))
(check-sat)
; query 33: function susan_corners_quick, block 1469, name %1470
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x15 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x101 (or false false (or $x15))))
(and (not $x101) (or $x101 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 34: function susan_corners_quick, block 1472, name %1473
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x626 (and (distinct (bvadd ((_ sign_extend 1) in.12_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.12_32 (_ bv1 32)))) true)))
(let (($x399 (or false false (or $x626))))
(and (not $x399) (or $x399 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 35: function susan_corners_quick, block 433, name %434
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x111 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x25 (or false false (or $x111))))
(and (not $x25) (or $x25 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 36: function susan_corners_quick, block 436, name %437
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x44 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x34 (or false false (or $x44))))
(and (not $x34) (or $x34 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 37: function susan_edges, block 1432, name %1433
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1417_32 () (_ BitVec 32))
(assert
 (let ((?x584 (ite (bvslt (_ bv0 32) in1417_32) (_ bv1 1) (_ bv0 1))))
(let (($x152 (or false false false)))
(let (($x365 (not $x152)))
(and $x365 (or $x152 (and (distinct ?x584 ?x584) true)))))))
(check-sat)
; query 38: function susan_edges, block 1486, name %1487
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.116_32 () (_ BitVec 32))
(assert
 (let (($x269 (and (distinct (bvadd ((_ sign_extend 1) in.116_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.116_32 (_ bv1 32)))) true)))
(let (($x643 (or false false (or $x269))))
(and (not $x643) (or $x643 (and (distinct (bvadd in.116_32 (_ bv1 32)) (bvadd in.116_32 (_ bv1 32))) true))))))
(check-sat)
; query 39: function susan_edges, block 1489, name %1490
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.114_32 () (_ BitVec 32))
(assert
 (let (($x474 (and (distinct (bvadd ((_ sign_extend 1) in.114_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.114_32 (_ bv1 32)))) true)))
(let (($x794 (or false false (or $x474))))
(and (not $x794) (or $x794 (and (distinct (bvadd in.114_32 (_ bv1 32)) (bvadd in.114_32 (_ bv1 32))) true))))))
(check-sat)
; query 40: function susan_edges, block 379, name %380
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.015_32 () (_ BitVec 32))
(assert
 (let (($x213 (and (distinct (bvadd ((_ sign_extend 1) in.015_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.015_32 (_ bv1 32)))) true)))
(let (($x171 (or false false (or $x213))))
(and (not $x171) (or $x171 (and (distinct (bvadd in.015_32 (_ bv1 32)) (bvadd in.015_32 (_ bv1 32))) true))))))
(check-sat)
; query 41: function susan_edges, block 382, name %383
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.013_32 () (_ BitVec 32))
(assert
 (let (($x393 (and (distinct (bvadd ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.013_32 (_ bv1 32)))) true)))
(let (($x278 (or false false (or $x393))))
(and (not $x278) (or $x278 (and (distinct (bvadd in.013_32 (_ bv1 32)) (bvadd in.013_32 (_ bv1 32))) true))))))
(check-sat)
; query 42: function susan_edges, block 870, name %871
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x677 (ite (bvslt (_ bv0 32) in.0_32) (_ bv1 1) (_ bv0 1))))
(let (($x152 (or false false false)))
(let (($x365 (not $x152)))
(and $x365 (or $x152 (and (distinct ?x677 ?x677) true)))))))
(check-sat)
; query 43: function susan_edges_small, block 119, name %120
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.09_32 () (_ BitVec 32))
(assert
 (let (($x772 (and (distinct (bvadd ((_ sign_extend 1) in.09_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.09_32 (_ bv1 32)))) true)))
(let (($x518 (or false false (or $x772))))
(and (not $x518) (or $x518 (and (distinct (bvadd in.09_32 (_ bv1 32)) (bvadd in.09_32 (_ bv1 32))) true))))))
(check-sat)
; query 44: function susan_edges_small, block 122, name %123
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.07_32 () (_ BitVec 32))
(assert
 (let (($x496 (and (distinct (bvadd ((_ sign_extend 1) in.07_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.07_32 (_ bv1 32)))) true)))
(let (($x675 (or false false (or $x496))))
(and (not $x675) (or $x675 (and (distinct (bvadd in.07_32 (_ bv1 32)) (bvadd in.07_32 (_ bv1 32))) true))))))
(check-sat)
; query 45: function susan_edges_small, block 278, name %279
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x677 (ite (bvslt (_ bv0 32) in.0_32) (_ bv1 1) (_ bv0 1))))
(let (($x152 (or false false false)))
(let (($x365 (not $x152)))
(and $x365 (or $x152 (and (distinct ?x677 ?x677) true)))))))
(check-sat)
; query 46: function susan_edges_small, block 426, name %427
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in411_32 () (_ BitVec 32))
(assert
 (let ((?x482 (ite (bvslt (_ bv0 32) in411_32) (_ bv1 1) (_ bv0 1))))
(let (($x152 (or false false false)))
(let (($x365 (not $x152)))
(and $x365 (or $x152 (and (distinct ?x482 ?x482) true)))))))
(check-sat)
; query 47: function susan_edges_small, block 458, name %459
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.110_32 () (_ BitVec 32))
(assert
 (let (($x499 (and (distinct (bvadd ((_ sign_extend 1) in.110_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.110_32 (_ bv1 32)))) true)))
(let (($x847 (or false false (or $x499))))
(and (not $x847) (or $x847 (and (distinct (bvadd in.110_32 (_ bv1 32)) (bvadd in.110_32 (_ bv1 32))) true))))))
(check-sat)
; query 48: function susan_edges_small, block 461, name %462
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.18_32 () (_ BitVec 32))
(assert
 (let (($x1100 (and (distinct (bvadd ((_ sign_extend 1) in.18_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.18_32 (_ bv1 32)))) true)))
(let (($x326 (or false false (or $x1100))))
(and (not $x326) (or $x326 (and (distinct (bvadd in.18_32 (_ bv1 32)) (bvadd in.18_32 (_ bv1 32))) true))))))
(check-sat)
; query 49: function susan_principle, block 378, name %379
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x111 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x25 (or false false (or $x111))))
(and (not $x25) (or $x25 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 50: function susan_principle, block 381, name %382
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x44 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x34 (or false false (or $x44))))
(and (not $x34) (or $x34 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 51: function susan_principle_small, block 118, name %119
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x111 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x25 (or false false (or $x111))))
(and (not $x25) (or $x25 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 52: function susan_principle_small, block 121, name %122
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x44 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x34 (or false false (or $x44))))
(and (not $x34) (or $x34 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 53: function susan_smoothing, block 123, name %124
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.09_32 () (_ BitVec 32))
(assert
 (let (($x645 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in.09_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in.09_32))) true)))
(let (($x179 (or false false (or $x645))))
(and (not $x179) (or $x179 (and (distinct (bvsub (_ bv0 32) in.09_32) (bvsub (_ bv0 32) in.09_32)) true))))))
(check-sat)
; query 54: function susan_smoothing, block 143, name %144
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.016_32 () (_ BitVec 32))
(assert
 (let (($x170 (and (distinct (bvadd ((_ sign_extend 1) in.016_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.016_32 (_ bv1 32)))) true)))
(let (($x941 (or false false (or $x170))))
(and (not $x941) (or $x941 (and (distinct (bvadd in.016_32 (_ bv1 32)) (bvadd in.016_32 (_ bv1 32))) true))))))
(check-sat)
; query 55: function susan_smoothing, block 148, name %149
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.017_32 () (_ BitVec 32))
(assert
 (let (($x315 (and (distinct (bvadd ((_ sign_extend 1) in.017_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.017_32 (_ bv1 32)))) true)))
(let (($x440 (or false false (or $x315))))
(and (not $x440) (or $x440 (and (distinct (bvadd in.017_32 (_ bv1 32)) (bvadd in.017_32 (_ bv1 32))) true))))))
(check-sat)
; query 56: function susan_smoothing, block 150, name %151
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.018_32 () (_ BitVec 32))
(assert
 (let (($x145 (and (distinct (bvsub ((_ sign_extend 1) in.018_32) ((_ sign_extend 1) (_ bv10000 32))) ((_ sign_extend 1) (bvsub in.018_32 (_ bv10000 32)))) true)))
(let (($x212 (or false false (or $x145))))
(and (not $x212) (or $x212 (and (distinct (bvsub in.018_32 (_ bv10000 32)) (bvsub in.018_32 (_ bv10000 32))) true))))))
(check-sat)
; query 57: function susan_smoothing, block 150, name %152
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.018_32 () (_ BitVec 32))
(assert
 (let ((?x272 (ite (= (_ bv0 32) (bvsub in.018_32 (_ bv10000 32))) (_ bv1 1) (_ bv0 1))))
(let (($x145 (and (distinct (bvsub ((_ sign_extend 1) in.018_32) ((_ sign_extend 1) (_ bv10000 32))) ((_ sign_extend 1) (bvsub in.018_32 (_ bv10000 32)))) true)))
(let (($x212 (or false false (or $x145))))
(let (($x442 (or $x212 false false)))
(and (not $x442) (or $x442 (and (distinct ?x272 ?x272) true))))))))
(check-sat)
; query 58: function susan_smoothing, block 165, name %166
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.114_32 () (_ BitVec 32))
(assert
 (let (($x474 (and (distinct (bvadd ((_ sign_extend 1) in.114_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.114_32 (_ bv1 32)))) true)))
(let (($x794 (or false false (or $x474))))
(and (not $x794) (or $x794 (and (distinct (bvadd in.114_32 (_ bv1 32)) (bvadd in.114_32 (_ bv1 32))) true))))))
(check-sat)
; query 59: function susan_smoothing, block 168, name %169
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.111_32 () (_ BitVec 32))
(assert
 (let (($x573 (and (distinct (bvadd ((_ sign_extend 1) in.111_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.111_32 (_ bv1 32)))) true)))
(let (($x385 (or false false (or $x573))))
(and (not $x385) (or $x385 (and (distinct (bvadd in.111_32 (_ bv1 32)) (bvadd in.111_32 (_ bv1 32))) true))))))
(check-sat)
; query 60: function susan_smoothing, block 21, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x784 (ite (= (_ bv0 32) (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x152 (or false false false)))
(let (($x365 (not $x152)))
(and $x365 (or $x152 (and (distinct ?x784 ?x784) true)))))))
(check-sat)
; query 61: function susan_smoothing, block 319, name %320
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.215_32 () (_ BitVec 32))
(assert
 (let (($x491 (and (distinct (bvadd ((_ sign_extend 1) in.215_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.215_32 (_ bv1 32)))) true)))
(let (($x228 (or false false (or $x491))))
(and (not $x228) (or $x228 (and (distinct (bvadd in.215_32 (_ bv1 32)) (bvadd in.215_32 (_ bv1 32))) true))))))
(check-sat)
; query 62: function susan_smoothing, block 322, name %323
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.212_32 () (_ BitVec 32))
(assert
 (let (($x169 (and (distinct (bvadd ((_ sign_extend 1) in.212_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.212_32 (_ bv1 32)))) true)))
(let (($x346 (or false false (or $x169))))
(and (not $x346) (or $x346 (and (distinct (bvadd in.212_32 (_ bv1 32)) (bvadd in.212_32 (_ bv1 32))) true))))))
(check-sat)
; query 63: function susan_smoothing, block 67, name %68
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.09_32 () (_ BitVec 32))
(assert
 (let (($x645 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in.09_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in.09_32))) true)))
(let (($x179 (or false false (or $x645))))
(and (not $x179) (or $x179 (and (distinct (bvsub (_ bv0 32) in.09_32) (bvsub (_ bv0 32) in.09_32)) true))))))
(check-sat)
; query 64: function susan_smoothing, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.013_32 () (_ BitVec 32))
(assert
 (let (($x393 (and (distinct (bvadd ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.013_32 (_ bv1 32)))) true)))
(let (($x278 (or false false (or $x393))))
(and (not $x278) (or $x278 (and (distinct (bvadd in.013_32 (_ bv1 32)) (bvadd in.013_32 (_ bv1 32))) true))))))
(check-sat)
; query 65: function susan_smoothing, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.010_32 () (_ BitVec 32))
(assert
 (let (($x360 (and (distinct (bvadd ((_ sign_extend 1) in.010_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.010_32 (_ bv1 32)))) true)))
(let (($x595 (or false false (or $x360))))
(and (not $x595) (or $x595 (and (distinct (bvadd in.010_32 (_ bv1 32)) (bvadd in.010_32 (_ bv1 32))) true))))))
(check-sat)
; query 66: function susan_thin, block 100, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in93_32 () (_ BitVec 32))
(assert
 (let ((?x387 (ite (= (_ bv1 32) in93_32) (_ bv1 1) (_ bv0 1))))
(let (($x152 (or false false false)))
(let (($x365 (not $x152)))
(and $x365 (or $x152 (and (distinct ?x387 ?x387) true)))))))
(check-sat)
; query 67: function susan_thin, block 428, name %429
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.022_32 () (_ BitVec 32))
(assert
 (let (($x699 (and (distinct (bvadd ((_ sign_extend 1) in.022_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.022_32 (_ bv1 32)))) true)))
(let (($x425 (or false false (or $x699))))
(and (not $x425) (or $x425 (and (distinct (bvadd in.022_32 (_ bv1 32)) (bvadd in.022_32 (_ bv1 32))) true))))))
(check-sat)
; query 68: function susan_thin, block 431, name %432
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.018_32 () (_ BitVec 32))
(assert
 (let (($x218 (and (distinct (bvadd ((_ sign_extend 1) in.018_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.018_32 (_ bv1 32)))) true)))
(let (($x353 (or false false (or $x218))))
(and (not $x353) (or $x353 (and (distinct (bvadd in.018_32 (_ bv1 32)) (bvadd in.018_32 (_ bv1 32))) true))))))
(check-sat)
; query 69: function susan_thin, block 433, name %434
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.040_32 () (_ BitVec 32))
(assert
 (let ((?x417 (ite (bvslt (_ bv0 32) in.040_32) (_ bv1 1) (_ bv0 1))))
(let (($x152 (or false false false)))
(let (($x365 (not $x152)))
(and $x365 (or $x152 (and (distinct ?x417 ?x417) true)))))))
(check-sat)
; query 70: function susan_thin, block 469, name %470
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.235_32 () (_ BitVec 32))
(assert
 (let ((?x412 (bvadd in.235_32 in.235_32)))
(let ((?x621 ((_ sign_extend 1) ?x412)))
(let (($x428 (and (distinct (bvadd ((_ sign_extend 1) in.235_32) ((_ sign_extend 1) in.235_32)) ?x621) true)))
(let (($x1023 (or false false (or $x428))))
(and (not $x1023) (or $x1023 (and (distinct ?x412 ?x412) true))))))))
(check-sat)
; query 71: function susan_thin, block 469, name %471
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.228_32 () (_ BitVec 32))
(declare-fun in.235_32 () (_ BitVec 32))
(assert
 (let ((?x412 (bvadd in.235_32 in.235_32)))
(let ((?x550 (bvadd ?x412 in.228_32)))
(let (($x651 (and (distinct (bvadd ((_ sign_extend 1) ?x412) ((_ sign_extend 1) in.228_32)) ((_ sign_extend 1) ?x550)) true)))
(let ((?x621 ((_ sign_extend 1) ?x412)))
(let (($x428 (and (distinct (bvadd ((_ sign_extend 1) in.235_32) ((_ sign_extend 1) in.235_32)) ?x621) true)))
(let (($x1023 (or false false (or $x428))))
(let (($x331 (or $x1023 false (or $x651))))
(and (not $x331) (or $x331 (and (distinct ?x550 ?x550) true)))))))))))
(check-sat)
; query 72: function susan_thin, block 469, name %472
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.228_32 () (_ BitVec 32))
(declare-fun in.235_32 () (_ BitVec 32))
(assert
 (let ((?x666 (ite (bvsgt (_ bv3 32) (bvadd (bvadd in.235_32 in.235_32) in.228_32)) (_ bv1 1) (_ bv0 1))))
(let ((?x703 ((_ sign_extend 1) in.228_32)))
(let ((?x412 (bvadd in.235_32 in.235_32)))
(let ((?x621 ((_ sign_extend 1) ?x412)))
(let (($x70 (or (and (distinct (bvadd ?x621 ?x703) ((_ sign_extend 1) (bvadd ?x412 in.228_32))) true))))
(let (($x428 (and (distinct (bvadd ((_ sign_extend 1) in.235_32) ((_ sign_extend 1) in.235_32)) ?x621) true)))
(let (($x1023 (or false false (or $x428))))
(let (($x331 (or $x1023 false $x70)))
(let (($x281 (or $x331 false false)))
(and (not $x281) (or $x281 (and (distinct ?x666 ?x666) true)))))))))))))
(check-sat)
; query 73: function susan_thin, block 473, name %474
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.235_32 () (_ BitVec 32))
(assert
 (let ((?x181 (bvsub in.235_32 (_ bv1 32))))
(let ((?x577 ((_ sign_extend 1) ?x181)))
(let (($x349 (or (and (distinct (bvsub ((_ sign_extend 1) in.235_32) ((_ sign_extend 1) (_ bv1 32))) ?x577) true))))
(let (($x551 (or false false $x349)))
(and (not $x551) (or $x551 (and (distinct ?x181 ?x181) true))))))))
(check-sat)
; query 74: function susan_thin, block 473, name %475
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.235_32 () (_ BitVec 32))
(declare-fun in.14_32 () (_ BitVec 32))
(assert
 (let ((?x181 (bvsub in.235_32 (_ bv1 32))))
(let ((?x402 (bvadd in.14_32 ?x181)))
(let (($x796 (and (distinct (bvadd ((_ sign_extend 1) in.14_32) ((_ sign_extend 1) ?x181)) ((_ sign_extend 1) ?x402)) true)))
(let ((?x577 ((_ sign_extend 1) ?x181)))
(let (($x349 (or (and (distinct (bvsub ((_ sign_extend 1) in.235_32) ((_ sign_extend 1) (_ bv1 32))) ?x577) true))))
(let (($x551 (or false false $x349)))
(let (($x58 (or false $x551 (or $x796))))
(and (not $x58) (or $x58 (and (distinct ?x402 ?x402) true)))))))))))
(check-sat)
; query 75: function susan_thin, block 473, name %476
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.228_32 () (_ BitVec 32))
(assert
 (let ((?x210 (bvsub in.228_32 (_ bv2 32))))
(let ((?x178 ((_ sign_extend 1) ?x210)))
(let (($x754 (or (and (distinct (bvsub ((_ sign_extend 1) in.228_32) ((_ sign_extend 1) (_ bv2 32))) ?x178) true))))
(let (($x492 (or false false $x754)))
(and (not $x492) (or $x492 (and (distinct ?x210 ?x210) true))))))))
(check-sat)
; query 76: function susan_thin, block 473, name %477
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.228_32 () (_ BitVec 32))
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x210 (bvsub in.228_32 (_ bv2 32))))
(let ((?x282 (bvadd in.0_32 ?x210)))
(let (($x290 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) ?x210)) ((_ sign_extend 1) ?x282)) true)))
(let ((?x178 ((_ sign_extend 1) ?x210)))
(let (($x754 (or (and (distinct (bvsub ((_ sign_extend 1) in.228_32) ((_ sign_extend 1) (_ bv2 32))) ?x178) true))))
(let (($x492 (or false false $x754)))
(let (($x324 (or false $x492 (or $x290))))
(and (not $x324) (or $x324 (and (distinct ?x282 ?x282) true)))))))))))
(check-sat)
; query 77: function susan_thin, block 473, name %478
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.235_32 () (_ BitVec 32))
(declare-fun in.14_32 () (_ BitVec 32))
(assert
 (let ((?x486 (ite (bvsgt (_ bv4 32) (bvadd in.14_32 (bvsub in.235_32 (_ bv1 32)))) (_ bv1 1) (_ bv0 1))))
(let (($x796 (and (distinct (bvadd ((_ sign_extend 1) in.14_32) ((_ sign_extend 1) (bvsub in.235_32 (_ bv1 32)))) ((_ sign_extend 1) (bvadd in.14_32 (bvsub in.235_32 (_ bv1 32))))) true)))
(let ((?x181 (bvsub in.235_32 (_ bv1 32))))
(let ((?x577 ((_ sign_extend 1) ?x181)))
(let (($x349 (or (and (distinct (bvsub ((_ sign_extend 1) in.235_32) ((_ sign_extend 1) (_ bv1 32))) ?x577) true))))
(let (($x551 (or false false $x349)))
(let (($x58 (or false $x551 (or $x796))))
(let (($x460 (or $x58 false false)))
(and (not $x460) (or $x460 (and (distinct ?x486 ?x486) true))))))))))))
(check-sat)
; query 78: function susan_thin, block 533, name %534
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in528_32 () (_ BitVec 32))
(declare-fun in498_32 () (_ BitVec 32))
(assert
 (let (($x152 (or false false false)))
(let (($x168 (or $x152 (and (distinct (bvor in498_32 in528_32) (bvor in498_32 in528_32)) true))))
(let (($x365 (not $x152)))
(and $x365 $x168)))))
(check-sat)
; query 79: function susan_thin, block 533, name %535
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in518_32 () (_ BitVec 32))
(declare-fun in508_32 () (_ BitVec 32))
(assert
 (let (($x152 (or false false false)))
(let (($x351 (or $x152 (and (distinct (bvor in508_32 in518_32) (bvor in508_32 in518_32)) true))))
(let (($x365 (not $x152)))
(and $x365 $x351)))))
(check-sat)
; query 80: function susan_thin, block 533, name %536
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in518_32 () (_ BitVec 32))
(declare-fun in508_32 () (_ BitVec 32))
(declare-fun in528_32 () (_ BitVec 32))
(declare-fun in498_32 () (_ BitVec 32))
(assert
 (let ((?x381 (bvor in508_32 in518_32)))
(let ((?x348 (bvor in498_32 in528_32)))
(let ((?x275 (bvand ?x348 ?x381)))
(let (($x152 (or false false false)))
(let (($x633 (or $x152 $x152 false)))
(let (($x679 (not $x633)))
(and $x679 (or $x633 (and (distinct ?x275 ?x275) true))))))))))
(check-sat)
; query 81: function susan_thin, block 533, name %537
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in518_32 () (_ BitVec 32))
(declare-fun in508_32 () (_ BitVec 32))
(declare-fun in528_32 () (_ BitVec 32))
(declare-fun in498_32 () (_ BitVec 32))
(assert
 (let ((?x381 (bvor in508_32 in518_32)))
(let ((?x348 (bvor in498_32 in528_32)))
(let ((?x275 (bvand ?x348 ?x381)))
(let ((?x728 (ite (and (distinct (_ bv0 32) ?x275) true) (_ bv1 1) (_ bv0 1))))
(let (($x152 (or false false false)))
(let (($x633 (or $x152 $x152 false)))
(let (($x182 (or $x633 false false)))
(let (($x541 (not $x182)))
(and $x541 (or $x182 (and (distinct ?x728 ?x728) true))))))))))))
(check-sat)
; query 82: function susan_thin, block 538, name %539
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in498_32 () (_ BitVec 32))
(assert
 (let ((?x300 (ite (and (distinct (_ bv0 32) in498_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x152 (or false false false)))
(let (($x365 (not $x152)))
(and $x365 (or $x152 (and (distinct ?x300 ?x300) true)))))))
(check-sat)
; query 83: function susan_thin, block 540, name %541
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in508_32 () (_ BitVec 32))
(assert
 (let ((?x893 (ite (and (distinct (_ bv0 32) in508_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x152 (or false false false)))
(let (($x365 (not $x152)))
(and $x365 (or $x152 (and (distinct ?x893 ?x893) true)))))))
(check-sat)
; query 84: function susan_thin, block 545, name %546
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in508_32 () (_ BitVec 32))
(assert
 (let ((?x893 (ite (and (distinct (_ bv0 32) in508_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x152 (or false false false)))
(let (($x365 (not $x152)))
(and $x365 (or $x152 (and (distinct ?x893 ?x893) true)))))))
(check-sat)
; query 85: function susan_thin, block 563, name %564
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.325_32 () (_ BitVec 32))
(assert
 (let ((?x821 (ite (= (_ bv0 32) in.325_32) (_ bv1 1) (_ bv0 1))))
(let (($x152 (or false false false)))
(let (($x365 (not $x152)))
(and $x365 (or $x152 (and (distinct ?x821 ?x821) true)))))))
(check-sat)
; query 86: function susan_thin, block 597, name %598
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.321_32 () (_ BitVec 32))
(assert
 (let ((?x431 (ite (= (_ bv0 32) in.321_32) (_ bv1 1) (_ bv0 1))))
(let (($x152 (or false false false)))
(let (($x365 (not $x152)))
(and $x365 (or $x152 (and (distinct ?x431 ?x431) true)))))))
(check-sat)
; query 87: function susan_thin, block 685, name %686
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in662_32 () (_ BitVec 32))
(declare-fun in680_32 () (_ BitVec 32))
(assert
 (let (($x152 (or false false false)))
(let (($x714 (or $x152 (and (distinct (bvor in680_32 in662_32) (bvor in680_32 in662_32)) true))))
(let (($x365 (not $x152)))
(and $x365 $x714)))))
(check-sat)
; query 88: function susan_thin, block 685, name %687
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in671_32 () (_ BitVec 32))
(declare-fun in653_32 () (_ BitVec 32))
(assert
 (let (($x152 (or false false false)))
(let (($x813 (or $x152 (and (distinct (bvor in653_32 in671_32) (bvor in653_32 in671_32)) true))))
(let (($x365 (not $x152)))
(and $x365 $x813)))))
(check-sat)
; query 89: function susan_thin, block 685, name %688
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in671_32 () (_ BitVec 32))
(declare-fun in653_32 () (_ BitVec 32))
(declare-fun in662_32 () (_ BitVec 32))
(declare-fun in680_32 () (_ BitVec 32))
(assert
 (let ((?x579 (bvor in653_32 in671_32)))
(let ((?x161 (bvor in680_32 in662_32)))
(let ((?x572 (bvand ?x161 ?x579)))
(let (($x152 (or false false false)))
(let (($x633 (or $x152 $x152 false)))
(let (($x679 (not $x633)))
(and $x679 (or $x633 (and (distinct ?x572 ?x572) true))))))))))
(check-sat)
; query 90: function susan_thin, block 685, name %689
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in671_32 () (_ BitVec 32))
(declare-fun in653_32 () (_ BitVec 32))
(declare-fun in662_32 () (_ BitVec 32))
(declare-fun in680_32 () (_ BitVec 32))
(assert
 (let ((?x579 (bvor in653_32 in671_32)))
(let ((?x161 (bvor in680_32 in662_32)))
(let ((?x572 (bvand ?x161 ?x579)))
(let ((?x265 (ite (and (distinct (_ bv0 32) ?x572) true) (_ bv1 1) (_ bv0 1))))
(let (($x152 (or false false false)))
(let (($x633 (or $x152 $x152 false)))
(let (($x182 (or $x633 false false)))
(let (($x541 (not $x182)))
(and $x541 (or $x182 (and (distinct ?x265 ?x265) true))))))))))))
(check-sat)
; query 91: function susan_thin, block 915, name %916
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.13_32 () (_ BitVec 32))
(assert
 (let (($x594 (and (distinct (bvadd ((_ sign_extend 1) in.13_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.13_32 (_ bv1 32)))) true)))
(let (($x1006 (or false false (or $x594))))
(and (not $x1006) (or $x1006 (and (distinct (bvadd in.13_32 (_ bv1 32)) (bvadd in.13_32 (_ bv1 32))) true))))))
(check-sat)
; query 92: function susan_thin, block 918, name %919
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.14_32 () (_ BitVec 32))
(assert
 (let (($x75 (and (distinct (bvadd ((_ sign_extend 1) in.14_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.14_32 (_ bv1 32)))) true)))
(let (($x68 (or false false (or $x75))))
(and (not $x68) (or $x68 (and (distinct (bvadd in.14_32 (_ bv1 32)) (bvadd in.14_32 (_ bv1 32))) true))))))
(check-sat)
