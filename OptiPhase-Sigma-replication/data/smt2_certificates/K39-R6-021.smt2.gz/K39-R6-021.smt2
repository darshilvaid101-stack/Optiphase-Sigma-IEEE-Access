; OptiPhase-Sigma refinement certificate for sweep K39-R6-021
