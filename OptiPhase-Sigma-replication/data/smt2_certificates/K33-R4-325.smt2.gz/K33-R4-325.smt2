; OptiPhase-Sigma refinement certificate for sweep K33-R4-325
; query 0: function edge_draw, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let ((?x292 (ite (= (_ bv0 32) in4_32) (_ bv1 1) (_ bv0 1))))
(let (($x37 (or false false false)))
(and (not $x37) (or $x37 (and (distinct ?x292 ?x292) true))))))
(check-sat)
