; OptiPhase-Sigma refinement certificate for sweep K57-R2-080
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x347 (or false false)))
(let (($x3115 (not $x347)))
(and $x3115 (or $x347 (and (distinct ((_ sign_extend 16) in25_16) ((_ sign_extend 16) in25_16)) true))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let ((?x3662 (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))))
(let (($x347 (or false false)))
(let (($x290 (or $x347 false false)))
(let (($x89 (not $x290)))
(and $x89 (or $x290 (and (distinct ?x3662 ?x3662) true))))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x347 (or false false)))
(let (($x3115 (not $x347)))
(and $x3115 (or $x347 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x728 ((_ sign_extend 16) in3_16)))
(let ((?x365 (bvand ?x728 (_ bv127 32))))
(let (($x347 (or false false)))
(let (($x290 (or $x347 false false)))
(let (($x89 (not $x290)))
(and $x89 (or $x290 (and (distinct ?x365 ?x365) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x728 ((_ sign_extend 16) in3_16)))
(let ((?x365 (bvand ?x728 (_ bv127 32))))
(let ((?x2369 ((_ extract 15 0) ?x365)))
(let (($x347 (or false false)))
(let (($x290 (or $x347 false false)))
(let (($x244 (or $x290 false)))
(let (($x3117 (not $x244)))
(and $x3117 (or $x244 (and (distinct ?x2369 ?x2369) true)))))))))))
(check-sat)
; query 5: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x347 (or false false)))
(let (($x3115 (not $x347)))
(and $x3115 (or $x347 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 6: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x3383 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x347 (or false false)))
(let (($x290 (or $x347 false false)))
(let (($x89 (not $x290)))
(and $x89 (or $x290 (and (distinct ?x3383 ?x3383) true))))))))
(check-sat)
; query 7: function core_bench_list, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x385 (or false false false)))
(let (($x183 (not $x385)))
(and $x183 (or $x385 (and (distinct (bvadd in.0_16 (_ bv1 16)) (bvadd in.0_16 (_ bv1 16))) true))))))
(check-sat)
; query 8: function core_bench_state, block 105, name %106
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x385 (or false false false)))
(let (($x183 (not $x385)))
(and $x183 (or $x385 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 9: function core_bench_state, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x385 (or false false false)))
(let (($x183 (not $x385)))
(and $x183 (or $x385 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 10: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x494 (bvadd in.01_32 (_ bv1 32))))
(let (($x876 (and (distinct ?x494 ?x494) true)))
(let (($x385 (or false false false)))
(let (($x183 (not $x385)))
(and $x183 (or $x385 $x876)))))))
(check-sat)
; query 11: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x494 (bvadd in.01_32 (_ bv1 32))))
(let ((?x443 (bvmul ?x494 ?x494)))
(let (($x385 (or false false false)))
(let (($x52 (or $x385 $x385 false)))
(and (not $x52) (or $x52 (and (distinct ?x443 ?x443) true))))))))
(check-sat)
; query 12: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x494 (bvadd in.01_32 (_ bv1 32))))
(let ((?x443 (bvmul ?x494 ?x494)))
(let ((?x779 (bvmul ?x443 (_ bv2 32))))
(let (($x385 (or false false false)))
(let (($x52 (or $x385 $x385 false)))
(let (($x746 (or $x52 false false)))
(and (not $x746) (or $x746 (and (distinct ?x779 ?x779) true))))))))))
(check-sat)
; query 13: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x494 (bvadd in.01_32 (_ bv1 32))))
(let ((?x443 (bvmul ?x494 ?x494)))
(let ((?x779 (bvmul ?x443 (_ bv2 32))))
(let ((?x56 (bvmul ?x779 (_ bv4 32))))
(let (($x385 (or false false false)))
(let (($x52 (or $x385 $x385 false)))
(let (($x746 (or $x52 false false)))
(let (($x76 (or $x746 false false)))
(and (not $x76) (or $x76 (and (distinct ?x56 ?x56) true))))))))))))
(check-sat)
; query 14: function core_init_matrix, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x385 (or false false false)))
(let (($x183 (not $x385)))
(and $x183 (or $x385 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 15: function core_init_matrix, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x385 (or false false false)))
(let (($x183 (not $x385)))
(and $x183 (or $x385 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 16: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x146 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x385 (or false false false)))
(let (($x183 (not $x385)))
(and $x183 (or $x385 (and (distinct ?x146 ?x146) true)))))))
(check-sat)
; query 17: function core_init_state, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_32 () (_ BitVec 32))
(assert
 (let (($x385 (or false false false)))
(let (($x183 (not $x385)))
(and $x183 (or $x385 (and (distinct (bvadd in.06_32 (_ bv1 32)) (bvadd in.06_32 (_ bv1 32))) true))))))
(check-sat)
; query 18: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x451 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x385 (or false false false)))
(let (($x183 (not $x385)))
(and $x183 (or $x385 (and (distinct ?x451 ?x451) true)))))))
(check-sat)
; query 19: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x385 (or false false false)))
(let (($x183 (not $x385)))
(and $x183 (or $x385 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 20: function core_list_init, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x494 (bvadd in.01_32 (_ bv1 32))))
(let (($x876 (and (distinct ?x494 ?x494) true)))
(let (($x385 (or false false false)))
(let (($x183 (not $x385)))
(and $x183 (or $x385 $x876)))))))
(check-sat)
; query 21: function core_list_mergesort, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x494 (bvadd in.01_32 (_ bv1 32))))
(let (($x876 (and (distinct ?x494 ?x494) true)))
(let (($x730 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x494)) true)))
(let (($x29 (or false false (or $x730))))
(and (not $x29) (or $x29 $x876)))))))
(check-sat)
; query 22: function core_list_mergesort, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x598 (ite (bvslt (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x385 (or false false false)))
(let (($x183 (not $x385)))
(and $x183 (or $x385 (and (distinct ?x598 ?x598) true)))))))
(check-sat)
; query 23: function core_list_mergesort, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.224_32 () (_ BitVec 32))
(assert
 (let ((?x476 (ite (= (_ bv0 32) in.224_32) (_ bv1 1) (_ bv0 1))))
(let (($x385 (or false false false)))
(let (($x183 (not $x385)))
(and $x183 (or $x385 (and (distinct ?x476 ?x476) true)))))))
(check-sat)
; query 24: function core_list_mergesort, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x119 (ite (= (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x385 (or false false false)))
(let (($x183 (not $x385)))
(and $x183 (or $x385 (and (distinct ?x119 ?x119) true)))))))
(check-sat)
; query 25: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x83 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x134 (or false false (or $x83))))
(and (not $x134) (or $x134 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 26: function core_list_mergesort, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x547 (and (distinct (bvmul ((_ sign_extend 32) in.020_32) ((_ sign_extend 32) (_ bv2 32))) ((_ sign_extend 32) (bvmul in.020_32 (_ bv2 32)))) true)))
(let (($x6 (or false false (or $x547))))
(and (not $x6) (or $x6 (and (distinct (bvmul in.020_32 (_ bv2 32)) (bvmul in.020_32 (_ bv2 32))) true))))))
(check-sat)
; query 27: function core_state_transition, block 102, name %103
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x347 (or false false)))
(let (($x3115 (not $x347)))
(and $x3115 (or $x347 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 28: function core_state_transition, block 102, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x225 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x347 (or false false)))
(let (($x290 (or $x347 false false)))
(let (($x89 (not $x290)))
(and $x89 (or $x290 (and (distinct ?x225 ?x225) true))))))))
(check-sat)
; query 29: function core_state_transition, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x347 (or false false)))
(let (($x3115 (not $x347)))
(and $x3115 (or $x347 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 30: function core_state_transition, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x655 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x347 (or false false)))
(let (($x290 (or $x347 false false)))
(let (($x89 (not $x290)))
(and $x89 (or $x290 (and (distinct ?x655 ?x655) true))))))))
(check-sat)
; query 31: function core_state_transition, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x347 (or false false)))
(let (($x3115 (not $x347)))
(and $x3115 (or $x347 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 32: function core_state_transition, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x225 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x347 (or false false)))
(let (($x290 (or $x347 false false)))
(let (($x89 (not $x290)))
(and $x89 (or $x290 (and (distinct ?x225 ?x225) true))))))))
(check-sat)
; query 33: function core_state_transition, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x347 (or false false)))
(let (($x3115 (not $x347)))
(and $x3115 (or $x347 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 34: function core_state_transition, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x574 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x347 (or false false)))
(let (($x290 (or $x347 false false)))
(let (($x89 (not $x290)))
(and $x89 (or $x290 (and (distinct ?x574 ?x574) true))))))))
(check-sat)
; query 35: function core_state_transition, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x347 (or false false)))
(let (($x3115 (not $x347)))
(and $x3115 (or $x347 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 36: function core_state_transition, block 51, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x574 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x347 (or false false)))
(let (($x290 (or $x347 false false)))
(let (($x89 (not $x290)))
(and $x89 (or $x290 (and (distinct ?x574 ?x574) true))))))))
(check-sat)
; query 37: function core_state_transition, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x347 (or false false)))
(let (($x3115 (not $x347)))
(and $x3115 (or $x347 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 38: function core_state_transition, block 64, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x574 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x347 (or false false)))
(let (($x290 (or $x347 false false)))
(let (($x89 (not $x290)))
(and $x89 (or $x290 (and (distinct ?x574 ?x574) true))))))))
(check-sat)
; query 39: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x3124 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x385 (or false false false)))
(let (($x183 (not $x385)))
(and $x183 (or $x385 (and (distinct ?x3124 ?x3124) true)))))))
(check-sat)
; query 40: function core_state_transition, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x347 (or false false)))
(let (($x3115 (not $x347)))
(and $x3115 (or $x347 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 41: function core_state_transition, block 80, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x2843 (ite (= (_ bv69 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x347 (or false false)))
(let (($x290 (or $x347 false false)))
(let (($x89 (not $x290)))
(and $x89 (or $x290 (and (distinct ?x2843 ?x2843) true))))))))
(check-sat)
; query 42: function core_state_transition, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x347 (or false false)))
(let (($x3115 (not $x347)))
(and $x3115 (or $x347 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 43: function core_state_transition, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x3329 (ite (= (_ bv101 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x347 (or false false)))
(let (($x290 (or $x347 false false)))
(let (($x89 (not $x290)))
(and $x89 (or $x290 (and (distinct ?x3329 ?x3329) true))))))))
(check-sat)
; query 44: function core_state_transition, block 99, name %100
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x347 (or false false)))
(let (($x3115 (not $x347)))
(and $x3115 (or $x347 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 45: function core_state_transition, block 99, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x655 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x347 (or false false)))
(let (($x290 (or $x347 false false)))
(let (($x89 (not $x290)))
(and $x89 (or $x290 (and (distinct ?x655 ?x655) true))))))))
(check-sat)
; query 46: function crcu8, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x347 (or false false)))
(let (($x3115 (not $x347)))
(and $x3115 (or $x347 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 47: function crcu8, block 19, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x947 ((_ zero_extend 16) in.01_16)))
(let ((?x593 (bvxor ?x947 (_ bv16386 32))))
(let (($x347 (or false false)))
(let (($x290 (or $x347 false false)))
(let (($x89 (not $x290)))
(and $x89 (or $x290 (and (distinct ?x593 ?x593) true)))))))))
(check-sat)
; query 48: function crcu8, block 19, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x947 ((_ zero_extend 16) in.01_16)))
(let ((?x593 (bvxor ?x947 (_ bv16386 32))))
(let ((?x3641 ((_ extract 15 0) ?x593)))
(let (($x347 (or false false)))
(let (($x290 (or $x347 false false)))
(let (($x244 (or $x290 false)))
(let (($x3117 (not $x244)))
(and $x3117 (or $x244 (and (distinct ?x3641 ?x3641) true)))))))))))
(check-sat)
; query 49: function crcu8, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x347 (or false false)))
(let (($x3115 (not $x347)))
(and $x3115 (or $x347 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 50: function crcu8, block 29, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x3933 ((_ zero_extend 16) in27_16)))
(let ((?x3656 (bvor ?x3933 (_ bv32768 32))))
(let (($x347 (or false false)))
(let (($x290 (or $x347 false false)))
(let (($x89 (not $x290)))
(and $x89 (or $x290 (and (distinct ?x3656 ?x3656) true)))))))))
(check-sat)
; query 51: function crcu8, block 29, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x3933 ((_ zero_extend 16) in27_16)))
(let ((?x3656 (bvor ?x3933 (_ bv32768 32))))
(let ((?x3657 ((_ extract 15 0) ?x3656)))
(let (($x347 (or false false)))
(let (($x290 (or $x347 false false)))
(let (($x244 (or $x290 false)))
(let (($x3117 (not $x244)))
(and $x3117 (or $x244 (and (distinct ?x3657 ?x3657) true)))))))))))
(check-sat)
; query 52: function crcu8, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x347 (or false false)))
(let (($x3115 (not $x347)))
(and $x3115 (or $x347 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 53: function crcu8, block 33, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x3933 ((_ zero_extend 16) in27_16)))
(let ((?x3374 (bvand ?x3933 (_ bv32767 32))))
(let (($x347 (or false false)))
(let (($x290 (or $x347 false false)))
(let (($x89 (not $x290)))
(and $x89 (or $x290 (and (distinct ?x3374 ?x3374) true)))))))))
(check-sat)
; query 54: function crcu8, block 33, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x3933 ((_ zero_extend 16) in27_16)))
(let ((?x3374 (bvand ?x3933 (_ bv32767 32))))
(let ((?x3093 ((_ extract 15 0) ?x3374)))
(let (($x347 (or false false)))
(let (($x290 (or $x347 false false)))
(let (($x244 (or $x290 false)))
(let (($x3117 (not $x244)))
(and $x3117 (or $x244 (and (distinct ?x3093 ?x3093) true)))))))))))
(check-sat)
; query 55: function crcu8, block 38, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_8 () (_ BitVec 8))
(assert
 (let (($x385 (or false false false)))
(let (($x183 (not $x385)))
(and $x183 (or $x385 (and (distinct (bvadd in.02_8 (_ bv1 8)) (bvadd in.02_8 (_ bv1 8))) true))))))
(check-sat)
; query 56: function crcu8, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x2386 ((_ extract 7 0) in.01_16)))
(let ((?x3375 ((_ zero_extend 24) ?x2386)))
(let (($x347 (or false false)))
(let (($x2161 (or $x347 false)))
(and (not $x2161) (or $x2161 (and (distinct ?x3375 ?x3375) true))))))))
(check-sat)
; query 57: function crcu8, block 6, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x2386 ((_ extract 7 0) in.01_16)))
(let ((?x3375 ((_ zero_extend 24) ?x2386)))
(let ((?x314 (bvand ?x3375 (_ bv1 32))))
(let (($x347 (or false false)))
(let (($x2161 (or $x347 false)))
(let (($x2163 (or $x2161 false false)))
(and (not $x2163) (or $x2163 (and (distinct ?x314 ?x314) true))))))))))
(check-sat)
; query 58: function crcu8, block 6, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x2386 ((_ extract 7 0) in.01_16)))
(let ((?x3375 ((_ zero_extend 24) ?x2386)))
(let ((?x314 (bvand ?x3375 (_ bv1 32))))
(let ((?x2388 ((_ zero_extend 24) in.0_8)))
(let ((?x517 (bvand ?x2388 (_ bv1 32))))
(let ((?x2387 (bvxor ?x517 ?x314)))
(let (($x347 (or false false)))
(let (($x2161 (or $x347 false)))
(let (($x2163 (or $x2161 false false)))
(let (($x290 (or $x347 false false)))
(let (($x2385 (or $x290 $x2163 false)))
(and (not $x2385) (or $x2385 (and (distinct ?x2387 ?x2387) true)))))))))))))))
(check-sat)
; query 59: function crcu8, block 6, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x2386 ((_ extract 7 0) in.01_16)))
(let ((?x3375 ((_ zero_extend 24) ?x2386)))
(let ((?x314 (bvand ?x3375 (_ bv1 32))))
(let ((?x2388 ((_ zero_extend 24) in.0_8)))
(let ((?x517 (bvand ?x2388 (_ bv1 32))))
(let ((?x2387 (bvxor ?x517 ?x314)))
(let ((?x2389 ((_ extract 7 0) ?x2387)))
(let (($x347 (or false false)))
(let (($x2161 (or $x347 false)))
(let (($x2163 (or $x2161 false false)))
(let (($x290 (or $x347 false false)))
(let (($x2385 (or $x290 $x2163 false)))
(let (($x2390 (or $x2385 false)))
(and (not $x2390) (or $x2390 (and (distinct ?x2389 ?x2389) true)))))))))))))))))
(check-sat)
; query 60: function crcu8, block 6, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x347 (or false false)))
(let (($x3115 (not $x347)))
(and $x3115 (or $x347 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 61: function crcu8, block 6, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x2388 ((_ zero_extend 24) in.0_8)))
(let ((?x635 (bvashr ?x2388 (_ bv1 32))))
(let (($x347 (or false false)))
(let (($x290 (or $x347 false false)))
(let (($x3381 (or $x290 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not $x3381) (or $x3381 (and (distinct ?x635 ?x635) true)))))))))
(check-sat)
; query 62: function crcu8, block 6, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x2388 ((_ zero_extend 24) in.0_8)))
(let ((?x635 (bvashr ?x2388 (_ bv1 32))))
(let ((?x1957 ((_ extract 7 0) ?x635)))
(let (($x347 (or false false)))
(let (($x290 (or $x347 false false)))
(let (($x3381 (or $x290 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x2170 (or $x3381 false)))
(and (not $x2170) (or $x2170 (and (distinct ?x1957 ?x1957) true)))))))))))
(check-sat)
; query 63: function crcu8, block 6, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x2386 ((_ extract 7 0) in.01_16)))
(let ((?x3375 ((_ zero_extend 24) ?x2386)))
(let ((?x314 (bvand ?x3375 (_ bv1 32))))
(let ((?x2388 ((_ zero_extend 24) in.0_8)))
(let ((?x517 (bvand ?x2388 (_ bv1 32))))
(let ((?x2387 (bvxor ?x517 ?x314)))
(let ((?x2389 ((_ extract 7 0) ?x2387)))
(let ((?x1950 ((_ zero_extend 24) ?x2389)))
(let (($x347 (or false false)))
(let (($x2161 (or $x347 false)))
(let (($x2163 (or $x2161 false false)))
(let (($x290 (or $x347 false false)))
(let (($x2385 (or $x290 $x2163 false)))
(let (($x2390 (or $x2385 false)))
(let (($x3382 (or $x2390 false)))
(and (not $x3382) (or $x3382 (and (distinct ?x1950 ?x1950) true)))))))))))))))))))
(check-sat)
; query 64: function crcu8, block 6, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x2386 ((_ extract 7 0) in.01_16)))
(let ((?x3375 ((_ zero_extend 24) ?x2386)))
(let ((?x314 (bvand ?x3375 (_ bv1 32))))
(let ((?x2388 ((_ zero_extend 24) in.0_8)))
(let ((?x517 (bvand ?x2388 (_ bv1 32))))
(let ((?x2387 (bvxor ?x517 ?x314)))
(let ((?x2389 ((_ extract 7 0) ?x2387)))
(let ((?x1950 ((_ zero_extend 24) ?x2389)))
(let ((?x2171 (ite (= (_ bv1 32) ?x1950) (_ bv1 1) (_ bv0 1))))
(let (($x347 (or false false)))
(let (($x2161 (or $x347 false)))
(let (($x2163 (or $x2161 false false)))
(let (($x290 (or $x347 false false)))
(let (($x2385 (or $x290 $x2163 false)))
(let (($x2390 (or $x2385 false)))
(let (($x3382 (or $x2390 false)))
(let (($x3380 (or $x3382 false false)))
(and (not $x3380) (or $x3380 (and (distinct ?x2171 ?x2171) true)))))))))))))))))))))
(check-sat)
; query 65: function crcu8, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x347 (or false false)))
(let (($x3115 (not $x347)))
(and $x3115 (or $x347 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 66: function crcu8, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x2388 ((_ zero_extend 24) in.0_8)))
(let ((?x517 (bvand ?x2388 (_ bv1 32))))
(let (($x347 (or false false)))
(let (($x290 (or $x347 false false)))
(let (($x89 (not $x290)))
(and $x89 (or $x290 (and (distinct ?x517 ?x517) true)))))))))
(check-sat)
; query 67: function crcu8, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x347 (or false false)))
(let (($x3115 (not $x347)))
(and $x3115 (or $x347 (and (distinct ((_ extract 7 0) in.01_16) ((_ extract 7 0) in.01_16)) true))))))
(check-sat)
; query 68: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x2350 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x3105 ((_ zero_extend 31) ?x2350)))
(let ((?x2874 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x3108 ((_ zero_extend 31) ?x2874)))
(let ((?x1965 (bvand ?x3108 ?x3105)))
(let ((?x2370 (ite (and (distinct (_ bv0 32) ?x1965) true) (_ bv1 1) (_ bv0 1))))
(let ((?x2609 ((_ zero_extend 63) ?x2370)))
(let (($x347 (or false false)))
(let (($x290 (or $x347 false false)))
(let (($x244 (or $x290 false)))
(let (($x1773 (or $x244 $x244 false)))
(let (($x1968 (or $x1773 false false)))
(let (($x2400 (or $x1968 false)))
(and (not $x2400) (or $x2400 (and (distinct ?x2609 ?x2609) true)))))))))))))))))
(check-sat)
; query 69: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x2350 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x3105 ((_ zero_extend 31) ?x2350)))
(let ((?x2874 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x3108 ((_ zero_extend 31) ?x2874)))
(let ((?x1965 (bvand ?x3108 ?x3105)))
(let ((?x2370 (ite (and (distinct (_ bv0 32) ?x1965) true) (_ bv1 1) (_ bv0 1))))
(let (($x2398 (= (_ bv1 1) ?x2370)))
(let ((?x2378 (ite $x2398 (_ bv1 32) (_ bv0 32))))
(let (($x347 (or false false)))
(let (($x290 (or $x347 false false)))
(let (($x244 (or $x290 false)))
(let (($x1773 (or $x244 $x244 false)))
(let (($x1968 (or $x1773 false false)))
(let (($x2179 (or $x1968 (ite $x2398 false false))))
(and (not $x2179) (or $x2179 (and (distinct ?x2378 ?x2378) true))))))))))))))))))
(check-sat)
; query 70: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x2350 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x3105 ((_ zero_extend 31) ?x2350)))
(let ((?x2874 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x3108 ((_ zero_extend 31) ?x2874)))
(let ((?x1965 (bvand ?x3108 ?x3105)))
(let ((?x2370 (ite (and (distinct (_ bv0 32) ?x1965) true) (_ bv1 1) (_ bv0 1))))
(let (($x2398 (= (_ bv1 1) ?x2370)))
(let ((?x2378 (ite $x2398 (_ bv1 32) (_ bv0 32))))
(let ((?x851 ((_ extract 7 0) ?x2378)))
(let (($x347 (or false false)))
(let (($x290 (or $x347 false false)))
(let (($x244 (or $x290 false)))
(let (($x1773 (or $x244 $x244 false)))
(let (($x1968 (or $x1773 false false)))
(let (($x2179 (or $x1968 (ite $x2398 false false))))
(let (($x103 (or $x2179 false)))
(and (not $x103) (or $x103 (and (distinct ?x851 ?x851) true))))))))))))))))))))
(check-sat)
; query 71: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x347 (or false false)))
(let (($x3115 (not $x347)))
(and $x3115 (or $x347 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 72: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x2874 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x347 (or false false)))
(let (($x290 (or $x347 false false)))
(let (($x89 (not $x290)))
(and $x89 (or $x290 (and (distinct ?x2874 ?x2874) true))))))))
(check-sat)
; query 73: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x2874 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x3108 ((_ zero_extend 31) ?x2874)))
(let (($x347 (or false false)))
(let (($x290 (or $x347 false false)))
(let (($x244 (or $x290 false)))
(let (($x3117 (not $x244)))
(and $x3117 (or $x244 (and (distinct ?x3108 ?x3108) true))))))))))
(check-sat)
; query 74: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x347 (or false false)))
(let (($x3115 (not $x347)))
(and $x3115 (or $x347 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 75: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x2350 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x347 (or false false)))
(let (($x290 (or $x347 false false)))
(let (($x89 (not $x290)))
(and $x89 (or $x290 (and (distinct ?x2350 ?x2350) true))))))))
(check-sat)
; query 76: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x2350 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x3105 ((_ zero_extend 31) ?x2350)))
(let (($x347 (or false false)))
(let (($x290 (or $x347 false false)))
(let (($x244 (or $x290 false)))
(let (($x3117 (not $x244)))
(and $x3117 (or $x244 (and (distinct ?x3105 ?x3105) true))))))))))
(check-sat)
; query 77: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x2350 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x3105 ((_ zero_extend 31) ?x2350)))
(let ((?x2874 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x3108 ((_ zero_extend 31) ?x2874)))
(let ((?x1965 (bvand ?x3108 ?x3105)))
(let (($x347 (or false false)))
(let (($x290 (or $x347 false false)))
(let (($x244 (or $x290 false)))
(let (($x1773 (or $x244 $x244 false)))
(and (not $x1773) (or $x1773 (and (distinct ?x1965 ?x1965) true)))))))))))))
(check-sat)
; query 78: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x2350 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x3105 ((_ zero_extend 31) ?x2350)))
(let ((?x2874 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x3108 ((_ zero_extend 31) ?x2874)))
(let ((?x1965 (bvand ?x3108 ?x3105)))
(let ((?x2370 (ite (and (distinct (_ bv0 32) ?x1965) true) (_ bv1 1) (_ bv0 1))))
(let (($x347 (or false false)))
(let (($x290 (or $x347 false false)))
(let (($x244 (or $x290 false)))
(let (($x1773 (or $x244 $x244 false)))
(let (($x1968 (or $x1773 false false)))
(and (not $x1968) (or $x1968 (and (distinct ?x2370 ?x2370) true)))))))))))))))
(check-sat)
; query 79: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x2636 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x385 (or false false false)))
(let (($x183 (not $x385)))
(and $x183 (or $x385 (and (distinct ?x2636 ?x2636) true)))))))
(check-sat)
; query 80: function matrix_add_const, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x385 (or false false false)))
(let (($x183 (not $x385)))
(and $x183 (or $x385 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 81: function matrix_add_const, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x494 (bvadd in.01_32 (_ bv1 32))))
(let (($x876 (and (distinct ?x494 ?x494) true)))
(let (($x385 (or false false false)))
(let (($x183 (not $x385)))
(and $x183 (or $x385 $x876)))))))
(check-sat)
; query 82: function matrix_mul_const, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x385 (or false false false)))
(let (($x183 (not $x385)))
(and $x183 (or $x385 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 83: function matrix_mul_const, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x494 (bvadd in.01_32 (_ bv1 32))))
(let (($x876 (and (distinct ?x494 ?x494) true)))
(let (($x385 (or false false false)))
(let (($x183 (not $x385)))
(and $x183 (or $x385 $x876)))))))
(check-sat)
; query 84: function matrix_mul_matrix, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x385 (or false false false)))
(let (($x183 (not $x385)))
(and $x183 (or $x385 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 85: function matrix_mul_matrix, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x494 (bvadd in.01_32 (_ bv1 32))))
(let (($x876 (and (distinct ?x494 ?x494) true)))
(let (($x385 (or false false false)))
(let (($x183 (not $x385)))
(and $x183 (or $x385 $x876)))))))
(check-sat)
; query 86: function matrix_mul_matrix, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x385 (or false false false)))
(let (($x183 (not $x385)))
(and $x183 (or $x385 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 87: function matrix_mul_matrix_bitextract, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x385 (or false false false)))
(let (($x183 (not $x385)))
(and $x183 (or $x385 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 88: function matrix_mul_matrix_bitextract, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x494 (bvadd in.01_32 (_ bv1 32))))
(let (($x876 (and (distinct ?x494 ?x494) true)))
(let (($x385 (or false false false)))
(let (($x183 (not $x385)))
(and $x183 (or $x385 $x876)))))))
(check-sat)
; query 89: function matrix_mul_matrix_bitextract, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x385 (or false false false)))
(let (($x183 (not $x385)))
(and $x183 (or $x385 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 90: function matrix_mul_vect, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x385 (or false false false)))
(let (($x183 (not $x385)))
(and $x183 (or $x385 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 91: function matrix_mul_vect, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x494 (bvadd in.01_32 (_ bv1 32))))
(let (($x876 (and (distinct ?x494 ?x494) true)))
(let (($x385 (or false false false)))
(let (($x183 (not $x385)))
(and $x183 (or $x385 $x876)))))))
(check-sat)
; query 92: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x347 (or false false)))
(let (($x3115 (not $x347)))
(and $x3115 (or $x347 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 93: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x2637 ((_ sign_extend 16) in.1_16)))
(let ((?x1961 (bvadd ?x2637 (_ bv10 32))))
(let (($x2176 (and (distinct (bvadd ((_ sign_extend 1) ?x2637) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x1961)) true)))
(let (($x347 (or false false)))
(let (($x2159 (or $x347 false (or $x2176))))
(and (not $x2159) (or $x2159 (and (distinct ?x1961 ?x1961) true)))))))))
(check-sat)
; query 94: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x2637 ((_ sign_extend 16) in.1_16)))
(let ((?x1961 (bvadd ?x2637 (_ bv10 32))))
(let ((?x2175 ((_ extract 15 0) ?x1961)))
(let (($x2176 (and (distinct (bvadd ((_ sign_extend 1) ?x2637) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x1961)) true)))
(let (($x347 (or false false)))
(let (($x2159 (or $x347 false (or $x2176))))
(let (($x1963 (or $x2159 false)))
(and (not $x1963) (or $x1963 (and (distinct ?x2175 ?x2175) true)))))))))))
(check-sat)
; query 95: function matrix_sum, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x3665 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x385 (or false false false)))
(let (($x183 (not $x385)))
(and $x183 (or $x385 (and (distinct ?x3665 ?x3665) true)))))))
(check-sat)
; query 96: function matrix_sum, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x3665 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let ((?x3106 ((_ zero_extend 63) ?x3665)))
(let (($x385 (or false false false)))
(let (($x3113 (or $x385 false)))
(and (not $x3113) (or $x3113 (and (distinct ?x3106 ?x3106) true))))))))
(check-sat)
; query 97: function matrix_sum, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x3665 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x3119 (= (_ bv1 1) ?x3665)))
(let ((?x3679 (ite $x3119 (_ bv1 32) (_ bv0 32))))
(let (($x385 (or false false false)))
(let (($x3957 (or $x385 (ite $x3119 false false))))
(and (not $x3957) (or $x3957 (and (distinct ?x3679 ?x3679) true)))))))))
(check-sat)
; query 98: function matrix_sum, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x347 (or false false)))
(let (($x3115 (not $x347)))
(and $x3115 (or $x347 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 99: function matrix_sum, block 22, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x3665 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x3119 (= (_ bv1 1) ?x3665)))
(let ((?x3679 (ite $x3119 (_ bv1 32) (_ bv0 32))))
(let ((?x2637 ((_ sign_extend 16) in.1_16)))
(let ((?x2861 (bvadd ?x2637 ?x3679)))
(let (($x2879 (and (distinct (bvadd ((_ sign_extend 1) ?x2637) ((_ sign_extend 1) ?x3679)) ((_ sign_extend 1) ?x2861)) true)))
(let (($x385 (or false false false)))
(let (($x3957 (or $x385 (ite $x3119 false false))))
(let (($x347 (or false false)))
(let (($x3672 (or $x347 $x3957 (or $x2879))))
(and (not $x3672) (or $x3672 (and (distinct ?x2861 ?x2861) true))))))))))))))
(check-sat)
; query 100: function matrix_sum, block 22, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x3665 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x3119 (= (_ bv1 1) ?x3665)))
(let ((?x3679 (ite $x3119 (_ bv1 32) (_ bv0 32))))
(let ((?x2637 ((_ sign_extend 16) in.1_16)))
(let ((?x2861 (bvadd ?x2637 ?x3679)))
(let ((?x3673 ((_ extract 15 0) ?x2861)))
(let (($x2879 (and (distinct (bvadd ((_ sign_extend 1) ?x2637) ((_ sign_extend 1) ?x3679)) ((_ sign_extend 1) ?x2861)) true)))
(let (($x385 (or false false false)))
(let (($x3957 (or $x385 (ite $x3119 false false))))
(let (($x347 (or false false)))
(let (($x3672 (or $x347 $x3957 (or $x2879))))
(let (($x3674 (or $x3672 false)))
(and (not $x3674) (or $x3674 (and (distinct ?x3673 ?x3673) true))))))))))))))))
(check-sat)
; query 101: function matrix_sum, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x385 (or false false false)))
(let (($x183 (not $x385)))
(and $x183 (or $x385 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 102: function matrix_sum, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x494 (bvadd in.01_32 (_ bv1 32))))
(let (($x876 (and (distinct ?x494 ?x494) true)))
(let (($x385 (or false false false)))
(let (($x183 (not $x385)))
(and $x183 (or $x385 $x876)))))))
(check-sat)
; query 103: function parseval, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.23_32 () (_ BitVec 32))
(assert
 (let (($x509 (and (distinct (bvmul ((_ sign_extend 32) in.23_32) ((_ sign_extend 32) (_ bv1024 32))) ((_ sign_extend 32) (bvmul in.23_32 (_ bv1024 32)))) true)))
(let (($x872 (or false false (or $x509))))
(and (not $x872) (or $x872 (and (distinct (bvmul in.23_32 (_ bv1024 32)) (bvmul in.23_32 (_ bv1024 32))) true))))))
(check-sat)
; query 104: function parseval, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.34_32 () (_ BitVec 32))
(assert
 (let (($x319 (and (distinct (bvmul ((_ sign_extend 32) in.34_32) ((_ sign_extend 32) (_ bv1048576 32))) ((_ sign_extend 32) (bvmul in.34_32 (_ bv1048576 32)))) true)))
(let (($x948 (or false false (or $x319))))
(and (not $x948) (or $x948 (and (distinct (bvmul in.34_32 (_ bv1048576 32)) (bvmul in.34_32 (_ bv1048576 32))) true))))))
(check-sat)
; query 105: function partition_memory, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x385 (or false false false)))
(let (($x183 (not $x385)))
(and $x183 (or $x385 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
