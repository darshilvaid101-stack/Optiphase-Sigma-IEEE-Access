; OptiPhase-Sigma refinement certificate for sweep K35-R3-084
; query 0: function edge_draw, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let ((?x504 (ite (= (_ bv0 32) in4_32) (_ bv1 1) (_ bv0 1))))
(let (($x127 (or false false false)))
(and (not $x127) (or $x127 (and (distinct ?x504 ?x504) true))))))
(check-sat)
