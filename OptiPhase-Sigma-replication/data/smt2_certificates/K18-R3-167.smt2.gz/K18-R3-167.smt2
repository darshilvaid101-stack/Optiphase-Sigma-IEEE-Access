; OptiPhase-Sigma refinement certificate for sweep K18-R3-167
; query 0: function xmalloc, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in7_32 () (_ BitVec 32))
(assert
 (let ((?x71 (ite (and (distinct (_ bv0 32) in7_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x29 (or false false false)))
(and (not $x29) (or $x29 (and (distinct ?x71 ?x71) true))))))
(check-sat)
