; OptiPhase-Sigma refinement certificate for sweep K56-R3-129
; query 0: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x333 (or false false false)))
(let (($x22 (not $x333)))
(and $x22 (or $x333 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x31 (bvadd in.01_32 (_ bv1 32))))
(let ((?x411 (bvmul ?x31 ?x31)))
(let (($x333 (or false false false)))
(let (($x122 (or $x333 $x333 false)))
(and (not $x122) (or $x122 (and (distinct ?x411 ?x411) true))))))))
(check-sat)
; query 2: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x31 (bvadd in.01_32 (_ bv1 32))))
(let ((?x411 (bvmul ?x31 ?x31)))
(let ((?x462 (bvmul ?x411 (_ bv2 32))))
(let (($x333 (or false false false)))
(let (($x122 (or $x333 $x333 false)))
(let (($x101 (or $x122 false false)))
(and (not $x101) (or $x101 (and (distinct ?x462 ?x462) true))))))))))
(check-sat)
; query 3: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x31 (bvadd in.01_32 (_ bv1 32))))
(let ((?x411 (bvmul ?x31 ?x31)))
(let ((?x462 (bvmul ?x411 (_ bv2 32))))
(let ((?x39 (bvmul ?x462 (_ bv4 32))))
(let (($x333 (or false false false)))
(let (($x122 (or $x333 $x333 false)))
(let (($x101 (or $x122 false false)))
(let (($x18 (or $x101 false false)))
(and (not $x18) (or $x18 (and (distinct ?x39 ?x39) true))))))))))))
(check-sat)
; query 4: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x922 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x333 (or false false false)))
(let (($x22 (not $x333)))
(and $x22 (or $x333 (and (distinct ?x922 ?x922) true)))))))
(check-sat)
; query 5: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x636 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x333 (or false false false)))
(let (($x22 (not $x333)))
(and $x22 (or $x333 (and (distinct ?x636 ?x636) true)))))))
(check-sat)
; query 6: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x333 (or false false false)))
(let (($x22 (not $x333)))
(and $x22 (or $x333 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 7: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x111 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x516 (or false false (or $x111))))
(and (not $x516) (or $x516 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x127 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x333 (or false false false)))
(let (($x22 (not $x333)))
(and $x22 (or $x333 (and (distinct ?x127 ?x127) true)))))))
(check-sat)
; query 9: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1673 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x333 (or false false false)))
(let (($x22 (not $x333)))
(and $x22 (or $x333 (and (distinct ?x1673 ?x1673) true)))))))
(check-sat)
; query 10: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x908 (or false false)))
(and (not $x908) (or $x908 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true)))))
(check-sat)
; query 11: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x16 ((_ sign_extend 16) in.1_16)))
(let ((?x232 (bvadd ?x16 (_ bv10 32))))
(let (($x2031 (and (distinct (bvadd ((_ sign_extend 1) ?x16) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x232)) true)))
(let (($x908 (or false false)))
(let (($x1621 (or $x908 false (or $x2031))))
(and (not $x1621) (or $x1621 (and (distinct ?x232 ?x232) true)))))))))
(check-sat)
; query 12: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x16 ((_ sign_extend 16) in.1_16)))
(let ((?x232 (bvadd ?x16 (_ bv10 32))))
(let ((?x159 ((_ extract 15 0) ?x232)))
(let (($x2031 (and (distinct (bvadd ((_ sign_extend 1) ?x16) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x232)) true)))
(let (($x908 (or false false)))
(let (($x1621 (or $x908 false (or $x2031))))
(let (($x1933 (or $x1621 false)))
(and (not $x1933) (or $x1933 (and (distinct ?x159 ?x159) true)))))))))))
(check-sat)
