; OptiPhase-Sigma refinement certificate for sweep K52-R3-291
; query 0: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x232 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x120 (or false false false)))
(let (($x147 (not $x120)))
(and $x147 (or $x120 (and (distinct ?x232 ?x232) true)))))))
(check-sat)
; query 1: function s162, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x371 (ite (bvslt (_ bv0 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x120 (or false false false)))
(let (($x147 (not $x120)))
(and $x147 (or $x120 (and (distinct ?x371 ?x371) true)))))))
(check-sat)
; query 2: function s276, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x367 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x118 (or false false (or $x367))))
(and (not $x118) (or $x118 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 3: function s276, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x349 (ite (bvsgt (_ bv16000 32) (bvadd in.0_32 (_ bv1 32))) (_ bv1 1) (_ bv0 1))))
(let (($x367 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x118 (or false false (or $x367))))
(let (($x944 (or $x118 false false)))
(and (not $x944) (or $x944 (and (distinct ?x349 ?x349) true))))))))
(check-sat)
; query 4: function set1d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x91 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x120 (or false false false)))
(let (($x147 (not $x120)))
(and $x147 (or $x120 (and (distinct ?x91 ?x91) true)))))))
(check-sat)
; query 5: function set1ds, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x411 (ite (= (_ bv4294967295 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x120 (or false false false)))
(let (($x147 (not $x120)))
(and $x147 (or $x120 (and (distinct ?x411 ?x411) true)))))))
(check-sat)
; query 6: function set2d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x91 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x120 (or false false false)))
(let (($x147 (not $x120)))
(and $x147 (or $x120 (and (distinct ?x91 ?x91) true)))))))
(check-sat)
