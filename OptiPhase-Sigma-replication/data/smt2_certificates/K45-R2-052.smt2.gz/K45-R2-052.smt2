; OptiPhase-Sigma refinement certificate for sweep K45-R2-052
; query 0: function Index_to_frequency, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x853 (ite (bvuge in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x507 (or false false false)))
(let (($x281 (not $x507)))
(and $x281 (or $x507 (and (distinct ?x853 ?x853) true)))))))
(check-sat)
; query 1: function IsPowerOfTwo, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x507 (or false false false)))
(let (($x281 (not $x507)))
(and $x281 (or $x507 (and (distinct (bvsub in0_32 (_ bv1 32)) (bvsub in0_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function IsPowerOfTwo, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x167 (bvsub in0_32 (_ bv1 32))))
(let ((?x343 (bvand in0_32 ?x167)))
(let (($x507 (or false false false)))
(let (($x99 (or false $x507 false)))
(and (not $x99) (or $x99 (and (distinct ?x343 ?x343) true))))))))
(check-sat)
; query 3: function IsPowerOfTwo, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x226 (ite (and (distinct (_ bv0 32) (bvand in0_32 (bvsub in0_32 (_ bv1 32)))) true) (_ bv1 1) (_ bv0 1))))
(let (($x507 (or false false false)))
(let (($x99 (or false $x507 false)))
(let (($x516 (or $x99 false false)))
(and (not $x516) (or $x516 (and (distinct ?x226 ?x226) true))))))))
(check-sat)
; query 4: function IsPowerOfTwo, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x49 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x507 (or false false false)))
(let (($x281 (not $x507)))
(and $x281 (or $x507 (and (distinct ?x49 ?x49) true)))))))
(check-sat)
; query 5: function NumberOfBitsNeeded, block 13, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x507 (or false false false)))
(let (($x281 (not $x507)))
(and $x281 (or $x507 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 6: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x49 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x507 (or false false false)))
(let (($x281 (not $x507)))
(and $x281 (or $x507 (and (distinct ?x49 ?x49) true)))))))
(check-sat)
; query 7: function ReverseBits, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x507 (or false false false)))
(let (($x281 (not $x507)))
(and $x281 (or $x507 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function ReverseBits, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x507 (or false false false)))
(let (($x807 (or $x507 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x121 (not $x807)))
(and $x121 (or $x807 (and (distinct (bvshl in.01_32 (_ bv1 32)) (bvshl in.01_32 (_ bv1 32))) true)))))))
(check-sat)
; query 9: function ReverseBits, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x507 (or false false false)))
(let (($x281 (not $x507)))
(and $x281 (or $x507 (and (distinct (bvand in.0_32 (_ bv1 32)) (bvand in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 10: function ReverseBits, block 5, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x13 (bvand in.0_32 (_ bv1 32))))
(let ((?x235 (bvshl in.01_32 (_ bv1 32))))
(let ((?x151 (bvor ?x235 ?x13)))
(let (($x507 (or false false false)))
(let (($x807 (or $x507 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x29 (or $x807 $x507 false)))
(and (not $x29) (or $x29 (and (distinct ?x151 ?x151) true))))))))))
(check-sat)
; query 11: function ReverseBits, block 5, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x507 (or false false false)))
(let (($x807 (or $x507 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x121 (not $x807)))
(and $x121 (or $x807 (and (distinct (bvlshr in.0_32 (_ bv1 32)) (bvlshr in.0_32 (_ bv1 32))) true)))))))
(check-sat)
; query 12: function fft_float, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x552 (ite (and (distinct (_ bv0 32) in1_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x507 (or false false false)))
(let (($x281 (not $x507)))
(and $x281 (or $x507 (and (distinct ?x552 ?x552) true)))))))
(check-sat)
; query 13: function fft_float, block 152, name %153
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let (($x507 (or false false false)))
(let (($x281 (not $x507)))
(and $x281 (or $x507 (and (distinct (bvadd in.04_32 (_ bv1 32)) (bvadd in.04_32 (_ bv1 32))) true))))))
(check-sat)
; query 14: function fft_float, block 152, name %154
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_32 () (_ BitVec 32))
(assert
 (let (($x507 (or false false false)))
(let (($x281 (not $x507)))
(and $x281 (or $x507 (and (distinct (bvadd in.03_32 (_ bv1 32)) (bvadd in.03_32 (_ bv1 32))) true))))))
(check-sat)
; query 15: function fft_float, block 156, name %157
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x507 (or false false false)))
(let (($x202 (or $x507 (and (distinct (bvadd in.1_32 in.02_32) (bvadd in.1_32 in.02_32)) true))))
(let (($x281 (not $x507)))
(and $x281 $x202)))))
(check-sat)
; query 16: function fft_float, block 159, name %160
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x507 (or false false false)))
(let (($x807 (or $x507 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x121 (not $x807)))
(and $x121 (or $x807 (and (distinct (bvshl in.02_32 (_ bv1 32)) (bvshl in.02_32 (_ bv1 32))) true)))))))
(check-sat)
; query 17: function fft_float, block 161, name %162
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x552 (ite (and (distinct (_ bv0 32) in1_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x507 (or false false false)))
(let (($x281 (not $x507)))
(and $x281 (or $x507 (and (distinct ?x552 ?x552) true)))))))
(check-sat)
; query 18: function fft_float, block 180, name %181
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let (($x507 (or false false false)))
(let (($x281 (not $x507)))
(and $x281 (or $x507 (and (distinct (bvadd in.2_32 (_ bv1 32)) (bvadd in.2_32 (_ bv1 32))) true))))))
(check-sat)
; query 19: function fft_float, block 41, name %42
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.05_32 () (_ BitVec 32))
(assert
 (let (($x507 (or false false false)))
(let (($x281 (not $x507)))
(and $x281 (or $x507 (and (distinct (bvadd in.05_32 (_ bv1 32)) (bvadd in.05_32 (_ bv1 32))) true))))))
(check-sat)
; query 20: function main, block 110, name %111
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x507 (or false false false)))
(let (($x281 (not $x507)))
(and $x281 (or $x507 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 21: function main, block 113, name %114
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x507 (or false false false)))
(let (($x281 (not $x507)))
(and $x281 (or $x507 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 22: function main, block 126, name %127
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let (($x507 (or false false false)))
(let (($x281 (not $x507)))
(and $x281 (or $x507 (and (distinct (bvadd in.2_32 (_ bv1 32)) (bvadd in.2_32 (_ bv1 32))) true))))))
(check-sat)
; query 23: function main, block 139, name %140
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.3_32 () (_ BitVec 32))
(assert
 (let (($x507 (or false false false)))
(let (($x281 (not $x507)))
(and $x281 (or $x507 (and (distinct (bvadd in.3_32 (_ bv1 32)) (bvadd in.3_32 (_ bv1 32))) true))))))
(check-sat)
; query 24: function main, block 57, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x507 (or false false false)))
(let (($x281 (not $x507)))
(and $x281 (or $x507 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 25: function main, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x80 (ite (= (_ bv4 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x507 (or false false false)))
(let (($x281 (not $x507)))
(and $x281 (or $x507 (and (distinct ?x80 ?x80) true)))))))
(check-sat)
; query 26: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x229 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x507 (or false false false)))
(let (($x281 (not $x507)))
(and $x281 (or $x507 (and (distinct ?x229 ?x229) true)))))))
(check-sat)
