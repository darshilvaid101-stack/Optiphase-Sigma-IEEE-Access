; OptiPhase-Sigma refinement certificate for sweep K49-R2-090
; query 0: function APCM_inverse_quantization, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x966 (or false false)))
(let (($x190 (not $x966)))
(and $x190 (or $x966 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 1: function APCM_inverse_quantization, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x235 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x966 (or false false)))
(let (($x25 (or $x966 false false)))
(let (($x7 (not $x25)))
(and $x7 (or $x25 (and (distinct ?x235 ?x235) true))))))))
(check-sat)
; query 2: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x966 (or false false)))
(let (($x190 (not $x966)))
(and $x190 (or $x966 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 3: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x29 (ite (bvslt (_ bv15 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x966 (or false false)))
(let (($x25 (or $x966 false false)))
(let (($x7 (not $x25)))
(and $x7 (or $x25 (and (distinct ?x29 ?x29) true))))))))
(check-sat)
; query 4: function Decoding_of_the_coded_Log_Area_Ratios, block 268, name %269
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in265_64 () (_ BitVec 64))
(assert
 (let (($x59 (and (distinct (ite (bvsge (_ bv18446744073709518848 64) in265_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv0 64) in265_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x27 (or false false false)))
(let (($x720 (not $x27)))
(and $x720 (or $x27 $x59))))))
(check-sat)
; query 5: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x966 (or false false)))
(let (($x190 (not $x966)))
(and $x190 (or $x966 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 6: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1968 (ite (bvsgt (_ bv40 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x966 (or false false)))
(let (($x25 (or $x966 false false)))
(let (($x7 (not $x25)))
(and $x7 (or $x25 (and (distinct ?x1968 ?x1968) true))))))))
(check-sat)
; query 7: function Quantization_and_coding, block 311, name %312
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in308_32 () (_ BitVec 32))
(declare-fun in308_64 () (_ BitVec 64))
(assert
 (let (($x77 (and (distinct (ite (bvslt (_ bv0 64) in308_64) (_ bv1 1) (_ bv0 1)) (ite (bvsgt (_ bv4294967292 32) in308_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x27 (or false false false)))
(let (($x720 (not $x27)))
(and $x720 (or $x27 $x77))))))
(check-sat)
; query 8: function RPE_grid_positioning, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x966 (or false false)))
(let (($x190 (not $x966)))
(and $x190 (or $x966 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 9: function RPE_grid_positioning, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x744 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x56 (and (distinct ?x744 ?x744) true)))
(let (($x966 (or false false)))
(let (($x209 (or false $x966 false)))
(and (not $x209) (or $x209 $x56)))))))
(check-sat)
; query 10: function alaw_input, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x71 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x480 (or false false (or $x71))))
(and (not $x480) (or $x480 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 11: function alaw_input, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let ((?x199 (ite (= (_ bv4294967295 32) in.1_32) (_ bv1 1) (_ bv0 1))))
(let (($x27 (or false false false)))
(let (($x720 (not $x27)))
(and $x720 (or $x27 (and (distinct ?x199 ?x199) true)))))))
(check-sat)
; query 12: function gsm_L_add, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_64 () (_ BitVec 64))
(assert
 (let ((?x74 (bvsub (_ bv0 64) in13_64)))
(let ((?x123 ((_ sign_extend 1) ?x74)))
(let (($x82 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in13_64)) ?x123) true)))))
(and (not $x82) (or $x82 (and (distinct ?x74 ?x74) true)))))))
(check-sat)
; query 13: function gsm_L_add, block 16, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_64 () (_ BitVec 64))
(assert
 (let ((?x74 (bvsub (_ bv0 64) in13_64)))
(let ((?x315 (bvsub ?x74 (_ bv2 64))))
(let (($x122 (and (distinct (bvsub ((_ sign_extend 1) ?x74) ((_ sign_extend 1) (_ bv2 64))) ((_ sign_extend 1) ?x315)) true)))
(let ((?x123 ((_ sign_extend 1) ?x74)))
(let (($x82 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in13_64)) ?x123) true)))))
(let (($x19 (or $x82 false (or $x122))))
(and (not $x19) (or $x19 (and (distinct ?x315 ?x315) true))))))))))
(check-sat)
; query 14: function gsm_L_add, block 21, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x13 (ite (bvsge (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x27 (or false false false)))
(let (($x720 (not $x27)))
(and $x720 (or $x27 (and (distinct ?x13 ?x13) true)))))))
(check-sat)
; query 15: function gsm_L_add, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x623 (bvadd in0_64 in1_64)))
(let (($x372 (and (distinct ?x623 ?x623) true)))
(let (($x84 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) ?x623)) true)))
(let (($x36 (or false false (or $x84))))
(and (not $x36) (or $x36 $x372)))))))
(check-sat)
; query 16: function gsm_L_add, block 25, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x623 (bvadd in0_64 in1_64)))
(let (($x372 (and (distinct ?x623 ?x623) true)))
(let (($x27 (or false false false)))
(let (($x720 (not $x27)))
(and $x720 (or $x27 $x372)))))))
(check-sat)
; query 17: function gsm_L_add, block 25, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x100 (ite (bvugt (bvadd in0_64 in1_64) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x27 (or false false false)))
(let (($x80 (or $x27 false false)))
(let (($x917 (not $x80)))
(and $x917 (or $x80 (and (distinct ?x100 ?x100) true))))))))
(check-sat)
; query 18: function gsm_L_add, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x117 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x27 (or false false false)))
(let (($x720 (not $x27)))
(and $x720 (or $x27 (and (distinct ?x117 ?x117) true)))))))
(check-sat)
; query 19: function gsm_L_add, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x623 (bvadd in0_64 in1_64)))
(let (($x372 (and (distinct ?x623 ?x623) true)))
(let (($x84 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) ?x623)) true)))
(let (($x36 (or false false (or $x84))))
(and (not $x36) (or $x36 $x372)))))))
(check-sat)
; query 20: function gsm_L_add, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x52 (bvadd in0_64 (_ bv1 64))))
(let ((?x140 (bvsub (_ bv0 64) ?x52)))
(let (($x14 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x52)) ((_ sign_extend 1) ?x140)) true)))
(let ((?x72 ((_ sign_extend 1) ?x52)))
(let (($x6 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x72) true)))))
(let (($x511 (or false $x6 (or $x14))))
(and (not $x511) (or $x511 (and (distinct ?x140 ?x140) true))))))))))
(check-sat)
; query 21: function gsm_L_add, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x653 (bvadd in1_64 (_ bv1 64))))
(let ((?x1658 ((_ sign_extend 1) ?x653)))
(let (($x104 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1658) true)))))
(and (not $x104) (or $x104 (and (distinct ?x653 ?x653) true)))))))
(check-sat)
; query 22: function gsm_L_add, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x653 (bvadd in1_64 (_ bv1 64))))
(let ((?x615 (bvsub (_ bv0 64) ?x653)))
(let (($x11 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x653)) ((_ sign_extend 1) ?x615)) true)))
(let ((?x1658 ((_ sign_extend 1) ?x653)))
(let (($x104 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1658) true)))))
(let (($x88 (or false $x104 (or $x11))))
(and (not $x88) (or $x88 (and (distinct ?x615 ?x615) true))))))))))
(check-sat)
; query 23: function gsm_L_add, block 8, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x653 (bvadd in1_64 (_ bv1 64))))
(let ((?x615 (bvsub (_ bv0 64) ?x653)))
(let ((?x52 (bvadd in0_64 (_ bv1 64))))
(let ((?x140 (bvsub (_ bv0 64) ?x52)))
(let ((?x149 (bvadd ?x140 ?x615)))
(let (($x11 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x653)) ((_ sign_extend 1) ?x615)) true)))
(let ((?x1658 ((_ sign_extend 1) ?x653)))
(let (($x104 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1658) true)))))
(let (($x88 (or false $x104 (or $x11))))
(let (($x14 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x52)) ((_ sign_extend 1) ?x140)) true)))
(let ((?x72 ((_ sign_extend 1) ?x52)))
(let (($x6 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x72) true)))))
(let (($x511 (or false $x6 (or $x14))))
(let (($x70 (or $x511 $x88 false)))
(and (not $x70) (or $x70 (and (distinct ?x149 ?x149) true))))))))))))))))))
(check-sat)
; query 24: function gsm_L_add, block 8, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x653 (bvadd in1_64 (_ bv1 64))))
(let ((?x615 (bvsub (_ bv0 64) ?x653)))
(let ((?x52 (bvadd in0_64 (_ bv1 64))))
(let ((?x140 (bvsub (_ bv0 64) ?x52)))
(let ((?x149 (bvadd ?x140 ?x615)))
(let ((?x618 (ite (bvuge ?x149 (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x11 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x653)) ((_ sign_extend 1) ?x615)) true)))
(let ((?x1658 ((_ sign_extend 1) ?x653)))
(let (($x104 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1658) true)))))
(let (($x88 (or false $x104 (or $x11))))
(let (($x14 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x52)) ((_ sign_extend 1) ?x140)) true)))
(let ((?x72 ((_ sign_extend 1) ?x52)))
(let (($x6 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x72) true)))))
(let (($x511 (or false $x6 (or $x14))))
(let (($x70 (or $x511 $x88 false)))
(let (($x260 (or $x70 false false)))
(and (not $x260) (or $x260 (and (distinct ?x618 ?x618) true))))))))))))))))))))
(check-sat)
; query 25: function gsm_L_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x52 (bvadd in0_64 (_ bv1 64))))
(let ((?x72 ((_ sign_extend 1) ?x52)))
(let (($x6 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x72) true)))))
(and (not $x6) (or $x6 (and (distinct ?x52 ?x52) true)))))))
(check-sat)
; query 26: function gsm_L_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1730 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x27 (or false false false)))
(let (($x720 (not $x27)))
(and $x720 (or $x27 (and (distinct ?x1730 ?x1730) true)))))))
(check-sat)
; query 27: function gsm_L_asl, block 12, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1959 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x27 (or false false false)))
(let (($x720 (not $x27)))
(and $x720 (or $x27 (and (distinct ?x1959 ?x1959) true)))))))
(check-sat)
; query 28: function gsm_L_asl, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x966 (or false false)))
(let (($x190 (not $x966)))
(and $x190 (or $x966 (and (distinct ((_ zero_extend 32) in1_32) ((_ zero_extend 32) in1_32)) true))))))
(check-sat)
; query 29: function gsm_L_asl, block 17, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x159 ((_ zero_extend 32) in1_32)))
(let ((?x1934 (bvshl in0_64 ?x159)))
(let (($x966 (or false false)))
(let (($x209 (or false $x966 false)))
(let (($x1662 (or $x209 (bvuge ?x159 (_ bv64 64)))))
(let (($x423 (not $x1662)))
(and $x423 (or $x1662 (and (distinct ?x1934 ?x1934) true))))))))))
(check-sat)
; query 30: function gsm_L_asl, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1217 (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x27 (or false false false)))
(let (($x720 (not $x27)))
(and $x720 (or $x27 (and (distinct ?x1217 ?x1217) true)))))))
(check-sat)
; query 31: function gsm_L_asl, block 7, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1730 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x152 ((_ zero_extend 31) ?x1730)))
(let ((?x1476 (bvsub (_ bv0 32) ?x152)))
(let (($x1682 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x152)) ((_ sign_extend 1) ?x1476)) true)))
(let (($x27 (or false false false)))
(let (($x1599 (or $x27 false)))
(let (($x1655 (or false $x1599 (or $x1682))))
(and (not $x1655) (or $x1655 (and (distinct ?x1476 ?x1476) true)))))))))))
(check-sat)
; query 32: function gsm_L_asl, block 7, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1730 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x152 ((_ zero_extend 31) ?x1730)))
(let ((?x1476 (bvsub (_ bv0 32) ?x152)))
(let ((?x980 ((_ sign_extend 32) ?x1476)))
(let (($x1682 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x152)) ((_ sign_extend 1) ?x1476)) true)))
(let (($x27 (or false false false)))
(let (($x1599 (or $x27 false)))
(let (($x1655 (or false $x1599 (or $x1682))))
(let (($x522 (or $x1655 false)))
(and (not $x522) (or $x522 (and (distinct ?x980 ?x980) true)))))))))))))
(check-sat)
; query 33: function gsm_L_asl, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1730 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x27 (or false false false)))
(let (($x720 (not $x27)))
(and $x720 (or $x27 (and (distinct ?x1730 ?x1730) true)))))))
(check-sat)
; query 34: function gsm_L_asl, block 7, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1730 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x152 ((_ zero_extend 31) ?x1730)))
(let (($x27 (or false false false)))
(let (($x1599 (or $x27 false)))
(and (not $x1599) (or $x1599 (and (distinct ?x152 ?x152) true))))))))
(check-sat)
; query 35: function gsm_L_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1838 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x27 (or false false false)))
(let (($x720 (not $x27)))
(and $x720 (or $x27 (and (distinct ?x1838 ?x1838) true)))))))
(check-sat)
; query 36: function gsm_L_asr, block 12, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1959 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x27 (or false false false)))
(let (($x720 (not $x27)))
(and $x720 (or $x27 (and (distinct ?x1959 ?x1959) true)))))))
(check-sat)
; query 37: function gsm_L_asr, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x170 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in1_32))) true)))
(let (($x1935 (or false false (or $x170))))
(and (not $x1935) (or $x1935 (and (distinct (bvsub (_ bv0 32) in1_32) (bvsub (_ bv0 32) in1_32)) true))))))
(check-sat)
; query 38: function gsm_L_asr, block 14, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1896 (bvsub (_ bv0 32) in1_32)))
(let ((?x1098 ((_ zero_extend 32) ?x1896)))
(let (($x170 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x1896)) true)))
(let (($x1935 (or false false (or $x170))))
(let (($x363 (or $x1935 false)))
(and (not $x363) (or $x363 (and (distinct ?x1098 ?x1098) true)))))))))
(check-sat)
; query 39: function gsm_L_asr, block 14, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1896 (bvsub (_ bv0 32) in1_32)))
(let ((?x1098 ((_ zero_extend 32) ?x1896)))
(let ((?x1699 (bvshl in0_64 ?x1098)))
(let (($x170 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x1896)) true)))
(let (($x1935 (or false false (or $x170))))
(let (($x363 (or $x1935 false)))
(let (($x1961 (or (or false $x363 false) (bvuge ?x1098 (_ bv64 64)))))
(and (not $x1961) (or $x1961 (and (distinct ?x1699 ?x1699) true)))))))))))
(check-sat)
; query 40: function gsm_L_asr, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x966 (or false false)))
(let (($x190 (not $x966)))
(and $x190 (or $x966 (and (distinct ((_ zero_extend 32) in1_32) ((_ zero_extend 32) in1_32)) true))))))
(check-sat)
; query 41: function gsm_L_asr, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x159 ((_ zero_extend 32) in1_32)))
(let ((?x1073 (bvashr in0_64 ?x159)))
(let (($x966 (or false false)))
(let (($x209 (or false $x966 false)))
(let (($x1662 (or $x209 (bvuge ?x159 (_ bv64 64)))))
(let (($x423 (not $x1662)))
(and $x423 (or $x1662 (and (distinct ?x1073 ?x1073) true))))))))))
(check-sat)
; query 42: function gsm_L_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1730 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x27 (or false false false)))
(let (($x720 (not $x27)))
(and $x720 (or $x27 (and (distinct ?x1730 ?x1730) true)))))))
(check-sat)
; query 43: function gsm_L_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1730 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x152 ((_ zero_extend 31) ?x1730)))
(let (($x27 (or false false false)))
(let (($x1599 (or $x27 false)))
(and (not $x1599) (or $x1599 (and (distinct ?x152 ?x152) true))))))))
(check-sat)
; query 44: function gsm_L_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1730 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x152 ((_ zero_extend 31) ?x1730)))
(let ((?x1476 (bvsub (_ bv0 32) ?x152)))
(let (($x1682 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x152)) ((_ sign_extend 1) ?x1476)) true)))
(let (($x27 (or false false false)))
(let (($x1599 (or $x27 false)))
(let (($x1655 (or false $x1599 (or $x1682))))
(and (not $x1655) (or $x1655 (and (distinct ?x1476 ?x1476) true)))))))))))
(check-sat)
; query 45: function gsm_L_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1730 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x152 ((_ zero_extend 31) ?x1730)))
(let ((?x1476 (bvsub (_ bv0 32) ?x152)))
(let ((?x980 ((_ sign_extend 32) ?x1476)))
(let (($x1682 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x152)) ((_ sign_extend 1) ?x1476)) true)))
(let (($x27 (or false false false)))
(let (($x1599 (or $x27 false)))
(let (($x1655 (or false $x1599 (or $x1682))))
(let (($x522 (or $x1655 false)))
(and (not $x522) (or $x522 (and (distinct ?x980 ?x980) true)))))))))))))
(check-sat)
; query 46: function gsm_L_asr, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1217 (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x27 (or false false false)))
(let (($x720 (not $x27)))
(and $x720 (or $x27 (and (distinct ?x1217 ?x1217) true)))))))
(check-sat)
; query 47: function gsm_L_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1838 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x27 (or false false false)))
(let (($x720 (not $x27)))
(and $x720 (or $x27 (and (distinct ?x1838 ?x1838) true)))))))
(check-sat)
; query 48: function gsm_L_mult, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x966 (or false false)))
(let (($x190 (not $x966)))
(and $x190 (or $x966 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 49: function gsm_L_mult, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x775 (ite (and (distinct (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) true) (_ bv1 1) (_ bv0 1))))
(let (($x966 (or false false)))
(let (($x25 (or $x966 false false)))
(let (($x7 (not $x25)))
(and $x7 (or $x25 (and (distinct ?x775 ?x775) true))))))))
(check-sat)
; query 50: function gsm_L_mult, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x966 (or false false)))
(let (($x190 (not $x966)))
(and $x190 (or $x966 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 51: function gsm_L_mult, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x352 (ite (and (distinct (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) true) (_ bv1 1) (_ bv0 1))))
(let (($x966 (or false false)))
(let (($x25 (or $x966 false false)))
(let (($x7 (not $x25)))
(and $x7 (or $x25 (and (distinct ?x352 ?x352) true))))))))
(check-sat)
; query 52: function gsm_L_sub, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in11_64 () (_ BitVec 64))
(assert
 (let (($x27 (or false false false)))
(let (($x720 (not $x27)))
(and $x720 (or $x27 (and (distinct (bvadd in11_64 (_ bv1 64)) (bvadd in11_64 (_ bv1 64))) true))))))
(check-sat)
; query 53: function gsm_L_sub, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x13 (ite (bvsge (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x27 (or false false false)))
(let (($x720 (not $x27)))
(and $x720 (or $x27 (and (distinct ?x13 ?x13) true)))))))
(check-sat)
; query 54: function gsm_L_sub, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x1018 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvsub in0_64 in1_64))) true)))
(let (($x1849 (or false false (or $x1018))))
(let (($x1222 (or $x1849 (and (distinct (bvsub in0_64 in1_64) (bvsub in0_64 in1_64)) true))))
(and (not $x1849) $x1222)))))
(check-sat)
; query 55: function gsm_L_sub, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x52 (bvadd in0_64 (_ bv1 64))))
(let ((?x72 ((_ sign_extend 1) ?x52)))
(let (($x6 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x72) true)))))
(and (not $x6) (or $x6 (and (distinct ?x52 ?x52) true)))))))
(check-sat)
; query 56: function gsm_L_sub, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x52 (bvadd in0_64 (_ bv1 64))))
(let ((?x140 (bvsub (_ bv0 64) ?x52)))
(let (($x14 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x52)) ((_ sign_extend 1) ?x140)) true)))
(let ((?x72 ((_ sign_extend 1) ?x52)))
(let (($x6 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x72) true)))))
(let (($x511 (or false $x6 (or $x14))))
(and (not $x511) (or $x511 (and (distinct ?x140 ?x140) true))))))))))
(check-sat)
; query 57: function gsm_L_sub, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x52 (bvadd in0_64 (_ bv1 64))))
(let ((?x140 (bvsub (_ bv0 64) ?x52)))
(let ((?x807 (bvadd ?x140 in1_64)))
(let (($x14 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x52)) ((_ sign_extend 1) ?x140)) true)))
(let ((?x72 ((_ sign_extend 1) ?x52)))
(let (($x6 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x72) true)))))
(let (($x511 (or false $x6 (or $x14))))
(let (($x1834 (or $x511 false false)))
(and (not $x1834) (or $x1834 (and (distinct ?x807 ?x807) true))))))))))))
(check-sat)
; query 58: function gsm_L_sub, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x824 (ite (bvuge (bvadd (bvsub (_ bv0 64) (bvadd in0_64 (_ bv1 64))) in1_64) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x14 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) (bvadd in0_64 (_ bv1 64)))) ((_ sign_extend 1) (bvsub (_ bv0 64) (bvadd in0_64 (_ bv1 64))))) true)))
(let ((?x52 (bvadd in0_64 (_ bv1 64))))
(let ((?x72 ((_ sign_extend 1) ?x52)))
(let (($x6 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x72) true)))))
(let (($x511 (or false $x6 (or $x14))))
(let (($x1834 (or $x511 false false)))
(let (($x1129 (or $x1834 false false)))
(and (not $x1129) (or $x1129 (and (distinct ?x824 ?x824) true))))))))))))
(check-sat)
; query 59: function gsm_L_sub, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_64 () (_ BitVec 64))
(assert
 (let ((?x739 (bvsub (_ bv0 64) in25_64)))
(let ((?x1842 ((_ sign_extend 1) ?x739)))
(let (($x1832 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in25_64)) ?x1842) true)))))
(and (not $x1832) (or $x1832 (and (distinct ?x739 ?x739) true)))))))
(check-sat)
; query 60: function gsm_L_sub, block 28, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_64 () (_ BitVec 64))
(assert
 (let ((?x739 (bvsub (_ bv0 64) in25_64)))
(let ((?x103 (bvsub ?x739 (_ bv1 64))))
(let (($x270 (and (distinct (bvsub ((_ sign_extend 1) ?x739) ((_ sign_extend 1) (_ bv1 64))) ((_ sign_extend 1) ?x103)) true)))
(let ((?x1842 ((_ sign_extend 1) ?x739)))
(let (($x1832 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in25_64)) ?x1842) true)))))
(let (($x1166 (or $x1832 false (or $x270))))
(and (not $x1166) (or $x1166 (and (distinct ?x103 ?x103) true))))))))))
(check-sat)
; query 61: function gsm_L_sub, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x117 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x27 (or false false false)))
(let (($x720 (not $x27)))
(and $x720 (or $x27 (and (distinct ?x117 ?x117) true)))))))
(check-sat)
; query 62: function gsm_L_sub, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x1018 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvsub in0_64 in1_64))) true)))
(let (($x1849 (or false false (or $x1018))))
(let (($x1222 (or $x1849 (and (distinct (bvsub in0_64 in1_64) (bvsub in0_64 in1_64)) true))))
(and (not $x1849) $x1222)))))
(check-sat)
; query 63: function gsm_L_sub, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x653 (bvadd in1_64 (_ bv1 64))))
(let ((?x615 (bvsub (_ bv0 64) ?x653)))
(let (($x11 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x653)) ((_ sign_extend 1) ?x615)) true)))
(let ((?x1658 ((_ sign_extend 1) ?x653)))
(let (($x104 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1658) true)))))
(let (($x88 (or false $x104 (or $x11))))
(and (not $x88) (or $x88 (and (distinct ?x615 ?x615) true))))))))))
(check-sat)
; query 64: function gsm_L_sub, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x653 (bvadd in1_64 (_ bv1 64))))
(let ((?x615 (bvsub (_ bv0 64) ?x653)))
(let ((?x528 (bvadd in0_64 ?x615)))
(let (($x11 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x653)) ((_ sign_extend 1) ?x615)) true)))
(let ((?x1658 ((_ sign_extend 1) ?x653)))
(let (($x104 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1658) true)))))
(let (($x88 (or false $x104 (or $x11))))
(let (($x1594 (or false $x88 false)))
(and (not $x1594) (or $x1594 (and (distinct ?x528 ?x528) true))))))))))))
(check-sat)
; query 65: function gsm_L_sub, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1821 (ite (bvuge (bvadd in0_64 (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64)))) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x11 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) (bvadd in1_64 (_ bv1 64)))) ((_ sign_extend 1) (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64))))) true)))
(let ((?x653 (bvadd in1_64 (_ bv1 64))))
(let ((?x1658 ((_ sign_extend 1) ?x653)))
(let (($x104 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1658) true)))))
(let (($x88 (or false $x104 (or $x11))))
(let (($x1594 (or false $x88 false)))
(let (($x790 (or $x1594 false false)))
(and (not $x790) (or $x790 (and (distinct ?x1821 ?x1821) true))))))))))))
(check-sat)
; query 66: function gsm_L_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x653 (bvadd in1_64 (_ bv1 64))))
(let ((?x1658 ((_ sign_extend 1) ?x653)))
(let (($x104 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1658) true)))))
(and (not $x104) (or $x104 (and (distinct ?x653 ?x653) true)))))))
(check-sat)
; query 67: function gsm_L_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1869 (ite (bvsle (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x27 (or false false false)))
(let (($x720 (not $x27)))
(and $x720 (or $x27 (and (distinct ?x1869 ?x1869) true)))))))
(check-sat)
; query 68: function gsm_abs, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x966 (or false false)))
(let (($x190 (not $x966)))
(and $x190 (or $x966 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 69: function gsm_abs, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1845 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x966 (or false false)))
(let (($x25 (or $x966 false false)))
(let (($x7 (not $x25)))
(and $x7 (or $x25 (and (distinct ?x1845 ?x1845) true))))))))
(check-sat)
; query 70: function gsm_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_64 () (_ BitVec 64))
(assert
 (let ((?x1903 (ite (bvslt (_ bv32767 64) in5_64) (_ bv1 1) (_ bv0 1))))
(let (($x27 (or false false false)))
(let (($x720 (not $x27)))
(and $x720 (or $x27 (and (distinct ?x1903 ?x1903) true)))))))
(check-sat)
; query 71: function gsm_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x966 (or false false)))
(let (($x190 (not $x966)))
(and $x190 (or $x966 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 72: function gsm_add, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x966 (or false false)))
(let (($x190 (not $x966)))
(and $x190 (or $x966 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 73: function gsm_add, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1876 ((_ sign_extend 48) in1_16)))
(let ((?x1894 ((_ sign_extend 48) in0_16)))
(let ((?x1916 (bvadd ?x1894 ?x1876)))
(let (($x1911 (and (distinct (bvadd ((_ sign_extend 1) ?x1894) ((_ sign_extend 1) ?x1876)) ((_ sign_extend 1) ?x1916)) true)))
(let (($x966 (or false false)))
(let (($x1951 (or $x966 $x966 (or $x1911))))
(and (not $x1951) (or $x1951 (and (distinct ?x1916 ?x1916) true))))))))))
(check-sat)
; query 74: function gsm_add, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1693 (ite (bvsgt (_ bv18446744073709518848 64) (bvadd ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x1876 ((_ sign_extend 48) in1_16)))
(let ((?x1904 ((_ sign_extend 1) ?x1876)))
(let ((?x1894 ((_ sign_extend 48) in0_16)))
(let ((?x1890 ((_ sign_extend 1) ?x1894)))
(let (($x966 (or false false)))
(let (($x1951 (or $x966 $x966 (or (and (distinct (bvadd ?x1890 ?x1904) ((_ sign_extend 1) (bvadd ?x1894 ?x1876))) true)))))
(let (($x1920 (or $x1951 false false)))
(and (not $x1920) (or $x1920 (and (distinct ?x1693 ?x1693) true))))))))))))
(check-sat)
; query 75: function gsm_asl, block 13, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1959 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x27 (or false false false)))
(let (($x720 (not $x27)))
(and $x720 (or $x27 (and (distinct ?x1959 ?x1959) true)))))))
(check-sat)
; query 76: function gsm_asl, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x966 (or false false)))
(let (($x190 (not $x966)))
(and $x190 (or $x966 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 77: function gsm_asl, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x113 ((_ sign_extend 16) in0_16)))
(let ((?x1962 (bvshl ?x113 in1_32)))
(let (($x966 (or false false)))
(let (($x25 (or $x966 false false)))
(let (($x1949 (or $x25 (bvuge in1_32 (_ bv32 32)))))
(let (($x1979 (not $x1949)))
(and $x1979 (or $x1949 (and (distinct ?x1962 ?x1962) true))))))))))
(check-sat)
; query 78: function gsm_asl, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x113 ((_ sign_extend 16) in0_16)))
(let ((?x1962 (bvshl ?x113 in1_32)))
(let ((?x1965 ((_ extract 15 0) ?x1962)))
(let (($x966 (or false false)))
(let (($x25 (or $x966 false false)))
(let (($x1949 (or $x25 (bvuge in1_32 (_ bv32 32)))))
(let (($x1966 (or $x1949 false)))
(let (($x1135 (not $x1966)))
(and $x1135 (or $x1966 (and (distinct ?x1965 ?x1965) true))))))))))))
(check-sat)
; query 79: function gsm_asl, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1973 (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x27 (or false false false)))
(let (($x720 (not $x27)))
(and $x720 (or $x27 (and (distinct ?x1973 ?x1973) true)))))))
(check-sat)
; query 80: function gsm_asl, block 7, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1845 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1808 ((_ zero_extend 31) ?x1845)))
(let (($x966 (or false false)))
(let (($x25 (or $x966 false false)))
(let (($x513 (or $x25 false)))
(and (not $x513) (or $x513 (and (distinct ?x1808 ?x1808) true)))))))))
(check-sat)
; query 81: function gsm_asl, block 7, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1845 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1808 ((_ zero_extend 31) ?x1845)))
(let ((?x1985 (bvsub (_ bv0 32) ?x1808)))
(let (($x840 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1808)) ((_ sign_extend 1) ?x1985)) true)))
(let (($x966 (or false false)))
(let (($x25 (or $x966 false false)))
(let (($x513 (or $x25 false)))
(let (($x649 (or false $x513 (or $x840))))
(and (not $x649) (or $x649 (and (distinct ?x1985 ?x1985) true))))))))))))
(check-sat)
; query 82: function gsm_asl, block 7, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1845 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1808 ((_ zero_extend 31) ?x1845)))
(let ((?x1985 (bvsub (_ bv0 32) ?x1808)))
(let ((?x768 ((_ extract 15 0) ?x1985)))
(let (($x840 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1808)) ((_ sign_extend 1) ?x1985)) true)))
(let (($x966 (or false false)))
(let (($x25 (or $x966 false false)))
(let (($x513 (or $x25 false)))
(let (($x649 (or false $x513 (or $x840))))
(let (($x450 (or $x649 false)))
(and (not $x450) (or $x450 (and (distinct ?x768 ?x768) true))))))))))))))
(check-sat)
; query 83: function gsm_asl, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x966 (or false false)))
(let (($x190 (not $x966)))
(and $x190 (or $x966 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 84: function gsm_asl, block 7, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1845 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x966 (or false false)))
(let (($x25 (or $x966 false false)))
(let (($x7 (not $x25)))
(and $x7 (or $x25 (and (distinct ?x1845 ?x1845) true))))))))
(check-sat)
; query 85: function gsm_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x876 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x27 (or false false false)))
(let (($x720 (not $x27)))
(and $x720 (or $x27 (and (distinct ?x876 ?x876) true)))))))
(check-sat)
; query 86: function gsm_asr, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1973 (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x27 (or false false false)))
(let (($x720 (not $x27)))
(and $x720 (or $x27 (and (distinct ?x1973 ?x1973) true)))))))
(check-sat)
; query 87: function gsm_asr, block 13, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1959 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x27 (or false false false)))
(let (($x720 (not $x27)))
(and $x720 (or $x27 (and (distinct ?x1959 ?x1959) true)))))))
(check-sat)
; query 88: function gsm_asr, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x966 (or false false)))
(let (($x190 (not $x966)))
(and $x190 (or $x966 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 89: function gsm_asr, block 15, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x170 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in1_32))) true)))
(let (($x1935 (or false false (or $x170))))
(and (not $x1935) (or $x1935 (and (distinct (bvsub (_ bv0 32) in1_32) (bvsub (_ bv0 32) in1_32)) true))))))
(check-sat)
; query 90: function gsm_asr, block 15, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1896 (bvsub (_ bv0 32) in1_32)))
(let ((?x113 ((_ sign_extend 16) in0_16)))
(let ((?x708 (bvshl ?x113 ?x1896)))
(let (($x170 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x1896)) true)))
(let (($x1935 (or false false (or $x170))))
(let (($x966 (or false false)))
(let (($x772 (or (or $x966 $x1935 false) (bvuge ?x1896 (_ bv32 32)))))
(and (not $x772) (or $x772 (and (distinct ?x708 ?x708) true)))))))))))
(check-sat)
; query 91: function gsm_asr, block 15, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1896 (bvsub (_ bv0 32) in1_32)))
(let ((?x113 ((_ sign_extend 16) in0_16)))
(let ((?x708 (bvshl ?x113 ?x1896)))
(let ((?x1151 ((_ extract 15 0) ?x708)))
(let (($x170 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x1896)) true)))
(let (($x1935 (or false false (or $x170))))
(let (($x966 (or false false)))
(let (($x772 (or (or $x966 $x1935 false) (bvuge ?x1896 (_ bv32 32)))))
(let (($x884 (or $x772 false)))
(and (not $x884) (or $x884 (and (distinct ?x1151 ?x1151) true)))))))))))))
(check-sat)
; query 92: function gsm_asr, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x966 (or false false)))
(let (($x190 (not $x966)))
(and $x190 (or $x966 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 93: function gsm_asr, block 20, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x113 ((_ sign_extend 16) in0_16)))
(let ((?x969 (bvashr ?x113 in1_32)))
(let (($x966 (or false false)))
(let (($x25 (or $x966 false false)))
(let (($x1949 (or $x25 (bvuge in1_32 (_ bv32 32)))))
(let (($x1979 (not $x1949)))
(and $x1979 (or $x1949 (and (distinct ?x969 ?x969) true))))))))))
(check-sat)
; query 94: function gsm_asr, block 20, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x113 ((_ sign_extend 16) in0_16)))
(let ((?x969 (bvashr ?x113 in1_32)))
(let ((?x147 ((_ extract 15 0) ?x969)))
(let (($x966 (or false false)))
(let (($x25 (or $x966 false false)))
(let (($x1949 (or $x25 (bvuge in1_32 (_ bv32 32)))))
(let (($x1966 (or $x1949 false)))
(let (($x1135 (not $x1966)))
(and $x1135 (or $x1966 (and (distinct ?x147 ?x147) true))))))))))))
(check-sat)
; query 95: function gsm_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x966 (or false false)))
(let (($x190 (not $x966)))
(and $x190 (or $x966 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 96: function gsm_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1845 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x966 (or false false)))
(let (($x25 (or $x966 false false)))
(let (($x7 (not $x25)))
(and $x7 (or $x25 (and (distinct ?x1845 ?x1845) true))))))))
(check-sat)
; query 97: function gsm_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1845 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1808 ((_ zero_extend 31) ?x1845)))
(let (($x966 (or false false)))
(let (($x25 (or $x966 false false)))
(let (($x513 (or $x25 false)))
(and (not $x513) (or $x513 (and (distinct ?x1808 ?x1808) true)))))))))
(check-sat)
; query 98: function gsm_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1845 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1808 ((_ zero_extend 31) ?x1845)))
(let ((?x1985 (bvsub (_ bv0 32) ?x1808)))
(let (($x840 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1808)) ((_ sign_extend 1) ?x1985)) true)))
(let (($x966 (or false false)))
(let (($x25 (or $x966 false false)))
(let (($x513 (or $x25 false)))
(let (($x649 (or false $x513 (or $x840))))
(and (not $x649) (or $x649 (and (distinct ?x1985 ?x1985) true))))))))))))
(check-sat)
; query 99: function gsm_asr, block 4, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1845 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1808 ((_ zero_extend 31) ?x1845)))
(let ((?x1985 (bvsub (_ bv0 32) ?x1808)))
(let ((?x768 ((_ extract 15 0) ?x1985)))
(let (($x840 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1808)) ((_ sign_extend 1) ?x1985)) true)))
(let (($x966 (or false false)))
(let (($x25 (or $x966 false false)))
(let (($x513 (or $x25 false)))
(let (($x649 (or false $x513 (or $x840))))
(let (($x450 (or $x649 false)))
(and (not $x450) (or $x450 (and (distinct ?x768 ?x768) true))))))))))))))
(check-sat)
; query 100: function gsm_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x876 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x27 (or false false false)))
(let (($x720 (not $x27)))
(and $x720 (or $x27 (and (distinct ?x876 ?x876) true)))))))
(check-sat)
; query 101: function gsm_debug_longwords, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in15_32 () (_ BitVec 32))
(assert
 (let ((?x133 (ite (bvslt in15_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x27 (or false false false)))
(let (($x720 (not $x27)))
(and $x720 (or $x27 (and (distinct ?x133 ?x133) true)))))))
(check-sat)
; query 102: function gsm_debug_words, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in16_32 () (_ BitVec 32))
(assert
 (let ((?x247 (ite (bvslt in16_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x27 (or false false false)))
(let (($x720 (not $x27)))
(and $x720 (or $x27 (and (distinct ?x247 ?x247) true)))))))
(check-sat)
; query 103: function gsm_div, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x966 (or false false)))
(let (($x190 (not $x966)))
(and $x190 (or $x966 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 104: function gsm_div, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x966 (or false false)))
(let (($x190 (not $x966)))
(and $x190 (or $x966 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 105: function gsm_div, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x966 (or false false)))
(let (($x190 (not $x966)))
(and $x190 (or $x966 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 106: function gsm_div, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x744 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x56 (and (distinct ?x744 ?x744) true)))
(let (($x966 (or false false)))
(let (($x25 (or $x966 false false)))
(let (($x7 (not $x25)))
(and $x7 (or $x25 $x56))))))))
(check-sat)
; query 107: function gsm_mult, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x966 (or false false)))
(let (($x190 (not $x966)))
(and $x190 (or $x966 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 108: function gsm_mult, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1654 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x966 (or false false)))
(let (($x25 (or $x966 false false)))
(let (($x7 (not $x25)))
(and $x7 (or $x25 (and (distinct ?x1654 ?x1654) true))))))))
(check-sat)
; query 109: function gsm_mult, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x966 (or false false)))
(let (($x190 (not $x966)))
(and $x190 (or $x966 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 110: function gsm_mult, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x966 (or false false)))
(let (($x190 (not $x966)))
(and $x190 (or $x966 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 111: function gsm_mult, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1876 ((_ sign_extend 48) in1_16)))
(let ((?x1894 ((_ sign_extend 48) in0_16)))
(let ((?x1732 (bvmul ?x1894 ?x1876)))
(let (($x1947 (and (distinct (bvmul ((_ sign_extend 64) ?x1894) ((_ sign_extend 64) ?x1876)) ((_ sign_extend 64) ?x1732)) true)))
(let (($x966 (or false false)))
(let (($x594 (or $x966 $x966 (or $x1947))))
(and (not $x594) (or $x594 (and (distinct ?x1732 ?x1732) true))))))))))
(check-sat)
; query 112: function gsm_mult, block 9, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1876 ((_ sign_extend 48) in1_16)))
(let ((?x1894 ((_ sign_extend 48) in0_16)))
(let ((?x1732 (bvmul ?x1894 ?x1876)))
(let ((?x952 (bvashr ?x1732 (_ bv15 64))))
(let (($x65 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1947 (and (distinct (bvmul ((_ sign_extend 64) ?x1894) ((_ sign_extend 64) ?x1876)) ((_ sign_extend 64) ?x1732)) true)))
(let (($x966 (or false false)))
(let (($x594 (or $x966 $x966 (or $x1947))))
(let (($x1393 (or (or $x594 false false) $x65)))
(and (not $x1393) (or $x1393 (and (distinct ?x952 ?x952) true)))))))))))))
(check-sat)
; query 113: function gsm_mult, block 9, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1876 ((_ sign_extend 48) in1_16)))
(let ((?x1894 ((_ sign_extend 48) in0_16)))
(let ((?x1732 (bvmul ?x1894 ?x1876)))
(let ((?x952 (bvashr ?x1732 (_ bv15 64))))
(let ((?x994 ((_ extract 15 0) ?x952)))
(let (($x65 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1947 (and (distinct (bvmul ((_ sign_extend 64) ?x1894) ((_ sign_extend 64) ?x1876)) ((_ sign_extend 64) ?x1732)) true)))
(let (($x966 (or false false)))
(let (($x594 (or $x966 $x966 (or $x1947))))
(let (($x1393 (or (or $x594 false false) $x65)))
(let (($x452 (or $x1393 false)))
(and (not $x452) (or $x452 (and (distinct ?x994 ?x994) true)))))))))))))))
(check-sat)
; query 114: function gsm_mult, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x966 (or false false)))
(let (($x190 (not $x966)))
(and $x190 (or $x966 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 115: function gsm_mult, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1891 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x966 (or false false)))
(let (($x25 (or $x966 false false)))
(let (($x7 (not $x25)))
(and $x7 (or $x25 (and (distinct ?x1891 ?x1891) true))))))))
(check-sat)
; query 116: function gsm_mult_r, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x966 (or false false)))
(let (($x190 (not $x966)))
(and $x190 (or $x966 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 117: function gsm_mult_r, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1891 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x966 (or false false)))
(let (($x25 (or $x966 false false)))
(let (($x7 (not $x25)))
(and $x7 (or $x25 (and (distinct ?x1891 ?x1891) true))))))))
(check-sat)
; query 118: function gsm_mult_r, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x966 (or false false)))
(let (($x190 (not $x966)))
(and $x190 (or $x966 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 119: function gsm_mult_r, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x966 (or false false)))
(let (($x190 (not $x966)))
(and $x190 (or $x966 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 120: function gsm_mult_r, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1876 ((_ sign_extend 48) in1_16)))
(let ((?x1894 ((_ sign_extend 48) in0_16)))
(let ((?x1732 (bvmul ?x1894 ?x1876)))
(let (($x1947 (and (distinct (bvmul ((_ sign_extend 64) ?x1894) ((_ sign_extend 64) ?x1876)) ((_ sign_extend 64) ?x1732)) true)))
(let (($x966 (or false false)))
(let (($x594 (or $x966 $x966 (or $x1947))))
(and (not $x594) (or $x594 (and (distinct ?x1732 ?x1732) true))))))))))
(check-sat)
; query 121: function gsm_mult_r, block 9, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1876 ((_ sign_extend 48) in1_16)))
(let ((?x1894 ((_ sign_extend 48) in0_16)))
(let ((?x1732 (bvmul ?x1894 ?x1876)))
(let ((?x1866 (bvadd ?x1732 (_ bv16384 64))))
(let (($x1892 (and (distinct (bvadd ((_ sign_extend 1) ?x1732) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x1866)) true)))
(let (($x1947 (and (distinct (bvmul ((_ sign_extend 64) ?x1894) ((_ sign_extend 64) ?x1876)) ((_ sign_extend 64) ?x1732)) true)))
(let (($x966 (or false false)))
(let (($x594 (or $x966 $x966 (or $x1947))))
(let (($x1196 (or $x594 false (or $x1892))))
(and (not $x1196) (or $x1196 (and (distinct ?x1866 ?x1866) true)))))))))))))
(check-sat)
; query 122: function gsm_mult_r, block 9, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1876 ((_ sign_extend 48) in1_16)))
(let ((?x1894 ((_ sign_extend 48) in0_16)))
(let ((?x1732 (bvmul ?x1894 ?x1876)))
(let ((?x1866 (bvadd ?x1732 (_ bv16384 64))))
(let ((?x448 (bvashr ?x1866 (_ bv15 64))))
(let (($x65 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1892 (and (distinct (bvadd ((_ sign_extend 1) ?x1732) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x1866)) true)))
(let (($x1947 (and (distinct (bvmul ((_ sign_extend 64) ?x1894) ((_ sign_extend 64) ?x1876)) ((_ sign_extend 64) ?x1732)) true)))
(let (($x966 (or false false)))
(let (($x594 (or $x966 $x966 (or $x1947))))
(let (($x1196 (or $x594 false (or $x1892))))
(let (($x998 (or (or $x1196 false false) $x65)))
(and (not $x998) (or $x998 (and (distinct ?x448 ?x448) true))))))))))))))))
(check-sat)
; query 123: function gsm_mult_r, block 9, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1876 ((_ sign_extend 48) in1_16)))
(let ((?x1894 ((_ sign_extend 48) in0_16)))
(let ((?x1732 (bvmul ?x1894 ?x1876)))
(let ((?x1866 (bvadd ?x1732 (_ bv16384 64))))
(let ((?x448 (bvashr ?x1866 (_ bv15 64))))
(let ((?x715 (bvand ?x448 (_ bv65535 64))))
(let (($x65 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1892 (and (distinct (bvadd ((_ sign_extend 1) ?x1732) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x1866)) true)))
(let (($x1947 (and (distinct (bvmul ((_ sign_extend 64) ?x1894) ((_ sign_extend 64) ?x1876)) ((_ sign_extend 64) ?x1732)) true)))
(let (($x966 (or false false)))
(let (($x594 (or $x966 $x966 (or $x1947))))
(let (($x1196 (or $x594 false (or $x1892))))
(let (($x998 (or (or $x1196 false false) $x65)))
(let (($x359 (or $x998 false false)))
(and (not $x359) (or $x359 (and (distinct ?x715 ?x715) true))))))))))))))))))
(check-sat)
; query 124: function gsm_mult_r, block 9, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1876 ((_ sign_extend 48) in1_16)))
(let ((?x1894 ((_ sign_extend 48) in0_16)))
(let ((?x1732 (bvmul ?x1894 ?x1876)))
(let ((?x1866 (bvadd ?x1732 (_ bv16384 64))))
(let ((?x448 (bvashr ?x1866 (_ bv15 64))))
(let ((?x715 (bvand ?x448 (_ bv65535 64))))
(let ((?x1770 ((_ extract 15 0) ?x715)))
(let (($x65 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1892 (and (distinct (bvadd ((_ sign_extend 1) ?x1732) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x1866)) true)))
(let (($x1947 (and (distinct (bvmul ((_ sign_extend 64) ?x1894) ((_ sign_extend 64) ?x1876)) ((_ sign_extend 64) ?x1732)) true)))
(let (($x966 (or false false)))
(let (($x594 (or $x966 $x966 (or $x1947))))
(let (($x1196 (or $x594 false (or $x1892))))
(let (($x998 (or (or $x1196 false false) $x65)))
(let (($x359 (or $x998 false false)))
(let (($x1764 (or $x359 false)))
(and (not $x1764) (or $x1764 (and (distinct ?x1770 ?x1770) true))))))))))))))))))))
(check-sat)
; query 125: function gsm_mult_r, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x966 (or false false)))
(let (($x190 (not $x966)))
(and $x190 (or $x966 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 126: function gsm_mult_r, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1654 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x966 (or false false)))
(let (($x25 (or $x966 false false)))
(let (($x7 (not $x25)))
(and $x7 (or $x25 (and (distinct ?x1654 ?x1654) true))))))))
(check-sat)
; query 127: function gsm_norm, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1664 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x27 (or false false false)))
(let (($x720 (not $x27)))
(and $x720 (or $x27 (and (distinct ?x1664 ?x1664) true)))))))
(check-sat)
; query 128: function gsm_norm, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1664 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x911 (bvxor ?x1664 (_ bv1 1))))
(let (($x27 (or false false false)))
(let (($x80 (or $x27 false false)))
(let (($x917 (not $x80)))
(and $x917 (or $x80 (and (distinct ?x911 ?x911) true)))))))))
(check-sat)
; query 129: function gsm_norm, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1664 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x911 (bvxor ?x1664 (_ bv1 1))))
(let ((?x707 ((_ zero_extend 31) ?x911)))
(let (($x27 (or false false false)))
(let (($x80 (or $x27 false false)))
(let (($x1624 (or $x80 false)))
(and (not $x1624) (or $x1624 (and (distinct ?x707 ?x707) true))))))))))
(check-sat)
; query 130: function gsm_norm, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1664 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x911 (bvxor ?x1664 (_ bv1 1))))
(let ((?x707 ((_ zero_extend 31) ?x911)))
(let ((?x1467 ((_ sign_extend 32) ?x707)))
(let (($x27 (or false false false)))
(let (($x80 (or $x27 false false)))
(let (($x1624 (or $x80 false)))
(let (($x813 (or $x1624 false)))
(and (not $x813) (or $x813 (and (distinct ?x1467 ?x1467) true))))))))))))
(check-sat)
; query 131: function gsm_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_64 () (_ BitVec 64))
(assert
 (let ((?x1903 (ite (bvslt (_ bv32767 64) in5_64) (_ bv1 1) (_ bv0 1))))
(let (($x27 (or false false false)))
(let (($x720 (not $x27)))
(and $x720 (or $x27 (and (distinct ?x1903 ?x1903) true)))))))
(check-sat)
; query 132: function gsm_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x966 (or false false)))
(let (($x190 (not $x966)))
(and $x190 (or $x966 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 133: function gsm_sub, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x966 (or false false)))
(let (($x190 (not $x966)))
(and $x190 (or $x966 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 134: function gsm_sub, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1876 ((_ sign_extend 48) in1_16)))
(let ((?x1894 ((_ sign_extend 48) in0_16)))
(let ((?x433 (bvsub ?x1894 ?x1876)))
(let (($x1479 (and (distinct (bvsub ((_ sign_extend 1) ?x1894) ((_ sign_extend 1) ?x1876)) ((_ sign_extend 1) ?x433)) true)))
(let (($x966 (or false false)))
(let (($x1344 (or $x966 $x966 (or $x1479))))
(and (not $x1344) (or $x1344 (and (distinct ?x433 ?x433) true))))))))))
(check-sat)
; query 135: function gsm_sub, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x111 (ite (bvsgt (_ bv18446744073709518848 64) (bvsub ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x1876 ((_ sign_extend 48) in1_16)))
(let ((?x1904 ((_ sign_extend 1) ?x1876)))
(let ((?x1894 ((_ sign_extend 48) in0_16)))
(let ((?x1890 ((_ sign_extend 1) ?x1894)))
(let (($x966 (or false false)))
(let (($x1344 (or $x966 $x966 (or (and (distinct (bvsub ?x1890 ?x1904) ((_ sign_extend 1) (bvsub ?x1894 ?x1876))) true)))))
(let (($x1731 (or $x1344 false false)))
(and (not $x1731) (or $x1731 (and (distinct ?x111 ?x111) true))))))))))))
(check-sat)
; query 136: function ok_to_replace, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1359 (ite (and (distinct (_ bv4294967295 32) in.01_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x27 (or false false false)))
(let (($x720 (not $x27)))
(and $x720 (or $x27 (and (distinct ?x1359 ?x1359) true)))))))
(check-sat)
; query 137: function ok_to_replace, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in16_32 () (_ BitVec 32))
(assert
 (let ((?x916 (ite (= (_ bv121 32) in16_32) (_ bv1 1) (_ bv0 1))))
(let (($x27 (or false false false)))
(let (($x720 (not $x27)))
(and $x720 (or $x27 (and (distinct ?x916 ?x916) true)))))))
(check-sat)
; query 138: function suffix, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_64 () (_ BitVec 64))
(declare-fun in3_64 () (_ BitVec 64))
(assert
 (let ((?x698 (ite (bvule in3_64 in4_64) (_ bv1 1) (_ bv0 1))))
(let (($x27 (or false false false)))
(let (($x720 (not $x27)))
(and $x720 (or $x27 (and (distinct ?x698 ?x698) true)))))))
(check-sat)
; query 139: function ulaw_input, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x71 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x480 (or false false (or $x71))))
(and (not $x480) (or $x480 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 140: function ulaw_input, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let ((?x199 (ite (= (_ bv4294967295 32) in.1_32) (_ bv1 1) (_ bv0 1))))
(let (($x27 (or false false false)))
(let (($x720 (not $x27)))
(and $x720 (or $x27 (and (distinct ?x199 ?x199) true)))))))
(check-sat)
