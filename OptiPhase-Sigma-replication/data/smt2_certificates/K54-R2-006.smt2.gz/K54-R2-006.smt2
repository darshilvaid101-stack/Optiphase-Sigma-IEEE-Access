; OptiPhase-Sigma refinement certificate for sweep K54-R2-006
; query 0: function check, block 103, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x86 (ite (= (_ bv22 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x501 (or false false false)))
(let (($x390 (not $x501)))
(and $x390 (or $x501 (and (distinct ?x86 ?x86) true)))))))
(check-sat)
; query 1: function check, block 109, name %110
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x310 (ite (= (_ bv33 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x501 (or false false false)))
(let (($x390 (not $x501)))
(and $x390 (or $x501 (and (distinct ?x310 ?x310) true)))))))
(check-sat)
; query 2: function check, block 115, name %116
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x380 (ite (= (_ bv0 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x501 (or false false false)))
(let (($x390 (not $x501)))
(and $x390 (or $x501 (and (distinct ?x380 ?x380) true)))))))
(check-sat)
; query 3: function check, block 121, name %122
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x385 (ite (= (_ bv12 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x501 (or false false false)))
(let (($x390 (not $x501)))
(and $x390 (or $x501 (and (distinct ?x385 ?x385) true)))))))
(check-sat)
; query 4: function check, block 128, name %129
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x183 (ite (= (_ bv25 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x501 (or false false false)))
(let (($x390 (not $x501)))
(and $x390 (or $x501 (and (distinct ?x183 ?x183) true)))))))
(check-sat)
; query 5: function check, block 135, name %136
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x179 (ite (= (_ bv13 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x501 (or false false false)))
(let (($x390 (not $x501)))
(and $x390 (or $x501 (and (distinct ?x179 ?x179) true)))))))
(check-sat)
; query 6: function check, block 142, name %143
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x120 (ite (= (_ bv123 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x501 (or false false false)))
(let (($x390 (not $x501)))
(and $x390 (or $x501 (and (distinct ?x120 ?x120) true)))))))
(check-sat)
; query 7: function check, block 150, name %151
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x371 (ite (= (_ bv1122 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x501 (or false false false)))
(let (($x390 (not $x501)))
(and $x390 (or $x501 (and (distinct ?x371 ?x371) true)))))))
(check-sat)
; query 8: function check, block 157, name %158
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x43 (ite (= (_ bv112233 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x501 (or false false false)))
(let (($x390 (not $x501)))
(and $x390 (or $x501 (and (distinct ?x43 ?x43) true)))))))
(check-sat)
; query 9: function check, block 165, name %166
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x452 (ite (= (_ bv111 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x501 (or false false false)))
(let (($x390 (not $x501)))
(and $x390 (or $x501 (and (distinct ?x452 ?x452) true)))))))
(check-sat)
; query 10: function check, block 172, name %173
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x235 (ite (= (_ bv4294967295 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x501 (or false false false)))
(let (($x390 (not $x501)))
(and $x390 (or $x501 (and (distinct ?x235 ?x235) true)))))))
(check-sat)
; query 11: function check, block 179, name %180
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x451 (ite (= (_ bv4294967284 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x501 (or false false false)))
(let (($x390 (not $x501)))
(and $x390 (or $x501 (and (distinct ?x451 ?x451) true)))))))
(check-sat)
; query 12: function check, block 25, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_32 () (_ BitVec 32))
(assert
 (let (($x239 (and (distinct (bvadd ((_ sign_extend 1) in.06_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.06_32 (_ bv1 32)))) true)))
(let (($x284 (or false false (or $x239))))
(and (not $x284) (or $x284 (and (distinct (bvadd in.06_32 (_ bv1 32)) (bvadd in.06_32 (_ bv1 32))) true))))))
(check-sat)
; query 13: function check, block 52, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.013_32 () (_ BitVec 32))
(assert
 (let (($x229 (and (distinct (bvadd ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.013_32 (_ bv1 32)))) true)))
(let (($x645 (or false false (or $x229))))
(and (not $x645) (or $x645 (and (distinct (bvadd in.013_32 (_ bv1 32)) (bvadd in.013_32 (_ bv1 32))) true))))))
(check-sat)
; query 14: function check, block 55, name %56
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.012_32 () (_ BitVec 32))
(assert
 (let (($x396 (and (distinct (bvadd ((_ sign_extend 1) in.012_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.012_32 (_ bv1 32)))) true)))
(let (($x225 (or false false (or $x396))))
(and (not $x225) (or $x225 (and (distinct (bvadd in.012_32 (_ bv1 32)) (bvadd in.012_32 (_ bv1 32))) true))))))
(check-sat)
; query 15: function check, block 65, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x779 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x287 (or false false (or $x779))))
(and (not $x287) (or $x287 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 16: function check, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x42 (ite (= (_ bv2 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x501 (or false false false)))
(let (($x390 (not $x501)))
(and $x390 (or $x501 (and (distinct ?x42 ?x42) true)))))))
(check-sat)
; query 17: function check, block 79, name %80
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x45 (ite (= (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x501 (or false false false)))
(let (($x390 (not $x501)))
(and $x390 (or $x501 (and (distinct ?x45 ?x45) true)))))))
(check-sat)
; query 18: function check, block 85, name %86
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x20 (ite (= (_ bv4 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x501 (or false false false)))
(let (($x390 (not $x501)))
(and $x390 (or $x501 (and (distinct ?x20 ?x20) true)))))))
(check-sat)
; query 19: function check, block 91, name %92
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x247 (ite (= (_ bv5 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x501 (or false false false)))
(let (($x390 (not $x501)))
(and $x390 (or $x501 (and (distinct ?x247 ?x247) true)))))))
(check-sat)
; query 20: function check, block 97, name %98
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x40 (ite (= (_ bv11 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x501 (or false false false)))
(let (($x390 (not $x501)))
(and $x390 (or $x501 (and (distinct ?x40 ?x40) true)))))))
(check-sat)
; query 21: function init, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x779 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x287 (or false false (or $x779))))
(and (not $x287) (or $x287 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 22: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x123 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x501 (or false false false)))
(let (($x390 (not $x501)))
(and $x390 (or $x501 (and (distinct ?x123 ?x123) true)))))))
(check-sat)
; query 23: function s321, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x779 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x287 (or false false (or $x779))))
(and (not $x287) (or $x287 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 24: function s321, block 24, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x97 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x154 (or false false (or $x97))))
(and (not $x154) (or $x154 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 25: function s322, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x779 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x287 (or false false (or $x779))))
(and (not $x287) (or $x287 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 26: function s322, block 35, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x97 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x154 (or false false (or $x97))))
(and (not $x154) (or $x154 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 27: function s323, block 35, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x779 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x287 (or false false (or $x779))))
(and (not $x287) (or $x287 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 28: function s323, block 39, name %40
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x97 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x154 (or false false (or $x97))))
(and (not $x154) (or $x154 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 29: function set, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x609 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv5 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv5 32)))) true)))
(let (($x196 (or false false (or $x609))))
(and (not $x196) (or $x196 (and (distinct (bvadd in.01_32 (_ bv5 32)) (bvadd in.01_32 (_ bv5 32))) true))))))
(check-sat)
; query 30: function set, block 46, name %47
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x779 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x287 (or false false (or $x779))))
(and (not $x287) (or $x287 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 31: function set1d, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x295 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x110 (or false false (or $x295))))
(and (not $x110) (or $x110 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 32: function set1d, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x255 (ite (= (_ bv4294967294 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x501 (or false false false)))
(let (($x390 (not $x501)))
(and $x390 (or $x501 (and (distinct ?x255 ?x255) true)))))))
(check-sat)
; query 33: function set1d, block 34, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x97 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x154 (or false false (or $x97))))
(and (not $x154) (or $x154 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 34: function set1d, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x213 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) in2_32)) ((_ sign_extend 1) (bvadd in.0_32 in2_32))) true)))
(let (($x32 (or false false (or $x213))))
(let (($x917 (or $x32 (and (distinct (bvadd in.0_32 in2_32) (bvadd in.0_32 in2_32)) true))))
(and (not $x32) $x917)))))
(check-sat)
; query 35: function set1d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x36 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x501 (or false false false)))
(let (($x390 (not $x501)))
(and $x390 (or $x501 (and (distinct ?x36 ?x36) true)))))))
(check-sat)
; query 36: function set1ds, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x295 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x110 (or false false (or $x295))))
(and (not $x110) (or $x110 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 37: function set1ds, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x346 (ite (= (_ bv4294967294 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x501 (or false false false)))
(let (($x390 (not $x501)))
(and $x390 (or $x501 (and (distinct ?x346 ?x346) true)))))))
(check-sat)
; query 38: function set1ds, block 35, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x97 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x154 (or false false (or $x97))))
(and (not $x154) (or $x154 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 39: function set1ds, block 44, name %45
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x107 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) in3_32)) ((_ sign_extend 1) (bvadd in.0_32 in3_32))) true)))
(let (($x164 (or false false (or $x107))))
(let (($x671 (or $x164 (and (distinct (bvadd in.0_32 in3_32) (bvadd in.0_32 in3_32)) true))))
(and (not $x164) $x671)))))
(check-sat)
; query 40: function set1ds, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x87 (ite (= (_ bv4294967295 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x501 (or false false false)))
(let (($x390 (not $x501)))
(and $x390 (or $x501 (and (distinct ?x87 ?x87) true)))))))
(check-sat)
; query 41: function set2d, block 21, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let (($x487 (and (distinct (bvadd ((_ sign_extend 1) in.04_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.04_32 (_ bv1 32)))) true)))
(let (($x440 (or false false (or $x487))))
(and (not $x440) (or $x440 (and (distinct (bvadd in.04_32 (_ bv1 32)) (bvadd in.04_32 (_ bv1 32))) true))))))
(check-sat)
; query 42: function set2d, block 24, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_32 () (_ BitVec 32))
(assert
 (let (($x202 (and (distinct (bvadd ((_ sign_extend 1) in.03_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.03_32 (_ bv1 32)))) true)))
(let (($x621 (or false false (or $x202))))
(and (not $x621) (or $x621 (and (distinct (bvadd in.03_32 (_ bv1 32)) (bvadd in.03_32 (_ bv1 32))) true))))))
(check-sat)
; query 43: function set2d, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x255 (ite (= (_ bv4294967294 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x501 (or false false false)))
(let (($x390 (not $x501)))
(and $x390 (or $x501 (and (distinct ?x255 ?x255) true)))))))
(check-sat)
; query 44: function set2d, block 47, name %48
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x295 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x110 (or false false (or $x295))))
(and (not $x110) (or $x110 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 45: function set2d, block 50, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.05_32 () (_ BitVec 32))
(assert
 (let (($x595 (and (distinct (bvadd ((_ sign_extend 1) in.05_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.05_32 (_ bv1 32)))) true)))
(let (($x590 (or false false (or $x595))))
(and (not $x590) (or $x590 (and (distinct (bvadd in.05_32 (_ bv1 32)) (bvadd in.05_32 (_ bv1 32))) true))))))
(check-sat)
; query 46: function set2d, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x213 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) in2_32)) ((_ sign_extend 1) (bvadd in.0_32 in2_32))) true)))
(let (($x32 (or false false (or $x213))))
(let (($x917 (or $x32 (and (distinct (bvadd in.0_32 in2_32) (bvadd in.0_32 in2_32)) true))))
(and (not $x32) $x917)))))
(check-sat)
; query 47: function set2d, block 67, name %68
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x97 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x154 (or false false (or $x97))))
(and (not $x154) (or $x154 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 48: function set2d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x36 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x501 (or false false false)))
(let (($x390 (not $x501)))
(and $x390 (or $x501 (and (distinct ?x36 ?x36) true)))))))
(check-sat)
; query 49: function sum1d, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x779 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x287 (or false false (or $x779))))
(and (not $x287) (or $x287 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
