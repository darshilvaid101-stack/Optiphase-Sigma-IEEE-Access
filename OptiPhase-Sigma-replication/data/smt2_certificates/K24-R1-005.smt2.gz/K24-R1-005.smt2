; OptiPhase-Sigma refinement certificate for sweep K24-R1-005
