; OptiPhase-Sigma refinement certificate for sweep K38-R6-021
