; OptiPhase-Sigma refinement certificate for sweep K02-R4-350
