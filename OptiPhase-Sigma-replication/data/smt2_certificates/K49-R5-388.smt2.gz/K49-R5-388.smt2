; OptiPhase-Sigma refinement certificate for sweep K49-R5-388
; query 0: function APCM_inverse_quantization, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x99 (or false false)))
(let (($x92 (not $x99)))
(and $x92 (or $x99 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 1: function APCM_inverse_quantization, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1751 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x99 (or false false)))
(let (($x46 (or $x99 false false)))
(let (($x133 (not $x46)))
(and $x133 (or $x46 (and (distinct ?x1751 ?x1751) true))))))))
(check-sat)
; query 2: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x99 (or false false)))
(let (($x92 (not $x99)))
(and $x92 (or $x99 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 3: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x68 (ite (bvslt (_ bv15 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x99 (or false false)))
(let (($x46 (or $x99 false false)))
(let (($x133 (not $x46)))
(and $x133 (or $x46 (and (distinct ?x68 ?x68) true))))))))
(check-sat)
; query 4: function Coefficients_0_12, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in15_64 () (_ BitVec 64))
(assert
 (let ((?x1771 (ite (bvslt (_ bv0 64) in15_64) (_ bv1 1) (_ bv0 1))))
(let (($x161 (or false false false)))
(let (($x216 (not $x161)))
(and $x216 (or $x161 (and (distinct ?x1771 ?x1771) true)))))))
(check-sat)
; query 5: function Coefficients_0_12, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in15_64 () (_ BitVec 64))
(assert
 (let ((?x1771 (ite (bvslt (_ bv0 64) in15_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1935 ((_ zero_extend 63) ?x1771)))
(let (($x161 (or false false false)))
(let (($x61 (or $x161 false)))
(let (($x121 (not $x61)))
(and $x121 (or $x61 (and (distinct ?x1935 ?x1935) true)))))))))
(check-sat)
; query 6: function Coefficients_0_12, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in15_64 () (_ BitVec 64))
(assert
 (let ((?x1771 (ite (bvslt (_ bv0 64) in15_64) (_ bv1 1) (_ bv0 1))))
(let (($x106 (= (_ bv1 1) ?x1771)))
(let ((?x1711 (ite $x106 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x161 (or false false false)))
(let (($x58 (or $x161 (ite $x106 false false))))
(and (not $x58) (or $x58 (and (distinct ?x1711 ?x1711) true)))))))))
(check-sat)
; query 7: function Coefficients_0_12, block 18, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in15_64 () (_ BitVec 64))
(assert
 (let ((?x1771 (ite (bvslt (_ bv0 64) in15_64) (_ bv1 1) (_ bv0 1))))
(let (($x106 (= (_ bv1 1) ?x1771)))
(let ((?x1711 (ite $x106 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x282 ((_ sign_extend 32) ?x1711)))
(let (($x161 (or false false false)))
(let (($x58 (or $x161 (ite $x106 false false))))
(let (($x1730 (or $x58 false)))
(and (not $x1730) (or $x1730 (and (distinct ?x282 ?x282) true)))))))))))
(check-sat)
; query 8: function Coefficients_13_26, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in15_64 () (_ BitVec 64))
(assert
 (let ((?x1771 (ite (bvslt (_ bv0 64) in15_64) (_ bv1 1) (_ bv0 1))))
(let (($x161 (or false false false)))
(let (($x216 (not $x161)))
(and $x216 (or $x161 (and (distinct ?x1771 ?x1771) true)))))))
(check-sat)
; query 9: function Coefficients_13_26, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in15_64 () (_ BitVec 64))
(assert
 (let ((?x1771 (ite (bvslt (_ bv0 64) in15_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1935 ((_ zero_extend 63) ?x1771)))
(let (($x161 (or false false false)))
(let (($x61 (or $x161 false)))
(let (($x121 (not $x61)))
(and $x121 (or $x61 (and (distinct ?x1935 ?x1935) true)))))))))
(check-sat)
; query 10: function Coefficients_13_26, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in15_64 () (_ BitVec 64))
(assert
 (let ((?x1771 (ite (bvslt (_ bv0 64) in15_64) (_ bv1 1) (_ bv0 1))))
(let (($x106 (= (_ bv1 1) ?x1771)))
(let ((?x1711 (ite $x106 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x161 (or false false false)))
(let (($x58 (or $x161 (ite $x106 false false))))
(and (not $x58) (or $x58 (and (distinct ?x1711 ?x1711) true)))))))))
(check-sat)
; query 11: function Coefficients_13_26, block 18, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in15_64 () (_ BitVec 64))
(assert
 (let ((?x1771 (ite (bvslt (_ bv0 64) in15_64) (_ bv1 1) (_ bv0 1))))
(let (($x106 (= (_ bv1 1) ?x1771)))
(let ((?x1711 (ite $x106 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x282 ((_ sign_extend 32) ?x1711)))
(let (($x161 (or false false false)))
(let (($x58 (or $x161 (ite $x106 false false))))
(let (($x1730 (or $x58 false)))
(and (not $x1730) (or $x1730 (and (distinct ?x282 ?x282) true)))))))))))
(check-sat)
; query 12: function Coefficients_27_39, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in15_64 () (_ BitVec 64))
(assert
 (let ((?x1771 (ite (bvslt (_ bv0 64) in15_64) (_ bv1 1) (_ bv0 1))))
(let (($x161 (or false false false)))
(let (($x216 (not $x161)))
(and $x216 (or $x161 (and (distinct ?x1771 ?x1771) true)))))))
(check-sat)
; query 13: function Coefficients_27_39, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in15_64 () (_ BitVec 64))
(assert
 (let ((?x1771 (ite (bvslt (_ bv0 64) in15_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1935 ((_ zero_extend 63) ?x1771)))
(let (($x161 (or false false false)))
(let (($x61 (or $x161 false)))
(let (($x121 (not $x61)))
(and $x121 (or $x61 (and (distinct ?x1935 ?x1935) true)))))))))
(check-sat)
; query 14: function Coefficients_27_39, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in15_64 () (_ BitVec 64))
(assert
 (let ((?x1771 (ite (bvslt (_ bv0 64) in15_64) (_ bv1 1) (_ bv0 1))))
(let (($x106 (= (_ bv1 1) ?x1771)))
(let ((?x1711 (ite $x106 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x161 (or false false false)))
(let (($x58 (or $x161 (ite $x106 false false))))
(and (not $x58) (or $x58 (and (distinct ?x1711 ?x1711) true)))))))))
(check-sat)
; query 15: function Coefficients_27_39, block 18, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in15_64 () (_ BitVec 64))
(assert
 (let ((?x1771 (ite (bvslt (_ bv0 64) in15_64) (_ bv1 1) (_ bv0 1))))
(let (($x106 (= (_ bv1 1) ?x1771)))
(let ((?x1711 (ite $x106 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x282 ((_ sign_extend 32) ?x1711)))
(let (($x161 (or false false false)))
(let (($x58 (or $x161 (ite $x106 false false))))
(let (($x1730 (or $x58 false)))
(and (not $x1730) (or $x1730 (and (distinct ?x282 ?x282) true)))))))))))
(check-sat)
; query 16: function Decoding_of_the_coded_Log_Area_Ratios, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in6_64 () (_ BitVec 64))
(assert
 (let ((?x1729 (ite (bvslt (_ bv0 64) in6_64) (_ bv1 1) (_ bv0 1))))
(let (($x161 (or false false false)))
(let (($x216 (not $x161)))
(and $x216 (or $x161 (and (distinct ?x1729 ?x1729) true)))))))
(check-sat)
; query 17: function Decoding_of_the_coded_Log_Area_Ratios, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in6_64 () (_ BitVec 64))
(assert
 (let ((?x1729 (ite (bvslt (_ bv0 64) in6_64) (_ bv1 1) (_ bv0 1))))
(let ((?x404 ((_ zero_extend 63) ?x1729)))
(let (($x161 (or false false false)))
(let (($x61 (or $x161 false)))
(let (($x121 (not $x61)))
(and $x121 (or $x61 (and (distinct ?x404 ?x404) true)))))))))
(check-sat)
; query 18: function Decoding_of_the_coded_Log_Area_Ratios, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in6_64 () (_ BitVec 64))
(assert
 (let ((?x1729 (ite (bvslt (_ bv0 64) in6_64) (_ bv1 1) (_ bv0 1))))
(let (($x1213 (= (_ bv1 1) ?x1729)))
(let ((?x1835 (ite $x1213 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x161 (or false false false)))
(let (($x1836 (or $x161 (ite $x1213 false false))))
(and (not $x1836) (or $x1836 (and (distinct ?x1835 ?x1835) true)))))))))
(check-sat)
; query 19: function Decoding_of_the_coded_Log_Area_Ratios, block 9, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in6_64 () (_ BitVec 64))
(assert
 (let ((?x1729 (ite (bvslt (_ bv0 64) in6_64) (_ bv1 1) (_ bv0 1))))
(let (($x1213 (= (_ bv1 1) ?x1729)))
(let ((?x1835 (ite $x1213 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x197 ((_ sign_extend 32) ?x1835)))
(let (($x161 (or false false false)))
(let (($x1836 (or $x161 (ite $x1213 false false))))
(let (($x1721 (or $x1836 false)))
(and (not $x1721) (or $x1721 (and (distinct ?x197 ?x197) true)))))))))))
(check-sat)
; query 20: function Gsm_Coder, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in39_64 () (_ BitVec 64))
(assert
 (let ((?x5 (ite (bvslt (_ bv0 64) in39_64) (_ bv1 1) (_ bv0 1))))
(let (($x161 (or false false false)))
(let (($x216 (not $x161)))
(and $x216 (or $x161 (and (distinct ?x5 ?x5) true)))))))
(check-sat)
; query 21: function Gsm_Coder, block 42, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in39_64 () (_ BitVec 64))
(assert
 (let ((?x5 (ite (bvslt (_ bv0 64) in39_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1742 ((_ zero_extend 63) ?x5)))
(let (($x161 (or false false false)))
(let (($x61 (or $x161 false)))
(let (($x121 (not $x61)))
(and $x121 (or $x61 (and (distinct ?x1742 ?x1742) true)))))))))
(check-sat)
; query 22: function Gsm_Coder, block 42, name %45
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in39_64 () (_ BitVec 64))
(assert
 (let ((?x5 (ite (bvslt (_ bv0 64) in39_64) (_ bv1 1) (_ bv0 1))))
(let (($x24 (= (_ bv1 1) ?x5)))
(let ((?x1847 (ite $x24 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x161 (or false false false)))
(let (($x10 (or $x161 (ite $x24 false false))))
(and (not $x10) (or $x10 (and (distinct ?x1847 ?x1847) true)))))))))
(check-sat)
; query 23: function Gsm_Coder, block 42, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in39_64 () (_ BitVec 64))
(assert
 (let ((?x5 (ite (bvslt (_ bv0 64) in39_64) (_ bv1 1) (_ bv0 1))))
(let (($x24 (= (_ bv1 1) ?x5)))
(let ((?x1847 (ite $x24 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x1712 ((_ sign_extend 32) ?x1847)))
(let (($x161 (or false false false)))
(let (($x10 (or $x161 (ite $x24 false false))))
(let (($x244 (or $x10 false)))
(and (not $x244) (or $x244 (and (distinct ?x1712 ?x1712) true)))))))))))
(check-sat)
; query 24: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x99 (or false false)))
(let (($x92 (not $x99)))
(and $x92 (or $x99 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 25: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x647 (ite (bvsgt (_ bv40 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x99 (or false false)))
(let (($x46 (or $x99 false false)))
(let (($x133 (not $x46)))
(and $x133 (or $x46 (and (distinct ?x647 ?x647) true))))))))
(check-sat)
; query 26: function Postprocessing, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in17_64 () (_ BitVec 64))
(assert
 (let ((?x119 (ite (bvslt (_ bv0 64) in17_64) (_ bv1 1) (_ bv0 1))))
(let (($x161 (or false false false)))
(let (($x216 (not $x161)))
(and $x216 (or $x161 (and (distinct ?x119 ?x119) true)))))))
(check-sat)
; query 27: function Postprocessing, block 20, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in17_64 () (_ BitVec 64))
(assert
 (let ((?x119 (ite (bvslt (_ bv0 64) in17_64) (_ bv1 1) (_ bv0 1))))
(let ((?x136 ((_ zero_extend 63) ?x119)))
(let (($x161 (or false false false)))
(let (($x61 (or $x161 false)))
(let (($x121 (not $x61)))
(and $x121 (or $x61 (and (distinct ?x136 ?x136) true)))))))))
(check-sat)
; query 28: function Postprocessing, block 20, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in17_64 () (_ BitVec 64))
(assert
 (let ((?x119 (ite (bvslt (_ bv0 64) in17_64) (_ bv1 1) (_ bv0 1))))
(let (($x59 (= (_ bv1 1) ?x119)))
(let ((?x95 (ite $x59 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x161 (or false false false)))
(let (($x134 (or $x161 (ite $x59 false false))))
(and (not $x134) (or $x134 (and (distinct ?x95 ?x95) true)))))))))
(check-sat)
; query 29: function Postprocessing, block 20, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in17_64 () (_ BitVec 64))
(assert
 (let ((?x119 (ite (bvslt (_ bv0 64) in17_64) (_ bv1 1) (_ bv0 1))))
(let (($x59 (= (_ bv1 1) ?x119)))
(let ((?x95 (ite $x59 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x140 ((_ sign_extend 32) ?x95)))
(let (($x161 (or false false false)))
(let (($x134 (or $x161 (ite $x59 false false))))
(let (($x31 (or $x134 false)))
(and (not $x31) (or $x31 (and (distinct ?x140 ?x140) true)))))))))))
(check-sat)
; query 30: function Quantization_and_coding, block 11, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in8_64 () (_ BitVec 64))
(assert
 (let ((?x192 (ite (bvslt (_ bv0 64) in8_64) (_ bv1 1) (_ bv0 1))))
(let (($x161 (or false false false)))
(let (($x216 (not $x161)))
(and $x216 (or $x161 (and (distinct ?x192 ?x192) true)))))))
(check-sat)
; query 31: function Quantization_and_coding, block 11, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in8_64 () (_ BitVec 64))
(assert
 (let ((?x192 (ite (bvslt (_ bv0 64) in8_64) (_ bv1 1) (_ bv0 1))))
(let ((?x366 ((_ zero_extend 63) ?x192)))
(let (($x161 (or false false false)))
(let (($x61 (or $x161 false)))
(let (($x121 (not $x61)))
(and $x121 (or $x61 (and (distinct ?x366 ?x366) true)))))))))
(check-sat)
; query 32: function Quantization_and_coding, block 11, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in8_64 () (_ BitVec 64))
(assert
 (let ((?x192 (ite (bvslt (_ bv0 64) in8_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (= (_ bv1 1) ?x192)))
(let ((?x151 (ite $x89 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x161 (or false false false)))
(let (($x146 (or $x161 (ite $x89 false false))))
(and (not $x146) (or $x146 (and (distinct ?x151 ?x151) true)))))))))
(check-sat)
; query 33: function Quantization_and_coding, block 11, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in8_64 () (_ BitVec 64))
(assert
 (let ((?x192 (ite (bvslt (_ bv0 64) in8_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (= (_ bv1 1) ?x192)))
(let ((?x151 (ite $x89 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x402 ((_ sign_extend 32) ?x151)))
(let (($x161 (or false false false)))
(let (($x146 (or $x161 (ite $x89 false false))))
(let (($x383 (or $x146 false)))
(and (not $x383) (or $x383 (and (distinct ?x402 ?x402) true)))))))))))
(check-sat)
; query 34: function Quantization_and_coding, block 111, name %112
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in108_64 () (_ BitVec 64))
(assert
 (let ((?x294 (ite (bvslt (_ bv0 64) in108_64) (_ bv1 1) (_ bv0 1))))
(let (($x161 (or false false false)))
(let (($x216 (not $x161)))
(and $x216 (or $x161 (and (distinct ?x294 ?x294) true)))))))
(check-sat)
; query 35: function Quantization_and_coding, block 111, name %113
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in108_64 () (_ BitVec 64))
(assert
 (let ((?x294 (ite (bvslt (_ bv0 64) in108_64) (_ bv1 1) (_ bv0 1))))
(let ((?x85 ((_ zero_extend 63) ?x294)))
(let (($x161 (or false false false)))
(let (($x61 (or $x161 false)))
(let (($x121 (not $x61)))
(and $x121 (or $x61 (and (distinct ?x85 ?x85) true)))))))))
(check-sat)
; query 36: function Quantization_and_coding, block 111, name %114
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in108_64 () (_ BitVec 64))
(assert
 (let ((?x294 (ite (bvslt (_ bv0 64) in108_64) (_ bv1 1) (_ bv0 1))))
(let (($x145 (= (_ bv1 1) ?x294)))
(let ((?x827 (ite $x145 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x161 (or false false false)))
(let (($x30 (or $x161 (ite $x145 false false))))
(and (not $x30) (or $x30 (and (distinct ?x827 ?x827) true)))))))))
(check-sat)
; query 37: function Quantization_and_coding, block 111, name %115
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in108_64 () (_ BitVec 64))
(assert
 (let ((?x294 (ite (bvslt (_ bv0 64) in108_64) (_ bv1 1) (_ bv0 1))))
(let (($x145 (= (_ bv1 1) ?x294)))
(let ((?x827 (ite $x145 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x23 ((_ sign_extend 32) ?x827)))
(let (($x161 (or false false false)))
(let (($x30 (or $x161 (ite $x145 false false))))
(let (($x626 (or $x30 false)))
(and (not $x626) (or $x626 (and (distinct ?x23 ?x23) true)))))))))))
(check-sat)
; query 38: function RPE_grid_positioning, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x99 (or false false)))
(let (($x92 (not $x99)))
(and $x92 (or $x99 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 39: function RPE_grid_positioning, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x163 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1694 (and (distinct ?x163 ?x163) true)))
(let (($x99 (or false false)))
(let (($x449 (or false $x99 false)))
(and (not $x449) (or $x449 $x1694)))))))
(check-sat)
; query 40: function Short_term_analysis_filtering, block 34, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in31_64 () (_ BitVec 64))
(assert
 (let ((?x86 (ite (bvslt (_ bv0 64) in31_64) (_ bv1 1) (_ bv0 1))))
(let (($x161 (or false false false)))
(let (($x216 (not $x161)))
(and $x216 (or $x161 (and (distinct ?x86 ?x86) true)))))))
(check-sat)
; query 41: function Short_term_analysis_filtering, block 34, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in31_64 () (_ BitVec 64))
(assert
 (let ((?x86 (ite (bvslt (_ bv0 64) in31_64) (_ bv1 1) (_ bv0 1))))
(let ((?x91 ((_ zero_extend 63) ?x86)))
(let (($x161 (or false false false)))
(let (($x61 (or $x161 false)))
(let (($x121 (not $x61)))
(and $x121 (or $x61 (and (distinct ?x91 ?x91) true)))))))))
(check-sat)
; query 42: function Short_term_analysis_filtering, block 34, name %37
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in31_64 () (_ BitVec 64))
(assert
 (let ((?x86 (ite (bvslt (_ bv0 64) in31_64) (_ bv1 1) (_ bv0 1))))
(let (($x1674 (= (_ bv1 1) ?x86)))
(let ((?x301 (ite $x1674 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x161 (or false false false)))
(let (($x1664 (or $x161 (ite $x1674 false false))))
(and (not $x1664) (or $x1664 (and (distinct ?x301 ?x301) true)))))))))
(check-sat)
; query 43: function Short_term_analysis_filtering, block 34, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in31_64 () (_ BitVec 64))
(assert
 (let ((?x86 (ite (bvslt (_ bv0 64) in31_64) (_ bv1 1) (_ bv0 1))))
(let (($x1674 (= (_ bv1 1) ?x86)))
(let ((?x301 (ite $x1674 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x790 ((_ sign_extend 32) ?x301)))
(let (($x161 (or false false false)))
(let (($x1664 (or $x161 (ite $x1674 false false))))
(let (($x1704 (or $x1664 false)))
(and (not $x1704) (or $x1704 (and (distinct ?x790 ?x790) true)))))))))))
(check-sat)
; query 44: function gsm_L_add, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x306 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x161 (or false false false)))
(let (($x216 (not $x161)))
(and $x216 (or $x161 (and (distinct ?x306 ?x306) true)))))))
(check-sat)
; query 45: function gsm_L_add, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x472 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvadd in0_64 in1_64))) true)))
(let (($x1665 (or false false (or $x472))))
(let (($x1904 (or $x1665 (and (distinct (bvadd in0_64 in1_64) (bvadd in0_64 in1_64)) true))))
(and (not $x1665) $x1904)))))
(check-sat)
; query 46: function gsm_L_add, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1658 (bvadd in0_64 (_ bv1 64))))
(let ((?x1734 (bvsub (_ bv0 64) ?x1658)))
(let (($x1884 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1658)) ((_ sign_extend 1) ?x1734)) true)))
(let ((?x1659 ((_ sign_extend 1) ?x1658)))
(let (($x1649 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1659) true)))))
(let (($x408 (or false $x1649 (or $x1884))))
(and (not $x408) (or $x408 (and (distinct ?x1734 ?x1734) true))))))))))
(check-sat)
; query 47: function gsm_L_add, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x612 (bvadd in1_64 (_ bv1 64))))
(let ((?x1676 ((_ sign_extend 1) ?x612)))
(let (($x1824 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1676) true)))))
(and (not $x1824) (or $x1824 (and (distinct ?x612 ?x612) true)))))))
(check-sat)
; query 48: function gsm_L_add, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x612 (bvadd in1_64 (_ bv1 64))))
(let ((?x1942 (bvsub (_ bv0 64) ?x612)))
(let (($x1671 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x612)) ((_ sign_extend 1) ?x1942)) true)))
(let ((?x1676 ((_ sign_extend 1) ?x612)))
(let (($x1824 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1676) true)))))
(let (($x1672 (or false $x1824 (or $x1671))))
(and (not $x1672) (or $x1672 (and (distinct ?x1942 ?x1942) true))))))))))
(check-sat)
; query 49: function gsm_L_add, block 8, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x612 (bvadd in1_64 (_ bv1 64))))
(let ((?x1942 (bvsub (_ bv0 64) ?x612)))
(let ((?x1658 (bvadd in0_64 (_ bv1 64))))
(let ((?x1734 (bvsub (_ bv0 64) ?x1658)))
(let ((?x1924 (bvadd ?x1734 ?x1942)))
(let (($x1671 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x612)) ((_ sign_extend 1) ?x1942)) true)))
(let ((?x1676 ((_ sign_extend 1) ?x612)))
(let (($x1824 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1676) true)))))
(let (($x1672 (or false $x1824 (or $x1671))))
(let (($x1884 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1658)) ((_ sign_extend 1) ?x1734)) true)))
(let ((?x1659 ((_ sign_extend 1) ?x1658)))
(let (($x1649 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1659) true)))))
(let (($x408 (or false $x1649 (or $x1884))))
(let (($x1914 (or $x408 $x1672 false)))
(and (not $x1914) (or $x1914 (and (distinct ?x1924 ?x1924) true))))))))))))))))))
(check-sat)
; query 50: function gsm_L_add, block 8, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x612 (bvadd in1_64 (_ bv1 64))))
(let ((?x1942 (bvsub (_ bv0 64) ?x612)))
(let ((?x1658 (bvadd in0_64 (_ bv1 64))))
(let ((?x1734 (bvsub (_ bv0 64) ?x1658)))
(let ((?x1924 (bvadd ?x1734 ?x1942)))
(let ((?x1657 (ite (bvuge ?x1924 (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x1671 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x612)) ((_ sign_extend 1) ?x1942)) true)))
(let ((?x1676 ((_ sign_extend 1) ?x612)))
(let (($x1824 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1676) true)))))
(let (($x1672 (or false $x1824 (or $x1671))))
(let (($x1884 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1658)) ((_ sign_extend 1) ?x1734)) true)))
(let ((?x1659 ((_ sign_extend 1) ?x1658)))
(let (($x1649 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1659) true)))))
(let (($x408 (or false $x1649 (or $x1884))))
(let (($x1914 (or $x408 $x1672 false)))
(let (($x1744 (or $x1914 false false)))
(and (not $x1744) (or $x1744 (and (distinct ?x1657 ?x1657) true))))))))))))))))))))
(check-sat)
; query 51: function gsm_L_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1658 (bvadd in0_64 (_ bv1 64))))
(let ((?x1659 ((_ sign_extend 1) ?x1658)))
(let (($x1649 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1659) true)))))
(and (not $x1649) (or $x1649 (and (distinct ?x1658 ?x1658) true)))))))
(check-sat)
; query 52: function gsm_L_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1687 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x161 (or false false false)))
(let (($x216 (not $x161)))
(and $x216 (or $x161 (and (distinct ?x1687 ?x1687) true)))))))
(check-sat)
; query 53: function gsm_L_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1669 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x161 (or false false false)))
(let (($x216 (not $x161)))
(and $x216 (or $x161 (and (distinct ?x1669 ?x1669) true)))))))
(check-sat)
; query 54: function gsm_L_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1687 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x161 (or false false false)))
(let (($x216 (not $x161)))
(and $x216 (or $x161 (and (distinct ?x1687 ?x1687) true)))))))
(check-sat)
; query 55: function gsm_L_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1687 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1677 ((_ zero_extend 31) ?x1687)))
(let (($x161 (or false false false)))
(let (($x61 (or $x161 false)))
(let (($x121 (not $x61)))
(and $x121 (or $x61 (and (distinct ?x1677 ?x1677) true)))))))))
(check-sat)
; query 56: function gsm_L_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1687 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1677 ((_ zero_extend 31) ?x1687)))
(let ((?x1688 (bvsub (_ bv0 32) ?x1677)))
(let (($x1686 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1677)) ((_ sign_extend 1) ?x1688)) true)))
(let (($x161 (or false false false)))
(let (($x61 (or $x161 false)))
(let (($x1709 (or false $x61 (or $x1686))))
(and (not $x1709) (or $x1709 (and (distinct ?x1688 ?x1688) true)))))))))))
(check-sat)
; query 57: function gsm_L_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1687 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1677 ((_ zero_extend 31) ?x1687)))
(let ((?x1688 (bvsub (_ bv0 32) ?x1677)))
(let ((?x1758 ((_ sign_extend 32) ?x1688)))
(let (($x1686 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1677)) ((_ sign_extend 1) ?x1688)) true)))
(let (($x161 (or false false false)))
(let (($x61 (or $x161 false)))
(let (($x1709 (or false $x61 (or $x1686))))
(let (($x894 (or $x1709 false)))
(and (not $x894) (or $x894 (and (distinct ?x1758 ?x1758) true)))))))))))))
(check-sat)
; query 58: function gsm_L_asr, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1782 (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x161 (or false false false)))
(let (($x216 (not $x161)))
(and $x216 (or $x161 (and (distinct ?x1782 ?x1782) true)))))))
(check-sat)
; query 59: function gsm_L_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1669 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x161 (or false false false)))
(let (($x216 (not $x161)))
(and $x216 (or $x161 (and (distinct ?x1669 ?x1669) true)))))))
(check-sat)
; query 60: function gsm_L_sub, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x306 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x161 (or false false false)))
(let (($x216 (not $x161)))
(and $x216 (or $x161 (and (distinct ?x306 ?x306) true)))))))
(check-sat)
; query 61: function gsm_L_sub, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x1845 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvsub in0_64 in1_64))) true)))
(let (($x1732 (or false false (or $x1845))))
(let (($x1772 (or $x1732 (and (distinct (bvsub in0_64 in1_64) (bvsub in0_64 in1_64)) true))))
(and (not $x1732) $x1772)))))
(check-sat)
; query 62: function gsm_L_sub, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x612 (bvadd in1_64 (_ bv1 64))))
(let ((?x1942 (bvsub (_ bv0 64) ?x612)))
(let (($x1671 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x612)) ((_ sign_extend 1) ?x1942)) true)))
(let ((?x1676 ((_ sign_extend 1) ?x612)))
(let (($x1824 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1676) true)))))
(let (($x1672 (or false $x1824 (or $x1671))))
(and (not $x1672) (or $x1672 (and (distinct ?x1942 ?x1942) true))))))))))
(check-sat)
; query 63: function gsm_L_sub, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x612 (bvadd in1_64 (_ bv1 64))))
(let ((?x1942 (bvsub (_ bv0 64) ?x612)))
(let ((?x857 (bvadd in0_64 ?x1942)))
(let (($x1671 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x612)) ((_ sign_extend 1) ?x1942)) true)))
(let ((?x1676 ((_ sign_extend 1) ?x612)))
(let (($x1824 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1676) true)))))
(let (($x1672 (or false $x1824 (or $x1671))))
(let (($x1795 (or false $x1672 false)))
(and (not $x1795) (or $x1795 (and (distinct ?x857 ?x857) true))))))))))))
(check-sat)
; query 64: function gsm_L_sub, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1802 (ite (bvuge (bvadd in0_64 (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64)))) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x1671 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) (bvadd in1_64 (_ bv1 64)))) ((_ sign_extend 1) (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64))))) true)))
(let ((?x612 (bvadd in1_64 (_ bv1 64))))
(let ((?x1676 ((_ sign_extend 1) ?x612)))
(let (($x1824 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1676) true)))))
(let (($x1672 (or false $x1824 (or $x1671))))
(let (($x1795 (or false $x1672 false)))
(let (($x1899 (or $x1795 false false)))
(and (not $x1899) (or $x1899 (and (distinct ?x1802 ?x1802) true))))))))))))
(check-sat)
; query 65: function gsm_L_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x612 (bvadd in1_64 (_ bv1 64))))
(let ((?x1676 ((_ sign_extend 1) ?x612)))
(let (($x1824 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1676) true)))))
(and (not $x1824) (or $x1824 (and (distinct ?x612 ?x612) true)))))))
(check-sat)
; query 66: function gsm_L_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1780 (ite (bvsle (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x161 (or false false false)))
(let (($x216 (not $x161)))
(and $x216 (or $x161 (and (distinct ?x1780 ?x1780) true)))))))
(check-sat)
; query 67: function gsm_abs, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x99 (or false false)))
(let (($x92 (not $x99)))
(and $x92 (or $x99 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 68: function gsm_abs, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1789 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x99 (or false false)))
(let (($x46 (or $x99 false false)))
(let (($x133 (not $x46)))
(and $x133 (or $x46 (and (distinct ?x1789 ?x1789) true))))))))
(check-sat)
; query 69: function gsm_abs, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x99 (or false false)))
(let (($x92 (not $x99)))
(and $x92 (or $x99 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 70: function gsm_abs, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1855 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x99 (or false false)))
(let (($x46 (or $x99 false false)))
(let (($x133 (not $x46)))
(and $x133 (or $x46 (and (distinct ?x1855 ?x1855) true))))))))
(check-sat)
; query 71: function gsm_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x99 (or false false)))
(let (($x92 (not $x99)))
(and $x92 (or $x99 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 72: function gsm_add, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x99 (or false false)))
(let (($x92 (not $x99)))
(and $x92 (or $x99 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 73: function gsm_add, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1736 ((_ sign_extend 48) in1_16)))
(let ((?x1781 ((_ sign_extend 48) in0_16)))
(let ((?x1770 (bvadd ?x1781 ?x1736)))
(let (($x1788 (and (distinct (bvadd ((_ sign_extend 1) ?x1781) ((_ sign_extend 1) ?x1736)) ((_ sign_extend 1) ?x1770)) true)))
(let (($x99 (or false false)))
(let (($x1919 (or $x99 $x99 (or $x1788))))
(and (not $x1919) (or $x1919 (and (distinct ?x1770 ?x1770) true))))))))))
(check-sat)
; query 74: function gsm_add, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1776 (ite (bvsgt (_ bv18446744073709518848 64) (bvadd ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x1736 ((_ sign_extend 48) in1_16)))
(let ((?x1799 ((_ sign_extend 1) ?x1736)))
(let ((?x1781 ((_ sign_extend 48) in0_16)))
(let ((?x109 ((_ sign_extend 1) ?x1781)))
(let (($x99 (or false false)))
(let (($x1919 (or $x99 $x99 (or (and (distinct (bvadd ?x109 ?x1799) ((_ sign_extend 1) (bvadd ?x1781 ?x1736))) true)))))
(let (($x1889 (or $x1919 false false)))
(and (not $x1889) (or $x1889 (and (distinct ?x1776 ?x1776) true))))))))))))
(check-sat)
; query 75: function gsm_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1825 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x161 (or false false false)))
(let (($x216 (not $x161)))
(and $x216 (or $x161 (and (distinct ?x1825 ?x1825) true)))))))
(check-sat)
; query 76: function gsm_asr, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x150 (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x161 (or false false false)))
(let (($x216 (not $x161)))
(and $x216 (or $x161 (and (distinct ?x150 ?x150) true)))))))
(check-sat)
; query 77: function gsm_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x99 (or false false)))
(let (($x92 (not $x99)))
(and $x92 (or $x99 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 78: function gsm_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1855 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x99 (or false false)))
(let (($x46 (or $x99 false false)))
(let (($x133 (not $x46)))
(and $x133 (or $x46 (and (distinct ?x1855 ?x1855) true))))))))
(check-sat)
; query 79: function gsm_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1855 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1775 ((_ zero_extend 31) ?x1855)))
(let (($x99 (or false false)))
(let (($x46 (or $x99 false false)))
(let (($x225 (or $x46 false)))
(and (not $x225) (or $x225 (and (distinct ?x1775 ?x1775) true)))))))))
(check-sat)
; query 80: function gsm_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1855 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1775 ((_ zero_extend 31) ?x1855)))
(let ((?x1752 (bvsub (_ bv0 32) ?x1775)))
(let (($x1806 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1775)) ((_ sign_extend 1) ?x1752)) true)))
(let (($x99 (or false false)))
(let (($x46 (or $x99 false false)))
(let (($x225 (or $x46 false)))
(let (($x1912 (or false $x225 (or $x1806))))
(and (not $x1912) (or $x1912 (and (distinct ?x1752 ?x1752) true))))))))))))
(check-sat)
; query 81: function gsm_asr, block 4, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1855 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1775 ((_ zero_extend 31) ?x1855)))
(let ((?x1752 (bvsub (_ bv0 32) ?x1775)))
(let ((?x1911 ((_ extract 15 0) ?x1752)))
(let (($x1806 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1775)) ((_ sign_extend 1) ?x1752)) true)))
(let (($x99 (or false false)))
(let (($x46 (or $x99 false false)))
(let (($x225 (or $x46 false)))
(let (($x1912 (or false $x225 (or $x1806))))
(let (($x39 (or $x1912 false)))
(and (not $x39) (or $x39 (and (distinct ?x1911 ?x1911) true))))))))))))))
(check-sat)
; query 82: function gsm_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1825 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x161 (or false false false)))
(let (($x216 (not $x161)))
(and $x216 (or $x161 (and (distinct ?x1825 ?x1825) true)))))))
(check-sat)
; query 83: function gsm_debug_longwords, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in15_32 () (_ BitVec 32))
(assert
 (let ((?x599 (ite (bvslt in15_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x161 (or false false false)))
(let (($x216 (not $x161)))
(and $x216 (or $x161 (and (distinct ?x599 ?x599) true)))))))
(check-sat)
; query 84: function gsm_debug_words, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in16_32 () (_ BitVec 32))
(assert
 (let ((?x1872 (ite (bvslt in16_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x161 (or false false false)))
(let (($x216 (not $x161)))
(and $x216 (or $x161 (and (distinct ?x1872 ?x1872) true)))))))
(check-sat)
; query 85: function gsm_div, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x99 (or false false)))
(let (($x92 (not $x99)))
(and $x92 (or $x99 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 86: function gsm_div, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x99 (or false false)))
(let (($x92 (not $x99)))
(and $x92 (or $x99 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 87: function gsm_div, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x99 (or false false)))
(let (($x92 (not $x99)))
(and $x92 (or $x99 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 88: function gsm_div, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x163 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1694 (and (distinct ?x163 ?x163) true)))
(let (($x99 (or false false)))
(let (($x46 (or $x99 false false)))
(let (($x133 (not $x46)))
(and $x133 (or $x46 $x1694))))))))
(check-sat)
; query 89: function gsm_norm, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1687 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x161 (or false false false)))
(let (($x216 (not $x161)))
(and $x216 (or $x161 (and (distinct ?x1687 (ite (bvsge (_ bv18446744072635809792 64) in0_64) (_ bv1 1) (_ bv0 1))) true)))))))
(check-sat)
; query 90: function gsm_norm, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x333 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x161 (or false false false)))
(let (($x216 (not $x161)))
(and $x216 (or $x161 (and (distinct ?x333 ?x333) true)))))))
(check-sat)
; query 91: function gsm_norm, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x333 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x1890 (bvxor ?x333 (_ bv1 1))))
(let (($x161 (or false false false)))
(let (($x1926 (or $x161 false false)))
(and (not $x1926) (or $x1926 (and (distinct ?x1890 ?x1890) true))))))))
(check-sat)
; query 92: function gsm_norm, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x333 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x1890 (bvxor ?x333 (_ bv1 1))))
(let ((?x719 ((_ zero_extend 31) ?x1890)))
(let (($x161 (or false false false)))
(let (($x1926 (or $x161 false false)))
(let (($x1952 (or $x1926 false)))
(and (not $x1952) (or $x1952 (and (distinct ?x719 ?x719) true))))))))))
(check-sat)
; query 93: function gsm_norm, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x333 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x1890 (bvxor ?x333 (_ bv1 1))))
(let ((?x719 ((_ zero_extend 31) ?x1890)))
(let ((?x1896 ((_ sign_extend 32) ?x719)))
(let (($x161 (or false false false)))
(let (($x1926 (or $x161 false false)))
(let (($x1952 (or $x1926 false)))
(let (($x1885 (or $x1952 false)))
(and (not $x1885) (or $x1885 (and (distinct ?x1896 ?x1896) true))))))))))))
(check-sat)
; query 94: function gsm_norm, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x333 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x1890 (bvxor ?x333 (_ bv1 1))))
(let ((?x719 ((_ zero_extend 31) ?x1890)))
(let ((?x1896 ((_ sign_extend 32) ?x719)))
(let ((?x1812 (ite (and (distinct (_ bv0 64) ?x1896) true) (_ bv1 1) (_ bv0 1))))
(let (($x161 (or false false false)))
(let (($x1926 (or $x161 false false)))
(let (($x1952 (or $x1926 false)))
(let (($x1885 (or $x1952 false)))
(let (($x1946 (or $x1885 false false)))
(and (not $x1946) (or $x1946 (and (distinct ?x1812 ?x1812) true))))))))))))))
(check-sat)
; query 95: function gsm_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x99 (or false false)))
(let (($x92 (not $x99)))
(and $x92 (or $x99 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 96: function gsm_sub, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x99 (or false false)))
(let (($x92 (not $x99)))
(and $x92 (or $x99 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 97: function gsm_sub, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1736 ((_ sign_extend 48) in1_16)))
(let ((?x1781 ((_ sign_extend 48) in0_16)))
(let ((?x1905 (bvsub ?x1781 ?x1736)))
(let (($x1384 (and (distinct (bvsub ((_ sign_extend 1) ?x1781) ((_ sign_extend 1) ?x1736)) ((_ sign_extend 1) ?x1905)) true)))
(let (($x99 (or false false)))
(let (($x1373 (or $x99 $x99 (or $x1384))))
(and (not $x1373) (or $x1373 (and (distinct ?x1905 ?x1905) true))))))))))
(check-sat)
; query 98: function gsm_sub, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1359 (ite (bvsgt (_ bv18446744073709518848 64) (bvsub ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x1736 ((_ sign_extend 48) in1_16)))
(let ((?x1799 ((_ sign_extend 1) ?x1736)))
(let ((?x1781 ((_ sign_extend 48) in0_16)))
(let ((?x109 ((_ sign_extend 1) ?x1781)))
(let (($x99 (or false false)))
(let (($x1373 (or $x99 $x99 (or (and (distinct (bvsub ?x109 ?x1799) ((_ sign_extend 1) (bvsub ?x1781 ?x1736))) true)))))
(let (($x1369 (or $x1373 false false)))
(and (not $x1369) (or $x1369 (and (distinct ?x1359 ?x1359) true))))))))))))
(check-sat)
; query 99: function process_decode, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let (($x99 (or false false)))
(let (($x92 (not $x99)))
(and $x92 (or $x99 (and (distinct ((_ sign_extend 32) in14_32) ((_ sign_extend 32) in14_32)) true))))))
(check-sat)
; query 100: function process_decode, block 16, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x1358 (ite (and (distinct (_ bv33 64) ((_ sign_extend 32) in14_32)) true) (_ bv1 1) (_ bv0 1))))
(let (($x99 (or false false)))
(let (($x46 (or $x99 false false)))
(let (($x133 (not $x46)))
(and $x133 (or $x46 (and (distinct ?x1358 ?x1358) true))))))))
(check-sat)
; query 101: function process_encode, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_32 () (_ BitVec 32))
(assert
 (let (($x99 (or false false)))
(let (($x92 (not $x99)))
(and $x92 (or $x99 (and (distinct ((_ sign_extend 32) in13_32) ((_ sign_extend 32) in13_32)) true))))))
(check-sat)
; query 102: function process_encode, block 15, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_32 () (_ BitVec 32))
(assert
 (let ((?x1951 (ite (bvult ((_ sign_extend 32) in13_32) (_ bv160 64)) (_ bv1 1) (_ bv0 1))))
(let (($x99 (or false false)))
(let (($x46 (or $x99 false false)))
(let (($x133 (not $x46)))
(and $x133 (or $x46 (and (distinct ?x1951 ?x1951) true))))))))
(check-sat)
