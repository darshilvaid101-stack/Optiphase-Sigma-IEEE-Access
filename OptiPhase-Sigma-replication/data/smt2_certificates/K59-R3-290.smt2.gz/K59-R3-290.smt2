; OptiPhase-Sigma refinement certificate for sweep K59-R3-290
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x126 (or false false)))
(let (($x6 (not $x126)))
(and $x6 (or $x126 (and (distinct ((_ sign_extend 16) in25_16) ((_ sign_extend 16) in25_16)) true))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let ((?x121 (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))))
(let (($x126 (or false false)))
(let (($x74 (or $x126 false false)))
(let (($x39 (not $x74)))
(and $x39 (or $x74 (and (distinct ?x121 ?x121) true))))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x126 (or false false)))
(let (($x6 (not $x126)))
(and $x6 (or $x126 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x1108 ((_ sign_extend 16) in3_16)))
(let ((?x1503 (bvand ?x1108 (_ bv127 32))))
(let (($x126 (or false false)))
(let (($x74 (or $x126 false false)))
(let (($x39 (not $x74)))
(and $x39 (or $x74 (and (distinct ?x1503 ?x1503) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x1108 ((_ sign_extend 16) in3_16)))
(let ((?x1503 (bvand ?x1108 (_ bv127 32))))
(let ((?x10 ((_ extract 15 0) ?x1503)))
(let (($x126 (or false false)))
(let (($x74 (or $x126 false false)))
(let (($x2150 (or $x74 false)))
(let (($x2655 (not $x2150)))
(and $x2655 (or $x2150 (and (distinct ?x10 ?x10) true)))))))))))
(check-sat)
; query 5: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x126 (or false false)))
(let (($x6 (not $x126)))
(and $x6 (or $x126 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 6: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x494 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x126 (or false false)))
(let (($x74 (or $x126 false false)))
(let (($x39 (not $x74)))
(and $x39 (or $x74 (and (distinct ?x494 ?x494) true))))))))
(check-sat)
; query 7: function core_bench_list, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x83 (or false false false)))
(let (($x62 (not $x83)))
(and $x62 (or $x83 (and (distinct (bvadd in.0_16 (_ bv1 16)) (bvadd in.0_16 (_ bv1 16))) true))))))
(check-sat)
; query 8: function core_bench_list, block 82, name %83
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let (($x126 (or false false)))
(let (($x6 (not $x126)))
(and $x6 (or $x126 (and (distinct ((_ zero_extend 16) in.02_16) ((_ zero_extend 16) in.02_16)) true))))))
(check-sat)
; query 9: function core_bench_list, block 82, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x11 ((_ zero_extend 16) in.02_16)))
(let ((?x467 (bvmul ?x11 (_ bv4 32))))
(let (($x118 (and (distinct (bvmul ((_ sign_extend 32) ?x11) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x467)) true)))
(let (($x126 (or false false)))
(let (($x768 (or $x126 false (or $x118))))
(and (not $x768) (or $x768 (and (distinct ?x467 ?x467) true)))))))))
(check-sat)
; query 10: function core_bench_list, block 82, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let (($x126 (or false false)))
(let (($x6 (not $x126)))
(and $x6 (or $x126 (and (distinct ((_ zero_extend 16) in.04_16) ((_ zero_extend 16) in.04_16)) true))))))
(check-sat)
; query 11: function core_bench_list, block 82, name %86
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x11 ((_ zero_extend 16) in.02_16)))
(let ((?x467 (bvmul ?x11 (_ bv4 32))))
(let ((?x215 (bvadd ?x467 (bvsub (_ bv0 32) ((_ zero_extend 16) in.04_16)))))
(let ((?x876 ((_ zero_extend 16) in.04_16)))
(let ((?x1235 (bvsub ?x467 ?x876)))
(let (($x118 (and (distinct (bvmul ((_ sign_extend 32) ?x11) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x467)) true)))
(let (($x126 (or false false)))
(let (($x768 (or $x126 false (or $x118))))
(let (($x72 (or $x768 (or false $x126 false) false)))
(let ((?x1607 ((_ sign_extend 1) ?x1235)))
(let (($x2660 (or $x768 $x126 (or (and (distinct (bvsub ((_ sign_extend 1) ?x467) ((_ sign_extend 1) ?x876)) ?x1607) true)))))
(and (not $x2660) (or $x72 (and (distinct ?x1235 ?x215) true)))))))))))))))
(check-sat)
; query 12: function core_bench_list, block 82, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x126 (or false false)))
(let (($x6 (not $x126)))
(and $x6 (or $x126 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 13: function core_bench_list, block 82, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x1309 ((_ zero_extend 16) in.01_16)))
(let ((?x11 ((_ zero_extend 16) in.02_16)))
(let ((?x467 (bvmul ?x11 (_ bv4 32))))
(let ((?x215 (bvadd ?x467 (bvsub (_ bv0 32) ((_ zero_extend 16) in.04_16)))))
(let ((?x33 (bvadd ?x215 ?x1309)))
(let ((?x876 ((_ zero_extend 16) in.04_16)))
(let ((?x1235 (bvsub ?x467 ?x876)))
(let ((?x1319 (bvadd ?x1309 ?x1235)))
(let (($x79 (and (distinct (bvadd ((_ sign_extend 1) ?x215) ((_ sign_extend 1) ?x1309)) ((_ sign_extend 1) ?x33)) true)))
(let (($x126 (or false false)))
(let (($x118 (and (distinct (bvmul ((_ sign_extend 32) ?x11) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x467)) true)))
(let (($x768 (or $x126 false (or $x118))))
(let (($x72 (or $x768 (or false $x126 false) false)))
(let (($x172 (or $x72 $x126 (or $x79))))
(let (($x31 (and (distinct (bvadd ((_ sign_extend 1) ?x1309) ((_ sign_extend 1) ?x1235)) ((_ sign_extend 1) ?x1319)) true)))
(let ((?x1607 ((_ sign_extend 1) ?x1235)))
(let (($x2660 (or $x768 $x126 (or (and (distinct (bvsub ((_ sign_extend 1) ?x467) ((_ sign_extend 1) ?x876)) ?x1607) true)))))
(let (($x1119 (or $x126 $x2660 (or $x31))))
(and (not $x1119) (or $x172 (and (distinct ?x1319 ?x33) true))))))))))))))))))))))
(check-sat)
; query 14: function core_bench_list, block 82, name %89
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x1309 ((_ zero_extend 16) in.01_16)))
(let ((?x11 ((_ zero_extend 16) in.02_16)))
(let ((?x467 (bvmul ?x11 (_ bv4 32))))
(let ((?x215 (bvadd ?x467 (bvsub (_ bv0 32) ((_ zero_extend 16) in.04_16)))))
(let ((?x33 (bvadd ?x215 ?x1309)))
(let (($x842 (and (distinct ((_ extract 15 0) (bvadd ?x1309 (bvsub ?x467 ((_ zero_extend 16) in.04_16)))) ((_ extract 15 0) ?x33)) true)))
(let (($x79 (and (distinct (bvadd ((_ sign_extend 1) ?x215) ((_ sign_extend 1) ?x1309)) ((_ sign_extend 1) ?x33)) true)))
(let (($x126 (or false false)))
(let (($x118 (and (distinct (bvmul ((_ sign_extend 32) ?x11) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x467)) true)))
(let (($x768 (or $x126 false (or $x118))))
(let (($x72 (or $x768 (or false $x126 false) false)))
(let (($x172 (or $x72 $x126 (or $x79))))
(let ((?x876 ((_ zero_extend 16) in.04_16)))
(let ((?x1235 (bvsub ?x467 ?x876)))
(let ((?x1607 ((_ sign_extend 1) ?x1235)))
(let ((?x618 ((_ sign_extend 1) ?x1309)))
(let (($x2660 (or $x768 $x126 (or (and (distinct (bvsub ((_ sign_extend 1) ?x467) ((_ sign_extend 1) ?x876)) ?x1607) true)))))
(let (($x1119 (or $x126 $x2660 (or (and (distinct (bvadd ?x618 ?x1607) ((_ sign_extend 1) (bvadd ?x1309 ?x1235))) true)))))
(and (not (or $x1119 false)) (or (or $x172 false) $x842)))))))))))))))))))))
(check-sat)
; query 15: function core_bench_list, block 82, name %90
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x126 (or false false)))
(let (($x6 (not $x126)))
(and $x6 (or $x126 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 16: function core_bench_list, block 82, name %91
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x2658 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x126 (or false false)))
(let (($x74 (or $x126 false false)))
(let (($x39 (not $x74)))
(and $x39 (or $x74 (and (distinct ?x2658 ?x2658) true))))))))
(check-sat)
; query 17: function core_bench_state, block 105, name %106
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x83 (or false false false)))
(let (($x62 (not $x83)))
(and $x62 (or $x83 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 18: function core_bench_state, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x83 (or false false false)))
(let (($x62 (not $x83)))
(and $x62 (or $x83 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 19: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x4348 (bvadd in.01_32 (_ bv1 32))))
(let (($x2462 (and (distinct ?x4348 ?x4348) true)))
(let (($x83 (or false false false)))
(let (($x62 (not $x83)))
(and $x62 (or $x83 $x2462)))))))
(check-sat)
; query 20: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x4348 (bvadd in.01_32 (_ bv1 32))))
(let ((?x9334 (bvmul ?x4348 (_ bv8 32))))
(let ((?x81 (bvmul ?x4348 ?x4348)))
(let (($x83 (or false false false)))
(let (($x2864 (or $x83 false false)))
(and (not (or $x83 $x83 false)) (or $x2864 (and (distinct ?x81 ?x9334) true)))))))))
(check-sat)
; query 21: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x2206 (and (distinct (bvmul (bvmul (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) (_ bv2 32)) (bvmul (bvmul (bvadd in.01_32 (_ bv1 32)) (_ bv8 32)) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x83 (or false false false)))
(let (($x2864 (or $x83 false false)))
(and (not (or (or $x83 $x83 false) false false)) (or (or $x2864 $x83 false) $x2206))))))
(check-sat)
; query 22: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x2972 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x83 (or false false false)))
(let (($x62 (not $x83)))
(and $x62 (or $x83 (and (distinct ?x2972 ?x2972) true)))))))
(check-sat)
; query 23: function core_init_state, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_32 () (_ BitVec 32))
(assert
 (let (($x83 (or false false false)))
(let (($x62 (not $x83)))
(and $x62 (or $x83 (and (distinct (bvadd in.06_32 (_ bv1 32)) (bvadd in.06_32 (_ bv1 32))) true))))))
(check-sat)
; query 24: function core_init_state, block 65, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let (($x83 (or false false false)))
(let (($x62 (not $x83)))
(and $x62 (or $x83 (and (distinct (bvadd in4_32 (_ bv1 32)) (bvadd in4_32 (_ bv1 32))) true))))))
(check-sat)
; query 25: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x711 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x83 (or false false false)))
(let (($x62 (not $x83)))
(and $x62 (or $x83 (and (distinct ?x711 ?x711) true)))))))
(check-sat)
; query 26: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x83 (or false false false)))
(let (($x62 (not $x83)))
(and $x62 (or $x83 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 27: function core_list_init, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x4348 (bvadd in.01_32 (_ bv1 32))))
(let (($x2462 (and (distinct ?x4348 ?x4348) true)))
(let (($x83 (or false false false)))
(let (($x62 (not $x83)))
(and $x62 (or $x83 $x2462)))))))
(check-sat)
; query 28: function core_list_mergesort, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x4348 (bvadd in.01_32 (_ bv1 32))))
(let (($x2462 (and (distinct ?x4348 ?x4348) true)))
(let (($x2003 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x4348)) true)))
(let (($x2149 (or false false (or $x2003))))
(and (not $x2149) (or $x2149 $x2462)))))))
(check-sat)
; query 29: function core_list_mergesort, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x9740 (ite (bvslt (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x83 (or false false false)))
(let (($x62 (not $x83)))
(and $x62 (or $x83 (and (distinct ?x9740 ?x9740) true)))))))
(check-sat)
; query 30: function core_list_mergesort, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.224_32 () (_ BitVec 32))
(assert
 (let ((?x436 (ite (= (_ bv0 32) in.224_32) (_ bv1 1) (_ bv0 1))))
(let (($x83 (or false false false)))
(let (($x62 (not $x83)))
(and $x62 (or $x83 (and (distinct ?x436 ?x436) true)))))))
(check-sat)
; query 31: function core_list_mergesort, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x2074 (ite (= (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x83 (or false false false)))
(let (($x62 (not $x83)))
(and $x62 (or $x83 (and (distinct ?x2074 ?x2074) true)))))))
(check-sat)
; query 32: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x685 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x3920 (or false false (or $x685))))
(and (not $x3920) (or $x3920 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 33: function core_list_mergesort, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x452 (and (distinct (bvmul ((_ sign_extend 32) in.020_32) ((_ sign_extend 32) (_ bv2 32))) ((_ sign_extend 32) (bvmul in.020_32 (_ bv2 32)))) true)))
(let (($x8261 (or false false (or $x452))))
(and (not $x8261) (or $x8261 (and (distinct (bvmul in.020_32 (_ bv2 32)) (bvmul in.020_32 (_ bv2 32))) true))))))
(check-sat)
; query 34: function core_state_transition, block 102, name %103
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x126 (or false false)))
(let (($x6 (not $x126)))
(and $x6 (or $x126 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 35: function core_state_transition, block 102, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x8549 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x126 (or false false)))
(let (($x74 (or $x126 false false)))
(let (($x39 (not $x74)))
(and $x39 (or $x74 (and (distinct ?x8549 ?x8549) true))))))))
(check-sat)
; query 36: function core_state_transition, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x126 (or false false)))
(let (($x6 (not $x126)))
(and $x6 (or $x126 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 37: function core_state_transition, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x42 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x126 (or false false)))
(let (($x74 (or $x126 false false)))
(let (($x39 (not $x74)))
(and $x39 (or $x74 (and (distinct ?x42 ?x42) true))))))))
(check-sat)
; query 38: function core_state_transition, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x126 (or false false)))
(let (($x6 (not $x126)))
(and $x6 (or $x126 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 39: function core_state_transition, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x8549 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x126 (or false false)))
(let (($x74 (or $x126 false false)))
(let (($x39 (not $x74)))
(and $x39 (or $x74 (and (distinct ?x8549 ?x8549) true))))))))
(check-sat)
; query 40: function core_state_transition, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x126 (or false false)))
(let (($x6 (not $x126)))
(and $x6 (or $x126 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 41: function core_state_transition, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x8072 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x126 (or false false)))
(let (($x74 (or $x126 false false)))
(let (($x39 (not $x74)))
(and $x39 (or $x74 (and (distinct ?x8072 ?x8072) true))))))))
(check-sat)
; query 42: function core_state_transition, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x126 (or false false)))
(let (($x6 (not $x126)))
(and $x6 (or $x126 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 43: function core_state_transition, block 51, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x8072 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x126 (or false false)))
(let (($x74 (or $x126 false false)))
(let (($x39 (not $x74)))
(and $x39 (or $x74 (and (distinct ?x8072 ?x8072) true))))))))
(check-sat)
; query 44: function core_state_transition, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x126 (or false false)))
(let (($x6 (not $x126)))
(and $x6 (or $x126 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 45: function core_state_transition, block 64, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x8072 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x126 (or false false)))
(let (($x74 (or $x126 false false)))
(let (($x39 (not $x74)))
(and $x39 (or $x74 (and (distinct ?x8072 ?x8072) true))))))))
(check-sat)
; query 46: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x1300 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x83 (or false false false)))
(let (($x62 (not $x83)))
(and $x62 (or $x83 (and (distinct ?x1300 ?x1300) true)))))))
(check-sat)
; query 47: function core_state_transition, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x126 (or false false)))
(let (($x6 (not $x126)))
(and $x6 (or $x126 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 48: function core_state_transition, block 80, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x807 (ite (= (_ bv69 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x126 (or false false)))
(let (($x74 (or $x126 false false)))
(let (($x39 (not $x74)))
(and $x39 (or $x74 (and (distinct ?x807 ?x807) true))))))))
(check-sat)
; query 49: function core_state_transition, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x126 (or false false)))
(let (($x6 (not $x126)))
(and $x6 (or $x126 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 50: function core_state_transition, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x7988 (ite (= (_ bv101 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x126 (or false false)))
(let (($x74 (or $x126 false false)))
(let (($x39 (not $x74)))
(and $x39 (or $x74 (and (distinct ?x7988 ?x7988) true))))))))
(check-sat)
; query 51: function core_state_transition, block 99, name %100
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x126 (or false false)))
(let (($x6 (not $x126)))
(and $x6 (or $x126 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 52: function core_state_transition, block 99, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x42 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x126 (or false false)))
(let (($x74 (or $x126 false false)))
(let (($x39 (not $x74)))
(and $x39 (or $x74 (and (distinct ?x42 ?x42) true))))))))
(check-sat)
; query 53: function crcu8, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x126 (or false false)))
(let (($x6 (not $x126)))
(and $x6 (or $x126 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 54: function crcu8, block 19, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x1309 ((_ zero_extend 16) in.01_16)))
(let ((?x4676 (bvxor ?x1309 (_ bv16386 32))))
(let (($x126 (or false false)))
(let (($x74 (or $x126 false false)))
(let (($x39 (not $x74)))
(and $x39 (or $x74 (and (distinct ?x4676 ?x4676) true)))))))))
(check-sat)
; query 55: function crcu8, block 19, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x1309 ((_ zero_extend 16) in.01_16)))
(let ((?x4676 (bvxor ?x1309 (_ bv16386 32))))
(let ((?x5185 ((_ extract 15 0) ?x4676)))
(let (($x126 (or false false)))
(let (($x74 (or $x126 false false)))
(let (($x2150 (or $x74 false)))
(let (($x2655 (not $x2150)))
(and $x2655 (or $x2150 (and (distinct ?x5185 ?x5185) true)))))))))))
(check-sat)
; query 56: function crcu8, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x126 (or false false)))
(let (($x6 (not $x126)))
(and $x6 (or $x126 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 57: function crcu8, block 29, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1899 ((_ zero_extend 16) in27_16)))
(let ((?x1160 (bvor ?x1899 (_ bv32768 32))))
(let (($x126 (or false false)))
(let (($x74 (or $x126 false false)))
(let (($x39 (not $x74)))
(and $x39 (or $x74 (and (distinct ?x1160 ?x1160) true)))))))))
(check-sat)
; query 58: function crcu8, block 29, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1899 ((_ zero_extend 16) in27_16)))
(let ((?x1160 (bvor ?x1899 (_ bv32768 32))))
(let ((?x3970 ((_ extract 15 0) ?x1160)))
(let (($x126 (or false false)))
(let (($x74 (or $x126 false false)))
(let (($x2150 (or $x74 false)))
(let (($x2655 (not $x2150)))
(and $x2655 (or $x2150 (and (distinct ?x3970 ?x3970) true)))))))))))
(check-sat)
; query 59: function crcu8, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x126 (or false false)))
(let (($x6 (not $x126)))
(and $x6 (or $x126 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 60: function crcu8, block 33, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1899 ((_ zero_extend 16) in27_16)))
(let ((?x8615 (bvand ?x1899 (_ bv32767 32))))
(let (($x126 (or false false)))
(let (($x74 (or $x126 false false)))
(let (($x39 (not $x74)))
(and $x39 (or $x74 (and (distinct ?x8615 ?x8615) true)))))))))
(check-sat)
; query 61: function crcu8, block 33, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1899 ((_ zero_extend 16) in27_16)))
(let ((?x8615 (bvand ?x1899 (_ bv32767 32))))
(let ((?x8617 ((_ extract 15 0) ?x8615)))
(let (($x126 (or false false)))
(let (($x74 (or $x126 false false)))
(let (($x2150 (or $x74 false)))
(let (($x2655 (not $x2150)))
(and $x2655 (or $x2150 (and (distinct ?x8617 ?x8617) true)))))))))))
(check-sat)
; query 62: function crcu8, block 38, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_8 () (_ BitVec 8))
(assert
 (let (($x83 (or false false false)))
(let (($x62 (not $x83)))
(and $x62 (or $x83 (and (distinct (bvadd in.02_8 (_ bv1 8)) (bvadd in.02_8 (_ bv1 8))) true))))))
(check-sat)
; query 63: function crcu8, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x3082 ((_ extract 7 0) in.01_16)))
(let ((?x8305 ((_ zero_extend 24) ?x3082)))
(let (($x126 (or false false)))
(let (($x8293 (or $x126 false)))
(and (not $x8293) (or $x8293 (and (distinct ?x8305 ?x8305) true))))))))
(check-sat)
; query 64: function crcu8, block 6, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x3082 ((_ extract 7 0) in.01_16)))
(let ((?x8305 ((_ zero_extend 24) ?x3082)))
(let ((?x4631 (bvand ?x8305 (_ bv1 32))))
(let (($x126 (or false false)))
(let (($x8293 (or $x126 false)))
(let (($x233 (or $x8293 false false)))
(and (not $x233) (or $x233 (and (distinct ?x4631 ?x4631) true))))))))))
(check-sat)
; query 65: function crcu8, block 6, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x3082 ((_ extract 7 0) in.01_16)))
(let ((?x8305 ((_ zero_extend 24) ?x3082)))
(let ((?x4631 (bvand ?x8305 (_ bv1 32))))
(let ((?x2946 ((_ zero_extend 24) in.0_8)))
(let ((?x2941 (bvand ?x2946 (_ bv1 32))))
(let ((?x8573 (bvxor ?x2941 ?x4631)))
(let (($x126 (or false false)))
(let (($x8293 (or $x126 false)))
(let (($x233 (or $x8293 false false)))
(let (($x74 (or $x126 false false)))
(let (($x1670 (or $x74 $x233 false)))
(and (not $x1670) (or $x1670 (and (distinct ?x8573 ?x8573) true)))))))))))))))
(check-sat)
; query 66: function crcu8, block 6, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x3082 ((_ extract 7 0) in.01_16)))
(let ((?x8305 ((_ zero_extend 24) ?x3082)))
(let ((?x4631 (bvand ?x8305 (_ bv1 32))))
(let ((?x2946 ((_ zero_extend 24) in.0_8)))
(let ((?x2941 (bvand ?x2946 (_ bv1 32))))
(let ((?x8573 (bvxor ?x2941 ?x4631)))
(let ((?x638 ((_ extract 7 0) ?x8573)))
(let (($x126 (or false false)))
(let (($x8293 (or $x126 false)))
(let (($x233 (or $x8293 false false)))
(let (($x74 (or $x126 false false)))
(let (($x1670 (or $x74 $x233 false)))
(let (($x10137 (or $x1670 false)))
(and (not $x10137) (or $x10137 (and (distinct ?x638 ?x638) true)))))))))))))))))
(check-sat)
; query 67: function crcu8, block 6, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x126 (or false false)))
(let (($x6 (not $x126)))
(and $x6 (or $x126 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 68: function crcu8, block 6, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x2946 ((_ zero_extend 24) in.0_8)))
(let ((?x3292 (bvashr ?x2946 (_ bv1 32))))
(let (($x126 (or false false)))
(let (($x74 (or $x126 false false)))
(let (($x1974 (or $x74 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not $x1974) (or $x1974 (and (distinct ?x3292 ?x3292) true)))))))))
(check-sat)
; query 69: function crcu8, block 6, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x2946 ((_ zero_extend 24) in.0_8)))
(let ((?x3292 (bvashr ?x2946 (_ bv1 32))))
(let ((?x1205 ((_ extract 7 0) ?x3292)))
(let (($x126 (or false false)))
(let (($x74 (or $x126 false false)))
(let (($x1974 (or $x74 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x2409 (or $x1974 false)))
(and (not $x2409) (or $x2409 (and (distinct ?x1205 ?x1205) true)))))))))))
(check-sat)
; query 70: function crcu8, block 6, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x3082 ((_ extract 7 0) in.01_16)))
(let ((?x8305 ((_ zero_extend 24) ?x3082)))
(let ((?x4631 (bvand ?x8305 (_ bv1 32))))
(let ((?x2946 ((_ zero_extend 24) in.0_8)))
(let ((?x2941 (bvand ?x2946 (_ bv1 32))))
(let ((?x8573 (bvxor ?x2941 ?x4631)))
(let ((?x638 ((_ extract 7 0) ?x8573)))
(let ((?x664 ((_ zero_extend 24) ?x638)))
(let (($x126 (or false false)))
(let (($x8293 (or $x126 false)))
(let (($x233 (or $x8293 false false)))
(let (($x74 (or $x126 false false)))
(let (($x1670 (or $x74 $x233 false)))
(let (($x10137 (or $x1670 false)))
(let (($x4259 (or $x10137 false)))
(and (not $x4259) (or $x4259 (and (distinct ?x664 ?x664) true)))))))))))))))))))
(check-sat)
; query 71: function crcu8, block 6, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x3082 ((_ extract 7 0) in.01_16)))
(let ((?x8305 ((_ zero_extend 24) ?x3082)))
(let ((?x4631 (bvand ?x8305 (_ bv1 32))))
(let ((?x2946 ((_ zero_extend 24) in.0_8)))
(let ((?x2941 (bvand ?x2946 (_ bv1 32))))
(let ((?x8573 (bvxor ?x2941 ?x4631)))
(let ((?x638 ((_ extract 7 0) ?x8573)))
(let ((?x664 ((_ zero_extend 24) ?x638)))
(let ((?x3015 (ite (= (_ bv1 32) ?x664) (_ bv1 1) (_ bv0 1))))
(let (($x126 (or false false)))
(let (($x8293 (or $x126 false)))
(let (($x233 (or $x8293 false false)))
(let (($x74 (or $x126 false false)))
(let (($x1670 (or $x74 $x233 false)))
(let (($x10137 (or $x1670 false)))
(let (($x4259 (or $x10137 false)))
(let (($x4256 (or $x4259 false false)))
(and (not $x4256) (or $x4256 (and (distinct ?x3015 ?x3015) true)))))))))))))))))))))
(check-sat)
; query 72: function crcu8, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x126 (or false false)))
(let (($x6 (not $x126)))
(and $x6 (or $x126 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 73: function crcu8, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x2946 ((_ zero_extend 24) in.0_8)))
(let ((?x2941 (bvand ?x2946 (_ bv1 32))))
(let (($x126 (or false false)))
(let (($x74 (or $x126 false false)))
(let (($x39 (not $x74)))
(and $x39 (or $x74 (and (distinct ?x2941 ?x2941) true)))))))))
(check-sat)
; query 74: function crcu8, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x126 (or false false)))
(let (($x6 (not $x126)))
(and $x6 (or $x126 (and (distinct ((_ extract 7 0) in.01_16) ((_ extract 7 0) in.01_16)) true))))))
(check-sat)
; query 75: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x8348 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x83 (or false false false)))
(let (($x62 (not $x83)))
(and $x62 (or $x83 (and (distinct ?x8348 ?x8348) true)))))))
(check-sat)
; query 76: function matrix_add_const, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x83 (or false false false)))
(let (($x62 (not $x83)))
(and $x62 (or $x83 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 77: function matrix_add_const, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x4348 (bvadd in.01_32 (_ bv1 32))))
(let (($x2462 (and (distinct ?x4348 ?x4348) true)))
(let (($x83 (or false false false)))
(let (($x62 (not $x83)))
(and $x62 (or $x83 $x2462)))))))
(check-sat)
; query 78: function matrix_mul_const, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x83 (or false false false)))
(let (($x62 (not $x83)))
(and $x62 (or $x83 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 79: function matrix_mul_const, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x4348 (bvadd in.01_32 (_ bv1 32))))
(let (($x2462 (and (distinct ?x4348 ?x4348) true)))
(let (($x83 (or false false false)))
(let (($x62 (not $x83)))
(and $x62 (or $x83 $x2462)))))))
(check-sat)
; query 80: function matrix_mul_matrix, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x83 (or false false false)))
(let (($x62 (not $x83)))
(and $x62 (or $x83 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 81: function matrix_mul_matrix, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x4348 (bvadd in.01_32 (_ bv1 32))))
(let (($x2462 (and (distinct ?x4348 ?x4348) true)))
(let (($x83 (or false false false)))
(let (($x62 (not $x83)))
(and $x62 (or $x83 $x2462)))))))
(check-sat)
; query 82: function matrix_mul_matrix, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x83 (or false false false)))
(let (($x62 (not $x83)))
(and $x62 (or $x83 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 83: function matrix_mul_matrix_bitextract, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x83 (or false false false)))
(let (($x62 (not $x83)))
(and $x62 (or $x83 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 84: function matrix_mul_matrix_bitextract, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x4348 (bvadd in.01_32 (_ bv1 32))))
(let (($x2462 (and (distinct ?x4348 ?x4348) true)))
(let (($x83 (or false false false)))
(let (($x62 (not $x83)))
(and $x62 (or $x83 $x2462)))))))
(check-sat)
; query 85: function matrix_mul_matrix_bitextract, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x83 (or false false false)))
(let (($x62 (not $x83)))
(and $x62 (or $x83 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 86: function matrix_mul_vect, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x83 (or false false false)))
(let (($x62 (not $x83)))
(and $x62 (or $x83 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 87: function matrix_mul_vect, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x4348 (bvadd in.01_32 (_ bv1 32))))
(let (($x2462 (and (distinct ?x4348 ?x4348) true)))
(let (($x83 (or false false false)))
(let (($x62 (not $x83)))
(and $x62 (or $x83 $x2462)))))))
(check-sat)
; query 88: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x126 (or false false)))
(let (($x6 (not $x126)))
(and $x6 (or $x126 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 89: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x1900 ((_ sign_extend 16) in.1_16)))
(let ((?x2045 (bvadd ?x1900 (_ bv10 32))))
(let (($x8646 (and (distinct (bvadd ((_ sign_extend 1) ?x1900) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x2045)) true)))
(let (($x126 (or false false)))
(let (($x10072 (or $x126 false (or $x8646))))
(and (not $x10072) (or $x10072 (and (distinct ?x2045 ?x2045) true)))))))))
(check-sat)
; query 90: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x1900 ((_ sign_extend 16) in.1_16)))
(let ((?x2045 (bvadd ?x1900 (_ bv10 32))))
(let ((?x8347 ((_ extract 15 0) ?x2045)))
(let (($x8646 (and (distinct (bvadd ((_ sign_extend 1) ?x1900) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x2045)) true)))
(let (($x126 (or false false)))
(let (($x10072 (or $x126 false (or $x8646))))
(let (($x8902 (or $x10072 false)))
(and (not $x8902) (or $x8902 (and (distinct ?x8347 ?x8347) true)))))))))))
(check-sat)
; query 91: function partition_memory, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x83 (or false false false)))
(let (($x62 (not $x83)))
(and $x62 (or $x83 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 92: function run_matrix_multiply, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x83 (or false false false)))
(let (($x62 (not $x83)))
(and $x62 (or $x83 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 93: function run_matrix_multiply, block 34, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x4348 (bvadd in.01_32 (_ bv1 32))))
(let (($x2462 (and (distinct ?x4348 ?x4348) true)))
(let (($x83 (or false false false)))
(let (($x62 (not $x83)))
(and $x62 (or $x83 $x2462)))))))
(check-sat)
