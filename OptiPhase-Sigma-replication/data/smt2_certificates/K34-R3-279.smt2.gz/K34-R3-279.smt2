; OptiPhase-Sigma refinement certificate for sweep K34-R3-279
; query 0: function corner_draw, block 11, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x39 (ite (= (_ bv0 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x10 (or false false false)))
(let (($x480 (not $x10)))
(and $x480 (or $x10 (and (distinct ?x39 ?x39) true)))))))
(check-sat)
; query 1: function edge_draw, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let ((?x146 (ite (= (_ bv0 32) in4_32) (_ bv1 1) (_ bv0 1))))
(let (($x10 (or false false false)))
(let (($x480 (not $x10)))
(and $x480 (or $x10 (and (distinct ?x146 ?x146) true)))))))
(check-sat)
; query 2: function main, block 129, name %130
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.011_32 () (_ BitVec 32))
(assert
 (let ((?x381 (ite (and (distinct (_ bv0 32) in.011_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x10 (or false false false)))
(let (($x480 (not $x10)))
(and $x480 (or $x10 (and (distinct ?x381 ?x381) true)))))))
(check-sat)
; query 3: function main, block 160, name %161
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x5 (ite (and (distinct (_ bv0 32) in.01_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x10 (or false false false)))
(let (($x480 (not $x10)))
(and $x480 (or $x10 (and (distinct ?x5 ?x5) true)))))))
(check-sat)
; query 4: function main, block 35, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x52 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x87 (or false false (or $x52))))
(and (not $x87) (or $x87 (and (distinct (bvadd in.020_32 (_ bv1 32)) (bvadd in.020_32 (_ bv1 32))) true))))))
(check-sat)
; query 5: function main, block 35, name %37
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let ((?x117 (ite (bvsge (bvadd in.020_32 (_ bv1 32)) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x52 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x87 (or false false (or $x52))))
(let (($x63 (or $x87 false false)))
(and (not $x63) (or $x63 (and (distinct ?x117 ?x117) true))))))))
(check-sat)
; query 6: function main, block 49, name %50
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x52 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x87 (or false false (or $x52))))
(and (not $x87) (or $x87 (and (distinct (bvadd in.020_32 (_ bv1 32)) (bvadd in.020_32 (_ bv1 32))) true))))))
(check-sat)
; query 7: function main, block 49, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let ((?x117 (ite (bvsge (bvadd in.020_32 (_ bv1 32)) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x52 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x87 (or false false (or $x52))))
(let (($x63 (or $x87 false false)))
(and (not $x63) (or $x63 (and (distinct ?x117 ?x117) true))))))))
(check-sat)
; query 8: function main, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.014_32 () (_ BitVec 32))
(assert
 (let ((?x54 (ite (= (_ bv1 32) in.014_32) (_ bv1 1) (_ bv0 1))))
(let (($x10 (or false false false)))
(let (($x480 (not $x10)))
(and $x480 (or $x10 (and (distinct ?x54 ?x54) true)))))))
(check-sat)
; query 9: function main, block 66, name %67
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x11 (ite (= (_ bv0 32) in.0_32) (_ bv1 1) (_ bv0 1))))
(let (($x10 (or false false false)))
(let (($x480 (not $x10)))
(and $x480 (or $x10 (and (distinct ?x11 ?x11) true)))))))
(check-sat)
; query 10: function main, block 84, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.07_32 () (_ BitVec 32))
(assert
 (let ((?x59 (ite (and (distinct (_ bv0 32) in.07_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x10 (or false false false)))
(let (($x480 (not $x10)))
(and $x480 (or $x10 (and (distinct ?x59 ?x59) true)))))))
(check-sat)
