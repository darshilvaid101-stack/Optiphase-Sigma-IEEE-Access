; OptiPhase-Sigma refinement certificate for sweep K15-R3-261
; query 0: function xmalloc, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in7_32 () (_ BitVec 32))
(assert
 (let ((?x95 (ite (and (distinct (_ bv0 32) in7_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x77 (or false false false)))
(and (not $x77) (or $x77 (and (distinct ?x95 ?x95) true))))))
(check-sat)
