; OptiPhase-Sigma refinement certificate for sweep K39-R5-373
; query 0: function BF_ofb64_encrypt, block 82, name %83
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x114 (ite (= (_ bv0 32) in.04_32) (_ bv1 1) (_ bv0 1))))
(let (($x368 (or false false false)))
(and (not $x368) (or $x368 (and (distinct ?x114 ?x114) true))))))
(check-sat)
