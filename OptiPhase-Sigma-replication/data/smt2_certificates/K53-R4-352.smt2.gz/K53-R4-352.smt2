; OptiPhase-Sigma refinement certificate for sweep K53-R4-352
