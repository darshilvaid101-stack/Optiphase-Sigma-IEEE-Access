; OptiPhase-Sigma refinement certificate for sweep K17-R6-002
