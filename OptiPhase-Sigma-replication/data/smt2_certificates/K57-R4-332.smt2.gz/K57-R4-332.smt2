; OptiPhase-Sigma refinement certificate for sweep K57-R4-332
; query 0: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x100 (or false false false)))
(let (($x60 (not $x100)))
(and $x60 (or $x100 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 1: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x140 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x100 (or false false false)))
(let (($x60 (not $x100)))
(and $x60 (or $x100 (and (distinct ?x140 ?x140) true)))))))
(check-sat)
