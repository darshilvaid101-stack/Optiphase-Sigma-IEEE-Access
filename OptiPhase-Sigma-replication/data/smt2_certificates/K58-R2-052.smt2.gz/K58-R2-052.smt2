; OptiPhase-Sigma refinement certificate for sweep K58-R2-052
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x92 (or false false)))
(let (($x442 (not $x92)))
(and $x442 (or $x92 (and (distinct ((_ sign_extend 16) in25_16) ((_ sign_extend 16) in25_16)) true))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let ((?x2657 (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))))
(let (($x92 (or false false)))
(let (($x41 (or $x92 false false)))
(let (($x1815 (not $x41)))
(and $x1815 (or $x41 (and (distinct ?x2657 ?x2657) true))))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x92 (or false false)))
(let (($x442 (not $x92)))
(and $x442 (or $x92 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x10 ((_ sign_extend 16) in3_16)))
(let ((?x2662 (bvand ?x10 (_ bv127 32))))
(let (($x92 (or false false)))
(let (($x41 (or $x92 false false)))
(let (($x1815 (not $x41)))
(and $x1815 (or $x41 (and (distinct ?x2662 ?x2662) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x10 ((_ sign_extend 16) in3_16)))
(let ((?x2662 (bvand ?x10 (_ bv127 32))))
(let ((?x74 ((_ extract 15 0) ?x2662)))
(let (($x92 (or false false)))
(let (($x41 (or $x92 false false)))
(let (($x2661 (or $x41 false)))
(let (($x2369 (not $x2661)))
(and $x2369 (or $x2661 (and (distinct ?x74 ?x74) true)))))))))))
(check-sat)
; query 5: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x92 (or false false)))
(let (($x442 (not $x92)))
(and $x442 (or $x92 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 6: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x13 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x92 (or false false)))
(let (($x41 (or $x92 false false)))
(let (($x1815 (not $x41)))
(and $x1815 (or $x41 (and (distinct ?x13 ?x13) true))))))))
(check-sat)
; query 7: function core_bench_list, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x2370 (or false false false)))
(let (($x1435 (not $x2370)))
(and $x1435 (or $x2370 (and (distinct (bvadd in.0_16 (_ bv1 16)) (bvadd in.0_16 (_ bv1 16))) true))))))
(check-sat)
; query 8: function core_bench_list, block 82, name %83
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let (($x92 (or false false)))
(let (($x442 (not $x92)))
(and $x442 (or $x92 (and (distinct ((_ zero_extend 16) in.02_16) ((_ zero_extend 16) in.02_16)) true))))))
(check-sat)
; query 9: function core_bench_list, block 82, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x2666 ((_ zero_extend 16) in.02_16)))
(let ((?x24 (bvmul ?x2666 (_ bv4 32))))
(let (($x121 (and (distinct (bvmul ((_ sign_extend 32) ?x2666) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x24)) true)))
(let (($x92 (or false false)))
(let (($x77 (or $x92 false (or $x121))))
(and (not $x77) (or $x77 (and (distinct ?x24 ?x24) true)))))))))
(check-sat)
; query 10: function core_bench_list, block 82, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let (($x92 (or false false)))
(let (($x442 (not $x92)))
(and $x442 (or $x92 (and (distinct ((_ zero_extend 16) in.04_16) ((_ zero_extend 16) in.04_16)) true))))))
(check-sat)
; query 11: function core_bench_list, block 82, name %86
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x734 ((_ zero_extend 16) in.04_16)))
(let ((?x2666 ((_ zero_extend 16) in.02_16)))
(let ((?x24 (bvmul ?x2666 (_ bv4 32))))
(let ((?x169 (bvsub ?x24 ?x734)))
(let ((?x72 ((_ sign_extend 1) ?x169)))
(let (($x92 (or false false)))
(let (($x121 (and (distinct (bvmul ((_ sign_extend 32) ?x2666) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x24)) true)))
(let (($x77 (or $x92 false (or $x121))))
(let (($x2658 (or $x77 $x92 (or (and (distinct (bvsub ((_ sign_extend 1) ?x24) ((_ sign_extend 1) ?x734)) ?x72) true)))))
(and (not $x2658) (or $x2658 (and (distinct ?x169 ?x169) true)))))))))))))
(check-sat)
; query 12: function core_bench_list, block 82, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x92 (or false false)))
(let (($x442 (not $x92)))
(and $x442 (or $x92 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 13: function core_bench_list, block 82, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x734 ((_ zero_extend 16) in.04_16)))
(let ((?x2666 ((_ zero_extend 16) in.02_16)))
(let ((?x24 (bvmul ?x2666 (_ bv4 32))))
(let ((?x169 (bvsub ?x24 ?x734)))
(let ((?x107 ((_ zero_extend 16) in.01_16)))
(let ((?x1651 (bvadd ?x107 ?x169)))
(let (($x645 (and (distinct (bvadd ((_ sign_extend 1) ?x107) ((_ sign_extend 1) ?x169)) ((_ sign_extend 1) ?x1651)) true)))
(let ((?x72 ((_ sign_extend 1) ?x169)))
(let (($x92 (or false false)))
(let (($x121 (and (distinct (bvmul ((_ sign_extend 32) ?x2666) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x24)) true)))
(let (($x77 (or $x92 false (or $x121))))
(let (($x2658 (or $x77 $x92 (or (and (distinct (bvsub ((_ sign_extend 1) ?x24) ((_ sign_extend 1) ?x734)) ?x72) true)))))
(let (($x1193 (or $x92 $x2658 (or $x645))))
(and (not $x1193) (or $x1193 (and (distinct ?x1651 ?x1651) true)))))))))))))))))
(check-sat)
; query 14: function core_bench_list, block 82, name %89
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x734 ((_ zero_extend 16) in.04_16)))
(let ((?x2666 ((_ zero_extend 16) in.02_16)))
(let ((?x24 (bvmul ?x2666 (_ bv4 32))))
(let ((?x169 (bvsub ?x24 ?x734)))
(let ((?x107 ((_ zero_extend 16) in.01_16)))
(let ((?x1651 (bvadd ?x107 ?x169)))
(let ((?x983 ((_ extract 15 0) ?x1651)))
(let (($x645 (and (distinct (bvadd ((_ sign_extend 1) ?x107) ((_ sign_extend 1) ?x169)) ((_ sign_extend 1) ?x1651)) true)))
(let ((?x72 ((_ sign_extend 1) ?x169)))
(let (($x92 (or false false)))
(let (($x121 (and (distinct (bvmul ((_ sign_extend 32) ?x2666) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x24)) true)))
(let (($x77 (or $x92 false (or $x121))))
(let (($x2658 (or $x77 $x92 (or (and (distinct (bvsub ((_ sign_extend 1) ?x24) ((_ sign_extend 1) ?x734)) ?x72) true)))))
(let (($x1193 (or $x92 $x2658 (or $x645))))
(let (($x337 (or $x1193 false)))
(and (not $x337) (or $x337 (and (distinct ?x983 ?x983) true)))))))))))))))))))
(check-sat)
; query 15: function core_bench_list, block 82, name %90
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x92 (or false false)))
(let (($x442 (not $x92)))
(and $x442 (or $x92 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 16: function core_bench_list, block 82, name %91
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1694 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x92 (or false false)))
(let (($x41 (or $x92 false false)))
(let (($x1815 (not $x41)))
(and $x1815 (or $x41 (and (distinct ?x1694 ?x1694) true))))))))
(check-sat)
; query 17: function core_bench_state, block 105, name %106
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x2370 (or false false false)))
(let (($x1435 (not $x2370)))
(and $x1435 (or $x2370 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 18: function core_bench_state, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x2370 (or false false false)))
(let (($x1435 (not $x2370)))
(and $x1435 (or $x2370 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 19: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1278 (bvadd in.01_32 (_ bv1 32))))
(let (($x2150 (and (distinct ?x1278 ?x1278) true)))
(let (($x2370 (or false false false)))
(let (($x1435 (not $x2370)))
(and $x1435 (or $x2370 $x2150)))))))
(check-sat)
; query 20: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1278 (bvadd in.01_32 (_ bv1 32))))
(let ((?x345 (bvmul ?x1278 ?x1278)))
(let (($x2370 (or false false false)))
(let (($x717 (or $x2370 $x2370 false)))
(and (not $x717) (or $x717 (and (distinct ?x345 ?x345) true))))))))
(check-sat)
; query 21: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1278 (bvadd in.01_32 (_ bv1 32))))
(let ((?x345 (bvmul ?x1278 ?x1278)))
(let ((?x1272 (bvmul ?x345 (_ bv2 32))))
(let (($x2370 (or false false false)))
(let (($x717 (or $x2370 $x2370 false)))
(let (($x443 (or $x717 false false)))
(and (not $x443) (or $x443 (and (distinct ?x1272 ?x1272) true))))))))))
(check-sat)
; query 22: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1278 (bvadd in.01_32 (_ bv1 32))))
(let ((?x345 (bvmul ?x1278 ?x1278)))
(let ((?x1272 (bvmul ?x345 (_ bv2 32))))
(let ((?x177 (bvmul ?x1272 (_ bv4 32))))
(let (($x2370 (or false false false)))
(let (($x717 (or $x2370 $x2370 false)))
(let (($x443 (or $x717 false false)))
(let (($x2354 (or $x443 false false)))
(and (not $x2354) (or $x2354 (and (distinct ?x177 ?x177) true))))))))))))
(check-sat)
; query 23: function core_init_matrix, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x2370 (or false false false)))
(let (($x1435 (not $x2370)))
(and $x1435 (or $x2370 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 24: function core_init_matrix, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x2370 (or false false false)))
(let (($x1435 (not $x2370)))
(and $x1435 (or $x2370 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 25: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x230 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x2370 (or false false false)))
(let (($x1435 (not $x2370)))
(and $x1435 (or $x2370 (and (distinct ?x230 ?x230) true)))))))
(check-sat)
; query 26: function core_init_state, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_32 () (_ BitVec 32))
(assert
 (let (($x2370 (or false false false)))
(let (($x1435 (not $x2370)))
(and $x1435 (or $x2370 (and (distinct (bvadd in.06_32 (_ bv1 32)) (bvadd in.06_32 (_ bv1 32))) true))))))
(check-sat)
; query 27: function core_init_state, block 65, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let (($x2370 (or false false false)))
(let (($x1435 (not $x2370)))
(and $x1435 (or $x2370 (and (distinct (bvadd in4_32 (_ bv1 32)) (bvadd in4_32 (_ bv1 32))) true))))))
(check-sat)
; query 28: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x2392 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x2370 (or false false false)))
(let (($x1435 (not $x2370)))
(and $x1435 (or $x2370 (and (distinct ?x2392 ?x2392) true)))))))
(check-sat)
; query 29: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x2370 (or false false false)))
(let (($x1435 (not $x2370)))
(and $x1435 (or $x2370 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 30: function core_list_init, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1278 (bvadd in.01_32 (_ bv1 32))))
(let (($x2150 (and (distinct ?x1278 ?x1278) true)))
(let (($x2370 (or false false false)))
(let (($x1435 (not $x2370)))
(and $x1435 (or $x2370 $x2150)))))))
(check-sat)
; query 31: function core_list_mergesort, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1278 (bvadd in.01_32 (_ bv1 32))))
(let (($x2150 (and (distinct ?x1278 ?x1278) true)))
(let (($x151 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x1278)) true)))
(let (($x1595 (or false false (or $x151))))
(and (not $x1595) (or $x1595 $x2150)))))))
(check-sat)
; query 32: function core_list_mergesort, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x1702 (ite (bvslt (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x2370 (or false false false)))
(let (($x1435 (not $x2370)))
(and $x1435 (or $x2370 (and (distinct ?x1702 ?x1702) true)))))))
(check-sat)
; query 33: function core_list_mergesort, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.224_32 () (_ BitVec 32))
(assert
 (let ((?x1767 (ite (= (_ bv0 32) in.224_32) (_ bv1 1) (_ bv0 1))))
(let (($x2370 (or false false false)))
(let (($x1435 (not $x2370)))
(and $x1435 (or $x2370 (and (distinct ?x1767 ?x1767) true)))))))
(check-sat)
; query 34: function core_list_mergesort, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x653 (ite (= (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x2370 (or false false false)))
(let (($x1435 (not $x2370)))
(and $x1435 (or $x2370 (and (distinct ?x653 ?x653) true)))))))
(check-sat)
; query 35: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x5263 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x2405 (or false false (or $x5263))))
(and (not $x2405) (or $x2405 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 36: function core_list_mergesort, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x343 (and (distinct (bvmul ((_ sign_extend 32) in.020_32) ((_ sign_extend 32) (_ bv2 32))) ((_ sign_extend 32) (bvmul in.020_32 (_ bv2 32)))) true)))
(let (($x757 (or false false (or $x343))))
(and (not $x757) (or $x757 (and (distinct (bvmul in.020_32 (_ bv2 32)) (bvmul in.020_32 (_ bv2 32))) true))))))
(check-sat)
; query 37: function core_state_transition, block 102, name %103
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x92 (or false false)))
(let (($x442 (not $x92)))
(and $x442 (or $x92 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 38: function core_state_transition, block 102, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x2624 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x92 (or false false)))
(let (($x41 (or $x92 false false)))
(let (($x1815 (not $x41)))
(and $x1815 (or $x41 (and (distinct ?x2624 ?x2624) true))))))))
(check-sat)
; query 39: function core_state_transition, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x92 (or false false)))
(let (($x442 (not $x92)))
(and $x442 (or $x92 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 40: function core_state_transition, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x2609 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x92 (or false false)))
(let (($x41 (or $x92 false false)))
(let (($x1815 (not $x41)))
(and $x1815 (or $x41 (and (distinct ?x2609 ?x2609) true))))))))
(check-sat)
; query 41: function core_state_transition, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x92 (or false false)))
(let (($x442 (not $x92)))
(and $x442 (or $x92 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 42: function core_state_transition, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x2624 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x92 (or false false)))
(let (($x41 (or $x92 false false)))
(let (($x1815 (not $x41)))
(and $x1815 (or $x41 (and (distinct ?x2624 ?x2624) true))))))))
(check-sat)
; query 43: function core_state_transition, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x92 (or false false)))
(let (($x442 (not $x92)))
(and $x442 (or $x92 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 44: function core_state_transition, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x3929 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x92 (or false false)))
(let (($x41 (or $x92 false false)))
(let (($x1815 (not $x41)))
(and $x1815 (or $x41 (and (distinct ?x3929 ?x3929) true))))))))
(check-sat)
; query 45: function core_state_transition, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x92 (or false false)))
(let (($x442 (not $x92)))
(and $x442 (or $x92 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 46: function core_state_transition, block 51, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x3929 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x92 (or false false)))
(let (($x41 (or $x92 false false)))
(let (($x1815 (not $x41)))
(and $x1815 (or $x41 (and (distinct ?x3929 ?x3929) true))))))))
(check-sat)
; query 47: function core_state_transition, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x92 (or false false)))
(let (($x442 (not $x92)))
(and $x442 (or $x92 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 48: function core_state_transition, block 64, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x3929 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x92 (or false false)))
(let (($x41 (or $x92 false false)))
(let (($x1815 (not $x41)))
(and $x1815 (or $x41 (and (distinct ?x3929 ?x3929) true))))))))
(check-sat)
; query 49: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x3636 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x2370 (or false false false)))
(let (($x1435 (not $x2370)))
(and $x1435 (or $x2370 (and (distinct ?x3636 ?x3636) true)))))))
(check-sat)
; query 50: function core_state_transition, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x92 (or false false)))
(let (($x442 (not $x92)))
(and $x442 (or $x92 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 51: function core_state_transition, block 80, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x3638 (ite (= (_ bv69 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x92 (or false false)))
(let (($x41 (or $x92 false false)))
(let (($x1815 (not $x41)))
(and $x1815 (or $x41 (and (distinct ?x3638 ?x3638) true))))))))
(check-sat)
; query 52: function core_state_transition, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x92 (or false false)))
(let (($x442 (not $x92)))
(and $x442 (or $x92 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 53: function core_state_transition, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x2603 (ite (= (_ bv101 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x92 (or false false)))
(let (($x41 (or $x92 false false)))
(let (($x1815 (not $x41)))
(and $x1815 (or $x41 (and (distinct ?x2603 ?x2603) true))))))))
(check-sat)
; query 54: function core_state_transition, block 99, name %100
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x92 (or false false)))
(let (($x442 (not $x92)))
(and $x442 (or $x92 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 55: function core_state_transition, block 99, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x2609 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x92 (or false false)))
(let (($x41 (or $x92 false false)))
(let (($x1815 (not $x41)))
(and $x1815 (or $x41 (and (distinct ?x2609 ?x2609) true))))))))
(check-sat)
; query 56: function crcu8, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x92 (or false false)))
(let (($x442 (not $x92)))
(and $x442 (or $x92 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 57: function crcu8, block 19, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x107 ((_ zero_extend 16) in.01_16)))
(let ((?x2171 (bvxor ?x107 (_ bv16386 32))))
(let (($x92 (or false false)))
(let (($x41 (or $x92 false false)))
(let (($x1815 (not $x41)))
(and $x1815 (or $x41 (and (distinct ?x2171 ?x2171) true)))))))))
(check-sat)
; query 58: function crcu8, block 19, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x107 ((_ zero_extend 16) in.01_16)))
(let ((?x2171 (bvxor ?x107 (_ bv16386 32))))
(let ((?x3925 ((_ extract 15 0) ?x2171)))
(let (($x92 (or false false)))
(let (($x41 (or $x92 false false)))
(let (($x2661 (or $x41 false)))
(let (($x2369 (not $x2661)))
(and $x2369 (or $x2661 (and (distinct ?x3925 ?x3925) true)))))))))))
(check-sat)
; query 59: function crcu8, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x92 (or false false)))
(let (($x442 (not $x92)))
(and $x442 (or $x92 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 60: function crcu8, block 29, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1081 ((_ zero_extend 16) in27_16)))
(let ((?x2836 (bvor ?x1081 (_ bv32768 32))))
(let (($x92 (or false false)))
(let (($x41 (or $x92 false false)))
(let (($x1815 (not $x41)))
(and $x1815 (or $x41 (and (distinct ?x2836 ?x2836) true)))))))))
(check-sat)
; query 61: function crcu8, block 29, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1081 ((_ zero_extend 16) in27_16)))
(let ((?x2836 (bvor ?x1081 (_ bv32768 32))))
(let ((?x2847 ((_ extract 15 0) ?x2836)))
(let (($x92 (or false false)))
(let (($x41 (or $x92 false false)))
(let (($x2661 (or $x41 false)))
(let (($x2369 (not $x2661)))
(and $x2369 (or $x2661 (and (distinct ?x2847 ?x2847) true)))))))))))
(check-sat)
; query 62: function crcu8, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x92 (or false false)))
(let (($x442 (not $x92)))
(and $x442 (or $x92 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 63: function crcu8, block 33, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1081 ((_ zero_extend 16) in27_16)))
(let ((?x870 (bvand ?x1081 (_ bv32767 32))))
(let (($x92 (or false false)))
(let (($x41 (or $x92 false false)))
(let (($x1815 (not $x41)))
(and $x1815 (or $x41 (and (distinct ?x870 ?x870) true)))))))))
(check-sat)
; query 64: function crcu8, block 33, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1081 ((_ zero_extend 16) in27_16)))
(let ((?x870 (bvand ?x1081 (_ bv32767 32))))
(let ((?x1470 ((_ extract 15 0) ?x870)))
(let (($x92 (or false false)))
(let (($x41 (or $x92 false false)))
(let (($x2661 (or $x41 false)))
(let (($x2369 (not $x2661)))
(and $x2369 (or $x2661 (and (distinct ?x1470 ?x1470) true)))))))))))
(check-sat)
; query 65: function crcu8, block 38, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_8 () (_ BitVec 8))
(assert
 (let (($x2370 (or false false false)))
(let (($x1435 (not $x2370)))
(and $x1435 (or $x2370 (and (distinct (bvadd in.02_8 (_ bv1 8)) (bvadd in.02_8 (_ bv1 8))) true))))))
(check-sat)
; query 66: function crcu8, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x2601 ((_ extract 7 0) in.01_16)))
(let ((?x1941 ((_ zero_extend 24) ?x2601)))
(let (($x92 (or false false)))
(let (($x1876 (or $x92 false)))
(and (not $x1876) (or $x1876 (and (distinct ?x1941 ?x1941) true))))))))
(check-sat)
; query 67: function crcu8, block 6, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x2601 ((_ extract 7 0) in.01_16)))
(let ((?x1941 ((_ zero_extend 24) ?x2601)))
(let ((?x2355 (bvand ?x1941 (_ bv1 32))))
(let (($x92 (or false false)))
(let (($x1876 (or $x92 false)))
(let (($x2148 (or $x1876 false false)))
(and (not $x2148) (or $x2148 (and (distinct ?x2355 ?x2355) true))))))))))
(check-sat)
; query 68: function crcu8, block 6, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x2601 ((_ extract 7 0) in.01_16)))
(let ((?x1941 ((_ zero_extend 24) ?x2601)))
(let ((?x2355 (bvand ?x1941 (_ bv1 32))))
(let ((?x1177 ((_ zero_extend 24) in.0_8)))
(let ((?x2843 (bvand ?x1177 (_ bv1 32))))
(let ((?x2357 (bvxor ?x2843 ?x2355)))
(let (($x92 (or false false)))
(let (($x1876 (or $x92 false)))
(let (($x2148 (or $x1876 false false)))
(let (($x41 (or $x92 false false)))
(let (($x1001 (or $x41 $x2148 false)))
(and (not $x1001) (or $x1001 (and (distinct ?x2357 ?x2357) true)))))))))))))))
(check-sat)
; query 69: function crcu8, block 6, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x2601 ((_ extract 7 0) in.01_16)))
(let ((?x1941 ((_ zero_extend 24) ?x2601)))
(let ((?x2355 (bvand ?x1941 (_ bv1 32))))
(let ((?x1177 ((_ zero_extend 24) in.0_8)))
(let ((?x2843 (bvand ?x1177 (_ bv1 32))))
(let ((?x2357 (bvxor ?x2843 ?x2355)))
(let ((?x1191 ((_ extract 7 0) ?x2357)))
(let (($x92 (or false false)))
(let (($x1876 (or $x92 false)))
(let (($x2148 (or $x1876 false false)))
(let (($x41 (or $x92 false false)))
(let (($x1001 (or $x41 $x2148 false)))
(let (($x1544 (or $x1001 false)))
(and (not $x1544) (or $x1544 (and (distinct ?x1191 ?x1191) true)))))))))))))))))
(check-sat)
; query 70: function crcu8, block 6, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x92 (or false false)))
(let (($x442 (not $x92)))
(and $x442 (or $x92 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 71: function crcu8, block 6, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1177 ((_ zero_extend 24) in.0_8)))
(let ((?x2152 (bvashr ?x1177 (_ bv1 32))))
(let (($x92 (or false false)))
(let (($x41 (or $x92 false false)))
(let (($x565 (or $x41 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not $x565) (or $x565 (and (distinct ?x2152 ?x2152) true)))))))))
(check-sat)
; query 72: function crcu8, block 6, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1177 ((_ zero_extend 24) in.0_8)))
(let ((?x2152 (bvashr ?x1177 (_ bv1 32))))
(let ((?x3107 ((_ extract 7 0) ?x2152)))
(let (($x92 (or false false)))
(let (($x41 (or $x92 false false)))
(let (($x565 (or $x41 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x2164 (or $x565 false)))
(and (not $x2164) (or $x2164 (and (distinct ?x3107 ?x3107) true)))))))))))
(check-sat)
; query 73: function crcu8, block 6, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x2601 ((_ extract 7 0) in.01_16)))
(let ((?x1941 ((_ zero_extend 24) ?x2601)))
(let ((?x2355 (bvand ?x1941 (_ bv1 32))))
(let ((?x1177 ((_ zero_extend 24) in.0_8)))
(let ((?x2843 (bvand ?x1177 (_ bv1 32))))
(let ((?x2357 (bvxor ?x2843 ?x2355)))
(let ((?x1191 ((_ extract 7 0) ?x2357)))
(let ((?x1648 ((_ zero_extend 24) ?x1191)))
(let (($x92 (or false false)))
(let (($x1876 (or $x92 false)))
(let (($x2148 (or $x1876 false false)))
(let (($x41 (or $x92 false false)))
(let (($x1001 (or $x41 $x2148 false)))
(let (($x1544 (or $x1001 false)))
(let (($x1781 (or $x1544 false)))
(and (not $x1781) (or $x1781 (and (distinct ?x1648 ?x1648) true)))))))))))))))))))
(check-sat)
; query 74: function crcu8, block 6, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x2601 ((_ extract 7 0) in.01_16)))
(let ((?x1941 ((_ zero_extend 24) ?x2601)))
(let ((?x2355 (bvand ?x1941 (_ bv1 32))))
(let ((?x1177 ((_ zero_extend 24) in.0_8)))
(let ((?x2843 (bvand ?x1177 (_ bv1 32))))
(let ((?x2357 (bvxor ?x2843 ?x2355)))
(let ((?x1191 ((_ extract 7 0) ?x2357)))
(let ((?x1648 ((_ zero_extend 24) ?x1191)))
(let ((?x1549 (ite (= (_ bv1 32) ?x1648) (_ bv1 1) (_ bv0 1))))
(let (($x92 (or false false)))
(let (($x1876 (or $x92 false)))
(let (($x2148 (or $x1876 false false)))
(let (($x41 (or $x92 false false)))
(let (($x1001 (or $x41 $x2148 false)))
(let (($x1544 (or $x1001 false)))
(let (($x1781 (or $x1544 false)))
(let (($x805 (or $x1781 false false)))
(and (not $x805) (or $x805 (and (distinct ?x1549 ?x1549) true)))))))))))))))))))))
(check-sat)
; query 75: function crcu8, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x92 (or false false)))
(let (($x442 (not $x92)))
(and $x442 (or $x92 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 76: function crcu8, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1177 ((_ zero_extend 24) in.0_8)))
(let ((?x2843 (bvand ?x1177 (_ bv1 32))))
(let (($x92 (or false false)))
(let (($x41 (or $x92 false false)))
(let (($x1815 (not $x41)))
(and $x1815 (or $x41 (and (distinct ?x2843 ?x2843) true)))))))))
(check-sat)
; query 77: function crcu8, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x92 (or false false)))
(let (($x442 (not $x92)))
(and $x442 (or $x92 (and (distinct ((_ extract 7 0) in.01_16) ((_ extract 7 0) in.01_16)) true))))))
(check-sat)
; query 78: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x2635 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2883 ((_ zero_extend 31) ?x2635)))
(let ((?x2632 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2636 ((_ zero_extend 31) ?x2632)))
(let ((?x279 (bvand ?x2636 ?x2883)))
(let ((?x2410 (ite (and (distinct (_ bv0 32) ?x279) true) (_ bv1 1) (_ bv0 1))))
(let ((?x2602 ((_ zero_extend 63) ?x2410)))
(let (($x92 (or false false)))
(let (($x41 (or $x92 false false)))
(let (($x2661 (or $x41 false)))
(let (($x1141 (or $x2661 $x2661 false)))
(let (($x2175 (or $x1141 false false)))
(let (($x2428 (or $x2175 false)))
(and (not $x2428) (or $x2428 (and (distinct ?x2602 ?x2602) true)))))))))))))))))
(check-sat)
; query 79: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x2635 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2883 ((_ zero_extend 31) ?x2635)))
(let ((?x2632 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2636 ((_ zero_extend 31) ?x2632)))
(let ((?x279 (bvand ?x2636 ?x2883)))
(let ((?x2410 (ite (and (distinct (_ bv0 32) ?x279) true) (_ bv1 1) (_ bv0 1))))
(let (($x2174 (= (_ bv1 1) ?x2410)))
(let ((?x968 (ite $x2174 (_ bv1 32) (_ bv0 32))))
(let (($x92 (or false false)))
(let (($x41 (or $x92 false false)))
(let (($x2661 (or $x41 false)))
(let (($x1141 (or $x2661 $x2661 false)))
(let (($x2175 (or $x1141 false false)))
(let (($x1370 (or $x2175 (ite $x2174 false false))))
(and (not $x1370) (or $x1370 (and (distinct ?x968 ?x968) true))))))))))))))))))
(check-sat)
; query 80: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x2635 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2883 ((_ zero_extend 31) ?x2635)))
(let ((?x2632 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2636 ((_ zero_extend 31) ?x2632)))
(let ((?x279 (bvand ?x2636 ?x2883)))
(let ((?x2410 (ite (and (distinct (_ bv0 32) ?x279) true) (_ bv1 1) (_ bv0 1))))
(let (($x2174 (= (_ bv1 1) ?x2410)))
(let ((?x968 (ite $x2174 (_ bv1 32) (_ bv0 32))))
(let ((?x2375 ((_ extract 7 0) ?x968)))
(let (($x92 (or false false)))
(let (($x41 (or $x92 false false)))
(let (($x2661 (or $x41 false)))
(let (($x1141 (or $x2661 $x2661 false)))
(let (($x2175 (or $x1141 false false)))
(let (($x1370 (or $x2175 (ite $x2174 false false))))
(let (($x26 (or $x1370 false)))
(and (not $x26) (or $x26 (and (distinct ?x2375 ?x2375) true))))))))))))))))))))
(check-sat)
; query 81: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x92 (or false false)))
(let (($x442 (not $x92)))
(and $x442 (or $x92 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 82: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x2632 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x92 (or false false)))
(let (($x41 (or $x92 false false)))
(let (($x1815 (not $x41)))
(and $x1815 (or $x41 (and (distinct ?x2632 ?x2632) true))))))))
(check-sat)
; query 83: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x2632 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2636 ((_ zero_extend 31) ?x2632)))
(let (($x92 (or false false)))
(let (($x41 (or $x92 false false)))
(let (($x2661 (or $x41 false)))
(let (($x2369 (not $x2661)))
(and $x2369 (or $x2661 (and (distinct ?x2636 ?x2636) true))))))))))
(check-sat)
; query 84: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x92 (or false false)))
(let (($x442 (not $x92)))
(and $x442 (or $x92 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 85: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x2635 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x92 (or false false)))
(let (($x41 (or $x92 false false)))
(let (($x1815 (not $x41)))
(and $x1815 (or $x41 (and (distinct ?x2635 ?x2635) true))))))))
(check-sat)
; query 86: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x2635 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2883 ((_ zero_extend 31) ?x2635)))
(let (($x92 (or false false)))
(let (($x41 (or $x92 false false)))
(let (($x2661 (or $x41 false)))
(let (($x2369 (not $x2661)))
(and $x2369 (or $x2661 (and (distinct ?x2883 ?x2883) true))))))))))
(check-sat)
; query 87: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x2635 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2883 ((_ zero_extend 31) ?x2635)))
(let ((?x2632 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2636 ((_ zero_extend 31) ?x2632)))
(let ((?x279 (bvand ?x2636 ?x2883)))
(let (($x92 (or false false)))
(let (($x41 (or $x92 false false)))
(let (($x2661 (or $x41 false)))
(let (($x1141 (or $x2661 $x2661 false)))
(and (not $x1141) (or $x1141 (and (distinct ?x279 ?x279) true)))))))))))))
(check-sat)
; query 88: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x2635 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2883 ((_ zero_extend 31) ?x2635)))
(let ((?x2632 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2636 ((_ zero_extend 31) ?x2632)))
(let ((?x279 (bvand ?x2636 ?x2883)))
(let ((?x2410 (ite (and (distinct (_ bv0 32) ?x279) true) (_ bv1 1) (_ bv0 1))))
(let (($x92 (or false false)))
(let (($x41 (or $x92 false false)))
(let (($x2661 (or $x41 false)))
(let (($x1141 (or $x2661 $x2661 false)))
(let (($x2175 (or $x1141 false false)))
(and (not $x2175) (or $x2175 (and (distinct ?x2410 ?x2410) true)))))))))))))))
(check-sat)
; query 89: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1237 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x2370 (or false false false)))
(let (($x1435 (not $x2370)))
(and $x1435 (or $x2370 (and (distinct ?x1237 ?x1237) true)))))))
(check-sat)
; query 90: function matrix_add_const, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x2370 (or false false false)))
(let (($x1435 (not $x2370)))
(and $x1435 (or $x2370 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 91: function matrix_add_const, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1278 (bvadd in.01_32 (_ bv1 32))))
(let (($x2150 (and (distinct ?x1278 ?x1278) true)))
(let (($x2370 (or false false false)))
(let (($x1435 (not $x2370)))
(and $x1435 (or $x2370 $x2150)))))))
(check-sat)
; query 92: function matrix_mul_const, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x2370 (or false false false)))
(let (($x1435 (not $x2370)))
(and $x1435 (or $x2370 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 93: function matrix_mul_const, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1278 (bvadd in.01_32 (_ bv1 32))))
(let (($x2150 (and (distinct ?x1278 ?x1278) true)))
(let (($x2370 (or false false false)))
(let (($x1435 (not $x2370)))
(and $x1435 (or $x2370 $x2150)))))))
(check-sat)
; query 94: function matrix_mul_matrix, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x2370 (or false false false)))
(let (($x1435 (not $x2370)))
(and $x1435 (or $x2370 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 95: function matrix_mul_matrix, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1278 (bvadd in.01_32 (_ bv1 32))))
(let (($x2150 (and (distinct ?x1278 ?x1278) true)))
(let (($x2370 (or false false false)))
(let (($x1435 (not $x2370)))
(and $x1435 (or $x2370 $x2150)))))))
(check-sat)
; query 96: function matrix_mul_matrix, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x2370 (or false false false)))
(let (($x1435 (not $x2370)))
(and $x1435 (or $x2370 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 97: function matrix_mul_matrix_bitextract, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x2370 (or false false false)))
(let (($x1435 (not $x2370)))
(and $x1435 (or $x2370 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 98: function matrix_mul_matrix_bitextract, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1278 (bvadd in.01_32 (_ bv1 32))))
(let (($x2150 (and (distinct ?x1278 ?x1278) true)))
(let (($x2370 (or false false false)))
(let (($x1435 (not $x2370)))
(and $x1435 (or $x2370 $x2150)))))))
(check-sat)
; query 99: function matrix_mul_matrix_bitextract, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x2370 (or false false false)))
(let (($x1435 (not $x2370)))
(and $x1435 (or $x2370 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 100: function matrix_mul_vect, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x2370 (or false false false)))
(let (($x1435 (not $x2370)))
(and $x1435 (or $x2370 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 101: function matrix_mul_vect, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1278 (bvadd in.01_32 (_ bv1 32))))
(let (($x2150 (and (distinct ?x1278 ?x1278) true)))
(let (($x2370 (or false false false)))
(let (($x1435 (not $x2370)))
(and $x1435 (or $x2370 $x2150)))))))
(check-sat)
; query 102: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x92 (or false false)))
(let (($x442 (not $x92)))
(and $x442 (or $x92 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 103: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x2650 ((_ sign_extend 16) in.1_16)))
(let ((?x674 (bvadd ?x2650 (_ bv10 32))))
(let (($x2644 (and (distinct (bvadd ((_ sign_extend 1) ?x2650) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x674)) true)))
(let (($x92 (or false false)))
(let (($x2642 (or $x92 false (or $x2644))))
(and (not $x2642) (or $x2642 (and (distinct ?x674 ?x674) true)))))))))
(check-sat)
; query 104: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x2650 ((_ sign_extend 16) in.1_16)))
(let ((?x674 (bvadd ?x2650 (_ bv10 32))))
(let ((?x2387 ((_ extract 15 0) ?x674)))
(let (($x2644 (and (distinct (bvadd ((_ sign_extend 1) ?x2650) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x674)) true)))
(let (($x92 (or false false)))
(let (($x2642 (or $x92 false (or $x2644))))
(let (($x2520 (or $x2642 false)))
(and (not $x2520) (or $x2520 (and (distinct ?x2387 ?x2387) true)))))))))))
(check-sat)
; query 105: function matrix_sum, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x2884 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x2370 (or false false false)))
(let (($x1435 (not $x2370)))
(and $x1435 (or $x2370 (and (distinct ?x2884 ?x2884) true)))))))
(check-sat)
; query 106: function matrix_sum, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x2884 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let ((?x1258 ((_ zero_extend 63) ?x2884)))
(let (($x2370 (or false false false)))
(let (($x159 (or $x2370 false)))
(and (not $x159) (or $x159 (and (distinct ?x1258 ?x1258) true))))))))
(check-sat)
; query 107: function matrix_sum, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x2884 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x1178 (= (_ bv1 1) ?x2884)))
(let ((?x1065 (ite $x1178 (_ bv1 32) (_ bv0 32))))
(let (($x2370 (or false false false)))
(let (($x1834 (or $x2370 (ite $x1178 false false))))
(and (not $x1834) (or $x1834 (and (distinct ?x1065 ?x1065) true)))))))))
(check-sat)
; query 108: function matrix_sum, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x92 (or false false)))
(let (($x442 (not $x92)))
(and $x442 (or $x92 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 109: function matrix_sum, block 22, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x2884 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x1178 (= (_ bv1 1) ?x2884)))
(let ((?x1065 (ite $x1178 (_ bv1 32) (_ bv0 32))))
(let ((?x2650 ((_ sign_extend 16) in.1_16)))
(let ((?x2155 (bvadd ?x2650 ?x1065)))
(let (($x222 (and (distinct (bvadd ((_ sign_extend 1) ?x2650) ((_ sign_extend 1) ?x1065)) ((_ sign_extend 1) ?x2155)) true)))
(let (($x2370 (or false false false)))
(let (($x1834 (or $x2370 (ite $x1178 false false))))
(let (($x92 (or false false)))
(let (($x928 (or $x92 $x1834 (or $x222))))
(and (not $x928) (or $x928 (and (distinct ?x2155 ?x2155) true))))))))))))))
(check-sat)
; query 110: function matrix_sum, block 22, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x2884 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x1178 (= (_ bv1 1) ?x2884)))
(let ((?x1065 (ite $x1178 (_ bv1 32) (_ bv0 32))))
(let ((?x2650 ((_ sign_extend 16) in.1_16)))
(let ((?x2155 (bvadd ?x2650 ?x1065)))
(let ((?x97 ((_ extract 15 0) ?x2155)))
(let (($x222 (and (distinct (bvadd ((_ sign_extend 1) ?x2650) ((_ sign_extend 1) ?x1065)) ((_ sign_extend 1) ?x2155)) true)))
(let (($x2370 (or false false false)))
(let (($x1834 (or $x2370 (ite $x1178 false false))))
(let (($x92 (or false false)))
(let (($x928 (or $x92 $x1834 (or $x222))))
(let (($x1591 (or $x928 false)))
(and (not $x1591) (or $x1591 (and (distinct ?x97 ?x97) true))))))))))))))))
(check-sat)
; query 111: function matrix_sum, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x2370 (or false false false)))
(let (($x1435 (not $x2370)))
(and $x1435 (or $x2370 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 112: function matrix_sum, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1278 (bvadd in.01_32 (_ bv1 32))))
(let (($x2150 (and (distinct ?x1278 ?x1278) true)))
(let (($x2370 (or false false false)))
(let (($x1435 (not $x2370)))
(and $x1435 (or $x2370 $x2150)))))))
(check-sat)
; query 113: function parseval, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.23_32 () (_ BitVec 32))
(assert
 (let (($x1769 (and (distinct (bvmul ((_ sign_extend 32) in.23_32) ((_ sign_extend 32) (_ bv1024 32))) ((_ sign_extend 32) (bvmul in.23_32 (_ bv1024 32)))) true)))
(let (($x975 (or false false (or $x1769))))
(and (not $x975) (or $x975 (and (distinct (bvmul in.23_32 (_ bv1024 32)) (bvmul in.23_32 (_ bv1024 32))) true))))))
(check-sat)
; query 114: function parseval, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.34_32 () (_ BitVec 32))
(assert
 (let (($x2671 (and (distinct (bvmul ((_ sign_extend 32) in.34_32) ((_ sign_extend 32) (_ bv1048576 32))) ((_ sign_extend 32) (bvmul in.34_32 (_ bv1048576 32)))) true)))
(let (($x2398 (or false false (or $x2671))))
(and (not $x2398) (or $x2398 (and (distinct (bvmul in.34_32 (_ bv1048576 32)) (bvmul in.34_32 (_ bv1048576 32))) true))))))
(check-sat)
; query 115: function partition_memory, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x2370 (or false false false)))
(let (($x1435 (not $x2370)))
(and $x1435 (or $x2370 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 116: function run_crc_loop, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1278 (bvadd in.01_32 (_ bv1 32))))
(let (($x2150 (and (distinct ?x1278 ?x1278) true)))
(let (($x2370 (or false false false)))
(let (($x1435 (not $x2370)))
(and $x1435 (or $x2370 $x2150)))))))
(check-sat)
