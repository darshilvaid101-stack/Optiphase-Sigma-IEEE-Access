; OptiPhase-Sigma refinement certificate for sweep K56-R3-112
; query 0: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x95 (or false false false)))
(let (($x122 (not $x95)))
(and $x122 (or $x95 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x540 (bvadd in.01_32 (_ bv1 32))))
(let ((?x151 (bvmul ?x540 ?x540)))
(let (($x95 (or false false false)))
(let (($x331 (or $x95 $x95 false)))
(and (not $x331) (or $x331 (and (distinct ?x151 ?x151) true))))))))
(check-sat)
; query 2: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x1909 (and (distinct (bvmul (bvmul (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) (_ bv2 32)) (bvshl (bvmul (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) (_ bv3 32))) true)))
(let (($x95 (or false false false)))
(let (($x331 (or $x95 $x95 false)))
(let (($x821 (or $x331 false false)))
(and (not $x821) (or (or $x821 (bvuge (_ bv3 32) (_ bv32 32))) $x1909)))))))
(check-sat)
; query 3: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x370 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x95 (or false false false)))
(let (($x122 (not $x95)))
(and $x122 (or $x95 (and (distinct ?x370 ?x370) true)))))))
(check-sat)
; query 4: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x95 (or false false false)))
(let (($x122 (not $x95)))
(and $x122 (or $x95 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 5: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x18 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x95 (or false false false)))
(let (($x122 (not $x95)))
(and $x122 (or $x95 (and (distinct ?x18 ?x18) true)))))))
(check-sat)
