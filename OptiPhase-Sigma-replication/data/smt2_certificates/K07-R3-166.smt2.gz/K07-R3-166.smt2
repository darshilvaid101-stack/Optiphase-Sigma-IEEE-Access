; OptiPhase-Sigma refinement certificate for sweep K07-R3-166
; query 0: function xmalloc, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in7_32 () (_ BitVec 32))
(assert
 (let ((?x60 (ite (and (distinct (_ bv0 32) in7_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x59 (or false false false)))
(and (not $x59) (or $x59 (and (distinct ?x60 ?x60) true))))))
(check-sat)
