; OptiPhase-Sigma refinement certificate for sweep K56-R3-249
; query 0: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x518 (or false false false)))
(let (($x57 (not $x518)))
(and $x57 (or $x518 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x755 (bvadd in.01_32 (_ bv1 32))))
(let ((?x89 (bvmul ?x755 ?x755)))
(let (($x518 (or false false false)))
(let (($x257 (or $x518 $x518 false)))
(and (not $x257) (or $x257 (and (distinct ?x89 ?x89) true))))))))
(check-sat)
; query 2: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x755 (bvadd in.01_32 (_ bv1 32))))
(let ((?x89 (bvmul ?x755 ?x755)))
(let ((?x175 (bvmul ?x89 (_ bv2 32))))
(let (($x518 (or false false false)))
(let (($x257 (or $x518 $x518 false)))
(let (($x268 (or $x257 false false)))
(and (not $x268) (or $x268 (and (distinct ?x175 ?x175) true))))))))))
(check-sat)
; query 3: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x755 (bvadd in.01_32 (_ bv1 32))))
(let ((?x89 (bvmul ?x755 ?x755)))
(let ((?x175 (bvmul ?x89 (_ bv2 32))))
(let ((?x37 (bvmul ?x175 (_ bv4 32))))
(let (($x518 (or false false false)))
(let (($x257 (or $x518 $x518 false)))
(let (($x268 (or $x257 false false)))
(let (($x413 (or $x268 false false)))
(and (not $x413) (or $x413 (and (distinct ?x37 ?x37) true))))))))))))
(check-sat)
; query 4: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x591 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x518 (or false false false)))
(let (($x57 (not $x518)))
(and $x57 (or $x518 (and (distinct ?x591 ?x591) true)))))))
(check-sat)
; query 5: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x1376 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x518 (or false false false)))
(let (($x57 (not $x518)))
(and $x57 (or $x518 (and (distinct ?x1376 ?x1376) true)))))))
(check-sat)
; query 6: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x518 (or false false false)))
(let (($x57 (not $x518)))
(and $x57 (or $x518 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 7: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x1391 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x64 (or false false (or $x1391))))
(and (not $x64) (or $x64 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x341 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x518 (or false false false)))
(let (($x57 (not $x518)))
(and $x57 (or $x518 (and (distinct ?x341 ?x341) true)))))))
(check-sat)
; query 9: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x428 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x518 (or false false false)))
(let (($x57 (not $x518)))
(and $x57 (or $x518 (and (distinct ?x428 ?x428) true)))))))
(check-sat)
; query 10: function matrix_add_const, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x518 (or false false false)))
(let (($x57 (not $x518)))
(and $x57 (or $x518 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 11: function matrix_add_const, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x518 (or false false false)))
(let (($x57 (not $x518)))
(and $x57 (or $x518 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 12: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x655 (or false false)))
(and (not $x655) (or $x655 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true)))))
(check-sat)
; query 13: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x330 ((_ sign_extend 16) in.1_16)))
(let ((?x562 (bvadd ?x330 (_ bv10 32))))
(let (($x1347 (and (distinct (bvadd ((_ sign_extend 1) ?x330) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x562)) true)))
(let (($x655 (or false false)))
(let (($x490 (or $x655 false (or $x1347))))
(and (not $x490) (or $x490 (and (distinct ?x562 ?x562) true)))))))))
(check-sat)
; query 14: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x330 ((_ sign_extend 16) in.1_16)))
(let ((?x562 (bvadd ?x330 (_ bv10 32))))
(let ((?x99 ((_ extract 15 0) ?x562)))
(let (($x1347 (and (distinct (bvadd ((_ sign_extend 1) ?x330) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x562)) true)))
(let (($x655 (or false false)))
(let (($x490 (or $x655 false (or $x1347))))
(let (($x21 (or $x490 false)))
(and (not $x21) (or $x21 (and (distinct ?x99 ?x99) true)))))))))))
(check-sat)
