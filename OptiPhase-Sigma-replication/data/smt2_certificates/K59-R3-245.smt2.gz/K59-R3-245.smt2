; OptiPhase-Sigma refinement certificate for sweep K59-R3-245
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x1040 (or false (or (= ((_ extract 15 15) in25_16) (_ bv1 1))))))
(let (($x1140 (or false false)))
(let (($x44 (not $x1140)))
(and $x44 (or $x1040 (and (distinct ((_ sign_extend 16) in25_16) ((_ zero_extend 16) in25_16)) true)))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x124 (and (distinct (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1)) (ite (bvsgt (_ bv34 32) ((_ zero_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))) true)))
(let (($x730 (or (or (or false (or (= ((_ extract 15 15) in25_16) (_ bv1 1)))) false false) $x124)))
(let (($x1140 (or false false)))
(let (($x512 (or $x1140 false false)))
(let (($x1275 (not $x512)))
(and $x1275 $x730)))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x1140 (or false false)))
(let (($x44 (not $x1140)))
(and $x44 (or $x1140 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x1369 ((_ sign_extend 16) in3_16)))
(let ((?x1079 (bvand ?x1369 (_ bv127 32))))
(let (($x1140 (or false false)))
(let (($x512 (or $x1140 false false)))
(let (($x1275 (not $x512)))
(and $x1275 (or $x512 (and (distinct ?x1079 ?x1079) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x1369 ((_ sign_extend 16) in3_16)))
(let ((?x1079 (bvand ?x1369 (_ bv127 32))))
(let ((?x7824 ((_ extract 15 0) ?x1079)))
(let (($x25 (or (and (distinct ((_ zero_extend 16) ?x7824) ?x1079) true) (and (distinct ((_ sign_extend 16) ?x7824) ?x1079) true))))
(let (($x1140 (or false false)))
(let (($x512 (or $x1140 false false)))
(let (($x192 (not (or $x512 false))))
(and $x192 (or (or $x512 $x25) (and (distinct ?x7824 ?x7824) true)))))))))))
(check-sat)
; query 5: function core_bench_list, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x726 (or false false false)))
(let (($x384 (not $x726)))
(and $x384 (or $x726 (and (distinct (bvadd in.0_16 (_ bv1 16)) (bvadd in.0_16 (_ bv1 16))) true))))))
(check-sat)
; query 6: function core_bench_state, block 105, name %106
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x461 (and (distinct (bvadd ((_ zero_extend 1) in.1_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x130 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x34 (or (or false false (or $x130 $x461)) (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))
(let (($x726 (or false false false)))
(let (($x384 (not $x726)))
(and $x384 $x34)))))))
(check-sat)
; query 7: function core_bench_state, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x483 (bvadd in.0_32 (_ bv1 32))))
(let (($x52 (and (distinct ?x483 ?x483) true)))
(let (($x257 (and (distinct (bvadd ((_ zero_extend 1) in.0_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) ?x483)) true)))
(let (($x490 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x483)) true)))
(let (($x726 (or false false false)))
(let (($x384 (not $x726)))
(and $x384 (or (or false false (or $x490 $x257)) $x52)))))))))
(check-sat)
; query 8: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x395 (bvadd in.01_32 (_ bv1 32))))
(let (($x389 (and (distinct ?x395 ?x395) true)))
(let (($x726 (or false false false)))
(let (($x384 (not $x726)))
(and $x384 (or $x726 $x389)))))))
(check-sat)
; query 9: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x395 (bvadd in.01_32 (_ bv1 32))))
(let ((?x21 (bvmul ?x395 (_ bv8 32))))
(let ((?x41 (bvmul ?x395 ?x395)))
(let (($x726 (or false false false)))
(let (($x100 (or $x726 false false)))
(and (not (or $x726 $x726 false)) (or $x100 (and (distinct ?x41 ?x21) true)))))))))
(check-sat)
; query 10: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x539 (and (distinct (bvmul (bvmul (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) (_ bv2 32)) (bvmul (bvmul (bvadd in.01_32 (_ bv1 32)) (_ bv8 32)) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x726 (or false false false)))
(let (($x100 (or $x726 false false)))
(and (not (or (or $x726 $x726 false) false false)) (or (or $x100 $x726 false) $x539))))))
(check-sat)
; query 11: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x618 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x726 (or false false false)))
(let (($x384 (not $x726)))
(and $x384 (or $x726 (and (distinct ?x618 ?x618) true)))))))
(check-sat)
; query 12: function core_init_state, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_32 () (_ BitVec 32))
(assert
 (let (($x122 (and (distinct (bvadd ((_ zero_extend 1) in.06_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.06_32 (_ bv1 32)))) true)))
(let (($x551 (and (distinct (bvadd ((_ sign_extend 1) in.06_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.06_32 (_ bv1 32)))) true)))
(let (($x630 (or (or false false (or $x551 $x122)) (and (distinct (bvadd in.06_32 (_ bv1 32)) (bvadd in.06_32 (_ bv1 32))) true))))
(let (($x726 (or false false false)))
(let (($x384 (not $x726)))
(and $x384 $x630)))))))
(check-sat)
; query 13: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x428 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x726 (or false false false)))
(let (($x384 (not $x726)))
(and $x384 (or $x726 (and (distinct ?x428 ?x428) true)))))))
(check-sat)
; query 14: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x726 (or false false false)))
(let (($x384 (not $x726)))
(and $x384 (or $x726 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 15: function core_list_init, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x395 (bvadd in.01_32 (_ bv1 32))))
(let (($x389 (and (distinct ?x395 ?x395) true)))
(let (($x46 (and (distinct (bvadd ((_ zero_extend 1) in.01_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) ?x395)) true)))
(let (($x726 (or false false false)))
(let (($x384 (not $x726)))
(and $x384 (or (or false false (or $x46)) $x389))))))))
(check-sat)
; query 16: function core_list_mergesort, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x395 (bvadd in.01_32 (_ bv1 32))))
(let (($x389 (and (distinct ?x395 ?x395) true)))
(let (($x170 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x395)) true)))
(let (($x136 (or false false (or $x170))))
(and (not $x136) (or $x136 $x389)))))))
(check-sat)
; query 17: function core_list_mergesort, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x426 (ite (bvslt (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x726 (or false false false)))
(let (($x384 (not $x726)))
(and $x384 (or $x726 (and (distinct ?x426 ?x426) true)))))))
(check-sat)
; query 18: function core_list_mergesort, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.224_32 () (_ BitVec 32))
(assert
 (let ((?x1410 (ite (= (_ bv0 32) in.224_32) (_ bv1 1) (_ bv0 1))))
(let (($x726 (or false false false)))
(let (($x384 (not $x726)))
(and $x384 (or $x726 (and (distinct ?x1410 ?x1410) true)))))))
(check-sat)
; query 19: function core_list_mergesort, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x8 (ite (= (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x726 (or false false false)))
(let (($x384 (not $x726)))
(and $x384 (or $x726 (and (distinct ?x8 ?x8) true)))))))
(check-sat)
; query 20: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x140 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x167 (or false false (or $x140))))
(and (not $x167) (or $x167 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 21: function core_list_mergesort, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x528 (and (distinct (bvmul ((_ sign_extend 32) in.020_32) ((_ sign_extend 32) (_ bv2 32))) ((_ sign_extend 32) (bvmul in.020_32 (_ bv2 32)))) true)))
(let (($x776 (or false false (or $x528))))
(and (not $x776) (or $x776 (and (distinct (bvmul in.020_32 (_ bv2 32)) (bvmul in.020_32 (_ bv2 32))) true))))))
(check-sat)
; query 22: function core_state_transition, block 102, name %103
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1140 (or false false)))
(let (($x44 (not $x1140)))
(and $x44 (or $x1140 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 23: function core_state_transition, block 102, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x33 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1140 (or false false)))
(let (($x512 (or $x1140 false false)))
(let (($x1275 (not $x512)))
(and $x1275 (or $x512 (and (distinct ?x33 ?x33) true))))))))
(check-sat)
; query 24: function core_state_transition, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1140 (or false false)))
(let (($x44 (not $x1140)))
(and $x44 (or $x1140 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 25: function core_state_transition, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x220 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1140 (or false false)))
(let (($x512 (or $x1140 false false)))
(let (($x1275 (not $x512)))
(and $x1275 (or $x512 (and (distinct ?x220 ?x220) true))))))))
(check-sat)
; query 26: function core_state_transition, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1140 (or false false)))
(let (($x44 (not $x1140)))
(and $x44 (or $x1140 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 27: function core_state_transition, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x33 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1140 (or false false)))
(let (($x512 (or $x1140 false false)))
(let (($x1275 (not $x512)))
(and $x1275 (or $x512 (and (distinct ?x33 ?x33) true))))))))
(check-sat)
; query 28: function core_state_transition, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1140 (or false false)))
(let (($x44 (not $x1140)))
(and $x44 (or $x1140 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 29: function core_state_transition, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x109 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1140 (or false false)))
(let (($x512 (or $x1140 false false)))
(let (($x1275 (not $x512)))
(and $x1275 (or $x512 (and (distinct ?x109 ?x109) true))))))))
(check-sat)
; query 30: function core_state_transition, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1140 (or false false)))
(let (($x44 (not $x1140)))
(and $x44 (or $x1140 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 31: function core_state_transition, block 51, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x109 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1140 (or false false)))
(let (($x512 (or $x1140 false false)))
(let (($x1275 (not $x512)))
(and $x1275 (or $x512 (and (distinct ?x109 ?x109) true))))))))
(check-sat)
; query 32: function core_state_transition, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1140 (or false false)))
(let (($x44 (not $x1140)))
(and $x44 (or $x1140 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 33: function core_state_transition, block 64, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x109 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1140 (or false false)))
(let (($x512 (or $x1140 false false)))
(let (($x1275 (not $x512)))
(and $x1275 (or $x512 (and (distinct ?x109 ?x109) true))))))))
(check-sat)
; query 34: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x355 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x726 (or false false false)))
(let (($x384 (not $x726)))
(and $x384 (or $x726 (and (distinct ?x355 ?x355) true)))))))
(check-sat)
; query 35: function core_state_transition, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1140 (or false false)))
(let (($x44 (not $x1140)))
(and $x44 (or $x1140 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 36: function core_state_transition, block 80, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x132 (ite (= (_ bv69 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1140 (or false false)))
(let (($x512 (or $x1140 false false)))
(let (($x1275 (not $x512)))
(and $x1275 (or $x512 (and (distinct ?x132 ?x132) true))))))))
(check-sat)
; query 37: function core_state_transition, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1140 (or false false)))
(let (($x44 (not $x1140)))
(and $x44 (or $x1140 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 38: function core_state_transition, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x692 (ite (= (_ bv101 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1140 (or false false)))
(let (($x512 (or $x1140 false false)))
(let (($x1275 (not $x512)))
(and $x1275 (or $x512 (and (distinct ?x692 ?x692) true))))))))
(check-sat)
; query 39: function core_state_transition, block 99, name %100
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1140 (or false false)))
(let (($x44 (not $x1140)))
(and $x44 (or $x1140 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 40: function core_state_transition, block 99, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x220 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1140 (or false false)))
(let (($x512 (or $x1140 false false)))
(let (($x1275 (not $x512)))
(and $x1275 (or $x512 (and (distinct ?x220 ?x220) true))))))))
(check-sat)
; query 41: function crcu8, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x1140 (or false false)))
(let (($x44 (not $x1140)))
(and $x44 (or $x1140 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 42: function crcu8, block 19, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x1385 ((_ zero_extend 16) in.01_16)))
(let ((?x1387 (bvxor ?x1385 (_ bv16386 32))))
(let (($x1140 (or false false)))
(let (($x512 (or $x1140 false false)))
(let (($x1275 (not $x512)))
(and $x1275 (or $x512 (and (distinct ?x1387 ?x1387) true)))))))))
(check-sat)
; query 43: function crcu8, block 19, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x1385 ((_ zero_extend 16) in.01_16)))
(let ((?x1387 (bvxor ?x1385 (_ bv16386 32))))
(let ((?x1330 ((_ extract 15 0) ?x1387)))
(let (($x1140 (or false false)))
(let (($x512 (or $x1140 false false)))
(let (($x1321 (or (or $x512 (or (and (distinct ((_ zero_extend 16) ?x1330) ?x1387) true))) (and (distinct ?x1330 ?x1330) true))))
(let (($x192 (not (or $x512 false))))
(and $x192 $x1321)))))))))
(check-sat)
; query 44: function crcu8, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x1380 (or false (or (= ((_ extract 15 15) in27_16) (_ bv1 1))))))
(let (($x1140 (or false false)))
(let (($x44 (not $x1140)))
(and $x44 (or $x1380 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true)))))))
(check-sat)
; query 45: function crcu8, block 29, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1342 ((_ zero_extend 16) in27_16)))
(let ((?x1340 (bvor ?x1342 (_ bv32768 32))))
(let (($x1380 (or false (or (= ((_ extract 15 15) in27_16) (_ bv1 1))))))
(let (($x1371 (or $x1380 false false)))
(let (($x1140 (or false false)))
(let (($x512 (or $x1140 false false)))
(let (($x1275 (not $x512)))
(and $x1275 (or $x1371 (and (distinct ?x1340 ?x1340) true)))))))))))
(check-sat)
; query 46: function crcu8, block 29, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1342 ((_ zero_extend 16) in27_16)))
(let ((?x1340 (bvor ?x1342 (_ bv32768 32))))
(let ((?x1386 ((_ extract 15 0) ?x1340)))
(let (($x1380 (or false (or (= ((_ extract 15 15) in27_16) (_ bv1 1))))))
(let (($x1371 (or $x1380 false false)))
(let (($x223 (or (or $x1371 (or (and (distinct ((_ zero_extend 16) ?x1386) ?x1340) true))) (and (distinct ?x1386 ?x1386) true))))
(let (($x192 (not (or (or (or false false) false false) false))))
(and $x192 $x223)))))))))
(check-sat)
; query 47: function crcu8, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x1174 ((_ extract 7 0) in.01_16)))
(let ((?x1087 ((_ zero_extend 24) ?x1174)))
(let (($x1140 (or false false)))
(let (($x1396 (or $x1140 false)))
(and (not $x1396) (or $x1396 (and (distinct ?x1087 ?x1087) true))))))))
(check-sat)
; query 48: function crcu8, block 6, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x1174 ((_ extract 7 0) in.01_16)))
(let ((?x1087 ((_ zero_extend 24) ?x1174)))
(let ((?x1408 (bvand ?x1087 (_ bv1 32))))
(let (($x1140 (or false false)))
(let (($x1396 (or $x1140 false)))
(let (($x1373 (or $x1396 false false)))
(and (not $x1373) (or $x1373 (and (distinct ?x1408 ?x1408) true))))))))))
(check-sat)
; query 49: function crcu8, block 6, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1174 ((_ extract 7 0) in.01_16)))
(let ((?x1087 ((_ zero_extend 24) ?x1174)))
(let ((?x1408 (bvand ?x1087 (_ bv1 32))))
(let ((?x1301 ((_ zero_extend 24) in.0_8)))
(let ((?x1315 (bvand ?x1301 (_ bv1 32))))
(let ((?x36 (bvxor ?x1315 ?x1408)))
(let (($x1140 (or false false)))
(let (($x1396 (or $x1140 false)))
(let (($x1373 (or $x1396 false false)))
(let (($x512 (or $x1140 false false)))
(let (($x1392 (or $x512 $x1373 false)))
(and (not $x1392) (or $x1392 (and (distinct ?x36 ?x36) true)))))))))))))))
(check-sat)
; query 50: function crcu8, block 6, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1174 ((_ extract 7 0) in.01_16)))
(let ((?x1087 ((_ zero_extend 24) ?x1174)))
(let ((?x1408 (bvand ?x1087 (_ bv1 32))))
(let ((?x1301 ((_ zero_extend 24) in.0_8)))
(let ((?x1315 (bvand ?x1301 (_ bv1 32))))
(let ((?x36 (bvxor ?x1315 ?x1408)))
(let ((?x1303 ((_ extract 7 0) ?x36)))
(let (($x673 (or (and (distinct ((_ zero_extend 24) ?x1303) ?x36) true) (and (distinct ((_ sign_extend 24) ?x1303) ?x36) true))))
(let (($x1140 (or false false)))
(let (($x1396 (or $x1140 false)))
(let (($x1373 (or $x1396 false false)))
(let (($x512 (or $x1140 false false)))
(let (($x1392 (or $x512 $x1373 false)))
(let (($x956 (or $x1392 $x673)))
(and (not (or $x1392 false)) (or $x956 (and (distinct ?x1303 ?x1303) true))))))))))))))))))
(check-sat)
; query 51: function crcu8, block 6, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x1140 (or false false)))
(let (($x44 (not $x1140)))
(and $x44 (or $x1140 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 52: function crcu8, block 6, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1301 ((_ zero_extend 24) in.0_8)))
(let ((?x1295 (bvlshr ?x1301 (_ bv1 32))))
(let ((?x1268 (bvashr ?x1301 (_ bv1 32))))
(let (($x1140 (or false false)))
(let (($x512 (or $x1140 false false)))
(let (($x1309 (or $x512 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not $x1309) (or $x1309 (and (distinct ?x1268 ?x1295) true))))))))))
(check-sat)
; query 53: function crcu8, block 6, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x990 (and (distinct ((_ extract 7 0) (bvashr ((_ zero_extend 24) in.0_8) (_ bv1 32))) ((_ extract 7 0) (bvlshr ((_ zero_extend 24) in.0_8) (_ bv1 32)))) true)))
(let (($x1140 (or false false)))
(let (($x512 (or $x1140 false false)))
(let (($x1309 (or $x512 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x1404 (or $x1309 false)))
(and (not $x1404) (or $x1404 $x990))))))))
(check-sat)
; query 54: function crcu8, block 6, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1174 ((_ extract 7 0) in.01_16)))
(let ((?x1087 ((_ zero_extend 24) ?x1174)))
(let ((?x1408 (bvand ?x1087 (_ bv1 32))))
(let ((?x1301 ((_ zero_extend 24) in.0_8)))
(let ((?x1315 (bvand ?x1301 (_ bv1 32))))
(let ((?x36 (bvxor ?x1315 ?x1408)))
(let ((?x1303 ((_ extract 7 0) ?x36)))
(let ((?x1299 ((_ zero_extend 24) ?x1303)))
(let (($x1140 (or false false)))
(let (($x1396 (or $x1140 false)))
(let (($x1373 (or $x1396 false false)))
(let (($x512 (or $x1140 false false)))
(let (($x1392 (or $x512 $x1373 false)))
(let (($x956 (or $x1392 (or (and (distinct ?x1299 ?x36) true) (and (distinct ((_ sign_extend 24) ?x1303) ?x36) true)))))
(let (($x897 (or $x956 (or (= ((_ extract 7 7) ?x1303) (_ bv1 1))))))
(and (not (or (or $x1392 false) false)) (or $x897 (and (distinct ?x1299 ?x1299) true)))))))))))))))))))
(check-sat)
; query 55: function crcu8, block 6, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1174 ((_ extract 7 0) in.01_16)))
(let ((?x1087 ((_ zero_extend 24) ?x1174)))
(let ((?x1408 (bvand ?x1087 (_ bv1 32))))
(let ((?x1301 ((_ zero_extend 24) in.0_8)))
(let ((?x1315 (bvand ?x1301 (_ bv1 32))))
(let ((?x36 (bvxor ?x1315 ?x1408)))
(let ((?x1303 ((_ extract 7 0) ?x36)))
(let ((?x1299 ((_ zero_extend 24) ?x1303)))
(let ((?x1260 (ite (= (_ bv1 32) ?x1299) (_ bv1 1) (_ bv0 1))))
(let (($x1140 (or false false)))
(let (($x1396 (or $x1140 false)))
(let (($x1373 (or $x1396 false false)))
(let (($x512 (or $x1140 false false)))
(let (($x1392 (or $x512 $x1373 false)))
(let (($x956 (or $x1392 (or (and (distinct ?x1299 ?x36) true) (and (distinct ((_ sign_extend 24) ?x1303) ?x36) true)))))
(let (($x897 (or $x956 (or (= ((_ extract 7 7) ?x1303) (_ bv1 1))))))
(and (not (or (or (or $x1392 false) false) false false)) (or (or $x897 false false) (and (distinct ?x1260 ?x1260) true))))))))))))))))))))
(check-sat)
; query 56: function crcu8, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x1140 (or false false)))
(let (($x44 (not $x1140)))
(and $x44 (or $x1140 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 57: function crcu8, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1301 ((_ zero_extend 24) in.0_8)))
(let ((?x1315 (bvand ?x1301 (_ bv1 32))))
(let (($x1140 (or false false)))
(let (($x512 (or $x1140 false false)))
(let (($x1275 (not $x512)))
(and $x1275 (or $x512 (and (distinct ?x1315 ?x1315) true)))))))))
(check-sat)
; query 58: function crcu8, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x1140 (or false false)))
(let (($x44 (not $x1140)))
(and $x44 (or $x1140 (and (distinct ((_ extract 7 0) in.01_16) ((_ extract 7 0) in.01_16)) true))))))
(check-sat)
; query 59: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1180 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x726 (or false false false)))
(let (($x384 (not $x726)))
(and $x384 (or $x726 (and (distinct ?x1180 ?x1180) true)))))))
(check-sat)
; query 60: function matrix_add_const, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x483 (bvadd in.0_32 (_ bv1 32))))
(let (($x52 (and (distinct ?x483 ?x483) true)))
(let (($x726 (or false false false)))
(let (($x384 (not $x726)))
(and $x384 (or $x726 $x52)))))))
(check-sat)
; query 61: function matrix_add_const, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x395 (bvadd in.01_32 (_ bv1 32))))
(let (($x389 (and (distinct ?x395 ?x395) true)))
(let (($x726 (or false false false)))
(let (($x384 (not $x726)))
(and $x384 (or $x726 $x389)))))))
(check-sat)
; query 62: function matrix_mul_const, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x483 (bvadd in.0_32 (_ bv1 32))))
(let (($x52 (and (distinct ?x483 ?x483) true)))
(let (($x726 (or false false false)))
(let (($x384 (not $x726)))
(and $x384 (or $x726 $x52)))))))
(check-sat)
; query 63: function matrix_mul_const, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x395 (bvadd in.01_32 (_ bv1 32))))
(let (($x389 (and (distinct ?x395 ?x395) true)))
(let (($x726 (or false false false)))
(let (($x384 (not $x726)))
(and $x384 (or $x726 $x389)))))))
(check-sat)
; query 64: function matrix_mul_matrix, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x483 (bvadd in.0_32 (_ bv1 32))))
(let (($x52 (and (distinct ?x483 ?x483) true)))
(let (($x726 (or false false false)))
(let (($x384 (not $x726)))
(and $x384 (or $x726 $x52)))))))
(check-sat)
; query 65: function matrix_mul_matrix, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x395 (bvadd in.01_32 (_ bv1 32))))
(let (($x389 (and (distinct ?x395 ?x395) true)))
(let (($x726 (or false false false)))
(let (($x384 (not $x726)))
(and $x384 (or $x726 $x389)))))))
(check-sat)
; query 66: function matrix_mul_matrix, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x726 (or false false false)))
(let (($x384 (not $x726)))
(and $x384 (or $x726 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 67: function matrix_mul_matrix_bitextract, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x483 (bvadd in.0_32 (_ bv1 32))))
(let (($x52 (and (distinct ?x483 ?x483) true)))
(let (($x726 (or false false false)))
(let (($x384 (not $x726)))
(and $x384 (or $x726 $x52)))))))
(check-sat)
; query 68: function matrix_mul_matrix_bitextract, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x395 (bvadd in.01_32 (_ bv1 32))))
(let (($x389 (and (distinct ?x395 ?x395) true)))
(let (($x726 (or false false false)))
(let (($x384 (not $x726)))
(and $x384 (or $x726 $x389)))))))
(check-sat)
; query 69: function matrix_mul_matrix_bitextract, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x726 (or false false false)))
(let (($x384 (not $x726)))
(and $x384 (or $x726 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 70: function matrix_mul_vect, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x483 (bvadd in.0_32 (_ bv1 32))))
(let (($x52 (and (distinct ?x483 ?x483) true)))
(let (($x726 (or false false false)))
(let (($x384 (not $x726)))
(and $x384 (or $x726 $x52)))))))
(check-sat)
; query 71: function matrix_mul_vect, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x395 (bvadd in.01_32 (_ bv1 32))))
(let (($x389 (and (distinct ?x395 ?x395) true)))
(let (($x726 (or false false false)))
(let (($x384 (not $x726)))
(and $x384 (or $x726 $x389)))))))
(check-sat)
; query 72: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x1140 (or false false)))
(let (($x44 (not $x1140)))
(and $x44 (or $x1140 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 73: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x247 ((_ sign_extend 16) in.1_16)))
(let ((?x1117 (bvadd ?x247 (_ bv10 32))))
(let (($x747 (and (distinct (bvadd ((_ sign_extend 1) ?x247) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x1117)) true)))
(let (($x1140 (or false false)))
(let (($x340 (or $x1140 false (or $x747))))
(and (not $x340) (or $x340 (and (distinct ?x1117 ?x1117) true)))))))))
(check-sat)
; query 74: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x247 ((_ sign_extend 16) in.1_16)))
(let ((?x1117 (bvadd ?x247 (_ bv10 32))))
(let ((?x890 ((_ extract 15 0) ?x1117)))
(let (($x747 (and (distinct (bvadd ((_ sign_extend 1) ?x247) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x1117)) true)))
(let (($x1140 (or false false)))
(let (($x340 (or $x1140 false (or $x747))))
(let (($x180 (or $x340 false)))
(and (not $x180) (or $x180 (and (distinct ?x890 ?x890) true)))))))))))
(check-sat)
; query 75: function partition_memory, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x483 (bvadd in.0_32 (_ bv1 32))))
(let (($x52 (and (distinct ?x483 ?x483) true)))
(let (($x257 (and (distinct (bvadd ((_ zero_extend 1) in.0_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) ?x483)) true)))
(let (($x490 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x483)) true)))
(let (($x726 (or false false false)))
(let (($x384 (not $x726)))
(and $x384 (or (or false false (or $x490 $x257)) $x52)))))))))
(check-sat)
; query 76: function run_matrix_multiply, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x726 (or false false false)))
(let (($x384 (not $x726)))
(and $x384 (or $x726 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 77: function run_matrix_multiply, block 34, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x395 (bvadd in.01_32 (_ bv1 32))))
(let (($x389 (and (distinct ?x395 ?x395) true)))
(let (($x726 (or false false false)))
(let (($x384 (not $x726)))
(and $x384 (or $x726 $x389)))))))
(check-sat)
