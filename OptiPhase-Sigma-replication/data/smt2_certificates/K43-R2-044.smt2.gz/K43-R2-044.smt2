; OptiPhase-Sigma refinement certificate for sweep K43-R2-044
; query 0: function crc32buf, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_64 () (_ BitVec 64))
(assert
 (let (($x229 (or false false false)))
(let (($x823 (not $x229)))
(and $x823 (or $x229 (and (distinct (bvxor in.02_64 (_ bv18446744073709551615 64)) (bvxor in.02_64 (_ bv18446744073709551615 64))) true))))))
(check-sat)
; query 1: function main, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x7 (ite (and (distinct (_ bv0 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x229 (or false false false)))
(let (($x823 (not $x229)))
(and $x823 (or $x229 (and (distinct ?x7 ?x7) true)))))))
(check-sat)
; query 2: function main, block 17, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x7 (ite (and (distinct (_ bv0 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let ((?x28 ((_ zero_extend 31) ?x7)))
(let (($x229 (or false false false)))
(let (($x384 (or $x229 false)))
(and (not $x384) (or $x384 (and (distinct ?x28 ?x28) true))))))))
(check-sat)
