; OptiPhase-Sigma refinement certificate for sweep K33-R6-041
; query 0: function edge_draw, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let ((?x130 (ite (= (_ bv0 32) in4_32) (_ bv1 1) (_ bv0 1))))
(let (($x33 (or false false false)))
(let (($x135 (not $x33)))
(and $x135 (or $x33 (and (distinct ?x130 ?x130) true)))))))
(check-sat)
; query 1: function main, block 129, name %130
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.011.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x693 (ite (and (distinct (_ bv0 32) in.011.lcssa_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x33 (or false false false)))
(let (($x135 (not $x33)))
(and $x135 (or $x33 (and (distinct ?x693 ?x693) true)))))))
(check-sat)
; query 2: function main, block 160, name %161
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x90 (ite (and (distinct (_ bv0 32) in.01.lcssa_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x33 (or false false false)))
(let (($x135 (not $x33)))
(and $x135 (or $x33 (and (distinct ?x90 ?x90) true)))))))
(check-sat)
; query 3: function main, block 66, name %67
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x114 (ite (= (_ bv0 32) in.0.lcssa_32) (_ bv1 1) (_ bv0 1))))
(let (($x33 (or false false false)))
(let (($x135 (not $x33)))
(and $x135 (or $x33 (and (distinct ?x114 ?x114) true)))))))
(check-sat)
; query 4: function main, block 84, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.07.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x297 (ite (and (distinct (_ bv0 32) in.07.lcssa_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x33 (or false false false)))
(let (($x135 (not $x33)))
(and $x135 (or $x33 (and (distinct ?x297 ?x297) true)))))))
(check-sat)
