; OptiPhase-Sigma refinement certificate for sweep K57-R2-010
; query 0: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x1868 (or false false false)))
(let (($x1664 (not $x1868)))
(and $x1664 (or $x1868 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x274 (bvadd in.01_32 (_ bv1 32))))
(let ((?x1213 (bvmul ?x274 ?x274)))
(let (($x1868 (or false false false)))
(let (($x157 (or $x1868 $x1868 false)))
(and (not $x157) (or $x157 (and (distinct ?x1213 ?x1213) true))))))))
(check-sat)
; query 2: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x274 (bvadd in.01_32 (_ bv1 32))))
(let ((?x1213 (bvmul ?x274 ?x274)))
(let ((?x1354 (bvmul ?x1213 (_ bv2 32))))
(let (($x1868 (or false false false)))
(let (($x157 (or $x1868 $x1868 false)))
(let (($x64 (or $x157 false false)))
(and (not $x64) (or $x64 (and (distinct ?x1354 ?x1354) true))))))))))
(check-sat)
; query 3: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x274 (bvadd in.01_32 (_ bv1 32))))
(let ((?x1213 (bvmul ?x274 ?x274)))
(let ((?x1354 (bvmul ?x1213 (_ bv2 32))))
(let ((?x123 (bvmul ?x1354 (_ bv4 32))))
(let (($x1868 (or false false false)))
(let (($x157 (or $x1868 $x1868 false)))
(let (($x64 (or $x157 false false)))
(let (($x815 (or $x64 false false)))
(and (not $x815) (or $x815 (and (distinct ?x123 ?x123) true))))))))))))
(check-sat)
; query 4: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x163 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x1868 (or false false false)))
(let (($x1664 (not $x1868)))
(and $x1664 (or $x1868 (and (distinct ?x163 ?x163) true)))))))
(check-sat)
; query 5: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x661 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x1868 (or false false false)))
(let (($x1664 (not $x1868)))
(and $x1664 (or $x1868 (and (distinct ?x661 ?x661) true)))))))
(check-sat)
; query 6: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x1868 (or false false false)))
(let (($x1664 (not $x1868)))
(and $x1664 (or $x1868 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 7: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x120 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x792 (or false false (or $x120))))
(and (not $x792) (or $x792 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x90 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x1868 (or false false false)))
(let (($x1664 (not $x1868)))
(and $x1664 (or $x1868 (and (distinct ?x90 ?x90) true)))))))
(check-sat)
; query 9: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1901 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x1868 (or false false false)))
(let (($x1664 (not $x1868)))
(and $x1664 (or $x1868 (and (distinct ?x1901 ?x1901) true)))))))
(check-sat)
; query 10: function matrix_add_const, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1868 (or false false false)))
(let (($x1664 (not $x1868)))
(and $x1664 (or $x1868 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 11: function matrix_add_const, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x1868 (or false false false)))
(let (($x1664 (not $x1868)))
(and $x1664 (or $x1868 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 12: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x12 (or false false)))
(and (not $x12) (or $x12 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true)))))
(check-sat)
; query 13: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x1840 ((_ sign_extend 16) in.1_16)))
(let ((?x1864 (bvadd ?x1840 (_ bv10 32))))
(let (($x1648 (and (distinct (bvadd ((_ sign_extend 1) ?x1840) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x1864)) true)))
(let (($x12 (or false false)))
(let (($x245 (or $x12 false (or $x1648))))
(and (not $x245) (or $x245 (and (distinct ?x1864 ?x1864) true)))))))))
(check-sat)
; query 14: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x1840 ((_ sign_extend 16) in.1_16)))
(let ((?x1864 (bvadd ?x1840 (_ bv10 32))))
(let ((?x72 ((_ extract 15 0) ?x1864)))
(let (($x1648 (and (distinct (bvadd ((_ sign_extend 1) ?x1840) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x1864)) true)))
(let (($x12 (or false false)))
(let (($x245 (or $x12 false (or $x1648))))
(let (($x184 (or $x245 false)))
(and (not $x184) (or $x184 (and (distinct ?x72 ?x72) true)))))))))))
(check-sat)
