; OptiPhase-Sigma refinement certificate for sweep K44-R1-005
; query 0: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x19 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x26 (or false false false)))
(let (($x216 (not $x26)))
(and $x216 (or $x26 (and (distinct ?x19 ?x19) true)))))))
(check-sat)
; query 1: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x9 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x26 (or false false false)))
(let (($x216 (not $x26)))
(and $x216 (or $x26 (and (distinct ?x9 ?x9) true)))))))
(check-sat)
