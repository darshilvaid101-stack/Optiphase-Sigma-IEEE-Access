; OptiPhase-Sigma refinement certificate for sweep K39-R3-263
; query 0: function BF_ofb64_encrypt, block 82, name %83
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x29 (ite (= (_ bv0 32) in.04_32) (_ bv1 1) (_ bv0 1))))
(let (($x274 (or false false false)))
(and (not $x274) (or $x274 (and (distinct ?x29 ?x29) true))))))
(check-sat)
