; OptiPhase-Sigma refinement certificate for sweep K04-R2-009
