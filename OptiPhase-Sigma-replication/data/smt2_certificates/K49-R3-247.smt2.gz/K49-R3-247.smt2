; OptiPhase-Sigma refinement certificate for sweep K49-R3-247
; query 0: function Decoding_of_the_coded_Log_Area_Ratios, block 107, name %108
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in104_64 () (_ BitVec 64))
(assert
 (let ((?x1858 (ite (bvslt (_ bv0 64) in104_64) (_ bv1 1) (_ bv0 1))))
(let (($x1899 (or false false false)))
(let (($x1936 (not $x1899)))
(and $x1936 (or $x1899 (and (distinct ?x1858 ?x1858) true)))))))
(check-sat)
; query 1: function Decoding_of_the_coded_Log_Area_Ratios, block 107, name %109
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in104_64 () (_ BitVec 64))
(assert
 (let (($x127 (and (distinct ((_ zero_extend 63) (ite (bvslt (_ bv0 64) in104_64) (_ bv1 1) (_ bv0 1))) (ite (= (_ bv1 1) (ite (bvslt (_ bv0 64) in104_64) (_ bv1 1) (_ bv0 1))) (_ bv32767 64) (_ bv18446744073709518848 64))) true)))
(let (($x1899 (or false false false)))
(let (($x5225 (or $x1899 (ite (= (_ bv1 1) (ite (bvslt (_ bv0 64) in104_64) (_ bv1 1) (_ bv0 1))) false false))))
(and (not (or $x1899 false)) (or $x5225 $x127))))))
(check-sat)
; query 2: function Decoding_of_the_coded_Log_Area_Ratios, block 219, name %220
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in216_64 () (_ BitVec 64))
(assert
 (let (($x71 (and (distinct (ite (bvsge (_ bv18446744073709518848 64) in216_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv0 64) in216_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x1899 (or false false false)))
(let (($x1936 (not $x1899)))
(and $x1936 (or $x1899 $x71))))))
(check-sat)
; query 3: function alaw_input, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x232 (and (distinct (bvadd ((_ zero_extend 1) in.02_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x434 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x234 (or (or false false (or $x434 $x232)) (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))
(and (not (or false false (or $x434))) $x234)))))
(check-sat)
; query 4: function alaw_input, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let ((?x21 (ite (= (_ bv4294967295 32) in.1_32) (_ bv1 1) (_ bv0 1))))
(let (($x1899 (or false false false)))
(let (($x1936 (not $x1899)))
(and $x1936 (or $x1899 (and (distinct ?x21 ?x21) true)))))))
(check-sat)
; query 5: function gsm_L_add, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let (($x559 (and (distinct (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv18446744073709551615 64) in1_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x1899 (or false false false)))
(let (($x1936 (not $x1899)))
(and $x1936 (or $x1899 $x559))))))
(check-sat)
; query 6: function gsm_L_add, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x1673 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvadd in0_64 in1_64))) true)))
(let (($x507 (or false false (or $x1673))))
(let (($x139 (or $x507 (and (distinct (bvadd in0_64 in1_64) (bvadd in0_64 in1_64)) true))))
(and (not $x507) $x139)))))
(check-sat)
; query 7: function gsm_L_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x142 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x1899 (or false false false)))
(let (($x1936 (not $x1899)))
(and $x1936 (or $x1899 (and (distinct ?x142 ?x142) true)))))))
(check-sat)
; query 8: function gsm_L_asl, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x172 (and (distinct (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvsgt (_ bv4294967265 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x1899 (or false false false)))
(let (($x1936 (not $x1899)))
(and $x1936 (or $x1899 $x172))))))
(check-sat)
; query 9: function gsm_L_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x226 (and (distinct (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv31 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x1899 (or false false false)))
(let (($x1936 (not $x1899)))
(and $x1936 (or $x1899 $x226))))))
(check-sat)
; query 10: function gsm_L_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x226 (and (distinct (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv31 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x1899 (or false false false)))
(let (($x1936 (not $x1899)))
(and $x1936 (or $x1899 $x226))))))
(check-sat)
; query 11: function gsm_L_sub, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x173 (bvsub in0_64 in1_64)))
(let (($x84 (and (distinct ?x173 ?x173) true)))
(let (($x418 (and (distinct (bvsub ((_ zero_extend 1) in0_64) ((_ zero_extend 1) in1_64)) ((_ zero_extend 1) ?x173)) true)))
(let (($x18 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) ?x173)) true)))
(let (($x24 (or false false (or $x18))))
(let (($x22 (not $x24)))
(and $x22 (or (or false false (or $x418)) $x84)))))))))
(check-sat)
; query 12: function gsm_L_sub, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let (($x559 (and (distinct (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv18446744073709551615 64) in1_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x1899 (or false false false)))
(let (($x1936 (not $x1899)))
(and $x1936 (or $x1899 $x559))))))
(check-sat)
; query 13: function gsm_L_sub, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x173 (bvsub in0_64 in1_64)))
(let (($x84 (and (distinct ?x173 ?x173) true)))
(let (($x18 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) ?x173)) true)))
(let (($x24 (or false false (or $x18))))
(let (($x22 (not $x24)))
(and $x22 (or $x24 $x84))))))))
(check-sat)
; query 14: function gsm_L_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x333 (and (distinct (ite (bvsle (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv18446744073709551615 64) in0_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x1899 (or false false false)))
(let (($x1936 (not $x1899)))
(and $x1936 (or $x1899 $x333))))))
(check-sat)
; query 15: function gsm_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_64 () (_ BitVec 64))
(assert
 (let ((?x35 (ite (bvslt (_ bv32767 64) in5_64) (_ bv1 1) (_ bv0 1))))
(let (($x1899 (or false false false)))
(let (($x1936 (not $x1899)))
(and $x1936 (or $x1899 (and (distinct ?x35 ?x35) true)))))))
(check-sat)
; query 16: function gsm_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x25 (or false false)))
(let (($x19 (not $x25)))
(and $x19 (or $x25 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 17: function gsm_add, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x25 (or false false)))
(let (($x19 (not $x25)))
(and $x19 (or $x25 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 18: function gsm_add, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x441 ((_ sign_extend 48) in1_16)))
(let ((?x262 ((_ sign_extend 48) in0_16)))
(let ((?x86 (bvadd ?x262 ?x441)))
(let (($x62 (and (distinct (bvadd ((_ sign_extend 1) ?x262) ((_ sign_extend 1) ?x441)) ((_ sign_extend 1) ?x86)) true)))
(let (($x25 (or false false)))
(let (($x137 (or $x25 $x25 (or $x62))))
(and (not $x137) (or $x137 (and (distinct ?x86 ?x86) true))))))))))
(check-sat)
; query 19: function gsm_add, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x33 (ite (bvsgt (_ bv18446744073709518848 64) (bvadd ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x441 ((_ sign_extend 48) in1_16)))
(let ((?x167 ((_ sign_extend 1) ?x441)))
(let ((?x262 ((_ sign_extend 48) in0_16)))
(let ((?x77 ((_ sign_extend 1) ?x262)))
(let (($x25 (or false false)))
(let (($x137 (or $x25 $x25 (or (and (distinct (bvadd ?x77 ?x167) ((_ sign_extend 1) (bvadd ?x262 ?x441))) true)))))
(let (($x193 (or $x137 false false)))
(and (not $x193) (or $x193 (and (distinct ?x33 ?x33) true))))))))))))
(check-sat)
; query 20: function gsm_asl, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x93 (and (distinct (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvsgt (_ bv4294967281 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x1899 (or false false false)))
(let (($x1936 (not $x1899)))
(and $x1936 (or $x1899 $x93))))))
(check-sat)
; query 21: function gsm_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x364 (and (distinct (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv15 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x1899 (or false false false)))
(let (($x1936 (not $x1899)))
(and $x1936 (or $x1899 $x364))))))
(check-sat)
; query 22: function gsm_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x364 (and (distinct (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv15 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x1899 (or false false false)))
(let (($x1936 (not $x1899)))
(and $x1936 (or $x1899 $x364))))))
(check-sat)
; query 23: function gsm_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_64 () (_ BitVec 64))
(assert
 (let ((?x35 (ite (bvslt (_ bv32767 64) in5_64) (_ bv1 1) (_ bv0 1))))
(let (($x1899 (or false false false)))
(let (($x1936 (not $x1899)))
(and $x1936 (or $x1899 (and (distinct ?x35 ?x35) true)))))))
(check-sat)
; query 24: function gsm_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x25 (or false false)))
(let (($x19 (not $x25)))
(and $x19 (or $x25 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 25: function gsm_sub, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x25 (or false false)))
(let (($x19 (not $x25)))
(and $x19 (or $x25 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 26: function gsm_sub, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x441 ((_ sign_extend 48) in1_16)))
(let ((?x262 ((_ sign_extend 48) in0_16)))
(let ((?x53 (bvsub ?x262 ?x441)))
(let (($x74 (and (distinct (bvsub ((_ sign_extend 1) ?x262) ((_ sign_extend 1) ?x441)) ((_ sign_extend 1) ?x53)) true)))
(let (($x25 (or false false)))
(let (($x15 (or $x25 $x25 (or $x74))))
(and (not $x15) (or $x15 (and (distinct ?x53 ?x53) true))))))))))
(check-sat)
; query 27: function gsm_sub, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x81 (ite (bvsgt (_ bv18446744073709518848 64) (bvsub ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x441 ((_ sign_extend 48) in1_16)))
(let ((?x167 ((_ sign_extend 1) ?x441)))
(let ((?x262 ((_ sign_extend 48) in0_16)))
(let ((?x77 ((_ sign_extend 1) ?x262)))
(let (($x25 (or false false)))
(let (($x15 (or $x25 $x25 (or (and (distinct (bvsub ?x77 ?x167) ((_ sign_extend 1) (bvsub ?x262 ?x441))) true)))))
(let (($x135 (or $x15 false false)))
(and (not $x135) (or $x135 (and (distinct ?x81 ?x81) true))))))))))))
(check-sat)
; query 28: function ulaw_input, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x232 (and (distinct (bvadd ((_ zero_extend 1) in.02_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x434 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x234 (or (or false false (or $x434 $x232)) (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))
(and (not (or false false (or $x434))) $x234)))))
(check-sat)
; query 29: function ulaw_input, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let ((?x21 (ite (= (_ bv4294967295 32) in.1_32) (_ bv1 1) (_ bv0 1))))
(let (($x1899 (or false false false)))
(let (($x1936 (not $x1899)))
(and $x1936 (or $x1899 (and (distinct ?x21 ?x21) true)))))))
(check-sat)
