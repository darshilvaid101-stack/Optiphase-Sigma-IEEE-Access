; OptiPhase-Sigma refinement certificate for sweep K59-R3-170
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x763 (or false false)))
(let (($x308 (not $x763)))
(and $x308 (or $x763 (and (distinct ((_ sign_extend 16) in25_16) ((_ sign_extend 16) in25_16)) true))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let ((?x364 (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))))
(let (($x763 (or false false)))
(let (($x435 (or $x763 false false)))
(let (($x60 (not $x435)))
(and $x60 (or $x435 (and (distinct ?x364 ?x364) true))))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x763 (or false false)))
(let (($x308 (not $x763)))
(and $x308 (or $x763 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x774 ((_ sign_extend 16) in3_16)))
(let ((?x429 (bvand ?x774 (_ bv127 32))))
(let (($x763 (or false false)))
(let (($x435 (or $x763 false false)))
(let (($x60 (not $x435)))
(and $x60 (or $x435 (and (distinct ?x429 ?x429) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x774 ((_ sign_extend 16) in3_16)))
(let ((?x429 (bvand ?x774 (_ bv127 32))))
(let ((?x926 ((_ extract 15 0) ?x429)))
(let (($x763 (or false false)))
(let (($x435 (or $x763 false false)))
(let (($x531 (or $x435 false)))
(and (not $x531) (or $x531 (and (distinct ?x926 ?x926) true))))))))))
(check-sat)
; query 5: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x763 (or false false)))
(let (($x308 (not $x763)))
(and $x308 (or $x763 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 6: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x353 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x763 (or false false)))
(let (($x435 (or $x763 false false)))
(let (($x60 (not $x435)))
(and $x60 (or $x435 (and (distinct ?x353 ?x353) true))))))))
(check-sat)
; query 7: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x396 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x515 (or false false false)))
(let (($x480 (not $x515)))
(and $x480 (or $x515 (and (distinct ?x396 ?x396) true)))))))
(check-sat)
; query 8: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x515 (or false false false)))
(let (($x480 (not $x515)))
(and $x480 (or $x515 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 9: function core_state_transition, block 102, name %103
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x763 (or false false)))
(let (($x308 (not $x763)))
(and $x308 (or $x763 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 10: function core_state_transition, block 102, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x15 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x763 (or false false)))
(let (($x435 (or $x763 false false)))
(let (($x60 (not $x435)))
(and $x60 (or $x435 (and (distinct ?x15 ?x15) true))))))))
(check-sat)
; query 11: function core_state_transition, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x763 (or false false)))
(let (($x308 (not $x763)))
(and $x308 (or $x763 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 12: function core_state_transition, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x56 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x763 (or false false)))
(let (($x435 (or $x763 false false)))
(let (($x60 (not $x435)))
(and $x60 (or $x435 (and (distinct ?x56 ?x56) true))))))))
(check-sat)
; query 13: function core_state_transition, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x763 (or false false)))
(let (($x308 (not $x763)))
(and $x308 (or $x763 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 14: function core_state_transition, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x15 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x763 (or false false)))
(let (($x435 (or $x763 false false)))
(let (($x60 (not $x435)))
(and $x60 (or $x435 (and (distinct ?x15 ?x15) true))))))))
(check-sat)
; query 15: function core_state_transition, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x763 (or false false)))
(let (($x308 (not $x763)))
(and $x308 (or $x763 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 16: function core_state_transition, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x274 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x763 (or false false)))
(let (($x435 (or $x763 false false)))
(let (($x60 (not $x435)))
(and $x60 (or $x435 (and (distinct ?x274 ?x274) true))))))))
(check-sat)
; query 17: function core_state_transition, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x763 (or false false)))
(let (($x308 (not $x763)))
(and $x308 (or $x763 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 18: function core_state_transition, block 51, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x274 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x763 (or false false)))
(let (($x435 (or $x763 false false)))
(let (($x60 (not $x435)))
(and $x60 (or $x435 (and (distinct ?x274 ?x274) true))))))))
(check-sat)
; query 19: function core_state_transition, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x763 (or false false)))
(let (($x308 (not $x763)))
(and $x308 (or $x763 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 20: function core_state_transition, block 64, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x274 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x763 (or false false)))
(let (($x435 (or $x763 false false)))
(let (($x60 (not $x435)))
(and $x60 (or $x435 (and (distinct ?x274 ?x274) true))))))))
(check-sat)
; query 21: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x283 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x515 (or false false false)))
(let (($x480 (not $x515)))
(and $x480 (or $x515 (and (distinct ?x283 ?x283) true)))))))
(check-sat)
; query 22: function core_state_transition, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x763 (or false false)))
(let (($x308 (not $x763)))
(and $x308 (or $x763 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 23: function core_state_transition, block 80, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x500 (ite (= (_ bv69 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x763 (or false false)))
(let (($x435 (or $x763 false false)))
(let (($x60 (not $x435)))
(and $x60 (or $x435 (and (distinct ?x500 ?x500) true))))))))
(check-sat)
; query 24: function core_state_transition, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x763 (or false false)))
(let (($x308 (not $x763)))
(and $x308 (or $x763 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 25: function core_state_transition, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x122 (ite (= (_ bv101 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x763 (or false false)))
(let (($x435 (or $x763 false false)))
(let (($x60 (not $x435)))
(and $x60 (or $x435 (and (distinct ?x122 ?x122) true))))))))
(check-sat)
; query 26: function core_state_transition, block 99, name %100
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x763 (or false false)))
(let (($x308 (not $x763)))
(and $x308 (or $x763 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 27: function core_state_transition, block 99, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x56 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x763 (or false false)))
(let (($x435 (or $x763 false false)))
(let (($x60 (not $x435)))
(and $x60 (or $x435 (and (distinct ?x56 ?x56) true))))))))
(check-sat)
; query 28: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x36 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x515 (or false false false)))
(let (($x480 (not $x515)))
(and $x480 (or $x515 (and (distinct ?x36 ?x36) true)))))))
(check-sat)
