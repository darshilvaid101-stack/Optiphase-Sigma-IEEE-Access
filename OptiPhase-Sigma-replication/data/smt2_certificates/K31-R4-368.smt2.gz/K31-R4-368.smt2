; OptiPhase-Sigma refinement certificate for sweep K31-R4-368
