; OptiPhase-Sigma refinement certificate for sweep K59-R2-031
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x343 (or false false)))
(let (($x197 (not $x343)))
(and $x197 (or $x343 (and (distinct ((_ sign_extend 16) in25_16) ((_ sign_extend 16) in25_16)) true))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let ((?x109 (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))))
(let (($x343 (or false false)))
(let (($x295 (or $x343 false false)))
(let (($x346 (not $x295)))
(and $x346 (or $x295 (and (distinct ?x109 ?x109) true))))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x343 (or false false)))
(let (($x197 (not $x343)))
(and $x197 (or $x343 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x28 ((_ sign_extend 16) in3_16)))
(let ((?x88 (bvand ?x28 (_ bv127 32))))
(let (($x343 (or false false)))
(let (($x295 (or $x343 false false)))
(let (($x346 (not $x295)))
(and $x346 (or $x295 (and (distinct ?x88 ?x88) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x28 ((_ sign_extend 16) in3_16)))
(let ((?x88 (bvand ?x28 (_ bv127 32))))
(let ((?x20 ((_ extract 15 0) ?x88)))
(let (($x343 (or false false)))
(let (($x295 (or $x343 false false)))
(let (($x1117 (or $x295 false)))
(let (($x116 (not $x1117)))
(and $x116 (or $x1117 (and (distinct ?x20 ?x20) true)))))))))))
(check-sat)
; query 5: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x343 (or false false)))
(let (($x197 (not $x343)))
(and $x197 (or $x343 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 6: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x113 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x343 (or false false)))
(let (($x295 (or $x343 false false)))
(let (($x346 (not $x295)))
(and $x346 (or $x295 (and (distinct ?x113 ?x113) true))))))))
(check-sat)
; query 7: function core_bench_list, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x2873 (or false false false)))
(let (($x921 (not $x2873)))
(and $x921 (or $x2873 (and (distinct (bvadd in.0_16 (_ bv1 16)) (bvadd in.0_16 (_ bv1 16))) true))))))
(check-sat)
; query 8: function core_bench_list, block 82, name %83
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let (($x343 (or false false)))
(let (($x197 (not $x343)))
(and $x197 (or $x343 (and (distinct ((_ zero_extend 16) in.02_16) ((_ zero_extend 16) in.02_16)) true))))))
(check-sat)
; query 9: function core_bench_list, block 82, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x434 ((_ zero_extend 16) in.02_16)))
(let ((?x366 (bvmul ?x434 (_ bv4 32))))
(let (($x1583 (and (distinct (bvmul ((_ sign_extend 32) ?x434) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x366)) true)))
(let (($x343 (or false false)))
(let (($x470 (or $x343 false (or $x1583))))
(and (not $x470) (or $x470 (and (distinct ?x366 ?x366) true)))))))))
(check-sat)
; query 10: function core_bench_list, block 82, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let (($x343 (or false false)))
(let (($x197 (not $x343)))
(and $x197 (or $x343 (and (distinct ((_ zero_extend 16) in.04_16) ((_ zero_extend 16) in.04_16)) true))))))
(check-sat)
; query 11: function core_bench_list, block 82, name %86
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x259 ((_ zero_extend 16) in.04_16)))
(let ((?x434 ((_ zero_extend 16) in.02_16)))
(let ((?x366 (bvmul ?x434 (_ bv4 32))))
(let ((?x2870 (bvsub ?x366 ?x259)))
(let ((?x1703 ((_ sign_extend 1) ?x2870)))
(let (($x343 (or false false)))
(let (($x1583 (and (distinct (bvmul ((_ sign_extend 32) ?x434) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x366)) true)))
(let (($x470 (or $x343 false (or $x1583))))
(let (($x1374 (or $x470 $x343 (or (and (distinct (bvsub ((_ sign_extend 1) ?x366) ((_ sign_extend 1) ?x259)) ?x1703) true)))))
(and (not $x1374) (or $x1374 (and (distinct ?x2870 ?x2870) true)))))))))))))
(check-sat)
; query 12: function core_bench_list, block 82, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x343 (or false false)))
(let (($x197 (not $x343)))
(and $x197 (or $x343 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 13: function core_bench_list, block 82, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x259 ((_ zero_extend 16) in.04_16)))
(let ((?x434 ((_ zero_extend 16) in.02_16)))
(let ((?x366 (bvmul ?x434 (_ bv4 32))))
(let ((?x2870 (bvsub ?x366 ?x259)))
(let ((?x83 ((_ zero_extend 16) in.01_16)))
(let ((?x12 (bvadd ?x83 ?x2870)))
(let (($x786 (and (distinct (bvadd ((_ sign_extend 1) ?x83) ((_ sign_extend 1) ?x2870)) ((_ sign_extend 1) ?x12)) true)))
(let ((?x1703 ((_ sign_extend 1) ?x2870)))
(let (($x343 (or false false)))
(let (($x1583 (and (distinct (bvmul ((_ sign_extend 32) ?x434) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x366)) true)))
(let (($x470 (or $x343 false (or $x1583))))
(let (($x1374 (or $x470 $x343 (or (and (distinct (bvsub ((_ sign_extend 1) ?x366) ((_ sign_extend 1) ?x259)) ?x1703) true)))))
(let (($x21 (or $x343 $x1374 (or $x786))))
(and (not $x21) (or $x21 (and (distinct ?x12 ?x12) true)))))))))))))))))
(check-sat)
; query 14: function core_bench_list, block 82, name %89
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x259 ((_ zero_extend 16) in.04_16)))
(let ((?x434 ((_ zero_extend 16) in.02_16)))
(let ((?x366 (bvmul ?x434 (_ bv4 32))))
(let ((?x2870 (bvsub ?x366 ?x259)))
(let ((?x83 ((_ zero_extend 16) in.01_16)))
(let ((?x12 (bvadd ?x83 ?x2870)))
(let ((?x66 ((_ extract 15 0) ?x12)))
(let (($x786 (and (distinct (bvadd ((_ sign_extend 1) ?x83) ((_ sign_extend 1) ?x2870)) ((_ sign_extend 1) ?x12)) true)))
(let ((?x1703 ((_ sign_extend 1) ?x2870)))
(let (($x343 (or false false)))
(let (($x1583 (and (distinct (bvmul ((_ sign_extend 32) ?x434) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x366)) true)))
(let (($x470 (or $x343 false (or $x1583))))
(let (($x1374 (or $x470 $x343 (or (and (distinct (bvsub ((_ sign_extend 1) ?x366) ((_ sign_extend 1) ?x259)) ?x1703) true)))))
(let (($x21 (or $x343 $x1374 (or $x786))))
(let (($x652 (or $x21 false)))
(and (not $x652) (or $x652 (and (distinct ?x66 ?x66) true)))))))))))))))))))
(check-sat)
; query 15: function core_bench_list, block 82, name %90
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x343 (or false false)))
(let (($x197 (not $x343)))
(and $x197 (or $x343 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 16: function core_bench_list, block 82, name %91
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x256 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x343 (or false false)))
(let (($x295 (or $x343 false false)))
(let (($x346 (not $x295)))
(and $x346 (or $x295 (and (distinct ?x256 ?x256) true))))))))
(check-sat)
; query 17: function core_bench_state, block 105, name %106
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x2873 (or false false false)))
(let (($x921 (not $x2873)))
(and $x921 (or $x2873 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 18: function core_bench_state, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x2873 (or false false false)))
(let (($x921 (not $x2873)))
(and $x921 (or $x2873 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 19: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x103 (bvadd in.01_32 (_ bv1 32))))
(let (($x1538 (and (distinct ?x103 ?x103) true)))
(let (($x2873 (or false false false)))
(let (($x921 (not $x2873)))
(and $x921 (or $x2873 $x1538)))))))
(check-sat)
; query 20: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x103 (bvadd in.01_32 (_ bv1 32))))
(let ((?x837 (bvmul ?x103 ?x103)))
(let (($x2873 (or false false false)))
(let (($x995 (or $x2873 $x2873 false)))
(and (not $x995) (or $x995 (and (distinct ?x837 ?x837) true))))))))
(check-sat)
; query 21: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x103 (bvadd in.01_32 (_ bv1 32))))
(let ((?x837 (bvmul ?x103 ?x103)))
(let ((?x168 (bvmul ?x837 (_ bv2 32))))
(let (($x2873 (or false false false)))
(let (($x995 (or $x2873 $x2873 false)))
(let (($x3727 (or $x995 false false)))
(and (not $x3727) (or $x3727 (and (distinct ?x168 ?x168) true))))))))))
(check-sat)
; query 22: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x103 (bvadd in.01_32 (_ bv1 32))))
(let ((?x837 (bvmul ?x103 ?x103)))
(let ((?x168 (bvmul ?x837 (_ bv2 32))))
(let ((?x664 (bvmul ?x168 (_ bv4 32))))
(let (($x2873 (or false false false)))
(let (($x995 (or $x2873 $x2873 false)))
(let (($x3727 (or $x995 false false)))
(let (($x222 (or $x3727 false false)))
(and (not $x222) (or $x222 (and (distinct ?x664 ?x664) true))))))))))))
(check-sat)
; query 23: function core_init_matrix, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x2873 (or false false false)))
(let (($x921 (not $x2873)))
(and $x921 (or $x2873 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 24: function core_init_matrix, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x2873 (or false false false)))
(let (($x921 (not $x2873)))
(and $x921 (or $x2873 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 25: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x5517 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x2873 (or false false false)))
(let (($x921 (not $x2873)))
(and $x921 (or $x2873 (and (distinct ?x5517 ?x5517) true)))))))
(check-sat)
; query 26: function core_init_state, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_32 () (_ BitVec 32))
(assert
 (let (($x2873 (or false false false)))
(let (($x921 (not $x2873)))
(and $x921 (or $x2873 (and (distinct (bvadd in.06_32 (_ bv1 32)) (bvadd in.06_32 (_ bv1 32))) true))))))
(check-sat)
; query 27: function core_init_state, block 65, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let (($x2873 (or false false false)))
(let (($x921 (not $x2873)))
(and $x921 (or $x2873 (and (distinct (bvadd in4_32 (_ bv1 32)) (bvadd in4_32 (_ bv1 32))) true))))))
(check-sat)
; query 28: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x4845 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x2873 (or false false false)))
(let (($x921 (not $x2873)))
(and $x921 (or $x2873 (and (distinct ?x4845 ?x4845) true)))))))
(check-sat)
; query 29: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x2873 (or false false false)))
(let (($x921 (not $x2873)))
(and $x921 (or $x2873 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 30: function core_list_init, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x103 (bvadd in.01_32 (_ bv1 32))))
(let (($x1538 (and (distinct ?x103 ?x103) true)))
(let (($x2873 (or false false false)))
(let (($x921 (not $x2873)))
(and $x921 (or $x2873 $x1538)))))))
(check-sat)
; query 31: function core_list_mergesort, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x103 (bvadd in.01_32 (_ bv1 32))))
(let (($x1538 (and (distinct ?x103 ?x103) true)))
(let (($x8182 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x103)) true)))
(let (($x3834 (or false false (or $x8182))))
(and (not $x3834) (or $x3834 $x1538)))))))
(check-sat)
; query 32: function core_list_mergesort, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x755 (ite (bvslt (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x2873 (or false false false)))
(let (($x921 (not $x2873)))
(and $x921 (or $x2873 (and (distinct ?x755 ?x755) true)))))))
(check-sat)
; query 33: function core_list_mergesort, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.224_32 () (_ BitVec 32))
(assert
 (let ((?x8169 (ite (= (_ bv0 32) in.224_32) (_ bv1 1) (_ bv0 1))))
(let (($x2873 (or false false false)))
(let (($x921 (not $x2873)))
(and $x921 (or $x2873 (and (distinct ?x8169 ?x8169) true)))))))
(check-sat)
; query 34: function core_list_mergesort, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x456 (ite (= (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x2873 (or false false false)))
(let (($x921 (not $x2873)))
(and $x921 (or $x2873 (and (distinct ?x456 ?x456) true)))))))
(check-sat)
; query 35: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x8155 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x2917 (or false false (or $x8155))))
(and (not $x2917) (or $x2917 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 36: function core_list_mergesort, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x8145 (and (distinct (bvmul ((_ sign_extend 32) in.020_32) ((_ sign_extend 32) (_ bv2 32))) ((_ sign_extend 32) (bvmul in.020_32 (_ bv2 32)))) true)))
(let (($x8139 (or false false (or $x8145))))
(and (not $x8139) (or $x8139 (and (distinct (bvmul in.020_32 (_ bv2 32)) (bvmul in.020_32 (_ bv2 32))) true))))))
(check-sat)
; query 37: function core_state_transition, block 102, name %103
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x343 (or false false)))
(let (($x197 (not $x343)))
(and $x197 (or $x343 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 38: function core_state_transition, block 102, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x8152 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x343 (or false false)))
(let (($x295 (or $x343 false false)))
(let (($x346 (not $x295)))
(and $x346 (or $x295 (and (distinct ?x8152 ?x8152) true))))))))
(check-sat)
; query 39: function core_state_transition, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x343 (or false false)))
(let (($x197 (not $x343)))
(and $x197 (or $x343 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 40: function core_state_transition, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x316 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x343 (or false false)))
(let (($x295 (or $x343 false false)))
(let (($x346 (not $x295)))
(and $x346 (or $x295 (and (distinct ?x316 ?x316) true))))))))
(check-sat)
; query 41: function core_state_transition, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x343 (or false false)))
(let (($x197 (not $x343)))
(and $x197 (or $x343 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 42: function core_state_transition, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x8152 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x343 (or false false)))
(let (($x295 (or $x343 false false)))
(let (($x346 (not $x295)))
(and $x346 (or $x295 (and (distinct ?x8152 ?x8152) true))))))))
(check-sat)
; query 43: function core_state_transition, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x343 (or false false)))
(let (($x197 (not $x343)))
(and $x197 (or $x343 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 44: function core_state_transition, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x8135 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x343 (or false false)))
(let (($x295 (or $x343 false false)))
(let (($x346 (not $x295)))
(and $x346 (or $x295 (and (distinct ?x8135 ?x8135) true))))))))
(check-sat)
; query 45: function core_state_transition, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x343 (or false false)))
(let (($x197 (not $x343)))
(and $x197 (or $x343 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 46: function core_state_transition, block 51, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x8135 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x343 (or false false)))
(let (($x295 (or $x343 false false)))
(let (($x346 (not $x295)))
(and $x346 (or $x295 (and (distinct ?x8135 ?x8135) true))))))))
(check-sat)
; query 47: function core_state_transition, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x343 (or false false)))
(let (($x197 (not $x343)))
(and $x197 (or $x343 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 48: function core_state_transition, block 64, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x8135 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x343 (or false false)))
(let (($x295 (or $x343 false false)))
(let (($x346 (not $x295)))
(and $x346 (or $x295 (and (distinct ?x8135 ?x8135) true))))))))
(check-sat)
; query 49: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x4159 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x2873 (or false false false)))
(let (($x921 (not $x2873)))
(and $x921 (or $x2873 (and (distinct ?x4159 ?x4159) true)))))))
(check-sat)
; query 50: function core_state_transition, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x343 (or false false)))
(let (($x197 (not $x343)))
(and $x197 (or $x343 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 51: function core_state_transition, block 80, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x8157 (ite (= (_ bv69 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x343 (or false false)))
(let (($x295 (or $x343 false false)))
(let (($x346 (not $x295)))
(and $x346 (or $x295 (and (distinct ?x8157 ?x8157) true))))))))
(check-sat)
; query 52: function core_state_transition, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x343 (or false false)))
(let (($x197 (not $x343)))
(and $x197 (or $x343 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 53: function core_state_transition, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x3659 (ite (= (_ bv101 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x343 (or false false)))
(let (($x295 (or $x343 false false)))
(let (($x346 (not $x295)))
(and $x346 (or $x295 (and (distinct ?x3659 ?x3659) true))))))))
(check-sat)
; query 54: function core_state_transition, block 99, name %100
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x343 (or false false)))
(let (($x197 (not $x343)))
(and $x197 (or $x343 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 55: function core_state_transition, block 99, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x316 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x343 (or false false)))
(let (($x295 (or $x343 false false)))
(let (($x346 (not $x295)))
(and $x346 (or $x295 (and (distinct ?x316 ?x316) true))))))))
(check-sat)
; query 56: function crcu8, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x343 (or false false)))
(let (($x197 (not $x343)))
(and $x197 (or $x343 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 57: function crcu8, block 19, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x83 ((_ zero_extend 16) in.01_16)))
(let ((?x8119 (bvxor ?x83 (_ bv16386 32))))
(let (($x343 (or false false)))
(let (($x295 (or $x343 false false)))
(let (($x346 (not $x295)))
(and $x346 (or $x295 (and (distinct ?x8119 ?x8119) true)))))))))
(check-sat)
; query 58: function crcu8, block 19, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x83 ((_ zero_extend 16) in.01_16)))
(let ((?x8119 (bvxor ?x83 (_ bv16386 32))))
(let ((?x8159 ((_ extract 15 0) ?x8119)))
(let (($x343 (or false false)))
(let (($x295 (or $x343 false false)))
(let (($x1117 (or $x295 false)))
(let (($x116 (not $x1117)))
(and $x116 (or $x1117 (and (distinct ?x8159 ?x8159) true)))))))))))
(check-sat)
; query 59: function crcu8, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x343 (or false false)))
(let (($x197 (not $x343)))
(and $x197 (or $x343 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 60: function crcu8, block 29, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x382 ((_ zero_extend 16) in27_16)))
(let ((?x1197 (bvor ?x382 (_ bv32768 32))))
(let (($x343 (or false false)))
(let (($x295 (or $x343 false false)))
(let (($x346 (not $x295)))
(and $x346 (or $x295 (and (distinct ?x1197 ?x1197) true)))))))))
(check-sat)
; query 61: function crcu8, block 29, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x382 ((_ zero_extend 16) in27_16)))
(let ((?x1197 (bvor ?x382 (_ bv32768 32))))
(let ((?x4933 ((_ extract 15 0) ?x1197)))
(let (($x343 (or false false)))
(let (($x295 (or $x343 false false)))
(let (($x1117 (or $x295 false)))
(let (($x116 (not $x1117)))
(and $x116 (or $x1117 (and (distinct ?x4933 ?x4933) true)))))))))))
(check-sat)
; query 62: function crcu8, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x343 (or false false)))
(let (($x197 (not $x343)))
(and $x197 (or $x343 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 63: function crcu8, block 33, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x382 ((_ zero_extend 16) in27_16)))
(let ((?x399 (bvand ?x382 (_ bv32767 32))))
(let (($x343 (or false false)))
(let (($x295 (or $x343 false false)))
(let (($x346 (not $x295)))
(and $x346 (or $x295 (and (distinct ?x399 ?x399) true)))))))))
(check-sat)
; query 64: function crcu8, block 33, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x382 ((_ zero_extend 16) in27_16)))
(let ((?x399 (bvand ?x382 (_ bv32767 32))))
(let ((?x961 ((_ extract 15 0) ?x399)))
(let (($x343 (or false false)))
(let (($x295 (or $x343 false false)))
(let (($x1117 (or $x295 false)))
(let (($x116 (not $x1117)))
(and $x116 (or $x1117 (and (distinct ?x961 ?x961) true)))))))))))
(check-sat)
; query 65: function crcu8, block 38, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_8 () (_ BitVec 8))
(assert
 (let (($x2873 (or false false false)))
(let (($x921 (not $x2873)))
(and $x921 (or $x2873 (and (distinct (bvadd in.02_8 (_ bv1 8)) (bvadd in.02_8 (_ bv1 8))) true))))))
(check-sat)
; query 66: function crcu8, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x5137 ((_ extract 7 0) in.01_16)))
(let ((?x4029 ((_ zero_extend 24) ?x5137)))
(let (($x343 (or false false)))
(let (($x3728 (or $x343 false)))
(and (not $x3728) (or $x3728 (and (distinct ?x4029 ?x4029) true))))))))
(check-sat)
; query 67: function crcu8, block 6, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x5137 ((_ extract 7 0) in.01_16)))
(let ((?x4029 ((_ zero_extend 24) ?x5137)))
(let ((?x4580 (bvand ?x4029 (_ bv1 32))))
(let (($x343 (or false false)))
(let (($x3728 (or $x343 false)))
(let (($x3588 (or $x3728 false false)))
(and (not $x3588) (or $x3588 (and (distinct ?x4580 ?x4580) true))))))))))
(check-sat)
; query 68: function crcu8, block 6, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x5137 ((_ extract 7 0) in.01_16)))
(let ((?x4029 ((_ zero_extend 24) ?x5137)))
(let ((?x4580 (bvand ?x4029 (_ bv1 32))))
(let ((?x3615 ((_ zero_extend 24) in.0_8)))
(let ((?x4310 (bvand ?x3615 (_ bv1 32))))
(let ((?x8115 (bvxor ?x4310 ?x4580)))
(let (($x343 (or false false)))
(let (($x3728 (or $x343 false)))
(let (($x3588 (or $x3728 false false)))
(let (($x295 (or $x343 false false)))
(let (($x740 (or $x295 $x3588 false)))
(and (not $x740) (or $x740 (and (distinct ?x8115 ?x8115) true)))))))))))))))
(check-sat)
; query 69: function crcu8, block 6, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x5137 ((_ extract 7 0) in.01_16)))
(let ((?x4029 ((_ zero_extend 24) ?x5137)))
(let ((?x4580 (bvand ?x4029 (_ bv1 32))))
(let ((?x3615 ((_ zero_extend 24) in.0_8)))
(let ((?x4310 (bvand ?x3615 (_ bv1 32))))
(let ((?x8115 (bvxor ?x4310 ?x4580)))
(let ((?x8116 ((_ extract 7 0) ?x8115)))
(let (($x343 (or false false)))
(let (($x3728 (or $x343 false)))
(let (($x3588 (or $x3728 false false)))
(let (($x295 (or $x343 false false)))
(let (($x740 (or $x295 $x3588 false)))
(let (($x4650 (or $x740 false)))
(and (not $x4650) (or $x4650 (and (distinct ?x8116 ?x8116) true)))))))))))))))))
(check-sat)
; query 70: function crcu8, block 6, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x343 (or false false)))
(let (($x197 (not $x343)))
(and $x197 (or $x343 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 71: function crcu8, block 6, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x3615 ((_ zero_extend 24) in.0_8)))
(let ((?x8114 (bvashr ?x3615 (_ bv1 32))))
(let (($x343 (or false false)))
(let (($x295 (or $x343 false false)))
(let (($x8113 (or $x295 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not $x8113) (or $x8113 (and (distinct ?x8114 ?x8114) true)))))))))
(check-sat)
; query 72: function crcu8, block 6, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x3615 ((_ zero_extend 24) in.0_8)))
(let ((?x8114 (bvashr ?x3615 (_ bv1 32))))
(let ((?x5171 ((_ extract 7 0) ?x8114)))
(let (($x343 (or false false)))
(let (($x295 (or $x343 false false)))
(let (($x8113 (or $x295 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x4305 (or $x8113 false)))
(and (not $x4305) (or $x4305 (and (distinct ?x5171 ?x5171) true)))))))))))
(check-sat)
; query 73: function crcu8, block 6, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x5137 ((_ extract 7 0) in.01_16)))
(let ((?x4029 ((_ zero_extend 24) ?x5137)))
(let ((?x4580 (bvand ?x4029 (_ bv1 32))))
(let ((?x3615 ((_ zero_extend 24) in.0_8)))
(let ((?x4310 (bvand ?x3615 (_ bv1 32))))
(let ((?x8115 (bvxor ?x4310 ?x4580)))
(let ((?x8116 ((_ extract 7 0) ?x8115)))
(let ((?x4711 ((_ zero_extend 24) ?x8116)))
(let (($x343 (or false false)))
(let (($x3728 (or $x343 false)))
(let (($x3588 (or $x3728 false false)))
(let (($x295 (or $x343 false false)))
(let (($x740 (or $x295 $x3588 false)))
(let (($x4650 (or $x740 false)))
(let (($x8112 (or $x4650 false)))
(and (not $x8112) (or $x8112 (and (distinct ?x4711 ?x4711) true)))))))))))))))))))
(check-sat)
; query 74: function crcu8, block 6, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x5137 ((_ extract 7 0) in.01_16)))
(let ((?x4029 ((_ zero_extend 24) ?x5137)))
(let ((?x4580 (bvand ?x4029 (_ bv1 32))))
(let ((?x3615 ((_ zero_extend 24) in.0_8)))
(let ((?x4310 (bvand ?x3615 (_ bv1 32))))
(let ((?x8115 (bvxor ?x4310 ?x4580)))
(let ((?x8116 ((_ extract 7 0) ?x8115)))
(let ((?x4711 ((_ zero_extend 24) ?x8116)))
(let ((?x5289 (ite (= (_ bv1 32) ?x4711) (_ bv1 1) (_ bv0 1))))
(let (($x343 (or false false)))
(let (($x3728 (or $x343 false)))
(let (($x3588 (or $x3728 false false)))
(let (($x295 (or $x343 false false)))
(let (($x740 (or $x295 $x3588 false)))
(let (($x4650 (or $x740 false)))
(let (($x8112 (or $x4650 false)))
(let (($x8163 (or $x8112 false false)))
(and (not $x8163) (or $x8163 (and (distinct ?x5289 ?x5289) true)))))))))))))))))))))
(check-sat)
; query 75: function crcu8, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x343 (or false false)))
(let (($x197 (not $x343)))
(and $x197 (or $x343 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 76: function crcu8, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x3615 ((_ zero_extend 24) in.0_8)))
(let ((?x4310 (bvand ?x3615 (_ bv1 32))))
(let (($x343 (or false false)))
(let (($x295 (or $x343 false false)))
(let (($x346 (not $x295)))
(and $x346 (or $x295 (and (distinct ?x4310 ?x4310) true)))))))))
(check-sat)
; query 77: function crcu8, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x343 (or false false)))
(let (($x197 (not $x343)))
(and $x197 (or $x343 (and (distinct ((_ extract 7 0) in.01_16) ((_ extract 7 0) in.01_16)) true))))))
(check-sat)
; query 78: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x3839 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x3322 ((_ zero_extend 31) ?x3839)))
(let ((?x8166 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1327 ((_ zero_extend 31) ?x8166)))
(let ((?x8104 (bvand ?x1327 ?x3322)))
(let ((?x8103 (ite (and (distinct (_ bv0 32) ?x8104) true) (_ bv1 1) (_ bv0 1))))
(let ((?x8108 ((_ zero_extend 63) ?x8103)))
(let (($x343 (or false false)))
(let (($x295 (or $x343 false false)))
(let (($x1117 (or $x295 false)))
(let (($x3492 (or $x1117 $x1117 false)))
(let (($x8102 (or $x3492 false false)))
(let (($x3868 (or $x8102 false)))
(and (not $x3868) (or $x3868 (and (distinct ?x8108 ?x8108) true)))))))))))))))))
(check-sat)
; query 79: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x3839 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x3322 ((_ zero_extend 31) ?x3839)))
(let ((?x8166 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1327 ((_ zero_extend 31) ?x8166)))
(let ((?x8104 (bvand ?x1327 ?x3322)))
(let ((?x8103 (ite (and (distinct (_ bv0 32) ?x8104) true) (_ bv1 1) (_ bv0 1))))
(let (($x4686 (= (_ bv1 1) ?x8103)))
(let ((?x5604 (ite $x4686 (_ bv1 32) (_ bv0 32))))
(let (($x343 (or false false)))
(let (($x295 (or $x343 false false)))
(let (($x1117 (or $x295 false)))
(let (($x3492 (or $x1117 $x1117 false)))
(let (($x8102 (or $x3492 false false)))
(let (($x8100 (or $x8102 (ite $x4686 false false))))
(and (not $x8100) (or $x8100 (and (distinct ?x5604 ?x5604) true))))))))))))))))))
(check-sat)
; query 80: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x3839 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x3322 ((_ zero_extend 31) ?x3839)))
(let ((?x8166 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1327 ((_ zero_extend 31) ?x8166)))
(let ((?x8104 (bvand ?x1327 ?x3322)))
(let ((?x8103 (ite (and (distinct (_ bv0 32) ?x8104) true) (_ bv1 1) (_ bv0 1))))
(let (($x4686 (= (_ bv1 1) ?x8103)))
(let ((?x5604 (ite $x4686 (_ bv1 32) (_ bv0 32))))
(let ((?x7270 ((_ extract 7 0) ?x5604)))
(let (($x343 (or false false)))
(let (($x295 (or $x343 false false)))
(let (($x1117 (or $x295 false)))
(let (($x3492 (or $x1117 $x1117 false)))
(let (($x8102 (or $x3492 false false)))
(let (($x8100 (or $x8102 (ite $x4686 false false))))
(let (($x8165 (or $x8100 false)))
(and (not $x8165) (or $x8165 (and (distinct ?x7270 ?x7270) true))))))))))))))))))))
(check-sat)
; query 81: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x343 (or false false)))
(let (($x197 (not $x343)))
(and $x197 (or $x343 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 82: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x8166 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x343 (or false false)))
(let (($x295 (or $x343 false false)))
(let (($x346 (not $x295)))
(and $x346 (or $x295 (and (distinct ?x8166 ?x8166) true))))))))
(check-sat)
; query 83: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x8166 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1327 ((_ zero_extend 31) ?x8166)))
(let (($x343 (or false false)))
(let (($x295 (or $x343 false false)))
(let (($x1117 (or $x295 false)))
(let (($x116 (not $x1117)))
(and $x116 (or $x1117 (and (distinct ?x1327 ?x1327) true))))))))))
(check-sat)
; query 84: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x343 (or false false)))
(let (($x197 (not $x343)))
(and $x197 (or $x343 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 85: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x3839 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x343 (or false false)))
(let (($x295 (or $x343 false false)))
(let (($x346 (not $x295)))
(and $x346 (or $x295 (and (distinct ?x3839 ?x3839) true))))))))
(check-sat)
; query 86: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x3839 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x3322 ((_ zero_extend 31) ?x3839)))
(let (($x343 (or false false)))
(let (($x295 (or $x343 false false)))
(let (($x1117 (or $x295 false)))
(let (($x116 (not $x1117)))
(and $x116 (or $x1117 (and (distinct ?x3322 ?x3322) true))))))))))
(check-sat)
; query 87: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x3839 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x3322 ((_ zero_extend 31) ?x3839)))
(let ((?x8166 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1327 ((_ zero_extend 31) ?x8166)))
(let ((?x8104 (bvand ?x1327 ?x3322)))
(let (($x343 (or false false)))
(let (($x295 (or $x343 false false)))
(let (($x1117 (or $x295 false)))
(let (($x3492 (or $x1117 $x1117 false)))
(and (not $x3492) (or $x3492 (and (distinct ?x8104 ?x8104) true)))))))))))))
(check-sat)
; query 88: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x3839 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x3322 ((_ zero_extend 31) ?x3839)))
(let ((?x8166 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1327 ((_ zero_extend 31) ?x8166)))
(let ((?x8104 (bvand ?x1327 ?x3322)))
(let ((?x8103 (ite (and (distinct (_ bv0 32) ?x8104) true) (_ bv1 1) (_ bv0 1))))
(let (($x343 (or false false)))
(let (($x295 (or $x343 false false)))
(let (($x1117 (or $x295 false)))
(let (($x3492 (or $x1117 $x1117 false)))
(let (($x8102 (or $x3492 false false)))
(and (not $x8102) (or $x8102 (and (distinct ?x8103 ?x8103) true)))))))))))))))
(check-sat)
; query 89: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1290 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x2873 (or false false false)))
(let (($x921 (not $x2873)))
(and $x921 (or $x2873 (and (distinct ?x1290 ?x1290) true)))))))
(check-sat)
; query 90: function matrix_add_const, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x2873 (or false false false)))
(let (($x921 (not $x2873)))
(and $x921 (or $x2873 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 91: function matrix_add_const, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x103 (bvadd in.01_32 (_ bv1 32))))
(let (($x1538 (and (distinct ?x103 ?x103) true)))
(let (($x2873 (or false false false)))
(let (($x921 (not $x2873)))
(and $x921 (or $x2873 $x1538)))))))
(check-sat)
; query 92: function matrix_mul_const, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x2873 (or false false false)))
(let (($x921 (not $x2873)))
(and $x921 (or $x2873 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 93: function matrix_mul_const, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x103 (bvadd in.01_32 (_ bv1 32))))
(let (($x1538 (and (distinct ?x103 ?x103) true)))
(let (($x2873 (or false false false)))
(let (($x921 (not $x2873)))
(and $x921 (or $x2873 $x1538)))))))
(check-sat)
; query 94: function matrix_mul_matrix, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x2873 (or false false false)))
(let (($x921 (not $x2873)))
(and $x921 (or $x2873 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 95: function matrix_mul_matrix, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x103 (bvadd in.01_32 (_ bv1 32))))
(let (($x1538 (and (distinct ?x103 ?x103) true)))
(let (($x2873 (or false false false)))
(let (($x921 (not $x2873)))
(and $x921 (or $x2873 $x1538)))))))
(check-sat)
; query 96: function matrix_mul_matrix, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x2873 (or false false false)))
(let (($x921 (not $x2873)))
(and $x921 (or $x2873 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 97: function matrix_mul_matrix_bitextract, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x2873 (or false false false)))
(let (($x921 (not $x2873)))
(and $x921 (or $x2873 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 98: function matrix_mul_matrix_bitextract, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x103 (bvadd in.01_32 (_ bv1 32))))
(let (($x1538 (and (distinct ?x103 ?x103) true)))
(let (($x2873 (or false false false)))
(let (($x921 (not $x2873)))
(and $x921 (or $x2873 $x1538)))))))
(check-sat)
; query 99: function matrix_mul_matrix_bitextract, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x2873 (or false false false)))
(let (($x921 (not $x2873)))
(and $x921 (or $x2873 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 100: function matrix_mul_vect, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x2873 (or false false false)))
(let (($x921 (not $x2873)))
(and $x921 (or $x2873 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 101: function matrix_mul_vect, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x103 (bvadd in.01_32 (_ bv1 32))))
(let (($x1538 (and (distinct ?x103 ?x103) true)))
(let (($x2873 (or false false false)))
(let (($x921 (not $x2873)))
(and $x921 (or $x2873 $x1538)))))))
(check-sat)
; query 102: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x343 (or false false)))
(let (($x197 (not $x343)))
(and $x197 (or $x343 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 103: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x125 ((_ sign_extend 16) in.1_16)))
(let ((?x8096 (bvadd ?x125 (_ bv10 32))))
(let (($x5216 (and (distinct (bvadd ((_ sign_extend 1) ?x125) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x8096)) true)))
(let (($x343 (or false false)))
(let (($x4990 (or $x343 false (or $x5216))))
(and (not $x4990) (or $x4990 (and (distinct ?x8096 ?x8096) true)))))))))
(check-sat)
; query 104: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x125 ((_ sign_extend 16) in.1_16)))
(let ((?x8096 (bvadd ?x125 (_ bv10 32))))
(let ((?x825 ((_ extract 15 0) ?x8096)))
(let (($x5216 (and (distinct (bvadd ((_ sign_extend 1) ?x125) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x8096)) true)))
(let (($x343 (or false false)))
(let (($x4990 (or $x343 false (or $x5216))))
(let (($x3523 (or $x4990 false)))
(and (not $x3523) (or $x3523 (and (distinct ?x825 ?x825) true)))))))))))
(check-sat)
; query 105: function matrix_sum, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x763 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x2873 (or false false false)))
(let (($x921 (not $x2873)))
(and $x921 (or $x2873 (and (distinct ?x763 ?x763) true)))))))
(check-sat)
; query 106: function matrix_sum, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x763 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let ((?x2269 ((_ zero_extend 63) ?x763)))
(let (($x2873 (or false false false)))
(let (($x5725 (or $x2873 false)))
(and (not $x5725) (or $x5725 (and (distinct ?x2269 ?x2269) true))))))))
(check-sat)
; query 107: function matrix_sum, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x763 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x2186 (= (_ bv1 1) ?x763)))
(let ((?x3585 (ite $x2186 (_ bv1 32) (_ bv0 32))))
(let (($x2873 (or false false false)))
(let (($x1260 (or $x2873 (ite $x2186 false false))))
(and (not $x1260) (or $x1260 (and (distinct ?x3585 ?x3585) true)))))))))
(check-sat)
; query 108: function matrix_sum, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x343 (or false false)))
(let (($x197 (not $x343)))
(and $x197 (or $x343 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 109: function matrix_sum, block 22, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x763 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x2186 (= (_ bv1 1) ?x763)))
(let ((?x3585 (ite $x2186 (_ bv1 32) (_ bv0 32))))
(let ((?x125 ((_ sign_extend 16) in.1_16)))
(let ((?x5646 (bvadd ?x125 ?x3585)))
(let (($x8084 (and (distinct (bvadd ((_ sign_extend 1) ?x125) ((_ sign_extend 1) ?x3585)) ((_ sign_extend 1) ?x5646)) true)))
(let (($x2873 (or false false false)))
(let (($x1260 (or $x2873 (ite $x2186 false false))))
(let (($x343 (or false false)))
(let (($x2743 (or $x343 $x1260 (or $x8084))))
(and (not $x2743) (or $x2743 (and (distinct ?x5646 ?x5646) true))))))))))))))
(check-sat)
; query 110: function matrix_sum, block 22, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x763 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x2186 (= (_ bv1 1) ?x763)))
(let ((?x3585 (ite $x2186 (_ bv1 32) (_ bv0 32))))
(let ((?x125 ((_ sign_extend 16) in.1_16)))
(let ((?x5646 (bvadd ?x125 ?x3585)))
(let ((?x8083 ((_ extract 15 0) ?x5646)))
(let (($x8084 (and (distinct (bvadd ((_ sign_extend 1) ?x125) ((_ sign_extend 1) ?x3585)) ((_ sign_extend 1) ?x5646)) true)))
(let (($x2873 (or false false false)))
(let (($x1260 (or $x2873 (ite $x2186 false false))))
(let (($x343 (or false false)))
(let (($x2743 (or $x343 $x1260 (or $x8084))))
(let (($x8088 (or $x2743 false)))
(and (not $x8088) (or $x8088 (and (distinct ?x8083 ?x8083) true))))))))))))))))
(check-sat)
; query 111: function matrix_sum, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x2873 (or false false false)))
(let (($x921 (not $x2873)))
(and $x921 (or $x2873 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 112: function matrix_sum, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x103 (bvadd in.01_32 (_ bv1 32))))
(let (($x1538 (and (distinct ?x103 ?x103) true)))
(let (($x2873 (or false false false)))
(let (($x921 (not $x2873)))
(and $x921 (or $x2873 $x1538)))))))
(check-sat)
; query 113: function parseval, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.23_32 () (_ BitVec 32))
(assert
 (let (($x3672 (and (distinct (bvmul ((_ sign_extend 32) in.23_32) ((_ sign_extend 32) (_ bv1024 32))) ((_ sign_extend 32) (bvmul in.23_32 (_ bv1024 32)))) true)))
(let (($x7149 (or false false (or $x3672))))
(and (not $x7149) (or $x7149 (and (distinct (bvmul in.23_32 (_ bv1024 32)) (bvmul in.23_32 (_ bv1024 32))) true))))))
(check-sat)
; query 114: function parseval, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.34_32 () (_ BitVec 32))
(assert
 (let (($x4074 (and (distinct (bvmul ((_ sign_extend 32) in.34_32) ((_ sign_extend 32) (_ bv1048576 32))) ((_ sign_extend 32) (bvmul in.34_32 (_ bv1048576 32)))) true)))
(let (($x2812 (or false false (or $x4074))))
(and (not $x2812) (or $x2812 (and (distinct (bvmul in.34_32 (_ bv1048576 32)) (bvmul in.34_32 (_ bv1048576 32))) true))))))
(check-sat)
; query 115: function partition_memory, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x2873 (or false false false)))
(let (($x921 (not $x2873)))
(and $x921 (or $x2873 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 116: function run_matrix_multiply, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x2873 (or false false false)))
(let (($x921 (not $x2873)))
(and $x921 (or $x2873 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 117: function run_matrix_multiply, block 34, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x103 (bvadd in.01_32 (_ bv1 32))))
(let (($x1538 (and (distinct ?x103 ?x103) true)))
(let (($x2873 (or false false false)))
(let (($x921 (not $x2873)))
(and $x921 (or $x2873 $x1538)))))))
(check-sat)
