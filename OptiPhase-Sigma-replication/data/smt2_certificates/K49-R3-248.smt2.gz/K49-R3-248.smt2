; OptiPhase-Sigma refinement certificate for sweep K49-R3-248
; query 0: function APCM_inverse_quantization, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x200 (or false false)))
(let (($x96 (not $x200)))
(and $x96 (or $x200 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 1: function APCM_inverse_quantization, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x86 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x200 (or false false)))
(let (($x165 (or $x200 false false)))
(let (($x123 (not $x165)))
(and $x123 (or $x165 (and (distinct ?x86 ?x86) true))))))))
(check-sat)
; query 2: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x200 (or false false)))
(let (($x96 (not $x200)))
(and $x96 (or $x200 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 3: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x22 (ite (bvslt (_ bv15 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x200 (or false false)))
(let (($x165 (or $x200 false false)))
(let (($x123 (not $x165)))
(and $x123 (or $x165 (and (distinct ?x22 ?x22) true))))))))
(check-sat)
; query 4: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x200 (or false false)))
(let (($x96 (not $x200)))
(and $x96 (or $x200 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 5: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x60 (ite (bvsgt (_ bv40 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x200 (or false false)))
(let (($x165 (or $x200 false false)))
(let (($x123 (not $x165)))
(and $x123 (or $x165 (and (distinct ?x60 ?x60) true))))))))
(check-sat)
; query 6: function RPE_grid_positioning, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x200 (or false false)))
(let (($x96 (not $x200)))
(and $x96 (or $x200 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 7: function RPE_grid_positioning, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x23 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x141 (and (distinct ?x23 ?x23) true)))
(let (($x200 (or false false)))
(let (($x91 (or false $x200 false)))
(and (not $x91) (or $x91 $x141)))))))
(check-sat)
; query 8: function gsm_L_add, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x95 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x410 (or false false false)))
(let (($x149 (not $x410)))
(and $x149 (or $x410 (and (distinct ?x95 ?x95) true)))))))
(check-sat)
; query 9: function gsm_L_add, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x73 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvadd in0_64 in1_64))) true)))
(let (($x59 (or false false (or $x73))))
(let (($x159 (or $x59 (and (distinct (bvadd in0_64 in1_64) (bvadd in0_64 in1_64)) true))))
(and (not $x59) $x159)))))
(check-sat)
; query 10: function gsm_L_add, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x46 (bvadd in0_64 (_ bv1 64))))
(let ((?x90 (bvsub (_ bv0 64) ?x46)))
(let (($x704 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x46)) ((_ sign_extend 1) ?x90)) true)))
(let ((?x65 ((_ sign_extend 1) ?x46)))
(let (($x160 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x65) true)))))
(let (($x20 (or false $x160 (or $x704))))
(and (not $x20) (or $x20 (and (distinct ?x90 ?x90) true))))))))))
(check-sat)
; query 11: function gsm_L_add, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x75 (bvadd in1_64 (_ bv1 64))))
(let ((?x28 ((_ sign_extend 1) ?x75)))
(let (($x18 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x28) true)))))
(and (not $x18) (or $x18 (and (distinct ?x75 ?x75) true)))))))
(check-sat)
; query 12: function gsm_L_add, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x75 (bvadd in1_64 (_ bv1 64))))
(let ((?x197 (bvsub (_ bv0 64) ?x75)))
(let (($x82 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x75)) ((_ sign_extend 1) ?x197)) true)))
(let ((?x28 ((_ sign_extend 1) ?x75)))
(let (($x18 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x28) true)))))
(let (($x591 (or false $x18 (or $x82))))
(and (not $x591) (or $x591 (and (distinct ?x197 ?x197) true))))))))))
(check-sat)
; query 13: function gsm_L_add, block 8, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x75 (bvadd in1_64 (_ bv1 64))))
(let ((?x197 (bvsub (_ bv0 64) ?x75)))
(let ((?x46 (bvadd in0_64 (_ bv1 64))))
(let ((?x90 (bvsub (_ bv0 64) ?x46)))
(let ((?x25 (bvadd ?x90 ?x197)))
(let (($x82 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x75)) ((_ sign_extend 1) ?x197)) true)))
(let ((?x28 ((_ sign_extend 1) ?x75)))
(let (($x18 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x28) true)))))
(let (($x591 (or false $x18 (or $x82))))
(let (($x704 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x46)) ((_ sign_extend 1) ?x90)) true)))
(let ((?x65 ((_ sign_extend 1) ?x46)))
(let (($x160 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x65) true)))))
(let (($x20 (or false $x160 (or $x704))))
(let (($x56 (or $x20 $x591 false)))
(and (not $x56) (or $x56 (and (distinct ?x25 ?x25) true))))))))))))))))))
(check-sat)
; query 14: function gsm_L_add, block 8, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x75 (bvadd in1_64 (_ bv1 64))))
(let ((?x197 (bvsub (_ bv0 64) ?x75)))
(let ((?x46 (bvadd in0_64 (_ bv1 64))))
(let ((?x90 (bvsub (_ bv0 64) ?x46)))
(let ((?x25 (bvadd ?x90 ?x197)))
(let ((?x50 (ite (bvuge ?x25 (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x82 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x75)) ((_ sign_extend 1) ?x197)) true)))
(let ((?x28 ((_ sign_extend 1) ?x75)))
(let (($x18 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x28) true)))))
(let (($x591 (or false $x18 (or $x82))))
(let (($x704 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x46)) ((_ sign_extend 1) ?x90)) true)))
(let ((?x65 ((_ sign_extend 1) ?x46)))
(let (($x160 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x65) true)))))
(let (($x20 (or false $x160 (or $x704))))
(let (($x56 (or $x20 $x591 false)))
(let (($x33 (or $x56 false false)))
(and (not $x33) (or $x33 (and (distinct ?x50 ?x50) true))))))))))))))))))))
(check-sat)
; query 15: function gsm_L_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x46 (bvadd in0_64 (_ bv1 64))))
(let ((?x65 ((_ sign_extend 1) ?x46)))
(let (($x160 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x65) true)))))
(and (not $x160) (or $x160 (and (distinct ?x46 ?x46) true)))))))
(check-sat)
; query 16: function gsm_L_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x233 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x410 (or false false false)))
(let (($x149 (not $x410)))
(and $x149 (or $x410 (and (distinct ?x233 ?x233) true)))))))
(check-sat)
; query 17: function gsm_L_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1084 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x410 (or false false false)))
(let (($x149 (not $x410)))
(and $x149 (or $x410 (and (distinct ?x1084 ?x1084) true)))))))
(check-sat)
; query 18: function gsm_L_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x233 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x410 (or false false false)))
(let (($x149 (not $x410)))
(and $x149 (or $x410 (and (distinct ?x233 ?x233) true)))))))
(check-sat)
; query 19: function gsm_L_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x233 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x94 ((_ zero_extend 31) ?x233)))
(let (($x410 (or false false false)))
(let (($x293 (or $x410 false)))
(and (not $x293) (or $x293 (and (distinct ?x94 ?x94) true))))))))
(check-sat)
; query 20: function gsm_L_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x233 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x94 ((_ zero_extend 31) ?x233)))
(let ((?x12 (bvsub (_ bv0 32) ?x94)))
(let (($x190 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x94)) ((_ sign_extend 1) ?x12)) true)))
(let (($x410 (or false false false)))
(let (($x293 (or $x410 false)))
(let (($x108 (or false $x293 (or $x190))))
(and (not $x108) (or $x108 (and (distinct ?x12 ?x12) true)))))))))))
(check-sat)
; query 21: function gsm_L_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x233 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x94 ((_ zero_extend 31) ?x233)))
(let ((?x12 (bvsub (_ bv0 32) ?x94)))
(let ((?x155 ((_ sign_extend 32) ?x12)))
(let (($x190 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x94)) ((_ sign_extend 1) ?x12)) true)))
(let (($x410 (or false false false)))
(let (($x293 (or $x410 false)))
(let (($x108 (or false $x293 (or $x190))))
(let (($x93 (or $x108 false)))
(and (not $x93) (or $x93 (and (distinct ?x155 ?x155) true)))))))))))))
(check-sat)
; query 22: function gsm_L_asr, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x39 (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x410 (or false false false)))
(let (($x149 (not $x410)))
(and $x149 (or $x410 (and (distinct ?x39 ?x39) true)))))))
(check-sat)
; query 23: function gsm_L_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1084 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x410 (or false false false)))
(let (($x149 (not $x410)))
(and $x149 (or $x410 (and (distinct ?x1084 ?x1084) true)))))))
(check-sat)
; query 24: function gsm_L_sub, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x95 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x410 (or false false false)))
(let (($x149 (not $x410)))
(and $x149 (or $x410 (and (distinct ?x95 ?x95) true)))))))
(check-sat)
; query 25: function gsm_L_sub, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x173 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvsub in0_64 in1_64))) true)))
(let (($x6 (or false false (or $x173))))
(let (($x597 (or $x6 (and (distinct (bvsub in0_64 in1_64) (bvsub in0_64 in1_64)) true))))
(and (not $x6) $x597)))))
(check-sat)
; query 26: function gsm_L_sub, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x75 (bvadd in1_64 (_ bv1 64))))
(let ((?x197 (bvsub (_ bv0 64) ?x75)))
(let (($x82 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x75)) ((_ sign_extend 1) ?x197)) true)))
(let ((?x28 ((_ sign_extend 1) ?x75)))
(let (($x18 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x28) true)))))
(let (($x591 (or false $x18 (or $x82))))
(and (not $x591) (or $x591 (and (distinct ?x197 ?x197) true))))))))))
(check-sat)
; query 27: function gsm_L_sub, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x75 (bvadd in1_64 (_ bv1 64))))
(let ((?x197 (bvsub (_ bv0 64) ?x75)))
(let ((?x493 (bvadd in0_64 ?x197)))
(let (($x82 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x75)) ((_ sign_extend 1) ?x197)) true)))
(let ((?x28 ((_ sign_extend 1) ?x75)))
(let (($x18 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x28) true)))))
(let (($x591 (or false $x18 (or $x82))))
(let (($x189 (or false $x591 false)))
(and (not $x189) (or $x189 (and (distinct ?x493 ?x493) true))))))))))))
(check-sat)
; query 28: function gsm_L_sub, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x66 (ite (bvuge (bvadd in0_64 (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64)))) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x82 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) (bvadd in1_64 (_ bv1 64)))) ((_ sign_extend 1) (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64))))) true)))
(let ((?x75 (bvadd in1_64 (_ bv1 64))))
(let ((?x28 ((_ sign_extend 1) ?x75)))
(let (($x18 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x28) true)))))
(let (($x591 (or false $x18 (or $x82))))
(let (($x189 (or false $x591 false)))
(let (($x114 (or $x189 false false)))
(and (not $x114) (or $x114 (and (distinct ?x66 ?x66) true))))))))))))
(check-sat)
; query 29: function gsm_L_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x75 (bvadd in1_64 (_ bv1 64))))
(let ((?x28 ((_ sign_extend 1) ?x75)))
(let (($x18 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x28) true)))))
(and (not $x18) (or $x18 (and (distinct ?x75 ?x75) true)))))))
(check-sat)
; query 30: function gsm_L_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x157 (ite (bvsle (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x410 (or false false false)))
(let (($x149 (not $x410)))
(and $x149 (or $x410 (and (distinct ?x157 ?x157) true)))))))
(check-sat)
; query 31: function gsm_abs, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x200 (or false false)))
(let (($x96 (not $x200)))
(and $x96 (or $x200 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 32: function gsm_abs, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x876 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x200 (or false false)))
(let (($x165 (or $x200 false false)))
(let (($x123 (not $x165)))
(and $x123 (or $x165 (and (distinct ?x876 ?x876) true))))))))
(check-sat)
; query 33: function gsm_abs, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x200 (or false false)))
(let (($x96 (not $x200)))
(and $x96 (or $x200 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 34: function gsm_abs, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x84 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x200 (or false false)))
(let (($x165 (or $x200 false false)))
(let (($x123 (not $x165)))
(and $x123 (or $x165 (and (distinct ?x84 ?x84) true))))))))
(check-sat)
; query 35: function gsm_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x200 (or false false)))
(let (($x96 (not $x200)))
(and $x96 (or $x200 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 36: function gsm_add, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x200 (or false false)))
(let (($x96 (not $x200)))
(and $x96 (or $x200 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 37: function gsm_add, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x7 ((_ sign_extend 48) in1_16)))
(let ((?x181 ((_ sign_extend 48) in0_16)))
(let ((?x171 (bvadd ?x181 ?x7)))
(let (($x193 (and (distinct (bvadd ((_ sign_extend 1) ?x181) ((_ sign_extend 1) ?x7)) ((_ sign_extend 1) ?x171)) true)))
(let (($x200 (or false false)))
(let (($x235 (or $x200 $x200 (or $x193))))
(and (not $x235) (or $x235 (and (distinct ?x171 ?x171) true))))))))))
(check-sat)
; query 38: function gsm_add, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x619 (ite (bvsgt (_ bv18446744073709518848 64) (bvadd ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x7 ((_ sign_extend 48) in1_16)))
(let ((?x17 ((_ sign_extend 1) ?x7)))
(let ((?x181 ((_ sign_extend 48) in0_16)))
(let ((?x124 ((_ sign_extend 1) ?x181)))
(let (($x200 (or false false)))
(let (($x235 (or $x200 $x200 (or (and (distinct (bvadd ?x124 ?x17) ((_ sign_extend 1) (bvadd ?x181 ?x7))) true)))))
(let (($x194 (or $x235 false false)))
(and (not $x194) (or $x194 (and (distinct ?x619 ?x619) true))))))))))))
(check-sat)
; query 39: function gsm_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x680 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x410 (or false false false)))
(let (($x149 (not $x410)))
(and $x149 (or $x410 (and (distinct ?x680 ?x680) true)))))))
(check-sat)
; query 40: function gsm_asr, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x158 (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x410 (or false false false)))
(let (($x149 (not $x410)))
(and $x149 (or $x410 (and (distinct ?x158 ?x158) true)))))))
(check-sat)
; query 41: function gsm_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x200 (or false false)))
(let (($x96 (not $x200)))
(and $x96 (or $x200 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 42: function gsm_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x84 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x200 (or false false)))
(let (($x165 (or $x200 false false)))
(let (($x123 (not $x165)))
(and $x123 (or $x165 (and (distinct ?x84 ?x84) true))))))))
(check-sat)
; query 43: function gsm_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x84 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x454 ((_ zero_extend 31) ?x84)))
(let (($x200 (or false false)))
(let (($x165 (or $x200 false false)))
(let (($x254 (or $x165 false)))
(and (not $x254) (or $x254 (and (distinct ?x454 ?x454) true)))))))))
(check-sat)
; query 44: function gsm_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x84 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x454 ((_ zero_extend 31) ?x84)))
(let ((?x360 (bvsub (_ bv0 32) ?x454)))
(let (($x237 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x454)) ((_ sign_extend 1) ?x360)) true)))
(let (($x200 (or false false)))
(let (($x165 (or $x200 false false)))
(let (($x254 (or $x165 false)))
(let (($x76 (or false $x254 (or $x237))))
(and (not $x76) (or $x76 (and (distinct ?x360 ?x360) true))))))))))))
(check-sat)
; query 45: function gsm_asr, block 4, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x84 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x454 ((_ zero_extend 31) ?x84)))
(let ((?x360 (bvsub (_ bv0 32) ?x454)))
(let ((?x861 ((_ extract 15 0) ?x360)))
(let (($x237 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x454)) ((_ sign_extend 1) ?x360)) true)))
(let (($x200 (or false false)))
(let (($x165 (or $x200 false false)))
(let (($x254 (or $x165 false)))
(let (($x76 (or false $x254 (or $x237))))
(let (($x1051 (or $x76 false)))
(and (not $x1051) (or $x1051 (and (distinct ?x861 ?x861) true))))))))))))))
(check-sat)
; query 46: function gsm_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x680 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x410 (or false false false)))
(let (($x149 (not $x410)))
(and $x149 (or $x410 (and (distinct ?x680 ?x680) true)))))))
(check-sat)
; query 47: function gsm_debug_longwords, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in15_32 () (_ BitVec 32))
(assert
 (let ((?x385 (ite (bvslt in15_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x410 (or false false false)))
(let (($x149 (not $x410)))
(and $x149 (or $x410 (and (distinct ?x385 ?x385) true)))))))
(check-sat)
; query 48: function gsm_debug_words, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in16_32 () (_ BitVec 32))
(assert
 (let ((?x305 (ite (bvslt in16_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x410 (or false false false)))
(let (($x149 (not $x410)))
(and $x149 (or $x410 (and (distinct ?x305 ?x305) true)))))))
(check-sat)
; query 49: function gsm_div, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x200 (or false false)))
(let (($x96 (not $x200)))
(and $x96 (or $x200 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 50: function gsm_div, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x200 (or false false)))
(let (($x96 (not $x200)))
(and $x96 (or $x200 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 51: function gsm_div, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x200 (or false false)))
(let (($x96 (not $x200)))
(and $x96 (or $x200 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 52: function gsm_div, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x23 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x141 (and (distinct ?x23 ?x23) true)))
(let (($x200 (or false false)))
(let (($x165 (or $x200 false false)))
(let (($x123 (not $x165)))
(and $x123 (or $x165 $x141))))))))
(check-sat)
; query 53: function gsm_norm, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x233 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x410 (or false false false)))
(let (($x149 (not $x410)))
(and $x149 (or $x410 (and (distinct ?x233 (ite (bvsge (_ bv18446744072635809792 64) in0_64) (_ bv1 1) (_ bv0 1))) true)))))))
(check-sat)
; query 54: function gsm_norm, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x504 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x410 (or false false false)))
(let (($x149 (not $x410)))
(and $x149 (or $x410 (and (distinct ?x504 ?x504) true)))))))
(check-sat)
; query 55: function gsm_norm, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x504 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x365 (bvxor ?x504 (_ bv1 1))))
(let (($x410 (or false false false)))
(let (($x1008 (or $x410 false false)))
(and (not $x1008) (or $x1008 (and (distinct ?x365 ?x365) true))))))))
(check-sat)
; query 56: function gsm_norm, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x504 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x365 (bvxor ?x504 (_ bv1 1))))
(let ((?x482 ((_ zero_extend 31) ?x365)))
(let (($x410 (or false false false)))
(let (($x1008 (or $x410 false false)))
(let (($x548 (or $x1008 false)))
(and (not $x548) (or $x548 (and (distinct ?x482 ?x482) true))))))))))
(check-sat)
; query 57: function gsm_norm, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x504 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x365 (bvxor ?x504 (_ bv1 1))))
(let ((?x482 ((_ zero_extend 31) ?x365)))
(let ((?x554 ((_ sign_extend 32) ?x482)))
(let (($x410 (or false false false)))
(let (($x1008 (or $x410 false false)))
(let (($x548 (or $x1008 false)))
(let (($x622 (or $x548 false)))
(and (not $x622) (or $x622 (and (distinct ?x554 ?x554) true))))))))))))
(check-sat)
; query 58: function gsm_norm, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x504 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x365 (bvxor ?x504 (_ bv1 1))))
(let ((?x482 ((_ zero_extend 31) ?x365)))
(let ((?x554 ((_ sign_extend 32) ?x482)))
(let ((?x543 (ite (and (distinct (_ bv0 64) ?x554) true) (_ bv1 1) (_ bv0 1))))
(let (($x410 (or false false false)))
(let (($x1008 (or $x410 false false)))
(let (($x548 (or $x1008 false)))
(let (($x622 (or $x548 false)))
(let (($x832 (or $x622 false false)))
(and (not $x832) (or $x832 (and (distinct ?x543 ?x543) true))))))))))))))
(check-sat)
; query 59: function gsm_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x200 (or false false)))
(let (($x96 (not $x200)))
(and $x96 (or $x200 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 60: function gsm_sub, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x200 (or false false)))
(let (($x96 (not $x200)))
(and $x96 (or $x200 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 61: function gsm_sub, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x7 ((_ sign_extend 48) in1_16)))
(let ((?x181 ((_ sign_extend 48) in0_16)))
(let ((?x846 (bvsub ?x181 ?x7)))
(let (($x337 (and (distinct (bvsub ((_ sign_extend 1) ?x181) ((_ sign_extend 1) ?x7)) ((_ sign_extend 1) ?x846)) true)))
(let (($x200 (or false false)))
(let (($x423 (or $x200 $x200 (or $x337))))
(and (not $x423) (or $x423 (and (distinct ?x846 ?x846) true))))))))))
(check-sat)
; query 62: function gsm_sub, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x770 (ite (bvsgt (_ bv18446744073709518848 64) (bvsub ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x7 ((_ sign_extend 48) in1_16)))
(let ((?x17 ((_ sign_extend 1) ?x7)))
(let ((?x181 ((_ sign_extend 48) in0_16)))
(let ((?x124 ((_ sign_extend 1) ?x181)))
(let (($x200 (or false false)))
(let (($x423 (or $x200 $x200 (or (and (distinct (bvsub ?x124 ?x17) ((_ sign_extend 1) (bvsub ?x181 ?x7))) true)))))
(let (($x968 (or $x423 false false)))
(and (not $x968) (or $x968 (and (distinct ?x770 ?x770) true))))))))))))
(check-sat)
; query 63: function process_decode, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let (($x200 (or false false)))
(let (($x96 (not $x200)))
(and $x96 (or $x200 (and (distinct ((_ sign_extend 32) in14_32) ((_ sign_extend 32) in14_32)) true))))))
(check-sat)
; query 64: function process_decode, block 16, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x271 (ite (and (distinct (_ bv33 64) ((_ sign_extend 32) in14_32)) true) (_ bv1 1) (_ bv0 1))))
(let (($x200 (or false false)))
(let (($x165 (or $x200 false false)))
(let (($x123 (not $x165)))
(and $x123 (or $x165 (and (distinct ?x271 ?x271) true))))))))
(check-sat)
; query 65: function process_encode, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_32 () (_ BitVec 32))
(assert
 (let (($x200 (or false false)))
(let (($x96 (not $x200)))
(and $x96 (or $x200 (and (distinct ((_ sign_extend 32) in13_32) ((_ sign_extend 32) in13_32)) true))))))
(check-sat)
; query 66: function process_encode, block 15, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_32 () (_ BitVec 32))
(assert
 (let ((?x772 (ite (bvult ((_ sign_extend 32) in13_32) (_ bv160 64)) (_ bv1 1) (_ bv0 1))))
(let (($x200 (or false false)))
(let (($x165 (or $x200 false false)))
(let (($x123 (not $x165)))
(and $x123 (or $x165 (and (distinct ?x772 ?x772) true))))))))
(check-sat)
