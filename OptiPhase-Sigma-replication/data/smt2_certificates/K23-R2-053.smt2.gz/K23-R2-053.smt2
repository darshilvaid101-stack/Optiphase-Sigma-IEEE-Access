; OptiPhase-Sigma refinement certificate for sweep K23-R2-053
; query 0: function init_array, block 12, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x56 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x130 (or false false (or $x56))))
(and (not $x130) (or $x130 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function init_array, block 25, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x27 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x92 (or false false (or $x27))))
(and (not $x92) (or $x92 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function init_array, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x163 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x109 (or false false (or $x163))))
(and (not $x109) (or $x109 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 3: function kernel_nussinov, block 11, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x84 (and (distinct (bvsub ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvsub in.01_32 (_ bv1 32)))) true)))
(let (($x8 (or false false (or $x84))))
(and (not $x8) (or $x8 (and (distinct (bvsub in.01_32 (_ bv1 32)) (bvsub in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 4: function kernel_nussinov, block 11, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x115 (ite (bvsle (_ bv0 32) (bvsub in.01_32 (_ bv1 32))) (_ bv1 1) (_ bv0 1))))
(let (($x84 (and (distinct (bvsub ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvsub in.01_32 (_ bv1 32)))) true)))
(let (($x8 (or false false (or $x84))))
(let (($x151 (or $x8 false false)))
(and (not $x151) (or $x151 (and (distinct ?x115 ?x115) true))))))))
(check-sat)
; query 5: function kernel_nussinov, block 185, name %186
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x72 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x17 (or false false (or $x72))))
(and (not $x17) (or $x17 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 6: function kernel_nussinov, block 233, name %234
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x27 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x92 (or false false (or $x27))))
(and (not $x92) (or $x92 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 7: function kernel_nussinov, block 236, name %237
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x56 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x130 (or false false (or $x56))))
(and (not $x130) (or $x130 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function kernel_nussinov, block 239, name %240
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x54 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv4294967295 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv4294967295 32)))) true)))
(let (($x118 (or false false (or $x54))))
(and (not $x118) (or $x118 (and (distinct (bvadd in.02_32 (_ bv4294967295 32)) (bvadd in.02_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 9: function kernel_nussinov, block 46, name %47
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x72 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x17 (or false false (or $x72))))
(and (not $x17) (or $x17 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 10: function kernel_nussinov, block 46, name %48
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x22 (ite (bvslt (bvadd in.02_32 (_ bv1 32)) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x72 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x17 (or false false (or $x72))))
(let (($x148 (or $x17 false false)))
(and (not $x148) (or $x148 (and (distinct ?x22 ?x22) true))))))))
(check-sat)
; query 11: function kernel_nussinov, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x72 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x17 (or false false (or $x72))))
(and (not $x17) (or $x17 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 12: function kernel_nussinov, block 81, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x84 (and (distinct (bvsub ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvsub in.01_32 (_ bv1 32)))) true)))
(let (($x8 (or false false (or $x84))))
(and (not $x8) (or $x8 (and (distinct (bvsub in.01_32 (_ bv1 32)) (bvsub in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 13: function kernel_nussinov, block 81, name %83
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x115 (ite (bvsle (_ bv0 32) (bvsub in.01_32 (_ bv1 32))) (_ bv1 1) (_ bv0 1))))
(let (($x84 (and (distinct (bvsub ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvsub in.01_32 (_ bv1 32)))) true)))
(let (($x8 (or false false (or $x84))))
(let (($x151 (or $x8 false false)))
(and (not $x151) (or $x151 (and (distinct ?x115 ?x115) true))))))))
(check-sat)
; query 14: function kernel_nussinov, block 84, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x72 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x17 (or false false (or $x72))))
(and (not $x17) (or $x17 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 15: function kernel_nussinov, block 84, name %86
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x22 (ite (bvslt (bvadd in.02_32 (_ bv1 32)) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x72 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x17 (or false false (or $x72))))
(let (($x148 (or $x17 false false)))
(and (not $x148) (or $x148 (and (distinct ?x22 ?x22) true))))))))
(check-sat)
; query 16: function kernel_nussinov, block 87, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x84 (and (distinct (bvsub ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvsub in.01_32 (_ bv1 32)))) true)))
(let (($x8 (or false false (or $x84))))
(and (not $x8) (or $x8 (and (distinct (bvsub in.01_32 (_ bv1 32)) (bvsub in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 17: function kernel_nussinov, block 87, name %89
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x139 (ite (bvslt in.02_32 (bvsub in.01_32 (_ bv1 32))) (_ bv1 1) (_ bv0 1))))
(let (($x84 (and (distinct (bvsub ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvsub in.01_32 (_ bv1 32)))) true)))
(let (($x8 (or false false (or $x84))))
(let (($x98 (or false $x8 false)))
(and (not $x98) (or $x98 (and (distinct ?x139 ?x139) true))))))))
(check-sat)
; query 18: function kernel_nussinov, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x69 (and (distinct (bvsub ((_ sign_extend 1) in0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvsub in0_32 (_ bv1 32)))) true)))
(let (($x20 (or false false (or $x69))))
(and (not $x20) (or $x20 (and (distinct (bvsub in0_32 (_ bv1 32)) (bvsub in0_32 (_ bv1 32))) true))))))
(check-sat)
; query 19: function polybench_flush_cache, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x56 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x130 (or false false (or $x56))))
(and (not $x130) (or $x130 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 20: function print_array, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x56 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x130 (or false false (or $x56))))
(and (not $x130) (or $x130 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 21: function print_array, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x72 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x17 (or false false (or $x72))))
(and (not $x17) (or $x17 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 22: function xmalloc, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in7_32 () (_ BitVec 32))
(assert
 (let ((?x35 (ite (and (distinct (_ bv0 32) in7_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x129 (or false false false)))
(and (not $x129) (or $x129 (and (distinct ?x35 ?x35) true))))))
(check-sat)
