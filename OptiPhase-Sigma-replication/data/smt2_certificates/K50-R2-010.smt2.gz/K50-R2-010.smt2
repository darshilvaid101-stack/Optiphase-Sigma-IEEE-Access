; OptiPhase-Sigma refinement certificate for sweep K50-R2-010
; query 0: function check, block 142, name %143
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x451 (and (distinct (ite (= (_ bv123 32) in0_32) (_ bv1 1) (_ bv0 1)) (ite (= (_ bv1122 32) in0_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x423 (or false false false)))
(let (($x686 (not $x423)))
(and $x686 (or $x423 $x451))))))
(check-sat)
; query 1: function check, block 157, name %158
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x785 (and (distinct (ite (= (_ bv112233 32) in0_32) (_ bv1 1) (_ bv0 1)) (ite (= (_ bv111 32) in0_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x423 (or false false false)))
(let (($x686 (not $x423)))
(and $x686 (or $x423 $x785))))))
(check-sat)
; query 2: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x820 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x423 (or false false false)))
(let (($x686 (not $x423)))
(and $x686 (or $x423 (and (distinct ?x820 ?x820) true)))))))
(check-sat)
; query 3: function s115, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x222 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x523 (or false false (or $x222))))
(and (not $x523) (or $x523 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 4: function set1d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x279 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x423 (or false false false)))
(let (($x686 (not $x423)))
(and $x686 (or $x423 (and (distinct ?x279 ?x279) true)))))))
(check-sat)
; query 5: function set1ds, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x81 (ite (= (_ bv4294967295 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x423 (or false false false)))
(let (($x686 (not $x423)))
(and $x686 (or $x423 (and (distinct ?x81 ?x81) true)))))))
(check-sat)
; query 6: function set2d, block 21, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let (($x798 (and (distinct (bvadd ((_ sign_extend 1) in.04_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.04_32 (_ bv1 32)))) true)))
(let (($x128 (or false false (or $x798))))
(and (not $x128) (or $x128 (and (distinct (bvadd in.04_32 (_ bv1 32)) (bvadd in.04_32 (_ bv1 32))) true))))))
(check-sat)
; query 7: function set2d, block 24, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_32 () (_ BitVec 32))
(assert
 (let (($x86 (and (distinct (bvadd ((_ sign_extend 1) in.03_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.03_32 (_ bv1 32)))) true)))
(let (($x63 (or false false (or $x86))))
(and (not $x63) (or $x63 (and (distinct (bvadd in.03_32 (_ bv1 32)) (bvadd in.03_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function set2d, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x155 (ite (= (_ bv4294967294 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x423 (or false false false)))
(let (($x686 (not $x423)))
(and $x686 (or $x423 (and (distinct ?x155 ?x155) true)))))))
(check-sat)
; query 9: function set2d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x279 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x423 (or false false false)))
(let (($x686 (not $x423)))
(and $x686 (or $x423 (and (distinct ?x279 ?x279) true)))))))
(check-sat)
; query 10: function sum1d, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x226 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x180 (or false false (or $x226))))
(and (not $x180) (or $x180 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
