; OptiPhase-Sigma refinement certificate for sweep K17-R3-250
