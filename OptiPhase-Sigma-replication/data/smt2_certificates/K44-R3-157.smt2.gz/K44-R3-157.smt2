; OptiPhase-Sigma refinement certificate for sweep K44-R3-157
; query 0: function IsPowerOfTwo, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x126 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x7 (or false false false)))
(let (($x227 (not $x7)))
(and $x227 (or $x7 (and (distinct ?x126 ?x126) true)))))))
(check-sat)
; query 1: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x126 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x7 (or false false false)))
(let (($x227 (not $x7)))
(and $x227 (or $x7 (and (distinct ?x126 ?x126) true)))))))
(check-sat)
; query 2: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x124 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x7 (or false false false)))
(let (($x227 (not $x7)))
(and $x227 (or $x7 (and (distinct ?x124 ?x124) true)))))))
(check-sat)
