; OptiPhase-Sigma refinement certificate for sweep K55-R4-311
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x182 (or false false)))
(let (($x396 (not $x182)))
(and $x396 (or $x182 (and (distinct ((_ sign_extend 16) in25_16) ((_ sign_extend 16) in25_16)) true))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let ((?x293 (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))))
(let (($x182 (or false false)))
(let (($x394 (or $x182 false false)))
(let (($x623 (not $x394)))
(and $x623 (or $x394 (and (distinct ?x293 ?x293) true))))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x182 (or false false)))
(let (($x396 (not $x182)))
(and $x396 (or $x182 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x56 ((_ sign_extend 16) in3_16)))
(let ((?x20 (bvand ?x56 (_ bv127 32))))
(let (($x182 (or false false)))
(let (($x394 (or $x182 false false)))
(let (($x623 (not $x394)))
(and $x623 (or $x394 (and (distinct ?x20 ?x20) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x56 ((_ sign_extend 16) in3_16)))
(let ((?x20 (bvand ?x56 (_ bv127 32))))
(let ((?x7 ((_ extract 15 0) ?x20)))
(let (($x182 (or false false)))
(let (($x394 (or $x182 false false)))
(let (($x848 (or $x394 false)))
(let (($x66 (not $x848)))
(and $x66 (or $x848 (and (distinct ?x7 ?x7) true)))))))))))
(check-sat)
; query 5: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x182 (or false false)))
(let (($x396 (not $x182)))
(and $x396 (or $x182 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 6: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x896 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x182 (or false false)))
(let (($x394 (or $x182 false false)))
(let (($x623 (not $x394)))
(and $x623 (or $x394 (and (distinct ?x896 ?x896) true))))))))
(check-sat)
; query 7: function core_bench_list, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x499 (or false false false)))
(let (($x51 (not $x499)))
(and $x51 (or $x499 (and (distinct (bvadd in.0_16 (_ bv1 16)) (bvadd in.0_16 (_ bv1 16))) true))))))
(check-sat)
; query 8: function core_bench_list, block 82, name %83
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let (($x182 (or false false)))
(let (($x396 (not $x182)))
(and $x396 (or $x182 (and (distinct ((_ zero_extend 16) in.02_16) ((_ zero_extend 16) in.02_16)) true))))))
(check-sat)
; query 9: function core_bench_list, block 82, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x449 ((_ zero_extend 16) in.02_16)))
(let ((?x95 (bvmul ?x449 (_ bv4 32))))
(let (($x149 (and (distinct (bvmul ((_ sign_extend 32) ?x449) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x95)) true)))
(let (($x182 (or false false)))
(let (($x98 (or $x182 false (or $x149))))
(and (not $x98) (or $x98 (and (distinct ?x95 ?x95) true)))))))))
(check-sat)
; query 10: function core_bench_list, block 82, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let (($x182 (or false false)))
(let (($x396 (not $x182)))
(and $x396 (or $x182 (and (distinct ((_ zero_extend 16) in.04_16) ((_ zero_extend 16) in.04_16)) true))))))
(check-sat)
; query 11: function core_bench_list, block 82, name %86
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x533 ((_ zero_extend 16) in.04_16)))
(let ((?x449 ((_ zero_extend 16) in.02_16)))
(let ((?x95 (bvmul ?x449 (_ bv4 32))))
(let ((?x175 (bvsub ?x95 ?x533)))
(let ((?x26 ((_ sign_extend 1) ?x175)))
(let (($x182 (or false false)))
(let (($x149 (and (distinct (bvmul ((_ sign_extend 32) ?x449) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x95)) true)))
(let (($x98 (or $x182 false (or $x149))))
(let (($x253 (or $x98 $x182 (or (and (distinct (bvsub ((_ sign_extend 1) ?x95) ((_ sign_extend 1) ?x533)) ?x26) true)))))
(and (not $x253) (or $x253 (and (distinct ?x175 ?x175) true)))))))))))))
(check-sat)
; query 12: function core_bench_list, block 82, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x182 (or false false)))
(let (($x396 (not $x182)))
(and $x396 (or $x182 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 13: function core_bench_list, block 82, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x533 ((_ zero_extend 16) in.04_16)))
(let ((?x449 ((_ zero_extend 16) in.02_16)))
(let ((?x95 (bvmul ?x449 (_ bv4 32))))
(let ((?x175 (bvsub ?x95 ?x533)))
(let ((?x602 ((_ zero_extend 16) in.01_16)))
(let ((?x103 (bvadd ?x602 ?x175)))
(let (($x64 (and (distinct (bvadd ((_ sign_extend 1) ?x602) ((_ sign_extend 1) ?x175)) ((_ sign_extend 1) ?x103)) true)))
(let ((?x26 ((_ sign_extend 1) ?x175)))
(let (($x182 (or false false)))
(let (($x149 (and (distinct (bvmul ((_ sign_extend 32) ?x449) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x95)) true)))
(let (($x98 (or $x182 false (or $x149))))
(let (($x253 (or $x98 $x182 (or (and (distinct (bvsub ((_ sign_extend 1) ?x95) ((_ sign_extend 1) ?x533)) ?x26) true)))))
(let (($x130 (or $x182 $x253 (or $x64))))
(and (not $x130) (or $x130 (and (distinct ?x103 ?x103) true)))))))))))))))))
(check-sat)
; query 14: function core_bench_list, block 82, name %89
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x533 ((_ zero_extend 16) in.04_16)))
(let ((?x449 ((_ zero_extend 16) in.02_16)))
(let ((?x95 (bvmul ?x449 (_ bv4 32))))
(let ((?x175 (bvsub ?x95 ?x533)))
(let ((?x602 ((_ zero_extend 16) in.01_16)))
(let ((?x103 (bvadd ?x602 ?x175)))
(let ((?x1851 ((_ extract 15 0) ?x103)))
(let (($x64 (and (distinct (bvadd ((_ sign_extend 1) ?x602) ((_ sign_extend 1) ?x175)) ((_ sign_extend 1) ?x103)) true)))
(let ((?x26 ((_ sign_extend 1) ?x175)))
(let (($x182 (or false false)))
(let (($x149 (and (distinct (bvmul ((_ sign_extend 32) ?x449) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x95)) true)))
(let (($x98 (or $x182 false (or $x149))))
(let (($x253 (or $x98 $x182 (or (and (distinct (bvsub ((_ sign_extend 1) ?x95) ((_ sign_extend 1) ?x533)) ?x26) true)))))
(let (($x130 (or $x182 $x253 (or $x64))))
(let (($x41 (or $x130 false)))
(and (not $x41) (or $x41 (and (distinct ?x1851 ?x1851) true)))))))))))))))))))
(check-sat)
; query 15: function core_bench_list, block 82, name %90
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x182 (or false false)))
(let (($x396 (not $x182)))
(and $x396 (or $x182 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 16: function core_bench_list, block 82, name %91
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x172 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x182 (or false false)))
(let (($x394 (or $x182 false false)))
(let (($x623 (not $x394)))
(and $x623 (or $x394 (and (distinct ?x172 ?x172) true))))))))
(check-sat)
; query 17: function core_bench_state, block 105, name %106
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x499 (or false false false)))
(let (($x51 (not $x499)))
(and $x51 (or $x499 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 18: function core_bench_state, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x499 (or false false false)))
(let (($x51 (not $x499)))
(and $x51 (or $x499 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 19: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x36 (bvadd in.01_32 (_ bv1 32))))
(let (($x738 (and (distinct ?x36 ?x36) true)))
(let (($x499 (or false false false)))
(let (($x51 (not $x499)))
(and $x51 (or $x499 $x738)))))))
(check-sat)
; query 20: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x36 (bvadd in.01_32 (_ bv1 32))))
(let ((?x121 (bvmul ?x36 ?x36)))
(let (($x499 (or false false false)))
(let (($x527 (or $x499 $x499 false)))
(and (not $x527) (or $x527 (and (distinct ?x121 ?x121) true))))))))
(check-sat)
; query 21: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x36 (bvadd in.01_32 (_ bv1 32))))
(let ((?x121 (bvmul ?x36 ?x36)))
(let ((?x82 (bvmul ?x121 (_ bv2 32))))
(let (($x499 (or false false false)))
(let (($x527 (or $x499 $x499 false)))
(let (($x462 (or $x527 false false)))
(and (not $x462) (or $x462 (and (distinct ?x82 ?x82) true))))))))))
(check-sat)
; query 22: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x36 (bvadd in.01_32 (_ bv1 32))))
(let ((?x121 (bvmul ?x36 ?x36)))
(let ((?x82 (bvmul ?x121 (_ bv2 32))))
(let ((?x19 (bvmul ?x82 (_ bv4 32))))
(let (($x499 (or false false false)))
(let (($x527 (or $x499 $x499 false)))
(let (($x462 (or $x527 false false)))
(let (($x296 (or $x462 false false)))
(and (not $x296) (or $x296 (and (distinct ?x19 ?x19) true))))))))))))
(check-sat)
; query 23: function core_init_matrix, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x499 (or false false false)))
(let (($x51 (not $x499)))
(and $x51 (or $x499 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 24: function core_init_matrix, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x499 (or false false false)))
(let (($x51 (not $x499)))
(and $x51 (or $x499 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 25: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x615 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x499 (or false false false)))
(let (($x51 (not $x499)))
(and $x51 (or $x499 (and (distinct ?x615 ?x615) true)))))))
(check-sat)
; query 26: function core_init_state, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_32 () (_ BitVec 32))
(assert
 (let (($x499 (or false false false)))
(let (($x51 (not $x499)))
(and $x51 (or $x499 (and (distinct (bvadd in.06_32 (_ bv1 32)) (bvadd in.06_32 (_ bv1 32))) true))))))
(check-sat)
; query 27: function core_init_state, block 65, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let (($x499 (or false false false)))
(let (($x51 (not $x499)))
(and $x51 (or $x499 (and (distinct (bvadd in4_32 (_ bv1 32)) (bvadd in4_32 (_ bv1 32))) true))))))
(check-sat)
; query 28: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x1852 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x499 (or false false false)))
(let (($x51 (not $x499)))
(and $x51 (or $x499 (and (distinct ?x1852 ?x1852) true)))))))
(check-sat)
; query 29: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x499 (or false false false)))
(let (($x51 (not $x499)))
(and $x51 (or $x499 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 30: function core_list_init, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x36 (bvadd in.01_32 (_ bv1 32))))
(let (($x738 (and (distinct ?x36 ?x36) true)))
(let (($x499 (or false false false)))
(let (($x51 (not $x499)))
(and $x51 (or $x499 $x738)))))))
(check-sat)
; query 31: function core_list_mergesort, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x36 (bvadd in.01_32 (_ bv1 32))))
(let (($x738 (and (distinct ?x36 ?x36) true)))
(let (($x44 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x36)) true)))
(let (($x58 (or false false (or $x44))))
(and (not $x58) (or $x58 $x738)))))))
(check-sat)
; query 32: function core_list_mergesort, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x1750 (ite (bvslt (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x499 (or false false false)))
(let (($x51 (not $x499)))
(and $x51 (or $x499 (and (distinct ?x1750 ?x1750) true)))))))
(check-sat)
; query 33: function core_list_mergesort, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.224_32 () (_ BitVec 32))
(assert
 (let ((?x1594 (ite (= (_ bv0 32) in.224_32) (_ bv1 1) (_ bv0 1))))
(let (($x499 (or false false false)))
(let (($x51 (not $x499)))
(and $x51 (or $x499 (and (distinct ?x1594 ?x1594) true)))))))
(check-sat)
; query 34: function core_list_mergesort, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x250 (ite (= (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x499 (or false false false)))
(let (($x51 (not $x499)))
(and $x51 (or $x499 (and (distinct ?x250 ?x250) true)))))))
(check-sat)
; query 35: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x816 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x984 (or false false (or $x816))))
(and (not $x984) (or $x984 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 36: function core_list_mergesort, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x1128 (and (distinct (bvmul ((_ sign_extend 32) in.020_32) ((_ sign_extend 32) (_ bv2 32))) ((_ sign_extend 32) (bvmul in.020_32 (_ bv2 32)))) true)))
(let (($x1348 (or false false (or $x1128))))
(and (not $x1348) (or $x1348 (and (distinct (bvmul in.020_32 (_ bv2 32)) (bvmul in.020_32 (_ bv2 32))) true))))))
(check-sat)
; query 37: function core_state_transition, block 102, name %103
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x182 (or false false)))
(let (($x396 (not $x182)))
(and $x396 (or $x182 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 38: function core_state_transition, block 102, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x605 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x182 (or false false)))
(let (($x394 (or $x182 false false)))
(let (($x623 (not $x394)))
(and $x623 (or $x394 (and (distinct ?x605 ?x605) true))))))))
(check-sat)
; query 39: function core_state_transition, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x182 (or false false)))
(let (($x396 (not $x182)))
(and $x396 (or $x182 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 40: function core_state_transition, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x953 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x182 (or false false)))
(let (($x394 (or $x182 false false)))
(let (($x623 (not $x394)))
(and $x623 (or $x394 (and (distinct ?x953 ?x953) true))))))))
(check-sat)
; query 41: function core_state_transition, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x182 (or false false)))
(let (($x396 (not $x182)))
(and $x396 (or $x182 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 42: function core_state_transition, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x605 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x182 (or false false)))
(let (($x394 (or $x182 false false)))
(let (($x623 (not $x394)))
(and $x623 (or $x394 (and (distinct ?x605 ?x605) true))))))))
(check-sat)
; query 43: function core_state_transition, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x182 (or false false)))
(let (($x396 (not $x182)))
(and $x396 (or $x182 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 44: function core_state_transition, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x227 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x182 (or false false)))
(let (($x394 (or $x182 false false)))
(let (($x623 (not $x394)))
(and $x623 (or $x394 (and (distinct ?x227 ?x227) true))))))))
(check-sat)
; query 45: function core_state_transition, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x182 (or false false)))
(let (($x396 (not $x182)))
(and $x396 (or $x182 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 46: function core_state_transition, block 51, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x227 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x182 (or false false)))
(let (($x394 (or $x182 false false)))
(let (($x623 (not $x394)))
(and $x623 (or $x394 (and (distinct ?x227 ?x227) true))))))))
(check-sat)
; query 47: function core_state_transition, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x182 (or false false)))
(let (($x396 (not $x182)))
(and $x396 (or $x182 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 48: function core_state_transition, block 64, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x227 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x182 (or false false)))
(let (($x394 (or $x182 false false)))
(let (($x623 (not $x394)))
(and $x623 (or $x394 (and (distinct ?x227 ?x227) true))))))))
(check-sat)
; query 49: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x742 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x499 (or false false false)))
(let (($x51 (not $x499)))
(and $x51 (or $x499 (and (distinct ?x742 ?x742) true)))))))
(check-sat)
; query 50: function core_state_transition, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x182 (or false false)))
(let (($x396 (not $x182)))
(and $x396 (or $x182 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 51: function core_state_transition, block 80, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1887 (ite (= (_ bv69 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x182 (or false false)))
(let (($x394 (or $x182 false false)))
(let (($x623 (not $x394)))
(and $x623 (or $x394 (and (distinct ?x1887 ?x1887) true))))))))
(check-sat)
; query 52: function core_state_transition, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x182 (or false false)))
(let (($x396 (not $x182)))
(and $x396 (or $x182 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 53: function core_state_transition, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1757 (ite (= (_ bv101 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x182 (or false false)))
(let (($x394 (or $x182 false false)))
(let (($x623 (not $x394)))
(and $x623 (or $x394 (and (distinct ?x1757 ?x1757) true))))))))
(check-sat)
; query 54: function core_state_transition, block 99, name %100
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x182 (or false false)))
(let (($x396 (not $x182)))
(and $x396 (or $x182 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 55: function core_state_transition, block 99, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x953 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x182 (or false false)))
(let (($x394 (or $x182 false false)))
(let (($x623 (not $x394)))
(and $x623 (or $x394 (and (distinct ?x953 ?x953) true))))))))
(check-sat)
; query 56: function crcu8, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x182 (or false false)))
(let (($x396 (not $x182)))
(and $x396 (or $x182 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 57: function crcu8, block 19, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x602 ((_ zero_extend 16) in.01_16)))
(let ((?x1116 (bvxor ?x602 (_ bv16386 32))))
(let (($x182 (or false false)))
(let (($x394 (or $x182 false false)))
(let (($x623 (not $x394)))
(and $x623 (or $x394 (and (distinct ?x1116 ?x1116) true)))))))))
(check-sat)
; query 58: function crcu8, block 19, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x602 ((_ zero_extend 16) in.01_16)))
(let ((?x1116 (bvxor ?x602 (_ bv16386 32))))
(let ((?x1767 ((_ extract 15 0) ?x1116)))
(let (($x182 (or false false)))
(let (($x394 (or $x182 false false)))
(let (($x848 (or $x394 false)))
(let (($x66 (not $x848)))
(and $x66 (or $x848 (and (distinct ?x1767 ?x1767) true)))))))))))
(check-sat)
; query 59: function crcu8, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x182 (or false false)))
(let (($x396 (not $x182)))
(and $x396 (or $x182 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 60: function crcu8, block 29, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x2599 ((_ zero_extend 16) in27_16)))
(let ((?x1079 (bvor ?x2599 (_ bv32768 32))))
(let (($x182 (or false false)))
(let (($x394 (or $x182 false false)))
(let (($x623 (not $x394)))
(and $x623 (or $x394 (and (distinct ?x1079 ?x1079) true)))))))))
(check-sat)
; query 61: function crcu8, block 29, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x2599 ((_ zero_extend 16) in27_16)))
(let ((?x1079 (bvor ?x2599 (_ bv32768 32))))
(let ((?x1545 ((_ extract 15 0) ?x1079)))
(let (($x182 (or false false)))
(let (($x394 (or $x182 false false)))
(let (($x848 (or $x394 false)))
(let (($x66 (not $x848)))
(and $x66 (or $x848 (and (distinct ?x1545 ?x1545) true)))))))))))
(check-sat)
; query 62: function crcu8, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x182 (or false false)))
(let (($x396 (not $x182)))
(and $x396 (or $x182 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 63: function crcu8, block 33, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x2599 ((_ zero_extend 16) in27_16)))
(let ((?x1983 (bvand ?x2599 (_ bv32767 32))))
(let (($x182 (or false false)))
(let (($x394 (or $x182 false false)))
(let (($x623 (not $x394)))
(and $x623 (or $x394 (and (distinct ?x1983 ?x1983) true)))))))))
(check-sat)
; query 64: function crcu8, block 33, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x2599 ((_ zero_extend 16) in27_16)))
(let ((?x1983 (bvand ?x2599 (_ bv32767 32))))
(let ((?x1168 ((_ extract 15 0) ?x1983)))
(let (($x182 (or false false)))
(let (($x394 (or $x182 false false)))
(let (($x848 (or $x394 false)))
(let (($x66 (not $x848)))
(and $x66 (or $x848 (and (distinct ?x1168 ?x1168) true)))))))))))
(check-sat)
; query 65: function crcu8, block 38, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_8 () (_ BitVec 8))
(assert
 (let (($x499 (or false false false)))
(let (($x51 (not $x499)))
(and $x51 (or $x499 (and (distinct (bvadd in.02_8 (_ bv1 8)) (bvadd in.02_8 (_ bv1 8))) true))))))
(check-sat)
; query 66: function crcu8, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x313 ((_ extract 7 0) in.01_16)))
(let ((?x1707 ((_ zero_extend 24) ?x313)))
(let (($x182 (or false false)))
(let (($x1789 (or $x182 false)))
(and (not $x1789) (or $x1789 (and (distinct ?x1707 ?x1707) true))))))))
(check-sat)
; query 67: function crcu8, block 6, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x313 ((_ extract 7 0) in.01_16)))
(let ((?x1707 ((_ zero_extend 24) ?x313)))
(let ((?x1557 (bvand ?x1707 (_ bv1 32))))
(let (($x182 (or false false)))
(let (($x1789 (or $x182 false)))
(let (($x1904 (or $x1789 false false)))
(and (not $x1904) (or $x1904 (and (distinct ?x1557 ?x1557) true))))))))))
(check-sat)
; query 68: function crcu8, block 6, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x313 ((_ extract 7 0) in.01_16)))
(let ((?x1707 ((_ zero_extend 24) ?x313)))
(let ((?x1557 (bvand ?x1707 (_ bv1 32))))
(let ((?x1641 ((_ zero_extend 24) in.0_8)))
(let ((?x198 (bvand ?x1641 (_ bv1 32))))
(let ((?x1025 (bvxor ?x198 ?x1557)))
(let (($x182 (or false false)))
(let (($x1789 (or $x182 false)))
(let (($x1904 (or $x1789 false false)))
(let (($x394 (or $x182 false false)))
(let (($x434 (or $x394 $x1904 false)))
(and (not $x434) (or $x434 (and (distinct ?x1025 ?x1025) true)))))))))))))))
(check-sat)
; query 69: function crcu8, block 6, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x313 ((_ extract 7 0) in.01_16)))
(let ((?x1707 ((_ zero_extend 24) ?x313)))
(let ((?x1557 (bvand ?x1707 (_ bv1 32))))
(let ((?x1641 ((_ zero_extend 24) in.0_8)))
(let ((?x198 (bvand ?x1641 (_ bv1 32))))
(let ((?x1025 (bvxor ?x198 ?x1557)))
(let ((?x2347 ((_ extract 7 0) ?x1025)))
(let (($x182 (or false false)))
(let (($x1789 (or $x182 false)))
(let (($x1904 (or $x1789 false false)))
(let (($x394 (or $x182 false false)))
(let (($x434 (or $x394 $x1904 false)))
(let (($x1687 (or $x434 false)))
(and (not $x1687) (or $x1687 (and (distinct ?x2347 ?x2347) true)))))))))))))))))
(check-sat)
; query 70: function crcu8, block 6, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x182 (or false false)))
(let (($x396 (not $x182)))
(and $x396 (or $x182 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 71: function crcu8, block 6, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1641 ((_ zero_extend 24) in.0_8)))
(let ((?x635 (bvashr ?x1641 (_ bv1 32))))
(let (($x182 (or false false)))
(let (($x394 (or $x182 false false)))
(let (($x692 (or $x394 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not $x692) (or $x692 (and (distinct ?x635 ?x635) true)))))))))
(check-sat)
; query 72: function crcu8, block 6, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1641 ((_ zero_extend 24) in.0_8)))
(let ((?x635 (bvashr ?x1641 (_ bv1 32))))
(let ((?x1307 ((_ extract 7 0) ?x635)))
(let (($x182 (or false false)))
(let (($x394 (or $x182 false false)))
(let (($x692 (or $x394 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x650 (or $x692 false)))
(and (not $x650) (or $x650 (and (distinct ?x1307 ?x1307) true)))))))))))
(check-sat)
; query 73: function crcu8, block 6, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x313 ((_ extract 7 0) in.01_16)))
(let ((?x1707 ((_ zero_extend 24) ?x313)))
(let ((?x1557 (bvand ?x1707 (_ bv1 32))))
(let ((?x1641 ((_ zero_extend 24) in.0_8)))
(let ((?x198 (bvand ?x1641 (_ bv1 32))))
(let ((?x1025 (bvxor ?x198 ?x1557)))
(let ((?x2347 ((_ extract 7 0) ?x1025)))
(let ((?x6049 ((_ zero_extend 24) ?x2347)))
(let (($x182 (or false false)))
(let (($x1789 (or $x182 false)))
(let (($x1904 (or $x1789 false false)))
(let (($x394 (or $x182 false false)))
(let (($x434 (or $x394 $x1904 false)))
(let (($x1687 (or $x434 false)))
(let (($x422 (or $x1687 false)))
(and (not $x422) (or $x422 (and (distinct ?x6049 ?x6049) true)))))))))))))))))))
(check-sat)
; query 74: function crcu8, block 6, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x313 ((_ extract 7 0) in.01_16)))
(let ((?x1707 ((_ zero_extend 24) ?x313)))
(let ((?x1557 (bvand ?x1707 (_ bv1 32))))
(let ((?x1641 ((_ zero_extend 24) in.0_8)))
(let ((?x198 (bvand ?x1641 (_ bv1 32))))
(let ((?x1025 (bvxor ?x198 ?x1557)))
(let ((?x2347 ((_ extract 7 0) ?x1025)))
(let ((?x6049 ((_ zero_extend 24) ?x2347)))
(let ((?x3272 (ite (= (_ bv1 32) ?x6049) (_ bv1 1) (_ bv0 1))))
(let (($x182 (or false false)))
(let (($x1789 (or $x182 false)))
(let (($x1904 (or $x1789 false false)))
(let (($x394 (or $x182 false false)))
(let (($x434 (or $x394 $x1904 false)))
(let (($x1687 (or $x434 false)))
(let (($x422 (or $x1687 false)))
(let (($x2733 (or $x422 false false)))
(and (not $x2733) (or $x2733 (and (distinct ?x3272 ?x3272) true)))))))))))))))))))))
(check-sat)
; query 75: function crcu8, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x182 (or false false)))
(let (($x396 (not $x182)))
(and $x396 (or $x182 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 76: function crcu8, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1641 ((_ zero_extend 24) in.0_8)))
(let ((?x198 (bvand ?x1641 (_ bv1 32))))
(let (($x182 (or false false)))
(let (($x394 (or $x182 false false)))
(let (($x623 (not $x394)))
(and $x623 (or $x394 (and (distinct ?x198 ?x198) true)))))))))
(check-sat)
; query 77: function crcu8, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x182 (or false false)))
(let (($x396 (not $x182)))
(and $x396 (or $x182 (and (distinct ((_ extract 7 0) in.01_16) ((_ extract 7 0) in.01_16)) true))))))
(check-sat)
; query 78: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1905 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1661 ((_ zero_extend 31) ?x1905)))
(let ((?x301 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x403 ((_ zero_extend 31) ?x301)))
(let ((?x2031 (bvand ?x403 ?x1661)))
(let ((?x1271 (ite (and (distinct (_ bv0 32) ?x2031) true) (_ bv1 1) (_ bv0 1))))
(let ((?x101 ((_ zero_extend 63) ?x1271)))
(let (($x182 (or false false)))
(let (($x394 (or $x182 false false)))
(let (($x848 (or $x394 false)))
(let (($x146 (or $x848 $x848 false)))
(let (($x1093 (or $x146 false false)))
(let (($x1011 (or $x1093 false)))
(and (not $x1011) (or $x1011 (and (distinct ?x101 ?x101) true)))))))))))))))))
(check-sat)
; query 79: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1905 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1661 ((_ zero_extend 31) ?x1905)))
(let ((?x301 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x403 ((_ zero_extend 31) ?x301)))
(let ((?x2031 (bvand ?x403 ?x1661)))
(let ((?x1271 (ite (and (distinct (_ bv0 32) ?x2031) true) (_ bv1 1) (_ bv0 1))))
(let (($x1684 (= (_ bv1 1) ?x1271)))
(let ((?x852 (ite $x1684 (_ bv1 32) (_ bv0 32))))
(let (($x182 (or false false)))
(let (($x394 (or $x182 false false)))
(let (($x848 (or $x394 false)))
(let (($x146 (or $x848 $x848 false)))
(let (($x1093 (or $x146 false false)))
(let (($x263 (or $x1093 (ite $x1684 false false))))
(and (not $x263) (or $x263 (and (distinct ?x852 ?x852) true))))))))))))))))))
(check-sat)
; query 80: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1905 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1661 ((_ zero_extend 31) ?x1905)))
(let ((?x301 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x403 ((_ zero_extend 31) ?x301)))
(let ((?x2031 (bvand ?x403 ?x1661)))
(let ((?x1271 (ite (and (distinct (_ bv0 32) ?x2031) true) (_ bv1 1) (_ bv0 1))))
(let (($x1684 (= (_ bv1 1) ?x1271)))
(let ((?x852 (ite $x1684 (_ bv1 32) (_ bv0 32))))
(let ((?x1580 ((_ extract 7 0) ?x852)))
(let (($x182 (or false false)))
(let (($x394 (or $x182 false false)))
(let (($x848 (or $x394 false)))
(let (($x146 (or $x848 $x848 false)))
(let (($x1093 (or $x146 false false)))
(let (($x263 (or $x1093 (ite $x1684 false false))))
(let (($x1732 (or $x263 false)))
(and (not $x1732) (or $x1732 (and (distinct ?x1580 ?x1580) true))))))))))))))))))))
(check-sat)
; query 81: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x182 (or false false)))
(let (($x396 (not $x182)))
(and $x396 (or $x182 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 82: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x301 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x182 (or false false)))
(let (($x394 (or $x182 false false)))
(let (($x623 (not $x394)))
(and $x623 (or $x394 (and (distinct ?x301 ?x301) true))))))))
(check-sat)
; query 83: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x301 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x403 ((_ zero_extend 31) ?x301)))
(let (($x182 (or false false)))
(let (($x394 (or $x182 false false)))
(let (($x848 (or $x394 false)))
(let (($x66 (not $x848)))
(and $x66 (or $x848 (and (distinct ?x403 ?x403) true))))))))))
(check-sat)
; query 84: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x182 (or false false)))
(let (($x396 (not $x182)))
(and $x396 (or $x182 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 85: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1905 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x182 (or false false)))
(let (($x394 (or $x182 false false)))
(let (($x623 (not $x394)))
(and $x623 (or $x394 (and (distinct ?x1905 ?x1905) true))))))))
(check-sat)
; query 86: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1905 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1661 ((_ zero_extend 31) ?x1905)))
(let (($x182 (or false false)))
(let (($x394 (or $x182 false false)))
(let (($x848 (or $x394 false)))
(let (($x66 (not $x848)))
(and $x66 (or $x848 (and (distinct ?x1661 ?x1661) true))))))))))
(check-sat)
; query 87: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1905 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1661 ((_ zero_extend 31) ?x1905)))
(let ((?x301 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x403 ((_ zero_extend 31) ?x301)))
(let ((?x2031 (bvand ?x403 ?x1661)))
(let (($x182 (or false false)))
(let (($x394 (or $x182 false false)))
(let (($x848 (or $x394 false)))
(let (($x146 (or $x848 $x848 false)))
(and (not $x146) (or $x146 (and (distinct ?x2031 ?x2031) true)))))))))))))
(check-sat)
; query 88: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1905 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1661 ((_ zero_extend 31) ?x1905)))
(let ((?x301 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x403 ((_ zero_extend 31) ?x301)))
(let ((?x2031 (bvand ?x403 ?x1661)))
(let ((?x1271 (ite (and (distinct (_ bv0 32) ?x2031) true) (_ bv1 1) (_ bv0 1))))
(let (($x182 (or false false)))
(let (($x394 (or $x182 false false)))
(let (($x848 (or $x394 false)))
(let (($x146 (or $x848 $x848 false)))
(let (($x1093 (or $x146 false false)))
(and (not $x1093) (or $x1093 (and (distinct ?x1271 ?x1271) true)))))))))))))))
(check-sat)
; query 89: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x2085 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x499 (or false false false)))
(let (($x51 (not $x499)))
(and $x51 (or $x499 (and (distinct ?x2085 ?x2085) true)))))))
(check-sat)
; query 90: function matrix_add_const, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x499 (or false false false)))
(let (($x51 (not $x499)))
(and $x51 (or $x499 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 91: function matrix_add_const, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x36 (bvadd in.01_32 (_ bv1 32))))
(let (($x738 (and (distinct ?x36 ?x36) true)))
(let (($x499 (or false false false)))
(let (($x51 (not $x499)))
(and $x51 (or $x499 $x738)))))))
(check-sat)
; query 92: function matrix_mul_const, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x499 (or false false false)))
(let (($x51 (not $x499)))
(and $x51 (or $x499 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 93: function matrix_mul_const, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x36 (bvadd in.01_32 (_ bv1 32))))
(let (($x738 (and (distinct ?x36 ?x36) true)))
(let (($x499 (or false false false)))
(let (($x51 (not $x499)))
(and $x51 (or $x499 $x738)))))))
(check-sat)
; query 94: function matrix_mul_matrix, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x499 (or false false false)))
(let (($x51 (not $x499)))
(and $x51 (or $x499 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 95: function matrix_mul_matrix, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x36 (bvadd in.01_32 (_ bv1 32))))
(let (($x738 (and (distinct ?x36 ?x36) true)))
(let (($x499 (or false false false)))
(let (($x51 (not $x499)))
(and $x51 (or $x499 $x738)))))))
(check-sat)
; query 96: function matrix_mul_matrix, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x499 (or false false false)))
(let (($x51 (not $x499)))
(and $x51 (or $x499 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 97: function matrix_mul_matrix_bitextract, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x499 (or false false false)))
(let (($x51 (not $x499)))
(and $x51 (or $x499 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 98: function matrix_mul_matrix_bitextract, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x36 (bvadd in.01_32 (_ bv1 32))))
(let (($x738 (and (distinct ?x36 ?x36) true)))
(let (($x499 (or false false false)))
(let (($x51 (not $x499)))
(and $x51 (or $x499 $x738)))))))
(check-sat)
; query 99: function matrix_mul_matrix_bitextract, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x499 (or false false false)))
(let (($x51 (not $x499)))
(and $x51 (or $x499 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 100: function matrix_mul_vect, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x499 (or false false false)))
(let (($x51 (not $x499)))
(and $x51 (or $x499 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 101: function matrix_mul_vect, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x36 (bvadd in.01_32 (_ bv1 32))))
(let (($x738 (and (distinct ?x36 ?x36) true)))
(let (($x499 (or false false false)))
(let (($x51 (not $x499)))
(and $x51 (or $x499 $x738)))))))
(check-sat)
; query 102: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x182 (or false false)))
(let (($x396 (not $x182)))
(and $x396 (or $x182 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 103: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x1006 ((_ sign_extend 16) in.1_16)))
(let ((?x1932 (bvadd ?x1006 (_ bv10 32))))
(let (($x789 (and (distinct (bvadd ((_ sign_extend 1) ?x1006) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x1932)) true)))
(let (($x182 (or false false)))
(let (($x1760 (or $x182 false (or $x789))))
(and (not $x1760) (or $x1760 (and (distinct ?x1932 ?x1932) true)))))))))
(check-sat)
; query 104: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x1006 ((_ sign_extend 16) in.1_16)))
(let ((?x1932 (bvadd ?x1006 (_ bv10 32))))
(let ((?x2069 ((_ extract 15 0) ?x1932)))
(let (($x789 (and (distinct (bvadd ((_ sign_extend 1) ?x1006) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x1932)) true)))
(let (($x182 (or false false)))
(let (($x1760 (or $x182 false (or $x789))))
(let (($x1867 (or $x1760 false)))
(and (not $x1867) (or $x1867 (and (distinct ?x2069 ?x2069) true)))))))))))
(check-sat)
; query 105: function matrix_sum, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x870 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x499 (or false false false)))
(let (($x51 (not $x499)))
(and $x51 (or $x499 (and (distinct ?x870 ?x870) true)))))))
(check-sat)
; query 106: function matrix_sum, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x870 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let ((?x1792 ((_ zero_extend 63) ?x870)))
(let (($x499 (or false false false)))
(let (($x2798 (or $x499 false)))
(and (not $x2798) (or $x2798 (and (distinct ?x1792 ?x1792) true))))))))
(check-sat)
; query 107: function matrix_sum, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x870 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x909 (= (_ bv1 1) ?x870)))
(let ((?x640 (ite $x909 (_ bv1 32) (_ bv0 32))))
(let (($x499 (or false false false)))
(let (($x1021 (or $x499 (ite $x909 false false))))
(and (not $x1021) (or $x1021 (and (distinct ?x640 ?x640) true)))))))))
(check-sat)
; query 108: function matrix_sum, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x182 (or false false)))
(let (($x396 (not $x182)))
(and $x396 (or $x182 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 109: function matrix_sum, block 22, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x870 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x909 (= (_ bv1 1) ?x870)))
(let ((?x640 (ite $x909 (_ bv1 32) (_ bv0 32))))
(let ((?x1006 ((_ sign_extend 16) in.1_16)))
(let ((?x736 (bvadd ?x1006 ?x640)))
(let (($x2728 (and (distinct (bvadd ((_ sign_extend 1) ?x1006) ((_ sign_extend 1) ?x640)) ((_ sign_extend 1) ?x736)) true)))
(let (($x499 (or false false false)))
(let (($x1021 (or $x499 (ite $x909 false false))))
(let (($x182 (or false false)))
(let (($x451 (or $x182 $x1021 (or $x2728))))
(and (not $x451) (or $x451 (and (distinct ?x736 ?x736) true))))))))))))))
(check-sat)
; query 110: function matrix_sum, block 22, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x870 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x909 (= (_ bv1 1) ?x870)))
(let ((?x640 (ite $x909 (_ bv1 32) (_ bv0 32))))
(let ((?x1006 ((_ sign_extend 16) in.1_16)))
(let ((?x736 (bvadd ?x1006 ?x640)))
(let ((?x311 ((_ extract 15 0) ?x736)))
(let (($x2728 (and (distinct (bvadd ((_ sign_extend 1) ?x1006) ((_ sign_extend 1) ?x640)) ((_ sign_extend 1) ?x736)) true)))
(let (($x499 (or false false false)))
(let (($x1021 (or $x499 (ite $x909 false false))))
(let (($x182 (or false false)))
(let (($x451 (or $x182 $x1021 (or $x2728))))
(let (($x1603 (or $x451 false)))
(and (not $x1603) (or $x1603 (and (distinct ?x311 ?x311) true))))))))))))))))
(check-sat)
; query 111: function matrix_sum, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x499 (or false false false)))
(let (($x51 (not $x499)))
(and $x51 (or $x499 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 112: function matrix_sum, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x36 (bvadd in.01_32 (_ bv1 32))))
(let (($x738 (and (distinct ?x36 ?x36) true)))
(let (($x499 (or false false false)))
(let (($x51 (not $x499)))
(and $x51 (or $x499 $x738)))))))
(check-sat)
; query 113: function parseval, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.23_32 () (_ BitVec 32))
(assert
 (let (($x1895 (and (distinct (bvmul ((_ sign_extend 32) in.23_32) ((_ sign_extend 32) (_ bv1024 32))) ((_ sign_extend 32) (bvmul in.23_32 (_ bv1024 32)))) true)))
(let (($x1353 (or false false (or $x1895))))
(and (not $x1353) (or $x1353 (and (distinct (bvmul in.23_32 (_ bv1024 32)) (bvmul in.23_32 (_ bv1024 32))) true))))))
(check-sat)
; query 114: function parseval, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.34_32 () (_ BitVec 32))
(assert
 (let (($x2763 (and (distinct (bvmul ((_ sign_extend 32) in.34_32) ((_ sign_extend 32) (_ bv1048576 32))) ((_ sign_extend 32) (bvmul in.34_32 (_ bv1048576 32)))) true)))
(let (($x1627 (or false false (or $x2763))))
(and (not $x1627) (or $x1627 (and (distinct (bvmul in.34_32 (_ bv1048576 32)) (bvmul in.34_32 (_ bv1048576 32))) true))))))
(check-sat)
; query 115: function partition_memory, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x499 (or false false false)))
(let (($x51 (not $x499)))
(and $x51 (or $x499 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
