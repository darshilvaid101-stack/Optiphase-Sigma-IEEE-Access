; OptiPhase-Sigma refinement certificate for sweep K49-R3-208
; query 0: function APCM_inverse_quantization, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 16) in53_16) ((_ sign_extend 16) in53_16)) true))))))
(check-sat)
; query 1: function APCM_inverse_quantization, block 56, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let ((?x2660 (ite (bvsle (_ bv4294967289 32) ((_ sign_extend 16) in53_16)) (_ bv1 1) (_ bv0 1))))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x2665 (not $x2657)))
(and $x2665 (or $x2657 (and (distinct ?x2660 ?x2660) true))))))))
(check-sat)
; query 2: function APCM_inverse_quantization, block 68, name %69
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 16) in53_16) ((_ sign_extend 16) in53_16)) true))))))
(check-sat)
; query 3: function APCM_inverse_quantization, block 68, name %70
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let ((?x2655 ((_ sign_extend 16) in53_16)))
(let ((?x52 (bvshl ?x2655 (_ bv12 32))))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x504 (or $x2657 (bvuge (_ bv12 32) (_ bv32 32)))))
(and (not $x504) (or $x504 (and (distinct ?x52 ?x52) true)))))))))
(check-sat)
; query 4: function APCM_inverse_quantization, block 68, name %71
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let ((?x2655 ((_ sign_extend 16) in53_16)))
(let ((?x52 (bvshl ?x2655 (_ bv12 32))))
(let ((?x631 ((_ extract 15 0) ?x52)))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x504 (or $x2657 (bvuge (_ bv12 32) (_ bv32 32)))))
(let (($x10 (or $x504 false)))
(and (not $x10) (or $x10 (and (distinct ?x631 ?x631) true)))))))))))
(check-sat)
; query 5: function APCM_inverse_quantization, block 68, name %72
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in22_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 48) in22_16) ((_ sign_extend 48) in22_16)) true))))))
(check-sat)
; query 6: function APCM_inverse_quantization, block 68, name %73
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let ((?x2655 ((_ sign_extend 16) in53_16)))
(let ((?x52 (bvshl ?x2655 (_ bv12 32))))
(let ((?x631 ((_ extract 15 0) ?x52)))
(let ((?x178 ((_ sign_extend 48) ?x631)))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x504 (or $x2657 (bvuge (_ bv12 32) (_ bv32 32)))))
(let (($x10 (or $x504 false)))
(let (($x354 (or $x10 false)))
(and (not $x354) (or $x354 (and (distinct ?x178 ?x178) true)))))))))))))
(check-sat)
; query 7: function APCM_inverse_quantization, block 68, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(declare-fun in22_16 () (_ BitVec 16))
(assert
 (let ((?x2655 ((_ sign_extend 16) in53_16)))
(let ((?x52 (bvshl ?x2655 (_ bv12 32))))
(let ((?x631 ((_ extract 15 0) ?x52)))
(let ((?x178 ((_ sign_extend 48) ?x631)))
(let ((?x540 ((_ sign_extend 48) in22_16)))
(let ((?x576 (bvmul ?x540 ?x178)))
(let (($x499 (and (distinct (bvmul ((_ sign_extend 64) ?x540) ((_ sign_extend 64) ?x178)) ((_ sign_extend 64) ?x576)) true)))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x504 (or $x2657 (bvuge (_ bv12 32) (_ bv32 32)))))
(let (($x10 (or $x504 false)))
(let (($x354 (or $x10 false)))
(let (($x6 (or $x2656 $x354 (or $x499))))
(and (not $x6) (or $x6 (and (distinct ?x576 ?x576) true)))))))))))))))))
(check-sat)
; query 8: function APCM_inverse_quantization, block 68, name %75
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(declare-fun in22_16 () (_ BitVec 16))
(assert
 (let ((?x2655 ((_ sign_extend 16) in53_16)))
(let ((?x52 (bvshl ?x2655 (_ bv12 32))))
(let ((?x631 ((_ extract 15 0) ?x52)))
(let ((?x178 ((_ sign_extend 48) ?x631)))
(let ((?x540 ((_ sign_extend 48) in22_16)))
(let ((?x576 (bvmul ?x540 ?x178)))
(let ((?x593 (bvadd ?x576 (_ bv16384 64))))
(let (($x734 (and (distinct (bvadd ((_ sign_extend 1) ?x576) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x593)) true)))
(let (($x499 (and (distinct (bvmul ((_ sign_extend 64) ?x540) ((_ sign_extend 64) ?x178)) ((_ sign_extend 64) ?x576)) true)))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x504 (or $x2657 (bvuge (_ bv12 32) (_ bv32 32)))))
(let (($x10 (or $x504 false)))
(let (($x354 (or $x10 false)))
(let (($x6 (or $x2656 $x354 (or $x499))))
(let (($x337 (or $x6 false (or $x734))))
(and (not $x337) (or $x337 (and (distinct ?x593 ?x593) true))))))))))))))))))))
(check-sat)
; query 9: function APCM_inverse_quantization, block 68, name %76
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(declare-fun in22_16 () (_ BitVec 16))
(assert
 (let ((?x2655 ((_ sign_extend 16) in53_16)))
(let ((?x52 (bvshl ?x2655 (_ bv12 32))))
(let ((?x631 ((_ extract 15 0) ?x52)))
(let ((?x178 ((_ sign_extend 48) ?x631)))
(let ((?x540 ((_ sign_extend 48) in22_16)))
(let ((?x576 (bvmul ?x540 ?x178)))
(let ((?x593 (bvadd ?x576 (_ bv16384 64))))
(let ((?x310 (bvashr ?x593 (_ bv15 64))))
(let (($x44 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x734 (and (distinct (bvadd ((_ sign_extend 1) ?x576) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x593)) true)))
(let (($x499 (and (distinct (bvmul ((_ sign_extend 64) ?x540) ((_ sign_extend 64) ?x178)) ((_ sign_extend 64) ?x576)) true)))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x504 (or $x2657 (bvuge (_ bv12 32) (_ bv32 32)))))
(let (($x10 (or $x504 false)))
(let (($x354 (or $x10 false)))
(let (($x6 (or $x2656 $x354 (or $x499))))
(let (($x337 (or $x6 false (or $x734))))
(let (($x443 (or (or $x337 false false) $x44)))
(and (not $x443) (or $x443 (and (distinct ?x310 ?x310) true)))))))))))))))))))))))
(check-sat)
; query 10: function APCM_inverse_quantization, block 68, name %77
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(declare-fun in22_16 () (_ BitVec 16))
(assert
 (let ((?x2655 ((_ sign_extend 16) in53_16)))
(let ((?x52 (bvshl ?x2655 (_ bv12 32))))
(let ((?x631 ((_ extract 15 0) ?x52)))
(let ((?x178 ((_ sign_extend 48) ?x631)))
(let ((?x540 ((_ sign_extend 48) in22_16)))
(let ((?x576 (bvmul ?x540 ?x178)))
(let ((?x593 (bvadd ?x576 (_ bv16384 64))))
(let ((?x310 (bvashr ?x593 (_ bv15 64))))
(let ((?x717 ((_ extract 15 0) ?x310)))
(let (($x44 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x734 (and (distinct (bvadd ((_ sign_extend 1) ?x576) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x593)) true)))
(let (($x499 (and (distinct (bvmul ((_ sign_extend 64) ?x540) ((_ sign_extend 64) ?x178)) ((_ sign_extend 64) ?x576)) true)))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x504 (or $x2657 (bvuge (_ bv12 32) (_ bv32 32)))))
(let (($x10 (or $x504 false)))
(let (($x354 (or $x10 false)))
(let (($x6 (or $x2656 $x354 (or $x499))))
(let (($x337 (or $x6 false (or $x734))))
(let (($x443 (or (or $x337 false false) $x44)))
(let (($x495 (or $x443 false)))
(and (not $x495) (or $x495 (and (distinct ?x717 ?x717) true)))))))))))))))))))))))))
(check-sat)
; query 11: function APCM_inverse_quantization, block 68, name %78
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(declare-fun in22_16 () (_ BitVec 16))
(assert
 (let ((?x2655 ((_ sign_extend 16) in53_16)))
(let ((?x52 (bvshl ?x2655 (_ bv12 32))))
(let ((?x631 ((_ extract 15 0) ?x52)))
(let ((?x178 ((_ sign_extend 48) ?x631)))
(let ((?x540 ((_ sign_extend 48) in22_16)))
(let ((?x576 (bvmul ?x540 ?x178)))
(let ((?x593 (bvadd ?x576 (_ bv16384 64))))
(let ((?x310 (bvashr ?x593 (_ bv15 64))))
(let ((?x717 ((_ extract 15 0) ?x310)))
(let ((?x235 ((_ sign_extend 48) ?x717)))
(let (($x44 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x734 (and (distinct (bvadd ((_ sign_extend 1) ?x576) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x593)) true)))
(let (($x499 (and (distinct (bvmul ((_ sign_extend 64) ?x540) ((_ sign_extend 64) ?x178)) ((_ sign_extend 64) ?x576)) true)))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x504 (or $x2657 (bvuge (_ bv12 32) (_ bv32 32)))))
(let (($x10 (or $x504 false)))
(let (($x354 (or $x10 false)))
(let (($x6 (or $x2656 $x354 (or $x499))))
(let (($x337 (or $x6 false (or $x734))))
(let (($x443 (or (or $x337 false false) $x44)))
(let (($x495 (or $x443 false)))
(let (($x146 (or $x495 false)))
(and (not $x146) (or $x146 (and (distinct ?x235 ?x235) true)))))))))))))))))))))))))))
(check-sat)
; query 12: function APCM_inverse_quantization, block 68, name %79
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in26_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 48) in26_16) ((_ sign_extend 48) in26_16)) true))))))
(check-sat)
; query 13: function APCM_inverse_quantization, block 68, name %80
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in26_16 () (_ BitVec 16))
(declare-fun in53_16 () (_ BitVec 16))
(declare-fun in22_16 () (_ BitVec 16))
(assert
 (let ((?x606 ((_ sign_extend 48) in26_16)))
(let ((?x2655 ((_ sign_extend 16) in53_16)))
(let ((?x52 (bvshl ?x2655 (_ bv12 32))))
(let ((?x631 ((_ extract 15 0) ?x52)))
(let ((?x178 ((_ sign_extend 48) ?x631)))
(let ((?x540 ((_ sign_extend 48) in22_16)))
(let ((?x576 (bvmul ?x540 ?x178)))
(let ((?x593 (bvadd ?x576 (_ bv16384 64))))
(let ((?x310 (bvashr ?x593 (_ bv15 64))))
(let ((?x717 ((_ extract 15 0) ?x310)))
(let ((?x235 ((_ sign_extend 48) ?x717)))
(let ((?x1152 (bvadd ?x235 ?x606)))
(let ((?x219 ((_ sign_extend 1) ?x1152)))
(let (($x2656 (or false false)))
(let (($x44 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x734 (and (distinct (bvadd ((_ sign_extend 1) ?x576) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x593)) true)))
(let (($x499 (and (distinct (bvmul ((_ sign_extend 64) ?x540) ((_ sign_extend 64) ?x178)) ((_ sign_extend 64) ?x576)) true)))
(let (($x2657 (or $x2656 false false)))
(let (($x504 (or $x2657 (bvuge (_ bv12 32) (_ bv32 32)))))
(let (($x10 (or $x504 false)))
(let (($x354 (or $x10 false)))
(let (($x6 (or $x2656 $x354 (or $x499))))
(let (($x337 (or $x6 false (or $x734))))
(let (($x443 (or (or $x337 false false) $x44)))
(let (($x495 (or $x443 false)))
(let (($x146 (or $x495 false)))
(let (($x275 (or $x146 $x2656 (or (and (distinct (bvadd ((_ sign_extend 1) ?x235) ((_ sign_extend 1) ?x606)) ?x219) true)))))
(and (not $x275) (or $x275 (and (distinct ?x1152 ?x1152) true)))))))))))))))))))))))))))))))
(check-sat)
; query 14: function APCM_inverse_quantization, block 68, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in26_16 () (_ BitVec 16))
(declare-fun in53_16 () (_ BitVec 16))
(declare-fun in22_16 () (_ BitVec 16))
(assert
 (let ((?x606 ((_ sign_extend 48) in26_16)))
(let ((?x2655 ((_ sign_extend 16) in53_16)))
(let ((?x52 (bvshl ?x2655 (_ bv12 32))))
(let ((?x631 ((_ extract 15 0) ?x52)))
(let ((?x178 ((_ sign_extend 48) ?x631)))
(let ((?x540 ((_ sign_extend 48) in22_16)))
(let ((?x576 (bvmul ?x540 ?x178)))
(let ((?x593 (bvadd ?x576 (_ bv16384 64))))
(let ((?x310 (bvashr ?x593 (_ bv15 64))))
(let ((?x717 ((_ extract 15 0) ?x310)))
(let ((?x235 ((_ sign_extend 48) ?x717)))
(let ((?x1152 (bvadd ?x235 ?x606)))
(let ((?x23 (bvsub ?x1152 (_ bv18446744073709518848 64))))
(let (($x79 (and (distinct (bvsub ((_ sign_extend 1) ?x1152) ((_ sign_extend 1) (_ bv18446744073709518848 64))) ((_ sign_extend 1) ?x23)) true)))
(let ((?x219 ((_ sign_extend 1) ?x1152)))
(let (($x2656 (or false false)))
(let (($x44 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x734 (and (distinct (bvadd ((_ sign_extend 1) ?x576) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x593)) true)))
(let (($x499 (and (distinct (bvmul ((_ sign_extend 64) ?x540) ((_ sign_extend 64) ?x178)) ((_ sign_extend 64) ?x576)) true)))
(let (($x2657 (or $x2656 false false)))
(let (($x504 (or $x2657 (bvuge (_ bv12 32) (_ bv32 32)))))
(let (($x10 (or $x504 false)))
(let (($x354 (or $x10 false)))
(let (($x6 (or $x2656 $x354 (or $x499))))
(let (($x337 (or $x6 false (or $x734))))
(let (($x443 (or (or $x337 false false) $x44)))
(let (($x495 (or $x443 false)))
(let (($x146 (or $x495 false)))
(let (($x275 (or $x146 $x2656 (or (and (distinct (bvadd ((_ sign_extend 1) ?x235) ((_ sign_extend 1) ?x606)) ?x219) true)))))
(let (($x1864 (or $x275 false (or $x79))))
(and (not $x1864) (or $x1864 (and (distinct ?x23 ?x23) true))))))))))))))))))))))))))))))))))
(check-sat)
; query 15: function APCM_inverse_quantization, block 68, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in26_16 () (_ BitVec 16))
(declare-fun in53_16 () (_ BitVec 16))
(declare-fun in22_16 () (_ BitVec 16))
(assert
 (let ((?x606 ((_ sign_extend 48) in26_16)))
(let ((?x2655 ((_ sign_extend 16) in53_16)))
(let ((?x52 (bvshl ?x2655 (_ bv12 32))))
(let ((?x631 ((_ extract 15 0) ?x52)))
(let ((?x178 ((_ sign_extend 48) ?x631)))
(let ((?x540 ((_ sign_extend 48) in22_16)))
(let ((?x576 (bvmul ?x540 ?x178)))
(let ((?x593 (bvadd ?x576 (_ bv16384 64))))
(let ((?x310 (bvashr ?x593 (_ bv15 64))))
(let ((?x717 ((_ extract 15 0) ?x310)))
(let ((?x235 ((_ sign_extend 48) ?x717)))
(let ((?x1152 (bvadd ?x235 ?x606)))
(let ((?x23 (bvsub ?x1152 (_ bv18446744073709518848 64))))
(let ((?x871 (ite (bvugt ?x23 (_ bv65535 64)) (_ bv1 1) (_ bv0 1))))
(let (($x79 (and (distinct (bvsub ((_ sign_extend 1) ?x1152) ((_ sign_extend 1) (_ bv18446744073709518848 64))) ((_ sign_extend 1) ?x23)) true)))
(let ((?x219 ((_ sign_extend 1) ?x1152)))
(let (($x2656 (or false false)))
(let (($x44 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x734 (and (distinct (bvadd ((_ sign_extend 1) ?x576) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x593)) true)))
(let (($x499 (and (distinct (bvmul ((_ sign_extend 64) ?x540) ((_ sign_extend 64) ?x178)) ((_ sign_extend 64) ?x576)) true)))
(let (($x2657 (or $x2656 false false)))
(let (($x504 (or $x2657 (bvuge (_ bv12 32) (_ bv32 32)))))
(let (($x10 (or $x504 false)))
(let (($x354 (or $x10 false)))
(let (($x6 (or $x2656 $x354 (or $x499))))
(let (($x337 (or $x6 false (or $x734))))
(let (($x443 (or (or $x337 false false) $x44)))
(let (($x495 (or $x443 false)))
(let (($x146 (or $x495 false)))
(let (($x275 (or $x146 $x2656 (or (and (distinct (bvadd ((_ sign_extend 1) ?x235) ((_ sign_extend 1) ?x606)) ?x219) true)))))
(let (($x1864 (or $x275 false (or $x79))))
(let (($x402 (or $x1864 false false)))
(and (not $x402) (or $x402 (and (distinct ?x871 ?x871) true))))))))))))))))))))))))))))))))))))
(check-sat)
; query 16: function APCM_inverse_quantization, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 17: function APCM_inverse_quantization, block 7, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x673 (ite (bvsge (_ bv7 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x2665 (not $x2657)))
(and $x2665 (or $x2657 (and (distinct ?x673 ?x673) true))))))))
(check-sat)
; query 18: function APCM_inverse_quantization, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in80_64 () (_ BitVec 64))
(assert
 (let ((?x506 (ite (bvslt (_ bv0 64) in80_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x506 ?x506) true)))))))
(check-sat)
; query 19: function APCM_inverse_quantization, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in80_64 () (_ BitVec 64))
(assert
 (let ((?x506 (ite (bvslt (_ bv0 64) in80_64) (_ bv1 1) (_ bv0 1))))
(let ((?x148 ((_ zero_extend 63) ?x506)))
(let (($x89 (or false false false)))
(let (($x56 (or $x89 false)))
(let (($x257 (not $x56)))
(and $x257 (or $x56 (and (distinct ?x148 ?x148) true)))))))))
(check-sat)
; query 20: function APCM_inverse_quantization, block 83, name %86
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in80_64 () (_ BitVec 64))
(assert
 (let ((?x506 (ite (bvslt (_ bv0 64) in80_64) (_ bv1 1) (_ bv0 1))))
(let (($x81 (= (_ bv1 1) ?x506)))
(let ((?x1534 (ite $x81 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x89 (or false false false)))
(let (($x1699 (or $x89 (ite $x81 false false))))
(and (not $x1699) (or $x1699 (and (distinct ?x1534 ?x1534) true)))))))))
(check-sat)
; query 21: function APCM_inverse_quantization, block 83, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in80_64 () (_ BitVec 64))
(assert
 (let ((?x506 (ite (bvslt (_ bv0 64) in80_64) (_ bv1 1) (_ bv0 1))))
(let (($x81 (= (_ bv1 1) ?x506)))
(let ((?x1534 (ite $x81 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x69 ((_ sign_extend 32) ?x1534)))
(let (($x89 (or false false false)))
(let (($x1699 (or $x89 (ite $x81 false false))))
(let (($x501 (or $x1699 false)))
(and (not $x501) (or $x501 (and (distinct ?x69 ?x69) true)))))))))))
(check-sat)
; query 22: function APCM_inverse_quantization, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 23: function APCM_inverse_quantization, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x633 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x2665 (not $x2657)))
(and $x2665 (or $x2657 (and (distinct ?x633 ?x633) true))))))))
(check-sat)
; query 24: function APCM_quantization_xmaxc_to_exp_mant, block 24, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 16) in.0_16) ((_ sign_extend 16) in.0_16)) true))))))
(check-sat)
; query 25: function APCM_quantization_xmaxc_to_exp_mant, block 24, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let ((?x852 ((_ sign_extend 16) in.0_16)))
(let ((?x911 (bvshl ?x852 (_ bv1 32))))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x1365 (or $x2657 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x744 (not $x1365)))
(and $x744 (or $x1365 (and (distinct ?x911 ?x911) true))))))))))
(check-sat)
; query 26: function APCM_quantization_xmaxc_to_exp_mant, block 24, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let ((?x852 ((_ sign_extend 16) in.0_16)))
(let ((?x911 (bvshl ?x852 (_ bv1 32))))
(let ((?x890 (bvor ?x911 (_ bv1 32))))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x1365 (or $x2657 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x59 (or $x1365 false false)))
(and (not $x59) (or $x59 (and (distinct ?x890 ?x890) true)))))))))))
(check-sat)
; query 27: function APCM_quantization_xmaxc_to_exp_mant, block 24, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let ((?x852 ((_ sign_extend 16) in.0_16)))
(let ((?x911 (bvshl ?x852 (_ bv1 32))))
(let ((?x890 (bvor ?x911 (_ bv1 32))))
(let ((?x769 ((_ extract 15 0) ?x890)))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x1365 (or $x2657 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x59 (or $x1365 false false)))
(let (($x1190 (or $x59 false)))
(and (not $x1190) (or $x1190 (and (distinct ?x769 ?x769) true)))))))))))))
(check-sat)
; query 28: function APCM_quantization_xmaxc_to_exp_mant, block 24, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_16 () (_ BitVec 16))
(assert
 (let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct (bvadd in.12_16 (_ bv65535 16)) (bvadd in.12_16 (_ bv65535 16))) true))))))
(check-sat)
; query 29: function APCM_quantization_xmaxc_to_exp_mant, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 16) in.2_16) ((_ sign_extend 16) in.2_16)) true))))))
(check-sat)
; query 30: function APCM_quantization_xmaxc_to_exp_mant, block 37, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_16 () (_ BitVec 16))
(assert
 (let ((?x1266 (ite (bvsge (_ bv6 32) ((_ sign_extend 16) in.2_16)) (_ bv1 1) (_ bv0 1))))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x2665 (not $x2657)))
(and $x2665 (or $x2657 (and (distinct ?x1266 ?x1266) true))))))))
(check-sat)
; query 31: function APCM_quantization_xmaxc_to_exp_mant, block 49, name %50
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 32: function APCM_quantization_xmaxc_to_exp_mant, block 49, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x438 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in.1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x2665 (not $x2657)))
(and $x2665 (or $x2657 (and (distinct ?x438 ?x438) true))))))))
(check-sat)
; query 33: function APCM_quantization_xmaxc_to_exp_mant, block 52, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 34: function APCM_quantization_xmaxc_to_exp_mant, block 52, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x537 (ite (bvsge (_ bv7 32) ((_ sign_extend 16) in.1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x2665 (not $x2657)))
(and $x2665 (or $x2657 (and (distinct ?x537 ?x537) true))))))))
(check-sat)
; query 35: function APCM_quantization_xmaxc_to_exp_mant, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1195 ((_ sign_extend 16) in0_16)))
(let ((?x1334 (bvashr ?x1195 (_ bv3 32))))
(let ((?x188 (bvsub ?x1334 (_ bv1 32))))
(let ((?x659 ((_ extract 15 0) ?x188)))
(let (($x1600 (and (distinct (bvsub ((_ sign_extend 1) ?x1334) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x188)) true)))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x1162 (or $x2657 (bvuge (_ bv3 32) (_ bv32 32)))))
(let (($x125 (or $x1162 false (or $x1600))))
(let (($x645 (or $x125 false)))
(and (not $x645) (or $x645 (and (distinct ?x659 ?x659) true))))))))))))))
(check-sat)
; query 36: function APCM_quantization_xmaxc_to_exp_mant, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 37: function APCM_quantization_xmaxc_to_exp_mant, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1195 ((_ sign_extend 16) in0_16)))
(let ((?x1334 (bvashr ?x1195 (_ bv3 32))))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x1162 (or $x2657 (bvuge (_ bv3 32) (_ bv32 32)))))
(and (not $x1162) (or $x1162 (and (distinct ?x1334 ?x1334) true)))))))))
(check-sat)
; query 38: function APCM_quantization_xmaxc_to_exp_mant, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1195 ((_ sign_extend 16) in0_16)))
(let ((?x1334 (bvashr ?x1195 (_ bv3 32))))
(let ((?x188 (bvsub ?x1334 (_ bv1 32))))
(let (($x1600 (and (distinct (bvsub ((_ sign_extend 1) ?x1334) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x188)) true)))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x1162 (or $x2657 (bvuge (_ bv3 32) (_ bv32 32)))))
(let (($x125 (or $x1162 false (or $x1600))))
(and (not $x125) (or $x125 (and (distinct ?x188 ?x188) true))))))))))))
(check-sat)
; query 39: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 40: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x813 (ite (bvslt (_ bv15 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x2665 (not $x2657)))
(and $x2665 (or $x2657 (and (distinct ?x813 ?x813) true))))))))
(check-sat)
; query 41: function Decoding_of_the_coded_Log_Area_Ratios, block 107, name %108
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in104_64 () (_ BitVec 64))
(assert
 (let ((?x170 (ite (bvslt (_ bv0 64) in104_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x170 ?x170) true)))))))
(check-sat)
; query 42: function Decoding_of_the_coded_Log_Area_Ratios, block 107, name %109
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in104_64 () (_ BitVec 64))
(assert
 (let ((?x170 (ite (bvslt (_ bv0 64) in104_64) (_ bv1 1) (_ bv0 1))))
(let ((?x360 ((_ zero_extend 63) ?x170)))
(let (($x89 (or false false false)))
(let (($x56 (or $x89 false)))
(let (($x257 (not $x56)))
(and $x257 (or $x56 (and (distinct ?x360 ?x360) true)))))))))
(check-sat)
; query 43: function Decoding_of_the_coded_Log_Area_Ratios, block 107, name %110
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in104_64 () (_ BitVec 64))
(assert
 (let ((?x170 (ite (bvslt (_ bv0 64) in104_64) (_ bv1 1) (_ bv0 1))))
(let (($x2089 (= (_ bv1 1) ?x170)))
(let ((?x1588 (ite $x2089 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x89 (or false false false)))
(let (($x419 (or $x89 (ite $x2089 false false))))
(and (not $x419) (or $x419 (and (distinct ?x1588 ?x1588) true)))))))))
(check-sat)
; query 44: function Decoding_of_the_coded_Log_Area_Ratios, block 107, name %111
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in104_64 () (_ BitVec 64))
(assert
 (let ((?x170 (ite (bvslt (_ bv0 64) in104_64) (_ bv1 1) (_ bv0 1))))
(let (($x2089 (= (_ bv1 1) ?x170)))
(let ((?x1588 (ite $x2089 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x57 ((_ sign_extend 32) ?x1588)))
(let (($x89 (or false false false)))
(let (($x419 (or $x89 (ite $x2089 false false))))
(let (($x946 (or $x419 false)))
(and (not $x946) (or $x946 (and (distinct ?x57 ?x57) true)))))))))))
(check-sat)
; query 45: function Decoding_of_the_coded_Log_Area_Ratios, block 121, name %122
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in118_64 () (_ BitVec 64))
(assert
 (let ((?x1441 (ite (bvsge (_ bv18446744073709518848 64) in118_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x1441 ?x1441) true)))))))
(check-sat)
; query 46: function Decoding_of_the_coded_Log_Area_Ratios, block 140, name %141
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in137_64 () (_ BitVec 64))
(assert
 (let ((?x278 (ite (bvslt (_ bv0 64) in137_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x278 ?x278) true)))))))
(check-sat)
; query 47: function Decoding_of_the_coded_Log_Area_Ratios, block 140, name %142
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in137_64 () (_ BitVec 64))
(assert
 (let ((?x278 (ite (bvslt (_ bv0 64) in137_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1379 ((_ zero_extend 63) ?x278)))
(let (($x89 (or false false false)))
(let (($x56 (or $x89 false)))
(let (($x257 (not $x56)))
(and $x257 (or $x56 (and (distinct ?x1379 ?x1379) true)))))))))
(check-sat)
; query 48: function Decoding_of_the_coded_Log_Area_Ratios, block 140, name %143
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in137_64 () (_ BitVec 64))
(assert
 (let ((?x278 (ite (bvslt (_ bv0 64) in137_64) (_ bv1 1) (_ bv0 1))))
(let (($x189 (= (_ bv1 1) ?x278)))
(let ((?x1212 (ite $x189 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x89 (or false false false)))
(let (($x1524 (or $x89 (ite $x189 false false))))
(and (not $x1524) (or $x1524 (and (distinct ?x1212 ?x1212) true)))))))))
(check-sat)
; query 49: function Decoding_of_the_coded_Log_Area_Ratios, block 140, name %144
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in137_64 () (_ BitVec 64))
(assert
 (let ((?x278 (ite (bvslt (_ bv0 64) in137_64) (_ bv1 1) (_ bv0 1))))
(let (($x189 (= (_ bv1 1) ?x278)))
(let ((?x1212 (ite $x189 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x1174 ((_ sign_extend 32) ?x1212)))
(let (($x89 (or false false false)))
(let (($x1524 (or $x89 (ite $x189 false false))))
(let (($x1017 (or $x1524 false)))
(and (not $x1017) (or $x1017 (and (distinct ?x1174 ?x1174) true)))))))))))
(check-sat)
; query 50: function Decoding_of_the_coded_Log_Area_Ratios, block 156, name %157
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in153_64 () (_ BitVec 64))
(assert
 (let ((?x897 (ite (bvslt (_ bv0 64) in153_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x897 ?x897) true)))))))
(check-sat)
; query 51: function Decoding_of_the_coded_Log_Area_Ratios, block 156, name %158
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in153_64 () (_ BitVec 64))
(assert
 (let ((?x897 (ite (bvslt (_ bv0 64) in153_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1866 ((_ zero_extend 63) ?x897)))
(let (($x89 (or false false false)))
(let (($x56 (or $x89 false)))
(let (($x257 (not $x56)))
(and $x257 (or $x56 (and (distinct ?x1866 ?x1866) true)))))))))
(check-sat)
; query 52: function Decoding_of_the_coded_Log_Area_Ratios, block 156, name %159
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in153_64 () (_ BitVec 64))
(assert
 (let ((?x897 (ite (bvslt (_ bv0 64) in153_64) (_ bv1 1) (_ bv0 1))))
(let (($x1850 (= (_ bv1 1) ?x897)))
(let ((?x1848 (ite $x1850 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x89 (or false false false)))
(let (($x391 (or $x89 (ite $x1850 false false))))
(and (not $x391) (or $x391 (and (distinct ?x1848 ?x1848) true)))))))))
(check-sat)
; query 53: function Decoding_of_the_coded_Log_Area_Ratios, block 156, name %160
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in153_64 () (_ BitVec 64))
(assert
 (let ((?x897 (ite (bvslt (_ bv0 64) in153_64) (_ bv1 1) (_ bv0 1))))
(let (($x1850 (= (_ bv1 1) ?x897)))
(let ((?x1848 (ite $x1850 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x1436 ((_ sign_extend 32) ?x1848)))
(let (($x89 (or false false false)))
(let (($x391 (or $x89 (ite $x1850 false false))))
(let (($x1060 (or $x391 false)))
(and (not $x1060) (or $x1060 (and (distinct ?x1436 ?x1436) true)))))))))))
(check-sat)
; query 54: function Decoding_of_the_coded_Log_Area_Ratios, block 170, name %171
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in167_64 () (_ BitVec 64))
(assert
 (let ((?x828 (ite (bvsge (_ bv18446744073709518848 64) in167_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x828 ?x828) true)))))))
(check-sat)
; query 55: function Decoding_of_the_coded_Log_Area_Ratios, block 189, name %190
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in186_64 () (_ BitVec 64))
(assert
 (let ((?x726 (ite (bvslt (_ bv0 64) in186_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x726 ?x726) true)))))))
(check-sat)
; query 56: function Decoding_of_the_coded_Log_Area_Ratios, block 189, name %191
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in186_64 () (_ BitVec 64))
(assert
 (let ((?x726 (ite (bvslt (_ bv0 64) in186_64) (_ bv1 1) (_ bv0 1))))
(let ((?x600 ((_ zero_extend 63) ?x726)))
(let (($x89 (or false false false)))
(let (($x56 (or $x89 false)))
(let (($x257 (not $x56)))
(and $x257 (or $x56 (and (distinct ?x600 ?x600) true)))))))))
(check-sat)
; query 57: function Decoding_of_the_coded_Log_Area_Ratios, block 189, name %192
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in186_64 () (_ BitVec 64))
(assert
 (let ((?x726 (ite (bvslt (_ bv0 64) in186_64) (_ bv1 1) (_ bv0 1))))
(let (($x47 (= (_ bv1 1) ?x726)))
(let ((?x1045 (ite $x47 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x89 (or false false false)))
(let (($x284 (or $x89 (ite $x47 false false))))
(and (not $x284) (or $x284 (and (distinct ?x1045 ?x1045) true)))))))))
(check-sat)
; query 58: function Decoding_of_the_coded_Log_Area_Ratios, block 189, name %193
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in186_64 () (_ BitVec 64))
(assert
 (let ((?x726 (ite (bvslt (_ bv0 64) in186_64) (_ bv1 1) (_ bv0 1))))
(let (($x47 (= (_ bv1 1) ?x726)))
(let ((?x1045 (ite $x47 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x1981 ((_ sign_extend 32) ?x1045)))
(let (($x89 (or false false false)))
(let (($x284 (or $x89 (ite $x47 false false))))
(let (($x1971 (or $x284 false)))
(and (not $x1971) (or $x1971 (and (distinct ?x1981 ?x1981) true)))))))))))
(check-sat)
; query 59: function Decoding_of_the_coded_Log_Area_Ratios, block 205, name %206
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in202_64 () (_ BitVec 64))
(assert
 (let ((?x259 (ite (bvslt (_ bv0 64) in202_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x259 ?x259) true)))))))
(check-sat)
; query 60: function Decoding_of_the_coded_Log_Area_Ratios, block 205, name %207
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in202_64 () (_ BitVec 64))
(assert
 (let ((?x259 (ite (bvslt (_ bv0 64) in202_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1938 ((_ zero_extend 63) ?x259)))
(let (($x89 (or false false false)))
(let (($x56 (or $x89 false)))
(let (($x257 (not $x56)))
(and $x257 (or $x56 (and (distinct ?x1938 ?x1938) true)))))))))
(check-sat)
; query 61: function Decoding_of_the_coded_Log_Area_Ratios, block 205, name %208
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in202_64 () (_ BitVec 64))
(assert
 (let ((?x259 (ite (bvslt (_ bv0 64) in202_64) (_ bv1 1) (_ bv0 1))))
(let (($x1936 (= (_ bv1 1) ?x259)))
(let ((?x1625 (ite $x1936 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x89 (or false false false)))
(let (($x241 (or $x89 (ite $x1936 false false))))
(and (not $x241) (or $x241 (and (distinct ?x1625 ?x1625) true)))))))))
(check-sat)
; query 62: function Decoding_of_the_coded_Log_Area_Ratios, block 205, name %209
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in202_64 () (_ BitVec 64))
(assert
 (let ((?x259 (ite (bvslt (_ bv0 64) in202_64) (_ bv1 1) (_ bv0 1))))
(let (($x1936 (= (_ bv1 1) ?x259)))
(let ((?x1625 (ite $x1936 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x1819 ((_ sign_extend 32) ?x1625)))
(let (($x89 (or false false false)))
(let (($x241 (or $x89 (ite $x1936 false false))))
(let (($x109 (or $x241 false)))
(and (not $x109) (or $x109 (and (distinct ?x1819 ?x1819) true)))))))))))
(check-sat)
; query 63: function Decoding_of_the_coded_Log_Area_Ratios, block 219, name %220
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in216_64 () (_ BitVec 64))
(assert
 (let ((?x861 (ite (bvsge (_ bv18446744073709518848 64) in216_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x861 ?x861) true)))))))
(check-sat)
; query 64: function Decoding_of_the_coded_Log_Area_Ratios, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in20_64 () (_ BitVec 64))
(assert
 (let ((?x1982 (ite (bvsge (_ bv18446744073709518848 64) in20_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x1982 ?x1982) true)))))))
(check-sat)
; query 65: function Decoding_of_the_coded_Log_Area_Ratios, block 238, name %239
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in235_64 () (_ BitVec 64))
(assert
 (let ((?x623 (ite (bvslt (_ bv0 64) in235_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x623 ?x623) true)))))))
(check-sat)
; query 66: function Decoding_of_the_coded_Log_Area_Ratios, block 238, name %240
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in235_64 () (_ BitVec 64))
(assert
 (let ((?x623 (ite (bvslt (_ bv0 64) in235_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1993 ((_ zero_extend 63) ?x623)))
(let (($x89 (or false false false)))
(let (($x56 (or $x89 false)))
(let (($x257 (not $x56)))
(and $x257 (or $x56 (and (distinct ?x1993 ?x1993) true)))))))))
(check-sat)
; query 67: function Decoding_of_the_coded_Log_Area_Ratios, block 238, name %241
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in235_64 () (_ BitVec 64))
(assert
 (let ((?x623 (ite (bvslt (_ bv0 64) in235_64) (_ bv1 1) (_ bv0 1))))
(let (($x978 (= (_ bv1 1) ?x623)))
(let ((?x1995 (ite $x978 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x89 (or false false false)))
(let (($x106 (or $x89 (ite $x978 false false))))
(and (not $x106) (or $x106 (and (distinct ?x1995 ?x1995) true)))))))))
(check-sat)
; query 68: function Decoding_of_the_coded_Log_Area_Ratios, block 238, name %242
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in235_64 () (_ BitVec 64))
(assert
 (let ((?x623 (ite (bvslt (_ bv0 64) in235_64) (_ bv1 1) (_ bv0 1))))
(let (($x978 (= (_ bv1 1) ?x623)))
(let ((?x1995 (ite $x978 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x1087 ((_ sign_extend 32) ?x1995)))
(let (($x89 (or false false false)))
(let (($x106 (or $x89 (ite $x978 false false))))
(let (($x893 (or $x106 false)))
(and (not $x893) (or $x893 (and (distinct ?x1087 ?x1087) true)))))))))))
(check-sat)
; query 69: function Decoding_of_the_coded_Log_Area_Ratios, block 254, name %255
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in251_64 () (_ BitVec 64))
(assert
 (let ((?x1341 (ite (bvslt (_ bv0 64) in251_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x1341 ?x1341) true)))))))
(check-sat)
; query 70: function Decoding_of_the_coded_Log_Area_Ratios, block 254, name %256
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in251_64 () (_ BitVec 64))
(assert
 (let ((?x1341 (ite (bvslt (_ bv0 64) in251_64) (_ bv1 1) (_ bv0 1))))
(let ((?x868 ((_ zero_extend 63) ?x1341)))
(let (($x89 (or false false false)))
(let (($x56 (or $x89 false)))
(let (($x257 (not $x56)))
(and $x257 (or $x56 (and (distinct ?x868 ?x868) true)))))))))
(check-sat)
; query 71: function Decoding_of_the_coded_Log_Area_Ratios, block 254, name %257
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in251_64 () (_ BitVec 64))
(assert
 (let ((?x1341 (ite (bvslt (_ bv0 64) in251_64) (_ bv1 1) (_ bv0 1))))
(let (($x209 (= (_ bv1 1) ?x1341)))
(let ((?x1466 (ite $x209 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x89 (or false false false)))
(let (($x669 (or $x89 (ite $x209 false false))))
(and (not $x669) (or $x669 (and (distinct ?x1466 ?x1466) true)))))))))
(check-sat)
; query 72: function Decoding_of_the_coded_Log_Area_Ratios, block 254, name %258
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in251_64 () (_ BitVec 64))
(assert
 (let ((?x1341 (ite (bvslt (_ bv0 64) in251_64) (_ bv1 1) (_ bv0 1))))
(let (($x209 (= (_ bv1 1) ?x1341)))
(let ((?x1466 (ite $x209 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x1918 ((_ sign_extend 32) ?x1466)))
(let (($x89 (or false false false)))
(let (($x669 (or $x89 (ite $x209 false false))))
(let (($x1860 (or $x669 false)))
(and (not $x1860) (or $x1860 (and (distinct ?x1918 ?x1918) true)))))))))))
(check-sat)
; query 73: function Decoding_of_the_coded_Log_Area_Ratios, block 268, name %269
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in265_64 () (_ BitVec 64))
(assert
 (let ((?x1452 (ite (bvsge (_ bv18446744073709518848 64) in265_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x1452 ?x1452) true)))))))
(check-sat)
; query 74: function Decoding_of_the_coded_Log_Area_Ratios, block 287, name %288
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in284_64 () (_ BitVec 64))
(assert
 (let ((?x1916 (ite (bvslt (_ bv0 64) in284_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x1916 ?x1916) true)))))))
(check-sat)
; query 75: function Decoding_of_the_coded_Log_Area_Ratios, block 287, name %289
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in284_64 () (_ BitVec 64))
(assert
 (let ((?x1916 (ite (bvslt (_ bv0 64) in284_64) (_ bv1 1) (_ bv0 1))))
(let ((?x490 ((_ zero_extend 63) ?x1916)))
(let (($x89 (or false false false)))
(let (($x56 (or $x89 false)))
(let (($x257 (not $x56)))
(and $x257 (or $x56 (and (distinct ?x490 ?x490) true)))))))))
(check-sat)
; query 76: function Decoding_of_the_coded_Log_Area_Ratios, block 287, name %290
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in284_64 () (_ BitVec 64))
(assert
 (let ((?x1916 (ite (bvslt (_ bv0 64) in284_64) (_ bv1 1) (_ bv0 1))))
(let (($x619 (= (_ bv1 1) ?x1916)))
(let ((?x770 (ite $x619 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x89 (or false false false)))
(let (($x55 (or $x89 (ite $x619 false false))))
(and (not $x55) (or $x55 (and (distinct ?x770 ?x770) true)))))))))
(check-sat)
; query 77: function Decoding_of_the_coded_Log_Area_Ratios, block 287, name %291
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in284_64 () (_ BitVec 64))
(assert
 (let ((?x1916 (ite (bvslt (_ bv0 64) in284_64) (_ bv1 1) (_ bv0 1))))
(let (($x619 (= (_ bv1 1) ?x1916)))
(let ((?x770 (ite $x619 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x737 ((_ sign_extend 32) ?x770)))
(let (($x89 (or false false false)))
(let (($x55 (or $x89 (ite $x619 false false))))
(let (($x1617 (or $x55 false)))
(and (not $x1617) (or $x1617 (and (distinct ?x737 ?x737) true)))))))))))
(check-sat)
; query 78: function Decoding_of_the_coded_Log_Area_Ratios, block 303, name %304
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in300_64 () (_ BitVec 64))
(assert
 (let ((?x1287 (ite (bvslt (_ bv0 64) in300_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x1287 ?x1287) true)))))))
(check-sat)
; query 79: function Decoding_of_the_coded_Log_Area_Ratios, block 303, name %305
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in300_64 () (_ BitVec 64))
(assert
 (let ((?x1287 (ite (bvslt (_ bv0 64) in300_64) (_ bv1 1) (_ bv0 1))))
(let ((?x2013 ((_ zero_extend 63) ?x1287)))
(let (($x89 (or false false false)))
(let (($x56 (or $x89 false)))
(let (($x257 (not $x56)))
(and $x257 (or $x56 (and (distinct ?x2013 ?x2013) true)))))))))
(check-sat)
; query 80: function Decoding_of_the_coded_Log_Area_Ratios, block 303, name %306
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in300_64 () (_ BitVec 64))
(assert
 (let ((?x1287 (ite (bvslt (_ bv0 64) in300_64) (_ bv1 1) (_ bv0 1))))
(let (($x482 (= (_ bv1 1) ?x1287)))
(let ((?x1304 (ite $x482 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x89 (or false false false)))
(let (($x784 (or $x89 (ite $x482 false false))))
(and (not $x784) (or $x784 (and (distinct ?x1304 ?x1304) true)))))))))
(check-sat)
; query 81: function Decoding_of_the_coded_Log_Area_Ratios, block 303, name %307
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in300_64 () (_ BitVec 64))
(assert
 (let ((?x1287 (ite (bvslt (_ bv0 64) in300_64) (_ bv1 1) (_ bv0 1))))
(let (($x482 (= (_ bv1 1) ?x1287)))
(let ((?x1304 (ite $x482 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x1300 ((_ sign_extend 32) ?x1304)))
(let (($x89 (or false false false)))
(let (($x784 (or $x89 (ite $x482 false false))))
(let (($x1312 (or $x784 false)))
(and (not $x1312) (or $x1312 (and (distinct ?x1300 ?x1300) true)))))))))))
(check-sat)
; query 82: function Decoding_of_the_coded_Log_Area_Ratios, block 317, name %318
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in314_64 () (_ BitVec 64))
(assert
 (let ((?x139 (ite (bvsge (_ bv18446744073709518848 64) in314_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x139 ?x139) true)))))))
(check-sat)
; query 83: function Decoding_of_the_coded_Log_Area_Ratios, block 336, name %337
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in333_64 () (_ BitVec 64))
(assert
 (let ((?x1147 (ite (bvslt (_ bv0 64) in333_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x1147 ?x1147) true)))))))
(check-sat)
; query 84: function Decoding_of_the_coded_Log_Area_Ratios, block 336, name %338
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in333_64 () (_ BitVec 64))
(assert
 (let ((?x1147 (ite (bvslt (_ bv0 64) in333_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1423 ((_ zero_extend 63) ?x1147)))
(let (($x89 (or false false false)))
(let (($x56 (or $x89 false)))
(let (($x257 (not $x56)))
(and $x257 (or $x56 (and (distinct ?x1423 ?x1423) true)))))))))
(check-sat)
; query 85: function Decoding_of_the_coded_Log_Area_Ratios, block 336, name %339
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in333_64 () (_ BitVec 64))
(assert
 (let ((?x1147 (ite (bvslt (_ bv0 64) in333_64) (_ bv1 1) (_ bv0 1))))
(let (($x1255 (= (_ bv1 1) ?x1147)))
(let ((?x93 (ite $x1255 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x89 (or false false false)))
(let (($x612 (or $x89 (ite $x1255 false false))))
(and (not $x612) (or $x612 (and (distinct ?x93 ?x93) true)))))))))
(check-sat)
; query 86: function Decoding_of_the_coded_Log_Area_Ratios, block 336, name %340
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in333_64 () (_ BitVec 64))
(assert
 (let ((?x1147 (ite (bvslt (_ bv0 64) in333_64) (_ bv1 1) (_ bv0 1))))
(let (($x1255 (= (_ bv1 1) ?x1147)))
(let ((?x93 (ite $x1255 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x1220 ((_ sign_extend 32) ?x93)))
(let (($x89 (or false false false)))
(let (($x612 (or $x89 (ite $x1255 false false))))
(let (($x1913 (or $x612 false)))
(and (not $x1913) (or $x1913 (and (distinct ?x1220 ?x1220) true)))))))))))
(check-sat)
; query 87: function Decoding_of_the_coded_Log_Area_Ratios, block 352, name %353
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in349_64 () (_ BitVec 64))
(assert
 (let ((?x719 (ite (bvslt (_ bv0 64) in349_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x719 ?x719) true)))))))
(check-sat)
; query 88: function Decoding_of_the_coded_Log_Area_Ratios, block 352, name %354
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in349_64 () (_ BitVec 64))
(assert
 (let ((?x719 (ite (bvslt (_ bv0 64) in349_64) (_ bv1 1) (_ bv0 1))))
(let ((?x2098 ((_ zero_extend 63) ?x719)))
(let (($x89 (or false false false)))
(let (($x56 (or $x89 false)))
(let (($x257 (not $x56)))
(and $x257 (or $x56 (and (distinct ?x2098 ?x2098) true)))))))))
(check-sat)
; query 89: function Decoding_of_the_coded_Log_Area_Ratios, block 352, name %355
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in349_64 () (_ BitVec 64))
(assert
 (let ((?x719 (ite (bvslt (_ bv0 64) in349_64) (_ bv1 1) (_ bv0 1))))
(let (($x1134 (= (_ bv1 1) ?x719)))
(let ((?x1465 (ite $x1134 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x89 (or false false false)))
(let (($x931 (or $x89 (ite $x1134 false false))))
(and (not $x931) (or $x931 (and (distinct ?x1465 ?x1465) true)))))))))
(check-sat)
; query 90: function Decoding_of_the_coded_Log_Area_Ratios, block 352, name %356
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in349_64 () (_ BitVec 64))
(assert
 (let ((?x719 (ite (bvslt (_ bv0 64) in349_64) (_ bv1 1) (_ bv0 1))))
(let (($x1134 (= (_ bv1 1) ?x719)))
(let ((?x1465 (ite $x1134 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x1030 ((_ sign_extend 32) ?x1465)))
(let (($x89 (or false false false)))
(let (($x931 (or $x89 (ite $x1134 false false))))
(let (($x749 (or $x931 false)))
(and (not $x749) (or $x749 (and (distinct ?x1030 ?x1030) true)))))))))))
(check-sat)
; query 91: function Decoding_of_the_coded_Log_Area_Ratios, block 366, name %367
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in363_64 () (_ BitVec 64))
(assert
 (let ((?x894 (ite (bvsge (_ bv18446744073709518848 64) in363_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x894 ?x894) true)))))))
(check-sat)
; query 92: function Decoding_of_the_coded_Log_Area_Ratios, block 385, name %386
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in382_64 () (_ BitVec 64))
(assert
 (let ((?x503 (ite (bvslt (_ bv0 64) in382_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x503 ?x503) true)))))))
(check-sat)
; query 93: function Decoding_of_the_coded_Log_Area_Ratios, block 385, name %387
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in382_64 () (_ BitVec 64))
(assert
 (let ((?x503 (ite (bvslt (_ bv0 64) in382_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1867 ((_ zero_extend 63) ?x503)))
(let (($x89 (or false false false)))
(let (($x56 (or $x89 false)))
(let (($x257 (not $x56)))
(and $x257 (or $x56 (and (distinct ?x1867 ?x1867) true)))))))))
(check-sat)
; query 94: function Decoding_of_the_coded_Log_Area_Ratios, block 385, name %388
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in382_64 () (_ BitVec 64))
(assert
 (let ((?x503 (ite (bvslt (_ bv0 64) in382_64) (_ bv1 1) (_ bv0 1))))
(let (($x1907 (= (_ bv1 1) ?x503)))
(let ((?x324 (ite $x1907 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x89 (or false false false)))
(let (($x493 (or $x89 (ite $x1907 false false))))
(and (not $x493) (or $x493 (and (distinct ?x324 ?x324) true)))))))))
(check-sat)
; query 95: function Decoding_of_the_coded_Log_Area_Ratios, block 385, name %389
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in382_64 () (_ BitVec 64))
(assert
 (let ((?x503 (ite (bvslt (_ bv0 64) in382_64) (_ bv1 1) (_ bv0 1))))
(let (($x1907 (= (_ bv1 1) ?x503)))
(let ((?x324 (ite $x1907 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x1773 ((_ sign_extend 32) ?x324)))
(let (($x89 (or false false false)))
(let (($x493 (or $x89 (ite $x1907 false false))))
(let (($x58 (or $x493 false)))
(and (not $x58) (or $x58 (and (distinct ?x1773 ?x1773) true)))))))))))
(check-sat)
; query 96: function Decoding_of_the_coded_Log_Area_Ratios, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in39_64 () (_ BitVec 64))
(assert
 (let ((?x1252 (ite (bvslt (_ bv0 64) in39_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x1252 ?x1252) true)))))))
(check-sat)
; query 97: function Decoding_of_the_coded_Log_Area_Ratios, block 42, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in39_64 () (_ BitVec 64))
(assert
 (let ((?x1252 (ite (bvslt (_ bv0 64) in39_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1194 ((_ zero_extend 63) ?x1252)))
(let (($x89 (or false false false)))
(let (($x56 (or $x89 false)))
(let (($x257 (not $x56)))
(and $x257 (or $x56 (and (distinct ?x1194 ?x1194) true)))))))))
(check-sat)
; query 98: function Decoding_of_the_coded_Log_Area_Ratios, block 42, name %45
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in39_64 () (_ BitVec 64))
(assert
 (let ((?x1252 (ite (bvslt (_ bv0 64) in39_64) (_ bv1 1) (_ bv0 1))))
(let (($x211 (= (_ bv1 1) ?x1252)))
(let ((?x127 (ite $x211 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x89 (or false false false)))
(let (($x422 (or $x89 (ite $x211 false false))))
(and (not $x422) (or $x422 (and (distinct ?x127 ?x127) true)))))))))
(check-sat)
; query 99: function Decoding_of_the_coded_Log_Area_Ratios, block 42, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in39_64 () (_ BitVec 64))
(assert
 (let ((?x1252 (ite (bvslt (_ bv0 64) in39_64) (_ bv1 1) (_ bv0 1))))
(let (($x211 (= (_ bv1 1) ?x1252)))
(let ((?x127 (ite $x211 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x413 ((_ sign_extend 32) ?x127)))
(let (($x89 (or false false false)))
(let (($x422 (or $x89 (ite $x211 false false))))
(let (($x1455 (or $x422 false)))
(and (not $x1455) (or $x1455 (and (distinct ?x413 ?x413) true)))))))))))
(check-sat)
; query 100: function Decoding_of_the_coded_Log_Area_Ratios, block 58, name %59
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in55_64 () (_ BitVec 64))
(assert
 (let ((?x1207 (ite (bvslt (_ bv0 64) in55_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x1207 ?x1207) true)))))))
(check-sat)
; query 101: function Decoding_of_the_coded_Log_Area_Ratios, block 58, name %60
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in55_64 () (_ BitVec 64))
(assert
 (let ((?x1207 (ite (bvslt (_ bv0 64) in55_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1788 ((_ zero_extend 63) ?x1207)))
(let (($x89 (or false false false)))
(let (($x56 (or $x89 false)))
(let (($x257 (not $x56)))
(and $x257 (or $x56 (and (distinct ?x1788 ?x1788) true)))))))))
(check-sat)
; query 102: function Decoding_of_the_coded_Log_Area_Ratios, block 58, name %61
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in55_64 () (_ BitVec 64))
(assert
 (let ((?x1207 (ite (bvslt (_ bv0 64) in55_64) (_ bv1 1) (_ bv0 1))))
(let (($x2100 (= (_ bv1 1) ?x1207)))
(let ((?x205 (ite $x2100 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x89 (or false false false)))
(let (($x919 (or $x89 (ite $x2100 false false))))
(and (not $x919) (or $x919 (and (distinct ?x205 ?x205) true)))))))))
(check-sat)
; query 103: function Decoding_of_the_coded_Log_Area_Ratios, block 58, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in55_64 () (_ BitVec 64))
(assert
 (let ((?x1207 (ite (bvslt (_ bv0 64) in55_64) (_ bv1 1) (_ bv0 1))))
(let (($x2100 (= (_ bv1 1) ?x1207)))
(let ((?x205 (ite $x2100 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x1748 ((_ sign_extend 32) ?x205)))
(let (($x89 (or false false false)))
(let (($x919 (or $x89 (ite $x2100 false false))))
(let (($x1457 (or $x919 false)))
(and (not $x1457) (or $x1457 (and (distinct ?x1748 ?x1748) true)))))))))))
(check-sat)
; query 104: function Decoding_of_the_coded_Log_Area_Ratios, block 72, name %73
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in69_64 () (_ BitVec 64))
(assert
 (let ((?x2007 (ite (bvsge (_ bv18446744073709518848 64) in69_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x2007 ?x2007) true)))))))
(check-sat)
; query 105: function Decoding_of_the_coded_Log_Area_Ratios, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in6_64 () (_ BitVec 64))
(assert
 (let ((?x1170 (ite (bvslt (_ bv0 64) in6_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x1170 ?x1170) true)))))))
(check-sat)
; query 106: function Decoding_of_the_coded_Log_Area_Ratios, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in6_64 () (_ BitVec 64))
(assert
 (let ((?x1170 (ite (bvslt (_ bv0 64) in6_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1218 ((_ zero_extend 63) ?x1170)))
(let (($x89 (or false false false)))
(let (($x56 (or $x89 false)))
(let (($x257 (not $x56)))
(and $x257 (or $x56 (and (distinct ?x1218 ?x1218) true)))))))))
(check-sat)
; query 107: function Decoding_of_the_coded_Log_Area_Ratios, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in6_64 () (_ BitVec 64))
(assert
 (let ((?x1170 (ite (bvslt (_ bv0 64) in6_64) (_ bv1 1) (_ bv0 1))))
(let (($x906 (= (_ bv1 1) ?x1170)))
(let ((?x1760 (ite $x906 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x89 (or false false false)))
(let (($x192 (or $x89 (ite $x906 false false))))
(and (not $x192) (or $x192 (and (distinct ?x1760 ?x1760) true)))))))))
(check-sat)
; query 108: function Decoding_of_the_coded_Log_Area_Ratios, block 9, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in6_64 () (_ BitVec 64))
(assert
 (let ((?x1170 (ite (bvslt (_ bv0 64) in6_64) (_ bv1 1) (_ bv0 1))))
(let (($x906 (= (_ bv1 1) ?x1170)))
(let ((?x1760 (ite $x906 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x1405 ((_ sign_extend 32) ?x1760)))
(let (($x89 (or false false false)))
(let (($x192 (or $x89 (ite $x906 false false))))
(let (($x2031 (or $x192 false)))
(and (not $x2031) (or $x2031 (and (distinct ?x1405 ?x1405) true)))))))))))
(check-sat)
; query 109: function Decoding_of_the_coded_Log_Area_Ratios, block 91, name %92
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in88_64 () (_ BitVec 64))
(assert
 (let ((?x827 (ite (bvslt (_ bv0 64) in88_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x827 ?x827) true)))))))
(check-sat)
; query 110: function Decoding_of_the_coded_Log_Area_Ratios, block 91, name %93
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in88_64 () (_ BitVec 64))
(assert
 (let ((?x827 (ite (bvslt (_ bv0 64) in88_64) (_ bv1 1) (_ bv0 1))))
(let ((?x883 ((_ zero_extend 63) ?x827)))
(let (($x89 (or false false false)))
(let (($x56 (or $x89 false)))
(let (($x257 (not $x56)))
(and $x257 (or $x56 (and (distinct ?x883 ?x883) true)))))))))
(check-sat)
; query 111: function Decoding_of_the_coded_Log_Area_Ratios, block 91, name %94
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in88_64 () (_ BitVec 64))
(assert
 (let ((?x827 (ite (bvslt (_ bv0 64) in88_64) (_ bv1 1) (_ bv0 1))))
(let (($x1121 (= (_ bv1 1) ?x827)))
(let ((?x1872 (ite $x1121 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x89 (or false false false)))
(let (($x1903 (or $x89 (ite $x1121 false false))))
(and (not $x1903) (or $x1903 (and (distinct ?x1872 ?x1872) true)))))))))
(check-sat)
; query 112: function Decoding_of_the_coded_Log_Area_Ratios, block 91, name %95
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in88_64 () (_ BitVec 64))
(assert
 (let ((?x827 (ite (bvslt (_ bv0 64) in88_64) (_ bv1 1) (_ bv0 1))))
(let (($x1121 (= (_ bv1 1) ?x827)))
(let ((?x1872 (ite $x1121 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x1954 ((_ sign_extend 32) ?x1872)))
(let (($x89 (or false false false)))
(let (($x1903 (or $x89 (ite $x1121 false false))))
(let (($x588 (or $x1903 false)))
(and (not $x588) (or $x588 (and (distinct ?x1954 ?x1954) true)))))))))))
(check-sat)
; query 113: function Gsm_Long_Term_Synthesis_Filtering, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 114: function Gsm_Long_Term_Synthesis_Filtering, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 16) in19_16) ((_ sign_extend 16) in19_16)) true))))))
(check-sat)
; query 115: function Gsm_Long_Term_Synthesis_Filtering, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x2017 (ite (bvsge (_ bv120 32) ((_ sign_extend 16) in19_16)) (_ bv1 1) (_ bv0 1))))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x2665 (not $x2657)))
(and $x2665 (or $x2657 (and (distinct ?x2017 ?x2017) true))))))))
(check-sat)
; query 116: function Gsm_Long_Term_Synthesis_Filtering, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1994 (ite (bvslt (_ bv120 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x2665 (not $x2657)))
(and $x2665 (or $x2657 (and (distinct ?x1994 ?x1994) true))))))))
(check-sat)
; query 117: function Gsm_Long_Term_Synthesis_Filtering, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 118: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 119: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1832 (ite (bvsgt (_ bv40 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x2665 (not $x2657)))
(and $x2665 (or $x2657 (and (distinct ?x1832 ?x1832) true))))))))
(check-sat)
; query 120: function Gsm_Preprocess, block 106, name %107
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in104_64 () (_ BitVec 64))
(assert
 (let ((?x601 (bvadd in104_64 (_ bv16384 64))))
(let (($x1168 (and (distinct ?x601 ?x601) true)))
(let (($x1723 (and (distinct (bvadd ((_ sign_extend 1) in104_64) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x601)) true)))
(let (($x1297 (or false false (or $x1723))))
(and (not $x1297) (or $x1297 $x1168)))))))
(check-sat)
; query 121: function Gsm_Preprocess, block 108, name %109
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in104_64 () (_ BitVec 64))
(assert
 (let ((?x601 (bvadd in104_64 (_ bv16384 64))))
(let (($x1168 (and (distinct ?x601 ?x601) true)))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 $x1168)))))))
(check-sat)
; query 122: function Gsm_Preprocess, block 108, name %110
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in104_64 () (_ BitVec 64))
(assert
 (let ((?x1057 (ite (bvuge (bvadd in104_64 (_ bv16384 64)) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x168 (or $x89 false false)))
(let (($x1546 (not $x168)))
(and $x1546 (or $x168 (and (distinct ?x1057 ?x1057) true))))))))
(check-sat)
; query 123: function Gsm_Preprocess, block 129, name %130
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in126_64 () (_ BitVec 64))
(assert
 (let ((?x1688 (ite (bvslt (_ bv0 64) in126_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x1688 ?x1688) true)))))))
(check-sat)
; query 124: function Gsm_Preprocess, block 129, name %131
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in126_64 () (_ BitVec 64))
(assert
 (let ((?x1688 (ite (bvslt (_ bv0 64) in126_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1211 ((_ zero_extend 63) ?x1688)))
(let (($x89 (or false false false)))
(let (($x56 (or $x89 false)))
(let (($x257 (not $x56)))
(and $x257 (or $x56 (and (distinct ?x1211 ?x1211) true)))))))))
(check-sat)
; query 125: function Gsm_Preprocess, block 129, name %132
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in126_64 () (_ BitVec 64))
(assert
 (let ((?x1688 (ite (bvslt (_ bv0 64) in126_64) (_ bv1 1) (_ bv0 1))))
(let (($x457 (= (_ bv1 1) ?x1688)))
(let ((?x1296 (ite $x457 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x89 (or false false false)))
(let (($x346 (or $x89 (ite $x457 false false))))
(and (not $x346) (or $x346 (and (distinct ?x1296 ?x1296) true)))))))))
(check-sat)
; query 126: function Gsm_Preprocess, block 129, name %133
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in126_64 () (_ BitVec 64))
(assert
 (let ((?x1688 (ite (bvslt (_ bv0 64) in126_64) (_ bv1 1) (_ bv0 1))))
(let (($x457 (= (_ bv1 1) ?x1688)))
(let ((?x1296 (ite $x457 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x614 ((_ sign_extend 32) ?x1296)))
(let (($x89 (or false false false)))
(let (($x346 (or $x89 (ite $x457 false false))))
(let (($x621 (or $x346 false)))
(and (not $x621) (or $x621 (and (distinct ?x614 ?x614) true)))))))))))
(check-sat)
; query 127: function Gsm_Preprocess, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 16) in19_16) ((_ sign_extend 16) in19_16)) true))))))
(check-sat)
; query 128: function Gsm_Preprocess, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x710 (ite (bvsge (_ bv16380 32) ((_ sign_extend 16) in19_16)) (_ bv1 1) (_ bv0 1))))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x2665 (not $x2657)))
(and $x2665 (or $x2657 (and (distinct ?x710 ?x710) true))))))))
(check-sat)
; query 129: function Gsm_Preprocess, block 30, name %33
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x710 (ite (bvsge (_ bv16380 32) ((_ sign_extend 16) in19_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x915 (bvxor ?x710 (_ bv1 1))))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x1048 (or $x2657 false false)))
(and (not $x1048) (or $x1048 (and (distinct ?x915 ?x915) true)))))))))
(check-sat)
; query 130: function Gsm_Preprocess, block 30, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x710 (ite (bvsge (_ bv16380 32) ((_ sign_extend 16) in19_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x915 (bvxor ?x710 (_ bv1 1))))
(let ((?x727 ((_ zero_extend 31) ?x915)))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x1048 (or $x2657 false false)))
(let (($x141 (or $x1048 false)))
(and (not $x141) (or $x141 (and (distinct ?x727 ?x727) true)))))))))))
(check-sat)
; query 131: function Gsm_Preprocess, block 30, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x710 (ite (bvsge (_ bv16380 32) ((_ sign_extend 16) in19_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x915 (bvxor ?x710 (_ bv1 1))))
(let ((?x727 ((_ zero_extend 31) ?x915)))
(let ((?x1657 ((_ sign_extend 32) ?x727)))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x1048 (or $x2657 false false)))
(let (($x141 (or $x1048 false)))
(let (($x1805 (or $x141 false)))
(and (not $x1805) (or $x1805 (and (distinct ?x1657 ?x1657) true)))))))))))))
(check-sat)
; query 132: function Gsm_Preprocess, block 30, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x710 (ite (bvsge (_ bv16380 32) ((_ sign_extend 16) in19_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x915 (bvxor ?x710 (_ bv1 1))))
(let ((?x727 ((_ zero_extend 31) ?x915)))
(let ((?x1657 ((_ sign_extend 32) ?x727)))
(let ((?x1878 (ite (and (distinct (_ bv0 64) ?x1657) true) (_ bv1 1) (_ bv0 1))))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x1048 (or $x2657 false false)))
(let (($x141 (or $x1048 false)))
(let (($x1805 (or $x141 false)))
(let (($x1717 (or $x1805 false false)))
(and (not $x1717) (or $x1717 (and (distinct ?x1878 ?x1878) true)))))))))))))))
(check-sat)
; query 133: function Gsm_Preprocess, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 16) in19_16) ((_ sign_extend 16) in19_16)) true))))))
(check-sat)
; query 134: function Gsm_Preprocess, block 40, name %42
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 16) in.03_16) ((_ sign_extend 16) in.03_16)) true))))))
(check-sat)
; query 135: function Gsm_Preprocess, block 40, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_16 () (_ BitVec 16))
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x567 ((_ sign_extend 16) in.03_16)))
(let ((?x1032 ((_ sign_extend 16) in19_16)))
(let ((?x639 (bvsub ?x1032 ?x567)))
(let (($x1947 (and (distinct (bvsub ((_ sign_extend 1) ?x1032) ((_ sign_extend 1) ?x567)) ((_ sign_extend 1) ?x639)) true)))
(let (($x2656 (or false false)))
(let (($x535 (or $x2656 $x2656 (or $x1947))))
(and (not $x535) (or $x535 (and (distinct ?x639 ?x639) true))))))))))
(check-sat)
; query 136: function Gsm_Preprocess, block 40, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_16 () (_ BitVec 16))
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x567 ((_ sign_extend 16) in.03_16)))
(let ((?x1032 ((_ sign_extend 16) in19_16)))
(let ((?x639 (bvsub ?x1032 ?x567)))
(let ((?x45 ((_ extract 15 0) ?x639)))
(let (($x1947 (and (distinct (bvsub ((_ sign_extend 1) ?x1032) ((_ sign_extend 1) ?x567)) ((_ sign_extend 1) ?x639)) true)))
(let (($x2656 (or false false)))
(let (($x535 (or $x2656 $x2656 (or $x1947))))
(let (($x1945 (or $x535 false)))
(and (not $x1945) (or $x1945 (and (distinct ?x45 ?x45) true))))))))))))
(check-sat)
; query 137: function Gsm_Preprocess, block 40, name %45
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_16 () (_ BitVec 16))
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x567 ((_ sign_extend 16) in.03_16)))
(let ((?x1032 ((_ sign_extend 16) in19_16)))
(let ((?x639 (bvsub ?x1032 ?x567)))
(let ((?x45 ((_ extract 15 0) ?x639)))
(let ((?x1225 ((_ sign_extend 16) ?x45)))
(let (($x1947 (and (distinct (bvsub ((_ sign_extend 1) ?x1032) ((_ sign_extend 1) ?x567)) ((_ sign_extend 1) ?x639)) true)))
(let (($x2656 (or false false)))
(let (($x535 (or $x2656 $x2656 (or $x1947))))
(let (($x1945 (or $x535 false)))
(let (($x1519 (or $x1945 false)))
(and (not $x1519) (or $x1519 (and (distinct ?x1225 ?x1225) true))))))))))))))
(check-sat)
; query 138: function Gsm_Preprocess, block 40, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_16 () (_ BitVec 16))
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x567 ((_ sign_extend 16) in.03_16)))
(let ((?x1032 ((_ sign_extend 16) in19_16)))
(let ((?x639 (bvsub ?x1032 ?x567)))
(let ((?x45 ((_ extract 15 0) ?x639)))
(let ((?x1225 ((_ sign_extend 16) ?x45)))
(let ((?x16 (ite (and (distinct (_ bv4294934528 32) ?x1225) true) (_ bv1 1) (_ bv0 1))))
(let (($x1947 (and (distinct (bvsub ((_ sign_extend 1) ?x1032) ((_ sign_extend 1) ?x567)) ((_ sign_extend 1) ?x639)) true)))
(let (($x2656 (or false false)))
(let (($x535 (or $x2656 $x2656 (or $x1947))))
(let (($x1945 (or $x535 false)))
(let (($x1519 (or $x1945 false)))
(let (($x1091 (or $x1519 false false)))
(and (not $x1091) (or $x1091 (and (distinct ?x16 ?x16) true))))))))))))))))
(check-sat)
; query 139: function Gsm_Preprocess, block 40, name %47
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_16 () (_ BitVec 16))
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x567 ((_ sign_extend 16) in.03_16)))
(let ((?x1032 ((_ sign_extend 16) in19_16)))
(let ((?x639 (bvsub ?x1032 ?x567)))
(let ((?x45 ((_ extract 15 0) ?x639)))
(let ((?x1225 ((_ sign_extend 16) ?x45)))
(let ((?x16 (ite (and (distinct (_ bv4294934528 32) ?x1225) true) (_ bv1 1) (_ bv0 1))))
(let ((?x441 (bvxor ?x16 (_ bv1 1))))
(let (($x1947 (and (distinct (bvsub ((_ sign_extend 1) ?x1032) ((_ sign_extend 1) ?x567)) ((_ sign_extend 1) ?x639)) true)))
(let (($x2656 (or false false)))
(let (($x535 (or $x2656 $x2656 (or $x1947))))
(let (($x1945 (or $x535 false)))
(let (($x1519 (or $x1945 false)))
(let (($x1091 (or $x1519 false false)))
(let (($x1165 (or $x1091 false false)))
(and (not $x1165) (or $x1165 (and (distinct ?x441 ?x441) true))))))))))))))))))
(check-sat)
; query 140: function Gsm_Preprocess, block 40, name %48
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_16 () (_ BitVec 16))
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x567 ((_ sign_extend 16) in.03_16)))
(let ((?x1032 ((_ sign_extend 16) in19_16)))
(let ((?x639 (bvsub ?x1032 ?x567)))
(let ((?x45 ((_ extract 15 0) ?x639)))
(let ((?x1225 ((_ sign_extend 16) ?x45)))
(let ((?x16 (ite (and (distinct (_ bv4294934528 32) ?x1225) true) (_ bv1 1) (_ bv0 1))))
(let ((?x441 (bvxor ?x16 (_ bv1 1))))
(let ((?x1159 ((_ zero_extend 31) ?x441)))
(let (($x1947 (and (distinct (bvsub ((_ sign_extend 1) ?x1032) ((_ sign_extend 1) ?x567)) ((_ sign_extend 1) ?x639)) true)))
(let (($x2656 (or false false)))
(let (($x535 (or $x2656 $x2656 (or $x1947))))
(let (($x1945 (or $x535 false)))
(let (($x1519 (or $x1945 false)))
(let (($x1091 (or $x1519 false false)))
(let (($x1165 (or $x1091 false false)))
(let (($x1179 (or $x1165 false)))
(and (not $x1179) (or $x1179 (and (distinct ?x1159 ?x1159) true))))))))))))))))))))
(check-sat)
; query 141: function Gsm_Preprocess, block 40, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_16 () (_ BitVec 16))
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x567 ((_ sign_extend 16) in.03_16)))
(let ((?x1032 ((_ sign_extend 16) in19_16)))
(let ((?x639 (bvsub ?x1032 ?x567)))
(let ((?x45 ((_ extract 15 0) ?x639)))
(let ((?x1225 ((_ sign_extend 16) ?x45)))
(let ((?x16 (ite (and (distinct (_ bv4294934528 32) ?x1225) true) (_ bv1 1) (_ bv0 1))))
(let ((?x441 (bvxor ?x16 (_ bv1 1))))
(let ((?x1159 ((_ zero_extend 31) ?x441)))
(let ((?x595 ((_ sign_extend 32) ?x1159)))
(let (($x1947 (and (distinct (bvsub ((_ sign_extend 1) ?x1032) ((_ sign_extend 1) ?x567)) ((_ sign_extend 1) ?x639)) true)))
(let (($x2656 (or false false)))
(let (($x535 (or $x2656 $x2656 (or $x1947))))
(let (($x1945 (or $x535 false)))
(let (($x1519 (or $x1945 false)))
(let (($x1091 (or $x1519 false false)))
(let (($x1165 (or $x1091 false false)))
(let (($x1179 (or $x1165 false)))
(let (($x570 (or $x1179 false)))
(and (not $x570) (or $x570 (and (distinct ?x595 ?x595) true))))))))))))))))))))))
(check-sat)
; query 142: function Gsm_Preprocess, block 40, name %50
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_16 () (_ BitVec 16))
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x567 ((_ sign_extend 16) in.03_16)))
(let ((?x1032 ((_ sign_extend 16) in19_16)))
(let ((?x639 (bvsub ?x1032 ?x567)))
(let ((?x45 ((_ extract 15 0) ?x639)))
(let ((?x1225 ((_ sign_extend 16) ?x45)))
(let ((?x16 (ite (and (distinct (_ bv4294934528 32) ?x1225) true) (_ bv1 1) (_ bv0 1))))
(let ((?x441 (bvxor ?x16 (_ bv1 1))))
(let ((?x1159 ((_ zero_extend 31) ?x441)))
(let ((?x595 ((_ sign_extend 32) ?x1159)))
(let ((?x644 (ite (and (distinct (_ bv0 64) ?x595) true) (_ bv1 1) (_ bv0 1))))
(let (($x1947 (and (distinct (bvsub ((_ sign_extend 1) ?x1032) ((_ sign_extend 1) ?x567)) ((_ sign_extend 1) ?x639)) true)))
(let (($x2656 (or false false)))
(let (($x535 (or $x2656 $x2656 (or $x1947))))
(let (($x1945 (or $x535 false)))
(let (($x1519 (or $x1945 false)))
(let (($x1091 (or $x1519 false false)))
(let (($x1165 (or $x1091 false false)))
(let (($x1179 (or $x1165 false)))
(let (($x570 (or $x1179 false)))
(let (($x524 (or $x570 false false)))
(and (not $x524) (or $x524 (and (distinct ?x644 ?x644) true))))))))))))))))))))))))
(check-sat)
; query 143: function Gsm_Preprocess, block 54, name %55
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in44_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 48) in44_16) ((_ sign_extend 48) in44_16)) true))))))
(check-sat)
; query 144: function Gsm_Preprocess, block 54, name %56
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in44_16 () (_ BitVec 16))
(assert
 (let ((?x718 ((_ sign_extend 48) in44_16)))
(let ((?x1824 (bvshl ?x718 (_ bv15 64))))
(let (($x44 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x835 (or $x2657 $x44)))
(and (not $x835) (or $x835 (and (distinct ?x1824 ?x1824) true))))))))))
(check-sat)
; query 145: function Gsm_Preprocess, block 54, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_64 () (_ BitVec 64))
(assert
 (let (($x44 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x89 (or false false false)))
(let (($x560 (or $x89 $x44)))
(and (not $x560) (or $x560 (and (distinct (bvashr in.04_64 (_ bv15 64)) (bvashr in.04_64 (_ bv15 64))) true)))))))
(check-sat)
; query 146: function Gsm_Preprocess, block 54, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_64 () (_ BitVec 64))
(assert
 (let ((?x1007 (bvashr in.04_64 (_ bv15 64))))
(let ((?x1075 ((_ extract 15 0) ?x1007)))
(let (($x44 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x89 (or false false false)))
(let (($x560 (or $x89 $x44)))
(let (($x592 (or $x560 false)))
(and (not $x592) (or $x592 (and (distinct ?x1075 ?x1075) true))))))))))
(check-sat)
; query 147: function Gsm_Preprocess, block 54, name %59
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_64 () (_ BitVec 64))
(assert
 (let ((?x1007 (bvashr in.04_64 (_ bv15 64))))
(let ((?x1075 ((_ extract 15 0) ?x1007)))
(let ((?x998 ((_ sign_extend 48) ?x1075)))
(let (($x44 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x89 (or false false false)))
(let (($x560 (or $x89 $x44)))
(let (($x592 (or $x560 false)))
(let (($x115 (or $x592 false)))
(and (not $x115) (or $x115 (and (distinct ?x998 ?x998) true))))))))))))
(check-sat)
; query 148: function Gsm_Preprocess, block 54, name %60
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_64 () (_ BitVec 64))
(assert
 (let ((?x1007 (bvashr in.04_64 (_ bv15 64))))
(let ((?x1075 ((_ extract 15 0) ?x1007)))
(let ((?x998 ((_ sign_extend 48) ?x1075)))
(let ((?x1603 (bvshl ?x998 (_ bv15 64))))
(let (($x44 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x89 (or false false false)))
(let (($x560 (or $x89 $x44)))
(let (($x592 (or $x560 false)))
(let (($x115 (or $x592 false)))
(let (($x1614 (or (or $x115 false false) $x44)))
(and (not $x1614) (or $x1614 (and (distinct ?x1603 ?x1603) true))))))))))))))
(check-sat)
; query 149: function Gsm_Preprocess, block 54, name %61
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_64 () (_ BitVec 64))
(assert
 (let ((?x1007 (bvashr in.04_64 (_ bv15 64))))
(let ((?x1075 ((_ extract 15 0) ?x1007)))
(let ((?x998 ((_ sign_extend 48) ?x1075)))
(let ((?x1603 (bvshl ?x998 (_ bv15 64))))
(let ((?x936 (bvsub in.04_64 ?x1603)))
(let (($x1124 (and (distinct (bvsub ((_ sign_extend 1) in.04_64) ((_ sign_extend 1) ?x1603)) ((_ sign_extend 1) ?x936)) true)))
(let (($x44 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x89 (or false false false)))
(let (($x560 (or $x89 $x44)))
(let (($x592 (or $x560 false)))
(let (($x115 (or $x592 false)))
(let (($x1614 (or (or $x115 false false) $x44)))
(let (($x1228 (or false $x1614 (or $x1124))))
(and (not $x1228) (or $x1228 (and (distinct ?x936 ?x936) true)))))))))))))))))
(check-sat)
; query 150: function Gsm_Preprocess, block 54, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_64 () (_ BitVec 64))
(assert
 (let ((?x1007 (bvashr in.04_64 (_ bv15 64))))
(let ((?x1075 ((_ extract 15 0) ?x1007)))
(let ((?x998 ((_ sign_extend 48) ?x1075)))
(let ((?x1603 (bvshl ?x998 (_ bv15 64))))
(let ((?x936 (bvsub in.04_64 ?x1603)))
(let ((?x766 ((_ extract 15 0) ?x936)))
(let (($x1124 (and (distinct (bvsub ((_ sign_extend 1) in.04_64) ((_ sign_extend 1) ?x1603)) ((_ sign_extend 1) ?x936)) true)))
(let (($x44 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x89 (or false false false)))
(let (($x560 (or $x89 $x44)))
(let (($x592 (or $x560 false)))
(let (($x115 (or $x592 false)))
(let (($x1614 (or (or $x115 false false) $x44)))
(let (($x1228 (or false $x1614 (or $x1124))))
(let (($x1384 (or $x1228 false)))
(and (not $x1384) (or $x1384 (and (distinct ?x766 ?x766) true)))))))))))))))))))
(check-sat)
; query 151: function Gsm_Preprocess, block 54, name %63
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_64 () (_ BitVec 64))
(assert
 (let ((?x1007 (bvashr in.04_64 (_ bv15 64))))
(let ((?x1075 ((_ extract 15 0) ?x1007)))
(let ((?x998 ((_ sign_extend 48) ?x1075)))
(let ((?x1603 (bvshl ?x998 (_ bv15 64))))
(let ((?x936 (bvsub in.04_64 ?x1603)))
(let ((?x766 ((_ extract 15 0) ?x936)))
(let ((?x586 ((_ sign_extend 48) ?x766)))
(let (($x1124 (and (distinct (bvsub ((_ sign_extend 1) in.04_64) ((_ sign_extend 1) ?x1603)) ((_ sign_extend 1) ?x936)) true)))
(let (($x44 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x89 (or false false false)))
(let (($x560 (or $x89 $x44)))
(let (($x592 (or $x560 false)))
(let (($x115 (or $x592 false)))
(let (($x1614 (or (or $x115 false false) $x44)))
(let (($x1228 (or false $x1614 (or $x1124))))
(let (($x1384 (or $x1228 false)))
(let (($x1291 (or $x1384 false)))
(and (not $x1291) (or $x1291 (and (distinct ?x586 ?x586) true)))))))))))))))))))))
(check-sat)
; query 152: function Gsm_Preprocess, block 54, name %64
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_64 () (_ BitVec 64))
(assert
 (let ((?x1007 (bvashr in.04_64 (_ bv15 64))))
(let ((?x1075 ((_ extract 15 0) ?x1007)))
(let ((?x998 ((_ sign_extend 48) ?x1075)))
(let ((?x1603 (bvshl ?x998 (_ bv15 64))))
(let ((?x936 (bvsub in.04_64 ?x1603)))
(let ((?x766 ((_ extract 15 0) ?x936)))
(let ((?x586 ((_ sign_extend 48) ?x766)))
(let ((?x889 (bvmul ?x586 (_ bv32735 64))))
(let (($x627 (and (distinct (bvmul ((_ sign_extend 64) ?x586) ((_ sign_extend 64) (_ bv32735 64))) ((_ sign_extend 64) ?x889)) true)))
(let (($x1124 (and (distinct (bvsub ((_ sign_extend 1) in.04_64) ((_ sign_extend 1) ?x1603)) ((_ sign_extend 1) ?x936)) true)))
(let (($x44 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x89 (or false false false)))
(let (($x560 (or $x89 $x44)))
(let (($x592 (or $x560 false)))
(let (($x115 (or $x592 false)))
(let (($x1614 (or (or $x115 false false) $x44)))
(let (($x1228 (or false $x1614 (or $x1124))))
(let (($x1384 (or $x1228 false)))
(let (($x1291 (or $x1384 false)))
(let (($x427 (or $x1291 false (or $x627))))
(and (not $x427) (or $x427 (and (distinct ?x889 ?x889) true))))))))))))))))))))))))
(check-sat)
; query 153: function Gsm_Preprocess, block 54, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_64 () (_ BitVec 64))
(assert
 (let ((?x1007 (bvashr in.04_64 (_ bv15 64))))
(let ((?x1075 ((_ extract 15 0) ?x1007)))
(let ((?x998 ((_ sign_extend 48) ?x1075)))
(let ((?x1603 (bvshl ?x998 (_ bv15 64))))
(let ((?x936 (bvsub in.04_64 ?x1603)))
(let ((?x766 ((_ extract 15 0) ?x936)))
(let ((?x586 ((_ sign_extend 48) ?x766)))
(let ((?x889 (bvmul ?x586 (_ bv32735 64))))
(let ((?x361 (bvadd ?x889 (_ bv16384 64))))
(let (($x768 (and (distinct (bvadd ((_ sign_extend 1) ?x889) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x361)) true)))
(let (($x627 (and (distinct (bvmul ((_ sign_extend 64) ?x586) ((_ sign_extend 64) (_ bv32735 64))) ((_ sign_extend 64) ?x889)) true)))
(let (($x1124 (and (distinct (bvsub ((_ sign_extend 1) in.04_64) ((_ sign_extend 1) ?x1603)) ((_ sign_extend 1) ?x936)) true)))
(let (($x44 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x89 (or false false false)))
(let (($x560 (or $x89 $x44)))
(let (($x592 (or $x560 false)))
(let (($x115 (or $x592 false)))
(let (($x1614 (or (or $x115 false false) $x44)))
(let (($x1228 (or false $x1614 (or $x1124))))
(let (($x1384 (or $x1228 false)))
(let (($x1291 (or $x1384 false)))
(let (($x427 (or $x1291 false (or $x627))))
(let (($x213 (or $x427 false (or $x768))))
(and (not $x213) (or $x213 (and (distinct ?x361 ?x361) true)))))))))))))))))))))))))))
(check-sat)
; query 154: function Gsm_Preprocess, block 54, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_64 () (_ BitVec 64))
(assert
 (let ((?x1007 (bvashr in.04_64 (_ bv15 64))))
(let ((?x1075 ((_ extract 15 0) ?x1007)))
(let ((?x998 ((_ sign_extend 48) ?x1075)))
(let ((?x1603 (bvshl ?x998 (_ bv15 64))))
(let ((?x936 (bvsub in.04_64 ?x1603)))
(let ((?x766 ((_ extract 15 0) ?x936)))
(let ((?x586 ((_ sign_extend 48) ?x766)))
(let ((?x889 (bvmul ?x586 (_ bv32735 64))))
(let ((?x361 (bvadd ?x889 (_ bv16384 64))))
(let ((?x92 (bvashr ?x361 (_ bv15 64))))
(let (($x44 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x768 (and (distinct (bvadd ((_ sign_extend 1) ?x889) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x361)) true)))
(let (($x627 (and (distinct (bvmul ((_ sign_extend 64) ?x586) ((_ sign_extend 64) (_ bv32735 64))) ((_ sign_extend 64) ?x889)) true)))
(let (($x1124 (and (distinct (bvsub ((_ sign_extend 1) in.04_64) ((_ sign_extend 1) ?x1603)) ((_ sign_extend 1) ?x936)) true)))
(let (($x89 (or false false false)))
(let (($x560 (or $x89 $x44)))
(let (($x592 (or $x560 false)))
(let (($x115 (or $x592 false)))
(let (($x1614 (or (or $x115 false false) $x44)))
(let (($x1228 (or false $x1614 (or $x1124))))
(let (($x1384 (or $x1228 false)))
(let (($x1291 (or $x1384 false)))
(let (($x427 (or $x1291 false (or $x627))))
(let (($x213 (or $x427 false (or $x768))))
(let (($x1817 (or (or $x213 false false) $x44)))
(and (not $x1817) (or $x1817 (and (distinct ?x92 ?x92) true)))))))))))))))))))))))))))))
(check-sat)
; query 155: function Gsm_Preprocess, block 54, name %67
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_64 () (_ BitVec 64))
(declare-fun in44_16 () (_ BitVec 16))
(assert
 (let ((?x1007 (bvashr in.04_64 (_ bv15 64))))
(let ((?x1075 ((_ extract 15 0) ?x1007)))
(let ((?x998 ((_ sign_extend 48) ?x1075)))
(let ((?x1603 (bvshl ?x998 (_ bv15 64))))
(let ((?x936 (bvsub in.04_64 ?x1603)))
(let ((?x766 ((_ extract 15 0) ?x936)))
(let ((?x586 ((_ sign_extend 48) ?x766)))
(let ((?x889 (bvmul ?x586 (_ bv32735 64))))
(let ((?x361 (bvadd ?x889 (_ bv16384 64))))
(let ((?x92 (bvashr ?x361 (_ bv15 64))))
(let ((?x718 ((_ sign_extend 48) in44_16)))
(let ((?x1824 (bvshl ?x718 (_ bv15 64))))
(let ((?x1781 (bvadd ?x1824 ?x92)))
(let (($x1691 (and (distinct (bvadd ((_ sign_extend 1) ?x1824) ((_ sign_extend 1) ?x92)) ((_ sign_extend 1) ?x1781)) true)))
(let (($x44 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x768 (and (distinct (bvadd ((_ sign_extend 1) ?x889) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x361)) true)))
(let (($x627 (and (distinct (bvmul ((_ sign_extend 64) ?x586) ((_ sign_extend 64) (_ bv32735 64))) ((_ sign_extend 64) ?x889)) true)))
(let (($x1124 (and (distinct (bvsub ((_ sign_extend 1) in.04_64) ((_ sign_extend 1) ?x1603)) ((_ sign_extend 1) ?x936)) true)))
(let (($x89 (or false false false)))
(let (($x560 (or $x89 $x44)))
(let (($x592 (or $x560 false)))
(let (($x115 (or $x592 false)))
(let (($x1614 (or (or $x115 false false) $x44)))
(let (($x1228 (or false $x1614 (or $x1124))))
(let (($x1384 (or $x1228 false)))
(let (($x1291 (or $x1384 false)))
(let (($x427 (or $x1291 false (or $x627))))
(let (($x213 (or $x427 false (or $x768))))
(let (($x1817 (or (or $x213 false false) $x44)))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x835 (or $x2657 $x44)))
(let (($x1904 (or $x835 $x1817 (or $x1691))))
(and (not $x1904) (or $x1904 (and (distinct ?x1781 ?x1781) true)))))))))))))))))))))))))))))))))))))
(check-sat)
; query 156: function Gsm_Preprocess, block 54, name %68
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_64 () (_ BitVec 64))
(assert
 (let ((?x1007 (bvashr in.04_64 (_ bv15 64))))
(let ((?x1075 ((_ extract 15 0) ?x1007)))
(let ((?x998 ((_ sign_extend 48) ?x1075)))
(let (($x44 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x89 (or false false false)))
(let (($x560 (or $x89 $x44)))
(let (($x592 (or $x560 false)))
(let (($x115 (or $x592 false)))
(and (not $x115) (or $x115 (and (distinct ?x998 ?x998) true))))))))))))
(check-sat)
; query 157: function Gsm_Preprocess, block 54, name %69
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_64 () (_ BitVec 64))
(assert
 (let ((?x1007 (bvashr in.04_64 (_ bv15 64))))
(let ((?x1075 ((_ extract 15 0) ?x1007)))
(let ((?x998 ((_ sign_extend 48) ?x1075)))
(let ((?x1096 (bvmul ?x998 (_ bv32735 64))))
(let (($x1693 (and (distinct (bvmul ((_ sign_extend 64) ?x998) ((_ sign_extend 64) (_ bv32735 64))) ((_ sign_extend 64) ?x1096)) true)))
(let (($x44 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x89 (or false false false)))
(let (($x560 (or $x89 $x44)))
(let (($x592 (or $x560 false)))
(let (($x115 (or $x592 false)))
(let (($x895 (or $x115 false (or $x1693))))
(and (not $x895) (or $x895 (and (distinct ?x1096 ?x1096) true)))))))))))))))
(check-sat)
; query 158: function Gsm_Preprocess, block 54, name %70
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_64 () (_ BitVec 64))
(assert
 (let ((?x1007 (bvashr in.04_64 (_ bv15 64))))
(let ((?x1075 ((_ extract 15 0) ?x1007)))
(let ((?x998 ((_ sign_extend 48) ?x1075)))
(let ((?x1096 (bvmul ?x998 (_ bv32735 64))))
(let ((?x1500 (ite (bvsgt (_ bv0 64) ?x1096) (_ bv1 1) (_ bv0 1))))
(let (($x1693 (and (distinct (bvmul ((_ sign_extend 64) ?x998) ((_ sign_extend 64) (_ bv32735 64))) ((_ sign_extend 64) ?x1096)) true)))
(let (($x44 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x89 (or false false false)))
(let (($x560 (or $x89 $x44)))
(let (($x592 (or $x560 false)))
(let (($x115 (or $x592 false)))
(let (($x895 (or $x115 false (or $x1693))))
(let (($x649 (or $x895 false false)))
(and (not $x649) (or $x649 (and (distinct ?x1500 ?x1500) true)))))))))))))))))
(check-sat)
; query 159: function Gsm_Preprocess, block 71, name %72
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in67_64 () (_ BitVec 64))
(assert
 (let ((?x485 (ite (bvsle (_ bv0 64) in67_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x485 ?x485) true)))))))
(check-sat)
; query 160: function Gsm_Preprocess, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in67_64 () (_ BitVec 64))
(declare-fun in69_64 () (_ BitVec 64))
(assert
 (let ((?x724 (bvadd in69_64 in67_64)))
(let (($x896 (and (distinct ?x724 ?x724) true)))
(let (($x995 (and (distinct (bvadd ((_ sign_extend 1) in69_64) ((_ sign_extend 1) in67_64)) ((_ sign_extend 1) ?x724)) true)))
(let (($x1556 (or false false (or $x995))))
(and (not $x1556) (or $x1556 $x896)))))))
(check-sat)
; query 161: function Gsm_Preprocess, block 75, name %76
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in69_64 () (_ BitVec 64))
(assert
 (let ((?x179 (bvadd in69_64 (_ bv1 64))))
(let ((?x937 ((_ sign_extend 1) ?x179)))
(let (($x746 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in69_64) ((_ sign_extend 1) (_ bv1 64))) ?x937) true)))))
(and (not $x746) (or $x746 (and (distinct ?x179 ?x179) true)))))))
(check-sat)
; query 162: function Gsm_Preprocess, block 75, name %77
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in69_64 () (_ BitVec 64))
(assert
 (let ((?x179 (bvadd in69_64 (_ bv1 64))))
(let ((?x1780 (bvsub (_ bv0 64) ?x179)))
(let (($x268 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x179)) ((_ sign_extend 1) ?x1780)) true)))
(let ((?x937 ((_ sign_extend 1) ?x179)))
(let (($x746 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in69_64) ((_ sign_extend 1) (_ bv1 64))) ?x937) true)))))
(let (($x471 (or false $x746 (or $x268))))
(and (not $x471) (or $x471 (and (distinct ?x1780 ?x1780) true))))))))))
(check-sat)
; query 163: function Gsm_Preprocess, block 75, name %78
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in67_64 () (_ BitVec 64))
(assert
 (let ((?x1549 (bvadd in67_64 (_ bv1 64))))
(let ((?x667 ((_ sign_extend 1) ?x1549)))
(let (($x794 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in67_64) ((_ sign_extend 1) (_ bv1 64))) ?x667) true)))))
(and (not $x794) (or $x794 (and (distinct ?x1549 ?x1549) true)))))))
(check-sat)
; query 164: function Gsm_Preprocess, block 75, name %79
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in67_64 () (_ BitVec 64))
(assert
 (let ((?x1549 (bvadd in67_64 (_ bv1 64))))
(let ((?x1105 (bvsub (_ bv0 64) ?x1549)))
(let (($x1183 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1549)) ((_ sign_extend 1) ?x1105)) true)))
(let ((?x667 ((_ sign_extend 1) ?x1549)))
(let (($x794 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in67_64) ((_ sign_extend 1) (_ bv1 64))) ?x667) true)))))
(let (($x1785 (or false $x794 (or $x1183))))
(and (not $x1785) (or $x1785 (and (distinct ?x1105 ?x1105) true))))))))))
(check-sat)
; query 165: function Gsm_Preprocess, block 75, name %80
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in67_64 () (_ BitVec 64))
(declare-fun in69_64 () (_ BitVec 64))
(assert
 (let ((?x1549 (bvadd in67_64 (_ bv1 64))))
(let ((?x1105 (bvsub (_ bv0 64) ?x1549)))
(let ((?x179 (bvadd in69_64 (_ bv1 64))))
(let ((?x1780 (bvsub (_ bv0 64) ?x179)))
(let ((?x1016 (bvadd ?x1780 ?x1105)))
(let (($x1183 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1549)) ((_ sign_extend 1) ?x1105)) true)))
(let ((?x667 ((_ sign_extend 1) ?x1549)))
(let (($x794 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in67_64) ((_ sign_extend 1) (_ bv1 64))) ?x667) true)))))
(let (($x1785 (or false $x794 (or $x1183))))
(let (($x268 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x179)) ((_ sign_extend 1) ?x1780)) true)))
(let ((?x937 ((_ sign_extend 1) ?x179)))
(let (($x746 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in69_64) ((_ sign_extend 1) (_ bv1 64))) ?x937) true)))))
(let (($x471 (or false $x746 (or $x268))))
(let (($x1579 (or $x471 $x1785 false)))
(and (not $x1579) (or $x1579 (and (distinct ?x1016 ?x1016) true))))))))))))))))))
(check-sat)
; query 166: function Gsm_Preprocess, block 75, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in67_64 () (_ BitVec 64))
(declare-fun in69_64 () (_ BitVec 64))
(assert
 (let ((?x1549 (bvadd in67_64 (_ bv1 64))))
(let ((?x1105 (bvsub (_ bv0 64) ?x1549)))
(let ((?x179 (bvadd in69_64 (_ bv1 64))))
(let ((?x1780 (bvsub (_ bv0 64) ?x179)))
(let ((?x1016 (bvadd ?x1780 ?x1105)))
(let ((?x610 (ite (bvuge ?x1016 (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x1183 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1549)) ((_ sign_extend 1) ?x1105)) true)))
(let ((?x667 ((_ sign_extend 1) ?x1549)))
(let (($x794 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in67_64) ((_ sign_extend 1) (_ bv1 64))) ?x667) true)))))
(let (($x1785 (or false $x794 (or $x1183))))
(let (($x268 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x179)) ((_ sign_extend 1) ?x1780)) true)))
(let ((?x937 ((_ sign_extend 1) ?x179)))
(let (($x746 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in69_64) ((_ sign_extend 1) (_ bv1 64))) ?x937) true)))))
(let (($x471 (or false $x746 (or $x268))))
(let (($x1579 (or $x471 $x1785 false)))
(let (($x761 (or $x1579 false false)))
(and (not $x761) (or $x761 (and (distinct ?x610 ?x610) true))))))))))))))))))))
(check-sat)
; query 167: function Gsm_Preprocess, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in80_64 () (_ BitVec 64))
(assert
 (let ((?x696 (bvsub (_ bv0 64) in80_64)))
(let ((?x997 ((_ sign_extend 1) ?x696)))
(let (($x1987 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in80_64)) ?x997) true)))))
(and (not $x1987) (or $x1987 (and (distinct ?x696 ?x696) true)))))))
(check-sat)
; query 168: function Gsm_Preprocess, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in80_64 () (_ BitVec 64))
(assert
 (let ((?x696 (bvsub (_ bv0 64) in80_64)))
(let ((?x872 (bvsub ?x696 (_ bv2 64))))
(let (($x1747 (and (distinct (bvsub ((_ sign_extend 1) ?x696) ((_ sign_extend 1) (_ bv2 64))) ((_ sign_extend 1) ?x872)) true)))
(let ((?x997 ((_ sign_extend 1) ?x696)))
(let (($x1987 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in80_64)) ?x997) true)))))
(let (($x469 (or $x1987 false (or $x1747))))
(and (not $x469) (or $x469 (and (distinct ?x872 ?x872) true))))))))))
(check-sat)
; query 169: function Gsm_Preprocess, block 90, name %91
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in67_64 () (_ BitVec 64))
(assert
 (let ((?x289 (ite (bvsge (_ bv0 64) in67_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x289 ?x289) true)))))))
(check-sat)
; query 170: function Gsm_Preprocess, block 92, name %93
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in67_64 () (_ BitVec 64))
(declare-fun in69_64 () (_ BitVec 64))
(assert
 (let ((?x724 (bvadd in69_64 in67_64)))
(let (($x896 (and (distinct ?x724 ?x724) true)))
(let (($x995 (and (distinct (bvadd ((_ sign_extend 1) in69_64) ((_ sign_extend 1) in67_64)) ((_ sign_extend 1) ?x724)) true)))
(let (($x1556 (or false false (or $x995))))
(and (not $x1556) (or $x1556 $x896)))))))
(check-sat)
; query 171: function Gsm_Preprocess, block 94, name %95
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in67_64 () (_ BitVec 64))
(declare-fun in69_64 () (_ BitVec 64))
(assert
 (let ((?x724 (bvadd in69_64 in67_64)))
(let (($x896 (and (distinct ?x724 ?x724) true)))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 $x896)))))))
(check-sat)
; query 172: function Gsm_Preprocess, block 94, name %96
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in67_64 () (_ BitVec 64))
(declare-fun in69_64 () (_ BitVec 64))
(assert
 (let ((?x1984 (ite (bvuge (bvadd in69_64 in67_64) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x168 (or $x89 false false)))
(let (($x1546 (not $x168)))
(and $x1546 (or $x168 (and (distinct ?x1984 ?x1984) true))))))))
(check-sat)
; query 173: function Postprocessing, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in17_64 () (_ BitVec 64))
(assert
 (let ((?x1081 (ite (bvslt (_ bv0 64) in17_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x1081 ?x1081) true)))))))
(check-sat)
; query 174: function Postprocessing, block 20, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in17_64 () (_ BitVec 64))
(assert
 (let ((?x1081 (ite (bvslt (_ bv0 64) in17_64) (_ bv1 1) (_ bv0 1))))
(let ((?x900 ((_ zero_extend 63) ?x1081)))
(let (($x89 (or false false false)))
(let (($x56 (or $x89 false)))
(let (($x257 (not $x56)))
(and $x257 (or $x56 (and (distinct ?x900 ?x900) true)))))))))
(check-sat)
; query 175: function Postprocessing, block 20, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in17_64 () (_ BitVec 64))
(assert
 (let ((?x1081 (ite (bvslt (_ bv0 64) in17_64) (_ bv1 1) (_ bv0 1))))
(let (($x484 (= (_ bv1 1) ?x1081)))
(let ((?x654 (ite $x484 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x89 (or false false false)))
(let (($x1838 (or $x89 (ite $x484 false false))))
(and (not $x1838) (or $x1838 (and (distinct ?x654 ?x654) true)))))))))
(check-sat)
; query 176: function Postprocessing, block 20, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in17_64 () (_ BitVec 64))
(assert
 (let ((?x1081 (ite (bvslt (_ bv0 64) in17_64) (_ bv1 1) (_ bv0 1))))
(let (($x484 (= (_ bv1 1) ?x1081)))
(let ((?x654 (ite $x484 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x1527 ((_ sign_extend 32) ?x654)))
(let (($x89 (or false false false)))
(let (($x1838 (or $x89 (ite $x484 false false))))
(let (($x1206 (or $x1838 false)))
(and (not $x1206) (or $x1206 (and (distinct ?x1527 ?x1527) true)))))))))))
(check-sat)
; query 177: function Postprocessing, block 34, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in31_64 () (_ BitVec 64))
(assert
 (let ((?x436 (ite (bvslt (_ bv0 64) in31_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x436 ?x436) true)))))))
(check-sat)
; query 178: function Postprocessing, block 34, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in31_64 () (_ BitVec 64))
(assert
 (let ((?x436 (ite (bvslt (_ bv0 64) in31_64) (_ bv1 1) (_ bv0 1))))
(let ((?x67 ((_ zero_extend 63) ?x436)))
(let (($x89 (or false false false)))
(let (($x56 (or $x89 false)))
(let (($x257 (not $x56)))
(and $x257 (or $x56 (and (distinct ?x67 ?x67) true)))))))))
(check-sat)
; query 179: function Postprocessing, block 34, name %37
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in31_64 () (_ BitVec 64))
(assert
 (let ((?x436 (ite (bvslt (_ bv0 64) in31_64) (_ bv1 1) (_ bv0 1))))
(let (($x1888 (= (_ bv1 1) ?x436)))
(let ((?x513 (ite $x1888 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x89 (or false false false)))
(let (($x866 (or $x89 (ite $x1888 false false))))
(and (not $x866) (or $x866 (and (distinct ?x513 ?x513) true)))))))))
(check-sat)
; query 180: function Postprocessing, block 34, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in31_64 () (_ BitVec 64))
(assert
 (let ((?x436 (ite (bvslt (_ bv0 64) in31_64) (_ bv1 1) (_ bv0 1))))
(let (($x1888 (= (_ bv1 1) ?x436)))
(let ((?x513 (ite $x1888 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x771 ((_ sign_extend 32) ?x513)))
(let (($x89 (or false false false)))
(let (($x866 (or $x89 (ite $x1888 false false))))
(let (($x1029 (or $x866 false)))
(and (not $x1029) (or $x1029 (and (distinct ?x771 ?x771) true)))))))))))
(check-sat)
; query 181: function Quantization_and_coding, block 11, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in8_64 () (_ BitVec 64))
(assert
 (let ((?x51 (ite (bvslt (_ bv0 64) in8_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x51 ?x51) true)))))))
(check-sat)
; query 182: function Quantization_and_coding, block 11, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in8_64 () (_ BitVec 64))
(assert
 (let ((?x51 (ite (bvslt (_ bv0 64) in8_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1639 ((_ zero_extend 63) ?x51)))
(let (($x89 (or false false false)))
(let (($x56 (or $x89 false)))
(let (($x257 (not $x56)))
(and $x257 (or $x56 (and (distinct ?x1639 ?x1639) true)))))))))
(check-sat)
; query 183: function Quantization_and_coding, block 11, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in8_64 () (_ BitVec 64))
(assert
 (let ((?x51 (ite (bvslt (_ bv0 64) in8_64) (_ bv1 1) (_ bv0 1))))
(let (($x1712 (= (_ bv1 1) ?x51)))
(let ((?x132 (ite $x1712 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x89 (or false false false)))
(let (($x716 (or $x89 (ite $x1712 false false))))
(and (not $x716) (or $x716 (and (distinct ?x132 ?x132) true)))))))))
(check-sat)
; query 184: function Quantization_and_coding, block 11, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in8_64 () (_ BitVec 64))
(assert
 (let ((?x51 (ite (bvslt (_ bv0 64) in8_64) (_ bv1 1) (_ bv0 1))))
(let (($x1712 (= (_ bv1 1) ?x51)))
(let ((?x132 (ite $x1712 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x685 ((_ sign_extend 32) ?x132)))
(let (($x89 (or false false false)))
(let (($x716 (or $x89 (ite $x1712 false false))))
(let (($x1815 (or $x716 false)))
(and (not $x1815) (or $x1815 (and (distinct ?x685 ?x685) true)))))))))))
(check-sat)
; query 185: function Quantization_and_coding, block 111, name %112
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in108_64 () (_ BitVec 64))
(assert
 (let ((?x1458 (ite (bvslt (_ bv0 64) in108_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x1458 ?x1458) true)))))))
(check-sat)
; query 186: function Quantization_and_coding, block 111, name %113
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in108_64 () (_ BitVec 64))
(assert
 (let ((?x1458 (ite (bvslt (_ bv0 64) in108_64) (_ bv1 1) (_ bv0 1))))
(let ((?x164 ((_ zero_extend 63) ?x1458)))
(let (($x89 (or false false false)))
(let (($x56 (or $x89 false)))
(let (($x257 (not $x56)))
(and $x257 (or $x56 (and (distinct ?x164 ?x164) true)))))))))
(check-sat)
; query 187: function Quantization_and_coding, block 111, name %114
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in108_64 () (_ BitVec 64))
(assert
 (let ((?x1458 (ite (bvslt (_ bv0 64) in108_64) (_ bv1 1) (_ bv0 1))))
(let (($x620 (= (_ bv1 1) ?x1458)))
(let ((?x468 (ite $x620 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x89 (or false false false)))
(let (($x1655 (or $x89 (ite $x620 false false))))
(and (not $x1655) (or $x1655 (and (distinct ?x468 ?x468) true)))))))))
(check-sat)
; query 188: function Quantization_and_coding, block 111, name %115
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in108_64 () (_ BitVec 64))
(assert
 (let ((?x1458 (ite (bvslt (_ bv0 64) in108_64) (_ bv1 1) (_ bv0 1))))
(let (($x620 (= (_ bv1 1) ?x1458)))
(let ((?x468 (ite $x620 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x1714 ((_ sign_extend 32) ?x468)))
(let (($x89 (or false false false)))
(let (($x1655 (or $x89 (ite $x620 false false))))
(let (($x1700 (or $x1655 false)))
(and (not $x1700) (or $x1700 (and (distinct ?x1714 ?x1714) true)))))))))))
(check-sat)
; query 189: function Quantization_and_coding, block 124, name %125
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in121_64 () (_ BitVec 64))
(assert
 (let ((?x1482 (ite (bvslt (_ bv0 64) in121_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x1482 ?x1482) true)))))))
(check-sat)
; query 190: function Quantization_and_coding, block 124, name %126
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in121_64 () (_ BitVec 64))
(assert
 (let ((?x1482 (ite (bvslt (_ bv0 64) in121_64) (_ bv1 1) (_ bv0 1))))
(let ((?x124 ((_ zero_extend 63) ?x1482)))
(let (($x89 (or false false false)))
(let (($x56 (or $x89 false)))
(let (($x257 (not $x56)))
(and $x257 (or $x56 (and (distinct ?x124 ?x124) true)))))))))
(check-sat)
; query 191: function Quantization_and_coding, block 124, name %127
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in121_64 () (_ BitVec 64))
(assert
 (let ((?x1482 (ite (bvslt (_ bv0 64) in121_64) (_ bv1 1) (_ bv0 1))))
(let (($x478 (= (_ bv1 1) ?x1482)))
(let ((?x150 (ite $x478 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x89 (or false false false)))
(let (($x1289 (or $x89 (ite $x478 false false))))
(and (not $x1289) (or $x1289 (and (distinct ?x150 ?x150) true)))))))))
(check-sat)
; query 192: function Quantization_and_coding, block 124, name %128
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in121_64 () (_ BitVec 64))
(assert
 (let ((?x1482 (ite (bvslt (_ bv0 64) in121_64) (_ bv1 1) (_ bv0 1))))
(let (($x478 (= (_ bv1 1) ?x1482)))
(let ((?x150 (ite $x478 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x960 ((_ sign_extend 32) ?x150)))
(let (($x89 (or false false false)))
(let (($x1289 (or $x89 (ite $x478 false false))))
(let (($x276 (or $x1289 false)))
(and (not $x276) (or $x276 (and (distinct ?x960 ?x960) true)))))))))))
(check-sat)
; query 193: function Quantization_and_coding, block 139, name %140
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in135_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 16) in135_16) ((_ sign_extend 16) in135_16)) true))))))
(check-sat)
; query 194: function Quantization_and_coding, block 139, name %141
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in135_16 () (_ BitVec 16))
(assert
 (let ((?x729 (ite (bvsgt (_ bv4294967280 32) ((_ sign_extend 16) in135_16)) (_ bv1 1) (_ bv0 1))))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x2665 (not $x2657)))
(and $x2665 (or $x2657 (and (distinct ?x729 ?x729) true))))))))
(check-sat)
; query 195: function Quantization_and_coding, block 143, name %144
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in135_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 16) in135_16) ((_ sign_extend 16) in135_16)) true))))))
(check-sat)
; query 196: function Quantization_and_coding, block 143, name %145
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in135_16 () (_ BitVec 16))
(assert
 (let ((?x930 ((_ sign_extend 16) in135_16)))
(let ((?x1666 (bvsub ?x930 (_ bv4294967280 32))))
(let (($x37 (and (distinct (bvsub ((_ sign_extend 1) ?x930) ((_ sign_extend 1) (_ bv4294967280 32))) ((_ sign_extend 1) ?x1666)) true)))
(let (($x2656 (or false false)))
(let (($x1668 (or $x2656 false (or $x37))))
(and (not $x1668) (or $x1668 (and (distinct ?x1666 ?x1666) true)))))))))
(check-sat)
; query 197: function Quantization_and_coding, block 161, name %162
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in158_64 () (_ BitVec 64))
(assert
 (let ((?x315 (ite (bvslt (_ bv0 64) in158_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x315 ?x315) true)))))))
(check-sat)
; query 198: function Quantization_and_coding, block 161, name %163
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in158_64 () (_ BitVec 64))
(assert
 (let ((?x315 (ite (bvslt (_ bv0 64) in158_64) (_ bv1 1) (_ bv0 1))))
(let ((?x2062 ((_ zero_extend 63) ?x315)))
(let (($x89 (or false false false)))
(let (($x56 (or $x89 false)))
(let (($x257 (not $x56)))
(and $x257 (or $x56 (and (distinct ?x2062 ?x2062) true)))))))))
(check-sat)
; query 199: function Quantization_and_coding, block 161, name %164
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in158_64 () (_ BitVec 64))
(assert
 (let ((?x315 (ite (bvslt (_ bv0 64) in158_64) (_ bv1 1) (_ bv0 1))))
(let (($x2058 (= (_ bv1 1) ?x315)))
(let ((?x1188 (ite $x2058 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x89 (or false false false)))
(let (($x2042 (or $x89 (ite $x2058 false false))))
(and (not $x2042) (or $x2042 (and (distinct ?x1188 ?x1188) true)))))))))
(check-sat)
; query 200: function Quantization_and_coding, block 161, name %165
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in158_64 () (_ BitVec 64))
(assert
 (let ((?x315 (ite (bvslt (_ bv0 64) in158_64) (_ bv1 1) (_ bv0 1))))
(let (($x2058 (= (_ bv1 1) ?x315)))
(let ((?x1188 (ite $x2058 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x2051 ((_ sign_extend 32) ?x1188)))
(let (($x89 (or false false false)))
(let (($x2042 (or $x89 (ite $x2058 false false))))
(let (($x2036 (or $x2042 false)))
(and (not $x2036) (or $x2036 (and (distinct ?x2051 ?x2051) true)))))))))))
(check-sat)
; query 201: function Quantization_and_coding, block 174, name %175
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in171_64 () (_ BitVec 64))
(assert
 (let ((?x2014 (ite (bvslt (_ bv0 64) in171_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x2014 ?x2014) true)))))))
(check-sat)
; query 202: function Quantization_and_coding, block 174, name %176
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in171_64 () (_ BitVec 64))
(assert
 (let ((?x2014 (ite (bvslt (_ bv0 64) in171_64) (_ bv1 1) (_ bv0 1))))
(let ((?x483 ((_ zero_extend 63) ?x2014)))
(let (($x89 (or false false false)))
(let (($x56 (or $x89 false)))
(let (($x257 (not $x56)))
(and $x257 (or $x56 (and (distinct ?x483 ?x483) true)))))))))
(check-sat)
; query 203: function Quantization_and_coding, block 174, name %177
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in171_64 () (_ BitVec 64))
(assert
 (let ((?x2014 (ite (bvslt (_ bv0 64) in171_64) (_ bv1 1) (_ bv0 1))))
(let (($x2018 (= (_ bv1 1) ?x2014)))
(let ((?x2019 (ite $x2018 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x89 (or false false false)))
(let (($x811 (or $x89 (ite $x2018 false false))))
(and (not $x811) (or $x811 (and (distinct ?x2019 ?x2019) true)))))))))
(check-sat)
; query 204: function Quantization_and_coding, block 174, name %178
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in171_64 () (_ BitVec 64))
(assert
 (let ((?x2014 (ite (bvslt (_ bv0 64) in171_64) (_ bv1 1) (_ bv0 1))))
(let (($x2018 (= (_ bv1 1) ?x2014)))
(let ((?x2019 (ite $x2018 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x2073 ((_ sign_extend 32) ?x2019)))
(let (($x89 (or false false false)))
(let (($x811 (or $x89 (ite $x2018 false false))))
(let (($x2068 (or $x811 false)))
(and (not $x2068) (or $x2068 (and (distinct ?x2073 ?x2073) true)))))))))))
(check-sat)
; query 205: function Quantization_and_coding, block 189, name %190
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in185_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 16) in185_16) ((_ sign_extend 16) in185_16)) true))))))
(check-sat)
; query 206: function Quantization_and_coding, block 189, name %191
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in185_16 () (_ BitVec 16))
(assert
 (let ((?x640 (ite (bvsgt (_ bv4294967280 32) ((_ sign_extend 16) in185_16)) (_ bv1 1) (_ bv0 1))))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x2665 (not $x2657)))
(and $x2665 (or $x2657 (and (distinct ?x640 ?x640) true))))))))
(check-sat)
; query 207: function Quantization_and_coding, block 193, name %194
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in185_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 16) in185_16) ((_ sign_extend 16) in185_16)) true))))))
(check-sat)
; query 208: function Quantization_and_coding, block 193, name %195
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in185_16 () (_ BitVec 16))
(assert
 (let ((?x2088 ((_ sign_extend 16) in185_16)))
(let ((?x460 (bvsub ?x2088 (_ bv4294967280 32))))
(let (($x1545 (and (distinct (bvsub ((_ sign_extend 1) ?x2088) ((_ sign_extend 1) (_ bv4294967280 32))) ((_ sign_extend 1) ?x460)) true)))
(let (($x2656 (or false false)))
(let (($x903 (or $x2656 false (or $x1545))))
(and (not $x903) (or $x903 (and (distinct ?x460 ?x460) true)))))))))
(check-sat)
; query 209: function Quantization_and_coding, block 211, name %212
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in208_64 () (_ BitVec 64))
(assert
 (let ((?x1525 (ite (bvslt (_ bv0 64) in208_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x1525 ?x1525) true)))))))
(check-sat)
; query 210: function Quantization_and_coding, block 211, name %213
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in208_64 () (_ BitVec 64))
(assert
 (let ((?x1525 (ite (bvslt (_ bv0 64) in208_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1352 ((_ zero_extend 63) ?x1525)))
(let (($x89 (or false false false)))
(let (($x56 (or $x89 false)))
(let (($x257 (not $x56)))
(and $x257 (or $x56 (and (distinct ?x1352 ?x1352) true)))))))))
(check-sat)
; query 211: function Quantization_and_coding, block 211, name %214
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in208_64 () (_ BitVec 64))
(assert
 (let ((?x1525 (ite (bvslt (_ bv0 64) in208_64) (_ bv1 1) (_ bv0 1))))
(let (($x1333 (= (_ bv1 1) ?x1525)))
(let ((?x1640 (ite $x1333 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x89 (or false false false)))
(let (($x1330 (or $x89 (ite $x1333 false false))))
(and (not $x1330) (or $x1330 (and (distinct ?x1640 ?x1640) true)))))))))
(check-sat)
; query 212: function Quantization_and_coding, block 211, name %215
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in208_64 () (_ BitVec 64))
(assert
 (let ((?x1525 (ite (bvslt (_ bv0 64) in208_64) (_ bv1 1) (_ bv0 1))))
(let (($x1333 (= (_ bv1 1) ?x1525)))
(let ((?x1640 (ite $x1333 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x1544 ((_ sign_extend 32) ?x1640)))
(let (($x89 (or false false false)))
(let (($x1330 (or $x89 (ite $x1333 false false))))
(let (($x603 (or $x1330 false)))
(and (not $x603) (or $x603 (and (distinct ?x1544 ?x1544) true)))))))))))
(check-sat)
; query 213: function Quantization_and_coding, block 224, name %225
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in221_64 () (_ BitVec 64))
(assert
 (let ((?x1013 (ite (bvslt (_ bv0 64) in221_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x1013 ?x1013) true)))))))
(check-sat)
; query 214: function Quantization_and_coding, block 224, name %226
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in221_64 () (_ BitVec 64))
(assert
 (let ((?x1013 (ite (bvslt (_ bv0 64) in221_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1516 ((_ zero_extend 63) ?x1013)))
(let (($x89 (or false false false)))
(let (($x56 (or $x89 false)))
(let (($x257 (not $x56)))
(and $x257 (or $x56 (and (distinct ?x1516 ?x1516) true)))))))))
(check-sat)
; query 215: function Quantization_and_coding, block 224, name %227
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in221_64 () (_ BitVec 64))
(assert
 (let ((?x1013 (ite (bvslt (_ bv0 64) in221_64) (_ bv1 1) (_ bv0 1))))
(let (($x1537 (= (_ bv1 1) ?x1013)))
(let ((?x1072 (ite $x1537 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x89 (or false false false)))
(let (($x1068 (or $x89 (ite $x1537 false false))))
(and (not $x1068) (or $x1068 (and (distinct ?x1072 ?x1072) true)))))))))
(check-sat)
; query 216: function Quantization_and_coding, block 224, name %228
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in221_64 () (_ BitVec 64))
(assert
 (let ((?x1013 (ite (bvslt (_ bv0 64) in221_64) (_ bv1 1) (_ bv0 1))))
(let (($x1537 (= (_ bv1 1) ?x1013)))
(let ((?x1072 (ite $x1537 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x2092 ((_ sign_extend 32) ?x1072)))
(let (($x89 (or false false false)))
(let (($x1068 (or $x89 (ite $x1537 false false))))
(let (($x1413 (or $x1068 false)))
(and (not $x1413) (or $x1413 (and (distinct ?x2092 ?x2092) true)))))))))))
(check-sat)
; query 217: function Quantization_and_coding, block 239, name %240
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in235_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 16) in235_16) ((_ sign_extend 16) in235_16)) true))))))
(check-sat)
; query 218: function Quantization_and_coding, block 239, name %241
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in235_16 () (_ BitVec 16))
(assert
 (let ((?x1369 (ite (bvsgt (_ bv4294967288 32) ((_ sign_extend 16) in235_16)) (_ bv1 1) (_ bv0 1))))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x2665 (not $x2657)))
(and $x2665 (or $x2657 (and (distinct ?x1369 ?x1369) true))))))))
(check-sat)
; query 219: function Quantization_and_coding, block 24, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_64 () (_ BitVec 64))
(assert
 (let ((?x773 (ite (bvslt (_ bv0 64) in21_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x773 ?x773) true)))))))
(check-sat)
; query 220: function Quantization_and_coding, block 24, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_64 () (_ BitVec 64))
(assert
 (let ((?x773 (ite (bvslt (_ bv0 64) in21_64) (_ bv1 1) (_ bv0 1))))
(let ((?x635 ((_ zero_extend 63) ?x773)))
(let (($x89 (or false false false)))
(let (($x56 (or $x89 false)))
(let (($x257 (not $x56)))
(and $x257 (or $x56 (and (distinct ?x635 ?x635) true)))))))))
(check-sat)
; query 221: function Quantization_and_coding, block 24, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_64 () (_ BitVec 64))
(assert
 (let ((?x773 (ite (bvslt (_ bv0 64) in21_64) (_ bv1 1) (_ bv0 1))))
(let (($x953 (= (_ bv1 1) ?x773)))
(let ((?x1716 (ite $x953 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x89 (or false false false)))
(let (($x1177 (or $x89 (ite $x953 false false))))
(and (not $x1177) (or $x1177 (and (distinct ?x1716 ?x1716) true)))))))))
(check-sat)
; query 222: function Quantization_and_coding, block 24, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_64 () (_ BitVec 64))
(assert
 (let ((?x773 (ite (bvslt (_ bv0 64) in21_64) (_ bv1 1) (_ bv0 1))))
(let (($x953 (= (_ bv1 1) ?x773)))
(let ((?x1716 (ite $x953 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x405 ((_ sign_extend 32) ?x1716)))
(let (($x89 (or false false false)))
(let (($x1177 (or $x89 (ite $x953 false false))))
(let (($x758 (or $x1177 false)))
(and (not $x758) (or $x758 (and (distinct ?x405 ?x405) true)))))))))))
(check-sat)
; query 223: function Quantization_and_coding, block 243, name %244
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in235_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 16) in235_16) ((_ sign_extend 16) in235_16)) true))))))
(check-sat)
; query 224: function Quantization_and_coding, block 243, name %245
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in235_16 () (_ BitVec 16))
(assert
 (let ((?x140 ((_ sign_extend 16) in235_16)))
(let ((?x1389 (bvsub ?x140 (_ bv4294967288 32))))
(let (($x1157 (and (distinct (bvsub ((_ sign_extend 1) ?x140) ((_ sign_extend 1) (_ bv4294967288 32))) ((_ sign_extend 1) ?x1389)) true)))
(let (($x2656 (or false false)))
(let (($x676 (or $x2656 false (or $x1157))))
(and (not $x676) (or $x676 (and (distinct ?x1389 ?x1389) true)))))))))
(check-sat)
; query 225: function Quantization_and_coding, block 261, name %262
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in258_64 () (_ BitVec 64))
(assert
 (let ((?x613 (ite (bvslt (_ bv0 64) in258_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x613 ?x613) true)))))))
(check-sat)
; query 226: function Quantization_and_coding, block 261, name %263
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in258_64 () (_ BitVec 64))
(assert
 (let ((?x613 (ite (bvslt (_ bv0 64) in258_64) (_ bv1 1) (_ bv0 1))))
(let ((?x264 ((_ zero_extend 63) ?x613)))
(let (($x89 (or false false false)))
(let (($x56 (or $x89 false)))
(let (($x257 (not $x56)))
(and $x257 (or $x56 (and (distinct ?x264 ?x264) true)))))))))
(check-sat)
; query 227: function Quantization_and_coding, block 261, name %264
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in258_64 () (_ BitVec 64))
(assert
 (let ((?x613 (ite (bvslt (_ bv0 64) in258_64) (_ bv1 1) (_ bv0 1))))
(let (($x913 (= (_ bv1 1) ?x613)))
(let ((?x680 (ite $x913 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x89 (or false false false)))
(let (($x786 (or $x89 (ite $x913 false false))))
(and (not $x786) (or $x786 (and (distinct ?x680 ?x680) true)))))))))
(check-sat)
; query 228: function Quantization_and_coding, block 261, name %265
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in258_64 () (_ BitVec 64))
(assert
 (let ((?x613 (ite (bvslt (_ bv0 64) in258_64) (_ bv1 1) (_ bv0 1))))
(let (($x913 (= (_ bv1 1) ?x613)))
(let ((?x680 (ite $x913 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x1951 ((_ sign_extend 32) ?x680)))
(let (($x89 (or false false false)))
(let (($x786 (or $x89 (ite $x913 false false))))
(let (($x36 (or $x786 false)))
(and (not $x36) (or $x36 (and (distinct ?x1951 ?x1951) true)))))))))))
(check-sat)
; query 229: function Quantization_and_coding, block 274, name %275
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in271_64 () (_ BitVec 64))
(assert
 (let ((?x1889 (ite (bvslt (_ bv0 64) in271_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x1889 ?x1889) true)))))))
(check-sat)
; query 230: function Quantization_and_coding, block 274, name %276
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in271_64 () (_ BitVec 64))
(assert
 (let ((?x1889 (ite (bvslt (_ bv0 64) in271_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1184 ((_ zero_extend 63) ?x1889)))
(let (($x89 (or false false false)))
(let (($x56 (or $x89 false)))
(let (($x257 (not $x56)))
(and $x257 (or $x56 (and (distinct ?x1184 ?x1184) true)))))))))
(check-sat)
; query 231: function Quantization_and_coding, block 274, name %277
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in271_64 () (_ BitVec 64))
(assert
 (let ((?x1889 (ite (bvslt (_ bv0 64) in271_64) (_ bv1 1) (_ bv0 1))))
(let (($x1882 (= (_ bv1 1) ?x1889)))
(let ((?x1605 (ite $x1882 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x89 (or false false false)))
(let (($x214 (or $x89 (ite $x1882 false false))))
(and (not $x214) (or $x214 (and (distinct ?x1605 ?x1605) true)))))))))
(check-sat)
; query 232: function Quantization_and_coding, block 274, name %278
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in271_64 () (_ BitVec 64))
(assert
 (let ((?x1889 (ite (bvslt (_ bv0 64) in271_64) (_ bv1 1) (_ bv0 1))))
(let (($x1882 (= (_ bv1 1) ?x1889)))
(let ((?x1605 (ite $x1882 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x677 ((_ sign_extend 32) ?x1605)))
(let (($x89 (or false false false)))
(let (($x214 (or $x89 (ite $x1882 false false))))
(let (($x1682 (or $x214 false)))
(and (not $x1682) (or $x1682 (and (distinct ?x677 ?x677) true)))))))))))
(check-sat)
; query 233: function Quantization_and_coding, block 289, name %290
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in285_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 16) in285_16) ((_ sign_extend 16) in285_16)) true))))))
(check-sat)
; query 234: function Quantization_and_coding, block 289, name %291
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in285_16 () (_ BitVec 16))
(assert
 (let ((?x807 (ite (bvsgt (_ bv4294967288 32) ((_ sign_extend 16) in285_16)) (_ bv1 1) (_ bv0 1))))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x2665 (not $x2657)))
(and $x2665 (or $x2657 (and (distinct ?x807 ?x807) true))))))))
(check-sat)
; query 235: function Quantization_and_coding, block 293, name %294
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in285_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 16) in285_16) ((_ sign_extend 16) in285_16)) true))))))
(check-sat)
; query 236: function Quantization_and_coding, block 293, name %295
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in285_16 () (_ BitVec 16))
(assert
 (let ((?x1645 ((_ sign_extend 16) in285_16)))
(let ((?x1409 (bvsub ?x1645 (_ bv4294967288 32))))
(let (($x1336 (and (distinct (bvsub ((_ sign_extend 1) ?x1645) ((_ sign_extend 1) (_ bv4294967288 32))) ((_ sign_extend 1) ?x1409)) true)))
(let (($x2656 (or false false)))
(let (($x155 (or $x2656 false (or $x1336))))
(and (not $x155) (or $x155 (and (distinct ?x1409 ?x1409) true)))))))))
(check-sat)
; query 237: function Quantization_and_coding, block 311, name %312
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in308_64 () (_ BitVec 64))
(assert
 (let ((?x1512 (ite (bvslt (_ bv0 64) in308_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x1512 ?x1512) true)))))))
(check-sat)
; query 238: function Quantization_and_coding, block 311, name %313
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in308_64 () (_ BitVec 64))
(assert
 (let ((?x1512 (ite (bvslt (_ bv0 64) in308_64) (_ bv1 1) (_ bv0 1))))
(let ((?x301 ((_ zero_extend 63) ?x1512)))
(let (($x89 (or false false false)))
(let (($x56 (or $x89 false)))
(let (($x257 (not $x56)))
(and $x257 (or $x56 (and (distinct ?x301 ?x301) true)))))))))
(check-sat)
; query 239: function Quantization_and_coding, block 311, name %314
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in308_64 () (_ BitVec 64))
(assert
 (let ((?x1512 (ite (bvslt (_ bv0 64) in308_64) (_ bv1 1) (_ bv0 1))))
(let (($x1609 (= (_ bv1 1) ?x1512)))
(let ((?x1131 (ite $x1609 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x89 (or false false false)))
(let (($x1567 (or $x89 (ite $x1609 false false))))
(and (not $x1567) (or $x1567 (and (distinct ?x1131 ?x1131) true)))))))))
(check-sat)
; query 240: function Quantization_and_coding, block 311, name %315
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in308_64 () (_ BitVec 64))
(assert
 (let ((?x1512 (ite (bvslt (_ bv0 64) in308_64) (_ bv1 1) (_ bv0 1))))
(let (($x1609 (= (_ bv1 1) ?x1512)))
(let ((?x1131 (ite $x1609 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x1462 ((_ sign_extend 32) ?x1131)))
(let (($x89 (or false false false)))
(let (($x1567 (or $x89 (ite $x1609 false false))))
(let (($x814 (or $x1567 false)))
(and (not $x814) (or $x814 (and (distinct ?x1462 ?x1462) true)))))))))))
(check-sat)
; query 241: function Quantization_and_coding, block 324, name %325
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in321_64 () (_ BitVec 64))
(assert
 (let ((?x71 (ite (bvslt (_ bv0 64) in321_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x71 ?x71) true)))))))
(check-sat)
; query 242: function Quantization_and_coding, block 324, name %326
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in321_64 () (_ BitVec 64))
(assert
 (let ((?x71 (ite (bvslt (_ bv0 64) in321_64) (_ bv1 1) (_ bv0 1))))
(let ((?x533 ((_ zero_extend 63) ?x71)))
(let (($x89 (or false false false)))
(let (($x56 (or $x89 false)))
(let (($x257 (not $x56)))
(and $x257 (or $x56 (and (distinct ?x533 ?x533) true)))))))))
(check-sat)
; query 243: function Quantization_and_coding, block 324, name %327
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in321_64 () (_ BitVec 64))
(assert
 (let ((?x71 (ite (bvslt (_ bv0 64) in321_64) (_ bv1 1) (_ bv0 1))))
(let (($x1616 (= (_ bv1 1) ?x71)))
(let ((?x138 (ite $x1616 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x89 (or false false false)))
(let (($x112 (or $x89 (ite $x1616 false false))))
(and (not $x112) (or $x112 (and (distinct ?x138 ?x138) true)))))))))
(check-sat)
; query 244: function Quantization_and_coding, block 324, name %328
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in321_64 () (_ BitVec 64))
(assert
 (let ((?x71 (ite (bvslt (_ bv0 64) in321_64) (_ bv1 1) (_ bv0 1))))
(let (($x1616 (= (_ bv1 1) ?x71)))
(let ((?x138 (ite $x1616 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x401 ((_ sign_extend 32) ?x138)))
(let (($x89 (or false false false)))
(let (($x112 (or $x89 (ite $x1616 false false))))
(let (($x1673 (or $x112 false)))
(and (not $x1673) (or $x1673 (and (distinct ?x401 ?x401) true)))))))))))
(check-sat)
; query 245: function Quantization_and_coding, block 339, name %340
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in335_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 16) in335_16) ((_ sign_extend 16) in335_16)) true))))))
(check-sat)
; query 246: function Quantization_and_coding, block 339, name %341
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in335_16 () (_ BitVec 16))
(assert
 (let ((?x1265 (ite (bvsgt (_ bv4294967292 32) ((_ sign_extend 16) in335_16)) (_ bv1 1) (_ bv0 1))))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x2665 (not $x2657)))
(and $x2665 (or $x2657 (and (distinct ?x1265 ?x1265) true))))))))
(check-sat)
; query 247: function Quantization_and_coding, block 343, name %344
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in335_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 16) in335_16) ((_ sign_extend 16) in335_16)) true))))))
(check-sat)
; query 248: function Quantization_and_coding, block 343, name %345
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in335_16 () (_ BitVec 16))
(assert
 (let ((?x197 ((_ sign_extend 16) in335_16)))
(let ((?x497 (bvsub ?x197 (_ bv4294967292 32))))
(let (($x957 (and (distinct (bvsub ((_ sign_extend 1) ?x197) ((_ sign_extend 1) (_ bv4294967292 32))) ((_ sign_extend 1) ?x497)) true)))
(let (($x2656 (or false false)))
(let (($x288 (or $x2656 false (or $x957))))
(and (not $x288) (or $x288 (and (distinct ?x497 ?x497) true)))))))))
(check-sat)
; query 249: function Quantization_and_coding, block 361, name %362
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in358_64 () (_ BitVec 64))
(assert
 (let ((?x265 (ite (bvslt (_ bv0 64) in358_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x265 ?x265) true)))))))
(check-sat)
; query 250: function Quantization_and_coding, block 361, name %363
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in358_64 () (_ BitVec 64))
(assert
 (let ((?x265 (ite (bvslt (_ bv0 64) in358_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1686 ((_ zero_extend 63) ?x265)))
(let (($x89 (or false false false)))
(let (($x56 (or $x89 false)))
(let (($x257 (not $x56)))
(and $x257 (or $x56 (and (distinct ?x1686 ?x1686) true)))))))))
(check-sat)
; query 251: function Quantization_and_coding, block 361, name %364
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in358_64 () (_ BitVec 64))
(assert
 (let ((?x265 (ite (bvslt (_ bv0 64) in358_64) (_ bv1 1) (_ bv0 1))))
(let (($x1778 (= (_ bv1 1) ?x265)))
(let ((?x991 (ite $x1778 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x89 (or false false false)))
(let (($x834 (or $x89 (ite $x1778 false false))))
(and (not $x834) (or $x834 (and (distinct ?x991 ?x991) true)))))))))
(check-sat)
; query 252: function Quantization_and_coding, block 361, name %365
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in358_64 () (_ BitVec 64))
(assert
 (let ((?x265 (ite (bvslt (_ bv0 64) in358_64) (_ bv1 1) (_ bv0 1))))
(let (($x1778 (= (_ bv1 1) ?x265)))
(let ((?x991 (ite $x1778 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x1325 ((_ sign_extend 32) ?x991)))
(let (($x89 (or false false false)))
(let (($x834 (or $x89 (ite $x1778 false false))))
(let (($x1676 (or $x834 false)))
(and (not $x1676) (or $x1676 (and (distinct ?x1325 ?x1325) true)))))))))))
(check-sat)
; query 253: function Quantization_and_coding, block 374, name %375
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in371_64 () (_ BitVec 64))
(assert
 (let ((?x1767 (ite (bvslt (_ bv0 64) in371_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x1767 ?x1767) true)))))))
(check-sat)
; query 254: function Quantization_and_coding, block 374, name %376
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in371_64 () (_ BitVec 64))
(assert
 (let ((?x1767 (ite (bvslt (_ bv0 64) in371_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1547 ((_ zero_extend 63) ?x1767)))
(let (($x89 (or false false false)))
(let (($x56 (or $x89 false)))
(let (($x257 (not $x56)))
(and $x257 (or $x56 (and (distinct ?x1547 ?x1547) true)))))))))
(check-sat)
; query 255: function Quantization_and_coding, block 374, name %377
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in371_64 () (_ BitVec 64))
(assert
 (let ((?x1767 (ite (bvslt (_ bv0 64) in371_64) (_ bv1 1) (_ bv0 1))))
(let (($x1530 (= (_ bv1 1) ?x1767)))
(let ((?x1382 (ite $x1530 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x89 (or false false false)))
(let (($x296 (or $x89 (ite $x1530 false false))))
(and (not $x296) (or $x296 (and (distinct ?x1382 ?x1382) true)))))))))
(check-sat)
; query 256: function Quantization_and_coding, block 374, name %378
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in371_64 () (_ BitVec 64))
(assert
 (let ((?x1767 (ite (bvslt (_ bv0 64) in371_64) (_ bv1 1) (_ bv0 1))))
(let (($x1530 (= (_ bv1 1) ?x1767)))
(let ((?x1382 (ite $x1530 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x472 ((_ sign_extend 32) ?x1382)))
(let (($x89 (or false false false)))
(let (($x296 (or $x89 (ite $x1530 false false))))
(let (($x873 (or $x296 false)))
(and (not $x873) (or $x873 (and (distinct ?x472 ?x472) true)))))))))))
(check-sat)
; query 257: function Quantization_and_coding, block 389, name %390
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in385_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 16) in385_16) ((_ sign_extend 16) in385_16)) true))))))
(check-sat)
; query 258: function Quantization_and_coding, block 389, name %391
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in385_16 () (_ BitVec 16))
(assert
 (let ((?x159 (ite (bvsgt (_ bv4294967292 32) ((_ sign_extend 16) in385_16)) (_ bv1 1) (_ bv0 1))))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x2665 (not $x2657)))
(and $x2665 (or $x2657 (and (distinct ?x159 ?x159) true))))))))
(check-sat)
; query 259: function Quantization_and_coding, block 39, name %40
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in35_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 16) in35_16) ((_ sign_extend 16) in35_16)) true))))))
(check-sat)
; query 260: function Quantization_and_coding, block 39, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in35_16 () (_ BitVec 16))
(assert
 (let ((?x1557 (ite (bvsgt (_ bv4294967264 32) ((_ sign_extend 16) in35_16)) (_ bv1 1) (_ bv0 1))))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x2665 (not $x2657)))
(and $x2665 (or $x2657 (and (distinct ?x1557 ?x1557) true))))))))
(check-sat)
; query 261: function Quantization_and_coding, block 393, name %394
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in385_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 16) in385_16) ((_ sign_extend 16) in385_16)) true))))))
(check-sat)
; query 262: function Quantization_and_coding, block 393, name %395
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in385_16 () (_ BitVec 16))
(assert
 (let ((?x26 ((_ sign_extend 16) in385_16)))
(let ((?x382 (bvsub ?x26 (_ bv4294967292 32))))
(let (($x1552 (and (distinct (bvsub ((_ sign_extend 1) ?x26) ((_ sign_extend 1) (_ bv4294967292 32))) ((_ sign_extend 1) ?x382)) true)))
(let (($x2656 (or false false)))
(let (($x323 (or $x2656 false (or $x1552))))
(and (not $x323) (or $x323 (and (distinct ?x382 ?x382) true)))))))))
(check-sat)
; query 263: function Quantization_and_coding, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in35_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 16) in35_16) ((_ sign_extend 16) in35_16)) true))))))
(check-sat)
; query 264: function Quantization_and_coding, block 43, name %45
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in35_16 () (_ BitVec 16))
(assert
 (let ((?x554 ((_ sign_extend 16) in35_16)))
(let ((?x347 (bvsub ?x554 (_ bv4294967264 32))))
(let (($x929 (and (distinct (bvsub ((_ sign_extend 1) ?x554) ((_ sign_extend 1) (_ bv4294967264 32))) ((_ sign_extend 1) ?x347)) true)))
(let (($x2656 (or false false)))
(let (($x1054 (or $x2656 false (or $x929))))
(and (not $x1054) (or $x1054 (and (distinct ?x347 ?x347) true)))))))))
(check-sat)
; query 265: function Quantization_and_coding, block 61, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in58_64 () (_ BitVec 64))
(assert
 (let ((?x1073 (ite (bvslt (_ bv0 64) in58_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x1073 ?x1073) true)))))))
(check-sat)
; query 266: function Quantization_and_coding, block 61, name %63
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in58_64 () (_ BitVec 64))
(assert
 (let ((?x1073 (ite (bvslt (_ bv0 64) in58_64) (_ bv1 1) (_ bv0 1))))
(let ((?x341 ((_ zero_extend 63) ?x1073)))
(let (($x89 (or false false false)))
(let (($x56 (or $x89 false)))
(let (($x257 (not $x56)))
(and $x257 (or $x56 (and (distinct ?x341 ?x341) true)))))))))
(check-sat)
; query 267: function Quantization_and_coding, block 61, name %64
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in58_64 () (_ BitVec 64))
(assert
 (let ((?x1073 (ite (bvslt (_ bv0 64) in58_64) (_ bv1 1) (_ bv0 1))))
(let (($x91 (= (_ bv1 1) ?x1073)))
(let ((?x1167 (ite $x91 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x89 (or false false false)))
(let (($x1274 (or $x89 (ite $x91 false false))))
(and (not $x1274) (or $x1274 (and (distinct ?x1167 ?x1167) true)))))))))
(check-sat)
; query 268: function Quantization_and_coding, block 61, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in58_64 () (_ BitVec 64))
(assert
 (let ((?x1073 (ite (bvslt (_ bv0 64) in58_64) (_ bv1 1) (_ bv0 1))))
(let (($x91 (= (_ bv1 1) ?x1073)))
(let ((?x1167 (ite $x91 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x1501 ((_ sign_extend 32) ?x1167)))
(let (($x89 (or false false false)))
(let (($x1274 (or $x89 (ite $x91 false false))))
(let (($x1812 (or $x1274 false)))
(and (not $x1812) (or $x1812 (and (distinct ?x1501 ?x1501) true)))))))))))
(check-sat)
; query 269: function Quantization_and_coding, block 74, name %75
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in71_64 () (_ BitVec 64))
(assert
 (let ((?x874 (ite (bvslt (_ bv0 64) in71_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x874 ?x874) true)))))))
(check-sat)
; query 270: function Quantization_and_coding, block 74, name %76
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in71_64 () (_ BitVec 64))
(assert
 (let ((?x874 (ite (bvslt (_ bv0 64) in71_64) (_ bv1 1) (_ bv0 1))))
(let ((?x808 ((_ zero_extend 63) ?x874)))
(let (($x89 (or false false false)))
(let (($x56 (or $x89 false)))
(let (($x257 (not $x56)))
(and $x257 (or $x56 (and (distinct ?x808 ?x808) true)))))))))
(check-sat)
; query 271: function Quantization_and_coding, block 74, name %77
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in71_64 () (_ BitVec 64))
(assert
 (let ((?x874 (ite (bvslt (_ bv0 64) in71_64) (_ bv1 1) (_ bv0 1))))
(let (($x1401 (= (_ bv1 1) ?x874)))
(let ((?x136 (ite $x1401 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x89 (or false false false)))
(let (($x1548 (or $x89 (ite $x1401 false false))))
(and (not $x1548) (or $x1548 (and (distinct ?x136 ?x136) true)))))))))
(check-sat)
; query 272: function Quantization_and_coding, block 74, name %78
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in71_64 () (_ BitVec 64))
(assert
 (let ((?x874 (ite (bvslt (_ bv0 64) in71_64) (_ bv1 1) (_ bv0 1))))
(let (($x1401 (= (_ bv1 1) ?x874)))
(let ((?x136 (ite $x1401 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x572 ((_ sign_extend 32) ?x136)))
(let (($x89 (or false false false)))
(let (($x1548 (or $x89 (ite $x1401 false false))))
(let (($x1055 (or $x1548 false)))
(and (not $x1055) (or $x1055 (and (distinct ?x572 ?x572) true)))))))))))
(check-sat)
; query 273: function Quantization_and_coding, block 89, name %90
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in85_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 16) in85_16) ((_ sign_extend 16) in85_16)) true))))))
(check-sat)
; query 274: function Quantization_and_coding, block 89, name %91
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in85_16 () (_ BitVec 16))
(assert
 (let ((?x2075 (ite (bvsgt (_ bv4294967264 32) ((_ sign_extend 16) in85_16)) (_ bv1 1) (_ bv0 1))))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x2665 (not $x2657)))
(and $x2665 (or $x2657 (and (distinct ?x2075 ?x2075) true))))))))
(check-sat)
; query 275: function Quantization_and_coding, block 93, name %94
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in85_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 16) in85_16) ((_ sign_extend 16) in85_16)) true))))))
(check-sat)
; query 276: function Quantization_and_coding, block 93, name %95
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in85_16 () (_ BitVec 16))
(assert
 (let ((?x1156 ((_ sign_extend 16) in85_16)))
(let ((?x1915 (bvsub ?x1156 (_ bv4294967264 32))))
(let (($x530 (and (distinct (bvsub ((_ sign_extend 1) ?x1156) ((_ sign_extend 1) (_ bv4294967264 32))) ((_ sign_extend 1) ?x1915)) true)))
(let (($x2656 (or false false)))
(let (($x629 (or $x2656 false (or $x530))))
(and (not $x629) (or $x629 (and (distinct ?x1915 ?x1915) true)))))))))
(check-sat)
; query 277: function RPE_grid_positioning, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.27_32 () (_ BitVec 32))
(assert
 (let (($x1041 (and (distinct (bvadd ((_ sign_extend 1) in.27_32) ((_ sign_extend 1) (_ bv4294967295 32))) ((_ sign_extend 1) (bvadd in.27_32 (_ bv4294967295 32)))) true)))
(let (($x229 (or false false (or $x1041))))
(and (not $x229) (or $x229 (and (distinct (bvadd in.27_32 (_ bv4294967295 32)) (bvadd in.27_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 278: function RPE_grid_positioning, block 31, name %33
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.27_32 () (_ BitVec 32))
(assert
 (let ((?x399 (ite (and (distinct (_ bv0 32) (bvadd in.27_32 (_ bv4294967295 32))) true) (_ bv1 1) (_ bv0 1))))
(let (($x1041 (and (distinct (bvadd ((_ sign_extend 1) in.27_32) ((_ sign_extend 1) (_ bv4294967295 32))) ((_ sign_extend 1) (bvadd in.27_32 (_ bv4294967295 32)))) true)))
(let (($x229 (or false false (or $x1041))))
(let (($x1067 (or $x229 false false)))
(and (not $x1067) (or $x1067 (and (distinct ?x399 ?x399) true))))))))
(check-sat)
; query 279: function RPE_grid_positioning, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 280: function RPE_grid_positioning, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x898 (ite (bvsge (_ bv3 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x2665 (not $x2657)))
(and $x2665 (or $x2657 (and (distinct ?x898 ?x898) true))))))))
(check-sat)
; query 281: function RPE_grid_positioning, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 282: function RPE_grid_positioning, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1239 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1281 (and (distinct ?x1239 ?x1239) true)))
(let (($x2656 (or false false)))
(let (($x1169 (or false $x2656 false)))
(and (not $x1169) (or $x1169 $x1281)))))))
(check-sat)
; query 283: function Reflection_coefficients, block 34, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in31_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 16) in31_16) ((_ sign_extend 16) in31_16)) true))))))
(check-sat)
; query 284: function Reflection_coefficients, block 34, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in31_16 () (_ BitVec 16))
(assert
 (let ((?x1226 (ite (bvsgt (_ bv32 32) ((_ sign_extend 16) in31_16)) (_ bv1 1) (_ bv0 1))))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x2665 (not $x2657)))
(and $x2665 (or $x2657 (and (distinct ?x1226 ?x1226) true))))))))
(check-sat)
; query 285: function gsm_L_add, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_64 () (_ BitVec 64))
(assert
 (let ((?x1485 (bvsub (_ bv0 64) in13_64)))
(let ((?x1495 ((_ sign_extend 1) ?x1485)))
(let (($x1286 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in13_64)) ?x1495) true)))))
(and (not $x1286) (or $x1286 (and (distinct ?x1485 ?x1485) true)))))))
(check-sat)
; query 286: function gsm_L_add, block 16, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_64 () (_ BitVec 64))
(assert
 (let ((?x1485 (bvsub (_ bv0 64) in13_64)))
(let ((?x1511 (bvsub ?x1485 (_ bv2 64))))
(let (($x1272 (and (distinct (bvsub ((_ sign_extend 1) ?x1485) ((_ sign_extend 1) (_ bv2 64))) ((_ sign_extend 1) ?x1511)) true)))
(let ((?x1495 ((_ sign_extend 1) ?x1485)))
(let (($x1286 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in13_64)) ?x1495) true)))))
(let (($x1509 (or $x1286 false (or $x1272))))
(and (not $x1509) (or $x1509 (and (distinct ?x1511 ?x1511) true))))))))))
(check-sat)
; query 287: function gsm_L_add, block 21, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1478 (ite (bvsge (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x1478 ?x1478) true)))))))
(check-sat)
; query 288: function gsm_L_add, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1025 (bvadd in0_64 in1_64)))
(let (($x236 (and (distinct ?x1025 ?x1025) true)))
(let (($x549 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) ?x1025)) true)))
(let (($x604 (or false false (or $x549))))
(and (not $x604) (or $x604 $x236)))))))
(check-sat)
; query 289: function gsm_L_add, block 25, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1025 (bvadd in0_64 in1_64)))
(let (($x236 (and (distinct ?x1025 ?x1025) true)))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 $x236)))))))
(check-sat)
; query 290: function gsm_L_add, block 25, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x801 (ite (bvugt (bvadd in0_64 in1_64) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x168 (or $x89 false false)))
(let (($x1546 (not $x168)))
(and $x1546 (or $x168 (and (distinct ?x801 ?x801) true))))))))
(check-sat)
; query 291: function gsm_L_add, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1925 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x1925 ?x1925) true)))))))
(check-sat)
; query 292: function gsm_L_add, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1025 (bvadd in0_64 in1_64)))
(let (($x236 (and (distinct ?x1025 ?x1025) true)))
(let (($x549 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) ?x1025)) true)))
(let (($x604 (or false false (or $x549))))
(and (not $x604) (or $x604 $x236)))))))
(check-sat)
; query 293: function gsm_L_add, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x174 (bvadd in0_64 (_ bv1 64))))
(let ((?x110 (bvsub (_ bv0 64) ?x174)))
(let (($x1093 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x174)) ((_ sign_extend 1) ?x110)) true)))
(let ((?x833 ((_ sign_extend 1) ?x174)))
(let (($x455 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x833) true)))))
(let (($x1917 (or false $x455 (or $x1093))))
(and (not $x1917) (or $x1917 (and (distinct ?x110 ?x110) true))))))))))
(check-sat)
; query 294: function gsm_L_add, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x958 (bvadd in1_64 (_ bv1 64))))
(let ((?x791 ((_ sign_extend 1) ?x958)))
(let (($x1027 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x791) true)))))
(and (not $x1027) (or $x1027 (and (distinct ?x958 ?x958) true)))))))
(check-sat)
; query 295: function gsm_L_add, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x958 (bvadd in1_64 (_ bv1 64))))
(let ((?x424 (bvsub (_ bv0 64) ?x958)))
(let (($x1486 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x958)) ((_ sign_extend 1) ?x424)) true)))
(let ((?x791 ((_ sign_extend 1) ?x958)))
(let (($x1027 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x791) true)))))
(let (($x22 (or false $x1027 (or $x1486))))
(and (not $x22) (or $x22 (and (distinct ?x424 ?x424) true))))))))))
(check-sat)
; query 296: function gsm_L_add, block 8, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x958 (bvadd in1_64 (_ bv1 64))))
(let ((?x424 (bvsub (_ bv0 64) ?x958)))
(let ((?x174 (bvadd in0_64 (_ bv1 64))))
(let ((?x110 (bvsub (_ bv0 64) ?x174)))
(let ((?x1892 (bvadd ?x110 ?x424)))
(let (($x1486 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x958)) ((_ sign_extend 1) ?x424)) true)))
(let ((?x791 ((_ sign_extend 1) ?x958)))
(let (($x1027 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x791) true)))))
(let (($x22 (or false $x1027 (or $x1486))))
(let (($x1093 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x174)) ((_ sign_extend 1) ?x110)) true)))
(let ((?x833 ((_ sign_extend 1) ?x174)))
(let (($x455 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x833) true)))))
(let (($x1917 (or false $x455 (or $x1093))))
(let (($x1798 (or $x1917 $x22 false)))
(and (not $x1798) (or $x1798 (and (distinct ?x1892 ?x1892) true))))))))))))))))))
(check-sat)
; query 297: function gsm_L_add, block 8, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x958 (bvadd in1_64 (_ bv1 64))))
(let ((?x424 (bvsub (_ bv0 64) ?x958)))
(let ((?x174 (bvadd in0_64 (_ bv1 64))))
(let ((?x110 (bvsub (_ bv0 64) ?x174)))
(let ((?x1892 (bvadd ?x110 ?x424)))
(let ((?x364 (ite (bvuge ?x1892 (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x1486 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x958)) ((_ sign_extend 1) ?x424)) true)))
(let ((?x791 ((_ sign_extend 1) ?x958)))
(let (($x1027 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x791) true)))))
(let (($x22 (or false $x1027 (or $x1486))))
(let (($x1093 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x174)) ((_ sign_extend 1) ?x110)) true)))
(let ((?x833 ((_ sign_extend 1) ?x174)))
(let (($x455 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x833) true)))))
(let (($x1917 (or false $x455 (or $x1093))))
(let (($x1798 (or $x1917 $x22 false)))
(let (($x305 (or $x1798 false false)))
(and (not $x305) (or $x305 (and (distinct ?x364 ?x364) true))))))))))))))))))))
(check-sat)
; query 298: function gsm_L_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x174 (bvadd in0_64 (_ bv1 64))))
(let ((?x833 ((_ sign_extend 1) ?x174)))
(let (($x455 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x833) true)))))
(and (not $x455) (or $x455 (and (distinct ?x174 ?x174) true)))))))
(check-sat)
; query 299: function gsm_L_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1154 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x1154 ?x1154) true)))))))
(check-sat)
; query 300: function gsm_L_asl, block 12, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1358 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x1358 ?x1358) true)))))))
(check-sat)
; query 301: function gsm_L_asl, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ zero_extend 32) in1_32) ((_ zero_extend 32) in1_32)) true))))))
(check-sat)
; query 302: function gsm_L_asl, block 17, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1967 ((_ zero_extend 32) in1_32)))
(let ((?x668 (bvshl in0_64 ?x1967)))
(let (($x2656 (or false false)))
(let (($x1169 (or false $x2656 false)))
(let (($x728 (or $x1169 (bvuge ?x1967 (_ bv64 64)))))
(let (($x449 (not $x728)))
(and $x449 (or $x728 (and (distinct ?x668 ?x668) true))))))))))
(check-sat)
; query 303: function gsm_L_asl, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1086 (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x1086 ?x1086) true)))))))
(check-sat)
; query 304: function gsm_L_asl, block 7, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1154 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1280 ((_ zero_extend 31) ?x1154)))
(let ((?x1350 (bvsub (_ bv0 32) ?x1280)))
(let (($x964 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1280)) ((_ sign_extend 1) ?x1350)) true)))
(let (($x89 (or false false false)))
(let (($x56 (or $x89 false)))
(let (($x502 (or false $x56 (or $x964))))
(and (not $x502) (or $x502 (and (distinct ?x1350 ?x1350) true)))))))))))
(check-sat)
; query 305: function gsm_L_asl, block 7, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1154 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1280 ((_ zero_extend 31) ?x1154)))
(let ((?x1350 (bvsub (_ bv0 32) ?x1280)))
(let ((?x430 ((_ sign_extend 32) ?x1350)))
(let (($x964 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1280)) ((_ sign_extend 1) ?x1350)) true)))
(let (($x89 (or false false false)))
(let (($x56 (or $x89 false)))
(let (($x502 (or false $x56 (or $x964))))
(let (($x65 (or $x502 false)))
(and (not $x65) (or $x65 (and (distinct ?x430 ?x430) true)))))))))))))
(check-sat)
; query 306: function gsm_L_asl, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1154 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x1154 ?x1154) true)))))))
(check-sat)
; query 307: function gsm_L_asl, block 7, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1154 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1280 ((_ zero_extend 31) ?x1154)))
(let (($x89 (or false false false)))
(let (($x56 (or $x89 false)))
(let (($x257 (not $x56)))
(and $x257 (or $x56 (and (distinct ?x1280 ?x1280) true)))))))))
(check-sat)
; query 308: function gsm_L_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x580 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x580 ?x580) true)))))))
(check-sat)
; query 309: function gsm_L_asr, block 12, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1358 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x1358 ?x1358) true)))))))
(check-sat)
; query 310: function gsm_L_asr, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x378 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in1_32))) true)))
(let (($x956 (or false false (or $x378))))
(and (not $x956) (or $x956 (and (distinct (bvsub (_ bv0 32) in1_32) (bvsub (_ bv0 32) in1_32)) true))))))
(check-sat)
; query 311: function gsm_L_asr, block 14, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1742 (bvsub (_ bv0 32) in1_32)))
(let ((?x1746 ((_ zero_extend 32) ?x1742)))
(let (($x378 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x1742)) true)))
(let (($x956 (or false false (or $x378))))
(let (($x774 (or $x956 false)))
(and (not $x774) (or $x774 (and (distinct ?x1746 ?x1746) true)))))))))
(check-sat)
; query 312: function gsm_L_asr, block 14, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1742 (bvsub (_ bv0 32) in1_32)))
(let ((?x1746 ((_ zero_extend 32) ?x1742)))
(let ((?x1741 (bvshl in0_64 ?x1746)))
(let (($x378 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x1742)) true)))
(let (($x956 (or false false (or $x378))))
(let (($x774 (or $x956 false)))
(let (($x404 (or (or false $x774 false) (bvuge ?x1746 (_ bv64 64)))))
(and (not $x404) (or $x404 (and (distinct ?x1741 ?x1741) true)))))))))))
(check-sat)
; query 313: function gsm_L_asr, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ zero_extend 32) in1_32) ((_ zero_extend 32) in1_32)) true))))))
(check-sat)
; query 314: function gsm_L_asr, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1967 ((_ zero_extend 32) in1_32)))
(let ((?x1863 (bvashr in0_64 ?x1967)))
(let (($x2656 (or false false)))
(let (($x1169 (or false $x2656 false)))
(let (($x728 (or $x1169 (bvuge ?x1967 (_ bv64 64)))))
(let (($x449 (not $x728)))
(and $x449 (or $x728 (and (distinct ?x1863 ?x1863) true))))))))))
(check-sat)
; query 315: function gsm_L_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1154 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x1154 ?x1154) true)))))))
(check-sat)
; query 316: function gsm_L_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1154 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1280 ((_ zero_extend 31) ?x1154)))
(let (($x89 (or false false false)))
(let (($x56 (or $x89 false)))
(let (($x257 (not $x56)))
(and $x257 (or $x56 (and (distinct ?x1280 ?x1280) true)))))))))
(check-sat)
; query 317: function gsm_L_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1154 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1280 ((_ zero_extend 31) ?x1154)))
(let ((?x1350 (bvsub (_ bv0 32) ?x1280)))
(let (($x964 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1280)) ((_ sign_extend 1) ?x1350)) true)))
(let (($x89 (or false false false)))
(let (($x56 (or $x89 false)))
(let (($x502 (or false $x56 (or $x964))))
(and (not $x502) (or $x502 (and (distinct ?x1350 ?x1350) true)))))))))))
(check-sat)
; query 318: function gsm_L_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1154 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1280 ((_ zero_extend 31) ?x1154)))
(let ((?x1350 (bvsub (_ bv0 32) ?x1280)))
(let ((?x430 ((_ sign_extend 32) ?x1350)))
(let (($x964 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1280)) ((_ sign_extend 1) ?x1350)) true)))
(let (($x89 (or false false false)))
(let (($x56 (or $x89 false)))
(let (($x502 (or false $x56 (or $x964))))
(let (($x65 (or $x502 false)))
(and (not $x65) (or $x65 (and (distinct ?x430 ?x430) true)))))))))))))
(check-sat)
; query 319: function gsm_L_asr, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1086 (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x1086 ?x1086) true)))))))
(check-sat)
; query 320: function gsm_L_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x580 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x580 ?x580) true)))))))
(check-sat)
; query 321: function gsm_L_mult, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 322: function gsm_L_mult, block 17, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 323: function gsm_L_mult, block 17, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1690 ((_ sign_extend 48) in1_16)))
(let ((?x765 ((_ sign_extend 48) in0_16)))
(let ((?x1487 (bvmul ?x765 ?x1690)))
(let (($x220 (and (distinct (bvmul ((_ sign_extend 64) ?x765) ((_ sign_extend 64) ?x1690)) ((_ sign_extend 64) ?x1487)) true)))
(let (($x2656 (or false false)))
(let (($x1959 (or $x2656 $x2656 (or $x220))))
(and (not $x1959) (or $x1959 (and (distinct ?x1487 ?x1487) true))))))))))
(check-sat)
; query 324: function gsm_L_mult, block 17, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1690 ((_ sign_extend 48) in1_16)))
(let ((?x765 ((_ sign_extend 48) in0_16)))
(let ((?x1487 (bvmul ?x765 ?x1690)))
(let ((?x819 (bvshl ?x1487 (_ bv1 64))))
(let (($x210 (bvuge (_ bv1 64) (_ bv64 64))))
(let (($x220 (and (distinct (bvmul ((_ sign_extend 64) ?x765) ((_ sign_extend 64) ?x1690)) ((_ sign_extend 64) ?x1487)) true)))
(let (($x2656 (or false false)))
(let (($x1959 (or $x2656 $x2656 (or $x220))))
(let (($x1149 (or $x1959 false false)))
(let (($x599 (or $x1149 $x210)))
(and (not $x599) (or $x599 (and (distinct ?x819 ?x819) true))))))))))))))
(check-sat)
; query 325: function gsm_L_mult, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 326: function gsm_L_mult, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1002 (ite (and (distinct (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) true) (_ bv1 1) (_ bv0 1))))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x2665 (not $x2657)))
(and $x2665 (or $x2657 (and (distinct ?x1002 ?x1002) true))))))))
(check-sat)
; query 327: function gsm_L_mult, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 328: function gsm_L_mult, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x968 (ite (and (distinct (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) true) (_ bv1 1) (_ bv0 1))))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x2665 (not $x2657)))
(and $x2665 (or $x2657 (and (distinct ?x968 ?x968) true))))))))
(check-sat)
; query 329: function gsm_L_sub, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in11_64 () (_ BitVec 64))
(assert
 (let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct (bvadd in11_64 (_ bv1 64)) (bvadd in11_64 (_ bv1 64))) true))))))
(check-sat)
; query 330: function gsm_L_sub, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1478 (ite (bvsge (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x1478 ?x1478) true)))))))
(check-sat)
; query 331: function gsm_L_sub, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x1844 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvsub in0_64 in1_64))) true)))
(let (($x1834 (or false false (or $x1844))))
(let (($x1198 (or $x1834 (and (distinct (bvsub in0_64 in1_64) (bvsub in0_64 in1_64)) true))))
(and (not $x1834) $x1198)))))
(check-sat)
; query 332: function gsm_L_sub, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x174 (bvadd in0_64 (_ bv1 64))))
(let ((?x833 ((_ sign_extend 1) ?x174)))
(let (($x455 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x833) true)))))
(and (not $x455) (or $x455 (and (distinct ?x174 ?x174) true)))))))
(check-sat)
; query 333: function gsm_L_sub, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x174 (bvadd in0_64 (_ bv1 64))))
(let ((?x110 (bvsub (_ bv0 64) ?x174)))
(let (($x1093 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x174)) ((_ sign_extend 1) ?x110)) true)))
(let ((?x833 ((_ sign_extend 1) ?x174)))
(let (($x455 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x833) true)))))
(let (($x1917 (or false $x455 (or $x1093))))
(and (not $x1917) (or $x1917 (and (distinct ?x110 ?x110) true))))))))))
(check-sat)
; query 334: function gsm_L_sub, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x174 (bvadd in0_64 (_ bv1 64))))
(let ((?x110 (bvsub (_ bv0 64) ?x174)))
(let ((?x779 (bvadd ?x110 in1_64)))
(let (($x1093 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x174)) ((_ sign_extend 1) ?x110)) true)))
(let ((?x833 ((_ sign_extend 1) ?x174)))
(let (($x455 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x833) true)))))
(let (($x1917 (or false $x455 (or $x1093))))
(let (($x1816 (or $x1917 false false)))
(and (not $x1816) (or $x1816 (and (distinct ?x779 ?x779) true))))))))))))
(check-sat)
; query 335: function gsm_L_sub, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1826 (ite (bvuge (bvadd (bvsub (_ bv0 64) (bvadd in0_64 (_ bv1 64))) in1_64) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x1093 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) (bvadd in0_64 (_ bv1 64)))) ((_ sign_extend 1) (bvsub (_ bv0 64) (bvadd in0_64 (_ bv1 64))))) true)))
(let ((?x174 (bvadd in0_64 (_ bv1 64))))
(let ((?x833 ((_ sign_extend 1) ?x174)))
(let (($x455 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x833) true)))))
(let (($x1917 (or false $x455 (or $x1093))))
(let (($x1816 (or $x1917 false false)))
(let (($x569 (or $x1816 false false)))
(and (not $x569) (or $x569 (and (distinct ?x1826 ?x1826) true))))))))))))
(check-sat)
; query 336: function gsm_L_sub, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_64 () (_ BitVec 64))
(assert
 (let ((?x1758 (bvsub (_ bv0 64) in25_64)))
(let ((?x1683 ((_ sign_extend 1) ?x1758)))
(let (($x843 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in25_64)) ?x1683) true)))))
(and (not $x843) (or $x843 (and (distinct ?x1758 ?x1758) true)))))))
(check-sat)
; query 337: function gsm_L_sub, block 28, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_64 () (_ BitVec 64))
(assert
 (let ((?x1758 (bvsub (_ bv0 64) in25_64)))
(let ((?x481 (bvsub ?x1758 (_ bv1 64))))
(let (($x800 (and (distinct (bvsub ((_ sign_extend 1) ?x1758) ((_ sign_extend 1) (_ bv1 64))) ((_ sign_extend 1) ?x481)) true)))
(let ((?x1683 ((_ sign_extend 1) ?x1758)))
(let (($x843 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in25_64)) ?x1683) true)))))
(let (($x1727 (or $x843 false (or $x800))))
(and (not $x1727) (or $x1727 (and (distinct ?x481 ?x481) true))))))))))
(check-sat)
; query 338: function gsm_L_sub, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1925 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x1925 ?x1925) true)))))))
(check-sat)
; query 339: function gsm_L_sub, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x1844 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvsub in0_64 in1_64))) true)))
(let (($x1834 (or false false (or $x1844))))
(let (($x1198 (or $x1834 (and (distinct (bvsub in0_64 in1_64) (bvsub in0_64 in1_64)) true))))
(and (not $x1834) $x1198)))))
(check-sat)
; query 340: function gsm_L_sub, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x958 (bvadd in1_64 (_ bv1 64))))
(let ((?x424 (bvsub (_ bv0 64) ?x958)))
(let (($x1486 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x958)) ((_ sign_extend 1) ?x424)) true)))
(let ((?x791 ((_ sign_extend 1) ?x958)))
(let (($x1027 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x791) true)))))
(let (($x22 (or false $x1027 (or $x1486))))
(and (not $x22) (or $x22 (and (distinct ?x424 ?x424) true))))))))))
(check-sat)
; query 341: function gsm_L_sub, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x958 (bvadd in1_64 (_ bv1 64))))
(let ((?x424 (bvsub (_ bv0 64) ?x958)))
(let ((?x409 (bvadd in0_64 ?x424)))
(let (($x1486 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x958)) ((_ sign_extend 1) ?x424)) true)))
(let ((?x791 ((_ sign_extend 1) ?x958)))
(let (($x1027 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x791) true)))))
(let (($x22 (or false $x1027 (or $x1486))))
(let (($x1726 (or false $x22 false)))
(and (not $x1726) (or $x1726 (and (distinct ?x409 ?x409) true))))))))))))
(check-sat)
; query 342: function gsm_L_sub, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1561 (ite (bvuge (bvadd in0_64 (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64)))) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x1486 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) (bvadd in1_64 (_ bv1 64)))) ((_ sign_extend 1) (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64))))) true)))
(let ((?x958 (bvadd in1_64 (_ bv1 64))))
(let ((?x791 ((_ sign_extend 1) ?x958)))
(let (($x1027 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x791) true)))))
(let (($x22 (or false $x1027 (or $x1486))))
(let (($x1726 (or false $x22 false)))
(let (($x902 (or $x1726 false false)))
(and (not $x902) (or $x902 (and (distinct ?x1561 ?x1561) true))))))))))))
(check-sat)
; query 343: function gsm_L_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x958 (bvadd in1_64 (_ bv1 64))))
(let ((?x791 ((_ sign_extend 1) ?x958)))
(let (($x1027 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x791) true)))))
(and (not $x1027) (or $x1027 (and (distinct ?x958 ?x958) true)))))))
(check-sat)
; query 344: function gsm_L_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x260 (ite (bvsle (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x260 ?x260) true)))))))
(check-sat)
; query 345: function gsm_abs, block 13, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 346: function gsm_abs, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 347: function gsm_abs, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x439 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x2665 (not $x2657)))
(and $x2665 (or $x2657 (and (distinct ?x439 ?x439) true))))))))
(check-sat)
; query 348: function gsm_abs, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1195 ((_ sign_extend 16) in0_16)))
(let ((?x329 (bvsub (_ bv0 32) ?x1195)))
(let (($x1728 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1195)) ((_ sign_extend 1) ?x329)) true)))
(let (($x2656 (or false false)))
(let (($x447 (or false $x2656 (or $x1728))))
(and (not $x447) (or $x447 (and (distinct ?x329 ?x329) true)))))))))
(check-sat)
; query 349: function gsm_abs, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 350: function gsm_abs, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 351: function gsm_abs, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1023 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x2665 (not $x2657)))
(and $x2665 (or $x2657 (and (distinct ?x1023 ?x1023) true))))))))
(check-sat)
; query 352: function gsm_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_64 () (_ BitVec 64))
(assert
 (let ((?x488 (ite (bvslt (_ bv32767 64) in5_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x488 ?x488) true)))))))
(check-sat)
; query 353: function gsm_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 354: function gsm_add, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 355: function gsm_add, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1690 ((_ sign_extend 48) in1_16)))
(let ((?x765 ((_ sign_extend 48) in0_16)))
(let ((?x678 (bvadd ?x765 ?x1690)))
(let (($x1176 (and (distinct (bvadd ((_ sign_extend 1) ?x765) ((_ sign_extend 1) ?x1690)) ((_ sign_extend 1) ?x678)) true)))
(let (($x2656 (or false false)))
(let (($x927 (or $x2656 $x2656 (or $x1176))))
(and (not $x927) (or $x927 (and (distinct ?x678 ?x678) true))))))))))
(check-sat)
; query 356: function gsm_add, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x862 (ite (bvsgt (_ bv18446744073709518848 64) (bvadd ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x1690 ((_ sign_extend 48) in1_16)))
(let ((?x1696 ((_ sign_extend 1) ?x1690)))
(let ((?x765 ((_ sign_extend 48) in0_16)))
(let ((?x373 ((_ sign_extend 1) ?x765)))
(let (($x2656 (or false false)))
(let (($x927 (or $x2656 $x2656 (or (and (distinct (bvadd ?x373 ?x1696) ((_ sign_extend 1) (bvadd ?x765 ?x1690))) true)))))
(let (($x389 (or $x927 false false)))
(and (not $x389) (or $x389 (and (distinct ?x862 ?x862) true))))))))))))
(check-sat)
; query 357: function gsm_asl, block 13, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1358 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x1358 ?x1358) true)))))))
(check-sat)
; query 358: function gsm_asl, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 359: function gsm_asl, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1195 ((_ sign_extend 16) in0_16)))
(let ((?x2060 (bvshl ?x1195 in1_32)))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x2070 (or $x2657 (bvuge in1_32 (_ bv32 32)))))
(let (($x2020 (not $x2070)))
(and $x2020 (or $x2070 (and (distinct ?x2060 ?x2060) true))))))))))
(check-sat)
; query 360: function gsm_asl, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1195 ((_ sign_extend 16) in0_16)))
(let ((?x2060 (bvshl ?x1195 in1_32)))
(let ((?x2050 ((_ extract 15 0) ?x2060)))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x2070 (or $x2657 (bvuge in1_32 (_ bv32 32)))))
(let (($x2040 (or $x2070 false)))
(let (($x1990 (not $x2040)))
(and $x1990 (or $x2040 (and (distinct ?x2050 ?x2050) true))))))))))))
(check-sat)
; query 361: function gsm_asl, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1733 (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x1733 ?x1733) true)))))))
(check-sat)
; query 362: function gsm_asl, block 7, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1023 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1222 ((_ zero_extend 31) ?x1023)))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x184 (or $x2657 false)))
(and (not $x184) (or $x184 (and (distinct ?x1222 ?x1222) true)))))))))
(check-sat)
; query 363: function gsm_asl, block 7, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1023 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1222 ((_ zero_extend 31) ?x1023)))
(let ((?x1905 (bvsub (_ bv0 32) ?x1222)))
(let (($x1928 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1222)) ((_ sign_extend 1) ?x1905)) true)))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x184 (or $x2657 false)))
(let (($x1856 (or false $x184 (or $x1928))))
(and (not $x1856) (or $x1856 (and (distinct ?x1905 ?x1905) true))))))))))))
(check-sat)
; query 364: function gsm_asl, block 7, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1023 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1222 ((_ zero_extend 31) ?x1023)))
(let ((?x1905 (bvsub (_ bv0 32) ?x1222)))
(let ((?x1811 ((_ extract 15 0) ?x1905)))
(let (($x1928 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1222)) ((_ sign_extend 1) ?x1905)) true)))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x184 (or $x2657 false)))
(let (($x1856 (or false $x184 (or $x1928))))
(let (($x1331 (or $x1856 false)))
(and (not $x1331) (or $x1331 (and (distinct ?x1811 ?x1811) true))))))))))))))
(check-sat)
; query 365: function gsm_asl, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 366: function gsm_asl, block 7, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1023 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x2665 (not $x2657)))
(and $x2665 (or $x2657 (and (distinct ?x1023 ?x1023) true))))))))
(check-sat)
; query 367: function gsm_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x2122 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x2122 ?x2122) true)))))))
(check-sat)
; query 368: function gsm_asr, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1733 (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x1733 ?x1733) true)))))))
(check-sat)
; query 369: function gsm_asr, block 13, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1358 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x1358 ?x1358) true)))))))
(check-sat)
; query 370: function gsm_asr, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 371: function gsm_asr, block 15, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x378 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in1_32))) true)))
(let (($x956 (or false false (or $x378))))
(and (not $x956) (or $x956 (and (distinct (bvsub (_ bv0 32) in1_32) (bvsub (_ bv0 32) in1_32)) true))))))
(check-sat)
; query 372: function gsm_asr, block 15, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1742 (bvsub (_ bv0 32) in1_32)))
(let ((?x1195 ((_ sign_extend 16) in0_16)))
(let ((?x2127 (bvshl ?x1195 ?x1742)))
(let (($x378 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x1742)) true)))
(let (($x956 (or false false (or $x378))))
(let (($x2656 (or false false)))
(let (($x2126 (or (or $x2656 $x956 false) (bvuge ?x1742 (_ bv32 32)))))
(and (not $x2126) (or $x2126 (and (distinct ?x2127 ?x2127) true)))))))))))
(check-sat)
; query 373: function gsm_asr, block 15, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1742 (bvsub (_ bv0 32) in1_32)))
(let ((?x1195 ((_ sign_extend 16) in0_16)))
(let ((?x2127 (bvshl ?x1195 ?x1742)))
(let ((?x2128 ((_ extract 15 0) ?x2127)))
(let (($x378 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x1742)) true)))
(let (($x956 (or false false (or $x378))))
(let (($x2656 (or false false)))
(let (($x2126 (or (or $x2656 $x956 false) (bvuge ?x1742 (_ bv32 32)))))
(let (($x2129 (or $x2126 false)))
(and (not $x2129) (or $x2129 (and (distinct ?x2128 ?x2128) true)))))))))))))
(check-sat)
; query 374: function gsm_asr, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 375: function gsm_asr, block 20, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1195 ((_ sign_extend 16) in0_16)))
(let ((?x2132 (bvashr ?x1195 in1_32)))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x2070 (or $x2657 (bvuge in1_32 (_ bv32 32)))))
(let (($x2020 (not $x2070)))
(and $x2020 (or $x2070 (and (distinct ?x2132 ?x2132) true))))))))))
(check-sat)
; query 376: function gsm_asr, block 20, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1195 ((_ sign_extend 16) in0_16)))
(let ((?x2132 (bvashr ?x1195 in1_32)))
(let ((?x2134 ((_ extract 15 0) ?x2132)))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x2070 (or $x2657 (bvuge in1_32 (_ bv32 32)))))
(let (($x2040 (or $x2070 false)))
(let (($x1990 (not $x2040)))
(and $x1990 (or $x2040 (and (distinct ?x2134 ?x2134) true))))))))))))
(check-sat)
; query 377: function gsm_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 378: function gsm_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1023 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x2665 (not $x2657)))
(and $x2665 (or $x2657 (and (distinct ?x1023 ?x1023) true))))))))
(check-sat)
; query 379: function gsm_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1023 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1222 ((_ zero_extend 31) ?x1023)))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x184 (or $x2657 false)))
(and (not $x184) (or $x184 (and (distinct ?x1222 ?x1222) true)))))))))
(check-sat)
; query 380: function gsm_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1023 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1222 ((_ zero_extend 31) ?x1023)))
(let ((?x1905 (bvsub (_ bv0 32) ?x1222)))
(let (($x1928 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1222)) ((_ sign_extend 1) ?x1905)) true)))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x184 (or $x2657 false)))
(let (($x1856 (or false $x184 (or $x1928))))
(and (not $x1856) (or $x1856 (and (distinct ?x1905 ?x1905) true))))))))))))
(check-sat)
; query 381: function gsm_asr, block 4, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1023 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1222 ((_ zero_extend 31) ?x1023)))
(let ((?x1905 (bvsub (_ bv0 32) ?x1222)))
(let ((?x1811 ((_ extract 15 0) ?x1905)))
(let (($x1928 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1222)) ((_ sign_extend 1) ?x1905)) true)))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x184 (or $x2657 false)))
(let (($x1856 (or false $x184 (or $x1928))))
(let (($x1331 (or $x1856 false)))
(and (not $x1331) (or $x1331 (and (distinct ?x1811 ?x1811) true))))))))))))))
(check-sat)
; query 382: function gsm_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x2122 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x2122 ?x2122) true)))))))
(check-sat)
; query 383: function gsm_div, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 384: function gsm_div, block 20, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x2148 (ite (= (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x2665 (not $x2657)))
(and $x2665 (or $x2657 (and (distinct ?x2148 ?x2148) true))))))))
(check-sat)
; query 385: function gsm_div, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 16) in.02_16) ((_ sign_extend 16) in.02_16)) true))))))
(check-sat)
; query 386: function gsm_div, block 28, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x2152 ((_ sign_extend 16) in.02_16)))
(let ((?x2153 (bvshl ?x2152 (_ bv1 32))))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x1365 (or $x2657 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x744 (not $x1365)))
(and $x744 (or $x1365 (and (distinct ?x2153 ?x2153) true))))))))))
(check-sat)
; query 387: function gsm_div, block 28, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x2152 ((_ sign_extend 16) in.02_16)))
(let ((?x2153 (bvshl ?x2152 (_ bv1 32))))
(let ((?x2156 ((_ extract 15 0) ?x2153)))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x1365 (or $x2657 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x2157 (or $x1365 false)))
(and (not $x2157) (or $x2157 (and (distinct ?x2156 ?x2156) true)))))))))))
(check-sat)
; query 388: function gsm_div, block 28, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_64 () (_ BitVec 64))
(assert
 (let (($x210 (bvuge (_ bv1 64) (_ bv64 64))))
(let (($x89 (or false false false)))
(let (($x2154 (or $x89 $x210)))
(and (not $x2154) (or $x2154 (and (distinct (bvshl in.03_64 (_ bv1 64)) (bvshl in.03_64 (_ bv1 64))) true)))))))
(check-sat)
; query 389: function gsm_div, block 28, name %33
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_64 () (_ BitVec 64))
(declare-fun in.03_64 () (_ BitVec 64))
(assert
 (let ((?x2162 (ite (bvsge (bvshl in.03_64 (_ bv1 64)) in4_64) (_ bv1 1) (_ bv0 1))))
(let (($x210 (bvuge (_ bv1 64) (_ bv64 64))))
(let (($x89 (or false false false)))
(let (($x2154 (or $x89 $x210)))
(let (($x2161 (or $x2154 false false)))
(and (not $x2161) (or $x2161 (and (distinct ?x2162 ?x2162) true)))))))))
(check-sat)
; query 390: function gsm_div, block 34, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_64 () (_ BitVec 64))
(declare-fun in32_64 () (_ BitVec 64))
(assert
 (let (($x2184 (and (distinct (bvsub ((_ sign_extend 1) in32_64) ((_ sign_extend 1) in4_64)) ((_ sign_extend 1) (bvsub in32_64 in4_64))) true)))
(let (($x2183 (or false false (or $x2184))))
(let (($x2194 (or $x2183 (and (distinct (bvsub in32_64 in4_64) (bvsub in32_64 in4_64)) true))))
(and (not $x2183) $x2194)))))
(check-sat)
; query 391: function gsm_div, block 34, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in31_16 () (_ BitVec 16))
(assert
 (let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct (bvadd in31_16 (_ bv1 16)) (bvadd in31_16 (_ bv1 16))) true))))))
(check-sat)
; query 392: function gsm_div, block 7, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x2199 (ite (bvsge ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x2656 (or false false)))
(let (($x2202 (or $x2656 $x2656 false)))
(and (not $x2202) (or $x2202 (and (distinct ?x2199 ?x2199) true)))))))
(check-sat)
; query 393: function gsm_div, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 394: function gsm_div, block 7, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 395: function gsm_div, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 396: function gsm_div, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 397: function gsm_div, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 398: function gsm_div, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1239 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1281 (and (distinct ?x1239 ?x1239) true)))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x2665 (not $x2657)))
(and $x2665 (or $x2657 $x1281))))))))
(check-sat)
; query 399: function gsm_mult, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 400: function gsm_mult, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x2209 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x2665 (not $x2657)))
(and $x2665 (or $x2657 (and (distinct ?x2209 ?x2209) true))))))))
(check-sat)
; query 401: function gsm_mult, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 402: function gsm_mult, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 403: function gsm_mult, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1690 ((_ sign_extend 48) in1_16)))
(let ((?x765 ((_ sign_extend 48) in0_16)))
(let ((?x1487 (bvmul ?x765 ?x1690)))
(let (($x220 (and (distinct (bvmul ((_ sign_extend 64) ?x765) ((_ sign_extend 64) ?x1690)) ((_ sign_extend 64) ?x1487)) true)))
(let (($x2656 (or false false)))
(let (($x1959 (or $x2656 $x2656 (or $x220))))
(and (not $x1959) (or $x1959 (and (distinct ?x1487 ?x1487) true))))))))))
(check-sat)
; query 404: function gsm_mult, block 9, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1690 ((_ sign_extend 48) in1_16)))
(let ((?x765 ((_ sign_extend 48) in0_16)))
(let ((?x1487 (bvmul ?x765 ?x1690)))
(let ((?x2213 (bvashr ?x1487 (_ bv15 64))))
(let (($x44 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x220 (and (distinct (bvmul ((_ sign_extend 64) ?x765) ((_ sign_extend 64) ?x1690)) ((_ sign_extend 64) ?x1487)) true)))
(let (($x2656 (or false false)))
(let (($x1959 (or $x2656 $x2656 (or $x220))))
(let (($x1149 (or $x1959 false false)))
(let (($x2214 (or $x1149 $x44)))
(and (not $x2214) (or $x2214 (and (distinct ?x2213 ?x2213) true))))))))))))))
(check-sat)
; query 405: function gsm_mult, block 9, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1690 ((_ sign_extend 48) in1_16)))
(let ((?x765 ((_ sign_extend 48) in0_16)))
(let ((?x1487 (bvmul ?x765 ?x1690)))
(let ((?x2213 (bvashr ?x1487 (_ bv15 64))))
(let ((?x2215 ((_ extract 15 0) ?x2213)))
(let (($x44 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x220 (and (distinct (bvmul ((_ sign_extend 64) ?x765) ((_ sign_extend 64) ?x1690)) ((_ sign_extend 64) ?x1487)) true)))
(let (($x2656 (or false false)))
(let (($x1959 (or $x2656 $x2656 (or $x220))))
(let (($x1149 (or $x1959 false false)))
(let (($x2214 (or $x1149 $x44)))
(let (($x2216 (or $x2214 false)))
(and (not $x2216) (or $x2216 (and (distinct ?x2215 ?x2215) true))))))))))))))))
(check-sat)
; query 406: function gsm_mult, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 407: function gsm_mult, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x439 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x2665 (not $x2657)))
(and $x2665 (or $x2657 (and (distinct ?x439 ?x439) true))))))))
(check-sat)
; query 408: function gsm_mult_r, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 409: function gsm_mult_r, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x439 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x2665 (not $x2657)))
(and $x2665 (or $x2657 (and (distinct ?x439 ?x439) true))))))))
(check-sat)
; query 410: function gsm_mult_r, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 411: function gsm_mult_r, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 412: function gsm_mult_r, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1690 ((_ sign_extend 48) in1_16)))
(let ((?x765 ((_ sign_extend 48) in0_16)))
(let ((?x1487 (bvmul ?x765 ?x1690)))
(let (($x220 (and (distinct (bvmul ((_ sign_extend 64) ?x765) ((_ sign_extend 64) ?x1690)) ((_ sign_extend 64) ?x1487)) true)))
(let (($x2656 (or false false)))
(let (($x1959 (or $x2656 $x2656 (or $x220))))
(and (not $x1959) (or $x1959 (and (distinct ?x1487 ?x1487) true))))))))))
(check-sat)
; query 413: function gsm_mult_r, block 9, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1690 ((_ sign_extend 48) in1_16)))
(let ((?x765 ((_ sign_extend 48) in0_16)))
(let ((?x1487 (bvmul ?x765 ?x1690)))
(let ((?x2227 (bvadd ?x1487 (_ bv16384 64))))
(let (($x2229 (and (distinct (bvadd ((_ sign_extend 1) ?x1487) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x2227)) true)))
(let (($x220 (and (distinct (bvmul ((_ sign_extend 64) ?x765) ((_ sign_extend 64) ?x1690)) ((_ sign_extend 64) ?x1487)) true)))
(let (($x2656 (or false false)))
(let (($x1959 (or $x2656 $x2656 (or $x220))))
(let (($x2231 (or $x1959 false (or $x2229))))
(and (not $x2231) (or $x2231 (and (distinct ?x2227 ?x2227) true)))))))))))))
(check-sat)
; query 414: function gsm_mult_r, block 9, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1690 ((_ sign_extend 48) in1_16)))
(let ((?x765 ((_ sign_extend 48) in0_16)))
(let ((?x1487 (bvmul ?x765 ?x1690)))
(let ((?x2227 (bvadd ?x1487 (_ bv16384 64))))
(let ((?x2241 (bvashr ?x2227 (_ bv15 64))))
(let (($x44 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x2229 (and (distinct (bvadd ((_ sign_extend 1) ?x1487) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x2227)) true)))
(let (($x220 (and (distinct (bvmul ((_ sign_extend 64) ?x765) ((_ sign_extend 64) ?x1690)) ((_ sign_extend 64) ?x1487)) true)))
(let (($x2656 (or false false)))
(let (($x1959 (or $x2656 $x2656 (or $x220))))
(let (($x2231 (or $x1959 false (or $x2229))))
(let (($x2240 (or (or $x2231 false false) $x44)))
(and (not $x2240) (or $x2240 (and (distinct ?x2241 ?x2241) true))))))))))))))))
(check-sat)
; query 415: function gsm_mult_r, block 9, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1690 ((_ sign_extend 48) in1_16)))
(let ((?x765 ((_ sign_extend 48) in0_16)))
(let ((?x1487 (bvmul ?x765 ?x1690)))
(let ((?x2227 (bvadd ?x1487 (_ bv16384 64))))
(let ((?x2241 (bvashr ?x2227 (_ bv15 64))))
(let ((?x2233 (bvand ?x2241 (_ bv65535 64))))
(let (($x44 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x2229 (and (distinct (bvadd ((_ sign_extend 1) ?x1487) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x2227)) true)))
(let (($x220 (and (distinct (bvmul ((_ sign_extend 64) ?x765) ((_ sign_extend 64) ?x1690)) ((_ sign_extend 64) ?x1487)) true)))
(let (($x2656 (or false false)))
(let (($x1959 (or $x2656 $x2656 (or $x220))))
(let (($x2231 (or $x1959 false (or $x2229))))
(let (($x2240 (or (or $x2231 false false) $x44)))
(let (($x2242 (or $x2240 false false)))
(and (not $x2242) (or $x2242 (and (distinct ?x2233 ?x2233) true))))))))))))))))))
(check-sat)
; query 416: function gsm_mult_r, block 9, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1690 ((_ sign_extend 48) in1_16)))
(let ((?x765 ((_ sign_extend 48) in0_16)))
(let ((?x1487 (bvmul ?x765 ?x1690)))
(let ((?x2227 (bvadd ?x1487 (_ bv16384 64))))
(let ((?x2241 (bvashr ?x2227 (_ bv15 64))))
(let ((?x2233 (bvand ?x2241 (_ bv65535 64))))
(let ((?x2243 ((_ extract 15 0) ?x2233)))
(let (($x44 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x2229 (and (distinct (bvadd ((_ sign_extend 1) ?x1487) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x2227)) true)))
(let (($x220 (and (distinct (bvmul ((_ sign_extend 64) ?x765) ((_ sign_extend 64) ?x1690)) ((_ sign_extend 64) ?x1487)) true)))
(let (($x2656 (or false false)))
(let (($x1959 (or $x2656 $x2656 (or $x220))))
(let (($x2231 (or $x1959 false (or $x2229))))
(let (($x2240 (or (or $x2231 false false) $x44)))
(let (($x2242 (or $x2240 false false)))
(let (($x2244 (or $x2242 false)))
(and (not $x2244) (or $x2244 (and (distinct ?x2243 ?x2243) true))))))))))))))))))))
(check-sat)
; query 417: function gsm_mult_r, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 418: function gsm_mult_r, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x2209 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x2665 (not $x2657)))
(and $x2665 (or $x2657 (and (distinct ?x2209 ?x2209) true))))))))
(check-sat)
; query 419: function gsm_norm, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1154 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x1154 ?x1154) true)))))))
(check-sat)
; query 420: function gsm_norm, block 12, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2264 (ite (bvsge (_ bv18446744072635809792 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x2264 ?x2264) true)))))))
(check-sat)
; query 421: function gsm_norm, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct (bvxor in0_64 (_ bv18446744073709551615 64)) (bvxor in0_64 (_ bv18446744073709551615 64))) true))))))
(check-sat)
; query 422: function gsm_norm, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_64 () (_ BitVec 64))
(assert
 (let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct (bvand in.01_64 (_ bv4278190080 64)) (bvand in.01_64 (_ bv4278190080 64))) true))))))
(check-sat)
; query 423: function gsm_norm, block 20, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_64 () (_ BitVec 64))
(assert
 (let ((?x2272 (ite (and (distinct (_ bv0 64) (bvand in.01_64 (_ bv4278190080 64))) true) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x168 (or $x89 false false)))
(let (($x1546 (not $x168)))
(and $x1546 (or $x168 (and (distinct ?x2272 ?x2272) true))))))))
(check-sat)
; query 424: function gsm_norm, block 39, name %40
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_64 () (_ BitVec 64))
(assert
 (let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct (bvand in.01_64 (_ bv65280 64)) (bvand in.01_64 (_ bv65280 64))) true))))))
(check-sat)
; query 425: function gsm_norm, block 39, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_64 () (_ BitVec 64))
(assert
 (let ((?x2280 (ite (and (distinct (_ bv0 64) (bvand in.01_64 (_ bv65280 64))) true) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x168 (or $x89 false false)))
(let (($x1546 (not $x168)))
(and $x1546 (or $x168 (and (distinct ?x2280 ?x2280) true))))))))
(check-sat)
; query 426: function gsm_norm, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2288 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x2288 ?x2288) true)))))))
(check-sat)
; query 427: function gsm_norm, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2288 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x2289 (bvxor ?x2288 (_ bv1 1))))
(let (($x89 (or false false false)))
(let (($x168 (or $x89 false false)))
(let (($x1546 (not $x168)))
(and $x1546 (or $x168 (and (distinct ?x2289 ?x2289) true)))))))))
(check-sat)
; query 428: function gsm_norm, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2288 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x2289 (bvxor ?x2288 (_ bv1 1))))
(let ((?x2290 ((_ zero_extend 31) ?x2289)))
(let (($x89 (or false false false)))
(let (($x168 (or $x89 false false)))
(let (($x2291 (or $x168 false)))
(and (not $x2291) (or $x2291 (and (distinct ?x2290 ?x2290) true))))))))))
(check-sat)
; query 429: function gsm_norm, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2288 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x2289 (bvxor ?x2288 (_ bv1 1))))
(let ((?x2290 ((_ zero_extend 31) ?x2289)))
(let ((?x2294 ((_ sign_extend 32) ?x2290)))
(let (($x89 (or false false false)))
(let (($x168 (or $x89 false false)))
(let (($x2291 (or $x168 false)))
(let (($x2295 (or $x2291 false)))
(and (not $x2295) (or $x2295 (and (distinct ?x2294 ?x2294) true))))))))))))
(check-sat)
; query 430: function gsm_norm, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2288 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x2289 (bvxor ?x2288 (_ bv1 1))))
(let ((?x2290 ((_ zero_extend 31) ?x2289)))
(let ((?x2294 ((_ sign_extend 32) ?x2290)))
(let ((?x2293 (ite (and (distinct (_ bv0 64) ?x2294) true) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x168 (or $x89 false false)))
(let (($x2291 (or $x168 false)))
(let (($x2295 (or $x2291 false)))
(let (($x2292 (or $x2295 false false)))
(and (not $x2292) (or $x2292 (and (distinct ?x2293 ?x2293) true))))))))))))))
(check-sat)
; query 431: function gsm_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_64 () (_ BitVec 64))
(assert
 (let ((?x488 (ite (bvslt (_ bv32767 64) in5_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x488 ?x488) true)))))))
(check-sat)
; query 432: function gsm_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 433: function gsm_sub, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 434: function gsm_sub, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1690 ((_ sign_extend 48) in1_16)))
(let ((?x765 ((_ sign_extend 48) in0_16)))
(let ((?x2316 (bvsub ?x765 ?x1690)))
(let (($x2318 (and (distinct (bvsub ((_ sign_extend 1) ?x765) ((_ sign_extend 1) ?x1690)) ((_ sign_extend 1) ?x2316)) true)))
(let (($x2656 (or false false)))
(let (($x2320 (or $x2656 $x2656 (or $x2318))))
(and (not $x2320) (or $x2320 (and (distinct ?x2316 ?x2316) true))))))))))
(check-sat)
; query 435: function gsm_sub, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x2323 (ite (bvsgt (_ bv18446744073709518848 64) (bvsub ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x1690 ((_ sign_extend 48) in1_16)))
(let ((?x1696 ((_ sign_extend 1) ?x1690)))
(let ((?x765 ((_ sign_extend 48) in0_16)))
(let ((?x373 ((_ sign_extend 1) ?x765)))
(let (($x2656 (or false false)))
(let (($x2320 (or $x2656 $x2656 (or (and (distinct (bvsub ?x373 ?x1696) ((_ sign_extend 1) (bvsub ?x765 ?x1690))) true)))))
(let (($x2322 (or $x2320 false false)))
(and (not $x2322) (or $x2322 (and (distinct ?x2323 ?x2323) true))))))))))))
(check-sat)
; query 436: function ok_to_replace, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x2334 (ite (and (distinct (_ bv4294967295 32) in.01_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x2334 ?x2334) true)))))))
(check-sat)
; query 437: function ok_to_replace, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in16_32 () (_ BitVec 32))
(assert
 (let ((?x2341 (ite (= (_ bv121 32) in16_32) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x2341 ?x2341) true)))))))
(check-sat)
; query 438: function process_decode, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 32) in14_32) ((_ sign_extend 32) in14_32)) true))))))
(check-sat)
; query 439: function process_decode, block 16, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x2355 (ite (and (distinct (_ bv33 64) ((_ sign_extend 32) in14_32)) true) (_ bv1 1) (_ bv0 1))))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x2665 (not $x2657)))
(and $x2665 (or $x2657 (and (distinct ?x2355 ?x2355) true))))))))
(check-sat)
; query 440: function process_encode, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_32 () (_ BitVec 32))
(assert
 (let (($x2656 (or false false)))
(let (($x2661 (not $x2656)))
(and $x2661 (or $x2656 (and (distinct ((_ sign_extend 32) in13_32) ((_ sign_extend 32) in13_32)) true))))))
(check-sat)
; query 441: function process_encode, block 15, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_32 () (_ BitVec 32))
(assert
 (let ((?x2348 (ite (bvult ((_ sign_extend 32) in13_32) (_ bv160 64)) (_ bv1 1) (_ bv0 1))))
(let (($x2656 (or false false)))
(let (($x2657 (or $x2656 false false)))
(let (($x2665 (not $x2657)))
(and $x2665 (or $x2657 (and (distinct ?x2348 ?x2348) true))))))))
(check-sat)
; query 442: function suffix, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_64 () (_ BitVec 64))
(declare-fun in3_64 () (_ BitVec 64))
(assert
 (let ((?x2366 (ite (bvule in3_64 in4_64) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x117 (not $x89)))
(and $x117 (or $x89 (and (distinct ?x2366 ?x2366) true)))))))
(check-sat)
