; OptiPhase-Sigma refinement certificate for sweep K49-R3-287
; query 0: function APCM_inverse_quantization, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 1: function APCM_inverse_quantization, block 7, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x199 (ite (bvsge (_ bv7 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x720 (or false false)))
(let (($x73 (or $x720 false false)))
(let (($x243 (not $x73)))
(and $x243 (or $x73 (and (distinct ?x199 ?x199) true))))))))
(check-sat)
; query 2: function APCM_inverse_quantization, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 3: function APCM_inverse_quantization, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x7 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x720 (or false false)))
(let (($x73 (or $x720 false false)))
(let (($x243 (not $x73)))
(and $x243 (or $x73 (and (distinct ?x7 ?x7) true))))))))
(check-sat)
; query 4: function APCM_quantization, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 16) in13_16) ((_ sign_extend 16) in13_16)) true))))))
(check-sat)
; query 5: function APCM_quantization, block 16, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_16 () (_ BitVec 16))
(assert
 (let ((?x113 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in13_16)) (_ bv1 1) (_ bv0 1))))
(let (($x720 (or false false)))
(let (($x73 (or $x720 false false)))
(let (($x243 (not $x73)))
(and $x243 (or $x73 (and (distinct ?x113 ?x113) true))))))))
(check-sat)
; query 6: function APCM_quantization, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 16) in13_16) ((_ sign_extend 16) in13_16)) true))))))
(check-sat)
; query 7: function APCM_quantization, block 20, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_16 () (_ BitVec 16))
(assert
 (let ((?x48 ((_ sign_extend 16) in13_16)))
(let ((?x821 (bvsub (_ bv0 32) ?x48)))
(let (($x127 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x48)) ((_ sign_extend 1) ?x821)) true)))
(let (($x720 (or false false)))
(let (($x379 (or false $x720 (or $x127))))
(and (not $x379) (or $x379 (and (distinct ?x821 ?x821) true)))))))))
(check-sat)
; query 8: function APCM_quantization, block 25, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 16) in13_16) ((_ sign_extend 16) in13_16)) true))))))
(check-sat)
; query 9: function APCM_quantization, block 35, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_32 () (_ BitVec 32))
(assert
 (let (($x356 (and (distinct (bvadd ((_ sign_extend 1) in.03_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.03_32 (_ bv1 32)))) true)))
(let (($x49 (or false false (or $x356))))
(and (not $x49) (or $x49 (and (distinct (bvadd in.03_32 (_ bv1 32)) (bvadd in.03_32 (_ bv1 32))) true))))))
(check-sat)
; query 10: function APCM_quantization_xmaxc_to_exp_mant, block 24, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 16) in.0_16) ((_ sign_extend 16) in.0_16)) true))))))
(check-sat)
; query 11: function APCM_quantization_xmaxc_to_exp_mant, block 24, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let ((?x391 ((_ sign_extend 16) in.0_16)))
(let ((?x116 (bvshl ?x391 (_ bv1 32))))
(let (($x209 (bvuge (_ bv1 32) (_ bv32 32))))
(let (($x720 (or false false)))
(let (($x86 (or (or $x720 false (or (and (distinct (bvashr ?x116 (_ bv1 32)) ?x391) true))) $x209)))
(let (($x73 (or $x720 false false)))
(let (($x54 (or $x73 $x209)))
(let (($x21 (not $x54)))
(and $x21 (or $x86 (and (distinct ?x116 ?x116) true))))))))))))
(check-sat)
; query 12: function APCM_quantization_xmaxc_to_exp_mant, block 24, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let ((?x391 ((_ sign_extend 16) in.0_16)))
(let ((?x116 (bvshl ?x391 (_ bv1 32))))
(let ((?x462 (bvadd ?x116 (_ bv1 32))))
(let ((?x56 (bvor ?x116 (_ bv1 32))))
(let (($x823 (and (distinct (bvadd ((_ zero_extend 1) ?x116) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) ?x462)) true)))
(let (($x194 (and (distinct (bvadd ((_ sign_extend 1) ?x116) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x462)) true)))
(let (($x209 (bvuge (_ bv1 32) (_ bv32 32))))
(let (($x720 (or false false)))
(let (($x86 (or (or $x720 false (or (and (distinct (bvashr ?x116 (_ bv1 32)) ?x391) true))) $x209)))
(let (($x144 (or $x86 false (or $x194 $x823))))
(and (not (or (or (or $x720 false false) $x209) false false)) (or $x144 (and (distinct ?x56 ?x462) true))))))))))))))
(check-sat)
; query 13: function APCM_quantization_xmaxc_to_exp_mant, block 24, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x131 (and (distinct ((_ extract 15 0) (bvor (bvshl ((_ sign_extend 16) in.0_16) (_ bv1 32)) (_ bv1 32))) ((_ extract 15 0) (bvadd (bvshl ((_ sign_extend 16) in.0_16) (_ bv1 32)) (_ bv1 32)))) true)))
(let ((?x9 (bvadd ((_ zero_extend 1) (bvshl ((_ sign_extend 16) in.0_16) (_ bv1 32))) ((_ zero_extend 1) (_ bv1 32)))))
(let (($x823 (and (distinct ?x9 ((_ zero_extend 1) (bvadd (bvshl ((_ sign_extend 16) in.0_16) (_ bv1 32)) (_ bv1 32)))) true)))
(let ((?x1968 ((_ sign_extend 1) (_ bv1 32))))
(let (($x194 (and (distinct (bvadd ((_ sign_extend 1) (bvshl ((_ sign_extend 16) in.0_16) (_ bv1 32))) ?x1968) ((_ sign_extend 1) (bvadd (bvshl ((_ sign_extend 16) in.0_16) (_ bv1 32)) (_ bv1 32)))) true)))
(let (($x209 (bvuge (_ bv1 32) (_ bv32 32))))
(let ((?x391 ((_ sign_extend 16) in.0_16)))
(let (($x720 (or false false)))
(let (($x71 (or $x720 false (or (and (distinct (bvashr (bvshl ?x391 (_ bv1 32)) (_ bv1 32)) ?x391) true)))))
(let (($x86 (or $x71 $x209)))
(let (($x144 (or $x86 false (or $x194 $x823))))
(let (($x19 (not (or (or (or (or $x720 false false) $x209) false false) false))))
(and $x19 (or (or $x144 false) $x131)))))))))))))))
(check-sat)
; query 14: function APCM_quantization_xmaxc_to_exp_mant, block 24, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_16 () (_ BitVec 16))
(assert
 (let (($x1480 (or false false false)))
(let (($x197 (not $x1480)))
(and $x197 (or $x1480 (and (distinct (bvadd in.12_16 (_ bv65535 16)) (bvadd in.12_16 (_ bv65535 16))) true))))))
(check-sat)
; query 15: function APCM_quantization_xmaxc_to_exp_mant, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 16) in.0_16) ((_ sign_extend 16) in.0_16)) true))))))
(check-sat)
; query 16: function APCM_quantization_xmaxc_to_exp_mant, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let ((?x391 ((_ sign_extend 16) in.0_16)))
(let ((?x8 (bvsub ?x391 (_ bv8 32))))
(let (($x101 (and (distinct (bvsub ((_ sign_extend 1) ?x391) ((_ sign_extend 1) (_ bv8 32))) ((_ sign_extend 1) ?x8)) true)))
(let (($x720 (or false false)))
(let (($x135 (or $x720 false (or $x101))))
(and (not $x135) (or $x135 (and (distinct ?x8 ?x8) true)))))))))
(check-sat)
; query 17: function APCM_quantization_xmaxc_to_exp_mant, block 30, name %33
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let ((?x391 ((_ sign_extend 16) in.0_16)))
(let ((?x8 (bvsub ?x391 (_ bv8 32))))
(let ((?x84 ((_ extract 15 0) ?x8)))
(let (($x101 (and (distinct (bvsub ((_ sign_extend 1) ?x391) ((_ sign_extend 1) (_ bv8 32))) ((_ sign_extend 1) ?x8)) true)))
(let (($x720 (or false false)))
(let (($x135 (or $x720 false (or $x101))))
(let (($x1075 (or $x135 false)))
(and (not $x1075) (or $x1075 (and (distinct ?x84 ?x84) true)))))))))))
(check-sat)
; query 18: function APCM_quantization_xmaxc_to_exp_mant, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 16) in.2_16) ((_ sign_extend 16) in.2_16)) true))))))
(check-sat)
; query 19: function APCM_quantization_xmaxc_to_exp_mant, block 37, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_16 () (_ BitVec 16))
(assert
 (let ((?x87 (ite (bvsge (_ bv6 32) ((_ sign_extend 16) in.2_16)) (_ bv1 1) (_ bv0 1))))
(let (($x720 (or false false)))
(let (($x73 (or $x720 false false)))
(let (($x243 (not $x73)))
(and $x243 (or $x73 (and (distinct ?x87 ?x87) true))))))))
(check-sat)
; query 20: function APCM_quantization_xmaxc_to_exp_mant, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x69 ((_ sign_extend 16) in0_16)))
(let ((?x72 (bvashr ?x69 (_ bv3 32))))
(let ((?x28 (bvsub ?x72 (_ bv1 32))))
(let ((?x109 ((_ extract 15 0) ?x28)))
(let (($x140 (and (distinct (bvsub ((_ sign_extend 1) ?x72) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x28)) true)))
(let (($x720 (or false false)))
(let (($x73 (or $x720 false false)))
(let (($x52 (or $x73 (bvuge (_ bv3 32) (_ bv32 32)))))
(let (($x14 (or $x52 false (or $x140))))
(let (($x1658 (or (or $x14 (or (and (distinct ((_ sign_extend 16) ?x109) ?x28) true))) (and (distinct ?x109 ?x109) true))))
(and (not (or $x14 false)) $x1658))))))))))))
(check-sat)
; query 21: function APCM_quantization_xmaxc_to_exp_mant, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 22: function APCM_quantization_xmaxc_to_exp_mant, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x69 ((_ sign_extend 16) in0_16)))
(let ((?x72 (bvashr ?x69 (_ bv3 32))))
(let (($x720 (or false false)))
(let (($x73 (or $x720 false false)))
(let (($x52 (or $x73 (bvuge (_ bv3 32) (_ bv32 32)))))
(and (not $x52) (or $x52 (and (distinct ?x72 ?x72) true)))))))))
(check-sat)
; query 23: function APCM_quantization_xmaxc_to_exp_mant, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x69 ((_ sign_extend 16) in0_16)))
(let ((?x72 (bvashr ?x69 (_ bv3 32))))
(let ((?x28 (bvsub ?x72 (_ bv1 32))))
(let (($x140 (and (distinct (bvsub ((_ sign_extend 1) ?x72) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x28)) true)))
(let (($x720 (or false false)))
(let (($x73 (or $x720 false false)))
(let (($x52 (or $x73 (bvuge (_ bv3 32) (_ bv32 32)))))
(let (($x14 (or $x52 false (or $x140))))
(and (not $x14) (or $x14 (and (distinct ?x28 ?x28) true))))))))))))
(check-sat)
; query 24: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 25: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1284 (ite (bvslt (_ bv15 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x720 (or false false)))
(let (($x73 (or $x720 false false)))
(let (($x243 (not $x73)))
(and $x243 (or $x73 (and (distinct ?x1284 ?x1284) true))))))))
(check-sat)
; query 26: function Autocorrelation, block 39, name %40
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x260 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x225 (or false false (or $x260))))
(and (not $x225) (or $x225 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 27: function Autocorrelation, block 41, name %42
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 16) in.04_16) ((_ sign_extend 16) in.04_16)) true))))))
(check-sat)
; query 28: function Autocorrelation, block 41, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let ((?x1886 (ite (= (_ bv0 32) ((_ sign_extend 16) in.04_16)) (_ bv1 1) (_ bv0 1))))
(let (($x720 (or false false)))
(let (($x73 (or $x720 false false)))
(let (($x243 (not $x73)))
(and $x243 (or $x73 (and (distinct ?x1886 ?x1886) true))))))))
(check-sat)
; query 29: function Autocorrelation, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 16) in.04_16) ((_ sign_extend 16) in.04_16)) true))))))
(check-sat)
; query 30: function Autocorrelation, block 45, name %47
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let ((?x1959 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.04_16)) (_ bv1 1) (_ bv0 1))))
(let (($x720 (or false false)))
(let (($x73 (or $x720 false false)))
(let (($x243 (not $x73)))
(and $x243 (or $x73 (and (distinct ?x1959 ?x1959) true))))))))
(check-sat)
; query 31: function Autocorrelation, block 45, name %48
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let ((?x1959 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.04_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x157 (bvxor ?x1959 (_ bv1 1))))
(let (($x720 (or false false)))
(let (($x73 (or $x720 false false)))
(let (($x1868 (or $x73 false false)))
(let (($x1599 (not $x1868)))
(and $x1599 (or $x1868 (and (distinct ?x157 ?x157) true))))))))))
(check-sat)
; query 32: function Autocorrelation, block 45, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let ((?x1959 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.04_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x157 (bvxor ?x1959 (_ bv1 1))))
(let ((?x1190 ((_ zero_extend 31) ?x157)))
(let (($x720 (or false false)))
(let (($x73 (or $x720 false false)))
(let (($x1868 (or $x73 false false)))
(let (($x159 (or $x1868 false)))
(let (($x1249 (not $x159)))
(and $x1249 (or $x159 (and (distinct ?x1190 ?x1190) true))))))))))))
(check-sat)
; query 33: function Autocorrelation, block 45, name %50
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let ((?x1959 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.04_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x157 (bvxor ?x1959 (_ bv1 1))))
(let ((?x1190 ((_ zero_extend 31) ?x157)))
(let ((?x423 ((_ zero_extend 32) ?x1190)))
(let ((?x1922 ((_ sign_extend 32) ?x1190)))
(let (($x720 (or false false)))
(let (($x73 (or $x720 false false)))
(let (($x1868 (or $x73 false false)))
(let (($x159 (or $x1868 false)))
(let (($x616 (or $x159 (or (= ((_ extract 31 31) ?x1190) (_ bv1 1))))))
(let (($x1214 (or $x159 false)))
(let (($x503 (not $x1214)))
(and $x503 (or $x616 (and (distinct ?x1922 ?x423) true))))))))))))))))
(check-sat)
; query 34: function Autocorrelation, block 45, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let ((?x1959 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.04_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x157 (bvxor ?x1959 (_ bv1 1))))
(let ((?x1190 ((_ zero_extend 31) ?x157)))
(let ((?x423 ((_ zero_extend 32) ?x1190)))
(let (($x380 (and (distinct (ite (and (distinct (_ bv0 64) ((_ sign_extend 32) ?x1190)) true) (_ bv1 1) (_ bv0 1)) (ite (and (distinct (_ bv0 64) ?x423) true) (_ bv1 1) (_ bv0 1))) true)))
(let (($x720 (or false false)))
(let (($x73 (or $x720 false false)))
(let (($x1868 (or $x73 false false)))
(let (($x159 (or $x1868 false)))
(let (($x616 (or $x159 (or (= ((_ extract 31 31) ?x1190) (_ bv1 1))))))
(let (($x820 (not (or (or $x159 false) false false))))
(and $x820 (or (or $x616 false false) $x380))))))))))))))
(check-sat)
; query 35: function Calculation_of_the_LTP_parameters, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in11_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 16) in11_16) ((_ sign_extend 16) in11_16)) true))))))
(check-sat)
; query 36: function Calculation_of_the_LTP_parameters, block 14, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in11_16 () (_ BitVec 16))
(assert
 (let ((?x588 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in11_16)) (_ bv1 1) (_ bv0 1))))
(let (($x720 (or false false)))
(let (($x73 (or $x720 false false)))
(let (($x243 (not $x73)))
(and $x243 (or $x73 (and (distinct ?x588 ?x588) true))))))))
(check-sat)
; query 37: function Calculation_of_the_LTP_parameters, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in11_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 16) in11_16) ((_ sign_extend 16) in11_16)) true))))))
(check-sat)
; query 38: function Calculation_of_the_LTP_parameters, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in11_16 () (_ BitVec 16))
(assert
 (let ((?x754 ((_ sign_extend 16) in11_16)))
(let ((?x1936 (bvsub (_ bv0 32) ?x754)))
(let (($x1928 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x754)) ((_ sign_extend 1) ?x1936)) true)))
(let (($x720 (or false false)))
(let (($x1896 (or false $x720 (or $x1928))))
(and (not $x1896) (or $x1896 (and (distinct ?x1936 ?x1936) true)))))))))
(check-sat)
; query 39: function Calculation_of_the_LTP_parameters, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in11_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 16) in11_16) ((_ sign_extend 16) in11_16)) true))))))
(check-sat)
; query 40: function Calculation_of_the_LTP_parameters, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_32 () (_ BitVec 32))
(assert
 (let (($x356 (and (distinct (bvadd ((_ sign_extend 1) in.03_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.03_32 (_ bv1 32)))) true)))
(let (($x49 (or false false (or $x356))))
(and (not $x49) (or $x49 (and (distinct (bvadd in.03_32 (_ bv1 32)) (bvadd in.03_32 (_ bv1 32))) true))))))
(check-sat)
; query 41: function Calculation_of_the_LTP_parameters, block 35, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 16) in.02_16) ((_ sign_extend 16) in.02_16)) true))))))
(check-sat)
; query 42: function Calculation_of_the_LTP_parameters, block 35, name %37
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x376 (ite (= (_ bv0 32) ((_ sign_extend 16) in.02_16)) (_ bv1 1) (_ bv0 1))))
(let (($x720 (or false false)))
(let (($x73 (or $x720 false false)))
(let (($x243 (not $x73)))
(and $x243 (or $x73 (and (distinct ?x376 ?x376) true))))))))
(check-sat)
; query 43: function Calculation_of_the_LTP_parameters, block 39, name %40
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 16) in.02_16) ((_ sign_extend 16) in.02_16)) true))))))
(check-sat)
; query 44: function Calculation_of_the_LTP_parameters, block 39, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x1929 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.02_16)) (_ bv1 1) (_ bv0 1))))
(let (($x720 (or false false)))
(let (($x73 (or $x720 false false)))
(let (($x243 (not $x73)))
(and $x243 (or $x73 (and (distinct ?x1929 ?x1929) true))))))))
(check-sat)
; query 45: function Calculation_of_the_LTP_parameters, block 39, name %42
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x1929 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.02_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1961 (bvxor ?x1929 (_ bv1 1))))
(let (($x720 (or false false)))
(let (($x73 (or $x720 false false)))
(let (($x1868 (or $x73 false false)))
(let (($x1599 (not $x1868)))
(and $x1599 (or $x1868 (and (distinct ?x1961 ?x1961) true))))))))))
(check-sat)
; query 46: function Calculation_of_the_LTP_parameters, block 39, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x1929 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.02_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1961 (bvxor ?x1929 (_ bv1 1))))
(let ((?x686 ((_ zero_extend 31) ?x1961)))
(let (($x720 (or false false)))
(let (($x73 (or $x720 false false)))
(let (($x1868 (or $x73 false false)))
(let (($x159 (or $x1868 false)))
(let (($x1249 (not $x159)))
(and $x1249 (or $x159 (and (distinct ?x686 ?x686) true))))))))))))
(check-sat)
; query 47: function Calculation_of_the_LTP_parameters, block 39, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x1929 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.02_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1961 (bvxor ?x1929 (_ bv1 1))))
(let ((?x686 ((_ zero_extend 31) ?x1961)))
(let ((?x1169 ((_ zero_extend 32) ?x686)))
(let ((?x1699 ((_ sign_extend 32) ?x686)))
(let (($x720 (or false false)))
(let (($x73 (or $x720 false false)))
(let (($x1868 (or $x73 false false)))
(let (($x159 (or $x1868 false)))
(let (($x1031 (or $x159 (or (= ((_ extract 31 31) ?x686) (_ bv1 1))))))
(let (($x1214 (or $x159 false)))
(let (($x503 (not $x1214)))
(and $x503 (or $x1031 (and (distinct ?x1699 ?x1169) true))))))))))))))))
(check-sat)
; query 48: function Calculation_of_the_LTP_parameters, block 39, name %45
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x1929 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.02_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1961 (bvxor ?x1929 (_ bv1 1))))
(let ((?x686 ((_ zero_extend 31) ?x1961)))
(let ((?x1169 ((_ zero_extend 32) ?x686)))
(let (($x447 (and (distinct (ite (and (distinct (_ bv0 64) ((_ sign_extend 32) ?x686)) true) (_ bv1 1) (_ bv0 1)) (ite (and (distinct (_ bv0 64) ?x1169) true) (_ bv1 1) (_ bv0 1))) true)))
(let (($x720 (or false false)))
(let (($x73 (or $x720 false false)))
(let (($x1868 (or $x73 false false)))
(let (($x159 (or $x1868 false)))
(let (($x1031 (or $x159 (or (= ((_ extract 31 31) ?x686) (_ bv1 1))))))
(let (($x820 (not (or (or $x159 false) false false))))
(and $x820 (or (or $x1031 false false) $x447))))))))))))))
(check-sat)
; query 49: function Gsm_Decoder, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1008 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x1834 (or false false (or $x1008))))
(and (not $x1834) (or $x1834 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 50: function Gsm_Long_Term_Synthesis_Filtering, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 51: function Gsm_Long_Term_Synthesis_Filtering, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 16) in19_16) ((_ sign_extend 16) in19_16)) true))))))
(check-sat)
; query 52: function Gsm_Long_Term_Synthesis_Filtering, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x171 (ite (bvsge (_ bv120 32) ((_ sign_extend 16) in19_16)) (_ bv1 1) (_ bv0 1))))
(let (($x720 (or false false)))
(let (($x73 (or $x720 false false)))
(let (($x243 (not $x73)))
(and $x243 (or $x73 (and (distinct ?x171 ?x171) true))))))))
(check-sat)
; query 53: function Gsm_Long_Term_Synthesis_Filtering, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x739 (ite (bvslt (_ bv120 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x720 (or false false)))
(let (($x73 (or $x720 false false)))
(let (($x243 (not $x73)))
(and $x243 (or $x73 (and (distinct ?x739 ?x739) true))))))))
(check-sat)
; query 54: function Gsm_Long_Term_Synthesis_Filtering, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 55: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 56: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1657 (ite (bvsgt (_ bv40 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x720 (or false false)))
(let (($x73 (or $x720 false false)))
(let (($x243 (not $x73)))
(and $x243 (or $x73 (and (distinct ?x1657 ?x1657) true))))))))
(check-sat)
; query 57: function LARp_to_rp, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 16) in19_16) ((_ sign_extend 16) in19_16)) true))))))
(check-sat)
; query 58: function LARp_to_rp, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x354 ((_ sign_extend 16) in19_16)))
(let ((?x103 (bvshl ?x354 (_ bv1 32))))
(let (($x209 (bvuge (_ bv1 32) (_ bv32 32))))
(let (($x720 (or false false)))
(let (($x660 (or (or $x720 false (or (and (distinct (bvashr ?x103 (_ bv1 32)) ?x354) true))) $x209)))
(let (($x73 (or $x720 false false)))
(let (($x54 (or $x73 $x209)))
(let (($x21 (not $x54)))
(and $x21 (or $x660 (and (distinct ?x103 ?x103) true))))))))))))
(check-sat)
; query 59: function LARp_to_rp, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x354 ((_ sign_extend 16) in19_16)))
(let ((?x103 (bvshl ?x354 (_ bv1 32))))
(let ((?x1131 ((_ sign_extend 32) ?x103)))
(let (($x209 (bvuge (_ bv1 32) (_ bv32 32))))
(let (($x720 (or false false)))
(let (($x660 (or (or $x720 false (or (and (distinct (bvashr ?x103 (_ bv1 32)) ?x354) true))) $x209)))
(and (not (or (or (or $x720 false false) $x209) false)) (or (or $x660 false) (and (distinct ?x1131 ?x1131) true))))))))))
(check-sat)
; query 60: function LARp_to_rp, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 16) in19_16) ((_ sign_extend 16) in19_16)) true))))))
(check-sat)
; query 61: function LARp_to_rp, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x1821 (ite (bvsgt (_ bv20070 32) ((_ sign_extend 16) in19_16)) (_ bv1 1) (_ bv0 1))))
(let (($x720 (or false false)))
(let (($x73 (or $x720 false false)))
(let (($x243 (not $x73)))
(and $x243 (or $x73 (and (distinct ?x1821 ?x1821) true))))))))
(check-sat)
; query 62: function LARp_to_rp, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 16) in19_16) ((_ sign_extend 16) in19_16)) true))))))
(check-sat)
; query 63: function LARp_to_rp, block 29, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x354 ((_ sign_extend 16) in19_16)))
(let ((?x1853 (bvadd ?x354 (_ bv11059 32))))
(let (($x1845 (and (distinct (bvadd ((_ sign_extend 1) ?x354) ((_ sign_extend 1) (_ bv11059 32))) ((_ sign_extend 1) ?x1853)) true)))
(let (($x720 (or false false)))
(let (($x1871 (or $x720 false (or $x1845))))
(and (not $x1871) (or $x1871 (and (distinct ?x1853 ?x1853) true)))))))))
(check-sat)
; query 64: function LARp_to_rp, block 29, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x354 ((_ sign_extend 16) in19_16)))
(let ((?x1853 (bvadd ?x354 (_ bv11059 32))))
(let ((?x1211 ((_ sign_extend 32) ?x1853)))
(let (($x1845 (and (distinct (bvadd ((_ sign_extend 1) ?x354) ((_ sign_extend 1) (_ bv11059 32))) ((_ sign_extend 1) ?x1853)) true)))
(let (($x720 (or false false)))
(let (($x1871 (or $x720 false (or $x1845))))
(let (($x1901 (or $x1871 false)))
(and (not $x1901) (or $x1901 (and (distinct ?x1211 ?x1211) true)))))))))))
(check-sat)
; query 65: function LARp_to_rp, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 16) in19_16) ((_ sign_extend 16) in19_16)) true))))))
(check-sat)
; query 66: function LARp_to_rp, block 33, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x354 ((_ sign_extend 16) in19_16)))
(let ((?x1943 (bvashr ?x354 (_ bv2 32))))
(let (($x720 (or false false)))
(let (($x73 (or $x720 false false)))
(let (($x1876 (or $x73 (bvuge (_ bv2 32) (_ bv32 32)))))
(and (not $x1876) (or $x1876 (and (distinct ?x1943 ?x1943) true)))))))))
(check-sat)
; query 67: function LARp_to_rp, block 33, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x354 ((_ sign_extend 16) in19_16)))
(let ((?x1943 (bvashr ?x354 (_ bv2 32))))
(let ((?x1925 ((_ sign_extend 32) ?x1943)))
(let (($x720 (or false false)))
(let (($x73 (or $x720 false false)))
(let (($x1876 (or $x73 (bvuge (_ bv2 32) (_ bv32 32)))))
(let (($x1926 (or $x1876 false)))
(and (not $x1926) (or $x1926 (and (distinct ?x1925 ?x1925) true)))))))))))
(check-sat)
; query 68: function LARp_to_rp, block 33, name %37
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x354 ((_ sign_extend 16) in19_16)))
(let ((?x1943 (bvashr ?x354 (_ bv2 32))))
(let ((?x1925 ((_ sign_extend 32) ?x1943)))
(let ((?x1930 (bvadd ?x1925 (_ bv26112 64))))
(let ((?x1911 ((_ sign_extend 1) ?x1930)))
(let (($x720 (or false false)))
(let (($x73 (or $x720 false false)))
(let (($x1876 (or $x73 (bvuge (_ bv2 32) (_ bv32 32)))))
(let (($x1926 (or $x1876 false)))
(let (($x1912 (or $x1926 false (or (and (distinct (bvadd ((_ sign_extend 1) ?x1925) ((_ sign_extend 1) (_ bv26112 64))) ?x1911) true)))))
(and (not $x1912) (or $x1912 (and (distinct ?x1930 ?x1930) true))))))))))))))
(check-sat)
; query 69: function LARp_to_rp, block 33, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x354 ((_ sign_extend 16) in19_16)))
(let ((?x1943 (bvashr ?x354 (_ bv2 32))))
(let ((?x1925 ((_ sign_extend 32) ?x1943)))
(let ((?x1930 (bvadd ?x1925 (_ bv26112 64))))
(let ((?x1956 (bvsub ?x1930 (_ bv18446744073709518848 64))))
(let (($x1765 (and (distinct (bvsub ((_ sign_extend 1) ?x1930) ((_ sign_extend 1) (_ bv18446744073709518848 64))) ((_ sign_extend 1) ?x1956)) true)))
(let ((?x1911 ((_ sign_extend 1) ?x1930)))
(let (($x720 (or false false)))
(let (($x73 (or $x720 false false)))
(let (($x1876 (or $x73 (bvuge (_ bv2 32) (_ bv32 32)))))
(let (($x1926 (or $x1876 false)))
(let (($x1912 (or $x1926 false (or (and (distinct (bvadd ((_ sign_extend 1) ?x1925) ((_ sign_extend 1) (_ bv26112 64))) ?x1911) true)))))
(let (($x1970 (or $x1912 false (or $x1765))))
(and (not $x1970) (or $x1970 (and (distinct ?x1956 ?x1956) true)))))))))))))))))
(check-sat)
; query 70: function LARp_to_rp, block 33, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x354 ((_ sign_extend 16) in19_16)))
(let ((?x1943 (bvashr ?x354 (_ bv2 32))))
(let ((?x1925 ((_ sign_extend 32) ?x1943)))
(let ((?x1930 (bvadd ?x1925 (_ bv26112 64))))
(let ((?x1956 (bvsub ?x1930 (_ bv18446744073709518848 64))))
(let ((?x1949 (ite (bvugt ?x1956 (_ bv65535 64)) (_ bv1 1) (_ bv0 1))))
(let (($x1765 (and (distinct (bvsub ((_ sign_extend 1) ?x1930) ((_ sign_extend 1) (_ bv18446744073709518848 64))) ((_ sign_extend 1) ?x1956)) true)))
(let ((?x1911 ((_ sign_extend 1) ?x1930)))
(let (($x720 (or false false)))
(let (($x73 (or $x720 false false)))
(let (($x1876 (or $x73 (bvuge (_ bv2 32) (_ bv32 32)))))
(let (($x1926 (or $x1876 false)))
(let (($x1912 (or $x1926 false (or (and (distinct (bvadd ((_ sign_extend 1) ?x1925) ((_ sign_extend 1) (_ bv26112 64))) ?x1911) true)))))
(let (($x1970 (or $x1912 false (or $x1765))))
(let (($x1955 (or $x1970 false false)))
(and (not $x1955) (or $x1955 (and (distinct ?x1949 ?x1949) true)))))))))))))))))))
(check-sat)
; query 71: function Long_term_analysis_filtering, block 117, name %118
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in114_64 () (_ BitVec 64))
(assert
 (let ((?x1747 (ite (bvsge (_ bv18446744073709518848 64) in114_64) (_ bv1 1) (_ bv0 1))))
(let (($x1480 (or false false false)))
(let (($x197 (not $x1480)))
(and $x197 (or $x1480 (and (distinct ?x1747 ?x1747) true)))))))
(check-sat)
; query 72: function Long_term_analysis_filtering, block 128, name %129
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let (($x39 (and (distinct (bvadd ((_ sign_extend 1) in.2_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.2_32 (_ bv1 32)))) true)))
(let (($x1285 (or false false (or $x39))))
(and (not $x1285) (or $x1285 (and (distinct (bvadd in.2_32 (_ bv1 32)) (bvadd in.2_32 (_ bv1 32))) true))))))
(check-sat)
; query 73: function Long_term_analysis_filtering, block 158, name %159
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in155_64 () (_ BitVec 64))
(assert
 (let ((?x483 (ite (bvsge (_ bv18446744073709518848 64) in155_64) (_ bv1 1) (_ bv0 1))))
(let (($x1480 (or false false false)))
(let (($x197 (not $x1480)))
(and $x197 (or $x1480 (and (distinct ?x483 ?x483) true)))))))
(check-sat)
; query 74: function Long_term_analysis_filtering, block 169, name %170
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.3_32 () (_ BitVec 32))
(assert
 (let (($x1080 (and (distinct (bvadd ((_ sign_extend 1) in.3_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.3_32 (_ bv1 32)))) true)))
(let (($x222 (or false false (or $x1080))))
(and (not $x222) (or $x222 (and (distinct (bvadd in.3_32 (_ bv1 32)) (bvadd in.3_32 (_ bv1 32))) true))))))
(check-sat)
; query 75: function Long_term_analysis_filtering, block 35, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in32_64 () (_ BitVec 64))
(assert
 (let ((?x639 (ite (bvsge (_ bv18446744073709518848 64) in32_64) (_ bv1 1) (_ bv0 1))))
(let (($x1480 (or false false false)))
(let (($x197 (not $x1480)))
(and $x197 (or $x1480 (and (distinct ?x639 ?x639) true)))))))
(check-sat)
; query 76: function Long_term_analysis_filtering, block 46, name %47
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1008 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x1834 (or false false (or $x1008))))
(and (not $x1834) (or $x1834 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 77: function Long_term_analysis_filtering, block 76, name %77
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in73_64 () (_ BitVec 64))
(assert
 (let ((?x147 (ite (bvsge (_ bv18446744073709518848 64) in73_64) (_ bv1 1) (_ bv0 1))))
(let (($x1480 (or false false false)))
(let (($x197 (not $x1480)))
(and $x197 (or $x1480 (and (distinct ?x147 ?x147) true)))))))
(check-sat)
; query 78: function Long_term_analysis_filtering, block 87, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x885 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x436 (or false false (or $x885))))
(and (not $x436) (or $x436 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 79: function Quantization_and_coding, block 239, name %240
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in235_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 16) in235_16) ((_ sign_extend 16) in235_16)) true))))))
(check-sat)
; query 80: function Quantization_and_coding, block 239, name %241
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in235_16 () (_ BitVec 16))
(assert
 (let (($x1654 (and (distinct (ite (bvsgt (_ bv4294967288 32) ((_ sign_extend 16) in235_16)) (_ bv1 1) (_ bv0 1)) (ite (bvsgt (_ bv4294967292 32) ((_ sign_extend 16) in235_16)) (_ bv1 1) (_ bv0 1))) true)))
(let (($x720 (or false false)))
(let (($x73 (or $x720 false false)))
(let (($x243 (not $x73)))
(and $x243 (or $x73 $x1654)))))))
(check-sat)
; query 81: function Quantization_and_coding, block 243, name %244
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in235_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 16) in235_16) ((_ sign_extend 16) in235_16)) true))))))
(check-sat)
; query 82: function Quantization_and_coding, block 243, name %245
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in235_16 () (_ BitVec 16))
(assert
 (let ((?x1254 ((_ sign_extend 16) in235_16)))
(let ((?x952 (bvsub ?x1254 (_ bv4294967292 32))))
(let ((?x726 (bvsub ?x1254 (_ bv4294967288 32))))
(let (($x267 (and (distinct (bvsub ((_ sign_extend 1) ?x1254) ((_ sign_extend 1) (_ bv4294967292 32))) ((_ sign_extend 1) ?x952)) true)))
(let (($x720 (or false false)))
(let (($x295 (and (distinct (bvsub ((_ sign_extend 1) ?x1254) ((_ sign_extend 1) (_ bv4294967288 32))) ((_ sign_extend 1) ?x726)) true)))
(and (not (or $x720 false (or $x295))) (or (or $x720 false (or $x267)) (and (distinct ?x726 ?x952) true))))))))))
(check-sat)
; query 83: function RPE_grid_positioning, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 84: function RPE_grid_positioning, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x803 (ite (bvsge (_ bv3 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x720 (or false false)))
(let (($x73 (or $x720 false false)))
(let (($x243 (not $x73)))
(and $x243 (or $x73 (and (distinct ?x803 ?x803) true))))))))
(check-sat)
; query 85: function RPE_grid_positioning, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 86: function RPE_grid_positioning, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1196 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1820 (and (distinct ?x1196 ?x1196) true)))
(let (($x720 (or false false)))
(let (($x325 (or false $x720 false)))
(and (not $x325) (or $x325 $x1820)))))))
(check-sat)
; query 87: function Short_term_synthesis_filtering, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in23_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 16) in23_16) ((_ sign_extend 16) in23_16)) true))))))
(check-sat)
; query 88: function Short_term_synthesis_filtering, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in23_16 () (_ BitVec 16))
(assert
 (let ((?x998 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in23_16)) (_ bv1 1) (_ bv0 1))))
(let (($x720 (or false false)))
(let (($x73 (or $x720 false false)))
(let (($x243 (not $x73)))
(and $x243 (or $x73 (and (distinct ?x998 ?x998) true))))))))
(check-sat)
; query 89: function Short_term_synthesis_filtering, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in20_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 48) in20_16) ((_ sign_extend 48) in20_16)) true))))))
(check-sat)
; query 90: function Short_term_synthesis_filtering, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in23_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 48) in23_16) ((_ sign_extend 48) in23_16)) true))))))
(check-sat)
; query 91: function Short_term_synthesis_filtering, block 30, name %33
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in20_16 () (_ BitVec 16))
(declare-fun in23_16 () (_ BitVec 16))
(assert
 (let ((?x1939 ((_ sign_extend 48) in20_16)))
(let ((?x448 ((_ sign_extend 48) in23_16)))
(let ((?x451 (bvmul ?x448 ?x1939)))
(let ((?x1866 (bvmul ?x1939 ?x448)))
(let (($x707 (and (distinct (bvmul ((_ sign_extend 64) ?x448) ((_ sign_extend 64) ?x1939)) ((_ sign_extend 64) ?x451)) true)))
(let (($x720 (or false false)))
(let (($x813 (or $x720 $x720 (or $x707))))
(let (($x808 (and (distinct (bvmul ((_ sign_extend 64) ?x1939) ((_ sign_extend 64) ?x448)) ((_ sign_extend 64) ?x1866)) true)))
(let (($x1942 (or $x720 $x720 (or $x808))))
(and (not $x1942) (or $x813 (and (distinct ?x1866 ?x451) true)))))))))))))
(check-sat)
; query 92: function Short_term_synthesis_filtering, block 30, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in20_16 () (_ BitVec 16))
(declare-fun in23_16 () (_ BitVec 16))
(assert
 (let ((?x1939 ((_ sign_extend 48) in20_16)))
(let ((?x448 ((_ sign_extend 48) in23_16)))
(let ((?x451 (bvmul ?x448 ?x1939)))
(let ((?x377 (bvadd ?x451 (_ bv16384 64))))
(let ((?x1866 (bvmul ?x1939 ?x448)))
(let ((?x721 (bvadd ?x1866 (_ bv16384 64))))
(let (($x734 (and (distinct (bvadd ((_ sign_extend 1) ?x451) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x377)) true)))
(let (($x707 (and (distinct (bvmul ((_ sign_extend 64) ?x448) ((_ sign_extend 64) ?x1939)) ((_ sign_extend 64) ?x451)) true)))
(let (($x720 (or false false)))
(let (($x813 (or $x720 $x720 (or $x707))))
(let (($x433 (or $x813 false (or $x734))))
(let (($x535 (and (distinct (bvadd ((_ sign_extend 1) ?x1866) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x721)) true)))
(let (($x808 (and (distinct (bvmul ((_ sign_extend 64) ?x1939) ((_ sign_extend 64) ?x448)) ((_ sign_extend 64) ?x1866)) true)))
(let (($x1942 (or $x720 $x720 (or $x808))))
(let (($x1664 (or $x1942 false (or $x535))))
(and (not $x1664) (or $x433 (and (distinct ?x721 ?x377) true)))))))))))))))))))
(check-sat)
; query 93: function Short_term_synthesis_filtering, block 30, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in20_16 () (_ BitVec 16))
(declare-fun in23_16 () (_ BitVec 16))
(assert
 (let ((?x1939 ((_ sign_extend 48) in20_16)))
(let ((?x448 ((_ sign_extend 48) in23_16)))
(let ((?x451 (bvmul ?x448 ?x1939)))
(let ((?x377 (bvadd ?x451 (_ bv16384 64))))
(let ((?x193 (bvashr ?x377 (_ bv15 64))))
(let ((?x1866 (bvmul ?x1939 ?x448)))
(let ((?x721 (bvadd ?x1866 (_ bv16384 64))))
(let ((?x761 (bvashr ?x721 (_ bv15 64))))
(let (($x911 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x734 (and (distinct (bvadd ((_ sign_extend 1) ?x451) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x377)) true)))
(let (($x707 (and (distinct (bvmul ((_ sign_extend 64) ?x448) ((_ sign_extend 64) ?x1939)) ((_ sign_extend 64) ?x451)) true)))
(let (($x720 (or false false)))
(let (($x813 (or $x720 $x720 (or $x707))))
(let (($x433 (or $x813 false (or $x734))))
(let (($x1479 (or (or $x433 false false) $x911)))
(let (($x535 (and (distinct (bvadd ((_ sign_extend 1) ?x1866) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x721)) true)))
(let (($x808 (and (distinct (bvmul ((_ sign_extend 64) ?x1939) ((_ sign_extend 64) ?x448)) ((_ sign_extend 64) ?x1866)) true)))
(let (($x1942 (or $x720 $x720 (or $x808))))
(let (($x1664 (or $x1942 false (or $x535))))
(let (($x1240 (or (or $x1664 false false) $x911)))
(and (not $x1240) (or $x1479 (and (distinct ?x761 ?x193) true))))))))))))))))))))))))
(check-sat)
; query 94: function Short_term_synthesis_filtering, block 30, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in20_16 () (_ BitVec 16))
(declare-fun in23_16 () (_ BitVec 16))
(assert
 (let ((?x1939 ((_ sign_extend 48) in20_16)))
(let ((?x448 ((_ sign_extend 48) in23_16)))
(let ((?x451 (bvmul ?x448 ?x1939)))
(let ((?x377 (bvadd ?x451 (_ bv16384 64))))
(let ((?x193 (bvashr ?x377 (_ bv15 64))))
(let (($x1209 (and (distinct (bvand (_ bv65535 64) (bvashr (bvadd (bvmul ?x1939 ?x448) (_ bv16384 64)) (_ bv15 64))) (bvand ?x193 (_ bv65535 64))) true)))
(let (($x911 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x734 (and (distinct (bvadd ((_ sign_extend 1) ?x451) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x377)) true)))
(let (($x707 (and (distinct (bvmul ((_ sign_extend 64) ?x448) ((_ sign_extend 64) ?x1939)) ((_ sign_extend 64) ?x451)) true)))
(let (($x720 (or false false)))
(let (($x813 (or $x720 $x720 (or $x707))))
(let (($x433 (or $x813 false (or $x734))))
(let (($x1479 (or (or $x433 false false) $x911)))
(let (($x535 (and (distinct (bvadd ((_ sign_extend 1) (bvmul ?x1939 ?x448)) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) (bvadd (bvmul ?x1939 ?x448) (_ bv16384 64)))) true)))
(let (($x808 (and (distinct (bvmul ((_ sign_extend 64) ?x1939) ((_ sign_extend 64) ?x448)) ((_ sign_extend 64) (bvmul ?x1939 ?x448))) true)))
(let (($x1942 (or $x720 $x720 (or $x808))))
(let (($x1664 (or $x1942 false (or $x535))))
(let (($x1240 (or (or $x1664 false false) $x911)))
(and (not (or false $x1240 false)) (or (or $x1479 false false) $x1209)))))))))))))))))))))
(check-sat)
; query 95: function Short_term_synthesis_filtering, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in42_64 () (_ BitVec 64))
(assert
 (let ((?x1446 (ite (bvsge (_ bv18446744073709518848 64) in42_64) (_ bv1 1) (_ bv0 1))))
(let (($x1480 (or false false false)))
(let (($x197 (not $x1480)))
(and $x197 (or $x1480 (and (distinct ?x1446 ?x1446) true)))))))
(check-sat)
; query 96: function Short_term_synthesis_filtering, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 16) in53_16) ((_ sign_extend 16) in53_16)) true))))))
(check-sat)
; query 97: function Short_term_synthesis_filtering, block 56, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let ((?x1714 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in53_16)) (_ bv1 1) (_ bv0 1))))
(let (($x720 (or false false)))
(let (($x73 (or $x720 false false)))
(let (($x243 (not $x73)))
(and $x243 (or $x73 (and (distinct ?x1714 ?x1714) true))))))))
(check-sat)
; query 98: function Short_term_synthesis_filtering, block 60, name %61
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in20_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 48) in20_16) ((_ sign_extend 48) in20_16)) true))))))
(check-sat)
; query 99: function Short_term_synthesis_filtering, block 60, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 48) in53_16) ((_ sign_extend 48) in53_16)) true))))))
(check-sat)
; query 100: function Short_term_synthesis_filtering, block 60, name %63
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in20_16 () (_ BitVec 16))
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let ((?x1939 ((_ sign_extend 48) in20_16)))
(let ((?x702 ((_ sign_extend 48) in53_16)))
(let ((?x24 (bvmul ?x702 ?x1939)))
(let ((?x1589 (bvmul ?x1939 ?x702)))
(let (($x962 (and (distinct (bvmul ((_ sign_extend 64) ?x702) ((_ sign_extend 64) ?x1939)) ((_ sign_extend 64) ?x24)) true)))
(let (($x720 (or false false)))
(let (($x119 (or $x720 $x720 (or $x962))))
(let (($x1613 (and (distinct (bvmul ((_ sign_extend 64) ?x1939) ((_ sign_extend 64) ?x702)) ((_ sign_extend 64) ?x1589)) true)))
(let (($x1392 (or $x720 $x720 (or $x1613))))
(and (not $x1392) (or $x119 (and (distinct ?x1589 ?x24) true)))))))))))))
(check-sat)
; query 101: function Short_term_synthesis_filtering, block 60, name %64
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in20_16 () (_ BitVec 16))
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let ((?x1939 ((_ sign_extend 48) in20_16)))
(let ((?x702 ((_ sign_extend 48) in53_16)))
(let ((?x24 (bvmul ?x702 ?x1939)))
(let ((?x349 (bvadd ?x24 (_ bv16384 64))))
(let ((?x1589 (bvmul ?x1939 ?x702)))
(let ((?x1540 (bvadd ?x1589 (_ bv16384 64))))
(let (($x1376 (and (distinct (bvadd ((_ sign_extend 1) ?x24) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x349)) true)))
(let (($x962 (and (distinct (bvmul ((_ sign_extend 64) ?x702) ((_ sign_extend 64) ?x1939)) ((_ sign_extend 64) ?x24)) true)))
(let (($x720 (or false false)))
(let (($x119 (or $x720 $x720 (or $x962))))
(let (($x1134 (or $x119 false (or $x1376))))
(let (($x1633 (and (distinct (bvadd ((_ sign_extend 1) ?x1589) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x1540)) true)))
(let (($x1613 (and (distinct (bvmul ((_ sign_extend 64) ?x1939) ((_ sign_extend 64) ?x702)) ((_ sign_extend 64) ?x1589)) true)))
(let (($x1392 (or $x720 $x720 (or $x1613))))
(let (($x1500 (or $x1392 false (or $x1633))))
(and (not $x1500) (or $x1134 (and (distinct ?x1540 ?x349) true)))))))))))))))))))
(check-sat)
; query 102: function Short_term_synthesis_filtering, block 60, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in20_16 () (_ BitVec 16))
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let ((?x1939 ((_ sign_extend 48) in20_16)))
(let ((?x702 ((_ sign_extend 48) in53_16)))
(let ((?x24 (bvmul ?x702 ?x1939)))
(let ((?x349 (bvadd ?x24 (_ bv16384 64))))
(let ((?x1377 (bvashr ?x349 (_ bv15 64))))
(let ((?x1589 (bvmul ?x1939 ?x702)))
(let ((?x1540 (bvadd ?x1589 (_ bv16384 64))))
(let ((?x1587 (bvashr ?x1540 (_ bv15 64))))
(let (($x911 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1376 (and (distinct (bvadd ((_ sign_extend 1) ?x24) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x349)) true)))
(let (($x962 (and (distinct (bvmul ((_ sign_extend 64) ?x702) ((_ sign_extend 64) ?x1939)) ((_ sign_extend 64) ?x24)) true)))
(let (($x720 (or false false)))
(let (($x119 (or $x720 $x720 (or $x962))))
(let (($x1134 (or $x119 false (or $x1376))))
(let (($x1195 (or (or $x1134 false false) $x911)))
(let (($x1633 (and (distinct (bvadd ((_ sign_extend 1) ?x1589) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x1540)) true)))
(let (($x1613 (and (distinct (bvmul ((_ sign_extend 64) ?x1939) ((_ sign_extend 64) ?x702)) ((_ sign_extend 64) ?x1589)) true)))
(let (($x1392 (or $x720 $x720 (or $x1613))))
(let (($x1500 (or $x1392 false (or $x1633))))
(let (($x1246 (or (or $x1500 false false) $x911)))
(and (not $x1246) (or $x1195 (and (distinct ?x1587 ?x1377) true))))))))))))))))))))))))
(check-sat)
; query 103: function Short_term_synthesis_filtering, block 60, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in20_16 () (_ BitVec 16))
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let ((?x1939 ((_ sign_extend 48) in20_16)))
(let ((?x702 ((_ sign_extend 48) in53_16)))
(let ((?x24 (bvmul ?x702 ?x1939)))
(let ((?x349 (bvadd ?x24 (_ bv16384 64))))
(let ((?x1377 (bvashr ?x349 (_ bv15 64))))
(let (($x559 (and (distinct (bvand (_ bv65535 64) (bvashr (bvadd (bvmul ?x1939 ?x702) (_ bv16384 64)) (_ bv15 64))) (bvand ?x1377 (_ bv65535 64))) true)))
(let (($x911 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1376 (and (distinct (bvadd ((_ sign_extend 1) ?x24) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x349)) true)))
(let (($x962 (and (distinct (bvmul ((_ sign_extend 64) ?x702) ((_ sign_extend 64) ?x1939)) ((_ sign_extend 64) ?x24)) true)))
(let (($x720 (or false false)))
(let (($x119 (or $x720 $x720 (or $x962))))
(let (($x1134 (or $x119 false (or $x1376))))
(let (($x1195 (or (or $x1134 false false) $x911)))
(let (($x1633 (and (distinct (bvadd ((_ sign_extend 1) (bvmul ?x1939 ?x702)) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) (bvadd (bvmul ?x1939 ?x702) (_ bv16384 64)))) true)))
(let (($x1613 (and (distinct (bvmul ((_ sign_extend 64) ?x1939) ((_ sign_extend 64) ?x702)) ((_ sign_extend 64) (bvmul ?x1939 ?x702))) true)))
(let (($x1392 (or $x720 $x720 (or $x1613))))
(let (($x1500 (or $x1392 false (or $x1633))))
(let (($x1246 (or (or $x1500 false false) $x911)))
(and (not (or false $x1246 false)) (or (or $x1195 false false) $x559)))))))))))))))))))))
(check-sat)
; query 104: function Transformation_to_Log_Area_Ratios, block 12, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 16) in5_16) ((_ sign_extend 16) in5_16)) true))))))
(check-sat)
; query 105: function Transformation_to_Log_Area_Ratios, block 12, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_16 () (_ BitVec 16))
(assert
 (let ((?x1763 ((_ sign_extend 16) in5_16)))
(let ((?x1089 (bvsub (_ bv0 32) ?x1763)))
(let (($x1640 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1763)) ((_ sign_extend 1) ?x1089)) true)))
(let (($x720 (or false false)))
(let (($x1945 (or false $x720 (or $x1640))))
(and (not $x1945) (or $x1945 (and (distinct ?x1089 ?x1089) true)))))))))
(check-sat)
; query 106: function Transformation_to_Log_Area_Ratios, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 16) in5_16) ((_ sign_extend 16) in5_16)) true))))))
(check-sat)
; query 107: function Transformation_to_Log_Area_Ratios, block 77, name %78
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 108: function Transformation_to_Log_Area_Ratios, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_16 () (_ BitVec 16))
(assert
 (let ((?x1013 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in5_16)) (_ bv1 1) (_ bv0 1))))
(let (($x720 (or false false)))
(let (($x73 (or $x720 false false)))
(let (($x243 (not $x73)))
(and $x243 (or $x73 (and (distinct ?x1013 ?x1013) true))))))))
(check-sat)
; query 109: function Transformation_to_Log_Area_Ratios, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 16) in5_16) ((_ sign_extend 16) in5_16)) true))))))
(check-sat)
; query 110: function alaw_input, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x1696 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x766 (or false false (or $x1696))))
(and (not $x766) (or $x766 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 111: function alaw_input, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let ((?x1532 (ite (= (_ bv4294967295 32) in.1_32) (_ bv1 1) (_ bv0 1))))
(let (($x1480 (or false false false)))
(let (($x197 (not $x1480)))
(and $x197 (or $x1480 (and (distinct ?x1532 ?x1532) true)))))))
(check-sat)
; query 112: function gsm_L_add, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_64 () (_ BitVec 64))
(assert
 (let ((?x1399 (bvsub (_ bv0 64) in13_64)))
(let ((?x1412 ((_ sign_extend 1) ?x1399)))
(let (($x1457 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in13_64)) ?x1412) true)))))
(and (not $x1457) (or $x1457 (and (distinct ?x1399 ?x1399) true)))))))
(check-sat)
; query 113: function gsm_L_add, block 16, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_64 () (_ BitVec 64))
(assert
 (let ((?x1399 (bvsub (_ bv0 64) in13_64)))
(let ((?x1526 (bvadd ?x1399 (_ bv18446744073709551614 64))))
(let ((?x1474 (bvsub ?x1399 (_ bv2 64))))
(let (($x1514 (and (distinct (bvadd ((_ sign_extend 1) ?x1399) ((_ sign_extend 1) (_ bv18446744073709551614 64))) ((_ sign_extend 1) ?x1526)) true)))
(let ((?x1412 ((_ sign_extend 1) ?x1399)))
(let (($x1457 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in13_64)) ?x1412) true)))))
(let (($x1122 (or $x1457 false (or (and (distinct (bvsub ?x1412 ((_ sign_extend 1) (_ bv2 64))) ((_ sign_extend 1) ?x1474)) true)))))
(and (not $x1122) (or (or $x1457 false (or $x1514)) (and (distinct ?x1474 ?x1526) true)))))))))))
(check-sat)
; query 114: function gsm_L_add, block 21, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1441 (ite (bvsge (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x1480 (or false false false)))
(let (($x197 (not $x1480)))
(and $x197 (or $x1480 (and (distinct ?x1441 ?x1441) true)))))))
(check-sat)
; query 115: function gsm_L_add, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1653 (bvadd in1_64 in0_64)))
(let ((?x1551 (bvadd in0_64 in1_64)))
(let (($x1150 (and (distinct ?x1551 ?x1653) true)))
(let (($x1407 (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) in0_64)) ((_ sign_extend 1) ?x1653)) true)))
(let (($x1550 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) ?x1551)) true)))
(and (not (or false false (or $x1550))) (or (or false false (or $x1407)) $x1150))))))))
(check-sat)
; query 116: function gsm_L_add, block 25, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1653 (bvadd in1_64 in0_64)))
(let ((?x1551 (bvadd in0_64 in1_64)))
(let (($x1150 (and (distinct ?x1551 ?x1653) true)))
(let (($x1421 (and (distinct (bvadd ((_ zero_extend 1) in1_64) ((_ zero_extend 1) in0_64)) ((_ zero_extend 1) ?x1653)) true)))
(let (($x1450 (or false false (or $x1421))))
(let (($x1480 (or false false false)))
(let (($x197 (not $x1480)))
(and $x197 (or $x1450 $x1150))))))))))
(check-sat)
; query 117: function gsm_L_add, block 25, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let (($x1499 (and (distinct (ite (bvugt (bvadd in0_64 in1_64) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1)) (ite (bvugt (bvadd in1_64 in0_64) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))) true)))
(let (($x1421 (and (distinct (bvadd ((_ zero_extend 1) in1_64) ((_ zero_extend 1) in0_64)) ((_ zero_extend 1) (bvadd in1_64 in0_64))) true)))
(let (($x1450 (or false false (or $x1421))))
(let (($x1480 (or false false false)))
(let (($x1405 (or $x1480 false false)))
(let (($x1470 (not $x1405)))
(and $x1470 (or (or $x1450 false false) $x1499)))))))))
(check-sat)
; query 118: function gsm_L_add, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1515 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x1480 (or false false false)))
(let (($x197 (not $x1480)))
(and $x197 (or $x1480 (and (distinct ?x1515 ?x1515) true)))))))
(check-sat)
; query 119: function gsm_L_add, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1653 (bvadd in1_64 in0_64)))
(let ((?x1551 (bvadd in0_64 in1_64)))
(let (($x1150 (and (distinct ?x1551 ?x1653) true)))
(let (($x1407 (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) in0_64)) ((_ sign_extend 1) ?x1653)) true)))
(let (($x1550 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) ?x1551)) true)))
(and (not (or false false (or $x1550))) (or (or false false (or $x1407)) $x1150))))))))
(check-sat)
; query 120: function gsm_L_add, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1538 (bvadd in0_64 (_ bv1 64))))
(let ((?x1534 (bvsub (_ bv0 64) ?x1538)))
(let (($x1503 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1538)) ((_ sign_extend 1) ?x1534)) true)))
(let ((?x1159 ((_ sign_extend 1) ?x1538)))
(let (($x868 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1159) true)))))
(let (($x263 (or false $x868 (or $x1503))))
(and (not $x263) (or $x263 (and (distinct ?x1534 ?x1534) true))))))))))
(check-sat)
; query 121: function gsm_L_add, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1459 (bvadd in1_64 (_ bv1 64))))
(let ((?x1398 ((_ sign_extend 1) ?x1459)))
(let (($x542 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1398) true)))))
(and (not $x542) (or $x542 (and (distinct ?x1459 ?x1459) true)))))))
(check-sat)
; query 122: function gsm_L_add, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1459 (bvadd in1_64 (_ bv1 64))))
(let ((?x1353 (bvsub (_ bv0 64) ?x1459)))
(let (($x1354 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1459)) ((_ sign_extend 1) ?x1353)) true)))
(let ((?x1398 ((_ sign_extend 1) ?x1459)))
(let (($x542 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1398) true)))))
(let (($x848 (or false $x542 (or $x1354))))
(and (not $x848) (or $x848 (and (distinct ?x1353 ?x1353) true))))))))))
(check-sat)
; query 123: function gsm_L_add, block 8, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1538 (bvadd in0_64 (_ bv1 64))))
(let ((?x1534 (bvsub (_ bv0 64) ?x1538)))
(let ((?x1459 (bvadd in1_64 (_ bv1 64))))
(let ((?x1353 (bvsub (_ bv0 64) ?x1459)))
(let ((?x1192 (bvadd ?x1353 ?x1534)))
(let ((?x986 (bvadd ?x1534 ?x1353)))
(let (($x1308 (and (distinct (bvadd ((_ zero_extend 1) ?x1353) ((_ zero_extend 1) ?x1534)) ((_ zero_extend 1) ?x1192)) true)))
(let (($x1503 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1538)) ((_ sign_extend 1) ?x1534)) true)))
(let ((?x1159 ((_ sign_extend 1) ?x1538)))
(let (($x868 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1159) true)))))
(let (($x263 (or false $x868 (or $x1503))))
(let (($x1354 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1459)) ((_ sign_extend 1) ?x1353)) true)))
(let ((?x1398 ((_ sign_extend 1) ?x1459)))
(let (($x542 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1398) true)))))
(let (($x848 (or false $x542 (or $x1354))))
(let (($x1279 (or $x848 $x263 (or $x1308))))
(and (not (or $x263 $x848 false)) (or $x1279 (and (distinct ?x986 ?x1192) true))))))))))))))))))))
(check-sat)
; query 124: function gsm_L_add, block 8, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1538 (bvadd in0_64 (_ bv1 64))))
(let ((?x1534 (bvsub (_ bv0 64) ?x1538)))
(let ((?x1459 (bvadd in1_64 (_ bv1 64))))
(let ((?x1353 (bvsub (_ bv0 64) ?x1459)))
(let ((?x1192 (bvadd ?x1353 ?x1534)))
(let (($x1218 (and (distinct (ite (bvuge (bvadd ?x1534 ?x1353) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1)) (ite (bvuge ?x1192 (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))) true)))
(let (($x1308 (and (distinct (bvadd ((_ zero_extend 1) ?x1353) ((_ zero_extend 1) ?x1534)) ((_ zero_extend 1) ?x1192)) true)))
(let (($x1503 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1538)) ((_ sign_extend 1) ?x1534)) true)))
(let ((?x1159 ((_ sign_extend 1) ?x1538)))
(let (($x868 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1159) true)))))
(let (($x263 (or false $x868 (or $x1503))))
(let (($x1354 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1459)) ((_ sign_extend 1) ?x1353)) true)))
(let ((?x1398 ((_ sign_extend 1) ?x1459)))
(let (($x542 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1398) true)))))
(let (($x848 (or false $x542 (or $x1354))))
(let (($x1279 (or $x848 $x263 (or $x1308))))
(and (not (or (or $x263 $x848 false) false false)) (or (or $x1279 false false) $x1218)))))))))))))))))))
(check-sat)
; query 125: function gsm_L_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1538 (bvadd in0_64 (_ bv1 64))))
(let ((?x1159 ((_ sign_extend 1) ?x1538)))
(let (($x868 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1159) true)))))
(and (not $x868) (or $x868 (and (distinct ?x1538 ?x1538) true)))))))
(check-sat)
; query 126: function gsm_L_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1265 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x1480 (or false false false)))
(let (($x197 (not $x1480)))
(and $x197 (or $x1480 (and (distinct ?x1265 ?x1265) true)))))))
(check-sat)
; query 127: function gsm_L_asl, block 12, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1370 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x1480 (or false false false)))
(let (($x197 (not $x1480)))
(and $x197 (or $x1480 (and (distinct ?x1370 ?x1370) true)))))))
(check-sat)
; query 128: function gsm_L_asl, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x1385 (or false (or (= ((_ extract 31 31) in1_32) (_ bv1 1))))))
(let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x1385 (and (distinct ((_ zero_extend 32) in1_32) ((_ zero_extend 32) in1_32)) true)))))))
(check-sat)
; query 129: function gsm_L_asl, block 17, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1325 ((_ zero_extend 32) in1_32)))
(let ((?x1307 (bvshl in0_64 ?x1325)))
(let (($x1310 (bvuge ?x1325 (_ bv64 64))))
(let (($x302 (or (or false (or false (or (= ((_ extract 31 31) in1_32) (_ bv1 1)))) false) $x1310)))
(let (($x1506 (not (or (or false (or false false) false) $x1310))))
(and $x1506 (or $x302 (and (distinct ?x1307 ?x1307) true)))))))))
(check-sat)
; query 130: function gsm_L_asl, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1537 (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x1480 (or false false false)))
(let (($x197 (not $x1480)))
(and $x197 (or $x1480 (and (distinct ?x1537 ?x1537) true)))))))
(check-sat)
; query 131: function gsm_L_asl, block 7, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1265 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1023 ((_ zero_extend 31) ?x1265)))
(let ((?x1558 (bvsub (_ bv0 32) ?x1023)))
(let (($x1559 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1023)) ((_ sign_extend 1) ?x1558)) true)))
(let (($x1480 (or false false false)))
(let (($x1991 (or $x1480 false)))
(let (($x1724 (or false $x1991 (or $x1559))))
(and (not $x1724) (or $x1724 (and (distinct ?x1558 ?x1558) true)))))))))))
(check-sat)
; query 132: function gsm_L_asl, block 7, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1265 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1023 ((_ zero_extend 31) ?x1265)))
(let ((?x1558 (bvsub (_ bv0 32) ?x1023)))
(let ((?x1686 ((_ sign_extend 32) ?x1558)))
(let (($x1559 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1023)) ((_ sign_extend 1) ?x1558)) true)))
(let (($x1480 (or false false false)))
(let (($x1991 (or $x1480 false)))
(let (($x1724 (or false $x1991 (or $x1559))))
(let (($x1661 (or $x1724 false)))
(and (not $x1661) (or $x1661 (and (distinct ?x1686 ?x1686) true)))))))))))))
(check-sat)
; query 133: function gsm_L_asl, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1265 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x1480 (or false false false)))
(let (($x197 (not $x1480)))
(and $x197 (or $x1480 (and (distinct ?x1265 ?x1265) true)))))))
(check-sat)
; query 134: function gsm_L_asl, block 7, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1265 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1023 ((_ zero_extend 31) ?x1265)))
(let (($x1480 (or false false false)))
(let (($x1991 (or $x1480 false)))
(and (not $x1991) (or $x1991 (and (distinct ?x1023 ?x1023) true))))))))
(check-sat)
; query 135: function gsm_L_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1106 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x1480 (or false false false)))
(let (($x197 (not $x1480)))
(and $x197 (or $x1480 (and (distinct ?x1106 ?x1106) true)))))))
(check-sat)
; query 136: function gsm_L_asr, block 12, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1370 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x1480 (or false false false)))
(let (($x197 (not $x1480)))
(and $x197 (or $x1480 (and (distinct ?x1370 ?x1370) true)))))))
(check-sat)
; query 137: function gsm_L_asr, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x362 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in1_32))) true)))
(let (($x290 (or false false (or $x362))))
(and (not $x290) (or $x290 (and (distinct (bvsub (_ bv0 32) in1_32) (bvsub (_ bv0 32) in1_32)) true))))))
(check-sat)
; query 138: function gsm_L_asr, block 14, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x207 (bvsub (_ bv0 32) in1_32)))
(let ((?x635 ((_ zero_extend 32) ?x207)))
(let (($x362 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x207)) true)))
(let (($x290 (or false false (or $x362))))
(let (($x713 (or $x290 (or (= ((_ extract 31 31) ?x207) (_ bv1 1))))))
(and (not (or $x290 false)) (or $x713 (and (distinct ?x635 ?x635) true)))))))))
(check-sat)
; query 139: function gsm_L_asr, block 14, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x207 (bvsub (_ bv0 32) in1_32)))
(let ((?x635 ((_ zero_extend 32) ?x207)))
(let ((?x690 (bvshl in0_64 ?x635)))
(let (($x1024 (bvuge ?x635 (_ bv64 64))))
(let (($x362 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x207)) true)))
(let (($x290 (or false false (or $x362))))
(let (($x713 (or $x290 (or (= ((_ extract 31 31) ?x207) (_ bv1 1))))))
(and (not (or (or false (or $x290 false) false) $x1024)) (or (or (or false $x713 false) $x1024) (and (distinct ?x690 ?x690) true)))))))))))
(check-sat)
; query 140: function gsm_L_asr, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x1385 (or false (or (= ((_ extract 31 31) in1_32) (_ bv1 1))))))
(let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x1385 (and (distinct ((_ zero_extend 32) in1_32) ((_ zero_extend 32) in1_32)) true)))))))
(check-sat)
; query 141: function gsm_L_asr, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1325 ((_ zero_extend 32) in1_32)))
(let ((?x1806 (bvashr in0_64 ?x1325)))
(let (($x1310 (bvuge ?x1325 (_ bv64 64))))
(let (($x302 (or (or false (or false (or (= ((_ extract 31 31) in1_32) (_ bv1 1)))) false) $x1310)))
(let (($x1506 (not (or (or false (or false false) false) $x1310))))
(and $x1506 (or $x302 (and (distinct ?x1806 ?x1806) true)))))))))
(check-sat)
; query 142: function gsm_L_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1265 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x1480 (or false false false)))
(let (($x197 (not $x1480)))
(and $x197 (or $x1480 (and (distinct ?x1265 ?x1265) true)))))))
(check-sat)
; query 143: function gsm_L_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1265 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1023 ((_ zero_extend 31) ?x1265)))
(let (($x1480 (or false false false)))
(let (($x1991 (or $x1480 false)))
(and (not $x1991) (or $x1991 (and (distinct ?x1023 ?x1023) true))))))))
(check-sat)
; query 144: function gsm_L_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1265 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1023 ((_ zero_extend 31) ?x1265)))
(let ((?x1558 (bvsub (_ bv0 32) ?x1023)))
(let (($x1559 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1023)) ((_ sign_extend 1) ?x1558)) true)))
(let (($x1480 (or false false false)))
(let (($x1991 (or $x1480 false)))
(let (($x1724 (or false $x1991 (or $x1559))))
(and (not $x1724) (or $x1724 (and (distinct ?x1558 ?x1558) true)))))))))))
(check-sat)
; query 145: function gsm_L_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1265 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1023 ((_ zero_extend 31) ?x1265)))
(let ((?x1558 (bvsub (_ bv0 32) ?x1023)))
(let ((?x1686 ((_ sign_extend 32) ?x1558)))
(let (($x1559 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1023)) ((_ sign_extend 1) ?x1558)) true)))
(let (($x1480 (or false false false)))
(let (($x1991 (or $x1480 false)))
(let (($x1724 (or false $x1991 (or $x1559))))
(let (($x1661 (or $x1724 false)))
(and (not $x1661) (or $x1661 (and (distinct ?x1686 ?x1686) true)))))))))))))
(check-sat)
; query 146: function gsm_L_asr, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1537 (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x1480 (or false false false)))
(let (($x197 (not $x1480)))
(and $x197 (or $x1480 (and (distinct ?x1537 ?x1537) true)))))))
(check-sat)
; query 147: function gsm_L_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1106 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x1480 (or false false false)))
(let (($x197 (not $x1480)))
(and $x197 (or $x1480 (and (distinct ?x1106 ?x1106) true)))))))
(check-sat)
; query 148: function gsm_L_mult, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 149: function gsm_L_mult, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1773 (ite (and (distinct (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) true) (_ bv1 1) (_ bv0 1))))
(let (($x720 (or false false)))
(let (($x73 (or $x720 false false)))
(let (($x243 (not $x73)))
(and $x243 (or $x73 (and (distinct ?x1773 ?x1773) true))))))))
(check-sat)
; query 150: function gsm_L_mult, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 151: function gsm_L_mult, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1772 (ite (and (distinct (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) true) (_ bv1 1) (_ bv0 1))))
(let (($x720 (or false false)))
(let (($x73 (or $x720 false false)))
(let (($x243 (not $x73)))
(and $x243 (or $x73 (and (distinct ?x1772 ?x1772) true))))))))
(check-sat)
; query 152: function gsm_L_sub, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in11_64 () (_ BitVec 64))
(assert
 (let (($x1812 (and (distinct (bvadd ((_ zero_extend 1) in11_64) ((_ zero_extend 1) (_ bv1 64))) ((_ zero_extend 1) (bvadd in11_64 (_ bv1 64)))) true)))
(let (($x900 (and (distinct (bvadd ((_ sign_extend 1) in11_64) ((_ sign_extend 1) (_ bv1 64))) ((_ sign_extend 1) (bvadd in11_64 (_ bv1 64)))) true)))
(let (($x956 (or (or false false (or $x900 $x1812)) (and (distinct (bvadd in11_64 (_ bv1 64)) (bvadd in11_64 (_ bv1 64))) true))))
(let (($x1480 (or false false false)))
(let (($x197 (not $x1480)))
(and $x197 $x956)))))))
(check-sat)
; query 153: function gsm_L_sub, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1441 (ite (bvsge (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x1480 (or false false false)))
(let (($x197 (not $x1480)))
(and $x197 (or $x1480 (and (distinct ?x1441 ?x1441) true)))))))
(check-sat)
; query 154: function gsm_L_sub, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x330 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvsub in0_64 in1_64))) true)))
(let (($x703 (or false false (or $x330))))
(let (($x415 (or $x703 (and (distinct (bvsub in0_64 in1_64) (bvsub in0_64 in1_64)) true))))
(and (not $x703) $x415)))))
(check-sat)
; query 155: function gsm_L_sub, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1538 (bvadd in0_64 (_ bv1 64))))
(let ((?x1159 ((_ sign_extend 1) ?x1538)))
(let (($x868 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1159) true)))))
(and (not $x868) (or $x868 (and (distinct ?x1538 ?x1538) true)))))))
(check-sat)
; query 156: function gsm_L_sub, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1538 (bvadd in0_64 (_ bv1 64))))
(let ((?x1534 (bvsub (_ bv0 64) ?x1538)))
(let (($x1503 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1538)) ((_ sign_extend 1) ?x1534)) true)))
(let ((?x1159 ((_ sign_extend 1) ?x1538)))
(let (($x868 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1159) true)))))
(let (($x263 (or false $x868 (or $x1503))))
(and (not $x263) (or $x263 (and (distinct ?x1534 ?x1534) true))))))))))
(check-sat)
; query 157: function gsm_L_sub, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1538 (bvadd in0_64 (_ bv1 64))))
(let ((?x1534 (bvsub (_ bv0 64) ?x1538)))
(let ((?x940 (bvadd ?x1534 in1_64)))
(let (($x142 (and (distinct (bvadd ((_ zero_extend 1) ?x1534) ((_ zero_extend 1) in1_64)) ((_ zero_extend 1) ?x940)) true)))
(let (($x1503 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1538)) ((_ sign_extend 1) ?x1534)) true)))
(let ((?x1159 ((_ sign_extend 1) ?x1538)))
(let (($x868 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1159) true)))))
(let (($x263 (or false $x868 (or $x1503))))
(let (($x533 (or $x263 false (or $x142))))
(and (not (or $x263 false false)) (or $x533 (and (distinct ?x940 ?x940) true)))))))))))))
(check-sat)
; query 158: function gsm_L_sub, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x519 (ite (bvuge (bvadd (bvsub (_ bv0 64) (bvadd in0_64 (_ bv1 64))) in1_64) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let ((?x1411 ((_ zero_extend 1) in1_64)))
(let ((?x1538 (bvadd in0_64 (_ bv1 64))))
(let ((?x1534 (bvsub (_ bv0 64) ?x1538)))
(let ((?x822 ((_ zero_extend 1) ?x1534)))
(let (($x1503 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1538)) ((_ sign_extend 1) ?x1534)) true)))
(let ((?x1159 ((_ sign_extend 1) ?x1538)))
(let (($x868 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1159) true)))))
(let (($x263 (or false $x868 (or $x1503))))
(let (($x533 (or $x263 false (or (and (distinct (bvadd ?x822 ?x1411) ((_ zero_extend 1) (bvadd ?x1534 in1_64))) true)))))
(and (not (or (or $x263 false false) false false)) (or (or $x533 false false) (and (distinct ?x519 ?x519) true))))))))))))))
(check-sat)
; query 159: function gsm_L_sub, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_64 () (_ BitVec 64))
(assert
 (let ((?x1058 (bvsub (_ bv0 64) in25_64)))
(let ((?x1103 ((_ sign_extend 1) ?x1058)))
(let (($x1076 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in25_64)) ?x1103) true)))))
(and (not $x1076) (or $x1076 (and (distinct ?x1058 ?x1058) true)))))))
(check-sat)
; query 160: function gsm_L_sub, block 28, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_64 () (_ BitVec 64))
(assert
 (let ((?x1058 (bvsub (_ bv0 64) in25_64)))
(let ((?x1041 (bvadd ?x1058 (_ bv18446744073709551615 64))))
(let ((?x760 (bvsub ?x1058 (_ bv1 64))))
(let (($x346 (and (distinct (bvadd ((_ sign_extend 1) ?x1058) ((_ sign_extend 1) (_ bv18446744073709551615 64))) ((_ sign_extend 1) ?x1041)) true)))
(let ((?x1103 ((_ sign_extend 1) ?x1058)))
(let (($x1076 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in25_64)) ?x1103) true)))))
(let (($x970 (or $x1076 false (or (and (distinct (bvsub ?x1103 ((_ sign_extend 1) (_ bv1 64))) ((_ sign_extend 1) ?x760)) true)))))
(and (not $x970) (or (or $x1076 false (or $x346)) (and (distinct ?x760 ?x1041) true)))))))))))
(check-sat)
; query 161: function gsm_L_sub, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1515 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x1480 (or false false false)))
(let (($x197 (not $x1480)))
(and $x197 (or $x1480 (and (distinct ?x1515 ?x1515) true)))))))
(check-sat)
; query 162: function gsm_L_sub, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x330 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvsub in0_64 in1_64))) true)))
(let (($x703 (or false false (or $x330))))
(let (($x415 (or $x703 (and (distinct (bvsub in0_64 in1_64) (bvsub in0_64 in1_64)) true))))
(and (not $x703) $x415)))))
(check-sat)
; query 163: function gsm_L_sub, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1459 (bvadd in1_64 (_ bv1 64))))
(let ((?x1353 (bvsub (_ bv0 64) ?x1459)))
(let (($x1354 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1459)) ((_ sign_extend 1) ?x1353)) true)))
(let ((?x1398 ((_ sign_extend 1) ?x1459)))
(let (($x542 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1398) true)))))
(let (($x848 (or false $x542 (or $x1354))))
(and (not $x848) (or $x848 (and (distinct ?x1353 ?x1353) true))))))))))
(check-sat)
; query 164: function gsm_L_sub, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1459 (bvadd in1_64 (_ bv1 64))))
(let ((?x1353 (bvsub (_ bv0 64) ?x1459)))
(let ((?x1083 (bvadd ?x1353 in0_64)))
(let ((?x341 (bvadd in0_64 ?x1353)))
(let (($x832 (and (distinct (bvadd ((_ zero_extend 1) ?x1353) ((_ zero_extend 1) in0_64)) ((_ zero_extend 1) ?x1083)) true)))
(let (($x1354 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1459)) ((_ sign_extend 1) ?x1353)) true)))
(let ((?x1398 ((_ sign_extend 1) ?x1459)))
(let (($x542 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1398) true)))))
(let (($x848 (or false $x542 (or $x1354))))
(let (($x1090 (or $x848 false (or $x832))))
(and (not (or false $x848 false)) (or $x1090 (and (distinct ?x341 ?x1083) true))))))))))))))
(check-sat)
; query 165: function gsm_L_sub, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x932 (ite (bvuge (bvadd (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64))) in0_64) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let ((?x242 (ite (bvuge (bvadd in0_64 (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64)))) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let ((?x1406 ((_ zero_extend 1) in0_64)))
(let ((?x1459 (bvadd in1_64 (_ bv1 64))))
(let ((?x1353 (bvsub (_ bv0 64) ?x1459)))
(let ((?x1324 ((_ zero_extend 1) ?x1353)))
(let (($x1354 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1459)) ((_ sign_extend 1) ?x1353)) true)))
(let ((?x1398 ((_ sign_extend 1) ?x1459)))
(let (($x542 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1398) true)))))
(let (($x848 (or false $x542 (or $x1354))))
(let (($x1090 (or $x848 false (or (and (distinct (bvadd ?x1324 ?x1406) ((_ zero_extend 1) (bvadd ?x1353 in0_64))) true)))))
(and (not (or (or false $x848 false) false false)) (or (or $x1090 false false) (and (distinct ?x242 ?x932) true)))))))))))))))
(check-sat)
; query 166: function gsm_L_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1459 (bvadd in1_64 (_ bv1 64))))
(let ((?x1398 ((_ sign_extend 1) ?x1459)))
(let (($x542 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1398) true)))))
(and (not $x542) (or $x542 (and (distinct ?x1459 ?x1459) true)))))))
(check-sat)
; query 167: function gsm_L_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x947 (ite (bvsle (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x1480 (or false false false)))
(let (($x197 (not $x1480)))
(and $x197 (or $x1480 (and (distinct ?x947 ?x947) true)))))))
(check-sat)
; query 168: function gsm_abs, block 13, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 169: function gsm_abs, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 170: function gsm_abs, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x177 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x720 (or false false)))
(let (($x73 (or $x720 false false)))
(let (($x243 (not $x73)))
(and $x243 (or $x73 (and (distinct ?x177 ?x177) true))))))))
(check-sat)
; query 171: function gsm_abs, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x69 ((_ sign_extend 16) in0_16)))
(let ((?x941 (bvsub (_ bv0 32) ?x69)))
(let (($x405 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x69)) ((_ sign_extend 1) ?x941)) true)))
(let (($x720 (or false false)))
(let (($x1937 (or false $x720 (or $x405))))
(and (not $x1937) (or $x1937 (and (distinct ?x941 ?x941) true)))))))))
(check-sat)
; query 172: function gsm_abs, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 173: function gsm_abs, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 174: function gsm_abs, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1011 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x720 (or false false)))
(let (($x73 (or $x720 false false)))
(let (($x243 (not $x73)))
(and $x243 (or $x73 (and (distinct ?x1011 ?x1011) true))))))))
(check-sat)
; query 175: function gsm_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_64 () (_ BitVec 64))
(assert
 (let ((?x244 (ite (bvslt (_ bv32767 64) in5_64) (_ bv1 1) (_ bv0 1))))
(let (($x1480 (or false false false)))
(let (($x197 (not $x1480)))
(and $x197 (or $x1480 (and (distinct ?x244 ?x244) true)))))))
(check-sat)
; query 176: function gsm_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 177: function gsm_add, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 178: function gsm_add, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1666 ((_ sign_extend 48) in0_16)))
(let ((?x1645 ((_ sign_extend 48) in1_16)))
(let ((?x556 (bvadd ?x1645 ?x1666)))
(let ((?x1792 (bvadd ?x1666 ?x1645)))
(let (($x1703 (and (distinct (bvadd ((_ sign_extend 1) ?x1645) ((_ sign_extend 1) ?x1666)) ((_ sign_extend 1) ?x556)) true)))
(let (($x720 (or false false)))
(let (($x261 (or $x720 $x720 (or $x1703))))
(let (($x650 (and (distinct (bvadd ((_ sign_extend 1) ?x1666) ((_ sign_extend 1) ?x1645)) ((_ sign_extend 1) ?x1792)) true)))
(let (($x506 (or $x720 $x720 (or $x650))))
(and (not $x506) (or $x261 (and (distinct ?x1792 ?x556) true)))))))))))))
(check-sat)
; query 179: function gsm_add, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x373 (ite (bvsgt (_ bv18446744073709518848 64) (bvadd ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in0_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x555 (ite (bvsgt (_ bv18446744073709518848 64) (bvadd ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x1666 ((_ sign_extend 48) in0_16)))
(let ((?x902 ((_ sign_extend 1) ?x1666)))
(let ((?x1645 ((_ sign_extend 48) in1_16)))
(let ((?x294 ((_ sign_extend 1) ?x1645)))
(let (($x720 (or false false)))
(let (($x261 (or $x720 $x720 (or (and (distinct (bvadd ?x294 ?x902) ((_ sign_extend 1) (bvadd ?x1645 ?x1666))) true)))))
(let (($x506 (or $x720 $x720 (or (and (distinct (bvadd ?x902 ?x294) ((_ sign_extend 1) (bvadd ?x1666 ?x1645))) true)))))
(and (not (or $x506 false false)) (or (or $x261 false false) (and (distinct ?x555 ?x373) true)))))))))))))
(check-sat)
; query 180: function gsm_asl, block 13, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1370 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x1480 (or false false false)))
(let (($x197 (not $x1480)))
(and $x197 (or $x1480 (and (distinct ?x1370 ?x1370) true)))))))
(check-sat)
; query 181: function gsm_asl, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 182: function gsm_asl, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x69 ((_ sign_extend 16) in0_16)))
(let ((?x1972 (bvshl ?x69 in1_32)))
(let (($x1819 (bvuge in1_32 (_ bv32 32))))
(let (($x720 (or false false)))
(let (($x1630 (or (or $x720 false (or (and (distinct (bvashr ?x1972 in1_32) ?x69) true))) $x1819)))
(let (($x73 (or $x720 false false)))
(let (($x676 (or $x73 $x1819)))
(let (($x1783 (not $x676)))
(and $x1783 (or $x1630 (and (distinct ?x1972 ?x1972) true))))))))))))
(check-sat)
; query 183: function gsm_asl, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x69 ((_ sign_extend 16) in0_16)))
(let ((?x1972 (bvshl ?x69 in1_32)))
(let ((?x1141 ((_ extract 15 0) ?x1972)))
(let (($x1819 (bvuge in1_32 (_ bv32 32))))
(let (($x720 (or false false)))
(let (($x1630 (or (or $x720 false (or (and (distinct (bvashr ?x1972 in1_32) ?x69) true))) $x1819)))
(let (($x1826 (not (or (or (or $x720 false false) $x1819) false))))
(and $x1826 (or (or $x1630 false) (and (distinct ?x1141 ?x1141) true)))))))))))
(check-sat)
; query 184: function gsm_asl, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1833 (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x1480 (or false false false)))
(let (($x197 (not $x1480)))
(and $x197 (or $x1480 (and (distinct ?x1833 ?x1833) true)))))))
(check-sat)
; query 185: function gsm_asl, block 7, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1011 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1870 ((_ zero_extend 31) ?x1011)))
(let (($x720 (or false false)))
(let (($x73 (or $x720 false false)))
(let (($x1883 (or $x73 false)))
(and (not $x1883) (or $x1883 (and (distinct ?x1870 ?x1870) true)))))))))
(check-sat)
; query 186: function gsm_asl, block 7, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1011 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1870 ((_ zero_extend 31) ?x1011)))
(let ((?x1932 (bvsub (_ bv0 32) ?x1870)))
(let (($x1910 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1870)) ((_ sign_extend 1) ?x1932)) true)))
(let (($x720 (or false false)))
(let (($x73 (or $x720 false false)))
(let (($x1883 (or $x73 false)))
(let (($x1946 (or false $x1883 (or $x1910))))
(and (not $x1946) (or $x1946 (and (distinct ?x1932 ?x1932) true))))))))))))
(check-sat)
; query 187: function gsm_asl, block 7, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1011 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1870 ((_ zero_extend 31) ?x1011)))
(let ((?x1932 (bvsub (_ bv0 32) ?x1870)))
(let ((?x1963 ((_ extract 15 0) ?x1932)))
(let (($x1910 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1870)) ((_ sign_extend 1) ?x1932)) true)))
(let (($x720 (or false false)))
(let (($x73 (or $x720 false false)))
(let (($x1883 (or $x73 false)))
(let (($x1946 (or false $x1883 (or $x1910))))
(let (($x565 (or (or $x1946 (or (and (distinct ((_ sign_extend 16) ?x1963) ?x1932) true))) (and (distinct ?x1963 ?x1963) true))))
(and (not (or $x1946 false)) $x565))))))))))))
(check-sat)
; query 188: function gsm_asl, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 189: function gsm_asl, block 7, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1011 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x720 (or false false)))
(let (($x73 (or $x720 false false)))
(let (($x243 (not $x73)))
(and $x243 (or $x73 (and (distinct ?x1011 ?x1011) true))))))))
(check-sat)
; query 190: function gsm_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1748 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x1480 (or false false false)))
(let (($x197 (not $x1480)))
(and $x197 (or $x1480 (and (distinct ?x1748 ?x1748) true)))))))
(check-sat)
; query 191: function gsm_asr, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1833 (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x1480 (or false false false)))
(let (($x197 (not $x1480)))
(and $x197 (or $x1480 (and (distinct ?x1833 ?x1833) true)))))))
(check-sat)
; query 192: function gsm_asr, block 13, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1370 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x1480 (or false false false)))
(let (($x197 (not $x1480)))
(and $x197 (or $x1480 (and (distinct ?x1370 ?x1370) true)))))))
(check-sat)
; query 193: function gsm_asr, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 194: function gsm_asr, block 15, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x362 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in1_32))) true)))
(let (($x290 (or false false (or $x362))))
(and (not $x290) (or $x290 (and (distinct (bvsub (_ bv0 32) in1_32) (bvsub (_ bv0 32) in1_32)) true))))))
(check-sat)
; query 195: function gsm_asr, block 15, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x207 (bvsub (_ bv0 32) in1_32)))
(let ((?x69 ((_ sign_extend 16) in0_16)))
(let ((?x189 (bvshl ?x69 ?x207)))
(let (($x857 (bvuge ?x207 (_ bv32 32))))
(let (($x362 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x207)) true)))
(let (($x290 (or false false (or $x362))))
(let (($x720 (or false false)))
(let (($x948 (or (or $x720 $x290 (or (and (distinct (bvashr ?x189 ?x207) ?x69) true))) $x857)))
(and (not (or (or $x720 $x290 false) $x857)) (or $x948 (and (distinct ?x189 ?x189) true))))))))))))
(check-sat)
; query 196: function gsm_asr, block 15, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x207 (bvsub (_ bv0 32) in1_32)))
(let ((?x69 ((_ sign_extend 16) in0_16)))
(let ((?x189 (bvshl ?x69 ?x207)))
(let ((?x890 ((_ extract 15 0) ?x189)))
(let (($x857 (bvuge ?x207 (_ bv32 32))))
(let (($x362 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x207)) true)))
(let (($x290 (or false false (or $x362))))
(let (($x720 (or false false)))
(let (($x948 (or (or $x720 $x290 (or (and (distinct (bvashr ?x189 ?x207) ?x69) true))) $x857)))
(and (not (or (or (or $x720 $x290 false) $x857) false)) (or (or $x948 false) (and (distinct ?x890 ?x890) true)))))))))))))
(check-sat)
; query 197: function gsm_asr, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 198: function gsm_asr, block 20, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x69 ((_ sign_extend 16) in0_16)))
(let ((?x895 (bvashr ?x69 in1_32)))
(let (($x1819 (bvuge in1_32 (_ bv32 32))))
(let (($x720 (or false false)))
(let (($x73 (or $x720 false false)))
(let (($x676 (or $x73 $x1819)))
(let (($x1783 (not $x676)))
(and $x1783 (or $x676 (and (distinct ?x895 ?x895) true)))))))))))
(check-sat)
; query 199: function gsm_asr, block 20, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x69 ((_ sign_extend 16) in0_16)))
(let ((?x895 (bvashr ?x69 in1_32)))
(let ((?x877 ((_ extract 15 0) ?x895)))
(let (($x1819 (bvuge in1_32 (_ bv32 32))))
(let (($x720 (or false false)))
(let (($x73 (or $x720 false false)))
(let (($x676 (or $x73 $x1819)))
(let (($x1114 (or (or $x676 (or (and (distinct ((_ sign_extend 16) ?x877) ?x895) true))) (and (distinct ?x877 ?x877) true))))
(let (($x1826 (not (or $x676 false))))
(and $x1826 $x1114)))))))))))
(check-sat)
; query 200: function gsm_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 201: function gsm_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1011 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x720 (or false false)))
(let (($x73 (or $x720 false false)))
(let (($x243 (not $x73)))
(and $x243 (or $x73 (and (distinct ?x1011 ?x1011) true))))))))
(check-sat)
; query 202: function gsm_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1011 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1870 ((_ zero_extend 31) ?x1011)))
(let (($x720 (or false false)))
(let (($x73 (or $x720 false false)))
(let (($x1883 (or $x73 false)))
(and (not $x1883) (or $x1883 (and (distinct ?x1870 ?x1870) true)))))))))
(check-sat)
; query 203: function gsm_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1011 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1870 ((_ zero_extend 31) ?x1011)))
(let ((?x1932 (bvsub (_ bv0 32) ?x1870)))
(let (($x1910 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1870)) ((_ sign_extend 1) ?x1932)) true)))
(let (($x720 (or false false)))
(let (($x73 (or $x720 false false)))
(let (($x1883 (or $x73 false)))
(let (($x1946 (or false $x1883 (or $x1910))))
(and (not $x1946) (or $x1946 (and (distinct ?x1932 ?x1932) true))))))))))))
(check-sat)
; query 204: function gsm_asr, block 4, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1011 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1870 ((_ zero_extend 31) ?x1011)))
(let ((?x1932 (bvsub (_ bv0 32) ?x1870)))
(let ((?x1963 ((_ extract 15 0) ?x1932)))
(let (($x1910 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1870)) ((_ sign_extend 1) ?x1932)) true)))
(let (($x720 (or false false)))
(let (($x73 (or $x720 false false)))
(let (($x1883 (or $x73 false)))
(let (($x1946 (or false $x1883 (or $x1910))))
(let (($x565 (or (or $x1946 (or (and (distinct ((_ sign_extend 16) ?x1963) ?x1932) true))) (and (distinct ?x1963 ?x1963) true))))
(and (not (or $x1946 false)) $x565))))))))))))
(check-sat)
; query 205: function gsm_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1748 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x1480 (or false false false)))
(let (($x197 (not $x1480)))
(and $x197 (or $x1480 (and (distinct ?x1748 ?x1748) true)))))))
(check-sat)
; query 206: function gsm_debug_longwords, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in15_32 () (_ BitVec 32))
(assert
 (let ((?x740 (ite (bvslt in15_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x1480 (or false false false)))
(let (($x197 (not $x1480)))
(and $x197 (or $x1480 (and (distinct ?x740 ?x740) true)))))))
(check-sat)
; query 207: function gsm_debug_words, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in16_32 () (_ BitVec 32))
(assert
 (let ((?x1433 (ite (bvslt in16_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x1480 (or false false false)))
(let (($x197 (not $x1480)))
(and $x197 (or $x1480 (and (distinct ?x1433 ?x1433) true)))))))
(check-sat)
; query 208: function gsm_div, block 7, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x516 (ite (bvsge ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x720 (or false false)))
(let (($x336 (or $x720 $x720 false)))
(and (not $x336) (or $x336 (and (distinct ?x516 ?x516) true)))))))
(check-sat)
; query 209: function gsm_div, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 210: function gsm_div, block 7, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 211: function gsm_div, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 212: function gsm_div, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 213: function gsm_div, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 214: function gsm_div, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1196 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1820 (and (distinct ?x1196 ?x1196) true)))
(let (($x720 (or false false)))
(let (($x73 (or $x720 false false)))
(let (($x243 (not $x73)))
(and $x243 (or $x73 $x1820))))))))
(check-sat)
; query 215: function gsm_mult, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 216: function gsm_mult, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x652 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x720 (or false false)))
(let (($x73 (or $x720 false false)))
(let (($x243 (not $x73)))
(and $x243 (or $x73 (and (distinct ?x652 ?x652) true))))))))
(check-sat)
; query 217: function gsm_mult, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 218: function gsm_mult, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 219: function gsm_mult, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1666 ((_ sign_extend 48) in0_16)))
(let ((?x1645 ((_ sign_extend 48) in1_16)))
(let ((?x920 (bvmul ?x1645 ?x1666)))
(let ((?x849 (bvmul ?x1666 ?x1645)))
(let (($x716 (and (distinct (bvmul ((_ sign_extend 64) ?x1645) ((_ sign_extend 64) ?x1666)) ((_ sign_extend 64) ?x920)) true)))
(let (($x720 (or false false)))
(let (($x1750 (or $x720 $x720 (or $x716))))
(let (($x1095 (and (distinct (bvmul ((_ sign_extend 64) ?x1666) ((_ sign_extend 64) ?x1645)) ((_ sign_extend 64) ?x849)) true)))
(let (($x216 (or $x720 $x720 (or $x1095))))
(and (not $x216) (or $x1750 (and (distinct ?x849 ?x920) true)))))))))))))
(check-sat)
; query 220: function gsm_mult, block 9, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1666 ((_ sign_extend 48) in0_16)))
(let ((?x1645 ((_ sign_extend 48) in1_16)))
(let ((?x920 (bvmul ?x1645 ?x1666)))
(let ((?x1603 (bvashr ?x920 (_ bv15 64))))
(let ((?x849 (bvmul ?x1666 ?x1645)))
(let ((?x752 (bvashr ?x849 (_ bv15 64))))
(let (($x911 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x716 (and (distinct (bvmul ((_ sign_extend 64) ?x1645) ((_ sign_extend 64) ?x1666)) ((_ sign_extend 64) ?x920)) true)))
(let (($x720 (or false false)))
(let (($x1750 (or $x720 $x720 (or $x716))))
(let (($x1687 (or (or $x1750 false false) $x911)))
(let (($x1095 (and (distinct (bvmul ((_ sign_extend 64) ?x1666) ((_ sign_extend 64) ?x1645)) ((_ sign_extend 64) ?x849)) true)))
(let (($x216 (or $x720 $x720 (or $x1095))))
(let (($x262 (or (or $x216 false false) $x911)))
(and (not $x262) (or $x1687 (and (distinct ?x752 ?x1603) true))))))))))))))))))
(check-sat)
; query 221: function gsm_mult, block 9, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1666 ((_ sign_extend 48) in0_16)))
(let ((?x1645 ((_ sign_extend 48) in1_16)))
(let ((?x920 (bvmul ?x1645 ?x1666)))
(let ((?x1603 (bvashr ?x920 (_ bv15 64))))
(let (($x911 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x716 (and (distinct (bvmul ((_ sign_extend 64) ?x1645) ((_ sign_extend 64) ?x1666)) ((_ sign_extend 64) ?x920)) true)))
(let (($x720 (or false false)))
(let (($x1750 (or $x720 $x720 (or $x716))))
(let (($x1687 (or (or $x1750 false false) $x911)))
(let (($x525 (or (or $x1687 false) (and (distinct ((_ extract 15 0) (bvashr (bvmul ?x1666 ?x1645) (_ bv15 64))) ((_ extract 15 0) ?x1603)) true))))
(let (($x1095 (and (distinct (bvmul ((_ sign_extend 64) ?x1666) ((_ sign_extend 64) ?x1645)) ((_ sign_extend 64) (bvmul ?x1666 ?x1645))) true)))
(let (($x216 (or $x720 $x720 (or $x1095))))
(let (($x262 (or (or $x216 false false) $x911)))
(and (not (or $x262 false)) $x525)))))))))))))))
(check-sat)
; query 222: function gsm_mult, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 223: function gsm_mult, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x177 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x720 (or false false)))
(let (($x73 (or $x720 false false)))
(let (($x243 (not $x73)))
(and $x243 (or $x73 (and (distinct ?x177 ?x177) true))))))))
(check-sat)
; query 224: function gsm_mult_r, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 225: function gsm_mult_r, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x177 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x720 (or false false)))
(let (($x73 (or $x720 false false)))
(let (($x243 (not $x73)))
(and $x243 (or $x73 (and (distinct ?x177 ?x177) true))))))))
(check-sat)
; query 226: function gsm_mult_r, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 227: function gsm_mult_r, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 228: function gsm_mult_r, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1666 ((_ sign_extend 48) in0_16)))
(let ((?x1645 ((_ sign_extend 48) in1_16)))
(let ((?x920 (bvmul ?x1645 ?x1666)))
(let ((?x849 (bvmul ?x1666 ?x1645)))
(let (($x716 (and (distinct (bvmul ((_ sign_extend 64) ?x1645) ((_ sign_extend 64) ?x1666)) ((_ sign_extend 64) ?x920)) true)))
(let (($x720 (or false false)))
(let (($x1750 (or $x720 $x720 (or $x716))))
(let (($x1095 (and (distinct (bvmul ((_ sign_extend 64) ?x1666) ((_ sign_extend 64) ?x1645)) ((_ sign_extend 64) ?x849)) true)))
(let (($x216 (or $x720 $x720 (or $x1095))))
(and (not $x216) (or $x1750 (and (distinct ?x849 ?x920) true)))))))))))))
(check-sat)
; query 229: function gsm_mult_r, block 9, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1666 ((_ sign_extend 48) in0_16)))
(let ((?x1645 ((_ sign_extend 48) in1_16)))
(let ((?x920 (bvmul ?x1645 ?x1666)))
(let ((?x546 (bvadd ?x920 (_ bv16384 64))))
(let ((?x849 (bvmul ?x1666 ?x1645)))
(let ((?x835 (bvadd ?x849 (_ bv16384 64))))
(let (($x339 (and (distinct (bvadd ((_ sign_extend 1) ?x920) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x546)) true)))
(let (($x716 (and (distinct (bvmul ((_ sign_extend 64) ?x1645) ((_ sign_extend 64) ?x1666)) ((_ sign_extend 64) ?x920)) true)))
(let (($x720 (or false false)))
(let (($x1750 (or $x720 $x720 (or $x716))))
(let (($x712 (or $x1750 false (or $x339))))
(let (($x540 (and (distinct (bvadd ((_ sign_extend 1) ?x849) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x835)) true)))
(let (($x1095 (and (distinct (bvmul ((_ sign_extend 64) ?x1666) ((_ sign_extend 64) ?x1645)) ((_ sign_extend 64) ?x849)) true)))
(let (($x216 (or $x720 $x720 (or $x1095))))
(let (($x933 (or $x216 false (or $x540))))
(and (not $x933) (or $x712 (and (distinct ?x835 ?x546) true)))))))))))))))))))
(check-sat)
; query 230: function gsm_mult_r, block 9, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1666 ((_ sign_extend 48) in0_16)))
(let ((?x1645 ((_ sign_extend 48) in1_16)))
(let ((?x920 (bvmul ?x1645 ?x1666)))
(let ((?x546 (bvadd ?x920 (_ bv16384 64))))
(let ((?x758 (bvashr ?x546 (_ bv15 64))))
(let ((?x849 (bvmul ?x1666 ?x1645)))
(let ((?x835 (bvadd ?x849 (_ bv16384 64))))
(let ((?x979 (bvashr ?x835 (_ bv15 64))))
(let (($x911 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x339 (and (distinct (bvadd ((_ sign_extend 1) ?x920) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x546)) true)))
(let (($x716 (and (distinct (bvmul ((_ sign_extend 64) ?x1645) ((_ sign_extend 64) ?x1666)) ((_ sign_extend 64) ?x920)) true)))
(let (($x720 (or false false)))
(let (($x1750 (or $x720 $x720 (or $x716))))
(let (($x712 (or $x1750 false (or $x339))))
(let (($x689 (or (or $x712 false false) $x911)))
(let (($x540 (and (distinct (bvadd ((_ sign_extend 1) ?x849) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x835)) true)))
(let (($x1095 (and (distinct (bvmul ((_ sign_extend 64) ?x1666) ((_ sign_extend 64) ?x1645)) ((_ sign_extend 64) ?x849)) true)))
(let (($x216 (or $x720 $x720 (or $x1095))))
(let (($x933 (or $x216 false (or $x540))))
(let (($x785 (or (or $x933 false false) $x911)))
(and (not $x785) (or $x689 (and (distinct ?x979 ?x758) true))))))))))))))))))))))))
(check-sat)
; query 231: function gsm_mult_r, block 9, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1666 ((_ sign_extend 48) in0_16)))
(let ((?x1645 ((_ sign_extend 48) in1_16)))
(let ((?x920 (bvmul ?x1645 ?x1666)))
(let ((?x546 (bvadd ?x920 (_ bv16384 64))))
(let ((?x758 (bvashr ?x546 (_ bv15 64))))
(let ((?x509 (bvand ?x758 (_ bv65535 64))))
(let ((?x849 (bvmul ?x1666 ?x1645)))
(let ((?x835 (bvadd ?x849 (_ bv16384 64))))
(let ((?x979 (bvashr ?x835 (_ bv15 64))))
(let ((?x422 (bvand ?x979 (_ bv65535 64))))
(let (($x911 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x339 (and (distinct (bvadd ((_ sign_extend 1) ?x920) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x546)) true)))
(let (($x716 (and (distinct (bvmul ((_ sign_extend 64) ?x1645) ((_ sign_extend 64) ?x1666)) ((_ sign_extend 64) ?x920)) true)))
(let (($x720 (or false false)))
(let (($x1750 (or $x720 $x720 (or $x716))))
(let (($x712 (or $x1750 false (or $x339))))
(let (($x689 (or (or $x712 false false) $x911)))
(let (($x289 (or $x689 false false)))
(let (($x540 (and (distinct (bvadd ((_ sign_extend 1) ?x849) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x835)) true)))
(let (($x1095 (and (distinct (bvmul ((_ sign_extend 64) ?x1666) ((_ sign_extend 64) ?x1645)) ((_ sign_extend 64) ?x849)) true)))
(let (($x216 (or $x720 $x720 (or $x1095))))
(let (($x933 (or $x216 false (or $x540))))
(let (($x785 (or (or $x933 false false) $x911)))
(let (($x881 (or $x785 false false)))
(and (not $x881) (or $x289 (and (distinct ?x422 ?x509) true))))))))))))))))))))))))))))
(check-sat)
; query 232: function gsm_mult_r, block 9, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1666 ((_ sign_extend 48) in0_16)))
(let ((?x1645 ((_ sign_extend 48) in1_16)))
(let ((?x920 (bvmul ?x1645 ?x1666)))
(let ((?x546 (bvadd ?x920 (_ bv16384 64))))
(let ((?x758 (bvashr ?x546 (_ bv15 64))))
(let ((?x509 (bvand ?x758 (_ bv65535 64))))
(let ((?x468 ((_ extract 15 0) ?x509)))
(let (($x831 (and (distinct ((_ extract 15 0) (bvand (bvashr (bvadd (bvmul ?x1666 ?x1645) (_ bv16384 64)) (_ bv15 64)) (_ bv65535 64))) ?x468) true)))
(let (($x911 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x339 (and (distinct (bvadd ((_ sign_extend 1) ?x920) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x546)) true)))
(let (($x716 (and (distinct (bvmul ((_ sign_extend 64) ?x1645) ((_ sign_extend 64) ?x1666)) ((_ sign_extend 64) ?x920)) true)))
(let (($x720 (or false false)))
(let (($x1750 (or $x720 $x720 (or $x716))))
(let (($x712 (or $x1750 false (or $x339))))
(let (($x689 (or (or $x712 false false) $x911)))
(let (($x289 (or $x689 false false)))
(let (($x540 (and (distinct (bvadd ((_ sign_extend 1) (bvmul ?x1666 ?x1645)) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) (bvadd (bvmul ?x1666 ?x1645) (_ bv16384 64)))) true)))
(let (($x1095 (and (distinct (bvmul ((_ sign_extend 64) ?x1666) ((_ sign_extend 64) ?x1645)) ((_ sign_extend 64) (bvmul ?x1666 ?x1645))) true)))
(let (($x216 (or $x720 $x720 (or $x1095))))
(let (($x933 (or $x216 false (or $x540))))
(let (($x785 (or (or $x933 false false) $x911)))
(let (($x881 (or $x785 false false)))
(and (not (or $x881 false)) (or (or $x289 (or (and (distinct ((_ zero_extend 48) ?x468) ?x509) true))) $x831)))))))))))))))))))))))))
(check-sat)
; query 233: function gsm_mult_r, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 234: function gsm_mult_r, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x652 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x720 (or false false)))
(let (($x73 (or $x720 false false)))
(let (($x243 (not $x73)))
(and $x243 (or $x73 (and (distinct ?x652 ?x652) true))))))))
(check-sat)
; query 235: function gsm_norm, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x845 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x1480 (or false false false)))
(let (($x197 (not $x1480)))
(and $x197 (or $x1480 (and (distinct ?x845 ?x845) true)))))))
(check-sat)
; query 236: function gsm_norm, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x845 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x894 (bvxor ?x845 (_ bv1 1))))
(let (($x1480 (or false false false)))
(let (($x1405 (or $x1480 false false)))
(let (($x1470 (not $x1405)))
(and $x1470 (or $x1405 (and (distinct ?x894 ?x894) true)))))))))
(check-sat)
; query 237: function gsm_norm, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x845 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x894 (bvxor ?x845 (_ bv1 1))))
(let ((?x643 ((_ zero_extend 31) ?x894)))
(let (($x1480 (or false false false)))
(let (($x1405 (or $x1480 false false)))
(let (($x138 (or $x1405 false)))
(and (not $x138) (or $x138 (and (distinct ?x643 ?x643) true))))))))))
(check-sat)
; query 238: function gsm_norm, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x845 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x894 (bvxor ?x845 (_ bv1 1))))
(let ((?x643 ((_ zero_extend 31) ?x894)))
(let ((?x526 ((_ zero_extend 32) ?x643)))
(let ((?x201 ((_ sign_extend 32) ?x643)))
(let (($x1480 (or false false false)))
(let (($x1405 (or $x1480 false false)))
(let (($x138 (or $x1405 false)))
(let (($x335 (or $x138 (or (= ((_ extract 31 31) ?x643) (_ bv1 1))))))
(and (not (or $x138 false)) (or $x335 (and (distinct ?x201 ?x526) true)))))))))))))
(check-sat)
; query 239: function gsm_norm, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x845 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x894 (bvxor ?x845 (_ bv1 1))))
(let ((?x643 ((_ zero_extend 31) ?x894)))
(let ((?x526 ((_ zero_extend 32) ?x643)))
(let (($x206 (and (distinct (ite (and (distinct (_ bv0 64) ((_ sign_extend 32) ?x643)) true) (_ bv1 1) (_ bv0 1)) (ite (and (distinct (_ bv0 64) ?x526) true) (_ bv1 1) (_ bv0 1))) true)))
(let (($x1480 (or false false false)))
(let (($x1405 (or $x1480 false false)))
(let (($x138 (or $x1405 false)))
(let (($x335 (or $x138 (or (= ((_ extract 31 31) ?x643) (_ bv1 1))))))
(and (not (or (or $x138 false) false false)) (or (or $x335 false false) $x206))))))))))))
(check-sat)
; query 240: function gsm_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_64 () (_ BitVec 64))
(assert
 (let ((?x244 (ite (bvslt (_ bv32767 64) in5_64) (_ bv1 1) (_ bv0 1))))
(let (($x1480 (or false false false)))
(let (($x197 (not $x1480)))
(and $x197 (or $x1480 (and (distinct ?x244 ?x244) true)))))))
(check-sat)
; query 241: function gsm_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 242: function gsm_sub, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x720 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 243: function gsm_sub, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1645 ((_ sign_extend 48) in1_16)))
(let ((?x1666 ((_ sign_extend 48) in0_16)))
(let ((?x892 (bvsub ?x1666 ?x1645)))
(let (($x748 (and (distinct (bvsub ((_ sign_extend 1) ?x1666) ((_ sign_extend 1) ?x1645)) ((_ sign_extend 1) ?x892)) true)))
(let (($x720 (or false false)))
(let (($x901 (or $x720 $x720 (or $x748))))
(and (not $x901) (or $x901 (and (distinct ?x892 ?x892) true))))))))))
(check-sat)
; query 244: function gsm_sub, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x561 (ite (bvsgt (_ bv18446744073709518848 64) (bvsub ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x1645 ((_ sign_extend 48) in1_16)))
(let ((?x294 ((_ sign_extend 1) ?x1645)))
(let ((?x1666 ((_ sign_extend 48) in0_16)))
(let ((?x902 ((_ sign_extend 1) ?x1666)))
(let (($x720 (or false false)))
(let (($x901 (or $x720 $x720 (or (and (distinct (bvsub ?x902 ?x294) ((_ sign_extend 1) (bvsub ?x1666 ?x1645))) true)))))
(let (($x788 (or $x901 false false)))
(and (not $x788) (or $x788 (and (distinct ?x561 ?x561) true))))))))))))
(check-sat)
; query 245: function ok_to_replace, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x665 (ite (and (distinct (_ bv4294967295 32) in.01_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x1480 (or false false false)))
(let (($x197 (not $x1480)))
(and $x197 (or $x1480 (and (distinct ?x665 ?x665) true)))))))
(check-sat)
; query 246: function ok_to_replace, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in16_32 () (_ BitVec 32))
(assert
 (let ((?x239 (ite (= (_ bv121 32) in16_32) (_ bv1 1) (_ bv0 1))))
(let (($x1480 (or false false false)))
(let (($x197 (not $x1480)))
(and $x197 (or $x1480 (and (distinct ?x239 ?x239) true)))))))
(check-sat)
; query 247: function process_decode, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let (($x667 (or false (or (= ((_ extract 31 31) in14_32) (_ bv1 1))))))
(let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x667 (and (distinct ((_ sign_extend 32) in14_32) ((_ zero_extend 32) in14_32)) true)))))))
(check-sat)
; query 248: function process_decode, block 16, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let (($x694 (and (distinct (ite (and (distinct (_ bv33 64) ((_ sign_extend 32) in14_32)) true) (_ bv1 1) (_ bv0 1)) (ite (and (distinct (_ bv33 64) ((_ zero_extend 32) in14_32)) true) (_ bv1 1) (_ bv0 1))) true)))
(let (($x757 (or (or (or false (or (= ((_ extract 31 31) in14_32) (_ bv1 1)))) false false) $x694)))
(let (($x720 (or false false)))
(let (($x73 (or $x720 false false)))
(let (($x243 (not $x73)))
(and $x243 $x757)))))))
(check-sat)
; query 249: function process_encode, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_32 () (_ BitVec 32))
(assert
 (let (($x248 (or false (or (= ((_ extract 31 31) in13_32) (_ bv1 1))))))
(let (($x720 (or false false)))
(let (($x161 (not $x720)))
(and $x161 (or $x248 (and (distinct ((_ sign_extend 32) in13_32) ((_ zero_extend 32) in13_32)) true)))))))
(check-sat)
; query 250: function process_encode, block 15, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_32 () (_ BitVec 32))
(assert
 (let (($x570 (and (distinct (ite (bvult ((_ sign_extend 32) in13_32) (_ bv160 64)) (_ bv1 1) (_ bv0 1)) (ite (bvult ((_ zero_extend 32) in13_32) (_ bv160 64)) (_ bv1 1) (_ bv0 1))) true)))
(let (($x600 (or (or (or false (or (= ((_ extract 31 31) in13_32) (_ bv1 1)))) false false) $x570)))
(let (($x720 (or false false)))
(let (($x73 (or $x720 false false)))
(let (($x243 (not $x73)))
(and $x243 $x600)))))))
(check-sat)
; query 251: function process_encode, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_32 () (_ BitVec 32))
(assert
 (let ((?x1512 (ite (bvsgt (_ bv0 32) in13_32) (_ bv1 1) (_ bv0 1))))
(let (($x1480 (or false false false)))
(let (($x197 (not $x1480)))
(and $x197 (or $x1480 (and (distinct ?x1512 ?x1512) true)))))))
(check-sat)
; query 252: function suffix, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_64 () (_ BitVec 64))
(declare-fun in3_64 () (_ BitVec 64))
(assert
 (let ((?x904 (ite (bvule in3_64 in4_64) (_ bv1 1) (_ bv0 1))))
(let (($x1480 (or false false false)))
(let (($x197 (not $x1480)))
(and $x197 (or $x1480 (and (distinct ?x904 ?x904) true)))))))
(check-sat)
; query 253: function ulaw_input, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x1696 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x766 (or false false (or $x1696))))
(and (not $x766) (or $x766 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 254: function ulaw_input, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let ((?x1532 (ite (= (_ bv4294967295 32) in.1_32) (_ bv1 1) (_ bv0 1))))
(let (($x1480 (or false false false)))
(let (($x197 (not $x1480)))
(and $x197 (or $x1480 (and (distinct ?x1532 ?x1532) true)))))))
(check-sat)
