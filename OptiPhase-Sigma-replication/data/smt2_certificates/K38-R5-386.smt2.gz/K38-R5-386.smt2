; OptiPhase-Sigma refinement certificate for sweep K38-R5-386
; query 0: function BF_cfb64_encrypt, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.07_32 () (_ BitVec 32))
(assert
 (let ((?x44 (ite (= (_ bv0 32) in.07_32) (_ bv1 1) (_ bv0 1))))
(let (($x21 (or false false false)))
(and (not $x21) (or $x21 (and (distinct ?x44 ?x44) true))))))
(check-sat)
