; OptiPhase-Sigma refinement certificate for sweep K28-R3-193
; query 0: function xmalloc, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in7_32 () (_ BitVec 32))
(assert
 (let ((?x103 (ite (and (distinct (_ bv0 32) in7_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x79 (or false false false)))
(and (not $x79) (or $x79 (and (distinct ?x103 ?x103) true))))))
(check-sat)
