; OptiPhase-Sigma refinement certificate for sweep K02-R3-282
