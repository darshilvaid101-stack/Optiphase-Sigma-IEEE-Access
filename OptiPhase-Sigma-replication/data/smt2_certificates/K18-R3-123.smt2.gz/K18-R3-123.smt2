; OptiPhase-Sigma refinement certificate for sweep K18-R3-123
; query 0: function init_array, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_32 () (_ BitVec 32))
(assert
 (let (($x156 (and (distinct (bvadd ((_ sign_extend 1) in.03_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.03_32 (_ bv1 32)))) true)))
(let (($x75 (or false false (or $x156))))
(and (not $x75) (or $x75 (and (distinct (bvadd in.03_32 (_ bv1 32)) (bvadd in.03_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function init_array, block 21, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x34 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x70 (or false false (or $x34))))
(and (not $x70) (or $x70 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function init_array, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.14_32 () (_ BitVec 32))
(assert
 (let (($x83 (and (distinct (bvadd ((_ sign_extend 1) in.14_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.14_32 (_ bv1 32)))) true)))
(let (($x28 (or false false (or $x83))))
(and (not $x28) (or $x28 (and (distinct (bvadd in.14_32 (_ bv1 32)) (bvadd in.14_32 (_ bv1 32))) true))))))
(check-sat)
; query 3: function print_array, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x93 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x98 (or false false (or $x93))))
(and (not $x98) (or $x98 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 4: function print_array, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x61 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x148 (or false false (or $x61))))
(and (not $x148) (or $x148 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
