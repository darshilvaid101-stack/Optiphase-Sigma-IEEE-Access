; OptiPhase-Sigma refinement certificate for sweep K50-R4-322
; query 0: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x58 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x14 (or false false false)))
(and (not $x14) (or $x14 (and (distinct ?x58 ?x58) true))))))
(check-sat)
