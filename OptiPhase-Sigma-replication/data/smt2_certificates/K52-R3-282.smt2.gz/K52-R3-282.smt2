; OptiPhase-Sigma refinement certificate for sweep K52-R3-282
; query 0: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x1832 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x1213 (or false false false)))
(let (($x114 (not $x1213)))
(and $x114 (or $x1213 (and (distinct ?x1832 ?x1832) true)))))))
(check-sat)
; query 1: function set1d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x792 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x1213 (or false false false)))
(let (($x114 (not $x1213)))
(and $x114 (or $x1213 (and (distinct ?x792 ?x792) true)))))))
(check-sat)
; query 2: function set1ds, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x1948 (ite (= (_ bv4294967295 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x1213 (or false false false)))
(let (($x114 (not $x1213)))
(and $x114 (or $x1213 (and (distinct ?x1948 ?x1948) true)))))))
(check-sat)
; query 3: function set2d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x792 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x1213 (or false false false)))
(let (($x114 (not $x1213)))
(and $x114 (or $x1213 (and (distinct ?x792 ?x792) true)))))))
(check-sat)
