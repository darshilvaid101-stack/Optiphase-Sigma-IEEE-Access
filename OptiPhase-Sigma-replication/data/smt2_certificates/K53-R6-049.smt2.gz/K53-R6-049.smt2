; OptiPhase-Sigma refinement certificate for sweep K53-R6-049
; query 0: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x273 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x234 (or false false false)))
(let (($x809 (not $x234)))
(and $x809 (or $x234 (and (distinct ?x273 ?x273) true)))))))
(check-sat)
; query 1: function set1d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x337 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x234 (or false false false)))
(let (($x809 (not $x234)))
(and $x809 (or $x234 (and (distinct ?x337 ?x337) true)))))))
(check-sat)
; query 2: function set1ds, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x16 (ite (= (_ bv4294967295 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x234 (or false false false)))
(let (($x809 (not $x234)))
(and $x809 (or $x234 (and (distinct ?x16 ?x16) true)))))))
(check-sat)
; query 3: function set2d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x337 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x234 (or false false false)))
(let (($x809 (not $x234)))
(and $x809 (or $x234 (and (distinct ?x337 ?x337) true)))))))
(check-sat)
