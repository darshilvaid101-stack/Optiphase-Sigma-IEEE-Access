; OptiPhase-Sigma refinement certificate for sweep K39-R5-411
