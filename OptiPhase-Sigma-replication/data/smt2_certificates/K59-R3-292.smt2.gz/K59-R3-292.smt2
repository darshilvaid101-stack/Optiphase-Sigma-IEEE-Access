; OptiPhase-Sigma refinement certificate for sweep K59-R3-292
; query 0: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x668 (or false false false)))
(let (($x344 (not $x668)))
(and $x344 (or $x668 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x471 (bvadd in.01_32 (_ bv1 32))))
(let ((?x20 (bvmul ?x471 ?x471)))
(let (($x668 (or false false false)))
(let (($x68 (or $x668 $x668 false)))
(and (not $x68) (or $x68 (and (distinct ?x20 ?x20) true))))))))
(check-sat)
; query 2: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x86 (and (distinct (bvmul (bvmul (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) (_ bv2 32)) (bvshl (bvmul (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) (_ bv3 32))) true)))
(let (($x668 (or false false false)))
(let (($x68 (or $x668 $x668 false)))
(let (($x167 (or $x68 false false)))
(and (not $x167) (or (or $x167 (bvuge (_ bv3 32) (_ bv32 32))) $x86)))))))
(check-sat)
; query 3: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x836 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x668 (or false false false)))
(let (($x344 (not $x668)))
(and $x344 (or $x668 (and (distinct ?x836 ?x836) true)))))))
(check-sat)
; query 4: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x668 (or false false false)))
(let (($x344 (not $x668)))
(and $x344 (or $x668 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 5: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x855 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x668 (or false false false)))
(let (($x344 (not $x668)))
(and $x344 (or $x668 (and (distinct ?x855 ?x855) true)))))))
(check-sat)
