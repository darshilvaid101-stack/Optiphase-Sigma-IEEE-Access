; OptiPhase-Sigma refinement certificate for sweep K56-R3-303
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x621 (or false false)))
(let (($x601 (not $x621)))
(and $x601 (or $x621 (and (distinct ((_ sign_extend 16) in25_16) ((_ sign_extend 16) in25_16)) true))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let ((?x700 (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))))
(let (($x621 (or false false)))
(let (($x500 (or $x621 false false)))
(let (($x571 (not $x500)))
(and $x571 (or $x500 (and (distinct ?x700 ?x700) true))))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x621 (or false false)))
(let (($x601 (not $x621)))
(and $x601 (or $x621 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x164 ((_ sign_extend 16) in3_16)))
(let ((?x679 (bvand ?x164 (_ bv127 32))))
(let (($x621 (or false false)))
(let (($x500 (or $x621 false false)))
(let (($x571 (not $x500)))
(and $x571 (or $x500 (and (distinct ?x679 ?x679) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x164 ((_ sign_extend 16) in3_16)))
(let ((?x679 (bvand ?x164 (_ bv127 32))))
(let ((?x295 ((_ extract 15 0) ?x679)))
(let (($x621 (or false false)))
(let (($x500 (or $x621 false false)))
(let (($x159 (or $x500 false)))
(let (($x103 (not $x159)))
(and $x103 (or $x159 (and (distinct ?x295 ?x295) true)))))))))))
(check-sat)
; query 5: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x621 (or false false)))
(let (($x601 (not $x621)))
(and $x601 (or $x621 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 6: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x227 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x621 (or false false)))
(let (($x500 (or $x621 false false)))
(let (($x571 (not $x500)))
(and $x571 (or $x500 (and (distinct ?x227 ?x227) true))))))))
(check-sat)
; query 7: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x545 (or false false false)))
(let (($x131 (not $x545)))
(and $x131 (or $x545 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x228 (bvadd in.01_32 (_ bv1 32))))
(let ((?x233 (bvmul ?x228 ?x228)))
(let (($x545 (or false false false)))
(let (($x61 (or $x545 $x545 false)))
(and (not $x61) (or $x61 (and (distinct ?x233 ?x233) true))))))))
(check-sat)
; query 9: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x228 (bvadd in.01_32 (_ bv1 32))))
(let ((?x233 (bvmul ?x228 ?x228)))
(let ((?x251 (bvmul ?x233 (_ bv2 32))))
(let (($x545 (or false false false)))
(let (($x61 (or $x545 $x545 false)))
(let (($x191 (or $x61 false false)))
(and (not $x191) (or $x191 (and (distinct ?x251 ?x251) true))))))))))
(check-sat)
; query 10: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x228 (bvadd in.01_32 (_ bv1 32))))
(let ((?x233 (bvmul ?x228 ?x228)))
(let ((?x251 (bvmul ?x233 (_ bv2 32))))
(let ((?x20 (bvmul ?x251 (_ bv4 32))))
(let (($x545 (or false false false)))
(let (($x61 (or $x545 $x545 false)))
(let (($x191 (or $x61 false false)))
(let (($x16 (or $x191 false false)))
(and (not $x16) (or $x16 (and (distinct ?x20 ?x20) true))))))))))))
(check-sat)
; query 11: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x132 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x545 (or false false false)))
(let (($x131 (not $x545)))
(and $x131 (or $x545 (and (distinct ?x132 ?x132) true)))))))
(check-sat)
; query 12: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x14 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x545 (or false false false)))
(let (($x131 (not $x545)))
(and $x131 (or $x545 (and (distinct ?x14 ?x14) true)))))))
(check-sat)
; query 13: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x545 (or false false false)))
(let (($x131 (not $x545)))
(and $x131 (or $x545 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 14: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x35 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x64 (or false false (or $x35))))
(and (not $x64) (or $x64 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 15: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x106 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x545 (or false false false)))
(let (($x131 (not $x545)))
(and $x131 (or $x545 (and (distinct ?x106 ?x106) true)))))))
(check-sat)
; query 16: function crcu8, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x621 (or false false)))
(let (($x601 (not $x621)))
(and $x601 (or $x621 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 17: function crcu8, block 19, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x846 ((_ zero_extend 16) in.01_16)))
(let ((?x734 (bvxor ?x846 (_ bv16386 32))))
(let (($x621 (or false false)))
(let (($x500 (or $x621 false false)))
(let (($x571 (not $x500)))
(and $x571 (or $x500 (and (distinct ?x734 ?x734) true)))))))))
(check-sat)
; query 18: function crcu8, block 19, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x846 ((_ zero_extend 16) in.01_16)))
(let ((?x734 (bvxor ?x846 (_ bv16386 32))))
(let ((?x872 ((_ extract 15 0) ?x734)))
(let (($x621 (or false false)))
(let (($x500 (or $x621 false false)))
(let (($x159 (or $x500 false)))
(let (($x103 (not $x159)))
(and $x103 (or $x159 (and (distinct ?x872 ?x872) true)))))))))))
(check-sat)
; query 19: function crcu8, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x85 ((_ extract 7 0) in.01_16)))
(let ((?x226 ((_ zero_extend 24) ?x85)))
(let (($x621 (or false false)))
(let (($x896 (or $x621 false)))
(and (not $x896) (or $x896 (and (distinct ?x226 ?x226) true))))))))
(check-sat)
; query 20: function crcu8, block 6, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x85 ((_ extract 7 0) in.01_16)))
(let ((?x226 ((_ zero_extend 24) ?x85)))
(let ((?x133 (bvand ?x226 (_ bv1 32))))
(let (($x621 (or false false)))
(let (($x896 (or $x621 false)))
(let (($x165 (or $x896 false false)))
(and (not $x165) (or $x165 (and (distinct ?x133 ?x133) true))))))))))
(check-sat)
; query 21: function crcu8, block 6, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x85 ((_ extract 7 0) in.01_16)))
(let ((?x226 ((_ zero_extend 24) ?x85)))
(let ((?x133 (bvand ?x226 (_ bv1 32))))
(let ((?x650 ((_ zero_extend 24) in.0_8)))
(let ((?x68 (bvand ?x650 (_ bv1 32))))
(let ((?x614 (bvxor ?x68 ?x133)))
(let (($x621 (or false false)))
(let (($x896 (or $x621 false)))
(let (($x165 (or $x896 false false)))
(let (($x500 (or $x621 false false)))
(let (($x548 (or $x500 $x165 false)))
(and (not $x548) (or $x548 (and (distinct ?x614 ?x614) true)))))))))))))))
(check-sat)
; query 22: function crcu8, block 6, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x85 ((_ extract 7 0) in.01_16)))
(let ((?x226 ((_ zero_extend 24) ?x85)))
(let ((?x133 (bvand ?x226 (_ bv1 32))))
(let ((?x650 ((_ zero_extend 24) in.0_8)))
(let ((?x68 (bvand ?x650 (_ bv1 32))))
(let ((?x614 (bvxor ?x68 ?x133)))
(let ((?x230 ((_ extract 7 0) ?x614)))
(let (($x621 (or false false)))
(let (($x896 (or $x621 false)))
(let (($x165 (or $x896 false false)))
(let (($x500 (or $x621 false false)))
(let (($x548 (or $x500 $x165 false)))
(let (($x213 (or $x548 false)))
(and (not $x213) (or $x213 (and (distinct ?x230 ?x230) true)))))))))))))))))
(check-sat)
; query 23: function crcu8, block 6, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x621 (or false false)))
(let (($x601 (not $x621)))
(and $x601 (or $x621 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 24: function crcu8, block 6, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x650 ((_ zero_extend 24) in.0_8)))
(let ((?x166 (bvashr ?x650 (_ bv1 32))))
(let (($x621 (or false false)))
(let (($x500 (or $x621 false false)))
(let (($x91 (or $x500 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not $x91) (or $x91 (and (distinct ?x166 ?x166) true)))))))))
(check-sat)
; query 25: function crcu8, block 6, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x650 ((_ zero_extend 24) in.0_8)))
(let ((?x166 (bvashr ?x650 (_ bv1 32))))
(let ((?x15 ((_ extract 7 0) ?x166)))
(let (($x621 (or false false)))
(let (($x500 (or $x621 false false)))
(let (($x91 (or $x500 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x410 (or $x91 false)))
(and (not $x410) (or $x410 (and (distinct ?x15 ?x15) true)))))))))))
(check-sat)
; query 26: function crcu8, block 6, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x85 ((_ extract 7 0) in.01_16)))
(let ((?x226 ((_ zero_extend 24) ?x85)))
(let ((?x133 (bvand ?x226 (_ bv1 32))))
(let ((?x650 ((_ zero_extend 24) in.0_8)))
(let ((?x68 (bvand ?x650 (_ bv1 32))))
(let ((?x614 (bvxor ?x68 ?x133)))
(let ((?x230 ((_ extract 7 0) ?x614)))
(let ((?x149 ((_ zero_extend 24) ?x230)))
(let (($x621 (or false false)))
(let (($x896 (or $x621 false)))
(let (($x165 (or $x896 false false)))
(let (($x500 (or $x621 false false)))
(let (($x548 (or $x500 $x165 false)))
(let (($x213 (or $x548 false)))
(let (($x79 (or $x213 false)))
(and (not $x79) (or $x79 (and (distinct ?x149 ?x149) true)))))))))))))))))))
(check-sat)
; query 27: function crcu8, block 6, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x85 ((_ extract 7 0) in.01_16)))
(let ((?x226 ((_ zero_extend 24) ?x85)))
(let ((?x133 (bvand ?x226 (_ bv1 32))))
(let ((?x650 ((_ zero_extend 24) in.0_8)))
(let ((?x68 (bvand ?x650 (_ bv1 32))))
(let ((?x614 (bvxor ?x68 ?x133)))
(let ((?x230 ((_ extract 7 0) ?x614)))
(let ((?x149 ((_ zero_extend 24) ?x230)))
(let ((?x54 (ite (= (_ bv1 32) ?x149) (_ bv1 1) (_ bv0 1))))
(let (($x621 (or false false)))
(let (($x896 (or $x621 false)))
(let (($x165 (or $x896 false false)))
(let (($x500 (or $x621 false false)))
(let (($x548 (or $x500 $x165 false)))
(let (($x213 (or $x548 false)))
(let (($x79 (or $x213 false)))
(let (($x34 (or $x79 false false)))
(and (not $x34) (or $x34 (and (distinct ?x54 ?x54) true)))))))))))))))))))))
(check-sat)
; query 28: function crcu8, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x621 (or false false)))
(let (($x601 (not $x621)))
(and $x601 (or $x621 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 29: function crcu8, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x650 ((_ zero_extend 24) in.0_8)))
(let ((?x68 (bvand ?x650 (_ bv1 32))))
(let (($x621 (or false false)))
(let (($x500 (or $x621 false false)))
(let (($x571 (not $x500)))
(and $x571 (or $x500 (and (distinct ?x68 ?x68) true)))))))))
(check-sat)
; query 30: function crcu8, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x621 (or false false)))
(let (($x601 (not $x621)))
(and $x601 (or $x621 (and (distinct ((_ extract 7 0) in.01_16) ((_ extract 7 0) in.01_16)) true))))))
(check-sat)
; query 31: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1333 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x545 (or false false false)))
(let (($x131 (not $x545)))
(and $x131 (or $x545 (and (distinct ?x1333 ?x1333) true)))))))
(check-sat)
; query 32: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x621 (or false false)))
(let (($x601 (not $x621)))
(and $x601 (or $x621 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 33: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x128 ((_ sign_extend 16) in.1_16)))
(let ((?x104 (bvadd ?x128 (_ bv10 32))))
(let (($x100 (and (distinct (bvadd ((_ sign_extend 1) ?x128) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x104)) true)))
(let (($x621 (or false false)))
(let (($x148 (or $x621 false (or $x100))))
(and (not $x148) (or $x148 (and (distinct ?x104 ?x104) true)))))))))
(check-sat)
; query 34: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x128 ((_ sign_extend 16) in.1_16)))
(let ((?x104 (bvadd ?x128 (_ bv10 32))))
(let ((?x1121 ((_ extract 15 0) ?x104)))
(let (($x100 (and (distinct (bvadd ((_ sign_extend 1) ?x128) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x104)) true)))
(let (($x621 (or false false)))
(let (($x148 (or $x621 false (or $x100))))
(let (($x414 (or $x148 false)))
(and (not $x414) (or $x414 (and (distinct ?x1121 ?x1121) true)))))))))))
(check-sat)
