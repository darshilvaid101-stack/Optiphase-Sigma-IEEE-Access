; OptiPhase-Sigma refinement certificate for sweep K40-R3-138
; query 0: function set_key, block 11, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let (($x63 (or false false false)))
(let (($x340 (not $x63)))
(and $x340 (or $x63 (and (distinct (bvand in2_32 (_ bv1 32)) (bvand in2_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function set_key, block 11, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x149 (ite (and (distinct (_ bv0 32) (bvand in2_32 (_ bv1 32))) true) (_ bv1 1) (_ bv0 1))))
(let (($x63 (or false false false)))
(let (($x26 (or $x63 false false)))
(let (($x64 (not $x26)))
(and $x64 (or $x26 (and (distinct ?x149 ?x149) true))))))))
(check-sat)
; query 2: function set_key, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let (($x63 (or false false false)))
(let (($x340 (not $x63)))
(and $x340 (or $x63 (and (distinct (bvand in2_32 (_ bv2 32)) (bvand in2_32 (_ bv2 32))) true))))))
(check-sat)
; query 3: function set_key, block 14, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x43 (ite (and (distinct (_ bv0 32) (bvand in2_32 (_ bv2 32))) true) (_ bv1 1) (_ bv0 1))))
(let (($x63 (or false false false)))
(let (($x26 (or $x63 false false)))
(let (($x64 (not $x26)))
(and $x64 (or $x26 (and (distinct ?x43 ?x43) true))))))))
(check-sat)
; query 4: function set_key, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x507 (ite (and (distinct (_ bv0 64) in1_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x63 (or false false false)))
(let (($x340 (not $x63)))
(and $x340 (or $x63 (and (distinct ?x507 ?x507) true)))))))
(check-sat)
; query 5: function set_key, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x178 (ite (bvult in1_64 (_ bv16 64)) (_ bv1 1) (_ bv0 1))))
(let (($x63 (or false false false)))
(let (($x340 (not $x63)))
(and $x340 (or $x63 (and (distinct ?x178 ?x178) true)))))))
(check-sat)
; query 6: function set_key, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x18 (ite (bvugt in1_64 (_ bv32 64)) (_ bv1 1) (_ bv0 1))))
(let (($x63 (or false false false)))
(let (($x340 (not $x63)))
(and $x340 (or $x63 (and (distinct ?x18 ?x18) true)))))))
(check-sat)
; query 7: function set_key, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let (($x63 (or false false false)))
(let (($x340 (not $x63)))
(and $x340 (or $x63 (and (distinct (bvand in1_64 (_ bv7 64)) (bvand in1_64 (_ bv7 64))) true))))))
(check-sat)
; query 8: function set_key, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x753 (ite (and (distinct (_ bv0 64) (bvand in1_64 (_ bv7 64))) true) (_ bv1 1) (_ bv0 1))))
(let (($x63 (or false false false)))
(let (($x26 (or $x63 false false)))
(let (($x64 (not $x26)))
(and $x64 (or $x26 (and (distinct ?x753 ?x753) true))))))))
(check-sat)
