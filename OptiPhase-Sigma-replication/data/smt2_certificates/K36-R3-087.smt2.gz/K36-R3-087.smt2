; OptiPhase-Sigma refinement certificate for sweep K36-R3-087
