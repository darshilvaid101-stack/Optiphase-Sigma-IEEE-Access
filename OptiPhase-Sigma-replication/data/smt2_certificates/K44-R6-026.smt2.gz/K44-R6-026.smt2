; OptiPhase-Sigma refinement certificate for sweep K44-R6-026
; query 0: function Index_to_frequency, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x745 (ite (bvuge in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x134 (or false false false)))
(let (($x452 (not $x134)))
(and $x452 (or $x134 (and (distinct ?x745 ?x745) true)))))))
(check-sat)
; query 1: function IsPowerOfTwo, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x89 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x134 (or false false false)))
(let (($x452 (not $x134)))
(and $x452 (or $x134 (and (distinct ?x89 ?x89) true)))))))
(check-sat)
; query 2: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x89 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x134 (or false false false)))
(let (($x452 (not $x134)))
(and $x452 (or $x134 (and (distinct ?x89 ?x89) true)))))))
(check-sat)
; query 3: function main, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x249 (ite (= (_ bv4 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x134 (or false false false)))
(let (($x452 (not $x134)))
(and $x452 (or $x134 (and (distinct ?x249 ?x249) true)))))))
(check-sat)
; query 4: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x168 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x134 (or false false false)))
(let (($x452 (not $x134)))
(and $x452 (or $x134 (and (distinct ?x168 ?x168) true)))))))
(check-sat)
