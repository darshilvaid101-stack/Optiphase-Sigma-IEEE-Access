; OptiPhase-Sigma refinement certificate for sweep K52-R4-342
; query 0: function s162, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x384 (ite (bvslt (_ bv0 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x151 (or false false false)))
(and (not $x151) (or $x151 (and (distinct ?x384 ?x384) true))))))
(check-sat)
