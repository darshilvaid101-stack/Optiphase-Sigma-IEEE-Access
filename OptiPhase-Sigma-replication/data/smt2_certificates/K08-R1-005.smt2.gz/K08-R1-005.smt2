; OptiPhase-Sigma refinement certificate for sweep K08-R1-005
