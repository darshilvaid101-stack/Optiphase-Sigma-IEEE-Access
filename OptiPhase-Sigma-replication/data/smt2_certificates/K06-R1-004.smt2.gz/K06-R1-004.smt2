; OptiPhase-Sigma refinement certificate for sweep K06-R1-004
