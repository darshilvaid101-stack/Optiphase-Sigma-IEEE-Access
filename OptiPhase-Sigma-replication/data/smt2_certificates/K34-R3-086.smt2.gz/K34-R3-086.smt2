; OptiPhase-Sigma refinement certificate for sweep K34-R3-086
; query 0: function edge_draw, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let ((?x235 (ite (= (_ bv0 32) in4_32) (_ bv1 1) (_ bv0 1))))
(let (($x11 (or false false false)))
(and (not $x11) (or $x11 (and (distinct ?x235 ?x235) true))))))
(check-sat)
