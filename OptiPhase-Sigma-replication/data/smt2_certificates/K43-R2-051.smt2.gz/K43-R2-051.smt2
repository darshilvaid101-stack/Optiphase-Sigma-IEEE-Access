; OptiPhase-Sigma refinement certificate for sweep K43-R2-051
; query 0: function crc32buf, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_64 () (_ BitVec 64))
(assert
 (let (($x364 (or false false false)))
(let (($x848 (not $x364)))
(and $x848 (or $x364 (and (distinct (bvxor in.02_64 (_ bv18446744073709551615 64)) (bvxor in.02_64 (_ bv18446744073709551615 64))) true))))))
(check-sat)
; query 1: function main, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x127 (ite (and (distinct (_ bv0 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x364 (or false false false)))
(let (($x848 (not $x364)))
(and $x848 (or $x364 (and (distinct ?x127 ?x127) true)))))))
(check-sat)
; query 2: function main, block 17, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x127 (ite (and (distinct (_ bv0 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let ((?x121 ((_ zero_extend 31) ?x127)))
(let (($x364 (or false false false)))
(let (($x516 (or $x364 false)))
(and (not $x516) (or $x516 (and (distinct ?x121 ?x121) true))))))))
(check-sat)
