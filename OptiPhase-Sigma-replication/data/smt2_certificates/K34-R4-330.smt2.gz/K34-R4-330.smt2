; OptiPhase-Sigma refinement certificate for sweep K34-R4-330
; query 0: function edge_draw, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let ((?x638 (ite (= (_ bv0 32) in4_32) (_ bv1 1) (_ bv0 1))))
(let (($x532 (or false false false)))
(and (not $x532) (or $x532 (and (distinct ?x638 ?x638) true))))))
(check-sat)
