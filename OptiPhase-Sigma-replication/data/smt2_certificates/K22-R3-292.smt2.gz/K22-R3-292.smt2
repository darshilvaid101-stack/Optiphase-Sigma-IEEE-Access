; OptiPhase-Sigma refinement certificate for sweep K22-R3-292
