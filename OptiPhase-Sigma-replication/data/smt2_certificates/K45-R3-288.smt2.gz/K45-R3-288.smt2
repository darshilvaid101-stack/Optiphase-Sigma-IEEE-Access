; OptiPhase-Sigma refinement certificate for sweep K45-R3-288
; query 0: function Index_to_frequency, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x27 (ite (bvuge in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x29 (or false false false)))
(let (($x104 (not $x29)))
(and $x104 (or $x29 (and (distinct ?x27 ?x27) true)))))))
(check-sat)
; query 1: function IsPowerOfTwo, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x29 (or false false false)))
(let (($x104 (not $x29)))
(and $x104 (or $x29 (and (distinct (bvsub in0_32 (_ bv1 32)) (bvsub in0_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function IsPowerOfTwo, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x71 (bvsub in0_32 (_ bv1 32))))
(let ((?x130 (bvand ?x71 in0_32)))
(let ((?x198 (bvand in0_32 ?x71)))
(let (($x29 (or false false false)))
(let (($x823 (or $x29 false false)))
(and (not (or false $x29 false)) (or $x823 (and (distinct ?x198 ?x130) true)))))))))
(check-sat)
; query 3: function IsPowerOfTwo, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x498 (and (distinct (ite (and (distinct (_ bv0 32) (bvand in0_32 (bvsub in0_32 (_ bv1 32)))) true) (_ bv1 1) (_ bv0 1)) (ite (and (distinct (_ bv0 32) (bvand (bvsub in0_32 (_ bv1 32)) in0_32)) true) (_ bv1 1) (_ bv0 1))) true)))
(let (($x1203 (or (or (or (or false false false) false false) false false) $x498)))
(let (($x399 (not (or (or false (or false false false) false) false false))))
(and $x399 $x1203)))))
(check-sat)
; query 4: function IsPowerOfTwo, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x269 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x29 (or false false false)))
(let (($x104 (not $x29)))
(and $x104 (or $x29 (and (distinct ?x269 ?x269) true)))))))
(check-sat)
; query 5: function NumberOfBitsNeeded, block 13, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x29 (or false false false)))
(let (($x104 (not $x29)))
(and $x104 (or $x29 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 6: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x269 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x29 (or false false false)))
(let (($x104 (not $x29)))
(and $x104 (or $x29 (and (distinct ?x269 ?x269) true)))))))
(check-sat)
; query 7: function ReverseBits, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x29 (or false false false)))
(let (($x104 (not $x29)))
(and $x104 (or $x29 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function ReverseBits, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x29 (or false false false)))
(let (($x646 (or $x29 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x619 (not $x646)))
(and $x619 (or $x646 (and (distinct (bvshl in.01_32 (_ bv1 32)) (bvshl in.01_32 (_ bv1 32))) true)))))))
(check-sat)
; query 9: function ReverseBits, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x29 (or false false false)))
(let (($x104 (not $x29)))
(and $x104 (or $x29 (and (distinct (bvand in.0_32 (_ bv1 32)) (bvand in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 10: function ReverseBits, block 5, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x135 (bvshl in.01_32 (_ bv1 32))))
(let ((?x19 (bvand in.0_32 (_ bv1 32))))
(let ((?x368 (bvadd ?x19 ?x135)))
(let (($x446 (and (distinct (bvadd ((_ zero_extend 1) ?x19) ((_ zero_extend 1) ?x135)) ((_ zero_extend 1) ?x368)) true)))
(let (($x50 (and (distinct (bvadd ((_ sign_extend 1) ?x19) ((_ sign_extend 1) ?x135)) ((_ sign_extend 1) ?x368)) true)))
(let (($x29 (or false false false)))
(let (($x646 (or $x29 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not (or $x646 $x29 false)) (or (or $x29 $x646 (or $x50 $x446)) (and (distinct (bvor ?x135 ?x19) ?x368) true)))))))))))
(check-sat)
; query 11: function ReverseBits, block 5, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x29 (or false false false)))
(let (($x646 (or $x29 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x619 (not $x646)))
(and $x619 (or $x646 (and (distinct (bvlshr in.0_32 (_ bv1 32)) (bvlshr in.0_32 (_ bv1 32))) true)))))))
(check-sat)
; query 12: function fft_float, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x436 (ite (and (distinct (_ bv0 32) in1_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x29 (or false false false)))
(let (($x104 (not $x29)))
(and $x104 (or $x29 (and (distinct ?x436 ?x436) true)))))))
(check-sat)
; query 13: function fft_float, block 152, name %153
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let (($x29 (or false false false)))
(let (($x104 (not $x29)))
(and $x104 (or $x29 (and (distinct (bvadd in.04_32 (_ bv1 32)) (bvadd in.04_32 (_ bv1 32))) true))))))
(check-sat)
; query 14: function fft_float, block 152, name %154
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_32 () (_ BitVec 32))
(assert
 (let (($x29 (or false false false)))
(let (($x104 (not $x29)))
(and $x104 (or $x29 (and (distinct (bvadd in.03_32 (_ bv1 32)) (bvadd in.03_32 (_ bv1 32))) true))))))
(check-sat)
; query 15: function fft_float, block 156, name %157
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x29 (or false false false)))
(let (($x69 (or $x29 (and (distinct (bvadd in.1_32 in.02_32) (bvadd in.1_32 in.02_32)) true))))
(let (($x104 (not $x29)))
(and $x104 $x69)))))
(check-sat)
; query 16: function fft_float, block 159, name %160
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x29 (or false false false)))
(let (($x646 (or $x29 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x619 (not $x646)))
(and $x619 (or $x646 (and (distinct (bvshl in.02_32 (_ bv1 32)) (bvshl in.02_32 (_ bv1 32))) true)))))))
(check-sat)
; query 17: function fft_float, block 161, name %162
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x436 (ite (and (distinct (_ bv0 32) in1_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x29 (or false false false)))
(let (($x104 (not $x29)))
(and $x104 (or $x29 (and (distinct ?x436 ?x436) true)))))))
(check-sat)
; query 18: function fft_float, block 180, name %181
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let (($x29 (or false false false)))
(let (($x104 (not $x29)))
(and $x104 (or $x29 (and (distinct (bvadd in.2_32 (_ bv1 32)) (bvadd in.2_32 (_ bv1 32))) true))))))
(check-sat)
; query 19: function fft_float, block 41, name %42
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.05_32 () (_ BitVec 32))
(assert
 (let (($x29 (or false false false)))
(let (($x104 (not $x29)))
(and $x104 (or $x29 (and (distinct (bvadd in.05_32 (_ bv1 32)) (bvadd in.05_32 (_ bv1 32))) true))))))
(check-sat)
; query 20: function main, block 110, name %111
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x29 (or false false false)))
(let (($x104 (not $x29)))
(and $x104 (or $x29 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 21: function main, block 113, name %114
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x29 (or false false false)))
(let (($x104 (not $x29)))
(and $x104 (or $x29 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 22: function main, block 126, name %127
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let (($x29 (or false false false)))
(let (($x104 (not $x29)))
(and $x104 (or $x29 (and (distinct (bvadd in.2_32 (_ bv1 32)) (bvadd in.2_32 (_ bv1 32))) true))))))
(check-sat)
; query 23: function main, block 139, name %140
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.3_32 () (_ BitVec 32))
(assert
 (let (($x29 (or false false false)))
(let (($x104 (not $x29)))
(and $x104 (or $x29 (and (distinct (bvadd in.3_32 (_ bv1 32)) (bvadd in.3_32 (_ bv1 32))) true))))))
(check-sat)
; query 24: function main, block 57, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x29 (or false false false)))
(let (($x104 (not $x29)))
(and $x104 (or $x29 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 25: function main, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x248 (ite (= (_ bv4 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x29 (or false false false)))
(let (($x104 (not $x29)))
(and $x104 (or $x29 (and (distinct ?x248 ?x248) true)))))))
(check-sat)
; query 26: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x54 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x29 (or false false false)))
(let (($x104 (not $x29)))
(and $x104 (or $x29 (and (distinct ?x54 ?x54) true)))))))
(check-sat)
