; OptiPhase-Sigma refinement certificate for sweep K47-R3-123
; query 0: function adpcm_decoder, block 61, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.210_32 () (_ BitVec 32))
(declare-fun in.013_32 () (_ BitVec 32))
(assert
 (let ((?x475 (bvadd in.013_32 in.210_32)))
(let ((?x156 (bvsub in.013_32 in.210_32)))
(let (($x374 (and (distinct (bvadd ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x475)) true)))
(let (($x383 (and (distinct (bvsub ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x156)) true)))
(and (not (or false false (or $x383))) (or (or false false (or $x374)) (and (distinct ?x156 ?x475) true))))))))
(check-sat)
; query 1: function main, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x274 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x105 (or false false false)))
(and (not $x105) (or $x105 (and (distinct ?x274 ?x274) true))))))
(check-sat)
