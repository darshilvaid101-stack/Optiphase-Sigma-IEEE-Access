; OptiPhase-Sigma refinement certificate for sweep K57-R3-201
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x701 (or false false)))
(let (($x219 (not $x701)))
(and $x219 (or $x701 (and (distinct ((_ sign_extend 16) in25_16) ((_ sign_extend 16) in25_16)) true))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let ((?x351 (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))))
(let (($x701 (or false false)))
(let (($x420 (or $x701 false false)))
(let (($x25 (not $x420)))
(and $x25 (or $x420 (and (distinct ?x351 ?x351) true))))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x701 (or false false)))
(let (($x219 (not $x701)))
(and $x219 (or $x701 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x53 ((_ sign_extend 16) in3_16)))
(let ((?x518 (bvand ?x53 (_ bv127 32))))
(let (($x701 (or false false)))
(let (($x420 (or $x701 false false)))
(let (($x25 (not $x420)))
(and $x25 (or $x420 (and (distinct ?x518 ?x518) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x53 ((_ sign_extend 16) in3_16)))
(let ((?x518 (bvand ?x53 (_ bv127 32))))
(let ((?x457 ((_ extract 15 0) ?x518)))
(let (($x701 (or false false)))
(let (($x420 (or $x701 false false)))
(let (($x564 (or $x420 false)))
(let (($x34 (not $x564)))
(and $x34 (or $x564 (and (distinct ?x457 ?x457) true)))))))))))
(check-sat)
; query 5: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x701 (or false false)))
(let (($x219 (not $x701)))
(and $x219 (or $x701 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 6: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x755 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x701 (or false false)))
(let (($x420 (or $x701 false false)))
(let (($x25 (not $x420)))
(and $x25 (or $x420 (and (distinct ?x755 ?x755) true))))))))
(check-sat)
; query 7: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x1347 (or false false false)))
(let (($x119 (not $x1347)))
(and $x119 (or $x1347 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x27 (bvadd in.01_32 (_ bv1 32))))
(let ((?x298 (bvmul ?x27 ?x27)))
(let (($x1347 (or false false false)))
(let (($x30 (or $x1347 $x1347 false)))
(and (not $x30) (or $x30 (and (distinct ?x298 ?x298) true))))))))
(check-sat)
; query 9: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x27 (bvadd in.01_32 (_ bv1 32))))
(let ((?x298 (bvmul ?x27 ?x27)))
(let ((?x21 (bvmul ?x298 (_ bv2 32))))
(let (($x1347 (or false false false)))
(let (($x30 (or $x1347 $x1347 false)))
(let (($x128 (or $x30 false false)))
(and (not $x128) (or $x128 (and (distinct ?x21 ?x21) true))))))))))
(check-sat)
; query 10: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x27 (bvadd in.01_32 (_ bv1 32))))
(let ((?x298 (bvmul ?x27 ?x27)))
(let ((?x21 (bvmul ?x298 (_ bv2 32))))
(let ((?x171 (bvmul ?x21 (_ bv4 32))))
(let (($x1347 (or false false false)))
(let (($x30 (or $x1347 $x1347 false)))
(let (($x128 (or $x30 false false)))
(let (($x37 (or $x128 false false)))
(and (not $x37) (or $x37 (and (distinct ?x171 ?x171) true))))))))))))
(check-sat)
; query 11: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x1391 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x1347 (or false false false)))
(let (($x119 (not $x1347)))
(and $x119 (or $x1347 (and (distinct ?x1391 ?x1391) true)))))))
(check-sat)
; query 12: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x63 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x1347 (or false false false)))
(let (($x119 (not $x1347)))
(and $x119 (or $x1347 (and (distinct ?x63 ?x63) true)))))))
(check-sat)
; query 13: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x1347 (or false false false)))
(let (($x119 (not $x1347)))
(and $x119 (or $x1347 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 14: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x98 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x410 (or false false (or $x98))))
(and (not $x410) (or $x410 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 15: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x276 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x1347 (or false false false)))
(let (($x119 (not $x1347)))
(and $x119 (or $x1347 (and (distinct ?x276 ?x276) true)))))))
(check-sat)
; query 16: function crcu8, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x701 (or false false)))
(let (($x219 (not $x701)))
(and $x219 (or $x701 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 17: function crcu8, block 19, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x46 ((_ zero_extend 16) in.01_16)))
(let ((?x87 (bvxor ?x46 (_ bv16386 32))))
(let (($x701 (or false false)))
(let (($x420 (or $x701 false false)))
(let (($x25 (not $x420)))
(and $x25 (or $x420 (and (distinct ?x87 ?x87) true)))))))))
(check-sat)
; query 18: function crcu8, block 19, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x46 ((_ zero_extend 16) in.01_16)))
(let ((?x87 (bvxor ?x46 (_ bv16386 32))))
(let ((?x43 ((_ extract 15 0) ?x87)))
(let (($x701 (or false false)))
(let (($x420 (or $x701 false false)))
(let (($x564 (or $x420 false)))
(let (($x34 (not $x564)))
(and $x34 (or $x564 (and (distinct ?x43 ?x43) true)))))))))))
(check-sat)
; query 19: function crcu8, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x529 ((_ extract 7 0) in.01_16)))
(let ((?x94 ((_ zero_extend 24) ?x529)))
(let (($x701 (or false false)))
(let (($x719 (or $x701 false)))
(and (not $x719) (or $x719 (and (distinct ?x94 ?x94) true))))))))
(check-sat)
; query 20: function crcu8, block 6, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x529 ((_ extract 7 0) in.01_16)))
(let ((?x94 ((_ zero_extend 24) ?x529)))
(let ((?x686 (bvand ?x94 (_ bv1 32))))
(let (($x701 (or false false)))
(let (($x719 (or $x701 false)))
(let (($x35 (or $x719 false false)))
(and (not $x35) (or $x35 (and (distinct ?x686 ?x686) true))))))))))
(check-sat)
; query 21: function crcu8, block 6, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x529 ((_ extract 7 0) in.01_16)))
(let ((?x94 ((_ zero_extend 24) ?x529)))
(let ((?x686 (bvand ?x94 (_ bv1 32))))
(let ((?x8 ((_ zero_extend 24) in.0_8)))
(let ((?x604 (bvand ?x8 (_ bv1 32))))
(let ((?x192 (bvxor ?x604 ?x686)))
(let (($x701 (or false false)))
(let (($x719 (or $x701 false)))
(let (($x35 (or $x719 false false)))
(let (($x420 (or $x701 false false)))
(let (($x60 (or $x420 $x35 false)))
(and (not $x60) (or $x60 (and (distinct ?x192 ?x192) true)))))))))))))))
(check-sat)
; query 22: function crcu8, block 6, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x529 ((_ extract 7 0) in.01_16)))
(let ((?x94 ((_ zero_extend 24) ?x529)))
(let ((?x686 (bvand ?x94 (_ bv1 32))))
(let ((?x8 ((_ zero_extend 24) in.0_8)))
(let ((?x604 (bvand ?x8 (_ bv1 32))))
(let ((?x192 (bvxor ?x604 ?x686)))
(let ((?x78 ((_ extract 7 0) ?x192)))
(let (($x701 (or false false)))
(let (($x719 (or $x701 false)))
(let (($x35 (or $x719 false false)))
(let (($x420 (or $x701 false false)))
(let (($x60 (or $x420 $x35 false)))
(let (($x415 (or $x60 false)))
(and (not $x415) (or $x415 (and (distinct ?x78 ?x78) true)))))))))))))))))
(check-sat)
; query 23: function crcu8, block 6, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x701 (or false false)))
(let (($x219 (not $x701)))
(and $x219 (or $x701 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 24: function crcu8, block 6, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x8 ((_ zero_extend 24) in.0_8)))
(let ((?x167 (bvashr ?x8 (_ bv1 32))))
(let (($x701 (or false false)))
(let (($x420 (or $x701 false false)))
(let (($x140 (or $x420 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not $x140) (or $x140 (and (distinct ?x167 ?x167) true)))))))))
(check-sat)
; query 25: function crcu8, block 6, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x8 ((_ zero_extend 24) in.0_8)))
(let ((?x167 (bvashr ?x8 (_ bv1 32))))
(let ((?x1400 ((_ extract 7 0) ?x167)))
(let (($x701 (or false false)))
(let (($x420 (or $x701 false false)))
(let (($x140 (or $x420 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x1305 (or $x140 false)))
(and (not $x1305) (or $x1305 (and (distinct ?x1400 ?x1400) true)))))))))))
(check-sat)
; query 26: function crcu8, block 6, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x529 ((_ extract 7 0) in.01_16)))
(let ((?x94 ((_ zero_extend 24) ?x529)))
(let ((?x686 (bvand ?x94 (_ bv1 32))))
(let ((?x8 ((_ zero_extend 24) in.0_8)))
(let ((?x604 (bvand ?x8 (_ bv1 32))))
(let ((?x192 (bvxor ?x604 ?x686)))
(let ((?x78 ((_ extract 7 0) ?x192)))
(let ((?x1302 ((_ zero_extend 24) ?x78)))
(let (($x701 (or false false)))
(let (($x719 (or $x701 false)))
(let (($x35 (or $x719 false false)))
(let (($x420 (or $x701 false false)))
(let (($x60 (or $x420 $x35 false)))
(let (($x415 (or $x60 false)))
(let (($x31 (or $x415 false)))
(and (not $x31) (or $x31 (and (distinct ?x1302 ?x1302) true)))))))))))))))))))
(check-sat)
; query 27: function crcu8, block 6, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x529 ((_ extract 7 0) in.01_16)))
(let ((?x94 ((_ zero_extend 24) ?x529)))
(let ((?x686 (bvand ?x94 (_ bv1 32))))
(let ((?x8 ((_ zero_extend 24) in.0_8)))
(let ((?x604 (bvand ?x8 (_ bv1 32))))
(let ((?x192 (bvxor ?x604 ?x686)))
(let ((?x78 ((_ extract 7 0) ?x192)))
(let ((?x1302 ((_ zero_extend 24) ?x78)))
(let ((?x48 (ite (= (_ bv1 32) ?x1302) (_ bv1 1) (_ bv0 1))))
(let (($x701 (or false false)))
(let (($x719 (or $x701 false)))
(let (($x35 (or $x719 false false)))
(let (($x420 (or $x701 false false)))
(let (($x60 (or $x420 $x35 false)))
(let (($x415 (or $x60 false)))
(let (($x31 (or $x415 false)))
(let (($x61 (or $x31 false false)))
(and (not $x61) (or $x61 (and (distinct ?x48 ?x48) true)))))))))))))))))))))
(check-sat)
; query 28: function crcu8, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x701 (or false false)))
(let (($x219 (not $x701)))
(and $x219 (or $x701 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 29: function crcu8, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x8 ((_ zero_extend 24) in.0_8)))
(let ((?x604 (bvand ?x8 (_ bv1 32))))
(let (($x701 (or false false)))
(let (($x420 (or $x701 false false)))
(let (($x25 (not $x420)))
(and $x25 (or $x420 (and (distinct ?x604 ?x604) true)))))))))
(check-sat)
; query 30: function crcu8, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x701 (or false false)))
(let (($x219 (not $x701)))
(and $x219 (or $x701 (and (distinct ((_ extract 7 0) in.01_16) ((_ extract 7 0) in.01_16)) true))))))
(check-sat)
; query 31: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x103 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x355 ((_ zero_extend 31) ?x103)))
(let ((?x109 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x309 ((_ zero_extend 31) ?x109)))
(let ((?x602 (bvand ?x309 ?x355)))
(let ((?x132 (ite (and (distinct (_ bv0 32) ?x602) true) (_ bv1 1) (_ bv0 1))))
(let ((?x106 ((_ zero_extend 63) ?x132)))
(let (($x701 (or false false)))
(let (($x420 (or $x701 false false)))
(let (($x564 (or $x420 false)))
(let (($x115 (or $x564 $x564 false)))
(let (($x1332 (or $x115 false false)))
(let (($x338 (or $x1332 false)))
(and (not $x338) (or $x338 (and (distinct ?x106 ?x106) true)))))))))))))))))
(check-sat)
; query 32: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x103 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x355 ((_ zero_extend 31) ?x103)))
(let ((?x109 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x309 ((_ zero_extend 31) ?x109)))
(let ((?x602 (bvand ?x309 ?x355)))
(let ((?x132 (ite (and (distinct (_ bv0 32) ?x602) true) (_ bv1 1) (_ bv0 1))))
(let (($x201 (= (_ bv1 1) ?x132)))
(let ((?x692 (ite $x201 (_ bv1 32) (_ bv0 32))))
(let (($x701 (or false false)))
(let (($x420 (or $x701 false false)))
(let (($x564 (or $x420 false)))
(let (($x115 (or $x564 $x564 false)))
(let (($x1332 (or $x115 false false)))
(let (($x865 (or $x1332 (ite $x201 false false))))
(and (not $x865) (or $x865 (and (distinct ?x692 ?x692) true))))))))))))))))))
(check-sat)
; query 33: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x103 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x355 ((_ zero_extend 31) ?x103)))
(let ((?x109 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x309 ((_ zero_extend 31) ?x109)))
(let ((?x602 (bvand ?x309 ?x355)))
(let ((?x132 (ite (and (distinct (_ bv0 32) ?x602) true) (_ bv1 1) (_ bv0 1))))
(let (($x201 (= (_ bv1 1) ?x132)))
(let ((?x692 (ite $x201 (_ bv1 32) (_ bv0 32))))
(let ((?x814 ((_ extract 7 0) ?x692)))
(let (($x701 (or false false)))
(let (($x420 (or $x701 false false)))
(let (($x564 (or $x420 false)))
(let (($x115 (or $x564 $x564 false)))
(let (($x1332 (or $x115 false false)))
(let (($x865 (or $x1332 (ite $x201 false false))))
(let (($x1312 (or $x865 false)))
(and (not $x1312) (or $x1312 (and (distinct ?x814 ?x814) true))))))))))))))))))))
(check-sat)
; query 34: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x701 (or false false)))
(let (($x219 (not $x701)))
(and $x219 (or $x701 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 35: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x109 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x701 (or false false)))
(let (($x420 (or $x701 false false)))
(let (($x25 (not $x420)))
(and $x25 (or $x420 (and (distinct ?x109 ?x109) true))))))))
(check-sat)
; query 36: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x109 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x309 ((_ zero_extend 31) ?x109)))
(let (($x701 (or false false)))
(let (($x420 (or $x701 false false)))
(let (($x564 (or $x420 false)))
(let (($x34 (not $x564)))
(and $x34 (or $x564 (and (distinct ?x309 ?x309) true))))))))))
(check-sat)
; query 37: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x701 (or false false)))
(let (($x219 (not $x701)))
(and $x219 (or $x701 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 38: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x103 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x701 (or false false)))
(let (($x420 (or $x701 false false)))
(let (($x25 (not $x420)))
(and $x25 (or $x420 (and (distinct ?x103 ?x103) true))))))))
(check-sat)
; query 39: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x103 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x355 ((_ zero_extend 31) ?x103)))
(let (($x701 (or false false)))
(let (($x420 (or $x701 false false)))
(let (($x564 (or $x420 false)))
(let (($x34 (not $x564)))
(and $x34 (or $x564 (and (distinct ?x355 ?x355) true))))))))))
(check-sat)
; query 40: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x103 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x355 ((_ zero_extend 31) ?x103)))
(let ((?x109 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x309 ((_ zero_extend 31) ?x109)))
(let ((?x602 (bvand ?x309 ?x355)))
(let (($x701 (or false false)))
(let (($x420 (or $x701 false false)))
(let (($x564 (or $x420 false)))
(let (($x115 (or $x564 $x564 false)))
(and (not $x115) (or $x115 (and (distinct ?x602 ?x602) true)))))))))))))
(check-sat)
; query 41: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x103 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x355 ((_ zero_extend 31) ?x103)))
(let ((?x109 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x309 ((_ zero_extend 31) ?x109)))
(let ((?x602 (bvand ?x309 ?x355)))
(let ((?x132 (ite (and (distinct (_ bv0 32) ?x602) true) (_ bv1 1) (_ bv0 1))))
(let (($x701 (or false false)))
(let (($x420 (or $x701 false false)))
(let (($x564 (or $x420 false)))
(let (($x115 (or $x564 $x564 false)))
(let (($x1332 (or $x115 false false)))
(and (not $x1332) (or $x1332 (and (distinct ?x132 ?x132) true)))))))))))))))
(check-sat)
; query 42: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1383 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x1347 (or false false false)))
(let (($x119 (not $x1347)))
(and $x119 (or $x1347 (and (distinct ?x1383 ?x1383) true)))))))
(check-sat)
; query 43: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x701 (or false false)))
(let (($x219 (not $x701)))
(and $x219 (or $x701 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 44: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x1307 ((_ sign_extend 16) in.1_16)))
(let ((?x1408 (bvadd ?x1307 (_ bv10 32))))
(let (($x1303 (and (distinct (bvadd ((_ sign_extend 1) ?x1307) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x1408)) true)))
(let (($x701 (or false false)))
(let (($x1268 (or $x701 false (or $x1303))))
(and (not $x1268) (or $x1268 (and (distinct ?x1408 ?x1408) true)))))))))
(check-sat)
; query 45: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x1307 ((_ sign_extend 16) in.1_16)))
(let ((?x1408 (bvadd ?x1307 (_ bv10 32))))
(let ((?x1404 ((_ extract 15 0) ?x1408)))
(let (($x1303 (and (distinct (bvadd ((_ sign_extend 1) ?x1307) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x1408)) true)))
(let (($x701 (or false false)))
(let (($x1268 (or $x701 false (or $x1303))))
(let (($x1373 (or $x1268 false)))
(and (not $x1373) (or $x1373 (and (distinct ?x1404 ?x1404) true)))))))))))
(check-sat)
; query 46: function matrix_sum, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x1265 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x1347 (or false false false)))
(let (($x119 (not $x1347)))
(and $x119 (or $x1347 (and (distinct ?x1265 ?x1265) true)))))))
(check-sat)
; query 47: function matrix_sum, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x1265 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let ((?x58 ((_ zero_extend 63) ?x1265)))
(let (($x1347 (or false false false)))
(let (($x1168 (or $x1347 false)))
(and (not $x1168) (or $x1168 (and (distinct ?x58 ?x58) true))))))))
(check-sat)
; query 48: function matrix_sum, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x1265 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x1013 (= (_ bv1 1) ?x1265)))
(let ((?x510 (ite $x1013 (_ bv1 32) (_ bv0 32))))
(let (($x1347 (or false false false)))
(let (($x846 (or $x1347 (ite $x1013 false false))))
(and (not $x846) (or $x846 (and (distinct ?x510 ?x510) true)))))))))
(check-sat)
; query 49: function matrix_sum, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x701 (or false false)))
(let (($x219 (not $x701)))
(and $x219 (or $x701 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 50: function matrix_sum, block 22, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x1265 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x1013 (= (_ bv1 1) ?x1265)))
(let ((?x510 (ite $x1013 (_ bv1 32) (_ bv0 32))))
(let ((?x1307 ((_ sign_extend 16) in.1_16)))
(let ((?x1140 (bvadd ?x1307 ?x510)))
(let (($x205 (and (distinct (bvadd ((_ sign_extend 1) ?x1307) ((_ sign_extend 1) ?x510)) ((_ sign_extend 1) ?x1140)) true)))
(let (($x1347 (or false false false)))
(let (($x846 (or $x1347 (ite $x1013 false false))))
(let (($x701 (or false false)))
(let (($x1323 (or $x701 $x846 (or $x205))))
(and (not $x1323) (or $x1323 (and (distinct ?x1140 ?x1140) true))))))))))))))
(check-sat)
; query 51: function matrix_sum, block 22, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x1265 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x1013 (= (_ bv1 1) ?x1265)))
(let ((?x510 (ite $x1013 (_ bv1 32) (_ bv0 32))))
(let ((?x1307 ((_ sign_extend 16) in.1_16)))
(let ((?x1140 (bvadd ?x1307 ?x510)))
(let ((?x1079 ((_ extract 15 0) ?x1140)))
(let (($x205 (and (distinct (bvadd ((_ sign_extend 1) ?x1307) ((_ sign_extend 1) ?x510)) ((_ sign_extend 1) ?x1140)) true)))
(let (($x1347 (or false false false)))
(let (($x846 (or $x1347 (ite $x1013 false false))))
(let (($x701 (or false false)))
(let (($x1323 (or $x701 $x846 (or $x205))))
(let (($x285 (or $x1323 false)))
(and (not $x285) (or $x285 (and (distinct ?x1079 ?x1079) true))))))))))))))))
(check-sat)
