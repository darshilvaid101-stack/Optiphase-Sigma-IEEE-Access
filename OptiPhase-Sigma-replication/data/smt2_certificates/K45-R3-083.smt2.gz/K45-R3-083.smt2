; OptiPhase-Sigma refinement certificate for sweep K45-R3-083
; query 0: function IsPowerOfTwo, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x320 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x440 (or false false false)))
(let (($x5 (not $x440)))
(and $x5 (or $x440 (and (distinct ?x320 ?x320) true)))))))
(check-sat)
; query 1: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x320 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x440 (or false false false)))
(let (($x5 (not $x440)))
(and $x5 (or $x440 (and (distinct ?x320 ?x320) true)))))))
(check-sat)
; query 2: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x701 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x440 (or false false false)))
(let (($x5 (not $x440)))
(and $x5 (or $x440 (and (distinct ?x701 ?x701) true)))))))
(check-sat)
