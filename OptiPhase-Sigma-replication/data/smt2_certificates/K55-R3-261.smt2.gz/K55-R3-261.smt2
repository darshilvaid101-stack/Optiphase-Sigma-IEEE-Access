; OptiPhase-Sigma refinement certificate for sweep K55-R3-261
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x70 (or false false)))
(let (($x251 (not $x70)))
(and $x251 (or $x70 (and (distinct ((_ sign_extend 16) in25_16) ((_ sign_extend 16) in25_16)) true))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let ((?x159 (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))))
(let (($x70 (or false false)))
(let (($x99 (or $x70 false false)))
(let (($x107 (not $x99)))
(and $x107 (or $x99 (and (distinct ?x159 ?x159) true))))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x70 (or false false)))
(let (($x251 (not $x70)))
(and $x251 (or $x70 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x20 ((_ sign_extend 16) in3_16)))
(let ((?x856 (bvand ?x20 (_ bv127 32))))
(let (($x70 (or false false)))
(let (($x99 (or $x70 false false)))
(let (($x107 (not $x99)))
(and $x107 (or $x99 (and (distinct ?x856 ?x856) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x20 ((_ sign_extend 16) in3_16)))
(let ((?x856 (bvand ?x20 (_ bv127 32))))
(let ((?x172 ((_ extract 15 0) ?x856)))
(let (($x70 (or false false)))
(let (($x99 (or $x70 false false)))
(let (($x225 (or $x99 false)))
(let (($x83 (not $x225)))
(and $x83 (or $x225 (and (distinct ?x172 ?x172) true)))))))))))
(check-sat)
; query 5: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x70 (or false false)))
(let (($x251 (not $x70)))
(and $x251 (or $x70 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 6: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x77 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x70 (or false false)))
(let (($x99 (or $x70 false false)))
(let (($x107 (not $x99)))
(and $x107 (or $x99 (and (distinct ?x77 ?x77) true))))))))
(check-sat)
; query 7: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x679 (or false false false)))
(let (($x157 (not $x679)))
(and $x157 (or $x679 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x587 (bvadd in.01_32 (_ bv1 32))))
(let ((?x58 (bvmul ?x587 ?x587)))
(let (($x679 (or false false false)))
(let (($x919 (or $x679 $x679 false)))
(and (not $x919) (or $x919 (and (distinct ?x58 ?x58) true))))))))
(check-sat)
; query 9: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x587 (bvadd in.01_32 (_ bv1 32))))
(let ((?x58 (bvmul ?x587 ?x587)))
(let ((?x142 (bvmul ?x58 (_ bv2 32))))
(let (($x679 (or false false false)))
(let (($x919 (or $x679 $x679 false)))
(let (($x458 (or $x919 false false)))
(and (not $x458) (or $x458 (and (distinct ?x142 ?x142) true))))))))))
(check-sat)
; query 10: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x587 (bvadd in.01_32 (_ bv1 32))))
(let ((?x58 (bvmul ?x587 ?x587)))
(let ((?x142 (bvmul ?x58 (_ bv2 32))))
(let ((?x133 (bvmul ?x142 (_ bv4 32))))
(let (($x679 (or false false false)))
(let (($x919 (or $x679 $x679 false)))
(let (($x458 (or $x919 false false)))
(let (($x144 (or $x458 false false)))
(and (not $x144) (or $x144 (and (distinct ?x133 ?x133) true))))))))))))
(check-sat)
; query 11: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x162 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x679 (or false false false)))
(let (($x157 (not $x679)))
(and $x157 (or $x679 (and (distinct ?x162 ?x162) true)))))))
(check-sat)
; query 12: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x734 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x679 (or false false false)))
(let (($x157 (not $x679)))
(and $x157 (or $x679 (and (distinct ?x734 ?x734) true)))))))
(check-sat)
; query 13: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x679 (or false false false)))
(let (($x157 (not $x679)))
(and $x157 (or $x679 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 14: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x137 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x200 (or false false (or $x137))))
(and (not $x200) (or $x200 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 15: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x79 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x679 (or false false false)))
(let (($x157 (not $x679)))
(and $x157 (or $x679 (and (distinct ?x79 ?x79) true)))))))
(check-sat)
; query 16: function crcu8, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x70 (or false false)))
(let (($x251 (not $x70)))
(and $x251 (or $x70 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 17: function crcu8, block 19, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x60 ((_ zero_extend 16) in.01_16)))
(let ((?x231 (bvxor ?x60 (_ bv16386 32))))
(let (($x70 (or false false)))
(let (($x99 (or $x70 false false)))
(let (($x107 (not $x99)))
(and $x107 (or $x99 (and (distinct ?x231 ?x231) true)))))))))
(check-sat)
; query 18: function crcu8, block 19, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x60 ((_ zero_extend 16) in.01_16)))
(let ((?x231 (bvxor ?x60 (_ bv16386 32))))
(let ((?x22 ((_ extract 15 0) ?x231)))
(let (($x70 (or false false)))
(let (($x99 (or $x70 false false)))
(let (($x225 (or $x99 false)))
(let (($x83 (not $x225)))
(and $x83 (or $x225 (and (distinct ?x22 ?x22) true)))))))))))
(check-sat)
; query 19: function crcu8, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x37 ((_ extract 7 0) in.01_16)))
(let ((?x153 ((_ zero_extend 24) ?x37)))
(let (($x70 (or false false)))
(let (($x624 (or $x70 false)))
(and (not $x624) (or $x624 (and (distinct ?x153 ?x153) true))))))))
(check-sat)
; query 20: function crcu8, block 6, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x37 ((_ extract 7 0) in.01_16)))
(let ((?x153 ((_ zero_extend 24) ?x37)))
(let ((?x75 (bvand ?x153 (_ bv1 32))))
(let (($x70 (or false false)))
(let (($x624 (or $x70 false)))
(let (($x92 (or $x624 false false)))
(and (not $x92) (or $x92 (and (distinct ?x75 ?x75) true))))))))))
(check-sat)
; query 21: function crcu8, block 6, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x37 ((_ extract 7 0) in.01_16)))
(let ((?x153 ((_ zero_extend 24) ?x37)))
(let ((?x75 (bvand ?x153 (_ bv1 32))))
(let ((?x67 ((_ zero_extend 24) in.0_8)))
(let ((?x86 (bvand ?x67 (_ bv1 32))))
(let ((?x136 (bvxor ?x86 ?x75)))
(let (($x70 (or false false)))
(let (($x624 (or $x70 false)))
(let (($x92 (or $x624 false false)))
(let (($x99 (or $x70 false false)))
(let (($x135 (or $x99 $x92 false)))
(and (not $x135) (or $x135 (and (distinct ?x136 ?x136) true)))))))))))))))
(check-sat)
; query 22: function crcu8, block 6, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x37 ((_ extract 7 0) in.01_16)))
(let ((?x153 ((_ zero_extend 24) ?x37)))
(let ((?x75 (bvand ?x153 (_ bv1 32))))
(let ((?x67 ((_ zero_extend 24) in.0_8)))
(let ((?x86 (bvand ?x67 (_ bv1 32))))
(let ((?x136 (bvxor ?x86 ?x75)))
(let ((?x44 ((_ extract 7 0) ?x136)))
(let (($x70 (or false false)))
(let (($x624 (or $x70 false)))
(let (($x92 (or $x624 false false)))
(let (($x99 (or $x70 false false)))
(let (($x135 (or $x99 $x92 false)))
(let (($x120 (or $x135 false)))
(and (not $x120) (or $x120 (and (distinct ?x44 ?x44) true)))))))))))))))))
(check-sat)
; query 23: function crcu8, block 6, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x70 (or false false)))
(let (($x251 (not $x70)))
(and $x251 (or $x70 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 24: function crcu8, block 6, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x67 ((_ zero_extend 24) in.0_8)))
(let ((?x104 (bvashr ?x67 (_ bv1 32))))
(let (($x70 (or false false)))
(let (($x99 (or $x70 false false)))
(let (($x161 (or $x99 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not $x161) (or $x161 (and (distinct ?x104 ?x104) true)))))))))
(check-sat)
; query 25: function crcu8, block 6, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x67 ((_ zero_extend 24) in.0_8)))
(let ((?x104 (bvashr ?x67 (_ bv1 32))))
(let ((?x466 ((_ extract 7 0) ?x104)))
(let (($x70 (or false false)))
(let (($x99 (or $x70 false false)))
(let (($x161 (or $x99 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x1333 (or $x161 false)))
(and (not $x1333) (or $x1333 (and (distinct ?x466 ?x466) true)))))))))))
(check-sat)
; query 26: function crcu8, block 6, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x37 ((_ extract 7 0) in.01_16)))
(let ((?x153 ((_ zero_extend 24) ?x37)))
(let ((?x75 (bvand ?x153 (_ bv1 32))))
(let ((?x67 ((_ zero_extend 24) in.0_8)))
(let ((?x86 (bvand ?x67 (_ bv1 32))))
(let ((?x136 (bvxor ?x86 ?x75)))
(let ((?x44 ((_ extract 7 0) ?x136)))
(let ((?x487 ((_ zero_extend 24) ?x44)))
(let (($x70 (or false false)))
(let (($x624 (or $x70 false)))
(let (($x92 (or $x624 false false)))
(let (($x99 (or $x70 false false)))
(let (($x135 (or $x99 $x92 false)))
(let (($x120 (or $x135 false)))
(let (($x1121 (or $x120 false)))
(and (not $x1121) (or $x1121 (and (distinct ?x487 ?x487) true)))))))))))))))))))
(check-sat)
; query 27: function crcu8, block 6, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x37 ((_ extract 7 0) in.01_16)))
(let ((?x153 ((_ zero_extend 24) ?x37)))
(let ((?x75 (bvand ?x153 (_ bv1 32))))
(let ((?x67 ((_ zero_extend 24) in.0_8)))
(let ((?x86 (bvand ?x67 (_ bv1 32))))
(let ((?x136 (bvxor ?x86 ?x75)))
(let ((?x44 ((_ extract 7 0) ?x136)))
(let ((?x487 ((_ zero_extend 24) ?x44)))
(let ((?x40 (ite (= (_ bv1 32) ?x487) (_ bv1 1) (_ bv0 1))))
(let (($x70 (or false false)))
(let (($x624 (or $x70 false)))
(let (($x92 (or $x624 false false)))
(let (($x99 (or $x70 false false)))
(let (($x135 (or $x99 $x92 false)))
(let (($x120 (or $x135 false)))
(let (($x1121 (or $x120 false)))
(let (($x184 (or $x1121 false false)))
(and (not $x184) (or $x184 (and (distinct ?x40 ?x40) true)))))))))))))))))))))
(check-sat)
; query 28: function crcu8, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x70 (or false false)))
(let (($x251 (not $x70)))
(and $x251 (or $x70 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 29: function crcu8, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x67 ((_ zero_extend 24) in.0_8)))
(let ((?x86 (bvand ?x67 (_ bv1 32))))
(let (($x70 (or false false)))
(let (($x99 (or $x70 false false)))
(let (($x107 (not $x99)))
(and $x107 (or $x99 (and (distinct ?x86 ?x86) true)))))))))
(check-sat)
; query 30: function crcu8, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x70 (or false false)))
(let (($x251 (not $x70)))
(and $x251 (or $x70 (and (distinct ((_ extract 7 0) in.01_16) ((_ extract 7 0) in.01_16)) true))))))
(check-sat)
; query 31: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1160 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x679 (or false false false)))
(let (($x157 (not $x679)))
(and $x157 (or $x679 (and (distinct ?x1160 ?x1160) true)))))))
(check-sat)
; query 32: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x70 (or false false)))
(let (($x251 (not $x70)))
(and $x251 (or $x70 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 33: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x74 ((_ sign_extend 16) in.1_16)))
(let ((?x84 (bvadd ?x74 (_ bv10 32))))
(let (($x24 (and (distinct (bvadd ((_ sign_extend 1) ?x74) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x84)) true)))
(let (($x70 (or false false)))
(let (($x1071 (or $x70 false (or $x24))))
(and (not $x1071) (or $x1071 (and (distinct ?x84 ?x84) true)))))))))
(check-sat)
; query 34: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x74 ((_ sign_extend 16) in.1_16)))
(let ((?x84 (bvadd ?x74 (_ bv10 32))))
(let ((?x80 ((_ extract 15 0) ?x84)))
(let (($x24 (and (distinct (bvadd ((_ sign_extend 1) ?x74) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x84)) true)))
(let (($x70 (or false false)))
(let (($x1071 (or $x70 false (or $x24))))
(let (($x276 (or $x1071 false)))
(and (not $x276) (or $x276 (and (distinct ?x80 ?x80) true)))))))))))
(check-sat)
