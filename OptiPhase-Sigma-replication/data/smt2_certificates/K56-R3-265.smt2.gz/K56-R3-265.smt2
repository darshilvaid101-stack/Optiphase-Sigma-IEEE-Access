; OptiPhase-Sigma refinement certificate for sweep K56-R3-265
; query 0: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x416 (or false false false)))
(let (($x1380 (not $x416)))
(and $x1380 (or $x416 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x199 (bvadd in.01_32 (_ bv1 32))))
(let ((?x664 (bvmul ?x199 ?x199)))
(let (($x416 (or false false false)))
(let (($x25 (or $x416 $x416 false)))
(and (not $x25) (or $x25 (and (distinct ?x664 ?x664) true))))))))
(check-sat)
; query 2: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x199 (bvadd in.01_32 (_ bv1 32))))
(let ((?x664 (bvmul ?x199 ?x199)))
(let ((?x64 (bvmul ?x664 (_ bv2 32))))
(let (($x416 (or false false false)))
(let (($x25 (or $x416 $x416 false)))
(let (($x86 (or $x25 false false)))
(and (not $x86) (or $x86 (and (distinct ?x64 ?x64) true))))))))))
(check-sat)
; query 3: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x199 (bvadd in.01_32 (_ bv1 32))))
(let ((?x664 (bvmul ?x199 ?x199)))
(let ((?x64 (bvmul ?x664 (_ bv2 32))))
(let ((?x79 (bvmul ?x64 (_ bv4 32))))
(let (($x416 (or false false false)))
(let (($x25 (or $x416 $x416 false)))
(let (($x86 (or $x25 false false)))
(let (($x194 (or $x86 false false)))
(and (not $x194) (or $x194 (and (distinct ?x79 ?x79) true))))))))))))
(check-sat)
; query 4: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x536 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x416 (or false false false)))
(let (($x1380 (not $x416)))
(and $x1380 (or $x416 (and (distinct ?x536 ?x536) true)))))))
(check-sat)
; query 5: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x6691 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x416 (or false false false)))
(let (($x1380 (not $x416)))
(and $x1380 (or $x416 (and (distinct ?x6691 ?x6691) true)))))))
(check-sat)
; query 6: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x416 (or false false false)))
(let (($x1380 (not $x416)))
(and $x1380 (or $x416 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 7: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x59 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x1532 (or false false (or $x59))))
(and (not $x1532) (or $x1532 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x1750 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x416 (or false false false)))
(let (($x1380 (not $x416)))
(and $x1380 (or $x416 (and (distinct ?x1750 ?x1750) true)))))))
(check-sat)
; query 9: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x356 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x416 (or false false false)))
(let (($x1380 (not $x416)))
(and $x1380 (or $x416 (and (distinct ?x356 ?x356) true)))))))
(check-sat)
; query 10: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x53 (or false false)))
(and (not $x53) (or $x53 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true)))))
(check-sat)
; query 11: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x105 ((_ sign_extend 16) in.1_16)))
(let ((?x229 (bvadd ?x105 (_ bv10 32))))
(let (($x1323 (and (distinct (bvadd ((_ sign_extend 1) ?x105) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x229)) true)))
(let (($x53 (or false false)))
(let (($x679 (or $x53 false (or $x1323))))
(and (not $x679) (or $x679 (and (distinct ?x229 ?x229) true)))))))))
(check-sat)
; query 12: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x105 ((_ sign_extend 16) in.1_16)))
(let ((?x229 (bvadd ?x105 (_ bv10 32))))
(let ((?x176 ((_ extract 15 0) ?x229)))
(let (($x1323 (and (distinct (bvadd ((_ sign_extend 1) ?x105) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x229)) true)))
(let (($x53 (or false false)))
(let (($x679 (or $x53 false (or $x1323))))
(let (($x372 (or $x679 false)))
(and (not $x372) (or $x372 (and (distinct ?x176 ?x176) true)))))))))))
(check-sat)
; query 13: function matrix_sum, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x1095 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x416 (or false false false)))
(let (($x1380 (not $x416)))
(and $x1380 (or $x416 (and (distinct ?x1095 ?x1095) true)))))))
(check-sat)
; query 14: function matrix_sum, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x1095 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let ((?x382 ((_ zero_extend 63) ?x1095)))
(let (($x416 (or false false false)))
(let (($x13 (or $x416 false)))
(and (not $x13) (or $x13 (and (distinct ?x382 ?x382) true))))))))
(check-sat)
; query 15: function matrix_sum, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x1095 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x311 (= (_ bv1 1) ?x1095)))
(let ((?x185 (ite $x311 (_ bv1 32) (_ bv0 32))))
(let (($x416 (or false false false)))
(let (($x17 (or $x416 (ite $x311 false false))))
(and (not $x17) (or $x17 (and (distinct ?x185 ?x185) true)))))))))
(check-sat)
; query 16: function matrix_sum, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x53 (or false false)))
(and (not $x53) (or $x53 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true)))))
(check-sat)
; query 17: function matrix_sum, block 22, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x1095 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x311 (= (_ bv1 1) ?x1095)))
(let ((?x185 (ite $x311 (_ bv1 32) (_ bv0 32))))
(let ((?x105 ((_ sign_extend 16) in.1_16)))
(let ((?x1813 (bvadd ?x105 ?x185)))
(let (($x641 (and (distinct (bvadd ((_ sign_extend 1) ?x105) ((_ sign_extend 1) ?x185)) ((_ sign_extend 1) ?x1813)) true)))
(let (($x416 (or false false false)))
(let (($x17 (or $x416 (ite $x311 false false))))
(let (($x53 (or false false)))
(let (($x744 (or $x53 $x17 (or $x641))))
(and (not $x744) (or $x744 (and (distinct ?x1813 ?x1813) true))))))))))))))
(check-sat)
; query 18: function matrix_sum, block 22, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x1095 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x311 (= (_ bv1 1) ?x1095)))
(let ((?x185 (ite $x311 (_ bv1 32) (_ bv0 32))))
(let ((?x105 ((_ sign_extend 16) in.1_16)))
(let ((?x1813 (bvadd ?x105 ?x185)))
(let ((?x1814 ((_ extract 15 0) ?x1813)))
(let (($x641 (and (distinct (bvadd ((_ sign_extend 1) ?x105) ((_ sign_extend 1) ?x185)) ((_ sign_extend 1) ?x1813)) true)))
(let (($x416 (or false false false)))
(let (($x17 (or $x416 (ite $x311 false false))))
(let (($x53 (or false false)))
(let (($x744 (or $x53 $x17 (or $x641))))
(let (($x320 (or $x744 false)))
(and (not $x320) (or $x320 (and (distinct ?x1814 ?x1814) true))))))))))))))))
(check-sat)
