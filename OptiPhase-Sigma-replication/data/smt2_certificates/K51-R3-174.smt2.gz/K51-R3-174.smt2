; OptiPhase-Sigma refinement certificate for sweep K51-R3-174
; query 0: function check, block 115, name %116
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x813 (and (distinct (ite (= (_ bv0 32) in0_32) (_ bv1 1) (_ bv0 1)) (ite (= (_ bv13 32) in0_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x652 (or false false false)))
(let (($x1042 (not $x652)))
(and $x1042 (or $x652 $x813))))))
(check-sat)
; query 1: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x20 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x652 (or false false false)))
(let (($x1042 (not $x652)))
(and $x1042 (or $x652 (and (distinct ?x20 ?x20) true)))))))
(check-sat)
; query 2: function set1d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x534 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x652 (or false false false)))
(let (($x1042 (not $x652)))
(and $x1042 (or $x652 (and (distinct ?x534 ?x534) true)))))))
(check-sat)
; query 3: function set1ds, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x1590 (ite (= (_ bv4294967295 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x652 (or false false false)))
(let (($x1042 (not $x652)))
(and $x1042 (or $x652 (and (distinct ?x1590 ?x1590) true)))))))
(check-sat)
; query 4: function set2d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x534 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x652 (or false false false)))
(let (($x1042 (not $x652)))
(and $x1042 (or $x652 (and (distinct ?x534 ?x534) true)))))))
(check-sat)
