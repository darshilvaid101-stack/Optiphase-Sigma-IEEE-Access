; OptiPhase-Sigma refinement certificate for sweep K48-R3-127
; query 0: function Decoding_of_the_coded_Log_Area_Ratios, block 107, name %108
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in104_64 () (_ BitVec 64))
(assert
 (let ((?x618 (ite (bvslt (_ bv0 64) in104_64) (_ bv1 1) (_ bv0 1))))
(let (($x46 (or false false false)))
(let (($x30 (not $x46)))
(and $x30 (or $x46 (and (distinct ?x618 ?x618) true)))))))
(check-sat)
; query 1: function Decoding_of_the_coded_Log_Area_Ratios, block 107, name %109
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in104_64 () (_ BitVec 64))
(assert
 (let (($x1602 (and (distinct ((_ zero_extend 63) (ite (bvslt (_ bv0 64) in104_64) (_ bv1 1) (_ bv0 1))) (ite (= (_ bv1 1) (ite (bvslt (_ bv0 64) in104_64) (_ bv1 1) (_ bv0 1))) (_ bv32767 64) (_ bv18446744073709518848 64))) true)))
(let (($x46 (or false false false)))
(let (($x79 (or $x46 (ite (= (_ bv1 1) (ite (bvslt (_ bv0 64) in104_64) (_ bv1 1) (_ bv0 1))) false false))))
(and (not (or $x46 false)) (or $x79 $x1602))))))
(check-sat)
; query 2: function Decoding_of_the_coded_Log_Area_Ratios, block 219, name %220
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in216_64 () (_ BitVec 64))
(assert
 (let (($x29 (and (distinct (ite (bvsge (_ bv18446744073709518848 64) in216_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv0 64) in216_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x46 (or false false false)))
(let (($x30 (not $x46)))
(and $x30 (or $x46 $x29))))))
(check-sat)
; query 3: function gsm_L_add, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let (($x104 (and (distinct (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv18446744073709551615 64) in1_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x46 (or false false false)))
(let (($x30 (not $x46)))
(and $x30 (or $x46 $x104))))))
(check-sat)
; query 4: function gsm_L_add, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x34 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvadd in0_64 in1_64))) true)))
(let (($x952 (or false false (or $x34))))
(let (($x565 (or $x952 (and (distinct (bvadd in0_64 in1_64) (bvadd in0_64 in1_64)) true))))
(and (not $x952) $x565)))))
(check-sat)
; query 5: function gsm_L_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x250 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x46 (or false false false)))
(let (($x30 (not $x46)))
(and $x30 (or $x46 (and (distinct ?x250 ?x250) true)))))))
(check-sat)
; query 6: function gsm_L_asl, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x44 (and (distinct (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvsgt (_ bv4294967265 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x46 (or false false false)))
(let (($x30 (not $x46)))
(and $x30 (or $x46 $x44))))))
(check-sat)
; query 7: function gsm_L_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x383 (and (distinct (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv31 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x46 (or false false false)))
(let (($x30 (not $x46)))
(and $x30 (or $x46 $x383))))))
(check-sat)
; query 8: function gsm_L_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x383 (and (distinct (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv31 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x46 (or false false false)))
(let (($x30 (not $x46)))
(and $x30 (or $x46 $x383))))))
(check-sat)
; query 9: function gsm_L_sub, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1503 (bvsub in0_64 in1_64)))
(let (($x101 (and (distinct ?x1503 ?x1503) true)))
(let (($x80 (and (distinct (bvsub ((_ zero_extend 1) in0_64) ((_ zero_extend 1) in1_64)) ((_ zero_extend 1) ?x1503)) true)))
(let (($x40 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) ?x1503)) true)))
(let (($x343 (or false false (or $x40))))
(let (($x94 (not $x343)))
(and $x94 (or (or false false (or $x80)) $x101)))))))))
(check-sat)
; query 10: function gsm_L_sub, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let (($x104 (and (distinct (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv18446744073709551615 64) in1_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x46 (or false false false)))
(let (($x30 (not $x46)))
(and $x30 (or $x46 $x104))))))
(check-sat)
; query 11: function gsm_L_sub, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1503 (bvsub in0_64 in1_64)))
(let (($x101 (and (distinct ?x1503 ?x1503) true)))
(let (($x40 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) ?x1503)) true)))
(let (($x343 (or false false (or $x40))))
(let (($x94 (not $x343)))
(and $x94 (or $x343 $x101))))))))
(check-sat)
; query 12: function gsm_L_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x217 (and (distinct (ite (bvsle (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv18446744073709551615 64) in0_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x46 (or false false false)))
(let (($x30 (not $x46)))
(and $x30 (or $x46 $x217))))))
(check-sat)
; query 13: function gsm_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_64 () (_ BitVec 64))
(assert
 (let ((?x307 (ite (bvslt (_ bv32767 64) in5_64) (_ bv1 1) (_ bv0 1))))
(let (($x46 (or false false false)))
(let (($x30 (not $x46)))
(and $x30 (or $x46 (and (distinct ?x307 ?x307) true)))))))
(check-sat)
; query 14: function gsm_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x1193 (or false false)))
(let (($x49 (not $x1193)))
(and $x49 (or $x1193 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 15: function gsm_add, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x1193 (or false false)))
(let (($x49 (not $x1193)))
(and $x49 (or $x1193 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 16: function gsm_add, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x540 ((_ sign_extend 48) in1_16)))
(let ((?x10 ((_ sign_extend 48) in0_16)))
(let ((?x69 (bvadd ?x10 ?x540)))
(let (($x54 (and (distinct (bvadd ((_ sign_extend 1) ?x10) ((_ sign_extend 1) ?x540)) ((_ sign_extend 1) ?x69)) true)))
(let (($x1193 (or false false)))
(let (($x501 (or $x1193 $x1193 (or $x54))))
(and (not $x501) (or $x501 (and (distinct ?x69 ?x69) true))))))))))
(check-sat)
; query 17: function gsm_add, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x27 (ite (bvsgt (_ bv18446744073709518848 64) (bvadd ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x540 ((_ sign_extend 48) in1_16)))
(let ((?x178 ((_ sign_extend 1) ?x540)))
(let ((?x10 ((_ sign_extend 48) in0_16)))
(let ((?x50 ((_ sign_extend 1) ?x10)))
(let (($x1193 (or false false)))
(let (($x501 (or $x1193 $x1193 (or (and (distinct (bvadd ?x50 ?x178) ((_ sign_extend 1) (bvadd ?x10 ?x540))) true)))))
(let (($x258 (or $x501 false false)))
(and (not $x258) (or $x258 (and (distinct ?x27 ?x27) true))))))))))))
(check-sat)
; query 18: function gsm_asl, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x122 (and (distinct (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvsgt (_ bv4294967281 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x46 (or false false false)))
(let (($x30 (not $x46)))
(and $x30 (or $x46 $x122))))))
(check-sat)
; query 19: function gsm_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x890 (and (distinct (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv15 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x46 (or false false false)))
(let (($x30 (not $x46)))
(and $x30 (or $x46 $x890))))))
(check-sat)
; query 20: function gsm_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x890 (and (distinct (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv15 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x46 (or false false false)))
(let (($x30 (not $x46)))
(and $x30 (or $x46 $x890))))))
(check-sat)
; query 21: function gsm_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_64 () (_ BitVec 64))
(assert
 (let ((?x307 (ite (bvslt (_ bv32767 64) in5_64) (_ bv1 1) (_ bv0 1))))
(let (($x46 (or false false false)))
(let (($x30 (not $x46)))
(and $x30 (or $x46 (and (distinct ?x307 ?x307) true)))))))
(check-sat)
; query 22: function gsm_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x1193 (or false false)))
(let (($x49 (not $x1193)))
(and $x49 (or $x1193 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 23: function gsm_sub, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x1193 (or false false)))
(let (($x49 (not $x1193)))
(and $x49 (or $x1193 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 24: function gsm_sub, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x540 ((_ sign_extend 48) in1_16)))
(let ((?x10 ((_ sign_extend 48) in0_16)))
(let ((?x1448 (bvsub ?x10 ?x540)))
(let (($x1924 (and (distinct (bvsub ((_ sign_extend 1) ?x10) ((_ sign_extend 1) ?x540)) ((_ sign_extend 1) ?x1448)) true)))
(let (($x1193 (or false false)))
(let (($x631 (or $x1193 $x1193 (or $x1924))))
(and (not $x631) (or $x631 (and (distinct ?x1448 ?x1448) true))))))))))
(check-sat)
; query 25: function gsm_sub, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x983 (ite (bvsgt (_ bv18446744073709518848 64) (bvsub ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x540 ((_ sign_extend 48) in1_16)))
(let ((?x178 ((_ sign_extend 1) ?x540)))
(let ((?x10 ((_ sign_extend 48) in0_16)))
(let ((?x50 ((_ sign_extend 1) ?x10)))
(let (($x1193 (or false false)))
(let (($x631 (or $x1193 $x1193 (or (and (distinct (bvsub ?x50 ?x178) ((_ sign_extend 1) (bvsub ?x10 ?x540))) true)))))
(let (($x1607 (or $x631 false false)))
(and (not $x1607) (or $x1607 (and (distinct ?x983 ?x983) true))))))))))))
(check-sat)
