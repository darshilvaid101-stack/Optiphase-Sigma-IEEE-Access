; OptiPhase-Sigma refinement certificate for sweep K21-R3-291
