; OptiPhase-Sigma refinement certificate for sweep K44-R1-004
; query 0: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x198 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x27 (or false false false)))
(let (($x121 (not $x27)))
(and $x121 (or $x27 (and (distinct ?x198 ?x198) true)))))))
(check-sat)
; query 1: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x79 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x27 (or false false false)))
(let (($x121 (not $x27)))
(and $x121 (or $x27 (and (distinct ?x79 ?x79) true)))))))
(check-sat)
