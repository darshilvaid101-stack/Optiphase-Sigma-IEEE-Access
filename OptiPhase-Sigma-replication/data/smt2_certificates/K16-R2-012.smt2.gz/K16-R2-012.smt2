; OptiPhase-Sigma refinement certificate for sweep K16-R2-012
