; OptiPhase-Sigma refinement certificate for sweep K52-R5-385
; query 0: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x862 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x72 (or false false false)))
(let (($x1272 (not $x72)))
(and $x1272 (or $x72 (and (distinct ?x862 ?x862) true)))))))
(check-sat)
; query 1: function s162, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x1288 (ite (bvslt (_ bv0 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x72 (or false false false)))
(let (($x1272 (not $x72)))
(and $x1272 (or $x72 (and (distinct ?x1288 ?x1288) true)))))))
(check-sat)
; query 2: function set1d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x339 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x72 (or false false false)))
(let (($x1272 (not $x72)))
(and $x1272 (or $x72 (and (distinct ?x339 ?x339) true)))))))
(check-sat)
; query 3: function set1ds, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x110 (ite (= (_ bv4294967295 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x72 (or false false false)))
(let (($x1272 (not $x72)))
(and $x1272 (or $x72 (and (distinct ?x110 ?x110) true)))))))
(check-sat)
; query 4: function set2d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x339 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x72 (or false false false)))
(let (($x1272 (not $x72)))
(and $x1272 (or $x72 (and (distinct ?x339 ?x339) true)))))))
(check-sat)
