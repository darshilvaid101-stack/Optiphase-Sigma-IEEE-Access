; OptiPhase-Sigma refinement certificate for sweep K49-R6-048
; query 0: function gsm_L_add, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let (($x516 (and (distinct (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv18446744073709551615 64) in1_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x141 (or false false false)))
(let (($x30 (not $x141)))
(and $x30 (or $x141 $x516))))))
(check-sat)
; query 1: function gsm_L_add, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x36 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvadd in0_64 in1_64))) true)))
(let (($x507 (or false false (or $x36))))
(let (($x5225 (or $x507 (and (distinct (bvadd in0_64 in1_64) (bvadd in0_64 in1_64)) true))))
(and (not $x507) $x5225)))))
(check-sat)
; query 2: function gsm_L_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x434 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x141 (or false false false)))
(let (($x30 (not $x141)))
(and $x30 (or $x141 (and (distinct ?x434 ?x434) true)))))))
(check-sat)
; query 3: function gsm_L_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x3177 (and (distinct (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv31 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x141 (or false false false)))
(let (($x30 (not $x141)))
(and $x30 (or $x141 $x3177))))))
(check-sat)
; query 4: function gsm_L_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x3177 (and (distinct (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv31 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x141 (or false false false)))
(let (($x30 (not $x141)))
(and $x30 (or $x141 $x3177))))))
(check-sat)
; query 5: function gsm_L_sub, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let (($x516 (and (distinct (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv18446744073709551615 64) in1_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x141 (or false false false)))
(let (($x30 (not $x141)))
(and $x30 (or $x141 $x516))))))
(check-sat)
; query 6: function gsm_L_sub, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x1926 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvsub in0_64 in1_64))) true)))
(let (($x279 (or false false (or $x1926))))
(let (($x423 (or $x279 (and (distinct (bvsub in0_64 in1_64) (bvsub in0_64 in1_64)) true))))
(and (not $x279) $x423)))))
(check-sat)
; query 7: function gsm_L_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x7 (and (distinct (ite (bvsle (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv18446744073709551615 64) in0_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x141 (or false false false)))
(let (($x30 (not $x141)))
(and $x30 (or $x141 $x7))))))
(check-sat)
; query 8: function gsm_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x404 (and (distinct (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv15 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x141 (or false false false)))
(let (($x30 (not $x141)))
(and $x30 (or $x141 $x404))))))
(check-sat)
; query 9: function gsm_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x404 (and (distinct (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv15 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x141 (or false false false)))
(let (($x30 (not $x141)))
(and $x30 (or $x141 $x404))))))
(check-sat)
