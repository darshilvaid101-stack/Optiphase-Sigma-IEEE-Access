; OptiPhase-Sigma refinement certificate for sweep K13-R5-403
