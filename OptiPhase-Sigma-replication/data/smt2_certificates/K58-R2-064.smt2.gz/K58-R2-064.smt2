; OptiPhase-Sigma refinement certificate for sweep K58-R2-064
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x2179 (or false false)))
(let (($x176 (not $x2179)))
(and $x176 (or $x2179 (and (distinct ((_ sign_extend 16) in25_16) ((_ sign_extend 16) in25_16)) true))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let ((?x53 (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))))
(let (($x2179 (or false false)))
(let (($x132 (or $x2179 false false)))
(let (($x168 (not $x132)))
(and $x168 (or $x132 (and (distinct ?x53 ?x53) true))))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x2179 (or false false)))
(let (($x176 (not $x2179)))
(and $x176 (or $x2179 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x134 ((_ sign_extend 16) in3_16)))
(let ((?x451 (bvand ?x134 (_ bv127 32))))
(let (($x2179 (or false false)))
(let (($x132 (or $x2179 false false)))
(let (($x168 (not $x132)))
(and $x168 (or $x132 (and (distinct ?x451 ?x451) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x134 ((_ sign_extend 16) in3_16)))
(let ((?x451 (bvand ?x134 (_ bv127 32))))
(let ((?x131 ((_ extract 15 0) ?x451)))
(let (($x2179 (or false false)))
(let (($x132 (or $x2179 false false)))
(let (($x2177 (or $x132 false)))
(and (not $x2177) (or $x2177 (and (distinct ?x131 ?x131) true))))))))))
(check-sat)
; query 5: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x2179 (or false false)))
(let (($x176 (not $x2179)))
(and $x176 (or $x2179 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 6: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x3124 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x2179 (or false false)))
(let (($x132 (or $x2179 false false)))
(let (($x168 (not $x132)))
(and $x168 (or $x132 (and (distinct ?x3124 ?x3124) true))))))))
(check-sat)
; query 7: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x283 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x22 (or false false false)))
(let (($x229 (not $x22)))
(and $x229 (or $x22 (and (distinct ?x283 ?x283) true)))))))
(check-sat)
; query 8: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x22 (or false false false)))
(let (($x229 (not $x22)))
(and $x229 (or $x22 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 9: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x226 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x22 (or false false false)))
(let (($x229 (not $x22)))
(and $x229 (or $x22 (and (distinct ?x226 ?x226) true)))))))
(check-sat)
