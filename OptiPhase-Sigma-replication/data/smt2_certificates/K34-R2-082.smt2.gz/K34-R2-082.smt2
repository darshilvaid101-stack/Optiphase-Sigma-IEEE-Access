; OptiPhase-Sigma refinement certificate for sweep K34-R2-082
; query 0: function corner_draw, block 11, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x171 (ite (= (_ bv0 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x62 (or false false false)))
(let (($x249 (not $x62)))
(and $x249 (or $x62 (and (distinct ?x171 ?x171) true)))))))
(check-sat)
; query 1: function edge_draw, block 39, name %40
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x18 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x22 (or false false (or $x18))))
(and (not $x22) (or $x22 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function edge_draw, block 57, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x12 (and (distinct (bvadd ((_ sign_extend 1) in.12_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.12_32 (_ bv1 32)))) true)))
(let (($x34 (or false false (or $x12))))
(and (not $x34) (or $x34 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 3: function edge_draw, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let ((?x110 (ite (= (_ bv0 32) in4_32) (_ bv1 1) (_ bv0 1))))
(let (($x62 (or false false false)))
(let (($x249 (not $x62)))
(and $x249 (or $x62 (and (distinct ?x110 ?x110) true)))))))
(check-sat)
; query 4: function enlarge, block 106, name %107
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x127 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x173 (or false false (or $x127))))
(and (not $x173) (or $x173 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 5: function enlarge, block 158, name %159
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x19 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x79 (or false false (or $x19))))
(and (not $x79) (or $x79 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 6: function enlarge, block 161, name %162
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let (($x42 (and (distinct (bvadd ((_ sign_extend 1) in.2_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.2_32 (_ bv1 32)))) true)))
(let (($x133 (or false false (or $x42))))
(and (not $x133) (or $x133 (and (distinct (bvadd in.2_32 (_ bv1 32)) (bvadd in.2_32 (_ bv1 32))) true))))))
(check-sat)
; query 7: function enlarge, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x18 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x22 (or false false (or $x18))))
(and (not $x22) (or $x22 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function getint, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x130 (ite (bvsle (_ bv48 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x62 (or false false false)))
(let (($x249 (not $x62)))
(and $x249 (or $x62 (and (distinct ?x130 ?x130) true)))))))
(check-sat)
; query 9: function getint, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x166 (ite (bvsge (_ bv57 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x62 (or false false false)))
(let (($x249 (not $x62)))
(and $x249 (or $x62 (and (distinct ?x166 ?x166) true)))))))
(check-sat)
; query 10: function getint, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in26_32 () (_ BitVec 32))
(assert
 (let ((?x174 (ite (bvsgt (_ bv48 32) in26_32) (_ bv1 1) (_ bv0 1))))
(let (($x62 (or false false false)))
(let (($x249 (not $x62)))
(and $x249 (or $x62 (and (distinct ?x174 ?x174) true)))))))
(check-sat)
; query 11: function getint, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in26_32 () (_ BitVec 32))
(assert
 (let ((?x96 (ite (bvslt (_ bv57 32) in26_32) (_ bv1 1) (_ bv0 1))))
(let (($x62 (or false false false)))
(let (($x249 (not $x62)))
(and $x249 (or $x62 (and (distinct ?x96 ?x96) true)))))))
(check-sat)
; query 12: function getint, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x15 (ite (= (_ bv4294967295 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x62 (or false false false)))
(let (($x249 (not $x62)))
(and $x249 (or $x62 (and (distinct ?x15 ?x15) true)))))))
(check-sat)
; query 13: function int_to_uchar, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_32 () (_ BitVec 32))
(assert
 (let (($x50 (and (distinct (bvadd ((_ sign_extend 1) in.03_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.03_32 (_ bv1 32)))) true)))
(let (($x46 (or false false (or $x50))))
(and (not $x46) (or $x46 (and (distinct (bvadd in.03_32 (_ bv1 32)) (bvadd in.03_32 (_ bv1 32))) true))))))
(check-sat)
; query 14: function int_to_uchar, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.14_32 () (_ BitVec 32))
(assert
 (let (($x111 (and (distinct (bvadd ((_ sign_extend 1) in.14_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.14_32 (_ bv1 32)))) true)))
(let (($x175 (or false false (or $x111))))
(and (not $x175) (or $x175 (and (distinct (bvadd in.14_32 (_ bv1 32)) (bvadd in.14_32 (_ bv1 32))) true))))))
(check-sat)
; query 15: function main, block 129, name %130
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.011.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x138 (ite (and (distinct (_ bv0 32) in.011.lcssa_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x62 (or false false false)))
(let (($x249 (not $x62)))
(and $x249 (or $x62 (and (distinct ?x138 ?x138) true)))))))
(check-sat)
; query 16: function main, block 160, name %161
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x97 (ite (and (distinct (_ bv0 32) in.01.lcssa_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x62 (or false false false)))
(let (($x249 (not $x62)))
(and $x249 (or $x62 (and (distinct ?x97 ?x97) true)))))))
(check-sat)
; query 17: function main, block 35, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x39 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x28 (or false false (or $x39))))
(and (not $x28) (or $x28 (and (distinct (bvadd in.020_32 (_ bv1 32)) (bvadd in.020_32 (_ bv1 32))) true))))))
(check-sat)
; query 18: function main, block 35, name %37
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let ((?x23 (ite (bvsge (bvadd in.020_32 (_ bv1 32)) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x39 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x28 (or false false (or $x39))))
(let (($x60 (or $x28 false false)))
(and (not $x60) (or $x60 (and (distinct ?x23 ?x23) true))))))))
(check-sat)
; query 19: function main, block 49, name %50
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x39 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x28 (or false false (or $x39))))
(and (not $x28) (or $x28 (and (distinct (bvadd in.020_32 (_ bv1 32)) (bvadd in.020_32 (_ bv1 32))) true))))))
(check-sat)
; query 20: function main, block 49, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let ((?x23 (ite (bvsge (bvadd in.020_32 (_ bv1 32)) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x39 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x28 (or false false (or $x39))))
(let (($x60 (or $x28 false false)))
(and (not $x60) (or $x60 (and (distinct ?x23 ?x23) true))))))))
(check-sat)
; query 21: function main, block 66, name %67
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x106 (ite (= (_ bv0 32) in.0.lcssa_32) (_ bv1 1) (_ bv0 1))))
(let (($x62 (or false false false)))
(let (($x249 (not $x62)))
(and $x249 (or $x62 (and (distinct ?x106 ?x106) true)))))))
(check-sat)
; query 22: function main, block 84, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.07.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x180 (ite (and (distinct (_ bv0 32) in.07.lcssa_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x62 (or false false false)))
(let (($x249 (not $x62)))
(and $x249 (or $x62 (and (distinct ?x180 ?x180) true)))))))
(check-sat)
; query 23: function median, block 103, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x19 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x79 (or false false (or $x19))))
(and (not $x79) (or $x79 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 24: function median, block 106, name %107
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x18 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x22 (or false false (or $x18))))
(and (not $x22) (or $x22 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 25: function setup_brightness_lut, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x18 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x22 (or false false (or $x18))))
(and (not $x22) (or $x22 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 26: function susan_corners, block 1066, name %1067
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x19 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x79 (or false false (or $x19))))
(and (not $x79) (or $x79 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 27: function susan_corners, block 1069, name %1070
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x18 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x22 (or false false (or $x18))))
(and (not $x22) (or $x22 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 28: function susan_corners, block 1549, name %1550
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x127 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x173 (or false false (or $x127))))
(and (not $x173) (or $x173 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 29: function susan_corners, block 1552, name %1553
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x12 (and (distinct (bvadd ((_ sign_extend 1) in.12_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.12_32 (_ bv1 32)))) true)))
(let (($x34 (or false false (or $x12))))
(and (not $x34) (or $x34 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 30: function susan_corners, block 845, name %846
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in839_32 () (_ BitVec 32))
(declare-fun in840_32 () (_ BitVec 32))
(assert
 (let ((?x385 (ite (bvslt in840_32 in839_32) (_ bv1 1) (_ bv0 1))))
(let (($x62 (or false false false)))
(let (($x249 (not $x62)))
(and $x249 (or $x62 (and (distinct ?x385 ?x385) true)))))))
(check-sat)
; query 31: function susan_corners_quick, block 1469, name %1470
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x127 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x173 (or false false (or $x127))))
(and (not $x173) (or $x173 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 32: function susan_corners_quick, block 1472, name %1473
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x12 (and (distinct (bvadd ((_ sign_extend 1) in.12_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.12_32 (_ bv1 32)))) true)))
(let (($x34 (or false false (or $x12))))
(and (not $x34) (or $x34 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 33: function susan_corners_quick, block 433, name %434
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x19 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x79 (or false false (or $x19))))
(and (not $x79) (or $x79 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 34: function susan_corners_quick, block 436, name %437
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x18 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x22 (or false false (or $x18))))
(and (not $x22) (or $x22 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 35: function susan_edges, block 1432, name %1433
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1417_32 () (_ BitVec 32))
(assert
 (let ((?x348 (ite (bvslt (_ bv0 32) in1417_32) (_ bv1 1) (_ bv0 1))))
(let (($x62 (or false false false)))
(let (($x249 (not $x62)))
(and $x249 (or $x62 (and (distinct ?x348 ?x348) true)))))))
(check-sat)
; query 36: function susan_edges, block 1486, name %1487
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.116_32 () (_ BitVec 32))
(assert
 (let (($x400 (and (distinct (bvadd ((_ sign_extend 1) in.116_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.116_32 (_ bv1 32)))) true)))
(let (($x424 (or false false (or $x400))))
(and (not $x424) (or $x424 (and (distinct (bvadd in.116_32 (_ bv1 32)) (bvadd in.116_32 (_ bv1 32))) true))))))
(check-sat)
; query 37: function susan_edges, block 1489, name %1490
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.114_32 () (_ BitVec 32))
(assert
 (let (($x798 (and (distinct (bvadd ((_ sign_extend 1) in.114_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.114_32 (_ bv1 32)))) true)))
(let (($x880 (or false false (or $x798))))
(and (not $x880) (or $x880 (and (distinct (bvadd in.114_32 (_ bv1 32)) (bvadd in.114_32 (_ bv1 32))) true))))))
(check-sat)
; query 38: function susan_edges, block 379, name %380
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.015_32 () (_ BitVec 32))
(assert
 (let (($x786 (and (distinct (bvadd ((_ sign_extend 1) in.015_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.015_32 (_ bv1 32)))) true)))
(let (($x304 (or false false (or $x786))))
(and (not $x304) (or $x304 (and (distinct (bvadd in.015_32 (_ bv1 32)) (bvadd in.015_32 (_ bv1 32))) true))))))
(check-sat)
; query 39: function susan_edges, block 382, name %383
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.013_32 () (_ BitVec 32))
(assert
 (let (($x485 (and (distinct (bvadd ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.013_32 (_ bv1 32)))) true)))
(let (($x576 (or false false (or $x485))))
(and (not $x576) (or $x576 (and (distinct (bvadd in.013_32 (_ bv1 32)) (bvadd in.013_32 (_ bv1 32))) true))))))
(check-sat)
; query 40: function susan_edges, block 850, name %851
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in834_32 () (_ BitVec 32))
(assert
 (let ((?x643 (ite (= (_ bv0 32) in834_32) (_ bv1 1) (_ bv0 1))))
(let (($x62 (or false false false)))
(let (($x249 (not $x62)))
(and $x249 (or $x62 (and (distinct ?x643 ?x643) true)))))))
(check-sat)
; query 41: function susan_edges, block 870, name %871
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x926 (ite (bvslt (_ bv0 32) in.0_32) (_ bv1 1) (_ bv0 1))))
(let (($x62 (or false false false)))
(let (($x249 (not $x62)))
(and $x249 (or $x62 (and (distinct ?x926 ?x926) true)))))))
(check-sat)
; query 42: function susan_edges_small, block 119, name %120
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.09_32 () (_ BitVec 32))
(assert
 (let (($x760 (and (distinct (bvadd ((_ sign_extend 1) in.09_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.09_32 (_ bv1 32)))) true)))
(let (($x799 (or false false (or $x760))))
(and (not $x799) (or $x799 (and (distinct (bvadd in.09_32 (_ bv1 32)) (bvadd in.09_32 (_ bv1 32))) true))))))
(check-sat)
; query 43: function susan_edges_small, block 122, name %123
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.07_32 () (_ BitVec 32))
(assert
 (let (($x316 (and (distinct (bvadd ((_ sign_extend 1) in.07_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.07_32 (_ bv1 32)))) true)))
(let (($x197 (or false false (or $x316))))
(and (not $x197) (or $x197 (and (distinct (bvadd in.07_32 (_ bv1 32)) (bvadd in.07_32 (_ bv1 32))) true))))))
(check-sat)
; query 44: function susan_edges_small, block 258, name %259
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in243_32 () (_ BitVec 32))
(assert
 (let ((?x676 (ite (= (_ bv0 32) in243_32) (_ bv1 1) (_ bv0 1))))
(let (($x62 (or false false false)))
(let (($x249 (not $x62)))
(and $x249 (or $x62 (and (distinct ?x676 ?x676) true)))))))
(check-sat)
; query 45: function susan_edges_small, block 278, name %279
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x926 (ite (bvslt (_ bv0 32) in.0_32) (_ bv1 1) (_ bv0 1))))
(let (($x62 (or false false false)))
(let (($x249 (not $x62)))
(and $x249 (or $x62 (and (distinct ?x926 ?x926) true)))))))
(check-sat)
; query 46: function susan_edges_small, block 426, name %427
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in411_32 () (_ BitVec 32))
(assert
 (let ((?x224 (ite (bvslt (_ bv0 32) in411_32) (_ bv1 1) (_ bv0 1))))
(let (($x62 (or false false false)))
(let (($x249 (not $x62)))
(and $x249 (or $x62 (and (distinct ?x224 ?x224) true)))))))
(check-sat)
; query 47: function susan_edges_small, block 458, name %459
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.110_32 () (_ BitVec 32))
(assert
 (let (($x736 (and (distinct (bvadd ((_ sign_extend 1) in.110_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.110_32 (_ bv1 32)))) true)))
(let (($x621 (or false false (or $x736))))
(and (not $x621) (or $x621 (and (distinct (bvadd in.110_32 (_ bv1 32)) (bvadd in.110_32 (_ bv1 32))) true))))))
(check-sat)
; query 48: function susan_edges_small, block 461, name %462
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.18_32 () (_ BitVec 32))
(assert
 (let (($x351 (and (distinct (bvadd ((_ sign_extend 1) in.18_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.18_32 (_ bv1 32)))) true)))
(let (($x690 (or false false (or $x351))))
(and (not $x690) (or $x690 (and (distinct (bvadd in.18_32 (_ bv1 32)) (bvadd in.18_32 (_ bv1 32))) true))))))
(check-sat)
; query 49: function susan_principle, block 378, name %379
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x19 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x79 (or false false (or $x19))))
(and (not $x79) (or $x79 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 50: function susan_principle, block 381, name %382
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x18 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x22 (or false false (or $x18))))
(and (not $x22) (or $x22 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 51: function susan_principle_small, block 118, name %119
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x19 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x79 (or false false (or $x19))))
(and (not $x79) (or $x79 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 52: function susan_principle_small, block 121, name %122
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x18 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x22 (or false false (or $x18))))
(and (not $x22) (or $x22 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 53: function susan_smoothing, block 123, name %124
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.09_32 () (_ BitVec 32))
(assert
 (let (($x666 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in.09_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in.09_32))) true)))
(let (($x802 (or false false (or $x666))))
(and (not $x802) (or $x802 (and (distinct (bvsub (_ bv0 32) in.09_32) (bvsub (_ bv0 32) in.09_32)) true))))))
(check-sat)
; query 54: function susan_smoothing, block 143, name %144
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.016_32 () (_ BitVec 32))
(assert
 (let (($x336 (and (distinct (bvadd ((_ sign_extend 1) in.016_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.016_32 (_ bv1 32)))) true)))
(let (($x483 (or false false (or $x336))))
(and (not $x483) (or $x483 (and (distinct (bvadd in.016_32 (_ bv1 32)) (bvadd in.016_32 (_ bv1 32))) true))))))
(check-sat)
; query 55: function susan_smoothing, block 148, name %149
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.017_32 () (_ BitVec 32))
(assert
 (let (($x1005 (and (distinct (bvadd ((_ sign_extend 1) in.017_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.017_32 (_ bv1 32)))) true)))
(let (($x272 (or false false (or $x1005))))
(and (not $x272) (or $x272 (and (distinct (bvadd in.017_32 (_ bv1 32)) (bvadd in.017_32 (_ bv1 32))) true))))))
(check-sat)
; query 56: function susan_smoothing, block 165, name %166
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.114_32 () (_ BitVec 32))
(assert
 (let (($x798 (and (distinct (bvadd ((_ sign_extend 1) in.114_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.114_32 (_ bv1 32)))) true)))
(let (($x880 (or false false (or $x798))))
(and (not $x880) (or $x880 (and (distinct (bvadd in.114_32 (_ bv1 32)) (bvadd in.114_32 (_ bv1 32))) true))))))
(check-sat)
; query 57: function susan_smoothing, block 168, name %169
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.111_32 () (_ BitVec 32))
(assert
 (let (($x768 (and (distinct (bvadd ((_ sign_extend 1) in.111_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.111_32 (_ bv1 32)))) true)))
(let (($x560 (or false false (or $x768))))
(and (not $x560) (or $x560 (and (distinct (bvadd in.111_32 (_ bv1 32)) (bvadd in.111_32 (_ bv1 32))) true))))))
(check-sat)
; query 58: function susan_smoothing, block 21, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x465 (ite (= (_ bv0 32) (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x62 (or false false false)))
(let (($x249 (not $x62)))
(and $x249 (or $x62 (and (distinct ?x465 ?x465) true)))))))
(check-sat)
; query 59: function susan_smoothing, block 319, name %320
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.215_32 () (_ BitVec 32))
(assert
 (let (($x810 (and (distinct (bvadd ((_ sign_extend 1) in.215_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.215_32 (_ bv1 32)))) true)))
(let (($x687 (or false false (or $x810))))
(and (not $x687) (or $x687 (and (distinct (bvadd in.215_32 (_ bv1 32)) (bvadd in.215_32 (_ bv1 32))) true))))))
(check-sat)
; query 60: function susan_smoothing, block 322, name %323
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.212_32 () (_ BitVec 32))
(assert
 (let (($x345 (and (distinct (bvadd ((_ sign_extend 1) in.212_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.212_32 (_ bv1 32)))) true)))
(let (($x759 (or false false (or $x345))))
(and (not $x759) (or $x759 (and (distinct (bvadd in.212_32 (_ bv1 32)) (bvadd in.212_32 (_ bv1 32))) true))))))
(check-sat)
; query 61: function susan_smoothing, block 67, name %68
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.09_32 () (_ BitVec 32))
(assert
 (let (($x666 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in.09_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in.09_32))) true)))
(let (($x802 (or false false (or $x666))))
(and (not $x802) (or $x802 (and (distinct (bvsub (_ bv0 32) in.09_32) (bvsub (_ bv0 32) in.09_32)) true))))))
(check-sat)
; query 62: function susan_smoothing, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.013_32 () (_ BitVec 32))
(assert
 (let (($x485 (and (distinct (bvadd ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.013_32 (_ bv1 32)))) true)))
(let (($x576 (or false false (or $x485))))
(and (not $x576) (or $x576 (and (distinct (bvadd in.013_32 (_ bv1 32)) (bvadd in.013_32 (_ bv1 32))) true))))))
(check-sat)
; query 63: function susan_smoothing, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.010_32 () (_ BitVec 32))
(assert
 (let (($x645 (and (distinct (bvadd ((_ sign_extend 1) in.010_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.010_32 (_ bv1 32)))) true)))
(let (($x828 (or false false (or $x645))))
(and (not $x828) (or $x828 (and (distinct (bvadd in.010_32 (_ bv1 32)) (bvadd in.010_32 (_ bv1 32))) true))))))
(check-sat)
; query 64: function susan_thin, block 100, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in93_32 () (_ BitVec 32))
(assert
 (let ((?x403 (ite (= (_ bv1 32) in93_32) (_ bv1 1) (_ bv0 1))))
(let (($x62 (or false false false)))
(let (($x249 (not $x62)))
(and $x249 (or $x62 (and (distinct ?x403 ?x403) true)))))))
(check-sat)
; query 65: function susan_thin, block 428, name %429
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.022_32 () (_ BitVec 32))
(assert
 (let (($x404 (and (distinct (bvadd ((_ sign_extend 1) in.022_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.022_32 (_ bv1 32)))) true)))
(let (($x169 (or false false (or $x404))))
(and (not $x169) (or $x169 (and (distinct (bvadd in.022_32 (_ bv1 32)) (bvadd in.022_32 (_ bv1 32))) true))))))
(check-sat)
; query 66: function susan_thin, block 431, name %432
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.018_32 () (_ BitVec 32))
(assert
 (let (($x343 (and (distinct (bvadd ((_ sign_extend 1) in.018_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.018_32 (_ bv1 32)))) true)))
(let (($x994 (or false false (or $x343))))
(and (not $x994) (or $x994 (and (distinct (bvadd in.018_32 (_ bv1 32)) (bvadd in.018_32 (_ bv1 32))) true))))))
(check-sat)
; query 67: function susan_thin, block 469, name %470
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.235.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x245 (bvadd in.235.lcssa_32 in.235.lcssa_32)))
(let ((?x626 ((_ sign_extend 1) ?x245)))
(let (($x555 (and (distinct (bvadd ((_ sign_extend 1) in.235.lcssa_32) ((_ sign_extend 1) in.235.lcssa_32)) ?x626) true)))
(let (($x691 (or false false (or $x555))))
(and (not $x691) (or $x691 (and (distinct ?x245 ?x245) true))))))))
(check-sat)
; query 68: function susan_thin, block 469, name %471
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.228.lcssa_32 () (_ BitVec 32))
(declare-fun in.235.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x245 (bvadd in.235.lcssa_32 in.235.lcssa_32)))
(let ((?x653 (bvadd ?x245 in.228.lcssa_32)))
(let (($x542 (and (distinct (bvadd ((_ sign_extend 1) ?x245) ((_ sign_extend 1) in.228.lcssa_32)) ((_ sign_extend 1) ?x653)) true)))
(let ((?x626 ((_ sign_extend 1) ?x245)))
(let (($x555 (and (distinct (bvadd ((_ sign_extend 1) in.235.lcssa_32) ((_ sign_extend 1) in.235.lcssa_32)) ?x626) true)))
(let (($x691 (or false false (or $x555))))
(let (($x456 (or $x691 false (or $x542))))
(and (not $x456) (or $x456 (and (distinct ?x653 ?x653) true)))))))))))
(check-sat)
; query 69: function susan_thin, block 469, name %472
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.228.lcssa_32 () (_ BitVec 32))
(declare-fun in.235.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x245 (bvadd in.235.lcssa_32 in.235.lcssa_32)))
(let ((?x653 (bvadd ?x245 in.228.lcssa_32)))
(let ((?x661 (ite (bvsgt (_ bv3 32) ?x653) (_ bv1 1) (_ bv0 1))))
(let (($x542 (and (distinct (bvadd ((_ sign_extend 1) ?x245) ((_ sign_extend 1) in.228.lcssa_32)) ((_ sign_extend 1) ?x653)) true)))
(let ((?x626 ((_ sign_extend 1) ?x245)))
(let (($x555 (and (distinct (bvadd ((_ sign_extend 1) in.235.lcssa_32) ((_ sign_extend 1) in.235.lcssa_32)) ?x626) true)))
(let (($x691 (or false false (or $x555))))
(let (($x456 (or $x691 false (or $x542))))
(let (($x595 (or $x456 false false)))
(and (not $x595) (or $x595 (and (distinct ?x661 ?x661) true)))))))))))))
(check-sat)
; query 70: function susan_thin, block 473, name %474
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.235.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x253 (bvsub in.235.lcssa_32 (_ bv1 32))))
(let ((?x642 ((_ sign_extend 1) ?x253)))
(let (($x726 (and (distinct (bvsub ((_ sign_extend 1) in.235.lcssa_32) ((_ sign_extend 1) (_ bv1 32))) ?x642) true)))
(let (($x353 (or false false (or $x726))))
(and (not $x353) (or $x353 (and (distinct ?x253 ?x253) true))))))))
(check-sat)
; query 71: function susan_thin, block 473, name %475
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.235.lcssa_32 () (_ BitVec 32))
(declare-fun in.14_32 () (_ BitVec 32))
(assert
 (let ((?x253 (bvsub in.235.lcssa_32 (_ bv1 32))))
(let ((?x377 (bvadd in.14_32 ?x253)))
(let (($x487 (and (distinct (bvadd ((_ sign_extend 1) in.14_32) ((_ sign_extend 1) ?x253)) ((_ sign_extend 1) ?x377)) true)))
(let ((?x642 ((_ sign_extend 1) ?x253)))
(let (($x726 (and (distinct (bvsub ((_ sign_extend 1) in.235.lcssa_32) ((_ sign_extend 1) (_ bv1 32))) ?x642) true)))
(let (($x353 (or false false (or $x726))))
(let (($x529 (or false $x353 (or $x487))))
(and (not $x529) (or $x529 (and (distinct ?x377 ?x377) true)))))))))))
(check-sat)
; query 72: function susan_thin, block 473, name %476
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.228.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x597 (bvsub in.228.lcssa_32 (_ bv2 32))))
(let ((?x413 ((_ sign_extend 1) ?x597)))
(let (($x419 (and (distinct (bvsub ((_ sign_extend 1) in.228.lcssa_32) ((_ sign_extend 1) (_ bv2 32))) ?x413) true)))
(let (($x729 (or false false (or $x419))))
(and (not $x729) (or $x729 (and (distinct ?x597 ?x597) true))))))))
(check-sat)
; query 73: function susan_thin, block 473, name %477
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.228.lcssa_32 () (_ BitVec 32))
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x597 (bvsub in.228.lcssa_32 (_ bv2 32))))
(let ((?x890 (bvadd in.0_32 ?x597)))
(let (($x965 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) ?x597)) ((_ sign_extend 1) ?x890)) true)))
(let ((?x413 ((_ sign_extend 1) ?x597)))
(let (($x419 (and (distinct (bvsub ((_ sign_extend 1) in.228.lcssa_32) ((_ sign_extend 1) (_ bv2 32))) ?x413) true)))
(let (($x729 (or false false (or $x419))))
(let (($x474 (or false $x729 (or $x965))))
(and (not $x474) (or $x474 (and (distinct ?x890 ?x890) true)))))))))))
(check-sat)
; query 74: function susan_thin, block 473, name %478
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.235.lcssa_32 () (_ BitVec 32))
(declare-fun in.14_32 () (_ BitVec 32))
(assert
 (let ((?x391 (ite (bvsgt (_ bv4 32) (bvadd in.14_32 (bvsub in.235.lcssa_32 (_ bv1 32)))) (_ bv1 1) (_ bv0 1))))
(let ((?x253 (bvsub in.235.lcssa_32 (_ bv1 32))))
(let ((?x642 ((_ sign_extend 1) ?x253)))
(let ((?x298 ((_ sign_extend 1) in.14_32)))
(let (($x726 (and (distinct (bvsub ((_ sign_extend 1) in.235.lcssa_32) ((_ sign_extend 1) (_ bv1 32))) ?x642) true)))
(let (($x353 (or false false (or $x726))))
(let (($x529 (or false $x353 (or (and (distinct (bvadd ?x298 ?x642) ((_ sign_extend 1) (bvadd in.14_32 ?x253))) true)))))
(let (($x379 (or $x529 false false)))
(and (not $x379) (or $x379 (and (distinct ?x391 ?x391) true))))))))))))
(check-sat)
; query 75: function susan_thin, block 533, name %534
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in528_32 () (_ BitVec 32))
(declare-fun in498_32 () (_ BitVec 32))
(assert
 (let (($x62 (or false false false)))
(let (($x236 (or $x62 (and (distinct (bvor in498_32 in528_32) (bvor in498_32 in528_32)) true))))
(let (($x249 (not $x62)))
(and $x249 $x236)))))
(check-sat)
; query 76: function susan_thin, block 533, name %535
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in518_32 () (_ BitVec 32))
(declare-fun in508_32 () (_ BitVec 32))
(assert
 (let (($x62 (or false false false)))
(let (($x535 (or $x62 (and (distinct (bvor in508_32 in518_32) (bvor in508_32 in518_32)) true))))
(let (($x249 (not $x62)))
(and $x249 $x535)))))
(check-sat)
; query 77: function susan_thin, block 533, name %536
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in518_32 () (_ BitVec 32))
(declare-fun in508_32 () (_ BitVec 32))
(declare-fun in528_32 () (_ BitVec 32))
(declare-fun in498_32 () (_ BitVec 32))
(assert
 (let ((?x412 (bvor in508_32 in518_32)))
(let ((?x479 (bvor in498_32 in528_32)))
(let ((?x297 (bvand ?x479 ?x412)))
(let (($x62 (or false false false)))
(let (($x434 (or $x62 $x62 false)))
(let (($x623 (not $x434)))
(and $x623 (or $x434 (and (distinct ?x297 ?x297) true))))))))))
(check-sat)
; query 78: function susan_thin, block 533, name %537
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in518_32 () (_ BitVec 32))
(declare-fun in508_32 () (_ BitVec 32))
(declare-fun in528_32 () (_ BitVec 32))
(declare-fun in498_32 () (_ BitVec 32))
(assert
 (let ((?x412 (bvor in508_32 in518_32)))
(let ((?x479 (bvor in498_32 in528_32)))
(let ((?x297 (bvand ?x479 ?x412)))
(let ((?x395 (ite (and (distinct (_ bv0 32) ?x297) true) (_ bv1 1) (_ bv0 1))))
(let (($x62 (or false false false)))
(let (($x434 (or $x62 $x62 false)))
(let (($x182 (or $x434 false false)))
(let (($x727 (not $x182)))
(and $x727 (or $x182 (and (distinct ?x395 ?x395) true))))))))))))
(check-sat)
; query 79: function susan_thin, block 538, name %539
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in498_32 () (_ BitVec 32))
(assert
 (let ((?x416 (ite (and (distinct (_ bv0 32) in498_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x62 (or false false false)))
(let (($x249 (not $x62)))
(and $x249 (or $x62 (and (distinct ?x416 ?x416) true)))))))
(check-sat)
; query 80: function susan_thin, block 540, name %541
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in508_32 () (_ BitVec 32))
(assert
 (let ((?x644 (ite (and (distinct (_ bv0 32) in508_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x62 (or false false false)))
(let (($x249 (not $x62)))
(and $x249 (or $x62 (and (distinct ?x644 ?x644) true)))))))
(check-sat)
; query 81: function susan_thin, block 545, name %546
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in508_32 () (_ BitVec 32))
(assert
 (let ((?x644 (ite (and (distinct (_ bv0 32) in508_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x62 (or false false false)))
(let (($x249 (not $x62)))
(and $x249 (or $x62 (and (distinct ?x644 ?x644) true)))))))
(check-sat)
; query 82: function susan_thin, block 563, name %564
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.325_32 () (_ BitVec 32))
(assert
 (let ((?x218 (ite (= (_ bv0 32) in.325_32) (_ bv1 1) (_ bv0 1))))
(let (($x62 (or false false false)))
(let (($x249 (not $x62)))
(and $x249 (or $x62 (and (distinct ?x218 ?x218) true)))))))
(check-sat)
; query 83: function susan_thin, block 597, name %598
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.321_32 () (_ BitVec 32))
(assert
 (let ((?x313 (ite (= (_ bv0 32) in.321_32) (_ bv1 1) (_ bv0 1))))
(let (($x62 (or false false false)))
(let (($x249 (not $x62)))
(and $x249 (or $x62 (and (distinct ?x313 ?x313) true)))))))
(check-sat)
; query 84: function susan_thin, block 685, name %686
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in662_32 () (_ BitVec 32))
(declare-fun in680_32 () (_ BitVec 32))
(assert
 (let (($x62 (or false false false)))
(let (($x183 (or $x62 (and (distinct (bvor in680_32 in662_32) (bvor in680_32 in662_32)) true))))
(let (($x249 (not $x62)))
(and $x249 $x183)))))
(check-sat)
; query 85: function susan_thin, block 685, name %687
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in671_32 () (_ BitVec 32))
(declare-fun in653_32 () (_ BitVec 32))
(assert
 (let (($x62 (or false false false)))
(let (($x1027 (or $x62 (and (distinct (bvor in653_32 in671_32) (bvor in653_32 in671_32)) true))))
(let (($x249 (not $x62)))
(and $x249 $x1027)))))
(check-sat)
; query 86: function susan_thin, block 685, name %688
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in671_32 () (_ BitVec 32))
(declare-fun in653_32 () (_ BitVec 32))
(declare-fun in662_32 () (_ BitVec 32))
(declare-fun in680_32 () (_ BitVec 32))
(assert
 (let ((?x390 (bvor in653_32 in671_32)))
(let ((?x321 (bvor in680_32 in662_32)))
(let ((?x240 (bvand ?x321 ?x390)))
(let (($x62 (or false false false)))
(let (($x434 (or $x62 $x62 false)))
(let (($x623 (not $x434)))
(and $x623 (or $x434 (and (distinct ?x240 ?x240) true))))))))))
(check-sat)
; query 87: function susan_thin, block 685, name %689
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in671_32 () (_ BitVec 32))
(declare-fun in653_32 () (_ BitVec 32))
(declare-fun in662_32 () (_ BitVec 32))
(declare-fun in680_32 () (_ BitVec 32))
(assert
 (let ((?x390 (bvor in653_32 in671_32)))
(let ((?x321 (bvor in680_32 in662_32)))
(let ((?x240 (bvand ?x321 ?x390)))
(let ((?x369 (ite (and (distinct (_ bv0 32) ?x240) true) (_ bv1 1) (_ bv0 1))))
(let (($x62 (or false false false)))
(let (($x434 (or $x62 $x62 false)))
(let (($x182 (or $x434 false false)))
(let (($x727 (not $x182)))
(and $x727 (or $x182 (and (distinct ?x369 ?x369) true))))))))))))
(check-sat)
; query 88: function susan_thin, block 915, name %916
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.13_32 () (_ BitVec 32))
(assert
 (let (($x681 (and (distinct (bvadd ((_ sign_extend 1) in.13_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.13_32 (_ bv1 32)))) true)))
(let (($x201 (or false false (or $x681))))
(and (not $x201) (or $x201 (and (distinct (bvadd in.13_32 (_ bv1 32)) (bvadd in.13_32 (_ bv1 32))) true))))))
(check-sat)
; query 89: function susan_thin, block 918, name %919
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.14.lcssa_32 () (_ BitVec 32))
(assert
 (let (($x893 (and (distinct (bvadd ((_ sign_extend 1) in.14.lcssa_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.14.lcssa_32 (_ bv1 32)))) true)))
(let (($x885 (or false false (or $x893))))
(let (($x273 (or $x885 (and (distinct (bvadd in.14.lcssa_32 (_ bv1 32)) (bvadd in.14.lcssa_32 (_ bv1 32))) true))))
(and (not $x885) $x273)))))
(check-sat)
