; OptiPhase-Sigma refinement certificate for sweep K52-R3-107
; query 0: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x339 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x868 (or false false false)))
(let (($x832 (not $x868)))
(and $x832 (or $x868 (and (distinct ?x339 ?x339) true)))))))
(check-sat)
; query 1: function s162, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x1284 (ite (bvslt (_ bv0 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x868 (or false false false)))
(let (($x832 (not $x868)))
(and $x832 (or $x868 (and (distinct ?x1284 ?x1284) true)))))))
(check-sat)
