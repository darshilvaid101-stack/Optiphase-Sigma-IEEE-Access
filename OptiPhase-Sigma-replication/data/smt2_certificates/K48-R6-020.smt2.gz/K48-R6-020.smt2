; OptiPhase-Sigma refinement certificate for sweep K48-R6-020
; query 0: function APCM_inverse_quantization, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x604 (or false false)))
(let (($x56 (not $x604)))
(and $x56 (or $x604 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 1: function APCM_inverse_quantization, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x173 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x604 (or false false)))
(let (($x296 (or $x604 false false)))
(let (($x79 (not $x296)))
(and $x79 (or $x296 (and (distinct ?x173 ?x173) true))))))))
(check-sat)
; query 2: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x604 (or false false)))
(let (($x56 (not $x604)))
(and $x56 (or $x604 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 3: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1065 (ite (bvslt (_ bv15 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x604 (or false false)))
(let (($x296 (or $x604 false false)))
(let (($x79 (not $x296)))
(and $x79 (or $x296 (and (distinct ?x1065 ?x1065) true))))))))
(check-sat)
; query 4: function Decoding_of_the_coded_Log_Area_Ratios, block 170, name %171
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in167_64 () (_ BitVec 64))
(assert
 (let (($x47 (and (distinct (ite (bvsge (_ bv18446744073709518848 64) in167_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv0 64) in167_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x52 (or false false false)))
(let (($x484 (not $x52)))
(and $x484 (or $x52 $x47))))))
(check-sat)
; query 5: function Decoding_of_the_coded_Log_Area_Ratios, block 268, name %269
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in265_64 () (_ BitVec 64))
(assert
 (let (($x283 (and (distinct (ite (bvsge (_ bv18446744073709518848 64) in265_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv0 64) in265_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x52 (or false false false)))
(let (($x484 (not $x52)))
(and $x484 (or $x52 $x283))))))
(check-sat)
; query 6: function Decoding_of_the_coded_Log_Area_Ratios, block 58, name %59
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in55_64 () (_ BitVec 64))
(assert
 (let (($x36 (and (distinct (ite (bvslt (_ bv0 64) in55_64) (_ bv1 1) (_ bv0 1)) (ite (bvsge (_ bv18446744073709518848 64) in55_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x52 (or false false false)))
(let (($x484 (not $x52)))
(and $x484 (or $x52 $x36))))))
(check-sat)
; query 7: function Decoding_of_the_coded_Log_Area_Ratios, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in6_64 () (_ BitVec 64))
(assert
 (let ((?x559 (ite (bvslt (_ bv0 64) in6_64) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x484 (not $x52)))
(and $x484 (or $x52 (and (distinct ?x559 ?x559) true)))))))
(check-sat)
; query 8: function Decoding_of_the_coded_Log_Area_Ratios, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in6_64 () (_ BitVec 64))
(assert
 (let ((?x559 (ite (bvslt (_ bv0 64) in6_64) (_ bv1 1) (_ bv0 1))))
(let ((?x594 ((_ zero_extend 63) ?x559)))
(let (($x52 (or false false false)))
(let (($x1248 (or $x52 false)))
(let (($x134 (not $x1248)))
(and $x134 (or $x1248 (and (distinct ?x594 ?x594) true)))))))))
(check-sat)
; query 9: function Decoding_of_the_coded_Log_Area_Ratios, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in6_64 () (_ BitVec 64))
(assert
 (let ((?x559 (ite (bvslt (_ bv0 64) in6_64) (_ bv1 1) (_ bv0 1))))
(let (($x738 (= (_ bv1 1) ?x559)))
(let ((?x32 (ite $x738 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x52 (or false false false)))
(let (($x42 (or $x52 (ite $x738 false false))))
(and (not $x42) (or $x42 (and (distinct ?x32 ?x32) true)))))))))
(check-sat)
; query 10: function Decoding_of_the_coded_Log_Area_Ratios, block 9, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in6_64 () (_ BitVec 64))
(assert
 (let ((?x559 (ite (bvslt (_ bv0 64) in6_64) (_ bv1 1) (_ bv0 1))))
(let (($x738 (= (_ bv1 1) ?x559)))
(let ((?x32 (ite $x738 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x644 ((_ sign_extend 32) ?x32)))
(let (($x52 (or false false false)))
(let (($x42 (or $x52 (ite $x738 false false))))
(let (($x462 (or $x42 false)))
(and (not $x462) (or $x462 (and (distinct ?x644 ?x644) true)))))))))))
(check-sat)
; query 11: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x604 (or false false)))
(let (($x56 (not $x604)))
(and $x56 (or $x604 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 12: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x140 (ite (bvsgt (_ bv40 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x604 (or false false)))
(let (($x296 (or $x604 false false)))
(let (($x79 (not $x296)))
(and $x79 (or $x296 (and (distinct ?x140 ?x140) true))))))))
(check-sat)
; query 13: function RPE_grid_positioning, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x604 (or false false)))
(let (($x56 (not $x604)))
(and $x56 (or $x604 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 14: function RPE_grid_positioning, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x82 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x460 (and (distinct ?x82 ?x82) true)))
(let (($x604 (or false false)))
(let (($x322 (or false $x604 false)))
(and (not $x322) (or $x322 $x460)))))))
(check-sat)
; query 15: function Reflection_coefficients, block 174, name %175
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in171_64 () (_ BitVec 64))
(assert
 (let ((?x11 (ite (bvslt (_ bv0 64) in171_64) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x484 (not $x52)))
(and $x484 (or $x52 (and (distinct ?x11 ?x11) true)))))))
(check-sat)
; query 16: function Reflection_coefficients, block 174, name %176
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in171_64 () (_ BitVec 64))
(assert
 (let ((?x11 (ite (bvslt (_ bv0 64) in171_64) (_ bv1 1) (_ bv0 1))))
(let ((?x153 ((_ zero_extend 63) ?x11)))
(let (($x52 (or false false false)))
(let (($x1248 (or $x52 false)))
(let (($x134 (not $x1248)))
(and $x134 (or $x1248 (and (distinct ?x153 ?x153) true)))))))))
(check-sat)
; query 17: function Reflection_coefficients, block 174, name %177
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in171_64 () (_ BitVec 64))
(assert
 (let ((?x11 (ite (bvslt (_ bv0 64) in171_64) (_ bv1 1) (_ bv0 1))))
(let (($x365 (= (_ bv1 1) ?x11)))
(let ((?x226 (ite $x365 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x52 (or false false false)))
(let (($x128 (or $x52 (ite $x365 false false))))
(and (not $x128) (or $x128 (and (distinct ?x226 ?x226) true)))))))))
(check-sat)
; query 18: function Reflection_coefficients, block 174, name %178
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in171_64 () (_ BitVec 64))
(assert
 (let ((?x11 (ite (bvslt (_ bv0 64) in171_64) (_ bv1 1) (_ bv0 1))))
(let (($x365 (= (_ bv1 1) ?x11)))
(let ((?x226 (ite $x365 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x602 ((_ sign_extend 32) ?x226)))
(let (($x52 (or false false false)))
(let (($x128 (or $x52 (ite $x365 false false))))
(let (($x149 (or $x128 false)))
(and (not $x149) (or $x149 (and (distinct ?x602 ?x602) true)))))))))))
(check-sat)
; query 19: function gsm_L_add, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_64 () (_ BitVec 64))
(assert
 (let ((?x193 (bvsub (_ bv0 64) in13_64)))
(let ((?x39 ((_ sign_extend 1) ?x193)))
(let (($x456 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in13_64)) ?x39) true)))))
(and (not $x456) (or $x456 (and (distinct ?x193 ?x193) true)))))))
(check-sat)
; query 20: function gsm_L_add, block 16, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_64 () (_ BitVec 64))
(assert
 (let ((?x193 (bvsub (_ bv0 64) in13_64)))
(let ((?x23 (bvsub ?x193 (_ bv2 64))))
(let (($x1900 (and (distinct (bvsub ((_ sign_extend 1) ?x193) ((_ sign_extend 1) (_ bv2 64))) ((_ sign_extend 1) ?x23)) true)))
(let ((?x39 ((_ sign_extend 1) ?x193)))
(let (($x456 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in13_64)) ?x39) true)))))
(let (($x575 (or $x456 false (or $x1900))))
(and (not $x575) (or $x575 (and (distinct ?x23 ?x23) true))))))))))
(check-sat)
; query 21: function gsm_L_add, block 21, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1848 (ite (bvsge (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x484 (not $x52)))
(and $x484 (or $x52 (and (distinct ?x1848 ?x1848) true)))))))
(check-sat)
; query 22: function gsm_L_add, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x96 (bvadd in0_64 in1_64)))
(let (($x1685 (and (distinct ?x96 ?x96) true)))
(let (($x627 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) ?x96)) true)))
(let (($x58 (or false false (or $x627))))
(and (not $x58) (or $x58 $x1685)))))))
(check-sat)
; query 23: function gsm_L_add, block 25, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x96 (bvadd in0_64 in1_64)))
(let (($x1685 (and (distinct ?x96 ?x96) true)))
(let (($x126 (and (distinct (bvadd ((_ zero_extend 1) in0_64) ((_ zero_extend 1) in1_64)) ((_ zero_extend 1) ?x96)) true)))
(let (($x54 (or false false (or $x126))))
(let (($x52 (or false false false)))
(let (($x484 (not $x52)))
(and $x484 (or $x54 $x1685)))))))))
(check-sat)
; query 24: function gsm_L_add, block 25, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x93 (ite (bvugt (bvadd in0_64 in1_64) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x126 (and (distinct (bvadd ((_ zero_extend 1) in0_64) ((_ zero_extend 1) in1_64)) ((_ zero_extend 1) (bvadd in0_64 in1_64))) true)))
(let (($x54 (or false false (or $x126))))
(let (($x52 (or false false false)))
(let (($x206 (or $x52 false false)))
(let (($x926 (not $x206)))
(and $x926 (or (or $x54 false false) (and (distinct ?x93 ?x93) true))))))))))
(check-sat)
; query 25: function gsm_L_add, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x2059 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x484 (not $x52)))
(and $x484 (or $x52 (and (distinct ?x2059 ?x2059) true)))))))
(check-sat)
; query 26: function gsm_L_add, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x96 (bvadd in0_64 in1_64)))
(let (($x1685 (and (distinct ?x96 ?x96) true)))
(let (($x627 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) ?x96)) true)))
(let (($x58 (or false false (or $x627))))
(and (not $x58) (or $x58 $x1685)))))))
(check-sat)
; query 27: function gsm_L_add, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1629 (bvadd in0_64 (_ bv1 64))))
(let ((?x782 (bvsub (_ bv0 64) ?x1629)))
(let (($x1435 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1629)) ((_ sign_extend 1) ?x782)) true)))
(let ((?x1634 ((_ sign_extend 1) ?x1629)))
(let (($x1348 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1634) true)))))
(let (($x2063 (or false $x1348 (or $x1435))))
(and (not $x2063) (or $x2063 (and (distinct ?x782 ?x782) true))))))))))
(check-sat)
; query 28: function gsm_L_add, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x883 (bvadd in1_64 (_ bv1 64))))
(let ((?x816 ((_ sign_extend 1) ?x883)))
(let (($x1245 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x816) true)))))
(and (not $x1245) (or $x1245 (and (distinct ?x883 ?x883) true)))))))
(check-sat)
; query 29: function gsm_L_add, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x883 (bvadd in1_64 (_ bv1 64))))
(let ((?x1240 (bvsub (_ bv0 64) ?x883)))
(let (($x704 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x883)) ((_ sign_extend 1) ?x1240)) true)))
(let ((?x816 ((_ sign_extend 1) ?x883)))
(let (($x1245 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x816) true)))))
(let (($x48 (or false $x1245 (or $x704))))
(and (not $x48) (or $x48 (and (distinct ?x1240 ?x1240) true))))))))))
(check-sat)
; query 30: function gsm_L_add, block 8, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x883 (bvadd in1_64 (_ bv1 64))))
(let ((?x1240 (bvsub (_ bv0 64) ?x883)))
(let ((?x1629 (bvadd in0_64 (_ bv1 64))))
(let ((?x782 (bvsub (_ bv0 64) ?x1629)))
(let ((?x179 (bvadd ?x782 ?x1240)))
(let (($x1751 (and (distinct (bvadd ((_ zero_extend 1) ?x782) ((_ zero_extend 1) ?x1240)) ((_ zero_extend 1) ?x179)) true)))
(let (($x704 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x883)) ((_ sign_extend 1) ?x1240)) true)))
(let ((?x816 ((_ sign_extend 1) ?x883)))
(let (($x1245 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x816) true)))))
(let (($x48 (or false $x1245 (or $x704))))
(let (($x1435 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1629)) ((_ sign_extend 1) ?x782)) true)))
(let ((?x1634 ((_ sign_extend 1) ?x1629)))
(let (($x1348 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1634) true)))))
(let (($x2063 (or false $x1348 (or $x1435))))
(let (($x99 (or $x2063 $x48 (or $x1751))))
(and (not (or $x2063 $x48 false)) (or $x99 (and (distinct ?x179 ?x179) true)))))))))))))))))))
(check-sat)
; query 31: function gsm_L_add, block 8, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x883 (bvadd in1_64 (_ bv1 64))))
(let ((?x1240 (bvsub (_ bv0 64) ?x883)))
(let ((?x1629 (bvadd in0_64 (_ bv1 64))))
(let ((?x782 (bvsub (_ bv0 64) ?x1629)))
(let ((?x179 (bvadd ?x782 ?x1240)))
(let ((?x1132 (ite (bvuge ?x179 (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x1751 (and (distinct (bvadd ((_ zero_extend 1) ?x782) ((_ zero_extend 1) ?x1240)) ((_ zero_extend 1) ?x179)) true)))
(let (($x704 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x883)) ((_ sign_extend 1) ?x1240)) true)))
(let ((?x816 ((_ sign_extend 1) ?x883)))
(let (($x1245 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x816) true)))))
(let (($x48 (or false $x1245 (or $x704))))
(let (($x1435 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1629)) ((_ sign_extend 1) ?x782)) true)))
(let ((?x1634 ((_ sign_extend 1) ?x1629)))
(let (($x1348 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1634) true)))))
(let (($x2063 (or false $x1348 (or $x1435))))
(let (($x99 (or $x2063 $x48 (or $x1751))))
(and (not (or (or $x2063 $x48 false) false false)) (or (or $x99 false false) (and (distinct ?x1132 ?x1132) true))))))))))))))))))))
(check-sat)
; query 32: function gsm_L_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1629 (bvadd in0_64 (_ bv1 64))))
(let ((?x1634 ((_ sign_extend 1) ?x1629)))
(let (($x1348 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1634) true)))))
(and (not $x1348) (or $x1348 (and (distinct ?x1629 ?x1629) true)))))))
(check-sat)
; query 33: function gsm_L_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x819 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x484 (not $x52)))
(and $x484 (or $x52 (and (distinct ?x819 ?x819) true)))))))
(check-sat)
; query 34: function gsm_L_asl, block 12, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x723 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x484 (not $x52)))
(and $x484 (or $x52 (and (distinct ?x723 ?x723) true)))))))
(check-sat)
; query 35: function gsm_L_asl, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x692 (or false (or (= ((_ extract 31 31) in1_32) (_ bv1 1))))))
(let (($x604 (or false false)))
(let (($x56 (not $x604)))
(and $x56 (or $x692 (and (distinct ((_ zero_extend 32) in1_32) ((_ zero_extend 32) in1_32)) true)))))))
(check-sat)
; query 36: function gsm_L_asl, block 17, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x57 ((_ zero_extend 32) in1_32)))
(let ((?x1266 (bvshl in0_64 ?x57)))
(let (($x834 (bvuge ?x57 (_ bv64 64))))
(let (($x17 (or (or false (or false (or (= ((_ extract 31 31) in1_32) (_ bv1 1)))) false) $x834)))
(let (($x676 (not (or (or false (or false false) false) $x834))))
(and $x676 (or $x17 (and (distinct ?x1266 ?x1266) true)))))))))
(check-sat)
; query 37: function gsm_L_asl, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1276 (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x484 (not $x52)))
(and $x484 (or $x52 (and (distinct ?x1276 ?x1276) true)))))))
(check-sat)
; query 38: function gsm_L_asl, block 7, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x819 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1377 ((_ zero_extend 31) ?x819)))
(let ((?x1540 (bvsub (_ bv0 32) ?x1377)))
(let (($x245 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1377)) ((_ sign_extend 1) ?x1540)) true)))
(let (($x52 (or false false false)))
(let (($x1248 (or $x52 false)))
(let (($x2733 (or false $x1248 (or $x245))))
(and (not $x2733) (or $x2733 (and (distinct ?x1540 ?x1540) true)))))))))))
(check-sat)
; query 39: function gsm_L_asl, block 7, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x819 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1377 ((_ zero_extend 31) ?x819)))
(let ((?x1540 (bvsub (_ bv0 32) ?x1377)))
(let ((?x74 ((_ sign_extend 32) ?x1540)))
(let (($x245 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1377)) ((_ sign_extend 1) ?x1540)) true)))
(let (($x52 (or false false false)))
(let (($x1248 (or $x52 false)))
(let (($x2733 (or false $x1248 (or $x245))))
(let (($x209 (or $x2733 false)))
(and (not $x209) (or $x209 (and (distinct ?x74 ?x74) true)))))))))))))
(check-sat)
; query 40: function gsm_L_asl, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x819 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x484 (not $x52)))
(and $x484 (or $x52 (and (distinct ?x819 ?x819) true)))))))
(check-sat)
; query 41: function gsm_L_asl, block 7, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x819 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1377 ((_ zero_extend 31) ?x819)))
(let (($x52 (or false false false)))
(let (($x1248 (or $x52 false)))
(let (($x134 (not $x1248)))
(and $x134 (or $x1248 (and (distinct ?x1377 ?x1377) true)))))))))
(check-sat)
; query 42: function gsm_L_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1732 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x484 (not $x52)))
(and $x484 (or $x52 (and (distinct ?x1732 ?x1732) true)))))))
(check-sat)
; query 43: function gsm_L_asr, block 12, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x723 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x484 (not $x52)))
(and $x484 (or $x52 (and (distinct ?x723 ?x723) true)))))))
(check-sat)
; query 44: function gsm_L_asr, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x1757 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in1_32))) true)))
(let (($x912 (or false false (or $x1757))))
(and (not $x912) (or $x912 (and (distinct (bvsub (_ bv0 32) in1_32) (bvsub (_ bv0 32) in1_32)) true))))))
(check-sat)
; query 45: function gsm_L_asr, block 14, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x142 (bvsub (_ bv0 32) in1_32)))
(let ((?x1094 ((_ zero_extend 32) ?x142)))
(let (($x1757 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x142)) true)))
(let (($x912 (or false false (or $x1757))))
(let (($x1683 (or $x912 (or (= ((_ extract 31 31) ?x142) (_ bv1 1))))))
(and (not (or $x912 false)) (or $x1683 (and (distinct ?x1094 ?x1094) true)))))))))
(check-sat)
; query 46: function gsm_L_asr, block 14, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x142 (bvsub (_ bv0 32) in1_32)))
(let ((?x1094 ((_ zero_extend 32) ?x142)))
(let ((?x1000 (bvshl in0_64 ?x1094)))
(let (($x1311 (bvuge ?x1094 (_ bv64 64))))
(let (($x1757 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x142)) true)))
(let (($x912 (or false false (or $x1757))))
(let (($x1683 (or $x912 (or (= ((_ extract 31 31) ?x142) (_ bv1 1))))))
(and (not (or (or false (or $x912 false) false) $x1311)) (or (or (or false $x1683 false) $x1311) (and (distinct ?x1000 ?x1000) true)))))))))))
(check-sat)
; query 47: function gsm_L_asr, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x692 (or false (or (= ((_ extract 31 31) in1_32) (_ bv1 1))))))
(let (($x604 (or false false)))
(let (($x56 (not $x604)))
(and $x56 (or $x692 (and (distinct ((_ zero_extend 32) in1_32) ((_ zero_extend 32) in1_32)) true)))))))
(check-sat)
; query 48: function gsm_L_asr, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x57 ((_ zero_extend 32) in1_32)))
(let ((?x853 (bvashr in0_64 ?x57)))
(let (($x834 (bvuge ?x57 (_ bv64 64))))
(let (($x17 (or (or false (or false (or (= ((_ extract 31 31) in1_32) (_ bv1 1)))) false) $x834)))
(let (($x676 (not (or (or false (or false false) false) $x834))))
(and $x676 (or $x17 (and (distinct ?x853 ?x853) true)))))))))
(check-sat)
; query 49: function gsm_L_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x819 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x484 (not $x52)))
(and $x484 (or $x52 (and (distinct ?x819 ?x819) true)))))))
(check-sat)
; query 50: function gsm_L_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x819 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1377 ((_ zero_extend 31) ?x819)))
(let (($x52 (or false false false)))
(let (($x1248 (or $x52 false)))
(let (($x134 (not $x1248)))
(and $x134 (or $x1248 (and (distinct ?x1377 ?x1377) true)))))))))
(check-sat)
; query 51: function gsm_L_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x819 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1377 ((_ zero_extend 31) ?x819)))
(let ((?x1540 (bvsub (_ bv0 32) ?x1377)))
(let (($x245 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1377)) ((_ sign_extend 1) ?x1540)) true)))
(let (($x52 (or false false false)))
(let (($x1248 (or $x52 false)))
(let (($x2733 (or false $x1248 (or $x245))))
(and (not $x2733) (or $x2733 (and (distinct ?x1540 ?x1540) true)))))))))))
(check-sat)
; query 52: function gsm_L_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x819 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1377 ((_ zero_extend 31) ?x819)))
(let ((?x1540 (bvsub (_ bv0 32) ?x1377)))
(let ((?x74 ((_ sign_extend 32) ?x1540)))
(let (($x245 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1377)) ((_ sign_extend 1) ?x1540)) true)))
(let (($x52 (or false false false)))
(let (($x1248 (or $x52 false)))
(let (($x2733 (or false $x1248 (or $x245))))
(let (($x209 (or $x2733 false)))
(and (not $x209) (or $x209 (and (distinct ?x74 ?x74) true)))))))))))))
(check-sat)
; query 53: function gsm_L_asr, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1276 (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x484 (not $x52)))
(and $x484 (or $x52 (and (distinct ?x1276 ?x1276) true)))))))
(check-sat)
; query 54: function gsm_L_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1732 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x484 (not $x52)))
(and $x484 (or $x52 (and (distinct ?x1732 ?x1732) true)))))))
(check-sat)
; query 55: function gsm_L_mult, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x604 (or false false)))
(let (($x56 (not $x604)))
(and $x56 (or $x604 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 56: function gsm_L_mult, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x2251 (ite (and (distinct (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) true) (_ bv1 1) (_ bv0 1))))
(let (($x604 (or false false)))
(let (($x296 (or $x604 false false)))
(let (($x79 (not $x296)))
(and $x79 (or $x296 (and (distinct ?x2251 ?x2251) true))))))))
(check-sat)
; query 57: function gsm_L_mult, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x604 (or false false)))
(let (($x56 (not $x604)))
(and $x56 (or $x604 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 58: function gsm_L_mult, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1194 (ite (and (distinct (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) true) (_ bv1 1) (_ bv0 1))))
(let (($x604 (or false false)))
(let (($x296 (or $x604 false false)))
(let (($x79 (not $x296)))
(and $x79 (or $x296 (and (distinct ?x1194 ?x1194) true))))))))
(check-sat)
; query 59: function gsm_L_sub, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in11_64 () (_ BitVec 64))
(assert
 (let (($x1715 (and (distinct (bvadd ((_ zero_extend 1) in11_64) ((_ zero_extend 1) (_ bv1 64))) ((_ zero_extend 1) (bvadd in11_64 (_ bv1 64)))) true)))
(let (($x869 (and (distinct (bvadd ((_ sign_extend 1) in11_64) ((_ sign_extend 1) (_ bv1 64))) ((_ sign_extend 1) (bvadd in11_64 (_ bv1 64)))) true)))
(let (($x1524 (or (or false false (or $x869 $x1715)) (and (distinct (bvadd in11_64 (_ bv1 64)) (bvadd in11_64 (_ bv1 64))) true))))
(let (($x52 (or false false false)))
(let (($x484 (not $x52)))
(and $x484 $x1524)))))))
(check-sat)
; query 60: function gsm_L_sub, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1848 (ite (bvsge (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x484 (not $x52)))
(and $x484 (or $x52 (and (distinct ?x1848 ?x1848) true)))))))
(check-sat)
; query 61: function gsm_L_sub, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x386 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvsub in0_64 in1_64))) true)))
(let (($x329 (or false false (or $x386))))
(let (($x745 (or $x329 (and (distinct (bvsub in0_64 in1_64) (bvsub in0_64 in1_64)) true))))
(and (not $x329) $x745)))))
(check-sat)
; query 62: function gsm_L_sub, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1629 (bvadd in0_64 (_ bv1 64))))
(let ((?x1634 ((_ sign_extend 1) ?x1629)))
(let (($x1348 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1634) true)))))
(and (not $x1348) (or $x1348 (and (distinct ?x1629 ?x1629) true)))))))
(check-sat)
; query 63: function gsm_L_sub, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1629 (bvadd in0_64 (_ bv1 64))))
(let ((?x782 (bvsub (_ bv0 64) ?x1629)))
(let (($x1435 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1629)) ((_ sign_extend 1) ?x782)) true)))
(let ((?x1634 ((_ sign_extend 1) ?x1629)))
(let (($x1348 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1634) true)))))
(let (($x2063 (or false $x1348 (or $x1435))))
(and (not $x2063) (or $x2063 (and (distinct ?x782 ?x782) true))))))))))
(check-sat)
; query 64: function gsm_L_sub, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1629 (bvadd in0_64 (_ bv1 64))))
(let ((?x782 (bvsub (_ bv0 64) ?x1629)))
(let ((?x1025 (bvadd ?x782 in1_64)))
(let (($x1870 (and (distinct (bvadd ((_ zero_extend 1) ?x782) ((_ zero_extend 1) in1_64)) ((_ zero_extend 1) ?x1025)) true)))
(let (($x1435 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1629)) ((_ sign_extend 1) ?x782)) true)))
(let ((?x1634 ((_ sign_extend 1) ?x1629)))
(let (($x1348 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1634) true)))))
(let (($x2063 (or false $x1348 (or $x1435))))
(let (($x1881 (or $x2063 false (or $x1870))))
(and (not (or $x2063 false false)) (or $x1881 (and (distinct ?x1025 ?x1025) true)))))))))))))
(check-sat)
; query 65: function gsm_L_sub, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1495 (ite (bvuge (bvadd (bvsub (_ bv0 64) (bvadd in0_64 (_ bv1 64))) in1_64) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let ((?x1068 ((_ zero_extend 1) in1_64)))
(let ((?x1629 (bvadd in0_64 (_ bv1 64))))
(let ((?x782 (bvsub (_ bv0 64) ?x1629)))
(let ((?x1530 ((_ zero_extend 1) ?x782)))
(let (($x1435 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1629)) ((_ sign_extend 1) ?x782)) true)))
(let ((?x1634 ((_ sign_extend 1) ?x1629)))
(let (($x1348 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1634) true)))))
(let (($x2063 (or false $x1348 (or $x1435))))
(let (($x1881 (or $x2063 false (or (and (distinct (bvadd ?x1530 ?x1068) ((_ zero_extend 1) (bvadd ?x782 in1_64))) true)))))
(and (not (or (or $x2063 false false) false false)) (or (or $x1881 false false) (and (distinct ?x1495 ?x1495) true))))))))))))))
(check-sat)
; query 66: function gsm_L_sub, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_64 () (_ BitVec 64))
(assert
 (let ((?x486 (bvsub (_ bv0 64) in25_64)))
(let ((?x812 ((_ sign_extend 1) ?x486)))
(let (($x1344 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in25_64)) ?x812) true)))))
(and (not $x1344) (or $x1344 (and (distinct ?x486 ?x486) true)))))))
(check-sat)
; query 67: function gsm_L_sub, block 28, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_64 () (_ BitVec 64))
(assert
 (let ((?x486 (bvsub (_ bv0 64) in25_64)))
(let ((?x1410 (bvsub ?x486 (_ bv1 64))))
(let (($x1116 (and (distinct (bvsub ((_ zero_extend 1) ?x486) ((_ zero_extend 1) (_ bv1 64))) ((_ zero_extend 1) ?x1410)) true)))
(let (($x180 (and (distinct (bvsub ((_ sign_extend 1) ?x486) ((_ sign_extend 1) (_ bv1 64))) ((_ sign_extend 1) ?x1410)) true)))
(let ((?x812 ((_ sign_extend 1) ?x486)))
(let (($x1344 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in25_64)) ?x812) true)))))
(and (not (or $x1344 false (or $x180))) (or (or $x1344 false (or $x180 $x1116)) (and (distinct ?x1410 ?x1410) true))))))))))
(check-sat)
; query 68: function gsm_L_sub, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x2059 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x484 (not $x52)))
(and $x484 (or $x52 (and (distinct ?x2059 ?x2059) true)))))))
(check-sat)
; query 69: function gsm_L_sub, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x386 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvsub in0_64 in1_64))) true)))
(let (($x329 (or false false (or $x386))))
(let (($x745 (or $x329 (and (distinct (bvsub in0_64 in1_64) (bvsub in0_64 in1_64)) true))))
(and (not $x329) $x745)))))
(check-sat)
; query 70: function gsm_L_sub, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x883 (bvadd in1_64 (_ bv1 64))))
(let ((?x1240 (bvsub (_ bv0 64) ?x883)))
(let (($x704 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x883)) ((_ sign_extend 1) ?x1240)) true)))
(let ((?x816 ((_ sign_extend 1) ?x883)))
(let (($x1245 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x816) true)))))
(let (($x48 (or false $x1245 (or $x704))))
(and (not $x48) (or $x48 (and (distinct ?x1240 ?x1240) true))))))))))
(check-sat)
; query 71: function gsm_L_sub, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x883 (bvadd in1_64 (_ bv1 64))))
(let ((?x1240 (bvsub (_ bv0 64) ?x883)))
(let ((?x2322 (bvadd in0_64 ?x1240)))
(let (($x151 (and (distinct (bvadd ((_ zero_extend 1) in0_64) ((_ zero_extend 1) ?x1240)) ((_ zero_extend 1) ?x2322)) true)))
(let (($x704 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x883)) ((_ sign_extend 1) ?x1240)) true)))
(let ((?x816 ((_ sign_extend 1) ?x883)))
(let (($x1245 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x816) true)))))
(let (($x48 (or false $x1245 (or $x704))))
(let (($x252 (or false $x48 (or $x151))))
(and (not (or false $x48 false)) (or $x252 (and (distinct ?x2322 ?x2322) true)))))))))))))
(check-sat)
; query 72: function gsm_L_sub, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1899 (ite (bvuge (bvadd in0_64 (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64)))) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let ((?x883 (bvadd in1_64 (_ bv1 64))))
(let ((?x1240 (bvsub (_ bv0 64) ?x883)))
(let ((?x318 ((_ zero_extend 1) ?x1240)))
(let ((?x1973 ((_ zero_extend 1) in0_64)))
(let (($x704 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x883)) ((_ sign_extend 1) ?x1240)) true)))
(let ((?x816 ((_ sign_extend 1) ?x883)))
(let (($x1245 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x816) true)))))
(let (($x48 (or false $x1245 (or $x704))))
(let (($x252 (or false $x48 (or (and (distinct (bvadd ?x1973 ?x318) ((_ zero_extend 1) (bvadd in0_64 ?x1240))) true)))))
(and (not (or (or false $x48 false) false false)) (or (or $x252 false false) (and (distinct ?x1899 ?x1899) true))))))))))))))
(check-sat)
; query 73: function gsm_L_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x883 (bvadd in1_64 (_ bv1 64))))
(let ((?x816 ((_ sign_extend 1) ?x883)))
(let (($x1245 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x816) true)))))
(and (not $x1245) (or $x1245 (and (distinct ?x883 ?x883) true)))))))
(check-sat)
; query 74: function gsm_L_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x203 (ite (bvsle (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x484 (not $x52)))
(and $x484 (or $x52 (and (distinct ?x203 ?x203) true)))))))
(check-sat)
; query 75: function gsm_abs, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x604 (or false false)))
(let (($x56 (not $x604)))
(and $x56 (or $x604 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 76: function gsm_abs, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1928 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x604 (or false false)))
(let (($x296 (or $x604 false false)))
(let (($x79 (not $x296)))
(and $x79 (or $x296 (and (distinct ?x1928 ?x1928) true))))))))
(check-sat)
; query 77: function gsm_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_64 () (_ BitVec 64))
(assert
 (let ((?x1226 (ite (bvslt (_ bv32767 64) in5_64) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x484 (not $x52)))
(and $x484 (or $x52 (and (distinct ?x1226 ?x1226) true)))))))
(check-sat)
; query 78: function gsm_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x604 (or false false)))
(let (($x56 (not $x604)))
(and $x56 (or $x604 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 79: function gsm_add, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x604 (or false false)))
(let (($x56 (not $x604)))
(and $x56 (or $x604 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 80: function gsm_add, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x377 ((_ sign_extend 48) in1_16)))
(let ((?x1174 ((_ sign_extend 48) in0_16)))
(let ((?x306 (bvadd ?x1174 ?x377)))
(let (($x2067 (and (distinct (bvadd ((_ sign_extend 1) ?x1174) ((_ sign_extend 1) ?x377)) ((_ sign_extend 1) ?x306)) true)))
(let (($x604 (or false false)))
(let (($x1762 (or $x604 $x604 (or $x2067))))
(and (not $x1762) (or $x1762 (and (distinct ?x306 ?x306) true))))))))))
(check-sat)
; query 81: function gsm_add, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1864 (ite (bvsgt (_ bv18446744073709518848 64) (bvadd ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x377 ((_ sign_extend 48) in1_16)))
(let ((?x1627 ((_ sign_extend 1) ?x377)))
(let ((?x1174 ((_ sign_extend 48) in0_16)))
(let ((?x1964 ((_ sign_extend 1) ?x1174)))
(let (($x604 (or false false)))
(let (($x1762 (or $x604 $x604 (or (and (distinct (bvadd ?x1964 ?x1627) ((_ sign_extend 1) (bvadd ?x1174 ?x377))) true)))))
(let (($x1029 (or $x1762 false false)))
(and (not $x1029) (or $x1029 (and (distinct ?x1864 ?x1864) true))))))))))))
(check-sat)
; query 82: function gsm_asl, block 13, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x723 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x484 (not $x52)))
(and $x484 (or $x52 (and (distinct ?x723 ?x723) true)))))))
(check-sat)
; query 83: function gsm_asl, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x604 (or false false)))
(let (($x56 (not $x604)))
(and $x56 (or $x604 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 84: function gsm_asl, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x353 ((_ sign_extend 16) in0_16)))
(let ((?x836 (bvshl ?x353 in1_32)))
(let (($x1063 (bvuge in1_32 (_ bv32 32))))
(let (($x604 (or false false)))
(let (($x616 (or (or $x604 false (or (and (distinct (bvashr ?x836 in1_32) ?x353) true))) $x1063)))
(let (($x296 (or $x604 false false)))
(let (($x553 (or $x296 $x1063)))
(let (($x850 (not $x553)))
(and $x850 (or $x616 (and (distinct ?x836 ?x836) true))))))))))))
(check-sat)
; query 85: function gsm_asl, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x353 ((_ sign_extend 16) in0_16)))
(let ((?x836 (bvshl ?x353 in1_32)))
(let ((?x888 ((_ extract 15 0) ?x836)))
(let (($x1063 (bvuge in1_32 (_ bv32 32))))
(let (($x604 (or false false)))
(let (($x616 (or (or $x604 false (or (and (distinct (bvashr ?x836 in1_32) ?x353) true))) $x1063)))
(let (($x522 (not (or (or (or $x604 false false) $x1063) false))))
(and $x522 (or (or $x616 false) (and (distinct ?x888 ?x888) true)))))))))))
(check-sat)
; query 86: function gsm_asl, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1365 (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x484 (not $x52)))
(and $x484 (or $x52 (and (distinct ?x1365 ?x1365) true)))))))
(check-sat)
; query 87: function gsm_asl, block 7, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1928 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1912 ((_ zero_extend 31) ?x1928)))
(let (($x604 (or false false)))
(let (($x296 (or $x604 false false)))
(let (($x248 (or $x296 false)))
(and (not $x248) (or $x248 (and (distinct ?x1912 ?x1912) true)))))))))
(check-sat)
; query 88: function gsm_asl, block 7, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1928 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1912 ((_ zero_extend 31) ?x1928)))
(let ((?x190 (bvsub (_ bv0 32) ?x1912)))
(let (($x1917 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1912)) ((_ sign_extend 1) ?x190)) true)))
(let (($x604 (or false false)))
(let (($x296 (or $x604 false false)))
(let (($x248 (or $x296 false)))
(let (($x1516 (or false $x248 (or $x1917))))
(and (not $x1516) (or $x1516 (and (distinct ?x190 ?x190) true))))))))))))
(check-sat)
; query 89: function gsm_asl, block 7, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1928 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1912 ((_ zero_extend 31) ?x1928)))
(let ((?x190 (bvsub (_ bv0 32) ?x1912)))
(let ((?x897 ((_ extract 15 0) ?x190)))
(let (($x1917 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1912)) ((_ sign_extend 1) ?x190)) true)))
(let (($x604 (or false false)))
(let (($x296 (or $x604 false false)))
(let (($x248 (or $x296 false)))
(let (($x1516 (or false $x248 (or $x1917))))
(let (($x1960 (or (or $x1516 (or (and (distinct ((_ sign_extend 16) ?x897) ?x190) true))) (and (distinct ?x897 ?x897) true))))
(and (not (or $x1516 false)) $x1960))))))))))))
(check-sat)
; query 90: function gsm_asl, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x604 (or false false)))
(let (($x56 (not $x604)))
(and $x56 (or $x604 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 91: function gsm_asl, block 7, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1928 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x604 (or false false)))
(let (($x296 (or $x604 false false)))
(let (($x79 (not $x296)))
(and $x79 (or $x296 (and (distinct ?x1928 ?x1928) true))))))))
(check-sat)
; query 92: function gsm_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1464 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x484 (not $x52)))
(and $x484 (or $x52 (and (distinct ?x1464 ?x1464) true)))))))
(check-sat)
; query 93: function gsm_asr, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1365 (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x484 (not $x52)))
(and $x484 (or $x52 (and (distinct ?x1365 ?x1365) true)))))))
(check-sat)
; query 94: function gsm_asr, block 13, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x723 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x484 (not $x52)))
(and $x484 (or $x52 (and (distinct ?x723 ?x723) true)))))))
(check-sat)
; query 95: function gsm_asr, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x604 (or false false)))
(let (($x56 (not $x604)))
(and $x56 (or $x604 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 96: function gsm_asr, block 15, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x1757 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in1_32))) true)))
(let (($x912 (or false false (or $x1757))))
(and (not $x912) (or $x912 (and (distinct (bvsub (_ bv0 32) in1_32) (bvsub (_ bv0 32) in1_32)) true))))))
(check-sat)
; query 97: function gsm_asr, block 15, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x142 (bvsub (_ bv0 32) in1_32)))
(let ((?x353 ((_ sign_extend 16) in0_16)))
(let ((?x808 (bvshl ?x353 ?x142)))
(let (($x1867 (bvuge ?x142 (_ bv32 32))))
(let (($x1757 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x142)) true)))
(let (($x912 (or false false (or $x1757))))
(let (($x604 (or false false)))
(let (($x1349 (or (or $x604 $x912 (or (and (distinct (bvashr ?x808 ?x142) ?x353) true))) $x1867)))
(and (not (or (or $x604 $x912 false) $x1867)) (or $x1349 (and (distinct ?x808 ?x808) true))))))))))))
(check-sat)
; query 98: function gsm_asr, block 15, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x142 (bvsub (_ bv0 32) in1_32)))
(let ((?x353 ((_ sign_extend 16) in0_16)))
(let ((?x808 (bvshl ?x353 ?x142)))
(let ((?x1893 ((_ extract 15 0) ?x808)))
(let (($x1867 (bvuge ?x142 (_ bv32 32))))
(let (($x1757 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x142)) true)))
(let (($x912 (or false false (or $x1757))))
(let (($x604 (or false false)))
(let (($x1349 (or (or $x604 $x912 (or (and (distinct (bvashr ?x808 ?x142) ?x353) true))) $x1867)))
(and (not (or (or (or $x604 $x912 false) $x1867) false)) (or (or $x1349 false) (and (distinct ?x1893 ?x1893) true)))))))))))))
(check-sat)
; query 99: function gsm_asr, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x604 (or false false)))
(let (($x56 (not $x604)))
(and $x56 (or $x604 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 100: function gsm_asr, block 20, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x353 ((_ sign_extend 16) in0_16)))
(let ((?x870 (bvashr ?x353 in1_32)))
(let (($x1063 (bvuge in1_32 (_ bv32 32))))
(let (($x604 (or false false)))
(let (($x296 (or $x604 false false)))
(let (($x553 (or $x296 $x1063)))
(let (($x850 (not $x553)))
(and $x850 (or $x553 (and (distinct ?x870 ?x870) true)))))))))))
(check-sat)
; query 101: function gsm_asr, block 20, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x353 ((_ sign_extend 16) in0_16)))
(let ((?x870 (bvashr ?x353 in1_32)))
(let ((?x1456 ((_ extract 15 0) ?x870)))
(let (($x1063 (bvuge in1_32 (_ bv32 32))))
(let (($x604 (or false false)))
(let (($x296 (or $x604 false false)))
(let (($x553 (or $x296 $x1063)))
(let (($x1113 (or (or $x553 (or (and (distinct ((_ sign_extend 16) ?x1456) ?x870) true))) (and (distinct ?x1456 ?x1456) true))))
(let (($x522 (not (or $x553 false))))
(and $x522 $x1113)))))))))))
(check-sat)
; query 102: function gsm_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x604 (or false false)))
(let (($x56 (not $x604)))
(and $x56 (or $x604 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 103: function gsm_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1928 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x604 (or false false)))
(let (($x296 (or $x604 false false)))
(let (($x79 (not $x296)))
(and $x79 (or $x296 (and (distinct ?x1928 ?x1928) true))))))))
(check-sat)
; query 104: function gsm_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1928 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1912 ((_ zero_extend 31) ?x1928)))
(let (($x604 (or false false)))
(let (($x296 (or $x604 false false)))
(let (($x248 (or $x296 false)))
(and (not $x248) (or $x248 (and (distinct ?x1912 ?x1912) true)))))))))
(check-sat)
; query 105: function gsm_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1928 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1912 ((_ zero_extend 31) ?x1928)))
(let ((?x190 (bvsub (_ bv0 32) ?x1912)))
(let (($x1917 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1912)) ((_ sign_extend 1) ?x190)) true)))
(let (($x604 (or false false)))
(let (($x296 (or $x604 false false)))
(let (($x248 (or $x296 false)))
(let (($x1516 (or false $x248 (or $x1917))))
(and (not $x1516) (or $x1516 (and (distinct ?x190 ?x190) true))))))))))))
(check-sat)
; query 106: function gsm_asr, block 4, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1928 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1912 ((_ zero_extend 31) ?x1928)))
(let ((?x190 (bvsub (_ bv0 32) ?x1912)))
(let ((?x897 ((_ extract 15 0) ?x190)))
(let (($x1917 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1912)) ((_ sign_extend 1) ?x190)) true)))
(let (($x604 (or false false)))
(let (($x296 (or $x604 false false)))
(let (($x248 (or $x296 false)))
(let (($x1516 (or false $x248 (or $x1917))))
(let (($x1960 (or (or $x1516 (or (and (distinct ((_ sign_extend 16) ?x897) ?x190) true))) (and (distinct ?x897 ?x897) true))))
(and (not (or $x1516 false)) $x1960))))))))))))
(check-sat)
; query 107: function gsm_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1464 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x484 (not $x52)))
(and $x484 (or $x52 (and (distinct ?x1464 ?x1464) true)))))))
(check-sat)
; query 108: function gsm_debug_longwords, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in15_32 () (_ BitVec 32))
(assert
 (let ((?x978 (ite (bvslt in15_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x484 (not $x52)))
(and $x484 (or $x52 (and (distinct ?x978 ?x978) true)))))))
(check-sat)
; query 109: function gsm_debug_words, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in16_32 () (_ BitVec 32))
(assert
 (let ((?x1015 (ite (bvslt in16_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x484 (not $x52)))
(and $x484 (or $x52 (and (distinct ?x1015 ?x1015) true)))))))
(check-sat)
; query 110: function gsm_div, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x604 (or false false)))
(let (($x56 (not $x604)))
(and $x56 (or $x604 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 111: function gsm_div, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x604 (or false false)))
(let (($x56 (not $x604)))
(and $x56 (or $x604 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 112: function gsm_div, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x604 (or false false)))
(let (($x56 (not $x604)))
(and $x56 (or $x604 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 113: function gsm_div, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x82 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x460 (and (distinct ?x82 ?x82) true)))
(let (($x604 (or false false)))
(let (($x296 (or $x604 false false)))
(let (($x79 (not $x296)))
(and $x79 (or $x296 $x460))))))))
(check-sat)
; query 114: function gsm_mult, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x604 (or false false)))
(let (($x56 (not $x604)))
(and $x56 (or $x604 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 115: function gsm_mult, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1099 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x604 (or false false)))
(let (($x296 (or $x604 false false)))
(let (($x79 (not $x296)))
(and $x79 (or $x296 (and (distinct ?x1099 ?x1099) true))))))))
(check-sat)
; query 116: function gsm_mult, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x604 (or false false)))
(let (($x56 (not $x604)))
(and $x56 (or $x604 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 117: function gsm_mult, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x604 (or false false)))
(let (($x56 (not $x604)))
(and $x56 (or $x604 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 118: function gsm_mult, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x377 ((_ sign_extend 48) in1_16)))
(let ((?x1174 ((_ sign_extend 48) in0_16)))
(let ((?x2697 (bvmul ?x1174 ?x377)))
(let (($x643 (and (distinct (bvmul ((_ sign_extend 64) ?x1174) ((_ sign_extend 64) ?x377)) ((_ sign_extend 64) ?x2697)) true)))
(let (($x604 (or false false)))
(let (($x1006 (or $x604 $x604 (or $x643))))
(and (not $x1006) (or $x1006 (and (distinct ?x2697 ?x2697) true))))))))))
(check-sat)
; query 119: function gsm_mult, block 9, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x377 ((_ sign_extend 48) in1_16)))
(let ((?x1174 ((_ sign_extend 48) in0_16)))
(let ((?x2697 (bvmul ?x1174 ?x377)))
(let ((?x606 (bvashr ?x2697 (_ bv15 64))))
(let (($x402 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x643 (and (distinct (bvmul ((_ sign_extend 64) ?x1174) ((_ sign_extend 64) ?x377)) ((_ sign_extend 64) ?x2697)) true)))
(let (($x604 (or false false)))
(let (($x1006 (or $x604 $x604 (or $x643))))
(let (($x2623 (or (or $x1006 false false) $x402)))
(and (not $x2623) (or $x2623 (and (distinct ?x606 ?x606) true)))))))))))))
(check-sat)
; query 120: function gsm_mult, block 9, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x377 ((_ sign_extend 48) in1_16)))
(let ((?x1174 ((_ sign_extend 48) in0_16)))
(let ((?x2697 (bvmul ?x1174 ?x377)))
(let ((?x606 (bvashr ?x2697 (_ bv15 64))))
(let ((?x1541 ((_ extract 15 0) ?x606)))
(let (($x402 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x643 (and (distinct (bvmul ((_ sign_extend 64) ?x1174) ((_ sign_extend 64) ?x377)) ((_ sign_extend 64) ?x2697)) true)))
(let (($x604 (or false false)))
(let (($x1006 (or $x604 $x604 (or $x643))))
(let (($x2623 (or (or $x1006 false false) $x402)))
(let (($x2678 (or $x2623 false)))
(and (not $x2678) (or $x2678 (and (distinct ?x1541 ?x1541) true)))))))))))))))
(check-sat)
; query 121: function gsm_mult, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x604 (or false false)))
(let (($x56 (not $x604)))
(and $x56 (or $x604 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 122: function gsm_mult, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1343 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x604 (or false false)))
(let (($x296 (or $x604 false false)))
(let (($x79 (not $x296)))
(and $x79 (or $x296 (and (distinct ?x1343 ?x1343) true))))))))
(check-sat)
; query 123: function gsm_mult_r, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x604 (or false false)))
(let (($x56 (not $x604)))
(and $x56 (or $x604 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 124: function gsm_mult_r, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1343 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x604 (or false false)))
(let (($x296 (or $x604 false false)))
(let (($x79 (not $x296)))
(and $x79 (or $x296 (and (distinct ?x1343 ?x1343) true))))))))
(check-sat)
; query 125: function gsm_mult_r, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x604 (or false false)))
(let (($x56 (not $x604)))
(and $x56 (or $x604 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 126: function gsm_mult_r, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x604 (or false false)))
(let (($x56 (not $x604)))
(and $x56 (or $x604 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 127: function gsm_mult_r, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x377 ((_ sign_extend 48) in1_16)))
(let ((?x1174 ((_ sign_extend 48) in0_16)))
(let ((?x2697 (bvmul ?x1174 ?x377)))
(let (($x643 (and (distinct (bvmul ((_ sign_extend 64) ?x1174) ((_ sign_extend 64) ?x377)) ((_ sign_extend 64) ?x2697)) true)))
(let (($x604 (or false false)))
(let (($x1006 (or $x604 $x604 (or $x643))))
(and (not $x1006) (or $x1006 (and (distinct ?x2697 ?x2697) true))))))))))
(check-sat)
; query 128: function gsm_mult_r, block 9, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x377 ((_ sign_extend 48) in1_16)))
(let ((?x1174 ((_ sign_extend 48) in0_16)))
(let ((?x2697 (bvmul ?x1174 ?x377)))
(let ((?x1622 (bvadd ?x2697 (_ bv16384 64))))
(let (($x2743 (and (distinct (bvadd ((_ sign_extend 1) ?x2697) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x1622)) true)))
(let (($x643 (and (distinct (bvmul ((_ sign_extend 64) ?x1174) ((_ sign_extend 64) ?x377)) ((_ sign_extend 64) ?x2697)) true)))
(let (($x604 (or false false)))
(let (($x1006 (or $x604 $x604 (or $x643))))
(let (($x1170 (or $x1006 false (or $x2743))))
(and (not $x1170) (or $x1170 (and (distinct ?x1622 ?x1622) true)))))))))))))
(check-sat)
; query 129: function gsm_mult_r, block 9, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x377 ((_ sign_extend 48) in1_16)))
(let ((?x1174 ((_ sign_extend 48) in0_16)))
(let ((?x2697 (bvmul ?x1174 ?x377)))
(let ((?x1622 (bvadd ?x2697 (_ bv16384 64))))
(let ((?x1083 (bvashr ?x1622 (_ bv15 64))))
(let (($x402 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x2743 (and (distinct (bvadd ((_ sign_extend 1) ?x2697) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x1622)) true)))
(let (($x643 (and (distinct (bvmul ((_ sign_extend 64) ?x1174) ((_ sign_extend 64) ?x377)) ((_ sign_extend 64) ?x2697)) true)))
(let (($x604 (or false false)))
(let (($x1006 (or $x604 $x604 (or $x643))))
(let (($x1170 (or $x1006 false (or $x2743))))
(let (($x1185 (or (or $x1170 false false) $x402)))
(and (not $x1185) (or $x1185 (and (distinct ?x1083 ?x1083) true))))))))))))))))
(check-sat)
; query 130: function gsm_mult_r, block 9, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x377 ((_ sign_extend 48) in1_16)))
(let ((?x1174 ((_ sign_extend 48) in0_16)))
(let ((?x2697 (bvmul ?x1174 ?x377)))
(let ((?x1622 (bvadd ?x2697 (_ bv16384 64))))
(let ((?x1083 (bvashr ?x1622 (_ bv15 64))))
(let ((?x2661 (bvand ?x1083 (_ bv65535 64))))
(let (($x402 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x2743 (and (distinct (bvadd ((_ sign_extend 1) ?x2697) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x1622)) true)))
(let (($x643 (and (distinct (bvmul ((_ sign_extend 64) ?x1174) ((_ sign_extend 64) ?x377)) ((_ sign_extend 64) ?x2697)) true)))
(let (($x604 (or false false)))
(let (($x1006 (or $x604 $x604 (or $x643))))
(let (($x1170 (or $x1006 false (or $x2743))))
(let (($x1185 (or (or $x1170 false false) $x402)))
(let (($x933 (or $x1185 false false)))
(and (not $x933) (or $x933 (and (distinct ?x2661 ?x2661) true))))))))))))))))))
(check-sat)
; query 131: function gsm_mult_r, block 9, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x377 ((_ sign_extend 48) in1_16)))
(let ((?x1174 ((_ sign_extend 48) in0_16)))
(let ((?x2697 (bvmul ?x1174 ?x377)))
(let ((?x1622 (bvadd ?x2697 (_ bv16384 64))))
(let ((?x1083 (bvashr ?x1622 (_ bv15 64))))
(let ((?x2661 (bvand ?x1083 (_ bv65535 64))))
(let ((?x623 ((_ extract 15 0) ?x2661)))
(let (($x402 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x2743 (and (distinct (bvadd ((_ sign_extend 1) ?x2697) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x1622)) true)))
(let (($x643 (and (distinct (bvmul ((_ sign_extend 64) ?x1174) ((_ sign_extend 64) ?x377)) ((_ sign_extend 64) ?x2697)) true)))
(let (($x604 (or false false)))
(let (($x1006 (or $x604 $x604 (or $x643))))
(let (($x1170 (or $x1006 false (or $x2743))))
(let (($x1185 (or (or $x1170 false false) $x402)))
(let (($x933 (or $x1185 false false)))
(let (($x2599 (or (or $x933 (or (and (distinct ((_ zero_extend 48) ?x623) ?x2661) true))) (and (distinct ?x623 ?x623) true))))
(and (not (or $x933 false)) $x2599))))))))))))))))))
(check-sat)
; query 132: function gsm_mult_r, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x604 (or false false)))
(let (($x56 (not $x604)))
(and $x56 (or $x604 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 133: function gsm_mult_r, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1099 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x604 (or false false)))
(let (($x296 (or $x604 false false)))
(let (($x79 (not $x296)))
(and $x79 (or $x296 (and (distinct ?x1099 ?x1099) true))))))))
(check-sat)
; query 134: function gsm_norm, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x434 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x484 (not $x52)))
(and $x484 (or $x52 (and (distinct ?x434 ?x434) true)))))))
(check-sat)
; query 135: function gsm_norm, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x434 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x2618 (bvxor ?x434 (_ bv1 1))))
(let (($x52 (or false false false)))
(let (($x206 (or $x52 false false)))
(let (($x926 (not $x206)))
(and $x926 (or $x206 (and (distinct ?x2618 ?x2618) true)))))))))
(check-sat)
; query 136: function gsm_norm, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x434 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x2618 (bvxor ?x434 (_ bv1 1))))
(let ((?x650 ((_ zero_extend 31) ?x2618)))
(let (($x52 (or false false false)))
(let (($x206 (or $x52 false false)))
(let (($x443 (or $x206 false)))
(and (not $x443) (or $x443 (and (distinct ?x650 ?x650) true))))))))))
(check-sat)
; query 137: function gsm_norm, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x434 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x2618 (bvxor ?x434 (_ bv1 1))))
(let ((?x650 ((_ zero_extend 31) ?x2618)))
(let (($x52 (or false false false)))
(let (($x206 (or $x52 false false)))
(let (($x443 (or $x206 false)))
(let (($x1906 (or (or $x443 (or (= ((_ extract 31 31) ?x650) (_ bv1 1)))) (and (distinct ((_ sign_extend 32) ?x650) ((_ zero_extend 32) ?x650)) true))))
(and (not (or $x443 false)) $x1906)))))))))
(check-sat)
; query 138: function gsm_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_64 () (_ BitVec 64))
(assert
 (let ((?x1226 (ite (bvslt (_ bv32767 64) in5_64) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x484 (not $x52)))
(and $x484 (or $x52 (and (distinct ?x1226 ?x1226) true)))))))
(check-sat)
; query 139: function gsm_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x604 (or false false)))
(let (($x56 (not $x604)))
(and $x56 (or $x604 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 140: function gsm_sub, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x604 (or false false)))
(let (($x56 (not $x604)))
(and $x56 (or $x604 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 141: function gsm_sub, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x377 ((_ sign_extend 48) in1_16)))
(let ((?x1174 ((_ sign_extend 48) in0_16)))
(let ((?x165 (bvsub ?x1174 ?x377)))
(let (($x1448 (and (distinct (bvsub ((_ sign_extend 1) ?x1174) ((_ sign_extend 1) ?x377)) ((_ sign_extend 1) ?x165)) true)))
(let (($x604 (or false false)))
(let (($x2501 (or $x604 $x604 (or $x1448))))
(and (not $x2501) (or $x2501 (and (distinct ?x165 ?x165) true))))))))))
(check-sat)
; query 142: function gsm_sub, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x2783 (ite (bvsgt (_ bv18446744073709518848 64) (bvsub ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x377 ((_ sign_extend 48) in1_16)))
(let ((?x1627 ((_ sign_extend 1) ?x377)))
(let ((?x1174 ((_ sign_extend 48) in0_16)))
(let ((?x1964 ((_ sign_extend 1) ?x1174)))
(let (($x604 (or false false)))
(let (($x2501 (or $x604 $x604 (or (and (distinct (bvsub ?x1964 ?x1627) ((_ sign_extend 1) (bvsub ?x1174 ?x377))) true)))))
(let (($x229 (or $x2501 false false)))
(and (not $x229) (or $x229 (and (distinct ?x2783 ?x2783) true))))))))))))
(check-sat)
; query 143: function ok_to_replace, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1102 (ite (and (distinct (_ bv4294967295 32) in.01_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x484 (not $x52)))
(and $x484 (or $x52 (and (distinct ?x1102 ?x1102) true)))))))
(check-sat)
; query 144: function suffix, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_64 () (_ BitVec 64))
(declare-fun in3_64 () (_ BitVec 64))
(assert
 (let ((?x1575 (ite (bvule in3_64 in4_64) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x484 (not $x52)))
(and $x484 (or $x52 (and (distinct ?x1575 ?x1575) true)))))))
(check-sat)
