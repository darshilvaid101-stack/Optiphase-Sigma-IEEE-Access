; OptiPhase-Sigma refinement certificate for sweep K30-R3-083
; query 0: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x128 (ite (bvsgt (_ bv2 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x104 (or false false false)))
(and (not $x104) (or $x104 (and (distinct ?x128 ?x128) true))))))
(check-sat)
