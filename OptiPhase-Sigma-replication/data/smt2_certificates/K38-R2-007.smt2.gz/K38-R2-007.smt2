; OptiPhase-Sigma refinement certificate for sweep K38-R2-007
; query 0: function BF_cbc_encrypt, block 126, name %127
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.010_64 () (_ BitVec 64))
(assert
 (let (($x596 (and (distinct (bvsub ((_ sign_extend 1) in.010_64) ((_ sign_extend 1) (_ bv8 64))) ((_ sign_extend 1) (bvsub in.010_64 (_ bv8 64)))) true)))
(let (($x326 (or false false (or $x596))))
(and (not $x326) (or $x326 (and (distinct (bvsub in.010_64 (_ bv8 64)) (bvsub in.010_64 (_ bv8 64))) true))))))
(check-sat)
; query 1: function BF_cbc_encrypt, block 366, name %367
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.111_64 () (_ BitVec 64))
(assert
 (let (($x221 (and (distinct (bvsub ((_ sign_extend 1) in.111_64) ((_ sign_extend 1) (_ bv8 64))) ((_ sign_extend 1) (bvsub in.111_64 (_ bv8 64)))) true)))
(let (($x146 (or false false (or $x221))))
(and (not $x146) (or $x146 (and (distinct (bvsub in.111_64 (_ bv8 64)) (bvsub in.111_64 (_ bv8 64))) true))))))
(check-sat)
; query 2: function BF_cfb64_encrypt, block 111, name %112
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.18_32 () (_ BitVec 32))
(assert
 (let ((?x282 (ite (= (_ bv0 32) in.18_32) (_ bv1 1) (_ bv0 1))))
(let (($x245 (or false false false)))
(let (($x291 (not $x245)))
(and $x291 (or $x245 (and (distinct ?x282 ?x282) true)))))))
(check-sat)
; query 3: function BF_cfb64_encrypt, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.07_32 () (_ BitVec 32))
(assert
 (let ((?x133 (ite (= (_ bv0 32) in.07_32) (_ bv1 1) (_ bv0 1))))
(let (($x245 (or false false false)))
(let (($x291 (not $x245)))
(and $x291 (or $x245 (and (distinct ?x133 ?x133) true)))))))
(check-sat)
; query 4: function BF_ofb64_encrypt, block 82, name %83
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x122 (ite (= (_ bv0 32) in.04_32) (_ bv1 1) (_ bv0 1))))
(let (($x245 (or false false false)))
(let (($x291 (not $x245)))
(and $x291 (or $x245 (and (distinct ?x122 ?x122) true)))))))
(check-sat)
; query 5: function BF_set_key, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x64 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x27 (or false false (or $x64))))
(and (not $x27) (or $x27 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 6: function BF_set_key, block 69, name %70
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.13_32 () (_ BitVec 32))
(assert
 (let (($x59 (and (distinct (bvadd ((_ sign_extend 1) in.13_32) ((_ sign_extend 1) (_ bv2 32))) ((_ sign_extend 1) (bvadd in.13_32 (_ bv2 32)))) true)))
(let (($x29 (or false false (or $x59))))
(and (not $x29) (or $x29 (and (distinct (bvadd in.13_32 (_ bv2 32)) (bvadd in.13_32 (_ bv2 32))) true))))))
(check-sat)
; query 7: function BF_set_key, block 87, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.24_32 () (_ BitVec 32))
(assert
 (let (($x62 (and (distinct (bvadd ((_ sign_extend 1) in.24_32) ((_ sign_extend 1) (_ bv2 32))) ((_ sign_extend 1) (bvadd in.24_32 (_ bv2 32)))) true)))
(let (($x123 (or false false (or $x62))))
(and (not $x123) (or $x123 (and (distinct (bvadd in.24_32 (_ bv2 32)) (bvadd in.24_32 (_ bv2 32))) true))))))
(check-sat)
; query 8: function main, block 124, name %125
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let ((?x78 (ite (bvsgt (_ bv40 32) in.2_32) (_ bv1 1) (_ bv0 1))))
(let (($x245 (or false false false)))
(let (($x291 (not $x245)))
(and $x291 (or $x245 (and (distinct ?x78 ?x78) true)))))))
(check-sat)
; query 9: function main, block 147, name %148
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x112 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x154 (or false false (or $x112))))
(and (not $x154) (or $x154 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 10: function main, block 60, name %61
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x19 (or false false)))
(and (not $x19) (or $x19 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 11: function main, block 60, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x44 (ite (bvsge (_ bv57 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x19 (or false false)))
(let (($x129 (or $x19 false false)))
(let (($x142 (not $x129)))
(and $x142 (or $x129 (and (distinct ?x44 ?x44) true))))))))
(check-sat)
; query 12: function main, block 63, name %64
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x245 (or false false false)))
(let (($x99 (or $x245 (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x99) (or $x99 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvshl in.01_32 (_ bv4 32))) true))))))
(check-sat)
; query 13: function main, block 63, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x19 (or false false)))
(and (not $x19) (or $x19 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 14: function main, block 63, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x80 ((_ sign_extend 24) in57_8)))
(let ((?x136 (bvshl in.01_32 (_ bv4 32))))
(let ((?x105 (bvadd ?x136 ?x80)))
(let ((?x161 ((_ sign_extend 1) ?x105)))
(let (($x19 (or false false)))
(let (($x245 (or false false false)))
(let (($x99 (or $x245 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x10 (or $x99 $x19 (or (and (distinct (bvadd ((_ sign_extend 1) ?x136) ((_ sign_extend 1) ?x80)) ?x161) true)))))
(and (not $x10) (or $x10 (and (distinct ?x105 ?x105) true))))))))))))
(check-sat)
; query 15: function main, block 63, name %67
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x80 ((_ sign_extend 24) in57_8)))
(let ((?x136 (bvshl in.01_32 (_ bv4 32))))
(let ((?x105 (bvadd ?x136 ?x80)))
(let ((?x103 (bvsub ?x105 (_ bv48 32))))
(let (($x109 (and (distinct (bvsub ((_ sign_extend 1) ?x105) ((_ sign_extend 1) (_ bv48 32))) ((_ sign_extend 1) ?x103)) true)))
(let ((?x161 ((_ sign_extend 1) ?x105)))
(let (($x19 (or false false)))
(let (($x245 (or false false false)))
(let (($x99 (or $x245 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x10 (or $x99 $x19 (or (and (distinct (bvadd ((_ sign_extend 1) ?x136) ((_ sign_extend 1) ?x80)) ?x161) true)))))
(let (($x115 (or $x10 false (or $x109))))
(and (not $x115) (or $x115 (and (distinct ?x103 ?x103) true)))))))))))))))
(check-sat)
; query 16: function main, block 68, name %69
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x19 (or false false)))
(and (not $x19) (or $x19 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 17: function main, block 68, name %70
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x208 (ite (bvsle (_ bv65 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x19 (or false false)))
(let (($x129 (or $x19 false false)))
(let (($x142 (not $x129)))
(and $x142 (or $x129 (and (distinct ?x208 ?x208) true))))))))
(check-sat)
; query 18: function main, block 71, name %72
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x19 (or false false)))
(and (not $x19) (or $x19 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 19: function main, block 71, name %73
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x202 (ite (bvsge (_ bv70 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x19 (or false false)))
(let (($x129 (or $x19 false false)))
(let (($x142 (not $x129)))
(and $x142 (or $x129 (and (distinct ?x202 ?x202) true))))))))
(check-sat)
; query 20: function main, block 74, name %75
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x245 (or false false false)))
(let (($x99 (or $x245 (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x99) (or $x99 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvshl in.01_32 (_ bv4 32))) true))))))
(check-sat)
; query 21: function main, block 74, name %76
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x19 (or false false)))
(and (not $x19) (or $x19 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 22: function main, block 74, name %77
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x80 ((_ sign_extend 24) in57_8)))
(let ((?x136 (bvshl in.01_32 (_ bv4 32))))
(let ((?x105 (bvadd ?x136 ?x80)))
(let ((?x161 ((_ sign_extend 1) ?x105)))
(let (($x19 (or false false)))
(let (($x245 (or false false false)))
(let (($x99 (or $x245 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x10 (or $x99 $x19 (or (and (distinct (bvadd ((_ sign_extend 1) ?x136) ((_ sign_extend 1) ?x80)) ?x161) true)))))
(and (not $x10) (or $x10 (and (distinct ?x105 ?x105) true))))))))))))
(check-sat)
; query 23: function main, block 74, name %78
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x80 ((_ sign_extend 24) in57_8)))
(let ((?x136 (bvshl in.01_32 (_ bv4 32))))
(let ((?x105 (bvadd ?x136 ?x80)))
(let ((?x126 (bvsub ?x105 (_ bv65 32))))
(let ((?x92 ((_ sign_extend 1) ?x126)))
(let ((?x161 ((_ sign_extend 1) ?x105)))
(let (($x19 (or false false)))
(let (($x245 (or false false false)))
(let (($x99 (or $x245 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x10 (or $x99 $x19 (or (and (distinct (bvadd ((_ sign_extend 1) ?x136) ((_ sign_extend 1) ?x80)) ?x161) true)))))
(let (($x464 (or $x10 false (or (and (distinct (bvsub ?x161 ((_ sign_extend 1) (_ bv65 32))) ?x92) true)))))
(and (not $x464) (or $x464 (and (distinct ?x126 ?x126) true)))))))))))))))
(check-sat)
; query 24: function main, block 74, name %79
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x80 ((_ sign_extend 24) in57_8)))
(let ((?x136 (bvshl in.01_32 (_ bv4 32))))
(let ((?x105 (bvadd ?x136 ?x80)))
(let ((?x126 (bvsub ?x105 (_ bv65 32))))
(let ((?x12 (bvadd ?x126 (_ bv10 32))))
(let (($x94 (and (distinct (bvadd ((_ sign_extend 1) ?x126) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x12)) true)))
(let ((?x92 ((_ sign_extend 1) ?x126)))
(let ((?x161 ((_ sign_extend 1) ?x105)))
(let (($x19 (or false false)))
(let (($x245 (or false false false)))
(let (($x99 (or $x245 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x10 (or $x99 $x19 (or (and (distinct (bvadd ((_ sign_extend 1) ?x136) ((_ sign_extend 1) ?x80)) ?x161) true)))))
(let (($x464 (or $x10 false (or (and (distinct (bvsub ?x161 ((_ sign_extend 1) (_ bv65 32))) ?x92) true)))))
(let (($x411 (or $x464 false (or $x94))))
(and (not $x411) (or $x411 (and (distinct ?x12 ?x12) true))))))))))))))))))
(check-sat)
