; OptiPhase-Sigma refinement certificate for sweep K45-R4-333
; query 0: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x25 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x46 (or false false false)))
(let (($x66 (not $x46)))
(and $x66 (or $x46 (and (distinct ?x25 ?x25) true)))))))
(check-sat)
; query 1: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x415 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x46 (or false false false)))
(let (($x66 (not $x46)))
(and $x66 (or $x46 (and (distinct ?x415 ?x415) true)))))))
(check-sat)
