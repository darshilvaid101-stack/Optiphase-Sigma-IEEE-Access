; OptiPhase-Sigma refinement certificate for sweep K33-R3-164
; query 0: function edge_draw, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let ((?x168 (ite (= (_ bv0 32) in4_32) (_ bv1 1) (_ bv0 1))))
(let (($x30 (or false false false)))
(let (($x198 (not $x30)))
(and $x198 (or $x30 (and (distinct ?x168 ?x168) true)))))))
(check-sat)
; query 1: function getint, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x621 (ite (bvsle (_ bv48 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x30 (or false false false)))
(let (($x198 (not $x30)))
(and $x198 (or $x30 (and (distinct ?x621 ?x621) true)))))))
(check-sat)
; query 2: function getint, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x286 (ite (bvsge (_ bv57 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x30 (or false false false)))
(let (($x198 (not $x30)))
(and $x198 (or $x30 (and (distinct ?x286 ?x286) true)))))))
(check-sat)
; query 3: function getint, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x519 (ite (= (_ bv4294967295 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x30 (or false false false)))
(let (($x198 (not $x30)))
(and $x198 (or $x30 (and (distinct ?x519 ?x519) true)))))))
(check-sat)
; query 4: function susan_smoothing, block 21, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x19 (ite (= (_ bv0 32) (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x30 (or false false false)))
(let (($x198 (not $x30)))
(and $x198 (or $x30 (and (distinct ?x19 ?x19) true)))))))
(check-sat)
