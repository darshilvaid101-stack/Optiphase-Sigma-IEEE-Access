; OptiPhase-Sigma refinement certificate for sweep K09-R6-011
