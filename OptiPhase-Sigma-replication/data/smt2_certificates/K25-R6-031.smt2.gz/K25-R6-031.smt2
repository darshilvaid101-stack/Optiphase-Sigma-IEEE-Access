; OptiPhase-Sigma refinement certificate for sweep K25-R6-031
