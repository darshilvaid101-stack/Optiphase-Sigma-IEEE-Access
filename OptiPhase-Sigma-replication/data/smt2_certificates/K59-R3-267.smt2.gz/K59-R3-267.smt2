; OptiPhase-Sigma refinement certificate for sweep K59-R3-267
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x280 (or false false)))
(let (($x321 (not $x280)))
(and $x321 (or $x280 (and (distinct ((_ sign_extend 16) in25_16) ((_ sign_extend 16) in25_16)) true))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let ((?x122 (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))))
(let (($x280 (or false false)))
(let (($x252 (or $x280 false false)))
(let (($x646 (not $x252)))
(and $x646 (or $x252 (and (distinct ?x122 ?x122) true))))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x280 (or false false)))
(let (($x321 (not $x280)))
(and $x321 (or $x280 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x12 ((_ sign_extend 16) in3_16)))
(let ((?x1462 (bvand ?x12 (_ bv127 32))))
(let (($x280 (or false false)))
(let (($x252 (or $x280 false false)))
(let (($x646 (not $x252)))
(and $x646 (or $x252 (and (distinct ?x1462 ?x1462) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x12 ((_ sign_extend 16) in3_16)))
(let ((?x1462 (bvand ?x12 (_ bv127 32))))
(let ((?x449 ((_ extract 15 0) ?x1462)))
(let (($x280 (or false false)))
(let (($x252 (or $x280 false false)))
(let (($x1941 (or $x252 false)))
(let (($x473 (not $x1941)))
(and $x473 (or $x1941 (and (distinct ?x449 ?x449) true)))))))))))
(check-sat)
; query 5: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x280 (or false false)))
(let (($x321 (not $x280)))
(and $x321 (or $x280 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 6: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x66 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x280 (or false false)))
(let (($x252 (or $x280 false false)))
(let (($x646 (not $x252)))
(and $x646 (or $x252 (and (distinct ?x66 ?x66) true))))))))
(check-sat)
; query 7: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x381 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x153 (or false false false)))
(let (($x72 (not $x153)))
(and $x72 (or $x153 (and (distinct ?x381 ?x381) true)))))))
(check-sat)
; query 8: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x153 (or false false false)))
(let (($x72 (not $x153)))
(and $x72 (or $x153 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 9: function core_state_transition, block 102, name %103
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x280 (or false false)))
(let (($x321 (not $x280)))
(and $x321 (or $x280 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 10: function core_state_transition, block 102, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x98 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x280 (or false false)))
(let (($x252 (or $x280 false false)))
(let (($x646 (not $x252)))
(and $x646 (or $x252 (and (distinct ?x98 ?x98) true))))))))
(check-sat)
; query 11: function core_state_transition, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x280 (or false false)))
(let (($x321 (not $x280)))
(and $x321 (or $x280 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 12: function core_state_transition, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x364 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x280 (or false false)))
(let (($x252 (or $x280 false false)))
(let (($x646 (not $x252)))
(and $x646 (or $x252 (and (distinct ?x364 ?x364) true))))))))
(check-sat)
; query 13: function core_state_transition, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x280 (or false false)))
(let (($x321 (not $x280)))
(and $x321 (or $x280 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 14: function core_state_transition, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x98 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x280 (or false false)))
(let (($x252 (or $x280 false false)))
(let (($x646 (not $x252)))
(and $x646 (or $x252 (and (distinct ?x98 ?x98) true))))))))
(check-sat)
; query 15: function core_state_transition, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x280 (or false false)))
(let (($x321 (not $x280)))
(and $x321 (or $x280 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 16: function core_state_transition, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x64 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x280 (or false false)))
(let (($x252 (or $x280 false false)))
(let (($x646 (not $x252)))
(and $x646 (or $x252 (and (distinct ?x64 ?x64) true))))))))
(check-sat)
; query 17: function core_state_transition, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x280 (or false false)))
(let (($x321 (not $x280)))
(and $x321 (or $x280 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 18: function core_state_transition, block 51, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x64 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x280 (or false false)))
(let (($x252 (or $x280 false false)))
(let (($x646 (not $x252)))
(and $x646 (or $x252 (and (distinct ?x64 ?x64) true))))))))
(check-sat)
; query 19: function core_state_transition, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x280 (or false false)))
(let (($x321 (not $x280)))
(and $x321 (or $x280 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 20: function core_state_transition, block 64, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x64 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x280 (or false false)))
(let (($x252 (or $x280 false false)))
(let (($x646 (not $x252)))
(and $x646 (or $x252 (and (distinct ?x64 ?x64) true))))))))
(check-sat)
; query 21: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x147 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x153 (or false false false)))
(let (($x72 (not $x153)))
(and $x72 (or $x153 (and (distinct ?x147 ?x147) true)))))))
(check-sat)
; query 22: function core_state_transition, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x280 (or false false)))
(let (($x321 (not $x280)))
(and $x321 (or $x280 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 23: function core_state_transition, block 80, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x533 (ite (= (_ bv69 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x280 (or false false)))
(let (($x252 (or $x280 false false)))
(let (($x646 (not $x252)))
(and $x646 (or $x252 (and (distinct ?x533 ?x533) true))))))))
(check-sat)
; query 24: function core_state_transition, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x280 (or false false)))
(let (($x321 (not $x280)))
(and $x321 (or $x280 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 25: function core_state_transition, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x33 (ite (= (_ bv101 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x280 (or false false)))
(let (($x252 (or $x280 false false)))
(let (($x646 (not $x252)))
(and $x646 (or $x252 (and (distinct ?x33 ?x33) true))))))))
(check-sat)
; query 26: function core_state_transition, block 99, name %100
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x280 (or false false)))
(let (($x321 (not $x280)))
(and $x321 (or $x280 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 27: function core_state_transition, block 99, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x364 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x280 (or false false)))
(let (($x252 (or $x280 false false)))
(let (($x646 (not $x252)))
(and $x646 (or $x252 (and (distinct ?x364 ?x364) true))))))))
(check-sat)
; query 28: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x274 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x696 ((_ zero_extend 31) ?x274)))
(let ((?x896 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x175 ((_ zero_extend 31) ?x896)))
(let ((?x427 (bvand ?x175 ?x696)))
(let ((?x296 (ite (and (distinct (_ bv0 32) ?x427) true) (_ bv1 1) (_ bv0 1))))
(let ((?x508 ((_ zero_extend 63) ?x296)))
(let (($x280 (or false false)))
(let (($x252 (or $x280 false false)))
(let (($x1941 (or $x252 false)))
(let (($x396 (or $x1941 $x1941 false)))
(let (($x39 (or $x396 false false)))
(let (($x32 (or $x39 false)))
(and (not $x32) (or $x32 (and (distinct ?x508 ?x508) true)))))))))))))))))
(check-sat)
; query 29: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x274 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x696 ((_ zero_extend 31) ?x274)))
(let ((?x896 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x175 ((_ zero_extend 31) ?x896)))
(let ((?x427 (bvand ?x175 ?x696)))
(let ((?x296 (ite (and (distinct (_ bv0 32) ?x427) true) (_ bv1 1) (_ bv0 1))))
(let (($x410 (= (_ bv1 1) ?x296)))
(let ((?x400 (ite $x410 (_ bv1 32) (_ bv0 32))))
(let (($x280 (or false false)))
(let (($x252 (or $x280 false false)))
(let (($x1941 (or $x252 false)))
(let (($x396 (or $x1941 $x1941 false)))
(let (($x39 (or $x396 false false)))
(let (($x8 (or $x39 (ite $x410 false false))))
(and (not $x8) (or $x8 (and (distinct ?x400 ?x400) true))))))))))))))))))
(check-sat)
; query 30: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x274 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x696 ((_ zero_extend 31) ?x274)))
(let ((?x896 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x175 ((_ zero_extend 31) ?x896)))
(let ((?x427 (bvand ?x175 ?x696)))
(let ((?x296 (ite (and (distinct (_ bv0 32) ?x427) true) (_ bv1 1) (_ bv0 1))))
(let (($x410 (= (_ bv1 1) ?x296)))
(let ((?x400 (ite $x410 (_ bv1 32) (_ bv0 32))))
(let ((?x283 ((_ extract 7 0) ?x400)))
(let (($x280 (or false false)))
(let (($x252 (or $x280 false false)))
(let (($x1941 (or $x252 false)))
(let (($x396 (or $x1941 $x1941 false)))
(let (($x39 (or $x396 false false)))
(let (($x8 (or $x39 (ite $x410 false false))))
(let (($x285 (or $x8 false)))
(and (not $x285) (or $x285 (and (distinct ?x283 ?x283) true))))))))))))))))))))
(check-sat)
; query 31: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x280 (or false false)))
(let (($x321 (not $x280)))
(and $x321 (or $x280 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 32: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x896 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x280 (or false false)))
(let (($x252 (or $x280 false false)))
(let (($x646 (not $x252)))
(and $x646 (or $x252 (and (distinct ?x896 ?x896) true))))))))
(check-sat)
; query 33: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x896 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x175 ((_ zero_extend 31) ?x896)))
(let (($x280 (or false false)))
(let (($x252 (or $x280 false false)))
(let (($x1941 (or $x252 false)))
(let (($x473 (not $x1941)))
(and $x473 (or $x1941 (and (distinct ?x175 ?x175) true))))))))))
(check-sat)
; query 34: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x280 (or false false)))
(let (($x321 (not $x280)))
(and $x321 (or $x280 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 35: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x274 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x280 (or false false)))
(let (($x252 (or $x280 false false)))
(let (($x646 (not $x252)))
(and $x646 (or $x252 (and (distinct ?x274 ?x274) true))))))))
(check-sat)
; query 36: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x274 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x696 ((_ zero_extend 31) ?x274)))
(let (($x280 (or false false)))
(let (($x252 (or $x280 false false)))
(let (($x1941 (or $x252 false)))
(let (($x473 (not $x1941)))
(and $x473 (or $x1941 (and (distinct ?x696 ?x696) true))))))))))
(check-sat)
; query 37: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x274 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x696 ((_ zero_extend 31) ?x274)))
(let ((?x896 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x175 ((_ zero_extend 31) ?x896)))
(let ((?x427 (bvand ?x175 ?x696)))
(let (($x280 (or false false)))
(let (($x252 (or $x280 false false)))
(let (($x1941 (or $x252 false)))
(let (($x396 (or $x1941 $x1941 false)))
(and (not $x396) (or $x396 (and (distinct ?x427 ?x427) true)))))))))))))
(check-sat)
; query 38: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x274 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x696 ((_ zero_extend 31) ?x274)))
(let ((?x896 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x175 ((_ zero_extend 31) ?x896)))
(let ((?x427 (bvand ?x175 ?x696)))
(let ((?x296 (ite (and (distinct (_ bv0 32) ?x427) true) (_ bv1 1) (_ bv0 1))))
(let (($x280 (or false false)))
(let (($x252 (or $x280 false false)))
(let (($x1941 (or $x252 false)))
(let (($x396 (or $x1941 $x1941 false)))
(let (($x39 (or $x396 false false)))
(and (not $x39) (or $x39 (and (distinct ?x296 ?x296) true)))))))))))))))
(check-sat)
; query 39: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x6667 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x153 (or false false false)))
(let (($x72 (not $x153)))
(and $x72 (or $x153 (and (distinct ?x6667 ?x6667) true)))))))
(check-sat)
; query 40: function parseval, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.23_32 () (_ BitVec 32))
(assert
 (let (($x4584 (and (distinct (bvmul ((_ sign_extend 32) in.23_32) ((_ sign_extend 32) (_ bv1024 32))) ((_ sign_extend 32) (bvmul in.23_32 (_ bv1024 32)))) true)))
(let (($x7879 (or false false (or $x4584))))
(and (not $x7879) (or $x7879 (and (distinct (bvmul in.23_32 (_ bv1024 32)) (bvmul in.23_32 (_ bv1024 32))) true))))))
(check-sat)
; query 41: function parseval, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.34_32 () (_ BitVec 32))
(assert
 (let (($x4846 (and (distinct (bvmul ((_ sign_extend 32) in.34_32) ((_ sign_extend 32) (_ bv1048576 32))) ((_ sign_extend 32) (bvmul in.34_32 (_ bv1048576 32)))) true)))
(let (($x2174 (or false false (or $x4846))))
(and (not $x2174) (or $x2174 (and (distinct (bvmul in.34_32 (_ bv1048576 32)) (bvmul in.34_32 (_ bv1048576 32))) true))))))
(check-sat)
