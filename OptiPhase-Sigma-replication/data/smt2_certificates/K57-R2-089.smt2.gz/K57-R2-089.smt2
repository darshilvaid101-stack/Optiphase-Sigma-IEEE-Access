; OptiPhase-Sigma refinement certificate for sweep K57-R2-089
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x1892 (or false false)))
(let (($x136 (not $x1892)))
(and $x136 (or $x1892 (and (distinct ((_ sign_extend 16) in25_16) ((_ sign_extend 16) in25_16)) true))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let ((?x111 (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1892 (or false false)))
(let (($x94 (or $x1892 false false)))
(let (($x139 (not $x94)))
(and $x139 (or $x94 (and (distinct ?x111 ?x111) true))))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x1892 (or false false)))
(let (($x136 (not $x1892)))
(and $x136 (or $x1892 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x156 ((_ sign_extend 16) in3_16)))
(let ((?x179 (bvand ?x156 (_ bv127 32))))
(let (($x1892 (or false false)))
(let (($x94 (or $x1892 false false)))
(let (($x139 (not $x94)))
(and $x139 (or $x94 (and (distinct ?x179 ?x179) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x156 ((_ sign_extend 16) in3_16)))
(let ((?x179 (bvand ?x156 (_ bv127 32))))
(let ((?x1675 ((_ extract 15 0) ?x179)))
(let (($x1892 (or false false)))
(let (($x94 (or $x1892 false false)))
(let (($x145 (or $x94 false)))
(let (($x1161 (not $x145)))
(and $x1161 (or $x145 (and (distinct ?x1675 ?x1675) true)))))))))))
(check-sat)
; query 5: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x1892 (or false false)))
(let (($x136 (not $x1892)))
(and $x136 (or $x1892 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 6: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x104 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x1892 (or false false)))
(let (($x94 (or $x1892 false false)))
(let (($x139 (not $x94)))
(and $x139 (or $x94 (and (distinct ?x104 ?x104) true))))))))
(check-sat)
; query 7: function core_bench_list, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x368 (or false false false)))
(let (($x610 (not $x368)))
(and $x610 (or $x368 (and (distinct (bvadd in.0_16 (_ bv1 16)) (bvadd in.0_16 (_ bv1 16))) true))))))
(check-sat)
; query 8: function core_bench_list, block 82, name %83
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let (($x1892 (or false false)))
(let (($x136 (not $x1892)))
(and $x136 (or $x1892 (and (distinct ((_ zero_extend 16) in.02_16) ((_ zero_extend 16) in.02_16)) true))))))
(check-sat)
; query 9: function core_bench_list, block 82, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x220 ((_ zero_extend 16) in.02_16)))
(let ((?x216 (bvmul ?x220 (_ bv4 32))))
(let (($x544 (and (distinct (bvmul ((_ sign_extend 32) ?x220) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x216)) true)))
(let (($x1892 (or false false)))
(let (($x2851 (or $x1892 false (or $x544))))
(and (not $x2851) (or $x2851 (and (distinct ?x216 ?x216) true)))))))))
(check-sat)
; query 10: function core_bench_list, block 82, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let (($x1892 (or false false)))
(let (($x136 (not $x1892)))
(and $x136 (or $x1892 (and (distinct ((_ zero_extend 16) in.04_16) ((_ zero_extend 16) in.04_16)) true))))))
(check-sat)
; query 11: function core_bench_list, block 82, name %86
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x6389 ((_ zero_extend 16) in.04_16)))
(let ((?x220 ((_ zero_extend 16) in.02_16)))
(let ((?x216 (bvmul ?x220 (_ bv4 32))))
(let ((?x142 (bvsub ?x216 ?x6389)))
(let ((?x116 ((_ sign_extend 1) ?x142)))
(let (($x1892 (or false false)))
(let (($x544 (and (distinct (bvmul ((_ sign_extend 32) ?x220) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x216)) true)))
(let (($x2851 (or $x1892 false (or $x544))))
(let (($x40 (or $x2851 $x1892 (or (and (distinct (bvsub ((_ sign_extend 1) ?x216) ((_ sign_extend 1) ?x6389)) ?x116) true)))))
(and (not $x40) (or $x40 (and (distinct ?x142 ?x142) true)))))))))))))
(check-sat)
; query 12: function core_bench_list, block 82, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x1892 (or false false)))
(let (($x136 (not $x1892)))
(and $x136 (or $x1892 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 13: function core_bench_list, block 82, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x6389 ((_ zero_extend 16) in.04_16)))
(let ((?x220 ((_ zero_extend 16) in.02_16)))
(let ((?x216 (bvmul ?x220 (_ bv4 32))))
(let ((?x142 (bvsub ?x216 ?x6389)))
(let ((?x206 ((_ zero_extend 16) in.01_16)))
(let ((?x467 (bvadd ?x206 ?x142)))
(let (($x980 (and (distinct (bvadd ((_ sign_extend 1) ?x206) ((_ sign_extend 1) ?x142)) ((_ sign_extend 1) ?x467)) true)))
(let ((?x116 ((_ sign_extend 1) ?x142)))
(let (($x1892 (or false false)))
(let (($x544 (and (distinct (bvmul ((_ sign_extend 32) ?x220) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x216)) true)))
(let (($x2851 (or $x1892 false (or $x544))))
(let (($x40 (or $x2851 $x1892 (or (and (distinct (bvsub ((_ sign_extend 1) ?x216) ((_ sign_extend 1) ?x6389)) ?x116) true)))))
(let (($x96 (or $x1892 $x40 (or $x980))))
(and (not $x96) (or $x96 (and (distinct ?x467 ?x467) true)))))))))))))))))
(check-sat)
; query 14: function core_bench_list, block 82, name %89
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x6389 ((_ zero_extend 16) in.04_16)))
(let ((?x220 ((_ zero_extend 16) in.02_16)))
(let ((?x216 (bvmul ?x220 (_ bv4 32))))
(let ((?x142 (bvsub ?x216 ?x6389)))
(let ((?x206 ((_ zero_extend 16) in.01_16)))
(let ((?x467 (bvadd ?x206 ?x142)))
(let ((?x2149 ((_ extract 15 0) ?x467)))
(let (($x980 (and (distinct (bvadd ((_ sign_extend 1) ?x206) ((_ sign_extend 1) ?x142)) ((_ sign_extend 1) ?x467)) true)))
(let ((?x116 ((_ sign_extend 1) ?x142)))
(let (($x1892 (or false false)))
(let (($x544 (and (distinct (bvmul ((_ sign_extend 32) ?x220) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x216)) true)))
(let (($x2851 (or $x1892 false (or $x544))))
(let (($x40 (or $x2851 $x1892 (or (and (distinct (bvsub ((_ sign_extend 1) ?x216) ((_ sign_extend 1) ?x6389)) ?x116) true)))))
(let (($x96 (or $x1892 $x40 (or $x980))))
(let (($x49 (or $x96 false)))
(and (not $x49) (or $x49 (and (distinct ?x2149 ?x2149) true)))))))))))))))))))
(check-sat)
; query 15: function core_bench_list, block 82, name %90
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x1892 (or false false)))
(let (($x136 (not $x1892)))
(and $x136 (or $x1892 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 16: function core_bench_list, block 82, name %91
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x119 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1892 (or false false)))
(let (($x94 (or $x1892 false false)))
(let (($x139 (not $x94)))
(and $x139 (or $x94 (and (distinct ?x119 ?x119) true))))))))
(check-sat)
; query 17: function core_bench_state, block 105, name %106
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x368 (or false false false)))
(let (($x610 (not $x368)))
(and $x610 (or $x368 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 18: function core_bench_state, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x368 (or false false false)))
(let (($x610 (not $x368)))
(and $x610 (or $x368 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 19: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1219 (bvadd in.01_32 (_ bv1 32))))
(let (($x35 (and (distinct ?x1219 ?x1219) true)))
(let (($x368 (or false false false)))
(let (($x610 (not $x368)))
(and $x610 (or $x368 $x35)))))))
(check-sat)
; query 20: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1219 (bvadd in.01_32 (_ bv1 32))))
(let ((?x701 (bvmul ?x1219 ?x1219)))
(let (($x368 (or false false false)))
(let (($x61 (or $x368 $x368 false)))
(and (not $x61) (or $x61 (and (distinct ?x701 ?x701) true))))))))
(check-sat)
; query 21: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1219 (bvadd in.01_32 (_ bv1 32))))
(let ((?x701 (bvmul ?x1219 ?x1219)))
(let ((?x3581 (bvmul ?x701 (_ bv2 32))))
(let (($x368 (or false false false)))
(let (($x61 (or $x368 $x368 false)))
(let (($x10 (or $x61 false false)))
(and (not $x10) (or $x10 (and (distinct ?x3581 ?x3581) true))))))))))
(check-sat)
; query 22: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1219 (bvadd in.01_32 (_ bv1 32))))
(let ((?x701 (bvmul ?x1219 ?x1219)))
(let ((?x3581 (bvmul ?x701 (_ bv2 32))))
(let ((?x134 (bvmul ?x3581 (_ bv4 32))))
(let (($x368 (or false false false)))
(let (($x61 (or $x368 $x368 false)))
(let (($x10 (or $x61 false false)))
(let (($x55 (or $x10 false false)))
(and (not $x55) (or $x55 (and (distinct ?x134 ?x134) true))))))))))))
(check-sat)
; query 23: function core_init_matrix, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x368 (or false false false)))
(let (($x610 (not $x368)))
(and $x610 (or $x368 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 24: function core_init_matrix, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x368 (or false false false)))
(let (($x610 (not $x368)))
(and $x610 (or $x368 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 25: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x90 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x368 (or false false false)))
(let (($x610 (not $x368)))
(and $x610 (or $x368 (and (distinct ?x90 ?x90) true)))))))
(check-sat)
; query 26: function core_init_state, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_32 () (_ BitVec 32))
(assert
 (let (($x368 (or false false false)))
(let (($x610 (not $x368)))
(and $x610 (or $x368 (and (distinct (bvadd in.06_32 (_ bv1 32)) (bvadd in.06_32 (_ bv1 32))) true))))))
(check-sat)
; query 27: function core_init_state, block 65, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let (($x368 (or false false false)))
(let (($x610 (not $x368)))
(and $x610 (or $x368 (and (distinct (bvadd in4_32 (_ bv1 32)) (bvadd in4_32 (_ bv1 32))) true))))))
(check-sat)
; query 28: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x615 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x368 (or false false false)))
(let (($x610 (not $x368)))
(and $x610 (or $x368 (and (distinct ?x615 ?x615) true)))))))
(check-sat)
; query 29: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x368 (or false false false)))
(let (($x610 (not $x368)))
(and $x610 (or $x368 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 30: function core_list_init, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1219 (bvadd in.01_32 (_ bv1 32))))
(let (($x35 (and (distinct ?x1219 ?x1219) true)))
(let (($x368 (or false false false)))
(let (($x610 (not $x368)))
(and $x610 (or $x368 $x35)))))))
(check-sat)
; query 31: function core_list_mergesort, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1219 (bvadd in.01_32 (_ bv1 32))))
(let (($x35 (and (distinct ?x1219 ?x1219) true)))
(let (($x573 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x1219)) true)))
(let (($x1667 (or false false (or $x573))))
(and (not $x1667) (or $x1667 $x35)))))))
(check-sat)
; query 32: function core_list_mergesort, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x3088 (ite (bvslt (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x368 (or false false false)))
(let (($x610 (not $x368)))
(and $x610 (or $x368 (and (distinct ?x3088 ?x3088) true)))))))
(check-sat)
; query 33: function core_list_mergesort, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.224_32 () (_ BitVec 32))
(assert
 (let ((?x3137 (ite (= (_ bv0 32) in.224_32) (_ bv1 1) (_ bv0 1))))
(let (($x368 (or false false false)))
(let (($x610 (not $x368)))
(and $x610 (or $x368 (and (distinct ?x3137 ?x3137) true)))))))
(check-sat)
; query 34: function core_list_mergesort, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x1082 (ite (= (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x368 (or false false false)))
(let (($x610 (not $x368)))
(and $x610 (or $x368 (and (distinct ?x1082 ?x1082) true)))))))
(check-sat)
; query 35: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x5445 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x6861 (or false false (or $x5445))))
(and (not $x6861) (or $x6861 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 36: function core_list_mergesort, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x7222 (and (distinct (bvmul ((_ sign_extend 32) in.020_32) ((_ sign_extend 32) (_ bv2 32))) ((_ sign_extend 32) (bvmul in.020_32 (_ bv2 32)))) true)))
(let (($x4838 (or false false (or $x7222))))
(and (not $x4838) (or $x4838 (and (distinct (bvmul in.020_32 (_ bv2 32)) (bvmul in.020_32 (_ bv2 32))) true))))))
(check-sat)
; query 37: function core_state_transition, block 102, name %103
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1892 (or false false)))
(let (($x136 (not $x1892)))
(and $x136 (or $x1892 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 38: function core_state_transition, block 102, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x2759 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1892 (or false false)))
(let (($x94 (or $x1892 false false)))
(let (($x139 (not $x94)))
(and $x139 (or $x94 (and (distinct ?x2759 ?x2759) true))))))))
(check-sat)
; query 39: function core_state_transition, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1892 (or false false)))
(let (($x136 (not $x1892)))
(and $x136 (or $x1892 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 40: function core_state_transition, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x3590 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1892 (or false false)))
(let (($x94 (or $x1892 false false)))
(let (($x139 (not $x94)))
(and $x139 (or $x94 (and (distinct ?x3590 ?x3590) true))))))))
(check-sat)
; query 41: function core_state_transition, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1892 (or false false)))
(let (($x136 (not $x1892)))
(and $x136 (or $x1892 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 42: function core_state_transition, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x2759 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1892 (or false false)))
(let (($x94 (or $x1892 false false)))
(let (($x139 (not $x94)))
(and $x139 (or $x94 (and (distinct ?x2759 ?x2759) true))))))))
(check-sat)
; query 43: function core_state_transition, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1892 (or false false)))
(let (($x136 (not $x1892)))
(and $x136 (or $x1892 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 44: function core_state_transition, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x6415 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1892 (or false false)))
(let (($x94 (or $x1892 false false)))
(let (($x139 (not $x94)))
(and $x139 (or $x94 (and (distinct ?x6415 ?x6415) true))))))))
(check-sat)
; query 45: function core_state_transition, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1892 (or false false)))
(let (($x136 (not $x1892)))
(and $x136 (or $x1892 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 46: function core_state_transition, block 51, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x6415 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1892 (or false false)))
(let (($x94 (or $x1892 false false)))
(let (($x139 (not $x94)))
(and $x139 (or $x94 (and (distinct ?x6415 ?x6415) true))))))))
(check-sat)
; query 47: function core_state_transition, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1892 (or false false)))
(let (($x136 (not $x1892)))
(and $x136 (or $x1892 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 48: function core_state_transition, block 64, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x6415 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1892 (or false false)))
(let (($x94 (or $x1892 false false)))
(let (($x139 (not $x94)))
(and $x139 (or $x94 (and (distinct ?x6415 ?x6415) true))))))))
(check-sat)
; query 49: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x3840 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x368 (or false false false)))
(let (($x610 (not $x368)))
(and $x610 (or $x368 (and (distinct ?x3840 ?x3840) true)))))))
(check-sat)
; query 50: function core_state_transition, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1892 (or false false)))
(let (($x136 (not $x1892)))
(and $x136 (or $x1892 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 51: function core_state_transition, block 80, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x7157 (ite (= (_ bv69 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1892 (or false false)))
(let (($x94 (or $x1892 false false)))
(let (($x139 (not $x94)))
(and $x139 (or $x94 (and (distinct ?x7157 ?x7157) true))))))))
(check-sat)
; query 52: function core_state_transition, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1892 (or false false)))
(let (($x136 (not $x1892)))
(and $x136 (or $x1892 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 53: function core_state_transition, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x865 (ite (= (_ bv101 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1892 (or false false)))
(let (($x94 (or $x1892 false false)))
(let (($x139 (not $x94)))
(and $x139 (or $x94 (and (distinct ?x865 ?x865) true))))))))
(check-sat)
; query 54: function core_state_transition, block 99, name %100
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1892 (or false false)))
(let (($x136 (not $x1892)))
(and $x136 (or $x1892 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 55: function core_state_transition, block 99, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x3590 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1892 (or false false)))
(let (($x94 (or $x1892 false false)))
(let (($x139 (not $x94)))
(and $x139 (or $x94 (and (distinct ?x3590 ?x3590) true))))))))
(check-sat)
; query 56: function crcu8, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x1892 (or false false)))
(let (($x136 (not $x1892)))
(and $x136 (or $x1892 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 57: function crcu8, block 19, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x206 ((_ zero_extend 16) in.01_16)))
(let ((?x5529 (bvxor ?x206 (_ bv16386 32))))
(let (($x1892 (or false false)))
(let (($x94 (or $x1892 false false)))
(let (($x139 (not $x94)))
(and $x139 (or $x94 (and (distinct ?x5529 ?x5529) true)))))))))
(check-sat)
; query 58: function crcu8, block 19, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x206 ((_ zero_extend 16) in.01_16)))
(let ((?x5529 (bvxor ?x206 (_ bv16386 32))))
(let ((?x6926 ((_ extract 15 0) ?x5529)))
(let (($x1892 (or false false)))
(let (($x94 (or $x1892 false false)))
(let (($x145 (or $x94 false)))
(let (($x1161 (not $x145)))
(and $x1161 (or $x145 (and (distinct ?x6926 ?x6926) true)))))))))))
(check-sat)
; query 59: function crcu8, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x1892 (or false false)))
(let (($x136 (not $x1892)))
(and $x136 (or $x1892 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 60: function crcu8, block 29, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1916 ((_ zero_extend 16) in27_16)))
(let ((?x1442 (bvor ?x1916 (_ bv32768 32))))
(let (($x1892 (or false false)))
(let (($x94 (or $x1892 false false)))
(let (($x139 (not $x94)))
(and $x139 (or $x94 (and (distinct ?x1442 ?x1442) true)))))))))
(check-sat)
; query 61: function crcu8, block 29, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1916 ((_ zero_extend 16) in27_16)))
(let ((?x1442 (bvor ?x1916 (_ bv32768 32))))
(let ((?x496 ((_ extract 15 0) ?x1442)))
(let (($x1892 (or false false)))
(let (($x94 (or $x1892 false false)))
(let (($x145 (or $x94 false)))
(let (($x1161 (not $x145)))
(and $x1161 (or $x145 (and (distinct ?x496 ?x496) true)))))))))))
(check-sat)
; query 62: function crcu8, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x1892 (or false false)))
(let (($x136 (not $x1892)))
(and $x136 (or $x1892 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 63: function crcu8, block 33, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1916 ((_ zero_extend 16) in27_16)))
(let ((?x341 (bvand ?x1916 (_ bv32767 32))))
(let (($x1892 (or false false)))
(let (($x94 (or $x1892 false false)))
(let (($x139 (not $x94)))
(and $x139 (or $x94 (and (distinct ?x341 ?x341) true)))))))))
(check-sat)
; query 64: function crcu8, block 33, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1916 ((_ zero_extend 16) in27_16)))
(let ((?x341 (bvand ?x1916 (_ bv32767 32))))
(let ((?x2653 ((_ extract 15 0) ?x341)))
(let (($x1892 (or false false)))
(let (($x94 (or $x1892 false false)))
(let (($x145 (or $x94 false)))
(let (($x1161 (not $x145)))
(and $x1161 (or $x145 (and (distinct ?x2653 ?x2653) true)))))))))))
(check-sat)
; query 65: function crcu8, block 38, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_8 () (_ BitVec 8))
(assert
 (let (($x368 (or false false false)))
(let (($x610 (not $x368)))
(and $x610 (or $x368 (and (distinct (bvadd in.02_8 (_ bv1 8)) (bvadd in.02_8 (_ bv1 8))) true))))))
(check-sat)
; query 66: function crcu8, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x1552 ((_ extract 7 0) in.01_16)))
(let ((?x907 ((_ zero_extend 24) ?x1552)))
(let (($x1892 (or false false)))
(let (($x6077 (or $x1892 false)))
(and (not $x6077) (or $x6077 (and (distinct ?x907 ?x907) true))))))))
(check-sat)
; query 67: function crcu8, block 6, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x1552 ((_ extract 7 0) in.01_16)))
(let ((?x907 ((_ zero_extend 24) ?x1552)))
(let ((?x2963 (bvand ?x907 (_ bv1 32))))
(let (($x1892 (or false false)))
(let (($x6077 (or $x1892 false)))
(let (($x880 (or $x6077 false false)))
(and (not $x880) (or $x880 (and (distinct ?x2963 ?x2963) true))))))))))
(check-sat)
; query 68: function crcu8, block 6, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1552 ((_ extract 7 0) in.01_16)))
(let ((?x907 ((_ zero_extend 24) ?x1552)))
(let ((?x2963 (bvand ?x907 (_ bv1 32))))
(let ((?x7364 ((_ zero_extend 24) in.0_8)))
(let ((?x3121 (bvand ?x7364 (_ bv1 32))))
(let ((?x5884 (bvxor ?x3121 ?x2963)))
(let (($x1892 (or false false)))
(let (($x6077 (or $x1892 false)))
(let (($x880 (or $x6077 false false)))
(let (($x94 (or $x1892 false false)))
(let (($x7485 (or $x94 $x880 false)))
(and (not $x7485) (or $x7485 (and (distinct ?x5884 ?x5884) true)))))))))))))))
(check-sat)
; query 69: function crcu8, block 6, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1552 ((_ extract 7 0) in.01_16)))
(let ((?x907 ((_ zero_extend 24) ?x1552)))
(let ((?x2963 (bvand ?x907 (_ bv1 32))))
(let ((?x7364 ((_ zero_extend 24) in.0_8)))
(let ((?x3121 (bvand ?x7364 (_ bv1 32))))
(let ((?x5884 (bvxor ?x3121 ?x2963)))
(let ((?x4367 ((_ extract 7 0) ?x5884)))
(let (($x1892 (or false false)))
(let (($x6077 (or $x1892 false)))
(let (($x880 (or $x6077 false false)))
(let (($x94 (or $x1892 false false)))
(let (($x7485 (or $x94 $x880 false)))
(let (($x1257 (or $x7485 false)))
(and (not $x1257) (or $x1257 (and (distinct ?x4367 ?x4367) true)))))))))))))))))
(check-sat)
; query 70: function crcu8, block 6, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x1892 (or false false)))
(let (($x136 (not $x1892)))
(and $x136 (or $x1892 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 71: function crcu8, block 6, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x7364 ((_ zero_extend 24) in.0_8)))
(let ((?x7192 (bvashr ?x7364 (_ bv1 32))))
(let (($x1892 (or false false)))
(let (($x94 (or $x1892 false false)))
(let (($x7153 (or $x94 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not $x7153) (or $x7153 (and (distinct ?x7192 ?x7192) true)))))))))
(check-sat)
; query 72: function crcu8, block 6, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x7364 ((_ zero_extend 24) in.0_8)))
(let ((?x7192 (bvashr ?x7364 (_ bv1 32))))
(let ((?x1241 ((_ extract 7 0) ?x7192)))
(let (($x1892 (or false false)))
(let (($x94 (or $x1892 false false)))
(let (($x7153 (or $x94 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x626 (or $x7153 false)))
(and (not $x626) (or $x626 (and (distinct ?x1241 ?x1241) true)))))))))))
(check-sat)
; query 73: function crcu8, block 6, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1552 ((_ extract 7 0) in.01_16)))
(let ((?x907 ((_ zero_extend 24) ?x1552)))
(let ((?x2963 (bvand ?x907 (_ bv1 32))))
(let ((?x7364 ((_ zero_extend 24) in.0_8)))
(let ((?x3121 (bvand ?x7364 (_ bv1 32))))
(let ((?x5884 (bvxor ?x3121 ?x2963)))
(let ((?x4367 ((_ extract 7 0) ?x5884)))
(let ((?x6963 ((_ zero_extend 24) ?x4367)))
(let (($x1892 (or false false)))
(let (($x6077 (or $x1892 false)))
(let (($x880 (or $x6077 false false)))
(let (($x94 (or $x1892 false false)))
(let (($x7485 (or $x94 $x880 false)))
(let (($x1257 (or $x7485 false)))
(let (($x3322 (or $x1257 false)))
(and (not $x3322) (or $x3322 (and (distinct ?x6963 ?x6963) true)))))))))))))))))))
(check-sat)
; query 74: function crcu8, block 6, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1552 ((_ extract 7 0) in.01_16)))
(let ((?x907 ((_ zero_extend 24) ?x1552)))
(let ((?x2963 (bvand ?x907 (_ bv1 32))))
(let ((?x7364 ((_ zero_extend 24) in.0_8)))
(let ((?x3121 (bvand ?x7364 (_ bv1 32))))
(let ((?x5884 (bvxor ?x3121 ?x2963)))
(let ((?x4367 ((_ extract 7 0) ?x5884)))
(let ((?x6963 ((_ zero_extend 24) ?x4367)))
(let ((?x3559 (ite (= (_ bv1 32) ?x6963) (_ bv1 1) (_ bv0 1))))
(let (($x1892 (or false false)))
(let (($x6077 (or $x1892 false)))
(let (($x880 (or $x6077 false false)))
(let (($x94 (or $x1892 false false)))
(let (($x7485 (or $x94 $x880 false)))
(let (($x1257 (or $x7485 false)))
(let (($x3322 (or $x1257 false)))
(let (($x2995 (or $x3322 false false)))
(and (not $x2995) (or $x2995 (and (distinct ?x3559 ?x3559) true)))))))))))))))))))))
(check-sat)
; query 75: function crcu8, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x1892 (or false false)))
(let (($x136 (not $x1892)))
(and $x136 (or $x1892 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 76: function crcu8, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x7364 ((_ zero_extend 24) in.0_8)))
(let ((?x3121 (bvand ?x7364 (_ bv1 32))))
(let (($x1892 (or false false)))
(let (($x94 (or $x1892 false false)))
(let (($x139 (not $x94)))
(and $x139 (or $x94 (and (distinct ?x3121 ?x3121) true)))))))))
(check-sat)
; query 77: function crcu8, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x1892 (or false false)))
(let (($x136 (not $x1892)))
(and $x136 (or $x1892 (and (distinct ((_ extract 7 0) in.01_16) ((_ extract 7 0) in.01_16)) true))))))
(check-sat)
; query 78: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1638 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x404 ((_ zero_extend 31) ?x1638)))
(let ((?x3641 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x4423 ((_ zero_extend 31) ?x3641)))
(let ((?x3557 (bvand ?x4423 ?x404)))
(let ((?x4361 (ite (and (distinct (_ bv0 32) ?x3557) true) (_ bv1 1) (_ bv0 1))))
(let ((?x3625 ((_ zero_extend 63) ?x4361)))
(let (($x1892 (or false false)))
(let (($x94 (or $x1892 false false)))
(let (($x145 (or $x94 false)))
(let (($x4149 (or $x145 $x145 false)))
(let (($x7027 (or $x4149 false false)))
(let (($x2853 (or $x7027 false)))
(and (not $x2853) (or $x2853 (and (distinct ?x3625 ?x3625) true)))))))))))))))))
(check-sat)
; query 79: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1638 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x404 ((_ zero_extend 31) ?x1638)))
(let ((?x3641 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x4423 ((_ zero_extend 31) ?x3641)))
(let ((?x3557 (bvand ?x4423 ?x404)))
(let ((?x4361 (ite (and (distinct (_ bv0 32) ?x3557) true) (_ bv1 1) (_ bv0 1))))
(let (($x1121 (= (_ bv1 1) ?x4361)))
(let ((?x3345 (ite $x1121 (_ bv1 32) (_ bv0 32))))
(let (($x1892 (or false false)))
(let (($x94 (or $x1892 false false)))
(let (($x145 (or $x94 false)))
(let (($x4149 (or $x145 $x145 false)))
(let (($x7027 (or $x4149 false false)))
(let (($x7363 (or $x7027 (ite $x1121 false false))))
(and (not $x7363) (or $x7363 (and (distinct ?x3345 ?x3345) true))))))))))))))))))
(check-sat)
; query 80: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1638 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x404 ((_ zero_extend 31) ?x1638)))
(let ((?x3641 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x4423 ((_ zero_extend 31) ?x3641)))
(let ((?x3557 (bvand ?x4423 ?x404)))
(let ((?x4361 (ite (and (distinct (_ bv0 32) ?x3557) true) (_ bv1 1) (_ bv0 1))))
(let (($x1121 (= (_ bv1 1) ?x4361)))
(let ((?x3345 (ite $x1121 (_ bv1 32) (_ bv0 32))))
(let ((?x4262 ((_ extract 7 0) ?x3345)))
(let (($x1892 (or false false)))
(let (($x94 (or $x1892 false false)))
(let (($x145 (or $x94 false)))
(let (($x4149 (or $x145 $x145 false)))
(let (($x7027 (or $x4149 false false)))
(let (($x7363 (or $x7027 (ite $x1121 false false))))
(let (($x5727 (or $x7363 false)))
(and (not $x5727) (or $x5727 (and (distinct ?x4262 ?x4262) true))))))))))))))))))))
(check-sat)
; query 81: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x1892 (or false false)))
(let (($x136 (not $x1892)))
(and $x136 (or $x1892 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 82: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x3641 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1892 (or false false)))
(let (($x94 (or $x1892 false false)))
(let (($x139 (not $x94)))
(and $x139 (or $x94 (and (distinct ?x3641 ?x3641) true))))))))
(check-sat)
; query 83: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x3641 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x4423 ((_ zero_extend 31) ?x3641)))
(let (($x1892 (or false false)))
(let (($x94 (or $x1892 false false)))
(let (($x145 (or $x94 false)))
(let (($x1161 (not $x145)))
(and $x1161 (or $x145 (and (distinct ?x4423 ?x4423) true))))))))))
(check-sat)
; query 84: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x1892 (or false false)))
(let (($x136 (not $x1892)))
(and $x136 (or $x1892 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 85: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1638 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1892 (or false false)))
(let (($x94 (or $x1892 false false)))
(let (($x139 (not $x94)))
(and $x139 (or $x94 (and (distinct ?x1638 ?x1638) true))))))))
(check-sat)
; query 86: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1638 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x404 ((_ zero_extend 31) ?x1638)))
(let (($x1892 (or false false)))
(let (($x94 (or $x1892 false false)))
(let (($x145 (or $x94 false)))
(let (($x1161 (not $x145)))
(and $x1161 (or $x145 (and (distinct ?x404 ?x404) true))))))))))
(check-sat)
; query 87: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1638 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x404 ((_ zero_extend 31) ?x1638)))
(let ((?x3641 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x4423 ((_ zero_extend 31) ?x3641)))
(let ((?x3557 (bvand ?x4423 ?x404)))
(let (($x1892 (or false false)))
(let (($x94 (or $x1892 false false)))
(let (($x145 (or $x94 false)))
(let (($x4149 (or $x145 $x145 false)))
(and (not $x4149) (or $x4149 (and (distinct ?x3557 ?x3557) true)))))))))))))
(check-sat)
; query 88: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1638 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x404 ((_ zero_extend 31) ?x1638)))
(let ((?x3641 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x4423 ((_ zero_extend 31) ?x3641)))
(let ((?x3557 (bvand ?x4423 ?x404)))
(let ((?x4361 (ite (and (distinct (_ bv0 32) ?x3557) true) (_ bv1 1) (_ bv0 1))))
(let (($x1892 (or false false)))
(let (($x94 (or $x1892 false false)))
(let (($x145 (or $x94 false)))
(let (($x4149 (or $x145 $x145 false)))
(let (($x7027 (or $x4149 false false)))
(and (not $x7027) (or $x7027 (and (distinct ?x4361 ?x4361) true)))))))))))))))
(check-sat)
; query 89: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1739 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x368 (or false false false)))
(let (($x610 (not $x368)))
(and $x610 (or $x368 (and (distinct ?x1739 ?x1739) true)))))))
(check-sat)
; query 90: function matrix_add_const, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x368 (or false false false)))
(let (($x610 (not $x368)))
(and $x610 (or $x368 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 91: function matrix_add_const, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1219 (bvadd in.01_32 (_ bv1 32))))
(let (($x35 (and (distinct ?x1219 ?x1219) true)))
(let (($x368 (or false false false)))
(let (($x610 (not $x368)))
(and $x610 (or $x368 $x35)))))))
(check-sat)
; query 92: function matrix_mul_const, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x368 (or false false false)))
(let (($x610 (not $x368)))
(and $x610 (or $x368 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 93: function matrix_mul_const, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1219 (bvadd in.01_32 (_ bv1 32))))
(let (($x35 (and (distinct ?x1219 ?x1219) true)))
(let (($x368 (or false false false)))
(let (($x610 (not $x368)))
(and $x610 (or $x368 $x35)))))))
(check-sat)
; query 94: function matrix_mul_matrix, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x368 (or false false false)))
(let (($x610 (not $x368)))
(and $x610 (or $x368 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 95: function matrix_mul_matrix, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1219 (bvadd in.01_32 (_ bv1 32))))
(let (($x35 (and (distinct ?x1219 ?x1219) true)))
(let (($x368 (or false false false)))
(let (($x610 (not $x368)))
(and $x610 (or $x368 $x35)))))))
(check-sat)
; query 96: function matrix_mul_matrix, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x368 (or false false false)))
(let (($x610 (not $x368)))
(and $x610 (or $x368 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 97: function matrix_mul_matrix_bitextract, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x368 (or false false false)))
(let (($x610 (not $x368)))
(and $x610 (or $x368 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 98: function matrix_mul_matrix_bitextract, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1219 (bvadd in.01_32 (_ bv1 32))))
(let (($x35 (and (distinct ?x1219 ?x1219) true)))
(let (($x368 (or false false false)))
(let (($x610 (not $x368)))
(and $x610 (or $x368 $x35)))))))
(check-sat)
; query 99: function matrix_mul_matrix_bitextract, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x368 (or false false false)))
(let (($x610 (not $x368)))
(and $x610 (or $x368 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 100: function matrix_mul_vect, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x368 (or false false false)))
(let (($x610 (not $x368)))
(and $x610 (or $x368 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 101: function matrix_mul_vect, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1219 (bvadd in.01_32 (_ bv1 32))))
(let (($x35 (and (distinct ?x1219 ?x1219) true)))
(let (($x368 (or false false false)))
(let (($x610 (not $x368)))
(and $x610 (or $x368 $x35)))))))
(check-sat)
; query 102: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x1892 (or false false)))
(let (($x136 (not $x1892)))
(and $x136 (or $x1892 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 103: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x2215 ((_ sign_extend 16) in.1_16)))
(let ((?x350 (bvadd ?x2215 (_ bv10 32))))
(let (($x7276 (and (distinct (bvadd ((_ sign_extend 1) ?x2215) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x350)) true)))
(let (($x1892 (or false false)))
(let (($x4554 (or $x1892 false (or $x7276))))
(and (not $x4554) (or $x4554 (and (distinct ?x350 ?x350) true)))))))))
(check-sat)
; query 104: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x2215 ((_ sign_extend 16) in.1_16)))
(let ((?x350 (bvadd ?x2215 (_ bv10 32))))
(let ((?x6362 ((_ extract 15 0) ?x350)))
(let (($x7276 (and (distinct (bvadd ((_ sign_extend 1) ?x2215) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x350)) true)))
(let (($x1892 (or false false)))
(let (($x4554 (or $x1892 false (or $x7276))))
(let (($x3616 (or $x4554 false)))
(and (not $x3616) (or $x3616 (and (distinct ?x6362 ?x6362) true)))))))))))
(check-sat)
; query 105: function matrix_sum, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x1723 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x368 (or false false false)))
(let (($x610 (not $x368)))
(and $x610 (or $x368 (and (distinct ?x1723 ?x1723) true)))))))
(check-sat)
; query 106: function matrix_sum, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x1723 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let ((?x4926 ((_ zero_extend 63) ?x1723)))
(let (($x368 (or false false false)))
(let (($x4497 (or $x368 false)))
(and (not $x4497) (or $x4497 (and (distinct ?x4926 ?x4926) true))))))))
(check-sat)
; query 107: function matrix_sum, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x1723 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x6853 (= (_ bv1 1) ?x1723)))
(let ((?x4288 (ite $x6853 (_ bv1 32) (_ bv0 32))))
(let (($x368 (or false false false)))
(let (($x4758 (or $x368 (ite $x6853 false false))))
(and (not $x4758) (or $x4758 (and (distinct ?x4288 ?x4288) true)))))))))
(check-sat)
; query 108: function matrix_sum, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x1892 (or false false)))
(let (($x136 (not $x1892)))
(and $x136 (or $x1892 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 109: function matrix_sum, block 22, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x1723 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x6853 (= (_ bv1 1) ?x1723)))
(let ((?x4288 (ite $x6853 (_ bv1 32) (_ bv0 32))))
(let ((?x2215 ((_ sign_extend 16) in.1_16)))
(let ((?x3041 (bvadd ?x2215 ?x4288)))
(let (($x1630 (and (distinct (bvadd ((_ sign_extend 1) ?x2215) ((_ sign_extend 1) ?x4288)) ((_ sign_extend 1) ?x3041)) true)))
(let (($x368 (or false false false)))
(let (($x4758 (or $x368 (ite $x6853 false false))))
(let (($x1892 (or false false)))
(let (($x4186 (or $x1892 $x4758 (or $x1630))))
(and (not $x4186) (or $x4186 (and (distinct ?x3041 ?x3041) true))))))))))))))
(check-sat)
; query 110: function matrix_sum, block 22, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x1723 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x6853 (= (_ bv1 1) ?x1723)))
(let ((?x4288 (ite $x6853 (_ bv1 32) (_ bv0 32))))
(let ((?x2215 ((_ sign_extend 16) in.1_16)))
(let ((?x3041 (bvadd ?x2215 ?x4288)))
(let ((?x4450 ((_ extract 15 0) ?x3041)))
(let (($x1630 (and (distinct (bvadd ((_ sign_extend 1) ?x2215) ((_ sign_extend 1) ?x4288)) ((_ sign_extend 1) ?x3041)) true)))
(let (($x368 (or false false false)))
(let (($x4758 (or $x368 (ite $x6853 false false))))
(let (($x1892 (or false false)))
(let (($x4186 (or $x1892 $x4758 (or $x1630))))
(let (($x824 (or $x4186 false)))
(and (not $x824) (or $x824 (and (distinct ?x4450 ?x4450) true))))))))))))))))
(check-sat)
; query 111: function matrix_sum, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x368 (or false false false)))
(let (($x610 (not $x368)))
(and $x610 (or $x368 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 112: function matrix_sum, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1219 (bvadd in.01_32 (_ bv1 32))))
(let (($x35 (and (distinct ?x1219 ?x1219) true)))
(let (($x368 (or false false false)))
(let (($x610 (not $x368)))
(and $x610 (or $x368 $x35)))))))
(check-sat)
; query 113: function parseval, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.23_32 () (_ BitVec 32))
(assert
 (let (($x4075 (and (distinct (bvmul ((_ sign_extend 32) in.23_32) ((_ sign_extend 32) (_ bv1024 32))) ((_ sign_extend 32) (bvmul in.23_32 (_ bv1024 32)))) true)))
(let (($x3359 (or false false (or $x4075))))
(and (not $x3359) (or $x3359 (and (distinct (bvmul in.23_32 (_ bv1024 32)) (bvmul in.23_32 (_ bv1024 32))) true))))))
(check-sat)
; query 114: function parseval, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.34_32 () (_ BitVec 32))
(assert
 (let (($x2425 (and (distinct (bvmul ((_ sign_extend 32) in.34_32) ((_ sign_extend 32) (_ bv1048576 32))) ((_ sign_extend 32) (bvmul in.34_32 (_ bv1048576 32)))) true)))
(let (($x2231 (or false false (or $x2425))))
(and (not $x2231) (or $x2231 (and (distinct (bvmul in.34_32 (_ bv1048576 32)) (bvmul in.34_32 (_ bv1048576 32))) true))))))
(check-sat)
; query 115: function partition_memory, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x368 (or false false false)))
(let (($x610 (not $x368)))
(and $x610 (or $x368 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
