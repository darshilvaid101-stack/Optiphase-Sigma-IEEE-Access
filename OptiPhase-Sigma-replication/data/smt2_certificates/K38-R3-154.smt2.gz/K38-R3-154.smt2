; OptiPhase-Sigma refinement certificate for sweep K38-R3-154
; query 0: function BF_cbc_encrypt, block 126, name %127
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.010_64 () (_ BitVec 64))
(assert
 (let (($x72 (and (distinct (bvsub ((_ sign_extend 1) in.010_64) ((_ sign_extend 1) (_ bv8 64))) ((_ sign_extend 1) (bvsub in.010_64 (_ bv8 64)))) true)))
(let (($x430 (or false false (or $x72))))
(and (not $x430) (or $x430 (and (distinct (bvsub in.010_64 (_ bv8 64)) (bvsub in.010_64 (_ bv8 64))) true))))))
(check-sat)
; query 1: function BF_cbc_encrypt, block 366, name %367
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.111_64 () (_ BitVec 64))
(assert
 (let (($x619 (and (distinct (bvsub ((_ sign_extend 1) in.111_64) ((_ sign_extend 1) (_ bv8 64))) ((_ sign_extend 1) (bvsub in.111_64 (_ bv8 64)))) true)))
(let (($x661 (or false false (or $x619))))
(and (not $x661) (or $x661 (and (distinct (bvsub in.111_64 (_ bv8 64)) (bvsub in.111_64 (_ bv8 64))) true))))))
(check-sat)
; query 2: function BF_set_key, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x81 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x436 (or false false (or $x81))))
(and (not $x436) (or $x436 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 3: function BF_set_key, block 69, name %70
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.13_32 () (_ BitVec 32))
(assert
 (let (($x96 (and (distinct (bvadd ((_ sign_extend 1) in.13_32) ((_ sign_extend 1) (_ bv2 32))) ((_ sign_extend 1) (bvadd in.13_32 (_ bv2 32)))) true)))
(let (($x640 (or false false (or $x96))))
(and (not $x640) (or $x640 (and (distinct (bvadd in.13_32 (_ bv2 32)) (bvadd in.13_32 (_ bv2 32))) true))))))
(check-sat)
; query 4: function BF_set_key, block 87, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.24_32 () (_ BitVec 32))
(assert
 (let (($x94 (and (distinct (bvadd ((_ sign_extend 1) in.24_32) ((_ sign_extend 1) (_ bv2 32))) ((_ sign_extend 1) (bvadd in.24_32 (_ bv2 32)))) true)))
(let (($x87 (or false false (or $x94))))
(and (not $x87) (or $x87 (and (distinct (bvadd in.24_32 (_ bv2 32)) (bvadd in.24_32 (_ bv2 32))) true))))))
(check-sat)
; query 5: function main, block 60, name %61
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x121 (or false false)))
(and (not $x121) (or $x121 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 6: function main, block 60, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x19 (ite (bvsge (_ bv57 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x121 (or false false)))
(let (($x313 (or $x121 false false)))
(let (($x32 (not $x313)))
(and $x32 (or $x313 (and (distinct ?x19 ?x19) true))))))))
(check-sat)
; query 7: function main, block 63, name %64
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x399 (or (or false false false) (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x399) (or $x399 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvshl in.01_32 (_ bv4 32))) true)))))
(check-sat)
; query 8: function main, block 63, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x121 (or false false)))
(and (not $x121) (or $x121 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 9: function main, block 63, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x24 ((_ sign_extend 24) in57_8)))
(let ((?x432 (bvshl in.01_32 (_ bv4 32))))
(let ((?x449 (bvadd ?x432 ?x24)))
(let ((?x135 ((_ sign_extend 1) ?x449)))
(let (($x121 (or false false)))
(let (($x399 (or (or false false false) (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x71 (or $x399 $x121 (or (and (distinct (bvadd ((_ sign_extend 1) ?x432) ((_ sign_extend 1) ?x24)) ?x135) true)))))
(and (not $x71) (or $x71 (and (distinct ?x449 ?x449) true)))))))))))
(check-sat)
; query 10: function main, block 63, name %67
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x24 ((_ sign_extend 24) in57_8)))
(let ((?x432 (bvshl in.01_32 (_ bv4 32))))
(let ((?x449 (bvadd ?x432 ?x24)))
(let ((?x86 (bvsub ?x449 (_ bv48 32))))
(let (($x446 (and (distinct (bvsub ((_ sign_extend 1) ?x449) ((_ sign_extend 1) (_ bv48 32))) ((_ sign_extend 1) ?x86)) true)))
(let ((?x135 ((_ sign_extend 1) ?x449)))
(let (($x121 (or false false)))
(let (($x399 (or (or false false false) (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x71 (or $x399 $x121 (or (and (distinct (bvadd ((_ sign_extend 1) ?x432) ((_ sign_extend 1) ?x24)) ?x135) true)))))
(let (($x82 (or $x71 false (or $x446))))
(and (not $x82) (or $x82 (and (distinct ?x86 ?x86) true))))))))))))))
(check-sat)
; query 11: function main, block 68, name %69
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x121 (or false false)))
(and (not $x121) (or $x121 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 12: function main, block 68, name %70
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x66 (ite (bvsle (_ bv65 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x121 (or false false)))
(let (($x313 (or $x121 false false)))
(let (($x32 (not $x313)))
(and $x32 (or $x313 (and (distinct ?x66 ?x66) true))))))))
(check-sat)
; query 13: function main, block 71, name %72
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x121 (or false false)))
(and (not $x121) (or $x121 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 14: function main, block 71, name %73
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x76 (ite (bvsge (_ bv70 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x121 (or false false)))
(let (($x313 (or $x121 false false)))
(let (($x32 (not $x313)))
(and $x32 (or $x313 (and (distinct ?x76 ?x76) true))))))))
(check-sat)
; query 15: function main, block 74, name %75
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x399 (or (or false false false) (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x399) (or $x399 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvshl in.01_32 (_ bv4 32))) true)))))
(check-sat)
; query 16: function main, block 74, name %76
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x121 (or false false)))
(and (not $x121) (or $x121 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 17: function main, block 74, name %77
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x24 ((_ sign_extend 24) in57_8)))
(let ((?x432 (bvshl in.01_32 (_ bv4 32))))
(let ((?x449 (bvadd ?x432 ?x24)))
(let ((?x135 ((_ sign_extend 1) ?x449)))
(let (($x121 (or false false)))
(let (($x399 (or (or false false false) (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x71 (or $x399 $x121 (or (and (distinct (bvadd ((_ sign_extend 1) ?x432) ((_ sign_extend 1) ?x24)) ?x135) true)))))
(and (not $x71) (or $x71 (and (distinct ?x449 ?x449) true)))))))))))
(check-sat)
