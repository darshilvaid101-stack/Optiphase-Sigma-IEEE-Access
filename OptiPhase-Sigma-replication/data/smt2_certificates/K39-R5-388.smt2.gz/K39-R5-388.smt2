; OptiPhase-Sigma refinement certificate for sweep K39-R5-388
; query 0: function BF_ofb64_encrypt, block 82, name %83
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x920 (ite (= (_ bv0 32) in.04_32) (_ bv1 1) (_ bv0 1))))
(let (($x413 (or false false false)))
(and (not $x413) (or $x413 (and (distinct ?x920 ?x920) true))))))
(check-sat)
