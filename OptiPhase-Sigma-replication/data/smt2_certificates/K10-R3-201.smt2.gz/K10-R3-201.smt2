; OptiPhase-Sigma refinement certificate for sweep K10-R3-201
; query 0: function xmalloc, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in7_32 () (_ BitVec 32))
(assert
 (let ((?x13 (ite (and (distinct (_ bv0 32) in7_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x51 (or false false false)))
(and (not $x51) (or $x51 (and (distinct ?x13 ?x13) true))))))
(check-sat)
