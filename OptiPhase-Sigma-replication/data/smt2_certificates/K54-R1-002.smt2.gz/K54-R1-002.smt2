; OptiPhase-Sigma refinement certificate for sweep K54-R1-002
