; OptiPhase-Sigma refinement certificate for sweep K40-R3-113
; query 0: function set_key, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let (($x60 (or false false false)))
(and (not $x60) (or $x60 (and (distinct (bvand in1_64 (_ bv7 64)) (bvand in1_64 (_ bv7 64))) true)))))
(check-sat)
; query 1: function set_key, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x32 (ite (and (distinct (_ bv0 64) (bvand in1_64 (_ bv7 64))) true) (_ bv1 1) (_ bv0 1))))
(let (($x60 (or false false false)))
(let (($x94 (or $x60 false false)))
(and (not $x94) (or $x94 (and (distinct ?x32 ?x32) true)))))))
(check-sat)
