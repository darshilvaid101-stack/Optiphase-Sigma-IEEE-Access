; OptiPhase-Sigma refinement certificate for sweep K30-R4-371
; query 0: function bit_count, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x575 (and (distinct (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1)) (ite (= (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x129 (or false false false)))
(let (($x54 (not $x129)))
(and $x54 (or $x129 $x575))))))
(check-sat)
; query 1: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x22 (ite (bvsgt (_ bv2 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x129 (or false false false)))
(let (($x54 (not $x129)))
(and $x54 (or $x129 (and (distinct ?x22 ?x22) true)))))))
(check-sat)
