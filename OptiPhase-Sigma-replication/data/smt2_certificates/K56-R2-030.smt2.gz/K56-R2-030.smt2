; OptiPhase-Sigma refinement certificate for sweep K56-R2-030
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x295 (or false (or (= ((_ extract 15 15) in25_16) (_ bv1 1))))))
(let (($x152 (or false false)))
(let (($x1174 (not $x152)))
(and $x1174 (or $x295 (and (distinct ((_ sign_extend 16) in25_16) ((_ zero_extend 16) in25_16)) true)))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x625 (and (distinct (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1)) (ite (bvsgt (_ bv34 32) ((_ zero_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))) true)))
(let (($x227 (or (or (or false (or (= ((_ extract 15 15) in25_16) (_ bv1 1)))) false false) $x625)))
(let (($x152 (or false false)))
(let (($x99 (or $x152 false false)))
(let (($x261 (not $x99)))
(and $x261 $x227)))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x152 (or false false)))
(let (($x1174 (not $x152)))
(and $x1174 (or $x152 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x38 ((_ sign_extend 16) in3_16)))
(let ((?x80 (bvand ?x38 (_ bv127 32))))
(let (($x152 (or false false)))
(let (($x99 (or $x152 false false)))
(let (($x261 (not $x99)))
(and $x261 (or $x99 (and (distinct ?x80 ?x80) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x38 ((_ sign_extend 16) in3_16)))
(let ((?x80 (bvand ?x38 (_ bv127 32))))
(let ((?x191 ((_ extract 15 0) ?x80)))
(let (($x131 (or (and (distinct ((_ zero_extend 16) ?x191) ?x80) true) (and (distinct ((_ sign_extend 16) ?x191) ?x80) true))))
(let (($x152 (or false false)))
(let (($x99 (or $x152 false false)))
(let (($x233 (or $x99 false)))
(let (($x74 (not $x233)))
(and $x74 (or (or $x99 $x131) (and (distinct ?x191 ?x191) true))))))))))))
(check-sat)
; query 5: function core_bench_list, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x856 (or false false false)))
(let (($x296 (not $x856)))
(and $x296 (or $x856 (and (distinct (bvadd in.0_16 (_ bv1 16)) (bvadd in.0_16 (_ bv1 16))) true))))))
(check-sat)
; query 6: function core_bench_state, block 105, name %106
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let ((?x132 (bvadd in.1_32 (_ bv1 32))))
(let (($x18 (and (distinct ?x132 ?x132) true)))
(let (($x77 (and (distinct (bvadd ((_ zero_extend 1) in.1_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) ?x132)) true)))
(let (($x160 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x132)) true)))
(let (($x856 (or false false false)))
(let (($x296 (not $x856)))
(and $x296 (or (or false false (or $x160 $x77)) $x18)))))))))
(check-sat)
; query 7: function core_bench_state, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x961 (bvadd in.0_32 (_ bv1 32))))
(let (($x142 (and (distinct ?x961 ?x961) true)))
(let (($x35 (and (distinct (bvadd ((_ zero_extend 1) in.0_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) ?x961)) true)))
(let (($x900 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x961)) true)))
(let (($x856 (or false false false)))
(let (($x296 (not $x856)))
(and $x296 (or (or false false (or $x900 $x35)) $x142)))))))))
(check-sat)
; query 8: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x144 (bvadd in.01_32 (_ bv1 32))))
(let (($x162 (and (distinct ?x144 ?x144) true)))
(let (($x856 (or false false false)))
(let (($x296 (not $x856)))
(and $x296 (or $x856 $x162)))))))
(check-sat)
; query 9: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x144 (bvadd in.01_32 (_ bv1 32))))
(let ((?x182 (bvmul ?x144 ?x144)))
(let (($x856 (or false false false)))
(let (($x430 (or $x856 $x856 false)))
(and (not $x430) (or $x430 (and (distinct ?x182 ?x182) true))))))))
(check-sat)
; query 10: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x144 (bvadd in.01_32 (_ bv1 32))))
(let ((?x182 (bvmul ?x144 ?x144)))
(let ((?x548 (bvmul ?x182 (_ bv2 32))))
(let (($x856 (or false false false)))
(let (($x430 (or $x856 $x856 false)))
(let (($x872 (or $x430 false false)))
(and (not $x872) (or $x872 (and (distinct ?x548 ?x548) true))))))))))
(check-sat)
; query 11: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x144 (bvadd in.01_32 (_ bv1 32))))
(let ((?x182 (bvmul ?x144 ?x144)))
(let ((?x548 (bvmul ?x182 (_ bv2 32))))
(let ((?x85 (bvmul ?x548 (_ bv4 32))))
(let (($x856 (or false false false)))
(let (($x430 (or $x856 $x856 false)))
(let (($x872 (or $x430 false false)))
(let (($x650 (or $x872 false false)))
(and (not $x650) (or $x650 (and (distinct ?x85 ?x85) true))))))))))))
(check-sat)
; query 12: function core_init_matrix, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let ((?x132 (bvadd in.1_32 (_ bv1 32))))
(let (($x18 (and (distinct ?x132 ?x132) true)))
(let (($x856 (or false false false)))
(let (($x296 (not $x856)))
(and $x296 (or $x856 $x18)))))))
(check-sat)
; query 13: function core_init_matrix, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x856 (or false false false)))
(let (($x296 (not $x856)))
(and $x296 (or $x856 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 14: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x73 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x856 (or false false false)))
(let (($x296 (not $x856)))
(and $x296 (or $x856 (and (distinct ?x73 ?x73) true)))))))
(check-sat)
; query 15: function core_init_state, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_32 () (_ BitVec 32))
(assert
 (let (($x179 (and (distinct (bvadd ((_ zero_extend 1) in.06_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.06_32 (_ bv1 32)))) true)))
(let (($x11 (and (distinct (bvadd ((_ sign_extend 1) in.06_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.06_32 (_ bv1 32)))) true)))
(let (($x97 (or (or false false (or $x11 $x179)) (and (distinct (bvadd in.06_32 (_ bv1 32)) (bvadd in.06_32 (_ bv1 32))) true))))
(let (($x856 (or false false false)))
(let (($x296 (not $x856)))
(and $x296 $x97)))))))
(check-sat)
; query 16: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x1266 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x856 (or false false false)))
(let (($x296 (not $x856)))
(and $x296 (or $x856 (and (distinct ?x1266 ?x1266) true)))))))
(check-sat)
; query 17: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x856 (or false false false)))
(let (($x296 (not $x856)))
(and $x296 (or $x856 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 18: function core_list_init, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x144 (bvadd in.01_32 (_ bv1 32))))
(let (($x162 (and (distinct ?x144 ?x144) true)))
(let (($x75 (and (distinct (bvadd ((_ zero_extend 1) in.01_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) ?x144)) true)))
(let (($x856 (or false false false)))
(let (($x296 (not $x856)))
(and $x296 (or (or false false (or $x75)) $x162))))))))
(check-sat)
; query 19: function core_list_mergesort, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x144 (bvadd in.01_32 (_ bv1 32))))
(let (($x162 (and (distinct ?x144 ?x144) true)))
(let (($x86 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x144)) true)))
(let (($x309 (or false false (or $x86))))
(and (not $x309) (or $x309 $x162)))))))
(check-sat)
; query 20: function core_list_mergesort, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x1182 (ite (bvslt (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x856 (or false false false)))
(let (($x296 (not $x856)))
(and $x296 (or $x856 (and (distinct ?x1182 ?x1182) true)))))))
(check-sat)
; query 21: function core_list_mergesort, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.224_32 () (_ BitVec 32))
(assert
 (let ((?x123 (ite (= (_ bv0 32) in.224_32) (_ bv1 1) (_ bv0 1))))
(let (($x856 (or false false false)))
(let (($x296 (not $x856)))
(and $x296 (or $x856 (and (distinct ?x123 ?x123) true)))))))
(check-sat)
; query 22: function core_list_mergesort, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x81 (ite (= (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x856 (or false false false)))
(let (($x296 (not $x856)))
(and $x296 (or $x856 (and (distinct ?x81 ?x81) true)))))))
(check-sat)
; query 23: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x414 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x616 (or false false (or $x414))))
(and (not $x616) (or $x616 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 24: function core_list_mergesort, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x42 (and (distinct (bvmul ((_ sign_extend 32) in.020_32) ((_ sign_extend 32) (_ bv2 32))) ((_ sign_extend 32) (bvmul in.020_32 (_ bv2 32)))) true)))
(let (($x33 (or false false (or $x42))))
(and (not $x33) (or $x33 (and (distinct (bvmul in.020_32 (_ bv2 32)) (bvmul in.020_32 (_ bv2 32))) true))))))
(check-sat)
; query 25: function core_state_transition, block 102, name %103
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x152 (or false false)))
(let (($x1174 (not $x152)))
(and $x1174 (or $x152 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 26: function core_state_transition, block 102, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x829 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x152 (or false false)))
(let (($x99 (or $x152 false false)))
(let (($x261 (not $x99)))
(and $x261 (or $x99 (and (distinct ?x829 ?x829) true))))))))
(check-sat)
; query 27: function core_state_transition, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x152 (or false false)))
(let (($x1174 (not $x152)))
(and $x1174 (or $x152 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 28: function core_state_transition, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1285 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x152 (or false false)))
(let (($x99 (or $x152 false false)))
(let (($x261 (not $x99)))
(and $x261 (or $x99 (and (distinct ?x1285 ?x1285) true))))))))
(check-sat)
; query 29: function core_state_transition, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x152 (or false false)))
(let (($x1174 (not $x152)))
(and $x1174 (or $x152 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 30: function core_state_transition, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x829 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x152 (or false false)))
(let (($x99 (or $x152 false false)))
(let (($x261 (not $x99)))
(and $x261 (or $x99 (and (distinct ?x829 ?x829) true))))))))
(check-sat)
; query 31: function core_state_transition, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x152 (or false false)))
(let (($x1174 (not $x152)))
(and $x1174 (or $x152 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 32: function core_state_transition, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x681 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x152 (or false false)))
(let (($x99 (or $x152 false false)))
(let (($x261 (not $x99)))
(and $x261 (or $x99 (and (distinct ?x681 ?x681) true))))))))
(check-sat)
; query 33: function core_state_transition, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x152 (or false false)))
(let (($x1174 (not $x152)))
(and $x1174 (or $x152 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 34: function core_state_transition, block 51, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x681 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x152 (or false false)))
(let (($x99 (or $x152 false false)))
(let (($x261 (not $x99)))
(and $x261 (or $x99 (and (distinct ?x681 ?x681) true))))))))
(check-sat)
; query 35: function core_state_transition, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x152 (or false false)))
(let (($x1174 (not $x152)))
(and $x1174 (or $x152 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 36: function core_state_transition, block 64, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x681 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x152 (or false false)))
(let (($x99 (or $x152 false false)))
(let (($x261 (not $x99)))
(and $x261 (or $x99 (and (distinct ?x681 ?x681) true))))))))
(check-sat)
; query 37: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x51 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x856 (or false false false)))
(let (($x296 (not $x856)))
(and $x296 (or $x856 (and (distinct ?x51 ?x51) true)))))))
(check-sat)
; query 38: function core_state_transition, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x152 (or false false)))
(let (($x1174 (not $x152)))
(and $x1174 (or $x152 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 39: function core_state_transition, block 80, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x208 (ite (= (_ bv69 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x152 (or false false)))
(let (($x99 (or $x152 false false)))
(let (($x261 (not $x99)))
(and $x261 (or $x99 (and (distinct ?x208 ?x208) true))))))))
(check-sat)
; query 40: function core_state_transition, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x152 (or false false)))
(let (($x1174 (not $x152)))
(and $x1174 (or $x152 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 41: function core_state_transition, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x140 (ite (= (_ bv101 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x152 (or false false)))
(let (($x99 (or $x152 false false)))
(let (($x261 (not $x99)))
(and $x261 (or $x99 (and (distinct ?x140 ?x140) true))))))))
(check-sat)
; query 42: function core_state_transition, block 99, name %100
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x152 (or false false)))
(let (($x1174 (not $x152)))
(and $x1174 (or $x152 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 43: function core_state_transition, block 99, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1285 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x152 (or false false)))
(let (($x99 (or $x152 false false)))
(let (($x261 (not $x99)))
(and $x261 (or $x99 (and (distinct ?x1285 ?x1285) true))))))))
(check-sat)
; query 44: function crcu8, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x152 (or false false)))
(let (($x1174 (not $x152)))
(and $x1174 (or $x152 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 45: function crcu8, block 19, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x292 ((_ zero_extend 16) in.01_16)))
(let ((?x479 (bvxor ?x292 (_ bv16386 32))))
(let (($x152 (or false false)))
(let (($x99 (or $x152 false false)))
(let (($x261 (not $x99)))
(and $x261 (or $x99 (and (distinct ?x479 ?x479) true)))))))))
(check-sat)
; query 46: function crcu8, block 19, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x292 ((_ zero_extend 16) in.01_16)))
(let ((?x479 (bvxor ?x292 (_ bv16386 32))))
(let ((?x921 ((_ extract 15 0) ?x479)))
(let (($x152 (or false false)))
(let (($x99 (or $x152 false false)))
(let (($x30 (or (or $x99 (or (and (distinct ((_ zero_extend 16) ?x921) ?x479) true))) (and (distinct ?x921 ?x921) true))))
(let (($x233 (or $x99 false)))
(let (($x74 (not $x233)))
(and $x74 $x30))))))))))
(check-sat)
; query 47: function crcu8, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x150 (or false (or (= ((_ extract 15 15) in27_16) (_ bv1 1))))))
(let (($x152 (or false false)))
(let (($x1174 (not $x152)))
(and $x1174 (or $x150 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true)))))))
(check-sat)
; query 48: function crcu8, block 29, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x706 ((_ zero_extend 16) in27_16)))
(let ((?x62 (bvor ?x706 (_ bv32768 32))))
(let (($x150 (or false (or (= ((_ extract 15 15) in27_16) (_ bv1 1))))))
(let (($x392 (or $x150 false false)))
(let (($x152 (or false false)))
(let (($x99 (or $x152 false false)))
(let (($x261 (not $x99)))
(and $x261 (or $x392 (and (distinct ?x62 ?x62) true)))))))))))
(check-sat)
; query 49: function crcu8, block 29, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x706 ((_ zero_extend 16) in27_16)))
(let ((?x62 (bvor ?x706 (_ bv32768 32))))
(let ((?x581 ((_ extract 15 0) ?x62)))
(let (($x150 (or false (or (= ((_ extract 15 15) in27_16) (_ bv1 1))))))
(let (($x392 (or $x150 false false)))
(let (($x385 (or (or $x392 (or (and (distinct ((_ zero_extend 16) ?x581) ?x62) true))) (and (distinct ?x581 ?x581) true))))
(let (($x152 (or false false)))
(let (($x99 (or $x152 false false)))
(let (($x233 (or $x99 false)))
(let (($x74 (not $x233)))
(and $x74 $x385))))))))))))
(check-sat)
; query 50: function crcu8, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x29 ((_ extract 7 0) in.01_16)))
(let ((?x532 ((_ zero_extend 24) ?x29)))
(let (($x152 (or false false)))
(let (($x263 (or $x152 false)))
(and (not $x263) (or $x263 (and (distinct ?x532 ?x532) true))))))))
(check-sat)
; query 51: function crcu8, block 6, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x29 ((_ extract 7 0) in.01_16)))
(let ((?x532 ((_ zero_extend 24) ?x29)))
(let ((?x757 (bvand ?x532 (_ bv1 32))))
(let (($x152 (or false false)))
(let (($x263 (or $x152 false)))
(let (($x114 (or $x263 false false)))
(and (not $x114) (or $x114 (and (distinct ?x757 ?x757) true))))))))))
(check-sat)
; query 52: function crcu8, block 6, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x29 ((_ extract 7 0) in.01_16)))
(let ((?x532 ((_ zero_extend 24) ?x29)))
(let ((?x757 (bvand ?x532 (_ bv1 32))))
(let ((?x235 ((_ zero_extend 24) in.0_8)))
(let ((?x662 (bvand ?x235 (_ bv1 32))))
(let ((?x1008 (bvxor ?x662 ?x757)))
(let (($x152 (or false false)))
(let (($x263 (or $x152 false)))
(let (($x114 (or $x263 false false)))
(let (($x99 (or $x152 false false)))
(let (($x198 (or $x99 $x114 false)))
(and (not $x198) (or $x198 (and (distinct ?x1008 ?x1008) true)))))))))))))))
(check-sat)
; query 53: function crcu8, block 6, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x29 ((_ extract 7 0) in.01_16)))
(let ((?x532 ((_ zero_extend 24) ?x29)))
(let ((?x757 (bvand ?x532 (_ bv1 32))))
(let ((?x235 ((_ zero_extend 24) in.0_8)))
(let ((?x662 (bvand ?x235 (_ bv1 32))))
(let ((?x1008 (bvxor ?x662 ?x757)))
(let ((?x1031 ((_ extract 7 0) ?x1008)))
(let (($x431 (or (and (distinct ((_ zero_extend 24) ?x1031) ?x1008) true) (and (distinct ((_ sign_extend 24) ?x1031) ?x1008) true))))
(let (($x152 (or false false)))
(let (($x263 (or $x152 false)))
(let (($x114 (or $x263 false false)))
(let (($x99 (or $x152 false false)))
(let (($x198 (or $x99 $x114 false)))
(let (($x271 (or $x198 $x431)))
(and (not (or $x198 false)) (or $x271 (and (distinct ?x1031 ?x1031) true))))))))))))))))))
(check-sat)
; query 54: function crcu8, block 6, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x152 (or false false)))
(let (($x1174 (not $x152)))
(and $x1174 (or $x152 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 55: function crcu8, block 6, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x235 ((_ zero_extend 24) in.0_8)))
(let ((?x656 (bvlshr ?x235 (_ bv1 32))))
(let ((?x239 (bvashr ?x235 (_ bv1 32))))
(let (($x152 (or false false)))
(let (($x99 (or $x152 false false)))
(let (($x337 (or $x99 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not $x337) (or $x337 (and (distinct ?x239 ?x656) true))))))))))
(check-sat)
; query 56: function crcu8, block 6, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x549 (and (distinct ((_ extract 7 0) (bvashr ((_ zero_extend 24) in.0_8) (_ bv1 32))) ((_ extract 7 0) (bvlshr ((_ zero_extend 24) in.0_8) (_ bv1 32)))) true)))
(let (($x152 (or false false)))
(let (($x99 (or $x152 false false)))
(let (($x337 (or $x99 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x982 (or $x337 false)))
(and (not $x982) (or $x982 $x549))))))))
(check-sat)
; query 57: function crcu8, block 6, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x29 ((_ extract 7 0) in.01_16)))
(let ((?x532 ((_ zero_extend 24) ?x29)))
(let ((?x757 (bvand ?x532 (_ bv1 32))))
(let ((?x235 ((_ zero_extend 24) in.0_8)))
(let ((?x662 (bvand ?x235 (_ bv1 32))))
(let ((?x1008 (bvxor ?x662 ?x757)))
(let ((?x1031 ((_ extract 7 0) ?x1008)))
(let ((?x254 ((_ zero_extend 24) ?x1031)))
(let (($x152 (or false false)))
(let (($x263 (or $x152 false)))
(let (($x114 (or $x263 false false)))
(let (($x99 (or $x152 false false)))
(let (($x198 (or $x99 $x114 false)))
(let (($x271 (or $x198 (or (and (distinct ?x254 ?x1008) true) (and (distinct ((_ sign_extend 24) ?x1031) ?x1008) true)))))
(let (($x416 (or $x271 (or (= ((_ extract 7 7) ?x1031) (_ bv1 1))))))
(and (not (or (or $x198 false) false)) (or $x416 (and (distinct ?x254 ?x254) true)))))))))))))))))))
(check-sat)
; query 58: function crcu8, block 6, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x29 ((_ extract 7 0) in.01_16)))
(let ((?x532 ((_ zero_extend 24) ?x29)))
(let ((?x757 (bvand ?x532 (_ bv1 32))))
(let ((?x235 ((_ zero_extend 24) in.0_8)))
(let ((?x662 (bvand ?x235 (_ bv1 32))))
(let ((?x1008 (bvxor ?x662 ?x757)))
(let ((?x1031 ((_ extract 7 0) ?x1008)))
(let ((?x254 ((_ zero_extend 24) ?x1031)))
(let ((?x832 (ite (= (_ bv1 32) ?x254) (_ bv1 1) (_ bv0 1))))
(let (($x152 (or false false)))
(let (($x263 (or $x152 false)))
(let (($x114 (or $x263 false false)))
(let (($x99 (or $x152 false false)))
(let (($x198 (or $x99 $x114 false)))
(let (($x271 (or $x198 (or (and (distinct ?x254 ?x1008) true) (and (distinct ((_ sign_extend 24) ?x1031) ?x1008) true)))))
(let (($x416 (or $x271 (or (= ((_ extract 7 7) ?x1031) (_ bv1 1))))))
(and (not (or (or (or $x198 false) false) false false)) (or (or $x416 false false) (and (distinct ?x832 ?x832) true))))))))))))))))))))
(check-sat)
; query 59: function crcu8, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x152 (or false false)))
(let (($x1174 (not $x152)))
(and $x1174 (or $x152 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 60: function crcu8, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x235 ((_ zero_extend 24) in.0_8)))
(let ((?x662 (bvand ?x235 (_ bv1 32))))
(let (($x152 (or false false)))
(let (($x99 (or $x152 false false)))
(let (($x261 (not $x99)))
(and $x261 (or $x99 (and (distinct ?x662 ?x662) true)))))))))
(check-sat)
; query 61: function crcu8, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x152 (or false false)))
(let (($x1174 (not $x152)))
(and $x1174 (or $x152 (and (distinct ((_ extract 7 0) in.01_16) ((_ extract 7 0) in.01_16)) true))))))
(check-sat)
; query 62: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x229 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x434 ((_ zero_extend 31) ?x229)))
(let ((?x442 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x542 ((_ zero_extend 31) ?x442)))
(let ((?x484 (bvand ?x542 ?x434)))
(let ((?x515 (ite (and (distinct (_ bv0 32) ?x484) true) (_ bv1 1) (_ bv0 1))))
(let ((?x509 ((_ zero_extend 63) ?x515)))
(let (($x152 (or false false)))
(let (($x99 (or $x152 false false)))
(let (($x233 (or $x99 false)))
(let (($x456 (or $x233 $x233 false)))
(let (($x507 (or $x456 false false)))
(let (($x801 (or $x507 false)))
(and (not $x801) (or $x801 (and (distinct ?x509 ?x509) true)))))))))))))))))
(check-sat)
; query 63: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x229 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x434 ((_ zero_extend 31) ?x229)))
(let ((?x442 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x542 ((_ zero_extend 31) ?x442)))
(let ((?x484 (bvand ?x542 ?x434)))
(let ((?x515 (ite (and (distinct (_ bv0 32) ?x484) true) (_ bv1 1) (_ bv0 1))))
(let (($x1067 (= (_ bv1 1) ?x515)))
(let ((?x329 (ite $x1067 (_ bv1 32) (_ bv0 32))))
(let (($x152 (or false false)))
(let (($x99 (or $x152 false false)))
(let (($x233 (or $x99 false)))
(let (($x456 (or $x233 $x233 false)))
(let (($x507 (or $x456 false false)))
(let (($x574 (or $x507 (ite $x1067 false false))))
(and (not $x574) (or $x574 (and (distinct ?x329 ?x329) true))))))))))))))))))
(check-sat)
; query 64: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x229 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x434 ((_ zero_extend 31) ?x229)))
(let ((?x442 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x542 ((_ zero_extend 31) ?x442)))
(let ((?x484 (bvand ?x542 ?x434)))
(let ((?x515 (ite (and (distinct (_ bv0 32) ?x484) true) (_ bv1 1) (_ bv0 1))))
(let (($x1067 (= (_ bv1 1) ?x515)))
(let ((?x329 (ite $x1067 (_ bv1 32) (_ bv0 32))))
(let ((?x273 ((_ extract 7 0) ?x329)))
(let (($x702 (or (and (distinct ((_ zero_extend 24) ?x273) ?x329) true) (and (distinct ((_ sign_extend 24) ?x273) ?x329) true))))
(let (($x152 (or false false)))
(let (($x99 (or $x152 false false)))
(let (($x233 (or $x99 false)))
(let (($x456 (or $x233 $x233 false)))
(let (($x507 (or $x456 false false)))
(let (($x574 (or $x507 (ite $x1067 false false))))
(and (not (or $x574 false)) (or (or $x574 $x702) (and (distinct ?x273 ?x273) true))))))))))))))))))))
(check-sat)
; query 65: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x152 (or false false)))
(let (($x1174 (not $x152)))
(and $x1174 (or $x152 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 66: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x442 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x152 (or false false)))
(let (($x99 (or $x152 false false)))
(let (($x261 (not $x99)))
(and $x261 (or $x99 (and (distinct ?x442 ?x442) true))))))))
(check-sat)
; query 67: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x442 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x542 ((_ zero_extend 31) ?x442)))
(let (($x152 (or false false)))
(let (($x99 (or $x152 false false)))
(let (($x233 (or $x99 false)))
(let (($x74 (not $x233)))
(and $x74 (or $x233 (and (distinct ?x542 ?x542) true))))))))))
(check-sat)
; query 68: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x152 (or false false)))
(let (($x1174 (not $x152)))
(and $x1174 (or $x152 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 69: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x229 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x152 (or false false)))
(let (($x99 (or $x152 false false)))
(let (($x261 (not $x99)))
(and $x261 (or $x99 (and (distinct ?x229 ?x229) true))))))))
(check-sat)
; query 70: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x229 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x434 ((_ zero_extend 31) ?x229)))
(let (($x152 (or false false)))
(let (($x99 (or $x152 false false)))
(let (($x233 (or $x99 false)))
(let (($x74 (not $x233)))
(and $x74 (or $x233 (and (distinct ?x434 ?x434) true))))))))))
(check-sat)
; query 71: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x229 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x434 ((_ zero_extend 31) ?x229)))
(let ((?x442 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x542 ((_ zero_extend 31) ?x442)))
(let ((?x484 (bvand ?x542 ?x434)))
(let (($x152 (or false false)))
(let (($x99 (or $x152 false false)))
(let (($x233 (or $x99 false)))
(let (($x456 (or $x233 $x233 false)))
(and (not $x456) (or $x456 (and (distinct ?x484 ?x484) true)))))))))))))
(check-sat)
; query 72: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x229 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x434 ((_ zero_extend 31) ?x229)))
(let ((?x442 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x542 ((_ zero_extend 31) ?x442)))
(let ((?x484 (bvand ?x542 ?x434)))
(let ((?x515 (ite (and (distinct (_ bv0 32) ?x484) true) (_ bv1 1) (_ bv0 1))))
(let (($x152 (or false false)))
(let (($x99 (or $x152 false false)))
(let (($x233 (or $x99 false)))
(let (($x456 (or $x233 $x233 false)))
(let (($x507 (or $x456 false false)))
(and (not $x507) (or $x507 (and (distinct ?x515 ?x515) true)))))))))))))))
(check-sat)
; query 73: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x970 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x856 (or false false false)))
(let (($x296 (not $x856)))
(and $x296 (or $x856 (and (distinct ?x970 ?x970) true)))))))
(check-sat)
; query 74: function matrix_add_const, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x961 (bvadd in.0_32 (_ bv1 32))))
(let (($x142 (and (distinct ?x961 ?x961) true)))
(let (($x856 (or false false false)))
(let (($x296 (not $x856)))
(and $x296 (or $x856 $x142)))))))
(check-sat)
; query 75: function matrix_add_const, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x144 (bvadd in.01_32 (_ bv1 32))))
(let (($x162 (and (distinct ?x144 ?x144) true)))
(let (($x856 (or false false false)))
(let (($x296 (not $x856)))
(and $x296 (or $x856 $x162)))))))
(check-sat)
; query 76: function matrix_mul_const, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x961 (bvadd in.0_32 (_ bv1 32))))
(let (($x142 (and (distinct ?x961 ?x961) true)))
(let (($x856 (or false false false)))
(let (($x296 (not $x856)))
(and $x296 (or $x856 $x142)))))))
(check-sat)
; query 77: function matrix_mul_const, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x144 (bvadd in.01_32 (_ bv1 32))))
(let (($x162 (and (distinct ?x144 ?x144) true)))
(let (($x856 (or false false false)))
(let (($x296 (not $x856)))
(and $x296 (or $x856 $x162)))))))
(check-sat)
; query 78: function matrix_mul_matrix, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x961 (bvadd in.0_32 (_ bv1 32))))
(let (($x142 (and (distinct ?x961 ?x961) true)))
(let (($x856 (or false false false)))
(let (($x296 (not $x856)))
(and $x296 (or $x856 $x142)))))))
(check-sat)
; query 79: function matrix_mul_matrix, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x144 (bvadd in.01_32 (_ bv1 32))))
(let (($x162 (and (distinct ?x144 ?x144) true)))
(let (($x856 (or false false false)))
(let (($x296 (not $x856)))
(and $x296 (or $x856 $x162)))))))
(check-sat)
; query 80: function matrix_mul_matrix, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x856 (or false false false)))
(let (($x296 (not $x856)))
(and $x296 (or $x856 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 81: function matrix_mul_matrix_bitextract, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x961 (bvadd in.0_32 (_ bv1 32))))
(let (($x142 (and (distinct ?x961 ?x961) true)))
(let (($x856 (or false false false)))
(let (($x296 (not $x856)))
(and $x296 (or $x856 $x142)))))))
(check-sat)
; query 82: function matrix_mul_matrix_bitextract, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x144 (bvadd in.01_32 (_ bv1 32))))
(let (($x162 (and (distinct ?x144 ?x144) true)))
(let (($x856 (or false false false)))
(let (($x296 (not $x856)))
(and $x296 (or $x856 $x162)))))))
(check-sat)
; query 83: function matrix_mul_matrix_bitextract, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x856 (or false false false)))
(let (($x296 (not $x856)))
(and $x296 (or $x856 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 84: function matrix_mul_vect, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x961 (bvadd in.0_32 (_ bv1 32))))
(let (($x142 (and (distinct ?x961 ?x961) true)))
(let (($x856 (or false false false)))
(let (($x296 (not $x856)))
(and $x296 (or $x856 $x142)))))))
(check-sat)
; query 85: function matrix_mul_vect, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x144 (bvadd in.01_32 (_ bv1 32))))
(let (($x162 (and (distinct ?x144 ?x144) true)))
(let (($x856 (or false false false)))
(let (($x296 (not $x856)))
(and $x296 (or $x856 $x162)))))))
(check-sat)
; query 86: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x152 (or false false)))
(let (($x1174 (not $x152)))
(and $x1174 (or $x152 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 87: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x284 ((_ sign_extend 16) in.1_16)))
(let ((?x310 (bvadd ?x284 (_ bv10 32))))
(let (($x370 (and (distinct (bvadd ((_ sign_extend 1) ?x284) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x310)) true)))
(let (($x152 (or false false)))
(let (($x720 (or $x152 false (or $x370))))
(and (not $x720) (or $x720 (and (distinct ?x310 ?x310) true)))))))))
(check-sat)
; query 88: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x284 ((_ sign_extend 16) in.1_16)))
(let ((?x310 (bvadd ?x284 (_ bv10 32))))
(let ((?x617 ((_ extract 15 0) ?x310)))
(let (($x370 (and (distinct (bvadd ((_ sign_extend 1) ?x284) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x310)) true)))
(let (($x152 (or false false)))
(let (($x720 (or $x152 false (or $x370))))
(let (($x541 (or $x720 false)))
(and (not $x541) (or $x541 (and (distinct ?x617 ?x617) true)))))))))))
(check-sat)
; query 89: function matrix_sum, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x678 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x856 (or false false false)))
(let (($x296 (not $x856)))
(and $x296 (or $x856 (and (distinct ?x678 ?x678) true)))))))
(check-sat)
; query 90: function matrix_sum, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x678 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let ((?x281 ((_ zero_extend 63) ?x678)))
(let (($x856 (or false false false)))
(let (($x354 (or $x856 false)))
(and (not $x354) (or $x354 (and (distinct ?x281 ?x281) true))))))))
(check-sat)
; query 91: function matrix_sum, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x678 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x464 (= (_ bv1 1) ?x678)))
(let ((?x460 (ite $x464 (_ bv1 32) (_ bv0 32))))
(let (($x856 (or false false false)))
(let (($x316 (or $x856 (ite $x464 false false))))
(and (not $x316) (or $x316 (and (distinct ?x460 ?x460) true)))))))))
(check-sat)
; query 92: function matrix_sum, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x152 (or false false)))
(let (($x1174 (not $x152)))
(and $x1174 (or $x152 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 93: function matrix_sum, block 22, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x678 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x464 (= (_ bv1 1) ?x678)))
(let ((?x460 (ite $x464 (_ bv1 32) (_ bv0 32))))
(let ((?x284 ((_ sign_extend 16) in.1_16)))
(let ((?x802 (bvadd ?x284 ?x460)))
(let (($x988 (and (distinct (bvadd ((_ sign_extend 1) ?x284) ((_ sign_extend 1) ?x460)) ((_ sign_extend 1) ?x802)) true)))
(let (($x856 (or false false false)))
(let (($x316 (or $x856 (ite $x464 false false))))
(let (($x152 (or false false)))
(let (($x420 (or $x152 $x316 (or $x988))))
(and (not $x420) (or $x420 (and (distinct ?x802 ?x802) true))))))))))))))
(check-sat)
; query 94: function matrix_sum, block 22, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x678 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x464 (= (_ bv1 1) ?x678)))
(let ((?x460 (ite $x464 (_ bv1 32) (_ bv0 32))))
(let ((?x284 ((_ sign_extend 16) in.1_16)))
(let ((?x802 (bvadd ?x284 ?x460)))
(let ((?x648 ((_ extract 15 0) ?x802)))
(let (($x988 (and (distinct (bvadd ((_ sign_extend 1) ?x284) ((_ sign_extend 1) ?x460)) ((_ sign_extend 1) ?x802)) true)))
(let (($x856 (or false false false)))
(let (($x316 (or $x856 (ite $x464 false false))))
(let (($x152 (or false false)))
(let (($x420 (or $x152 $x316 (or $x988))))
(let (($x323 (or $x420 false)))
(and (not $x323) (or $x323 (and (distinct ?x648 ?x648) true))))))))))))))))
(check-sat)
; query 95: function matrix_sum, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x961 (bvadd in.0_32 (_ bv1 32))))
(let (($x142 (and (distinct ?x961 ?x961) true)))
(let (($x856 (or false false false)))
(let (($x296 (not $x856)))
(and $x296 (or $x856 $x142)))))))
(check-sat)
; query 96: function matrix_sum, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x144 (bvadd in.01_32 (_ bv1 32))))
(let (($x162 (and (distinct ?x144 ?x144) true)))
(let (($x856 (or false false false)))
(let (($x296 (not $x856)))
(and $x296 (or $x856 $x162)))))))
(check-sat)
; query 97: function parseval, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.23_32 () (_ BitVec 32))
(assert
 (let (($x976 (and (distinct (bvmul ((_ sign_extend 32) in.23_32) ((_ sign_extend 32) (_ bv1024 32))) ((_ sign_extend 32) (bvmul in.23_32 (_ bv1024 32)))) true)))
(let (($x539 (or false false (or $x976))))
(and (not $x539) (or $x539 (and (distinct (bvmul in.23_32 (_ bv1024 32)) (bvmul in.23_32 (_ bv1024 32))) true))))))
(check-sat)
; query 98: function parseval, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.34_32 () (_ BitVec 32))
(assert
 (let (($x700 (and (distinct (bvmul ((_ sign_extend 32) in.34_32) ((_ sign_extend 32) (_ bv1048576 32))) ((_ sign_extend 32) (bvmul in.34_32 (_ bv1048576 32)))) true)))
(let (($x804 (or false false (or $x700))))
(and (not $x804) (or $x804 (and (distinct (bvmul in.34_32 (_ bv1048576 32)) (bvmul in.34_32 (_ bv1048576 32))) true))))))
(check-sat)
