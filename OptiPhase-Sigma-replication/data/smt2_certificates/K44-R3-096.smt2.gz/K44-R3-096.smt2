; OptiPhase-Sigma refinement certificate for sweep K44-R3-096
; query 0: function IsPowerOfTwo, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x137 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x547 (or false false false)))
(let (($x703 (not $x547)))
(and $x703 (or $x547 (and (distinct ?x137 ?x137) true)))))))
(check-sat)
; query 1: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x137 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x547 (or false false false)))
(let (($x703 (not $x547)))
(and $x703 (or $x547 (and (distinct ?x137 ?x137) true)))))))
(check-sat)
; query 2: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x276 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x547 (or false false false)))
(let (($x703 (not $x547)))
(and $x703 (or $x547 (and (distinct ?x276 ?x276) true)))))))
(check-sat)
