; OptiPhase-Sigma refinement certificate for sweep K45-R4-322
; query 0: function Index_to_frequency, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x43 (ite (bvuge in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x108 (or false false false)))
(let (($x114 (not $x108)))
(and $x114 (or $x108 (and (distinct ?x43 ?x43) true)))))))
(check-sat)
; query 1: function IsPowerOfTwo, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x753 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x108 (or false false false)))
(let (($x114 (not $x108)))
(and $x114 (or $x108 (and (distinct ?x753 ?x753) true)))))))
(check-sat)
; query 2: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x753 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x108 (or false false false)))
(let (($x114 (not $x108)))
(and $x114 (or $x108 (and (distinct ?x753 ?x753) true)))))))
(check-sat)
; query 3: function main, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x217 (ite (= (_ bv4 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x108 (or false false false)))
(let (($x114 (not $x108)))
(and $x114 (or $x108 (and (distinct ?x217 ?x217) true)))))))
(check-sat)
; query 4: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x428 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x108 (or false false false)))
(let (($x114 (not $x108)))
(and $x114 (or $x108 (and (distinct ?x428 ?x428) true)))))))
(check-sat)
