; OptiPhase-Sigma refinement certificate for sweep K30-R4-365
; query 0: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x559 (ite (bvsgt (_ bv2 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x609 (or false false false)))
(and (not $x609) (or $x609 (and (distinct ?x559 ?x559) true))))))
(check-sat)
