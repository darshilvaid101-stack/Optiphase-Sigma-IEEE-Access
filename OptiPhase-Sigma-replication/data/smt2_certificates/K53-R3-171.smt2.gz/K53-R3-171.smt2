; OptiPhase-Sigma refinement certificate for sweep K53-R3-171
; query 0: function check, block 157, name %158
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x135 (and (distinct (ite (= (_ bv112233 32) in0_32) (_ bv1 1) (_ bv0 1)) (ite (= (_ bv4294967295 32) in0_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x234 (or false false false)))
(let (($x72 (not $x234)))
(and $x72 (or $x234 $x135))))))
(check-sat)
; query 1: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x207 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x234 (or false false false)))
(let (($x72 (not $x234)))
(and $x72 (or $x234 (and (distinct ?x207 ?x207) true)))))))
(check-sat)
; query 2: function set1d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x1111 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x234 (or false false false)))
(let (($x72 (not $x234)))
(and $x72 (or $x234 (and (distinct ?x1111 ?x1111) true)))))))
(check-sat)
; query 3: function set1ds, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x710 (ite (= (_ bv4294967295 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x234 (or false false false)))
(let (($x72 (not $x234)))
(and $x72 (or $x234 (and (distinct ?x710 ?x710) true)))))))
(check-sat)
; query 4: function set2d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x1111 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x234 (or false false false)))
(let (($x72 (not $x234)))
(and $x72 (or $x234 (and (distinct ?x1111 ?x1111) true)))))))
(check-sat)
