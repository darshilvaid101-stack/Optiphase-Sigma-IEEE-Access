; OptiPhase-Sigma refinement certificate for sweep K16-R1-005
