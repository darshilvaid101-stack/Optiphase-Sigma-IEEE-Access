; OptiPhase-Sigma refinement certificate for sweep K46-R4-333
; query 0: function main, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x5 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x14 (or false false false)))
(and (not $x14) (or $x14 (and (distinct ?x5 ?x5) true))))))
(check-sat)
