; OptiPhase-Sigma refinement certificate for sweep K45-R4-335
; query 0: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x150 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x15 (or false false false)))
(let (($x18 (not $x15)))
(and $x18 (or $x15 (and (distinct ?x150 ?x150) true)))))))
(check-sat)
; query 1: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x49 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x15 (or false false false)))
(let (($x18 (not $x15)))
(and $x18 (or $x15 (and (distinct ?x49 ?x49) true)))))))
(check-sat)
