; OptiPhase-Sigma refinement certificate for sweep K43-R3-274
; query 0: function crc32buf, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_64 () (_ BitVec 64))
(assert
 (let (($x384 (or false false false)))
(let (($x40 (not $x384)))
(and $x40 (or $x384 (and (distinct (bvxor in.02_64 (_ bv18446744073709551615 64)) (bvxor in.02_64 (_ bv18446744073709551615 64))) true))))))
(check-sat)
; query 1: function main, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x249 (ite (and (distinct (_ bv0 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x384 (or false false false)))
(let (($x40 (not $x384)))
(and $x40 (or $x384 (and (distinct ?x249 ?x249) true)))))))
(check-sat)
; query 2: function main, block 17, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x249 (ite (and (distinct (_ bv0 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let ((?x27 ((_ zero_extend 31) ?x249)))
(let (($x384 (or false false false)))
(let (($x227 (or $x384 false)))
(and (not $x227) (or $x227 (and (distinct ?x27 ?x27) true))))))))
(check-sat)
