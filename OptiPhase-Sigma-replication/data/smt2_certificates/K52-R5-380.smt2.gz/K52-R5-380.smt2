; OptiPhase-Sigma refinement certificate for sweep K52-R5-380
; query 0: function s162, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x160 (ite (bvslt (_ bv0 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x20 (or false false false)))
(and (not $x20) (or $x20 (and (distinct ?x160 ?x160) true))))))
(check-sat)
