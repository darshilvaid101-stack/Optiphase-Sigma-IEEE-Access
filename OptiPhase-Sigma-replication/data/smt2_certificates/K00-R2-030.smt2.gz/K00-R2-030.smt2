; OptiPhase-Sigma refinement certificate for sweep K00-R2-030
; query 0: function init_array, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x12 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x14 (or false false (or $x12))))
(and (not $x14) (or $x14 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function init_array, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x24 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x26 (or false false (or $x24))))
(and (not $x26) (or $x26 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function kernel_correlation, block 120, name %121
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let (($x36 (and (distinct (bvadd ((_ sign_extend 1) in.2_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.2_32 (_ bv1 32)))) true)))
(let (($x38 (or false false (or $x36))))
(and (not $x38) (or $x38 (and (distinct (bvadd in.2_32 (_ bv1 32)) (bvadd in.2_32 (_ bv1 32))) true))))))
(check-sat)
; query 3: function kernel_correlation, block 123, name %124
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.24_32 () (_ BitVec 32))
(assert
 (let (($x48 (and (distinct (bvadd ((_ sign_extend 1) in.24_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.24_32 (_ bv1 32)))) true)))
(let (($x50 (or false false (or $x48))))
(and (not $x50) (or $x50 (and (distinct (bvadd in.24_32 (_ bv1 32)) (bvadd in.24_32 (_ bv1 32))) true))))))
(check-sat)
; query 4: function kernel_correlation, block 25, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x60 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x62 (or false false (or $x60))))
(and (not $x62) (or $x62 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 5: function kernel_correlation, block 32, name %33
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x24 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x26 (or false false (or $x24))))
(and (not $x26) (or $x26 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 6: function kernel_correlation, block 65, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.13_32 () (_ BitVec 32))
(assert
 (let (($x72 (and (distinct (bvadd ((_ sign_extend 1) in.13_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.13_32 (_ bv1 32)))) true)))
(let (($x74 (or false false (or $x72))))
(and (not $x74) (or $x74 (and (distinct (bvadd in.13_32 (_ bv1 32)) (bvadd in.13_32 (_ bv1 32))) true))))))
(check-sat)
; query 7: function kernel_correlation, block 91, name %92
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x84 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x86 (or false false (or $x84))))
(and (not $x86) (or $x86 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function print_array, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x12 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x14 (or false false (or $x12))))
(and (not $x14) (or $x14 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 9: function print_array, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x24 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x26 (or false false (or $x24))))
(and (not $x26) (or $x26 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
