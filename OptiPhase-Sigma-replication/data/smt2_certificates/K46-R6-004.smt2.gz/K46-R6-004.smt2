; OptiPhase-Sigma refinement certificate for sweep K46-R6-004
; query 0: function adpcm_decoder, block 61, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.013_32 () (_ BitVec 32))
(declare-fun in.210_32 () (_ BitVec 32))
(assert
 (let ((?x67 (bvadd in.210_32 in.013_32)))
(let ((?x327 (bvsub in.013_32 in.210_32)))
(let (($x823 (and (distinct (bvadd ((_ sign_extend 1) in.210_32) ((_ sign_extend 1) in.013_32)) ((_ sign_extend 1) ?x67)) true)))
(let (($x155 (and (distinct (bvsub ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x327)) true)))
(and (not (or false false (or $x155))) (or (or false false (or $x823)) (and (distinct ?x327 ?x67) true))))))))
(check-sat)
; query 1: function main, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x267 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x54 (or false false false)))
(and (not $x54) (or $x54 (and (distinct ?x267 ?x267) true))))))
(check-sat)
