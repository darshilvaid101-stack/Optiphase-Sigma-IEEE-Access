; OptiPhase-Sigma refinement certificate for sweep K10-R1-005
