; OptiPhase-Sigma refinement certificate for sweep K51-R3-087
; query 0: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x41 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x217 (or false false false)))
(let (($x18 (not $x217)))
(and $x18 (or $x217 (and (distinct ?x41 ?x41) true)))))))
(check-sat)
; query 1: function set1d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x480 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x217 (or false false false)))
(let (($x18 (not $x217)))
(and $x18 (or $x217 (and (distinct ?x480 ?x480) true)))))))
(check-sat)
; query 2: function set1ds, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x789 (ite (= (_ bv4294967295 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x217 (or false false false)))
(let (($x18 (not $x217)))
(and $x18 (or $x217 (and (distinct ?x789 ?x789) true)))))))
(check-sat)
; query 3: function set2d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x480 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x217 (or false false false)))
(let (($x18 (not $x217)))
(and $x18 (or $x217 (and (distinct ?x480 ?x480) true)))))))
(check-sat)
