; OptiPhase-Sigma refinement certificate for sweep K56-R2-080
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x129 (or false false)))
(let (($x1911 (not $x129)))
(and $x1911 (or $x129 (and (distinct ((_ sign_extend 16) in25_16) ((_ sign_extend 16) in25_16)) true))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let ((?x19 (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))))
(let (($x129 (or false false)))
(let (($x555 (or $x129 false false)))
(let (($x229 (not $x555)))
(and $x229 (or $x555 (and (distinct ?x19 ?x19) true))))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x129 (or false false)))
(let (($x1911 (not $x129)))
(and $x1911 (or $x129 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x392 ((_ sign_extend 16) in3_16)))
(let ((?x759 (bvand ?x392 (_ bv127 32))))
(let (($x129 (or false false)))
(let (($x555 (or $x129 false false)))
(let (($x229 (not $x555)))
(and $x229 (or $x555 (and (distinct ?x759 ?x759) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x392 ((_ sign_extend 16) in3_16)))
(let ((?x759 (bvand ?x392 (_ bv127 32))))
(let ((?x337 ((_ extract 15 0) ?x759)))
(let (($x129 (or false false)))
(let (($x555 (or $x129 false false)))
(let (($x426 (or $x555 false)))
(let (($x515 (not $x426)))
(and $x515 (or $x426 (and (distinct ?x337 ?x337) true)))))))))))
(check-sat)
; query 5: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x129 (or false false)))
(let (($x1911 (not $x129)))
(and $x1911 (or $x129 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 6: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x591 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x129 (or false false)))
(let (($x555 (or $x129 false false)))
(let (($x229 (not $x555)))
(and $x229 (or $x555 (and (distinct ?x591 ?x591) true))))))))
(check-sat)
; query 7: function core_bench_list, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x52 (or false false false)))
(let (($x336 (not $x52)))
(and $x336 (or $x52 (and (distinct (bvadd in.0_16 (_ bv1 16)) (bvadd in.0_16 (_ bv1 16))) true))))))
(check-sat)
; query 8: function core_bench_list, block 82, name %83
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let (($x129 (or false false)))
(let (($x1911 (not $x129)))
(and $x1911 (or $x129 (and (distinct ((_ zero_extend 16) in.02_16) ((_ zero_extend 16) in.02_16)) true))))))
(check-sat)
; query 9: function core_bench_list, block 82, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x269 ((_ zero_extend 16) in.02_16)))
(let ((?x952 (bvmul ?x269 (_ bv4 32))))
(let (($x362 (and (distinct (bvmul ((_ sign_extend 32) ?x269) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x952)) true)))
(let (($x129 (or false false)))
(let (($x117 (or $x129 false (or $x362))))
(and (not $x117) (or $x117 (and (distinct ?x952 ?x952) true)))))))))
(check-sat)
; query 10: function core_bench_list, block 82, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let (($x129 (or false false)))
(let (($x1911 (not $x129)))
(and $x1911 (or $x129 (and (distinct ((_ zero_extend 16) in.04_16) ((_ zero_extend 16) in.04_16)) true))))))
(check-sat)
; query 11: function core_bench_list, block 82, name %86
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x206 ((_ zero_extend 16) in.04_16)))
(let ((?x269 ((_ zero_extend 16) in.02_16)))
(let ((?x952 (bvmul ?x269 (_ bv4 32))))
(let ((?x74 (bvsub ?x952 ?x206)))
(let ((?x2117 ((_ sign_extend 1) ?x74)))
(let (($x129 (or false false)))
(let (($x362 (and (distinct (bvmul ((_ sign_extend 32) ?x269) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x952)) true)))
(let (($x117 (or $x129 false (or $x362))))
(let (($x418 (or $x117 $x129 (or (and (distinct (bvsub ((_ sign_extend 1) ?x952) ((_ sign_extend 1) ?x206)) ?x2117) true)))))
(and (not $x418) (or $x418 (and (distinct ?x74 ?x74) true)))))))))))))
(check-sat)
; query 12: function core_bench_list, block 82, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x129 (or false false)))
(let (($x1911 (not $x129)))
(and $x1911 (or $x129 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 13: function core_bench_list, block 82, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x206 ((_ zero_extend 16) in.04_16)))
(let ((?x269 ((_ zero_extend 16) in.02_16)))
(let ((?x952 (bvmul ?x269 (_ bv4 32))))
(let ((?x74 (bvsub ?x952 ?x206)))
(let ((?x114 ((_ zero_extend 16) in.01_16)))
(let ((?x1732 (bvadd ?x114 ?x74)))
(let (($x1442 (and (distinct (bvadd ((_ sign_extend 1) ?x114) ((_ sign_extend 1) ?x74)) ((_ sign_extend 1) ?x1732)) true)))
(let ((?x2117 ((_ sign_extend 1) ?x74)))
(let (($x129 (or false false)))
(let (($x362 (and (distinct (bvmul ((_ sign_extend 32) ?x269) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x952)) true)))
(let (($x117 (or $x129 false (or $x362))))
(let (($x418 (or $x117 $x129 (or (and (distinct (bvsub ((_ sign_extend 1) ?x952) ((_ sign_extend 1) ?x206)) ?x2117) true)))))
(let (($x104 (or $x129 $x418 (or $x1442))))
(and (not $x104) (or $x104 (and (distinct ?x1732 ?x1732) true)))))))))))))))))
(check-sat)
; query 14: function core_bench_list, block 82, name %89
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x206 ((_ zero_extend 16) in.04_16)))
(let ((?x269 ((_ zero_extend 16) in.02_16)))
(let ((?x952 (bvmul ?x269 (_ bv4 32))))
(let ((?x74 (bvsub ?x952 ?x206)))
(let ((?x114 ((_ zero_extend 16) in.01_16)))
(let ((?x1732 (bvadd ?x114 ?x74)))
(let ((?x725 ((_ extract 15 0) ?x1732)))
(let (($x1442 (and (distinct (bvadd ((_ sign_extend 1) ?x114) ((_ sign_extend 1) ?x74)) ((_ sign_extend 1) ?x1732)) true)))
(let ((?x2117 ((_ sign_extend 1) ?x74)))
(let (($x129 (or false false)))
(let (($x362 (and (distinct (bvmul ((_ sign_extend 32) ?x269) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x952)) true)))
(let (($x117 (or $x129 false (or $x362))))
(let (($x418 (or $x117 $x129 (or (and (distinct (bvsub ((_ sign_extend 1) ?x952) ((_ sign_extend 1) ?x206)) ?x2117) true)))))
(let (($x104 (or $x129 $x418 (or $x1442))))
(let (($x152 (or $x104 false)))
(and (not $x152) (or $x152 (and (distinct ?x725 ?x725) true)))))))))))))))))))
(check-sat)
; query 15: function core_bench_list, block 82, name %90
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x129 (or false false)))
(let (($x1911 (not $x129)))
(and $x1911 (or $x129 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 16: function core_bench_list, block 82, name %91
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x858 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x129 (or false false)))
(let (($x555 (or $x129 false false)))
(let (($x229 (not $x555)))
(and $x229 (or $x555 (and (distinct ?x858 ?x858) true))))))))
(check-sat)
; query 17: function core_bench_state, block 105, name %106
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x52 (or false false false)))
(let (($x336 (not $x52)))
(and $x336 (or $x52 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 18: function core_bench_state, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x52 (or false false false)))
(let (($x336 (not $x52)))
(and $x336 (or $x52 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 19: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x166 (bvadd in.01_32 (_ bv1 32))))
(let (($x9703 (and (distinct ?x166 ?x166) true)))
(let (($x52 (or false false false)))
(let (($x336 (not $x52)))
(and $x336 (or $x52 $x9703)))))))
(check-sat)
; query 20: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x166 (bvadd in.01_32 (_ bv1 32))))
(let ((?x15625 (bvmul ?x166 ?x166)))
(let (($x52 (or false false false)))
(let (($x38715 (or $x52 $x52 false)))
(and (not $x38715) (or $x38715 (and (distinct ?x15625 ?x15625) true))))))))
(check-sat)
; query 21: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x166 (bvadd in.01_32 (_ bv1 32))))
(let ((?x15625 (bvmul ?x166 ?x166)))
(let ((?x8722 (bvmul ?x15625 (_ bv2 32))))
(let (($x52 (or false false false)))
(let (($x38715 (or $x52 $x52 false)))
(let (($x511 (or $x38715 false false)))
(and (not $x511) (or $x511 (and (distinct ?x8722 ?x8722) true))))))))))
(check-sat)
; query 22: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x166 (bvadd in.01_32 (_ bv1 32))))
(let ((?x15625 (bvmul ?x166 ?x166)))
(let ((?x8722 (bvmul ?x15625 (_ bv2 32))))
(let ((?x49 (bvmul ?x8722 (_ bv4 32))))
(let (($x52 (or false false false)))
(let (($x38715 (or $x52 $x52 false)))
(let (($x511 (or $x38715 false false)))
(let (($x365 (or $x511 false false)))
(and (not $x365) (or $x365 (and (distinct ?x49 ?x49) true))))))))))))
(check-sat)
; query 23: function core_init_matrix, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x52 (or false false false)))
(let (($x336 (not $x52)))
(and $x336 (or $x52 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 24: function core_init_matrix, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x52 (or false false false)))
(let (($x336 (not $x52)))
(and $x336 (or $x52 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 25: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x411 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x336 (not $x52)))
(and $x336 (or $x52 (and (distinct ?x411 ?x411) true)))))))
(check-sat)
; query 26: function core_init_state, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_32 () (_ BitVec 32))
(assert
 (let (($x52 (or false false false)))
(let (($x336 (not $x52)))
(and $x336 (or $x52 (and (distinct (bvadd in.06_32 (_ bv1 32)) (bvadd in.06_32 (_ bv1 32))) true))))))
(check-sat)
; query 27: function core_init_state, block 65, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let (($x52 (or false false false)))
(let (($x336 (not $x52)))
(and $x336 (or $x52 (and (distinct (bvadd in4_32 (_ bv1 32)) (bvadd in4_32 (_ bv1 32))) true))))))
(check-sat)
; query 28: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x406 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x336 (not $x52)))
(and $x336 (or $x52 (and (distinct ?x406 ?x406) true)))))))
(check-sat)
; query 29: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x52 (or false false false)))
(let (($x336 (not $x52)))
(and $x336 (or $x52 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 30: function core_list_init, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x166 (bvadd in.01_32 (_ bv1 32))))
(let (($x9703 (and (distinct ?x166 ?x166) true)))
(let (($x52 (or false false false)))
(let (($x336 (not $x52)))
(and $x336 (or $x52 $x9703)))))))
(check-sat)
; query 31: function core_list_mergesort, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x166 (bvadd in.01_32 (_ bv1 32))))
(let (($x9703 (and (distinct ?x166 ?x166) true)))
(let (($x10507 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x166)) true)))
(let (($x39321 (or false false (or $x10507))))
(and (not $x39321) (or $x39321 $x9703)))))))
(check-sat)
; query 32: function core_list_mergesort, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x40161 (ite (bvslt (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x336 (not $x52)))
(and $x336 (or $x52 (and (distinct ?x40161 ?x40161) true)))))))
(check-sat)
; query 33: function core_list_mergesort, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.224_32 () (_ BitVec 32))
(assert
 (let ((?x44699 (ite (= (_ bv0 32) in.224_32) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x336 (not $x52)))
(and $x336 (or $x52 (and (distinct ?x44699 ?x44699) true)))))))
(check-sat)
; query 34: function core_list_mergesort, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x12613 (ite (= (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x336 (not $x52)))
(and $x336 (or $x52 (and (distinct ?x12613 ?x12613) true)))))))
(check-sat)
; query 35: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x9305 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x2179 (or false false (or $x9305))))
(and (not $x2179) (or $x2179 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 36: function core_list_mergesort, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x44461 (and (distinct (bvmul ((_ sign_extend 32) in.020_32) ((_ sign_extend 32) (_ bv2 32))) ((_ sign_extend 32) (bvmul in.020_32 (_ bv2 32)))) true)))
(let (($x344 (or false false (or $x44461))))
(and (not $x344) (or $x344 (and (distinct (bvmul in.020_32 (_ bv2 32)) (bvmul in.020_32 (_ bv2 32))) true))))))
(check-sat)
; query 37: function core_state_transition, block 102, name %103
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x129 (or false false)))
(let (($x1911 (not $x129)))
(and $x1911 (or $x129 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 38: function core_state_transition, block 102, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x21517 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x129 (or false false)))
(let (($x555 (or $x129 false false)))
(let (($x229 (not $x555)))
(and $x229 (or $x555 (and (distinct ?x21517 ?x21517) true))))))))
(check-sat)
; query 39: function core_state_transition, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x129 (or false false)))
(let (($x1911 (not $x129)))
(and $x1911 (or $x129 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 40: function core_state_transition, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1207 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x129 (or false false)))
(let (($x555 (or $x129 false false)))
(let (($x229 (not $x555)))
(and $x229 (or $x555 (and (distinct ?x1207 ?x1207) true))))))))
(check-sat)
; query 41: function core_state_transition, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x129 (or false false)))
(let (($x1911 (not $x129)))
(and $x1911 (or $x129 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 42: function core_state_transition, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x21517 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x129 (or false false)))
(let (($x555 (or $x129 false false)))
(let (($x229 (not $x555)))
(and $x229 (or $x555 (and (distinct ?x21517 ?x21517) true))))))))
(check-sat)
; query 43: function core_state_transition, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x129 (or false false)))
(let (($x1911 (not $x129)))
(and $x1911 (or $x129 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 44: function core_state_transition, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x19583 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x129 (or false false)))
(let (($x555 (or $x129 false false)))
(let (($x229 (not $x555)))
(and $x229 (or $x555 (and (distinct ?x19583 ?x19583) true))))))))
(check-sat)
; query 45: function core_state_transition, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x129 (or false false)))
(let (($x1911 (not $x129)))
(and $x1911 (or $x129 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 46: function core_state_transition, block 51, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x19583 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x129 (or false false)))
(let (($x555 (or $x129 false false)))
(let (($x229 (not $x555)))
(and $x229 (or $x555 (and (distinct ?x19583 ?x19583) true))))))))
(check-sat)
; query 47: function core_state_transition, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x129 (or false false)))
(let (($x1911 (not $x129)))
(and $x1911 (or $x129 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 48: function core_state_transition, block 64, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x19583 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x129 (or false false)))
(let (($x555 (or $x129 false false)))
(let (($x229 (not $x555)))
(and $x229 (or $x555 (and (distinct ?x19583 ?x19583) true))))))))
(check-sat)
; query 49: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x9933 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x336 (not $x52)))
(and $x336 (or $x52 (and (distinct ?x9933 ?x9933) true)))))))
(check-sat)
; query 50: function core_state_transition, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x129 (or false false)))
(let (($x1911 (not $x129)))
(and $x1911 (or $x129 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 51: function core_state_transition, block 80, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x2368 (ite (= (_ bv69 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x129 (or false false)))
(let (($x555 (or $x129 false false)))
(let (($x229 (not $x555)))
(and $x229 (or $x555 (and (distinct ?x2368 ?x2368) true))))))))
(check-sat)
; query 52: function core_state_transition, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x129 (or false false)))
(let (($x1911 (not $x129)))
(and $x1911 (or $x129 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 53: function core_state_transition, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x3274 (ite (= (_ bv101 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x129 (or false false)))
(let (($x555 (or $x129 false false)))
(let (($x229 (not $x555)))
(and $x229 (or $x555 (and (distinct ?x3274 ?x3274) true))))))))
(check-sat)
; query 54: function core_state_transition, block 99, name %100
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x129 (or false false)))
(let (($x1911 (not $x129)))
(and $x1911 (or $x129 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 55: function core_state_transition, block 99, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1207 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x129 (or false false)))
(let (($x555 (or $x129 false false)))
(let (($x229 (not $x555)))
(and $x229 (or $x555 (and (distinct ?x1207 ?x1207) true))))))))
(check-sat)
; query 56: function crcu8, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x129 (or false false)))
(let (($x1911 (not $x129)))
(and $x1911 (or $x129 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 57: function crcu8, block 19, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x114 ((_ zero_extend 16) in.01_16)))
(let ((?x1516 (bvxor ?x114 (_ bv16386 32))))
(let (($x129 (or false false)))
(let (($x555 (or $x129 false false)))
(let (($x229 (not $x555)))
(and $x229 (or $x555 (and (distinct ?x1516 ?x1516) true)))))))))
(check-sat)
; query 58: function crcu8, block 19, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x114 ((_ zero_extend 16) in.01_16)))
(let ((?x1516 (bvxor ?x114 (_ bv16386 32))))
(let ((?x1660 ((_ extract 15 0) ?x1516)))
(let (($x129 (or false false)))
(let (($x555 (or $x129 false false)))
(let (($x426 (or $x555 false)))
(let (($x515 (not $x426)))
(and $x515 (or $x426 (and (distinct ?x1660 ?x1660) true)))))))))))
(check-sat)
; query 59: function crcu8, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x129 (or false false)))
(let (($x1911 (not $x129)))
(and $x1911 (or $x129 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 60: function crcu8, block 29, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x11918 ((_ zero_extend 16) in27_16)))
(let ((?x44546 (bvor ?x11918 (_ bv32768 32))))
(let (($x129 (or false false)))
(let (($x555 (or $x129 false false)))
(let (($x229 (not $x555)))
(and $x229 (or $x555 (and (distinct ?x44546 ?x44546) true)))))))))
(check-sat)
; query 61: function crcu8, block 29, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x11918 ((_ zero_extend 16) in27_16)))
(let ((?x44546 (bvor ?x11918 (_ bv32768 32))))
(let ((?x251 ((_ extract 15 0) ?x44546)))
(let (($x129 (or false false)))
(let (($x555 (or $x129 false false)))
(let (($x426 (or $x555 false)))
(let (($x515 (not $x426)))
(and $x515 (or $x426 (and (distinct ?x251 ?x251) true)))))))))))
(check-sat)
; query 62: function crcu8, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x129 (or false false)))
(let (($x1911 (not $x129)))
(and $x1911 (or $x129 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 63: function crcu8, block 33, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x11918 ((_ zero_extend 16) in27_16)))
(let ((?x43087 (bvand ?x11918 (_ bv32767 32))))
(let (($x129 (or false false)))
(let (($x555 (or $x129 false false)))
(let (($x229 (not $x555)))
(and $x229 (or $x555 (and (distinct ?x43087 ?x43087) true)))))))))
(check-sat)
; query 64: function crcu8, block 33, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x11918 ((_ zero_extend 16) in27_16)))
(let ((?x43087 (bvand ?x11918 (_ bv32767 32))))
(let ((?x16087 ((_ extract 15 0) ?x43087)))
(let (($x129 (or false false)))
(let (($x555 (or $x129 false false)))
(let (($x426 (or $x555 false)))
(let (($x515 (not $x426)))
(and $x515 (or $x426 (and (distinct ?x16087 ?x16087) true)))))))))))
(check-sat)
; query 65: function crcu8, block 38, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_8 () (_ BitVec 8))
(assert
 (let (($x52 (or false false false)))
(let (($x336 (not $x52)))
(and $x336 (or $x52 (and (distinct (bvadd in.02_8 (_ bv1 8)) (bvadd in.02_8 (_ bv1 8))) true))))))
(check-sat)
; query 66: function crcu8, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x41816 ((_ extract 7 0) in.01_16)))
(let ((?x40062 ((_ zero_extend 24) ?x41816)))
(let (($x129 (or false false)))
(let (($x1534 (or $x129 false)))
(and (not $x1534) (or $x1534 (and (distinct ?x40062 ?x40062) true))))))))
(check-sat)
; query 67: function crcu8, block 6, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x41816 ((_ extract 7 0) in.01_16)))
(let ((?x40062 ((_ zero_extend 24) ?x41816)))
(let ((?x40750 (bvand ?x40062 (_ bv1 32))))
(let (($x129 (or false false)))
(let (($x1534 (or $x129 false)))
(let (($x42401 (or $x1534 false false)))
(and (not $x42401) (or $x42401 (and (distinct ?x40750 ?x40750) true))))))))))
(check-sat)
; query 68: function crcu8, block 6, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x41816 ((_ extract 7 0) in.01_16)))
(let ((?x40062 ((_ zero_extend 24) ?x41816)))
(let ((?x40750 (bvand ?x40062 (_ bv1 32))))
(let ((?x39322 ((_ zero_extend 24) in.0_8)))
(let ((?x17192 (bvand ?x39322 (_ bv1 32))))
(let ((?x798 (bvxor ?x17192 ?x40750)))
(let (($x129 (or false false)))
(let (($x1534 (or $x129 false)))
(let (($x42401 (or $x1534 false false)))
(let (($x555 (or $x129 false false)))
(let (($x386 (or $x555 $x42401 false)))
(and (not $x386) (or $x386 (and (distinct ?x798 ?x798) true)))))))))))))))
(check-sat)
; query 69: function crcu8, block 6, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x41816 ((_ extract 7 0) in.01_16)))
(let ((?x40062 ((_ zero_extend 24) ?x41816)))
(let ((?x40750 (bvand ?x40062 (_ bv1 32))))
(let ((?x39322 ((_ zero_extend 24) in.0_8)))
(let ((?x17192 (bvand ?x39322 (_ bv1 32))))
(let ((?x798 (bvxor ?x17192 ?x40750)))
(let ((?x42161 ((_ extract 7 0) ?x798)))
(let (($x129 (or false false)))
(let (($x1534 (or $x129 false)))
(let (($x42401 (or $x1534 false false)))
(let (($x555 (or $x129 false false)))
(let (($x386 (or $x555 $x42401 false)))
(let (($x1195 (or $x386 false)))
(and (not $x1195) (or $x1195 (and (distinct ?x42161 ?x42161) true)))))))))))))))))
(check-sat)
; query 70: function crcu8, block 6, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x129 (or false false)))
(let (($x1911 (not $x129)))
(and $x1911 (or $x129 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 71: function crcu8, block 6, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x39322 ((_ zero_extend 24) in.0_8)))
(let ((?x17725 (bvashr ?x39322 (_ bv1 32))))
(let (($x129 (or false false)))
(let (($x555 (or $x129 false false)))
(let (($x16210 (or $x555 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not $x16210) (or $x16210 (and (distinct ?x17725 ?x17725) true)))))))))
(check-sat)
; query 72: function crcu8, block 6, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x39322 ((_ zero_extend 24) in.0_8)))
(let ((?x17725 (bvashr ?x39322 (_ bv1 32))))
(let ((?x7186 ((_ extract 7 0) ?x17725)))
(let (($x129 (or false false)))
(let (($x555 (or $x129 false false)))
(let (($x16210 (or $x555 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x318 (or $x16210 false)))
(and (not $x318) (or $x318 (and (distinct ?x7186 ?x7186) true)))))))))))
(check-sat)
; query 73: function crcu8, block 6, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x41816 ((_ extract 7 0) in.01_16)))
(let ((?x40062 ((_ zero_extend 24) ?x41816)))
(let ((?x40750 (bvand ?x40062 (_ bv1 32))))
(let ((?x39322 ((_ zero_extend 24) in.0_8)))
(let ((?x17192 (bvand ?x39322 (_ bv1 32))))
(let ((?x798 (bvxor ?x17192 ?x40750)))
(let ((?x42161 ((_ extract 7 0) ?x798)))
(let ((?x13925 ((_ zero_extend 24) ?x42161)))
(let (($x129 (or false false)))
(let (($x1534 (or $x129 false)))
(let (($x42401 (or $x1534 false false)))
(let (($x555 (or $x129 false false)))
(let (($x386 (or $x555 $x42401 false)))
(let (($x1195 (or $x386 false)))
(let (($x18424 (or $x1195 false)))
(and (not $x18424) (or $x18424 (and (distinct ?x13925 ?x13925) true)))))))))))))))))))
(check-sat)
; query 74: function crcu8, block 6, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x41816 ((_ extract 7 0) in.01_16)))
(let ((?x40062 ((_ zero_extend 24) ?x41816)))
(let ((?x40750 (bvand ?x40062 (_ bv1 32))))
(let ((?x39322 ((_ zero_extend 24) in.0_8)))
(let ((?x17192 (bvand ?x39322 (_ bv1 32))))
(let ((?x798 (bvxor ?x17192 ?x40750)))
(let ((?x42161 ((_ extract 7 0) ?x798)))
(let ((?x13925 ((_ zero_extend 24) ?x42161)))
(let ((?x1869 (ite (= (_ bv1 32) ?x13925) (_ bv1 1) (_ bv0 1))))
(let (($x129 (or false false)))
(let (($x1534 (or $x129 false)))
(let (($x42401 (or $x1534 false false)))
(let (($x555 (or $x129 false false)))
(let (($x386 (or $x555 $x42401 false)))
(let (($x1195 (or $x386 false)))
(let (($x18424 (or $x1195 false)))
(let (($x21337 (or $x18424 false false)))
(and (not $x21337) (or $x21337 (and (distinct ?x1869 ?x1869) true)))))))))))))))))))))
(check-sat)
; query 75: function crcu8, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x129 (or false false)))
(let (($x1911 (not $x129)))
(and $x1911 (or $x129 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 76: function crcu8, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x39322 ((_ zero_extend 24) in.0_8)))
(let ((?x17192 (bvand ?x39322 (_ bv1 32))))
(let (($x129 (or false false)))
(let (($x555 (or $x129 false false)))
(let (($x229 (not $x555)))
(and $x229 (or $x555 (and (distinct ?x17192 ?x17192) true)))))))))
(check-sat)
; query 77: function crcu8, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x129 (or false false)))
(let (($x1911 (not $x129)))
(and $x1911 (or $x129 (and (distinct ((_ extract 7 0) in.01_16) ((_ extract 7 0) in.01_16)) true))))))
(check-sat)
; query 78: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x12265 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x41890 ((_ zero_extend 31) ?x12265)))
(let ((?x16145 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x20437 ((_ zero_extend 31) ?x16145)))
(let ((?x41896 (bvand ?x20437 ?x41890)))
(let ((?x1924 (ite (and (distinct (_ bv0 32) ?x41896) true) (_ bv1 1) (_ bv0 1))))
(let ((?x16555 ((_ zero_extend 63) ?x1924)))
(let (($x129 (or false false)))
(let (($x555 (or $x129 false false)))
(let (($x426 (or $x555 false)))
(let (($x2200 (or $x426 $x426 false)))
(let (($x6992 (or $x2200 false false)))
(let (($x10315 (or $x6992 false)))
(and (not $x10315) (or $x10315 (and (distinct ?x16555 ?x16555) true)))))))))))))))))
(check-sat)
; query 79: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x12265 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x41890 ((_ zero_extend 31) ?x12265)))
(let ((?x16145 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x20437 ((_ zero_extend 31) ?x16145)))
(let ((?x41896 (bvand ?x20437 ?x41890)))
(let ((?x1924 (ite (and (distinct (_ bv0 32) ?x41896) true) (_ bv1 1) (_ bv0 1))))
(let (($x21085 (= (_ bv1 1) ?x1924)))
(let ((?x1917 (ite $x21085 (_ bv1 32) (_ bv0 32))))
(let (($x129 (or false false)))
(let (($x555 (or $x129 false false)))
(let (($x426 (or $x555 false)))
(let (($x2200 (or $x426 $x426 false)))
(let (($x6992 (or $x2200 false false)))
(let (($x20840 (or $x6992 (ite $x21085 false false))))
(and (not $x20840) (or $x20840 (and (distinct ?x1917 ?x1917) true))))))))))))))))))
(check-sat)
; query 80: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x12265 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x41890 ((_ zero_extend 31) ?x12265)))
(let ((?x16145 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x20437 ((_ zero_extend 31) ?x16145)))
(let ((?x41896 (bvand ?x20437 ?x41890)))
(let ((?x1924 (ite (and (distinct (_ bv0 32) ?x41896) true) (_ bv1 1) (_ bv0 1))))
(let (($x21085 (= (_ bv1 1) ?x1924)))
(let ((?x1917 (ite $x21085 (_ bv1 32) (_ bv0 32))))
(let ((?x10482 ((_ extract 7 0) ?x1917)))
(let (($x129 (or false false)))
(let (($x555 (or $x129 false false)))
(let (($x426 (or $x555 false)))
(let (($x2200 (or $x426 $x426 false)))
(let (($x6992 (or $x2200 false false)))
(let (($x20840 (or $x6992 (ite $x21085 false false))))
(let (($x19718 (or $x20840 false)))
(and (not $x19718) (or $x19718 (and (distinct ?x10482 ?x10482) true))))))))))))))))))))
(check-sat)
; query 81: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x129 (or false false)))
(let (($x1911 (not $x129)))
(and $x1911 (or $x129 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 82: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x16145 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x129 (or false false)))
(let (($x555 (or $x129 false false)))
(let (($x229 (not $x555)))
(and $x229 (or $x555 (and (distinct ?x16145 ?x16145) true))))))))
(check-sat)
; query 83: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x16145 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x20437 ((_ zero_extend 31) ?x16145)))
(let (($x129 (or false false)))
(let (($x555 (or $x129 false false)))
(let (($x426 (or $x555 false)))
(let (($x515 (not $x426)))
(and $x515 (or $x426 (and (distinct ?x20437 ?x20437) true))))))))))
(check-sat)
; query 84: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x129 (or false false)))
(let (($x1911 (not $x129)))
(and $x1911 (or $x129 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 85: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x12265 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x129 (or false false)))
(let (($x555 (or $x129 false false)))
(let (($x229 (not $x555)))
(and $x229 (or $x555 (and (distinct ?x12265 ?x12265) true))))))))
(check-sat)
; query 86: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x12265 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x41890 ((_ zero_extend 31) ?x12265)))
(let (($x129 (or false false)))
(let (($x555 (or $x129 false false)))
(let (($x426 (or $x555 false)))
(let (($x515 (not $x426)))
(and $x515 (or $x426 (and (distinct ?x41890 ?x41890) true))))))))))
(check-sat)
; query 87: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x12265 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x41890 ((_ zero_extend 31) ?x12265)))
(let ((?x16145 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x20437 ((_ zero_extend 31) ?x16145)))
(let ((?x41896 (bvand ?x20437 ?x41890)))
(let (($x129 (or false false)))
(let (($x555 (or $x129 false false)))
(let (($x426 (or $x555 false)))
(let (($x2200 (or $x426 $x426 false)))
(and (not $x2200) (or $x2200 (and (distinct ?x41896 ?x41896) true)))))))))))))
(check-sat)
; query 88: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x12265 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x41890 ((_ zero_extend 31) ?x12265)))
(let ((?x16145 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x20437 ((_ zero_extend 31) ?x16145)))
(let ((?x41896 (bvand ?x20437 ?x41890)))
(let ((?x1924 (ite (and (distinct (_ bv0 32) ?x41896) true) (_ bv1 1) (_ bv0 1))))
(let (($x129 (or false false)))
(let (($x555 (or $x129 false false)))
(let (($x426 (or $x555 false)))
(let (($x2200 (or $x426 $x426 false)))
(let (($x6992 (or $x2200 false false)))
(and (not $x6992) (or $x6992 (and (distinct ?x1924 ?x1924) true)))))))))))))))
(check-sat)
; query 89: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x40732 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x336 (not $x52)))
(and $x336 (or $x52 (and (distinct ?x40732 ?x40732) true)))))))
(check-sat)
; query 90: function matrix_add_const, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x52 (or false false false)))
(let (($x336 (not $x52)))
(and $x336 (or $x52 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 91: function matrix_add_const, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x166 (bvadd in.01_32 (_ bv1 32))))
(let (($x9703 (and (distinct ?x166 ?x166) true)))
(let (($x52 (or false false false)))
(let (($x336 (not $x52)))
(and $x336 (or $x52 $x9703)))))))
(check-sat)
; query 92: function matrix_mul_const, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x52 (or false false false)))
(let (($x336 (not $x52)))
(and $x336 (or $x52 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 93: function matrix_mul_const, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x166 (bvadd in.01_32 (_ bv1 32))))
(let (($x9703 (and (distinct ?x166 ?x166) true)))
(let (($x52 (or false false false)))
(let (($x336 (not $x52)))
(and $x336 (or $x52 $x9703)))))))
(check-sat)
; query 94: function matrix_mul_matrix, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x52 (or false false false)))
(let (($x336 (not $x52)))
(and $x336 (or $x52 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 95: function matrix_mul_matrix, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x166 (bvadd in.01_32 (_ bv1 32))))
(let (($x9703 (and (distinct ?x166 ?x166) true)))
(let (($x52 (or false false false)))
(let (($x336 (not $x52)))
(and $x336 (or $x52 $x9703)))))))
(check-sat)
; query 96: function matrix_mul_matrix, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x52 (or false false false)))
(let (($x336 (not $x52)))
(and $x336 (or $x52 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 97: function matrix_mul_matrix_bitextract, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x52 (or false false false)))
(let (($x336 (not $x52)))
(and $x336 (or $x52 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 98: function matrix_mul_matrix_bitextract, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x166 (bvadd in.01_32 (_ bv1 32))))
(let (($x9703 (and (distinct ?x166 ?x166) true)))
(let (($x52 (or false false false)))
(let (($x336 (not $x52)))
(and $x336 (or $x52 $x9703)))))))
(check-sat)
; query 99: function matrix_mul_matrix_bitextract, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x52 (or false false false)))
(let (($x336 (not $x52)))
(and $x336 (or $x52 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 100: function matrix_mul_vect, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x52 (or false false false)))
(let (($x336 (not $x52)))
(and $x336 (or $x52 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 101: function matrix_mul_vect, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x166 (bvadd in.01_32 (_ bv1 32))))
(let (($x9703 (and (distinct ?x166 ?x166) true)))
(let (($x52 (or false false false)))
(let (($x336 (not $x52)))
(and $x336 (or $x52 $x9703)))))))
(check-sat)
; query 102: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x129 (or false false)))
(let (($x1911 (not $x129)))
(and $x1911 (or $x129 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 103: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x15636 ((_ sign_extend 16) in.1_16)))
(let ((?x512 (bvadd ?x15636 (_ bv10 32))))
(let (($x44588 (and (distinct (bvadd ((_ sign_extend 1) ?x15636) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x512)) true)))
(let (($x129 (or false false)))
(let (($x40421 (or $x129 false (or $x44588))))
(and (not $x40421) (or $x40421 (and (distinct ?x512 ?x512) true)))))))))
(check-sat)
; query 104: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x15636 ((_ sign_extend 16) in.1_16)))
(let ((?x512 (bvadd ?x15636 (_ bv10 32))))
(let ((?x21684 ((_ extract 15 0) ?x512)))
(let (($x44588 (and (distinct (bvadd ((_ sign_extend 1) ?x15636) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x512)) true)))
(let (($x129 (or false false)))
(let (($x40421 (or $x129 false (or $x44588))))
(let (($x2015 (or $x40421 false)))
(and (not $x2015) (or $x2015 (and (distinct ?x21684 ?x21684) true)))))))))))
(check-sat)
; query 105: function matrix_sum, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x861 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x336 (not $x52)))
(and $x336 (or $x52 (and (distinct ?x861 ?x861) true)))))))
(check-sat)
; query 106: function matrix_sum, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x861 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let ((?x1237 ((_ zero_extend 63) ?x861)))
(let (($x52 (or false false false)))
(let (($x15903 (or $x52 false)))
(and (not $x15903) (or $x15903 (and (distinct ?x1237 ?x1237) true))))))))
(check-sat)
; query 107: function matrix_sum, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x861 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x14951 (= (_ bv1 1) ?x861)))
(let ((?x12717 (ite $x14951 (_ bv1 32) (_ bv0 32))))
(let (($x52 (or false false false)))
(let (($x15539 (or $x52 (ite $x14951 false false))))
(and (not $x15539) (or $x15539 (and (distinct ?x12717 ?x12717) true)))))))))
(check-sat)
; query 108: function matrix_sum, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x129 (or false false)))
(let (($x1911 (not $x129)))
(and $x1911 (or $x129 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 109: function matrix_sum, block 22, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x861 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x14951 (= (_ bv1 1) ?x861)))
(let ((?x12717 (ite $x14951 (_ bv1 32) (_ bv0 32))))
(let ((?x15636 ((_ sign_extend 16) in.1_16)))
(let ((?x1109 (bvadd ?x15636 ?x12717)))
(let (($x42612 (and (distinct (bvadd ((_ sign_extend 1) ?x15636) ((_ sign_extend 1) ?x12717)) ((_ sign_extend 1) ?x1109)) true)))
(let (($x52 (or false false false)))
(let (($x15539 (or $x52 (ite $x14951 false false))))
(let (($x129 (or false false)))
(let (($x41471 (or $x129 $x15539 (or $x42612))))
(and (not $x41471) (or $x41471 (and (distinct ?x1109 ?x1109) true))))))))))))))
(check-sat)
; query 110: function matrix_sum, block 22, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x861 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x14951 (= (_ bv1 1) ?x861)))
(let ((?x12717 (ite $x14951 (_ bv1 32) (_ bv0 32))))
(let ((?x15636 ((_ sign_extend 16) in.1_16)))
(let ((?x1109 (bvadd ?x15636 ?x12717)))
(let ((?x41068 ((_ extract 15 0) ?x1109)))
(let (($x42612 (and (distinct (bvadd ((_ sign_extend 1) ?x15636) ((_ sign_extend 1) ?x12717)) ((_ sign_extend 1) ?x1109)) true)))
(let (($x52 (or false false false)))
(let (($x15539 (or $x52 (ite $x14951 false false))))
(let (($x129 (or false false)))
(let (($x41471 (or $x129 $x15539 (or $x42612))))
(let (($x1495 (or $x41471 false)))
(and (not $x1495) (or $x1495 (and (distinct ?x41068 ?x41068) true))))))))))))))))
(check-sat)
; query 111: function matrix_sum, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x52 (or false false false)))
(let (($x336 (not $x52)))
(and $x336 (or $x52 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 112: function matrix_sum, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x166 (bvadd in.01_32 (_ bv1 32))))
(let (($x9703 (and (distinct ?x166 ?x166) true)))
(let (($x52 (or false false false)))
(let (($x336 (not $x52)))
(and $x336 (or $x52 $x9703)))))))
(check-sat)
; query 113: function parseval, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.23_32 () (_ BitVec 32))
(assert
 (let (($x44075 (and (distinct (bvmul ((_ sign_extend 32) in.23_32) ((_ sign_extend 32) (_ bv1024 32))) ((_ sign_extend 32) (bvmul in.23_32 (_ bv1024 32)))) true)))
(let (($x1129 (or false false (or $x44075))))
(and (not $x1129) (or $x1129 (and (distinct (bvmul in.23_32 (_ bv1024 32)) (bvmul in.23_32 (_ bv1024 32))) true))))))
(check-sat)
; query 114: function parseval, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.34_32 () (_ BitVec 32))
(assert
 (let (($x11543 (and (distinct (bvmul ((_ sign_extend 32) in.34_32) ((_ sign_extend 32) (_ bv1048576 32))) ((_ sign_extend 32) (bvmul in.34_32 (_ bv1048576 32)))) true)))
(let (($x44537 (or false false (or $x11543))))
(and (not $x44537) (or $x44537 (and (distinct (bvmul in.34_32 (_ bv1048576 32)) (bvmul in.34_32 (_ bv1048576 32))) true))))))
(check-sat)
; query 115: function partition_memory, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x52 (or false false false)))
(let (($x336 (not $x52)))
(and $x336 (or $x52 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
