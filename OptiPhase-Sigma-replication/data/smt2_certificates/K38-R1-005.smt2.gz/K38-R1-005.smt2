; OptiPhase-Sigma refinement certificate for sweep K38-R1-005
