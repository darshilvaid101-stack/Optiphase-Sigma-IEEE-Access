; OptiPhase-Sigma refinement certificate for sweep K50-R6-047
; query 0: function check, block 103, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x15 (ite (= (_ bv22 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x86 (or false false false)))
(let (($x298 (not $x86)))
(and $x298 (or $x86 (and (distinct ?x15 (ite (= (_ bv0 32) in0_32) (_ bv1 1) (_ bv0 1))) true)))))))
(check-sat)
; query 1: function check, block 109, name %110
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x25 (ite (= (_ bv33 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x86 (or false false false)))
(let (($x298 (not $x86)))
(and $x298 (or $x86 (and (distinct ?x25 (ite (= (_ bv12 32) in0_32) (_ bv1 1) (_ bv0 1))) true)))))))
(check-sat)
; query 2: function check, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x326 (ite (= (_ bv4 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x86 (or false false false)))
(let (($x298 (not $x86)))
(and $x298 (or $x86 (and (distinct (ite (= (_ bv2 32) in0_32) (_ bv1 1) (_ bv0 1)) ?x326) true)))))))
(check-sat)
; query 3: function check, block 79, name %80
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x848 (ite (= (_ bv5 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x86 (or false false false)))
(let (($x298 (not $x86)))
(and $x298 (or $x86 (and (distinct (ite (= (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1)) ?x848) true)))))))
(check-sat)
; query 4: function check, block 85, name %86
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x18 (ite (= (_ bv11 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let ((?x326 (ite (= (_ bv4 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x86 (or false false false)))
(let (($x298 (not $x86)))
(and $x298 (or $x86 (and (distinct ?x326 ?x18) true))))))))
(check-sat)
; query 5: function check, block 91, name %92
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x15 (ite (= (_ bv22 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let ((?x848 (ite (= (_ bv5 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x86 (or false false false)))
(let (($x298 (not $x86)))
(and $x298 (or $x86 (and (distinct ?x848 ?x15) true))))))))
(check-sat)
; query 6: function check, block 97, name %98
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x25 (ite (= (_ bv33 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let ((?x18 (ite (= (_ bv11 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x86 (or false false false)))
(let (($x298 (not $x86)))
(and $x298 (or $x86 (and (distinct ?x18 ?x25) true))))))))
(check-sat)
; query 7: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x478 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x86 (or false false false)))
(let (($x298 (not $x86)))
(and $x298 (or $x86 (and (distinct ?x478 ?x478) true)))))))
(check-sat)
; query 8: function s1119, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x272 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x74 (or false false (or $x272))))
(and (not $x74) (or $x74 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 9: function set1d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x785 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x86 (or false false false)))
(let (($x298 (not $x86)))
(and $x298 (or $x86 (and (distinct ?x785 ?x785) true)))))))
(check-sat)
; query 10: function set1ds, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x1485 (ite (= (_ bv4294967295 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x86 (or false false false)))
(let (($x298 (not $x86)))
(and $x298 (or $x86 (and (distinct ?x1485 ?x1485) true)))))))
(check-sat)
; query 11: function set2d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x785 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x86 (or false false false)))
(let (($x298 (not $x86)))
(and $x298 (or $x86 (and (distinct ?x785 ?x785) true)))))))
(check-sat)
