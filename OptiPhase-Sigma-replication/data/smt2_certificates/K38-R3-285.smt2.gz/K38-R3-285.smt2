; OptiPhase-Sigma refinement certificate for sweep K38-R3-285
; query 0: function BF_cbc_encrypt, block 126, name %127
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.010_64 () (_ BitVec 64))
(assert
 (let (($x44 (and (distinct (bvsub ((_ sign_extend 1) in.010_64) ((_ sign_extend 1) (_ bv8 64))) ((_ sign_extend 1) (bvsub in.010_64 (_ bv8 64)))) true)))
(let (($x228 (or false false (or $x44))))
(and (not $x228) (or $x228 (and (distinct (bvsub in.010_64 (_ bv8 64)) (bvsub in.010_64 (_ bv8 64))) true))))))
(check-sat)
; query 1: function BF_cfb64_encrypt, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.07_32 () (_ BitVec 32))
(assert
 (let ((?x354 (ite (= (_ bv0 32) in.07_32) (_ bv1 1) (_ bv0 1))))
(let (($x43 (or false false false)))
(and (not $x43) (or $x43 (and (distinct ?x354 ?x354) true))))))
(check-sat)
; query 2: function BF_set_key, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x379 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x217 (or false false (or $x379))))
(and (not $x217) (or $x217 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 3: function BF_set_key, block 69, name %70
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.13_32 () (_ BitVec 32))
(assert
 (let (($x181 (and (distinct (bvadd ((_ sign_extend 1) in.13_32) ((_ sign_extend 1) (_ bv2 32))) ((_ sign_extend 1) (bvadd in.13_32 (_ bv2 32)))) true)))
(let (($x91 (or false false (or $x181))))
(and (not $x91) (or $x91 (and (distinct (bvadd in.13_32 (_ bv2 32)) (bvadd in.13_32 (_ bv2 32))) true))))))
(check-sat)
; query 4: function BF_set_key, block 87, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.24_32 () (_ BitVec 32))
(assert
 (let (($x178 (and (distinct (bvadd ((_ sign_extend 1) in.24_32) ((_ sign_extend 1) (_ bv2 32))) ((_ sign_extend 1) (bvadd in.24_32 (_ bv2 32)))) true)))
(let (($x153 (or false false (or $x178))))
(and (not $x153) (or $x153 (and (distinct (bvadd in.24_32 (_ bv2 32)) (bvadd in.24_32 (_ bv2 32))) true))))))
(check-sat)
; query 5: function main, block 60, name %61
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x151 (or false false)))
(and (not $x151) (or $x151 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 6: function main, block 60, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x87 (ite (bvsge (_ bv57 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x151 (or false false)))
(let (($x193 (or $x151 false false)))
(let (($x100 (not $x193)))
(and $x100 (or $x193 (and (distinct ?x87 ?x87) true))))))))
(check-sat)
; query 7: function main, block 63, name %64
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x43 (or false false false)))
(and (not (or $x43 (bvuge (_ bv4 32) (_ bv32 32)))) (or $x43 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvmul in.01_32 (_ bv16 32))) true)))))
(check-sat)
; query 8: function main, block 63, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x151 (or false false)))
(and (not $x151) (or $x151 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 9: function main, block 63, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x628 (bvmul in.01_32 (_ bv16 32))))
(let ((?x249 (bvadd ?x628 (_ bv4294967248 32))))
(let ((?x92 ((_ sign_extend 24) in57_8)))
(let ((?x54 (bvshl in.01_32 (_ bv4 32))))
(let ((?x67 (bvadd ?x54 ?x92)))
(let (($x43 (or false false false)))
(let (($x143 (or $x43 false false)))
(let ((?x104 ((_ sign_extend 1) ?x67)))
(let (($x151 (or false false)))
(let (($x200 (or $x43 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x82 (or $x200 $x151 (or (and (distinct (bvadd ((_ sign_extend 1) ?x54) ((_ sign_extend 1) ?x92)) ?x104) true)))))
(let (($x109 (not $x82)))
(and $x109 (or $x143 (and (distinct ?x67 ?x249) true))))))))))))))))
(check-sat)
; query 10: function main, block 63, name %67
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x92 ((_ sign_extend 24) in57_8)))
(let ((?x54 (bvshl in.01_32 (_ bv4 32))))
(let ((?x67 (bvadd ?x54 ?x92)))
(let ((?x167 (bvsub ?x67 (_ bv48 32))))
(let (($x151 (or false false)))
(let (($x43 (or false false false)))
(let (($x143 (or $x43 false false)))
(let (($x13 (or $x143 $x151 false)))
(let (($x122 (or $x13 (and (distinct ?x167 (bvadd (bvadd (bvmul in.01_32 (_ bv16 32)) (_ bv4294967248 32)) ?x92)) true))))
(let (($x56 (and (distinct (bvsub ((_ sign_extend 1) ?x67) ((_ sign_extend 1) (_ bv48 32))) ((_ sign_extend 1) ?x167)) true)))
(let ((?x104 ((_ sign_extend 1) ?x67)))
(let (($x200 (or $x43 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x82 (or $x200 $x151 (or (and (distinct (bvadd ((_ sign_extend 1) ?x54) ((_ sign_extend 1) ?x92)) ?x104) true)))))
(and (not (or $x82 false (or $x56))) $x122)))))))))))))))
(check-sat)
; query 11: function main, block 68, name %69
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x151 (or false false)))
(and (not $x151) (or $x151 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 12: function main, block 68, name %70
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x83 (ite (bvsle (_ bv65 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x151 (or false false)))
(let (($x193 (or $x151 false false)))
(let (($x100 (not $x193)))
(and $x100 (or $x193 (and (distinct ?x83 ?x83) true))))))))
(check-sat)
; query 13: function main, block 71, name %72
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x151 (or false false)))
(and (not $x151) (or $x151 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 14: function main, block 71, name %73
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x117 (ite (bvsge (_ bv70 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x151 (or false false)))
(let (($x193 (or $x151 false false)))
(let (($x100 (not $x193)))
(and $x100 (or $x193 (and (distinct ?x117 ?x117) true))))))))
(check-sat)
; query 15: function main, block 74, name %75
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x43 (or false false false)))
(and (not (or $x43 (bvuge (_ bv4 32) (_ bv32 32)))) (or $x43 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvmul in.01_32 (_ bv16 32))) true)))))
(check-sat)
; query 16: function main, block 74, name %76
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x151 (or false false)))
(and (not $x151) (or $x151 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 17: function main, block 74, name %77
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x628 (bvmul in.01_32 (_ bv16 32))))
(let ((?x235 (bvadd ?x628 (_ bv4294967241 32))))
(let ((?x92 ((_ sign_extend 24) in57_8)))
(let ((?x54 (bvshl in.01_32 (_ bv4 32))))
(let ((?x67 (bvadd ?x54 ?x92)))
(let (($x43 (or false false false)))
(let (($x143 (or $x43 false false)))
(let ((?x104 ((_ sign_extend 1) ?x67)))
(let (($x151 (or false false)))
(let (($x200 (or $x43 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x82 (or $x200 $x151 (or (and (distinct (bvadd ((_ sign_extend 1) ?x54) ((_ sign_extend 1) ?x92)) ?x104) true)))))
(let (($x109 (not $x82)))
(and $x109 (or $x143 (and (distinct ?x67 ?x235) true))))))))))))))))
(check-sat)
; query 18: function main, block 74, name %78
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x92 ((_ sign_extend 24) in57_8)))
(let ((?x54 (bvshl in.01_32 (_ bv4 32))))
(let ((?x67 (bvadd ?x54 ?x92)))
(let ((?x225 (bvsub ?x67 (_ bv65 32))))
(let (($x151 (or false false)))
(let (($x43 (or false false false)))
(let (($x143 (or $x43 false false)))
(let (($x13 (or $x143 $x151 false)))
(let (($x8 (or $x13 (and (distinct ?x225 (bvadd (bvadd (bvmul in.01_32 (_ bv16 32)) (_ bv4294967241 32)) ?x92)) true))))
(let (($x186 (and (distinct (bvsub ((_ sign_extend 1) ?x67) ((_ sign_extend 1) (_ bv65 32))) ((_ sign_extend 1) ?x225)) true)))
(let ((?x104 ((_ sign_extend 1) ?x67)))
(let (($x200 (or $x43 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x82 (or $x200 $x151 (or (and (distinct (bvadd ((_ sign_extend 1) ?x54) ((_ sign_extend 1) ?x92)) ?x104) true)))))
(and (not (or $x82 false (or $x186))) $x8)))))))))))))))
(check-sat)
