; OptiPhase-Sigma refinement certificate for sweep K27-R6-022
