; OptiPhase-Sigma refinement certificate for sweep K40-R4-318
; query 0: function set_key, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let (($x374 (or false false false)))
(and (not $x374) (or $x374 (and (distinct (bvand in1_64 (_ bv7 64)) (bvand in1_64 (_ bv7 64))) true)))))
(check-sat)
; query 1: function set_key, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x19 (ite (and (distinct (_ bv0 64) (bvand in1_64 (_ bv7 64))) true) (_ bv1 1) (_ bv0 1))))
(let (($x374 (or false false false)))
(let (($x245 (or $x374 false false)))
(and (not $x245) (or $x245 (and (distinct ?x19 ?x19) true)))))))
(check-sat)
