; OptiPhase-Sigma refinement certificate for sweep K55-R1-003
; query 0: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x518 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x71 (or false false false)))
(and (not $x71) (or $x71 (and (distinct ?x518 ?x518) true))))))
(check-sat)
