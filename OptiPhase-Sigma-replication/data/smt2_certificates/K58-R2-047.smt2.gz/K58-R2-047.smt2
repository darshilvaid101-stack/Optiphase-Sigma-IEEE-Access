; OptiPhase-Sigma refinement certificate for sweep K58-R2-047
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x68 (or false false)))
(let (($x110 (not $x68)))
(and $x110 (or $x68 (and (distinct ((_ sign_extend 16) in25_16) ((_ sign_extend 16) in25_16)) true))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let ((?x187 (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))))
(let (($x68 (or false false)))
(let (($x78 (or $x68 false false)))
(let (($x1374 (not $x78)))
(and $x1374 (or $x78 (and (distinct ?x187 ?x187) true))))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x68 (or false false)))
(let (($x110 (not $x68)))
(and $x110 (or $x68 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x138 ((_ sign_extend 16) in3_16)))
(let ((?x3336 (bvand ?x138 (_ bv127 32))))
(let (($x68 (or false false)))
(let (($x78 (or $x68 false false)))
(let (($x1374 (not $x78)))
(and $x1374 (or $x78 (and (distinct ?x3336 ?x3336) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x138 ((_ sign_extend 16) in3_16)))
(let ((?x3336 (bvand ?x138 (_ bv127 32))))
(let ((?x177 ((_ extract 15 0) ?x3336)))
(let (($x68 (or false false)))
(let (($x78 (or $x68 false false)))
(let (($x139 (or $x78 false)))
(let (($x156 (not $x139)))
(and $x156 (or $x139 (and (distinct ?x177 ?x177) true)))))))))))
(check-sat)
; query 5: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x68 (or false false)))
(let (($x110 (not $x68)))
(and $x110 (or $x68 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 6: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x128 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x68 (or false false)))
(let (($x78 (or $x68 false false)))
(let (($x1374 (not $x78)))
(and $x1374 (or $x78 (and (distinct ?x128 ?x128) true))))))))
(check-sat)
; query 7: function core_bench_list, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x102 (or false false false)))
(let (($x104 (not $x102)))
(and $x104 (or $x102 (and (distinct (bvadd in.0_16 (_ bv1 16)) (bvadd in.0_16 (_ bv1 16))) true))))))
(check-sat)
; query 8: function core_bench_list, block 82, name %83
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let (($x68 (or false false)))
(let (($x110 (not $x68)))
(and $x110 (or $x68 (and (distinct ((_ zero_extend 16) in.02_16) ((_ zero_extend 16) in.02_16)) true))))))
(check-sat)
; query 9: function core_bench_list, block 82, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x175 ((_ zero_extend 16) in.02_16)))
(let ((?x586 (bvmul ?x175 (_ bv4 32))))
(let (($x1389 (and (distinct (bvmul ((_ sign_extend 32) ?x175) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x586)) true)))
(let (($x68 (or false false)))
(let (($x152 (or $x68 false (or $x1389))))
(and (not $x152) (or $x152 (and (distinct ?x586 ?x586) true)))))))))
(check-sat)
; query 10: function core_bench_list, block 82, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let (($x68 (or false false)))
(let (($x110 (not $x68)))
(and $x110 (or $x68 (and (distinct ((_ zero_extend 16) in.04_16) ((_ zero_extend 16) in.04_16)) true))))))
(check-sat)
; query 11: function core_bench_list, block 82, name %86
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x153 ((_ zero_extend 16) in.04_16)))
(let ((?x175 ((_ zero_extend 16) in.02_16)))
(let ((?x586 (bvmul ?x175 (_ bv4 32))))
(let ((?x544 (bvsub ?x586 ?x153)))
(let ((?x216 ((_ sign_extend 1) ?x544)))
(let (($x68 (or false false)))
(let (($x1389 (and (distinct (bvmul ((_ sign_extend 32) ?x175) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x586)) true)))
(let (($x152 (or $x68 false (or $x1389))))
(let (($x178 (or $x152 $x68 (or (and (distinct (bvsub ((_ sign_extend 1) ?x586) ((_ sign_extend 1) ?x153)) ?x216) true)))))
(and (not $x178) (or $x178 (and (distinct ?x544 ?x544) true)))))))))))))
(check-sat)
; query 12: function core_bench_list, block 82, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x68 (or false false)))
(let (($x110 (not $x68)))
(and $x110 (or $x68 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 13: function core_bench_list, block 82, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x153 ((_ zero_extend 16) in.04_16)))
(let ((?x175 ((_ zero_extend 16) in.02_16)))
(let ((?x586 (bvmul ?x175 (_ bv4 32))))
(let ((?x544 (bvsub ?x586 ?x153)))
(let ((?x2716 ((_ zero_extend 16) in.01_16)))
(let ((?x6389 (bvadd ?x2716 ?x544)))
(let (($x1446 (and (distinct (bvadd ((_ sign_extend 1) ?x2716) ((_ sign_extend 1) ?x544)) ((_ sign_extend 1) ?x6389)) true)))
(let ((?x216 ((_ sign_extend 1) ?x544)))
(let (($x68 (or false false)))
(let (($x1389 (and (distinct (bvmul ((_ sign_extend 32) ?x175) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x586)) true)))
(let (($x152 (or $x68 false (or $x1389))))
(let (($x178 (or $x152 $x68 (or (and (distinct (bvsub ((_ sign_extend 1) ?x586) ((_ sign_extend 1) ?x153)) ?x216) true)))))
(let (($x4410 (or $x68 $x178 (or $x1446))))
(and (not $x4410) (or $x4410 (and (distinct ?x6389 ?x6389) true)))))))))))))))))
(check-sat)
; query 14: function core_bench_list, block 82, name %89
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x153 ((_ zero_extend 16) in.04_16)))
(let ((?x175 ((_ zero_extend 16) in.02_16)))
(let ((?x586 (bvmul ?x175 (_ bv4 32))))
(let ((?x544 (bvsub ?x586 ?x153)))
(let ((?x2716 ((_ zero_extend 16) in.01_16)))
(let ((?x6389 (bvadd ?x2716 ?x544)))
(let ((?x101 ((_ extract 15 0) ?x6389)))
(let (($x1446 (and (distinct (bvadd ((_ sign_extend 1) ?x2716) ((_ sign_extend 1) ?x544)) ((_ sign_extend 1) ?x6389)) true)))
(let ((?x216 ((_ sign_extend 1) ?x544)))
(let (($x68 (or false false)))
(let (($x1389 (and (distinct (bvmul ((_ sign_extend 32) ?x175) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x586)) true)))
(let (($x152 (or $x68 false (or $x1389))))
(let (($x178 (or $x152 $x68 (or (and (distinct (bvsub ((_ sign_extend 1) ?x586) ((_ sign_extend 1) ?x153)) ?x216) true)))))
(let (($x4410 (or $x68 $x178 (or $x1446))))
(let (($x1869 (or $x4410 false)))
(and (not $x1869) (or $x1869 (and (distinct ?x101 ?x101) true)))))))))))))))))))
(check-sat)
; query 15: function core_bench_list, block 82, name %90
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x68 (or false false)))
(let (($x110 (not $x68)))
(and $x110 (or $x68 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 16: function core_bench_list, block 82, name %91
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1321 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x68 (or false false)))
(let (($x78 (or $x68 false false)))
(let (($x1374 (not $x78)))
(and $x1374 (or $x78 (and (distinct ?x1321 ?x1321) true))))))))
(check-sat)
; query 17: function core_bench_state, block 105, name %106
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x102 (or false false false)))
(let (($x104 (not $x102)))
(and $x104 (or $x102 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 18: function core_bench_state, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x102 (or false false false)))
(let (($x104 (not $x102)))
(and $x104 (or $x102 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 19: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1219 (bvadd in.01_32 (_ bv1 32))))
(let (($x188 (and (distinct ?x1219 ?x1219) true)))
(let (($x102 (or false false false)))
(let (($x104 (not $x102)))
(and $x104 (or $x102 $x188)))))))
(check-sat)
; query 20: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1219 (bvadd in.01_32 (_ bv1 32))))
(let ((?x608 (bvmul ?x1219 ?x1219)))
(let (($x102 (or false false false)))
(let (($x35 (or $x102 $x102 false)))
(and (not $x35) (or $x35 (and (distinct ?x608 ?x608) true))))))))
(check-sat)
; query 21: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1219 (bvadd in.01_32 (_ bv1 32))))
(let ((?x608 (bvmul ?x1219 ?x1219)))
(let ((?x103 (bvmul ?x608 (_ bv2 32))))
(let (($x102 (or false false false)))
(let (($x35 (or $x102 $x102 false)))
(let (($x61 (or $x35 false false)))
(and (not $x61) (or $x61 (and (distinct ?x103 ?x103) true))))))))))
(check-sat)
; query 22: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1219 (bvadd in.01_32 (_ bv1 32))))
(let ((?x608 (bvmul ?x1219 ?x1219)))
(let ((?x103 (bvmul ?x608 (_ bv2 32))))
(let ((?x21 (bvmul ?x103 (_ bv4 32))))
(let (($x102 (or false false false)))
(let (($x35 (or $x102 $x102 false)))
(let (($x61 (or $x35 false false)))
(let (($x701 (or $x61 false false)))
(and (not $x701) (or $x701 (and (distinct ?x21 ?x21) true))))))))))))
(check-sat)
; query 23: function core_init_matrix, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x102 (or false false false)))
(let (($x104 (not $x102)))
(and $x104 (or $x102 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 24: function core_init_matrix, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x102 (or false false false)))
(let (($x104 (not $x102)))
(and $x104 (or $x102 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 25: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x90 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x102 (or false false false)))
(let (($x104 (not $x102)))
(and $x104 (or $x102 (and (distinct ?x90 ?x90) true)))))))
(check-sat)
; query 26: function core_init_state, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_32 () (_ BitVec 32))
(assert
 (let (($x102 (or false false false)))
(let (($x104 (not $x102)))
(and $x104 (or $x102 (and (distinct (bvadd in.06_32 (_ bv1 32)) (bvadd in.06_32 (_ bv1 32))) true))))))
(check-sat)
; query 27: function core_init_state, block 65, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let (($x102 (or false false false)))
(let (($x104 (not $x102)))
(and $x104 (or $x102 (and (distinct (bvadd in4_32 (_ bv1 32)) (bvadd in4_32 (_ bv1 32))) true))))))
(check-sat)
; query 28: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x615 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x102 (or false false false)))
(let (($x104 (not $x102)))
(and $x104 (or $x102 (and (distinct ?x615 ?x615) true)))))))
(check-sat)
; query 29: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x102 (or false false false)))
(let (($x104 (not $x102)))
(and $x104 (or $x102 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 30: function core_list_init, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1219 (bvadd in.01_32 (_ bv1 32))))
(let (($x188 (and (distinct ?x1219 ?x1219) true)))
(let (($x102 (or false false false)))
(let (($x104 (not $x102)))
(and $x104 (or $x102 $x188)))))))
(check-sat)
; query 31: function core_list_mergesort, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1219 (bvadd in.01_32 (_ bv1 32))))
(let (($x188 (and (distinct ?x1219 ?x1219) true)))
(let (($x122 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x1219)) true)))
(let (($x1667 (or false false (or $x122))))
(and (not $x1667) (or $x1667 $x188)))))))
(check-sat)
; query 32: function core_list_mergesort, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x3088 (ite (bvslt (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x102 (or false false false)))
(let (($x104 (not $x102)))
(and $x104 (or $x102 (and (distinct ?x3088 ?x3088) true)))))))
(check-sat)
; query 33: function core_list_mergesort, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.224_32 () (_ BitVec 32))
(assert
 (let ((?x3137 (ite (= (_ bv0 32) in.224_32) (_ bv1 1) (_ bv0 1))))
(let (($x102 (or false false false)))
(let (($x104 (not $x102)))
(and $x104 (or $x102 (and (distinct ?x3137 ?x3137) true)))))))
(check-sat)
; query 34: function core_list_mergesort, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x1082 (ite (= (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x102 (or false false false)))
(let (($x104 (not $x102)))
(and $x104 (or $x102 (and (distinct ?x1082 ?x1082) true)))))))
(check-sat)
; query 35: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x5445 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x6861 (or false false (or $x5445))))
(and (not $x6861) (or $x6861 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 36: function core_list_mergesort, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x3031 (and (distinct (bvmul ((_ sign_extend 32) in.020_32) ((_ sign_extend 32) (_ bv2 32))) ((_ sign_extend 32) (bvmul in.020_32 (_ bv2 32)))) true)))
(let (($x4838 (or false false (or $x3031))))
(and (not $x4838) (or $x4838 (and (distinct (bvmul in.020_32 (_ bv2 32)) (bvmul in.020_32 (_ bv2 32))) true))))))
(check-sat)
; query 37: function core_state_transition, block 102, name %103
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x68 (or false false)))
(let (($x110 (not $x68)))
(and $x110 (or $x68 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 38: function core_state_transition, block 102, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x733 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x68 (or false false)))
(let (($x78 (or $x68 false false)))
(let (($x1374 (not $x78)))
(and $x1374 (or $x78 (and (distinct ?x733 ?x733) true))))))))
(check-sat)
; query 39: function core_state_transition, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x68 (or false false)))
(let (($x110 (not $x68)))
(and $x110 (or $x68 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 40: function core_state_transition, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x3590 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x68 (or false false)))
(let (($x78 (or $x68 false false)))
(let (($x1374 (not $x78)))
(and $x1374 (or $x78 (and (distinct ?x3590 ?x3590) true))))))))
(check-sat)
; query 41: function core_state_transition, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x68 (or false false)))
(let (($x110 (not $x68)))
(and $x110 (or $x68 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 42: function core_state_transition, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x733 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x68 (or false false)))
(let (($x78 (or $x68 false false)))
(let (($x1374 (not $x78)))
(and $x1374 (or $x78 (and (distinct ?x733 ?x733) true))))))))
(check-sat)
; query 43: function core_state_transition, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x68 (or false false)))
(let (($x110 (not $x68)))
(and $x110 (or $x68 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 44: function core_state_transition, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x6415 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x68 (or false false)))
(let (($x78 (or $x68 false false)))
(let (($x1374 (not $x78)))
(and $x1374 (or $x78 (and (distinct ?x6415 ?x6415) true))))))))
(check-sat)
; query 45: function core_state_transition, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x68 (or false false)))
(let (($x110 (not $x68)))
(and $x110 (or $x68 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 46: function core_state_transition, block 51, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x6415 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x68 (or false false)))
(let (($x78 (or $x68 false false)))
(let (($x1374 (not $x78)))
(and $x1374 (or $x78 (and (distinct ?x6415 ?x6415) true))))))))
(check-sat)
; query 47: function core_state_transition, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x68 (or false false)))
(let (($x110 (not $x68)))
(and $x110 (or $x68 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 48: function core_state_transition, block 64, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x6415 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x68 (or false false)))
(let (($x78 (or $x68 false false)))
(let (($x1374 (not $x78)))
(and $x1374 (or $x78 (and (distinct ?x6415 ?x6415) true))))))))
(check-sat)
; query 49: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x3840 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x102 (or false false false)))
(let (($x104 (not $x102)))
(and $x104 (or $x102 (and (distinct ?x3840 ?x3840) true)))))))
(check-sat)
; query 50: function core_state_transition, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x68 (or false false)))
(let (($x110 (not $x68)))
(and $x110 (or $x68 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 51: function core_state_transition, block 80, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x7157 (ite (= (_ bv69 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x68 (or false false)))
(let (($x78 (or $x68 false false)))
(let (($x1374 (not $x78)))
(and $x1374 (or $x78 (and (distinct ?x7157 ?x7157) true))))))))
(check-sat)
; query 52: function core_state_transition, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x68 (or false false)))
(let (($x110 (not $x68)))
(and $x110 (or $x68 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 53: function core_state_transition, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x865 (ite (= (_ bv101 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x68 (or false false)))
(let (($x78 (or $x68 false false)))
(let (($x1374 (not $x78)))
(and $x1374 (or $x78 (and (distinct ?x865 ?x865) true))))))))
(check-sat)
; query 54: function core_state_transition, block 99, name %100
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x68 (or false false)))
(let (($x110 (not $x68)))
(and $x110 (or $x68 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 55: function core_state_transition, block 99, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x3590 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x68 (or false false)))
(let (($x78 (or $x68 false false)))
(let (($x1374 (not $x78)))
(and $x1374 (or $x78 (and (distinct ?x3590 ?x3590) true))))))))
(check-sat)
; query 56: function crcu8, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x68 (or false false)))
(let (($x110 (not $x68)))
(and $x110 (or $x68 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 57: function crcu8, block 19, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x2716 ((_ zero_extend 16) in.01_16)))
(let ((?x5529 (bvxor ?x2716 (_ bv16386 32))))
(let (($x68 (or false false)))
(let (($x78 (or $x68 false false)))
(let (($x1374 (not $x78)))
(and $x1374 (or $x78 (and (distinct ?x5529 ?x5529) true)))))))))
(check-sat)
; query 58: function crcu8, block 19, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x2716 ((_ zero_extend 16) in.01_16)))
(let ((?x5529 (bvxor ?x2716 (_ bv16386 32))))
(let ((?x5689 ((_ extract 15 0) ?x5529)))
(let (($x68 (or false false)))
(let (($x78 (or $x68 false false)))
(let (($x139 (or $x78 false)))
(let (($x156 (not $x139)))
(and $x156 (or $x139 (and (distinct ?x5689 ?x5689) true)))))))))))
(check-sat)
; query 59: function crcu8, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x68 (or false false)))
(let (($x110 (not $x68)))
(and $x110 (or $x68 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 60: function crcu8, block 29, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1916 ((_ zero_extend 16) in27_16)))
(let ((?x7246 (bvor ?x1916 (_ bv32768 32))))
(let (($x68 (or false false)))
(let (($x78 (or $x68 false false)))
(let (($x1374 (not $x78)))
(and $x1374 (or $x78 (and (distinct ?x7246 ?x7246) true)))))))))
(check-sat)
; query 61: function crcu8, block 29, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1916 ((_ zero_extend 16) in27_16)))
(let ((?x7246 (bvor ?x1916 (_ bv32768 32))))
(let ((?x3796 ((_ extract 15 0) ?x7246)))
(let (($x68 (or false false)))
(let (($x78 (or $x68 false false)))
(let (($x139 (or $x78 false)))
(let (($x156 (not $x139)))
(and $x156 (or $x139 (and (distinct ?x3796 ?x3796) true)))))))))))
(check-sat)
; query 62: function crcu8, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x68 (or false false)))
(let (($x110 (not $x68)))
(and $x110 (or $x68 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 63: function crcu8, block 33, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1916 ((_ zero_extend 16) in27_16)))
(let ((?x341 (bvand ?x1916 (_ bv32767 32))))
(let (($x68 (or false false)))
(let (($x78 (or $x68 false false)))
(let (($x1374 (not $x78)))
(and $x1374 (or $x78 (and (distinct ?x341 ?x341) true)))))))))
(check-sat)
; query 64: function crcu8, block 33, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1916 ((_ zero_extend 16) in27_16)))
(let ((?x341 (bvand ?x1916 (_ bv32767 32))))
(let ((?x2505 ((_ extract 15 0) ?x341)))
(let (($x68 (or false false)))
(let (($x78 (or $x68 false false)))
(let (($x139 (or $x78 false)))
(let (($x156 (not $x139)))
(and $x156 (or $x139 (and (distinct ?x2505 ?x2505) true)))))))))))
(check-sat)
; query 65: function crcu8, block 38, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_8 () (_ BitVec 8))
(assert
 (let (($x102 (or false false false)))
(let (($x104 (not $x102)))
(and $x104 (or $x102 (and (distinct (bvadd in.02_8 (_ bv1 8)) (bvadd in.02_8 (_ bv1 8))) true))))))
(check-sat)
; query 66: function crcu8, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x907 ((_ extract 7 0) in.01_16)))
(let ((?x6288 ((_ zero_extend 24) ?x907)))
(let (($x68 (or false false)))
(let (($x5278 (or $x68 false)))
(and (not $x5278) (or $x5278 (and (distinct ?x6288 ?x6288) true))))))))
(check-sat)
; query 67: function crcu8, block 6, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x907 ((_ extract 7 0) in.01_16)))
(let ((?x6288 ((_ zero_extend 24) ?x907)))
(let ((?x880 (bvand ?x6288 (_ bv1 32))))
(let (($x68 (or false false)))
(let (($x5278 (or $x68 false)))
(let (($x319 (or $x5278 false false)))
(and (not $x319) (or $x319 (and (distinct ?x880 ?x880) true))))))))))
(check-sat)
; query 68: function crcu8, block 6, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x907 ((_ extract 7 0) in.01_16)))
(let ((?x6288 ((_ zero_extend 24) ?x907)))
(let ((?x880 (bvand ?x6288 (_ bv1 32))))
(let ((?x3842 ((_ zero_extend 24) in.0_8)))
(let ((?x1552 (bvand ?x3842 (_ bv1 32))))
(let ((?x2963 (bvxor ?x1552 ?x880)))
(let (($x68 (or false false)))
(let (($x5278 (or $x68 false)))
(let (($x319 (or $x5278 false false)))
(let (($x78 (or $x68 false false)))
(let (($x1627 (or $x78 $x319 false)))
(and (not $x1627) (or $x1627 (and (distinct ?x2963 ?x2963) true)))))))))))))))
(check-sat)
; query 69: function crcu8, block 6, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x907 ((_ extract 7 0) in.01_16)))
(let ((?x6288 ((_ zero_extend 24) ?x907)))
(let ((?x880 (bvand ?x6288 (_ bv1 32))))
(let ((?x3842 ((_ zero_extend 24) in.0_8)))
(let ((?x1552 (bvand ?x3842 (_ bv1 32))))
(let ((?x2963 (bvxor ?x1552 ?x880)))
(let ((?x3476 ((_ extract 7 0) ?x2963)))
(let (($x68 (or false false)))
(let (($x5278 (or $x68 false)))
(let (($x319 (or $x5278 false false)))
(let (($x78 (or $x68 false false)))
(let (($x1627 (or $x78 $x319 false)))
(let (($x3454 (or $x1627 false)))
(and (not $x3454) (or $x3454 (and (distinct ?x3476 ?x3476) true)))))))))))))))))
(check-sat)
; query 70: function crcu8, block 6, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x68 (or false false)))
(let (($x110 (not $x68)))
(and $x110 (or $x68 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 71: function crcu8, block 6, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x3842 ((_ zero_extend 24) in.0_8)))
(let ((?x4511 (bvashr ?x3842 (_ bv1 32))))
(let (($x68 (or false false)))
(let (($x78 (or $x68 false false)))
(let (($x6787 (or $x78 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not $x6787) (or $x6787 (and (distinct ?x4511 ?x4511) true)))))))))
(check-sat)
; query 72: function crcu8, block 6, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x3842 ((_ zero_extend 24) in.0_8)))
(let ((?x4511 (bvashr ?x3842 (_ bv1 32))))
(let ((?x7364 ((_ extract 7 0) ?x4511)))
(let (($x68 (or false false)))
(let (($x78 (or $x68 false false)))
(let (($x6787 (or $x78 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x3121 (or $x6787 false)))
(and (not $x3121) (or $x3121 (and (distinct ?x7364 ?x7364) true)))))))))))
(check-sat)
; query 73: function crcu8, block 6, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x907 ((_ extract 7 0) in.01_16)))
(let ((?x6288 ((_ zero_extend 24) ?x907)))
(let ((?x880 (bvand ?x6288 (_ bv1 32))))
(let ((?x3842 ((_ zero_extend 24) in.0_8)))
(let ((?x1552 (bvand ?x3842 (_ bv1 32))))
(let ((?x2963 (bvxor ?x1552 ?x880)))
(let ((?x3476 ((_ extract 7 0) ?x2963)))
(let ((?x5884 ((_ zero_extend 24) ?x3476)))
(let (($x68 (or false false)))
(let (($x5278 (or $x68 false)))
(let (($x319 (or $x5278 false false)))
(let (($x78 (or $x68 false false)))
(let (($x1627 (or $x78 $x319 false)))
(let (($x3454 (or $x1627 false)))
(let (($x2050 (or $x3454 false)))
(and (not $x2050) (or $x2050 (and (distinct ?x5884 ?x5884) true)))))))))))))))))))
(check-sat)
; query 74: function crcu8, block 6, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x907 ((_ extract 7 0) in.01_16)))
(let ((?x6288 ((_ zero_extend 24) ?x907)))
(let ((?x880 (bvand ?x6288 (_ bv1 32))))
(let ((?x3842 ((_ zero_extend 24) in.0_8)))
(let ((?x1552 (bvand ?x3842 (_ bv1 32))))
(let ((?x2963 (bvxor ?x1552 ?x880)))
(let ((?x3476 ((_ extract 7 0) ?x2963)))
(let ((?x5884 ((_ zero_extend 24) ?x3476)))
(let ((?x1257 (ite (= (_ bv1 32) ?x5884) (_ bv1 1) (_ bv0 1))))
(let (($x68 (or false false)))
(let (($x5278 (or $x68 false)))
(let (($x319 (or $x5278 false false)))
(let (($x78 (or $x68 false false)))
(let (($x1627 (or $x78 $x319 false)))
(let (($x3454 (or $x1627 false)))
(let (($x2050 (or $x3454 false)))
(let (($x2411 (or $x2050 false false)))
(and (not $x2411) (or $x2411 (and (distinct ?x1257 ?x1257) true)))))))))))))))))))))
(check-sat)
; query 75: function crcu8, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x68 (or false false)))
(let (($x110 (not $x68)))
(and $x110 (or $x68 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 76: function crcu8, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x3842 ((_ zero_extend 24) in.0_8)))
(let ((?x1552 (bvand ?x3842 (_ bv1 32))))
(let (($x68 (or false false)))
(let (($x78 (or $x68 false false)))
(let (($x1374 (not $x78)))
(and $x1374 (or $x78 (and (distinct ?x1552 ?x1552) true)))))))))
(check-sat)
; query 77: function crcu8, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x68 (or false false)))
(let (($x110 (not $x68)))
(and $x110 (or $x68 (and (distinct ((_ extract 7 0) in.01_16) ((_ extract 7 0) in.01_16)) true))))))
(check-sat)
; query 78: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x3641 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x4423 ((_ zero_extend 31) ?x3641)))
(let ((?x5980 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x7520 ((_ zero_extend 31) ?x5980)))
(let ((?x2262 (bvand ?x7520 ?x4423)))
(let ((?x3557 (ite (and (distinct (_ bv0 32) ?x2262) true) (_ bv1 1) (_ bv0 1))))
(let ((?x4278 ((_ zero_extend 63) ?x3557)))
(let (($x68 (or false false)))
(let (($x78 (or $x68 false false)))
(let (($x139 (or $x78 false)))
(let (($x3085 (or $x139 $x139 false)))
(let (($x404 (or $x3085 false false)))
(let (($x4361 (or $x404 false)))
(and (not $x4361) (or $x4361 (and (distinct ?x4278 ?x4278) true)))))))))))))))))
(check-sat)
; query 79: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x3641 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x4423 ((_ zero_extend 31) ?x3641)))
(let ((?x5980 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x7520 ((_ zero_extend 31) ?x5980)))
(let ((?x2262 (bvand ?x7520 ?x4423)))
(let ((?x3557 (ite (and (distinct (_ bv0 32) ?x2262) true) (_ bv1 1) (_ bv0 1))))
(let (($x3625 (= (_ bv1 1) ?x3557)))
(let ((?x464 (ite $x3625 (_ bv1 32) (_ bv0 32))))
(let (($x68 (or false false)))
(let (($x78 (or $x68 false false)))
(let (($x139 (or $x78 false)))
(let (($x3085 (or $x139 $x139 false)))
(let (($x404 (or $x3085 false false)))
(let (($x1273 (or $x404 (ite $x3625 false false))))
(and (not $x1273) (or $x1273 (and (distinct ?x464 ?x464) true))))))))))))))))))
(check-sat)
; query 80: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x3641 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x4423 ((_ zero_extend 31) ?x3641)))
(let ((?x5980 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x7520 ((_ zero_extend 31) ?x5980)))
(let ((?x2262 (bvand ?x7520 ?x4423)))
(let ((?x3557 (ite (and (distinct (_ bv0 32) ?x2262) true) (_ bv1 1) (_ bv0 1))))
(let (($x3625 (= (_ bv1 1) ?x3557)))
(let ((?x464 (ite $x3625 (_ bv1 32) (_ bv0 32))))
(let ((?x1121 ((_ extract 7 0) ?x464)))
(let (($x68 (or false false)))
(let (($x78 (or $x68 false false)))
(let (($x139 (or $x78 false)))
(let (($x3085 (or $x139 $x139 false)))
(let (($x404 (or $x3085 false false)))
(let (($x1273 (or $x404 (ite $x3625 false false))))
(let (($x436 (or $x1273 false)))
(and (not $x436) (or $x436 (and (distinct ?x1121 ?x1121) true))))))))))))))))))))
(check-sat)
; query 81: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x68 (or false false)))
(let (($x110 (not $x68)))
(and $x110 (or $x68 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 82: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x5980 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x68 (or false false)))
(let (($x78 (or $x68 false false)))
(let (($x1374 (not $x78)))
(and $x1374 (or $x78 (and (distinct ?x5980 ?x5980) true))))))))
(check-sat)
; query 83: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x5980 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x7520 ((_ zero_extend 31) ?x5980)))
(let (($x68 (or false false)))
(let (($x78 (or $x68 false false)))
(let (($x139 (or $x78 false)))
(let (($x156 (not $x139)))
(and $x156 (or $x139 (and (distinct ?x7520 ?x7520) true))))))))))
(check-sat)
; query 84: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x68 (or false false)))
(let (($x110 (not $x68)))
(and $x110 (or $x68 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 85: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x3641 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x68 (or false false)))
(let (($x78 (or $x68 false false)))
(let (($x1374 (not $x78)))
(and $x1374 (or $x78 (and (distinct ?x3641 ?x3641) true))))))))
(check-sat)
; query 86: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x3641 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x4423 ((_ zero_extend 31) ?x3641)))
(let (($x68 (or false false)))
(let (($x78 (or $x68 false false)))
(let (($x139 (or $x78 false)))
(let (($x156 (not $x139)))
(and $x156 (or $x139 (and (distinct ?x4423 ?x4423) true))))))))))
(check-sat)
; query 87: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x3641 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x4423 ((_ zero_extend 31) ?x3641)))
(let ((?x5980 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x7520 ((_ zero_extend 31) ?x5980)))
(let ((?x2262 (bvand ?x7520 ?x4423)))
(let (($x68 (or false false)))
(let (($x78 (or $x68 false false)))
(let (($x139 (or $x78 false)))
(let (($x3085 (or $x139 $x139 false)))
(and (not $x3085) (or $x3085 (and (distinct ?x2262 ?x2262) true)))))))))))))
(check-sat)
; query 88: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x3641 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x4423 ((_ zero_extend 31) ?x3641)))
(let ((?x5980 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x7520 ((_ zero_extend 31) ?x5980)))
(let ((?x2262 (bvand ?x7520 ?x4423)))
(let ((?x3557 (ite (and (distinct (_ bv0 32) ?x2262) true) (_ bv1 1) (_ bv0 1))))
(let (($x68 (or false false)))
(let (($x78 (or $x68 false false)))
(let (($x139 (or $x78 false)))
(let (($x3085 (or $x139 $x139 false)))
(let (($x404 (or $x3085 false false)))
(and (not $x404) (or $x404 (and (distinct ?x3557 ?x3557) true)))))))))))))))
(check-sat)
; query 89: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1739 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x102 (or false false false)))
(let (($x104 (not $x102)))
(and $x104 (or $x102 (and (distinct ?x1739 ?x1739) true)))))))
(check-sat)
; query 90: function matrix_add_const, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x102 (or false false false)))
(let (($x104 (not $x102)))
(and $x104 (or $x102 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 91: function matrix_add_const, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1219 (bvadd in.01_32 (_ bv1 32))))
(let (($x188 (and (distinct ?x1219 ?x1219) true)))
(let (($x102 (or false false false)))
(let (($x104 (not $x102)))
(and $x104 (or $x102 $x188)))))))
(check-sat)
; query 92: function matrix_mul_const, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x102 (or false false false)))
(let (($x104 (not $x102)))
(and $x104 (or $x102 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 93: function matrix_mul_const, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1219 (bvadd in.01_32 (_ bv1 32))))
(let (($x188 (and (distinct ?x1219 ?x1219) true)))
(let (($x102 (or false false false)))
(let (($x104 (not $x102)))
(and $x104 (or $x102 $x188)))))))
(check-sat)
; query 94: function matrix_mul_matrix, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x102 (or false false false)))
(let (($x104 (not $x102)))
(and $x104 (or $x102 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 95: function matrix_mul_matrix, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1219 (bvadd in.01_32 (_ bv1 32))))
(let (($x188 (and (distinct ?x1219 ?x1219) true)))
(let (($x102 (or false false false)))
(let (($x104 (not $x102)))
(and $x104 (or $x102 $x188)))))))
(check-sat)
; query 96: function matrix_mul_matrix, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x102 (or false false false)))
(let (($x104 (not $x102)))
(and $x104 (or $x102 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 97: function matrix_mul_matrix_bitextract, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x102 (or false false false)))
(let (($x104 (not $x102)))
(and $x104 (or $x102 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 98: function matrix_mul_matrix_bitextract, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1219 (bvadd in.01_32 (_ bv1 32))))
(let (($x188 (and (distinct ?x1219 ?x1219) true)))
(let (($x102 (or false false false)))
(let (($x104 (not $x102)))
(and $x104 (or $x102 $x188)))))))
(check-sat)
; query 99: function matrix_mul_matrix_bitextract, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x102 (or false false false)))
(let (($x104 (not $x102)))
(and $x104 (or $x102 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 100: function matrix_mul_vect, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x102 (or false false false)))
(let (($x104 (not $x102)))
(and $x104 (or $x102 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 101: function matrix_mul_vect, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1219 (bvadd in.01_32 (_ bv1 32))))
(let (($x188 (and (distinct ?x1219 ?x1219) true)))
(let (($x102 (or false false false)))
(let (($x104 (not $x102)))
(and $x104 (or $x102 $x188)))))))
(check-sat)
; query 102: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x68 (or false false)))
(let (($x110 (not $x68)))
(and $x110 (or $x68 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 103: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x2215 ((_ sign_extend 16) in.1_16)))
(let ((?x7236 (bvadd ?x2215 (_ bv10 32))))
(let (($x1274 (and (distinct (bvadd ((_ sign_extend 1) ?x2215) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x7236)) true)))
(let (($x68 (or false false)))
(let (($x5284 (or $x68 false (or $x1274))))
(and (not $x5284) (or $x5284 (and (distinct ?x7236 ?x7236) true)))))))))
(check-sat)
; query 104: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x2215 ((_ sign_extend 16) in.1_16)))
(let ((?x7236 (bvadd ?x2215 (_ bv10 32))))
(let ((?x7276 ((_ extract 15 0) ?x7236)))
(let (($x1274 (and (distinct (bvadd ((_ sign_extend 1) ?x2215) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x7236)) true)))
(let (($x68 (or false false)))
(let (($x5284 (or $x68 false (or $x1274))))
(let (($x3260 (or $x5284 false)))
(and (not $x3260) (or $x3260 (and (distinct ?x7276 ?x7276) true)))))))))))
(check-sat)
; query 105: function matrix_sum, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x1723 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x102 (or false false false)))
(let (($x104 (not $x102)))
(and $x104 (or $x102 (and (distinct ?x1723 ?x1723) true)))))))
(check-sat)
; query 106: function matrix_sum, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x1723 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let ((?x7343 ((_ zero_extend 63) ?x1723)))
(let (($x102 (or false false false)))
(let (($x3287 (or $x102 false)))
(and (not $x3287) (or $x3287 (and (distinct ?x7343 ?x7343) true))))))))
(check-sat)
; query 107: function matrix_sum, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x1723 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x5486 (= (_ bv1 1) ?x1723)))
(let ((?x4497 (ite $x5486 (_ bv1 32) (_ bv0 32))))
(let (($x102 (or false false false)))
(let (($x4926 (or $x102 (ite $x5486 false false))))
(and (not $x4926) (or $x4926 (and (distinct ?x4497 ?x4497) true)))))))))
(check-sat)
; query 108: function matrix_sum, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x68 (or false false)))
(let (($x110 (not $x68)))
(and $x110 (or $x68 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 109: function matrix_sum, block 22, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x1723 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x5486 (= (_ bv1 1) ?x1723)))
(let ((?x4497 (ite $x5486 (_ bv1 32) (_ bv0 32))))
(let ((?x2215 ((_ sign_extend 16) in.1_16)))
(let ((?x1284 (bvadd ?x2215 ?x4497)))
(let (($x5367 (and (distinct (bvadd ((_ sign_extend 1) ?x2215) ((_ sign_extend 1) ?x4497)) ((_ sign_extend 1) ?x1284)) true)))
(let (($x102 (or false false false)))
(let (($x4926 (or $x102 (ite $x5486 false false))))
(let (($x68 (or false false)))
(let (($x1332 (or $x68 $x4926 (or $x5367))))
(and (not $x1332) (or $x1332 (and (distinct ?x1284 ?x1284) true))))))))))))))
(check-sat)
; query 110: function matrix_sum, block 22, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x1723 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x5486 (= (_ bv1 1) ?x1723)))
(let ((?x4497 (ite $x5486 (_ bv1 32) (_ bv0 32))))
(let ((?x2215 ((_ sign_extend 16) in.1_16)))
(let ((?x1284 (bvadd ?x2215 ?x4497)))
(let ((?x4288 ((_ extract 15 0) ?x1284)))
(let (($x5367 (and (distinct (bvadd ((_ sign_extend 1) ?x2215) ((_ sign_extend 1) ?x4497)) ((_ sign_extend 1) ?x1284)) true)))
(let (($x102 (or false false false)))
(let (($x4926 (or $x102 (ite $x5486 false false))))
(let (($x68 (or false false)))
(let (($x1332 (or $x68 $x4926 (or $x5367))))
(let (($x490 (or $x1332 false)))
(and (not $x490) (or $x490 (and (distinct ?x4288 ?x4288) true))))))))))))))))
(check-sat)
; query 111: function matrix_sum, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x102 (or false false false)))
(let (($x104 (not $x102)))
(and $x104 (or $x102 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 112: function matrix_sum, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1219 (bvadd in.01_32 (_ bv1 32))))
(let (($x188 (and (distinct ?x1219 ?x1219) true)))
(let (($x102 (or false false false)))
(let (($x104 (not $x102)))
(and $x104 (or $x102 $x188)))))))
(check-sat)
; query 113: function parseval, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.23_32 () (_ BitVec 32))
(assert
 (let (($x7123 (and (distinct (bvmul ((_ sign_extend 32) in.23_32) ((_ sign_extend 32) (_ bv1024 32))) ((_ sign_extend 32) (bvmul in.23_32 (_ bv1024 32)))) true)))
(let (($x3359 (or false false (or $x7123))))
(and (not $x3359) (or $x3359 (and (distinct (bvmul in.23_32 (_ bv1024 32)) (bvmul in.23_32 (_ bv1024 32))) true))))))
(check-sat)
; query 114: function parseval, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.34_32 () (_ BitVec 32))
(assert
 (let (($x4776 (and (distinct (bvmul ((_ sign_extend 32) in.34_32) ((_ sign_extend 32) (_ bv1048576 32))) ((_ sign_extend 32) (bvmul in.34_32 (_ bv1048576 32)))) true)))
(let (($x2231 (or false false (or $x4776))))
(and (not $x2231) (or $x2231 (and (distinct (bvmul in.34_32 (_ bv1048576 32)) (bvmul in.34_32 (_ bv1048576 32))) true))))))
(check-sat)
; query 115: function partition_memory, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x102 (or false false false)))
(let (($x104 (not $x102)))
(and $x104 (or $x102 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 116: function run_crc_loop, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1219 (bvadd in.01_32 (_ bv1 32))))
(let (($x188 (and (distinct ?x1219 ?x1219) true)))
(let (($x102 (or false false false)))
(let (($x104 (not $x102)))
(and $x104 (or $x102 $x188)))))))
(check-sat)
