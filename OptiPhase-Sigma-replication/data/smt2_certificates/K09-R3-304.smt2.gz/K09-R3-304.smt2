; OptiPhase-Sigma refinement certificate for sweep K09-R3-304
; query 0: function xmalloc, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in7_32 () (_ BitVec 32))
(assert
 (let ((?x132 (ite (and (distinct (_ bv0 32) in7_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x119 (or false false false)))
(and (not $x119) (or $x119 (and (distinct ?x132 ?x132) true))))))
(check-sat)
