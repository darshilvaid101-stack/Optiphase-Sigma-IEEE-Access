; OptiPhase-Sigma refinement certificate for sweep K52-R3-220
; query 0: function check, block 103, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x519 (ite (= (_ bv22 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x105 (or false false false)))
(let (($x113 (not $x105)))
(and $x113 (or $x105 (and (distinct ?x519 (ite (= (_ bv0 32) in0_32) (_ bv1 1) (_ bv0 1))) true)))))))
(check-sat)
; query 1: function check, block 109, name %110
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x1621 (ite (= (_ bv33 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x105 (or false false false)))
(let (($x113 (not $x105)))
(and $x113 (or $x105 (and (distinct ?x1621 (ite (= (_ bv12 32) in0_32) (_ bv1 1) (_ bv0 1))) true)))))))
(check-sat)
; query 2: function check, block 67, name %68
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x286 (ite (= (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x105 (or false false false)))
(let (($x113 (not $x105)))
(and $x113 (or $x105 (and (distinct (ite (= (_ bv1 32) in0_32) (_ bv1 1) (_ bv0 1)) ?x286) true)))))))
(check-sat)
; query 3: function check, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x149 (ite (= (_ bv4 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x105 (or false false false)))
(let (($x113 (not $x105)))
(and $x113 (or $x105 (and (distinct (ite (= (_ bv2 32) in0_32) (_ bv1 1) (_ bv0 1)) ?x149) true)))))))
(check-sat)
; query 4: function check, block 79, name %80
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x712 (ite (= (_ bv5 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let ((?x286 (ite (= (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x105 (or false false false)))
(let (($x113 (not $x105)))
(and $x113 (or $x105 (and (distinct ?x286 ?x712) true))))))))
(check-sat)
; query 5: function check, block 85, name %86
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x206 (ite (= (_ bv11 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let ((?x149 (ite (= (_ bv4 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x105 (or false false false)))
(let (($x113 (not $x105)))
(and $x113 (or $x105 (and (distinct ?x149 ?x206) true))))))))
(check-sat)
; query 6: function check, block 91, name %92
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x519 (ite (= (_ bv22 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let ((?x712 (ite (= (_ bv5 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x105 (or false false false)))
(let (($x113 (not $x105)))
(and $x113 (or $x105 (and (distinct ?x712 ?x519) true))))))))
(check-sat)
; query 7: function check, block 97, name %98
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x1621 (ite (= (_ bv33 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let ((?x206 (ite (= (_ bv11 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x105 (or false false false)))
(let (($x113 (not $x105)))
(and $x113 (or $x105 (and (distinct ?x206 ?x1621) true))))))))
(check-sat)
; query 8: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x139 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x105 (or false false false)))
(let (($x113 (not $x105)))
(and $x113 (or $x105 (and (distinct ?x139 ?x139) true)))))))
(check-sat)
; query 9: function s162, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x1889 (ite (bvslt (_ bv0 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x105 (or false false false)))
(let (($x113 (not $x105)))
(and $x113 (or $x105 (and (distinct ?x1889 ?x1889) true)))))))
(check-sat)
; query 10: function s276, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x157 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x232 (or false false (or $x157))))
(and (not $x232) (or $x232 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 11: function s276, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x948 (ite (bvsgt (_ bv16000 32) (bvadd in.0_32 (_ bv1 32))) (_ bv1 1) (_ bv0 1))))
(let (($x157 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x232 (or false false (or $x157))))
(let (($x36 (or $x232 false false)))
(and (not $x36) (or $x36 (and (distinct ?x948 ?x948) true))))))))
(check-sat)
; query 12: function set1d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x1935 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x105 (or false false false)))
(let (($x113 (not $x105)))
(and $x113 (or $x105 (and (distinct ?x1935 ?x1935) true)))))))
(check-sat)
; query 13: function set1ds, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x408 (ite (= (_ bv4294967295 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x105 (or false false false)))
(let (($x113 (not $x105)))
(and $x113 (or $x105 (and (distinct ?x408 ?x408) true)))))))
(check-sat)
; query 14: function set2d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x1935 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x105 (or false false false)))
(let (($x113 (not $x105)))
(and $x113 (or $x105 (and (distinct ?x1935 ?x1935) true)))))))
(check-sat)
