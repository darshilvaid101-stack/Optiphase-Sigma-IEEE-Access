; OptiPhase-Sigma refinement certificate for sweep K51-R5-402
