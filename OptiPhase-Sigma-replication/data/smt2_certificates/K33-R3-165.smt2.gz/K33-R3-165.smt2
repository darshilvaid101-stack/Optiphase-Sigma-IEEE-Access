; OptiPhase-Sigma refinement certificate for sweep K33-R3-165
; query 0: function getint, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x18 (ite (bvsle (_ bv48 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x20 (or false false false)))
(let (($x25 (not $x20)))
(and $x25 (or $x20 (and (distinct ?x18 ?x18) true)))))))
(check-sat)
; query 1: function getint, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x478 (ite (bvsge (_ bv57 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x20 (or false false false)))
(let (($x25 (not $x20)))
(and $x25 (or $x20 (and (distinct ?x478 ?x478) true)))))))
(check-sat)
; query 2: function getint, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x171 (ite (= (_ bv4294967295 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x20 (or false false false)))
(let (($x25 (not $x20)))
(and $x25 (or $x20 (and (distinct ?x171 ?x171) true)))))))
(check-sat)
; query 3: function main, block 129, name %130
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.011.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x151 (ite (and (distinct (_ bv0 32) in.011.lcssa_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x20 (or false false false)))
(let (($x25 (not $x20)))
(and $x25 (or $x20 (and (distinct ?x151 ?x151) true)))))))
(check-sat)
; query 4: function main, block 160, name %161
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x121 (ite (and (distinct (_ bv0 32) in.01.lcssa_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x20 (or false false false)))
(let (($x25 (not $x20)))
(and $x25 (or $x20 (and (distinct ?x121 ?x121) true)))))))
(check-sat)
; query 5: function main, block 66, name %67
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x41 (ite (= (_ bv0 32) in.0.lcssa_32) (_ bv1 1) (_ bv0 1))))
(let (($x20 (or false false false)))
(let (($x25 (not $x20)))
(and $x25 (or $x20 (and (distinct ?x41 ?x41) true)))))))
(check-sat)
; query 6: function main, block 84, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.07.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x77 (ite (and (distinct (_ bv0 32) in.07.lcssa_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x20 (or false false false)))
(let (($x25 (not $x20)))
(and $x25 (or $x20 (and (distinct ?x77 ?x77) true)))))))
(check-sat)
; query 7: function susan_smoothing, block 21, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x129 (ite (= (_ bv0 32) (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x20 (or false false false)))
(let (($x25 (not $x20)))
(and $x25 (or $x20 (and (distinct ?x129 ?x129) true)))))))
(check-sat)
