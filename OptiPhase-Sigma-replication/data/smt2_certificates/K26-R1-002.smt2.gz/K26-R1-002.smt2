; OptiPhase-Sigma refinement certificate for sweep K26-R1-002
