; OptiPhase-Sigma refinement certificate for sweep K33-R6-044
; query 0: function edge_draw, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let ((?x62 (ite (= (_ bv0 32) in4_32) (_ bv1 1) (_ bv0 1))))
(let (($x309 (or false false false)))
(let (($x127 (not $x309)))
(and $x127 (or $x309 (and (distinct ?x62 ?x62) true)))))))
(check-sat)
; query 1: function getint, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x55 (and (distinct (ite (bvsle (_ bv48 32) in.02_32) (_ bv1 1) (_ bv0 1)) (ite (bvsgt (_ bv58 32) in.02_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x309 (or false false false)))
(let (($x127 (not $x309)))
(and $x127 (or $x309 $x55))))))
(check-sat)
