; OptiPhase-Sigma refinement certificate for sweep K43-R3-189
; query 0: function crc32buf, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_64 () (_ BitVec 64))
(assert
 (let (($x89 (or false false false)))
(let (($x178 (not $x89)))
(and $x178 (or $x89 (and (distinct (bvxor in.02_64 (_ bv18446744073709551615 64)) (bvxor in.02_64 (_ bv18446744073709551615 64))) true))))))
(check-sat)
; query 1: function main, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x176 (ite (and (distinct (_ bv0 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(let (($x178 (not $x89)))
(and $x178 (or $x89 (and (distinct ?x176 ?x176) true)))))))
(check-sat)
; query 2: function main, block 17, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x176 (ite (and (distinct (_ bv0 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let ((?x442 ((_ zero_extend 31) ?x176)))
(let (($x89 (or false false false)))
(let (($x125 (or $x89 false)))
(and (not $x125) (or $x125 (and (distinct ?x442 ?x442) true))))))))
(check-sat)
