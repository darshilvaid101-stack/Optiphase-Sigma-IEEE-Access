; OptiPhase-Sigma refinement certificate for sweep K48-R3-219
; query 0: function APCM_inverse_quantization, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x91 (or false false)))
(let (($x449 (not $x91)))
(and $x449 (or $x91 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 1: function APCM_inverse_quantization, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1882 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x91 (or false false)))
(let (($x1462 (or $x91 false false)))
(let (($x21 (not $x1462)))
(and $x21 (or $x1462 (and (distinct ?x1882 ?x1882) true))))))))
(check-sat)
; query 2: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x91 (or false false)))
(let (($x449 (not $x91)))
(and $x449 (or $x91 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 3: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x100 (ite (bvslt (_ bv15 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x91 (or false false)))
(let (($x1462 (or $x91 false false)))
(let (($x21 (not $x1462)))
(and $x21 (or $x1462 (and (distinct ?x100 ?x100) true))))))))
(check-sat)
; query 4: function Decoding_of_the_coded_Log_Area_Ratios, block 268, name %269
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in265_64 () (_ BitVec 64))
(assert
 (let (($x813 (and (distinct (ite (bvsge (_ bv18446744073709518848 64) in265_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv0 64) in265_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x172 (or false false false)))
(let (($x340 (not $x172)))
(and $x340 (or $x172 $x813))))))
(check-sat)
; query 5: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x91 (or false false)))
(let (($x449 (not $x91)))
(and $x449 (or $x91 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 6: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x516 (ite (bvsgt (_ bv40 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x91 (or false false)))
(let (($x1462 (or $x91 false false)))
(let (($x21 (not $x1462)))
(and $x21 (or $x1462 (and (distinct ?x516 ?x516) true))))))))
(check-sat)
; query 7: function Quantization_and_coding, block 311, name %312
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in308_32 () (_ BitVec 32))
(declare-fun in308_64 () (_ BitVec 64))
(assert
 (let (($x882 (and (distinct (ite (bvslt (_ bv0 64) in308_64) (_ bv1 1) (_ bv0 1)) (ite (bvsgt (_ bv4294967292 32) in308_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x172 (or false false false)))
(let (($x340 (not $x172)))
(and $x340 (or $x172 $x882))))))
(check-sat)
; query 8: function RPE_grid_positioning, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x91 (or false false)))
(let (($x449 (not $x91)))
(and $x449 (or $x91 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 9: function RPE_grid_positioning, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x427 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x95 (and (distinct ?x427 ?x427) true)))
(let (($x91 (or false false)))
(let (($x462 (or false $x91 false)))
(and (not $x462) (or $x462 $x95)))))))
(check-sat)
; query 10: function alaw_input, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x153 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x128 (or false false (or $x153))))
(and (not $x128) (or $x128 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 11: function alaw_input, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let ((?x71 (ite (= (_ bv4294967295 32) in.1_32) (_ bv1 1) (_ bv0 1))))
(let (($x172 (or false false false)))
(let (($x340 (not $x172)))
(and $x340 (or $x172 (and (distinct ?x71 ?x71) true)))))))
(check-sat)
; query 12: function gsm_L_add, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_64 () (_ BitVec 64))
(assert
 (let ((?x416 (bvsub (_ bv0 64) in13_64)))
(let ((?x831 ((_ sign_extend 1) ?x416)))
(let (($x196 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in13_64)) ?x831) true)))))
(and (not $x196) (or $x196 (and (distinct ?x416 ?x416) true)))))))
(check-sat)
; query 13: function gsm_L_add, block 16, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_64 () (_ BitVec 64))
(assert
 (let ((?x416 (bvsub (_ bv0 64) in13_64)))
(let ((?x283 (bvsub ?x416 (_ bv2 64))))
(let (($x501 (and (distinct (bvsub ((_ sign_extend 1) ?x416) ((_ sign_extend 1) (_ bv2 64))) ((_ sign_extend 1) ?x283)) true)))
(let ((?x831 ((_ sign_extend 1) ?x416)))
(let (($x196 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in13_64)) ?x831) true)))))
(let (($x149 (or $x196 false (or $x501))))
(and (not $x149) (or $x149 (and (distinct ?x283 ?x283) true))))))))))
(check-sat)
; query 14: function gsm_L_add, block 21, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x87 (ite (bvsge (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x172 (or false false false)))
(let (($x340 (not $x172)))
(and $x340 (or $x172 (and (distinct ?x87 ?x87) true)))))))
(check-sat)
; query 15: function gsm_L_add, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x12 (bvadd in0_64 in1_64)))
(let (($x105 (and (distinct ?x12 ?x12) true)))
(let (($x119 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) ?x12)) true)))
(let (($x533 (or false false (or $x119))))
(and (not $x533) (or $x533 $x105)))))))
(check-sat)
; query 16: function gsm_L_add, block 25, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x12 (bvadd in0_64 in1_64)))
(let (($x105 (and (distinct ?x12 ?x12) true)))
(let (($x172 (or false false false)))
(let (($x340 (not $x172)))
(and $x340 (or $x172 $x105)))))))
(check-sat)
; query 17: function gsm_L_add, block 25, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x285 (ite (bvugt (bvadd in0_64 in1_64) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x172 (or false false false)))
(let (($x508 (or $x172 false false)))
(let (($x39 (not $x508)))
(and $x39 (or $x508 (and (distinct ?x285 ?x285) true))))))))
(check-sat)
; query 18: function gsm_L_add, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x2780 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x172 (or false false false)))
(let (($x340 (not $x172)))
(and $x340 (or $x172 (and (distinct ?x2780 ?x2780) true)))))))
(check-sat)
; query 19: function gsm_L_add, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x12 (bvadd in0_64 in1_64)))
(let (($x105 (and (distinct ?x12 ?x12) true)))
(let (($x119 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) ?x12)) true)))
(let (($x533 (or false false (or $x119))))
(and (not $x533) (or $x533 $x105)))))))
(check-sat)
; query 20: function gsm_L_add, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x23 (bvadd in0_64 (_ bv1 64))))
(let ((?x155 (bvsub (_ bv0 64) ?x23)))
(let (($x774 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x23)) ((_ sign_extend 1) ?x155)) true)))
(let ((?x575 ((_ sign_extend 1) ?x23)))
(let (($x991 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x575) true)))))
(let (($x1026 (or false $x991 (or $x774))))
(and (not $x1026) (or $x1026 (and (distinct ?x155 ?x155) true))))))))))
(check-sat)
; query 21: function gsm_L_add, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x615 (bvadd in1_64 (_ bv1 64))))
(let ((?x43 ((_ sign_extend 1) ?x615)))
(let (($x1750 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x43) true)))))
(and (not $x1750) (or $x1750 (and (distinct ?x615 ?x615) true)))))))
(check-sat)
; query 22: function gsm_L_add, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x615 (bvadd in1_64 (_ bv1 64))))
(let ((?x729 (bvsub (_ bv0 64) ?x615)))
(let (($x44 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x615)) ((_ sign_extend 1) ?x729)) true)))
(let ((?x43 ((_ sign_extend 1) ?x615)))
(let (($x1750 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x43) true)))))
(let (($x1068 (or false $x1750 (or $x44))))
(and (not $x1068) (or $x1068 (and (distinct ?x729 ?x729) true))))))))))
(check-sat)
; query 23: function gsm_L_add, block 8, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x615 (bvadd in1_64 (_ bv1 64))))
(let ((?x729 (bvsub (_ bv0 64) ?x615)))
(let ((?x23 (bvadd in0_64 (_ bv1 64))))
(let ((?x155 (bvsub (_ bv0 64) ?x23)))
(let ((?x281 (bvadd ?x155 ?x729)))
(let (($x44 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x615)) ((_ sign_extend 1) ?x729)) true)))
(let ((?x43 ((_ sign_extend 1) ?x615)))
(let (($x1750 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x43) true)))))
(let (($x1068 (or false $x1750 (or $x44))))
(let (($x774 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x23)) ((_ sign_extend 1) ?x155)) true)))
(let ((?x575 ((_ sign_extend 1) ?x23)))
(let (($x991 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x575) true)))))
(let (($x1026 (or false $x991 (or $x774))))
(let (($x1128 (or $x1026 $x1068 false)))
(and (not $x1128) (or $x1128 (and (distinct ?x281 ?x281) true))))))))))))))))))
(check-sat)
; query 24: function gsm_L_add, block 8, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x615 (bvadd in1_64 (_ bv1 64))))
(let ((?x729 (bvsub (_ bv0 64) ?x615)))
(let ((?x23 (bvadd in0_64 (_ bv1 64))))
(let ((?x155 (bvsub (_ bv0 64) ?x23)))
(let ((?x281 (bvadd ?x155 ?x729)))
(let ((?x810 (ite (bvuge ?x281 (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x44 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x615)) ((_ sign_extend 1) ?x729)) true)))
(let ((?x43 ((_ sign_extend 1) ?x615)))
(let (($x1750 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x43) true)))))
(let (($x1068 (or false $x1750 (or $x44))))
(let (($x774 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x23)) ((_ sign_extend 1) ?x155)) true)))
(let ((?x575 ((_ sign_extend 1) ?x23)))
(let (($x991 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x575) true)))))
(let (($x1026 (or false $x991 (or $x774))))
(let (($x1128 (or $x1026 $x1068 false)))
(let (($x222 (or $x1128 false false)))
(and (not $x222) (or $x222 (and (distinct ?x810 ?x810) true))))))))))))))))))))
(check-sat)
; query 25: function gsm_L_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x23 (bvadd in0_64 (_ bv1 64))))
(let ((?x575 ((_ sign_extend 1) ?x23)))
(let (($x991 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x575) true)))))
(and (not $x991) (or $x991 (and (distinct ?x23 ?x23) true)))))))
(check-sat)
; query 26: function gsm_L_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1435 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x172 (or false false false)))
(let (($x340 (not $x172)))
(and $x340 (or $x172 (and (distinct ?x1435 ?x1435) true)))))))
(check-sat)
; query 27: function gsm_L_asl, block 12, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1837 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x172 (or false false false)))
(let (($x340 (not $x172)))
(and $x340 (or $x172 (and (distinct ?x1837 ?x1837) true)))))))
(check-sat)
; query 28: function gsm_L_asl, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x91 (or false false)))
(let (($x449 (not $x91)))
(and $x449 (or $x91 (and (distinct ((_ zero_extend 32) in1_32) ((_ zero_extend 32) in1_32)) true))))))
(check-sat)
; query 29: function gsm_L_asl, block 17, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x669 ((_ zero_extend 32) in1_32)))
(let ((?x444 (bvshl in0_64 ?x669)))
(let (($x91 (or false false)))
(let (($x462 (or false $x91 false)))
(let (($x179 (or $x462 (bvuge ?x669 (_ bv64 64)))))
(let (($x742 (not $x179)))
(and $x742 (or $x179 (and (distinct ?x444 ?x444) true))))))))))
(check-sat)
; query 30: function gsm_L_asl, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x953 (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x172 (or false false false)))
(let (($x340 (not $x172)))
(and $x340 (or $x172 (and (distinct ?x953 ?x953) true)))))))
(check-sat)
; query 31: function gsm_L_asl, block 7, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1435 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x379 ((_ zero_extend 31) ?x1435)))
(let ((?x840 (bvsub (_ bv0 32) ?x379)))
(let (($x250 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x379)) ((_ sign_extend 1) ?x840)) true)))
(let (($x172 (or false false false)))
(let (($x305 (or $x172 false)))
(let (($x218 (or false $x305 (or $x250))))
(and (not $x218) (or $x218 (and (distinct ?x840 ?x840) true)))))))))))
(check-sat)
; query 32: function gsm_L_asl, block 7, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1435 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x379 ((_ zero_extend 31) ?x1435)))
(let ((?x840 (bvsub (_ bv0 32) ?x379)))
(let ((?x361 ((_ sign_extend 32) ?x840)))
(let (($x250 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x379)) ((_ sign_extend 1) ?x840)) true)))
(let (($x172 (or false false false)))
(let (($x305 (or $x172 false)))
(let (($x218 (or false $x305 (or $x250))))
(let (($x877 (or $x218 false)))
(and (not $x877) (or $x877 (and (distinct ?x361 ?x361) true)))))))))))))
(check-sat)
; query 33: function gsm_L_asl, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1435 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x172 (or false false false)))
(let (($x340 (not $x172)))
(and $x340 (or $x172 (and (distinct ?x1435 ?x1435) true)))))))
(check-sat)
; query 34: function gsm_L_asl, block 7, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1435 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x379 ((_ zero_extend 31) ?x1435)))
(let (($x172 (or false false false)))
(let (($x305 (or $x172 false)))
(and (not $x305) (or $x305 (and (distinct ?x379 ?x379) true))))))))
(check-sat)
; query 35: function gsm_L_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1557 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x172 (or false false false)))
(let (($x340 (not $x172)))
(and $x340 (or $x172 (and (distinct ?x1557 ?x1557) true)))))))
(check-sat)
; query 36: function gsm_L_asr, block 12, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1837 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x172 (or false false false)))
(let (($x340 (not $x172)))
(and $x340 (or $x172 (and (distinct ?x1837 ?x1837) true)))))))
(check-sat)
; query 37: function gsm_L_asr, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x1789 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in1_32))) true)))
(let (($x1590 (or false false (or $x1789))))
(and (not $x1590) (or $x1590 (and (distinct (bvsub (_ bv0 32) in1_32) (bvsub (_ bv0 32) in1_32)) true))))))
(check-sat)
; query 38: function gsm_L_asr, block 14, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x621 (bvsub (_ bv0 32) in1_32)))
(let ((?x692 ((_ zero_extend 32) ?x621)))
(let (($x1789 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x621)) true)))
(let (($x1590 (or false false (or $x1789))))
(let (($x53 (or $x1590 false)))
(and (not $x53) (or $x53 (and (distinct ?x692 ?x692) true)))))))))
(check-sat)
; query 39: function gsm_L_asr, block 14, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x621 (bvsub (_ bv0 32) in1_32)))
(let ((?x692 ((_ zero_extend 32) ?x621)))
(let ((?x1579 (bvshl in0_64 ?x692)))
(let (($x1789 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x621)) true)))
(let (($x1590 (or false false (or $x1789))))
(let (($x53 (or $x1590 false)))
(let (($x676 (or (or false $x53 false) (bvuge ?x692 (_ bv64 64)))))
(and (not $x676) (or $x676 (and (distinct ?x1579 ?x1579) true)))))))))))
(check-sat)
; query 40: function gsm_L_asr, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x91 (or false false)))
(let (($x449 (not $x91)))
(and $x449 (or $x91 (and (distinct ((_ zero_extend 32) in1_32) ((_ zero_extend 32) in1_32)) true))))))
(check-sat)
; query 41: function gsm_L_asr, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x669 ((_ zero_extend 32) in1_32)))
(let ((?x1276 (bvashr in0_64 ?x669)))
(let (($x91 (or false false)))
(let (($x462 (or false $x91 false)))
(let (($x179 (or $x462 (bvuge ?x669 (_ bv64 64)))))
(let (($x742 (not $x179)))
(and $x742 (or $x179 (and (distinct ?x1276 ?x1276) true))))))))))
(check-sat)
; query 42: function gsm_L_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1435 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x172 (or false false false)))
(let (($x340 (not $x172)))
(and $x340 (or $x172 (and (distinct ?x1435 ?x1435) true)))))))
(check-sat)
; query 43: function gsm_L_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1435 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x379 ((_ zero_extend 31) ?x1435)))
(let (($x172 (or false false false)))
(let (($x305 (or $x172 false)))
(and (not $x305) (or $x305 (and (distinct ?x379 ?x379) true))))))))
(check-sat)
; query 44: function gsm_L_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1435 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x379 ((_ zero_extend 31) ?x1435)))
(let ((?x840 (bvsub (_ bv0 32) ?x379)))
(let (($x250 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x379)) ((_ sign_extend 1) ?x840)) true)))
(let (($x172 (or false false false)))
(let (($x305 (or $x172 false)))
(let (($x218 (or false $x305 (or $x250))))
(and (not $x218) (or $x218 (and (distinct ?x840 ?x840) true)))))))))))
(check-sat)
; query 45: function gsm_L_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1435 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x379 ((_ zero_extend 31) ?x1435)))
(let ((?x840 (bvsub (_ bv0 32) ?x379)))
(let ((?x361 ((_ sign_extend 32) ?x840)))
(let (($x250 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x379)) ((_ sign_extend 1) ?x840)) true)))
(let (($x172 (or false false false)))
(let (($x305 (or $x172 false)))
(let (($x218 (or false $x305 (or $x250))))
(let (($x877 (or $x218 false)))
(and (not $x877) (or $x877 (and (distinct ?x361 ?x361) true)))))))))))))
(check-sat)
; query 46: function gsm_L_asr, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x953 (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x172 (or false false false)))
(let (($x340 (not $x172)))
(and $x340 (or $x172 (and (distinct ?x953 ?x953) true)))))))
(check-sat)
; query 47: function gsm_L_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1557 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x172 (or false false false)))
(let (($x340 (not $x172)))
(and $x340 (or $x172 (and (distinct ?x1557 ?x1557) true)))))))
(check-sat)
; query 48: function gsm_L_mult, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x91 (or false false)))
(let (($x449 (not $x91)))
(and $x449 (or $x91 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 49: function gsm_L_mult, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x303 (ite (and (distinct (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) true) (_ bv1 1) (_ bv0 1))))
(let (($x91 (or false false)))
(let (($x1462 (or $x91 false false)))
(let (($x21 (not $x1462)))
(and $x21 (or $x1462 (and (distinct ?x303 ?x303) true))))))))
(check-sat)
; query 50: function gsm_L_mult, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x91 (or false false)))
(let (($x449 (not $x91)))
(and $x449 (or $x91 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 51: function gsm_L_mult, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x752 (ite (and (distinct (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) true) (_ bv1 1) (_ bv0 1))))
(let (($x91 (or false false)))
(let (($x1462 (or $x91 false false)))
(let (($x21 (not $x1462)))
(and $x21 (or $x1462 (and (distinct ?x752 ?x752) true))))))))
(check-sat)
; query 52: function gsm_L_sub, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in11_64 () (_ BitVec 64))
(assert
 (let (($x172 (or false false false)))
(let (($x340 (not $x172)))
(and $x340 (or $x172 (and (distinct (bvadd in11_64 (_ bv1 64)) (bvadd in11_64 (_ bv1 64))) true))))))
(check-sat)
; query 53: function gsm_L_sub, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x87 (ite (bvsge (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x172 (or false false false)))
(let (($x340 (not $x172)))
(and $x340 (or $x172 (and (distinct ?x87 ?x87) true)))))))
(check-sat)
; query 54: function gsm_L_sub, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x333 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvsub in0_64 in1_64))) true)))
(let (($x291 (or false false (or $x333))))
(let (($x1732 (or $x291 (and (distinct (bvsub in0_64 in1_64) (bvsub in0_64 in1_64)) true))))
(and (not $x291) $x1732)))))
(check-sat)
; query 55: function gsm_L_sub, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x23 (bvadd in0_64 (_ bv1 64))))
(let ((?x575 ((_ sign_extend 1) ?x23)))
(let (($x991 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x575) true)))))
(and (not $x991) (or $x991 (and (distinct ?x23 ?x23) true)))))))
(check-sat)
; query 56: function gsm_L_sub, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x23 (bvadd in0_64 (_ bv1 64))))
(let ((?x155 (bvsub (_ bv0 64) ?x23)))
(let (($x774 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x23)) ((_ sign_extend 1) ?x155)) true)))
(let ((?x575 ((_ sign_extend 1) ?x23)))
(let (($x991 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x575) true)))))
(let (($x1026 (or false $x991 (or $x774))))
(and (not $x1026) (or $x1026 (and (distinct ?x155 ?x155) true))))))))))
(check-sat)
; query 57: function gsm_L_sub, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x23 (bvadd in0_64 (_ bv1 64))))
(let ((?x155 (bvsub (_ bv0 64) ?x23)))
(let ((?x420 (bvadd ?x155 in1_64)))
(let (($x774 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x23)) ((_ sign_extend 1) ?x155)) true)))
(let ((?x575 ((_ sign_extend 1) ?x23)))
(let (($x991 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x575) true)))))
(let (($x1026 (or false $x991 (or $x774))))
(let (($x1168 (or $x1026 false false)))
(and (not $x1168) (or $x1168 (and (distinct ?x420 ?x420) true))))))))))))
(check-sat)
; query 58: function gsm_L_sub, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1094 (ite (bvuge (bvadd (bvsub (_ bv0 64) (bvadd in0_64 (_ bv1 64))) in1_64) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x774 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) (bvadd in0_64 (_ bv1 64)))) ((_ sign_extend 1) (bvsub (_ bv0 64) (bvadd in0_64 (_ bv1 64))))) true)))
(let ((?x23 (bvadd in0_64 (_ bv1 64))))
(let ((?x575 ((_ sign_extend 1) ?x23)))
(let (($x991 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x575) true)))))
(let (($x1026 (or false $x991 (or $x774))))
(let (($x1168 (or $x1026 false false)))
(let (($x1757 (or $x1168 false false)))
(and (not $x1757) (or $x1757 (and (distinct ?x1094 ?x1094) true))))))))))))
(check-sat)
; query 59: function gsm_L_sub, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_64 () (_ BitVec 64))
(assert
 (let ((?x1031 (bvsub (_ bv0 64) in25_64)))
(let ((?x1209 ((_ sign_extend 1) ?x1031)))
(let (($x1021 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in25_64)) ?x1209) true)))))
(and (not $x1021) (or $x1021 (and (distinct ?x1031 ?x1031) true)))))))
(check-sat)
; query 60: function gsm_L_sub, block 28, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_64 () (_ BitVec 64))
(assert
 (let ((?x1031 (bvsub (_ bv0 64) in25_64)))
(let ((?x537 (bvsub ?x1031 (_ bv1 64))))
(let (($x852 (and (distinct (bvsub ((_ sign_extend 1) ?x1031) ((_ sign_extend 1) (_ bv1 64))) ((_ sign_extend 1) ?x537)) true)))
(let ((?x1209 ((_ sign_extend 1) ?x1031)))
(let (($x1021 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in25_64)) ?x1209) true)))))
(let (($x1814 (or $x1021 false (or $x852))))
(and (not $x1814) (or $x1814 (and (distinct ?x537 ?x537) true))))))))))
(check-sat)
; query 61: function gsm_L_sub, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x2780 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x172 (or false false false)))
(let (($x340 (not $x172)))
(and $x340 (or $x172 (and (distinct ?x2780 ?x2780) true)))))))
(check-sat)
; query 62: function gsm_L_sub, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x333 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvsub in0_64 in1_64))) true)))
(let (($x291 (or false false (or $x333))))
(let (($x1732 (or $x291 (and (distinct (bvsub in0_64 in1_64) (bvsub in0_64 in1_64)) true))))
(and (not $x291) $x1732)))))
(check-sat)
; query 63: function gsm_L_sub, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x615 (bvadd in1_64 (_ bv1 64))))
(let ((?x729 (bvsub (_ bv0 64) ?x615)))
(let (($x44 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x615)) ((_ sign_extend 1) ?x729)) true)))
(let ((?x43 ((_ sign_extend 1) ?x615)))
(let (($x1750 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x43) true)))))
(let (($x1068 (or false $x1750 (or $x44))))
(and (not $x1068) (or $x1068 (and (distinct ?x729 ?x729) true))))))))))
(check-sat)
; query 64: function gsm_L_sub, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x615 (bvadd in1_64 (_ bv1 64))))
(let ((?x729 (bvsub (_ bv0 64) ?x615)))
(let ((?x1307 (bvadd in0_64 ?x729)))
(let (($x44 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x615)) ((_ sign_extend 1) ?x729)) true)))
(let ((?x43 ((_ sign_extend 1) ?x615)))
(let (($x1750 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x43) true)))))
(let (($x1068 (or false $x1750 (or $x44))))
(let (($x1741 (or false $x1068 false)))
(and (not $x1741) (or $x1741 (and (distinct ?x1307 ?x1307) true))))))))))))
(check-sat)
; query 65: function gsm_L_sub, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1496 (ite (bvuge (bvadd in0_64 (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64)))) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x44 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) (bvadd in1_64 (_ bv1 64)))) ((_ sign_extend 1) (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64))))) true)))
(let ((?x615 (bvadd in1_64 (_ bv1 64))))
(let ((?x43 ((_ sign_extend 1) ?x615)))
(let (($x1750 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x43) true)))))
(let (($x1068 (or false $x1750 (or $x44))))
(let (($x1741 (or false $x1068 false)))
(let (($x646 (or $x1741 false false)))
(and (not $x646) (or $x646 (and (distinct ?x1496 ?x1496) true))))))))))))
(check-sat)
; query 66: function gsm_L_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x615 (bvadd in1_64 (_ bv1 64))))
(let ((?x43 ((_ sign_extend 1) ?x615)))
(let (($x1750 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x43) true)))))
(and (not $x1750) (or $x1750 (and (distinct ?x615 ?x615) true)))))))
(check-sat)
; query 67: function gsm_L_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x659 (ite (bvsle (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x172 (or false false false)))
(let (($x340 (not $x172)))
(and $x340 (or $x172 (and (distinct ?x659 ?x659) true)))))))
(check-sat)
; query 68: function gsm_abs, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x91 (or false false)))
(let (($x449 (not $x91)))
(and $x449 (or $x91 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 69: function gsm_abs, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x637 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x91 (or false false)))
(let (($x1462 (or $x91 false false)))
(let (($x21 (not $x1462)))
(and $x21 (or $x1462 (and (distinct ?x637 ?x637) true))))))))
(check-sat)
; query 70: function gsm_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_64 () (_ BitVec 64))
(assert
 (let ((?x1524 (ite (bvslt (_ bv32767 64) in5_64) (_ bv1 1) (_ bv0 1))))
(let (($x172 (or false false false)))
(let (($x340 (not $x172)))
(and $x340 (or $x172 (and (distinct ?x1524 ?x1524) true)))))))
(check-sat)
; query 71: function gsm_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x91 (or false false)))
(let (($x449 (not $x91)))
(and $x449 (or $x91 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 72: function gsm_add, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x91 (or false false)))
(let (($x449 (not $x91)))
(and $x449 (or $x91 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 73: function gsm_add, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x878 ((_ sign_extend 48) in1_16)))
(let ((?x386 ((_ sign_extend 48) in0_16)))
(let ((?x908 (bvadd ?x386 ?x878)))
(let (($x1870 (and (distinct (bvadd ((_ sign_extend 1) ?x386) ((_ sign_extend 1) ?x878)) ((_ sign_extend 1) ?x908)) true)))
(let (($x91 (or false false)))
(let (($x761 (or $x91 $x91 (or $x1870))))
(and (not $x761) (or $x761 (and (distinct ?x908 ?x908) true))))))))))
(check-sat)
; query 74: function gsm_add, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1972 (ite (bvsgt (_ bv18446744073709518848 64) (bvadd ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x878 ((_ sign_extend 48) in1_16)))
(let ((?x1958 ((_ sign_extend 1) ?x878)))
(let ((?x386 ((_ sign_extend 48) in0_16)))
(let ((?x1025 ((_ sign_extend 1) ?x386)))
(let (($x91 (or false false)))
(let (($x761 (or $x91 $x91 (or (and (distinct (bvadd ?x1025 ?x1958) ((_ sign_extend 1) (bvadd ?x386 ?x878))) true)))))
(let (($x301 (or $x761 false false)))
(and (not $x301) (or $x301 (and (distinct ?x1972 ?x1972) true))))))))))))
(check-sat)
; query 75: function gsm_asl, block 13, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1837 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x172 (or false false false)))
(let (($x340 (not $x172)))
(and $x340 (or $x172 (and (distinct ?x1837 ?x1837) true)))))))
(check-sat)
; query 76: function gsm_asl, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x91 (or false false)))
(let (($x449 (not $x91)))
(and $x449 (or $x91 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 77: function gsm_asl, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x253 ((_ sign_extend 16) in0_16)))
(let ((?x795 (bvshl ?x253 in1_32)))
(let (($x91 (or false false)))
(let (($x1462 (or $x91 false false)))
(let (($x1232 (or $x1462 (bvuge in1_32 (_ bv32 32)))))
(let (($x812 (not $x1232)))
(and $x812 (or $x1232 (and (distinct ?x795 ?x795) true))))))))))
(check-sat)
; query 78: function gsm_asl, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x253 ((_ sign_extend 16) in0_16)))
(let ((?x795 (bvshl ?x253 in1_32)))
(let ((?x37 ((_ extract 15 0) ?x795)))
(let (($x91 (or false false)))
(let (($x1462 (or $x91 false false)))
(let (($x1232 (or $x1462 (bvuge in1_32 (_ bv32 32)))))
(let (($x1344 (or $x1232 false)))
(let (($x502 (not $x1344)))
(and $x502 (or $x1344 (and (distinct ?x37 ?x37) true))))))))))))
(check-sat)
; query 79: function gsm_asl, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1308 (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x172 (or false false false)))
(let (($x340 (not $x172)))
(and $x340 (or $x172 (and (distinct ?x1308 ?x1308) true)))))))
(check-sat)
; query 80: function gsm_asl, block 7, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x637 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x438 ((_ zero_extend 31) ?x637)))
(let (($x91 (or false false)))
(let (($x1462 (or $x91 false false)))
(let (($x2487 (or $x1462 false)))
(and (not $x2487) (or $x2487 (and (distinct ?x438 ?x438) true)))))))))
(check-sat)
; query 81: function gsm_asl, block 7, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x637 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x438 ((_ zero_extend 31) ?x637)))
(let ((?x1554 (bvsub (_ bv0 32) ?x438)))
(let (($x2147 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x438)) ((_ sign_extend 1) ?x1554)) true)))
(let (($x91 (or false false)))
(let (($x1462 (or $x91 false false)))
(let (($x2487 (or $x1462 false)))
(let (($x1210 (or false $x2487 (or $x2147))))
(and (not $x1210) (or $x1210 (and (distinct ?x1554 ?x1554) true))))))))))))
(check-sat)
; query 82: function gsm_asl, block 7, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x637 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x438 ((_ zero_extend 31) ?x637)))
(let ((?x1554 (bvsub (_ bv0 32) ?x438)))
(let ((?x1271 ((_ extract 15 0) ?x1554)))
(let (($x2147 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x438)) ((_ sign_extend 1) ?x1554)) true)))
(let (($x91 (or false false)))
(let (($x1462 (or $x91 false false)))
(let (($x2487 (or $x1462 false)))
(let (($x1210 (or false $x2487 (or $x2147))))
(let (($x2515 (or $x1210 false)))
(and (not $x2515) (or $x2515 (and (distinct ?x1271 ?x1271) true))))))))))))))
(check-sat)
; query 83: function gsm_asl, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x91 (or false false)))
(let (($x449 (not $x91)))
(and $x449 (or $x91 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 84: function gsm_asl, block 7, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x637 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x91 (or false false)))
(let (($x1462 (or $x91 false false)))
(let (($x21 (not $x1462)))
(and $x21 (or $x1462 (and (distinct ?x637 ?x637) true))))))))
(check-sat)
; query 85: function gsm_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x425 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x172 (or false false false)))
(let (($x340 (not $x172)))
(and $x340 (or $x172 (and (distinct ?x425 ?x425) true)))))))
(check-sat)
; query 86: function gsm_asr, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1308 (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x172 (or false false false)))
(let (($x340 (not $x172)))
(and $x340 (or $x172 (and (distinct ?x1308 ?x1308) true)))))))
(check-sat)
; query 87: function gsm_asr, block 13, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1837 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x172 (or false false false)))
(let (($x340 (not $x172)))
(and $x340 (or $x172 (and (distinct ?x1837 ?x1837) true)))))))
(check-sat)
; query 88: function gsm_asr, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x91 (or false false)))
(let (($x449 (not $x91)))
(and $x449 (or $x91 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 89: function gsm_asr, block 15, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x1789 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in1_32))) true)))
(let (($x1590 (or false false (or $x1789))))
(and (not $x1590) (or $x1590 (and (distinct (bvsub (_ bv0 32) in1_32) (bvsub (_ bv0 32) in1_32)) true))))))
(check-sat)
; query 90: function gsm_asr, block 15, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x621 (bvsub (_ bv0 32) in1_32)))
(let ((?x253 ((_ sign_extend 16) in0_16)))
(let ((?x2030 (bvshl ?x253 ?x621)))
(let (($x1789 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x621)) true)))
(let (($x1590 (or false false (or $x1789))))
(let (($x91 (or false false)))
(let (($x983 (or (or $x91 $x1590 false) (bvuge ?x621 (_ bv32 32)))))
(and (not $x983) (or $x983 (and (distinct ?x2030 ?x2030) true)))))))))))
(check-sat)
; query 91: function gsm_asr, block 15, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x621 (bvsub (_ bv0 32) in1_32)))
(let ((?x253 ((_ sign_extend 16) in0_16)))
(let ((?x2030 (bvshl ?x253 ?x621)))
(let ((?x2788 ((_ extract 15 0) ?x2030)))
(let (($x1789 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x621)) true)))
(let (($x1590 (or false false (or $x1789))))
(let (($x91 (or false false)))
(let (($x983 (or (or $x91 $x1590 false) (bvuge ?x621 (_ bv32 32)))))
(let (($x1940 (or $x983 false)))
(and (not $x1940) (or $x1940 (and (distinct ?x2788 ?x2788) true)))))))))))))
(check-sat)
; query 92: function gsm_asr, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x91 (or false false)))
(let (($x449 (not $x91)))
(and $x449 (or $x91 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 93: function gsm_asr, block 20, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x253 ((_ sign_extend 16) in0_16)))
(let ((?x1612 (bvashr ?x253 in1_32)))
(let (($x91 (or false false)))
(let (($x1462 (or $x91 false false)))
(let (($x1232 (or $x1462 (bvuge in1_32 (_ bv32 32)))))
(let (($x812 (not $x1232)))
(and $x812 (or $x1232 (and (distinct ?x1612 ?x1612) true))))))))))
(check-sat)
; query 94: function gsm_asr, block 20, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x253 ((_ sign_extend 16) in0_16)))
(let ((?x1612 (bvashr ?x253 in1_32)))
(let ((?x1964 ((_ extract 15 0) ?x1612)))
(let (($x91 (or false false)))
(let (($x1462 (or $x91 false false)))
(let (($x1232 (or $x1462 (bvuge in1_32 (_ bv32 32)))))
(let (($x1344 (or $x1232 false)))
(let (($x502 (not $x1344)))
(and $x502 (or $x1344 (and (distinct ?x1964 ?x1964) true))))))))))))
(check-sat)
; query 95: function gsm_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x91 (or false false)))
(let (($x449 (not $x91)))
(and $x449 (or $x91 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 96: function gsm_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x637 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x91 (or false false)))
(let (($x1462 (or $x91 false false)))
(let (($x21 (not $x1462)))
(and $x21 (or $x1462 (and (distinct ?x637 ?x637) true))))))))
(check-sat)
; query 97: function gsm_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x637 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x438 ((_ zero_extend 31) ?x637)))
(let (($x91 (or false false)))
(let (($x1462 (or $x91 false false)))
(let (($x2487 (or $x1462 false)))
(and (not $x2487) (or $x2487 (and (distinct ?x438 ?x438) true)))))))))
(check-sat)
; query 98: function gsm_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x637 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x438 ((_ zero_extend 31) ?x637)))
(let ((?x1554 (bvsub (_ bv0 32) ?x438)))
(let (($x2147 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x438)) ((_ sign_extend 1) ?x1554)) true)))
(let (($x91 (or false false)))
(let (($x1462 (or $x91 false false)))
(let (($x2487 (or $x1462 false)))
(let (($x1210 (or false $x2487 (or $x2147))))
(and (not $x1210) (or $x1210 (and (distinct ?x1554 ?x1554) true))))))))))))
(check-sat)
; query 99: function gsm_asr, block 4, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x637 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x438 ((_ zero_extend 31) ?x637)))
(let ((?x1554 (bvsub (_ bv0 32) ?x438)))
(let ((?x1271 ((_ extract 15 0) ?x1554)))
(let (($x2147 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x438)) ((_ sign_extend 1) ?x1554)) true)))
(let (($x91 (or false false)))
(let (($x1462 (or $x91 false false)))
(let (($x2487 (or $x1462 false)))
(let (($x1210 (or false $x2487 (or $x2147))))
(let (($x2515 (or $x1210 false)))
(and (not $x2515) (or $x2515 (and (distinct ?x1271 ?x1271) true))))))))))))))
(check-sat)
; query 100: function gsm_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x425 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x172 (or false false false)))
(let (($x340 (not $x172)))
(and $x340 (or $x172 (and (distinct ?x425 ?x425) true)))))))
(check-sat)
; query 101: function gsm_debug_longwords, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in15_32 () (_ BitVec 32))
(assert
 (let ((?x1762 (ite (bvslt in15_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x172 (or false false false)))
(let (($x340 (not $x172)))
(and $x340 (or $x172 (and (distinct ?x1762 ?x1762) true)))))))
(check-sat)
; query 102: function gsm_debug_words, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in16_32 () (_ BitVec 32))
(assert
 (let ((?x2659 (ite (bvslt in16_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x172 (or false false false)))
(let (($x340 (not $x172)))
(and $x340 (or $x172 (and (distinct ?x2659 ?x2659) true)))))))
(check-sat)
; query 103: function gsm_div, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x91 (or false false)))
(let (($x449 (not $x91)))
(and $x449 (or $x91 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 104: function gsm_div, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x91 (or false false)))
(let (($x449 (not $x91)))
(and $x449 (or $x91 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 105: function gsm_div, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x91 (or false false)))
(let (($x449 (not $x91)))
(and $x449 (or $x91 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 106: function gsm_div, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x427 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x95 (and (distinct ?x427 ?x427) true)))
(let (($x91 (or false false)))
(let (($x1462 (or $x91 false false)))
(let (($x21 (not $x1462)))
(and $x21 (or $x1462 $x95))))))))
(check-sat)
; query 107: function gsm_mult, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x91 (or false false)))
(let (($x449 (not $x91)))
(and $x449 (or $x91 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 108: function gsm_mult, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x2620 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x91 (or false false)))
(let (($x1462 (or $x91 false false)))
(let (($x21 (not $x1462)))
(and $x21 (or $x1462 (and (distinct ?x2620 ?x2620) true))))))))
(check-sat)
; query 109: function gsm_mult, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x91 (or false false)))
(let (($x449 (not $x91)))
(and $x449 (or $x91 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 110: function gsm_mult, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x91 (or false false)))
(let (($x449 (not $x91)))
(and $x449 (or $x91 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 111: function gsm_mult, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x878 ((_ sign_extend 48) in1_16)))
(let ((?x386 ((_ sign_extend 48) in0_16)))
(let ((?x836 (bvmul ?x386 ?x878)))
(let (($x1838 (and (distinct (bvmul ((_ sign_extend 64) ?x386) ((_ sign_extend 64) ?x878)) ((_ sign_extend 64) ?x836)) true)))
(let (($x91 (or false false)))
(let (($x2033 (or $x91 $x91 (or $x1838))))
(and (not $x2033) (or $x2033 (and (distinct ?x836 ?x836) true))))))))))
(check-sat)
; query 112: function gsm_mult, block 9, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x878 ((_ sign_extend 48) in1_16)))
(let ((?x386 ((_ sign_extend 48) in0_16)))
(let ((?x836 (bvmul ?x386 ?x878)))
(let ((?x1134 (bvashr ?x836 (_ bv15 64))))
(let (($x182 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1838 (and (distinct (bvmul ((_ sign_extend 64) ?x386) ((_ sign_extend 64) ?x878)) ((_ sign_extend 64) ?x836)) true)))
(let (($x91 (or false false)))
(let (($x2033 (or $x91 $x91 (or $x1838))))
(let (($x783 (or (or $x2033 false false) $x182)))
(and (not $x783) (or $x783 (and (distinct ?x1134 ?x1134) true)))))))))))))
(check-sat)
; query 113: function gsm_mult, block 9, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x878 ((_ sign_extend 48) in1_16)))
(let ((?x386 ((_ sign_extend 48) in0_16)))
(let ((?x836 (bvmul ?x386 ?x878)))
(let ((?x1134 (bvashr ?x836 (_ bv15 64))))
(let ((?x1782 ((_ extract 15 0) ?x1134)))
(let (($x182 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1838 (and (distinct (bvmul ((_ sign_extend 64) ?x386) ((_ sign_extend 64) ?x878)) ((_ sign_extend 64) ?x836)) true)))
(let (($x91 (or false false)))
(let (($x2033 (or $x91 $x91 (or $x1838))))
(let (($x783 (or (or $x2033 false false) $x182)))
(let (($x536 (or $x783 false)))
(and (not $x536) (or $x536 (and (distinct ?x1782 ?x1782) true)))))))))))))))
(check-sat)
; query 114: function gsm_mult, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x91 (or false false)))
(let (($x449 (not $x91)))
(and $x449 (or $x91 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 115: function gsm_mult, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1137 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x91 (or false false)))
(let (($x1462 (or $x91 false false)))
(let (($x21 (not $x1462)))
(and $x21 (or $x1462 (and (distinct ?x1137 ?x1137) true))))))))
(check-sat)
; query 116: function gsm_mult_r, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x91 (or false false)))
(let (($x449 (not $x91)))
(and $x449 (or $x91 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 117: function gsm_mult_r, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1137 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x91 (or false false)))
(let (($x1462 (or $x91 false false)))
(let (($x21 (not $x1462)))
(and $x21 (or $x1462 (and (distinct ?x1137 ?x1137) true))))))))
(check-sat)
; query 118: function gsm_mult_r, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x91 (or false false)))
(let (($x449 (not $x91)))
(and $x449 (or $x91 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 119: function gsm_mult_r, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x91 (or false false)))
(let (($x449 (not $x91)))
(and $x449 (or $x91 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 120: function gsm_mult_r, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x878 ((_ sign_extend 48) in1_16)))
(let ((?x386 ((_ sign_extend 48) in0_16)))
(let ((?x836 (bvmul ?x386 ?x878)))
(let (($x1838 (and (distinct (bvmul ((_ sign_extend 64) ?x386) ((_ sign_extend 64) ?x878)) ((_ sign_extend 64) ?x836)) true)))
(let (($x91 (or false false)))
(let (($x2033 (or $x91 $x91 (or $x1838))))
(and (not $x2033) (or $x2033 (and (distinct ?x836 ?x836) true))))))))))
(check-sat)
; query 121: function gsm_mult_r, block 9, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x878 ((_ sign_extend 48) in1_16)))
(let ((?x386 ((_ sign_extend 48) in0_16)))
(let ((?x836 (bvmul ?x386 ?x878)))
(let ((?x911 (bvadd ?x836 (_ bv16384 64))))
(let (($x363 (and (distinct (bvadd ((_ sign_extend 1) ?x836) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x911)) true)))
(let (($x1838 (and (distinct (bvmul ((_ sign_extend 64) ?x386) ((_ sign_extend 64) ?x878)) ((_ sign_extend 64) ?x836)) true)))
(let (($x91 (or false false)))
(let (($x2033 (or $x91 $x91 (or $x1838))))
(let (($x1580 (or $x2033 false (or $x363))))
(and (not $x1580) (or $x1580 (and (distinct ?x911 ?x911) true)))))))))))))
(check-sat)
; query 122: function gsm_mult_r, block 9, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x878 ((_ sign_extend 48) in1_16)))
(let ((?x386 ((_ sign_extend 48) in0_16)))
(let ((?x836 (bvmul ?x386 ?x878)))
(let ((?x911 (bvadd ?x836 (_ bv16384 64))))
(let ((?x1442 (bvashr ?x911 (_ bv15 64))))
(let (($x182 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x363 (and (distinct (bvadd ((_ sign_extend 1) ?x836) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x911)) true)))
(let (($x1838 (and (distinct (bvmul ((_ sign_extend 64) ?x386) ((_ sign_extend 64) ?x878)) ((_ sign_extend 64) ?x836)) true)))
(let (($x91 (or false false)))
(let (($x2033 (or $x91 $x91 (or $x1838))))
(let (($x1580 (or $x2033 false (or $x363))))
(let (($x944 (or (or $x1580 false false) $x182)))
(and (not $x944) (or $x944 (and (distinct ?x1442 ?x1442) true))))))))))))))))
(check-sat)
; query 123: function gsm_mult_r, block 9, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x878 ((_ sign_extend 48) in1_16)))
(let ((?x386 ((_ sign_extend 48) in0_16)))
(let ((?x836 (bvmul ?x386 ?x878)))
(let ((?x911 (bvadd ?x836 (_ bv16384 64))))
(let ((?x1442 (bvashr ?x911 (_ bv15 64))))
(let ((?x1464 (bvand ?x1442 (_ bv65535 64))))
(let (($x182 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x363 (and (distinct (bvadd ((_ sign_extend 1) ?x836) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x911)) true)))
(let (($x1838 (and (distinct (bvmul ((_ sign_extend 64) ?x386) ((_ sign_extend 64) ?x878)) ((_ sign_extend 64) ?x836)) true)))
(let (($x91 (or false false)))
(let (($x2033 (or $x91 $x91 (or $x1838))))
(let (($x1580 (or $x2033 false (or $x363))))
(let (($x944 (or (or $x1580 false false) $x182)))
(let (($x255 (or $x944 false false)))
(and (not $x255) (or $x255 (and (distinct ?x1464 ?x1464) true))))))))))))))))))
(check-sat)
; query 124: function gsm_mult_r, block 9, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x878 ((_ sign_extend 48) in1_16)))
(let ((?x386 ((_ sign_extend 48) in0_16)))
(let ((?x836 (bvmul ?x386 ?x878)))
(let ((?x911 (bvadd ?x836 (_ bv16384 64))))
(let ((?x1442 (bvashr ?x911 (_ bv15 64))))
(let ((?x1464 (bvand ?x1442 (_ bv65535 64))))
(let ((?x1896 ((_ extract 15 0) ?x1464)))
(let (($x182 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x363 (and (distinct (bvadd ((_ sign_extend 1) ?x836) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x911)) true)))
(let (($x1838 (and (distinct (bvmul ((_ sign_extend 64) ?x386) ((_ sign_extend 64) ?x878)) ((_ sign_extend 64) ?x836)) true)))
(let (($x91 (or false false)))
(let (($x2033 (or $x91 $x91 (or $x1838))))
(let (($x1580 (or $x2033 false (or $x363))))
(let (($x944 (or (or $x1580 false false) $x182)))
(let (($x255 (or $x944 false false)))
(let (($x1603 (or $x255 false)))
(and (not $x1603) (or $x1603 (and (distinct ?x1896 ?x1896) true))))))))))))))))))))
(check-sat)
; query 125: function gsm_mult_r, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x91 (or false false)))
(let (($x449 (not $x91)))
(and $x449 (or $x91 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 126: function gsm_mult_r, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x2620 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x91 (or false false)))
(let (($x1462 (or $x91 false false)))
(let (($x21 (not $x1462)))
(and $x21 (or $x1462 (and (distinct ?x2620 ?x2620) true))))))))
(check-sat)
; query 127: function gsm_norm, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1532 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x172 (or false false false)))
(let (($x340 (not $x172)))
(and $x340 (or $x172 (and (distinct ?x1532 ?x1532) true)))))))
(check-sat)
; query 128: function gsm_norm, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1532 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x1197 (bvxor ?x1532 (_ bv1 1))))
(let (($x172 (or false false false)))
(let (($x508 (or $x172 false false)))
(let (($x39 (not $x508)))
(and $x39 (or $x508 (and (distinct ?x1197 ?x1197) true)))))))))
(check-sat)
; query 129: function gsm_norm, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1532 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x1197 (bvxor ?x1532 (_ bv1 1))))
(let ((?x757 ((_ zero_extend 31) ?x1197)))
(let (($x172 (or false false false)))
(let (($x508 (or $x172 false false)))
(let (($x473 (or $x508 false)))
(and (not $x473) (or $x473 (and (distinct ?x757 ?x757) true))))))))))
(check-sat)
; query 130: function gsm_norm, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1532 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x1197 (bvxor ?x1532 (_ bv1 1))))
(let ((?x757 ((_ zero_extend 31) ?x1197)))
(let ((?x1215 ((_ sign_extend 32) ?x757)))
(let (($x172 (or false false false)))
(let (($x508 (or $x172 false false)))
(let (($x473 (or $x508 false)))
(let (($x1456 (or $x473 false)))
(and (not $x1456) (or $x1456 (and (distinct ?x1215 ?x1215) true))))))))))))
(check-sat)
; query 131: function gsm_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_64 () (_ BitVec 64))
(assert
 (let ((?x1524 (ite (bvslt (_ bv32767 64) in5_64) (_ bv1 1) (_ bv0 1))))
(let (($x172 (or false false false)))
(let (($x340 (not $x172)))
(and $x340 (or $x172 (and (distinct ?x1524 ?x1524) true)))))))
(check-sat)
; query 132: function gsm_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x91 (or false false)))
(let (($x449 (not $x91)))
(and $x449 (or $x91 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 133: function gsm_sub, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x91 (or false false)))
(let (($x449 (not $x91)))
(and $x449 (or $x91 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 134: function gsm_sub, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x878 ((_ sign_extend 48) in1_16)))
(let ((?x386 ((_ sign_extend 48) in0_16)))
(let ((?x159 (bvsub ?x386 ?x878)))
(let (($x1113 (and (distinct (bvsub ((_ sign_extend 1) ?x386) ((_ sign_extend 1) ?x878)) ((_ sign_extend 1) ?x159)) true)))
(let (($x91 (or false false)))
(let (($x1140 (or $x91 $x91 (or $x1113))))
(and (not $x1140) (or $x1140 (and (distinct ?x159 ?x159) true))))))))))
(check-sat)
; query 135: function gsm_sub, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x2657 (ite (bvsgt (_ bv18446744073709518848 64) (bvsub ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x878 ((_ sign_extend 48) in1_16)))
(let ((?x1958 ((_ sign_extend 1) ?x878)))
(let ((?x386 ((_ sign_extend 48) in0_16)))
(let ((?x1025 ((_ sign_extend 1) ?x386)))
(let (($x91 (or false false)))
(let (($x1140 (or $x91 $x91 (or (and (distinct (bvsub ?x1025 ?x1958) ((_ sign_extend 1) (bvsub ?x386 ?x878))) true)))))
(let (($x1115 (or $x1140 false false)))
(and (not $x1115) (or $x1115 (and (distinct ?x2657 ?x2657) true))))))))))))
(check-sat)
; query 136: function ok_to_replace, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x866 (ite (and (distinct (_ bv4294967295 32) in.01_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x172 (or false false false)))
(let (($x340 (not $x172)))
(and $x340 (or $x172 (and (distinct ?x866 ?x866) true)))))))
(check-sat)
; query 137: function ok_to_replace, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in16_32 () (_ BitVec 32))
(assert
 (let ((?x1645 (ite (= (_ bv121 32) in16_32) (_ bv1 1) (_ bv0 1))))
(let (($x172 (or false false false)))
(let (($x340 (not $x172)))
(and $x340 (or $x172 (and (distinct ?x1645 ?x1645) true)))))))
(check-sat)
; query 138: function suffix, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_64 () (_ BitVec 64))
(declare-fun in3_64 () (_ BitVec 64))
(assert
 (let ((?x1006 (ite (bvule in3_64 in4_64) (_ bv1 1) (_ bv0 1))))
(let (($x172 (or false false false)))
(let (($x340 (not $x172)))
(and $x340 (or $x172 (and (distinct ?x1006 ?x1006) true)))))))
(check-sat)
; query 139: function ulaw_input, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x153 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x128 (or false false (or $x153))))
(and (not $x128) (or $x128 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 140: function ulaw_input, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let ((?x71 (ite (= (_ bv4294967295 32) in.1_32) (_ bv1 1) (_ bv0 1))))
(let (($x172 (or false false false)))
(let (($x340 (not $x172)))
(and $x340 (or $x172 (and (distinct ?x71 ?x71) true)))))))
(check-sat)
