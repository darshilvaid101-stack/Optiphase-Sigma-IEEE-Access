; OptiPhase-Sigma refinement certificate for sweep K33-R4-323
; query 0: function edge_draw, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let ((?x609 (ite (= (_ bv0 32) in4_32) (_ bv1 1) (_ bv0 1))))
(let (($x109 (or false false false)))
(and (not $x109) (or $x109 (and (distinct ?x609 ?x609) true))))))
(check-sat)
