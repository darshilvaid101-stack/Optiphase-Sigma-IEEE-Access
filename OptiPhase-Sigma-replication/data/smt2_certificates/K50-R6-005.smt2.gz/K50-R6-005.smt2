; OptiPhase-Sigma refinement certificate for sweep K50-R6-005
; query 0: function check, block 67, name %68
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x105 (ite (= (_ bv5 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x115 (or false false false)))
(let (($x538 (not $x115)))
(and $x538 (or $x115 (and (distinct (ite (= (_ bv1 32) in0_32) (_ bv1 1) (_ bv0 1)) ?x105) true)))))))
(check-sat)
; query 1: function check, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x2781 (ite (= (_ bv11 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x115 (or false false false)))
(let (($x538 (not $x115)))
(and $x538 (or $x115 (and (distinct (ite (= (_ bv2 32) in0_32) (_ bv1 1) (_ bv0 1)) ?x2781) true)))))))
(check-sat)
; query 2: function check, block 79, name %80
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x37 (and (distinct (ite (= (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1)) (ite (= (_ bv22 32) in0_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x115 (or false false false)))
(let (($x538 (not $x115)))
(and $x538 (or $x115 $x37))))))
(check-sat)
; query 3: function check, block 85, name %86
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x44 (and (distinct (ite (= (_ bv4 32) in0_32) (_ bv1 1) (_ bv0 1)) (ite (= (_ bv33 32) in0_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x115 (or false false false)))
(let (($x538 (not $x115)))
(and $x538 (or $x115 $x44))))))
(check-sat)
; query 4: function check, block 91, name %92
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x105 (ite (= (_ bv5 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x115 (or false false false)))
(let (($x538 (not $x115)))
(and $x538 (or $x115 (and (distinct ?x105 (ite (= (_ bv0 32) in0_32) (_ bv1 1) (_ bv0 1))) true)))))))
(check-sat)
; query 5: function check, block 97, name %98
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x2781 (ite (= (_ bv11 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x115 (or false false false)))
(let (($x538 (not $x115)))
(and $x538 (or $x115 (and (distinct ?x2781 (ite (= (_ bv12 32) in0_32) (_ bv1 1) (_ bv0 1))) true)))))))
(check-sat)
; query 6: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x1734 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x115 (or false false false)))
(let (($x538 (not $x115)))
(and $x538 (or $x115 (and (distinct ?x1734 ?x1734) true)))))))
(check-sat)
; query 7: function set1d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x54 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x115 (or false false false)))
(let (($x538 (not $x115)))
(and $x538 (or $x115 (and (distinct ?x54 ?x54) true)))))))
(check-sat)
; query 8: function set1ds, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x91 (ite (= (_ bv4294967295 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x115 (or false false false)))
(let (($x538 (not $x115)))
(and $x538 (or $x115 (and (distinct ?x91 ?x91) true)))))))
(check-sat)
; query 9: function set2d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x54 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x115 (or false false false)))
(let (($x538 (not $x115)))
(and $x538 (or $x115 (and (distinct ?x54 ?x54) true)))))))
(check-sat)
