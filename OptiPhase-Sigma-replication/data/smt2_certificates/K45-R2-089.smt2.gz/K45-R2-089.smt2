; OptiPhase-Sigma refinement certificate for sweep K45-R2-089
; query 0: function Index_to_frequency, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x172 (ite (bvuge in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x848 (or false false false)))
(let (($x49 (not $x848)))
(and $x49 (or $x848 (and (distinct ?x172 ?x172) true)))))))
(check-sat)
; query 1: function IsPowerOfTwo, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x848 (or false false false)))
(let (($x49 (not $x848)))
(and $x49 (or $x848 (and (distinct (bvsub in0_32 (_ bv1 32)) (bvsub in0_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function IsPowerOfTwo, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x364 (bvsub in0_32 (_ bv1 32))))
(let ((?x33 (bvand in0_32 ?x364)))
(let (($x848 (or false false false)))
(let (($x71 (or false $x848 false)))
(and (not $x71) (or $x71 (and (distinct ?x33 ?x33) true))))))))
(check-sat)
; query 3: function IsPowerOfTwo, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x365 (ite (and (distinct (_ bv0 32) (bvand in0_32 (bvsub in0_32 (_ bv1 32)))) true) (_ bv1 1) (_ bv0 1))))
(let (($x848 (or false false false)))
(let (($x71 (or false $x848 false)))
(let (($x296 (or $x71 false false)))
(and (not $x296) (or $x296 (and (distinct ?x365 ?x365) true))))))))
(check-sat)
; query 4: function IsPowerOfTwo, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x308 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x848 (or false false false)))
(let (($x49 (not $x848)))
(and $x49 (or $x848 (and (distinct ?x308 ?x308) true)))))))
(check-sat)
; query 5: function NumberOfBitsNeeded, block 13, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x848 (or false false false)))
(let (($x49 (not $x848)))
(and $x49 (or $x848 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 6: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x308 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x848 (or false false false)))
(let (($x49 (not $x848)))
(and $x49 (or $x848 (and (distinct ?x308 ?x308) true)))))))
(check-sat)
; query 7: function ReverseBits, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x848 (or false false false)))
(let (($x49 (not $x848)))
(and $x49 (or $x848 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function ReverseBits, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x848 (or false false false)))
(let (($x153 (or $x848 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x594 (not $x153)))
(and $x594 (or $x153 (and (distinct (bvshl in.01_32 (_ bv1 32)) (bvshl in.01_32 (_ bv1 32))) true)))))))
(check-sat)
; query 9: function ReverseBits, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x848 (or false false false)))
(let (($x49 (not $x848)))
(and $x49 (or $x848 (and (distinct (bvand in.0_32 (_ bv1 32)) (bvand in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 10: function ReverseBits, block 5, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1059 (bvand in.0_32 (_ bv1 32))))
(let ((?x484 (bvshl in.01_32 (_ bv1 32))))
(let ((?x531 (bvor ?x484 ?x1059)))
(let (($x848 (or false false false)))
(let (($x153 (or $x848 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x831 (or $x153 $x848 false)))
(and (not $x831) (or $x831 (and (distinct ?x531 ?x531) true))))))))))
(check-sat)
; query 11: function ReverseBits, block 5, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x848 (or false false false)))
(let (($x153 (or $x848 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x594 (not $x153)))
(and $x594 (or $x153 (and (distinct (bvlshr in.0_32 (_ bv1 32)) (bvlshr in.0_32 (_ bv1 32))) true)))))))
(check-sat)
; query 12: function fft_float, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x66 (ite (and (distinct (_ bv0 32) in1_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x848 (or false false false)))
(let (($x49 (not $x848)))
(and $x49 (or $x848 (and (distinct ?x66 ?x66) true)))))))
(check-sat)
; query 13: function fft_float, block 152, name %153
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let (($x848 (or false false false)))
(let (($x49 (not $x848)))
(and $x49 (or $x848 (and (distinct (bvadd in.04_32 (_ bv1 32)) (bvadd in.04_32 (_ bv1 32))) true))))))
(check-sat)
; query 14: function fft_float, block 152, name %154
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_32 () (_ BitVec 32))
(assert
 (let (($x848 (or false false false)))
(let (($x49 (not $x848)))
(and $x49 (or $x848 (and (distinct (bvadd in.03_32 (_ bv1 32)) (bvadd in.03_32 (_ bv1 32))) true))))))
(check-sat)
; query 15: function fft_float, block 156, name %157
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x848 (or false false false)))
(let (($x51 (or $x848 (and (distinct (bvadd in.1_32 in.02_32) (bvadd in.1_32 in.02_32)) true))))
(let (($x49 (not $x848)))
(and $x49 $x51)))))
(check-sat)
; query 16: function fft_float, block 159, name %160
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x848 (or false false false)))
(let (($x153 (or $x848 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x594 (not $x153)))
(and $x594 (or $x153 (and (distinct (bvshl in.02_32 (_ bv1 32)) (bvshl in.02_32 (_ bv1 32))) true)))))))
(check-sat)
; query 17: function fft_float, block 161, name %162
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x66 (ite (and (distinct (_ bv0 32) in1_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x848 (or false false false)))
(let (($x49 (not $x848)))
(and $x49 (or $x848 (and (distinct ?x66 ?x66) true)))))))
(check-sat)
; query 18: function fft_float, block 180, name %181
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let (($x848 (or false false false)))
(let (($x49 (not $x848)))
(and $x49 (or $x848 (and (distinct (bvadd in.2_32 (_ bv1 32)) (bvadd in.2_32 (_ bv1 32))) true))))))
(check-sat)
; query 19: function fft_float, block 41, name %42
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.05_32 () (_ BitVec 32))
(assert
 (let (($x848 (or false false false)))
(let (($x49 (not $x848)))
(and $x49 (or $x848 (and (distinct (bvadd in.05_32 (_ bv1 32)) (bvadd in.05_32 (_ bv1 32))) true))))))
(check-sat)
; query 20: function main, block 110, name %111
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x848 (or false false false)))
(let (($x49 (not $x848)))
(and $x49 (or $x848 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 21: function main, block 113, name %114
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x848 (or false false false)))
(let (($x49 (not $x848)))
(and $x49 (or $x848 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 22: function main, block 126, name %127
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let (($x848 (or false false false)))
(let (($x49 (not $x848)))
(and $x49 (or $x848 (and (distinct (bvadd in.2_32 (_ bv1 32)) (bvadd in.2_32 (_ bv1 32))) true))))))
(check-sat)
; query 23: function main, block 139, name %140
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.3_32 () (_ BitVec 32))
(assert
 (let (($x848 (or false false false)))
(let (($x49 (not $x848)))
(and $x49 (or $x848 (and (distinct (bvadd in.3_32 (_ bv1 32)) (bvadd in.3_32 (_ bv1 32))) true))))))
(check-sat)
; query 24: function main, block 57, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x848 (or false false false)))
(let (($x49 (not $x848)))
(and $x49 (or $x848 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 25: function main, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x32 (ite (= (_ bv4 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x848 (or false false false)))
(let (($x49 (not $x848)))
(and $x49 (or $x848 (and (distinct ?x32 ?x32) true)))))))
(check-sat)
; query 26: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x18 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x848 (or false false false)))
(let (($x49 (not $x848)))
(and $x49 (or $x848 (and (distinct ?x18 ?x18) true)))))))
(check-sat)
