; OptiPhase-Sigma refinement certificate for sweep K57-R2-079
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x662 (or false false)))
(let (($x608 (not $x662)))
(and $x608 (or $x662 (and (distinct ((_ sign_extend 16) in25_16) ((_ sign_extend 16) in25_16)) true))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let ((?x864 (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))))
(let (($x662 (or false false)))
(let (($x51 (or $x662 false false)))
(let (($x27 (not $x51)))
(and $x27 (or $x51 (and (distinct ?x864 ?x864) true))))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x662 (or false false)))
(let (($x608 (not $x662)))
(and $x608 (or $x662 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x34 ((_ sign_extend 16) in3_16)))
(let ((?x443 (bvand ?x34 (_ bv127 32))))
(let (($x662 (or false false)))
(let (($x51 (or $x662 false false)))
(let (($x27 (not $x51)))
(and $x27 (or $x51 (and (distinct ?x443 ?x443) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x34 ((_ sign_extend 16) in3_16)))
(let ((?x443 (bvand ?x34 (_ bv127 32))))
(let ((?x114 ((_ extract 15 0) ?x443)))
(let (($x662 (or false false)))
(let (($x51 (or $x662 false false)))
(let (($x1199 (or $x51 false)))
(let (($x1125 (not $x1199)))
(and $x1125 (or $x1199 (and (distinct ?x114 ?x114) true)))))))))))
(check-sat)
; query 5: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x662 (or false false)))
(let (($x608 (not $x662)))
(and $x608 (or $x662 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 6: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x81 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x662 (or false false)))
(let (($x51 (or $x662 false false)))
(let (($x27 (not $x51)))
(and $x27 (or $x51 (and (distinct ?x81 ?x81) true))))))))
(check-sat)
; query 7: function core_bench_list, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x318 (or false false false)))
(let (($x478 (not $x318)))
(and $x478 (or $x318 (and (distinct (bvadd in.0_16 (_ bv1 16)) (bvadd in.0_16 (_ bv1 16))) true))))))
(check-sat)
; query 8: function core_bench_state, block 105, name %106
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x318 (or false false false)))
(let (($x478 (not $x318)))
(and $x478 (or $x318 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 9: function core_bench_state, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x318 (or false false false)))
(let (($x478 (not $x318)))
(and $x478 (or $x318 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 10: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x164 (bvadd in.01_32 (_ bv1 32))))
(let (($x361 (and (distinct ?x164 ?x164) true)))
(let (($x318 (or false false false)))
(let (($x478 (not $x318)))
(and $x478 (or $x318 $x361)))))))
(check-sat)
; query 11: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x164 (bvadd in.01_32 (_ bv1 32))))
(let ((?x538 (bvmul ?x164 ?x164)))
(let (($x318 (or false false false)))
(let (($x16 (or $x318 $x318 false)))
(and (not $x16) (or $x16 (and (distinct ?x538 ?x538) true))))))))
(check-sat)
; query 12: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x164 (bvadd in.01_32 (_ bv1 32))))
(let ((?x538 (bvmul ?x164 ?x164)))
(let ((?x86 (bvmul ?x538 (_ bv2 32))))
(let (($x318 (or false false false)))
(let (($x16 (or $x318 $x318 false)))
(let (($x710 (or $x16 false false)))
(and (not $x710) (or $x710 (and (distinct ?x86 ?x86) true))))))))))
(check-sat)
; query 13: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x164 (bvadd in.01_32 (_ bv1 32))))
(let ((?x538 (bvmul ?x164 ?x164)))
(let ((?x86 (bvmul ?x538 (_ bv2 32))))
(let ((?x1111 (bvmul ?x86 (_ bv4 32))))
(let (($x318 (or false false false)))
(let (($x16 (or $x318 $x318 false)))
(let (($x710 (or $x16 false false)))
(let (($x1034 (or $x710 false false)))
(and (not $x1034) (or $x1034 (and (distinct ?x1111 ?x1111) true))))))))))))
(check-sat)
; query 14: function core_init_matrix, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x318 (or false false false)))
(let (($x478 (not $x318)))
(and $x478 (or $x318 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 15: function core_init_matrix, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x318 (or false false false)))
(let (($x478 (not $x318)))
(and $x478 (or $x318 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 16: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x1652 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x318 (or false false false)))
(let (($x478 (not $x318)))
(and $x478 (or $x318 (and (distinct ?x1652 ?x1652) true)))))))
(check-sat)
; query 17: function core_init_state, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_32 () (_ BitVec 32))
(assert
 (let (($x318 (or false false false)))
(let (($x478 (not $x318)))
(and $x478 (or $x318 (and (distinct (bvadd in.06_32 (_ bv1 32)) (bvadd in.06_32 (_ bv1 32))) true))))))
(check-sat)
; query 18: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x275 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x318 (or false false false)))
(let (($x478 (not $x318)))
(and $x478 (or $x318 (and (distinct ?x275 ?x275) true)))))))
(check-sat)
; query 19: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x318 (or false false false)))
(let (($x478 (not $x318)))
(and $x478 (or $x318 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 20: function core_list_init, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x164 (bvadd in.01_32 (_ bv1 32))))
(let (($x361 (and (distinct ?x164 ?x164) true)))
(let (($x318 (or false false false)))
(let (($x478 (not $x318)))
(and $x478 (or $x318 $x361)))))))
(check-sat)
; query 21: function core_list_mergesort, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x164 (bvadd in.01_32 (_ bv1 32))))
(let (($x361 (and (distinct ?x164 ?x164) true)))
(let (($x298 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x164)) true)))
(let (($x347 (or false false (or $x298))))
(and (not $x347) (or $x347 $x361)))))))
(check-sat)
; query 22: function core_list_mergesort, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x294 (ite (bvslt (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x318 (or false false false)))
(let (($x478 (not $x318)))
(and $x478 (or $x318 (and (distinct ?x294 ?x294) true)))))))
(check-sat)
; query 23: function core_list_mergesort, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.224_32 () (_ BitVec 32))
(assert
 (let ((?x74 (ite (= (_ bv0 32) in.224_32) (_ bv1 1) (_ bv0 1))))
(let (($x318 (or false false false)))
(let (($x478 (not $x318)))
(and $x478 (or $x318 (and (distinct ?x74 ?x74) true)))))))
(check-sat)
; query 24: function core_list_mergesort, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x53 (ite (= (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x318 (or false false false)))
(let (($x478 (not $x318)))
(and $x478 (or $x318 (and (distinct ?x53 ?x53) true)))))))
(check-sat)
; query 25: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x739 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x406 (or false false (or $x739))))
(and (not $x406) (or $x406 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 26: function core_list_mergesort, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x1431 (and (distinct (bvmul ((_ sign_extend 32) in.020_32) ((_ sign_extend 32) (_ bv2 32))) ((_ sign_extend 32) (bvmul in.020_32 (_ bv2 32)))) true)))
(let (($x431 (or false false (or $x1431))))
(and (not $x431) (or $x431 (and (distinct (bvmul in.020_32 (_ bv2 32)) (bvmul in.020_32 (_ bv2 32))) true))))))
(check-sat)
; query 27: function core_state_transition, block 102, name %103
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x662 (or false false)))
(let (($x608 (not $x662)))
(and $x608 (or $x662 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 28: function core_state_transition, block 102, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x444 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x662 (or false false)))
(let (($x51 (or $x662 false false)))
(let (($x27 (not $x51)))
(and $x27 (or $x51 (and (distinct ?x444 ?x444) true))))))))
(check-sat)
; query 29: function core_state_transition, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x662 (or false false)))
(let (($x608 (not $x662)))
(and $x608 (or $x662 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 30: function core_state_transition, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x66 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x662 (or false false)))
(let (($x51 (or $x662 false false)))
(let (($x27 (not $x51)))
(and $x27 (or $x51 (and (distinct ?x66 ?x66) true))))))))
(check-sat)
; query 31: function core_state_transition, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x662 (or false false)))
(let (($x608 (not $x662)))
(and $x608 (or $x662 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 32: function core_state_transition, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x444 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x662 (or false false)))
(let (($x51 (or $x662 false false)))
(let (($x27 (not $x51)))
(and $x27 (or $x51 (and (distinct ?x444 ?x444) true))))))))
(check-sat)
; query 33: function core_state_transition, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x662 (or false false)))
(let (($x608 (not $x662)))
(and $x608 (or $x662 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 34: function core_state_transition, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x280 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x662 (or false false)))
(let (($x51 (or $x662 false false)))
(let (($x27 (not $x51)))
(and $x27 (or $x51 (and (distinct ?x280 ?x280) true))))))))
(check-sat)
; query 35: function core_state_transition, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x662 (or false false)))
(let (($x608 (not $x662)))
(and $x608 (or $x662 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 36: function core_state_transition, block 51, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x280 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x662 (or false false)))
(let (($x51 (or $x662 false false)))
(let (($x27 (not $x51)))
(and $x27 (or $x51 (and (distinct ?x280 ?x280) true))))))))
(check-sat)
; query 37: function core_state_transition, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x662 (or false false)))
(let (($x608 (not $x662)))
(and $x608 (or $x662 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 38: function core_state_transition, block 64, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x280 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x662 (or false false)))
(let (($x51 (or $x662 false false)))
(let (($x27 (not $x51)))
(and $x27 (or $x51 (and (distinct ?x280 ?x280) true))))))))
(check-sat)
; query 39: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x286 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x318 (or false false false)))
(let (($x478 (not $x318)))
(and $x478 (or $x318 (and (distinct ?x286 ?x286) true)))))))
(check-sat)
; query 40: function core_state_transition, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x662 (or false false)))
(let (($x608 (not $x662)))
(and $x608 (or $x662 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 41: function core_state_transition, block 80, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x149 (ite (= (_ bv69 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x662 (or false false)))
(let (($x51 (or $x662 false false)))
(let (($x27 (not $x51)))
(and $x27 (or $x51 (and (distinct ?x149 ?x149) true))))))))
(check-sat)
; query 42: function core_state_transition, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x662 (or false false)))
(let (($x608 (not $x662)))
(and $x608 (or $x662 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 43: function core_state_transition, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1151 (ite (= (_ bv101 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x662 (or false false)))
(let (($x51 (or $x662 false false)))
(let (($x27 (not $x51)))
(and $x27 (or $x51 (and (distinct ?x1151 ?x1151) true))))))))
(check-sat)
; query 44: function core_state_transition, block 99, name %100
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x662 (or false false)))
(let (($x608 (not $x662)))
(and $x608 (or $x662 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 45: function core_state_transition, block 99, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x66 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x662 (or false false)))
(let (($x51 (or $x662 false false)))
(let (($x27 (not $x51)))
(and $x27 (or $x51 (and (distinct ?x66 ?x66) true))))))))
(check-sat)
; query 46: function crcu8, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x662 (or false false)))
(let (($x608 (not $x662)))
(and $x608 (or $x662 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 47: function crcu8, block 19, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x628 ((_ zero_extend 16) in.01_16)))
(let ((?x404 (bvxor ?x628 (_ bv16386 32))))
(let (($x662 (or false false)))
(let (($x51 (or $x662 false false)))
(let (($x27 (not $x51)))
(and $x27 (or $x51 (and (distinct ?x404 ?x404) true)))))))))
(check-sat)
; query 48: function crcu8, block 19, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x628 ((_ zero_extend 16) in.01_16)))
(let ((?x404 (bvxor ?x628 (_ bv16386 32))))
(let ((?x304 ((_ extract 15 0) ?x404)))
(let (($x662 (or false false)))
(let (($x51 (or $x662 false false)))
(let (($x1199 (or $x51 false)))
(let (($x1125 (not $x1199)))
(and $x1125 (or $x1199 (and (distinct ?x304 ?x304) true)))))))))))
(check-sat)
; query 49: function crcu8, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x662 (or false false)))
(let (($x608 (not $x662)))
(and $x608 (or $x662 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 50: function crcu8, block 29, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1193 ((_ zero_extend 16) in27_16)))
(let ((?x1222 (bvor ?x1193 (_ bv32768 32))))
(let (($x662 (or false false)))
(let (($x51 (or $x662 false false)))
(let (($x27 (not $x51)))
(and $x27 (or $x51 (and (distinct ?x1222 ?x1222) true)))))))))
(check-sat)
; query 51: function crcu8, block 29, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1193 ((_ zero_extend 16) in27_16)))
(let ((?x1222 (bvor ?x1193 (_ bv32768 32))))
(let ((?x1185 ((_ extract 15 0) ?x1222)))
(let (($x662 (or false false)))
(let (($x51 (or $x662 false false)))
(let (($x1199 (or $x51 false)))
(let (($x1125 (not $x1199)))
(and $x1125 (or $x1199 (and (distinct ?x1185 ?x1185) true)))))))))))
(check-sat)
; query 52: function crcu8, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x662 (or false false)))
(let (($x608 (not $x662)))
(and $x608 (or $x662 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 53: function crcu8, block 33, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1193 ((_ zero_extend 16) in27_16)))
(let ((?x1134 (bvand ?x1193 (_ bv32767 32))))
(let (($x662 (or false false)))
(let (($x51 (or $x662 false false)))
(let (($x27 (not $x51)))
(and $x27 (or $x51 (and (distinct ?x1134 ?x1134) true)))))))))
(check-sat)
; query 54: function crcu8, block 33, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1193 ((_ zero_extend 16) in27_16)))
(let ((?x1134 (bvand ?x1193 (_ bv32767 32))))
(let ((?x1537 ((_ extract 15 0) ?x1134)))
(let (($x662 (or false false)))
(let (($x51 (or $x662 false false)))
(let (($x1199 (or $x51 false)))
(let (($x1125 (not $x1199)))
(and $x1125 (or $x1199 (and (distinct ?x1537 ?x1537) true)))))))))))
(check-sat)
; query 55: function crcu8, block 38, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_8 () (_ BitVec 8))
(assert
 (let (($x318 (or false false false)))
(let (($x478 (not $x318)))
(and $x478 (or $x318 (and (distinct (bvadd in.02_8 (_ bv1 8)) (bvadd in.02_8 (_ bv1 8))) true))))))
(check-sat)
; query 56: function crcu8, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x1003 ((_ extract 7 0) in.01_16)))
(let ((?x1267 ((_ zero_extend 24) ?x1003)))
(let (($x662 (or false false)))
(let (($x787 (or $x662 false)))
(and (not $x787) (or $x787 (and (distinct ?x1267 ?x1267) true))))))))
(check-sat)
; query 57: function crcu8, block 6, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x1003 ((_ extract 7 0) in.01_16)))
(let ((?x1267 ((_ zero_extend 24) ?x1003)))
(let ((?x1067 (bvand ?x1267 (_ bv1 32))))
(let (($x662 (or false false)))
(let (($x787 (or $x662 false)))
(let (($x1169 (or $x787 false false)))
(and (not $x1169) (or $x1169 (and (distinct ?x1067 ?x1067) true))))))))))
(check-sat)
; query 58: function crcu8, block 6, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1003 ((_ extract 7 0) in.01_16)))
(let ((?x1267 ((_ zero_extend 24) ?x1003)))
(let ((?x1067 (bvand ?x1267 (_ bv1 32))))
(let ((?x1342 ((_ zero_extend 24) in.0_8)))
(let ((?x781 (bvand ?x1342 (_ bv1 32))))
(let ((?x1186 (bvxor ?x781 ?x1067)))
(let (($x662 (or false false)))
(let (($x787 (or $x662 false)))
(let (($x1169 (or $x787 false false)))
(let (($x51 (or $x662 false false)))
(let (($x1182 (or $x51 $x1169 false)))
(and (not $x1182) (or $x1182 (and (distinct ?x1186 ?x1186) true)))))))))))))))
(check-sat)
; query 59: function crcu8, block 6, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1003 ((_ extract 7 0) in.01_16)))
(let ((?x1267 ((_ zero_extend 24) ?x1003)))
(let ((?x1067 (bvand ?x1267 (_ bv1 32))))
(let ((?x1342 ((_ zero_extend 24) in.0_8)))
(let ((?x781 (bvand ?x1342 (_ bv1 32))))
(let ((?x1186 (bvxor ?x781 ?x1067)))
(let ((?x1507 ((_ extract 7 0) ?x1186)))
(let (($x662 (or false false)))
(let (($x787 (or $x662 false)))
(let (($x1169 (or $x787 false false)))
(let (($x51 (or $x662 false false)))
(let (($x1182 (or $x51 $x1169 false)))
(let (($x484 (or $x1182 false)))
(and (not $x484) (or $x484 (and (distinct ?x1507 ?x1507) true)))))))))))))))))
(check-sat)
; query 60: function crcu8, block 6, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x662 (or false false)))
(let (($x608 (not $x662)))
(and $x608 (or $x662 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 61: function crcu8, block 6, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1342 ((_ zero_extend 24) in.0_8)))
(let ((?x372 (bvashr ?x1342 (_ bv1 32))))
(let (($x662 (or false false)))
(let (($x51 (or $x662 false false)))
(let (($x516 (or $x51 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not $x516) (or $x516 (and (distinct ?x372 ?x372) true)))))))))
(check-sat)
; query 62: function crcu8, block 6, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1342 ((_ zero_extend 24) in.0_8)))
(let ((?x372 (bvashr ?x1342 (_ bv1 32))))
(let ((?x197 ((_ extract 7 0) ?x372)))
(let (($x662 (or false false)))
(let (($x51 (or $x662 false false)))
(let (($x516 (or $x51 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x25 (or $x516 false)))
(and (not $x25) (or $x25 (and (distinct ?x197 ?x197) true)))))))))))
(check-sat)
; query 63: function crcu8, block 6, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1003 ((_ extract 7 0) in.01_16)))
(let ((?x1267 ((_ zero_extend 24) ?x1003)))
(let ((?x1067 (bvand ?x1267 (_ bv1 32))))
(let ((?x1342 ((_ zero_extend 24) in.0_8)))
(let ((?x781 (bvand ?x1342 (_ bv1 32))))
(let ((?x1186 (bvxor ?x781 ?x1067)))
(let ((?x1507 ((_ extract 7 0) ?x1186)))
(let ((?x121 ((_ zero_extend 24) ?x1507)))
(let (($x662 (or false false)))
(let (($x787 (or $x662 false)))
(let (($x1169 (or $x787 false false)))
(let (($x51 (or $x662 false false)))
(let (($x1182 (or $x51 $x1169 false)))
(let (($x484 (or $x1182 false)))
(let (($x1478 (or $x484 false)))
(and (not $x1478) (or $x1478 (and (distinct ?x121 ?x121) true)))))))))))))))))))
(check-sat)
; query 64: function crcu8, block 6, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1003 ((_ extract 7 0) in.01_16)))
(let ((?x1267 ((_ zero_extend 24) ?x1003)))
(let ((?x1067 (bvand ?x1267 (_ bv1 32))))
(let ((?x1342 ((_ zero_extend 24) in.0_8)))
(let ((?x781 (bvand ?x1342 (_ bv1 32))))
(let ((?x1186 (bvxor ?x781 ?x1067)))
(let ((?x1507 ((_ extract 7 0) ?x1186)))
(let ((?x121 ((_ zero_extend 24) ?x1507)))
(let ((?x848 (ite (= (_ bv1 32) ?x121) (_ bv1 1) (_ bv0 1))))
(let (($x662 (or false false)))
(let (($x787 (or $x662 false)))
(let (($x1169 (or $x787 false false)))
(let (($x51 (or $x662 false false)))
(let (($x1182 (or $x51 $x1169 false)))
(let (($x484 (or $x1182 false)))
(let (($x1478 (or $x484 false)))
(let (($x815 (or $x1478 false false)))
(and (not $x815) (or $x815 (and (distinct ?x848 ?x848) true)))))))))))))))))))))
(check-sat)
; query 65: function crcu8, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x662 (or false false)))
(let (($x608 (not $x662)))
(and $x608 (or $x662 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 66: function crcu8, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1342 ((_ zero_extend 24) in.0_8)))
(let ((?x781 (bvand ?x1342 (_ bv1 32))))
(let (($x662 (or false false)))
(let (($x51 (or $x662 false false)))
(let (($x27 (not $x51)))
(and $x27 (or $x51 (and (distinct ?x781 ?x781) true)))))))))
(check-sat)
; query 67: function crcu8, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x662 (or false false)))
(let (($x608 (not $x662)))
(and $x608 (or $x662 (and (distinct ((_ extract 7 0) in.01_16) ((_ extract 7 0) in.01_16)) true))))))
(check-sat)
; query 68: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1423 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1261 ((_ zero_extend 31) ?x1423)))
(let ((?x2490 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2501 ((_ zero_extend 31) ?x2490)))
(let ((?x1294 (bvand ?x2501 ?x1261)))
(let ((?x2506 (ite (and (distinct (_ bv0 32) ?x1294) true) (_ bv1 1) (_ bv0 1))))
(let ((?x2491 ((_ zero_extend 63) ?x2506)))
(let (($x662 (or false false)))
(let (($x51 (or $x662 false false)))
(let (($x1199 (or $x51 false)))
(let (($x1340 (or $x1199 $x1199 false)))
(let (($x2505 (or $x1340 false false)))
(let (($x2504 (or $x2505 false)))
(and (not $x2504) (or $x2504 (and (distinct ?x2491 ?x2491) true)))))))))))))))))
(check-sat)
; query 69: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1423 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1261 ((_ zero_extend 31) ?x1423)))
(let ((?x2490 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2501 ((_ zero_extend 31) ?x2490)))
(let ((?x1294 (bvand ?x2501 ?x1261)))
(let ((?x2506 (ite (and (distinct (_ bv0 32) ?x1294) true) (_ bv1 1) (_ bv0 1))))
(let (($x2530 (= (_ bv1 1) ?x2506)))
(let ((?x2522 (ite $x2530 (_ bv1 32) (_ bv0 32))))
(let (($x662 (or false false)))
(let (($x51 (or $x662 false false)))
(let (($x1199 (or $x51 false)))
(let (($x1340 (or $x1199 $x1199 false)))
(let (($x2505 (or $x1340 false false)))
(let (($x2712 (or $x2505 (ite $x2530 false false))))
(and (not $x2712) (or $x2712 (and (distinct ?x2522 ?x2522) true))))))))))))))))))
(check-sat)
; query 70: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1423 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1261 ((_ zero_extend 31) ?x1423)))
(let ((?x2490 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2501 ((_ zero_extend 31) ?x2490)))
(let ((?x1294 (bvand ?x2501 ?x1261)))
(let ((?x2506 (ite (and (distinct (_ bv0 32) ?x1294) true) (_ bv1 1) (_ bv0 1))))
(let (($x2530 (= (_ bv1 1) ?x2506)))
(let ((?x2522 (ite $x2530 (_ bv1 32) (_ bv0 32))))
(let ((?x2713 ((_ extract 7 0) ?x2522)))
(let (($x662 (or false false)))
(let (($x51 (or $x662 false false)))
(let (($x1199 (or $x51 false)))
(let (($x1340 (or $x1199 $x1199 false)))
(let (($x2505 (or $x1340 false false)))
(let (($x2712 (or $x2505 (ite $x2530 false false))))
(let (($x2517 (or $x2712 false)))
(and (not $x2517) (or $x2517 (and (distinct ?x2713 ?x2713) true))))))))))))))))))))
(check-sat)
; query 71: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x662 (or false false)))
(let (($x608 (not $x662)))
(and $x608 (or $x662 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 72: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x2490 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x662 (or false false)))
(let (($x51 (or $x662 false false)))
(let (($x27 (not $x51)))
(and $x27 (or $x51 (and (distinct ?x2490 ?x2490) true))))))))
(check-sat)
; query 73: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x2490 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2501 ((_ zero_extend 31) ?x2490)))
(let (($x662 (or false false)))
(let (($x51 (or $x662 false false)))
(let (($x1199 (or $x51 false)))
(let (($x1125 (not $x1199)))
(and $x1125 (or $x1199 (and (distinct ?x2501 ?x2501) true))))))))))
(check-sat)
; query 74: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x662 (or false false)))
(let (($x608 (not $x662)))
(and $x608 (or $x662 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 75: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1423 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x662 (or false false)))
(let (($x51 (or $x662 false false)))
(let (($x27 (not $x51)))
(and $x27 (or $x51 (and (distinct ?x1423 ?x1423) true))))))))
(check-sat)
; query 76: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1423 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1261 ((_ zero_extend 31) ?x1423)))
(let (($x662 (or false false)))
(let (($x51 (or $x662 false false)))
(let (($x1199 (or $x51 false)))
(let (($x1125 (not $x1199)))
(and $x1125 (or $x1199 (and (distinct ?x1261 ?x1261) true))))))))))
(check-sat)
; query 77: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1423 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1261 ((_ zero_extend 31) ?x1423)))
(let ((?x2490 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2501 ((_ zero_extend 31) ?x2490)))
(let ((?x1294 (bvand ?x2501 ?x1261)))
(let (($x662 (or false false)))
(let (($x51 (or $x662 false false)))
(let (($x1199 (or $x51 false)))
(let (($x1340 (or $x1199 $x1199 false)))
(and (not $x1340) (or $x1340 (and (distinct ?x1294 ?x1294) true)))))))))))))
(check-sat)
; query 78: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1423 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1261 ((_ zero_extend 31) ?x1423)))
(let ((?x2490 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2501 ((_ zero_extend 31) ?x2490)))
(let ((?x1294 (bvand ?x2501 ?x1261)))
(let ((?x2506 (ite (and (distinct (_ bv0 32) ?x1294) true) (_ bv1 1) (_ bv0 1))))
(let (($x662 (or false false)))
(let (($x51 (or $x662 false false)))
(let (($x1199 (or $x51 false)))
(let (($x1340 (or $x1199 $x1199 false)))
(let (($x2505 (or $x1340 false false)))
(and (not $x2505) (or $x2505 (and (distinct ?x2506 ?x2506) true)))))))))))))))
(check-sat)
; query 79: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x6852 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x318 (or false false false)))
(let (($x478 (not $x318)))
(and $x478 (or $x318 (and (distinct ?x6852 ?x6852) true)))))))
(check-sat)
; query 80: function matrix_add_const, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x318 (or false false false)))
(let (($x478 (not $x318)))
(and $x478 (or $x318 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 81: function matrix_add_const, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x164 (bvadd in.01_32 (_ bv1 32))))
(let (($x361 (and (distinct ?x164 ?x164) true)))
(let (($x318 (or false false false)))
(let (($x478 (not $x318)))
(and $x478 (or $x318 $x361)))))))
(check-sat)
; query 82: function matrix_mul_const, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x318 (or false false false)))
(let (($x478 (not $x318)))
(and $x478 (or $x318 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 83: function matrix_mul_const, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x164 (bvadd in.01_32 (_ bv1 32))))
(let (($x361 (and (distinct ?x164 ?x164) true)))
(let (($x318 (or false false false)))
(let (($x478 (not $x318)))
(and $x478 (or $x318 $x361)))))))
(check-sat)
; query 84: function matrix_mul_matrix, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x318 (or false false false)))
(let (($x478 (not $x318)))
(and $x478 (or $x318 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 85: function matrix_mul_matrix, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x164 (bvadd in.01_32 (_ bv1 32))))
(let (($x361 (and (distinct ?x164 ?x164) true)))
(let (($x318 (or false false false)))
(let (($x478 (not $x318)))
(and $x478 (or $x318 $x361)))))))
(check-sat)
; query 86: function matrix_mul_matrix, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x318 (or false false false)))
(let (($x478 (not $x318)))
(and $x478 (or $x318 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 87: function matrix_mul_matrix_bitextract, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x318 (or false false false)))
(let (($x478 (not $x318)))
(and $x478 (or $x318 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 88: function matrix_mul_matrix_bitextract, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x164 (bvadd in.01_32 (_ bv1 32))))
(let (($x361 (and (distinct ?x164 ?x164) true)))
(let (($x318 (or false false false)))
(let (($x478 (not $x318)))
(and $x478 (or $x318 $x361)))))))
(check-sat)
; query 89: function matrix_mul_matrix_bitextract, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x318 (or false false false)))
(let (($x478 (not $x318)))
(and $x478 (or $x318 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 90: function matrix_mul_vect, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x318 (or false false false)))
(let (($x478 (not $x318)))
(and $x478 (or $x318 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 91: function matrix_mul_vect, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x164 (bvadd in.01_32 (_ bv1 32))))
(let (($x361 (and (distinct ?x164 ?x164) true)))
(let (($x318 (or false false false)))
(let (($x478 (not $x318)))
(and $x478 (or $x318 $x361)))))))
(check-sat)
; query 92: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x662 (or false false)))
(let (($x608 (not $x662)))
(and $x608 (or $x662 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 93: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x6867 ((_ sign_extend 16) in.1_16)))
(let ((?x6873 (bvadd ?x6867 (_ bv10 32))))
(let (($x6871 (and (distinct (bvadd ((_ sign_extend 1) ?x6867) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x6873)) true)))
(let (($x662 (or false false)))
(let (($x6888 (or $x662 false (or $x6871))))
(and (not $x6888) (or $x6888 (and (distinct ?x6873 ?x6873) true)))))))))
(check-sat)
; query 94: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x6867 ((_ sign_extend 16) in.1_16)))
(let ((?x6873 (bvadd ?x6867 (_ bv10 32))))
(let ((?x2042 ((_ extract 15 0) ?x6873)))
(let (($x6871 (and (distinct (bvadd ((_ sign_extend 1) ?x6867) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x6873)) true)))
(let (($x662 (or false false)))
(let (($x6888 (or $x662 false (or $x6871))))
(let (($x6885 (or $x6888 false)))
(and (not $x6885) (or $x6885 (and (distinct ?x2042 ?x2042) true)))))))))))
(check-sat)
; query 95: function matrix_sum, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x6903 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x318 (or false false false)))
(let (($x478 (not $x318)))
(and $x478 (or $x318 (and (distinct ?x6903 ?x6903) true)))))))
(check-sat)
; query 96: function matrix_sum, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x6903 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let ((?x6908 ((_ zero_extend 63) ?x6903)))
(let (($x318 (or false false false)))
(let (($x6910 (or $x318 false)))
(and (not $x6910) (or $x6910 (and (distinct ?x6908 ?x6908) true))))))))
(check-sat)
; query 97: function matrix_sum, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x6903 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x6911 (= (_ bv1 1) ?x6903)))
(let ((?x6893 (ite $x6911 (_ bv1 32) (_ bv0 32))))
(let (($x318 (or false false false)))
(let (($x1018 (or $x318 (ite $x6911 false false))))
(and (not $x1018) (or $x1018 (and (distinct ?x6893 ?x6893) true)))))))))
(check-sat)
; query 98: function matrix_sum, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x662 (or false false)))
(let (($x608 (not $x662)))
(and $x608 (or $x662 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 99: function matrix_sum, block 22, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x6903 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x6911 (= (_ bv1 1) ?x6903)))
(let ((?x6893 (ite $x6911 (_ bv1 32) (_ bv0 32))))
(let ((?x6867 ((_ sign_extend 16) in.1_16)))
(let ((?x813 (bvadd ?x6867 ?x6893)))
(let (($x1026 (and (distinct (bvadd ((_ sign_extend 1) ?x6867) ((_ sign_extend 1) ?x6893)) ((_ sign_extend 1) ?x813)) true)))
(let (($x318 (or false false false)))
(let (($x1018 (or $x318 (ite $x6911 false false))))
(let (($x662 (or false false)))
(let (($x902 (or $x662 $x1018 (or $x1026))))
(and (not $x902) (or $x902 (and (distinct ?x813 ?x813) true))))))))))))))
(check-sat)
; query 100: function matrix_sum, block 22, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x6903 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x6911 (= (_ bv1 1) ?x6903)))
(let ((?x6893 (ite $x6911 (_ bv1 32) (_ bv0 32))))
(let ((?x6867 ((_ sign_extend 16) in.1_16)))
(let ((?x813 (bvadd ?x6867 ?x6893)))
(let ((?x648 ((_ extract 15 0) ?x813)))
(let (($x1026 (and (distinct (bvadd ((_ sign_extend 1) ?x6867) ((_ sign_extend 1) ?x6893)) ((_ sign_extend 1) ?x813)) true)))
(let (($x318 (or false false false)))
(let (($x1018 (or $x318 (ite $x6911 false false))))
(let (($x662 (or false false)))
(let (($x902 (or $x662 $x1018 (or $x1026))))
(let (($x791 (or $x902 false)))
(and (not $x791) (or $x791 (and (distinct ?x648 ?x648) true))))))))))))))))
(check-sat)
; query 101: function matrix_sum, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x318 (or false false false)))
(let (($x478 (not $x318)))
(and $x478 (or $x318 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 102: function matrix_sum, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x164 (bvadd in.01_32 (_ bv1 32))))
(let (($x361 (and (distinct ?x164 ?x164) true)))
(let (($x318 (or false false false)))
(let (($x478 (not $x318)))
(and $x478 (or $x318 $x361)))))))
(check-sat)
; query 103: function parseval, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.23_32 () (_ BitVec 32))
(assert
 (let (($x2654 (and (distinct (bvmul ((_ sign_extend 32) in.23_32) ((_ sign_extend 32) (_ bv1024 32))) ((_ sign_extend 32) (bvmul in.23_32 (_ bv1024 32)))) true)))
(let (($x4465 (or false false (or $x2654))))
(and (not $x4465) (or $x4465 (and (distinct (bvmul in.23_32 (_ bv1024 32)) (bvmul in.23_32 (_ bv1024 32))) true))))))
(check-sat)
; query 104: function parseval, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.34_32 () (_ BitVec 32))
(assert
 (let (($x2721 (and (distinct (bvmul ((_ sign_extend 32) in.34_32) ((_ sign_extend 32) (_ bv1048576 32))) ((_ sign_extend 32) (bvmul in.34_32 (_ bv1048576 32)))) true)))
(let (($x2924 (or false false (or $x2721))))
(and (not $x2924) (or $x2924 (and (distinct (bvmul in.34_32 (_ bv1048576 32)) (bvmul in.34_32 (_ bv1048576 32))) true))))))
(check-sat)
; query 105: function partition_memory, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x318 (or false false false)))
(let (($x478 (not $x318)))
(and $x478 (or $x318 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
