; OptiPhase-Sigma refinement certificate for sweep K30-R1-002
; query 0: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x81 (ite (bvsgt (_ bv2 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x72 (or false false false)))
(and (not $x72) (or $x72 (and (distinct ?x81 ?x81) true))))))
(check-sat)
