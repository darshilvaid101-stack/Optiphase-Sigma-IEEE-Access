; OptiPhase-Sigma refinement certificate for sweep K09-R4-346
