; OptiPhase-Sigma refinement certificate for sweep K37-R6-021
; query 0: function bit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x32 (and (distinct (bvsub ((_ sign_extend 1) (_ bv31 32)) ((_ sign_extend 1) in0_32)) ((_ sign_extend 1) (bvsub (_ bv31 32) in0_32))) true)))
(let (($x124 (or false false (or $x32))))
(and (not $x124) (or $x124 (and (distinct (bvsub (_ bv31 32) in0_32) (bvsub (_ bv31 32) in0_32)) true))))))
(check-sat)
; query 1: function bit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x389 (bvsub (_ bv31 32) in0_32)))
(let ((?x164 (bvshl (_ bv1 32) ?x389)))
(let (($x32 (and (distinct (bvsub ((_ sign_extend 1) (_ bv31 32)) ((_ sign_extend 1) in0_32)) ((_ sign_extend 1) ?x389)) true)))
(let (($x124 (or false false (or $x32))))
(let (($x411 (or (or false $x124 false) (bvuge ?x389 (_ bv32 32)))))
(and (not $x411) (or $x411 (and (distinct ?x164 ?x164) true)))))))))
(check-sat)
; query 2: function bit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x389 (bvsub (_ bv31 32) in0_32)))
(let ((?x164 (bvshl (_ bv1 32) ?x389)))
(let ((?x77 ((_ sign_extend 32) ?x164)))
(let (($x32 (and (distinct (bvsub ((_ sign_extend 1) (_ bv31 32)) ((_ sign_extend 1) in0_32)) ((_ sign_extend 1) ?x389)) true)))
(let (($x124 (or false false (or $x32))))
(let (($x411 (or (or false $x124 false) (bvuge ?x389 (_ bv32 32)))))
(let (($x182 (or $x411 false)))
(and (not $x182) (or $x182 (and (distinct ?x77 ?x77) true)))))))))))
(check-sat)
; query 3: function bit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x28 (and (distinct (bvand in1_64 ((_ sign_extend 32) (bvshl (_ bv1 32) (bvsub (_ bv31 32) in0_32)))) (bvand ((_ sign_extend 32) (bvshl (_ bv1 32) (bvsub (_ bv31 32) in0_32))) in1_64)) true)))
(let (($x32 (and (distinct (bvsub ((_ sign_extend 1) (_ bv31 32)) ((_ sign_extend 1) in0_32)) ((_ sign_extend 1) (bvsub (_ bv31 32) in0_32))) true)))
(let (($x124 (or false false (or $x32))))
(let (($x411 (or (or false $x124 false) (bvuge (bvsub (_ bv31 32) in0_32) (_ bv32 32)))))
(let (($x182 (or $x411 false)))
(and (not (or false $x182 false)) (or (or $x182 false false) $x28))))))))
(check-sat)
; query 4: function main, block 104, name %105
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (and (not (or false false)) (or (or false false) (and (distinct ((_ extract 31 0) (_ bv4294967295 64)) ((_ extract 31 0) (_ bv4294967295 64))) true))))
(check-sat)
; query 5: function main, block 104, name %106
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x92 (or false false)))
(let (($x924 (or $x92 false false)))
(let (($x87 (or $x924 (and (distinct (bvand ((_ extract 31 0) (_ bv4294967295 64)) (_ bv4278190080 32)) (bvand ((_ extract 31 0) (_ bv4294967295 64)) (_ bv4278190080 32))) true))))
(let (($x47 (not $x924)))
(and $x47 $x87))))))
(check-sat)
; query 6: function main, block 104, name %107
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x264 ((_ extract 31 0) (_ bv4294967295 64))))
(let ((?x278 (bvand ?x264 (_ bv4278190080 32))))
(let ((?x70 (bvlshr ?x278 (_ bv24 32))))
(let (($x92 (or false false)))
(let (($x924 (or $x92 false false)))
(let (($x392 (or $x924 false false)))
(let (($x91 (or $x392 (bvuge (_ bv24 32) (_ bv32 32)))))
(let (($x122 (not $x91)))
(and $x122 (or $x91 (and (distinct ?x70 ?x70) true))))))))))))
(check-sat)
; query 7: function main, block 104, name %108
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (and (not (or false false)) (or (or false false) (and (distinct ((_ extract 31 0) (_ bv4294967295 64)) ((_ extract 31 0) (_ bv4294967295 64))) true))))
(check-sat)
; query 8: function main, block 104, name %109
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x92 (or false false)))
(let (($x924 (or $x92 false false)))
(let (($x36 (or $x924 (and (distinct (bvand ((_ extract 31 0) (_ bv4294967295 64)) (_ bv16711680 32)) (bvand ((_ extract 31 0) (_ bv4294967295 64)) (_ bv16711680 32))) true))))
(let (($x47 (not $x924)))
(and $x47 $x36))))))
(check-sat)
; query 9: function main, block 104, name %110
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x264 ((_ extract 31 0) (_ bv4294967295 64))))
(let ((?x38 (bvand ?x264 (_ bv16711680 32))))
(let ((?x609 (bvlshr ?x38 (_ bv8 32))))
(let (($x92 (or false false)))
(let (($x924 (or $x92 false false)))
(let (($x392 (or $x924 false false)))
(let (($x114 (or $x392 (bvuge (_ bv8 32) (_ bv32 32)))))
(let (($x405 (not $x114)))
(and $x405 (or $x114 (and (distinct ?x609 ?x609) true))))))))))))
(check-sat)
; query 10: function main, block 104, name %111
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x264 ((_ extract 31 0) (_ bv4294967295 64))))
(let ((?x38 (bvand ?x264 (_ bv16711680 32))))
(let ((?x609 (bvlshr ?x38 (_ bv8 32))))
(let ((?x278 (bvand ?x264 (_ bv4278190080 32))))
(let ((?x70 (bvlshr ?x278 (_ bv24 32))))
(let ((?x45 (bvor ?x70 ?x609)))
(let (($x92 (or false false)))
(let (($x924 (or $x92 false false)))
(let (($x392 (or $x924 false false)))
(let (($x114 (or $x392 (bvuge (_ bv8 32) (_ bv32 32)))))
(let (($x91 (or $x392 (bvuge (_ bv24 32) (_ bv32 32)))))
(let (($x662 (or $x91 $x114 false)))
(and (not $x662) (or $x662 (and (distinct ?x45 ?x45) true))))))))))))))))
(check-sat)
; query 11: function main, block 104, name %112
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (and (not (or false false)) (or (or false false) (and (distinct ((_ extract 31 0) (_ bv4294967295 64)) ((_ extract 31 0) (_ bv4294967295 64))) true))))
(check-sat)
; query 12: function main, block 104, name %113
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x92 (or false false)))
(let (($x924 (or $x92 false false)))
(let (($x514 (or $x924 (and (distinct (bvand ((_ extract 31 0) (_ bv4294967295 64)) (_ bv65280 32)) (bvand ((_ extract 31 0) (_ bv4294967295 64)) (_ bv65280 32))) true))))
(let (($x47 (not $x924)))
(and $x47 $x514))))))
(check-sat)
; query 13: function main, block 104, name %114
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x264 ((_ extract 31 0) (_ bv4294967295 64))))
(let ((?x309 (bvand ?x264 (_ bv65280 32))))
(let ((?x88 (bvshl ?x309 (_ bv8 32))))
(let (($x92 (or false false)))
(let (($x924 (or $x92 false false)))
(let (($x392 (or $x924 false false)))
(let (($x114 (or $x392 (bvuge (_ bv8 32) (_ bv32 32)))))
(let (($x405 (not $x114)))
(and $x405 (or $x114 (and (distinct ?x88 ?x88) true))))))))))))
(check-sat)
; query 14: function main, block 104, name %115
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x264 ((_ extract 31 0) (_ bv4294967295 64))))
(let ((?x309 (bvand ?x264 (_ bv65280 32))))
(let ((?x88 (bvshl ?x309 (_ bv8 32))))
(let ((?x38 (bvand ?x264 (_ bv16711680 32))))
(let ((?x609 (bvlshr ?x38 (_ bv8 32))))
(let ((?x278 (bvand ?x264 (_ bv4278190080 32))))
(let ((?x70 (bvlshr ?x278 (_ bv24 32))))
(let ((?x45 (bvor ?x70 ?x609)))
(let ((?x476 (bvadd ?x45 ?x88)))
(let ((?x407 (bvor ?x45 ?x88)))
(let ((?x499 ((_ zero_extend 1) ?x476)))
(let ((?x376 ((_ sign_extend 1) ?x476)))
(let (($x200 (or (and (distinct (bvadd ((_ sign_extend 1) ?x45) ((_ sign_extend 1) ?x88)) ?x376) true) (and (distinct (bvadd ((_ zero_extend 1) ?x45) ((_ zero_extend 1) ?x88)) ?x499) true))))
(let (($x92 (or false false)))
(let (($x924 (or $x92 false false)))
(let (($x392 (or $x924 false false)))
(let (($x114 (or $x392 (bvuge (_ bv8 32) (_ bv32 32)))))
(let (($x91 (or $x392 (bvuge (_ bv24 32) (_ bv32 32)))))
(let (($x662 (or $x91 $x114 false)))
(let (($x145 (or $x662 $x114 $x200)))
(and (not (or $x662 $x114 false)) (or $x145 (and (distinct ?x407 ?x476) true))))))))))))))))))))))))
(check-sat)
; query 15: function main, block 104, name %116
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (and (not (or false false)) (or (or false false) (and (distinct ((_ extract 31 0) (_ bv4294967295 64)) ((_ extract 31 0) (_ bv4294967295 64))) true))))
(check-sat)
; query 16: function main, block 104, name %117
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x92 (or false false)))
(let (($x924 (or $x92 false false)))
(let (($x176 (or $x924 (and (distinct (bvand ((_ extract 31 0) (_ bv4294967295 64)) (_ bv255 32)) (bvand ((_ extract 31 0) (_ bv4294967295 64)) (_ bv255 32))) true))))
(let (($x47 (not $x924)))
(and $x47 $x176))))))
(check-sat)
; query 17: function main, block 104, name %118
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x264 ((_ extract 31 0) (_ bv4294967295 64))))
(let ((?x447 (bvand ?x264 (_ bv255 32))))
(let ((?x566 (bvshl ?x447 (_ bv24 32))))
(let (($x92 (or false false)))
(let (($x924 (or $x92 false false)))
(let (($x392 (or $x924 false false)))
(let (($x91 (or $x392 (bvuge (_ bv24 32) (_ bv32 32)))))
(let (($x122 (not $x91)))
(and $x122 (or $x91 (and (distinct ?x566 ?x566) true))))))))))))
(check-sat)
; query 18: function main, block 104, name %119
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x264 ((_ extract 31 0) (_ bv4294967295 64))))
(let ((?x447 (bvand ?x264 (_ bv255 32))))
(let ((?x566 (bvshl ?x447 (_ bv24 32))))
(let ((?x309 (bvand ?x264 (_ bv65280 32))))
(let ((?x88 (bvshl ?x309 (_ bv8 32))))
(let ((?x38 (bvand ?x264 (_ bv16711680 32))))
(let ((?x609 (bvlshr ?x38 (_ bv8 32))))
(let ((?x278 (bvand ?x264 (_ bv4278190080 32))))
(let ((?x70 (bvlshr ?x278 (_ bv24 32))))
(let ((?x45 (bvor ?x70 ?x609)))
(let ((?x476 (bvadd ?x45 ?x88)))
(let ((?x142 (bvadd ?x476 ?x566)))
(let (($x139 (and (distinct (bvadd ((_ zero_extend 1) ?x476) ((_ zero_extend 1) ?x566)) ((_ zero_extend 1) ?x142)) true)))
(let (($x55 (and (distinct (bvadd ((_ sign_extend 1) ?x476) ((_ sign_extend 1) ?x566)) ((_ sign_extend 1) ?x142)) true)))
(let (($x92 (or false false)))
(let (($x924 (or $x92 false false)))
(let (($x392 (or $x924 false false)))
(let (($x91 (or $x392 (bvuge (_ bv24 32) (_ bv32 32)))))
(let ((?x499 ((_ zero_extend 1) ?x476)))
(let ((?x376 ((_ sign_extend 1) ?x476)))
(let (($x200 (or (and (distinct (bvadd ((_ sign_extend 1) ?x45) ((_ sign_extend 1) ?x88)) ?x376) true) (and (distinct (bvadd ((_ zero_extend 1) ?x45) ((_ zero_extend 1) ?x88)) ?x499) true))))
(let (($x114 (or $x392 (bvuge (_ bv8 32) (_ bv32 32)))))
(let (($x662 (or $x91 $x114 false)))
(let (($x145 (or $x662 $x114 $x200)))
(let (($x29 (or (or $x145 $x91 (or $x55 $x139)) (and (distinct (bvor (bvor ?x45 ?x88) ?x566) ?x142) true))))
(and (not (or (or $x662 $x114 false) $x91 false)) $x29)))))))))))))))))))))))))))
(check-sat)
