; OptiPhase-Sigma refinement certificate for sweep K42-R2-047
; query 0: function byte_reverse, block 35, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x460 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x562 (or false false (or $x460))))
(and (not $x562) (or $x562 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function sha_transform, block 12, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x460 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x562 (or false false (or $x460))))
(and (not $x562) (or $x562 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function sha_transform, block 122, name %123
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.4_32 () (_ BitVec 32))
(assert
 (let (($x73 (and (distinct (bvadd ((_ sign_extend 1) in.4_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.4_32 (_ bv1 32)))) true)))
(let (($x99 (or false false (or $x73))))
(and (not $x99) (or $x99 (and (distinct (bvadd in.4_32 (_ bv1 32)) (bvadd in.4_32 (_ bv1 32))) true))))))
(check-sat)
; query 3: function sha_transform, block 143, name %144
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.5_32 () (_ BitVec 32))
(assert
 (let (($x111 (and (distinct (bvadd ((_ sign_extend 1) in.5_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.5_32 (_ bv1 32)))) true)))
(let (($x72 (or false false (or $x111))))
(and (not $x72) (or $x72 (and (distinct (bvadd in.5_32 (_ bv1 32)) (bvadd in.5_32 (_ bv1 32))) true))))))
(check-sat)
; query 4: function sha_transform, block 39, name %40
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x12 (and (distinct (bvadd ((_ sign_extend 1) in.12_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.12_32 (_ bv1 32)))) true)))
(let (($x5 (or false false (or $x12))))
(and (not $x5) (or $x5 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 5: function sha_transform, block 77, name %78
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.23_32 () (_ BitVec 32))
(assert
 (let (($x51 (and (distinct (bvadd ((_ sign_extend 1) in.23_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.23_32 (_ bv1 32)))) true)))
(let (($x146 (or false false (or $x51))))
(and (not $x146) (or $x146 (and (distinct (bvadd in.23_32 (_ bv1 32)) (bvadd in.23_32 (_ bv1 32))) true))))))
(check-sat)
; query 6: function sha_transform, block 98, name %99
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.34_32 () (_ BitVec 32))
(assert
 (let (($x192 (and (distinct (bvadd ((_ sign_extend 1) in.34_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.34_32 (_ bv1 32)))) true)))
(let (($x133 (or false false (or $x192))))
(and (not $x133) (or $x133 (and (distinct (bvadd in.34_32 (_ bv1 32)) (bvadd in.34_32 (_ bv1 32))) true))))))
(check-sat)
