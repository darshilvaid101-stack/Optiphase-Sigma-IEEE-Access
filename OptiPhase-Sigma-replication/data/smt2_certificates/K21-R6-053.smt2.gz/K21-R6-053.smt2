; OptiPhase-Sigma refinement certificate for sweep K21-R6-053
