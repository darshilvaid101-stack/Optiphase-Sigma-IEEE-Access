; OptiPhase-Sigma refinement certificate for sweep K30-R4-338
; query 0: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x555 (ite (bvsgt (_ bv2 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x339 (or false false false)))
(and (not $x339) (or $x339 (and (distinct ?x555 ?x555) true))))))
(check-sat)
