; OptiPhase-Sigma refinement certificate for sweep K57-R3-127
; query 0: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x1928 (or false false false)))
(let (($x1013 (not $x1928)))
(and $x1013 (or $x1928 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x214 (bvadd in.01_32 (_ bv1 32))))
(let ((?x263 (bvmul ?x214 ?x214)))
(let (($x1928 (or false false false)))
(let (($x293 (or $x1928 $x1928 false)))
(and (not $x293) (or $x293 (and (distinct ?x263 ?x263) true))))))))
(check-sat)
; query 2: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x87 (and (distinct (bvmul (bvmul (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) (_ bv2 32)) (bvshl (bvmul (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) (_ bv3 32))) true)))
(let (($x1928 (or false false false)))
(let (($x293 (or $x1928 $x1928 false)))
(let (($x81 (or $x293 false false)))
(and (not $x81) (or (or $x81 (bvuge (_ bv3 32) (_ bv32 32))) $x87)))))))
(check-sat)
; query 3: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x1954 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x1928 (or false false false)))
(let (($x1013 (not $x1928)))
(and $x1013 (or $x1928 (and (distinct ?x1954 ?x1954) true)))))))
(check-sat)
; query 4: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x1928 (or false false false)))
(let (($x1013 (not $x1928)))
(and $x1013 (or $x1928 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 5: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1879 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x1928 (or false false false)))
(let (($x1013 (not $x1928)))
(and $x1013 (or $x1928 (and (distinct ?x1879 ?x1879) true)))))))
(check-sat)
