; OptiPhase-Sigma refinement certificate for sweep K49-R3-110
; query 0: function APCM_inverse_quantization, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x245 (or false false)))
(let (($x460 (not $x245)))
(and $x460 (or $x245 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 1: function APCM_inverse_quantization, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1696 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x245 (or false false)))
(let (($x700 (or $x245 false false)))
(let (($x73 (not $x700)))
(and $x73 (or $x700 (and (distinct ?x1696 ?x1696) true))))))))
(check-sat)
; query 2: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x245 (or false false)))
(let (($x460 (not $x245)))
(and $x460 (or $x245 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 3: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1721 (ite (bvslt (_ bv15 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x245 (or false false)))
(let (($x700 (or $x245 false false)))
(let (($x73 (not $x700)))
(and $x73 (or $x700 (and (distinct ?x1721 ?x1721) true))))))))
(check-sat)
; query 4: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x245 (or false false)))
(let (($x460 (not $x245)))
(and $x460 (or $x245 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 5: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1730 (ite (bvsgt (_ bv40 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x245 (or false false)))
(let (($x700 (or $x245 false false)))
(let (($x73 (not $x700)))
(and $x73 (or $x700 (and (distinct ?x1730 ?x1730) true))))))))
(check-sat)
; query 6: function RPE_grid_positioning, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x245 (or false false)))
(let (($x460 (not $x245)))
(and $x460 (or $x245 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 7: function RPE_grid_positioning, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x126 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x184 (and (distinct ?x126 ?x126) true)))
(let (($x245 (or false false)))
(let (($x76 (or false $x245 false)))
(and (not $x76) (or $x76 $x184)))))))
(check-sat)
; query 8: function gsm_L_add, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1868 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x121 (or false false false)))
(let (($x656 (not $x121)))
(and $x656 (or $x121 (and (distinct ?x1868 ?x1868) true)))))))
(check-sat)
; query 9: function gsm_L_add, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let (($x174 (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) in0_64)) ((_ sign_extend 1) (bvadd in1_64 in0_64))) true)))
(let (($x1839 (or (or false false (or $x174)) (and (distinct (bvadd in0_64 in1_64) (bvadd in1_64 in0_64)) true))))
(let (($x58 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvadd in0_64 in1_64))) true)))
(and (not (or false false (or $x58))) $x1839)))))
(check-sat)
; query 10: function gsm_L_add, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x80 (bvadd in0_64 (_ bv1 64))))
(let ((?x1832 (bvsub (_ bv0 64) ?x80)))
(let (($x221 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x80)) ((_ sign_extend 1) ?x1832)) true)))
(let ((?x374 ((_ sign_extend 1) ?x80)))
(let (($x99 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x374) true)))))
(let (($x454 (or false $x99 (or $x221))))
(and (not $x454) (or $x454 (and (distinct ?x1832 ?x1832) true))))))))))
(check-sat)
; query 11: function gsm_L_add, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x19 (bvadd in1_64 (_ bv1 64))))
(let ((?x94 ((_ sign_extend 1) ?x19)))
(let (($x326 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x94) true)))))
(and (not $x326) (or $x326 (and (distinct ?x19 ?x19) true)))))))
(check-sat)
; query 12: function gsm_L_add, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x19 (bvadd in1_64 (_ bv1 64))))
(let ((?x375 (bvsub (_ bv0 64) ?x19)))
(let (($x475 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x19)) ((_ sign_extend 1) ?x375)) true)))
(let ((?x94 ((_ sign_extend 1) ?x19)))
(let (($x326 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x94) true)))))
(let (($x290 (or false $x326 (or $x475))))
(and (not $x290) (or $x290 (and (distinct ?x375 ?x375) true))))))))))
(check-sat)
; query 13: function gsm_L_add, block 8, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x80 (bvadd in0_64 (_ bv1 64))))
(let ((?x1832 (bvsub (_ bv0 64) ?x80)))
(let ((?x19 (bvadd in1_64 (_ bv1 64))))
(let ((?x375 (bvsub (_ bv0 64) ?x19)))
(let ((?x35 (bvadd ?x375 ?x1832)))
(let ((?x37 (bvadd ?x1832 ?x375)))
(let (($x221 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x80)) ((_ sign_extend 1) ?x1832)) true)))
(let ((?x374 ((_ sign_extend 1) ?x80)))
(let (($x99 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x374) true)))))
(let (($x454 (or false $x99 (or $x221))))
(let (($x475 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x19)) ((_ sign_extend 1) ?x375)) true)))
(let ((?x94 ((_ sign_extend 1) ?x19)))
(let (($x326 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x94) true)))))
(let (($x290 (or false $x326 (or $x475))))
(let (($x136 (or $x290 $x454 false)))
(and (not (or $x454 $x290 false)) (or $x136 (and (distinct ?x37 ?x35) true)))))))))))))))))))
(check-sat)
; query 14: function gsm_L_add, block 8, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x80 (bvadd in0_64 (_ bv1 64))))
(let ((?x1832 (bvsub (_ bv0 64) ?x80)))
(let ((?x19 (bvadd in1_64 (_ bv1 64))))
(let ((?x375 (bvsub (_ bv0 64) ?x19)))
(let ((?x35 (bvadd ?x375 ?x1832)))
(let (($x131 (and (distinct (ite (bvuge (bvadd ?x1832 ?x375) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1)) (ite (bvuge ?x35 (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))) true)))
(let (($x221 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x80)) ((_ sign_extend 1) ?x1832)) true)))
(let ((?x374 ((_ sign_extend 1) ?x80)))
(let (($x99 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x374) true)))))
(let (($x454 (or false $x99 (or $x221))))
(let (($x475 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x19)) ((_ sign_extend 1) ?x375)) true)))
(let ((?x94 ((_ sign_extend 1) ?x19)))
(let (($x326 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x94) true)))))
(let (($x290 (or false $x326 (or $x475))))
(let (($x136 (or $x290 $x454 false)))
(and (not (or (or $x454 $x290 false) false false)) (or (or $x136 false false) $x131))))))))))))))))))
(check-sat)
; query 15: function gsm_L_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x80 (bvadd in0_64 (_ bv1 64))))
(let ((?x374 ((_ sign_extend 1) ?x80)))
(let (($x99 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x374) true)))))
(and (not $x99) (or $x99 (and (distinct ?x80 ?x80) true)))))))
(check-sat)
; query 16: function gsm_L_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x34 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x121 (or false false false)))
(let (($x656 (not $x121)))
(and $x656 (or $x121 (and (distinct ?x34 ?x34) true)))))))
(check-sat)
; query 17: function gsm_L_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x151 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x121 (or false false false)))
(let (($x656 (not $x121)))
(and $x656 (or $x121 (and (distinct ?x151 ?x151) true)))))))
(check-sat)
; query 18: function gsm_L_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x34 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x121 (or false false false)))
(let (($x656 (not $x121)))
(and $x656 (or $x121 (and (distinct ?x34 ?x34) true)))))))
(check-sat)
; query 19: function gsm_L_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x34 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x626 ((_ zero_extend 31) ?x34)))
(let (($x121 (or false false false)))
(let (($x383 (or $x121 false)))
(and (not $x383) (or $x383 (and (distinct ?x626 ?x626) true))))))))
(check-sat)
; query 20: function gsm_L_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x34 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x626 ((_ zero_extend 31) ?x34)))
(let ((?x1737 (bvsub (_ bv0 32) ?x626)))
(let (($x271 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x626)) ((_ sign_extend 1) ?x1737)) true)))
(let (($x121 (or false false false)))
(let (($x383 (or $x121 false)))
(let (($x297 (or false $x383 (or $x271))))
(and (not $x297) (or $x297 (and (distinct ?x1737 ?x1737) true)))))))))))
(check-sat)
; query 21: function gsm_L_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x34 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x626 ((_ zero_extend 31) ?x34)))
(let ((?x1737 (bvsub (_ bv0 32) ?x626)))
(let ((?x66 ((_ sign_extend 32) ?x1737)))
(let (($x271 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x626)) ((_ sign_extend 1) ?x1737)) true)))
(let (($x121 (or false false false)))
(let (($x383 (or $x121 false)))
(let (($x297 (or false $x383 (or $x271))))
(let (($x145 (or $x297 false)))
(and (not $x145) (or $x145 (and (distinct ?x66 ?x66) true)))))))))))))
(check-sat)
; query 22: function gsm_L_asr, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x8 (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x121 (or false false false)))
(let (($x656 (not $x121)))
(and $x656 (or $x121 (and (distinct ?x8 ?x8) true)))))))
(check-sat)
; query 23: function gsm_L_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x151 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x121 (or false false false)))
(let (($x656 (not $x121)))
(and $x656 (or $x121 (and (distinct ?x151 ?x151) true)))))))
(check-sat)
; query 24: function gsm_L_sub, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1868 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x121 (or false false false)))
(let (($x656 (not $x121)))
(and $x656 (or $x121 (and (distinct ?x1868 ?x1868) true)))))))
(check-sat)
; query 25: function gsm_L_sub, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x103 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvsub in0_64 in1_64))) true)))
(let (($x463 (or false false (or $x103))))
(let (($x1694 (or $x463 (and (distinct (bvsub in0_64 in1_64) (bvsub in0_64 in1_64)) true))))
(and (not $x463) $x1694)))))
(check-sat)
; query 26: function gsm_L_sub, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x19 (bvadd in1_64 (_ bv1 64))))
(let ((?x375 (bvsub (_ bv0 64) ?x19)))
(let (($x475 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x19)) ((_ sign_extend 1) ?x375)) true)))
(let ((?x94 ((_ sign_extend 1) ?x19)))
(let (($x326 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x94) true)))))
(let (($x290 (or false $x326 (or $x475))))
(and (not $x290) (or $x290 (and (distinct ?x375 ?x375) true))))))))))
(check-sat)
; query 27: function gsm_L_sub, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x19 (bvadd in1_64 (_ bv1 64))))
(let ((?x375 (bvsub (_ bv0 64) ?x19)))
(let ((?x449 (bvadd ?x375 in0_64)))
(let ((?x53 (bvadd in0_64 ?x375)))
(let (($x475 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x19)) ((_ sign_extend 1) ?x375)) true)))
(let ((?x94 ((_ sign_extend 1) ?x19)))
(let (($x326 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x94) true)))))
(let (($x290 (or false $x326 (or $x475))))
(let (($x77 (or $x290 false false)))
(and (not (or false $x290 false)) (or $x77 (and (distinct ?x53 ?x449) true)))))))))))))
(check-sat)
; query 28: function gsm_L_sub, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x301 (ite (bvuge (bvadd (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64))) in0_64) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let ((?x611 (ite (bvuge (bvadd in0_64 (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64)))) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x475 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) (bvadd in1_64 (_ bv1 64)))) ((_ sign_extend 1) (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64))))) true)))
(let ((?x19 (bvadd in1_64 (_ bv1 64))))
(let ((?x94 ((_ sign_extend 1) ?x19)))
(let (($x326 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x94) true)))))
(let (($x290 (or false $x326 (or $x475))))
(let (($x77 (or $x290 false false)))
(and (not (or (or false $x290 false) false false)) (or (or $x77 false false) (and (distinct ?x611 ?x301) true))))))))))))
(check-sat)
; query 29: function gsm_L_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x19 (bvadd in1_64 (_ bv1 64))))
(let ((?x94 ((_ sign_extend 1) ?x19)))
(let (($x326 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x94) true)))))
(and (not $x326) (or $x326 (and (distinct ?x19 ?x19) true)))))))
(check-sat)
; query 30: function gsm_L_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1664 (ite (bvsle (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x121 (or false false false)))
(let (($x656 (not $x121)))
(and $x656 (or $x121 (and (distinct ?x1664 ?x1664) true)))))))
(check-sat)
; query 31: function gsm_abs, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x245 (or false false)))
(let (($x460 (not $x245)))
(and $x460 (or $x245 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 32: function gsm_abs, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x337 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x245 (or false false)))
(let (($x700 (or $x245 false false)))
(let (($x73 (not $x700)))
(and $x73 (or $x700 (and (distinct ?x337 ?x337) true))))))))
(check-sat)
; query 33: function gsm_abs, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x245 (or false false)))
(let (($x460 (not $x245)))
(and $x460 (or $x245 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 34: function gsm_abs, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1854 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x245 (or false false)))
(let (($x700 (or $x245 false false)))
(let (($x73 (not $x700)))
(and $x73 (or $x700 (and (distinct ?x1854 ?x1854) true))))))))
(check-sat)
; query 35: function gsm_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x245 (or false false)))
(let (($x460 (not $x245)))
(and $x460 (or $x245 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 36: function gsm_add, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x245 (or false false)))
(let (($x460 (not $x245)))
(and $x460 (or $x245 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 37: function gsm_add, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1754 ((_ sign_extend 48) in0_16)))
(let ((?x1655 ((_ sign_extend 48) in1_16)))
(let ((?x49 (bvadd ?x1655 ?x1754)))
(let ((?x1211 (bvadd ?x1754 ?x1655)))
(let (($x1794 (and (distinct (bvadd ((_ sign_extend 1) ?x1655) ((_ sign_extend 1) ?x1754)) ((_ sign_extend 1) ?x49)) true)))
(let (($x245 (or false false)))
(let (($x1884 (or $x245 $x245 (or $x1794))))
(let (($x1658 (and (distinct (bvadd ((_ sign_extend 1) ?x1754) ((_ sign_extend 1) ?x1655)) ((_ sign_extend 1) ?x1211)) true)))
(let (($x1667 (or $x245 $x245 (or $x1658))))
(and (not $x1667) (or $x1884 (and (distinct ?x1211 ?x49) true)))))))))))))
(check-sat)
; query 38: function gsm_add, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1942 (ite (bvsgt (_ bv18446744073709518848 64) (bvadd ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in0_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x1784 (ite (bvsgt (_ bv18446744073709518848 64) (bvadd ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x1754 ((_ sign_extend 48) in0_16)))
(let ((?x1904 ((_ sign_extend 1) ?x1754)))
(let ((?x1655 ((_ sign_extend 48) in1_16)))
(let ((?x1874 ((_ sign_extend 1) ?x1655)))
(let (($x245 (or false false)))
(let (($x1884 (or $x245 $x245 (or (and (distinct (bvadd ?x1874 ?x1904) ((_ sign_extend 1) (bvadd ?x1655 ?x1754))) true)))))
(let (($x1667 (or $x245 $x245 (or (and (distinct (bvadd ?x1904 ?x1874) ((_ sign_extend 1) (bvadd ?x1754 ?x1655))) true)))))
(and (not (or $x1667 false false)) (or (or $x1884 false false) (and (distinct ?x1784 ?x1942) true)))))))))))))
(check-sat)
; query 39: function gsm_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1651 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x121 (or false false false)))
(let (($x656 (not $x121)))
(and $x656 (or $x121 (and (distinct ?x1651 ?x1651) true)))))))
(check-sat)
; query 40: function gsm_asr, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x430 (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x121 (or false false false)))
(let (($x656 (not $x121)))
(and $x656 (or $x121 (and (distinct ?x430 ?x430) true)))))))
(check-sat)
; query 41: function gsm_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x245 (or false false)))
(let (($x460 (not $x245)))
(and $x460 (or $x245 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 42: function gsm_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1854 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x245 (or false false)))
(let (($x700 (or $x245 false false)))
(let (($x73 (not $x700)))
(and $x73 (or $x700 (and (distinct ?x1854 ?x1854) true))))))))
(check-sat)
; query 43: function gsm_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1854 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1677 ((_ zero_extend 31) ?x1854)))
(let (($x245 (or false false)))
(let (($x700 (or $x245 false false)))
(let (($x1652 (or $x700 false)))
(and (not $x1652) (or $x1652 (and (distinct ?x1677 ?x1677) true)))))))))
(check-sat)
; query 44: function gsm_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1854 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1677 ((_ zero_extend 31) ?x1854)))
(let ((?x1688 (bvsub (_ bv0 32) ?x1677)))
(let (($x382 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1677)) ((_ sign_extend 1) ?x1688)) true)))
(let (($x245 (or false false)))
(let (($x700 (or $x245 false false)))
(let (($x1652 (or $x700 false)))
(let (($x1686 (or false $x1652 (or $x382))))
(and (not $x1686) (or $x1686 (and (distinct ?x1688 ?x1688) true))))))))))))
(check-sat)
; query 45: function gsm_asr, block 4, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1854 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1677 ((_ zero_extend 31) ?x1854)))
(let ((?x1688 (bvsub (_ bv0 32) ?x1677)))
(let ((?x1681 ((_ extract 15 0) ?x1688)))
(let (($x382 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1677)) ((_ sign_extend 1) ?x1688)) true)))
(let (($x245 (or false false)))
(let (($x700 (or $x245 false false)))
(let (($x1652 (or $x700 false)))
(let (($x1686 (or false $x1652 (or $x382))))
(let (($x1682 (or $x1686 false)))
(and (not $x1682) (or $x1682 (and (distinct ?x1681 ?x1681) true))))))))))))))
(check-sat)
; query 46: function gsm_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1651 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x121 (or false false false)))
(let (($x656 (not $x121)))
(and $x656 (or $x121 (and (distinct ?x1651 ?x1651) true)))))))
(check-sat)
; query 47: function gsm_debug_longwords, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in15_32 () (_ BitVec 32))
(assert
 (let ((?x1719 (ite (bvslt in15_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x121 (or false false false)))
(let (($x656 (not $x121)))
(and $x656 (or $x121 (and (distinct ?x1719 ?x1719) true)))))))
(check-sat)
; query 48: function gsm_debug_words, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in16_32 () (_ BitVec 32))
(assert
 (let ((?x891 (ite (bvslt in16_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x121 (or false false false)))
(let (($x656 (not $x121)))
(and $x656 (or $x121 (and (distinct ?x891 ?x891) true)))))))
(check-sat)
; query 49: function gsm_div, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x245 (or false false)))
(let (($x460 (not $x245)))
(and $x460 (or $x245 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 50: function gsm_div, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x245 (or false false)))
(let (($x460 (not $x245)))
(and $x460 (or $x245 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 51: function gsm_div, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x245 (or false false)))
(let (($x460 (not $x245)))
(and $x460 (or $x245 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 52: function gsm_div, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x126 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x184 (and (distinct ?x126 ?x126) true)))
(let (($x245 (or false false)))
(let (($x700 (or $x245 false false)))
(let (($x73 (not $x700)))
(and $x73 (or $x700 $x184))))))))
(check-sat)
; query 53: function gsm_norm, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x34 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x121 (or false false false)))
(let (($x656 (not $x121)))
(and $x656 (or $x121 (and (distinct ?x34 (ite (bvsge (_ bv18446744072635809792 64) in0_64) (_ bv1 1) (_ bv0 1))) true)))))))
(check-sat)
; query 54: function gsm_norm, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1819 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x121 (or false false false)))
(let (($x656 (not $x121)))
(and $x656 (or $x121 (and (distinct ?x1819 ?x1819) true)))))))
(check-sat)
; query 55: function gsm_norm, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1819 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x1697 (bvxor ?x1819 (_ bv1 1))))
(let (($x121 (or false false false)))
(let (($x1876 (or $x121 false false)))
(and (not $x1876) (or $x1876 (and (distinct ?x1697 ?x1697) true))))))))
(check-sat)
; query 56: function gsm_norm, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1819 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x1697 (bvxor ?x1819 (_ bv1 1))))
(let ((?x1756 ((_ zero_extend 31) ?x1697)))
(let (($x121 (or false false false)))
(let (($x1876 (or $x121 false false)))
(let (($x1727 (or $x1876 false)))
(and (not $x1727) (or $x1727 (and (distinct ?x1756 ?x1756) true))))))))))
(check-sat)
; query 57: function gsm_norm, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1819 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x1697 (bvxor ?x1819 (_ bv1 1))))
(let ((?x1756 ((_ zero_extend 31) ?x1697)))
(let ((?x1732 ((_ sign_extend 32) ?x1756)))
(let (($x121 (or false false false)))
(let (($x1876 (or $x121 false false)))
(let (($x1727 (or $x1876 false)))
(let (($x1745 (or $x1727 false)))
(and (not $x1745) (or $x1745 (and (distinct ?x1732 ?x1732) true))))))))))))
(check-sat)
; query 58: function gsm_norm, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1819 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x1697 (bvxor ?x1819 (_ bv1 1))))
(let ((?x1756 ((_ zero_extend 31) ?x1697)))
(let ((?x1732 ((_ sign_extend 32) ?x1756)))
(let ((?x1805 (ite (and (distinct (_ bv0 64) ?x1732) true) (_ bv1 1) (_ bv0 1))))
(let (($x121 (or false false false)))
(let (($x1876 (or $x121 false false)))
(let (($x1727 (or $x1876 false)))
(let (($x1745 (or $x1727 false)))
(let (($x1858 (or $x1745 false false)))
(and (not $x1858) (or $x1858 (and (distinct ?x1805 ?x1805) true))))))))))))))
(check-sat)
; query 59: function gsm_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x245 (or false false)))
(let (($x460 (not $x245)))
(and $x460 (or $x245 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 60: function gsm_sub, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x245 (or false false)))
(let (($x460 (not $x245)))
(and $x460 (or $x245 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 61: function gsm_sub, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1655 ((_ sign_extend 48) in1_16)))
(let ((?x1754 ((_ sign_extend 48) in0_16)))
(let ((?x1941 (bvsub ?x1754 ?x1655)))
(let (($x1829 (and (distinct (bvsub ((_ sign_extend 1) ?x1754) ((_ sign_extend 1) ?x1655)) ((_ sign_extend 1) ?x1941)) true)))
(let (($x245 (or false false)))
(let (($x1897 (or $x245 $x245 (or $x1829))))
(and (not $x1897) (or $x1897 (and (distinct ?x1941 ?x1941) true))))))))))
(check-sat)
; query 62: function gsm_sub, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1789 (ite (bvsgt (_ bv18446744073709518848 64) (bvsub ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x1655 ((_ sign_extend 48) in1_16)))
(let ((?x1874 ((_ sign_extend 1) ?x1655)))
(let ((?x1754 ((_ sign_extend 48) in0_16)))
(let ((?x1904 ((_ sign_extend 1) ?x1754)))
(let (($x245 (or false false)))
(let (($x1897 (or $x245 $x245 (or (and (distinct (bvsub ?x1904 ?x1874) ((_ sign_extend 1) (bvsub ?x1754 ?x1655))) true)))))
(let (($x1810 (or $x1897 false false)))
(and (not $x1810) (or $x1810 (and (distinct ?x1789 ?x1789) true))))))))))))
(check-sat)
; query 63: function process_decode, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let (($x245 (or false false)))
(let (($x460 (not $x245)))
(and $x460 (or $x245 (and (distinct ((_ sign_extend 32) in14_32) ((_ sign_extend 32) in14_32)) true))))))
(check-sat)
; query 64: function process_decode, block 16, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x1770 (ite (and (distinct (_ bv33 64) ((_ sign_extend 32) in14_32)) true) (_ bv1 1) (_ bv0 1))))
(let (($x245 (or false false)))
(let (($x700 (or $x245 false false)))
(let (($x73 (not $x700)))
(and $x73 (or $x700 (and (distinct ?x1770 ?x1770) true))))))))
(check-sat)
; query 65: function process_encode, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_32 () (_ BitVec 32))
(assert
 (let (($x245 (or false false)))
(let (($x460 (not $x245)))
(and $x460 (or $x245 (and (distinct ((_ sign_extend 32) in13_32) ((_ sign_extend 32) in13_32)) true))))))
(check-sat)
; query 66: function process_encode, block 15, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_32 () (_ BitVec 32))
(assert
 (let ((?x533 (ite (bvult ((_ sign_extend 32) in13_32) (_ bv160 64)) (_ bv1 1) (_ bv0 1))))
(let (($x245 (or false false)))
(let (($x700 (or $x245 false false)))
(let (($x73 (not $x700)))
(and $x73 (or $x700 (and (distinct ?x533 ?x533) true))))))))
(check-sat)
