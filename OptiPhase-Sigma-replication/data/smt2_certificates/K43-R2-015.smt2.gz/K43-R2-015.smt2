; OptiPhase-Sigma refinement certificate for sweep K43-R2-015
