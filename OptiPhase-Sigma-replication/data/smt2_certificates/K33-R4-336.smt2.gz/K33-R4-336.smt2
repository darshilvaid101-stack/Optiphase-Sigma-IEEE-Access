; OptiPhase-Sigma refinement certificate for sweep K33-R4-336
; query 0: function edge_draw, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let ((?x22 (ite (= (_ bv0 32) in4_32) (_ bv1 1) (_ bv0 1))))
(let (($x393 (or false false false)))
(and (not $x393) (or $x393 (and (distinct ?x22 ?x22) true))))))
(check-sat)
