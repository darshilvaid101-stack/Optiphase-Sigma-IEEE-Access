; OptiPhase-Sigma refinement certificate for sweep K35-R6-006
; query 0: function corner_draw, block 11, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x38 (ite (= (_ bv0 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x32 (or false false false)))
(let (($x184 (not $x32)))
(and $x184 (or $x32 (and (distinct ?x38 ?x38) true)))))))
(check-sat)
; query 1: function edge_draw, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let ((?x124 (ite (= (_ bv0 32) in4_32) (_ bv1 1) (_ bv0 1))))
(let (($x32 (or false false false)))
(let (($x184 (not $x32)))
(and $x184 (or $x32 (and (distinct ?x124 ?x124) true)))))))
(check-sat)
; query 2: function main, block 129, name %130
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.011_32 () (_ BitVec 32))
(assert
 (let ((?x157 (ite (and (distinct (_ bv0 32) in.011_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x32 (or false false false)))
(let (($x184 (not $x32)))
(and $x184 (or $x32 (and (distinct ?x157 ?x157) true)))))))
(check-sat)
; query 3: function main, block 160, name %161
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x674 (ite (and (distinct (_ bv0 32) in.01_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x32 (or false false false)))
(let (($x184 (not $x32)))
(and $x184 (or $x32 (and (distinct ?x674 ?x674) true)))))))
(check-sat)
; query 4: function main, block 35, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x166 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x112 (or false false (or $x166))))
(and (not $x112) (or $x112 (and (distinct (bvadd in.020_32 (_ bv1 32)) (bvadd in.020_32 (_ bv1 32))) true))))))
(check-sat)
; query 5: function main, block 35, name %37
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let ((?x125 (ite (bvsge (bvadd in.020_32 (_ bv1 32)) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x166 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x112 (or false false (or $x166))))
(let (($x52 (or $x112 false false)))
(and (not $x52) (or $x52 (and (distinct ?x125 ?x125) true))))))))
(check-sat)
; query 6: function main, block 49, name %50
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x166 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x112 (or false false (or $x166))))
(and (not $x112) (or $x112 (and (distinct (bvadd in.020_32 (_ bv1 32)) (bvadd in.020_32 (_ bv1 32))) true))))))
(check-sat)
; query 7: function main, block 49, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let ((?x125 (ite (bvsge (bvadd in.020_32 (_ bv1 32)) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x166 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x112 (or false false (or $x166))))
(let (($x52 (or $x112 false false)))
(and (not $x52) (or $x52 (and (distinct ?x125 ?x125) true))))))))
(check-sat)
; query 8: function main, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.014_32 () (_ BitVec 32))
(assert
 (let ((?x227 (ite (= (_ bv1 32) in.014_32) (_ bv1 1) (_ bv0 1))))
(let (($x32 (or false false false)))
(let (($x184 (not $x32)))
(and $x184 (or $x32 (and (distinct ?x227 ?x227) true)))))))
(check-sat)
; query 9: function main, block 66, name %67
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x8 (ite (= (_ bv0 32) in.0_32) (_ bv1 1) (_ bv0 1))))
(let (($x32 (or false false false)))
(let (($x184 (not $x32)))
(and $x184 (or $x32 (and (distinct ?x8 ?x8) true)))))))
(check-sat)
; query 10: function main, block 84, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.07_32 () (_ BitVec 32))
(assert
 (let ((?x65 (ite (and (distinct (_ bv0 32) in.07_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x32 (or false false false)))
(let (($x184 (not $x32)))
(and $x184 (or $x32 (and (distinct ?x65 ?x65) true)))))))
(check-sat)
