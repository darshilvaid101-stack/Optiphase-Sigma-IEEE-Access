; OptiPhase-Sigma refinement certificate for sweep K21-R4-309
; query 0: function init_array, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x50 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x11 (or false false (or $x50))))
(and (not $x11) (or $x11 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function init_array, block 25, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x149 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x151 (or false false (or $x149))))
(and (not $x151) (or $x151 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function kernel_deriche, block 102, name %103
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.112_32 () (_ BitVec 32))
(assert
 (let (($x40 (and (distinct (bvadd ((_ sign_extend 1) in.112_32) ((_ sign_extend 1) (_ bv4294967295 32))) ((_ sign_extend 1) (bvadd in.112_32 (_ bv4294967295 32)))) true)))
(let (($x16 (or false false (or $x40))))
(and (not $x16) (or $x16 (and (distinct (bvadd in.112_32 (_ bv4294967295 32)) (bvadd in.112_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 3: function kernel_deriche, block 105, name %106
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.110_32 () (_ BitVec 32))
(assert
 (let (($x39 (and (distinct (bvadd ((_ sign_extend 1) in.110_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.110_32 (_ bv1 32)))) true)))
(let (($x112 (or false false (or $x39))))
(and (not $x112) (or $x112 (and (distinct (bvadd in.110_32 (_ bv1 32)) (bvadd in.110_32 (_ bv1 32))) true))))))
(check-sat)
; query 4: function kernel_deriche, block 130, name %131
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.213_32 () (_ BitVec 32))
(assert
 (let (($x120 (and (distinct (bvadd ((_ sign_extend 1) in.213_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.213_32 (_ bv1 32)))) true)))
(let (($x109 (or false false (or $x120))))
(and (not $x109) (or $x109 (and (distinct (bvadd in.213_32 (_ bv1 32)) (bvadd in.213_32 (_ bv1 32))) true))))))
(check-sat)
; query 5: function kernel_deriche, block 133, name %134
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let (($x84 (and (distinct (bvadd ((_ sign_extend 1) in.2_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.2_32 (_ bv1 32)))) true)))
(let (($x121 (or false false (or $x84))))
(and (not $x121) (or $x121 (and (distinct (bvadd in.2_32 (_ bv1 32)) (bvadd in.2_32 (_ bv1 32))) true))))))
(check-sat)
; query 6: function kernel_deriche, block 165, name %166
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.3_32 () (_ BitVec 32))
(assert
 (let (($x98 (and (distinct (bvadd ((_ sign_extend 1) in.3_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.3_32 (_ bv1 32)))) true)))
(let (($x244 (or false false (or $x98))))
(and (not $x244) (or $x244 (and (distinct (bvadd in.3_32 (_ bv1 32)) (bvadd in.3_32 (_ bv1 32))) true))))))
(check-sat)
; query 7: function kernel_deriche, block 168, name %169
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.314_32 () (_ BitVec 32))
(assert
 (let (($x9 (and (distinct (bvadd ((_ sign_extend 1) in.314_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.314_32 (_ bv1 32)))) true)))
(let (($x54 (or false false (or $x9))))
(and (not $x54) (or $x54 (and (distinct (bvadd in.314_32 (_ bv1 32)) (bvadd in.314_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function kernel_deriche, block 173, name %174
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x30 (and (distinct (bvsub ((_ sign_extend 1) in0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvsub in0_32 (_ bv1 32)))) true)))
(let (($x51 (or false false (or $x30))))
(and (not $x51) (or $x51 (and (distinct (bvsub in0_32 (_ bv1 32)) (bvsub in0_32 (_ bv1 32))) true))))))
(check-sat)
; query 9: function kernel_deriche, block 196, name %197
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.4_32 () (_ BitVec 32))
(assert
 (let (($x38 (and (distinct (bvadd ((_ sign_extend 1) in.4_32) ((_ sign_extend 1) (_ bv4294967295 32))) ((_ sign_extend 1) (bvadd in.4_32 (_ bv4294967295 32)))) true)))
(let (($x48 (or false false (or $x38))))
(and (not $x48) (or $x48 (and (distinct (bvadd in.4_32 (_ bv4294967295 32)) (bvadd in.4_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 10: function kernel_deriche, block 199, name %200
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.415_32 () (_ BitVec 32))
(assert
 (let (($x142 (and (distinct (bvadd ((_ sign_extend 1) in.415_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.415_32 (_ bv1 32)))) true)))
(let (($x35 (or false false (or $x142))))
(and (not $x35) (or $x35 (and (distinct (bvadd in.415_32 (_ bv1 32)) (bvadd in.415_32 (_ bv1 32))) true))))))
(check-sat)
; query 11: function kernel_deriche, block 224, name %225
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.516_32 () (_ BitVec 32))
(assert
 (let (($x64 (and (distinct (bvadd ((_ sign_extend 1) in.516_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.516_32 (_ bv1 32)))) true)))
(let (($x60 (or false false (or $x64))))
(and (not $x60) (or $x60 (and (distinct (bvadd in.516_32 (_ bv1 32)) (bvadd in.516_32 (_ bv1 32))) true))))))
(check-sat)
; query 12: function kernel_deriche, block 227, name %228
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.5_32 () (_ BitVec 32))
(assert
 (let (($x403 (and (distinct (bvadd ((_ sign_extend 1) in.5_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.5_32 (_ bv1 32)))) true)))
(let (($x408 (or false false (or $x403))))
(and (not $x408) (or $x408 (and (distinct (bvadd in.5_32 (_ bv1 32)) (bvadd in.5_32 (_ bv1 32))) true))))))
(check-sat)
; query 13: function kernel_deriche, block 71, name %72
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.011_32 () (_ BitVec 32))
(assert
 (let (($x356 (and (distinct (bvadd ((_ sign_extend 1) in.011_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.011_32 (_ bv1 32)))) true)))
(let (($x503 (or false false (or $x356))))
(and (not $x503) (or $x503 (and (distinct (bvadd in.011_32 (_ bv1 32)) (bvadd in.011_32 (_ bv1 32))) true))))))
(check-sat)
; query 14: function kernel_deriche, block 74, name %75
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.09_32 () (_ BitVec 32))
(assert
 (let (($x461 (and (distinct (bvadd ((_ sign_extend 1) in.09_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.09_32 (_ bv1 32)))) true)))
(let (($x384 (or false false (or $x461))))
(and (not $x384) (or $x384 (and (distinct (bvadd in.09_32 (_ bv1 32)) (bvadd in.09_32 (_ bv1 32))) true))))))
(check-sat)
; query 15: function kernel_deriche, block 79, name %80
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x140 (and (distinct (bvsub ((_ sign_extend 1) in1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvsub in1_32 (_ bv1 32)))) true)))
(let (($x181 (or false false (or $x140))))
(and (not $x181) (or $x181 (and (distinct (bvsub in1_32 (_ bv1 32)) (bvsub in1_32 (_ bv1 32))) true))))))
(check-sat)
; query 16: function polybench_flush_cache, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x149 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x151 (or false false (or $x149))))
(and (not $x151) (or $x151 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 17: function print_array, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x50 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x11 (or false false (or $x50))))
(and (not $x11) (or $x11 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 18: function print_array, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x149 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x151 (or false false (or $x149))))
(and (not $x151) (or $x151 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 19: function xmalloc, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in7_32 () (_ BitVec 32))
(assert
 (let ((?x147 (ite (and (distinct (_ bv0 32) in7_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x423 (or false false false)))
(and (not $x423) (or $x423 (and (distinct ?x147 ?x147) true))))))
(check-sat)
