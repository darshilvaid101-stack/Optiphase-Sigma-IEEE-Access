; OptiPhase-Sigma refinement certificate for sweep K58-R5-409
; query 0: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x407 (or false false false)))
(let (($x166 (not $x407)))
(and $x166 (or $x407 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x701 (bvadd in.01_32 (_ bv1 32))))
(let ((?x586 (bvmul ?x701 ?x701)))
(let (($x407 (or false false false)))
(let (($x47 (or $x407 $x407 false)))
(and (not $x47) (or $x47 (and (distinct ?x586 ?x586) true))))))))
(check-sat)
; query 2: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x674 (and (distinct (bvmul (bvmul (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) (_ bv2 32)) (bvshl (bvmul (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) (_ bv3 32))) true)))
(let (($x407 (or false false false)))
(let (($x47 (or $x407 $x407 false)))
(let (($x1536 (or $x47 false false)))
(and (not $x1536) (or (or $x1536 (bvuge (_ bv3 32) (_ bv32 32))) $x674)))))))
(check-sat)
; query 3: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x57 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x407 (or false false false)))
(let (($x166 (not $x407)))
(and $x166 (or $x407 (and (distinct ?x57 ?x57) true)))))))
(check-sat)
; query 4: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x317 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x407 (or false false false)))
(let (($x166 (not $x407)))
(and $x166 (or $x407 (and (distinct ?x317 ?x317) true)))))))
(check-sat)
