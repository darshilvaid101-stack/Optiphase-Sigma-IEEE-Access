; OptiPhase-Sigma refinement certificate for sweep K21-R1-003
