; OptiPhase-Sigma refinement certificate for sweep K07-R1-002
