; OptiPhase-Sigma refinement certificate for sweep K18-R3-158
