; OptiPhase-Sigma refinement certificate for sweep K53-R6-008
; query 0: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x293 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x77 (or false false false)))
(and (not $x77) (or $x77 (and (distinct ?x293 ?x293) true))))))
(check-sat)
