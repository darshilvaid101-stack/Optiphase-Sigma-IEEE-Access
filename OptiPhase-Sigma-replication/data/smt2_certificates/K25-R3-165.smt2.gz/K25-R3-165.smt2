; OptiPhase-Sigma refinement certificate for sweep K25-R3-165
; query 0: function xmalloc, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in7_32 () (_ BitVec 32))
(assert
 (let ((?x119 (ite (and (distinct (_ bv0 32) in7_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x43 (or false false false)))
(and (not $x43) (or $x43 (and (distinct ?x119 ?x119) true))))))
(check-sat)
