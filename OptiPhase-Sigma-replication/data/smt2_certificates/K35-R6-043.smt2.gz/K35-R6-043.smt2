; OptiPhase-Sigma refinement certificate for sweep K35-R6-043
; query 0: function edge_draw, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let ((?x64 (ite (= (_ bv0 32) in4_32) (_ bv1 1) (_ bv0 1))))
(let (($x117 (or false false false)))
(let (($x613 (not $x117)))
(and $x613 (or $x117 (and (distinct ?x64 ?x64) true)))))))
(check-sat)
; query 1: function getint, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x246 (and (distinct (ite (bvsle (_ bv48 32) in.02_32) (_ bv1 1) (_ bv0 1)) (ite (bvsgt (_ bv58 32) in.02_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x117 (or false false false)))
(let (($x613 (not $x117)))
(and $x613 (or $x117 $x246))))))
(check-sat)
