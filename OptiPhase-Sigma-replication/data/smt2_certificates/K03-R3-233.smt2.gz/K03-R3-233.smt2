; OptiPhase-Sigma refinement certificate for sweep K03-R3-233
