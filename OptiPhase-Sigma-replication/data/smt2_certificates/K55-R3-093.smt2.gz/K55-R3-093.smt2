; OptiPhase-Sigma refinement certificate for sweep K55-R3-093
; query 0: function core_bench_state, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x53 (bvadd in.0_32 (_ bv1 32))))
(let (($x17 (and (distinct ?x53 ?x53) true)))
(let (($x1813 (and (distinct (bvadd ((_ zero_extend 1) in.0_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) ?x53)) true)))
(let (($x820 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x53)) true)))
(let (($x161 (or false false false)))
(let (($x49 (not $x161)))
(and $x49 (or (or false false (or $x820 $x1813)) $x17)))))))))
(check-sat)
; query 1: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x161 (or false false false)))
(let (($x49 (not $x161)))
(and $x49 (or $x161 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x77 (bvadd in.01_32 (_ bv1 32))))
(let ((?x176 (bvmul ?x77 ?x77)))
(let (($x161 (or false false false)))
(let (($x83 (or $x161 $x161 false)))
(and (not $x83) (or $x83 (and (distinct ?x176 ?x176) true))))))))
(check-sat)
; query 3: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x623 (and (distinct (bvmul (bvmul (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) (_ bv2 32)) (bvshl (bvmul (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) (_ bv3 32))) true)))
(let (($x161 (or false false false)))
(let (($x83 (or $x161 $x161 false)))
(let (($x151 (or $x83 false false)))
(and (not $x151) (or (or $x151 (bvuge (_ bv3 32) (_ bv32 32))) $x623)))))))
(check-sat)
; query 4: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x849 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x161 (or false false false)))
(let (($x49 (not $x161)))
(and $x49 (or $x161 (and (distinct ?x849 ?x849) true)))))))
(check-sat)
; query 5: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x161 (or false false false)))
(let (($x49 (not $x161)))
(and $x49 (or $x161 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 6: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x602 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x161 (or false false false)))
(let (($x49 (not $x161)))
(and $x49 (or $x161 (and (distinct ?x602 ?x602) true)))))))
(check-sat)
; query 7: function matrix_mul_const, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x53 (bvadd in.0_32 (_ bv1 32))))
(let (($x17 (and (distinct ?x53 ?x53) true)))
(let (($x161 (or false false false)))
(let (($x49 (not $x161)))
(and $x49 (or $x161 $x17)))))))
(check-sat)
; query 8: function matrix_mul_const, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x161 (or false false false)))
(let (($x49 (not $x161)))
(and $x49 (or $x161 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 9: function matrix_mul_matrix, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x53 (bvadd in.0_32 (_ bv1 32))))
(let (($x17 (and (distinct ?x53 ?x53) true)))
(let (($x161 (or false false false)))
(let (($x49 (not $x161)))
(and $x49 (or $x161 $x17)))))))
(check-sat)
; query 10: function matrix_mul_matrix, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x161 (or false false false)))
(let (($x49 (not $x161)))
(and $x49 (or $x161 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 11: function matrix_mul_matrix, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x161 (or false false false)))
(let (($x49 (not $x161)))
(and $x49 (or $x161 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 12: function matrix_mul_matrix_bitextract, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x53 (bvadd in.0_32 (_ bv1 32))))
(let (($x17 (and (distinct ?x53 ?x53) true)))
(let (($x161 (or false false false)))
(let (($x49 (not $x161)))
(and $x49 (or $x161 $x17)))))))
(check-sat)
; query 13: function matrix_mul_matrix_bitextract, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x161 (or false false false)))
(let (($x49 (not $x161)))
(and $x49 (or $x161 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 14: function matrix_mul_matrix_bitextract, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x161 (or false false false)))
(let (($x49 (not $x161)))
(and $x49 (or $x161 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 15: function matrix_mul_vect, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x53 (bvadd in.0_32 (_ bv1 32))))
(let (($x17 (and (distinct ?x53 ?x53) true)))
(let (($x161 (or false false false)))
(let (($x49 (not $x161)))
(and $x49 (or $x161 $x17)))))))
(check-sat)
; query 16: function matrix_mul_vect, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x161 (or false false false)))
(let (($x49 (not $x161)))
(and $x49 (or $x161 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
