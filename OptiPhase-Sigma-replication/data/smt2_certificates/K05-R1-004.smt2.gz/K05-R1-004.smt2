; OptiPhase-Sigma refinement certificate for sweep K05-R1-004
