; OptiPhase-Sigma refinement certificate for sweep K36-R2-068
; query 0: function dijkstra, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x252 (ite (= in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x413 (or false false false)))
(and (not $x413) (or $x413 (and (distinct ?x252 ?x252) true))))))
(check-sat)
; query 1: function main, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x618 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x100 (or false false (or $x618))))
(and (not $x100) (or $x100 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function main, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x93 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x620 (or false false (or $x93))))
(and (not $x620) (or $x620 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 3: function main, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x701 (and (distinct (bvadd ((_ sign_extend 1) in.12_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.12_32 (_ bv1 32)))) true)))
(let (($x276 (or false false (or $x701))))
(and (not $x276) (or $x276 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 4: function main, block 37, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in35_32 () (_ BitVec 32))
(assert
 (let (($x48 (and (distinct (bvadd ((_ sign_extend 1) in35_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in35_32 (_ bv1 32)))) true)))
(let (($x12 (or false false (or $x48))))
(and (not $x12) (or $x12 (and (distinct (bvadd in35_32 (_ bv1 32)) (bvadd in35_32 (_ bv1 32))) true))))))
(check-sat)
