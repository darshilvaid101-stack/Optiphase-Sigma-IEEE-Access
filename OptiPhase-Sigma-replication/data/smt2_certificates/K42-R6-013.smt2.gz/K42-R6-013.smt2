; OptiPhase-Sigma refinement certificate for sweep K42-R6-013
