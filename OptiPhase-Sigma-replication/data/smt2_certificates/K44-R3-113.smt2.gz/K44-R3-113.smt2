; OptiPhase-Sigma refinement certificate for sweep K44-R3-113
; query 0: function Index_to_frequency, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x450 (ite (bvuge in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x249 (or false false false)))
(let (($x99 (not $x249)))
(and $x99 (or $x249 (and (distinct ?x450 ?x450) true)))))))
(check-sat)
; query 1: function IsPowerOfTwo, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x250 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x249 (or false false false)))
(let (($x99 (not $x249)))
(and $x99 (or $x249 (and (distinct ?x250 ?x250) true)))))))
(check-sat)
; query 2: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x250 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x249 (or false false false)))
(let (($x99 (not $x249)))
(and $x99 (or $x249 (and (distinct ?x250 ?x250) true)))))))
(check-sat)
; query 3: function main, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x119 (ite (= (_ bv4 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x249 (or false false false)))
(let (($x99 (not $x249)))
(and $x99 (or $x249 (and (distinct ?x119 ?x119) true)))))))
(check-sat)
; query 4: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x853 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x249 (or false false false)))
(let (($x99 (not $x249)))
(and $x99 (or $x249 (and (distinct ?x853 ?x853) true)))))))
(check-sat)
