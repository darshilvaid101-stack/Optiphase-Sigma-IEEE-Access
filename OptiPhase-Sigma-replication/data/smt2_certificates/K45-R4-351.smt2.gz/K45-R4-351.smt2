; OptiPhase-Sigma refinement certificate for sweep K45-R4-351
; query 0: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x168 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x128 (or false false false)))
(let (($x134 (not $x128)))
(and $x134 (or $x128 (and (distinct ?x168 ?x168) true)))))))
(check-sat)
; query 1: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x69 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x128 (or false false false)))
(let (($x134 (not $x128)))
(and $x134 (or $x128 (and (distinct ?x69 ?x69) true)))))))
(check-sat)
