; OptiPhase-Sigma refinement certificate for sweep K41-R3-195
; query 0: function decfile, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in17_32 () (_ BitVec 32))
(assert
 (let ((?x220 (ite (and (distinct (_ bv16 32) in17_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x192 (or false false false)))
(let (($x49 (not $x192)))
(and $x49 (or $x192 (and (distinct ?x220 ?x220) true)))))))
(check-sat)
; query 1: function fillrand, block 34, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x64 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x40 (or false false (or $x64))))
(and (not $x40) (or $x40 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function main, block 41, name %42
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let (($x685 (or false false)))
(and (not $x685) (or $x685 (and (distinct ((_ sign_extend 24) in38_8) ((_ sign_extend 24) in38_8)) true)))))
(check-sat)
; query 3: function main, block 41, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let ((?x139 (ite (bvsge (_ bv57 32) ((_ sign_extend 24) in38_8)) (_ bv1 1) (_ bv0 1))))
(let (($x685 (or false false)))
(let (($x140 (or $x685 false false)))
(let (($x467 (not $x140)))
(and $x467 (or $x140 (and (distinct ?x139 ?x139) true))))))))
(check-sat)
; query 4: function main, block 44, name %45
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x192 (or false false false)))
(let (($x32 (or $x192 (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x32) (or $x32 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvshl in.01_32 (_ bv4 32))) true))))))
(check-sat)
; query 5: function main, block 44, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let (($x685 (or false false)))
(and (not $x685) (or $x685 (and (distinct ((_ sign_extend 24) in38_8) ((_ sign_extend 24) in38_8)) true)))))
(check-sat)
; query 6: function main, block 44, name %47
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x51 ((_ sign_extend 24) in38_8)))
(let ((?x190 (bvshl in.01_32 (_ bv4 32))))
(let ((?x128 (bvadd ?x190 ?x51)))
(let ((?x77 ((_ sign_extend 1) ?x128)))
(let (($x685 (or false false)))
(let (($x192 (or false false false)))
(let (($x32 (or $x192 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x52 (or $x32 $x685 (or (and (distinct (bvadd ((_ sign_extend 1) ?x190) ((_ sign_extend 1) ?x51)) ?x77) true)))))
(and (not $x52) (or $x52 (and (distinct ?x128 ?x128) true))))))))))))
(check-sat)
; query 7: function main, block 44, name %48
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x51 ((_ sign_extend 24) in38_8)))
(let ((?x190 (bvshl in.01_32 (_ bv4 32))))
(let ((?x128 (bvadd ?x190 ?x51)))
(let ((?x1055 (bvsub ?x128 (_ bv48 32))))
(let (($x234 (and (distinct (bvsub ((_ sign_extend 1) ?x128) ((_ sign_extend 1) (_ bv48 32))) ((_ sign_extend 1) ?x1055)) true)))
(let ((?x77 ((_ sign_extend 1) ?x128)))
(let (($x685 (or false false)))
(let (($x192 (or false false false)))
(let (($x32 (or $x192 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x52 (or $x32 $x685 (or (and (distinct (bvadd ((_ sign_extend 1) ?x190) ((_ sign_extend 1) ?x51)) ?x77) true)))))
(let (($x671 (or $x52 false (or $x234))))
(and (not $x671) (or $x671 (and (distinct ?x1055 ?x1055) true)))))))))))))))
(check-sat)
; query 8: function main, block 49, name %50
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let (($x685 (or false false)))
(and (not $x685) (or $x685 (and (distinct ((_ sign_extend 24) in38_8) ((_ sign_extend 24) in38_8)) true)))))
(check-sat)
; query 9: function main, block 49, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let ((?x228 (ite (bvsle (_ bv65 32) ((_ sign_extend 24) in38_8)) (_ bv1 1) (_ bv0 1))))
(let (($x685 (or false false)))
(let (($x140 (or $x685 false false)))
(let (($x467 (not $x140)))
(and $x467 (or $x140 (and (distinct ?x228 ?x228) true))))))))
(check-sat)
; query 10: function main, block 52, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let (($x685 (or false false)))
(and (not $x685) (or $x685 (and (distinct ((_ sign_extend 24) in38_8) ((_ sign_extend 24) in38_8)) true)))))
(check-sat)
; query 11: function main, block 52, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let ((?x83 (ite (bvsge (_ bv70 32) ((_ sign_extend 24) in38_8)) (_ bv1 1) (_ bv0 1))))
(let (($x685 (or false false)))
(let (($x140 (or $x685 false false)))
(let (($x467 (not $x140)))
(and $x467 (or $x140 (and (distinct ?x83 ?x83) true))))))))
(check-sat)
; query 12: function main, block 55, name %56
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x192 (or false false false)))
(let (($x32 (or $x192 (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x32) (or $x32 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvshl in.01_32 (_ bv4 32))) true))))))
(check-sat)
; query 13: function main, block 55, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let (($x685 (or false false)))
(and (not $x685) (or $x685 (and (distinct ((_ sign_extend 24) in38_8) ((_ sign_extend 24) in38_8)) true)))))
(check-sat)
; query 14: function main, block 55, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x51 ((_ sign_extend 24) in38_8)))
(let ((?x190 (bvshl in.01_32 (_ bv4 32))))
(let ((?x128 (bvadd ?x190 ?x51)))
(let ((?x77 ((_ sign_extend 1) ?x128)))
(let (($x685 (or false false)))
(let (($x192 (or false false false)))
(let (($x32 (or $x192 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x52 (or $x32 $x685 (or (and (distinct (bvadd ((_ sign_extend 1) ?x190) ((_ sign_extend 1) ?x51)) ?x77) true)))))
(and (not $x52) (or $x52 (and (distinct ?x128 ?x128) true))))))))))))
(check-sat)
; query 15: function main, block 55, name %59
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x51 ((_ sign_extend 24) in38_8)))
(let ((?x190 (bvshl in.01_32 (_ bv4 32))))
(let ((?x128 (bvadd ?x190 ?x51)))
(let ((?x121 (bvsub ?x128 (_ bv65 32))))
(let ((?x94 ((_ sign_extend 1) ?x121)))
(let ((?x77 ((_ sign_extend 1) ?x128)))
(let (($x685 (or false false)))
(let (($x192 (or false false false)))
(let (($x32 (or $x192 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x52 (or $x32 $x685 (or (and (distinct (bvadd ((_ sign_extend 1) ?x190) ((_ sign_extend 1) ?x51)) ?x77) true)))))
(let (($x231 (or $x52 false (or (and (distinct (bvsub ?x77 ((_ sign_extend 1) (_ bv65 32))) ?x94) true)))))
(and (not $x231) (or $x231 (and (distinct ?x121 ?x121) true)))))))))))))))
(check-sat)
; query 16: function main, block 55, name %60
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x51 ((_ sign_extend 24) in38_8)))
(let ((?x190 (bvshl in.01_32 (_ bv4 32))))
(let ((?x128 (bvadd ?x190 ?x51)))
(let ((?x121 (bvsub ?x128 (_ bv65 32))))
(let ((?x265 (bvadd ?x121 (_ bv10 32))))
(let (($x157 (and (distinct (bvadd ((_ sign_extend 1) ?x121) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x265)) true)))
(let ((?x94 ((_ sign_extend 1) ?x121)))
(let ((?x77 ((_ sign_extend 1) ?x128)))
(let (($x685 (or false false)))
(let (($x192 (or false false false)))
(let (($x32 (or $x192 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x52 (or $x32 $x685 (or (and (distinct (bvadd ((_ sign_extend 1) ?x190) ((_ sign_extend 1) ?x51)) ?x77) true)))))
(let (($x231 (or $x52 false (or (and (distinct (bvsub ?x77 ((_ sign_extend 1) (_ bv65 32))) ?x94) true)))))
(let (($x162 (or $x231 false (or $x157))))
(and (not $x162) (or $x162 (and (distinct ?x265 ?x265) true))))))))))))))))))
(check-sat)
; query 17: function set_key, block 11, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let (($x192 (or false false false)))
(let (($x49 (not $x192)))
(and $x49 (or $x192 (and (distinct (bvand in2_32 (_ bv1 32)) (bvand in2_32 (_ bv1 32))) true))))))
(check-sat)
; query 18: function set_key, block 11, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x226 (ite (and (distinct (_ bv0 32) (bvand in2_32 (_ bv1 32))) true) (_ bv1 1) (_ bv0 1))))
(let (($x192 (or false false false)))
(let (($x89 (or $x192 false false)))
(let (($x143 (not $x89)))
(and $x143 (or $x89 (and (distinct ?x226 ?x226) true))))))))
(check-sat)
; query 19: function set_key, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let (($x192 (or false false false)))
(let (($x49 (not $x192)))
(and $x49 (or $x192 (and (distinct (bvand in2_32 (_ bv2 32)) (bvand in2_32 (_ bv2 32))) true))))))
(check-sat)
; query 20: function set_key, block 14, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x183 (ite (and (distinct (_ bv0 32) (bvand in2_32 (_ bv2 32))) true) (_ bv1 1) (_ bv0 1))))
(let (($x192 (or false false false)))
(let (($x89 (or $x192 false false)))
(let (($x143 (not $x89)))
(and $x143 (or $x89 (and (distinct ?x183 ?x183) true))))))))
(check-sat)
; query 21: function set_key, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x656 (ite (and (distinct (_ bv0 64) in1_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x192 (or false false false)))
(let (($x49 (not $x192)))
(and $x49 (or $x192 (and (distinct ?x656 ?x656) true)))))))
(check-sat)
; query 22: function set_key, block 514, name %515
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_64 () (_ BitVec 64))
(assert
 (let (($x192 (or false false false)))
(let (($x49 (not $x192)))
(and $x49 (or $x192 (and (distinct (bvadd in.01_64 (_ bv1 64)) (bvadd in.01_64 (_ bv1 64))) true))))))
(check-sat)
; query 23: function set_key, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x397 (ite (bvult in1_64 (_ bv16 64)) (_ bv1 1) (_ bv0 1))))
(let (($x192 (or false false false)))
(let (($x49 (not $x192)))
(and $x49 (or $x192 (and (distinct ?x397 ?x397) true)))))))
(check-sat)
; query 24: function set_key, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x19 (ite (bvugt in1_64 (_ bv32 64)) (_ bv1 1) (_ bv0 1))))
(let (($x192 (or false false false)))
(let (($x49 (not $x192)))
(and $x49 (or $x192 (and (distinct ?x19 ?x19) true)))))))
(check-sat)
; query 25: function set_key, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let (($x192 (or false false false)))
(let (($x49 (not $x192)))
(and $x49 (or $x192 (and (distinct (bvand in1_64 (_ bv7 64)) (bvand in1_64 (_ bv7 64))) true))))))
(check-sat)
; query 26: function set_key, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x9 (ite (and (distinct (_ bv0 64) (bvand in1_64 (_ bv7 64))) true) (_ bv1 1) (_ bv0 1))))
(let (($x192 (or false false false)))
(let (($x89 (or $x192 false false)))
(let (($x143 (not $x89)))
(and $x143 (or $x89 (and (distinct ?x9 ?x9) true))))))))
(check-sat)
