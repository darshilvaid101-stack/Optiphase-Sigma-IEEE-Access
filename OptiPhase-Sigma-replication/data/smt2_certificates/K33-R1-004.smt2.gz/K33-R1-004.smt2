; OptiPhase-Sigma refinement certificate for sweep K33-R1-004
