; OptiPhase-Sigma refinement certificate for sweep K56-R3-293
; query 0: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x1742 (or false false)))
(let (($x404 (not $x1742)))
(and $x404 (or $x1742 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 1: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x533 ((_ sign_extend 16) in3_16)))
(let ((?x1429 (bvand ?x533 (_ bv127 32))))
(let (($x1742 (or false false)))
(let (($x24 (or $x1742 false false)))
(let (($x11 (not $x24)))
(and $x11 (or $x24 (and (distinct ?x1429 ?x1429) true)))))))))
(check-sat)
; query 2: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x533 ((_ sign_extend 16) in3_16)))
(let ((?x1429 (bvand ?x533 (_ bv127 32))))
(let ((?x656 ((_ extract 15 0) ?x1429)))
(let (($x1742 (or false false)))
(let (($x24 (or $x1742 false false)))
(let (($x1650 (or $x24 false)))
(let (($x99 (not $x1650)))
(and $x99 (or $x1650 (and (distinct ?x656 ?x656) true)))))))))))
(check-sat)
; query 3: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x1742 (or false false)))
(let (($x404 (not $x1742)))
(and $x404 (or $x1742 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 4: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x64 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x1742 (or false false)))
(let (($x24 (or $x1742 false false)))
(let (($x11 (not $x24)))
(and $x11 (or $x24 (and (distinct ?x64 ?x64) true))))))))
(check-sat)
; query 5: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x1835 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x157 (or false false false)))
(let (($x274 (not $x157)))
(and $x274 (or $x157 (and (distinct ?x1835 ?x1835) true)))))))
(check-sat)
; query 6: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x614 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x157 (or false false false)))
(let (($x274 (not $x157)))
(and $x274 (or $x157 (and (distinct ?x614 ?x614) true)))))))
(check-sat)
; query 7: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x157 (or false false false)))
(let (($x274 (not $x157)))
(and $x274 (or $x157 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 8: function crcu8, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x1742 (or false false)))
(let (($x404 (not $x1742)))
(and $x404 (or $x1742 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 9: function crcu8, block 19, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x1922 ((_ zero_extend 16) in.01_16)))
(let ((?x61 (bvxor ?x1922 (_ bv16386 32))))
(let (($x1742 (or false false)))
(let (($x24 (or $x1742 false false)))
(let (($x11 (not $x24)))
(and $x11 (or $x24 (and (distinct ?x61 ?x61) true)))))))))
(check-sat)
; query 10: function crcu8, block 19, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x1922 ((_ zero_extend 16) in.01_16)))
(let ((?x61 (bvxor ?x1922 (_ bv16386 32))))
(let ((?x91 ((_ extract 15 0) ?x61)))
(let (($x1742 (or false false)))
(let (($x24 (or $x1742 false false)))
(let (($x1650 (or $x24 false)))
(let (($x99 (not $x1650)))
(and $x99 (or $x1650 (and (distinct ?x91 ?x91) true)))))))))))
(check-sat)
; query 11: function crcu8, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x715 ((_ extract 7 0) in.01_16)))
(let ((?x1730 ((_ zero_extend 24) ?x715)))
(let (($x1742 (or false false)))
(let (($x700 (or $x1742 false)))
(and (not $x700) (or $x700 (and (distinct ?x1730 ?x1730) true))))))))
(check-sat)
; query 12: function crcu8, block 6, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x715 ((_ extract 7 0) in.01_16)))
(let ((?x1730 ((_ zero_extend 24) ?x715)))
(let ((?x1832 (bvand ?x1730 (_ bv1 32))))
(let (($x1742 (or false false)))
(let (($x700 (or $x1742 false)))
(let (($x73 (or $x700 false false)))
(and (not $x73) (or $x73 (and (distinct ?x1832 ?x1832) true))))))))))
(check-sat)
; query 13: function crcu8, block 6, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x715 ((_ extract 7 0) in.01_16)))
(let ((?x1730 ((_ zero_extend 24) ?x715)))
(let ((?x1832 (bvand ?x1730 (_ bv1 32))))
(let ((?x290 ((_ zero_extend 24) in.0_8)))
(let ((?x790 (bvand ?x290 (_ bv1 32))))
(let ((?x304 (bvxor ?x790 ?x1832)))
(let (($x1742 (or false false)))
(let (($x700 (or $x1742 false)))
(let (($x73 (or $x700 false false)))
(let (($x24 (or $x1742 false false)))
(let (($x27 (or $x24 $x73 false)))
(and (not $x27) (or $x27 (and (distinct ?x304 ?x304) true)))))))))))))))
(check-sat)
; query 14: function crcu8, block 6, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x715 ((_ extract 7 0) in.01_16)))
(let ((?x1730 ((_ zero_extend 24) ?x715)))
(let ((?x1832 (bvand ?x1730 (_ bv1 32))))
(let ((?x290 ((_ zero_extend 24) in.0_8)))
(let ((?x790 (bvand ?x290 (_ bv1 32))))
(let ((?x304 (bvxor ?x790 ?x1832)))
(let ((?x245 ((_ extract 7 0) ?x304)))
(let (($x1742 (or false false)))
(let (($x700 (or $x1742 false)))
(let (($x73 (or $x700 false false)))
(let (($x24 (or $x1742 false false)))
(let (($x27 (or $x24 $x73 false)))
(let (($x1648 (or $x27 false)))
(and (not $x1648) (or $x1648 (and (distinct ?x245 ?x245) true)))))))))))))))))
(check-sat)
; query 15: function crcu8, block 6, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x1742 (or false false)))
(let (($x404 (not $x1742)))
(and $x404 (or $x1742 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 16: function crcu8, block 6, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x290 ((_ zero_extend 24) in.0_8)))
(let ((?x167 (bvashr ?x290 (_ bv1 32))))
(let (($x1742 (or false false)))
(let (($x24 (or $x1742 false false)))
(let (($x136 (or $x24 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not $x136) (or $x136 (and (distinct ?x167 ?x167) true)))))))))
(check-sat)
; query 17: function crcu8, block 6, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x290 ((_ zero_extend 24) in.0_8)))
(let ((?x167 (bvashr ?x290 (_ bv1 32))))
(let ((?x1951 ((_ extract 7 0) ?x167)))
(let (($x1742 (or false false)))
(let (($x24 (or $x1742 false false)))
(let (($x136 (or $x24 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x776 (or $x136 false)))
(and (not $x776) (or $x776 (and (distinct ?x1951 ?x1951) true)))))))))))
(check-sat)
; query 18: function crcu8, block 6, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x715 ((_ extract 7 0) in.01_16)))
(let ((?x1730 ((_ zero_extend 24) ?x715)))
(let ((?x1832 (bvand ?x1730 (_ bv1 32))))
(let ((?x290 ((_ zero_extend 24) in.0_8)))
(let ((?x790 (bvand ?x290 (_ bv1 32))))
(let ((?x304 (bvxor ?x790 ?x1832)))
(let ((?x245 ((_ extract 7 0) ?x304)))
(let ((?x1935 ((_ zero_extend 24) ?x245)))
(let (($x1742 (or false false)))
(let (($x700 (or $x1742 false)))
(let (($x73 (or $x700 false false)))
(let (($x24 (or $x1742 false false)))
(let (($x27 (or $x24 $x73 false)))
(let (($x1648 (or $x27 false)))
(let (($x1696 (or $x1648 false)))
(and (not $x1696) (or $x1696 (and (distinct ?x1935 ?x1935) true)))))))))))))))))))
(check-sat)
; query 19: function crcu8, block 6, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x715 ((_ extract 7 0) in.01_16)))
(let ((?x1730 ((_ zero_extend 24) ?x715)))
(let ((?x1832 (bvand ?x1730 (_ bv1 32))))
(let ((?x290 ((_ zero_extend 24) in.0_8)))
(let ((?x790 (bvand ?x290 (_ bv1 32))))
(let ((?x304 (bvxor ?x790 ?x1832)))
(let ((?x245 ((_ extract 7 0) ?x304)))
(let ((?x1935 ((_ zero_extend 24) ?x245)))
(let ((?x454 (ite (= (_ bv1 32) ?x1935) (_ bv1 1) (_ bv0 1))))
(let (($x1742 (or false false)))
(let (($x700 (or $x1742 false)))
(let (($x73 (or $x700 false false)))
(let (($x24 (or $x1742 false false)))
(let (($x27 (or $x24 $x73 false)))
(let (($x1648 (or $x27 false)))
(let (($x1696 (or $x1648 false)))
(let (($x46 (or $x1696 false false)))
(and (not $x46) (or $x46 (and (distinct ?x454 ?x454) true)))))))))))))))))))))
(check-sat)
; query 20: function crcu8, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x1742 (or false false)))
(let (($x404 (not $x1742)))
(and $x404 (or $x1742 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 21: function crcu8, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x290 ((_ zero_extend 24) in.0_8)))
(let ((?x790 (bvand ?x290 (_ bv1 32))))
(let (($x1742 (or false false)))
(let (($x24 (or $x1742 false false)))
(let (($x11 (not $x24)))
(and $x11 (or $x24 (and (distinct ?x790 ?x790) true)))))))))
(check-sat)
; query 22: function crcu8, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x1742 (or false false)))
(let (($x404 (not $x1742)))
(and $x404 (or $x1742 (and (distinct ((_ extract 7 0) in.01_16) ((_ extract 7 0) in.01_16)) true))))))
(check-sat)
; query 23: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1672 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x141 ((_ zero_extend 31) ?x1672)))
(let ((?x1666 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x447 ((_ zero_extend 31) ?x1666)))
(let ((?x941 (bvand ?x447 ?x141)))
(let ((?x1687 (ite (and (distinct (_ bv0 32) ?x941) true) (_ bv1 1) (_ bv0 1))))
(let ((?x10 ((_ zero_extend 63) ?x1687)))
(let (($x1742 (or false false)))
(let (($x24 (or $x1742 false false)))
(let (($x1650 (or $x24 false)))
(let (($x1677 (or $x1650 $x1650 false)))
(let (($x1746 (or $x1677 false false)))
(let (($x1688 (or $x1746 false)))
(and (not $x1688) (or $x1688 (and (distinct ?x10 ?x10) true)))))))))))))))))
(check-sat)
; query 24: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1672 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x141 ((_ zero_extend 31) ?x1672)))
(let ((?x1666 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x447 ((_ zero_extend 31) ?x1666)))
(let ((?x941 (bvand ?x447 ?x141)))
(let ((?x1687 (ite (and (distinct (_ bv0 32) ?x941) true) (_ bv1 1) (_ bv0 1))))
(let (($x125 (= (_ bv1 1) ?x1687)))
(let ((?x1694 (ite $x125 (_ bv1 32) (_ bv0 32))))
(let (($x1742 (or false false)))
(let (($x24 (or $x1742 false false)))
(let (($x1650 (or $x24 false)))
(let (($x1677 (or $x1650 $x1650 false)))
(let (($x1746 (or $x1677 false false)))
(let (($x1719 (or $x1746 (ite $x125 false false))))
(and (not $x1719) (or $x1719 (and (distinct ?x1694 ?x1694) true))))))))))))))))))
(check-sat)
; query 25: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1672 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x141 ((_ zero_extend 31) ?x1672)))
(let ((?x1666 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x447 ((_ zero_extend 31) ?x1666)))
(let ((?x941 (bvand ?x447 ?x141)))
(let ((?x1687 (ite (and (distinct (_ bv0 32) ?x941) true) (_ bv1 1) (_ bv0 1))))
(let (($x125 (= (_ bv1 1) ?x1687)))
(let ((?x1694 (ite $x125 (_ bv1 32) (_ bv0 32))))
(let ((?x801 ((_ extract 7 0) ?x1694)))
(let (($x1742 (or false false)))
(let (($x24 (or $x1742 false false)))
(let (($x1650 (or $x24 false)))
(let (($x1677 (or $x1650 $x1650 false)))
(let (($x1746 (or $x1677 false false)))
(let (($x1719 (or $x1746 (ite $x125 false false))))
(let (($x1724 (or $x1719 false)))
(and (not $x1724) (or $x1724 (and (distinct ?x801 ?x801) true))))))))))))))))))))
(check-sat)
; query 26: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x1742 (or false false)))
(let (($x404 (not $x1742)))
(and $x404 (or $x1742 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 27: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1666 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1742 (or false false)))
(let (($x24 (or $x1742 false false)))
(let (($x11 (not $x24)))
(and $x11 (or $x24 (and (distinct ?x1666 ?x1666) true))))))))
(check-sat)
; query 28: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1666 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x447 ((_ zero_extend 31) ?x1666)))
(let (($x1742 (or false false)))
(let (($x24 (or $x1742 false false)))
(let (($x1650 (or $x24 false)))
(let (($x99 (not $x1650)))
(and $x99 (or $x1650 (and (distinct ?x447 ?x447) true))))))))))
(check-sat)
; query 29: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x1742 (or false false)))
(let (($x404 (not $x1742)))
(and $x404 (or $x1742 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 30: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1672 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1742 (or false false)))
(let (($x24 (or $x1742 false false)))
(let (($x11 (not $x24)))
(and $x11 (or $x24 (and (distinct ?x1672 ?x1672) true))))))))
(check-sat)
; query 31: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1672 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x141 ((_ zero_extend 31) ?x1672)))
(let (($x1742 (or false false)))
(let (($x24 (or $x1742 false false)))
(let (($x1650 (or $x24 false)))
(let (($x99 (not $x1650)))
(and $x99 (or $x1650 (and (distinct ?x141 ?x141) true))))))))))
(check-sat)
; query 32: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1672 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x141 ((_ zero_extend 31) ?x1672)))
(let ((?x1666 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x447 ((_ zero_extend 31) ?x1666)))
(let ((?x941 (bvand ?x447 ?x141)))
(let (($x1742 (or false false)))
(let (($x24 (or $x1742 false false)))
(let (($x1650 (or $x24 false)))
(let (($x1677 (or $x1650 $x1650 false)))
(and (not $x1677) (or $x1677 (and (distinct ?x941 ?x941) true)))))))))))))
(check-sat)
; query 33: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1672 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x141 ((_ zero_extend 31) ?x1672)))
(let ((?x1666 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x447 ((_ zero_extend 31) ?x1666)))
(let ((?x941 (bvand ?x447 ?x141)))
(let ((?x1687 (ite (and (distinct (_ bv0 32) ?x941) true) (_ bv1 1) (_ bv0 1))))
(let (($x1742 (or false false)))
(let (($x24 (or $x1742 false false)))
(let (($x1650 (or $x24 false)))
(let (($x1677 (or $x1650 $x1650 false)))
(let (($x1746 (or $x1677 false false)))
(and (not $x1746) (or $x1746 (and (distinct ?x1687 ?x1687) true)))))))))))))))
(check-sat)
; query 34: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x406 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x157 (or false false false)))
(let (($x274 (not $x157)))
(and $x274 (or $x157 (and (distinct ?x406 ?x406) true)))))))
(check-sat)
