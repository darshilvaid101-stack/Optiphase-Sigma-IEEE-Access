; OptiPhase-Sigma refinement certificate for sweep K51-R4-319
; query 0: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x21 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x1568 (or false false false)))
(and (not $x1568) (or $x1568 (and (distinct ?x21 ?x21) true))))))
(check-sat)
