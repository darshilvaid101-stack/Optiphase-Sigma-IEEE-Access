; OptiPhase-Sigma refinement certificate for sweep K46-R3-263
; query 0: function adpcm_decoder, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x39 (ite (and (distinct (_ bv0 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x71 (or false false false)))
(let (($x448 (not $x71)))
(and $x448 (or $x71 (and (distinct ?x39 ?x39) true)))))))
(check-sat)
; query 1: function adpcm_decoder, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x71 (or false false false)))
(let (($x448 (not $x71)))
(and $x448 (or $x71 (and (distinct (bvand in.01_32 (_ bv15 32)) (bvand in.01_32 (_ bv15 32))) true))))))
(check-sat)
; query 2: function main, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x18 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x71 (or false false false)))
(let (($x448 (not $x71)))
(and $x448 (or $x71 (and (distinct ?x18 ?x18) true)))))))
(check-sat)
