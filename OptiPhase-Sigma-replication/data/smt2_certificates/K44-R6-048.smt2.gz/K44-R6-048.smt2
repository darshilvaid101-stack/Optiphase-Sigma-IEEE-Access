; OptiPhase-Sigma refinement certificate for sweep K44-R6-048
; query 0: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x71 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x122 (or false false false)))
(let (($x15 (not $x122)))
(and $x15 (or $x122 (and (distinct ?x71 ?x71) true)))))))
(check-sat)
; query 1: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x120 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x122 (or false false false)))
(let (($x15 (not $x122)))
(and $x15 (or $x122 (and (distinct ?x120 ?x120) true)))))))
(check-sat)
