; OptiPhase-Sigma refinement certificate for sweep K55-R2-083
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x1573 (or false false)))
(let (($x1473 (not $x1573)))
(and $x1473 (or $x1573 (and (distinct ((_ sign_extend 16) in25_16) ((_ sign_extend 16) in25_16)) true))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let ((?x58 (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1573 (or false false)))
(let (($x622 (or $x1573 false false)))
(let (($x1161 (not $x622)))
(and $x1161 (or $x622 (and (distinct ?x58 ?x58) true))))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x1573 (or false false)))
(let (($x1473 (not $x1573)))
(and $x1473 (or $x1573 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x1934 ((_ sign_extend 16) in3_16)))
(let ((?x2057 (bvand ?x1934 (_ bv127 32))))
(let (($x1573 (or false false)))
(let (($x622 (or $x1573 false false)))
(let (($x1161 (not $x622)))
(and $x1161 (or $x622 (and (distinct ?x2057 ?x2057) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x1934 ((_ sign_extend 16) in3_16)))
(let ((?x2057 (bvand ?x1934 (_ bv127 32))))
(let ((?x707 ((_ extract 15 0) ?x2057)))
(let (($x1573 (or false false)))
(let (($x622 (or $x1573 false false)))
(let (($x360 (or $x622 false)))
(let (($x1374 (not $x360)))
(and $x1374 (or $x360 (and (distinct ?x707 ?x707) true)))))))))))
(check-sat)
; query 5: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x1573 (or false false)))
(let (($x1473 (not $x1573)))
(and $x1473 (or $x1573 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 6: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x88 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x1573 (or false false)))
(let (($x622 (or $x1573 false false)))
(let (($x1161 (not $x622)))
(and $x1161 (or $x622 (and (distinct ?x88 ?x88) true))))))))
(check-sat)
; query 7: function core_bench_list, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x1599 (or false false false)))
(let (($x1042 (not $x1599)))
(and $x1042 (or $x1599 (and (distinct (bvadd in.0_16 (_ bv1 16)) (bvadd in.0_16 (_ bv1 16))) true))))))
(check-sat)
; query 8: function core_bench_list, block 82, name %83
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let (($x1573 (or false false)))
(let (($x1473 (not $x1573)))
(and $x1473 (or $x1573 (and (distinct ((_ zero_extend 16) in.02_16) ((_ zero_extend 16) in.02_16)) true))))))
(check-sat)
; query 9: function core_bench_list, block 82, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x38 ((_ zero_extend 16) in.02_16)))
(let ((?x813 (bvmul ?x38 (_ bv4 32))))
(let (($x1217 (and (distinct (bvmul ((_ sign_extend 32) ?x38) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x813)) true)))
(let (($x1573 (or false false)))
(let (($x849 (or $x1573 false (or $x1217))))
(and (not $x849) (or $x849 (and (distinct ?x813 ?x813) true)))))))))
(check-sat)
; query 10: function core_bench_list, block 82, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let (($x1573 (or false false)))
(let (($x1473 (not $x1573)))
(and $x1473 (or $x1573 (and (distinct ((_ zero_extend 16) in.04_16) ((_ zero_extend 16) in.04_16)) true))))))
(check-sat)
; query 11: function core_bench_list, block 82, name %86
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x366 ((_ zero_extend 16) in.04_16)))
(let ((?x38 ((_ zero_extend 16) in.02_16)))
(let ((?x813 (bvmul ?x38 (_ bv4 32))))
(let ((?x789 (bvsub ?x813 ?x366)))
(let ((?x132 ((_ sign_extend 1) ?x789)))
(let (($x1573 (or false false)))
(let (($x1217 (and (distinct (bvmul ((_ sign_extend 32) ?x38) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x813)) true)))
(let (($x849 (or $x1573 false (or $x1217))))
(let (($x86 (or $x849 $x1573 (or (and (distinct (bvsub ((_ sign_extend 1) ?x813) ((_ sign_extend 1) ?x366)) ?x132) true)))))
(and (not $x86) (or $x86 (and (distinct ?x789 ?x789) true)))))))))))))
(check-sat)
; query 12: function core_bench_list, block 82, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x1573 (or false false)))
(let (($x1473 (not $x1573)))
(and $x1473 (or $x1573 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 13: function core_bench_list, block 82, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x366 ((_ zero_extend 16) in.04_16)))
(let ((?x38 ((_ zero_extend 16) in.02_16)))
(let ((?x813 (bvmul ?x38 (_ bv4 32))))
(let ((?x789 (bvsub ?x813 ?x366)))
(let ((?x660 ((_ zero_extend 16) in.01_16)))
(let ((?x1469 (bvadd ?x660 ?x789)))
(let (($x28 (and (distinct (bvadd ((_ sign_extend 1) ?x660) ((_ sign_extend 1) ?x789)) ((_ sign_extend 1) ?x1469)) true)))
(let ((?x132 ((_ sign_extend 1) ?x789)))
(let (($x1573 (or false false)))
(let (($x1217 (and (distinct (bvmul ((_ sign_extend 32) ?x38) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x813)) true)))
(let (($x849 (or $x1573 false (or $x1217))))
(let (($x86 (or $x849 $x1573 (or (and (distinct (bvsub ((_ sign_extend 1) ?x813) ((_ sign_extend 1) ?x366)) ?x132) true)))))
(let (($x2402 (or $x1573 $x86 (or $x28))))
(and (not $x2402) (or $x2402 (and (distinct ?x1469 ?x1469) true)))))))))))))))))
(check-sat)
; query 14: function core_bench_list, block 82, name %89
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x366 ((_ zero_extend 16) in.04_16)))
(let ((?x38 ((_ zero_extend 16) in.02_16)))
(let ((?x813 (bvmul ?x38 (_ bv4 32))))
(let ((?x789 (bvsub ?x813 ?x366)))
(let ((?x660 ((_ zero_extend 16) in.01_16)))
(let ((?x1469 (bvadd ?x660 ?x789)))
(let ((?x239 ((_ extract 15 0) ?x1469)))
(let (($x28 (and (distinct (bvadd ((_ sign_extend 1) ?x660) ((_ sign_extend 1) ?x789)) ((_ sign_extend 1) ?x1469)) true)))
(let ((?x132 ((_ sign_extend 1) ?x789)))
(let (($x1573 (or false false)))
(let (($x1217 (and (distinct (bvmul ((_ sign_extend 32) ?x38) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x813)) true)))
(let (($x849 (or $x1573 false (or $x1217))))
(let (($x86 (or $x849 $x1573 (or (and (distinct (bvsub ((_ sign_extend 1) ?x813) ((_ sign_extend 1) ?x366)) ?x132) true)))))
(let (($x2402 (or $x1573 $x86 (or $x28))))
(let (($x151 (or $x2402 false)))
(and (not $x151) (or $x151 (and (distinct ?x239 ?x239) true)))))))))))))))))))
(check-sat)
; query 15: function core_bench_list, block 82, name %90
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x1573 (or false false)))
(let (($x1473 (not $x1573)))
(and $x1473 (or $x1573 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 16: function core_bench_list, block 82, name %91
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x99 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1573 (or false false)))
(let (($x622 (or $x1573 false false)))
(let (($x1161 (not $x622)))
(and $x1161 (or $x622 (and (distinct ?x99 ?x99) true))))))))
(check-sat)
; query 17: function core_bench_state, block 105, name %106
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x1599 (or false false false)))
(let (($x1042 (not $x1599)))
(and $x1042 (or $x1599 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 18: function core_bench_state, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1599 (or false false false)))
(let (($x1042 (not $x1599)))
(and $x1042 (or $x1599 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 19: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x450 (bvadd in.01_32 (_ bv1 32))))
(let (($x583 (and (distinct ?x450 ?x450) true)))
(let (($x1599 (or false false false)))
(let (($x1042 (not $x1599)))
(and $x1042 (or $x1599 $x583)))))))
(check-sat)
; query 20: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x450 (bvadd in.01_32 (_ bv1 32))))
(let ((?x1568 (bvmul ?x450 ?x450)))
(let (($x1599 (or false false false)))
(let (($x328 (or $x1599 $x1599 false)))
(and (not $x328) (or $x328 (and (distinct ?x1568 ?x1568) true))))))))
(check-sat)
; query 21: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x450 (bvadd in.01_32 (_ bv1 32))))
(let ((?x1568 (bvmul ?x450 ?x450)))
(let ((?x1003 (bvmul ?x1568 (_ bv2 32))))
(let (($x1599 (or false false false)))
(let (($x328 (or $x1599 $x1599 false)))
(let (($x788 (or $x328 false false)))
(and (not $x788) (or $x788 (and (distinct ?x1003 ?x1003) true))))))))))
(check-sat)
; query 22: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x450 (bvadd in.01_32 (_ bv1 32))))
(let ((?x1568 (bvmul ?x450 ?x450)))
(let ((?x1003 (bvmul ?x1568 (_ bv2 32))))
(let ((?x2081 (bvmul ?x1003 (_ bv4 32))))
(let (($x1599 (or false false false)))
(let (($x328 (or $x1599 $x1599 false)))
(let (($x788 (or $x328 false false)))
(let (($x965 (or $x788 false false)))
(and (not $x965) (or $x965 (and (distinct ?x2081 ?x2081) true))))))))))))
(check-sat)
; query 23: function core_init_matrix, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x1599 (or false false false)))
(let (($x1042 (not $x1599)))
(and $x1042 (or $x1599 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 24: function core_init_matrix, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x1599 (or false false false)))
(let (($x1042 (not $x1599)))
(and $x1042 (or $x1599 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 25: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x1139 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x1599 (or false false false)))
(let (($x1042 (not $x1599)))
(and $x1042 (or $x1599 (and (distinct ?x1139 ?x1139) true)))))))
(check-sat)
; query 26: function core_init_state, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_32 () (_ BitVec 32))
(assert
 (let (($x1599 (or false false false)))
(let (($x1042 (not $x1599)))
(and $x1042 (or $x1599 (and (distinct (bvadd in.06_32 (_ bv1 32)) (bvadd in.06_32 (_ bv1 32))) true))))))
(check-sat)
; query 27: function core_init_state, block 65, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let (($x1599 (or false false false)))
(let (($x1042 (not $x1599)))
(and $x1042 (or $x1599 (and (distinct (bvadd in4_32 (_ bv1 32)) (bvadd in4_32 (_ bv1 32))) true))))))
(check-sat)
; query 28: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x343 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x1599 (or false false false)))
(let (($x1042 (not $x1599)))
(and $x1042 (or $x1599 (and (distinct ?x343 ?x343) true)))))))
(check-sat)
; query 29: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x1599 (or false false false)))
(let (($x1042 (not $x1599)))
(and $x1042 (or $x1599 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 30: function core_list_init, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x450 (bvadd in.01_32 (_ bv1 32))))
(let (($x583 (and (distinct ?x450 ?x450) true)))
(let (($x1599 (or false false false)))
(let (($x1042 (not $x1599)))
(and $x1042 (or $x1599 $x583)))))))
(check-sat)
; query 31: function core_list_mergesort, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x450 (bvadd in.01_32 (_ bv1 32))))
(let (($x583 (and (distinct ?x450 ?x450) true)))
(let (($x121 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x450)) true)))
(let (($x542 (or false false (or $x121))))
(and (not $x542) (or $x542 $x583)))))))
(check-sat)
; query 32: function core_list_mergesort, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x372 (ite (bvslt (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x1599 (or false false false)))
(let (($x1042 (not $x1599)))
(and $x1042 (or $x1599 (and (distinct ?x372 ?x372) true)))))))
(check-sat)
; query 33: function core_list_mergesort, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.224_32 () (_ BitVec 32))
(assert
 (let ((?x131 (ite (= (_ bv0 32) in.224_32) (_ bv1 1) (_ bv0 1))))
(let (($x1599 (or false false false)))
(let (($x1042 (not $x1599)))
(and $x1042 (or $x1599 (and (distinct ?x131 ?x131) true)))))))
(check-sat)
; query 34: function core_list_mergesort, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x1483 (ite (= (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x1599 (or false false false)))
(let (($x1042 (not $x1599)))
(and $x1042 (or $x1599 (and (distinct ?x1483 ?x1483) true)))))))
(check-sat)
; query 35: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x634 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x267 (or false false (or $x634))))
(and (not $x267) (or $x267 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 36: function core_list_mergesort, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x1942 (and (distinct (bvmul ((_ sign_extend 32) in.020_32) ((_ sign_extend 32) (_ bv2 32))) ((_ sign_extend 32) (bvmul in.020_32 (_ bv2 32)))) true)))
(let (($x2074 (or false false (or $x1942))))
(and (not $x2074) (or $x2074 (and (distinct (bvmul in.020_32 (_ bv2 32)) (bvmul in.020_32 (_ bv2 32))) true))))))
(check-sat)
; query 37: function core_state_transition, block 102, name %103
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1573 (or false false)))
(let (($x1473 (not $x1573)))
(and $x1473 (or $x1573 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 38: function core_state_transition, block 102, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x341 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1573 (or false false)))
(let (($x622 (or $x1573 false false)))
(let (($x1161 (not $x622)))
(and $x1161 (or $x622 (and (distinct ?x341 ?x341) true))))))))
(check-sat)
; query 39: function core_state_transition, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1573 (or false false)))
(let (($x1473 (not $x1573)))
(and $x1473 (or $x1573 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 40: function core_state_transition, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x2189 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1573 (or false false)))
(let (($x622 (or $x1573 false false)))
(let (($x1161 (not $x622)))
(and $x1161 (or $x622 (and (distinct ?x2189 ?x2189) true))))))))
(check-sat)
; query 41: function core_state_transition, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1573 (or false false)))
(let (($x1473 (not $x1573)))
(and $x1473 (or $x1573 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 42: function core_state_transition, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x341 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1573 (or false false)))
(let (($x622 (or $x1573 false false)))
(let (($x1161 (not $x622)))
(and $x1161 (or $x622 (and (distinct ?x341 ?x341) true))))))))
(check-sat)
; query 43: function core_state_transition, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1573 (or false false)))
(let (($x1473 (not $x1573)))
(and $x1473 (or $x1573 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 44: function core_state_transition, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1917 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1573 (or false false)))
(let (($x622 (or $x1573 false false)))
(let (($x1161 (not $x622)))
(and $x1161 (or $x622 (and (distinct ?x1917 ?x1917) true))))))))
(check-sat)
; query 45: function core_state_transition, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1573 (or false false)))
(let (($x1473 (not $x1573)))
(and $x1473 (or $x1573 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 46: function core_state_transition, block 51, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1917 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1573 (or false false)))
(let (($x622 (or $x1573 false false)))
(let (($x1161 (not $x622)))
(and $x1161 (or $x622 (and (distinct ?x1917 ?x1917) true))))))))
(check-sat)
; query 47: function core_state_transition, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1573 (or false false)))
(let (($x1473 (not $x1573)))
(and $x1473 (or $x1573 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 48: function core_state_transition, block 64, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1917 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1573 (or false false)))
(let (($x622 (or $x1573 false false)))
(let (($x1161 (not $x622)))
(and $x1161 (or $x622 (and (distinct ?x1917 ?x1917) true))))))))
(check-sat)
; query 49: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x1242 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x1599 (or false false false)))
(let (($x1042 (not $x1599)))
(and $x1042 (or $x1599 (and (distinct ?x1242 ?x1242) true)))))))
(check-sat)
; query 50: function core_state_transition, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1573 (or false false)))
(let (($x1473 (not $x1573)))
(and $x1473 (or $x1573 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 51: function core_state_transition, block 80, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x2351 (ite (= (_ bv69 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1573 (or false false)))
(let (($x622 (or $x1573 false false)))
(let (($x1161 (not $x622)))
(and $x1161 (or $x622 (and (distinct ?x2351 ?x2351) true))))))))
(check-sat)
; query 52: function core_state_transition, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1573 (or false false)))
(let (($x1473 (not $x1573)))
(and $x1473 (or $x1573 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 53: function core_state_transition, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1924 (ite (= (_ bv101 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1573 (or false false)))
(let (($x622 (or $x1573 false false)))
(let (($x1161 (not $x622)))
(and $x1161 (or $x622 (and (distinct ?x1924 ?x1924) true))))))))
(check-sat)
; query 54: function core_state_transition, block 99, name %100
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1573 (or false false)))
(let (($x1473 (not $x1573)))
(and $x1473 (or $x1573 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 55: function core_state_transition, block 99, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x2189 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1573 (or false false)))
(let (($x622 (or $x1573 false false)))
(let (($x1161 (not $x622)))
(and $x1161 (or $x622 (and (distinct ?x2189 ?x2189) true))))))))
(check-sat)
; query 56: function crcu8, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x1573 (or false false)))
(let (($x1473 (not $x1573)))
(and $x1473 (or $x1573 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 57: function crcu8, block 19, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x660 ((_ zero_extend 16) in.01_16)))
(let ((?x3974 (bvxor ?x660 (_ bv16386 32))))
(let (($x1573 (or false false)))
(let (($x622 (or $x1573 false false)))
(let (($x1161 (not $x622)))
(and $x1161 (or $x622 (and (distinct ?x3974 ?x3974) true)))))))))
(check-sat)
; query 58: function crcu8, block 19, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x660 ((_ zero_extend 16) in.01_16)))
(let ((?x3974 (bvxor ?x660 (_ bv16386 32))))
(let ((?x5287 ((_ extract 15 0) ?x3974)))
(let (($x1573 (or false false)))
(let (($x622 (or $x1573 false false)))
(let (($x360 (or $x622 false)))
(let (($x1374 (not $x360)))
(and $x1374 (or $x360 (and (distinct ?x5287 ?x5287) true)))))))))))
(check-sat)
; query 59: function crcu8, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x1573 (or false false)))
(let (($x1473 (not $x1573)))
(and $x1473 (or $x1573 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 60: function crcu8, block 29, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x403 ((_ zero_extend 16) in27_16)))
(let ((?x473 (bvor ?x403 (_ bv32768 32))))
(let (($x1573 (or false false)))
(let (($x622 (or $x1573 false false)))
(let (($x1161 (not $x622)))
(and $x1161 (or $x622 (and (distinct ?x473 ?x473) true)))))))))
(check-sat)
; query 61: function crcu8, block 29, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x403 ((_ zero_extend 16) in27_16)))
(let ((?x473 (bvor ?x403 (_ bv32768 32))))
(let ((?x3338 ((_ extract 15 0) ?x473)))
(let (($x1573 (or false false)))
(let (($x622 (or $x1573 false false)))
(let (($x360 (or $x622 false)))
(let (($x1374 (not $x360)))
(and $x1374 (or $x360 (and (distinct ?x3338 ?x3338) true)))))))))))
(check-sat)
; query 62: function crcu8, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x1573 (or false false)))
(let (($x1473 (not $x1573)))
(and $x1473 (or $x1573 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 63: function crcu8, block 33, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x403 ((_ zero_extend 16) in27_16)))
(let ((?x2204 (bvand ?x403 (_ bv32767 32))))
(let (($x1573 (or false false)))
(let (($x622 (or $x1573 false false)))
(let (($x1161 (not $x622)))
(and $x1161 (or $x622 (and (distinct ?x2204 ?x2204) true)))))))))
(check-sat)
; query 64: function crcu8, block 33, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x403 ((_ zero_extend 16) in27_16)))
(let ((?x2204 (bvand ?x403 (_ bv32767 32))))
(let ((?x906 ((_ extract 15 0) ?x2204)))
(let (($x1573 (or false false)))
(let (($x622 (or $x1573 false false)))
(let (($x360 (or $x622 false)))
(let (($x1374 (not $x360)))
(and $x1374 (or $x360 (and (distinct ?x906 ?x906) true)))))))))))
(check-sat)
; query 65: function crcu8, block 38, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_8 () (_ BitVec 8))
(assert
 (let (($x1599 (or false false false)))
(let (($x1042 (not $x1599)))
(and $x1042 (or $x1599 (and (distinct (bvadd in.02_8 (_ bv1 8)) (bvadd in.02_8 (_ bv1 8))) true))))))
(check-sat)
; query 66: function crcu8, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x2516 ((_ extract 7 0) in.01_16)))
(let ((?x4296 ((_ zero_extend 24) ?x2516)))
(let (($x1573 (or false false)))
(let (($x861 (or $x1573 false)))
(and (not $x861) (or $x861 (and (distinct ?x4296 ?x4296) true))))))))
(check-sat)
; query 67: function crcu8, block 6, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x2516 ((_ extract 7 0) in.01_16)))
(let ((?x4296 ((_ zero_extend 24) ?x2516)))
(let ((?x1417 (bvand ?x4296 (_ bv1 32))))
(let (($x1573 (or false false)))
(let (($x861 (or $x1573 false)))
(let (($x1897 (or $x861 false false)))
(and (not $x1897) (or $x1897 (and (distinct ?x1417 ?x1417) true))))))))))
(check-sat)
; query 68: function crcu8, block 6, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x2516 ((_ extract 7 0) in.01_16)))
(let ((?x4296 ((_ zero_extend 24) ?x2516)))
(let ((?x1417 (bvand ?x4296 (_ bv1 32))))
(let ((?x547 ((_ zero_extend 24) in.0_8)))
(let ((?x387 (bvand ?x547 (_ bv1 32))))
(let ((?x1518 (bvxor ?x387 ?x1417)))
(let (($x1573 (or false false)))
(let (($x861 (or $x1573 false)))
(let (($x1897 (or $x861 false false)))
(let (($x622 (or $x1573 false false)))
(let (($x1375 (or $x622 $x1897 false)))
(and (not $x1375) (or $x1375 (and (distinct ?x1518 ?x1518) true)))))))))))))))
(check-sat)
; query 69: function crcu8, block 6, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x2516 ((_ extract 7 0) in.01_16)))
(let ((?x4296 ((_ zero_extend 24) ?x2516)))
(let ((?x1417 (bvand ?x4296 (_ bv1 32))))
(let ((?x547 ((_ zero_extend 24) in.0_8)))
(let ((?x387 (bvand ?x547 (_ bv1 32))))
(let ((?x1518 (bvxor ?x387 ?x1417)))
(let ((?x5867 ((_ extract 7 0) ?x1518)))
(let (($x1573 (or false false)))
(let (($x861 (or $x1573 false)))
(let (($x1897 (or $x861 false false)))
(let (($x622 (or $x1573 false false)))
(let (($x1375 (or $x622 $x1897 false)))
(let (($x527 (or $x1375 false)))
(and (not $x527) (or $x527 (and (distinct ?x5867 ?x5867) true)))))))))))))))))
(check-sat)
; query 70: function crcu8, block 6, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x1573 (or false false)))
(let (($x1473 (not $x1573)))
(and $x1473 (or $x1573 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 71: function crcu8, block 6, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x547 ((_ zero_extend 24) in.0_8)))
(let ((?x2660 (bvashr ?x547 (_ bv1 32))))
(let (($x1573 (or false false)))
(let (($x622 (or $x1573 false false)))
(let (($x889 (or $x622 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not $x889) (or $x889 (and (distinct ?x2660 ?x2660) true)))))))))
(check-sat)
; query 72: function crcu8, block 6, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x547 ((_ zero_extend 24) in.0_8)))
(let ((?x2660 (bvashr ?x547 (_ bv1 32))))
(let ((?x5916 ((_ extract 7 0) ?x2660)))
(let (($x1573 (or false false)))
(let (($x622 (or $x1573 false false)))
(let (($x889 (or $x622 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x5770 (or $x889 false)))
(and (not $x5770) (or $x5770 (and (distinct ?x5916 ?x5916) true)))))))))))
(check-sat)
; query 73: function crcu8, block 6, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x2516 ((_ extract 7 0) in.01_16)))
(let ((?x4296 ((_ zero_extend 24) ?x2516)))
(let ((?x1417 (bvand ?x4296 (_ bv1 32))))
(let ((?x547 ((_ zero_extend 24) in.0_8)))
(let ((?x387 (bvand ?x547 (_ bv1 32))))
(let ((?x1518 (bvxor ?x387 ?x1417)))
(let ((?x5867 ((_ extract 7 0) ?x1518)))
(let ((?x1995 ((_ zero_extend 24) ?x5867)))
(let (($x1573 (or false false)))
(let (($x861 (or $x1573 false)))
(let (($x1897 (or $x861 false false)))
(let (($x622 (or $x1573 false false)))
(let (($x1375 (or $x622 $x1897 false)))
(let (($x527 (or $x1375 false)))
(let (($x525 (or $x527 false)))
(and (not $x525) (or $x525 (and (distinct ?x1995 ?x1995) true)))))))))))))))))))
(check-sat)
; query 74: function crcu8, block 6, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x2516 ((_ extract 7 0) in.01_16)))
(let ((?x4296 ((_ zero_extend 24) ?x2516)))
(let ((?x1417 (bvand ?x4296 (_ bv1 32))))
(let ((?x547 ((_ zero_extend 24) in.0_8)))
(let ((?x387 (bvand ?x547 (_ bv1 32))))
(let ((?x1518 (bvxor ?x387 ?x1417)))
(let ((?x5867 ((_ extract 7 0) ?x1518)))
(let ((?x1995 ((_ zero_extend 24) ?x5867)))
(let ((?x2022 (ite (= (_ bv1 32) ?x1995) (_ bv1 1) (_ bv0 1))))
(let (($x1573 (or false false)))
(let (($x861 (or $x1573 false)))
(let (($x1897 (or $x861 false false)))
(let (($x622 (or $x1573 false false)))
(let (($x1375 (or $x622 $x1897 false)))
(let (($x527 (or $x1375 false)))
(let (($x525 (or $x527 false)))
(let (($x2379 (or $x525 false false)))
(and (not $x2379) (or $x2379 (and (distinct ?x2022 ?x2022) true)))))))))))))))))))))
(check-sat)
; query 75: function crcu8, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x1573 (or false false)))
(let (($x1473 (not $x1573)))
(and $x1473 (or $x1573 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 76: function crcu8, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x547 ((_ zero_extend 24) in.0_8)))
(let ((?x387 (bvand ?x547 (_ bv1 32))))
(let (($x1573 (or false false)))
(let (($x622 (or $x1573 false false)))
(let (($x1161 (not $x622)))
(and $x1161 (or $x622 (and (distinct ?x387 ?x387) true)))))))))
(check-sat)
; query 77: function crcu8, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x1573 (or false false)))
(let (($x1473 (not $x1573)))
(and $x1473 (or $x1573 (and (distinct ((_ extract 7 0) in.01_16) ((_ extract 7 0) in.01_16)) true))))))
(check-sat)
; query 78: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x5058 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x5454 ((_ zero_extend 31) ?x5058)))
(let ((?x2631 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1796 ((_ zero_extend 31) ?x2631)))
(let ((?x1048 (bvand ?x1796 ?x5454)))
(let ((?x69 (ite (and (distinct (_ bv0 32) ?x1048) true) (_ bv1 1) (_ bv0 1))))
(let ((?x4290 ((_ zero_extend 63) ?x69)))
(let (($x1573 (or false false)))
(let (($x622 (or $x1573 false false)))
(let (($x360 (or $x622 false)))
(let (($x5981 (or $x360 $x360 false)))
(let (($x3966 (or $x5981 false false)))
(let (($x6045 (or $x3966 false)))
(and (not $x6045) (or $x6045 (and (distinct ?x4290 ?x4290) true)))))))))))))))))
(check-sat)
; query 79: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x5058 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x5454 ((_ zero_extend 31) ?x5058)))
(let ((?x2631 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1796 ((_ zero_extend 31) ?x2631)))
(let ((?x1048 (bvand ?x1796 ?x5454)))
(let ((?x69 (ite (and (distinct (_ bv0 32) ?x1048) true) (_ bv1 1) (_ bv0 1))))
(let (($x4918 (= (_ bv1 1) ?x69)))
(let ((?x5731 (ite $x4918 (_ bv1 32) (_ bv0 32))))
(let (($x1573 (or false false)))
(let (($x622 (or $x1573 false false)))
(let (($x360 (or $x622 false)))
(let (($x5981 (or $x360 $x360 false)))
(let (($x3966 (or $x5981 false false)))
(let (($x1550 (or $x3966 (ite $x4918 false false))))
(and (not $x1550) (or $x1550 (and (distinct ?x5731 ?x5731) true))))))))))))))))))
(check-sat)
; query 80: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x5058 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x5454 ((_ zero_extend 31) ?x5058)))
(let ((?x2631 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1796 ((_ zero_extend 31) ?x2631)))
(let ((?x1048 (bvand ?x1796 ?x5454)))
(let ((?x69 (ite (and (distinct (_ bv0 32) ?x1048) true) (_ bv1 1) (_ bv0 1))))
(let (($x4918 (= (_ bv1 1) ?x69)))
(let ((?x5731 (ite $x4918 (_ bv1 32) (_ bv0 32))))
(let ((?x5286 ((_ extract 7 0) ?x5731)))
(let (($x1573 (or false false)))
(let (($x622 (or $x1573 false false)))
(let (($x360 (or $x622 false)))
(let (($x5981 (or $x360 $x360 false)))
(let (($x3966 (or $x5981 false false)))
(let (($x1550 (or $x3966 (ite $x4918 false false))))
(let (($x2542 (or $x1550 false)))
(and (not $x2542) (or $x2542 (and (distinct ?x5286 ?x5286) true))))))))))))))))))))
(check-sat)
; query 81: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x1573 (or false false)))
(let (($x1473 (not $x1573)))
(and $x1473 (or $x1573 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 82: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x2631 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1573 (or false false)))
(let (($x622 (or $x1573 false false)))
(let (($x1161 (not $x622)))
(and $x1161 (or $x622 (and (distinct ?x2631 ?x2631) true))))))))
(check-sat)
; query 83: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x2631 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1796 ((_ zero_extend 31) ?x2631)))
(let (($x1573 (or false false)))
(let (($x622 (or $x1573 false false)))
(let (($x360 (or $x622 false)))
(let (($x1374 (not $x360)))
(and $x1374 (or $x360 (and (distinct ?x1796 ?x1796) true))))))))))
(check-sat)
; query 84: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x1573 (or false false)))
(let (($x1473 (not $x1573)))
(and $x1473 (or $x1573 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 85: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x5058 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1573 (or false false)))
(let (($x622 (or $x1573 false false)))
(let (($x1161 (not $x622)))
(and $x1161 (or $x622 (and (distinct ?x5058 ?x5058) true))))))))
(check-sat)
; query 86: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x5058 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x5454 ((_ zero_extend 31) ?x5058)))
(let (($x1573 (or false false)))
(let (($x622 (or $x1573 false false)))
(let (($x360 (or $x622 false)))
(let (($x1374 (not $x360)))
(and $x1374 (or $x360 (and (distinct ?x5454 ?x5454) true))))))))))
(check-sat)
; query 87: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x5058 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x5454 ((_ zero_extend 31) ?x5058)))
(let ((?x2631 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1796 ((_ zero_extend 31) ?x2631)))
(let ((?x1048 (bvand ?x1796 ?x5454)))
(let (($x1573 (or false false)))
(let (($x622 (or $x1573 false false)))
(let (($x360 (or $x622 false)))
(let (($x5981 (or $x360 $x360 false)))
(and (not $x5981) (or $x5981 (and (distinct ?x1048 ?x1048) true)))))))))))))
(check-sat)
; query 88: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x5058 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x5454 ((_ zero_extend 31) ?x5058)))
(let ((?x2631 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1796 ((_ zero_extend 31) ?x2631)))
(let ((?x1048 (bvand ?x1796 ?x5454)))
(let ((?x69 (ite (and (distinct (_ bv0 32) ?x1048) true) (_ bv1 1) (_ bv0 1))))
(let (($x1573 (or false false)))
(let (($x622 (or $x1573 false false)))
(let (($x360 (or $x622 false)))
(let (($x5981 (or $x360 $x360 false)))
(let (($x3966 (or $x5981 false false)))
(and (not $x3966) (or $x3966 (and (distinct ?x69 ?x69) true)))))))))))))))
(check-sat)
; query 89: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1431 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x1599 (or false false false)))
(let (($x1042 (not $x1599)))
(and $x1042 (or $x1599 (and (distinct ?x1431 ?x1431) true)))))))
(check-sat)
; query 90: function matrix_add_const, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1599 (or false false false)))
(let (($x1042 (not $x1599)))
(and $x1042 (or $x1599 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 91: function matrix_add_const, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x450 (bvadd in.01_32 (_ bv1 32))))
(let (($x583 (and (distinct ?x450 ?x450) true)))
(let (($x1599 (or false false false)))
(let (($x1042 (not $x1599)))
(and $x1042 (or $x1599 $x583)))))))
(check-sat)
; query 92: function matrix_mul_const, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1599 (or false false false)))
(let (($x1042 (not $x1599)))
(and $x1042 (or $x1599 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 93: function matrix_mul_const, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x450 (bvadd in.01_32 (_ bv1 32))))
(let (($x583 (and (distinct ?x450 ?x450) true)))
(let (($x1599 (or false false false)))
(let (($x1042 (not $x1599)))
(and $x1042 (or $x1599 $x583)))))))
(check-sat)
; query 94: function matrix_mul_matrix, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1599 (or false false false)))
(let (($x1042 (not $x1599)))
(and $x1042 (or $x1599 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 95: function matrix_mul_matrix, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x450 (bvadd in.01_32 (_ bv1 32))))
(let (($x583 (and (distinct ?x450 ?x450) true)))
(let (($x1599 (or false false false)))
(let (($x1042 (not $x1599)))
(and $x1042 (or $x1599 $x583)))))))
(check-sat)
; query 96: function matrix_mul_matrix, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x1599 (or false false false)))
(let (($x1042 (not $x1599)))
(and $x1042 (or $x1599 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 97: function matrix_mul_matrix_bitextract, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1599 (or false false false)))
(let (($x1042 (not $x1599)))
(and $x1042 (or $x1599 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 98: function matrix_mul_matrix_bitextract, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x450 (bvadd in.01_32 (_ bv1 32))))
(let (($x583 (and (distinct ?x450 ?x450) true)))
(let (($x1599 (or false false false)))
(let (($x1042 (not $x1599)))
(and $x1042 (or $x1599 $x583)))))))
(check-sat)
; query 99: function matrix_mul_matrix_bitextract, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x1599 (or false false false)))
(let (($x1042 (not $x1599)))
(and $x1042 (or $x1599 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 100: function matrix_mul_vect, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1599 (or false false false)))
(let (($x1042 (not $x1599)))
(and $x1042 (or $x1599 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 101: function matrix_mul_vect, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x450 (bvadd in.01_32 (_ bv1 32))))
(let (($x583 (and (distinct ?x450 ?x450) true)))
(let (($x1599 (or false false false)))
(let (($x1042 (not $x1599)))
(and $x1042 (or $x1599 $x583)))))))
(check-sat)
; query 102: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x1573 (or false false)))
(let (($x1473 (not $x1573)))
(and $x1473 (or $x1573 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 103: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x1727 ((_ sign_extend 16) in.1_16)))
(let ((?x417 (bvadd ?x1727 (_ bv10 32))))
(let (($x541 (and (distinct (bvadd ((_ sign_extend 1) ?x1727) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x417)) true)))
(let (($x1573 (or false false)))
(let (($x2494 (or $x1573 false (or $x541))))
(and (not $x2494) (or $x2494 (and (distinct ?x417 ?x417) true)))))))))
(check-sat)
; query 104: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x1727 ((_ sign_extend 16) in.1_16)))
(let ((?x417 (bvadd ?x1727 (_ bv10 32))))
(let ((?x5390 ((_ extract 15 0) ?x417)))
(let (($x541 (and (distinct (bvadd ((_ sign_extend 1) ?x1727) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x417)) true)))
(let (($x1573 (or false false)))
(let (($x2494 (or $x1573 false (or $x541))))
(let (($x1694 (or $x2494 false)))
(and (not $x1694) (or $x1694 (and (distinct ?x5390 ?x5390) true)))))))))))
(check-sat)
; query 105: function matrix_sum, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x1290 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x1599 (or false false false)))
(let (($x1042 (not $x1599)))
(and $x1042 (or $x1599 (and (distinct ?x1290 ?x1290) true)))))))
(check-sat)
; query 106: function matrix_sum, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x1290 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let ((?x3576 ((_ zero_extend 63) ?x1290)))
(let (($x1599 (or false false false)))
(let (($x5524 (or $x1599 false)))
(and (not $x5524) (or $x5524 (and (distinct ?x3576 ?x3576) true))))))))
(check-sat)
; query 107: function matrix_sum, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x1290 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x2765 (= (_ bv1 1) ?x1290)))
(let ((?x5624 (ite $x2765 (_ bv1 32) (_ bv0 32))))
(let (($x1599 (or false false false)))
(let (($x7224 (or $x1599 (ite $x2765 false false))))
(and (not $x7224) (or $x7224 (and (distinct ?x5624 ?x5624) true)))))))))
(check-sat)
; query 108: function matrix_sum, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x1573 (or false false)))
(let (($x1473 (not $x1573)))
(and $x1473 (or $x1573 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 109: function matrix_sum, block 22, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x1290 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x2765 (= (_ bv1 1) ?x1290)))
(let ((?x5624 (ite $x2765 (_ bv1 32) (_ bv0 32))))
(let ((?x1727 ((_ sign_extend 16) in.1_16)))
(let ((?x845 (bvadd ?x1727 ?x5624)))
(let (($x5604 (and (distinct (bvadd ((_ sign_extend 1) ?x1727) ((_ sign_extend 1) ?x5624)) ((_ sign_extend 1) ?x845)) true)))
(let (($x1599 (or false false false)))
(let (($x7224 (or $x1599 (ite $x2765 false false))))
(let (($x1573 (or false false)))
(let (($x1976 (or $x1573 $x7224 (or $x5604))))
(and (not $x1976) (or $x1976 (and (distinct ?x845 ?x845) true))))))))))))))
(check-sat)
; query 110: function matrix_sum, block 22, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x1290 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x2765 (= (_ bv1 1) ?x1290)))
(let ((?x5624 (ite $x2765 (_ bv1 32) (_ bv0 32))))
(let ((?x1727 ((_ sign_extend 16) in.1_16)))
(let ((?x845 (bvadd ?x1727 ?x5624)))
(let ((?x804 ((_ extract 15 0) ?x845)))
(let (($x5604 (and (distinct (bvadd ((_ sign_extend 1) ?x1727) ((_ sign_extend 1) ?x5624)) ((_ sign_extend 1) ?x845)) true)))
(let (($x1599 (or false false false)))
(let (($x7224 (or $x1599 (ite $x2765 false false))))
(let (($x1573 (or false false)))
(let (($x1976 (or $x1573 $x7224 (or $x5604))))
(let (($x7047 (or $x1976 false)))
(and (not $x7047) (or $x7047 (and (distinct ?x804 ?x804) true))))))))))))))))
(check-sat)
; query 111: function matrix_sum, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1599 (or false false false)))
(let (($x1042 (not $x1599)))
(and $x1042 (or $x1599 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 112: function matrix_sum, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x450 (bvadd in.01_32 (_ bv1 32))))
(let (($x583 (and (distinct ?x450 ?x450) true)))
(let (($x1599 (or false false false)))
(let (($x1042 (not $x1599)))
(and $x1042 (or $x1599 $x583)))))))
(check-sat)
; query 113: function parseval, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.23_32 () (_ BitVec 32))
(assert
 (let (($x2038 (and (distinct (bvmul ((_ sign_extend 32) in.23_32) ((_ sign_extend 32) (_ bv1024 32))) ((_ sign_extend 32) (bvmul in.23_32 (_ bv1024 32)))) true)))
(let (($x5044 (or false false (or $x2038))))
(and (not $x5044) (or $x5044 (and (distinct (bvmul in.23_32 (_ bv1024 32)) (bvmul in.23_32 (_ bv1024 32))) true))))))
(check-sat)
; query 114: function parseval, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.34_32 () (_ BitVec 32))
(assert
 (let (($x3475 (and (distinct (bvmul ((_ sign_extend 32) in.34_32) ((_ sign_extend 32) (_ bv1048576 32))) ((_ sign_extend 32) (bvmul in.34_32 (_ bv1048576 32)))) true)))
(let (($x2461 (or false false (or $x3475))))
(and (not $x2461) (or $x2461 (and (distinct (bvmul in.34_32 (_ bv1048576 32)) (bvmul in.34_32 (_ bv1048576 32))) true))))))
(check-sat)
; query 115: function partition_memory, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1599 (or false false false)))
(let (($x1042 (not $x1599)))
(and $x1042 (or $x1599 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
