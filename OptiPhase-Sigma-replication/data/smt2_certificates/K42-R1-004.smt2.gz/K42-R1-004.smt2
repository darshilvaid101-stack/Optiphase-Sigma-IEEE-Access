; OptiPhase-Sigma refinement certificate for sweep K42-R1-004
