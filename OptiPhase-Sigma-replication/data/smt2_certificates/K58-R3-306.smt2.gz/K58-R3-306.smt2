; OptiPhase-Sigma refinement certificate for sweep K58-R3-306
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x1655 (not $x382)))
(and $x1655 (or $x382 (and (distinct ((_ sign_extend 16) in25_16) ((_ sign_extend 16) in25_16)) true))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let ((?x311 (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))))
(let (($x382 (or false false)))
(let (($x744 (or $x382 false false)))
(let (($x623 (not $x744)))
(and $x623 (or $x744 (and (distinct ?x311 ?x311) true))))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x1655 (not $x382)))
(and $x1655 (or $x382 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x1856 ((_ sign_extend 16) in3_16)))
(let ((?x86 (bvand ?x1856 (_ bv127 32))))
(let (($x382 (or false false)))
(let (($x744 (or $x382 false false)))
(let (($x623 (not $x744)))
(and $x623 (or $x744 (and (distinct ?x86 ?x86) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x1856 ((_ sign_extend 16) in3_16)))
(let ((?x86 (bvand ?x1856 (_ bv127 32))))
(let ((?x416 ((_ extract 15 0) ?x86)))
(let (($x382 (or false false)))
(let (($x744 (or $x382 false false)))
(let (($x318 (or $x744 false)))
(let (($x53 (not $x318)))
(and $x53 (or $x318 (and (distinct ?x416 ?x416) true)))))))))))
(check-sat)
; query 5: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x382 (or false false)))
(let (($x1655 (not $x382)))
(and $x1655 (or $x382 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 6: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x379 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x382 (or false false)))
(let (($x744 (or $x382 false false)))
(let (($x623 (not $x744)))
(and $x623 (or $x744 (and (distinct ?x379 ?x379) true))))))))
(check-sat)
; query 7: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x17 (or false false false)))
(let (($x720 (not $x17)))
(and $x720 (or $x17 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x115 (bvadd in.01_32 (_ bv1 32))))
(let ((?x29 (bvmul ?x115 ?x115)))
(let (($x17 (or false false false)))
(let (($x4142 (or $x17 $x17 false)))
(and (not $x4142) (or $x4142 (and (distinct ?x29 ?x29) true))))))))
(check-sat)
; query 9: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x115 (bvadd in.01_32 (_ bv1 32))))
(let ((?x29 (bvmul ?x115 ?x115)))
(let ((?x84 (bvmul ?x29 (_ bv2 32))))
(let (($x17 (or false false false)))
(let (($x4142 (or $x17 $x17 false)))
(let (($x320 (or $x4142 false false)))
(and (not $x320) (or $x320 (and (distinct ?x84 ?x84) true))))))))))
(check-sat)
; query 10: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x115 (bvadd in.01_32 (_ bv1 32))))
(let ((?x29 (bvmul ?x115 ?x115)))
(let ((?x84 (bvmul ?x29 (_ bv2 32))))
(let ((?x216 (bvmul ?x84 (_ bv4 32))))
(let (($x17 (or false false false)))
(let (($x4142 (or $x17 $x17 false)))
(let (($x320 (or $x4142 false false)))
(let (($x67 (or $x320 false false)))
(and (not $x67) (or $x67 (and (distinct ?x216 ?x216) true))))))))))))
(check-sat)
; query 11: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x1380 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x17 (or false false false)))
(let (($x720 (not $x17)))
(and $x720 (or $x17 (and (distinct ?x1380 ?x1380) true)))))))
(check-sat)
; query 12: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x113 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x17 (or false false false)))
(let (($x720 (not $x17)))
(and $x720 (or $x17 (and (distinct ?x113 ?x113) true)))))))
(check-sat)
; query 13: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x17 (or false false false)))
(let (($x720 (not $x17)))
(and $x720 (or $x17 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 14: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x176 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x79 (or false false (or $x176))))
(and (not $x79) (or $x79 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 15: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x296 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x17 (or false false false)))
(let (($x720 (not $x17)))
(and $x720 (or $x17 (and (distinct ?x296 ?x296) true)))))))
(check-sat)
; query 16: function crcu8, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x1655 (not $x382)))
(and $x1655 (or $x382 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 17: function crcu8, block 19, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x28 ((_ zero_extend 16) in.01_16)))
(let ((?x3821 (bvxor ?x28 (_ bv16386 32))))
(let (($x382 (or false false)))
(let (($x744 (or $x382 false false)))
(let (($x623 (not $x744)))
(and $x623 (or $x744 (and (distinct ?x3821 ?x3821) true)))))))))
(check-sat)
; query 18: function crcu8, block 19, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x28 ((_ zero_extend 16) in.01_16)))
(let ((?x3821 (bvxor ?x28 (_ bv16386 32))))
(let ((?x821 ((_ extract 15 0) ?x3821)))
(let (($x382 (or false false)))
(let (($x744 (or $x382 false false)))
(let (($x318 (or $x744 false)))
(let (($x53 (not $x318)))
(and $x53 (or $x318 (and (distinct ?x821 ?x821) true)))))))))))
(check-sat)
; query 19: function crcu8, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x27 ((_ extract 7 0) in.01_16)))
(let ((?x861 ((_ zero_extend 24) ?x27)))
(let (($x382 (or false false)))
(let (($x66 (or $x382 false)))
(and (not $x66) (or $x66 (and (distinct ?x861 ?x861) true))))))))
(check-sat)
; query 20: function crcu8, block 6, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x27 ((_ extract 7 0) in.01_16)))
(let ((?x861 ((_ zero_extend 24) ?x27)))
(let ((?x920 (bvand ?x861 (_ bv1 32))))
(let (($x382 (or false false)))
(let (($x66 (or $x382 false)))
(let (($x107 (or $x66 false false)))
(and (not $x107) (or $x107 (and (distinct ?x920 ?x920) true))))))))))
(check-sat)
; query 21: function crcu8, block 6, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x27 ((_ extract 7 0) in.01_16)))
(let ((?x861 ((_ zero_extend 24) ?x27)))
(let ((?x920 (bvand ?x861 (_ bv1 32))))
(let ((?x356 ((_ zero_extend 24) in.0_8)))
(let ((?x1750 (bvand ?x356 (_ bv1 32))))
(let ((?x550 (bvxor ?x1750 ?x920)))
(let (($x382 (or false false)))
(let (($x66 (or $x382 false)))
(let (($x107 (or $x66 false false)))
(let (($x744 (or $x382 false false)))
(let (($x238 (or $x744 $x107 false)))
(and (not $x238) (or $x238 (and (distinct ?x550 ?x550) true)))))))))))))))
(check-sat)
; query 22: function crcu8, block 6, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x27 ((_ extract 7 0) in.01_16)))
(let ((?x861 ((_ zero_extend 24) ?x27)))
(let ((?x920 (bvand ?x861 (_ bv1 32))))
(let ((?x356 ((_ zero_extend 24) in.0_8)))
(let ((?x1750 (bvand ?x356 (_ bv1 32))))
(let ((?x550 (bvxor ?x1750 ?x920)))
(let ((?x5651 ((_ extract 7 0) ?x550)))
(let (($x382 (or false false)))
(let (($x66 (or $x382 false)))
(let (($x107 (or $x66 false false)))
(let (($x744 (or $x382 false false)))
(let (($x238 (or $x744 $x107 false)))
(let (($x190 (or $x238 false)))
(and (not $x190) (or $x190 (and (distinct ?x5651 ?x5651) true)))))))))))))))))
(check-sat)
; query 23: function crcu8, block 6, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x382 (or false false)))
(let (($x1655 (not $x382)))
(and $x1655 (or $x382 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 24: function crcu8, block 6, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x356 ((_ zero_extend 24) in.0_8)))
(let ((?x243 (bvashr ?x356 (_ bv1 32))))
(let (($x382 (or false false)))
(let (($x744 (or $x382 false false)))
(let (($x392 (or $x744 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not $x392) (or $x392 (and (distinct ?x243 ?x243) true)))))))))
(check-sat)
; query 25: function crcu8, block 6, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x356 ((_ zero_extend 24) in.0_8)))
(let ((?x243 (bvashr ?x356 (_ bv1 32))))
(let ((?x4964 ((_ extract 7 0) ?x243)))
(let (($x382 (or false false)))
(let (($x744 (or $x382 false false)))
(let (($x392 (or $x744 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x444 (or $x392 false)))
(and (not $x444) (or $x444 (and (distinct ?x4964 ?x4964) true)))))))))))
(check-sat)
; query 26: function crcu8, block 6, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x27 ((_ extract 7 0) in.01_16)))
(let ((?x861 ((_ zero_extend 24) ?x27)))
(let ((?x920 (bvand ?x861 (_ bv1 32))))
(let ((?x356 ((_ zero_extend 24) in.0_8)))
(let ((?x1750 (bvand ?x356 (_ bv1 32))))
(let ((?x550 (bvxor ?x1750 ?x920)))
(let ((?x5651 ((_ extract 7 0) ?x550)))
(let ((?x116 ((_ zero_extend 24) ?x5651)))
(let (($x382 (or false false)))
(let (($x66 (or $x382 false)))
(let (($x107 (or $x66 false false)))
(let (($x744 (or $x382 false false)))
(let (($x238 (or $x744 $x107 false)))
(let (($x190 (or $x238 false)))
(let (($x74 (or $x190 false)))
(and (not $x74) (or $x74 (and (distinct ?x116 ?x116) true)))))))))))))))))))
(check-sat)
; query 27: function crcu8, block 6, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x27 ((_ extract 7 0) in.01_16)))
(let ((?x861 ((_ zero_extend 24) ?x27)))
(let ((?x920 (bvand ?x861 (_ bv1 32))))
(let ((?x356 ((_ zero_extend 24) in.0_8)))
(let ((?x1750 (bvand ?x356 (_ bv1 32))))
(let ((?x550 (bvxor ?x1750 ?x920)))
(let ((?x5651 ((_ extract 7 0) ?x550)))
(let ((?x116 ((_ zero_extend 24) ?x5651)))
(let ((?x10508 (ite (= (_ bv1 32) ?x116) (_ bv1 1) (_ bv0 1))))
(let (($x382 (or false false)))
(let (($x66 (or $x382 false)))
(let (($x107 (or $x66 false false)))
(let (($x744 (or $x382 false false)))
(let (($x238 (or $x744 $x107 false)))
(let (($x190 (or $x238 false)))
(let (($x74 (or $x190 false)))
(let (($x564 (or $x74 false false)))
(and (not $x564) (or $x564 (and (distinct ?x10508 ?x10508) true)))))))))))))))))))))
(check-sat)
; query 28: function crcu8, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x382 (or false false)))
(let (($x1655 (not $x382)))
(and $x1655 (or $x382 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 29: function crcu8, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x356 ((_ zero_extend 24) in.0_8)))
(let ((?x1750 (bvand ?x356 (_ bv1 32))))
(let (($x382 (or false false)))
(let (($x744 (or $x382 false false)))
(let (($x623 (not $x744)))
(and $x623 (or $x744 (and (distinct ?x1750 ?x1750) true)))))))))
(check-sat)
; query 30: function crcu8, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x1655 (not $x382)))
(and $x1655 (or $x382 (and (distinct ((_ extract 7 0) in.01_16) ((_ extract 7 0) in.01_16)) true))))))
(check-sat)
; query 31: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1008 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x11861 ((_ zero_extend 31) ?x1008)))
(let ((?x139 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x6892 ((_ zero_extend 31) ?x139)))
(let ((?x5264 (bvand ?x6892 ?x11861)))
(let ((?x4536 (ite (and (distinct (_ bv0 32) ?x5264) true) (_ bv1 1) (_ bv0 1))))
(let ((?x4601 ((_ zero_extend 63) ?x4536)))
(let (($x382 (or false false)))
(let (($x744 (or $x382 false false)))
(let (($x318 (or $x744 false)))
(let (($x1712 (or $x318 $x318 false)))
(let (($x2968 (or $x1712 false false)))
(let (($x7215 (or $x2968 false)))
(and (not $x7215) (or $x7215 (and (distinct ?x4601 ?x4601) true)))))))))))))))))
(check-sat)
; query 32: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1008 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x11861 ((_ zero_extend 31) ?x1008)))
(let ((?x139 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x6892 ((_ zero_extend 31) ?x139)))
(let ((?x5264 (bvand ?x6892 ?x11861)))
(let ((?x4536 (ite (and (distinct (_ bv0 32) ?x5264) true) (_ bv1 1) (_ bv0 1))))
(let (($x8879 (= (_ bv1 1) ?x4536)))
(let ((?x10292 (ite $x8879 (_ bv1 32) (_ bv0 32))))
(let (($x382 (or false false)))
(let (($x744 (or $x382 false false)))
(let (($x318 (or $x744 false)))
(let (($x1712 (or $x318 $x318 false)))
(let (($x2968 (or $x1712 false false)))
(let (($x5162 (or $x2968 (ite $x8879 false false))))
(and (not $x5162) (or $x5162 (and (distinct ?x10292 ?x10292) true))))))))))))))))))
(check-sat)
; query 33: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1008 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x11861 ((_ zero_extend 31) ?x1008)))
(let ((?x139 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x6892 ((_ zero_extend 31) ?x139)))
(let ((?x5264 (bvand ?x6892 ?x11861)))
(let ((?x4536 (ite (and (distinct (_ bv0 32) ?x5264) true) (_ bv1 1) (_ bv0 1))))
(let (($x8879 (= (_ bv1 1) ?x4536)))
(let ((?x10292 (ite $x8879 (_ bv1 32) (_ bv0 32))))
(let ((?x12399 ((_ extract 7 0) ?x10292)))
(let (($x382 (or false false)))
(let (($x744 (or $x382 false false)))
(let (($x318 (or $x744 false)))
(let (($x1712 (or $x318 $x318 false)))
(let (($x2968 (or $x1712 false false)))
(let (($x5162 (or $x2968 (ite $x8879 false false))))
(let (($x2049 (or $x5162 false)))
(and (not $x2049) (or $x2049 (and (distinct ?x12399 ?x12399) true))))))))))))))))))))
(check-sat)
; query 34: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x382 (or false false)))
(let (($x1655 (not $x382)))
(and $x1655 (or $x382 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 35: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x139 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x382 (or false false)))
(let (($x744 (or $x382 false false)))
(let (($x623 (not $x744)))
(and $x623 (or $x744 (and (distinct ?x139 ?x139) true))))))))
(check-sat)
; query 36: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x139 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x6892 ((_ zero_extend 31) ?x139)))
(let (($x382 (or false false)))
(let (($x744 (or $x382 false false)))
(let (($x318 (or $x744 false)))
(let (($x53 (not $x318)))
(and $x53 (or $x318 (and (distinct ?x6892 ?x6892) true))))))))))
(check-sat)
; query 37: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x382 (or false false)))
(let (($x1655 (not $x382)))
(and $x1655 (or $x382 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 38: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1008 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x382 (or false false)))
(let (($x744 (or $x382 false false)))
(let (($x623 (not $x744)))
(and $x623 (or $x744 (and (distinct ?x1008 ?x1008) true))))))))
(check-sat)
; query 39: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1008 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x11861 ((_ zero_extend 31) ?x1008)))
(let (($x382 (or false false)))
(let (($x744 (or $x382 false false)))
(let (($x318 (or $x744 false)))
(let (($x53 (not $x318)))
(and $x53 (or $x318 (and (distinct ?x11861 ?x11861) true))))))))))
(check-sat)
; query 40: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1008 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x11861 ((_ zero_extend 31) ?x1008)))
(let ((?x139 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x6892 ((_ zero_extend 31) ?x139)))
(let ((?x5264 (bvand ?x6892 ?x11861)))
(let (($x382 (or false false)))
(let (($x744 (or $x382 false false)))
(let (($x318 (or $x744 false)))
(let (($x1712 (or $x318 $x318 false)))
(and (not $x1712) (or $x1712 (and (distinct ?x5264 ?x5264) true)))))))))))))
(check-sat)
; query 41: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1008 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x11861 ((_ zero_extend 31) ?x1008)))
(let ((?x139 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x6892 ((_ zero_extend 31) ?x139)))
(let ((?x5264 (bvand ?x6892 ?x11861)))
(let ((?x4536 (ite (and (distinct (_ bv0 32) ?x5264) true) (_ bv1 1) (_ bv0 1))))
(let (($x382 (or false false)))
(let (($x744 (or $x382 false false)))
(let (($x318 (or $x744 false)))
(let (($x1712 (or $x318 $x318 false)))
(let (($x2968 (or $x1712 false false)))
(and (not $x2968) (or $x2968 (and (distinct ?x4536 ?x4536) true)))))))))))))))
(check-sat)
; query 42: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x8995 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x17 (or false false false)))
(let (($x720 (not $x17)))
(and $x720 (or $x17 (and (distinct ?x8995 ?x8995) true)))))))
(check-sat)
; query 43: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x1655 (not $x382)))
(and $x1655 (or $x382 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 44: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x9100 ((_ sign_extend 16) in.1_16)))
(let ((?x2457 (bvadd ?x9100 (_ bv10 32))))
(let (($x7181 (and (distinct (bvadd ((_ sign_extend 1) ?x9100) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x2457)) true)))
(let (($x382 (or false false)))
(let (($x6678 (or $x382 false (or $x7181))))
(and (not $x6678) (or $x6678 (and (distinct ?x2457 ?x2457) true)))))))))
(check-sat)
; query 45: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x9100 ((_ sign_extend 16) in.1_16)))
(let ((?x2457 (bvadd ?x9100 (_ bv10 32))))
(let ((?x5409 ((_ extract 15 0) ?x2457)))
(let (($x7181 (and (distinct (bvadd ((_ sign_extend 1) ?x9100) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x2457)) true)))
(let (($x382 (or false false)))
(let (($x6678 (or $x382 false (or $x7181))))
(let (($x11900 (or $x6678 false)))
(and (not $x11900) (or $x11900 (and (distinct ?x5409 ?x5409) true)))))))))))
(check-sat)
; query 46: function matrix_sum, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x11558 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x17 (or false false false)))
(let (($x720 (not $x17)))
(and $x720 (or $x17 (and (distinct ?x11558 ?x11558) true)))))))
(check-sat)
; query 47: function matrix_sum, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x11558 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let ((?x6975 ((_ zero_extend 63) ?x11558)))
(let (($x17 (or false false false)))
(let (($x4453 (or $x17 false)))
(and (not $x4453) (or $x4453 (and (distinct ?x6975 ?x6975) true))))))))
(check-sat)
; query 48: function matrix_sum, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x11558 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x9747 (= (_ bv1 1) ?x11558)))
(let ((?x5749 (ite $x9747 (_ bv1 32) (_ bv0 32))))
(let (($x17 (or false false false)))
(let (($x592 (or $x17 (ite $x9747 false false))))
(and (not $x592) (or $x592 (and (distinct ?x5749 ?x5749) true)))))))))
(check-sat)
; query 49: function matrix_sum, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x1655 (not $x382)))
(and $x1655 (or $x382 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 50: function matrix_sum, block 22, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x11558 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x9747 (= (_ bv1 1) ?x11558)))
(let ((?x5749 (ite $x9747 (_ bv1 32) (_ bv0 32))))
(let ((?x9100 ((_ sign_extend 16) in.1_16)))
(let ((?x7476 (bvadd ?x9100 ?x5749)))
(let (($x1415 (and (distinct (bvadd ((_ sign_extend 1) ?x9100) ((_ sign_extend 1) ?x5749)) ((_ sign_extend 1) ?x7476)) true)))
(let (($x17 (or false false false)))
(let (($x592 (or $x17 (ite $x9747 false false))))
(let (($x382 (or false false)))
(let (($x2391 (or $x382 $x592 (or $x1415))))
(and (not $x2391) (or $x2391 (and (distinct ?x7476 ?x7476) true))))))))))))))
(check-sat)
; query 51: function matrix_sum, block 22, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x11558 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x9747 (= (_ bv1 1) ?x11558)))
(let ((?x5749 (ite $x9747 (_ bv1 32) (_ bv0 32))))
(let ((?x9100 ((_ sign_extend 16) in.1_16)))
(let ((?x7476 (bvadd ?x9100 ?x5749)))
(let ((?x5030 ((_ extract 15 0) ?x7476)))
(let (($x1415 (and (distinct (bvadd ((_ sign_extend 1) ?x9100) ((_ sign_extend 1) ?x5749)) ((_ sign_extend 1) ?x7476)) true)))
(let (($x17 (or false false false)))
(let (($x592 (or $x17 (ite $x9747 false false))))
(let (($x382 (or false false)))
(let (($x2391 (or $x382 $x592 (or $x1415))))
(let (($x9602 (or $x2391 false)))
(and (not $x9602) (or $x9602 (and (distinct ?x5030 ?x5030) true))))))))))))))))
(check-sat)
