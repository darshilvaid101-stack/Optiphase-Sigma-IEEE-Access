; OptiPhase-Sigma refinement certificate for sweep K55-R3-287
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x84 (or false (or (= ((_ extract 15 15) in25_16) (_ bv1 1))))))
(let (($x628 (or false false)))
(let (($x28 (not $x628)))
(and $x28 (or $x84 (and (distinct ((_ sign_extend 16) in25_16) ((_ zero_extend 16) in25_16)) true)))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x224 (and (distinct (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1)) (ite (bvsgt (_ bv34 32) ((_ zero_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))) true)))
(let (($x550 (or (or (or false (or (= ((_ extract 15 15) in25_16) (_ bv1 1)))) false false) $x224)))
(let (($x628 (or false false)))
(let (($x816 (or $x628 false false)))
(let (($x1967 (not $x816)))
(and $x1967 $x550)))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x628 (or false false)))
(let (($x28 (not $x628)))
(and $x28 (or $x628 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x1462 ((_ sign_extend 16) in3_16)))
(let ((?x113 (bvand ?x1462 (_ bv127 32))))
(let (($x628 (or false false)))
(let (($x816 (or $x628 false false)))
(let (($x1967 (not $x816)))
(and $x1967 (or $x816 (and (distinct ?x113 ?x113) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x1462 ((_ sign_extend 16) in3_16)))
(let ((?x113 (bvand ?x1462 (_ bv127 32))))
(let ((?x1095 ((_ extract 15 0) ?x113)))
(let (($x216 (or (and (distinct ((_ zero_extend 16) ?x1095) ?x113) true) (and (distinct ((_ sign_extend 16) ?x1095) ?x113) true))))
(let (($x628 (or false false)))
(let (($x816 (or $x628 false false)))
(let (($x13 (not (or $x816 false))))
(and $x13 (or (or $x816 $x216) (and (distinct ?x1095 ?x1095) true)))))))))))
(check-sat)
; query 5: function core_bench_list, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x83 (or false false false)))
(let (($x43 (not $x83)))
(and $x43 (or $x83 (and (distinct (bvadd in.0_16 (_ bv1 16)) (bvadd in.0_16 (_ bv1 16))) true))))))
(check-sat)
; query 6: function core_bench_list, block 82, name %83
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let (($x628 (or false false)))
(let (($x28 (not $x628)))
(and $x28 (or $x628 (and (distinct ((_ zero_extend 16) in.02_16) ((_ zero_extend 16) in.02_16)) true))))))
(check-sat)
; query 7: function core_bench_list, block 82, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x127 ((_ zero_extend 16) in.02_16)))
(let ((?x64 (bvmul ?x127 (_ bv4 32))))
(let (($x129 (and (distinct (bvmul ((_ zero_extend 32) ?x127) ((_ zero_extend 32) (_ bv4 32))) ((_ zero_extend 32) ?x64)) true)))
(let (($x384 (and (distinct (bvmul ((_ sign_extend 32) ?x127) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x64)) true)))
(let (($x628 (or false false)))
(let (($x235 (or $x628 false (or $x384 $x129))))
(and (not (or $x628 false (or $x384))) (or $x235 (and (distinct ?x64 ?x64) true))))))))))
(check-sat)
; query 8: function core_bench_list, block 82, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let (($x628 (or false false)))
(let (($x28 (not $x628)))
(and $x28 (or $x628 (and (distinct ((_ zero_extend 16) in.04_16) ((_ zero_extend 16) in.04_16)) true))))))
(check-sat)
; query 9: function core_bench_list, block 82, name %86
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x27 ((_ zero_extend 16) in.04_16)))
(let ((?x209 (bvsub (_ bv0 32) ?x27)))
(let ((?x127 ((_ zero_extend 16) in.02_16)))
(let ((?x64 (bvmul ?x127 (_ bv4 32))))
(let ((?x79 (bvadd ?x64 ?x209)))
(let ((?x243 (bvsub ?x64 ?x27)))
(let ((?x89 ((_ sign_extend 1) ?x79)))
(let ((?x139 ((_ sign_extend 1) ?x209)))
(let (($x628 (or false false)))
(let (($x212 (or false $x628 (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x27)) ?x139) true)))))
(let (($x129 (and (distinct (bvmul ((_ zero_extend 32) ?x127) ((_ zero_extend 32) (_ bv4 32))) ((_ zero_extend 32) ?x64)) true)))
(let (($x384 (and (distinct (bvmul ((_ sign_extend 32) ?x127) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x64)) true)))
(let (($x235 (or $x628 false (or $x384 $x129))))
(let (($x229 (or $x235 $x212 (or (and (distinct (bvadd ((_ sign_extend 1) ?x64) ?x139) ?x89) true)))))
(let ((?x602 ((_ sign_extend 1) ?x243)))
(let (($x720 (or $x628 false (or $x384))))
(let (($x679 (or $x720 $x628 (or (and (distinct (bvsub ((_ sign_extend 1) ?x64) ((_ sign_extend 1) ?x27)) ?x602) true)))))
(and (not $x679) (or $x229 (and (distinct ?x243 ?x79) true)))))))))))))))))))))
(check-sat)
; query 10: function core_bench_list, block 82, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x628 (or false false)))
(let (($x28 (not $x628)))
(and $x28 (or $x628 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 11: function core_bench_list, block 82, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x7 ((_ zero_extend 16) in.01_16)))
(let ((?x27 ((_ zero_extend 16) in.04_16)))
(let ((?x209 (bvsub (_ bv0 32) ?x27)))
(let ((?x127 ((_ zero_extend 16) in.02_16)))
(let ((?x64 (bvmul ?x127 (_ bv4 32))))
(let ((?x79 (bvadd ?x64 ?x209)))
(let ((?x1856 (bvadd ?x79 ?x7)))
(let ((?x243 (bvsub ?x64 ?x27)))
(let ((?x18 (bvadd ?x7 ?x243)))
(let (($x1323 (and (distinct (bvadd ((_ sign_extend 1) ?x79) ((_ sign_extend 1) ?x7)) ((_ sign_extend 1) ?x1856)) true)))
(let (($x628 (or false false)))
(let ((?x89 ((_ sign_extend 1) ?x79)))
(let ((?x139 ((_ sign_extend 1) ?x209)))
(let (($x212 (or false $x628 (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x27)) ?x139) true)))))
(let (($x129 (and (distinct (bvmul ((_ zero_extend 32) ?x127) ((_ zero_extend 32) (_ bv4 32))) ((_ zero_extend 32) ?x64)) true)))
(let (($x384 (and (distinct (bvmul ((_ sign_extend 32) ?x127) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x64)) true)))
(let (($x235 (or $x628 false (or $x384 $x129))))
(let (($x229 (or $x235 $x212 (or (and (distinct (bvadd ((_ sign_extend 1) ?x64) ?x139) ?x89) true)))))
(let (($x68 (or $x229 $x628 (or $x1323))))
(let (($x185 (and (distinct (bvadd ((_ sign_extend 1) ?x7) ((_ sign_extend 1) ?x243)) ((_ sign_extend 1) ?x18)) true)))
(let ((?x602 ((_ sign_extend 1) ?x243)))
(let (($x720 (or $x628 false (or $x384))))
(let (($x679 (or $x720 $x628 (or (and (distinct (bvsub ((_ sign_extend 1) ?x64) ((_ sign_extend 1) ?x27)) ?x602) true)))))
(let (($x564 (or $x628 $x679 (or $x185))))
(and (not $x564) (or $x68 (and (distinct ?x18 ?x1856) true))))))))))))))))))))))))))))
(check-sat)
; query 12: function core_bench_list, block 82, name %89
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x7 ((_ zero_extend 16) in.01_16)))
(let ((?x27 ((_ zero_extend 16) in.04_16)))
(let ((?x209 (bvsub (_ bv0 32) ?x27)))
(let ((?x127 ((_ zero_extend 16) in.02_16)))
(let ((?x64 (bvmul ?x127 (_ bv4 32))))
(let ((?x79 (bvadd ?x64 ?x209)))
(let ((?x1856 (bvadd ?x79 ?x7)))
(let (($x1323 (and (distinct (bvadd ((_ sign_extend 1) ?x79) ((_ sign_extend 1) ?x7)) ((_ sign_extend 1) ?x1856)) true)))
(let (($x628 (or false false)))
(let ((?x89 ((_ sign_extend 1) ?x79)))
(let ((?x139 ((_ sign_extend 1) ?x209)))
(let (($x212 (or false $x628 (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x27)) ?x139) true)))))
(let (($x129 (and (distinct (bvmul ((_ zero_extend 32) ?x127) ((_ zero_extend 32) (_ bv4 32))) ((_ zero_extend 32) ?x64)) true)))
(let (($x384 (and (distinct (bvmul ((_ sign_extend 32) ?x127) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x64)) true)))
(let (($x235 (or $x628 false (or $x384 $x129))))
(let (($x229 (or $x235 $x212 (or (and (distinct (bvadd ((_ sign_extend 1) ?x64) ?x139) ?x89) true)))))
(let (($x68 (or $x229 $x628 (or $x1323))))
(let (($x546 (or (or $x68 false) (and (distinct ((_ extract 15 0) (bvadd ?x7 (bvsub ?x64 ?x27))) ((_ extract 15 0) ?x1856)) true))))
(let (($x185 (and (distinct (bvadd ((_ sign_extend 1) ?x7) ((_ sign_extend 1) (bvsub ?x64 ?x27))) ((_ sign_extend 1) (bvadd ?x7 (bvsub ?x64 ?x27)))) true)))
(let ((?x243 (bvsub ?x64 ?x27)))
(let ((?x602 ((_ sign_extend 1) ?x243)))
(let (($x720 (or $x628 false (or $x384))))
(let (($x679 (or $x720 $x628 (or (and (distinct (bvsub ((_ sign_extend 1) ?x64) ((_ sign_extend 1) ?x27)) ?x602) true)))))
(let (($x564 (or $x628 $x679 (or $x185))))
(and (not (or $x564 false)) $x546))))))))))))))))))))))))))
(check-sat)
; query 13: function core_bench_list, block 82, name %90
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x628 (or false false)))
(let (($x28 (not $x628)))
(and $x28 (or $x628 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 14: function core_bench_list, block 82, name %91
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1480 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x628 (or false false)))
(let (($x816 (or $x628 false false)))
(let (($x1967 (not $x816)))
(and $x1967 (or $x816 (and (distinct ?x1480 ?x1480) true))))))))
(check-sat)
; query 15: function core_bench_state, block 105, name %106
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x318 (and (distinct (bvadd ((_ zero_extend 1) in.1_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x388 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x496 (or (or false false (or $x388 $x318)) (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))
(let (($x83 (or false false false)))
(let (($x43 (not $x83)))
(and $x43 $x496)))))))
(check-sat)
; query 16: function core_bench_state, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x338 (bvadd in.0_32 (_ bv1 32))))
(let (($x6691 (and (distinct ?x338 ?x338) true)))
(let (($x4964 (and (distinct (bvadd ((_ zero_extend 1) in.0_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) ?x338)) true)))
(let (($x5736 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x338)) true)))
(let (($x83 (or false false false)))
(let (($x43 (not $x83)))
(and $x43 (or (or false false (or $x5736 $x4964)) $x6691)))))))))
(check-sat)
; query 17: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x701 (bvadd in.01_32 (_ bv1 32))))
(let (($x5264 (and (distinct ?x701 ?x701) true)))
(let (($x83 (or false false false)))
(let (($x43 (not $x83)))
(and $x43 (or $x83 $x5264)))))))
(check-sat)
; query 18: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x701 (bvadd in.01_32 (_ bv1 32))))
(let ((?x3045 (bvmul ?x701 (_ bv8 32))))
(let ((?x5370 (bvmul ?x701 ?x701)))
(let (($x83 (or false false false)))
(let (($x4019 (or $x83 false false)))
(and (not (or $x83 $x83 false)) (or $x4019 (and (distinct ?x5370 ?x3045) true)))))))))
(check-sat)
; query 19: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x6414 (and (distinct (bvmul (bvmul (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) (_ bv2 32)) (bvmul (bvmul (bvadd in.01_32 (_ bv1 32)) (_ bv8 32)) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x83 (or false false false)))
(let (($x4019 (or $x83 false false)))
(and (not (or (or $x83 $x83 false) false false)) (or (or $x4019 $x83 false) $x6414))))))
(check-sat)
; query 20: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x5596 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x83 (or false false false)))
(let (($x43 (not $x83)))
(and $x43 (or $x83 (and (distinct ?x5596 ?x5596) true)))))))
(check-sat)
; query 21: function core_init_state, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_32 () (_ BitVec 32))
(assert
 (let (($x6772 (and (distinct (bvadd ((_ zero_extend 1) in.06_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.06_32 (_ bv1 32)))) true)))
(let (($x3010 (and (distinct (bvadd ((_ sign_extend 1) in.06_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.06_32 (_ bv1 32)))) true)))
(let (($x3966 (or (or false false (or $x3010 $x6772)) (and (distinct (bvadd in.06_32 (_ bv1 32)) (bvadd in.06_32 (_ bv1 32))) true))))
(let (($x83 (or false false false)))
(let (($x43 (not $x83)))
(and $x43 $x3966)))))))
(check-sat)
; query 22: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x6129 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x83 (or false false false)))
(let (($x43 (not $x83)))
(and $x43 (or $x83 (and (distinct ?x6129 ?x6129) true)))))))
(check-sat)
; query 23: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x83 (or false false false)))
(let (($x43 (not $x83)))
(and $x43 (or $x83 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 24: function core_list_init, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x701 (bvadd in.01_32 (_ bv1 32))))
(let (($x5264 (and (distinct ?x701 ?x701) true)))
(let (($x4699 (and (distinct (bvadd ((_ zero_extend 1) in.01_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) ?x701)) true)))
(let (($x83 (or false false false)))
(let (($x43 (not $x83)))
(and $x43 (or (or false false (or $x4699)) $x5264))))))))
(check-sat)
; query 25: function core_list_mergesort, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x701 (bvadd in.01_32 (_ bv1 32))))
(let (($x5264 (and (distinct ?x701 ?x701) true)))
(let (($x5071 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x701)) true)))
(let (($x4106 (or false false (or $x5071))))
(and (not $x4106) (or $x4106 $x5264)))))))
(check-sat)
; query 26: function core_list_mergesort, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x5317 (ite (bvslt (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x83 (or false false false)))
(let (($x43 (not $x83)))
(and $x43 (or $x83 (and (distinct ?x5317 ?x5317) true)))))))
(check-sat)
; query 27: function core_list_mergesort, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.224_32 () (_ BitVec 32))
(assert
 (let ((?x6071 (ite (= (_ bv0 32) in.224_32) (_ bv1 1) (_ bv0 1))))
(let (($x83 (or false false false)))
(let (($x43 (not $x83)))
(and $x43 (or $x83 (and (distinct ?x6071 ?x6071) true)))))))
(check-sat)
; query 28: function core_list_mergesort, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x5213 (ite (= (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x83 (or false false false)))
(let (($x43 (not $x83)))
(and $x43 (or $x83 (and (distinct ?x5213 ?x5213) true)))))))
(check-sat)
; query 29: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x2311 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x2407 (or false false (or $x2311))))
(and (not $x2407) (or $x2407 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 30: function core_list_mergesort, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x8024 (and (distinct (bvmul ((_ sign_extend 32) in.020_32) ((_ sign_extend 32) (_ bv2 32))) ((_ sign_extend 32) (bvmul in.020_32 (_ bv2 32)))) true)))
(let (($x308 (or false false (or $x8024))))
(and (not $x308) (or $x308 (and (distinct (bvmul in.020_32 (_ bv2 32)) (bvmul in.020_32 (_ bv2 32))) true))))))
(check-sat)
; query 31: function core_state_transition, block 102, name %103
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x628 (or false false)))
(let (($x28 (not $x628)))
(and $x28 (or $x628 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 32: function core_state_transition, block 102, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x494 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x628 (or false false)))
(let (($x816 (or $x628 false false)))
(let (($x1967 (not $x816)))
(and $x1967 (or $x816 (and (distinct ?x494 ?x494) true))))))))
(check-sat)
; query 33: function core_state_transition, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x628 (or false false)))
(let (($x28 (not $x628)))
(and $x28 (or $x628 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 34: function core_state_transition, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x596 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x628 (or false false)))
(let (($x816 (or $x628 false false)))
(let (($x1967 (not $x816)))
(and $x1967 (or $x816 (and (distinct ?x596 ?x596) true))))))))
(check-sat)
; query 35: function core_state_transition, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x628 (or false false)))
(let (($x28 (not $x628)))
(and $x28 (or $x628 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 36: function core_state_transition, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x494 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x628 (or false false)))
(let (($x816 (or $x628 false false)))
(let (($x1967 (not $x816)))
(and $x1967 (or $x816 (and (distinct ?x494 ?x494) true))))))))
(check-sat)
; query 37: function core_state_transition, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x628 (or false false)))
(let (($x28 (not $x628)))
(and $x28 (or $x628 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 38: function core_state_transition, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x985 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x628 (or false false)))
(let (($x816 (or $x628 false false)))
(let (($x1967 (not $x816)))
(and $x1967 (or $x816 (and (distinct ?x985 ?x985) true))))))))
(check-sat)
; query 39: function core_state_transition, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x628 (or false false)))
(let (($x28 (not $x628)))
(and $x28 (or $x628 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 40: function core_state_transition, block 51, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x985 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x628 (or false false)))
(let (($x816 (or $x628 false false)))
(let (($x1967 (not $x816)))
(and $x1967 (or $x816 (and (distinct ?x985 ?x985) true))))))))
(check-sat)
; query 41: function core_state_transition, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x628 (or false false)))
(let (($x28 (not $x628)))
(and $x28 (or $x628 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 42: function core_state_transition, block 64, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x985 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x628 (or false false)))
(let (($x816 (or $x628 false false)))
(let (($x1967 (not $x816)))
(and $x1967 (or $x816 (and (distinct ?x985 ?x985) true))))))))
(check-sat)
; query 43: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x1449 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x83 (or false false false)))
(let (($x43 (not $x83)))
(and $x43 (or $x83 (and (distinct ?x1449 ?x1449) true)))))))
(check-sat)
; query 44: function core_state_transition, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x628 (or false false)))
(let (($x28 (not $x628)))
(and $x28 (or $x628 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 45: function core_state_transition, block 80, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1224 (ite (= (_ bv69 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x628 (or false false)))
(let (($x816 (or $x628 false false)))
(let (($x1967 (not $x816)))
(and $x1967 (or $x816 (and (distinct ?x1224 ?x1224) true))))))))
(check-sat)
; query 46: function core_state_transition, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x628 (or false false)))
(let (($x28 (not $x628)))
(and $x28 (or $x628 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 47: function core_state_transition, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1051 (ite (= (_ bv101 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x628 (or false false)))
(let (($x816 (or $x628 false false)))
(let (($x1967 (not $x816)))
(and $x1967 (or $x816 (and (distinct ?x1051 ?x1051) true))))))))
(check-sat)
; query 48: function core_state_transition, block 99, name %100
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x628 (or false false)))
(let (($x28 (not $x628)))
(and $x28 (or $x628 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 49: function core_state_transition, block 99, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x596 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x628 (or false false)))
(let (($x816 (or $x628 false false)))
(let (($x1967 (not $x816)))
(and $x1967 (or $x816 (and (distinct ?x596 ?x596) true))))))))
(check-sat)
; query 50: function crcu8, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x628 (or false false)))
(let (($x28 (not $x628)))
(and $x28 (or $x628 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 51: function crcu8, block 19, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x7 ((_ zero_extend 16) in.01_16)))
(let ((?x1662 (bvxor ?x7 (_ bv16386 32))))
(let (($x628 (or false false)))
(let (($x816 (or $x628 false false)))
(let (($x1967 (not $x816)))
(and $x1967 (or $x816 (and (distinct ?x1662 ?x1662) true)))))))))
(check-sat)
; query 52: function crcu8, block 19, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x7 ((_ zero_extend 16) in.01_16)))
(let ((?x1662 (bvxor ?x7 (_ bv16386 32))))
(let ((?x1214 ((_ extract 15 0) ?x1662)))
(let (($x628 (or false false)))
(let (($x816 (or $x628 false false)))
(let (($x6699 (or (or $x816 (or (and (distinct ((_ zero_extend 16) ?x1214) ?x1662) true))) (and (distinct ?x1214 ?x1214) true))))
(let (($x13 (not (or $x816 false))))
(and $x13 $x6699)))))))))
(check-sat)
; query 53: function crcu8, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x93 (or false (or (= ((_ extract 15 15) in27_16) (_ bv1 1))))))
(let (($x628 (or false false)))
(let (($x28 (not $x628)))
(and $x28 (or $x93 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true)))))))
(check-sat)
; query 54: function crcu8, block 29, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1994 ((_ zero_extend 16) in27_16)))
(let ((?x6368 (bvor ?x1994 (_ bv32768 32))))
(let (($x93 (or false (or (= ((_ extract 15 15) in27_16) (_ bv1 1))))))
(let (($x2674 (or $x93 false false)))
(let (($x628 (or false false)))
(let (($x816 (or $x628 false false)))
(let (($x1967 (not $x816)))
(and $x1967 (or $x2674 (and (distinct ?x6368 ?x6368) true)))))))))))
(check-sat)
; query 55: function crcu8, block 29, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1994 ((_ zero_extend 16) in27_16)))
(let ((?x6368 (bvor ?x1994 (_ bv32768 32))))
(let ((?x6287 ((_ extract 15 0) ?x6368)))
(let (($x93 (or false (or (= ((_ extract 15 15) in27_16) (_ bv1 1))))))
(let (($x2674 (or $x93 false false)))
(let (($x3067 (or (or $x2674 (or (and (distinct ((_ zero_extend 16) ?x6287) ?x6368) true))) (and (distinct ?x6287 ?x6287) true))))
(let (($x13 (not (or (or (or false false) false false) false))))
(and $x13 $x3067)))))))))
(check-sat)
; query 56: function crcu8, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x5675 ((_ extract 7 0) in.01_16)))
(let ((?x1920 ((_ zero_extend 24) ?x5675)))
(let (($x628 (or false false)))
(let (($x1284 (or $x628 false)))
(and (not $x1284) (or $x1284 (and (distinct ?x1920 ?x1920) true))))))))
(check-sat)
; query 57: function crcu8, block 6, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x5675 ((_ extract 7 0) in.01_16)))
(let ((?x1920 ((_ zero_extend 24) ?x5675)))
(let ((?x3264 (bvand ?x1920 (_ bv1 32))))
(let (($x628 (or false false)))
(let (($x1284 (or $x628 false)))
(let (($x473 (or $x1284 false false)))
(and (not $x473) (or $x473 (and (distinct ?x3264 ?x3264) true))))))))))
(check-sat)
; query 58: function crcu8, block 6, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x5675 ((_ extract 7 0) in.01_16)))
(let ((?x1920 ((_ zero_extend 24) ?x5675)))
(let ((?x3264 (bvand ?x1920 (_ bv1 32))))
(let ((?x98 ((_ zero_extend 24) in.0_8)))
(let ((?x443 (bvand ?x98 (_ bv1 32))))
(let ((?x6768 (bvxor ?x443 ?x3264)))
(let (($x628 (or false false)))
(let (($x1284 (or $x628 false)))
(let (($x473 (or $x1284 false false)))
(let (($x816 (or $x628 false false)))
(let (($x6251 (or $x816 $x473 false)))
(and (not $x6251) (or $x6251 (and (distinct ?x6768 ?x6768) true)))))))))))))))
(check-sat)
; query 59: function crcu8, block 6, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x5675 ((_ extract 7 0) in.01_16)))
(let ((?x1920 ((_ zero_extend 24) ?x5675)))
(let ((?x3264 (bvand ?x1920 (_ bv1 32))))
(let ((?x98 ((_ zero_extend 24) in.0_8)))
(let ((?x443 (bvand ?x98 (_ bv1 32))))
(let ((?x6768 (bvxor ?x443 ?x3264)))
(let ((?x533 ((_ extract 7 0) ?x6768)))
(let (($x1463 (or (and (distinct ((_ zero_extend 24) ?x533) ?x6768) true) (and (distinct ((_ sign_extend 24) ?x533) ?x6768) true))))
(let (($x628 (or false false)))
(let (($x1284 (or $x628 false)))
(let (($x473 (or $x1284 false false)))
(let (($x816 (or $x628 false false)))
(let (($x6251 (or $x816 $x473 false)))
(let (($x8092 (or $x6251 $x1463)))
(and (not (or $x6251 false)) (or $x8092 (and (distinct ?x533 ?x533) true))))))))))))))))))
(check-sat)
; query 60: function crcu8, block 6, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x628 (or false false)))
(let (($x28 (not $x628)))
(and $x28 (or $x628 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 61: function crcu8, block 6, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x98 ((_ zero_extend 24) in.0_8)))
(let ((?x5965 (bvlshr ?x98 (_ bv1 32))))
(let ((?x2335 (bvashr ?x98 (_ bv1 32))))
(let (($x628 (or false false)))
(let (($x816 (or $x628 false false)))
(let (($x2304 (or $x816 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not $x2304) (or $x2304 (and (distinct ?x2335 ?x5965) true))))))))))
(check-sat)
; query 62: function crcu8, block 6, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x570 (and (distinct ((_ extract 7 0) (bvashr ((_ zero_extend 24) in.0_8) (_ bv1 32))) ((_ extract 7 0) (bvlshr ((_ zero_extend 24) in.0_8) (_ bv1 32)))) true)))
(let (($x628 (or false false)))
(let (($x816 (or $x628 false false)))
(let (($x2304 (or $x816 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x5411 (or $x2304 false)))
(and (not $x5411) (or $x5411 $x570))))))))
(check-sat)
; query 63: function crcu8, block 6, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x5675 ((_ extract 7 0) in.01_16)))
(let ((?x1920 ((_ zero_extend 24) ?x5675)))
(let ((?x3264 (bvand ?x1920 (_ bv1 32))))
(let ((?x98 ((_ zero_extend 24) in.0_8)))
(let ((?x443 (bvand ?x98 (_ bv1 32))))
(let ((?x6768 (bvxor ?x443 ?x3264)))
(let ((?x533 ((_ extract 7 0) ?x6768)))
(let ((?x3713 ((_ zero_extend 24) ?x533)))
(let (($x628 (or false false)))
(let (($x1284 (or $x628 false)))
(let (($x473 (or $x1284 false false)))
(let (($x816 (or $x628 false false)))
(let (($x6251 (or $x816 $x473 false)))
(let (($x8092 (or $x6251 (or (and (distinct ?x3713 ?x6768) true) (and (distinct ((_ sign_extend 24) ?x533) ?x6768) true)))))
(let (($x1553 (or $x8092 (or (= ((_ extract 7 7) ?x533) (_ bv1 1))))))
(and (not (or (or $x6251 false) false)) (or $x1553 (and (distinct ?x3713 ?x3713) true)))))))))))))))))))
(check-sat)
; query 64: function crcu8, block 6, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x5675 ((_ extract 7 0) in.01_16)))
(let ((?x1920 ((_ zero_extend 24) ?x5675)))
(let ((?x3264 (bvand ?x1920 (_ bv1 32))))
(let ((?x98 ((_ zero_extend 24) in.0_8)))
(let ((?x443 (bvand ?x98 (_ bv1 32))))
(let ((?x6768 (bvxor ?x443 ?x3264)))
(let ((?x533 ((_ extract 7 0) ?x6768)))
(let ((?x3713 ((_ zero_extend 24) ?x533)))
(let ((?x2730 (ite (= (_ bv1 32) ?x3713) (_ bv1 1) (_ bv0 1))))
(let (($x628 (or false false)))
(let (($x1284 (or $x628 false)))
(let (($x473 (or $x1284 false false)))
(let (($x816 (or $x628 false false)))
(let (($x6251 (or $x816 $x473 false)))
(let (($x8092 (or $x6251 (or (and (distinct ?x3713 ?x6768) true) (and (distinct ((_ sign_extend 24) ?x533) ?x6768) true)))))
(let (($x1553 (or $x8092 (or (= ((_ extract 7 7) ?x533) (_ bv1 1))))))
(and (not (or (or (or $x6251 false) false) false false)) (or (or $x1553 false false) (and (distinct ?x2730 ?x2730) true))))))))))))))))))))
(check-sat)
; query 65: function crcu8, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x628 (or false false)))
(let (($x28 (not $x628)))
(and $x28 (or $x628 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 66: function crcu8, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x98 ((_ zero_extend 24) in.0_8)))
(let ((?x443 (bvand ?x98 (_ bv1 32))))
(let (($x628 (or false false)))
(let (($x816 (or $x628 false false)))
(let (($x1967 (not $x816)))
(and $x1967 (or $x816 (and (distinct ?x443 ?x443) true)))))))))
(check-sat)
; query 67: function crcu8, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x628 (or false false)))
(let (($x28 (not $x628)))
(and $x28 (or $x628 (and (distinct ((_ extract 7 0) in.01_16) ((_ extract 7 0) in.01_16)) true))))))
(check-sat)
; query 68: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x477 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x83 (or false false false)))
(let (($x43 (not $x83)))
(and $x43 (or $x83 (and (distinct ?x477 ?x477) true)))))))
(check-sat)
; query 69: function matrix_add_const, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x338 (bvadd in.0_32 (_ bv1 32))))
(let (($x6691 (and (distinct ?x338 ?x338) true)))
(let (($x83 (or false false false)))
(let (($x43 (not $x83)))
(and $x43 (or $x83 $x6691)))))))
(check-sat)
; query 70: function matrix_add_const, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x701 (bvadd in.01_32 (_ bv1 32))))
(let (($x5264 (and (distinct ?x701 ?x701) true)))
(let (($x83 (or false false false)))
(let (($x43 (not $x83)))
(and $x43 (or $x83 $x5264)))))))
(check-sat)
; query 71: function matrix_mul_const, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x338 (bvadd in.0_32 (_ bv1 32))))
(let (($x6691 (and (distinct ?x338 ?x338) true)))
(let (($x83 (or false false false)))
(let (($x43 (not $x83)))
(and $x43 (or $x83 $x6691)))))))
(check-sat)
; query 72: function matrix_mul_const, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x701 (bvadd in.01_32 (_ bv1 32))))
(let (($x5264 (and (distinct ?x701 ?x701) true)))
(let (($x83 (or false false false)))
(let (($x43 (not $x83)))
(and $x43 (or $x83 $x5264)))))))
(check-sat)
; query 73: function matrix_mul_matrix, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x338 (bvadd in.0_32 (_ bv1 32))))
(let (($x6691 (and (distinct ?x338 ?x338) true)))
(let (($x83 (or false false false)))
(let (($x43 (not $x83)))
(and $x43 (or $x83 $x6691)))))))
(check-sat)
; query 74: function matrix_mul_matrix, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x701 (bvadd in.01_32 (_ bv1 32))))
(let (($x5264 (and (distinct ?x701 ?x701) true)))
(let (($x83 (or false false false)))
(let (($x43 (not $x83)))
(and $x43 (or $x83 $x5264)))))))
(check-sat)
; query 75: function matrix_mul_matrix, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x83 (or false false false)))
(let (($x43 (not $x83)))
(and $x43 (or $x83 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 76: function matrix_mul_matrix_bitextract, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x338 (bvadd in.0_32 (_ bv1 32))))
(let (($x6691 (and (distinct ?x338 ?x338) true)))
(let (($x83 (or false false false)))
(let (($x43 (not $x83)))
(and $x43 (or $x83 $x6691)))))))
(check-sat)
; query 77: function matrix_mul_matrix_bitextract, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x701 (bvadd in.01_32 (_ bv1 32))))
(let (($x5264 (and (distinct ?x701 ?x701) true)))
(let (($x83 (or false false false)))
(let (($x43 (not $x83)))
(and $x43 (or $x83 $x5264)))))))
(check-sat)
; query 78: function matrix_mul_matrix_bitextract, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x83 (or false false false)))
(let (($x43 (not $x83)))
(and $x43 (or $x83 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 79: function matrix_mul_vect, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x338 (bvadd in.0_32 (_ bv1 32))))
(let (($x6691 (and (distinct ?x338 ?x338) true)))
(let (($x83 (or false false false)))
(let (($x43 (not $x83)))
(and $x43 (or $x83 $x6691)))))))
(check-sat)
; query 80: function matrix_mul_vect, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x701 (bvadd in.01_32 (_ bv1 32))))
(let (($x5264 (and (distinct ?x701 ?x701) true)))
(let (($x83 (or false false false)))
(let (($x43 (not $x83)))
(and $x43 (or $x83 $x5264)))))))
(check-sat)
; query 81: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x628 (or false false)))
(let (($x28 (not $x628)))
(and $x28 (or $x628 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 82: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x2805 ((_ sign_extend 16) in.1_16)))
(let ((?x1616 (bvadd ?x2805 (_ bv10 32))))
(let (($x5062 (and (distinct (bvadd ((_ sign_extend 1) ?x2805) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x1616)) true)))
(let (($x628 (or false false)))
(let (($x2596 (or $x628 false (or $x5062))))
(and (not $x2596) (or $x2596 (and (distinct ?x1616 ?x1616) true)))))))))
(check-sat)
; query 83: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x2805 ((_ sign_extend 16) in.1_16)))
(let ((?x1616 (bvadd ?x2805 (_ bv10 32))))
(let ((?x1827 ((_ extract 15 0) ?x1616)))
(let (($x5062 (and (distinct (bvadd ((_ sign_extend 1) ?x2805) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x1616)) true)))
(let (($x628 (or false false)))
(let (($x2596 (or $x628 false (or $x5062))))
(let (($x1459 (or $x2596 false)))
(and (not $x1459) (or $x1459 (and (distinct ?x1827 ?x1827) true)))))))))))
(check-sat)
; query 84: function partition_memory, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x338 (bvadd in.0_32 (_ bv1 32))))
(let (($x6691 (and (distinct ?x338 ?x338) true)))
(let (($x4964 (and (distinct (bvadd ((_ zero_extend 1) in.0_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) ?x338)) true)))
(let (($x5736 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x338)) true)))
(let (($x83 (or false false false)))
(let (($x43 (not $x83)))
(and $x43 (or (or false false (or $x5736 $x4964)) $x6691)))))))))
(check-sat)
