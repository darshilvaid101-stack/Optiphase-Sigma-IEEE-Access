; OptiPhase-Sigma refinement certificate for sweep K52-R3-207
; query 0: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x383 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x155 (or false false false)))
(let (($x746 (not $x155)))
(and $x746 (or $x155 (and (distinct ?x383 ?x383) true)))))))
(check-sat)
; query 1: function set1d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x364 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x155 (or false false false)))
(let (($x746 (not $x155)))
(and $x746 (or $x155 (and (distinct ?x364 ?x364) true)))))))
(check-sat)
; query 2: function set1ds, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x481 (ite (= (_ bv4294967295 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x155 (or false false false)))
(let (($x746 (not $x155)))
(and $x746 (or $x155 (and (distinct ?x481 ?x481) true)))))))
(check-sat)
; query 3: function set2d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x364 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x155 (or false false false)))
(let (($x746 (not $x155)))
(and $x746 (or $x155 (and (distinct ?x364 ?x364) true)))))))
(check-sat)
