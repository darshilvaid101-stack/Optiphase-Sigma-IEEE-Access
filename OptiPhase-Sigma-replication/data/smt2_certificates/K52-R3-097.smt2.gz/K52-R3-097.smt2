; OptiPhase-Sigma refinement certificate for sweep K52-R3-097
; query 0: function s162, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x547 (ite (bvslt (_ bv0 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x119 (or false false false)))
(and (not $x119) (or $x119 (and (distinct ?x547 ?x547) true))))))
(check-sat)
