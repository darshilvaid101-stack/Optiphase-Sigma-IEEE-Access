; OptiPhase-Sigma refinement certificate for sweep K41-R2-011
; query 0: function set_key, block 11, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let (($x11 (or false false false)))
(let (($x139 (not $x11)))
(and $x139 (or $x11 (and (distinct (bvand in2_32 (_ bv1 32)) (bvand in2_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function set_key, block 11, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x34 (ite (and (distinct (_ bv0 32) (bvand in2_32 (_ bv1 32))) true) (_ bv1 1) (_ bv0 1))))
(let (($x11 (or false false false)))
(let (($x384 (or $x11 false false)))
(let (($x756 (not $x384)))
(and $x756 (or $x384 (and (distinct ?x34 ?x34) true))))))))
(check-sat)
; query 2: function set_key, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let (($x11 (or false false false)))
(let (($x139 (not $x11)))
(and $x139 (or $x11 (and (distinct (bvand in2_32 (_ bv2 32)) (bvand in2_32 (_ bv2 32))) true))))))
(check-sat)
; query 3: function set_key, block 14, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x331 (ite (and (distinct (_ bv0 32) (bvand in2_32 (_ bv2 32))) true) (_ bv1 1) (_ bv0 1))))
(let (($x11 (or false false false)))
(let (($x384 (or $x11 false false)))
(let (($x756 (not $x384)))
(and $x756 (or $x384 (and (distinct ?x331 ?x331) true))))))))
(check-sat)
; query 4: function set_key, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x279 (ite (and (distinct (_ bv0 64) in1_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x11 (or false false false)))
(let (($x139 (not $x11)))
(and $x139 (or $x11 (and (distinct ?x279 ?x279) true)))))))
(check-sat)
; query 5: function set_key, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x131 (ite (bvult in1_64 (_ bv16 64)) (_ bv1 1) (_ bv0 1))))
(let (($x11 (or false false false)))
(let (($x139 (not $x11)))
(and $x139 (or $x11 (and (distinct ?x131 ?x131) true)))))))
(check-sat)
; query 6: function set_key, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x124 (ite (bvugt in1_64 (_ bv32 64)) (_ bv1 1) (_ bv0 1))))
(let (($x11 (or false false false)))
(let (($x139 (not $x11)))
(and $x139 (or $x11 (and (distinct ?x124 ?x124) true)))))))
(check-sat)
; query 7: function set_key, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let (($x11 (or false false false)))
(let (($x139 (not $x11)))
(and $x139 (or $x11 (and (distinct (bvand in1_64 (_ bv7 64)) (bvand in1_64 (_ bv7 64))) true))))))
(check-sat)
; query 8: function set_key, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x497 (ite (and (distinct (_ bv0 64) (bvand in1_64 (_ bv7 64))) true) (_ bv1 1) (_ bv0 1))))
(let (($x11 (or false false false)))
(let (($x384 (or $x11 false false)))
(let (($x756 (not $x384)))
(and $x756 (or $x384 (and (distinct ?x497 ?x497) true))))))))
(check-sat)
