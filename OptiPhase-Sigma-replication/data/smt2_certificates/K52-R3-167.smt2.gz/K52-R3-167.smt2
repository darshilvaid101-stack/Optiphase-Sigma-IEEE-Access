; OptiPhase-Sigma refinement certificate for sweep K52-R3-167
; query 0: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x851 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x413 (or false false false)))
(let (($x547 (not $x413)))
(and $x547 (or $x413 (and (distinct ?x851 ?x851) true)))))))
(check-sat)
; query 1: function set1d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x1346 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x413 (or false false false)))
(let (($x547 (not $x413)))
(and $x547 (or $x413 (and (distinct ?x1346 ?x1346) true)))))))
(check-sat)
; query 2: function set1ds, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x1336 (ite (= (_ bv4294967295 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x413 (or false false false)))
(let (($x547 (not $x413)))
(and $x547 (or $x413 (and (distinct ?x1336 ?x1336) true)))))))
(check-sat)
; query 3: function set2d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x1346 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x413 (or false false false)))
(let (($x547 (not $x413)))
(and $x547 (or $x413 (and (distinct ?x1346 ?x1346) true)))))))
(check-sat)
