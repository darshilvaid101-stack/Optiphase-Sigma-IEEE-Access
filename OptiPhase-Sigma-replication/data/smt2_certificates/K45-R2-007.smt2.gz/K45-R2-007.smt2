; OptiPhase-Sigma refinement certificate for sweep K45-R2-007
; query 0: function Index_to_frequency, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x79 (ite (bvuge in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x114 (or false false false)))
(let (($x342 (not $x114)))
(and $x342 (or $x114 (and (distinct ?x79 ?x79) true)))))))
(check-sat)
; query 1: function IsPowerOfTwo, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x114 (or false false false)))
(let (($x342 (not $x114)))
(and $x342 (or $x114 (and (distinct (bvsub in0_32 (_ bv1 32)) (bvsub in0_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function IsPowerOfTwo, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x32 (bvsub in0_32 (_ bv1 32))))
(let ((?x61 (bvand in0_32 ?x32)))
(let (($x114 (or false false false)))
(let (($x121 (or false $x114 false)))
(and (not $x121) (or $x121 (and (distinct ?x61 ?x61) true))))))))
(check-sat)
; query 3: function IsPowerOfTwo, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x498 (ite (and (distinct (_ bv0 32) (bvand in0_32 (bvsub in0_32 (_ bv1 32)))) true) (_ bv1 1) (_ bv0 1))))
(let (($x114 (or false false false)))
(let (($x121 (or false $x114 false)))
(let (($x111 (or $x121 false false)))
(and (not $x111) (or $x111 (and (distinct ?x498 ?x498) true))))))))
(check-sat)
; query 4: function IsPowerOfTwo, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x24 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x114 (or false false false)))
(let (($x342 (not $x114)))
(and $x342 (or $x114 (and (distinct ?x24 ?x24) true)))))))
(check-sat)
; query 5: function NumberOfBitsNeeded, block 13, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x114 (or false false false)))
(let (($x342 (not $x114)))
(and $x342 (or $x114 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 6: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x24 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x114 (or false false false)))
(let (($x342 (not $x114)))
(and $x342 (or $x114 (and (distinct ?x24 ?x24) true)))))))
(check-sat)
; query 7: function ReverseBits, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x114 (or false false false)))
(let (($x342 (not $x114)))
(and $x342 (or $x114 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function ReverseBits, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x114 (or false false false)))
(let (($x646 (or $x114 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x135 (not $x646)))
(and $x135 (or $x646 (and (distinct (bvshl in.01_32 (_ bv1 32)) (bvshl in.01_32 (_ bv1 32))) true)))))))
(check-sat)
; query 9: function ReverseBits, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x114 (or false false false)))
(let (($x342 (not $x114)))
(and $x342 (or $x114 (and (distinct (bvand in.0_32 (_ bv1 32)) (bvand in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 10: function ReverseBits, block 5, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x449 (bvand in.0_32 (_ bv1 32))))
(let ((?x127 (bvshl in.01_32 (_ bv1 32))))
(let ((?x116 (bvor ?x127 ?x449)))
(let (($x114 (or false false false)))
(let (($x646 (or $x114 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x50 (or $x646 $x114 false)))
(and (not $x50) (or $x50 (and (distinct ?x116 ?x116) true))))))))))
(check-sat)
; query 11: function ReverseBits, block 5, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x114 (or false false false)))
(let (($x646 (or $x114 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x135 (not $x646)))
(and $x135 (or $x646 (and (distinct (bvlshr in.0_32 (_ bv1 32)) (bvlshr in.0_32 (_ bv1 32))) true)))))))
(check-sat)
; query 12: function main, block 110, name %111
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x114 (or false false false)))
(let (($x342 (not $x114)))
(and $x342 (or $x114 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 13: function main, block 113, name %114
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x114 (or false false false)))
(let (($x342 (not $x114)))
(and $x342 (or $x114 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 14: function main, block 126, name %127
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let (($x114 (or false false false)))
(let (($x342 (not $x114)))
(and $x342 (or $x114 (and (distinct (bvadd in.2_32 (_ bv1 32)) (bvadd in.2_32 (_ bv1 32))) true))))))
(check-sat)
; query 15: function main, block 139, name %140
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.3_32 () (_ BitVec 32))
(assert
 (let (($x114 (or false false false)))
(let (($x342 (not $x114)))
(and $x342 (or $x114 (and (distinct (bvadd in.3_32 (_ bv1 32)) (bvadd in.3_32 (_ bv1 32))) true))))))
(check-sat)
; query 16: function main, block 57, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x114 (or false false false)))
(let (($x342 (not $x114)))
(and $x342 (or $x114 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 17: function main, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x359 (ite (= (_ bv4 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x114 (or false false false)))
(let (($x342 (not $x114)))
(and $x342 (or $x114 (and (distinct ?x359 ?x359) true)))))))
(check-sat)
; query 18: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x267 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x114 (or false false false)))
(let (($x342 (not $x114)))
(and $x342 (or $x114 (and (distinct ?x267 ?x267) true)))))))
(check-sat)
