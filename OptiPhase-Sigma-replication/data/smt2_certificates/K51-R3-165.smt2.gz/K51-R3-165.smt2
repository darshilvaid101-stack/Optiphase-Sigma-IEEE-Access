; OptiPhase-Sigma refinement certificate for sweep K51-R3-165
; query 0: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x1859 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x1932 (or false false false)))
(let (($x1886 (not $x1932)))
(and $x1886 (or $x1932 (and (distinct ?x1859 ?x1859) true)))))))
(check-sat)
; query 1: function set1d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x807 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x1932 (or false false false)))
(let (($x1886 (not $x1932)))
(and $x1886 (or $x1932 (and (distinct ?x807 ?x807) true)))))))
(check-sat)
; query 2: function set1ds, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x851 (ite (= (_ bv4294967295 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x1932 (or false false false)))
(let (($x1886 (not $x1932)))
(and $x1886 (or $x1932 (and (distinct ?x851 ?x851) true)))))))
(check-sat)
; query 3: function set2d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x807 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x1932 (or false false false)))
(let (($x1886 (not $x1932)))
(and $x1886 (or $x1932 (and (distinct ?x807 ?x807) true)))))))
(check-sat)
