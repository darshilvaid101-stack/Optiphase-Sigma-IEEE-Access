; OptiPhase-Sigma refinement certificate for sweep K17-R2-063
