; OptiPhase-Sigma refinement certificate for sweep K03-R3-232
; query 0: function init_array, block 66, name %67
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x94 (and (distinct (bvadd ((_ zero_extend 1) in.0_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x85 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x97 (or (or false false (or $x85 $x94)) (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))
(and (not (or false false (or $x85))) $x97)))))
(check-sat)
; query 1: function init_array, block 69, name %70
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x25 (and (distinct (bvadd ((_ zero_extend 1) in.01_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x8 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x7 (or (or false false (or $x8 $x25)) (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))
(and (not (or false false (or $x8))) $x7)))))
(check-sat)
; query 2: function kernel_gemver, block 111, name %112
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let (($x42 (and (distinct (bvadd ((_ zero_extend 1) in.2_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.2_32 (_ bv1 32)))) true)))
(let (($x15 (and (distinct (bvadd ((_ sign_extend 1) in.2_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.2_32 (_ bv1 32)))) true)))
(let (($x59 (or (or false false (or $x15 $x42)) (and (distinct (bvadd in.2_32 (_ bv1 32)) (bvadd in.2_32 (_ bv1 32))) true))))
(and (not (or false false (or $x15))) $x59)))))
(check-sat)
; query 3: function kernel_gemver, block 114, name %115
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.3_32 () (_ BitVec 32))
(assert
 (let (($x57 (and (distinct (bvadd ((_ zero_extend 1) in.3_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.3_32 (_ bv1 32)))) true)))
(let (($x58 (and (distinct (bvadd ((_ sign_extend 1) in.3_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.3_32 (_ bv1 32)))) true)))
(let (($x50 (or (or false false (or $x58 $x57)) (and (distinct (bvadd in.3_32 (_ bv1 32)) (bvadd in.3_32 (_ bv1 32))) true))))
(and (not (or false false (or $x58))) $x50)))))
(check-sat)
; query 4: function kernel_gemver, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x94 (and (distinct (bvadd ((_ zero_extend 1) in.0_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x85 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x97 (or (or false false (or $x85 $x94)) (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))
(and (not (or false false (or $x85))) $x97)))))
(check-sat)
; query 5: function kernel_gemver, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x25 (and (distinct (bvadd ((_ zero_extend 1) in.01_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x8 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x7 (or (or false false (or $x8 $x25)) (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))
(and (not (or false false (or $x8))) $x7)))))
(check-sat)
; query 6: function kernel_gemver, block 69, name %70
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x68 (and (distinct (bvadd ((_ zero_extend 1) in.1_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x63 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x74 (or (or false false (or $x63 $x68)) (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))
(and (not (or false false (or $x63))) $x74)))))
(check-sat)
; query 7: function kernel_gemver, block 72, name %73
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x108 (and (distinct (bvadd ((_ zero_extend 1) in.12_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.12_32 (_ bv1 32)))) true)))
(let (($x105 (and (distinct (bvadd ((_ sign_extend 1) in.12_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.12_32 (_ bv1 32)))) true)))
(let (($x119 (or (or false false (or $x105 $x108)) (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))
(and (not (or false false (or $x105))) $x119)))))
(check-sat)
; query 8: function kernel_gemver, block 87, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.23_32 () (_ BitVec 32))
(assert
 (let (($x114 (and (distinct (bvadd ((_ zero_extend 1) in.23_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.23_32 (_ bv1 32)))) true)))
(let (($x130 (and (distinct (bvadd ((_ sign_extend 1) in.23_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.23_32 (_ bv1 32)))) true)))
(let (($x132 (or (or false false (or $x130 $x114)) (and (distinct (bvadd in.23_32 (_ bv1 32)) (bvadd in.23_32 (_ bv1 32))) true))))
(and (not (or false false (or $x130))) $x132)))))
(check-sat)
