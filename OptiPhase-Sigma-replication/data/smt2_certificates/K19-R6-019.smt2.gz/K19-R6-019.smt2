; OptiPhase-Sigma refinement certificate for sweep K19-R6-019
