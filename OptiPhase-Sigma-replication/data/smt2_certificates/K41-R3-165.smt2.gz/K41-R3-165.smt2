; OptiPhase-Sigma refinement certificate for sweep K41-R3-165
; query 0: function decfile, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in17_32 () (_ BitVec 32))
(assert
 (let ((?x343 (ite (and (distinct (_ bv16 32) in17_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x471 (or false false false)))
(let (($x836 (not $x471)))
(and $x836 (or $x471 (and (distinct ?x343 ?x343) true)))))))
(check-sat)
; query 1: function main, block 41, name %42
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let (($x678 (or false false)))
(and (not $x678) (or $x678 (and (distinct ((_ sign_extend 24) in38_8) ((_ sign_extend 24) in38_8)) true)))))
(check-sat)
; query 2: function main, block 41, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let ((?x271 (ite (bvsge (_ bv57 32) ((_ sign_extend 24) in38_8)) (_ bv1 1) (_ bv0 1))))
(let (($x678 (or false false)))
(let (($x81 (or $x678 false false)))
(let (($x134 (not $x81)))
(and $x134 (or $x81 (and (distinct ?x271 ?x271) true))))))))
(check-sat)
; query 3: function main, block 44, name %45
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x471 (or false false false)))
(let (($x26 (or $x471 (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x26) (or $x26 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvshl in.01_32 (_ bv4 32))) true))))))
(check-sat)
; query 4: function main, block 44, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let (($x678 (or false false)))
(and (not $x678) (or $x678 (and (distinct ((_ sign_extend 24) in38_8) ((_ sign_extend 24) in38_8)) true)))))
(check-sat)
; query 5: function main, block 44, name %47
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x663 ((_ sign_extend 24) in38_8)))
(let ((?x12 (bvshl in.01_32 (_ bv4 32))))
(let ((?x583 (bvadd ?x12 ?x663)))
(let ((?x228 ((_ sign_extend 1) ?x583)))
(let (($x678 (or false false)))
(let (($x471 (or false false false)))
(let (($x26 (or $x471 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x161 (or $x26 $x678 (or (and (distinct (bvadd ((_ sign_extend 1) ?x12) ((_ sign_extend 1) ?x663)) ?x228) true)))))
(and (not $x161) (or $x161 (and (distinct ?x583 ?x583) true))))))))))))
(check-sat)
; query 6: function main, block 44, name %48
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x663 ((_ sign_extend 24) in38_8)))
(let ((?x12 (bvshl in.01_32 (_ bv4 32))))
(let ((?x583 (bvadd ?x12 ?x663)))
(let ((?x54 (bvsub ?x583 (_ bv48 32))))
(let (($x777 (and (distinct (bvsub ((_ sign_extend 1) ?x583) ((_ sign_extend 1) (_ bv48 32))) ((_ sign_extend 1) ?x54)) true)))
(let ((?x228 ((_ sign_extend 1) ?x583)))
(let (($x678 (or false false)))
(let (($x471 (or false false false)))
(let (($x26 (or $x471 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x161 (or $x26 $x678 (or (and (distinct (bvadd ((_ sign_extend 1) ?x12) ((_ sign_extend 1) ?x663)) ?x228) true)))))
(let (($x77 (or $x161 false (or $x777))))
(and (not $x77) (or $x77 (and (distinct ?x54 ?x54) true)))))))))))))))
(check-sat)
; query 7: function main, block 49, name %50
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let (($x678 (or false false)))
(and (not $x678) (or $x678 (and (distinct ((_ sign_extend 24) in38_8) ((_ sign_extend 24) in38_8)) true)))))
(check-sat)
; query 8: function main, block 49, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let ((?x329 (ite (bvsle (_ bv65 32) ((_ sign_extend 24) in38_8)) (_ bv1 1) (_ bv0 1))))
(let (($x678 (or false false)))
(let (($x81 (or $x678 false false)))
(let (($x134 (not $x81)))
(and $x134 (or $x81 (and (distinct ?x329 ?x329) true))))))))
(check-sat)
; query 9: function main, block 52, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let (($x678 (or false false)))
(and (not $x678) (or $x678 (and (distinct ((_ sign_extend 24) in38_8) ((_ sign_extend 24) in38_8)) true)))))
(check-sat)
; query 10: function main, block 52, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let ((?x100 (ite (bvsge (_ bv70 32) ((_ sign_extend 24) in38_8)) (_ bv1 1) (_ bv0 1))))
(let (($x678 (or false false)))
(let (($x81 (or $x678 false false)))
(let (($x134 (not $x81)))
(and $x134 (or $x81 (and (distinct ?x100 ?x100) true))))))))
(check-sat)
; query 11: function main, block 55, name %56
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x471 (or false false false)))
(let (($x26 (or $x471 (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x26) (or $x26 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvshl in.01_32 (_ bv4 32))) true))))))
(check-sat)
; query 12: function main, block 55, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let (($x678 (or false false)))
(and (not $x678) (or $x678 (and (distinct ((_ sign_extend 24) in38_8) ((_ sign_extend 24) in38_8)) true)))))
(check-sat)
; query 13: function main, block 55, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x663 ((_ sign_extend 24) in38_8)))
(let ((?x12 (bvshl in.01_32 (_ bv4 32))))
(let ((?x583 (bvadd ?x12 ?x663)))
(let ((?x228 ((_ sign_extend 1) ?x583)))
(let (($x678 (or false false)))
(let (($x471 (or false false false)))
(let (($x26 (or $x471 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x161 (or $x26 $x678 (or (and (distinct (bvadd ((_ sign_extend 1) ?x12) ((_ sign_extend 1) ?x663)) ?x228) true)))))
(and (not $x161) (or $x161 (and (distinct ?x583 ?x583) true))))))))))))
(check-sat)
; query 14: function main, block 55, name %59
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x663 ((_ sign_extend 24) in38_8)))
(let ((?x12 (bvshl in.01_32 (_ bv4 32))))
(let ((?x583 (bvadd ?x12 ?x663)))
(let ((?x121 (bvsub ?x583 (_ bv65 32))))
(let ((?x50 ((_ sign_extend 1) ?x121)))
(let ((?x228 ((_ sign_extend 1) ?x583)))
(let (($x678 (or false false)))
(let (($x471 (or false false false)))
(let (($x26 (or $x471 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x161 (or $x26 $x678 (or (and (distinct (bvadd ((_ sign_extend 1) ?x12) ((_ sign_extend 1) ?x663)) ?x228) true)))))
(let (($x254 (or $x161 false (or (and (distinct (bvsub ?x228 ((_ sign_extend 1) (_ bv65 32))) ?x50) true)))))
(and (not $x254) (or $x254 (and (distinct ?x121 ?x121) true)))))))))))))))
(check-sat)
; query 15: function main, block 55, name %60
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x663 ((_ sign_extend 24) in38_8)))
(let ((?x12 (bvshl in.01_32 (_ bv4 32))))
(let ((?x583 (bvadd ?x12 ?x663)))
(let ((?x121 (bvsub ?x583 (_ bv65 32))))
(let ((?x220 (bvadd ?x121 (_ bv10 32))))
(let (($x48 (and (distinct (bvadd ((_ sign_extend 1) ?x121) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x220)) true)))
(let ((?x50 ((_ sign_extend 1) ?x121)))
(let ((?x228 ((_ sign_extend 1) ?x583)))
(let (($x678 (or false false)))
(let (($x471 (or false false false)))
(let (($x26 (or $x471 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x161 (or $x26 $x678 (or (and (distinct (bvadd ((_ sign_extend 1) ?x12) ((_ sign_extend 1) ?x663)) ?x228) true)))))
(let (($x254 (or $x161 false (or (and (distinct (bvsub ?x228 ((_ sign_extend 1) (_ bv65 32))) ?x50) true)))))
(let (($x232 (or $x254 false (or $x48))))
(and (not $x232) (or $x232 (and (distinct ?x220 ?x220) true))))))))))))))))))
(check-sat)
; query 16: function main, block 81, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x105 (ite (bvsgt (_ bv32 32) in.06.lcssa_32) (_ bv1 1) (_ bv0 1))))
(let (($x471 (or false false false)))
(let (($x836 (not $x471)))
(and $x836 (or $x471 (and (distinct ?x105 ?x105) true)))))))
(check-sat)
; query 17: function main, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06.lcssa_32 () (_ BitVec 32))
(assert
 (let (($x471 (or false false false)))
(let (($x561 (or $x471 (and (distinct (bvand in.06.lcssa_32 (_ bv15 32)) (bvand in.06.lcssa_32 (_ bv15 32))) true))))
(let (($x836 (not $x471)))
(and $x836 $x561)))))
(check-sat)
; query 18: function main, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x110 (ite (and (distinct (_ bv0 32) (bvand in.06.lcssa_32 (_ bv15 32))) true) (_ bv1 1) (_ bv0 1))))
(let (($x471 (or false false false)))
(let (($x167 (or $x471 false false)))
(let (($x117 (not $x167)))
(and $x117 (or $x167 (and (distinct ?x110 ?x110) true))))))))
(check-sat)
; query 19: function set_key, block 11, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let (($x471 (or false false false)))
(let (($x836 (not $x471)))
(and $x836 (or $x471 (and (distinct (bvand in2_32 (_ bv1 32)) (bvand in2_32 (_ bv1 32))) true))))))
(check-sat)
; query 20: function set_key, block 11, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x90 (ite (and (distinct (_ bv0 32) (bvand in2_32 (_ bv1 32))) true) (_ bv1 1) (_ bv0 1))))
(let (($x471 (or false false false)))
(let (($x167 (or $x471 false false)))
(let (($x117 (not $x167)))
(and $x117 (or $x167 (and (distinct ?x90 ?x90) true))))))))
(check-sat)
; query 21: function set_key, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let (($x471 (or false false false)))
(let (($x836 (not $x471)))
(and $x836 (or $x471 (and (distinct (bvand in2_32 (_ bv2 32)) (bvand in2_32 (_ bv2 32))) true))))))
(check-sat)
; query 22: function set_key, block 14, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x39 (ite (and (distinct (_ bv0 32) (bvand in2_32 (_ bv2 32))) true) (_ bv1 1) (_ bv0 1))))
(let (($x471 (or false false false)))
(let (($x167 (or $x471 false false)))
(let (($x117 (not $x167)))
(and $x117 (or $x167 (and (distinct ?x39 ?x39) true))))))))
(check-sat)
; query 23: function set_key, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x360 (ite (and (distinct (_ bv0 64) in1_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x471 (or false false false)))
(let (($x836 (not $x471)))
(and $x836 (or $x471 (and (distinct ?x360 ?x360) true)))))))
(check-sat)
; query 24: function set_key, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x253 (ite (bvult in1_64 (_ bv16 64)) (_ bv1 1) (_ bv0 1))))
(let (($x471 (or false false false)))
(let (($x836 (not $x471)))
(and $x836 (or $x471 (and (distinct ?x253 ?x253) true)))))))
(check-sat)
; query 25: function set_key, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x15 (ite (bvugt in1_64 (_ bv32 64)) (_ bv1 1) (_ bv0 1))))
(let (($x471 (or false false false)))
(let (($x836 (not $x471)))
(and $x836 (or $x471 (and (distinct ?x15 ?x15) true)))))))
(check-sat)
; query 26: function set_key, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let (($x471 (or false false false)))
(let (($x836 (not $x471)))
(and $x836 (or $x471 (and (distinct (bvand in1_64 (_ bv7 64)) (bvand in1_64 (_ bv7 64))) true))))))
(check-sat)
; query 27: function set_key, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x106 (ite (and (distinct (_ bv0 64) (bvand in1_64 (_ bv7 64))) true) (_ bv1 1) (_ bv0 1))))
(let (($x471 (or false false false)))
(let (($x167 (or $x471 false false)))
(let (($x117 (not $x167)))
(and $x117 (or $x167 (and (distinct ?x106 ?x106) true))))))))
(check-sat)
