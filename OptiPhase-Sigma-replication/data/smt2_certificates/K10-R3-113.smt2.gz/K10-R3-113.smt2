; OptiPhase-Sigma refinement certificate for sweep K10-R3-113
