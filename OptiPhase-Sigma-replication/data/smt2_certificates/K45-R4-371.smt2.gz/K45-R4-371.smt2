; OptiPhase-Sigma refinement certificate for sweep K45-R4-371
; query 0: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x98 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x276 (or false false false)))
(let (($x167 (not $x276)))
(and $x167 (or $x276 (and (distinct ?x98 ?x98) true)))))))
(check-sat)
; query 1: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x533 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x276 (or false false false)))
(let (($x167 (not $x276)))
(and $x167 (or $x276 (and (distinct ?x533 ?x533) true)))))))
(check-sat)
