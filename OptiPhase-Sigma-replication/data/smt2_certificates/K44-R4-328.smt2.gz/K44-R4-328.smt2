; OptiPhase-Sigma refinement certificate for sweep K44-R4-328
; query 0: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x562 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x30 (or false false false)))
(let (($x44 (not $x30)))
(and $x44 (or $x30 (and (distinct ?x562 ?x562) true)))))))
(check-sat)
; query 1: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x308 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x30 (or false false false)))
(let (($x44 (not $x30)))
(and $x44 (or $x30 (and (distinct ?x308 ?x308) true)))))))
(check-sat)
