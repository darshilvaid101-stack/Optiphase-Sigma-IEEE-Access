; OptiPhase-Sigma refinement certificate for sweep K57-R2-082
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x1128 (or false false)))
(let (($x83 (not $x1128)))
(and $x83 (or $x1128 (and (distinct ((_ sign_extend 16) in25_16) ((_ sign_extend 16) in25_16)) true))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let ((?x151 (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1128 (or false false)))
(let (($x279 (or $x1128 false false)))
(let (($x418 (not $x279)))
(and $x418 (or $x279 (and (distinct ?x151 ?x151) true))))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x1128 (or false false)))
(let (($x83 (not $x1128)))
(and $x83 (or $x1128 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x725 ((_ sign_extend 16) in3_16)))
(let ((?x24 (bvand ?x725 (_ bv127 32))))
(let (($x1128 (or false false)))
(let (($x279 (or $x1128 false false)))
(let (($x418 (not $x279)))
(and $x418 (or $x279 (and (distinct ?x24 ?x24) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x725 ((_ sign_extend 16) in3_16)))
(let ((?x24 (bvand ?x725 (_ bv127 32))))
(let ((?x342 ((_ extract 15 0) ?x24)))
(let (($x1128 (or false false)))
(let (($x279 (or $x1128 false false)))
(let (($x114 (or $x279 false)))
(let (($x129 (not $x114)))
(and $x129 (or $x114 (and (distinct ?x342 ?x342) true)))))))))))
(check-sat)
; query 5: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x1128 (or false false)))
(let (($x83 (not $x1128)))
(and $x83 (or $x1128 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 6: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x64 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x1128 (or false false)))
(let (($x279 (or $x1128 false false)))
(let (($x418 (not $x279)))
(and $x418 (or $x279 (and (distinct ?x64 ?x64) true))))))))
(check-sat)
; query 7: function core_bench_list, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x592 (or false false false)))
(let (($x28 (not $x592)))
(and $x28 (or $x592 (and (distinct (bvadd in.0_16 (_ bv1 16)) (bvadd in.0_16 (_ bv1 16))) true))))))
(check-sat)
; query 8: function core_bench_list, block 82, name %83
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let (($x1128 (or false false)))
(let (($x83 (not $x1128)))
(and $x83 (or $x1128 (and (distinct ((_ zero_extend 16) in.02_16) ((_ zero_extend 16) in.02_16)) true))))))
(check-sat)
; query 9: function core_bench_list, block 82, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x392 ((_ zero_extend 16) in.02_16)))
(let ((?x426 (bvmul ?x392 (_ bv4 32))))
(let (($x681 (and (distinct (bvmul ((_ sign_extend 32) ?x392) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x426)) true)))
(let (($x1128 (or false false)))
(let (($x337 (or $x1128 false (or $x681))))
(and (not $x337) (or $x337 (and (distinct ?x426 ?x426) true)))))))))
(check-sat)
; query 10: function core_bench_list, block 82, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let (($x1128 (or false false)))
(let (($x83 (not $x1128)))
(and $x83 (or $x1128 (and (distinct ((_ zero_extend 16) in.04_16) ((_ zero_extend 16) in.04_16)) true))))))
(check-sat)
; query 11: function core_bench_list, block 82, name %86
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x1669 ((_ zero_extend 16) in.04_16)))
(let ((?x392 ((_ zero_extend 16) in.02_16)))
(let ((?x426 (bvmul ?x392 (_ bv4 32))))
(let ((?x488 (bvsub ?x426 ?x1669)))
(let ((?x77 ((_ sign_extend 1) ?x488)))
(let (($x1128 (or false false)))
(let (($x681 (and (distinct (bvmul ((_ sign_extend 32) ?x392) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x426)) true)))
(let (($x337 (or $x1128 false (or $x681))))
(let (($x309 (or $x337 $x1128 (or (and (distinct (bvsub ((_ sign_extend 1) ?x426) ((_ sign_extend 1) ?x1669)) ?x77) true)))))
(and (not $x309) (or $x309 (and (distinct ?x488 ?x488) true)))))))))))))
(check-sat)
; query 12: function core_bench_list, block 82, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x1128 (or false false)))
(let (($x83 (not $x1128)))
(and $x83 (or $x1128 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 13: function core_bench_list, block 82, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x1669 ((_ zero_extend 16) in.04_16)))
(let ((?x392 ((_ zero_extend 16) in.02_16)))
(let ((?x426 (bvmul ?x392 (_ bv4 32))))
(let ((?x488 (bvsub ?x426 ?x1669)))
(let ((?x320 ((_ zero_extend 16) in.01_16)))
(let ((?x1070 (bvadd ?x320 ?x488)))
(let (($x144 (and (distinct (bvadd ((_ sign_extend 1) ?x320) ((_ sign_extend 1) ?x488)) ((_ sign_extend 1) ?x1070)) true)))
(let ((?x77 ((_ sign_extend 1) ?x488)))
(let (($x1128 (or false false)))
(let (($x681 (and (distinct (bvmul ((_ sign_extend 32) ?x392) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x426)) true)))
(let (($x337 (or $x1128 false (or $x681))))
(let (($x309 (or $x337 $x1128 (or (and (distinct (bvsub ((_ sign_extend 1) ?x426) ((_ sign_extend 1) ?x1669)) ?x77) true)))))
(let (($x9873 (or $x1128 $x309 (or $x144))))
(and (not $x9873) (or $x9873 (and (distinct ?x1070 ?x1070) true)))))))))))))))))
(check-sat)
; query 14: function core_bench_list, block 82, name %89
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x1669 ((_ zero_extend 16) in.04_16)))
(let ((?x392 ((_ zero_extend 16) in.02_16)))
(let ((?x426 (bvmul ?x392 (_ bv4 32))))
(let ((?x488 (bvsub ?x426 ?x1669)))
(let ((?x320 ((_ zero_extend 16) in.01_16)))
(let ((?x1070 (bvadd ?x320 ?x488)))
(let ((?x614 ((_ extract 15 0) ?x1070)))
(let (($x144 (and (distinct (bvadd ((_ sign_extend 1) ?x320) ((_ sign_extend 1) ?x488)) ((_ sign_extend 1) ?x1070)) true)))
(let ((?x77 ((_ sign_extend 1) ?x488)))
(let (($x1128 (or false false)))
(let (($x681 (and (distinct (bvmul ((_ sign_extend 32) ?x392) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x426)) true)))
(let (($x337 (or $x1128 false (or $x681))))
(let (($x309 (or $x337 $x1128 (or (and (distinct (bvsub ((_ sign_extend 1) ?x426) ((_ sign_extend 1) ?x1669)) ?x77) true)))))
(let (($x9873 (or $x1128 $x309 (or $x144))))
(let (($x68 (or $x9873 false)))
(and (not $x68) (or $x68 (and (distinct ?x614 ?x614) true)))))))))))))))))))
(check-sat)
; query 15: function core_bench_list, block 82, name %90
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x1128 (or false false)))
(let (($x83 (not $x1128)))
(and $x83 (or $x1128 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 16: function core_bench_list, block 82, name %91
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x492 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1128 (or false false)))
(let (($x279 (or $x1128 false false)))
(let (($x418 (not $x279)))
(and $x418 (or $x279 (and (distinct ?x492 ?x492) true))))))))
(check-sat)
; query 17: function core_bench_state, block 105, name %106
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x592 (or false false false)))
(let (($x28 (not $x592)))
(and $x28 (or $x592 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 18: function core_bench_state, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x592 (or false false false)))
(let (($x28 (not $x592)))
(and $x28 (or $x592 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 19: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x343 (bvadd in.01_32 (_ bv1 32))))
(let (($x187 (and (distinct ?x343 ?x343) true)))
(let (($x592 (or false false false)))
(let (($x28 (not $x592)))
(and $x28 (or $x592 $x187)))))))
(check-sat)
; query 20: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x343 (bvadd in.01_32 (_ bv1 32))))
(let ((?x8722 (bvmul ?x343 ?x343)))
(let (($x592 (or false false false)))
(let (($x175 (or $x592 $x592 false)))
(and (not $x175) (or $x175 (and (distinct ?x8722 ?x8722) true))))))))
(check-sat)
; query 21: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x343 (bvadd in.01_32 (_ bv1 32))))
(let ((?x8722 (bvmul ?x343 ?x343)))
(let ((?x1952 (bvmul ?x8722 (_ bv2 32))))
(let (($x592 (or false false false)))
(let (($x175 (or $x592 $x592 false)))
(let (($x50 (or $x175 false false)))
(and (not $x50) (or $x50 (and (distinct ?x1952 ?x1952) true))))))))))
(check-sat)
; query 22: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x343 (bvadd in.01_32 (_ bv1 32))))
(let ((?x8722 (bvmul ?x343 ?x343)))
(let ((?x1952 (bvmul ?x8722 (_ bv2 32))))
(let ((?x245 (bvmul ?x1952 (_ bv4 32))))
(let (($x592 (or false false false)))
(let (($x175 (or $x592 $x592 false)))
(let (($x50 (or $x175 false false)))
(let (($x15625 (or $x50 false false)))
(and (not $x15625) (or $x15625 (and (distinct ?x245 ?x245) true))))))))))))
(check-sat)
; query 23: function core_init_matrix, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x592 (or false false false)))
(let (($x28 (not $x592)))
(and $x28 (or $x592 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 24: function core_init_matrix, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x592 (or false false false)))
(let (($x28 (not $x592)))
(and $x28 (or $x592 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 25: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x411 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x592 (or false false false)))
(let (($x28 (not $x592)))
(and $x28 (or $x592 (and (distinct ?x411 ?x411) true)))))))
(check-sat)
; query 26: function core_init_state, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_32 () (_ BitVec 32))
(assert
 (let (($x592 (or false false false)))
(let (($x28 (not $x592)))
(and $x28 (or $x592 (and (distinct (bvadd in.06_32 (_ bv1 32)) (bvadd in.06_32 (_ bv1 32))) true))))))
(check-sat)
; query 27: function core_init_state, block 65, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let (($x592 (or false false false)))
(let (($x28 (not $x592)))
(and $x28 (or $x592 (and (distinct (bvadd in4_32 (_ bv1 32)) (bvadd in4_32 (_ bv1 32))) true))))))
(check-sat)
; query 28: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x406 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x592 (or false false false)))
(let (($x28 (not $x592)))
(and $x28 (or $x592 (and (distinct ?x406 ?x406) true)))))))
(check-sat)
; query 29: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x592 (or false false false)))
(let (($x28 (not $x592)))
(and $x28 (or $x592 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 30: function core_list_init, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x343 (bvadd in.01_32 (_ bv1 32))))
(let (($x187 (and (distinct ?x343 ?x343) true)))
(let (($x592 (or false false false)))
(let (($x28 (not $x592)))
(and $x28 (or $x592 $x187)))))))
(check-sat)
; query 31: function core_list_mergesort, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x343 (bvadd in.01_32 (_ bv1 32))))
(let (($x187 (and (distinct ?x343 ?x343) true)))
(let (($x19953 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x343)) true)))
(let (($x39321 (or false false (or $x19953))))
(and (not $x39321) (or $x39321 $x187)))))))
(check-sat)
; query 32: function core_list_mergesort, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x40161 (ite (bvslt (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x592 (or false false false)))
(let (($x28 (not $x592)))
(and $x28 (or $x592 (and (distinct ?x40161 ?x40161) true)))))))
(check-sat)
; query 33: function core_list_mergesort, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.224_32 () (_ BitVec 32))
(assert
 (let ((?x44699 (ite (= (_ bv0 32) in.224_32) (_ bv1 1) (_ bv0 1))))
(let (($x592 (or false false false)))
(let (($x28 (not $x592)))
(and $x28 (or $x592 (and (distinct ?x44699 ?x44699) true)))))))
(check-sat)
; query 34: function core_list_mergesort, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x12613 (ite (= (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x592 (or false false false)))
(let (($x28 (not $x592)))
(and $x28 (or $x592 (and (distinct ?x12613 ?x12613) true)))))))
(check-sat)
; query 35: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x9305 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x2179 (or false false (or $x9305))))
(and (not $x2179) (or $x2179 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 36: function core_list_mergesort, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x132 (and (distinct (bvmul ((_ sign_extend 32) in.020_32) ((_ sign_extend 32) (_ bv2 32))) ((_ sign_extend 32) (bvmul in.020_32 (_ bv2 32)))) true)))
(let (($x344 (or false false (or $x132))))
(and (not $x344) (or $x344 (and (distinct (bvmul in.020_32 (_ bv2 32)) (bvmul in.020_32 (_ bv2 32))) true))))))
(check-sat)
; query 37: function core_state_transition, block 102, name %103
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1128 (or false false)))
(let (($x83 (not $x1128)))
(and $x83 (or $x1128 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 38: function core_state_transition, block 102, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1532 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1128 (or false false)))
(let (($x279 (or $x1128 false false)))
(let (($x418 (not $x279)))
(and $x418 (or $x279 (and (distinct ?x1532 ?x1532) true))))))))
(check-sat)
; query 39: function core_state_transition, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1128 (or false false)))
(let (($x83 (not $x1128)))
(and $x83 (or $x1128 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 40: function core_state_transition, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1207 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1128 (or false false)))
(let (($x279 (or $x1128 false false)))
(let (($x418 (not $x279)))
(and $x418 (or $x279 (and (distinct ?x1207 ?x1207) true))))))))
(check-sat)
; query 41: function core_state_transition, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1128 (or false false)))
(let (($x83 (not $x1128)))
(and $x83 (or $x1128 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 42: function core_state_transition, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1532 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1128 (or false false)))
(let (($x279 (or $x1128 false false)))
(let (($x418 (not $x279)))
(and $x418 (or $x279 (and (distinct ?x1532 ?x1532) true))))))))
(check-sat)
; query 43: function core_state_transition, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1128 (or false false)))
(let (($x83 (not $x1128)))
(and $x83 (or $x1128 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 44: function core_state_transition, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x19583 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1128 (or false false)))
(let (($x279 (or $x1128 false false)))
(let (($x418 (not $x279)))
(and $x418 (or $x279 (and (distinct ?x19583 ?x19583) true))))))))
(check-sat)
; query 45: function core_state_transition, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1128 (or false false)))
(let (($x83 (not $x1128)))
(and $x83 (or $x1128 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 46: function core_state_transition, block 51, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x19583 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1128 (or false false)))
(let (($x279 (or $x1128 false false)))
(let (($x418 (not $x279)))
(and $x418 (or $x279 (and (distinct ?x19583 ?x19583) true))))))))
(check-sat)
; query 47: function core_state_transition, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1128 (or false false)))
(let (($x83 (not $x1128)))
(and $x83 (or $x1128 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 48: function core_state_transition, block 64, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x19583 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1128 (or false false)))
(let (($x279 (or $x1128 false false)))
(let (($x418 (not $x279)))
(and $x418 (or $x279 (and (distinct ?x19583 ?x19583) true))))))))
(check-sat)
; query 49: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x9933 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x592 (or false false false)))
(let (($x28 (not $x592)))
(and $x28 (or $x592 (and (distinct ?x9933 ?x9933) true)))))))
(check-sat)
; query 50: function core_state_transition, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1128 (or false false)))
(let (($x83 (not $x1128)))
(and $x83 (or $x1128 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 51: function core_state_transition, block 80, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x2368 (ite (= (_ bv69 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1128 (or false false)))
(let (($x279 (or $x1128 false false)))
(let (($x418 (not $x279)))
(and $x418 (or $x279 (and (distinct ?x2368 ?x2368) true))))))))
(check-sat)
; query 52: function core_state_transition, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1128 (or false false)))
(let (($x83 (not $x1128)))
(and $x83 (or $x1128 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 53: function core_state_transition, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x3274 (ite (= (_ bv101 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1128 (or false false)))
(let (($x279 (or $x1128 false false)))
(let (($x418 (not $x279)))
(and $x418 (or $x279 (and (distinct ?x3274 ?x3274) true))))))))
(check-sat)
; query 54: function core_state_transition, block 99, name %100
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1128 (or false false)))
(let (($x83 (not $x1128)))
(and $x83 (or $x1128 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 55: function core_state_transition, block 99, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1207 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1128 (or false false)))
(let (($x279 (or $x1128 false false)))
(let (($x418 (not $x279)))
(and $x418 (or $x279 (and (distinct ?x1207 ?x1207) true))))))))
(check-sat)
; query 56: function crcu8, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x1128 (or false false)))
(let (($x83 (not $x1128)))
(and $x83 (or $x1128 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 57: function crcu8, block 19, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x320 ((_ zero_extend 16) in.01_16)))
(let ((?x1516 (bvxor ?x320 (_ bv16386 32))))
(let (($x1128 (or false false)))
(let (($x279 (or $x1128 false false)))
(let (($x418 (not $x279)))
(and $x418 (or $x279 (and (distinct ?x1516 ?x1516) true)))))))))
(check-sat)
; query 58: function crcu8, block 19, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x320 ((_ zero_extend 16) in.01_16)))
(let ((?x1516 (bvxor ?x320 (_ bv16386 32))))
(let ((?x7001 ((_ extract 15 0) ?x1516)))
(let (($x1128 (or false false)))
(let (($x279 (or $x1128 false false)))
(let (($x114 (or $x279 false)))
(let (($x129 (not $x114)))
(and $x129 (or $x114 (and (distinct ?x7001 ?x7001) true)))))))))))
(check-sat)
; query 59: function crcu8, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x1128 (or false false)))
(let (($x83 (not $x1128)))
(and $x83 (or $x1128 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 60: function crcu8, block 29, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x11918 ((_ zero_extend 16) in27_16)))
(let ((?x394 (bvor ?x11918 (_ bv32768 32))))
(let (($x1128 (or false false)))
(let (($x279 (or $x1128 false false)))
(let (($x418 (not $x279)))
(and $x418 (or $x279 (and (distinct ?x394 ?x394) true)))))))))
(check-sat)
; query 61: function crcu8, block 29, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x11918 ((_ zero_extend 16) in27_16)))
(let ((?x394 (bvor ?x11918 (_ bv32768 32))))
(let ((?x18985 ((_ extract 15 0) ?x394)))
(let (($x1128 (or false false)))
(let (($x279 (or $x1128 false false)))
(let (($x114 (or $x279 false)))
(let (($x129 (not $x114)))
(and $x129 (or $x114 (and (distinct ?x18985 ?x18985) true)))))))))))
(check-sat)
; query 62: function crcu8, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x1128 (or false false)))
(let (($x83 (not $x1128)))
(and $x83 (or $x1128 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 63: function crcu8, block 33, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x11918 ((_ zero_extend 16) in27_16)))
(let ((?x43087 (bvand ?x11918 (_ bv32767 32))))
(let (($x1128 (or false false)))
(let (($x279 (or $x1128 false false)))
(let (($x418 (not $x279)))
(and $x418 (or $x279 (and (distinct ?x43087 ?x43087) true)))))))))
(check-sat)
; query 64: function crcu8, block 33, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x11918 ((_ zero_extend 16) in27_16)))
(let ((?x43087 (bvand ?x11918 (_ bv32767 32))))
(let ((?x2246 ((_ extract 15 0) ?x43087)))
(let (($x1128 (or false false)))
(let (($x279 (or $x1128 false false)))
(let (($x114 (or $x279 false)))
(let (($x129 (not $x114)))
(and $x129 (or $x114 (and (distinct ?x2246 ?x2246) true)))))))))))
(check-sat)
; query 65: function crcu8, block 38, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_8 () (_ BitVec 8))
(assert
 (let (($x592 (or false false false)))
(let (($x28 (not $x592)))
(and $x28 (or $x592 (and (distinct (bvadd in.02_8 (_ bv1 8)) (bvadd in.02_8 (_ bv1 8))) true))))))
(check-sat)
; query 66: function crcu8, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x40062 ((_ extract 7 0) in.01_16)))
(let ((?x980 ((_ zero_extend 24) ?x40062)))
(let (($x1128 (or false false)))
(let (($x9335 (or $x1128 false)))
(and (not $x9335) (or $x9335 (and (distinct ?x980 ?x980) true))))))))
(check-sat)
; query 67: function crcu8, block 6, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x40062 ((_ extract 7 0) in.01_16)))
(let ((?x980 ((_ zero_extend 24) ?x40062)))
(let ((?x42401 (bvand ?x980 (_ bv1 32))))
(let (($x1128 (or false false)))
(let (($x9335 (or $x1128 false)))
(let (($x1019 (or $x9335 false false)))
(and (not $x1019) (or $x1019 (and (distinct ?x42401 ?x42401) true))))))))))
(check-sat)
; query 68: function crcu8, block 6, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x40062 ((_ extract 7 0) in.01_16)))
(let ((?x980 ((_ zero_extend 24) ?x40062)))
(let ((?x42401 (bvand ?x980 (_ bv1 32))))
(let ((?x724 ((_ zero_extend 24) in.0_8)))
(let ((?x41816 (bvand ?x724 (_ bv1 32))))
(let ((?x40750 (bvxor ?x41816 ?x42401)))
(let (($x1128 (or false false)))
(let (($x9335 (or $x1128 false)))
(let (($x1019 (or $x9335 false false)))
(let (($x279 (or $x1128 false false)))
(let (($x21728 (or $x279 $x1019 false)))
(and (not $x21728) (or $x21728 (and (distinct ?x40750 ?x40750) true)))))))))))))))
(check-sat)
; query 69: function crcu8, block 6, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x40062 ((_ extract 7 0) in.01_16)))
(let ((?x980 ((_ zero_extend 24) ?x40062)))
(let ((?x42401 (bvand ?x980 (_ bv1 32))))
(let ((?x724 ((_ zero_extend 24) in.0_8)))
(let ((?x41816 (bvand ?x724 (_ bv1 32))))
(let ((?x40750 (bvxor ?x41816 ?x42401)))
(let ((?x2134 ((_ extract 7 0) ?x40750)))
(let (($x1128 (or false false)))
(let (($x9335 (or $x1128 false)))
(let (($x1019 (or $x9335 false false)))
(let (($x279 (or $x1128 false false)))
(let (($x21728 (or $x279 $x1019 false)))
(let (($x17928 (or $x21728 false)))
(and (not $x17928) (or $x17928 (and (distinct ?x2134 ?x2134) true)))))))))))))))))
(check-sat)
; query 70: function crcu8, block 6, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x1128 (or false false)))
(let (($x83 (not $x1128)))
(and $x83 (or $x1128 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 71: function crcu8, block 6, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x724 ((_ zero_extend 24) in.0_8)))
(let ((?x8 (bvashr ?x724 (_ bv1 32))))
(let (($x1128 (or false false)))
(let (($x279 (or $x1128 false false)))
(let (($x43729 (or $x279 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not $x43729) (or $x43729 (and (distinct ?x8 ?x8) true)))))))))
(check-sat)
; query 72: function crcu8, block 6, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x724 ((_ zero_extend 24) in.0_8)))
(let ((?x8 (bvashr ?x724 (_ bv1 32))))
(let ((?x39322 ((_ extract 7 0) ?x8)))
(let (($x1128 (or false false)))
(let (($x279 (or $x1128 false false)))
(let (($x43729 (or $x279 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x17192 (or $x43729 false)))
(and (not $x17192) (or $x17192 (and (distinct ?x39322 ?x39322) true)))))))))))
(check-sat)
; query 73: function crcu8, block 6, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x40062 ((_ extract 7 0) in.01_16)))
(let ((?x980 ((_ zero_extend 24) ?x40062)))
(let ((?x42401 (bvand ?x980 (_ bv1 32))))
(let ((?x724 ((_ zero_extend 24) in.0_8)))
(let ((?x41816 (bvand ?x724 (_ bv1 32))))
(let ((?x40750 (bvxor ?x41816 ?x42401)))
(let ((?x2134 ((_ extract 7 0) ?x40750)))
(let ((?x798 ((_ zero_extend 24) ?x2134)))
(let (($x1128 (or false false)))
(let (($x9335 (or $x1128 false)))
(let (($x1019 (or $x9335 false false)))
(let (($x279 (or $x1128 false false)))
(let (($x21728 (or $x279 $x1019 false)))
(let (($x17928 (or $x21728 false)))
(let (($x22223 (or $x17928 false)))
(and (not $x22223) (or $x22223 (and (distinct ?x798 ?x798) true)))))))))))))))))))
(check-sat)
; query 74: function crcu8, block 6, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x40062 ((_ extract 7 0) in.01_16)))
(let ((?x980 ((_ zero_extend 24) ?x40062)))
(let ((?x42401 (bvand ?x980 (_ bv1 32))))
(let ((?x724 ((_ zero_extend 24) in.0_8)))
(let ((?x41816 (bvand ?x724 (_ bv1 32))))
(let ((?x40750 (bvxor ?x41816 ?x42401)))
(let ((?x2134 ((_ extract 7 0) ?x40750)))
(let ((?x798 ((_ zero_extend 24) ?x2134)))
(let ((?x1195 (ite (= (_ bv1 32) ?x798) (_ bv1 1) (_ bv0 1))))
(let (($x1128 (or false false)))
(let (($x9335 (or $x1128 false)))
(let (($x1019 (or $x9335 false false)))
(let (($x279 (or $x1128 false false)))
(let (($x21728 (or $x279 $x1019 false)))
(let (($x17928 (or $x21728 false)))
(let (($x22223 (or $x17928 false)))
(let (($x767 (or $x22223 false false)))
(and (not $x767) (or $x767 (and (distinct ?x1195 ?x1195) true)))))))))))))))))))))
(check-sat)
; query 75: function crcu8, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x1128 (or false false)))
(let (($x83 (not $x1128)))
(and $x83 (or $x1128 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 76: function crcu8, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x724 ((_ zero_extend 24) in.0_8)))
(let ((?x41816 (bvand ?x724 (_ bv1 32))))
(let (($x1128 (or false false)))
(let (($x279 (or $x1128 false false)))
(let (($x418 (not $x279)))
(and $x418 (or $x279 (and (distinct ?x41816 ?x41816) true)))))))))
(check-sat)
; query 77: function crcu8, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x1128 (or false false)))
(let (($x83 (not $x1128)))
(and $x83 (or $x1128 (and (distinct ((_ extract 7 0) in.01_16) ((_ extract 7 0) in.01_16)) true))))))
(check-sat)
; query 78: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x16145 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x20437 ((_ zero_extend 31) ?x16145)))
(let ((?x16247 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x16250 ((_ zero_extend 31) ?x16247)))
(let ((?x650 (bvand ?x16250 ?x20437)))
(let ((?x41896 (ite (and (distinct (_ bv0 32) ?x650) true) (_ bv1 1) (_ bv0 1))))
(let ((?x41101 ((_ zero_extend 63) ?x41896)))
(let (($x1128 (or false false)))
(let (($x279 (or $x1128 false false)))
(let (($x114 (or $x279 false)))
(let (($x40247 (or $x114 $x114 false)))
(let (($x41890 (or $x40247 false false)))
(let (($x1924 (or $x41890 false)))
(and (not $x1924) (or $x1924 (and (distinct ?x41101 ?x41101) true)))))))))))))))))
(check-sat)
; query 79: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x16145 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x20437 ((_ zero_extend 31) ?x16145)))
(let ((?x16247 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x16250 ((_ zero_extend 31) ?x16247)))
(let ((?x650 (bvand ?x16250 ?x20437)))
(let ((?x41896 (ite (and (distinct (_ bv0 32) ?x650) true) (_ bv1 1) (_ bv0 1))))
(let (($x16555 (= (_ bv1 1) ?x41896)))
(let ((?x944 (ite $x16555 (_ bv1 32) (_ bv0 32))))
(let (($x1128 (or false false)))
(let (($x279 (or $x1128 false false)))
(let (($x114 (or $x279 false)))
(let (($x40247 (or $x114 $x114 false)))
(let (($x41890 (or $x40247 false false)))
(let (($x1487 (or $x41890 (ite $x16555 false false))))
(and (not $x1487) (or $x1487 (and (distinct ?x944 ?x944) true))))))))))))))))))
(check-sat)
; query 80: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x16145 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x20437 ((_ zero_extend 31) ?x16145)))
(let ((?x16247 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x16250 ((_ zero_extend 31) ?x16247)))
(let ((?x650 (bvand ?x16250 ?x20437)))
(let ((?x41896 (ite (and (distinct (_ bv0 32) ?x650) true) (_ bv1 1) (_ bv0 1))))
(let (($x16555 (= (_ bv1 1) ?x41896)))
(let ((?x944 (ite $x16555 (_ bv1 32) (_ bv0 32))))
(let ((?x21085 ((_ extract 7 0) ?x944)))
(let (($x1128 (or false false)))
(let (($x279 (or $x1128 false false)))
(let (($x114 (or $x279 false)))
(let (($x40247 (or $x114 $x114 false)))
(let (($x41890 (or $x40247 false false)))
(let (($x1487 (or $x41890 (ite $x16555 false false))))
(let (($x14894 (or $x1487 false)))
(and (not $x14894) (or $x14894 (and (distinct ?x21085 ?x21085) true))))))))))))))))))))
(check-sat)
; query 81: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x1128 (or false false)))
(let (($x83 (not $x1128)))
(and $x83 (or $x1128 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 82: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x16247 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1128 (or false false)))
(let (($x279 (or $x1128 false false)))
(let (($x418 (not $x279)))
(and $x418 (or $x279 (and (distinct ?x16247 ?x16247) true))))))))
(check-sat)
; query 83: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x16247 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x16250 ((_ zero_extend 31) ?x16247)))
(let (($x1128 (or false false)))
(let (($x279 (or $x1128 false false)))
(let (($x114 (or $x279 false)))
(let (($x129 (not $x114)))
(and $x129 (or $x114 (and (distinct ?x16250 ?x16250) true))))))))))
(check-sat)
; query 84: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x1128 (or false false)))
(let (($x83 (not $x1128)))
(and $x83 (or $x1128 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 85: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x16145 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1128 (or false false)))
(let (($x279 (or $x1128 false false)))
(let (($x418 (not $x279)))
(and $x418 (or $x279 (and (distinct ?x16145 ?x16145) true))))))))
(check-sat)
; query 86: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x16145 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x20437 ((_ zero_extend 31) ?x16145)))
(let (($x1128 (or false false)))
(let (($x279 (or $x1128 false false)))
(let (($x114 (or $x279 false)))
(let (($x129 (not $x114)))
(and $x129 (or $x114 (and (distinct ?x20437 ?x20437) true))))))))))
(check-sat)
; query 87: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x16145 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x20437 ((_ zero_extend 31) ?x16145)))
(let ((?x16247 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x16250 ((_ zero_extend 31) ?x16247)))
(let ((?x650 (bvand ?x16250 ?x20437)))
(let (($x1128 (or false false)))
(let (($x279 (or $x1128 false false)))
(let (($x114 (or $x279 false)))
(let (($x40247 (or $x114 $x114 false)))
(and (not $x40247) (or $x40247 (and (distinct ?x650 ?x650) true)))))))))))))
(check-sat)
; query 88: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x16145 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x20437 ((_ zero_extend 31) ?x16145)))
(let ((?x16247 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x16250 ((_ zero_extend 31) ?x16247)))
(let ((?x650 (bvand ?x16250 ?x20437)))
(let ((?x41896 (ite (and (distinct (_ bv0 32) ?x650) true) (_ bv1 1) (_ bv0 1))))
(let (($x1128 (or false false)))
(let (($x279 (or $x1128 false false)))
(let (($x114 (or $x279 false)))
(let (($x40247 (or $x114 $x114 false)))
(let (($x41890 (or $x40247 false false)))
(and (not $x41890) (or $x41890 (and (distinct ?x41896 ?x41896) true)))))))))))))))
(check-sat)
; query 89: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x40732 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x592 (or false false false)))
(let (($x28 (not $x592)))
(and $x28 (or $x592 (and (distinct ?x40732 ?x40732) true)))))))
(check-sat)
; query 90: function matrix_add_const, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x592 (or false false false)))
(let (($x28 (not $x592)))
(and $x28 (or $x592 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 91: function matrix_add_const, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x343 (bvadd in.01_32 (_ bv1 32))))
(let (($x187 (and (distinct ?x343 ?x343) true)))
(let (($x592 (or false false false)))
(let (($x28 (not $x592)))
(and $x28 (or $x592 $x187)))))))
(check-sat)
; query 92: function matrix_mul_const, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x592 (or false false false)))
(let (($x28 (not $x592)))
(and $x28 (or $x592 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 93: function matrix_mul_const, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x343 (bvadd in.01_32 (_ bv1 32))))
(let (($x187 (and (distinct ?x343 ?x343) true)))
(let (($x592 (or false false false)))
(let (($x28 (not $x592)))
(and $x28 (or $x592 $x187)))))))
(check-sat)
; query 94: function matrix_mul_matrix, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x592 (or false false false)))
(let (($x28 (not $x592)))
(and $x28 (or $x592 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 95: function matrix_mul_matrix, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x343 (bvadd in.01_32 (_ bv1 32))))
(let (($x187 (and (distinct ?x343 ?x343) true)))
(let (($x592 (or false false false)))
(let (($x28 (not $x592)))
(and $x28 (or $x592 $x187)))))))
(check-sat)
; query 96: function matrix_mul_matrix, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x592 (or false false false)))
(let (($x28 (not $x592)))
(and $x28 (or $x592 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 97: function matrix_mul_matrix_bitextract, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x592 (or false false false)))
(let (($x28 (not $x592)))
(and $x28 (or $x592 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 98: function matrix_mul_matrix_bitextract, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x343 (bvadd in.01_32 (_ bv1 32))))
(let (($x187 (and (distinct ?x343 ?x343) true)))
(let (($x592 (or false false false)))
(let (($x28 (not $x592)))
(and $x28 (or $x592 $x187)))))))
(check-sat)
; query 99: function matrix_mul_matrix_bitextract, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x592 (or false false false)))
(let (($x28 (not $x592)))
(and $x28 (or $x592 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 100: function matrix_mul_vect, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x592 (or false false false)))
(let (($x28 (not $x592)))
(and $x28 (or $x592 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 101: function matrix_mul_vect, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x343 (bvadd in.01_32 (_ bv1 32))))
(let (($x187 (and (distinct ?x343 ?x343) true)))
(let (($x592 (or false false false)))
(let (($x28 (not $x592)))
(and $x28 (or $x592 $x187)))))))
(check-sat)
; query 102: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x1128 (or false false)))
(let (($x83 (not $x1128)))
(and $x83 (or $x1128 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 103: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x15636 ((_ sign_extend 16) in.1_16)))
(let ((?x8846 (bvadd ?x15636 (_ bv10 32))))
(let (($x656 (and (distinct (bvadd ((_ sign_extend 1) ?x15636) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x8846)) true)))
(let (($x1128 (or false false)))
(let (($x44035 (or $x1128 false (or $x656))))
(and (not $x44035) (or $x44035 (and (distinct ?x8846 ?x8846) true)))))))))
(check-sat)
; query 104: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x15636 ((_ sign_extend 16) in.1_16)))
(let ((?x8846 (bvadd ?x15636 (_ bv10 32))))
(let ((?x44588 ((_ extract 15 0) ?x8846)))
(let (($x656 (and (distinct (bvadd ((_ sign_extend 1) ?x15636) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x8846)) true)))
(let (($x1128 (or false false)))
(let (($x44035 (or $x1128 false (or $x656))))
(let (($x9824 (or $x44035 false)))
(and (not $x9824) (or $x9824 (and (distinct ?x44588 ?x44588) true)))))))))))
(check-sat)
; query 105: function matrix_sum, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x861 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x592 (or false false false)))
(let (($x28 (not $x592)))
(and $x28 (or $x592 (and (distinct ?x861 ?x861) true)))))))
(check-sat)
; query 106: function matrix_sum, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x861 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let ((?x1765 ((_ zero_extend 63) ?x861)))
(let (($x592 (or false false false)))
(let (($x768 (or $x592 false)))
(and (not $x768) (or $x768 (and (distinct ?x1765 ?x1765) true))))))))
(check-sat)
; query 107: function matrix_sum, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x861 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x44702 (= (_ bv1 1) ?x861)))
(let ((?x15903 (ite $x44702 (_ bv1 32) (_ bv0 32))))
(let (($x592 (or false false false)))
(let (($x1237 (or $x592 (ite $x44702 false false))))
(and (not $x1237) (or $x1237 (and (distinct ?x15903 ?x15903) true)))))))))
(check-sat)
; query 108: function matrix_sum, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x1128 (or false false)))
(let (($x83 (not $x1128)))
(and $x83 (or $x1128 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 109: function matrix_sum, block 22, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x861 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x44702 (= (_ bv1 1) ?x861)))
(let ((?x15903 (ite $x44702 (_ bv1 32) (_ bv0 32))))
(let ((?x15636 ((_ sign_extend 16) in.1_16)))
(let ((?x1867 (bvadd ?x15636 ?x15903)))
(let (($x7705 (and (distinct (bvadd ((_ sign_extend 1) ?x15636) ((_ sign_extend 1) ?x15903)) ((_ sign_extend 1) ?x1867)) true)))
(let (($x592 (or false false false)))
(let (($x1237 (or $x592 (ite $x44702 false false))))
(let (($x1128 (or false false)))
(let (($x38954 (or $x1128 $x1237 (or $x7705))))
(and (not $x38954) (or $x38954 (and (distinct ?x1867 ?x1867) true))))))))))))))
(check-sat)
; query 110: function matrix_sum, block 22, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x861 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x44702 (= (_ bv1 1) ?x861)))
(let ((?x15903 (ite $x44702 (_ bv1 32) (_ bv0 32))))
(let ((?x15636 ((_ sign_extend 16) in.1_16)))
(let ((?x1867 (bvadd ?x15636 ?x15903)))
(let ((?x12717 ((_ extract 15 0) ?x1867)))
(let (($x7705 (and (distinct (bvadd ((_ sign_extend 1) ?x15636) ((_ sign_extend 1) ?x15903)) ((_ sign_extend 1) ?x1867)) true)))
(let (($x592 (or false false false)))
(let (($x1237 (or $x592 (ite $x44702 false false))))
(let (($x1128 (or false false)))
(let (($x38954 (or $x1128 $x1237 (or $x7705))))
(let (($x2084 (or $x38954 false)))
(and (not $x2084) (or $x2084 (and (distinct ?x12717 ?x12717) true))))))))))))))))
(check-sat)
; query 111: function matrix_sum, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x592 (or false false false)))
(let (($x28 (not $x592)))
(and $x28 (or $x592 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 112: function matrix_sum, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x343 (bvadd in.01_32 (_ bv1 32))))
(let (($x187 (and (distinct ?x343 ?x343) true)))
(let (($x592 (or false false false)))
(let (($x28 (not $x592)))
(and $x28 (or $x592 $x187)))))))
(check-sat)
; query 113: function parseval, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.23_32 () (_ BitVec 32))
(assert
 (let (($x14376 (and (distinct (bvmul ((_ sign_extend 32) in.23_32) ((_ sign_extend 32) (_ bv1024 32))) ((_ sign_extend 32) (bvmul in.23_32 (_ bv1024 32)))) true)))
(let (($x1129 (or false false (or $x14376))))
(and (not $x1129) (or $x1129 (and (distinct (bvmul in.23_32 (_ bv1024 32)) (bvmul in.23_32 (_ bv1024 32))) true))))))
(check-sat)
; query 114: function parseval, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.34_32 () (_ BitVec 32))
(assert
 (let (($x44386 (and (distinct (bvmul ((_ sign_extend 32) in.34_32) ((_ sign_extend 32) (_ bv1048576 32))) ((_ sign_extend 32) (bvmul in.34_32 (_ bv1048576 32)))) true)))
(let (($x44537 (or false false (or $x44386))))
(and (not $x44537) (or $x44537 (and (distinct (bvmul in.34_32 (_ bv1048576 32)) (bvmul in.34_32 (_ bv1048576 32))) true))))))
(check-sat)
; query 115: function partition_memory, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x592 (or false false false)))
(let (($x28 (not $x592)))
(and $x28 (or $x592 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
