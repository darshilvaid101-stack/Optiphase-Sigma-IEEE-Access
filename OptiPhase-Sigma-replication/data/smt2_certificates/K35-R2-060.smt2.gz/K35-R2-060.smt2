; OptiPhase-Sigma refinement certificate for sweep K35-R2-060
; query 0: function corner_draw, block 11, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x113 (ite (= (_ bv0 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x541 (or false false false)))
(let (($x10 (not $x541)))
(and $x10 (or $x541 (and (distinct ?x113 ?x113) true)))))))
(check-sat)
; query 1: function edge_draw, block 39, name %40
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x296 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x124 (or false false (or $x296))))
(and (not $x124) (or $x124 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function edge_draw, block 57, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x774 (and (distinct (bvadd ((_ sign_extend 1) in.12_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.12_32 (_ bv1 32)))) true)))
(let (($x103 (or false false (or $x774))))
(and (not $x103) (or $x103 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 3: function edge_draw, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let ((?x462 (ite (= (_ bv0 32) in4_32) (_ bv1 1) (_ bv0 1))))
(let (($x541 (or false false false)))
(let (($x10 (not $x541)))
(and $x10 (or $x541 (and (distinct ?x462 ?x462) true)))))))
(check-sat)
; query 4: function enlarge, block 106, name %107
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x121 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x126 (or false false (or $x121))))
(and (not $x126) (or $x126 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 5: function enlarge, block 158, name %159
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x339 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x129 (or false false (or $x339))))
(and (not $x129) (or $x129 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 6: function enlarge, block 161, name %162
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let (($x43 (and (distinct (bvadd ((_ sign_extend 1) in.2_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.2_32 (_ bv1 32)))) true)))
(let (($x44 (or false false (or $x43))))
(and (not $x44) (or $x44 (and (distinct (bvadd in.2_32 (_ bv1 32)) (bvadd in.2_32 (_ bv1 32))) true))))))
(check-sat)
; query 7: function enlarge, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x296 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x124 (or false false (or $x296))))
(and (not $x124) (or $x124 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function getint, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x128 (ite (bvsle (_ bv48 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x541 (or false false false)))
(let (($x10 (not $x541)))
(and $x10 (or $x541 (and (distinct ?x128 ?x128) true)))))))
(check-sat)
; query 9: function getint, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x514 (ite (bvsge (_ bv57 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x541 (or false false false)))
(let (($x10 (not $x541)))
(and $x10 (or $x541 (and (distinct ?x514 ?x514) true)))))))
(check-sat)
; query 10: function getint, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in26_32 () (_ BitVec 32))
(assert
 (let ((?x55 (ite (bvsgt (_ bv48 32) in26_32) (_ bv1 1) (_ bv0 1))))
(let (($x541 (or false false false)))
(let (($x10 (not $x541)))
(and $x10 (or $x541 (and (distinct ?x55 ?x55) true)))))))
(check-sat)
; query 11: function getint, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in26_32 () (_ BitVec 32))
(assert
 (let ((?x8 (ite (bvslt (_ bv57 32) in26_32) (_ bv1 1) (_ bv0 1))))
(let (($x541 (or false false false)))
(let (($x10 (not $x541)))
(and $x10 (or $x541 (and (distinct ?x8 ?x8) true)))))))
(check-sat)
; query 12: function getint, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x107 (ite (= (_ bv4294967295 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x541 (or false false false)))
(let (($x10 (not $x541)))
(and $x10 (or $x541 (and (distinct ?x107 ?x107) true)))))))
(check-sat)
; query 13: function int_to_uchar, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_32 () (_ BitVec 32))
(assert
 (let (($x71 (and (distinct (bvadd ((_ sign_extend 1) in.03_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.03_32 (_ bv1 32)))) true)))
(let (($x408 (or false false (or $x71))))
(and (not $x408) (or $x408 (and (distinct (bvadd in.03_32 (_ bv1 32)) (bvadd in.03_32 (_ bv1 32))) true))))))
(check-sat)
; query 14: function int_to_uchar, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x142 (and (distinct (bvsub ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) in.0_32)) ((_ sign_extend 1) (bvsub in.01_32 in.0_32))) true)))
(let (($x308 (or false false (or $x142))))
(let (($x226 (or $x308 (and (distinct (bvsub in.01_32 in.0_32) (bvsub in.01_32 in.0_32)) true))))
(and (not $x308) $x226)))))
(check-sat)
; query 15: function int_to_uchar, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.14_32 () (_ BitVec 32))
(assert
 (let (($x42 (and (distinct (bvadd ((_ sign_extend 1) in.14_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.14_32 (_ bv1 32)))) true)))
(let (($x382 (or false false (or $x42))))
(and (not $x382) (or $x382 (and (distinct (bvadd in.14_32 (_ bv1 32)) (bvadd in.14_32 (_ bv1 32))) true))))))
(check-sat)
; query 16: function main, block 129, name %130
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.011_32 () (_ BitVec 32))
(assert
 (let ((?x67 (ite (and (distinct (_ bv0 32) in.011_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x541 (or false false false)))
(let (($x10 (not $x541)))
(and $x10 (or $x541 (and (distinct ?x67 ?x67) true)))))))
(check-sat)
; query 17: function main, block 160, name %161
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x131 (ite (and (distinct (_ bv0 32) in.01_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x541 (or false false false)))
(let (($x10 (not $x541)))
(and $x10 (or $x541 (and (distinct ?x131 ?x131) true)))))))
(check-sat)
; query 18: function main, block 35, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x492 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x374 (or false false (or $x492))))
(and (not $x374) (or $x374 (and (distinct (bvadd in.020_32 (_ bv1 32)) (bvadd in.020_32 (_ bv1 32))) true))))))
(check-sat)
; query 19: function main, block 35, name %37
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let ((?x125 (ite (bvsge (bvadd in.020_32 (_ bv1 32)) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x492 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x374 (or false false (or $x492))))
(let (($x282 (or $x374 false false)))
(and (not $x282) (or $x282 (and (distinct ?x125 ?x125) true))))))))
(check-sat)
; query 20: function main, block 49, name %50
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x492 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x374 (or false false (or $x492))))
(and (not $x374) (or $x374 (and (distinct (bvadd in.020_32 (_ bv1 32)) (bvadd in.020_32 (_ bv1 32))) true))))))
(check-sat)
; query 21: function main, block 49, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let ((?x125 (ite (bvsge (bvadd in.020_32 (_ bv1 32)) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x492 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x374 (or false false (or $x492))))
(let (($x282 (or $x374 false false)))
(and (not $x282) (or $x282 (and (distinct ?x125 ?x125) true))))))))
(check-sat)
; query 22: function main, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.014_32 () (_ BitVec 32))
(assert
 (let ((?x28 (ite (= (_ bv1 32) in.014_32) (_ bv1 1) (_ bv0 1))))
(let (($x541 (or false false false)))
(let (($x10 (not $x541)))
(and $x10 (or $x541 (and (distinct ?x28 ?x28) true)))))))
(check-sat)
; query 23: function main, block 66, name %67
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x109 (ite (= (_ bv0 32) in.0_32) (_ bv1 1) (_ bv0 1))))
(let (($x541 (or false false false)))
(let (($x10 (not $x541)))
(and $x10 (or $x541 (and (distinct ?x109 ?x109) true)))))))
(check-sat)
; query 24: function main, block 84, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.07_32 () (_ BitVec 32))
(assert
 (let ((?x416 (ite (and (distinct (_ bv0 32) in.07_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x541 (or false false false)))
(let (($x10 (not $x541)))
(and $x10 (or $x541 (and (distinct ?x416 ?x416) true)))))))
(check-sat)
; query 25: function median, block 103, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x339 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x129 (or false false (or $x339))))
(and (not $x129) (or $x129 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 26: function median, block 106, name %107
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x296 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x124 (or false false (or $x296))))
(and (not $x124) (or $x124 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 27: function setup_brightness_lut, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x296 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x124 (or false false (or $x296))))
(and (not $x124) (or $x124 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 28: function susan_corners, block 1066, name %1067
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x339 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x129 (or false false (or $x339))))
(and (not $x129) (or $x129 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 29: function susan_corners, block 1069, name %1070
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x296 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x124 (or false false (or $x296))))
(and (not $x124) (or $x124 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 30: function susan_corners, block 1549, name %1550
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x121 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x126 (or false false (or $x121))))
(and (not $x126) (or $x126 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 31: function susan_corners, block 1552, name %1553
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x774 (and (distinct (bvadd ((_ sign_extend 1) in.12_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.12_32 (_ bv1 32)))) true)))
(let (($x103 (or false false (or $x774))))
(and (not $x103) (or $x103 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 32: function susan_corners, block 845, name %846
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in839_32 () (_ BitVec 32))
(declare-fun in840_32 () (_ BitVec 32))
(assert
 (let ((?x299 (ite (bvslt in840_32 in839_32) (_ bv1 1) (_ bv0 1))))
(let (($x541 (or false false false)))
(let (($x10 (not $x541)))
(and $x10 (or $x541 (and (distinct ?x299 ?x299) true)))))))
(check-sat)
; query 33: function susan_corners_quick, block 1469, name %1470
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x121 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x126 (or false false (or $x121))))
(and (not $x126) (or $x126 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 34: function susan_corners_quick, block 1472, name %1473
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x774 (and (distinct (bvadd ((_ sign_extend 1) in.12_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.12_32 (_ bv1 32)))) true)))
(let (($x103 (or false false (or $x774))))
(and (not $x103) (or $x103 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 35: function susan_corners_quick, block 433, name %434
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x339 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x129 (or false false (or $x339))))
(and (not $x129) (or $x129 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 36: function susan_corners_quick, block 436, name %437
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x296 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x124 (or false false (or $x296))))
(and (not $x124) (or $x124 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 37: function susan_edges, block 1432, name %1433
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1417_32 () (_ BitVec 32))
(assert
 (let ((?x477 (ite (bvslt (_ bv0 32) in1417_32) (_ bv1 1) (_ bv0 1))))
(let (($x541 (or false false false)))
(let (($x10 (not $x541)))
(and $x10 (or $x541 (and (distinct ?x477 ?x477) true)))))))
(check-sat)
; query 38: function susan_edges, block 1486, name %1487
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.116_32 () (_ BitVec 32))
(assert
 (let (($x645 (and (distinct (bvadd ((_ sign_extend 1) in.116_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.116_32 (_ bv1 32)))) true)))
(let (($x641 (or false false (or $x645))))
(and (not $x641) (or $x641 (and (distinct (bvadd in.116_32 (_ bv1 32)) (bvadd in.116_32 (_ bv1 32))) true))))))
(check-sat)
; query 39: function susan_edges, block 1489, name %1490
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.114_32 () (_ BitVec 32))
(assert
 (let (($x613 (and (distinct (bvadd ((_ sign_extend 1) in.114_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.114_32 (_ bv1 32)))) true)))
(let (($x431 (or false false (or $x613))))
(and (not $x431) (or $x431 (and (distinct (bvadd in.114_32 (_ bv1 32)) (bvadd in.114_32 (_ bv1 32))) true))))))
(check-sat)
; query 40: function susan_edges, block 379, name %380
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.015_32 () (_ BitVec 32))
(assert
 (let (($x221 (and (distinct (bvadd ((_ sign_extend 1) in.015_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.015_32 (_ bv1 32)))) true)))
(let (($x13 (or false false (or $x221))))
(and (not $x13) (or $x13 (and (distinct (bvadd in.015_32 (_ bv1 32)) (bvadd in.015_32 (_ bv1 32))) true))))))
(check-sat)
; query 41: function susan_edges, block 382, name %383
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.013_32 () (_ BitVec 32))
(assert
 (let (($x538 (and (distinct (bvadd ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.013_32 (_ bv1 32)))) true)))
(let (($x452 (or false false (or $x538))))
(and (not $x452) (or $x452 (and (distinct (bvadd in.013_32 (_ bv1 32)) (bvadd in.013_32 (_ bv1 32))) true))))))
(check-sat)
; query 42: function susan_edges, block 850, name %851
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in834_32 () (_ BitVec 32))
(assert
 (let ((?x459 (ite (= (_ bv0 32) in834_32) (_ bv1 1) (_ bv0 1))))
(let (($x541 (or false false false)))
(let (($x10 (not $x541)))
(and $x10 (or $x541 (and (distinct ?x459 ?x459) true)))))))
(check-sat)
; query 43: function susan_edges, block 870, name %871
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x369 (ite (bvslt (_ bv0 32) in.0_32) (_ bv1 1) (_ bv0 1))))
(let (($x541 (or false false false)))
(let (($x10 (not $x541)))
(and $x10 (or $x541 (and (distinct ?x369 ?x369) true)))))))
(check-sat)
; query 44: function susan_edges_small, block 119, name %120
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.09_32 () (_ BitVec 32))
(assert
 (let (($x314 (and (distinct (bvadd ((_ sign_extend 1) in.09_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.09_32 (_ bv1 32)))) true)))
(let (($x441 (or false false (or $x314))))
(and (not $x441) (or $x441 (and (distinct (bvadd in.09_32 (_ bv1 32)) (bvadd in.09_32 (_ bv1 32))) true))))))
(check-sat)
; query 45: function susan_edges_small, block 122, name %123
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.07_32 () (_ BitVec 32))
(assert
 (let (($x632 (and (distinct (bvadd ((_ sign_extend 1) in.07_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.07_32 (_ bv1 32)))) true)))
(let (($x550 (or false false (or $x632))))
(and (not $x550) (or $x550 (and (distinct (bvadd in.07_32 (_ bv1 32)) (bvadd in.07_32 (_ bv1 32))) true))))))
(check-sat)
; query 46: function susan_edges_small, block 258, name %259
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in243_32 () (_ BitVec 32))
(assert
 (let ((?x202 (ite (= (_ bv0 32) in243_32) (_ bv1 1) (_ bv0 1))))
(let (($x541 (or false false false)))
(let (($x10 (not $x541)))
(and $x10 (or $x541 (and (distinct ?x202 ?x202) true)))))))
(check-sat)
; query 47: function susan_edges_small, block 278, name %279
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x369 (ite (bvslt (_ bv0 32) in.0_32) (_ bv1 1) (_ bv0 1))))
(let (($x541 (or false false false)))
(let (($x10 (not $x541)))
(and $x10 (or $x541 (and (distinct ?x369 ?x369) true)))))))
(check-sat)
; query 48: function susan_edges_small, block 426, name %427
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in411_32 () (_ BitVec 32))
(assert
 (let ((?x660 (ite (bvslt (_ bv0 32) in411_32) (_ bv1 1) (_ bv0 1))))
(let (($x541 (or false false false)))
(let (($x10 (not $x541)))
(and $x10 (or $x541 (and (distinct ?x660 ?x660) true)))))))
(check-sat)
; query 49: function susan_edges_small, block 458, name %459
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.110_32 () (_ BitVec 32))
(assert
 (let (($x276 (and (distinct (bvadd ((_ sign_extend 1) in.110_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.110_32 (_ bv1 32)))) true)))
(let (($x674 (or false false (or $x276))))
(and (not $x674) (or $x674 (and (distinct (bvadd in.110_32 (_ bv1 32)) (bvadd in.110_32 (_ bv1 32))) true))))))
(check-sat)
; query 50: function susan_edges_small, block 461, name %462
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.18_32 () (_ BitVec 32))
(assert
 (let (($x179 (and (distinct (bvadd ((_ sign_extend 1) in.18_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.18_32 (_ bv1 32)))) true)))
(let (($x192 (or false false (or $x179))))
(and (not $x192) (or $x192 (and (distinct (bvadd in.18_32 (_ bv1 32)) (bvadd in.18_32 (_ bv1 32))) true))))))
(check-sat)
; query 51: function susan_principle, block 378, name %379
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x339 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x129 (or false false (or $x339))))
(and (not $x129) (or $x129 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 52: function susan_principle, block 381, name %382
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x296 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x124 (or false false (or $x296))))
(and (not $x124) (or $x124 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 53: function susan_principle_small, block 118, name %119
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x339 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x129 (or false false (or $x339))))
(and (not $x129) (or $x129 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 54: function susan_principle_small, block 121, name %122
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x296 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x124 (or false false (or $x296))))
(and (not $x124) (or $x124 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 55: function susan_smoothing, block 123, name %124
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.09_32 () (_ BitVec 32))
(assert
 (let (($x104 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in.09_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in.09_32))) true)))
(let (($x638 (or false false (or $x104))))
(and (not $x638) (or $x638 (and (distinct (bvsub (_ bv0 32) in.09_32) (bvsub (_ bv0 32) in.09_32)) true))))))
(check-sat)
; query 56: function susan_smoothing, block 143, name %144
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.016_32 () (_ BitVec 32))
(assert
 (let (($x247 (and (distinct (bvadd ((_ sign_extend 1) in.016_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.016_32 (_ bv1 32)))) true)))
(let (($x157 (or false false (or $x247))))
(and (not $x157) (or $x157 (and (distinct (bvadd in.016_32 (_ bv1 32)) (bvadd in.016_32 (_ bv1 32))) true))))))
(check-sat)
; query 57: function susan_smoothing, block 148, name %149
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.017_32 () (_ BitVec 32))
(assert
 (let (($x893 (and (distinct (bvadd ((_ sign_extend 1) in.017_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.017_32 (_ bv1 32)))) true)))
(let (($x832 (or false false (or $x893))))
(and (not $x832) (or $x832 (and (distinct (bvadd in.017_32 (_ bv1 32)) (bvadd in.017_32 (_ bv1 32))) true))))))
(check-sat)
; query 58: function susan_smoothing, block 150, name %151
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.018_32 () (_ BitVec 32))
(assert
 (let (($x775 (and (distinct (bvsub ((_ sign_extend 1) in.018_32) ((_ sign_extend 1) (_ bv10000 32))) ((_ sign_extend 1) (bvsub in.018_32 (_ bv10000 32)))) true)))
(let (($x169 (or false false (or $x775))))
(and (not $x169) (or $x169 (and (distinct (bvsub in.018_32 (_ bv10000 32)) (bvsub in.018_32 (_ bv10000 32))) true))))))
(check-sat)
; query 59: function susan_smoothing, block 150, name %152
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.018_32 () (_ BitVec 32))
(assert
 (let ((?x884 (ite (= (_ bv0 32) (bvsub in.018_32 (_ bv10000 32))) (_ bv1 1) (_ bv0 1))))
(let (($x775 (and (distinct (bvsub ((_ sign_extend 1) in.018_32) ((_ sign_extend 1) (_ bv10000 32))) ((_ sign_extend 1) (bvsub in.018_32 (_ bv10000 32)))) true)))
(let (($x169 (or false false (or $x775))))
(let (($x371 (or $x169 false false)))
(and (not $x371) (or $x371 (and (distinct ?x884 ?x884) true))))))))
(check-sat)
; query 60: function susan_smoothing, block 165, name %166
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.114_32 () (_ BitVec 32))
(assert
 (let (($x613 (and (distinct (bvadd ((_ sign_extend 1) in.114_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.114_32 (_ bv1 32)))) true)))
(let (($x431 (or false false (or $x613))))
(and (not $x431) (or $x431 (and (distinct (bvadd in.114_32 (_ bv1 32)) (bvadd in.114_32 (_ bv1 32))) true))))))
(check-sat)
; query 61: function susan_smoothing, block 168, name %169
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.111_32 () (_ BitVec 32))
(assert
 (let (($x777 (and (distinct (bvadd ((_ sign_extend 1) in.111_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.111_32 (_ bv1 32)))) true)))
(let (($x141 (or false false (or $x777))))
(and (not $x141) (or $x141 (and (distinct (bvadd in.111_32 (_ bv1 32)) (bvadd in.111_32 (_ bv1 32))) true))))))
(check-sat)
; query 62: function susan_smoothing, block 21, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x947 (ite (= (_ bv0 32) (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x541 (or false false false)))
(let (($x10 (not $x541)))
(and $x10 (or $x541 (and (distinct ?x947 ?x947) true)))))))
(check-sat)
; query 63: function susan_smoothing, block 319, name %320
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.215_32 () (_ BitVec 32))
(assert
 (let (($x227 (and (distinct (bvadd ((_ sign_extend 1) in.215_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.215_32 (_ bv1 32)))) true)))
(let (($x671 (or false false (or $x227))))
(and (not $x671) (or $x671 (and (distinct (bvadd in.215_32 (_ bv1 32)) (bvadd in.215_32 (_ bv1 32))) true))))))
(check-sat)
; query 64: function susan_smoothing, block 322, name %323
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.212_32 () (_ BitVec 32))
(assert
 (let (($x496 (and (distinct (bvadd ((_ sign_extend 1) in.212_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.212_32 (_ bv1 32)))) true)))
(let (($x190 (or false false (or $x496))))
(and (not $x190) (or $x190 (and (distinct (bvadd in.212_32 (_ bv1 32)) (bvadd in.212_32 (_ bv1 32))) true))))))
(check-sat)
; query 65: function susan_smoothing, block 67, name %68
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.09_32 () (_ BitVec 32))
(assert
 (let (($x104 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in.09_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in.09_32))) true)))
(let (($x638 (or false false (or $x104))))
(and (not $x638) (or $x638 (and (distinct (bvsub (_ bv0 32) in.09_32) (bvsub (_ bv0 32) in.09_32)) true))))))
(check-sat)
; query 66: function susan_smoothing, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.013_32 () (_ BitVec 32))
(assert
 (let (($x538 (and (distinct (bvadd ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.013_32 (_ bv1 32)))) true)))
(let (($x452 (or false false (or $x538))))
(and (not $x452) (or $x452 (and (distinct (bvadd in.013_32 (_ bv1 32)) (bvadd in.013_32 (_ bv1 32))) true))))))
(check-sat)
; query 67: function susan_smoothing, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.010_32 () (_ BitVec 32))
(assert
 (let (($x453 (and (distinct (bvadd ((_ sign_extend 1) in.010_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.010_32 (_ bv1 32)))) true)))
(let (($x871 (or false false (or $x453))))
(and (not $x871) (or $x871 (and (distinct (bvadd in.010_32 (_ bv1 32)) (bvadd in.010_32 (_ bv1 32))) true))))))
(check-sat)
; query 68: function susan_thin, block 100, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in93_32 () (_ BitVec 32))
(assert
 (let ((?x586 (ite (= (_ bv1 32) in93_32) (_ bv1 1) (_ bv0 1))))
(let (($x541 (or false false false)))
(let (($x10 (not $x541)))
(and $x10 (or $x541 (and (distinct ?x586 ?x586) true)))))))
(check-sat)
; query 69: function susan_thin, block 428, name %429
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.022_32 () (_ BitVec 32))
(assert
 (let (($x373 (and (distinct (bvadd ((_ sign_extend 1) in.022_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.022_32 (_ bv1 32)))) true)))
(let (($x174 (or false false (or $x373))))
(and (not $x174) (or $x174 (and (distinct (bvadd in.022_32 (_ bv1 32)) (bvadd in.022_32 (_ bv1 32))) true))))))
(check-sat)
; query 70: function susan_thin, block 431, name %432
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.018_32 () (_ BitVec 32))
(assert
 (let (($x574 (and (distinct (bvadd ((_ sign_extend 1) in.018_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.018_32 (_ bv1 32)))) true)))
(let (($x219 (or false false (or $x574))))
(and (not $x219) (or $x219 (and (distinct (bvadd in.018_32 (_ bv1 32)) (bvadd in.018_32 (_ bv1 32))) true))))))
(check-sat)
; query 71: function susan_thin, block 433, name %434
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.040_32 () (_ BitVec 32))
(assert
 (let ((?x394 (ite (bvslt (_ bv0 32) in.040_32) (_ bv1 1) (_ bv0 1))))
(let (($x541 (or false false false)))
(let (($x10 (not $x541)))
(and $x10 (or $x541 (and (distinct ?x394 ?x394) true)))))))
(check-sat)
; query 72: function susan_thin, block 469, name %470
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.235_32 () (_ BitVec 32))
(assert
 (let ((?x622 (bvadd in.235_32 in.235_32)))
(let ((?x266 ((_ sign_extend 1) ?x622)))
(let (($x666 (and (distinct (bvadd ((_ sign_extend 1) in.235_32) ((_ sign_extend 1) in.235_32)) ?x266) true)))
(let (($x438 (or false false (or $x666))))
(and (not $x438) (or $x438 (and (distinct ?x622 ?x622) true))))))))
(check-sat)
; query 73: function susan_thin, block 469, name %471
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.228_32 () (_ BitVec 32))
(declare-fun in.235_32 () (_ BitVec 32))
(assert
 (let ((?x622 (bvadd in.235_32 in.235_32)))
(let ((?x670 (bvadd ?x622 in.228_32)))
(let (($x329 (and (distinct (bvadd ((_ sign_extend 1) ?x622) ((_ sign_extend 1) in.228_32)) ((_ sign_extend 1) ?x670)) true)))
(let ((?x266 ((_ sign_extend 1) ?x622)))
(let (($x666 (and (distinct (bvadd ((_ sign_extend 1) in.235_32) ((_ sign_extend 1) in.235_32)) ?x266) true)))
(let (($x438 (or false false (or $x666))))
(let (($x417 (or $x438 false (or $x329))))
(and (not $x417) (or $x417 (and (distinct ?x670 ?x670) true)))))))))))
(check-sat)
; query 74: function susan_thin, block 469, name %472
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.228_32 () (_ BitVec 32))
(declare-fun in.235_32 () (_ BitVec 32))
(assert
 (let ((?x902 (ite (bvsgt (_ bv3 32) (bvadd (bvadd in.235_32 in.235_32) in.228_32)) (_ bv1 1) (_ bv0 1))))
(let ((?x228 ((_ sign_extend 1) in.228_32)))
(let ((?x622 (bvadd in.235_32 in.235_32)))
(let ((?x266 ((_ sign_extend 1) ?x622)))
(let (($x658 (or (and (distinct (bvadd ?x266 ?x228) ((_ sign_extend 1) (bvadd ?x622 in.228_32))) true))))
(let (($x666 (and (distinct (bvadd ((_ sign_extend 1) in.235_32) ((_ sign_extend 1) in.235_32)) ?x266) true)))
(let (($x438 (or false false (or $x666))))
(let (($x417 (or $x438 false $x658)))
(let (($x634 (or $x417 false false)))
(and (not $x634) (or $x634 (and (distinct ?x902 ?x902) true)))))))))))))
(check-sat)
; query 75: function susan_thin, block 473, name %474
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.235_32 () (_ BitVec 32))
(assert
 (let ((?x215 (bvsub in.235_32 (_ bv1 32))))
(let ((?x892 ((_ sign_extend 1) ?x215)))
(let (($x819 (or (and (distinct (bvsub ((_ sign_extend 1) in.235_32) ((_ sign_extend 1) (_ bv1 32))) ?x892) true))))
(let (($x673 (or false false $x819)))
(and (not $x673) (or $x673 (and (distinct ?x215 ?x215) true))))))))
(check-sat)
; query 76: function susan_thin, block 473, name %475
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.235_32 () (_ BitVec 32))
(declare-fun in.14_32 () (_ BitVec 32))
(assert
 (let ((?x215 (bvsub in.235_32 (_ bv1 32))))
(let ((?x506 (bvadd in.14_32 ?x215)))
(let (($x601 (and (distinct (bvadd ((_ sign_extend 1) in.14_32) ((_ sign_extend 1) ?x215)) ((_ sign_extend 1) ?x506)) true)))
(let ((?x892 ((_ sign_extend 1) ?x215)))
(let (($x819 (or (and (distinct (bvsub ((_ sign_extend 1) in.235_32) ((_ sign_extend 1) (_ bv1 32))) ?x892) true))))
(let (($x673 (or false false $x819)))
(let (($x479 (or false $x673 (or $x601))))
(and (not $x479) (or $x479 (and (distinct ?x506 ?x506) true)))))))))))
(check-sat)
; query 77: function susan_thin, block 473, name %476
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.228_32 () (_ BitVec 32))
(assert
 (let ((?x548 (bvsub in.228_32 (_ bv2 32))))
(let ((?x768 ((_ sign_extend 1) ?x548)))
(let (($x295 (or (and (distinct (bvsub ((_ sign_extend 1) in.228_32) ((_ sign_extend 1) (_ bv2 32))) ?x768) true))))
(let (($x786 (or false false $x295)))
(and (not $x786) (or $x786 (and (distinct ?x548 ?x548) true))))))))
(check-sat)
; query 78: function susan_thin, block 473, name %477
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.228_32 () (_ BitVec 32))
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x548 (bvsub in.228_32 (_ bv2 32))))
(let ((?x220 (bvadd in.0_32 ?x548)))
(let (($x558 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) ?x548)) ((_ sign_extend 1) ?x220)) true)))
(let ((?x768 ((_ sign_extend 1) ?x548)))
(let (($x295 (or (and (distinct (bvsub ((_ sign_extend 1) in.228_32) ((_ sign_extend 1) (_ bv2 32))) ?x768) true))))
(let (($x786 (or false false $x295)))
(let (($x467 (or false $x786 (or $x558))))
(and (not $x467) (or $x467 (and (distinct ?x220 ?x220) true)))))))))))
(check-sat)
; query 79: function susan_thin, block 473, name %478
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.235_32 () (_ BitVec 32))
(declare-fun in.14_32 () (_ BitVec 32))
(assert
 (let ((?x740 (ite (bvsgt (_ bv4 32) (bvadd in.14_32 (bvsub in.235_32 (_ bv1 32)))) (_ bv1 1) (_ bv0 1))))
(let (($x601 (and (distinct (bvadd ((_ sign_extend 1) in.14_32) ((_ sign_extend 1) (bvsub in.235_32 (_ bv1 32)))) ((_ sign_extend 1) (bvadd in.14_32 (bvsub in.235_32 (_ bv1 32))))) true)))
(let ((?x215 (bvsub in.235_32 (_ bv1 32))))
(let ((?x892 ((_ sign_extend 1) ?x215)))
(let (($x819 (or (and (distinct (bvsub ((_ sign_extend 1) in.235_32) ((_ sign_extend 1) (_ bv1 32))) ?x892) true))))
(let (($x673 (or false false $x819)))
(let (($x479 (or false $x673 (or $x601))))
(let (($x589 (or $x479 false false)))
(and (not $x589) (or $x589 (and (distinct ?x740 ?x740) true))))))))))))
(check-sat)
; query 80: function susan_thin, block 533, name %534
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in528_32 () (_ BitVec 32))
(declare-fun in498_32 () (_ BitVec 32))
(assert
 (let (($x541 (or false false false)))
(let (($x995 (or $x541 (and (distinct (bvor in498_32 in528_32) (bvor in498_32 in528_32)) true))))
(let (($x10 (not $x541)))
(and $x10 $x995)))))
(check-sat)
; query 81: function susan_thin, block 533, name %535
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in518_32 () (_ BitVec 32))
(declare-fun in508_32 () (_ BitVec 32))
(assert
 (let (($x541 (or false false false)))
(let (($x756 (or $x541 (and (distinct (bvor in508_32 in518_32) (bvor in508_32 in518_32)) true))))
(let (($x10 (not $x541)))
(and $x10 $x756)))))
(check-sat)
; query 82: function susan_thin, block 533, name %536
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in518_32 () (_ BitVec 32))
(declare-fun in508_32 () (_ BitVec 32))
(declare-fun in528_32 () (_ BitVec 32))
(declare-fun in498_32 () (_ BitVec 32))
(assert
 (let ((?x789 (bvor in508_32 in518_32)))
(let ((?x187 (bvor in498_32 in528_32)))
(let ((?x929 (bvand ?x187 ?x789)))
(let (($x541 (or false false false)))
(let (($x188 (or $x541 $x541 false)))
(let (($x512 (not $x188)))
(and $x512 (or $x188 (and (distinct ?x929 ?x929) true))))))))))
(check-sat)
; query 83: function susan_thin, block 533, name %537
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in518_32 () (_ BitVec 32))
(declare-fun in508_32 () (_ BitVec 32))
(declare-fun in528_32 () (_ BitVec 32))
(declare-fun in498_32 () (_ BitVec 32))
(assert
 (let ((?x789 (bvor in508_32 in518_32)))
(let ((?x187 (bvor in498_32 in528_32)))
(let ((?x929 (bvand ?x187 ?x789)))
(let ((?x862 (ite (and (distinct (_ bv0 32) ?x929) true) (_ bv1 1) (_ bv0 1))))
(let (($x541 (or false false false)))
(let (($x188 (or $x541 $x541 false)))
(let (($x626 (or $x188 false false)))
(let (($x502 (not $x626)))
(and $x502 (or $x626 (and (distinct ?x862 ?x862) true))))))))))))
(check-sat)
; query 84: function susan_thin, block 538, name %539
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in498_32 () (_ BitVec 32))
(assert
 (let ((?x896 (ite (and (distinct (_ bv0 32) in498_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x541 (or false false false)))
(let (($x10 (not $x541)))
(and $x10 (or $x541 (and (distinct ?x896 ?x896) true)))))))
(check-sat)
; query 85: function susan_thin, block 540, name %541
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in508_32 () (_ BitVec 32))
(assert
 (let ((?x204 (ite (and (distinct (_ bv0 32) in508_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x541 (or false false false)))
(let (($x10 (not $x541)))
(and $x10 (or $x541 (and (distinct ?x204 ?x204) true)))))))
(check-sat)
; query 86: function susan_thin, block 545, name %546
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in508_32 () (_ BitVec 32))
(assert
 (let ((?x204 (ite (and (distinct (_ bv0 32) in508_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x541 (or false false false)))
(let (($x10 (not $x541)))
(and $x10 (or $x541 (and (distinct ?x204 ?x204) true)))))))
(check-sat)
; query 87: function susan_thin, block 563, name %564
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.325_32 () (_ BitVec 32))
(assert
 (let ((?x443 (ite (= (_ bv0 32) in.325_32) (_ bv1 1) (_ bv0 1))))
(let (($x541 (or false false false)))
(let (($x10 (not $x541)))
(and $x10 (or $x541 (and (distinct ?x443 ?x443) true)))))))
(check-sat)
; query 88: function susan_thin, block 597, name %598
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.321_32 () (_ BitVec 32))
(assert
 (let ((?x407 (ite (= (_ bv0 32) in.321_32) (_ bv1 1) (_ bv0 1))))
(let (($x541 (or false false false)))
(let (($x10 (not $x541)))
(and $x10 (or $x541 (and (distinct ?x407 ?x407) true)))))))
(check-sat)
; query 89: function susan_thin, block 685, name %686
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in662_32 () (_ BitVec 32))
(declare-fun in680_32 () (_ BitVec 32))
(assert
 (let (($x541 (or false false false)))
(let (($x619 (or $x541 (and (distinct (bvor in680_32 in662_32) (bvor in680_32 in662_32)) true))))
(let (($x10 (not $x541)))
(and $x10 $x619)))))
(check-sat)
; query 90: function susan_thin, block 685, name %687
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in671_32 () (_ BitVec 32))
(declare-fun in653_32 () (_ BitVec 32))
(assert
 (let (($x541 (or false false false)))
(let (($x338 (or $x541 (and (distinct (bvor in653_32 in671_32) (bvor in653_32 in671_32)) true))))
(let (($x10 (not $x541)))
(and $x10 $x338)))))
(check-sat)
; query 91: function susan_thin, block 685, name %688
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in671_32 () (_ BitVec 32))
(declare-fun in653_32 () (_ BitVec 32))
(declare-fun in662_32 () (_ BitVec 32))
(declare-fun in680_32 () (_ BitVec 32))
(assert
 (let ((?x375 (bvor in653_32 in671_32)))
(let ((?x804 (bvor in680_32 in662_32)))
(let ((?x930 (bvand ?x804 ?x375)))
(let (($x541 (or false false false)))
(let (($x188 (or $x541 $x541 false)))
(let (($x512 (not $x188)))
(and $x512 (or $x188 (and (distinct ?x930 ?x930) true))))))))))
(check-sat)
; query 92: function susan_thin, block 685, name %689
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in671_32 () (_ BitVec 32))
(declare-fun in653_32 () (_ BitVec 32))
(declare-fun in662_32 () (_ BitVec 32))
(declare-fun in680_32 () (_ BitVec 32))
(assert
 (let ((?x375 (bvor in653_32 in671_32)))
(let ((?x804 (bvor in680_32 in662_32)))
(let ((?x930 (bvand ?x804 ?x375)))
(let ((?x858 (ite (and (distinct (_ bv0 32) ?x930) true) (_ bv1 1) (_ bv0 1))))
(let (($x541 (or false false false)))
(let (($x188 (or $x541 $x541 false)))
(let (($x626 (or $x188 false false)))
(let (($x502 (not $x626)))
(and $x502 (or $x626 (and (distinct ?x858 ?x858) true))))))))))))
(check-sat)
; query 93: function susan_thin, block 915, name %916
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.13_32 () (_ BitVec 32))
(assert
 (let (($x552 (and (distinct (bvadd ((_ sign_extend 1) in.13_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.13_32 (_ bv1 32)))) true)))
(let (($x257 (or false false (or $x552))))
(and (not $x257) (or $x257 (and (distinct (bvadd in.13_32 (_ bv1 32)) (bvadd in.13_32 (_ bv1 32))) true))))))
(check-sat)
; query 94: function susan_thin, block 918, name %919
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.14_32 () (_ BitVec 32))
(assert
 (let (($x42 (and (distinct (bvadd ((_ sign_extend 1) in.14_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.14_32 (_ bv1 32)))) true)))
(let (($x382 (or false false (or $x42))))
(and (not $x382) (or $x382 (and (distinct (bvadd in.14_32 (_ bv1 32)) (bvadd in.14_32 (_ bv1 32))) true))))))
(check-sat)
