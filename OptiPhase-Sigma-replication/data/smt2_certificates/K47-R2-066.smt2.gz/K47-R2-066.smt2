; OptiPhase-Sigma refinement certificate for sweep K47-R2-066
; query 0: function adpcm_coder, block 25, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in20_32 () (_ BitVec 32))
(assert
 (let (($x5 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in20_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in20_32))) true)))
(let (($x701 (or false false (or $x5))))
(and (not $x701) (or $x701 (and (distinct (bvsub (_ bv0 32) in20_32) (bvsub (_ bv0 32) in20_32)) true))))))
(check-sat)
; query 1: function adpcm_coder, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(declare-fun in.017_32 () (_ BitVec 32))
(assert
 (let ((?x17 (bvsub in.017_32 in.020_32)))
(let (($x71 (and (distinct (bvsub ((_ sign_extend 1) in.017_32) ((_ sign_extend 1) in.020_32)) ((_ sign_extend 1) ?x17)) true)))
(let (($x675 (or false false (or $x71))))
(and (not $x675) (or $x675 (and (distinct ?x17 ?x17) true)))))))
(check-sat)
; query 2: function adpcm_coder, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(declare-fun in28_32 () (_ BitVec 32))
(assert
 (let (($x1590 (and (distinct (bvadd ((_ sign_extend 1) in28_32) ((_ sign_extend 1) in.020_32)) ((_ sign_extend 1) (bvadd in28_32 in.020_32))) true)))
(let (($x713 (or false false (or $x1590))))
(let (($x417 (or $x713 (and (distinct (bvadd in28_32 in.020_32) (bvadd in28_32 in.020_32)) true))))
(and (not $x713) $x417)))))
(check-sat)
; query 3: function adpcm_coder, block 36, name %37
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.014_32 () (_ BitVec 32))
(assert
 (let (($x62 (or false false false)))
(let (($x523 (not $x62)))
(and $x523 (or $x62 (and (distinct (bvor in.014_32 (_ bv2 32)) (bvor in.014_32 (_ bv2 32))) true))))))
(check-sat)
; query 4: function adpcm_coder, block 36, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in34_32 () (_ BitVec 32))
(declare-fun in.118_32 () (_ BitVec 32))
(assert
 (let (($x108 (and (distinct (bvsub ((_ sign_extend 1) in.118_32) ((_ sign_extend 1) in34_32)) ((_ sign_extend 1) (bvsub in.118_32 in34_32))) true)))
(let (($x124 (or false false (or $x108))))
(let (($x317 (or $x124 (and (distinct (bvsub in.118_32 in34_32) (bvsub in.118_32 in34_32)) true))))
(and (not $x124) $x317)))))
(check-sat)
; query 5: function adpcm_coder, block 36, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in34_32 () (_ BitVec 32))
(declare-fun in.08_32 () (_ BitVec 32))
(assert
 (let (($x83 (and (distinct (bvadd ((_ sign_extend 1) in.08_32) ((_ sign_extend 1) in34_32)) ((_ sign_extend 1) (bvadd in.08_32 in34_32))) true)))
(let (($x38 (or false false (or $x83))))
(let (($x43 (or $x38 (and (distinct (bvadd in.08_32 in34_32) (bvadd in.08_32 in34_32)) true))))
(and (not $x38) $x43)))))
(check-sat)
; query 6: function adpcm_coder, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.115_32 () (_ BitVec 32))
(assert
 (let (($x62 (or false false false)))
(let (($x523 (not $x62)))
(and $x523 (or $x62 (and (distinct (bvor in.115_32 (_ bv1 32)) (bvor in.115_32 (_ bv1 32))) true))))))
(check-sat)
; query 7: function adpcm_coder, block 43, name %45
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in41_32 () (_ BitVec 32))
(declare-fun in.19_32 () (_ BitVec 32))
(assert
 (let (($x59 (and (distinct (bvadd ((_ sign_extend 1) in.19_32) ((_ sign_extend 1) in41_32)) ((_ sign_extend 1) (bvadd in.19_32 in41_32))) true)))
(let (($x468 (or false false (or $x59))))
(let (($x82 (or $x468 (and (distinct (bvadd in.19_32 in41_32) (bvadd in.19_32 in41_32)) true))))
(and (not $x468) $x82)))))
(check-sat)
; query 8: function adpcm_coder, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.210_32 () (_ BitVec 32))
(declare-fun in.011_32 () (_ BitVec 32))
(assert
 (let ((?x166 (bvsub in.011_32 in.210_32)))
(let (($x446 (and (distinct (bvsub ((_ sign_extend 1) in.011_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x166)) true)))
(let (($x167 (or false false (or $x446))))
(and (not $x167) (or $x167 (and (distinct ?x166 ?x166) true)))))))
(check-sat)
; query 9: function adpcm_coder, block 50, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.210_32 () (_ BitVec 32))
(declare-fun in.011_32 () (_ BitVec 32))
(assert
 (let ((?x74 (bvadd in.011_32 in.210_32)))
(let (($x622 (and (distinct (bvadd ((_ sign_extend 1) in.011_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x74)) true)))
(let (($x52 (or false false (or $x622))))
(and (not $x52) (or $x52 (and (distinct ?x74 ?x74) true)))))))
(check-sat)
; query 10: function adpcm_coder, block 55, name %56
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.112_32 () (_ BitVec 32))
(assert
 (let ((?x78 (ite (bvsgt (_ bv4294934528 32) in.112_32) (_ bv1 1) (_ bv0 1))))
(let (($x62 (or false false false)))
(let (($x523 (not $x62)))
(and $x523 (or $x62 (and (distinct ?x78 ?x78) true)))))))
(check-sat)
; query 11: function adpcm_coder, block 75, name %76
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in60_32 () (_ BitVec 32))
(assert
 (let (($x62 (or false false false)))
(let (($x81 (or $x62 (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x81) (or $x81 (and (distinct (bvshl in60_32 (_ bv4 32)) (bvshl in60_32 (_ bv4 32))) true))))))
(check-sat)
; query 12: function adpcm_coder, block 75, name %77
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in60_32 () (_ BitVec 32))
(assert
 (let ((?x46 (bvshl in60_32 (_ bv4 32))))
(let ((?x176 (bvand ?x46 (_ bv240 32))))
(let (($x62 (or false false false)))
(let (($x81 (or $x62 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x47 (or $x81 false false)))
(and (not $x47) (or $x47 (and (distinct ?x176 ?x176) true)))))))))
(check-sat)
; query 13: function adpcm_coder, block 87, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x887 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv4294967295 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv4294967295 32)))) true)))
(let (($x159 (or false false (or $x887))))
(and (not $x159) (or $x159 (and (distinct (bvadd in.02_32 (_ bv4294967295 32)) (bvadd in.02_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 14: function adpcm_decoder, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x494 (ite (and (distinct (_ bv0 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x62 (or false false false)))
(let (($x523 (not $x62)))
(and $x523 (or $x62 (and (distinct ?x494 ?x494) true)))))))
(check-sat)
; query 15: function adpcm_decoder, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x62 (or false false false)))
(let (($x523 (not $x62)))
(and $x523 (or $x62 (and (distinct (bvand in.01_32 (_ bv15 32)) (bvand in.01_32 (_ bv15 32))) true))))))
(check-sat)
; query 16: function adpcm_decoder, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.012_32 () (_ BitVec 32))
(declare-fun in42_32 () (_ BitVec 32))
(assert
 (let (($x791 (and (distinct (bvadd ((_ sign_extend 1) in42_32) ((_ sign_extend 1) in.012_32)) ((_ sign_extend 1) (bvadd in42_32 in.012_32))) true)))
(let (($x36 (or false false (or $x791))))
(let (($x685 (or $x36 (and (distinct (bvadd in42_32 in.012_32) (bvadd in42_32 in.012_32)) true))))
(and (not $x36) $x685)))))
(check-sat)
; query 17: function adpcm_decoder, block 50, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.012_32 () (_ BitVec 32))
(assert
 (let (($x62 (or false false false)))
(let (($x708 (or $x62 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x1485 (or $x708 (and (distinct (bvashr in.012_32 (_ bv1 32)) (bvashr in.012_32 (_ bv1 32))) true))))
(and (not $x708) $x1485)))))
(check-sat)
; query 18: function adpcm_decoder, block 50, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.012_32 () (_ BitVec 32))
(declare-fun in.08_32 () (_ BitVec 32))
(assert
 (let ((?x590 (bvashr in.012_32 (_ bv1 32))))
(let ((?x300 (bvadd in.08_32 ?x590)))
(let (($x309 (and (distinct (bvadd ((_ sign_extend 1) in.08_32) ((_ sign_extend 1) ?x590)) ((_ sign_extend 1) ?x300)) true)))
(let (($x62 (or false false false)))
(let (($x708 (or $x62 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x901 (or false $x708 (or $x309))))
(and (not $x901) (or $x901 (and (distinct ?x300 ?x300) true))))))))))
(check-sat)
; query 19: function adpcm_decoder, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.012_32 () (_ BitVec 32))
(assert
 (let (($x62 (or false false false)))
(let (($x1004 (or $x62 (bvuge (_ bv2 32) (_ bv32 32)))))
(let (($x1134 (or $x1004 (and (distinct (bvashr in.012_32 (_ bv2 32)) (bvashr in.012_32 (_ bv2 32))) true))))
(and (not $x1004) $x1134)))))
(check-sat)
; query 20: function adpcm_decoder, block 56, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.012_32 () (_ BitVec 32))
(declare-fun in.19_32 () (_ BitVec 32))
(assert
 (let ((?x1481 (bvashr in.012_32 (_ bv2 32))))
(let ((?x1032 (bvadd in.19_32 ?x1481)))
(let (($x1548 (and (distinct (bvadd ((_ sign_extend 1) in.19_32) ((_ sign_extend 1) ?x1481)) ((_ sign_extend 1) ?x1032)) true)))
(let (($x62 (or false false false)))
(let (($x1004 (or $x62 (bvuge (_ bv2 32) (_ bv32 32)))))
(let (($x1092 (or false $x1004 (or $x1548))))
(and (not $x1092) (or $x1092 (and (distinct ?x1032 ?x1032) true))))))))))
(check-sat)
; query 21: function adpcm_decoder, block 61, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.210_32 () (_ BitVec 32))
(declare-fun in.013_32 () (_ BitVec 32))
(assert
 (let ((?x762 (bvsub in.013_32 in.210_32)))
(let (($x1141 (and (distinct (bvsub ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x762)) true)))
(let (($x807 (or false false (or $x1141))))
(and (not $x807) (or $x807 (and (distinct ?x762 ?x762) true)))))))
(check-sat)
; query 22: function adpcm_decoder, block 63, name %64
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.210_32 () (_ BitVec 32))
(declare-fun in.013_32 () (_ BitVec 32))
(assert
 (let ((?x766 (bvadd in.013_32 in.210_32)))
(let (($x838 (and (distinct (bvadd ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x766)) true)))
(let (($x953 (or false false (or $x838))))
(and (not $x953) (or $x953 (and (distinct ?x766 ?x766) true)))))))
(check-sat)
; query 23: function adpcm_decoder, block 68, name %69
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.114_32 () (_ BitVec 32))
(assert
 (let ((?x801 (ite (bvsgt (_ bv4294934528 32) in.114_32) (_ bv1 1) (_ bv0 1))))
(let (($x62 (or false false false)))
(let (($x523 (not $x62)))
(and $x523 (or $x62 (and (distinct ?x801 ?x801) true)))))))
(check-sat)
; query 24: function adpcm_decoder, block 78, name %79
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x887 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv4294967295 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv4294967295 32)))) true)))
(let (($x159 (or false false (or $x887))))
(and (not $x159) (or $x159 (and (distinct (bvadd in.02_32 (_ bv4294967295 32)) (bvadd in.02_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 25: function main, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x864 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x62 (or false false false)))
(let (($x523 (not $x62)))
(and $x523 (or $x62 (and (distinct ?x864 ?x864) true)))))))
(check-sat)
