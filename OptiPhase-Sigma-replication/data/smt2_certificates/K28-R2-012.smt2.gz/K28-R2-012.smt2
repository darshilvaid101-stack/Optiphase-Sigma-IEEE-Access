; OptiPhase-Sigma refinement certificate for sweep K28-R2-012
