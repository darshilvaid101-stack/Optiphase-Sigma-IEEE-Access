; OptiPhase-Sigma refinement certificate for sweep K55-R2-088
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x1748 (or false false)))
(let (($x64 (not $x1748)))
(and $x64 (or $x1748 (and (distinct ((_ sign_extend 16) in25_16) ((_ sign_extend 16) in25_16)) true))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let ((?x274 (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1748 (or false false)))
(let (($x282 (or $x1748 false false)))
(let (($x1838 (not $x282)))
(and $x1838 (or $x282 (and (distinct ?x274 ?x274) true))))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x1748 (or false false)))
(let (($x64 (not $x1748)))
(and $x64 (or $x1748 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x533 ((_ sign_extend 16) in3_16)))
(let ((?x541 (bvand ?x533 (_ bv127 32))))
(let (($x1748 (or false false)))
(let (($x282 (or $x1748 false false)))
(let (($x1838 (not $x282)))
(and $x1838 (or $x282 (and (distinct ?x541 ?x541) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x533 ((_ sign_extend 16) in3_16)))
(let ((?x541 (bvand ?x533 (_ bv127 32))))
(let ((?x1664 ((_ extract 15 0) ?x541)))
(let (($x1748 (or false false)))
(let (($x282 (or $x1748 false false)))
(let (($x974 (or $x282 false)))
(let (($x56 (not $x974)))
(and $x56 (or $x974 (and (distinct ?x1664 ?x1664) true)))))))))))
(check-sat)
; query 5: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x1748 (or false false)))
(let (($x64 (not $x1748)))
(and $x64 (or $x1748 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 6: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x290 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x1748 (or false false)))
(let (($x282 (or $x1748 false false)))
(let (($x1838 (not $x282)))
(and $x1838 (or $x282 (and (distinct ?x290 ?x290) true))))))))
(check-sat)
; query 7: function core_bench_list, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x1354 (or false false false)))
(let (($x1948 (not $x1354)))
(and $x1948 (or $x1354 (and (distinct (bvadd in.0_16 (_ bv1 16)) (bvadd in.0_16 (_ bv1 16))) true))))))
(check-sat)
; query 8: function core_bench_state, block 105, name %106
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x1354 (or false false false)))
(let (($x1948 (not $x1354)))
(and $x1948 (or $x1354 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 9: function core_bench_state, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1354 (or false false false)))
(let (($x1948 (not $x1354)))
(and $x1948 (or $x1354 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 10: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x216 (bvadd in.01_32 (_ bv1 32))))
(let (($x479 (and (distinct ?x216 ?x216) true)))
(let (($x1354 (or false false false)))
(let (($x1948 (not $x1354)))
(and $x1948 (or $x1354 $x479)))))))
(check-sat)
; query 11: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x216 (bvadd in.01_32 (_ bv1 32))))
(let ((?x184 (bvmul ?x216 ?x216)))
(let (($x1354 (or false false false)))
(let (($x596 (or $x1354 $x1354 false)))
(and (not $x596) (or $x596 (and (distinct ?x184 ?x184) true))))))))
(check-sat)
; query 12: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x216 (bvadd in.01_32 (_ bv1 32))))
(let ((?x184 (bvmul ?x216 ?x216)))
(let ((?x163 (bvmul ?x184 (_ bv2 32))))
(let (($x1354 (or false false false)))
(let (($x596 (or $x1354 $x1354 false)))
(let (($x12 (or $x596 false false)))
(and (not $x12) (or $x12 (and (distinct ?x163 ?x163) true))))))))))
(check-sat)
; query 13: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x216 (bvadd in.01_32 (_ bv1 32))))
(let ((?x184 (bvmul ?x216 ?x216)))
(let ((?x163 (bvmul ?x184 (_ bv2 32))))
(let ((?x454 (bvmul ?x163 (_ bv4 32))))
(let (($x1354 (or false false false)))
(let (($x596 (or $x1354 $x1354 false)))
(let (($x12 (or $x596 false false)))
(let (($x301 (or $x12 false false)))
(and (not $x301) (or $x301 (and (distinct ?x454 ?x454) true))))))))))))
(check-sat)
; query 14: function core_init_matrix, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x1354 (or false false false)))
(let (($x1948 (not $x1354)))
(and $x1948 (or $x1354 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 15: function core_init_matrix, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x1354 (or false false false)))
(let (($x1948 (not $x1354)))
(and $x1948 (or $x1354 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 16: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x1837 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x1354 (or false false false)))
(let (($x1948 (not $x1354)))
(and $x1948 (or $x1354 (and (distinct ?x1837 ?x1837) true)))))))
(check-sat)
; query 17: function core_init_state, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_32 () (_ BitVec 32))
(assert
 (let (($x1354 (or false false false)))
(let (($x1948 (not $x1354)))
(and $x1948 (or $x1354 (and (distinct (bvadd in.06_32 (_ bv1 32)) (bvadd in.06_32 (_ bv1 32))) true))))))
(check-sat)
; query 18: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x1771 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x1354 (or false false false)))
(let (($x1948 (not $x1354)))
(and $x1948 (or $x1354 (and (distinct ?x1771 ?x1771) true)))))))
(check-sat)
; query 19: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x1354 (or false false false)))
(let (($x1948 (not $x1354)))
(and $x1948 (or $x1354 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 20: function core_list_init, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x216 (bvadd in.01_32 (_ bv1 32))))
(let (($x479 (and (distinct ?x216 ?x216) true)))
(let (($x1354 (or false false false)))
(let (($x1948 (not $x1354)))
(and $x1948 (or $x1354 $x479)))))))
(check-sat)
; query 21: function core_list_mergesort, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x216 (bvadd in.01_32 (_ bv1 32))))
(let (($x479 (and (distinct ?x216 ?x216) true)))
(let (($x111 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x216)) true)))
(let (($x1702 (or false false (or $x111))))
(and (not $x1702) (or $x1702 $x479)))))))
(check-sat)
; query 22: function core_list_mergesort, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x1649 (ite (bvslt (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x1354 (or false false false)))
(let (($x1948 (not $x1354)))
(and $x1948 (or $x1354 (and (distinct ?x1649 ?x1649) true)))))))
(check-sat)
; query 23: function core_list_mergesort, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.224_32 () (_ BitVec 32))
(assert
 (let ((?x1654 (ite (= (_ bv0 32) in.224_32) (_ bv1 1) (_ bv0 1))))
(let (($x1354 (or false false false)))
(let (($x1948 (not $x1354)))
(and $x1948 (or $x1354 (and (distinct ?x1654 ?x1654) true)))))))
(check-sat)
; query 24: function core_list_mergesort, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x1839 (ite (= (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x1354 (or false false false)))
(let (($x1948 (not $x1354)))
(and $x1948 (or $x1354 (and (distinct ?x1839 ?x1839) true)))))))
(check-sat)
; query 25: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x1688 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x1694 (or false false (or $x1688))))
(and (not $x1694) (or $x1694 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 26: function core_list_mergesort, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x926 (and (distinct (bvmul ((_ sign_extend 32) in.020_32) ((_ sign_extend 32) (_ bv2 32))) ((_ sign_extend 32) (bvmul in.020_32 (_ bv2 32)))) true)))
(let (($x244 (or false false (or $x926))))
(and (not $x244) (or $x244 (and (distinct (bvmul in.020_32 (_ bv2 32)) (bvmul in.020_32 (_ bv2 32))) true))))))
(check-sat)
; query 27: function core_state_transition, block 102, name %103
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1748 (or false false)))
(let (($x64 (not $x1748)))
(and $x64 (or $x1748 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 28: function core_state_transition, block 102, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x884 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1748 (or false false)))
(let (($x282 (or $x1748 false false)))
(let (($x1838 (not $x282)))
(and $x1838 (or $x282 (and (distinct ?x884 ?x884) true))))))))
(check-sat)
; query 29: function core_state_transition, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1748 (or false false)))
(let (($x64 (not $x1748)))
(and $x64 (or $x1748 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 30: function core_state_transition, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x366 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1748 (or false false)))
(let (($x282 (or $x1748 false false)))
(let (($x1838 (not $x282)))
(and $x1838 (or $x282 (and (distinct ?x366 ?x366) true))))))))
(check-sat)
; query 31: function core_state_transition, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1748 (or false false)))
(let (($x64 (not $x1748)))
(and $x64 (or $x1748 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 32: function core_state_transition, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x884 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1748 (or false false)))
(let (($x282 (or $x1748 false false)))
(let (($x1838 (not $x282)))
(and $x1838 (or $x282 (and (distinct ?x884 ?x884) true))))))))
(check-sat)
; query 33: function core_state_transition, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1748 (or false false)))
(let (($x64 (not $x1748)))
(and $x64 (or $x1748 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 34: function core_state_transition, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x717 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1748 (or false false)))
(let (($x282 (or $x1748 false false)))
(let (($x1838 (not $x282)))
(and $x1838 (or $x282 (and (distinct ?x717 ?x717) true))))))))
(check-sat)
; query 35: function core_state_transition, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1748 (or false false)))
(let (($x64 (not $x1748)))
(and $x64 (or $x1748 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 36: function core_state_transition, block 51, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x717 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1748 (or false false)))
(let (($x282 (or $x1748 false false)))
(let (($x1838 (not $x282)))
(and $x1838 (or $x282 (and (distinct ?x717 ?x717) true))))))))
(check-sat)
; query 37: function core_state_transition, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1748 (or false false)))
(let (($x64 (not $x1748)))
(and $x64 (or $x1748 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 38: function core_state_transition, block 64, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x717 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1748 (or false false)))
(let (($x282 (or $x1748 false false)))
(let (($x1838 (not $x282)))
(and $x1838 (or $x282 (and (distinct ?x717 ?x717) true))))))))
(check-sat)
; query 39: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x406 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x1354 (or false false false)))
(let (($x1948 (not $x1354)))
(and $x1948 (or $x1354 (and (distinct ?x406 ?x406) true)))))))
(check-sat)
; query 40: function core_state_transition, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1748 (or false false)))
(let (($x64 (not $x1748)))
(and $x64 (or $x1748 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 41: function core_state_transition, block 80, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x821 (ite (= (_ bv69 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1748 (or false false)))
(let (($x282 (or $x1748 false false)))
(let (($x1838 (not $x282)))
(and $x1838 (or $x282 (and (distinct ?x821 ?x821) true))))))))
(check-sat)
; query 42: function core_state_transition, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1748 (or false false)))
(let (($x64 (not $x1748)))
(and $x64 (or $x1748 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 43: function core_state_transition, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x822 (ite (= (_ bv101 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1748 (or false false)))
(let (($x282 (or $x1748 false false)))
(let (($x1838 (not $x282)))
(and $x1838 (or $x282 (and (distinct ?x822 ?x822) true))))))))
(check-sat)
; query 44: function core_state_transition, block 99, name %100
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1748 (or false false)))
(let (($x64 (not $x1748)))
(and $x64 (or $x1748 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 45: function core_state_transition, block 99, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x366 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1748 (or false false)))
(let (($x282 (or $x1748 false false)))
(let (($x1838 (not $x282)))
(and $x1838 (or $x282 (and (distinct ?x366 ?x366) true))))))))
(check-sat)
; query 46: function crcu8, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x1748 (or false false)))
(let (($x64 (not $x1748)))
(and $x64 (or $x1748 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 47: function crcu8, block 19, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x930 ((_ zero_extend 16) in.01_16)))
(let ((?x968 (bvxor ?x930 (_ bv16386 32))))
(let (($x1748 (or false false)))
(let (($x282 (or $x1748 false false)))
(let (($x1838 (not $x282)))
(and $x1838 (or $x282 (and (distinct ?x968 ?x968) true)))))))))
(check-sat)
; query 48: function crcu8, block 19, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x930 ((_ zero_extend 16) in.01_16)))
(let ((?x968 (bvxor ?x930 (_ bv16386 32))))
(let ((?x122 ((_ extract 15 0) ?x968)))
(let (($x1748 (or false false)))
(let (($x282 (or $x1748 false false)))
(let (($x974 (or $x282 false)))
(let (($x56 (not $x974)))
(and $x56 (or $x974 (and (distinct ?x122 ?x122) true)))))))))))
(check-sat)
; query 49: function crcu8, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x1748 (or false false)))
(let (($x64 (not $x1748)))
(and $x64 (or $x1748 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 50: function crcu8, block 29, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1704 ((_ zero_extend 16) in27_16)))
(let ((?x1720 (bvor ?x1704 (_ bv32768 32))))
(let (($x1748 (or false false)))
(let (($x282 (or $x1748 false false)))
(let (($x1838 (not $x282)))
(and $x1838 (or $x282 (and (distinct ?x1720 ?x1720) true)))))))))
(check-sat)
; query 51: function crcu8, block 29, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1704 ((_ zero_extend 16) in27_16)))
(let ((?x1720 (bvor ?x1704 (_ bv32768 32))))
(let ((?x785 ((_ extract 15 0) ?x1720)))
(let (($x1748 (or false false)))
(let (($x282 (or $x1748 false false)))
(let (($x974 (or $x282 false)))
(let (($x56 (not $x974)))
(and $x56 (or $x974 (and (distinct ?x785 ?x785) true)))))))))))
(check-sat)
; query 52: function crcu8, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x1748 (or false false)))
(let (($x64 (not $x1748)))
(and $x64 (or $x1748 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 53: function crcu8, block 33, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1704 ((_ zero_extend 16) in27_16)))
(let ((?x1202 (bvand ?x1704 (_ bv32767 32))))
(let (($x1748 (or false false)))
(let (($x282 (or $x1748 false false)))
(let (($x1838 (not $x282)))
(and $x1838 (or $x282 (and (distinct ?x1202 ?x1202) true)))))))))
(check-sat)
; query 54: function crcu8, block 33, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1704 ((_ zero_extend 16) in27_16)))
(let ((?x1202 (bvand ?x1704 (_ bv32767 32))))
(let ((?x1214 ((_ extract 15 0) ?x1202)))
(let (($x1748 (or false false)))
(let (($x282 (or $x1748 false false)))
(let (($x974 (or $x282 false)))
(let (($x56 (not $x974)))
(and $x56 (or $x974 (and (distinct ?x1214 ?x1214) true)))))))))))
(check-sat)
; query 55: function crcu8, block 38, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_8 () (_ BitVec 8))
(assert
 (let (($x1354 (or false false false)))
(let (($x1948 (not $x1354)))
(and $x1948 (or $x1354 (and (distinct (bvadd in.02_8 (_ bv1 8)) (bvadd in.02_8 (_ bv1 8))) true))))))
(check-sat)
; query 56: function crcu8, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x939 ((_ extract 7 0) in.01_16)))
(let ((?x973 ((_ zero_extend 24) ?x939)))
(let (($x1748 (or false false)))
(let (($x344 (or $x1748 false)))
(and (not $x344) (or $x344 (and (distinct ?x973 ?x973) true))))))))
(check-sat)
; query 57: function crcu8, block 6, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x939 ((_ extract 7 0) in.01_16)))
(let ((?x973 ((_ zero_extend 24) ?x939)))
(let ((?x951 (bvand ?x973 (_ bv1 32))))
(let (($x1748 (or false false)))
(let (($x344 (or $x1748 false)))
(let (($x1934 (or $x344 false false)))
(and (not $x1934) (or $x1934 (and (distinct ?x951 ?x951) true))))))))))
(check-sat)
; query 58: function crcu8, block 6, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x939 ((_ extract 7 0) in.01_16)))
(let ((?x973 ((_ zero_extend 24) ?x939)))
(let ((?x951 (bvand ?x973 (_ bv1 32))))
(let ((?x955 ((_ zero_extend 24) in.0_8)))
(let ((?x396 (bvand ?x955 (_ bv1 32))))
(let ((?x958 (bvxor ?x396 ?x951)))
(let (($x1748 (or false false)))
(let (($x344 (or $x1748 false)))
(let (($x1934 (or $x344 false false)))
(let (($x282 (or $x1748 false false)))
(let (($x1222 (or $x282 $x1934 false)))
(and (not $x1222) (or $x1222 (and (distinct ?x958 ?x958) true)))))))))))))))
(check-sat)
; query 59: function crcu8, block 6, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x939 ((_ extract 7 0) in.01_16)))
(let ((?x973 ((_ zero_extend 24) ?x939)))
(let ((?x951 (bvand ?x973 (_ bv1 32))))
(let ((?x955 ((_ zero_extend 24) in.0_8)))
(let ((?x396 (bvand ?x955 (_ bv1 32))))
(let ((?x958 (bvxor ?x396 ?x951)))
(let ((?x807 ((_ extract 7 0) ?x958)))
(let (($x1748 (or false false)))
(let (($x344 (or $x1748 false)))
(let (($x1934 (or $x344 false false)))
(let (($x282 (or $x1748 false false)))
(let (($x1222 (or $x282 $x1934 false)))
(let (($x937 (or $x1222 false)))
(and (not $x937) (or $x937 (and (distinct ?x807 ?x807) true)))))))))))))))))
(check-sat)
; query 60: function crcu8, block 6, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x1748 (or false false)))
(let (($x64 (not $x1748)))
(and $x64 (or $x1748 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 61: function crcu8, block 6, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x955 ((_ zero_extend 24) in.0_8)))
(let ((?x895 (bvashr ?x955 (_ bv1 32))))
(let (($x1748 (or false false)))
(let (($x282 (or $x1748 false false)))
(let (($x453 (or $x282 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not $x453) (or $x453 (and (distinct ?x895 ?x895) true)))))))))
(check-sat)
; query 62: function crcu8, block 6, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x955 ((_ zero_extend 24) in.0_8)))
(let ((?x895 (bvashr ?x955 (_ bv1 32))))
(let ((?x747 ((_ extract 7 0) ?x895)))
(let (($x1748 (or false false)))
(let (($x282 (or $x1748 false false)))
(let (($x453 (or $x282 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x882 (or $x453 false)))
(and (not $x882) (or $x882 (and (distinct ?x747 ?x747) true)))))))))))
(check-sat)
; query 63: function crcu8, block 6, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x939 ((_ extract 7 0) in.01_16)))
(let ((?x973 ((_ zero_extend 24) ?x939)))
(let ((?x951 (bvand ?x973 (_ bv1 32))))
(let ((?x955 ((_ zero_extend 24) in.0_8)))
(let ((?x396 (bvand ?x955 (_ bv1 32))))
(let ((?x958 (bvxor ?x396 ?x951)))
(let ((?x807 ((_ extract 7 0) ?x958)))
(let ((?x991 ((_ zero_extend 24) ?x807)))
(let (($x1748 (or false false)))
(let (($x344 (or $x1748 false)))
(let (($x1934 (or $x344 false false)))
(let (($x282 (or $x1748 false false)))
(let (($x1222 (or $x282 $x1934 false)))
(let (($x937 (or $x1222 false)))
(let (($x969 (or $x937 false)))
(and (not $x969) (or $x969 (and (distinct ?x991 ?x991) true)))))))))))))))))))
(check-sat)
; query 64: function crcu8, block 6, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x939 ((_ extract 7 0) in.01_16)))
(let ((?x973 ((_ zero_extend 24) ?x939)))
(let ((?x951 (bvand ?x973 (_ bv1 32))))
(let ((?x955 ((_ zero_extend 24) in.0_8)))
(let ((?x396 (bvand ?x955 (_ bv1 32))))
(let ((?x958 (bvxor ?x396 ?x951)))
(let ((?x807 ((_ extract 7 0) ?x958)))
(let ((?x991 ((_ zero_extend 24) ?x807)))
(let ((?x946 (ite (= (_ bv1 32) ?x991) (_ bv1 1) (_ bv0 1))))
(let (($x1748 (or false false)))
(let (($x344 (or $x1748 false)))
(let (($x1934 (or $x344 false false)))
(let (($x282 (or $x1748 false false)))
(let (($x1222 (or $x282 $x1934 false)))
(let (($x937 (or $x1222 false)))
(let (($x969 (or $x937 false)))
(let (($x943 (or $x969 false false)))
(and (not $x943) (or $x943 (and (distinct ?x946 ?x946) true)))))))))))))))))))))
(check-sat)
; query 65: function crcu8, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x1748 (or false false)))
(let (($x64 (not $x1748)))
(and $x64 (or $x1748 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 66: function crcu8, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x955 ((_ zero_extend 24) in.0_8)))
(let ((?x396 (bvand ?x955 (_ bv1 32))))
(let (($x1748 (or false false)))
(let (($x282 (or $x1748 false false)))
(let (($x1838 (not $x282)))
(and $x1838 (or $x282 (and (distinct ?x396 ?x396) true)))))))))
(check-sat)
; query 67: function crcu8, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x1748 (or false false)))
(let (($x64 (not $x1748)))
(and $x64 (or $x1748 (and (distinct ((_ extract 7 0) in.01_16) ((_ extract 7 0) in.01_16)) true))))))
(check-sat)
; query 68: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x169 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x781 ((_ zero_extend 31) ?x169)))
(let ((?x645 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1831 ((_ zero_extend 31) ?x645)))
(let ((?x678 (bvand ?x1831 ?x781)))
(let ((?x137 (ite (and (distinct (_ bv0 32) ?x678) true) (_ bv1 1) (_ bv0 1))))
(let ((?x903 ((_ zero_extend 63) ?x137)))
(let (($x1748 (or false false)))
(let (($x282 (or $x1748 false false)))
(let (($x974 (or $x282 false)))
(let (($x143 (or $x974 $x974 false)))
(let (($x702 (or $x143 false false)))
(let (($x934 (or $x702 false)))
(and (not $x934) (or $x934 (and (distinct ?x903 ?x903) true)))))))))))))))))
(check-sat)
; query 69: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x169 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x781 ((_ zero_extend 31) ?x169)))
(let ((?x645 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1831 ((_ zero_extend 31) ?x645)))
(let ((?x678 (bvand ?x1831 ?x781)))
(let ((?x137 (ite (and (distinct (_ bv0 32) ?x678) true) (_ bv1 1) (_ bv0 1))))
(let (($x155 (= (_ bv1 1) ?x137)))
(let ((?x837 (ite $x155 (_ bv1 32) (_ bv0 32))))
(let (($x1748 (or false false)))
(let (($x282 (or $x1748 false false)))
(let (($x974 (or $x282 false)))
(let (($x143 (or $x974 $x974 false)))
(let (($x702 (or $x143 false false)))
(let (($x985 (or $x702 (ite $x155 false false))))
(and (not $x985) (or $x985 (and (distinct ?x837 ?x837) true))))))))))))))))))
(check-sat)
; query 70: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x169 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x781 ((_ zero_extend 31) ?x169)))
(let ((?x645 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1831 ((_ zero_extend 31) ?x645)))
(let ((?x678 (bvand ?x1831 ?x781)))
(let ((?x137 (ite (and (distinct (_ bv0 32) ?x678) true) (_ bv1 1) (_ bv0 1))))
(let (($x155 (= (_ bv1 1) ?x137)))
(let ((?x837 (ite $x155 (_ bv1 32) (_ bv0 32))))
(let ((?x618 ((_ extract 7 0) ?x837)))
(let (($x1748 (or false false)))
(let (($x282 (or $x1748 false false)))
(let (($x974 (or $x282 false)))
(let (($x143 (or $x974 $x974 false)))
(let (($x702 (or $x143 false false)))
(let (($x985 (or $x702 (ite $x155 false false))))
(let (($x300 (or $x985 false)))
(and (not $x300) (or $x300 (and (distinct ?x618 ?x618) true))))))))))))))))))))
(check-sat)
; query 71: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x1748 (or false false)))
(let (($x64 (not $x1748)))
(and $x64 (or $x1748 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 72: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x645 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1748 (or false false)))
(let (($x282 (or $x1748 false false)))
(let (($x1838 (not $x282)))
(and $x1838 (or $x282 (and (distinct ?x645 ?x645) true))))))))
(check-sat)
; query 73: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x645 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1831 ((_ zero_extend 31) ?x645)))
(let (($x1748 (or false false)))
(let (($x282 (or $x1748 false false)))
(let (($x974 (or $x282 false)))
(let (($x56 (not $x974)))
(and $x56 (or $x974 (and (distinct ?x1831 ?x1831) true))))))))))
(check-sat)
; query 74: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x1748 (or false false)))
(let (($x64 (not $x1748)))
(and $x64 (or $x1748 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 75: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x169 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1748 (or false false)))
(let (($x282 (or $x1748 false false)))
(let (($x1838 (not $x282)))
(and $x1838 (or $x282 (and (distinct ?x169 ?x169) true))))))))
(check-sat)
; query 76: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x169 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x781 ((_ zero_extend 31) ?x169)))
(let (($x1748 (or false false)))
(let (($x282 (or $x1748 false false)))
(let (($x974 (or $x282 false)))
(let (($x56 (not $x974)))
(and $x56 (or $x974 (and (distinct ?x781 ?x781) true))))))))))
(check-sat)
; query 77: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x169 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x781 ((_ zero_extend 31) ?x169)))
(let ((?x645 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1831 ((_ zero_extend 31) ?x645)))
(let ((?x678 (bvand ?x1831 ?x781)))
(let (($x1748 (or false false)))
(let (($x282 (or $x1748 false false)))
(let (($x974 (or $x282 false)))
(let (($x143 (or $x974 $x974 false)))
(and (not $x143) (or $x143 (and (distinct ?x678 ?x678) true)))))))))))))
(check-sat)
; query 78: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x169 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x781 ((_ zero_extend 31) ?x169)))
(let ((?x645 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1831 ((_ zero_extend 31) ?x645)))
(let ((?x678 (bvand ?x1831 ?x781)))
(let ((?x137 (ite (and (distinct (_ bv0 32) ?x678) true) (_ bv1 1) (_ bv0 1))))
(let (($x1748 (or false false)))
(let (($x282 (or $x1748 false false)))
(let (($x974 (or $x282 false)))
(let (($x143 (or $x974 $x974 false)))
(let (($x702 (or $x143 false false)))
(and (not $x702) (or $x702 (and (distinct ?x137 ?x137) true)))))))))))))))
(check-sat)
; query 79: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x249 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x1354 (or false false false)))
(let (($x1948 (not $x1354)))
(and $x1948 (or $x1354 (and (distinct ?x249 ?x249) true)))))))
(check-sat)
; query 80: function matrix_add_const, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1354 (or false false false)))
(let (($x1948 (not $x1354)))
(and $x1948 (or $x1354 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 81: function matrix_add_const, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x216 (bvadd in.01_32 (_ bv1 32))))
(let (($x479 (and (distinct ?x216 ?x216) true)))
(let (($x1354 (or false false false)))
(let (($x1948 (not $x1354)))
(and $x1948 (or $x1354 $x479)))))))
(check-sat)
; query 82: function matrix_mul_const, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1354 (or false false false)))
(let (($x1948 (not $x1354)))
(and $x1948 (or $x1354 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 83: function matrix_mul_const, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x216 (bvadd in.01_32 (_ bv1 32))))
(let (($x479 (and (distinct ?x216 ?x216) true)))
(let (($x1354 (or false false false)))
(let (($x1948 (not $x1354)))
(and $x1948 (or $x1354 $x479)))))))
(check-sat)
; query 84: function matrix_mul_matrix, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1354 (or false false false)))
(let (($x1948 (not $x1354)))
(and $x1948 (or $x1354 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 85: function matrix_mul_matrix, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x216 (bvadd in.01_32 (_ bv1 32))))
(let (($x479 (and (distinct ?x216 ?x216) true)))
(let (($x1354 (or false false false)))
(let (($x1948 (not $x1354)))
(and $x1948 (or $x1354 $x479)))))))
(check-sat)
; query 86: function matrix_mul_matrix, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x1354 (or false false false)))
(let (($x1948 (not $x1354)))
(and $x1948 (or $x1354 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 87: function matrix_mul_matrix_bitextract, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1354 (or false false false)))
(let (($x1948 (not $x1354)))
(and $x1948 (or $x1354 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 88: function matrix_mul_matrix_bitextract, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x216 (bvadd in.01_32 (_ bv1 32))))
(let (($x479 (and (distinct ?x216 ?x216) true)))
(let (($x1354 (or false false false)))
(let (($x1948 (not $x1354)))
(and $x1948 (or $x1354 $x479)))))))
(check-sat)
; query 89: function matrix_mul_matrix_bitextract, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x1354 (or false false false)))
(let (($x1948 (not $x1354)))
(and $x1948 (or $x1354 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 90: function matrix_mul_vect, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1354 (or false false false)))
(let (($x1948 (not $x1354)))
(and $x1948 (or $x1354 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 91: function matrix_mul_vect, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x216 (bvadd in.01_32 (_ bv1 32))))
(let (($x479 (and (distinct ?x216 ?x216) true)))
(let (($x1354 (or false false false)))
(let (($x1948 (not $x1354)))
(and $x1948 (or $x1354 $x479)))))))
(check-sat)
; query 92: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x1748 (or false false)))
(let (($x64 (not $x1748)))
(and $x64 (or $x1748 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 93: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x867 ((_ sign_extend 16) in.1_16)))
(let ((?x261 (bvadd ?x867 (_ bv10 32))))
(let (($x201 (and (distinct (bvadd ((_ sign_extend 1) ?x867) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x261)) true)))
(let (($x1748 (or false false)))
(let (($x412 (or $x1748 false (or $x201))))
(and (not $x412) (or $x412 (and (distinct ?x261 ?x261) true)))))))))
(check-sat)
; query 94: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x867 ((_ sign_extend 16) in.1_16)))
(let ((?x261 (bvadd ?x867 (_ bv10 32))))
(let ((?x289 ((_ extract 15 0) ?x261)))
(let (($x201 (and (distinct (bvadd ((_ sign_extend 1) ?x867) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x261)) true)))
(let (($x1748 (or false false)))
(let (($x412 (or $x1748 false (or $x201))))
(let (($x518 (or $x412 false)))
(and (not $x518) (or $x518 (and (distinct ?x289 ?x289) true)))))))))))
(check-sat)
; query 95: function matrix_sum, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x819 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x1354 (or false false false)))
(let (($x1948 (not $x1354)))
(and $x1948 (or $x1354 (and (distinct ?x819 ?x819) true)))))))
(check-sat)
; query 96: function matrix_sum, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x819 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let ((?x549 ((_ zero_extend 63) ?x819)))
(let (($x1354 (or false false false)))
(let (($x218 (or $x1354 false)))
(and (not $x218) (or $x218 (and (distinct ?x549 ?x549) true))))))))
(check-sat)
; query 97: function matrix_sum, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x819 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x582 (= (_ bv1 1) ?x819)))
(let ((?x547 (ite $x582 (_ bv1 32) (_ bv0 32))))
(let (($x1354 (or false false false)))
(let (($x777 (or $x1354 (ite $x582 false false))))
(and (not $x777) (or $x777 (and (distinct ?x547 ?x547) true)))))))))
(check-sat)
; query 98: function matrix_sum, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x1748 (or false false)))
(let (($x64 (not $x1748)))
(and $x64 (or $x1748 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 99: function matrix_sum, block 22, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x819 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x582 (= (_ bv1 1) ?x819)))
(let ((?x547 (ite $x582 (_ bv1 32) (_ bv0 32))))
(let ((?x867 ((_ sign_extend 16) in.1_16)))
(let ((?x873 (bvadd ?x867 ?x547)))
(let (($x483 (and (distinct (bvadd ((_ sign_extend 1) ?x867) ((_ sign_extend 1) ?x547)) ((_ sign_extend 1) ?x873)) true)))
(let (($x1354 (or false false false)))
(let (($x777 (or $x1354 (ite $x582 false false))))
(let (($x1748 (or false false)))
(let (($x171 (or $x1748 $x777 (or $x483))))
(and (not $x171) (or $x171 (and (distinct ?x873 ?x873) true))))))))))))))
(check-sat)
; query 100: function matrix_sum, block 22, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x819 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x582 (= (_ bv1 1) ?x819)))
(let ((?x547 (ite $x582 (_ bv1 32) (_ bv0 32))))
(let ((?x867 ((_ sign_extend 16) in.1_16)))
(let ((?x873 (bvadd ?x867 ?x547)))
(let ((?x572 ((_ extract 15 0) ?x873)))
(let (($x483 (and (distinct (bvadd ((_ sign_extend 1) ?x867) ((_ sign_extend 1) ?x547)) ((_ sign_extend 1) ?x873)) true)))
(let (($x1354 (or false false false)))
(let (($x777 (or $x1354 (ite $x582 false false))))
(let (($x1748 (or false false)))
(let (($x171 (or $x1748 $x777 (or $x483))))
(let (($x767 (or $x171 false)))
(and (not $x767) (or $x767 (and (distinct ?x572 ?x572) true))))))))))))))))
(check-sat)
; query 101: function matrix_sum, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1354 (or false false false)))
(let (($x1948 (not $x1354)))
(and $x1948 (or $x1354 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 102: function matrix_sum, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x216 (bvadd in.01_32 (_ bv1 32))))
(let (($x479 (and (distinct ?x216 ?x216) true)))
(let (($x1354 (or false false false)))
(let (($x1948 (not $x1354)))
(and $x1948 (or $x1354 $x479)))))))
(check-sat)
; query 103: function parseval, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.23_32 () (_ BitVec 32))
(assert
 (let (($x1645 (and (distinct (bvmul ((_ sign_extend 32) in.23_32) ((_ sign_extend 32) (_ bv1024 32))) ((_ sign_extend 32) (bvmul in.23_32 (_ bv1024 32)))) true)))
(let (($x1329 (or false false (or $x1645))))
(and (not $x1329) (or $x1329 (and (distinct (bvmul in.23_32 (_ bv1024 32)) (bvmul in.23_32 (_ bv1024 32))) true))))))
(check-sat)
; query 104: function parseval, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.34_32 () (_ BitVec 32))
(assert
 (let (($x1328 (and (distinct (bvmul ((_ sign_extend 32) in.34_32) ((_ sign_extend 32) (_ bv1048576 32))) ((_ sign_extend 32) (bvmul in.34_32 (_ bv1048576 32)))) true)))
(let (($x1324 (or false false (or $x1328))))
(and (not $x1324) (or $x1324 (and (distinct (bvmul in.34_32 (_ bv1048576 32)) (bvmul in.34_32 (_ bv1048576 32))) true))))))
(check-sat)
; query 105: function partition_memory, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1354 (or false false false)))
(let (($x1948 (not $x1354)))
(and $x1948 (or $x1354 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
