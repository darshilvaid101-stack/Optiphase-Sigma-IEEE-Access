; OptiPhase-Sigma refinement certificate for sweep K06-R3-132
