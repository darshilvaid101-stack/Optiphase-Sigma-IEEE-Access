; OptiPhase-Sigma refinement certificate for sweep K48-R3-085
; query 0: function Decoding_of_the_coded_Log_Area_Ratios, block 107, name %108
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in104_64 () (_ BitVec 64))
(assert
 (let ((?x178 (ite (bvslt (_ bv0 64) in104_64) (_ bv1 1) (_ bv0 1))))
(let (($x21 (or false false false)))
(let (($x62 (not $x21)))
(and $x62 (or $x21 (and (distinct ?x178 ?x178) true)))))))
(check-sat)
; query 1: function Decoding_of_the_coded_Log_Area_Ratios, block 107, name %109
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in104_64 () (_ BitVec 64))
(assert
 (let (($x122 (and (distinct ((_ zero_extend 63) (ite (bvslt (_ bv0 64) in104_64) (_ bv1 1) (_ bv0 1))) (ite (= (_ bv1 1) (ite (bvslt (_ bv0 64) in104_64) (_ bv1 1) (_ bv0 1))) (_ bv32767 64) (_ bv18446744073709518848 64))) true)))
(let (($x21 (or false false false)))
(let (($x13 (or $x21 (ite (= (_ bv1 1) (ite (bvslt (_ bv0 64) in104_64) (_ bv1 1) (_ bv0 1))) false false))))
(and (not (or $x21 false)) (or $x13 $x122))))))
(check-sat)
; query 2: function Decoding_of_the_coded_Log_Area_Ratios, block 219, name %220
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in216_64 () (_ BitVec 64))
(assert
 (let (($x94 (and (distinct (ite (bvsge (_ bv18446744073709518848 64) in216_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv0 64) in216_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x21 (or false false false)))
(let (($x62 (not $x21)))
(and $x62 (or $x21 $x94))))))
(check-sat)
; query 3: function gsm_L_add, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let (($x57 (and (distinct (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv18446744073709551615 64) in1_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x21 (or false false false)))
(let (($x62 (not $x21)))
(and $x62 (or $x21 $x57))))))
(check-sat)
; query 4: function gsm_L_add, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x182 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvadd in0_64 in1_64))) true)))
(let (($x615 (or false false (or $x182))))
(let (($x31 (or $x615 (and (distinct (bvadd in0_64 in1_64) (bvadd in0_64 in1_64)) true))))
(and (not $x615) $x31)))))
(check-sat)
; query 5: function gsm_L_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x75 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x21 (or false false false)))
(let (($x62 (not $x21)))
(and $x62 (or $x21 (and (distinct ?x75 ?x75) true)))))))
(check-sat)
; query 6: function gsm_L_asl, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x140 (and (distinct (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvsgt (_ bv4294967265 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x21 (or false false false)))
(let (($x62 (not $x21)))
(and $x62 (or $x21 $x140))))))
(check-sat)
; query 7: function gsm_L_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x136 (and (distinct (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv31 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x21 (or false false false)))
(let (($x62 (not $x21)))
(and $x62 (or $x21 $x136))))))
(check-sat)
; query 8: function gsm_L_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x136 (and (distinct (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv31 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x21 (or false false false)))
(let (($x62 (not $x21)))
(and $x62 (or $x21 $x136))))))
(check-sat)
; query 9: function gsm_L_sub, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x101 (bvsub in0_64 in1_64)))
(let (($x64 (and (distinct ?x101 ?x101) true)))
(let (($x145 (and (distinct (bvsub ((_ zero_extend 1) in0_64) ((_ zero_extend 1) in1_64)) ((_ zero_extend 1) ?x101)) true)))
(let (($x32 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) ?x101)) true)))
(let (($x52 (or false false (or $x32))))
(let (($x575 (not $x52)))
(and $x575 (or (or false false (or $x145)) $x64)))))))))
(check-sat)
; query 10: function gsm_L_sub, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let (($x57 (and (distinct (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv18446744073709551615 64) in1_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x21 (or false false false)))
(let (($x62 (not $x21)))
(and $x62 (or $x21 $x57))))))
(check-sat)
; query 11: function gsm_L_sub, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x101 (bvsub in0_64 in1_64)))
(let (($x64 (and (distinct ?x101 ?x101) true)))
(let (($x32 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) ?x101)) true)))
(let (($x52 (or false false (or $x32))))
(let (($x575 (not $x52)))
(and $x575 (or $x52 $x64))))))))
(check-sat)
; query 12: function gsm_L_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x88 (and (distinct (ite (bvsle (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv18446744073709551615 64) in0_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x21 (or false false false)))
(let (($x62 (not $x21)))
(and $x62 (or $x21 $x88))))))
(check-sat)
; query 13: function gsm_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_64 () (_ BitVec 64))
(assert
 (let ((?x491 (ite (bvslt (_ bv32767 64) in5_64) (_ bv1 1) (_ bv0 1))))
(let (($x21 (or false false false)))
(let (($x62 (not $x21)))
(and $x62 (or $x21 (and (distinct ?x491 ?x491) true)))))))
(check-sat)
; query 14: function gsm_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x190 (or false false)))
(let (($x138 (not $x190)))
(and $x138 (or $x190 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 15: function gsm_add, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x190 (or false false)))
(let (($x138 (not $x190)))
(and $x138 (or $x190 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 16: function gsm_add, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x175 ((_ sign_extend 48) in1_16)))
(let ((?x671 ((_ sign_extend 48) in0_16)))
(let ((?x130 (bvadd ?x671 ?x175)))
(let (($x311 (and (distinct (bvadd ((_ sign_extend 1) ?x671) ((_ sign_extend 1) ?x175)) ((_ sign_extend 1) ?x130)) true)))
(let (($x190 (or false false)))
(let (($x134 (or $x190 $x190 (or $x311))))
(and (not $x134) (or $x134 (and (distinct ?x130 ?x130) true))))))))))
(check-sat)
; query 17: function gsm_add, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x163 (ite (bvsgt (_ bv18446744073709518848 64) (bvadd ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x175 ((_ sign_extend 48) in1_16)))
(let ((?x1055 ((_ sign_extend 1) ?x175)))
(let ((?x671 ((_ sign_extend 48) in0_16)))
(let ((?x106 ((_ sign_extend 1) ?x671)))
(let (($x190 (or false false)))
(let (($x134 (or $x190 $x190 (or (and (distinct (bvadd ?x106 ?x1055) ((_ sign_extend 1) (bvadd ?x671 ?x175))) true)))))
(let (($x42 (or $x134 false false)))
(and (not $x42) (or $x42 (and (distinct ?x163 ?x163) true))))))))))))
(check-sat)
; query 18: function gsm_asl, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x19 (and (distinct (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvsgt (_ bv4294967281 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x21 (or false false false)))
(let (($x62 (not $x21)))
(and $x62 (or $x21 $x19))))))
(check-sat)
; query 19: function gsm_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x120 (and (distinct (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv15 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x21 (or false false false)))
(let (($x62 (not $x21)))
(and $x62 (or $x21 $x120))))))
(check-sat)
; query 20: function gsm_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x120 (and (distinct (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv15 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x21 (or false false false)))
(let (($x62 (not $x21)))
(and $x62 (or $x21 $x120))))))
(check-sat)
; query 21: function gsm_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_64 () (_ BitVec 64))
(assert
 (let ((?x491 (ite (bvslt (_ bv32767 64) in5_64) (_ bv1 1) (_ bv0 1))))
(let (($x21 (or false false false)))
(let (($x62 (not $x21)))
(and $x62 (or $x21 (and (distinct ?x491 ?x491) true)))))))
(check-sat)
; query 22: function gsm_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x190 (or false false)))
(let (($x138 (not $x190)))
(and $x138 (or $x190 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 23: function gsm_sub, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x190 (or false false)))
(let (($x138 (not $x190)))
(and $x138 (or $x190 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 24: function gsm_sub, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x175 ((_ sign_extend 48) in1_16)))
(let ((?x671 ((_ sign_extend 48) in0_16)))
(let ((?x265 (bvsub ?x671 ?x175)))
(let (($x24 (and (distinct (bvsub ((_ sign_extend 1) ?x671) ((_ sign_extend 1) ?x175)) ((_ sign_extend 1) ?x265)) true)))
(let (($x190 (or false false)))
(let (($x216 (or $x190 $x190 (or $x24))))
(and (not $x216) (or $x216 (and (distinct ?x265 ?x265) true))))))))))
(check-sat)
; query 25: function gsm_sub, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x188 (ite (bvsgt (_ bv18446744073709518848 64) (bvsub ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x175 ((_ sign_extend 48) in1_16)))
(let ((?x1055 ((_ sign_extend 1) ?x175)))
(let ((?x671 ((_ sign_extend 48) in0_16)))
(let ((?x106 ((_ sign_extend 1) ?x671)))
(let (($x190 (or false false)))
(let (($x216 (or $x190 $x190 (or (and (distinct (bvsub ?x106 ?x1055) ((_ sign_extend 1) (bvsub ?x671 ?x175))) true)))))
(let (($x119 (or $x216 false false)))
(and (not $x119) (or $x119 (and (distinct ?x188 ?x188) true))))))))))))
(check-sat)
