; OptiPhase-Sigma refinement certificate for sweep K54-R6-049
; query 0: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x157 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x263 (or false false false)))
(let (($x1748 (not $x263)))
(and $x1748 (or $x263 (and (distinct ?x157 ?x157) true)))))))
(check-sat)
; query 1: function set1d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x274 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x263 (or false false false)))
(let (($x1748 (not $x263)))
(and $x1748 (or $x263 (and (distinct ?x274 ?x274) true)))))))
(check-sat)
; query 2: function set1ds, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x541 (ite (= (_ bv4294967295 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x263 (or false false false)))
(let (($x1748 (not $x263)))
(and $x1748 (or $x263 (and (distinct ?x541 ?x541) true)))))))
(check-sat)
; query 3: function set2d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x274 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x263 (or false false false)))
(let (($x1748 (not $x263)))
(and $x1748 (or $x263 (and (distinct ?x274 ?x274) true)))))))
(check-sat)
