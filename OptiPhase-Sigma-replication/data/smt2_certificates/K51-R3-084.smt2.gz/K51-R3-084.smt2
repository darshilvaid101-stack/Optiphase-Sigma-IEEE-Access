; OptiPhase-Sigma refinement certificate for sweep K51-R3-084
; query 0: function check, block 142, name %143
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x180 (and (distinct (ite (= (_ bv123 32) in0_32) (_ bv1 1) (_ bv0 1)) (ite (= (_ bv1122 32) in0_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x1968 (or false false false)))
(let (($x1655 (not $x1968)))
(and $x1655 (or $x1968 $x180))))))
(check-sat)
; query 1: function check, block 157, name %158
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x197 (and (distinct (ite (= (_ bv112233 32) in0_32) (_ bv1 1) (_ bv0 1)) (ite (= (_ bv111 32) in0_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x1968 (or false false false)))
(let (($x1655 (not $x1968)))
(and $x1655 (or $x1968 $x197))))))
(check-sat)
; query 2: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x1428 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x1968 (or false false false)))
(let (($x1655 (not $x1968)))
(and $x1655 (or $x1968 (and (distinct ?x1428 ?x1428) true)))))))
(check-sat)
; query 3: function set1d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x73 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x1968 (or false false false)))
(let (($x1655 (not $x1968)))
(and $x1655 (or $x1968 (and (distinct ?x73 ?x73) true)))))))
(check-sat)
; query 4: function set1ds, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x609 (ite (= (_ bv4294967295 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x1968 (or false false false)))
(let (($x1655 (not $x1968)))
(and $x1655 (or $x1968 (and (distinct ?x609 ?x609) true)))))))
(check-sat)
; query 5: function set2d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x73 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x1968 (or false false false)))
(let (($x1655 (not $x1968)))
(and $x1655 (or $x1968 (and (distinct ?x73 ?x73) true)))))))
(check-sat)
