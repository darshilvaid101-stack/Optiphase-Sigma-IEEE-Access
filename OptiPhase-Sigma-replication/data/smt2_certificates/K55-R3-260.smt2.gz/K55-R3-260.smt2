; OptiPhase-Sigma refinement certificate for sweep K55-R3-260
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x518 (or false false)))
(let (($x27 (not $x518)))
(and $x27 (or $x518 (and (distinct ((_ sign_extend 16) in25_16) ((_ sign_extend 16) in25_16)) true))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let ((?x591 (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))))
(let (($x518 (or false false)))
(let (($x257 (or $x518 false false)))
(let (($x54 (not $x257)))
(and $x54 (or $x257 (and (distinct ?x591 ?x591) true))))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x518 (or false false)))
(let (($x27 (not $x518)))
(and $x27 (or $x518 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x41 ((_ sign_extend 16) in3_16)))
(let ((?x410 (bvand ?x41 (_ bv127 32))))
(let (($x518 (or false false)))
(let (($x257 (or $x518 false false)))
(let (($x54 (not $x257)))
(and $x54 (or $x257 (and (distinct ?x410 ?x410) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x41 ((_ sign_extend 16) in3_16)))
(let ((?x410 (bvand ?x41 (_ bv127 32))))
(let ((?x553 ((_ extract 15 0) ?x410)))
(let (($x518 (or false false)))
(let (($x257 (or $x518 false false)))
(let (($x1391 (or $x257 false)))
(let (($x175 (not $x1391)))
(and $x175 (or $x1391 (and (distinct ?x553 ?x553) true)))))))))))
(check-sat)
; query 5: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x518 (or false false)))
(let (($x27 (not $x518)))
(and $x27 (or $x518 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 6: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x330 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x518 (or false false)))
(let (($x257 (or $x518 false false)))
(let (($x54 (not $x257)))
(and $x54 (or $x257 (and (distinct ?x330 ?x330) true))))))))
(check-sat)
; query 7: function core_bench_list, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x49 (or false false false)))
(let (($x52 (not $x49)))
(and $x52 (or $x49 (and (distinct (bvadd in.0_16 (_ bv1 16)) (bvadd in.0_16 (_ bv1 16))) true))))))
(check-sat)
; query 8: function core_bench_state, block 105, name %106
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x49 (or false false false)))
(let (($x52 (not $x49)))
(and $x52 (or $x49 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 9: function core_bench_state, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x49 (or false false false)))
(let (($x52 (not $x49)))
(and $x52 (or $x49 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 10: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x62 (bvadd in.01_32 (_ bv1 32))))
(let (($x98 (and (distinct ?x62 ?x62) true)))
(let (($x49 (or false false false)))
(let (($x52 (not $x49)))
(and $x52 (or $x49 $x98)))))))
(check-sat)
; query 11: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x62 (bvadd in.01_32 (_ bv1 32))))
(let ((?x953 (bvmul ?x62 (_ bv8 32))))
(let ((?x539 (bvmul ?x62 ?x62)))
(let (($x49 (or false false false)))
(let (($x500 (or $x49 false false)))
(and (not (or $x49 $x49 false)) (or $x500 (and (distinct ?x539 ?x953) true)))))))))
(check-sat)
; query 12: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x38 (and (distinct (bvmul (bvmul (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) (_ bv2 32)) (bvmul (bvmul (bvadd in.01_32 (_ bv1 32)) (_ bv8 32)) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x49 (or false false false)))
(let (($x500 (or $x49 false false)))
(and (not (or (or $x49 $x49 false) false false)) (or (or $x500 $x49 false) $x38))))))
(check-sat)
; query 13: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x15 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x49 (or false false false)))
(let (($x52 (not $x49)))
(and $x52 (or $x49 (and (distinct ?x15 ?x15) true)))))))
(check-sat)
; query 14: function core_init_state, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_32 () (_ BitVec 32))
(assert
 (let (($x49 (or false false false)))
(let (($x52 (not $x49)))
(and $x52 (or $x49 (and (distinct (bvadd in.06_32 (_ bv1 32)) (bvadd in.06_32 (_ bv1 32))) true))))))
(check-sat)
; query 15: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x99 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x49 (or false false false)))
(let (($x52 (not $x49)))
(and $x52 (or $x49 (and (distinct ?x99 ?x99) true)))))))
(check-sat)
; query 16: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x49 (or false false false)))
(let (($x52 (not $x49)))
(and $x52 (or $x49 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 17: function core_list_init, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x62 (bvadd in.01_32 (_ bv1 32))))
(let (($x98 (and (distinct ?x62 ?x62) true)))
(let (($x49 (or false false false)))
(let (($x52 (not $x49)))
(and $x52 (or $x49 $x98)))))))
(check-sat)
; query 18: function core_list_mergesort, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x62 (bvadd in.01_32 (_ bv1 32))))
(let (($x98 (and (distinct ?x62 ?x62) true)))
(let (($x108 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x62)) true)))
(let (($x512 (or false false (or $x108))))
(and (not $x512) (or $x512 $x98)))))))
(check-sat)
; query 19: function core_list_mergesort, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x124 (ite (bvslt (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x49 (or false false false)))
(let (($x52 (not $x49)))
(and $x52 (or $x49 (and (distinct ?x124 ?x124) true)))))))
(check-sat)
; query 20: function core_list_mergesort, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.224_32 () (_ BitVec 32))
(assert
 (let ((?x587 (ite (= (_ bv0 32) in.224_32) (_ bv1 1) (_ bv0 1))))
(let (($x49 (or false false false)))
(let (($x52 (not $x49)))
(and $x52 (or $x49 (and (distinct ?x587 ?x587) true)))))))
(check-sat)
; query 21: function core_list_mergesort, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x170 (ite (= (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x49 (or false false false)))
(let (($x52 (not $x49)))
(and $x52 (or $x49 (and (distinct ?x170 ?x170) true)))))))
(check-sat)
; query 22: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x45 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x528 (or false false (or $x45))))
(and (not $x528) (or $x528 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 23: function core_list_mergesort, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x256 (and (distinct (bvmul ((_ sign_extend 32) in.020_32) ((_ sign_extend 32) (_ bv2 32))) ((_ sign_extend 32) (bvmul in.020_32 (_ bv2 32)))) true)))
(let (($x251 (or false false (or $x256))))
(and (not $x251) (or $x251 (and (distinct (bvmul in.020_32 (_ bv2 32)) (bvmul in.020_32 (_ bv2 32))) true))))))
(check-sat)
; query 24: function core_state_transition, block 102, name %103
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x518 (or false false)))
(let (($x27 (not $x518)))
(and $x27 (or $x518 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 25: function core_state_transition, block 102, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1403 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x518 (or false false)))
(let (($x257 (or $x518 false false)))
(let (($x54 (not $x257)))
(and $x54 (or $x257 (and (distinct ?x1403 ?x1403) true))))))))
(check-sat)
; query 26: function core_state_transition, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x518 (or false false)))
(let (($x27 (not $x518)))
(and $x27 (or $x518 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 27: function core_state_transition, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x479 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x518 (or false false)))
(let (($x257 (or $x518 false false)))
(let (($x54 (not $x257)))
(and $x54 (or $x257 (and (distinct ?x479 ?x479) true))))))))
(check-sat)
; query 28: function core_state_transition, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x518 (or false false)))
(let (($x27 (not $x518)))
(and $x27 (or $x518 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 29: function core_state_transition, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1403 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x518 (or false false)))
(let (($x257 (or $x518 false false)))
(let (($x54 (not $x257)))
(and $x54 (or $x257 (and (distinct ?x1403 ?x1403) true))))))))
(check-sat)
; query 30: function core_state_transition, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x518 (or false false)))
(let (($x27 (not $x518)))
(and $x27 (or $x518 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 31: function core_state_transition, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x227 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x518 (or false false)))
(let (($x257 (or $x518 false false)))
(let (($x54 (not $x257)))
(and $x54 (or $x257 (and (distinct ?x227 ?x227) true))))))))
(check-sat)
; query 32: function core_state_transition, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x518 (or false false)))
(let (($x27 (not $x518)))
(and $x27 (or $x518 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 33: function core_state_transition, block 51, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x227 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x518 (or false false)))
(let (($x257 (or $x518 false false)))
(let (($x54 (not $x257)))
(and $x54 (or $x257 (and (distinct ?x227 ?x227) true))))))))
(check-sat)
; query 34: function core_state_transition, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x518 (or false false)))
(let (($x27 (not $x518)))
(and $x27 (or $x518 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 35: function core_state_transition, block 64, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x227 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x518 (or false false)))
(let (($x257 (or $x518 false false)))
(let (($x54 (not $x257)))
(and $x54 (or $x257 (and (distinct ?x227 ?x227) true))))))))
(check-sat)
; query 36: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x33 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x49 (or false false false)))
(let (($x52 (not $x49)))
(and $x52 (or $x49 (and (distinct ?x33 ?x33) true)))))))
(check-sat)
; query 37: function core_state_transition, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x518 (or false false)))
(let (($x27 (not $x518)))
(and $x27 (or $x518 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 38: function core_state_transition, block 80, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x88 (ite (= (_ bv69 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x518 (or false false)))
(let (($x257 (or $x518 false false)))
(let (($x54 (not $x257)))
(and $x54 (or $x257 (and (distinct ?x88 ?x88) true))))))))
(check-sat)
; query 39: function core_state_transition, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x518 (or false false)))
(let (($x27 (not $x518)))
(and $x27 (or $x518 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 40: function core_state_transition, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x115 (ite (= (_ bv101 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x518 (or false false)))
(let (($x257 (or $x518 false false)))
(let (($x54 (not $x257)))
(and $x54 (or $x257 (and (distinct ?x115 ?x115) true))))))))
(check-sat)
; query 41: function core_state_transition, block 99, name %100
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x518 (or false false)))
(let (($x27 (not $x518)))
(and $x27 (or $x518 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 42: function core_state_transition, block 99, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x479 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x518 (or false false)))
(let (($x257 (or $x518 false false)))
(let (($x54 (not $x257)))
(and $x54 (or $x257 (and (distinct ?x479 ?x479) true))))))))
(check-sat)
; query 43: function crcu8, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x518 (or false false)))
(let (($x27 (not $x518)))
(and $x27 (or $x518 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 44: function crcu8, block 19, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x106 ((_ zero_extend 16) in.01_16)))
(let ((?x865 (bvxor ?x106 (_ bv16386 32))))
(let (($x518 (or false false)))
(let (($x257 (or $x518 false false)))
(let (($x54 (not $x257)))
(and $x54 (or $x257 (and (distinct ?x865 ?x865) true)))))))))
(check-sat)
; query 45: function crcu8, block 19, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x106 ((_ zero_extend 16) in.01_16)))
(let ((?x865 (bvxor ?x106 (_ bv16386 32))))
(let ((?x190 ((_ extract 15 0) ?x865)))
(let (($x518 (or false false)))
(let (($x257 (or $x518 false false)))
(let (($x1391 (or $x257 false)))
(let (($x175 (not $x1391)))
(and $x175 (or $x1391 (and (distinct ?x190 ?x190) true)))))))))))
(check-sat)
; query 46: function crcu8, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x518 (or false false)))
(let (($x27 (not $x518)))
(and $x27 (or $x518 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 47: function crcu8, block 29, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1328 ((_ zero_extend 16) in27_16)))
(let ((?x1333 (bvor ?x1328 (_ bv32768 32))))
(let (($x518 (or false false)))
(let (($x257 (or $x518 false false)))
(let (($x54 (not $x257)))
(and $x54 (or $x257 (and (distinct ?x1333 ?x1333) true)))))))))
(check-sat)
; query 48: function crcu8, block 29, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1328 ((_ zero_extend 16) in27_16)))
(let ((?x1333 (bvor ?x1328 (_ bv32768 32))))
(let ((?x1339 ((_ extract 15 0) ?x1333)))
(let (($x518 (or false false)))
(let (($x257 (or $x518 false false)))
(let (($x1391 (or $x257 false)))
(let (($x175 (not $x1391)))
(and $x175 (or $x1391 (and (distinct ?x1339 ?x1339) true)))))))))))
(check-sat)
; query 49: function crcu8, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x518 (or false false)))
(let (($x27 (not $x518)))
(and $x27 (or $x518 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 50: function crcu8, block 33, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1328 ((_ zero_extend 16) in27_16)))
(let ((?x451 (bvand ?x1328 (_ bv32767 32))))
(let (($x518 (or false false)))
(let (($x257 (or $x518 false false)))
(let (($x54 (not $x257)))
(and $x54 (or $x257 (and (distinct ?x451 ?x451) true)))))))))
(check-sat)
; query 51: function crcu8, block 33, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1328 ((_ zero_extend 16) in27_16)))
(let ((?x451 (bvand ?x1328 (_ bv32767 32))))
(let ((?x1091 ((_ extract 15 0) ?x451)))
(let (($x518 (or false false)))
(let (($x257 (or $x518 false false)))
(let (($x1391 (or $x257 false)))
(let (($x175 (not $x1391)))
(and $x175 (or $x1391 (and (distinct ?x1091 ?x1091) true)))))))))))
(check-sat)
; query 52: function crcu8, block 38, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_8 () (_ BitVec 8))
(assert
 (let (($x49 (or false false false)))
(let (($x52 (not $x49)))
(and $x52 (or $x49 (and (distinct (bvadd in.02_8 (_ bv1 8)) (bvadd in.02_8 (_ bv1 8))) true))))))
(check-sat)
; query 53: function crcu8, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x70 ((_ extract 7 0) in.01_16)))
(let ((?x1383 ((_ zero_extend 24) ?x70)))
(let (($x518 (or false false)))
(let (($x1270 (or $x518 false)))
(and (not $x1270) (or $x1270 (and (distinct ?x1383 ?x1383) true))))))))
(check-sat)
; query 54: function crcu8, block 6, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x70 ((_ extract 7 0) in.01_16)))
(let ((?x1383 ((_ zero_extend 24) ?x70)))
(let ((?x527 (bvand ?x1383 (_ bv1 32))))
(let (($x518 (or false false)))
(let (($x1270 (or $x518 false)))
(let (($x1097 (or $x1270 false false)))
(and (not $x1097) (or $x1097 (and (distinct ?x527 ?x527) true))))))))))
(check-sat)
; query 55: function crcu8, block 6, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x70 ((_ extract 7 0) in.01_16)))
(let ((?x1383 ((_ zero_extend 24) ?x70)))
(let ((?x527 (bvand ?x1383 (_ bv1 32))))
(let ((?x1370 ((_ zero_extend 24) in.0_8)))
(let ((?x1268 (bvand ?x1370 (_ bv1 32))))
(let ((?x1404 (bvxor ?x1268 ?x527)))
(let (($x518 (or false false)))
(let (($x1270 (or $x518 false)))
(let (($x1097 (or $x1270 false false)))
(let (($x257 (or $x518 false false)))
(let (($x1408 (or $x257 $x1097 false)))
(and (not $x1408) (or $x1408 (and (distinct ?x1404 ?x1404) true)))))))))))))))
(check-sat)
; query 56: function crcu8, block 6, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x70 ((_ extract 7 0) in.01_16)))
(let ((?x1383 ((_ zero_extend 24) ?x70)))
(let ((?x527 (bvand ?x1383 (_ bv1 32))))
(let ((?x1370 ((_ zero_extend 24) in.0_8)))
(let ((?x1268 (bvand ?x1370 (_ bv1 32))))
(let ((?x1404 (bvxor ?x1268 ?x527)))
(let ((?x36 ((_ extract 7 0) ?x1404)))
(let (($x518 (or false false)))
(let (($x1270 (or $x518 false)))
(let (($x1097 (or $x1270 false false)))
(let (($x257 (or $x518 false false)))
(let (($x1408 (or $x257 $x1097 false)))
(let (($x554 (or $x1408 false)))
(and (not $x554) (or $x554 (and (distinct ?x36 ?x36) true)))))))))))))))))
(check-sat)
; query 57: function crcu8, block 6, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x518 (or false false)))
(let (($x27 (not $x518)))
(and $x27 (or $x518 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 58: function crcu8, block 6, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1370 ((_ zero_extend 24) in.0_8)))
(let ((?x58 (bvashr ?x1370 (_ bv1 32))))
(let (($x518 (or false false)))
(let (($x257 (or $x518 false false)))
(let (($x145 (or $x257 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not $x145) (or $x145 (and (distinct ?x58 ?x58) true)))))))))
(check-sat)
; query 59: function crcu8, block 6, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1370 ((_ zero_extend 24) in.0_8)))
(let ((?x58 (bvashr ?x1370 (_ bv1 32))))
(let ((?x1369 ((_ extract 7 0) ?x58)))
(let (($x518 (or false false)))
(let (($x257 (or $x518 false false)))
(let (($x145 (or $x257 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x1318 (or $x145 false)))
(and (not $x1318) (or $x1318 (and (distinct ?x1369 ?x1369) true)))))))))))
(check-sat)
; query 60: function crcu8, block 6, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x70 ((_ extract 7 0) in.01_16)))
(let ((?x1383 ((_ zero_extend 24) ?x70)))
(let ((?x527 (bvand ?x1383 (_ bv1 32))))
(let ((?x1370 ((_ zero_extend 24) in.0_8)))
(let ((?x1268 (bvand ?x1370 (_ bv1 32))))
(let ((?x1404 (bvxor ?x1268 ?x527)))
(let ((?x36 ((_ extract 7 0) ?x1404)))
(let ((?x1323 ((_ zero_extend 24) ?x36)))
(let (($x518 (or false false)))
(let (($x1270 (or $x518 false)))
(let (($x1097 (or $x1270 false false)))
(let (($x257 (or $x518 false false)))
(let (($x1408 (or $x257 $x1097 false)))
(let (($x554 (or $x1408 false)))
(let (($x205 (or $x554 false)))
(and (not $x205) (or $x205 (and (distinct ?x1323 ?x1323) true)))))))))))))))))))
(check-sat)
; query 61: function crcu8, block 6, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x70 ((_ extract 7 0) in.01_16)))
(let ((?x1383 ((_ zero_extend 24) ?x70)))
(let ((?x527 (bvand ?x1383 (_ bv1 32))))
(let ((?x1370 ((_ zero_extend 24) in.0_8)))
(let ((?x1268 (bvand ?x1370 (_ bv1 32))))
(let ((?x1404 (bvxor ?x1268 ?x527)))
(let ((?x36 ((_ extract 7 0) ?x1404)))
(let ((?x1323 ((_ zero_extend 24) ?x36)))
(let ((?x1306 (ite (= (_ bv1 32) ?x1323) (_ bv1 1) (_ bv0 1))))
(let (($x518 (or false false)))
(let (($x1270 (or $x518 false)))
(let (($x1097 (or $x1270 false false)))
(let (($x257 (or $x518 false false)))
(let (($x1408 (or $x257 $x1097 false)))
(let (($x554 (or $x1408 false)))
(let (($x205 (or $x554 false)))
(let (($x1396 (or $x205 false false)))
(and (not $x1396) (or $x1396 (and (distinct ?x1306 ?x1306) true)))))))))))))))))))))
(check-sat)
; query 62: function crcu8, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x518 (or false false)))
(let (($x27 (not $x518)))
(and $x27 (or $x518 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 63: function crcu8, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1370 ((_ zero_extend 24) in.0_8)))
(let ((?x1268 (bvand ?x1370 (_ bv1 32))))
(let (($x518 (or false false)))
(let (($x257 (or $x518 false false)))
(let (($x54 (not $x257)))
(and $x54 (or $x257 (and (distinct ?x1268 ?x1268) true)))))))))
(check-sat)
; query 64: function crcu8, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x518 (or false false)))
(let (($x27 (not $x518)))
(and $x27 (or $x518 (and (distinct ((_ extract 7 0) in.01_16) ((_ extract 7 0) in.01_16)) true))))))
(check-sat)
; query 65: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x929 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x49 (or false false false)))
(let (($x52 (not $x49)))
(and $x52 (or $x49 (and (distinct ?x929 ?x929) true)))))))
(check-sat)
; query 66: function matrix_add_const, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x49 (or false false false)))
(let (($x52 (not $x49)))
(and $x52 (or $x49 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 67: function matrix_add_const, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x62 (bvadd in.01_32 (_ bv1 32))))
(let (($x98 (and (distinct ?x62 ?x62) true)))
(let (($x49 (or false false false)))
(let (($x52 (not $x49)))
(and $x52 (or $x49 $x98)))))))
(check-sat)
; query 68: function matrix_mul_const, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x49 (or false false false)))
(let (($x52 (not $x49)))
(and $x52 (or $x49 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 69: function matrix_mul_const, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x62 (bvadd in.01_32 (_ bv1 32))))
(let (($x98 (and (distinct ?x62 ?x62) true)))
(let (($x49 (or false false false)))
(let (($x52 (not $x49)))
(and $x52 (or $x49 $x98)))))))
(check-sat)
; query 70: function matrix_mul_matrix, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x49 (or false false false)))
(let (($x52 (not $x49)))
(and $x52 (or $x49 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 71: function matrix_mul_matrix, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x62 (bvadd in.01_32 (_ bv1 32))))
(let (($x98 (and (distinct ?x62 ?x62) true)))
(let (($x49 (or false false false)))
(let (($x52 (not $x49)))
(and $x52 (or $x49 $x98)))))))
(check-sat)
; query 72: function matrix_mul_matrix, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x49 (or false false false)))
(let (($x52 (not $x49)))
(and $x52 (or $x49 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 73: function matrix_mul_matrix_bitextract, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x49 (or false false false)))
(let (($x52 (not $x49)))
(and $x52 (or $x49 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 74: function matrix_mul_matrix_bitextract, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x62 (bvadd in.01_32 (_ bv1 32))))
(let (($x98 (and (distinct ?x62 ?x62) true)))
(let (($x49 (or false false false)))
(let (($x52 (not $x49)))
(and $x52 (or $x49 $x98)))))))
(check-sat)
; query 75: function matrix_mul_matrix_bitextract, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x49 (or false false false)))
(let (($x52 (not $x49)))
(and $x52 (or $x49 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 76: function matrix_mul_vect, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x49 (or false false false)))
(let (($x52 (not $x49)))
(and $x52 (or $x49 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 77: function matrix_mul_vect, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x62 (bvadd in.01_32 (_ bv1 32))))
(let (($x98 (and (distinct ?x62 ?x62) true)))
(let (($x49 (or false false false)))
(let (($x52 (not $x49)))
(and $x52 (or $x49 $x98)))))))
(check-sat)
; query 78: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x518 (or false false)))
(let (($x27 (not $x518)))
(and $x27 (or $x518 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 79: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x1152 ((_ sign_extend 16) in.1_16)))
(let ((?x1216 (bvadd ?x1152 (_ bv10 32))))
(let (($x1264 (and (distinct (bvadd ((_ sign_extend 1) ?x1152) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x1216)) true)))
(let (($x518 (or false false)))
(let (($x430 (or $x518 false (or $x1264))))
(and (not $x430) (or $x430 (and (distinct ?x1216 ?x1216) true)))))))))
(check-sat)
; query 80: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x1152 ((_ sign_extend 16) in.1_16)))
(let ((?x1216 (bvadd ?x1152 (_ bv10 32))))
(let ((?x783 ((_ extract 15 0) ?x1216)))
(let (($x1264 (and (distinct (bvadd ((_ sign_extend 1) ?x1152) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x1216)) true)))
(let (($x518 (or false false)))
(let (($x430 (or $x518 false (or $x1264))))
(let (($x1011 (or $x430 false)))
(and (not $x1011) (or $x1011 (and (distinct ?x783 ?x783) true)))))))))))
(check-sat)
; query 81: function partition_memory, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x49 (or false false false)))
(let (($x52 (not $x49)))
(and $x52 (or $x49 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
