; OptiPhase-Sigma refinement certificate for sweep K46-R3-116
; query 0: function adpcm_decoder, block 61, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.210_32 () (_ BitVec 32))
(declare-fun in.013_32 () (_ BitVec 32))
(assert
 (let ((?x30 (bvadd in.013_32 in.210_32)))
(let ((?x86 (bvsub in.013_32 in.210_32)))
(let (($x29 (and (distinct (bvadd ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x30)) true)))
(let (($x467 (and (distinct (bvsub ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x86)) true)))
(and (not (or false false (or $x467))) (or (or false false (or $x29)) (and (distinct ?x86 ?x30) true))))))))
(check-sat)
; query 1: function main, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x555 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x84 (or false false false)))
(and (not $x84) (or $x84 (and (distinct ?x555 ?x555) true))))))
(check-sat)
