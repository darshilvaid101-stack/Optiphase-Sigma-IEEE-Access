; OptiPhase-Sigma refinement certificate for sweep K53-R1-003
