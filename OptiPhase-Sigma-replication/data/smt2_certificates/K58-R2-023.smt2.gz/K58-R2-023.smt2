; OptiPhase-Sigma refinement certificate for sweep K58-R2-023
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x235 (or false (or (= ((_ extract 15 15) in25_16) (_ bv1 1))))))
(let (($x53 (or false false)))
(let (($x219 (not $x53)))
(and $x219 (or $x235 (and (distinct ((_ sign_extend 16) in25_16) ((_ zero_extend 16) in25_16)) true)))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x1140 (and (distinct (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1)) (ite (bvult ((_ zero_extend 16) in25_16) (_ bv34 32)) (_ bv1 1) (_ bv0 1))) true)))
(let (($x235 (or false (or (= ((_ extract 15 15) in25_16) (_ bv1 1))))))
(let (($x5 (or $x235 false (and (distinct ((_ extract 31 31) ((_ zero_extend 16) in25_16)) ((_ extract 31 31) (_ bv34 32))) true))))
(let (($x53 (or false false)))
(let (($x108 (or $x53 false false)))
(let (($x510 (not $x108)))
(and $x510 (or $x5 $x1140)))))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x53 (or false false)))
(let (($x219 (not $x53)))
(and $x219 (or $x53 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x726 ((_ sign_extend 16) in3_16)))
(let ((?x1136 (bvand ?x726 (_ bv127 32))))
(let (($x53 (or false false)))
(let (($x108 (or $x53 false false)))
(let (($x510 (not $x108)))
(and $x510 (or $x108 (and (distinct ?x1136 ?x1136) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x726 ((_ sign_extend 16) in3_16)))
(let ((?x1136 (bvand ?x726 (_ bv127 32))))
(let ((?x137 ((_ extract 15 0) ?x1136)))
(let (($x205 (or (and (distinct ((_ zero_extend 16) ?x137) ?x1136) true) (and (distinct ((_ sign_extend 16) ?x137) ?x1136) true))))
(let (($x53 (or false false)))
(let (($x108 (or $x53 false false)))
(let (($x1097 (or $x108 false)))
(let (($x49 (not $x1097)))
(and $x49 (or (or $x108 $x205) (and (distinct ?x137 ?x137) true))))))))))))
(check-sat)
; query 5: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x490 (or (or false (or (= ((_ extract 7 7) (_ bv0 8)) (_ bv1 1)))) (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))
(let (($x53 (or false false)))
(let (($x219 (not $x53)))
(and $x219 $x490)))))
(check-sat)
; query 6: function core_bench_list, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x564 (or false false false)))
(let (($x105 (not $x564)))
(and $x105 (or $x564 (and (distinct (bvadd in.0_16 (_ bv1 16)) (bvadd in.0_16 (_ bv1 16))) true))))))
(check-sat)
; query 7: function core_bench_state, block 105, name %106
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let ((?x195 (bvadd in.1_32 (_ bv1 32))))
(let (($x128 (and (distinct ?x195 ?x195) true)))
(let (($x298 (and (distinct (bvadd ((_ zero_extend 1) in.1_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) ?x195)) true)))
(let (($x547 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x195)) true)))
(let (($x564 (or false false false)))
(let (($x105 (not $x564)))
(and $x105 (or (or false false (or $x547 $x298)) $x128)))))))))
(check-sat)
; query 8: function core_bench_state, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x389 (bvadd in.0_32 (_ bv1 32))))
(let (($x462 (and (distinct ?x389 ?x389) true)))
(let (($x1375 (and (distinct (bvadd ((_ zero_extend 1) in.0_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) ?x389)) true)))
(let (($x37 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x389)) true)))
(let (($x564 (or false false false)))
(let (($x105 (not $x564)))
(and $x105 (or (or false false (or $x37 $x1375)) $x462)))))))))
(check-sat)
; query 9: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1336 (bvadd in.01_32 (_ bv1 32))))
(let (($x516 (and (distinct ?x1336 ?x1336) true)))
(let (($x564 (or false false false)))
(let (($x105 (not $x564)))
(and $x105 (or $x564 $x516)))))))
(check-sat)
; query 10: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1336 (bvadd in.01_32 (_ bv1 32))))
(let ((?x1376 (bvmul ?x1336 ?x1336)))
(let (($x564 (or false false false)))
(let (($x1311 (or $x564 $x564 false)))
(and (not $x1311) (or $x1311 (and (distinct ?x1376 ?x1376) true))))))))
(check-sat)
; query 11: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1336 (bvadd in.01_32 (_ bv1 32))))
(let ((?x1376 (bvmul ?x1336 ?x1336)))
(let ((?x122 (bvmul ?x1376 (_ bv2 32))))
(let (($x564 (or false false false)))
(let (($x1311 (or $x564 $x564 false)))
(let (($x1335 (or $x1311 false false)))
(and (not $x1335) (or $x1335 (and (distinct ?x122 ?x122) true))))))))))
(check-sat)
; query 12: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1336 (bvadd in.01_32 (_ bv1 32))))
(let ((?x1376 (bvmul ?x1336 ?x1336)))
(let ((?x122 (bvmul ?x1376 (_ bv2 32))))
(let ((?x765 (bvmul ?x122 (_ bv4 32))))
(let (($x564 (or false false false)))
(let (($x1311 (or $x564 $x564 false)))
(let (($x1335 (or $x1311 false false)))
(let (($x55 (or $x1335 false false)))
(and (not $x55) (or $x55 (and (distinct ?x765 ?x765) true))))))))))))
(check-sat)
; query 13: function core_init_matrix, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let ((?x195 (bvadd in.1_32 (_ bv1 32))))
(let (($x128 (and (distinct ?x195 ?x195) true)))
(let (($x298 (and (distinct (bvadd ((_ zero_extend 1) in.1_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) ?x195)) true)))
(let (($x564 (or false false false)))
(let (($x105 (not $x564)))
(and $x105 (or (or false false (or $x298)) $x128))))))))
(check-sat)
; query 14: function core_init_matrix, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x564 (or false false false)))
(let (($x105 (not $x564)))
(and $x105 (or $x564 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 15: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x123 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x564 (or false false false)))
(let (($x105 (not $x564)))
(and $x105 (or $x564 (and (distinct ?x123 ?x123) true)))))))
(check-sat)
; query 16: function core_init_state, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_32 () (_ BitVec 32))
(assert
 (let (($x136 (and (distinct (bvadd ((_ zero_extend 1) in.06_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.06_32 (_ bv1 32)))) true)))
(let (($x94 (or (or false false (or $x136)) (and (distinct (bvadd in.06_32 (_ bv1 32)) (bvadd in.06_32 (_ bv1 32))) true))))
(let (($x564 (or false false false)))
(let (($x105 (not $x564)))
(and $x105 $x94))))))
(check-sat)
; query 17: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x35 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x564 (or false false false)))
(let (($x105 (not $x564)))
(and $x105 (or $x564 (and (distinct ?x35 ?x35) true)))))))
(check-sat)
; query 18: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x564 (or false false false)))
(let (($x105 (not $x564)))
(and $x105 (or $x564 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 19: function core_list_init, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1336 (bvadd in.01_32 (_ bv1 32))))
(let (($x516 (and (distinct ?x1336 ?x1336) true)))
(let (($x124 (and (distinct (bvadd ((_ zero_extend 1) in.01_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) ?x1336)) true)))
(let (($x564 (or false false false)))
(let (($x105 (not $x564)))
(and $x105 (or (or false false (or $x124)) $x516))))))))
(check-sat)
; query 20: function core_list_mergesort, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1336 (bvadd in.01_32 (_ bv1 32))))
(let (($x516 (and (distinct ?x1336 ?x1336) true)))
(let (($x9 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x1336)) true)))
(let (($x20 (or false false (or $x9))))
(and (not $x20) (or $x20 $x516)))))))
(check-sat)
; query 21: function core_list_mergesort, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x161 (ite (bvslt (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x564 (or false false false)))
(let (($x105 (not $x564)))
(and $x105 (or $x564 (and (distinct ?x161 ?x161) true)))))))
(check-sat)
; query 22: function core_list_mergesort, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.224_32 () (_ BitVec 32))
(assert
 (let ((?x256 (ite (= (_ bv0 32) in.224_32) (_ bv1 1) (_ bv0 1))))
(let (($x564 (or false false false)))
(let (($x105 (not $x564)))
(and $x105 (or $x564 (and (distinct ?x256 ?x256) true)))))))
(check-sat)
; query 23: function core_list_mergesort, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x1302 (ite (= (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x564 (or false false false)))
(let (($x105 (not $x564)))
(and $x105 (or $x564 (and (distinct ?x1302 ?x1302) true)))))))
(check-sat)
; query 24: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x720 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x244 (or false false (or $x720))))
(and (not $x244) (or $x244 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 25: function core_list_mergesort, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x1313 (and (distinct (bvmul ((_ sign_extend 32) in.020_32) ((_ sign_extend 32) (_ bv2 32))) ((_ sign_extend 32) (bvmul in.020_32 (_ bv2 32)))) true)))
(let (($x240 (or false false (or $x1313))))
(and (not $x240) (or $x240 (and (distinct (bvmul in.020_32 (_ bv2 32)) (bvmul in.020_32 (_ bv2 32))) true))))))
(check-sat)
; query 26: function core_state_transition, block 102, name %103
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x53 (or false false)))
(let (($x219 (not $x53)))
(and $x219 (or $x53 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 27: function core_state_transition, block 102, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x132 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x53 (or false false)))
(let (($x108 (or $x53 false false)))
(let (($x510 (not $x108)))
(and $x510 (or $x108 (and (distinct ?x132 ?x132) true))))))))
(check-sat)
; query 28: function core_state_transition, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x53 (or false false)))
(let (($x219 (not $x53)))
(and $x219 (or $x53 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 29: function core_state_transition, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x692 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x53 (or false false)))
(let (($x108 (or $x53 false false)))
(let (($x510 (not $x108)))
(and $x510 (or $x108 (and (distinct ?x692 ?x692) true))))))))
(check-sat)
; query 30: function core_state_transition, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x53 (or false false)))
(let (($x219 (not $x53)))
(and $x219 (or $x53 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 31: function core_state_transition, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x132 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x53 (or false false)))
(let (($x108 (or $x53 false false)))
(let (($x510 (not $x108)))
(and $x510 (or $x108 (and (distinct ?x132 ?x132) true))))))))
(check-sat)
; query 32: function core_state_transition, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x53 (or false false)))
(let (($x219 (not $x53)))
(and $x219 (or $x53 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 33: function core_state_transition, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x814 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x53 (or false false)))
(let (($x108 (or $x53 false false)))
(let (($x510 (not $x108)))
(and $x510 (or $x108 (and (distinct ?x814 ?x814) true))))))))
(check-sat)
; query 34: function core_state_transition, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x53 (or false false)))
(let (($x219 (not $x53)))
(and $x219 (or $x53 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 35: function core_state_transition, block 51, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x814 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x53 (or false false)))
(let (($x108 (or $x53 false false)))
(let (($x510 (not $x108)))
(and $x510 (or $x108 (and (distinct ?x814 ?x814) true))))))))
(check-sat)
; query 36: function core_state_transition, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x53 (or false false)))
(let (($x219 (not $x53)))
(and $x219 (or $x53 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 37: function core_state_transition, block 64, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x814 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x53 (or false false)))
(let (($x108 (or $x53 false false)))
(let (($x510 (not $x108)))
(and $x510 (or $x108 (and (distinct ?x814 ?x814) true))))))))
(check-sat)
; query 38: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x267 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x564 (or false false false)))
(let (($x105 (not $x564)))
(and $x105 (or $x564 (and (distinct ?x267 ?x267) true)))))))
(check-sat)
; query 39: function core_state_transition, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x53 (or false false)))
(let (($x219 (not $x53)))
(and $x219 (or $x53 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 40: function core_state_transition, block 80, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1388 (ite (= (_ bv69 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x53 (or false false)))
(let (($x108 (or $x53 false false)))
(let (($x510 (not $x108)))
(and $x510 (or $x108 (and (distinct ?x1388 ?x1388) true))))))))
(check-sat)
; query 41: function core_state_transition, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x53 (or false false)))
(let (($x219 (not $x53)))
(and $x219 (or $x53 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 42: function core_state_transition, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1342 (ite (= (_ bv101 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x53 (or false false)))
(let (($x108 (or $x53 false false)))
(let (($x510 (not $x108)))
(and $x510 (or $x108 (and (distinct ?x1342 ?x1342) true))))))))
(check-sat)
; query 43: function core_state_transition, block 99, name %100
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x53 (or false false)))
(let (($x219 (not $x53)))
(and $x219 (or $x53 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 44: function core_state_transition, block 99, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x692 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x53 (or false false)))
(let (($x108 (or $x53 false false)))
(let (($x510 (not $x108)))
(and $x510 (or $x108 (and (distinct ?x692 ?x692) true))))))))
(check-sat)
; query 45: function crcu8, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x53 (or false false)))
(let (($x219 (not $x53)))
(and $x219 (or $x53 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 46: function crcu8, block 19, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x507 ((_ zero_extend 16) in.01_16)))
(let ((?x584 (bvxor ?x507 (_ bv16386 32))))
(let (($x53 (or false false)))
(let (($x108 (or $x53 false false)))
(let (($x510 (not $x108)))
(and $x510 (or $x108 (and (distinct ?x584 ?x584) true)))))))))
(check-sat)
; query 47: function crcu8, block 19, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x507 ((_ zero_extend 16) in.01_16)))
(let ((?x584 (bvxor ?x507 (_ bv16386 32))))
(let ((?x1384 ((_ extract 15 0) ?x584)))
(let (($x53 (or false false)))
(let (($x108 (or $x53 false false)))
(let (($x223 (or (or $x108 (or (and (distinct ((_ zero_extend 16) ?x1384) ?x584) true))) (and (distinct ?x1384 ?x1384) true))))
(let (($x1097 (or $x108 false)))
(let (($x49 (not $x1097)))
(and $x49 $x223))))))))))
(check-sat)
; query 48: function crcu8, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x1301 (or false (or (= ((_ extract 15 15) in27_16) (_ bv1 1))))))
(let (($x53 (or false false)))
(let (($x219 (not $x53)))
(and $x219 (or $x1301 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true)))))))
(check-sat)
; query 49: function crcu8, block 29, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1315 ((_ zero_extend 16) in27_16)))
(let ((?x1370 (bvor ?x1315 (_ bv32768 32))))
(let (($x1301 (or false (or (= ((_ extract 15 15) in27_16) (_ bv1 1))))))
(let (($x1373 (or $x1301 false false)))
(let (($x53 (or false false)))
(let (($x108 (or $x53 false false)))
(let (($x510 (not $x108)))
(and $x510 (or $x1373 (and (distinct ?x1370 ?x1370) true)))))))))))
(check-sat)
; query 50: function crcu8, block 29, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1315 ((_ zero_extend 16) in27_16)))
(let ((?x1370 (bvor ?x1315 (_ bv32768 32))))
(let ((?x1268 ((_ extract 15 0) ?x1370)))
(let (($x1301 (or false (or (= ((_ extract 15 15) in27_16) (_ bv1 1))))))
(let (($x1373 (or $x1301 false false)))
(let (($x1306 (or (or $x1373 (or (and (distinct ((_ zero_extend 16) ?x1268) ?x1370) true))) (and (distinct ?x1268 ?x1268) true))))
(let (($x53 (or false false)))
(let (($x108 (or $x53 false false)))
(let (($x1097 (or $x108 false)))
(let (($x49 (not $x1097)))
(and $x49 $x1306))))))))))))
(check-sat)
; query 51: function crcu8, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x563 ((_ extract 7 0) in.01_16)))
(let ((?x673 ((_ zero_extend 24) ?x563)))
(let (($x53 (or false false)))
(let (($x486 (or $x53 false)))
(and (not $x486) (or $x486 (and (distinct ?x673 ?x673) true))))))))
(check-sat)
; query 52: function crcu8, block 6, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x563 ((_ extract 7 0) in.01_16)))
(let ((?x673 ((_ zero_extend 24) ?x563)))
(let ((?x1252 (bvand ?x673 (_ bv1 32))))
(let (($x53 (or false false)))
(let (($x486 (or $x53 false)))
(let (($x866 (or $x486 false false)))
(and (not $x866) (or $x866 (and (distinct ?x1252 ?x1252) true))))))))))
(check-sat)
; query 53: function crcu8, block 6, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x563 ((_ extract 7 0) in.01_16)))
(let ((?x673 ((_ zero_extend 24) ?x563)))
(let ((?x1252 (bvand ?x673 (_ bv1 32))))
(let ((?x368 ((_ zero_extend 24) in.0_8)))
(let ((?x909 (bvand ?x368 (_ bv1 32))))
(let ((?x1025 (bvxor ?x909 ?x1252)))
(let (($x53 (or false false)))
(let (($x486 (or $x53 false)))
(let (($x866 (or $x486 false false)))
(let (($x108 (or $x53 false false)))
(let (($x1020 (or $x108 $x866 false)))
(and (not $x1020) (or $x1020 (and (distinct ?x1025 ?x1025) true)))))))))))))))
(check-sat)
; query 54: function crcu8, block 6, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x563 ((_ extract 7 0) in.01_16)))
(let ((?x673 ((_ zero_extend 24) ?x563)))
(let ((?x1252 (bvand ?x673 (_ bv1 32))))
(let ((?x368 ((_ zero_extend 24) in.0_8)))
(let ((?x909 (bvand ?x368 (_ bv1 32))))
(let ((?x1025 (bvxor ?x909 ?x1252)))
(let ((?x905 ((_ extract 7 0) ?x1025)))
(let (($x184 (or (and (distinct ((_ zero_extend 24) ?x905) ?x1025) true) (and (distinct ((_ sign_extend 24) ?x905) ?x1025) true))))
(let (($x53 (or false false)))
(let (($x486 (or $x53 false)))
(let (($x866 (or $x486 false false)))
(let (($x108 (or $x53 false false)))
(let (($x1020 (or $x108 $x866 false)))
(let (($x709 (or $x1020 $x184)))
(and (not (or $x1020 false)) (or $x709 (and (distinct ?x905 ?x905) true))))))))))))))))))
(check-sat)
; query 55: function crcu8, block 6, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x53 (or false false)))
(let (($x219 (not $x53)))
(and $x219 (or $x53 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 56: function crcu8, block 6, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x368 ((_ zero_extend 24) in.0_8)))
(let ((?x684 (bvlshr ?x368 (_ bv1 32))))
(let ((?x1109 (bvashr ?x368 (_ bv1 32))))
(let (($x53 (or false false)))
(let (($x108 (or $x53 false false)))
(let (($x856 (or $x108 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not $x856) (or $x856 (and (distinct ?x1109 ?x684) true))))))))))
(check-sat)
; query 57: function crcu8, block 6, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x368 ((_ zero_extend 24) in.0_8)))
(let ((?x684 (bvlshr ?x368 (_ bv1 32))))
(let ((?x819 ((_ extract 7 0) ?x684)))
(let (($x1218 (or (and (distinct ((_ zero_extend 24) ?x819) ?x684) true) (and (distinct ((_ sign_extend 24) ?x819) ?x684) true))))
(let (($x53 (or false false)))
(let (($x108 (or $x53 false false)))
(let (($x856 (or $x108 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not (or $x856 false)) (or (or $x856 $x1218) (and (distinct ((_ extract 7 0) (bvashr ?x368 (_ bv1 32))) ?x819) true)))))))))))
(check-sat)
; query 58: function crcu8, block 6, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x563 ((_ extract 7 0) in.01_16)))
(let ((?x673 ((_ zero_extend 24) ?x563)))
(let ((?x1252 (bvand ?x673 (_ bv1 32))))
(let ((?x368 ((_ zero_extend 24) in.0_8)))
(let ((?x909 (bvand ?x368 (_ bv1 32))))
(let ((?x1025 (bvxor ?x909 ?x1252)))
(let ((?x905 ((_ extract 7 0) ?x1025)))
(let ((?x908 ((_ zero_extend 24) ?x905)))
(let (($x53 (or false false)))
(let (($x486 (or $x53 false)))
(let (($x866 (or $x486 false false)))
(let (($x108 (or $x53 false false)))
(let (($x1020 (or $x108 $x866 false)))
(let (($x709 (or $x1020 (or (and (distinct ?x908 ?x1025) true) (and (distinct ((_ sign_extend 24) ?x905) ?x1025) true)))))
(let (($x247 (or $x709 (or (= ((_ extract 7 7) ?x905) (_ bv1 1))))))
(and (not (or (or $x1020 false) false)) (or $x247 (and (distinct ?x908 ?x908) true)))))))))))))))))))
(check-sat)
; query 59: function crcu8, block 6, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x563 ((_ extract 7 0) in.01_16)))
(let ((?x673 ((_ zero_extend 24) ?x563)))
(let ((?x1252 (bvand ?x673 (_ bv1 32))))
(let ((?x368 ((_ zero_extend 24) in.0_8)))
(let ((?x909 (bvand ?x368 (_ bv1 32))))
(let ((?x1025 (bvxor ?x909 ?x1252)))
(let ((?x905 ((_ extract 7 0) ?x1025)))
(let ((?x908 ((_ zero_extend 24) ?x905)))
(let ((?x1154 (ite (= (_ bv1 32) ?x908) (_ bv1 1) (_ bv0 1))))
(let (($x53 (or false false)))
(let (($x486 (or $x53 false)))
(let (($x866 (or $x486 false false)))
(let (($x108 (or $x53 false false)))
(let (($x1020 (or $x108 $x866 false)))
(let (($x709 (or $x1020 (or (and (distinct ?x908 ?x1025) true) (and (distinct ((_ sign_extend 24) ?x905) ?x1025) true)))))
(let (($x247 (or $x709 (or (= ((_ extract 7 7) ?x905) (_ bv1 1))))))
(and (not (or (or (or $x1020 false) false) false false)) (or (or $x247 false false) (and (distinct ?x1154 ?x1154) true))))))))))))))))))))
(check-sat)
; query 60: function crcu8, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x53 (or false false)))
(let (($x219 (not $x53)))
(and $x219 (or $x53 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 61: function crcu8, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x368 ((_ zero_extend 24) in.0_8)))
(let ((?x909 (bvand ?x368 (_ bv1 32))))
(let (($x53 (or false false)))
(let (($x108 (or $x53 false false)))
(let (($x510 (not $x108)))
(and $x510 (or $x108 (and (distinct ?x909 ?x909) true)))))))))
(check-sat)
; query 62: function crcu8, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x53 (or false false)))
(let (($x219 (not $x53)))
(and $x219 (or $x53 (and (distinct ((_ extract 7 0) in.01_16) ((_ extract 7 0) in.01_16)) true))))))
(check-sat)
; query 63: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1263 (ite (bvule ((_ zero_extend 24) in0_8) (_ bv57 32)) (_ bv1 1) (_ bv0 1))))
(let ((?x771 ((_ zero_extend 31) ?x1263)))
(let ((?x640 (ite (bvuge ((_ zero_extend 24) in0_8) (_ bv48 32)) (_ bv1 1) (_ bv0 1))))
(let ((?x417 ((_ zero_extend 31) ?x640)))
(let ((?x1126 (bvand ?x417 ?x771)))
(let ((?x3313 (ite (and (distinct (_ bv0 32) ?x1126) true) (_ bv1 1) (_ bv0 1))))
(let ((?x1017 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1069 ((_ zero_extend 31) ?x1017)))
(let ((?x432 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x831 ((_ zero_extend 31) ?x432)))
(let ((?x763 (bvand ?x831 ?x1069)))
(let ((?x1381 (ite (and (distinct (_ bv0 32) ?x763) true) (_ bv1 1) (_ bv0 1))))
(let (($x53 (or false false)))
(let (($x1080 (or $x53 false (and (distinct ((_ extract 31 31) ((_ zero_extend 24) in0_8)) ((_ extract 31 31) (_ bv57 32))) true))))
(let (($x1036 (or $x1080 false)))
(let (($x697 (or $x53 false (and (distinct ((_ extract 31 31) ((_ zero_extend 24) in0_8)) ((_ extract 31 31) (_ bv48 32))) true))))
(let (($x1214 (or $x697 false)))
(let (($x3312 (or $x1214 $x1036 false)))
(let (($x3323 (or $x3312 false false)))
(let (($x108 (or $x53 false false)))
(let (($x1097 (or $x108 false)))
(let (($x943 (or $x1097 $x1097 false)))
(let (($x1205 (or $x943 false false)))
(and (not (or $x1205 false)) (or (or $x3323 false) (and (distinct ((_ zero_extend 63) ?x1381) ((_ zero_extend 63) ?x3313)) true)))))))))))))))))))))))))))
(check-sat)
; query 64: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1263 (ite (bvule ((_ zero_extend 24) in0_8) (_ bv57 32)) (_ bv1 1) (_ bv0 1))))
(let ((?x771 ((_ zero_extend 31) ?x1263)))
(let ((?x640 (ite (bvuge ((_ zero_extend 24) in0_8) (_ bv48 32)) (_ bv1 1) (_ bv0 1))))
(let ((?x417 ((_ zero_extend 31) ?x640)))
(let ((?x1126 (bvand ?x417 ?x771)))
(let ((?x3313 (ite (and (distinct (_ bv0 32) ?x1126) true) (_ bv1 1) (_ bv0 1))))
(let (($x3505 (= (_ bv1 1) ?x3313)))
(let ((?x3525 (ite $x3505 (_ bv1 32) (_ bv0 32))))
(let ((?x1017 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1069 ((_ zero_extend 31) ?x1017)))
(let ((?x432 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x831 ((_ zero_extend 31) ?x432)))
(let ((?x763 (bvand ?x831 ?x1069)))
(let ((?x1381 (ite (and (distinct (_ bv0 32) ?x763) true) (_ bv1 1) (_ bv0 1))))
(let (($x83 (= (_ bv1 1) ?x1381)))
(let ((?x1220 (ite $x83 (_ bv1 32) (_ bv0 32))))
(let (($x53 (or false false)))
(let (($x1080 (or $x53 false (and (distinct ((_ extract 31 31) ((_ zero_extend 24) in0_8)) ((_ extract 31 31) (_ bv57 32))) true))))
(let (($x1036 (or $x1080 false)))
(let (($x697 (or $x53 false (and (distinct ((_ extract 31 31) ((_ zero_extend 24) in0_8)) ((_ extract 31 31) (_ bv48 32))) true))))
(let (($x1214 (or $x697 false)))
(let (($x3312 (or $x1214 $x1036 false)))
(let (($x3323 (or $x3312 false false)))
(let (($x3560 (or $x3323 (ite $x3505 false false))))
(let (($x108 (or $x53 false false)))
(let (($x1097 (or $x108 false)))
(let (($x943 (or $x1097 $x1097 false)))
(let (($x1205 (or $x943 false false)))
(let (($x1223 (or $x1205 (ite $x83 false false))))
(and (not $x1223) (or $x3560 (and (distinct ?x1220 ?x3525) true)))))))))))))))))))))))))))))))))
(check-sat)
; query 65: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1263 (ite (bvule ((_ zero_extend 24) in0_8) (_ bv57 32)) (_ bv1 1) (_ bv0 1))))
(let ((?x771 ((_ zero_extend 31) ?x1263)))
(let ((?x640 (ite (bvuge ((_ zero_extend 24) in0_8) (_ bv48 32)) (_ bv1 1) (_ bv0 1))))
(let ((?x417 ((_ zero_extend 31) ?x640)))
(let ((?x1126 (bvand ?x417 ?x771)))
(let ((?x3313 (ite (and (distinct (_ bv0 32) ?x1126) true) (_ bv1 1) (_ bv0 1))))
(let (($x3505 (= (_ bv1 1) ?x3313)))
(let ((?x3525 (ite $x3505 (_ bv1 32) (_ bv0 32))))
(let ((?x3802 ((_ extract 7 0) ?x3525)))
(let ((?x1017 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1069 ((_ zero_extend 31) ?x1017)))
(let ((?x432 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x831 ((_ zero_extend 31) ?x432)))
(let ((?x763 (bvand ?x831 ?x1069)))
(let ((?x1381 (ite (and (distinct (_ bv0 32) ?x763) true) (_ bv1 1) (_ bv0 1))))
(let (($x83 (= (_ bv1 1) ?x1381)))
(let ((?x1220 (ite $x83 (_ bv1 32) (_ bv0 32))))
(let (($x348 (or (and (distinct ((_ zero_extend 24) ?x3802) ?x3525) true) (and (distinct ((_ sign_extend 24) ?x3802) ?x3525) true))))
(let (($x53 (or false false)))
(let (($x1080 (or $x53 false (and (distinct ((_ extract 31 31) ((_ zero_extend 24) in0_8)) ((_ extract 31 31) (_ bv57 32))) true))))
(let (($x1036 (or $x1080 false)))
(let (($x697 (or $x53 false (and (distinct ((_ extract 31 31) ((_ zero_extend 24) in0_8)) ((_ extract 31 31) (_ bv48 32))) true))))
(let (($x1214 (or $x697 false)))
(let (($x3312 (or $x1214 $x1036 false)))
(let (($x3323 (or $x3312 false false)))
(let (($x3560 (or $x3323 (ite $x3505 false false))))
(let (($x108 (or $x53 false false)))
(let (($x1097 (or $x108 false)))
(let (($x943 (or $x1097 $x1097 false)))
(let (($x1205 (or $x943 false false)))
(let (($x1223 (or $x1205 (ite $x83 false false))))
(and (not (or $x1223 false)) (or (or $x3560 $x348) (and (distinct ((_ extract 7 0) ?x1220) ?x3802) true)))))))))))))))))))))))))))))))))))
(check-sat)
; query 66: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x53 (or false false)))
(let (($x219 (not $x53)))
(and $x219 (or $x53 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 67: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x640 (ite (bvuge ((_ zero_extend 24) in0_8) (_ bv48 32)) (_ bv1 1) (_ bv0 1))))
(let ((?x432 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x53 (or false false)))
(let (($x697 (or $x53 false (and (distinct ((_ extract 31 31) ((_ zero_extend 24) in0_8)) ((_ extract 31 31) (_ bv48 32))) true))))
(let (($x108 (or $x53 false false)))
(let (($x510 (not $x108)))
(and $x510 (or $x697 (and (distinct ?x432 ?x640) true))))))))))
(check-sat)
; query 68: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x640 (ite (bvuge ((_ zero_extend 24) in0_8) (_ bv48 32)) (_ bv1 1) (_ bv0 1))))
(let ((?x417 ((_ zero_extend 31) ?x640)))
(let ((?x432 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x831 ((_ zero_extend 31) ?x432)))
(let (($x53 (or false false)))
(let (($x697 (or $x53 false (and (distinct ((_ extract 31 31) ((_ zero_extend 24) in0_8)) ((_ extract 31 31) (_ bv48 32))) true))))
(let (($x1214 (or $x697 false)))
(let (($x108 (or $x53 false false)))
(let (($x1097 (or $x108 false)))
(let (($x49 (not $x1097)))
(and $x49 (or $x1214 (and (distinct ?x831 ?x417) true))))))))))))))
(check-sat)
; query 69: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x53 (or false false)))
(let (($x219 (not $x53)))
(and $x219 (or $x53 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 70: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1263 (ite (bvule ((_ zero_extend 24) in0_8) (_ bv57 32)) (_ bv1 1) (_ bv0 1))))
(let ((?x1017 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x53 (or false false)))
(let (($x1080 (or $x53 false (and (distinct ((_ extract 31 31) ((_ zero_extend 24) in0_8)) ((_ extract 31 31) (_ bv57 32))) true))))
(let (($x108 (or $x53 false false)))
(let (($x510 (not $x108)))
(and $x510 (or $x1080 (and (distinct ?x1017 ?x1263) true))))))))))
(check-sat)
; query 71: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1263 (ite (bvule ((_ zero_extend 24) in0_8) (_ bv57 32)) (_ bv1 1) (_ bv0 1))))
(let ((?x771 ((_ zero_extend 31) ?x1263)))
(let ((?x1017 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1069 ((_ zero_extend 31) ?x1017)))
(let (($x53 (or false false)))
(let (($x1080 (or $x53 false (and (distinct ((_ extract 31 31) ((_ zero_extend 24) in0_8)) ((_ extract 31 31) (_ bv57 32))) true))))
(let (($x1036 (or $x1080 false)))
(let (($x108 (or $x53 false false)))
(let (($x1097 (or $x108 false)))
(let (($x49 (not $x1097)))
(and $x49 (or $x1036 (and (distinct ?x1069 ?x771) true))))))))))))))
(check-sat)
; query 72: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1263 (ite (bvule ((_ zero_extend 24) in0_8) (_ bv57 32)) (_ bv1 1) (_ bv0 1))))
(let ((?x771 ((_ zero_extend 31) ?x1263)))
(let ((?x640 (ite (bvuge ((_ zero_extend 24) in0_8) (_ bv48 32)) (_ bv1 1) (_ bv0 1))))
(let ((?x417 ((_ zero_extend 31) ?x640)))
(let ((?x1126 (bvand ?x417 ?x771)))
(let ((?x1017 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1069 ((_ zero_extend 31) ?x1017)))
(let ((?x432 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x831 ((_ zero_extend 31) ?x432)))
(let ((?x763 (bvand ?x831 ?x1069)))
(let (($x53 (or false false)))
(let (($x1080 (or $x53 false (and (distinct ((_ extract 31 31) ((_ zero_extend 24) in0_8)) ((_ extract 31 31) (_ bv57 32))) true))))
(let (($x1036 (or $x1080 false)))
(let (($x697 (or $x53 false (and (distinct ((_ extract 31 31) ((_ zero_extend 24) in0_8)) ((_ extract 31 31) (_ bv48 32))) true))))
(let (($x1214 (or $x697 false)))
(let (($x3312 (or $x1214 $x1036 false)))
(let (($x108 (or $x53 false false)))
(let (($x1097 (or $x108 false)))
(let (($x943 (or $x1097 $x1097 false)))
(and (not $x943) (or $x3312 (and (distinct ?x763 ?x1126) true)))))))))))))))))))))))
(check-sat)
; query 73: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1263 (ite (bvule ((_ zero_extend 24) in0_8) (_ bv57 32)) (_ bv1 1) (_ bv0 1))))
(let ((?x771 ((_ zero_extend 31) ?x1263)))
(let ((?x640 (ite (bvuge ((_ zero_extend 24) in0_8) (_ bv48 32)) (_ bv1 1) (_ bv0 1))))
(let ((?x417 ((_ zero_extend 31) ?x640)))
(let ((?x1126 (bvand ?x417 ?x771)))
(let ((?x3313 (ite (and (distinct (_ bv0 32) ?x1126) true) (_ bv1 1) (_ bv0 1))))
(let ((?x1017 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1069 ((_ zero_extend 31) ?x1017)))
(let ((?x432 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x831 ((_ zero_extend 31) ?x432)))
(let ((?x763 (bvand ?x831 ?x1069)))
(let ((?x1381 (ite (and (distinct (_ bv0 32) ?x763) true) (_ bv1 1) (_ bv0 1))))
(let (($x53 (or false false)))
(let (($x1080 (or $x53 false (and (distinct ((_ extract 31 31) ((_ zero_extend 24) in0_8)) ((_ extract 31 31) (_ bv57 32))) true))))
(let (($x1036 (or $x1080 false)))
(let (($x697 (or $x53 false (and (distinct ((_ extract 31 31) ((_ zero_extend 24) in0_8)) ((_ extract 31 31) (_ bv48 32))) true))))
(let (($x1214 (or $x697 false)))
(let (($x3312 (or $x1214 $x1036 false)))
(let (($x3323 (or $x3312 false false)))
(let (($x108 (or $x53 false false)))
(let (($x1097 (or $x108 false)))
(let (($x943 (or $x1097 $x1097 false)))
(let (($x1205 (or $x943 false false)))
(and (not $x1205) (or $x3323 (and (distinct ?x1381 ?x3313) true)))))))))))))))))))))))))))
(check-sat)
; query 74: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x3886 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x564 (or false false false)))
(let (($x105 (not $x564)))
(and $x105 (or $x564 (and (distinct ?x3886 ?x3886) true)))))))
(check-sat)
; query 75: function matrix_add_const, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x389 (bvadd in.0_32 (_ bv1 32))))
(let (($x462 (and (distinct ?x389 ?x389) true)))
(let (($x1375 (and (distinct (bvadd ((_ zero_extend 1) in.0_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) ?x389)) true)))
(let (($x564 (or false false false)))
(let (($x105 (not $x564)))
(and $x105 (or (or false false (or $x1375)) $x462))))))))
(check-sat)
; query 76: function matrix_add_const, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1336 (bvadd in.01_32 (_ bv1 32))))
(let (($x516 (and (distinct ?x1336 ?x1336) true)))
(let (($x564 (or false false false)))
(let (($x105 (not $x564)))
(and $x105 (or $x564 $x516)))))))
(check-sat)
; query 77: function matrix_mul_const, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x389 (bvadd in.0_32 (_ bv1 32))))
(let (($x462 (and (distinct ?x389 ?x389) true)))
(let (($x1375 (and (distinct (bvadd ((_ zero_extend 1) in.0_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) ?x389)) true)))
(let (($x564 (or false false false)))
(let (($x105 (not $x564)))
(and $x105 (or (or false false (or $x1375)) $x462))))))))
(check-sat)
; query 78: function matrix_mul_const, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1336 (bvadd in.01_32 (_ bv1 32))))
(let (($x516 (and (distinct ?x1336 ?x1336) true)))
(let (($x564 (or false false false)))
(let (($x105 (not $x564)))
(and $x105 (or $x564 $x516)))))))
(check-sat)
; query 79: function matrix_mul_matrix, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x389 (bvadd in.0_32 (_ bv1 32))))
(let (($x462 (and (distinct ?x389 ?x389) true)))
(let (($x1375 (and (distinct (bvadd ((_ zero_extend 1) in.0_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) ?x389)) true)))
(let (($x564 (or false false false)))
(let (($x105 (not $x564)))
(and $x105 (or (or false false (or $x1375)) $x462))))))))
(check-sat)
; query 80: function matrix_mul_matrix, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1336 (bvadd in.01_32 (_ bv1 32))))
(let (($x516 (and (distinct ?x1336 ?x1336) true)))
(let (($x564 (or false false false)))
(let (($x105 (not $x564)))
(and $x105 (or $x564 $x516)))))))
(check-sat)
; query 81: function matrix_mul_matrix, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x564 (or false false false)))
(let (($x105 (not $x564)))
(and $x105 (or $x564 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 82: function matrix_mul_matrix_bitextract, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x389 (bvadd in.0_32 (_ bv1 32))))
(let (($x462 (and (distinct ?x389 ?x389) true)))
(let (($x1375 (and (distinct (bvadd ((_ zero_extend 1) in.0_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) ?x389)) true)))
(let (($x564 (or false false false)))
(let (($x105 (not $x564)))
(and $x105 (or (or false false (or $x1375)) $x462))))))))
(check-sat)
; query 83: function matrix_mul_matrix_bitextract, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1336 (bvadd in.01_32 (_ bv1 32))))
(let (($x516 (and (distinct ?x1336 ?x1336) true)))
(let (($x564 (or false false false)))
(let (($x105 (not $x564)))
(and $x105 (or $x564 $x516)))))))
(check-sat)
; query 84: function matrix_mul_matrix_bitextract, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x564 (or false false false)))
(let (($x105 (not $x564)))
(and $x105 (or $x564 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 85: function matrix_mul_vect, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x389 (bvadd in.0_32 (_ bv1 32))))
(let (($x462 (and (distinct ?x389 ?x389) true)))
(let (($x1375 (and (distinct (bvadd ((_ zero_extend 1) in.0_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) ?x389)) true)))
(let (($x564 (or false false false)))
(let (($x105 (not $x564)))
(and $x105 (or (or false false (or $x1375)) $x462))))))))
(check-sat)
; query 86: function matrix_mul_vect, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1336 (bvadd in.01_32 (_ bv1 32))))
(let (($x516 (and (distinct ?x1336 ?x1336) true)))
(let (($x564 (or false false false)))
(let (($x105 (not $x564)))
(and $x105 (or $x564 $x516)))))))
(check-sat)
; query 87: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x53 (or false false)))
(let (($x219 (not $x53)))
(and $x219 (or $x53 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 88: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x4368 ((_ sign_extend 16) in.1_16)))
(let ((?x5248 (bvadd ?x4368 (_ bv10 32))))
(let (($x3664 (and (distinct (bvadd ((_ sign_extend 1) ?x4368) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x5248)) true)))
(let (($x53 (or false false)))
(let (($x2561 (or $x53 false (or $x3664))))
(and (not $x2561) (or $x2561 (and (distinct ?x5248 ?x5248) true)))))))))
(check-sat)
; query 89: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x4368 ((_ sign_extend 16) in.1_16)))
(let ((?x5248 (bvadd ?x4368 (_ bv10 32))))
(let ((?x2382 ((_ extract 15 0) ?x5248)))
(let (($x3664 (and (distinct (bvadd ((_ sign_extend 1) ?x4368) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x5248)) true)))
(let (($x53 (or false false)))
(let (($x2561 (or $x53 false (or $x3664))))
(let (($x2269 (or $x2561 false)))
(and (not $x2269) (or $x2269 (and (distinct ?x2382 ?x2382) true)))))))))))
(check-sat)
; query 90: function matrix_sum, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x3830 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x564 (or false false false)))
(let (($x105 (not $x564)))
(and $x105 (or $x564 (and (distinct ?x3830 ?x3830) true)))))))
(check-sat)
; query 91: function matrix_sum, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x3830 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let ((?x4280 ((_ zero_extend 63) ?x3830)))
(let (($x564 (or false false false)))
(let (($x4556 (or $x564 false)))
(and (not $x4556) (or $x4556 (and (distinct ?x4280 ?x4280) true))))))))
(check-sat)
; query 92: function matrix_sum, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x3830 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x4292 (= (_ bv1 1) ?x3830)))
(let ((?x4569 (ite $x4292 (_ bv1 32) (_ bv0 32))))
(let (($x564 (or false false false)))
(let (($x3329 (or $x564 (ite $x4292 false false))))
(and (not $x3329) (or $x3329 (and (distinct ?x4569 ?x4569) true)))))))))
(check-sat)
; query 93: function matrix_sum, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x53 (or false false)))
(let (($x219 (not $x53)))
(and $x219 (or $x53 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 94: function matrix_sum, block 22, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x3830 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x4292 (= (_ bv1 1) ?x3830)))
(let ((?x4569 (ite $x4292 (_ bv1 32) (_ bv0 32))))
(let ((?x4368 ((_ sign_extend 16) in.1_16)))
(let ((?x4298 (bvadd ?x4368 ?x4569)))
(let (($x4296 (and (distinct (bvadd ((_ sign_extend 1) ?x4368) ((_ sign_extend 1) ?x4569)) ((_ sign_extend 1) ?x4298)) true)))
(let (($x564 (or false false false)))
(let (($x3329 (or $x564 (ite $x4292 false false))))
(let (($x53 (or false false)))
(let (($x4314 (or $x53 $x3329 (or $x4296))))
(and (not $x4314) (or $x4314 (and (distinct ?x4298 ?x4298) true))))))))))))))
(check-sat)
; query 95: function matrix_sum, block 22, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x3830 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x4292 (= (_ bv1 1) ?x3830)))
(let ((?x4569 (ite $x4292 (_ bv1 32) (_ bv0 32))))
(let ((?x4368 ((_ sign_extend 16) in.1_16)))
(let ((?x4298 (bvadd ?x4368 ?x4569)))
(let ((?x4311 ((_ extract 15 0) ?x4298)))
(let (($x4296 (and (distinct (bvadd ((_ sign_extend 1) ?x4368) ((_ sign_extend 1) ?x4569)) ((_ sign_extend 1) ?x4298)) true)))
(let (($x564 (or false false false)))
(let (($x3329 (or $x564 (ite $x4292 false false))))
(let (($x53 (or false false)))
(let (($x4314 (or $x53 $x3329 (or $x4296))))
(let (($x4312 (or $x4314 false)))
(and (not $x4312) (or $x4312 (and (distinct ?x4311 ?x4311) true))))))))))))))))
(check-sat)
; query 96: function matrix_sum, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x389 (bvadd in.0_32 (_ bv1 32))))
(let (($x462 (and (distinct ?x389 ?x389) true)))
(let (($x1375 (and (distinct (bvadd ((_ zero_extend 1) in.0_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) ?x389)) true)))
(let (($x564 (or false false false)))
(let (($x105 (not $x564)))
(and $x105 (or (or false false (or $x1375)) $x462))))))))
(check-sat)
; query 97: function matrix_sum, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1336 (bvadd in.01_32 (_ bv1 32))))
(let (($x516 (and (distinct ?x1336 ?x1336) true)))
(let (($x564 (or false false false)))
(let (($x105 (not $x564)))
(and $x105 (or $x564 $x516)))))))
(check-sat)
; query 98: function parseval, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.23_32 () (_ BitVec 32))
(assert
 (let (($x7783 (and (distinct (bvmul ((_ sign_extend 32) in.23_32) ((_ sign_extend 32) (_ bv1024 32))) ((_ sign_extend 32) (bvmul in.23_32 (_ bv1024 32)))) true)))
(let (($x4592 (or false false (or $x7783))))
(and (not $x4592) (or $x4592 (and (distinct (bvmul in.23_32 (_ bv1024 32)) (bvmul in.23_32 (_ bv1024 32))) true))))))
(check-sat)
; query 99: function parseval, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.34_32 () (_ BitVec 32))
(assert
 (let (($x7808 (and (distinct (bvmul ((_ sign_extend 32) in.34_32) ((_ sign_extend 32) (_ bv1048576 32))) ((_ sign_extend 32) (bvmul in.34_32 (_ bv1048576 32)))) true)))
(let (($x7822 (or false false (or $x7808))))
(and (not $x7822) (or $x7822 (and (distinct (bvmul in.34_32 (_ bv1048576 32)) (bvmul in.34_32 (_ bv1048576 32))) true))))))
(check-sat)
; query 100: function partition_memory, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x389 (bvadd in.0_32 (_ bv1 32))))
(let (($x462 (and (distinct ?x389 ?x389) true)))
(let (($x1375 (and (distinct (bvadd ((_ zero_extend 1) in.0_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) ?x389)) true)))
(let (($x37 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x389)) true)))
(let (($x564 (or false false false)))
(let (($x105 (not $x564)))
(and $x105 (or (or false false (or $x37 $x1375)) $x462)))))))))
(check-sat)
; query 101: function run_crc_loop, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1336 (bvadd in.01_32 (_ bv1 32))))
(let (($x516 (and (distinct ?x1336 ?x1336) true)))
(let (($x124 (and (distinct (bvadd ((_ zero_extend 1) in.01_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) ?x1336)) true)))
(let (($x9 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x1336)) true)))
(let (($x564 (or false false false)))
(let (($x105 (not $x564)))
(and $x105 (or (or false false (or $x9 $x124)) $x516)))))))))
(check-sat)
