; OptiPhase-Sigma refinement certificate for sweep K38-R4-310
; query 0: function BF_cbc_encrypt, block 126, name %127
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.010_64 () (_ BitVec 64))
(assert
 (let (($x704 (and (distinct (bvsub ((_ sign_extend 1) in.010_64) ((_ sign_extend 1) (_ bv8 64))) ((_ sign_extend 1) (bvsub in.010_64 (_ bv8 64)))) true)))
(let (($x47 (or false false (or $x704))))
(and (not $x47) (or $x47 (and (distinct (bvsub in.010_64 (_ bv8 64)) (bvsub in.010_64 (_ bv8 64))) true))))))
(check-sat)
; query 1: function BF_cbc_encrypt, block 366, name %367
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.111_64 () (_ BitVec 64))
(assert
 (let (($x762 (and (distinct (bvsub ((_ sign_extend 1) in.111_64) ((_ sign_extend 1) (_ bv8 64))) ((_ sign_extend 1) (bvsub in.111_64 (_ bv8 64)))) true)))
(let (($x16 (or false false (or $x762))))
(and (not $x16) (or $x16 (and (distinct (bvsub in.111_64 (_ bv8 64)) (bvsub in.111_64 (_ bv8 64))) true))))))
(check-sat)
; query 2: function BF_cfb64_encrypt, block 111, name %112
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.18_32 () (_ BitVec 32))
(assert
 (let ((?x421 (ite (= (_ bv0 32) in.18_32) (_ bv1 1) (_ bv0 1))))
(let (($x27 (or false false false)))
(let (($x112 (not $x27)))
(and $x112 (or $x27 (and (distinct ?x421 ?x421) true)))))))
(check-sat)
; query 3: function BF_cfb64_encrypt, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.07_32 () (_ BitVec 32))
(assert
 (let ((?x383 (ite (= (_ bv0 32) in.07_32) (_ bv1 1) (_ bv0 1))))
(let (($x27 (or false false false)))
(let (($x112 (not $x27)))
(and $x112 (or $x27 (and (distinct ?x383 ?x383) true)))))))
(check-sat)
; query 4: function BF_ofb64_encrypt, block 82, name %83
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x228 (ite (= (_ bv0 32) in.04_32) (_ bv1 1) (_ bv0 1))))
(let (($x27 (or false false false)))
(let (($x112 (not $x27)))
(and $x112 (or $x27 (and (distinct ?x228 ?x228) true)))))))
(check-sat)
; query 5: function BF_set_key, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x18 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x260 (or false false (or $x18))))
(and (not $x260) (or $x260 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 6: function BF_set_key, block 69, name %70
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.13_32 () (_ BitVec 32))
(assert
 (let (($x11 (and (distinct (bvadd ((_ sign_extend 1) in.13_32) ((_ sign_extend 1) (_ bv2 32))) ((_ sign_extend 1) (bvadd in.13_32 (_ bv2 32)))) true)))
(let (($x119 (or false false (or $x11))))
(and (not $x119) (or $x119 (and (distinct (bvadd in.13_32 (_ bv2 32)) (bvadd in.13_32 (_ bv2 32))) true))))))
(check-sat)
; query 7: function BF_set_key, block 87, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.24_32 () (_ BitVec 32))
(assert
 (let (($x232 (and (distinct (bvadd ((_ sign_extend 1) in.24_32) ((_ sign_extend 1) (_ bv2 32))) ((_ sign_extend 1) (bvadd in.24_32 (_ bv2 32)))) true)))
(let (($x49 (or false false (or $x232))))
(and (not $x49) (or $x49 (and (distinct (bvadd in.24_32 (_ bv2 32)) (bvadd in.24_32 (_ bv2 32))) true))))))
(check-sat)
; query 8: function main, block 124, name %125
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let ((?x145 (ite (bvsgt (_ bv40 32) in.2_32) (_ bv1 1) (_ bv0 1))))
(let (($x27 (or false false false)))
(let (($x112 (not $x27)))
(and $x112 (or $x27 (and (distinct ?x145 ?x145) true)))))))
(check-sat)
; query 9: function main, block 147, name %148
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x58 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x131 (or false false (or $x58))))
(and (not $x131) (or $x131 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 10: function main, block 60, name %61
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x94 (or false false)))
(and (not $x94) (or $x94 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 11: function main, block 60, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x37 (ite (bvsge (_ bv57 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x94 (or false false)))
(let (($x101 (or $x94 false false)))
(let (($x105 (not $x101)))
(and $x105 (or $x101 (and (distinct ?x37 ?x37) true))))))))
(check-sat)
; query 12: function main, block 63, name %64
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x27 (or false false false)))
(let (($x157 (or $x27 (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x157) (or $x157 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvshl in.01_32 (_ bv4 32))) true))))))
(check-sat)
; query 13: function main, block 63, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x94 (or false false)))
(and (not $x94) (or $x94 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 14: function main, block 63, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x97 ((_ sign_extend 24) in57_8)))
(let ((?x69 (bvshl in.01_32 (_ bv4 32))))
(let ((?x134 (bvadd ?x69 ?x97)))
(let ((?x127 ((_ sign_extend 1) ?x134)))
(let (($x94 (or false false)))
(let (($x27 (or false false false)))
(let (($x157 (or $x27 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x15 (or $x157 $x94 (or (and (distinct (bvadd ((_ sign_extend 1) ?x69) ((_ sign_extend 1) ?x97)) ?x127) true)))))
(and (not $x15) (or $x15 (and (distinct ?x134 ?x134) true))))))))))))
(check-sat)
; query 15: function main, block 63, name %67
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x97 ((_ sign_extend 24) in57_8)))
(let ((?x69 (bvshl in.01_32 (_ bv4 32))))
(let ((?x134 (bvadd ?x69 ?x97)))
(let ((?x57 (bvsub ?x134 (_ bv48 32))))
(let (($x23 (and (distinct (bvsub ((_ sign_extend 1) ?x134) ((_ sign_extend 1) (_ bv48 32))) ((_ sign_extend 1) ?x57)) true)))
(let ((?x127 ((_ sign_extend 1) ?x134)))
(let (($x94 (or false false)))
(let (($x27 (or false false false)))
(let (($x157 (or $x27 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x15 (or $x157 $x94 (or (and (distinct (bvadd ((_ sign_extend 1) ?x69) ((_ sign_extend 1) ?x97)) ?x127) true)))))
(let (($x205 (or $x15 false (or $x23))))
(and (not $x205) (or $x205 (and (distinct ?x57 ?x57) true)))))))))))))))
(check-sat)
; query 16: function main, block 68, name %69
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x94 (or false false)))
(and (not $x94) (or $x94 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 17: function main, block 68, name %70
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x392 (ite (bvsle (_ bv65 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x94 (or false false)))
(let (($x101 (or $x94 false false)))
(let (($x105 (not $x101)))
(and $x105 (or $x101 (and (distinct ?x392 ?x392) true))))))))
(check-sat)
; query 18: function main, block 71, name %72
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x94 (or false false)))
(and (not $x94) (or $x94 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 19: function main, block 71, name %73
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x403 (ite (bvsge (_ bv70 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x94 (or false false)))
(let (($x101 (or $x94 false false)))
(let (($x105 (not $x101)))
(and $x105 (or $x101 (and (distinct ?x403 ?x403) true))))))))
(check-sat)
; query 20: function main, block 74, name %75
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x27 (or false false false)))
(let (($x157 (or $x27 (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x157) (or $x157 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvshl in.01_32 (_ bv4 32))) true))))))
(check-sat)
; query 21: function main, block 74, name %76
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x94 (or false false)))
(and (not $x94) (or $x94 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 22: function main, block 74, name %77
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x97 ((_ sign_extend 24) in57_8)))
(let ((?x69 (bvshl in.01_32 (_ bv4 32))))
(let ((?x134 (bvadd ?x69 ?x97)))
(let ((?x127 ((_ sign_extend 1) ?x134)))
(let (($x94 (or false false)))
(let (($x27 (or false false false)))
(let (($x157 (or $x27 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x15 (or $x157 $x94 (or (and (distinct (bvadd ((_ sign_extend 1) ?x69) ((_ sign_extend 1) ?x97)) ?x127) true)))))
(and (not $x15) (or $x15 (and (distinct ?x134 ?x134) true))))))))))))
(check-sat)
; query 23: function main, block 74, name %78
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x97 ((_ sign_extend 24) in57_8)))
(let ((?x69 (bvshl in.01_32 (_ bv4 32))))
(let ((?x134 (bvadd ?x69 ?x97)))
(let ((?x51 (bvsub ?x134 (_ bv65 32))))
(let ((?x365 ((_ sign_extend 1) ?x51)))
(let ((?x127 ((_ sign_extend 1) ?x134)))
(let (($x94 (or false false)))
(let (($x27 (or false false false)))
(let (($x157 (or $x27 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x15 (or $x157 $x94 (or (and (distinct (bvadd ((_ sign_extend 1) ?x69) ((_ sign_extend 1) ?x97)) ?x127) true)))))
(let (($x295 (or $x15 false (or (and (distinct (bvsub ?x127 ((_ sign_extend 1) (_ bv65 32))) ?x365) true)))))
(and (not $x295) (or $x295 (and (distinct ?x51 ?x51) true)))))))))))))))
(check-sat)
; query 24: function main, block 74, name %79
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x97 ((_ sign_extend 24) in57_8)))
(let ((?x69 (bvshl in.01_32 (_ bv4 32))))
(let ((?x134 (bvadd ?x69 ?x97)))
(let ((?x51 (bvsub ?x134 (_ bv65 32))))
(let ((?x675 (bvadd ?x51 (_ bv10 32))))
(let (($x179 (and (distinct (bvadd ((_ sign_extend 1) ?x51) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x675)) true)))
(let ((?x365 ((_ sign_extend 1) ?x51)))
(let ((?x127 ((_ sign_extend 1) ?x134)))
(let (($x94 (or false false)))
(let (($x27 (or false false false)))
(let (($x157 (or $x27 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x15 (or $x157 $x94 (or (and (distinct (bvadd ((_ sign_extend 1) ?x69) ((_ sign_extend 1) ?x97)) ?x127) true)))))
(let (($x295 (or $x15 false (or (and (distinct (bvsub ?x127 ((_ sign_extend 1) (_ bv65 32))) ?x365) true)))))
(let (($x111 (or $x295 false (or $x179))))
(and (not $x111) (or $x111 (and (distinct ?x675 ?x675) true))))))))))))))))))
(check-sat)
