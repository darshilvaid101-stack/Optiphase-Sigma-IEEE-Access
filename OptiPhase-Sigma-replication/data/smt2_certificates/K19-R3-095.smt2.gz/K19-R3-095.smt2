; OptiPhase-Sigma refinement certificate for sweep K19-R3-095
; query 0: function init_array, block 21, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.07_32 () (_ BitVec 32))
(assert
 (let (($x53 (and (distinct (bvadd ((_ zero_extend 1) in.07_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.07_32 (_ bv1 32)))) true)))
(let (($x19 (and (distinct (bvadd ((_ sign_extend 1) in.07_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.07_32 (_ bv1 32)))) true)))
(let (($x141 (or (or false false (or $x19 $x53)) (and (distinct (bvadd in.07_32 (_ bv1 32)) (bvadd in.07_32 (_ bv1 32))) true))))
(and (not (or false false (or $x19))) $x141)))))
(check-sat)
; query 1: function kernel_ludcmp, block 108, name %109
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.18_32 () (_ BitVec 32))
(assert
 (let (($x147 (and (distinct (bvadd ((_ zero_extend 1) in.18_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.18_32 (_ bv1 32)))) true)))
(let (($x41 (and (distinct (bvadd ((_ sign_extend 1) in.18_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.18_32 (_ bv1 32)))) true)))
(let (($x61 (or (or false false (or $x41 $x147)) (and (distinct (bvadd in.18_32 (_ bv1 32)) (bvadd in.18_32 (_ bv1 32))) true))))
(and (not (or false false (or $x41))) $x61)))))
(check-sat)
; query 2: function kernel_ludcmp, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_32 () (_ BitVec 32))
(assert
 (let (($x43 (and (distinct (bvadd ((_ zero_extend 1) in.03_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.03_32 (_ bv1 32)))) true)))
(let (($x102 (and (distinct (bvadd ((_ sign_extend 1) in.03_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.03_32 (_ bv1 32)))) true)))
(let (($x126 (or (or false false (or $x102 $x43)) (and (distinct (bvadd in.03_32 (_ bv1 32)) (bvadd in.03_32 (_ bv1 32))) true))))
(and (not (or false false (or $x102))) $x126)))))
(check-sat)
; query 3: function kernel_ludcmp, block 78, name %79
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.14_32 () (_ BitVec 32))
(assert
 (let (($x63 (and (distinct (bvadd ((_ zero_extend 1) in.14_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.14_32 (_ bv1 32)))) true)))
(let (($x26 (and (distinct (bvadd ((_ sign_extend 1) in.14_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.14_32 (_ bv1 32)))) true)))
(let (($x96 (or (or false false (or $x26 $x63)) (and (distinct (bvadd in.14_32 (_ bv1 32)) (bvadd in.14_32 (_ bv1 32))) true))))
(and (not (or false false (or $x26))) $x96)))))
(check-sat)
; query 4: function kernel_ludcmp, block 81, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.07_32 () (_ BitVec 32))
(assert
 (let (($x53 (and (distinct (bvadd ((_ zero_extend 1) in.07_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.07_32 (_ bv1 32)))) true)))
(let (($x19 (and (distinct (bvadd ((_ sign_extend 1) in.07_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.07_32 (_ bv1 32)))) true)))
(let (($x141 (or (or false false (or $x19 $x53)) (and (distinct (bvadd in.07_32 (_ bv1 32)) (bvadd in.07_32 (_ bv1 32))) true))))
(and (not (or false false (or $x19))) $x141)))))
(check-sat)
