; OptiPhase-Sigma refinement certificate for sweep K52-R4-336
; query 0: function s162, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x385 (ite (bvslt (_ bv0 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x146 (or false false false)))
(and (not $x146) (or $x146 (and (distinct ?x385 ?x385) true))))))
(check-sat)
