; OptiPhase-Sigma refinement certificate for sweep K10-R2-032
; query 0: function init_array, block 101, name %102
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.34_32 () (_ BitVec 32))
(assert
 (let (($x150 (and (distinct (bvadd ((_ sign_extend 1) in.34_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.34_32 (_ bv1 32)))) true)))
(let (($x131 (or false false (or $x150))))
(and (not $x131) (or $x131 (and (distinct (bvadd in.34_32 (_ bv1 32)) (bvadd in.34_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function init_array, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x125 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x116 (or false false (or $x125))))
(and (not $x116) (or $x116 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function init_array, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x9 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x19 (or false false (or $x9))))
(and (not $x19) (or $x19 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 3: function init_array, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x64 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x67 (or false false (or $x64))))
(and (not $x67) (or $x67 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 4: function init_array, block 54, name %55
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x79 (and (distinct (bvadd ((_ sign_extend 1) in.12_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.12_32 (_ bv1 32)))) true)))
(let (($x81 (or false false (or $x79))))
(and (not $x81) (or $x81 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 5: function init_array, block 74, name %75
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let (($x18 (and (distinct (bvadd ((_ sign_extend 1) in.2_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.2_32 (_ bv1 32)))) true)))
(let (($x85 (or false false (or $x18))))
(and (not $x85) (or $x85 (and (distinct (bvadd in.2_32 (_ bv1 32)) (bvadd in.2_32 (_ bv1 32))) true))))))
(check-sat)
; query 6: function init_array, block 77, name %78
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.23_32 () (_ BitVec 32))
(assert
 (let (($x44 (and (distinct (bvadd ((_ sign_extend 1) in.23_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.23_32 (_ bv1 32)))) true)))
(let (($x124 (or false false (or $x44))))
(and (not $x124) (or $x124 (and (distinct (bvadd in.23_32 (_ bv1 32)) (bvadd in.23_32 (_ bv1 32))) true))))))
(check-sat)
; query 7: function init_array, block 98, name %99
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.3_32 () (_ BitVec 32))
(assert
 (let (($x31 (and (distinct (bvadd ((_ sign_extend 1) in.3_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.3_32 (_ bv1 32)))) true)))
(let (($x106 (or false false (or $x31))))
(and (not $x106) (or $x106 (and (distinct (bvadd in.3_32 (_ bv1 32)) (bvadd in.3_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function kernel_3mm, block 118, name %119
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let (($x18 (and (distinct (bvadd ((_ sign_extend 1) in.2_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.2_32 (_ bv1 32)))) true)))
(let (($x85 (or false false (or $x18))))
(and (not $x85) (or $x85 (and (distinct (bvadd in.2_32 (_ bv1 32)) (bvadd in.2_32 (_ bv1 32))) true))))))
(check-sat)
; query 9: function kernel_3mm, block 121, name %122
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.23_32 () (_ BitVec 32))
(assert
 (let (($x44 (and (distinct (bvadd ((_ sign_extend 1) in.23_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.23_32 (_ bv1 32)))) true)))
(let (($x124 (or false false (or $x44))))
(and (not $x124) (or $x124 (and (distinct (bvadd in.23_32 (_ bv1 32)) (bvadd in.23_32 (_ bv1 32))) true))))))
(check-sat)
; query 10: function kernel_3mm, block 124, name %125
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.26_32 () (_ BitVec 32))
(assert
 (let (($x56 (and (distinct (bvadd ((_ sign_extend 1) in.26_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.26_32 (_ bv1 32)))) true)))
(let (($x92 (or false false (or $x56))))
(and (not $x92) (or $x92 (and (distinct (bvadd in.26_32 (_ bv1 32)) (bvadd in.26_32 (_ bv1 32))) true))))))
(check-sat)
; query 11: function kernel_3mm, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x125 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x116 (or false false (or $x125))))
(and (not $x116) (or $x116 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 12: function kernel_3mm, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x9 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x19 (or false false (or $x9))))
(and (not $x19) (or $x19 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 13: function kernel_3mm, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let (($x136 (and (distinct (bvadd ((_ sign_extend 1) in.04_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.04_32 (_ bv1 32)))) true)))
(let (($x108 (or false false (or $x136))))
(and (not $x108) (or $x108 (and (distinct (bvadd in.04_32 (_ bv1 32)) (bvadd in.04_32 (_ bv1 32))) true))))))
(check-sat)
; query 14: function kernel_3mm, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x64 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x67 (or false false (or $x64))))
(and (not $x67) (or $x67 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 15: function kernel_3mm, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x79 (and (distinct (bvadd ((_ sign_extend 1) in.12_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.12_32 (_ bv1 32)))) true)))
(let (($x81 (or false false (or $x79))))
(and (not $x81) (or $x81 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 16: function kernel_3mm, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.15_32 () (_ BitVec 32))
(assert
 (let (($x95 (and (distinct (bvadd ((_ sign_extend 1) in.15_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.15_32 (_ bv1 32)))) true)))
(let (($x101 (or false false (or $x95))))
(and (not $x101) (or $x101 (and (distinct (bvadd in.15_32 (_ bv1 32)) (bvadd in.15_32 (_ bv1 32))) true))))))
(check-sat)
; query 17: function polybench_flush_cache, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x9 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x19 (or false false (or $x9))))
(and (not $x19) (or $x19 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 18: function print_array, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x125 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x116 (or false false (or $x125))))
(and (not $x116) (or $x116 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 19: function print_array, block 32, name %33
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x9 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x19 (or false false (or $x9))))
(and (not $x19) (or $x19 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 20: function xmalloc, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in7_32 () (_ BitVec 32))
(assert
 (let ((?x166 (ite (and (distinct (_ bv0 32) in7_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x133 (or false false false)))
(and (not $x133) (or $x133 (and (distinct ?x166 ?x166) true))))))
(check-sat)
