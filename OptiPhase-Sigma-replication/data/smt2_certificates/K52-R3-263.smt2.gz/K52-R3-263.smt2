; OptiPhase-Sigma refinement certificate for sweep K52-R3-263
; query 0: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x22 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x53 (or false false false)))
(let (($x164 (not $x53)))
(and $x164 (or $x53 (and (distinct ?x22 ?x22) true)))))))
(check-sat)
; query 1: function s162, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x254 (ite (bvslt (_ bv0 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x53 (or false false false)))
(let (($x164 (not $x53)))
(and $x164 (or $x53 (and (distinct ?x254 ?x254) true)))))))
(check-sat)
