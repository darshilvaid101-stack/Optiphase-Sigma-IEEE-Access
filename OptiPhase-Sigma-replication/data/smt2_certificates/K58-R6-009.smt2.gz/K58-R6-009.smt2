; OptiPhase-Sigma refinement certificate for sweep K58-R6-009
; query 0: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x753 (or false false false)))
(let (($x426 (not $x753)))
(and $x426 (or $x753 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x33 (bvadd in.01_32 (_ bv1 32))))
(let ((?x720 (bvmul ?x33 ?x33)))
(let (($x753 (or false false false)))
(let (($x83 (or $x753 $x753 false)))
(and (not $x83) (or $x83 (and (distinct ?x720 ?x720) true))))))))
(check-sat)
; query 2: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x33 (bvadd in.01_32 (_ bv1 32))))
(let ((?x720 (bvmul ?x33 ?x33)))
(let ((?x86 (bvmul ?x720 (_ bv2 32))))
(let (($x753 (or false false false)))
(let (($x83 (or $x753 $x753 false)))
(let (($x121 (or $x83 false false)))
(and (not $x121) (or $x121 (and (distinct ?x86 ?x86) true))))))))))
(check-sat)
; query 3: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x33 (bvadd in.01_32 (_ bv1 32))))
(let ((?x720 (bvmul ?x33 ?x33)))
(let ((?x86 (bvmul ?x720 (_ bv2 32))))
(let ((?x374 (bvmul ?x86 (_ bv4 32))))
(let (($x753 (or false false false)))
(let (($x83 (or $x753 $x753 false)))
(let (($x121 (or $x83 false false)))
(let (($x63 (or $x121 false false)))
(and (not $x63) (or $x63 (and (distinct ?x374 ?x374) true))))))))))))
(check-sat)
; query 4: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x790 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x753 (or false false false)))
(let (($x426 (not $x753)))
(and $x426 (or $x753 (and (distinct ?x790 ?x790) true)))))))
(check-sat)
; query 5: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x35 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x753 (or false false false)))
(let (($x426 (not $x753)))
(and $x426 (or $x753 (and (distinct ?x35 ?x35) true)))))))
(check-sat)
; query 6: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x753 (or false false false)))
(let (($x426 (not $x753)))
(and $x426 (or $x753 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 7: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x10 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x148 (or false false (or $x10))))
(and (not $x148) (or $x148 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x142 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x753 (or false false false)))
(let (($x426 (not $x753)))
(and $x426 (or $x753 (and (distinct ?x142 ?x142) true)))))))
(check-sat)
; query 9: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x477 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x753 (or false false false)))
(let (($x426 (not $x753)))
(and $x426 (or $x753 (and (distinct ?x477 ?x477) true)))))))
(check-sat)
; query 10: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x564 (or false false)))
(and (not $x564) (or $x564 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true)))))
(check-sat)
; query 11: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x98 ((_ sign_extend 16) in.1_16)))
(let ((?x420 (bvadd ?x98 (_ bv10 32))))
(let (($x329 (and (distinct (bvadd ((_ sign_extend 1) ?x98) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x420)) true)))
(let (($x564 (or false false)))
(let (($x927 (or $x564 false (or $x329))))
(and (not $x927) (or $x927 (and (distinct ?x420 ?x420) true)))))))))
(check-sat)
; query 12: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x98 ((_ sign_extend 16) in.1_16)))
(let ((?x420 (bvadd ?x98 (_ bv10 32))))
(let ((?x586 ((_ extract 15 0) ?x420)))
(let (($x329 (and (distinct (bvadd ((_ sign_extend 1) ?x98) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x420)) true)))
(let (($x564 (or false false)))
(let (($x927 (or $x564 false (or $x329))))
(let (($x91 (or $x927 false)))
(and (not $x91) (or $x91 (and (distinct ?x586 ?x586) true)))))))))))
(check-sat)
; query 13: function matrix_sum, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x490 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x753 (or false false false)))
(let (($x426 (not $x753)))
(and $x426 (or $x753 (and (distinct ?x490 ?x490) true)))))))
(check-sat)
; query 14: function matrix_sum, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x490 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let ((?x307 ((_ zero_extend 63) ?x490)))
(let (($x753 (or false false false)))
(let (($x543 (or $x753 false)))
(and (not $x543) (or $x543 (and (distinct ?x307 ?x307) true))))))))
(check-sat)
; query 15: function matrix_sum, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x490 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x2782 (= (_ bv1 1) ?x490)))
(let ((?x59 (ite $x2782 (_ bv1 32) (_ bv0 32))))
(let (($x753 (or false false false)))
(let (($x54 (or $x753 (ite $x2782 false false))))
(and (not $x54) (or $x54 (and (distinct ?x59 ?x59) true)))))))))
(check-sat)
; query 16: function matrix_sum, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x564 (or false false)))
(and (not $x564) (or $x564 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true)))))
(check-sat)
; query 17: function matrix_sum, block 22, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x490 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x2782 (= (_ bv1 1) ?x490)))
(let ((?x59 (ite $x2782 (_ bv1 32) (_ bv0 32))))
(let ((?x98 ((_ sign_extend 16) in.1_16)))
(let ((?x28 (bvadd ?x98 ?x59)))
(let (($x156 (and (distinct (bvadd ((_ sign_extend 1) ?x98) ((_ sign_extend 1) ?x59)) ((_ sign_extend 1) ?x28)) true)))
(let (($x753 (or false false false)))
(let (($x54 (or $x753 (ite $x2782 false false))))
(let (($x564 (or false false)))
(let (($x19 (or $x564 $x54 (or $x156))))
(and (not $x19) (or $x19 (and (distinct ?x28 ?x28) true))))))))))))))
(check-sat)
; query 18: function matrix_sum, block 22, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x490 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x2782 (= (_ bv1 1) ?x490)))
(let ((?x59 (ite $x2782 (_ bv1 32) (_ bv0 32))))
(let ((?x98 ((_ sign_extend 16) in.1_16)))
(let ((?x28 (bvadd ?x98 ?x59)))
(let ((?x159 ((_ extract 15 0) ?x28)))
(let (($x156 (and (distinct (bvadd ((_ sign_extend 1) ?x98) ((_ sign_extend 1) ?x59)) ((_ sign_extend 1) ?x28)) true)))
(let (($x753 (or false false false)))
(let (($x54 (or $x753 (ite $x2782 false false))))
(let (($x564 (or false false)))
(let (($x19 (or $x564 $x54 (or $x156))))
(let (($x544 (or $x19 false)))
(and (not $x544) (or $x544 (and (distinct ?x159 ?x159) true))))))))))))))))
(check-sat)
