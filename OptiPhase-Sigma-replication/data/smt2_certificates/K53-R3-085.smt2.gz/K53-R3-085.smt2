; OptiPhase-Sigma refinement certificate for sweep K53-R3-085
; query 0: function check, block 103, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x77 (ite (= (_ bv22 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x83 (or false false false)))
(let (($x67 (not $x83)))
(and $x67 (or $x83 (and (distinct ?x77 (ite (= (_ bv0 32) in0_32) (_ bv1 1) (_ bv0 1))) true)))))))
(check-sat)
; query 1: function check, block 109, name %110
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x623 (ite (= (_ bv33 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x83 (or false false false)))
(let (($x67 (not $x83)))
(and $x67 (or $x83 (and (distinct ?x623 (ite (= (_ bv12 32) in0_32) (_ bv1 1) (_ bv0 1))) true)))))))
(check-sat)
; query 2: function check, block 67, name %68
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x1655 (ite (= (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x83 (or false false false)))
(let (($x67 (not $x83)))
(and $x67 (or $x83 (and (distinct (ite (= (_ bv1 32) in0_32) (_ bv1 1) (_ bv0 1)) ?x1655) true)))))))
(check-sat)
; query 3: function check, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x1380 (ite (= (_ bv4 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x83 (or false false false)))
(let (($x67 (not $x83)))
(and $x67 (or $x83 (and (distinct (ite (= (_ bv2 32) in0_32) (_ bv1 1) (_ bv0 1)) ?x1380) true)))))))
(check-sat)
; query 4: function check, block 79, name %80
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x1167 (ite (= (_ bv5 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let ((?x1655 (ite (= (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x83 (or false false false)))
(let (($x67 (not $x83)))
(and $x67 (or $x83 (and (distinct ?x1655 ?x1167) true))))))))
(check-sat)
; query 5: function check, block 85, name %86
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x217 (ite (= (_ bv11 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let ((?x1380 (ite (= (_ bv4 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x83 (or false false false)))
(let (($x67 (not $x83)))
(and $x67 (or $x83 (and (distinct ?x1380 ?x217) true))))))))
(check-sat)
; query 6: function check, block 91, name %92
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x77 (ite (= (_ bv22 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let ((?x1167 (ite (= (_ bv5 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x83 (or false false false)))
(let (($x67 (not $x83)))
(and $x67 (or $x83 (and (distinct ?x1167 ?x77) true))))))))
(check-sat)
; query 7: function check, block 97, name %98
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x623 (ite (= (_ bv33 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let ((?x217 (ite (= (_ bv11 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x83 (or false false false)))
(let (($x67 (not $x83)))
(and $x67 (or $x83 (and (distinct ?x217 ?x623) true))))))))
(check-sat)
; query 8: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x609 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x83 (or false false false)))
(let (($x67 (not $x83)))
(and $x67 (or $x83 (and (distinct ?x609 ?x609) true)))))))
(check-sat)
; query 9: function set1d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x59 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x83 (or false false false)))
(let (($x67 (not $x83)))
(and $x67 (or $x83 (and (distinct ?x59 ?x59) true)))))))
(check-sat)
; query 10: function set1ds, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x821 (ite (= (_ bv4294967295 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x83 (or false false false)))
(let (($x67 (not $x83)))
(and $x67 (or $x83 (and (distinct ?x821 ?x821) true)))))))
(check-sat)
; query 11: function set2d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x59 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x83 (or false false false)))
(let (($x67 (not $x83)))
(and $x67 (or $x83 (and (distinct ?x59 ?x59) true)))))))
(check-sat)
