; OptiPhase-Sigma refinement certificate for sweep K26-R6-043
