; OptiPhase-Sigma refinement certificate for sweep K58-R3-293
; query 0: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x697 (or false false)))
(let (($x466 (not $x697)))
(and $x466 (or $x697 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 1: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x651 ((_ sign_extend 16) in3_16)))
(let ((?x210 (bvand ?x651 (_ bv127 32))))
(let (($x697 (or false false)))
(let (($x187 (or $x697 false false)))
(let (($x674 (not $x187)))
(and $x674 (or $x187 (and (distinct ?x210 ?x210) true)))))))))
(check-sat)
; query 2: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x651 ((_ sign_extend 16) in3_16)))
(let ((?x210 (bvand ?x651 (_ bv127 32))))
(let ((?x1332 ((_ extract 15 0) ?x210)))
(let (($x697 (or false false)))
(let (($x187 (or $x697 false false)))
(let (($x476 (or $x187 false)))
(let (($x868 (not $x476)))
(and $x868 (or $x476 (and (distinct ?x1332 ?x1332) true)))))))))))
(check-sat)
; query 3: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x697 (or false false)))
(let (($x466 (not $x697)))
(and $x466 (or $x697 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 4: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x443 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x697 (or false false)))
(let (($x187 (or $x697 false false)))
(let (($x674 (not $x187)))
(and $x674 (or $x187 (and (distinct ?x443 ?x443) true))))))))
(check-sat)
; query 5: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x57 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x47 (or false false false)))
(let (($x1588 (not $x47)))
(and $x1588 (or $x47 (and (distinct ?x57 ?x57) true)))))))
(check-sat)
; query 6: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x101 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x47 (or false false false)))
(let (($x1588 (not $x47)))
(and $x1588 (or $x47 (and (distinct ?x101 ?x101) true)))))))
(check-sat)
; query 7: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x47 (or false false false)))
(let (($x1588 (not $x47)))
(and $x1588 (or $x47 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 8: function crcu8, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x697 (or false false)))
(let (($x466 (not $x697)))
(and $x466 (or $x697 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 9: function crcu8, block 19, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x1395 ((_ zero_extend 16) in.01_16)))
(let ((?x51 (bvxor ?x1395 (_ bv16386 32))))
(let (($x697 (or false false)))
(let (($x187 (or $x697 false false)))
(let (($x674 (not $x187)))
(and $x674 (or $x187 (and (distinct ?x51 ?x51) true)))))))))
(check-sat)
; query 10: function crcu8, block 19, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x1395 ((_ zero_extend 16) in.01_16)))
(let ((?x51 (bvxor ?x1395 (_ bv16386 32))))
(let ((?x104 ((_ extract 15 0) ?x51)))
(let (($x697 (or false false)))
(let (($x187 (or $x697 false false)))
(let (($x476 (or $x187 false)))
(let (($x868 (not $x476)))
(and $x868 (or $x476 (and (distinct ?x104 ?x104) true)))))))))))
(check-sat)
; query 11: function crcu8, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x796 ((_ extract 7 0) in.01_16)))
(let ((?x901 ((_ zero_extend 24) ?x796)))
(let (($x697 (or false false)))
(let (($x338 (or $x697 false)))
(and (not $x338) (or $x338 (and (distinct ?x901 ?x901) true))))))))
(check-sat)
; query 12: function crcu8, block 6, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x796 ((_ extract 7 0) in.01_16)))
(let ((?x901 ((_ zero_extend 24) ?x796)))
(let ((?x132 (bvand ?x901 (_ bv1 32))))
(let (($x697 (or false false)))
(let (($x338 (or $x697 false)))
(let (($x158 (or $x338 false false)))
(and (not $x158) (or $x158 (and (distinct ?x132 ?x132) true))))))))))
(check-sat)
; query 13: function crcu8, block 6, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x796 ((_ extract 7 0) in.01_16)))
(let ((?x901 ((_ zero_extend 24) ?x796)))
(let ((?x132 (bvand ?x901 (_ bv1 32))))
(let ((?x1344 ((_ zero_extend 24) in.0_8)))
(let ((?x71 (bvand ?x1344 (_ bv1 32))))
(let ((?x347 (bvxor ?x71 ?x132)))
(let (($x697 (or false false)))
(let (($x338 (or $x697 false)))
(let (($x158 (or $x338 false false)))
(let (($x187 (or $x697 false false)))
(let (($x62 (or $x187 $x158 false)))
(and (not $x62) (or $x62 (and (distinct ?x347 ?x347) true)))))))))))))))
(check-sat)
; query 14: function crcu8, block 6, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x796 ((_ extract 7 0) in.01_16)))
(let ((?x901 ((_ zero_extend 24) ?x796)))
(let ((?x132 (bvand ?x901 (_ bv1 32))))
(let ((?x1344 ((_ zero_extend 24) in.0_8)))
(let ((?x71 (bvand ?x1344 (_ bv1 32))))
(let ((?x347 (bvxor ?x71 ?x132)))
(let ((?x785 ((_ extract 7 0) ?x347)))
(let (($x697 (or false false)))
(let (($x338 (or $x697 false)))
(let (($x158 (or $x338 false false)))
(let (($x187 (or $x697 false false)))
(let (($x62 (or $x187 $x158 false)))
(let (($x73 (or $x62 false)))
(and (not $x73) (or $x73 (and (distinct ?x785 ?x785) true)))))))))))))))))
(check-sat)
; query 15: function crcu8, block 6, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x697 (or false false)))
(let (($x466 (not $x697)))
(and $x466 (or $x697 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 16: function crcu8, block 6, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1344 ((_ zero_extend 24) in.0_8)))
(let ((?x238 (bvashr ?x1344 (_ bv1 32))))
(let (($x697 (or false false)))
(let (($x187 (or $x697 false false)))
(let (($x328 (or $x187 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not $x328) (or $x328 (and (distinct ?x238 ?x238) true)))))))))
(check-sat)
; query 17: function crcu8, block 6, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1344 ((_ zero_extend 24) in.0_8)))
(let ((?x238 (bvashr ?x1344 (_ bv1 32))))
(let ((?x440 ((_ extract 7 0) ?x238)))
(let (($x697 (or false false)))
(let (($x187 (or $x697 false false)))
(let (($x328 (or $x187 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x382 (or $x328 false)))
(and (not $x382) (or $x382 (and (distinct ?x440 ?x440) true)))))))))))
(check-sat)
; query 18: function crcu8, block 6, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x796 ((_ extract 7 0) in.01_16)))
(let ((?x901 ((_ zero_extend 24) ?x796)))
(let ((?x132 (bvand ?x901 (_ bv1 32))))
(let ((?x1344 ((_ zero_extend 24) in.0_8)))
(let ((?x71 (bvand ?x1344 (_ bv1 32))))
(let ((?x347 (bvxor ?x71 ?x132)))
(let ((?x785 ((_ extract 7 0) ?x347)))
(let ((?x123 ((_ zero_extend 24) ?x785)))
(let (($x697 (or false false)))
(let (($x338 (or $x697 false)))
(let (($x158 (or $x338 false false)))
(let (($x187 (or $x697 false false)))
(let (($x62 (or $x187 $x158 false)))
(let (($x73 (or $x62 false)))
(let (($x298 (or $x73 false)))
(and (not $x298) (or $x298 (and (distinct ?x123 ?x123) true)))))))))))))))))))
(check-sat)
; query 19: function crcu8, block 6, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x796 ((_ extract 7 0) in.01_16)))
(let ((?x901 ((_ zero_extend 24) ?x796)))
(let ((?x132 (bvand ?x901 (_ bv1 32))))
(let ((?x1344 ((_ zero_extend 24) in.0_8)))
(let ((?x71 (bvand ?x1344 (_ bv1 32))))
(let ((?x347 (bvxor ?x71 ?x132)))
(let ((?x785 ((_ extract 7 0) ?x347)))
(let ((?x123 ((_ zero_extend 24) ?x785)))
(let ((?x126 (ite (= (_ bv1 32) ?x123) (_ bv1 1) (_ bv0 1))))
(let (($x697 (or false false)))
(let (($x338 (or $x697 false)))
(let (($x158 (or $x338 false false)))
(let (($x187 (or $x697 false false)))
(let (($x62 (or $x187 $x158 false)))
(let (($x73 (or $x62 false)))
(let (($x298 (or $x73 false)))
(let (($x15 (or $x298 false false)))
(and (not $x15) (or $x15 (and (distinct ?x126 ?x126) true)))))))))))))))))))))
(check-sat)
; query 20: function crcu8, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x697 (or false false)))
(let (($x466 (not $x697)))
(and $x466 (or $x697 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 21: function crcu8, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1344 ((_ zero_extend 24) in.0_8)))
(let ((?x71 (bvand ?x1344 (_ bv1 32))))
(let (($x697 (or false false)))
(let (($x187 (or $x697 false false)))
(let (($x674 (not $x187)))
(and $x674 (or $x187 (and (distinct ?x71 ?x71) true)))))))))
(check-sat)
; query 22: function crcu8, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x697 (or false false)))
(let (($x466 (not $x697)))
(and $x466 (or $x697 (and (distinct ((_ extract 7 0) in.01_16) ((_ extract 7 0) in.01_16)) true))))))
(check-sat)
; query 23: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x602 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x8 ((_ zero_extend 31) ?x602)))
(let ((?x131 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x137 ((_ zero_extend 31) ?x131)))
(let ((?x1078 (bvand ?x137 ?x8)))
(let ((?x703 (ite (and (distinct (_ bv0 32) ?x1078) true) (_ bv1 1) (_ bv0 1))))
(let ((?x174 ((_ zero_extend 63) ?x703)))
(let (($x697 (or false false)))
(let (($x187 (or $x697 false false)))
(let (($x476 (or $x187 false)))
(let (($x273 (or $x476 $x476 false)))
(let (($x458 (or $x273 false false)))
(let (($x121 (or $x458 false)))
(and (not $x121) (or $x121 (and (distinct ?x174 ?x174) true)))))))))))))))))
(check-sat)
; query 24: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x602 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x8 ((_ zero_extend 31) ?x602)))
(let ((?x131 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x137 ((_ zero_extend 31) ?x131)))
(let ((?x1078 (bvand ?x137 ?x8)))
(let ((?x703 (ite (and (distinct (_ bv0 32) ?x1078) true) (_ bv1 1) (_ bv0 1))))
(let (($x1346 (= (_ bv1 1) ?x703)))
(let ((?x289 (ite $x1346 (_ bv1 32) (_ bv0 32))))
(let (($x697 (or false false)))
(let (($x187 (or $x697 false false)))
(let (($x476 (or $x187 false)))
(let (($x273 (or $x476 $x476 false)))
(let (($x458 (or $x273 false false)))
(let (($x108 (or $x458 (ite $x1346 false false))))
(and (not $x108) (or $x108 (and (distinct ?x289 ?x289) true))))))))))))))))))
(check-sat)
; query 25: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x602 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x8 ((_ zero_extend 31) ?x602)))
(let ((?x131 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x137 ((_ zero_extend 31) ?x131)))
(let ((?x1078 (bvand ?x137 ?x8)))
(let ((?x703 (ite (and (distinct (_ bv0 32) ?x1078) true) (_ bv1 1) (_ bv0 1))))
(let (($x1346 (= (_ bv1 1) ?x703)))
(let ((?x289 (ite $x1346 (_ bv1 32) (_ bv0 32))))
(let ((?x48 ((_ extract 7 0) ?x289)))
(let (($x697 (or false false)))
(let (($x187 (or $x697 false false)))
(let (($x476 (or $x187 false)))
(let (($x273 (or $x476 $x476 false)))
(let (($x458 (or $x273 false false)))
(let (($x108 (or $x458 (ite $x1346 false false))))
(let (($x308 (or $x108 false)))
(and (not $x308) (or $x308 (and (distinct ?x48 ?x48) true))))))))))))))))))))
(check-sat)
; query 26: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x697 (or false false)))
(let (($x466 (not $x697)))
(and $x466 (or $x697 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 27: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x131 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x697 (or false false)))
(let (($x187 (or $x697 false false)))
(let (($x674 (not $x187)))
(and $x674 (or $x187 (and (distinct ?x131 ?x131) true))))))))
(check-sat)
; query 28: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x131 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x137 ((_ zero_extend 31) ?x131)))
(let (($x697 (or false false)))
(let (($x187 (or $x697 false false)))
(let (($x476 (or $x187 false)))
(let (($x868 (not $x476)))
(and $x868 (or $x476 (and (distinct ?x137 ?x137) true))))))))))
(check-sat)
; query 29: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x697 (or false false)))
(let (($x466 (not $x697)))
(and $x466 (or $x697 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 30: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x602 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x697 (or false false)))
(let (($x187 (or $x697 false false)))
(let (($x674 (not $x187)))
(and $x674 (or $x187 (and (distinct ?x602 ?x602) true))))))))
(check-sat)
; query 31: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x602 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x8 ((_ zero_extend 31) ?x602)))
(let (($x697 (or false false)))
(let (($x187 (or $x697 false false)))
(let (($x476 (or $x187 false)))
(let (($x868 (not $x476)))
(and $x868 (or $x476 (and (distinct ?x8 ?x8) true))))))))))
(check-sat)
; query 32: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x602 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x8 ((_ zero_extend 31) ?x602)))
(let ((?x131 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x137 ((_ zero_extend 31) ?x131)))
(let ((?x1078 (bvand ?x137 ?x8)))
(let (($x697 (or false false)))
(let (($x187 (or $x697 false false)))
(let (($x476 (or $x187 false)))
(let (($x273 (or $x476 $x476 false)))
(and (not $x273) (or $x273 (and (distinct ?x1078 ?x1078) true)))))))))))))
(check-sat)
; query 33: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x602 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x8 ((_ zero_extend 31) ?x602)))
(let ((?x131 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x137 ((_ zero_extend 31) ?x131)))
(let ((?x1078 (bvand ?x137 ?x8)))
(let ((?x703 (ite (and (distinct (_ bv0 32) ?x1078) true) (_ bv1 1) (_ bv0 1))))
(let (($x697 (or false false)))
(let (($x187 (or $x697 false false)))
(let (($x476 (or $x187 false)))
(let (($x273 (or $x476 $x476 false)))
(let (($x458 (or $x273 false false)))
(and (not $x458) (or $x458 (and (distinct ?x703 ?x703) true)))))))))))))))
(check-sat)
; query 34: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x701 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x47 (or false false false)))
(let (($x1588 (not $x47)))
(and $x1588 (or $x47 (and (distinct ?x701 ?x701) true)))))))
(check-sat)
