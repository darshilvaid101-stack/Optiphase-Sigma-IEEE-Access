; OptiPhase-Sigma refinement certificate for sweep K50-R5-373
; query 0: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x178 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x622 (or false false false)))
(and (not $x622) (or $x622 (and (distinct ?x178 ?x178) true))))))
(check-sat)
