; OptiPhase-Sigma refinement certificate for sweep K55-R1-000
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x756 (or false false)))
(let (($x24 (not $x756)))
(and $x24 (or $x756 (and (distinct ((_ sign_extend 16) in25_16) ((_ sign_extend 16) in25_16)) true))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let ((?x222 (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))))
(let (($x756 (or false false)))
(let (($x269 (or $x756 false false)))
(let (($x119 (not $x269)))
(and $x119 (or $x269 (and (distinct ?x222 ?x222) true))))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x756 (or false false)))
(let (($x24 (not $x756)))
(and $x24 (or $x756 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x323 ((_ sign_extend 16) in3_16)))
(let ((?x7 (bvand ?x323 (_ bv127 32))))
(let (($x756 (or false false)))
(let (($x269 (or $x756 false false)))
(let (($x119 (not $x269)))
(and $x119 (or $x269 (and (distinct ?x7 ?x7) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x323 ((_ sign_extend 16) in3_16)))
(let ((?x7 (bvand ?x323 (_ bv127 32))))
(let ((?x1362 ((_ extract 15 0) ?x7)))
(let (($x756 (or false false)))
(let (($x269 (or $x756 false false)))
(let (($x230 (or $x269 false)))
(let (($x86 (not $x230)))
(and $x86 (or $x230 (and (distinct ?x1362 ?x1362) true)))))))))))
(check-sat)
; query 5: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x756 (or false false)))
(let (($x24 (not $x756)))
(and $x24 (or $x756 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 6: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x339 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x756 (or false false)))
(let (($x269 (or $x756 false false)))
(let (($x119 (not $x269)))
(and $x119 (or $x269 (and (distinct ?x339 ?x339) true))))))))
(check-sat)
; query 7: function core_bench_list, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x80 (or false false false)))
(let (($x800 (not $x80)))
(and $x800 (or $x80 (and (distinct (bvadd in.0_16 (_ bv1 16)) (bvadd in.0_16 (_ bv1 16))) true))))))
(check-sat)
; query 8: function core_bench_state, block 105, name %106
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x80 (or false false false)))
(let (($x800 (not $x80)))
(and $x800 (or $x80 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 9: function core_bench_state, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x80 (or false false false)))
(let (($x800 (not $x80)))
(and $x800 (or $x80 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 10: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1273 (bvadd in.01_32 (_ bv1 32))))
(let (($x1011 (and (distinct ?x1273 ?x1273) true)))
(let (($x80 (or false false false)))
(let (($x800 (not $x80)))
(and $x800 (or $x80 $x1011)))))))
(check-sat)
; query 11: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1273 (bvadd in.01_32 (_ bv1 32))))
(let ((?x832 (bvmul ?x1273 ?x1273)))
(let (($x80 (or false false false)))
(let (($x76 (or $x80 $x80 false)))
(and (not $x76) (or $x76 (and (distinct ?x832 ?x832) true))))))))
(check-sat)
; query 12: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1273 (bvadd in.01_32 (_ bv1 32))))
(let ((?x832 (bvmul ?x1273 ?x1273)))
(let ((?x639 (bvmul ?x832 (_ bv2 32))))
(let (($x80 (or false false false)))
(let (($x76 (or $x80 $x80 false)))
(let (($x117 (or $x76 false false)))
(and (not $x117) (or $x117 (and (distinct ?x639 ?x639) true))))))))))
(check-sat)
; query 13: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1273 (bvadd in.01_32 (_ bv1 32))))
(let ((?x832 (bvmul ?x1273 ?x1273)))
(let ((?x639 (bvmul ?x832 (_ bv2 32))))
(let ((?x523 (bvmul ?x639 (_ bv4 32))))
(let (($x80 (or false false false)))
(let (($x76 (or $x80 $x80 false)))
(let (($x117 (or $x76 false false)))
(let (($x102 (or $x117 false false)))
(and (not $x102) (or $x102 (and (distinct ?x523 ?x523) true))))))))))))
(check-sat)
; query 14: function core_init_matrix, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x80 (or false false false)))
(let (($x800 (not $x80)))
(and $x800 (or $x80 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 15: function core_init_matrix, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x80 (or false false false)))
(let (($x800 (not $x80)))
(and $x800 (or $x80 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 16: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x601 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x80 (or false false false)))
(let (($x800 (not $x80)))
(and $x800 (or $x80 (and (distinct ?x601 ?x601) true)))))))
(check-sat)
; query 17: function core_init_state, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_32 () (_ BitVec 32))
(assert
 (let (($x80 (or false false false)))
(let (($x800 (not $x80)))
(and $x800 (or $x80 (and (distinct (bvadd in.06_32 (_ bv1 32)) (bvadd in.06_32 (_ bv1 32))) true))))))
(check-sat)
; query 18: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x109 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x80 (or false false false)))
(let (($x800 (not $x80)))
(and $x800 (or $x80 (and (distinct ?x109 ?x109) true)))))))
(check-sat)
; query 19: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x80 (or false false false)))
(let (($x800 (not $x80)))
(and $x800 (or $x80 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 20: function core_list_init, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1273 (bvadd in.01_32 (_ bv1 32))))
(let (($x1011 (and (distinct ?x1273 ?x1273) true)))
(let (($x80 (or false false false)))
(let (($x800 (not $x80)))
(and $x800 (or $x80 $x1011)))))))
(check-sat)
; query 21: function core_list_mergesort, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1273 (bvadd in.01_32 (_ bv1 32))))
(let (($x1011 (and (distinct ?x1273 ?x1273) true)))
(let (($x101 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x1273)) true)))
(let (($x806 (or false false (or $x101))))
(and (not $x806) (or $x806 $x1011)))))))
(check-sat)
; query 22: function core_list_mergesort, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x120 (ite (bvslt (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x80 (or false false false)))
(let (($x800 (not $x80)))
(and $x800 (or $x80 (and (distinct ?x120 ?x120) true)))))))
(check-sat)
; query 23: function core_list_mergesort, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.224_32 () (_ BitVec 32))
(assert
 (let ((?x35 (ite (= (_ bv0 32) in.224_32) (_ bv1 1) (_ bv0 1))))
(let (($x80 (or false false false)))
(let (($x800 (not $x80)))
(and $x800 (or $x80 (and (distinct ?x35 ?x35) true)))))))
(check-sat)
; query 24: function core_list_mergesort, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x215 (ite (= (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x80 (or false false false)))
(let (($x800 (not $x80)))
(and $x800 (or $x80 (and (distinct ?x215 ?x215) true)))))))
(check-sat)
; query 25: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x490 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x1223 (or false false (or $x490))))
(and (not $x1223) (or $x1223 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 26: function core_list_mergesort, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x575 (and (distinct (bvmul ((_ sign_extend 32) in.020_32) ((_ sign_extend 32) (_ bv2 32))) ((_ sign_extend 32) (bvmul in.020_32 (_ bv2 32)))) true)))
(let (($x178 (or false false (or $x575))))
(and (not $x178) (or $x178 (and (distinct (bvmul in.020_32 (_ bv2 32)) (bvmul in.020_32 (_ bv2 32))) true))))))
(check-sat)
; query 27: function core_state_transition, block 102, name %103
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x756 (or false false)))
(let (($x24 (not $x756)))
(and $x24 (or $x756 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 28: function core_state_transition, block 102, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x413 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x756 (or false false)))
(let (($x269 (or $x756 false false)))
(let (($x119 (not $x269)))
(and $x119 (or $x269 (and (distinct ?x413 ?x413) true))))))))
(check-sat)
; query 29: function core_state_transition, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x756 (or false false)))
(let (($x24 (not $x756)))
(and $x24 (or $x756 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 30: function core_state_transition, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x292 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x756 (or false false)))
(let (($x269 (or $x756 false false)))
(let (($x119 (not $x269)))
(and $x119 (or $x269 (and (distinct ?x292 ?x292) true))))))))
(check-sat)
; query 31: function core_state_transition, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x756 (or false false)))
(let (($x24 (not $x756)))
(and $x24 (or $x756 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 32: function core_state_transition, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x413 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x756 (or false false)))
(let (($x269 (or $x756 false false)))
(let (($x119 (not $x269)))
(and $x119 (or $x269 (and (distinct ?x413 ?x413) true))))))))
(check-sat)
; query 33: function core_state_transition, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x756 (or false false)))
(let (($x24 (not $x756)))
(and $x24 (or $x756 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 34: function core_state_transition, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x497 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x756 (or false false)))
(let (($x269 (or $x756 false false)))
(let (($x119 (not $x269)))
(and $x119 (or $x269 (and (distinct ?x497 ?x497) true))))))))
(check-sat)
; query 35: function core_state_transition, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x756 (or false false)))
(let (($x24 (not $x756)))
(and $x24 (or $x756 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 36: function core_state_transition, block 51, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x497 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x756 (or false false)))
(let (($x269 (or $x756 false false)))
(let (($x119 (not $x269)))
(and $x119 (or $x269 (and (distinct ?x497 ?x497) true))))))))
(check-sat)
; query 37: function core_state_transition, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x756 (or false false)))
(let (($x24 (not $x756)))
(and $x24 (or $x756 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 38: function core_state_transition, block 64, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x497 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x756 (or false false)))
(let (($x269 (or $x756 false false)))
(let (($x119 (not $x269)))
(and $x119 (or $x269 (and (distinct ?x497 ?x497) true))))))))
(check-sat)
; query 39: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x30 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x80 (or false false false)))
(let (($x800 (not $x80)))
(and $x800 (or $x80 (and (distinct ?x30 ?x30) true)))))))
(check-sat)
; query 40: function core_state_transition, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x756 (or false false)))
(let (($x24 (not $x756)))
(and $x24 (or $x756 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 41: function core_state_transition, block 80, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1277 (ite (= (_ bv69 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x756 (or false false)))
(let (($x269 (or $x756 false false)))
(let (($x119 (not $x269)))
(and $x119 (or $x269 (and (distinct ?x1277 ?x1277) true))))))))
(check-sat)
; query 42: function core_state_transition, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x756 (or false false)))
(let (($x24 (not $x756)))
(and $x24 (or $x756 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 43: function core_state_transition, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1301 (ite (= (_ bv101 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x756 (or false false)))
(let (($x269 (or $x756 false false)))
(let (($x119 (not $x269)))
(and $x119 (or $x269 (and (distinct ?x1301 ?x1301) true))))))))
(check-sat)
; query 44: function core_state_transition, block 99, name %100
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x756 (or false false)))
(let (($x24 (not $x756)))
(and $x24 (or $x756 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 45: function core_state_transition, block 99, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x292 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x756 (or false false)))
(let (($x269 (or $x756 false false)))
(let (($x119 (not $x269)))
(and $x119 (or $x269 (and (distinct ?x292 ?x292) true))))))))
(check-sat)
; query 46: function crcu8, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x756 (or false false)))
(let (($x24 (not $x756)))
(and $x24 (or $x756 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 47: function crcu8, block 19, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x1330 ((_ zero_extend 16) in.01_16)))
(let ((?x1337 (bvxor ?x1330 (_ bv16386 32))))
(let (($x756 (or false false)))
(let (($x269 (or $x756 false false)))
(let (($x119 (not $x269)))
(and $x119 (or $x269 (and (distinct ?x1337 ?x1337) true)))))))))
(check-sat)
; query 48: function crcu8, block 19, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x1330 ((_ zero_extend 16) in.01_16)))
(let ((?x1337 (bvxor ?x1330 (_ bv16386 32))))
(let ((?x1338 ((_ extract 15 0) ?x1337)))
(let (($x756 (or false false)))
(let (($x269 (or $x756 false false)))
(let (($x230 (or $x269 false)))
(let (($x86 (not $x230)))
(and $x86 (or $x230 (and (distinct ?x1338 ?x1338) true)))))))))))
(check-sat)
; query 49: function crcu8, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x756 (or false false)))
(let (($x24 (not $x756)))
(and $x24 (or $x756 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 50: function crcu8, block 29, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x9 ((_ zero_extend 16) in27_16)))
(let ((?x258 (bvor ?x9 (_ bv32768 32))))
(let (($x756 (or false false)))
(let (($x269 (or $x756 false false)))
(let (($x119 (not $x269)))
(and $x119 (or $x269 (and (distinct ?x258 ?x258) true)))))))))
(check-sat)
; query 51: function crcu8, block 29, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x9 ((_ zero_extend 16) in27_16)))
(let ((?x258 (bvor ?x9 (_ bv32768 32))))
(let ((?x232 ((_ extract 15 0) ?x258)))
(let (($x756 (or false false)))
(let (($x269 (or $x756 false false)))
(let (($x230 (or $x269 false)))
(let (($x86 (not $x230)))
(and $x86 (or $x230 (and (distinct ?x232 ?x232) true)))))))))))
(check-sat)
; query 52: function crcu8, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x756 (or false false)))
(let (($x24 (not $x756)))
(and $x24 (or $x756 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 53: function crcu8, block 33, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x9 ((_ zero_extend 16) in27_16)))
(let ((?x614 (bvand ?x9 (_ bv32767 32))))
(let (($x756 (or false false)))
(let (($x269 (or $x756 false false)))
(let (($x119 (not $x269)))
(and $x119 (or $x269 (and (distinct ?x614 ?x614) true)))))))))
(check-sat)
; query 54: function crcu8, block 33, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x9 ((_ zero_extend 16) in27_16)))
(let ((?x614 (bvand ?x9 (_ bv32767 32))))
(let ((?x1371 ((_ extract 15 0) ?x614)))
(let (($x756 (or false false)))
(let (($x269 (or $x756 false false)))
(let (($x230 (or $x269 false)))
(let (($x86 (not $x230)))
(and $x86 (or $x230 (and (distinct ?x1371 ?x1371) true)))))))))))
(check-sat)
; query 55: function crcu8, block 38, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_8 () (_ BitVec 8))
(assert
 (let (($x80 (or false false false)))
(let (($x800 (not $x80)))
(and $x800 (or $x80 (and (distinct (bvadd in.02_8 (_ bv1 8)) (bvadd in.02_8 (_ bv1 8))) true))))))
(check-sat)
; query 56: function crcu8, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x1353 ((_ extract 7 0) in.01_16)))
(let ((?x1381 ((_ zero_extend 24) ?x1353)))
(let (($x756 (or false false)))
(let (($x280 (or $x756 false)))
(and (not $x280) (or $x280 (and (distinct ?x1381 ?x1381) true))))))))
(check-sat)
; query 57: function crcu8, block 6, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x1353 ((_ extract 7 0) in.01_16)))
(let ((?x1381 ((_ zero_extend 24) ?x1353)))
(let ((?x438 (bvand ?x1381 (_ bv1 32))))
(let (($x756 (or false false)))
(let (($x280 (or $x756 false)))
(let (($x789 (or $x280 false false)))
(and (not $x789) (or $x789 (and (distinct ?x438 ?x438) true))))))))))
(check-sat)
; query 58: function crcu8, block 6, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1353 ((_ extract 7 0) in.01_16)))
(let ((?x1381 ((_ zero_extend 24) ?x1353)))
(let ((?x438 (bvand ?x1381 (_ bv1 32))))
(let ((?x1343 ((_ zero_extend 24) in.0_8)))
(let ((?x88 (bvand ?x1343 (_ bv1 32))))
(let ((?x176 (bvxor ?x88 ?x438)))
(let (($x756 (or false false)))
(let (($x280 (or $x756 false)))
(let (($x789 (or $x280 false false)))
(let (($x269 (or $x756 false false)))
(let (($x392 (or $x269 $x789 false)))
(and (not $x392) (or $x392 (and (distinct ?x176 ?x176) true)))))))))))))))
(check-sat)
; query 59: function crcu8, block 6, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1353 ((_ extract 7 0) in.01_16)))
(let ((?x1381 ((_ zero_extend 24) ?x1353)))
(let ((?x438 (bvand ?x1381 (_ bv1 32))))
(let ((?x1343 ((_ zero_extend 24) in.0_8)))
(let ((?x88 (bvand ?x1343 (_ bv1 32))))
(let ((?x176 (bvxor ?x88 ?x438)))
(let ((?x33 ((_ extract 7 0) ?x176)))
(let (($x756 (or false false)))
(let (($x280 (or $x756 false)))
(let (($x789 (or $x280 false false)))
(let (($x269 (or $x756 false false)))
(let (($x392 (or $x269 $x789 false)))
(let (($x243 (or $x392 false)))
(and (not $x243) (or $x243 (and (distinct ?x33 ?x33) true)))))))))))))))))
(check-sat)
; query 60: function crcu8, block 6, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x756 (or false false)))
(let (($x24 (not $x756)))
(and $x24 (or $x756 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 61: function crcu8, block 6, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1343 ((_ zero_extend 24) in.0_8)))
(let ((?x68 (bvashr ?x1343 (_ bv1 32))))
(let (($x756 (or false false)))
(let (($x269 (or $x756 false false)))
(let (($x169 (or $x269 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not $x169) (or $x169 (and (distinct ?x68 ?x68) true)))))))))
(check-sat)
; query 62: function crcu8, block 6, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1343 ((_ zero_extend 24) in.0_8)))
(let ((?x68 (bvashr ?x1343 (_ bv1 32))))
(let ((?x19 ((_ extract 7 0) ?x68)))
(let (($x756 (or false false)))
(let (($x269 (or $x756 false false)))
(let (($x169 (or $x269 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x525 (or $x169 false)))
(and (not $x525) (or $x525 (and (distinct ?x19 ?x19) true)))))))))))
(check-sat)
; query 63: function crcu8, block 6, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1353 ((_ extract 7 0) in.01_16)))
(let ((?x1381 ((_ zero_extend 24) ?x1353)))
(let ((?x438 (bvand ?x1381 (_ bv1 32))))
(let ((?x1343 ((_ zero_extend 24) in.0_8)))
(let ((?x88 (bvand ?x1343 (_ bv1 32))))
(let ((?x176 (bvxor ?x88 ?x438)))
(let ((?x33 ((_ extract 7 0) ?x176)))
(let ((?x223 ((_ zero_extend 24) ?x33)))
(let (($x756 (or false false)))
(let (($x280 (or $x756 false)))
(let (($x789 (or $x280 false false)))
(let (($x269 (or $x756 false false)))
(let (($x392 (or $x269 $x789 false)))
(let (($x243 (or $x392 false)))
(let (($x733 (or $x243 false)))
(and (not $x733) (or $x733 (and (distinct ?x223 ?x223) true)))))))))))))))))))
(check-sat)
; query 64: function crcu8, block 6, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1353 ((_ extract 7 0) in.01_16)))
(let ((?x1381 ((_ zero_extend 24) ?x1353)))
(let ((?x438 (bvand ?x1381 (_ bv1 32))))
(let ((?x1343 ((_ zero_extend 24) in.0_8)))
(let ((?x88 (bvand ?x1343 (_ bv1 32))))
(let ((?x176 (bvxor ?x88 ?x438)))
(let ((?x33 ((_ extract 7 0) ?x176)))
(let ((?x223 ((_ zero_extend 24) ?x33)))
(let ((?x872 (ite (= (_ bv1 32) ?x223) (_ bv1 1) (_ bv0 1))))
(let (($x756 (or false false)))
(let (($x280 (or $x756 false)))
(let (($x789 (or $x280 false false)))
(let (($x269 (or $x756 false false)))
(let (($x392 (or $x269 $x789 false)))
(let (($x243 (or $x392 false)))
(let (($x733 (or $x243 false)))
(let (($x1346 (or $x733 false false)))
(and (not $x1346) (or $x1346 (and (distinct ?x872 ?x872) true)))))))))))))))))))))
(check-sat)
; query 65: function crcu8, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x756 (or false false)))
(let (($x24 (not $x756)))
(and $x24 (or $x756 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 66: function crcu8, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1343 ((_ zero_extend 24) in.0_8)))
(let ((?x88 (bvand ?x1343 (_ bv1 32))))
(let (($x756 (or false false)))
(let (($x269 (or $x756 false false)))
(let (($x119 (not $x269)))
(and $x119 (or $x269 (and (distinct ?x88 ?x88) true)))))))))
(check-sat)
; query 67: function crcu8, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x756 (or false false)))
(let (($x24 (not $x756)))
(and $x24 (or $x756 (and (distinct ((_ extract 7 0) in.01_16) ((_ extract 7 0) in.01_16)) true))))))
(check-sat)
; query 68: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x571 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x917 ((_ zero_extend 31) ?x571)))
(let ((?x504 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x259 ((_ zero_extend 31) ?x504)))
(let ((?x710 (bvand ?x259 ?x917)))
(let ((?x378 (ite (and (distinct (_ bv0 32) ?x710) true) (_ bv1 1) (_ bv0 1))))
(let ((?x578 ((_ zero_extend 63) ?x378)))
(let (($x756 (or false false)))
(let (($x269 (or $x756 false false)))
(let (($x230 (or $x269 false)))
(let (($x637 (or $x230 $x230 false)))
(let (($x543 (or $x637 false false)))
(let (($x537 (or $x543 false)))
(and (not $x537) (or $x537 (and (distinct ?x578 ?x578) true)))))))))))))))))
(check-sat)
; query 69: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x571 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x917 ((_ zero_extend 31) ?x571)))
(let ((?x504 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x259 ((_ zero_extend 31) ?x504)))
(let ((?x710 (bvand ?x259 ?x917)))
(let ((?x378 (ite (and (distinct (_ bv0 32) ?x710) true) (_ bv1 1) (_ bv0 1))))
(let (($x192 (= (_ bv1 1) ?x378)))
(let ((?x445 (ite $x192 (_ bv1 32) (_ bv0 32))))
(let (($x756 (or false false)))
(let (($x269 (or $x756 false false)))
(let (($x230 (or $x269 false)))
(let (($x637 (or $x230 $x230 false)))
(let (($x543 (or $x637 false false)))
(let (($x530 (or $x543 (ite $x192 false false))))
(and (not $x530) (or $x530 (and (distinct ?x445 ?x445) true))))))))))))))))))
(check-sat)
; query 70: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x571 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x917 ((_ zero_extend 31) ?x571)))
(let ((?x504 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x259 ((_ zero_extend 31) ?x504)))
(let ((?x710 (bvand ?x259 ?x917)))
(let ((?x378 (ite (and (distinct (_ bv0 32) ?x710) true) (_ bv1 1) (_ bv0 1))))
(let (($x192 (= (_ bv1 1) ?x378)))
(let ((?x445 (ite $x192 (_ bv1 32) (_ bv0 32))))
(let ((?x312 ((_ extract 7 0) ?x445)))
(let (($x756 (or false false)))
(let (($x269 (or $x756 false false)))
(let (($x230 (or $x269 false)))
(let (($x637 (or $x230 $x230 false)))
(let (($x543 (or $x637 false false)))
(let (($x530 (or $x543 (ite $x192 false false))))
(let (($x896 (or $x530 false)))
(and (not $x896) (or $x896 (and (distinct ?x312 ?x312) true))))))))))))))))))))
(check-sat)
; query 71: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x756 (or false false)))
(let (($x24 (not $x756)))
(and $x24 (or $x756 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 72: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x504 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x756 (or false false)))
(let (($x269 (or $x756 false false)))
(let (($x119 (not $x269)))
(and $x119 (or $x269 (and (distinct ?x504 ?x504) true))))))))
(check-sat)
; query 73: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x504 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x259 ((_ zero_extend 31) ?x504)))
(let (($x756 (or false false)))
(let (($x269 (or $x756 false false)))
(let (($x230 (or $x269 false)))
(let (($x86 (not $x230)))
(and $x86 (or $x230 (and (distinct ?x259 ?x259) true))))))))))
(check-sat)
; query 74: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x756 (or false false)))
(let (($x24 (not $x756)))
(and $x24 (or $x756 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 75: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x571 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x756 (or false false)))
(let (($x269 (or $x756 false false)))
(let (($x119 (not $x269)))
(and $x119 (or $x269 (and (distinct ?x571 ?x571) true))))))))
(check-sat)
; query 76: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x571 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x917 ((_ zero_extend 31) ?x571)))
(let (($x756 (or false false)))
(let (($x269 (or $x756 false false)))
(let (($x230 (or $x269 false)))
(let (($x86 (not $x230)))
(and $x86 (or $x230 (and (distinct ?x917 ?x917) true))))))))))
(check-sat)
; query 77: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x571 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x917 ((_ zero_extend 31) ?x571)))
(let ((?x504 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x259 ((_ zero_extend 31) ?x504)))
(let ((?x710 (bvand ?x259 ?x917)))
(let (($x756 (or false false)))
(let (($x269 (or $x756 false false)))
(let (($x230 (or $x269 false)))
(let (($x637 (or $x230 $x230 false)))
(and (not $x637) (or $x637 (and (distinct ?x710 ?x710) true)))))))))))))
(check-sat)
; query 78: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x571 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x917 ((_ zero_extend 31) ?x571)))
(let ((?x504 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x259 ((_ zero_extend 31) ?x504)))
(let ((?x710 (bvand ?x259 ?x917)))
(let ((?x378 (ite (and (distinct (_ bv0 32) ?x710) true) (_ bv1 1) (_ bv0 1))))
(let (($x756 (or false false)))
(let (($x269 (or $x756 false false)))
(let (($x230 (or $x269 false)))
(let (($x637 (or $x230 $x230 false)))
(let (($x543 (or $x637 false false)))
(and (not $x543) (or $x543 (and (distinct ?x378 ?x378) true)))))))))))))))
(check-sat)
; query 79: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1317 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x80 (or false false false)))
(let (($x800 (not $x80)))
(and $x800 (or $x80 (and (distinct ?x1317 ?x1317) true)))))))
(check-sat)
; query 80: function matrix_add_const, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x80 (or false false false)))
(let (($x800 (not $x80)))
(and $x800 (or $x80 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 81: function matrix_add_const, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1273 (bvadd in.01_32 (_ bv1 32))))
(let (($x1011 (and (distinct ?x1273 ?x1273) true)))
(let (($x80 (or false false false)))
(let (($x800 (not $x80)))
(and $x800 (or $x80 $x1011)))))))
(check-sat)
; query 82: function matrix_mul_const, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x80 (or false false false)))
(let (($x800 (not $x80)))
(and $x800 (or $x80 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 83: function matrix_mul_const, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1273 (bvadd in.01_32 (_ bv1 32))))
(let (($x1011 (and (distinct ?x1273 ?x1273) true)))
(let (($x80 (or false false false)))
(let (($x800 (not $x80)))
(and $x800 (or $x80 $x1011)))))))
(check-sat)
; query 84: function matrix_mul_matrix, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x80 (or false false false)))
(let (($x800 (not $x80)))
(and $x800 (or $x80 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 85: function matrix_mul_matrix, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1273 (bvadd in.01_32 (_ bv1 32))))
(let (($x1011 (and (distinct ?x1273 ?x1273) true)))
(let (($x80 (or false false false)))
(let (($x800 (not $x80)))
(and $x800 (or $x80 $x1011)))))))
(check-sat)
; query 86: function matrix_mul_matrix, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x80 (or false false false)))
(let (($x800 (not $x80)))
(and $x800 (or $x80 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 87: function matrix_mul_matrix_bitextract, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x80 (or false false false)))
(let (($x800 (not $x80)))
(and $x800 (or $x80 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 88: function matrix_mul_matrix_bitextract, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1273 (bvadd in.01_32 (_ bv1 32))))
(let (($x1011 (and (distinct ?x1273 ?x1273) true)))
(let (($x80 (or false false false)))
(let (($x800 (not $x80)))
(and $x800 (or $x80 $x1011)))))))
(check-sat)
; query 89: function matrix_mul_matrix_bitextract, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x80 (or false false false)))
(let (($x800 (not $x80)))
(and $x800 (or $x80 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 90: function matrix_mul_vect, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x80 (or false false false)))
(let (($x800 (not $x80)))
(and $x800 (or $x80 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 91: function matrix_mul_vect, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1273 (bvadd in.01_32 (_ bv1 32))))
(let (($x1011 (and (distinct ?x1273 ?x1273) true)))
(let (($x80 (or false false false)))
(let (($x800 (not $x80)))
(and $x800 (or $x80 $x1011)))))))
(check-sat)
; query 92: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x756 (or false false)))
(let (($x24 (not $x756)))
(and $x24 (or $x756 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 93: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x610 ((_ sign_extend 16) in.1_16)))
(let ((?x325 (bvadd ?x610 (_ bv10 32))))
(let (($x462 (and (distinct (bvadd ((_ sign_extend 1) ?x610) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x325)) true)))
(let (($x756 (or false false)))
(let (($x986 (or $x756 false (or $x462))))
(and (not $x986) (or $x986 (and (distinct ?x325 ?x325) true)))))))))
(check-sat)
; query 94: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x610 ((_ sign_extend 16) in.1_16)))
(let ((?x325 (bvadd ?x610 (_ bv10 32))))
(let ((?x478 ((_ extract 15 0) ?x325)))
(let (($x462 (and (distinct (bvadd ((_ sign_extend 1) ?x610) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x325)) true)))
(let (($x756 (or false false)))
(let (($x986 (or $x756 false (or $x462))))
(let (($x207 (or $x986 false)))
(and (not $x207) (or $x207 (and (distinct ?x478 ?x478) true)))))))))))
(check-sat)
; query 95: function matrix_sum, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x472 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x80 (or false false false)))
(let (($x800 (not $x80)))
(and $x800 (or $x80 (and (distinct ?x472 ?x472) true)))))))
(check-sat)
; query 96: function matrix_sum, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x472 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let ((?x43 ((_ zero_extend 63) ?x472)))
(let (($x80 (or false false false)))
(let (($x446 (or $x80 false)))
(and (not $x446) (or $x446 (and (distinct ?x43 ?x43) true))))))))
(check-sat)
; query 97: function matrix_sum, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x472 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x375 (= (_ bv1 1) ?x472)))
(let ((?x787 (ite $x375 (_ bv1 32) (_ bv0 32))))
(let (($x80 (or false false false)))
(let (($x305 (or $x80 (ite $x375 false false))))
(and (not $x305) (or $x305 (and (distinct ?x787 ?x787) true)))))))))
(check-sat)
; query 98: function matrix_sum, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x756 (or false false)))
(let (($x24 (not $x756)))
(and $x24 (or $x756 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 99: function matrix_sum, block 22, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x472 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x375 (= (_ bv1 1) ?x472)))
(let ((?x787 (ite $x375 (_ bv1 32) (_ bv0 32))))
(let ((?x610 ((_ sign_extend 16) in.1_16)))
(let ((?x251 (bvadd ?x610 ?x787)))
(let (($x386 (and (distinct (bvadd ((_ sign_extend 1) ?x610) ((_ sign_extend 1) ?x787)) ((_ sign_extend 1) ?x251)) true)))
(let (($x80 (or false false false)))
(let (($x305 (or $x80 (ite $x375 false false))))
(let (($x756 (or false false)))
(let (($x550 (or $x756 $x305 (or $x386))))
(and (not $x550) (or $x550 (and (distinct ?x251 ?x251) true))))))))))))))
(check-sat)
; query 100: function matrix_sum, block 22, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x472 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x375 (= (_ bv1 1) ?x472)))
(let ((?x787 (ite $x375 (_ bv1 32) (_ bv0 32))))
(let ((?x610 ((_ sign_extend 16) in.1_16)))
(let ((?x251 (bvadd ?x610 ?x787)))
(let ((?x622 ((_ extract 15 0) ?x251)))
(let (($x386 (and (distinct (bvadd ((_ sign_extend 1) ?x610) ((_ sign_extend 1) ?x787)) ((_ sign_extend 1) ?x251)) true)))
(let (($x80 (or false false false)))
(let (($x305 (or $x80 (ite $x375 false false))))
(let (($x756 (or false false)))
(let (($x550 (or $x756 $x305 (or $x386))))
(let (($x380 (or $x550 false)))
(and (not $x380) (or $x380 (and (distinct ?x622 ?x622) true))))))))))))))))
(check-sat)
; query 101: function matrix_sum, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x80 (or false false false)))
(let (($x800 (not $x80)))
(and $x800 (or $x80 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 102: function matrix_sum, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1273 (bvadd in.01_32 (_ bv1 32))))
(let (($x1011 (and (distinct ?x1273 ?x1273) true)))
(let (($x80 (or false false false)))
(let (($x800 (not $x80)))
(and $x800 (or $x80 $x1011)))))))
(check-sat)
; query 103: function parseval, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.23_32 () (_ BitVec 32))
(assert
 (let (($x572 (and (distinct (bvmul ((_ sign_extend 32) in.23_32) ((_ sign_extend 32) (_ bv1024 32))) ((_ sign_extend 32) (bvmul in.23_32 (_ bv1024 32)))) true)))
(let (($x624 (or false false (or $x572))))
(and (not $x624) (or $x624 (and (distinct (bvmul in.23_32 (_ bv1024 32)) (bvmul in.23_32 (_ bv1024 32))) true))))))
(check-sat)
; query 104: function parseval, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.34_32 () (_ BitVec 32))
(assert
 (let (($x327 (and (distinct (bvmul ((_ sign_extend 32) in.34_32) ((_ sign_extend 32) (_ bv1048576 32))) ((_ sign_extend 32) (bvmul in.34_32 (_ bv1048576 32)))) true)))
(let (($x288 (or false false (or $x327))))
(and (not $x288) (or $x288 (and (distinct (bvmul in.34_32 (_ bv1048576 32)) (bvmul in.34_32 (_ bv1048576 32))) true))))))
(check-sat)
; query 105: function partition_memory, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x80 (or false false false)))
(let (($x800 (not $x80)))
(and $x800 (or $x80 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
