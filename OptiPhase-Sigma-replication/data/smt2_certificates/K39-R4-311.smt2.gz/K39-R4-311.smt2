; OptiPhase-Sigma refinement certificate for sweep K39-R4-311
; query 0: function BF_cbc_encrypt, block 126, name %127
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.010_64 () (_ BitVec 64))
(assert
 (let (($x1011 (and (distinct (bvsub ((_ sign_extend 1) in.010_64) ((_ sign_extend 1) (_ bv8 64))) ((_ sign_extend 1) (bvsub in.010_64 (_ bv8 64)))) true)))
(let (($x94 (or false false (or $x1011))))
(and (not $x94) (or $x94 (and (distinct (bvsub in.010_64 (_ bv8 64)) (bvsub in.010_64 (_ bv8 64))) true))))))
(check-sat)
; query 1: function BF_cbc_encrypt, block 366, name %367
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.111_64 () (_ BitVec 64))
(assert
 (let (($x66 (and (distinct (bvsub ((_ sign_extend 1) in.111_64) ((_ sign_extend 1) (_ bv8 64))) ((_ sign_extend 1) (bvsub in.111_64 (_ bv8 64)))) true)))
(let (($x514 (or false false (or $x66))))
(and (not $x514) (or $x514 (and (distinct (bvsub in.111_64 (_ bv8 64)) (bvsub in.111_64 (_ bv8 64))) true))))))
(check-sat)
; query 2: function BF_cfb64_encrypt, block 111, name %112
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.18_32 () (_ BitVec 32))
(assert
 (let ((?x341 (ite (= (_ bv0 32) in.18_32) (_ bv1 1) (_ bv0 1))))
(let (($x120 (or false false false)))
(let (($x785 (not $x120)))
(and $x785 (or $x120 (and (distinct ?x341 ?x341) true)))))))
(check-sat)
; query 3: function BF_cfb64_encrypt, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.07_32 () (_ BitVec 32))
(assert
 (let ((?x133 (ite (= (_ bv0 32) in.07_32) (_ bv1 1) (_ bv0 1))))
(let (($x120 (or false false false)))
(let (($x785 (not $x120)))
(and $x785 (or $x120 (and (distinct ?x133 ?x133) true)))))))
(check-sat)
; query 4: function BF_ofb64_encrypt, block 82, name %83
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x306 (ite (= (_ bv0 32) in.04_32) (_ bv1 1) (_ bv0 1))))
(let (($x120 (or false false false)))
(let (($x785 (not $x120)))
(and $x785 (or $x120 (and (distinct ?x306 ?x306) true)))))))
(check-sat)
; query 5: function BF_set_key, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x7 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x24 (or false false (or $x7))))
(and (not $x24) (or $x24 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 6: function BF_set_key, block 69, name %70
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.13_32 () (_ BitVec 32))
(assert
 (let (($x29 (and (distinct (bvadd ((_ sign_extend 1) in.13_32) ((_ sign_extend 1) (_ bv2 32))) ((_ sign_extend 1) (bvadd in.13_32 (_ bv2 32)))) true)))
(let (($x231 (or false false (or $x29))))
(and (not $x231) (or $x231 (and (distinct (bvadd in.13_32 (_ bv2 32)) (bvadd in.13_32 (_ bv2 32))) true))))))
(check-sat)
; query 7: function BF_set_key, block 87, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.24_32 () (_ BitVec 32))
(assert
 (let (($x100 (and (distinct (bvadd ((_ sign_extend 1) in.24_32) ((_ sign_extend 1) (_ bv2 32))) ((_ sign_extend 1) (bvadd in.24_32 (_ bv2 32)))) true)))
(let (($x126 (or false false (or $x100))))
(and (not $x126) (or $x126 (and (distinct (bvadd in.24_32 (_ bv2 32)) (bvadd in.24_32 (_ bv2 32))) true))))))
(check-sat)
; query 8: function main, block 124, name %125
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let ((?x102 (ite (bvsgt (_ bv40 32) in.2_32) (_ bv1 1) (_ bv0 1))))
(let (($x120 (or false false false)))
(let (($x785 (not $x120)))
(and $x785 (or $x120 (and (distinct ?x102 ?x102) true)))))))
(check-sat)
; query 9: function main, block 147, name %148
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x300 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x47 (or false false (or $x300))))
(and (not $x47) (or $x47 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 10: function main, block 60, name %61
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x156 (or false false)))
(and (not $x156) (or $x156 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 11: function main, block 60, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x227 (ite (bvsge (_ bv57 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x156 (or false false)))
(let (($x150 (or $x156 false false)))
(let (($x164 (not $x150)))
(and $x164 (or $x150 (and (distinct ?x227 ?x227) true))))))))
(check-sat)
; query 12: function main, block 63, name %64
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x120 (or false false false)))
(let (($x139 (or $x120 (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x139) (or $x139 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvshl in.01_32 (_ bv4 32))) true))))))
(check-sat)
; query 13: function main, block 63, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x156 (or false false)))
(and (not $x156) (or $x156 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 14: function main, block 63, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x135 ((_ sign_extend 24) in57_8)))
(let ((?x152 (bvshl in.01_32 (_ bv4 32))))
(let ((?x116 (bvadd ?x152 ?x135)))
(let ((?x128 ((_ sign_extend 1) ?x116)))
(let (($x156 (or false false)))
(let (($x120 (or false false false)))
(let (($x139 (or $x120 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x79 (or $x139 $x156 (or (and (distinct (bvadd ((_ sign_extend 1) ?x152) ((_ sign_extend 1) ?x135)) ?x128) true)))))
(and (not $x79) (or $x79 (and (distinct ?x116 ?x116) true))))))))))))
(check-sat)
; query 15: function main, block 63, name %67
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x135 ((_ sign_extend 24) in57_8)))
(let ((?x152 (bvshl in.01_32 (_ bv4 32))))
(let ((?x116 (bvadd ?x152 ?x135)))
(let ((?x31 (bvsub ?x116 (_ bv48 32))))
(let (($x176 (and (distinct (bvsub ((_ sign_extend 1) ?x116) ((_ sign_extend 1) (_ bv48 32))) ((_ sign_extend 1) ?x31)) true)))
(let ((?x128 ((_ sign_extend 1) ?x116)))
(let (($x156 (or false false)))
(let (($x120 (or false false false)))
(let (($x139 (or $x120 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x79 (or $x139 $x156 (or (and (distinct (bvadd ((_ sign_extend 1) ?x152) ((_ sign_extend 1) ?x135)) ?x128) true)))))
(let (($x96 (or $x79 false (or $x176))))
(and (not $x96) (or $x96 (and (distinct ?x31 ?x31) true)))))))))))))))
(check-sat)
; query 16: function main, block 68, name %69
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x156 (or false false)))
(and (not $x156) (or $x156 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 17: function main, block 68, name %70
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x115 (ite (bvsle (_ bv65 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x156 (or false false)))
(let (($x150 (or $x156 false false)))
(let (($x164 (not $x150)))
(and $x164 (or $x150 (and (distinct ?x115 ?x115) true))))))))
(check-sat)
; query 18: function main, block 71, name %72
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x156 (or false false)))
(and (not $x156) (or $x156 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 19: function main, block 71, name %73
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x54 (ite (bvsge (_ bv70 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x156 (or false false)))
(let (($x150 (or $x156 false false)))
(let (($x164 (not $x150)))
(and $x164 (or $x150 (and (distinct ?x54 ?x54) true))))))))
(check-sat)
; query 20: function main, block 74, name %75
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x120 (or false false false)))
(let (($x139 (or $x120 (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x139) (or $x139 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvshl in.01_32 (_ bv4 32))) true))))))
(check-sat)
; query 21: function main, block 74, name %76
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x156 (or false false)))
(and (not $x156) (or $x156 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 22: function main, block 74, name %77
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x135 ((_ sign_extend 24) in57_8)))
(let ((?x152 (bvshl in.01_32 (_ bv4 32))))
(let ((?x116 (bvadd ?x152 ?x135)))
(let ((?x128 ((_ sign_extend 1) ?x116)))
(let (($x156 (or false false)))
(let (($x120 (or false false false)))
(let (($x139 (or $x120 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x79 (or $x139 $x156 (or (and (distinct (bvadd ((_ sign_extend 1) ?x152) ((_ sign_extend 1) ?x135)) ?x128) true)))))
(and (not $x79) (or $x79 (and (distinct ?x116 ?x116) true))))))))))))
(check-sat)
; query 23: function main, block 74, name %78
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x135 ((_ sign_extend 24) in57_8)))
(let ((?x152 (bvshl in.01_32 (_ bv4 32))))
(let ((?x116 (bvadd ?x152 ?x135)))
(let ((?x67 (bvsub ?x116 (_ bv65 32))))
(let ((?x323 ((_ sign_extend 1) ?x67)))
(let ((?x128 ((_ sign_extend 1) ?x116)))
(let (($x156 (or false false)))
(let (($x120 (or false false false)))
(let (($x139 (or $x120 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x79 (or $x139 $x156 (or (and (distinct (bvadd ((_ sign_extend 1) ?x152) ((_ sign_extend 1) ?x135)) ?x128) true)))))
(let (($x131 (or $x79 false (or (and (distinct (bvsub ?x128 ((_ sign_extend 1) (_ bv65 32))) ?x323) true)))))
(and (not $x131) (or $x131 (and (distinct ?x67 ?x67) true)))))))))))))))
(check-sat)
; query 24: function main, block 74, name %79
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x135 ((_ sign_extend 24) in57_8)))
(let ((?x152 (bvshl in.01_32 (_ bv4 32))))
(let ((?x116 (bvadd ?x152 ?x135)))
(let ((?x67 (bvsub ?x116 (_ bv65 32))))
(let ((?x40 (bvadd ?x67 (_ bv10 32))))
(let (($x124 (and (distinct (bvadd ((_ sign_extend 1) ?x67) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x40)) true)))
(let ((?x323 ((_ sign_extend 1) ?x67)))
(let ((?x128 ((_ sign_extend 1) ?x116)))
(let (($x156 (or false false)))
(let (($x120 (or false false false)))
(let (($x139 (or $x120 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x79 (or $x139 $x156 (or (and (distinct (bvadd ((_ sign_extend 1) ?x152) ((_ sign_extend 1) ?x135)) ?x128) true)))))
(let (($x131 (or $x79 false (or (and (distinct (bvsub ?x128 ((_ sign_extend 1) (_ bv65 32))) ?x323) true)))))
(let (($x30 (or $x131 false (or $x124))))
(and (not $x30) (or $x30 (and (distinct ?x40 ?x40) true))))))))))))))))))
(check-sat)
