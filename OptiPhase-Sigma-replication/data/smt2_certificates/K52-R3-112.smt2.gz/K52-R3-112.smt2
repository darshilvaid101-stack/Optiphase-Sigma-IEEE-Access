; OptiPhase-Sigma refinement certificate for sweep K52-R3-112
; query 0: function check, block 142, name %143
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x1732 (and (distinct (ite (= (_ bv123 32) in0_32) (_ bv1 1) (_ bv0 1)) (ite (= (_ bv1122 32) in0_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x176 (or false false false)))
(let (($x337 (not $x176)))
(and $x337 (or $x176 $x1732))))))
(check-sat)
; query 1: function check, block 157, name %158
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x362 (and (distinct (ite (= (_ bv112233 32) in0_32) (_ bv1 1) (_ bv0 1)) (ite (= (_ bv111 32) in0_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x176 (or false false false)))
(let (($x337 (not $x176)))
(and $x337 (or $x176 $x362))))))
(check-sat)
; query 2: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x95 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x176 (or false false false)))
(let (($x337 (not $x176)))
(and $x337 (or $x176 (and (distinct ?x95 ?x95) true)))))))
(check-sat)
; query 3: function s162, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x142 (ite (bvslt (_ bv0 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x176 (or false false false)))
(let (($x337 (not $x176)))
(and $x337 (or $x176 (and (distinct ?x142 ?x142) true)))))))
(check-sat)
; query 4: function s276, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1179 (and (distinct (bvadd ((_ zero_extend 1) in.0_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x446 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x123 (or (or false false (or $x446 $x1179)) (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))
(and (not (or false false (or $x446))) $x123)))))
(check-sat)
; query 5: function s276, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1669 (and (distinct (ite (bvsgt (_ bv16000 32) (bvadd in.0_32 (_ bv1 32))) (_ bv1 1) (_ bv0 1)) (ite (bvult in.0_32 (_ bv15999 32)) (_ bv1 1) (_ bv0 1))) true)))
(let (($x714 (or (or false false (and (distinct ((_ extract 31 31) in.0_32) ((_ extract 31 31) (_ bv15999 32))) true)) $x1669)))
(let (($x446 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x399 (or false false (or $x446))))
(and (not (or $x399 false false)) $x714))))))
(check-sat)
; query 6: function set1d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x591 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x176 (or false false false)))
(let (($x337 (not $x176)))
(and $x337 (or $x176 (and (distinct ?x591 ?x591) true)))))))
(check-sat)
; query 7: function set1ds, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x430 (ite (= (_ bv4294967295 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x176 (or false false false)))
(let (($x337 (not $x176)))
(and $x337 (or $x176 (and (distinct ?x430 ?x430) true)))))))
(check-sat)
; query 8: function set2d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x591 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x176 (or false false false)))
(let (($x337 (not $x176)))
(and $x337 (or $x176 (and (distinct ?x591 ?x591) true)))))))
(check-sat)
