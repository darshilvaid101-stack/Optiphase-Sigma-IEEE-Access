; OptiPhase-Sigma refinement certificate for sweep K23-R3-112
