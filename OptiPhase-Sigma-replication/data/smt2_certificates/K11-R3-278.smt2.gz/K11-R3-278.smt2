; OptiPhase-Sigma refinement certificate for sweep K11-R3-278
