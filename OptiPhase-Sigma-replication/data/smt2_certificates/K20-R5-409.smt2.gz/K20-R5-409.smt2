; OptiPhase-Sigma refinement certificate for sweep K20-R5-409
