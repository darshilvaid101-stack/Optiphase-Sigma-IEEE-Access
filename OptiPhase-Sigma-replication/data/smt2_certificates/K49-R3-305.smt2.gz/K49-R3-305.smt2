; OptiPhase-Sigma refinement certificate for sweep K49-R3-305
; query 0: function APCM_inverse_quantization, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x1936 (or false false)))
(let (($x182 (not $x1936)))
(and $x182 (or $x1936 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 1: function APCM_inverse_quantization, block 7, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x21 (ite (bvsge (_ bv7 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1936 (or false false)))
(let (($x821 (or $x1936 false false)))
(let (($x31 (not $x821)))
(and $x31 (or $x821 (and (distinct ?x21 ?x21) true))))))))
(check-sat)
; query 2: function APCM_inverse_quantization, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x1936 (or false false)))
(let (($x182 (not $x1936)))
(and $x182 (or $x1936 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 3: function APCM_inverse_quantization, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x908 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1936 (or false false)))
(let (($x821 (or $x1936 false false)))
(let (($x31 (not $x821)))
(and $x31 (or $x821 (and (distinct ?x908 ?x908) true))))))))
(check-sat)
; query 4: function APCM_quantization, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_16 () (_ BitVec 16))
(assert
 (let (($x1936 (or false false)))
(let (($x182 (not $x1936)))
(and $x182 (or $x1936 (and (distinct ((_ sign_extend 16) in13_16) ((_ sign_extend 16) in13_16)) true))))))
(check-sat)
; query 5: function APCM_quantization, block 16, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_16 () (_ BitVec 16))
(assert
 (let ((?x127 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in13_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1936 (or false false)))
(let (($x821 (or $x1936 false false)))
(let (($x31 (not $x821)))
(and $x31 (or $x821 (and (distinct ?x127 ?x127) true))))))))
(check-sat)
; query 6: function APCM_quantization_xmaxc_to_exp_mant, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x71 ((_ sign_extend 16) in0_16)))
(let ((?x616 (bvashr ?x71 (_ bv3 32))))
(let ((?x1679 (bvsub ?x616 (_ bv1 32))))
(let ((?x101 ((_ extract 15 0) ?x1679)))
(let (($x1681 (and (distinct (bvsub ((_ sign_extend 1) ?x616) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x1679)) true)))
(let (($x1936 (or false false)))
(let (($x821 (or $x1936 false false)))
(let (($x149 (or $x821 (bvuge (_ bv3 32) (_ bv32 32)))))
(let (($x72 (or $x149 false (or $x1681))))
(let (($x125 (or $x72 false)))
(and (not $x125) (or $x125 (and (distinct ?x101 ?x101) true))))))))))))))
(check-sat)
; query 7: function APCM_quantization_xmaxc_to_exp_mant, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x1936 (or false false)))
(let (($x182 (not $x1936)))
(and $x182 (or $x1936 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 8: function APCM_quantization_xmaxc_to_exp_mant, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x71 ((_ sign_extend 16) in0_16)))
(let ((?x616 (bvashr ?x71 (_ bv3 32))))
(let (($x1936 (or false false)))
(let (($x821 (or $x1936 false false)))
(let (($x149 (or $x821 (bvuge (_ bv3 32) (_ bv32 32)))))
(and (not $x149) (or $x149 (and (distinct ?x616 ?x616) true)))))))))
(check-sat)
; query 9: function APCM_quantization_xmaxc_to_exp_mant, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x71 ((_ sign_extend 16) in0_16)))
(let ((?x616 (bvashr ?x71 (_ bv3 32))))
(let ((?x1679 (bvsub ?x616 (_ bv1 32))))
(let (($x1681 (and (distinct (bvsub ((_ sign_extend 1) ?x616) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x1679)) true)))
(let (($x1936 (or false false)))
(let (($x821 (or $x1936 false false)))
(let (($x149 (or $x821 (bvuge (_ bv3 32) (_ bv32 32)))))
(let (($x72 (or $x149 false (or $x1681))))
(and (not $x72) (or $x72 (and (distinct ?x1679 ?x1679) true))))))))))))
(check-sat)
; query 10: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x1936 (or false false)))
(let (($x182 (not $x1936)))
(and $x182 (or $x1936 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 11: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1620 (ite (bvslt (_ bv15 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1936 (or false false)))
(let (($x821 (or $x1936 false false)))
(let (($x31 (not $x821)))
(and $x31 (or $x821 (and (distinct ?x1620 ?x1620) true))))))))
(check-sat)
; query 12: function Calculation_of_the_LTP_parameters, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in11_16 () (_ BitVec 16))
(assert
 (let (($x1936 (or false false)))
(let (($x182 (not $x1936)))
(and $x182 (or $x1936 (and (distinct ((_ sign_extend 16) in11_16) ((_ sign_extend 16) in11_16)) true))))))
(check-sat)
; query 13: function Calculation_of_the_LTP_parameters, block 14, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in11_16 () (_ BitVec 16))
(assert
 (let ((?x507 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in11_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1936 (or false false)))
(let (($x821 (or $x1936 false false)))
(let (($x31 (not $x821)))
(and $x31 (or $x821 (and (distinct ?x507 ?x507) true))))))))
(check-sat)
; query 14: function Gsm_Long_Term_Synthesis_Filtering, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x1936 (or false false)))
(let (($x182 (not $x1936)))
(and $x182 (or $x1936 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 15: function Gsm_Long_Term_Synthesis_Filtering, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let (($x1936 (or false false)))
(let (($x182 (not $x1936)))
(and $x182 (or $x1936 (and (distinct ((_ sign_extend 16) in19_16) ((_ sign_extend 16) in19_16)) true))))))
(check-sat)
; query 16: function Gsm_Long_Term_Synthesis_Filtering, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x1076 (ite (bvsge (_ bv120 32) ((_ sign_extend 16) in19_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1936 (or false false)))
(let (($x821 (or $x1936 false false)))
(let (($x31 (not $x821)))
(and $x31 (or $x821 (and (distinct ?x1076 ?x1076) true))))))))
(check-sat)
; query 17: function Gsm_Long_Term_Synthesis_Filtering, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x16 (ite (bvslt (_ bv120 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1936 (or false false)))
(let (($x821 (or $x1936 false false)))
(let (($x31 (not $x821)))
(and $x31 (or $x821 (and (distinct ?x16 ?x16) true))))))))
(check-sat)
; query 18: function Gsm_Long_Term_Synthesis_Filtering, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x1936 (or false false)))
(let (($x182 (not $x1936)))
(and $x182 (or $x1936 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 19: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x1936 (or false false)))
(let (($x182 (not $x1936)))
(and $x182 (or $x1936 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 20: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x69 (ite (bvsgt (_ bv40 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1936 (or false false)))
(let (($x821 (or $x1936 false false)))
(let (($x31 (not $x821)))
(and $x31 (or $x821 (and (distinct ?x69 ?x69) true))))))))
(check-sat)
; query 21: function RPE_grid_positioning, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x1936 (or false false)))
(let (($x182 (not $x1936)))
(and $x182 (or $x1936 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 22: function RPE_grid_positioning, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x545 (ite (bvsge (_ bv3 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1936 (or false false)))
(let (($x821 (or $x1936 false false)))
(let (($x31 (not $x821)))
(and $x31 (or $x821 (and (distinct ?x545 ?x545) true))))))))
(check-sat)
; query 23: function RPE_grid_positioning, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x1936 (or false false)))
(let (($x182 (not $x1936)))
(and $x182 (or $x1936 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 24: function RPE_grid_positioning, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x309 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x85 (and (distinct ?x309 ?x309) true)))
(let (($x1936 (or false false)))
(let (($x509 (or false $x1936 false)))
(and (not $x509) (or $x509 $x85)))))))
(check-sat)
; query 25: function Short_term_synthesis_filtering, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in23_16 () (_ BitVec 16))
(assert
 (let (($x1936 (or false false)))
(let (($x182 (not $x1936)))
(and $x182 (or $x1936 (and (distinct ((_ sign_extend 16) in23_16) ((_ sign_extend 16) in23_16)) true))))))
(check-sat)
; query 26: function Short_term_synthesis_filtering, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in23_16 () (_ BitVec 16))
(assert
 (let ((?x206 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in23_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1936 (or false false)))
(let (($x821 (or $x1936 false false)))
(let (($x31 (not $x821)))
(and $x31 (or $x821 (and (distinct ?x206 ?x206) true))))))))
(check-sat)
; query 27: function Transformation_to_Log_Area_Ratios, block 77, name %78
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x1936 (or false false)))
(let (($x182 (not $x1936)))
(and $x182 (or $x1936 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 28: function Transformation_to_Log_Area_Ratios, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_16 () (_ BitVec 16))
(assert
 (let ((?x84 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in5_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1936 (or false false)))
(let (($x821 (or $x1936 false false)))
(let (($x31 (not $x821)))
(and $x31 (or $x821 (and (distinct ?x84 ?x84) true))))))))
(check-sat)
; query 29: function Transformation_to_Log_Area_Ratios, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_16 () (_ BitVec 16))
(assert
 (let (($x1936 (or false false)))
(let (($x182 (not $x1936)))
(and $x182 (or $x1936 (and (distinct ((_ sign_extend 16) in5_16) ((_ sign_extend 16) in5_16)) true))))))
(check-sat)
; query 30: function gsm_L_add, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x216 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x441 (or false false false)))
(let (($x30 (not $x441)))
(and $x30 (or $x441 (and (distinct ?x216 ?x216) true)))))))
(check-sat)
; query 31: function gsm_L_add, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let (($x116 (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) in0_64)) ((_ sign_extend 1) (bvadd in1_64 in0_64))) true)))
(let (($x151 (or (or false false (or $x116)) (and (distinct (bvadd in0_64 in1_64) (bvadd in1_64 in0_64)) true))))
(let (($x145 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvadd in0_64 in1_64))) true)))
(and (not (or false false (or $x145))) $x151)))))
(check-sat)
; query 32: function gsm_L_add, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x356 (bvadd in0_64 (_ bv1 64))))
(let ((?x181 (bvsub (_ bv0 64) ?x356)))
(let (($x115 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x356)) ((_ sign_extend 1) ?x181)) true)))
(let ((?x93 ((_ sign_extend 1) ?x356)))
(let (($x114 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x93) true)))))
(let (($x104 (or false $x114 (or $x115))))
(and (not $x104) (or $x104 (and (distinct ?x181 ?x181) true))))))))))
(check-sat)
; query 33: function gsm_L_add, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x50 (bvadd in1_64 (_ bv1 64))))
(let ((?x53 ((_ sign_extend 1) ?x50)))
(let (($x27 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x53) true)))))
(and (not $x27) (or $x27 (and (distinct ?x50 ?x50) true)))))))
(check-sat)
; query 34: function gsm_L_add, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x50 (bvadd in1_64 (_ bv1 64))))
(let ((?x87 (bvsub (_ bv0 64) ?x50)))
(let (($x392 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x50)) ((_ sign_extend 1) ?x87)) true)))
(let ((?x53 ((_ sign_extend 1) ?x50)))
(let (($x27 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x53) true)))))
(let (($x135 (or false $x27 (or $x392))))
(and (not $x135) (or $x135 (and (distinct ?x87 ?x87) true))))))))))
(check-sat)
; query 35: function gsm_L_add, block 8, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x356 (bvadd in0_64 (_ bv1 64))))
(let ((?x181 (bvsub (_ bv0 64) ?x356)))
(let ((?x50 (bvadd in1_64 (_ bv1 64))))
(let ((?x87 (bvsub (_ bv0 64) ?x50)))
(let ((?x263 (bvadd ?x87 ?x181)))
(let ((?x208 (bvadd ?x181 ?x87)))
(let (($x115 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x356)) ((_ sign_extend 1) ?x181)) true)))
(let ((?x93 ((_ sign_extend 1) ?x356)))
(let (($x114 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x93) true)))))
(let (($x104 (or false $x114 (or $x115))))
(let (($x392 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x50)) ((_ sign_extend 1) ?x87)) true)))
(let ((?x53 ((_ sign_extend 1) ?x50)))
(let (($x27 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x53) true)))))
(let (($x135 (or false $x27 (or $x392))))
(let (($x397 (or $x135 $x104 false)))
(and (not (or $x104 $x135 false)) (or $x397 (and (distinct ?x208 ?x263) true)))))))))))))))))))
(check-sat)
; query 36: function gsm_L_add, block 8, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x356 (bvadd in0_64 (_ bv1 64))))
(let ((?x181 (bvsub (_ bv0 64) ?x356)))
(let ((?x50 (bvadd in1_64 (_ bv1 64))))
(let ((?x87 (bvsub (_ bv0 64) ?x50)))
(let ((?x263 (bvadd ?x87 ?x181)))
(let (($x366 (and (distinct (ite (bvuge (bvadd ?x181 ?x87) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1)) (ite (bvuge ?x263 (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))) true)))
(let (($x115 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x356)) ((_ sign_extend 1) ?x181)) true)))
(let ((?x93 ((_ sign_extend 1) ?x356)))
(let (($x114 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x93) true)))))
(let (($x104 (or false $x114 (or $x115))))
(let (($x392 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x50)) ((_ sign_extend 1) ?x87)) true)))
(let ((?x53 ((_ sign_extend 1) ?x50)))
(let (($x27 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x53) true)))))
(let (($x135 (or false $x27 (or $x392))))
(let (($x397 (or $x135 $x104 false)))
(and (not (or (or $x104 $x135 false) false false)) (or (or $x397 false false) $x366))))))))))))))))))
(check-sat)
; query 37: function gsm_L_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x356 (bvadd in0_64 (_ bv1 64))))
(let ((?x93 ((_ sign_extend 1) ?x356)))
(let (($x114 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x93) true)))))
(and (not $x114) (or $x114 (and (distinct ?x356 ?x356) true)))))))
(check-sat)
; query 38: function gsm_L_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x46 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x441 (or false false false)))
(let (($x30 (not $x441)))
(and $x30 (or $x441 (and (distinct ?x46 ?x46) true)))))))
(check-sat)
; query 39: function gsm_L_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x150 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x441 (or false false false)))
(let (($x30 (not $x441)))
(and $x30 (or $x441 (and (distinct ?x150 ?x150) true)))))))
(check-sat)
; query 40: function gsm_L_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x46 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x441 (or false false false)))
(let (($x30 (not $x441)))
(and $x30 (or $x441 (and (distinct ?x46 ?x46) true)))))))
(check-sat)
; query 41: function gsm_L_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x46 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x130 ((_ zero_extend 31) ?x46)))
(let (($x441 (or false false false)))
(let (($x56 (or $x441 false)))
(and (not $x56) (or $x56 (and (distinct ?x130 ?x130) true))))))))
(check-sat)
; query 42: function gsm_L_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x46 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x130 ((_ zero_extend 31) ?x46)))
(let ((?x67 (bvsub (_ bv0 32) ?x130)))
(let (($x1911 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x130)) ((_ sign_extend 1) ?x67)) true)))
(let (($x441 (or false false false)))
(let (($x56 (or $x441 false)))
(let (($x48 (or false $x56 (or $x1911))))
(and (not $x48) (or $x48 (and (distinct ?x67 ?x67) true)))))))))))
(check-sat)
; query 43: function gsm_L_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x46 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x130 ((_ zero_extend 31) ?x46)))
(let ((?x67 (bvsub (_ bv0 32) ?x130)))
(let ((?x310 ((_ sign_extend 32) ?x67)))
(let (($x1911 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x130)) ((_ sign_extend 1) ?x67)) true)))
(let (($x441 (or false false false)))
(let (($x56 (or $x441 false)))
(let (($x48 (or false $x56 (or $x1911))))
(let (($x20 (or $x48 false)))
(and (not $x20) (or $x20 (and (distinct ?x310 ?x310) true)))))))))))))
(check-sat)
; query 44: function gsm_L_asr, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x475 (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x441 (or false false false)))
(let (($x30 (not $x441)))
(and $x30 (or $x441 (and (distinct ?x475 ?x475) true)))))))
(check-sat)
; query 45: function gsm_L_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x150 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x441 (or false false false)))
(let (($x30 (not $x441)))
(and $x30 (or $x441 (and (distinct ?x150 ?x150) true)))))))
(check-sat)
; query 46: function gsm_L_mult, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x1936 (or false false)))
(let (($x182 (not $x1936)))
(and $x182 (or $x1936 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 47: function gsm_L_mult, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x317 (ite (and (distinct (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) true) (_ bv1 1) (_ bv0 1))))
(let (($x1936 (or false false)))
(let (($x821 (or $x1936 false false)))
(let (($x31 (not $x821)))
(and $x31 (or $x821 (and (distinct ?x317 ?x317) true))))))))
(check-sat)
; query 48: function gsm_L_mult, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x1936 (or false false)))
(let (($x182 (not $x1936)))
(and $x182 (or $x1936 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 49: function gsm_L_mult, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x259 (ite (and (distinct (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) true) (_ bv1 1) (_ bv0 1))))
(let (($x1936 (or false false)))
(let (($x821 (or $x1936 false false)))
(let (($x31 (not $x821)))
(and $x31 (or $x821 (and (distinct ?x259 ?x259) true))))))))
(check-sat)
; query 50: function gsm_L_sub, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x216 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x441 (or false false false)))
(let (($x30 (not $x441)))
(and $x30 (or $x441 (and (distinct ?x216 ?x216) true)))))))
(check-sat)
; query 51: function gsm_L_sub, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x1048 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvsub in0_64 in1_64))) true)))
(let (($x1514 (or false false (or $x1048))))
(let (($x1566 (or $x1514 (and (distinct (bvsub in0_64 in1_64) (bvsub in0_64 in1_64)) true))))
(and (not $x1514) $x1566)))))
(check-sat)
; query 52: function gsm_L_sub, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x50 (bvadd in1_64 (_ bv1 64))))
(let ((?x87 (bvsub (_ bv0 64) ?x50)))
(let (($x392 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x50)) ((_ sign_extend 1) ?x87)) true)))
(let ((?x53 ((_ sign_extend 1) ?x50)))
(let (($x27 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x53) true)))))
(let (($x135 (or false $x27 (or $x392))))
(and (not $x135) (or $x135 (and (distinct ?x87 ?x87) true))))))))))
(check-sat)
; query 53: function gsm_L_sub, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x50 (bvadd in1_64 (_ bv1 64))))
(let ((?x87 (bvsub (_ bv0 64) ?x50)))
(let ((?x178 (bvadd ?x87 in0_64)))
(let ((?x1439 (bvadd in0_64 ?x87)))
(let (($x392 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x50)) ((_ sign_extend 1) ?x87)) true)))
(let ((?x53 ((_ sign_extend 1) ?x50)))
(let (($x27 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x53) true)))))
(let (($x135 (or false $x27 (or $x392))))
(let (($x1831 (or $x135 false false)))
(and (not (or false $x135 false)) (or $x1831 (and (distinct ?x1439 ?x178) true)))))))))))))
(check-sat)
; query 54: function gsm_L_sub, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1801 (ite (bvuge (bvadd (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64))) in0_64) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let ((?x89 (ite (bvuge (bvadd in0_64 (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64)))) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x392 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) (bvadd in1_64 (_ bv1 64)))) ((_ sign_extend 1) (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64))))) true)))
(let ((?x50 (bvadd in1_64 (_ bv1 64))))
(let ((?x53 ((_ sign_extend 1) ?x50)))
(let (($x27 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x53) true)))))
(let (($x135 (or false $x27 (or $x392))))
(let (($x1831 (or $x135 false false)))
(and (not (or (or false $x135 false) false false)) (or (or $x1831 false false) (and (distinct ?x89 ?x1801) true))))))))))))
(check-sat)
; query 55: function gsm_L_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x50 (bvadd in1_64 (_ bv1 64))))
(let ((?x53 ((_ sign_extend 1) ?x50)))
(let (($x27 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x53) true)))))
(and (not $x27) (or $x27 (and (distinct ?x50 ?x50) true)))))))
(check-sat)
; query 56: function gsm_L_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1865 (ite (bvsle (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x441 (or false false false)))
(let (($x30 (not $x441)))
(and $x30 (or $x441 (and (distinct ?x1865 ?x1865) true)))))))
(check-sat)
; query 57: function gsm_abs, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x1936 (or false false)))
(let (($x182 (not $x1936)))
(and $x182 (or $x1936 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 58: function gsm_abs, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1992 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1936 (or false false)))
(let (($x821 (or $x1936 false false)))
(let (($x31 (not $x821)))
(and $x31 (or $x821 (and (distinct ?x1992 ?x1992) true))))))))
(check-sat)
; query 59: function gsm_abs, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x1936 (or false false)))
(let (($x182 (not $x1936)))
(and $x182 (or $x1936 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 60: function gsm_abs, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x506 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1936 (or false false)))
(let (($x821 (or $x1936 false false)))
(let (($x31 (not $x821)))
(and $x31 (or $x821 (and (distinct ?x506 ?x506) true))))))))
(check-sat)
; query 61: function gsm_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x1936 (or false false)))
(let (($x182 (not $x1936)))
(and $x182 (or $x1936 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 62: function gsm_add, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x1936 (or false false)))
(let (($x182 (not $x1936)))
(and $x182 (or $x1936 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 63: function gsm_add, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1962 ((_ sign_extend 48) in0_16)))
(let ((?x4910 ((_ sign_extend 48) in1_16)))
(let ((?x1873 (bvadd ?x4910 ?x1962)))
(let ((?x2655 (bvadd ?x1962 ?x4910)))
(let (($x1959 (and (distinct (bvadd ((_ sign_extend 1) ?x4910) ((_ sign_extend 1) ?x1962)) ((_ sign_extend 1) ?x1873)) true)))
(let (($x1936 (or false false)))
(let (($x1843 (or $x1936 $x1936 (or $x1959))))
(let (($x1092 (and (distinct (bvadd ((_ sign_extend 1) ?x1962) ((_ sign_extend 1) ?x4910)) ((_ sign_extend 1) ?x2655)) true)))
(let (($x1828 (or $x1936 $x1936 (or $x1092))))
(and (not $x1828) (or $x1843 (and (distinct ?x2655 ?x1873) true)))))))))))))
(check-sat)
; query 64: function gsm_add, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x5119 (ite (bvsgt (_ bv18446744073709518848 64) (bvadd ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in0_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x131 (ite (bvsgt (_ bv18446744073709518848 64) (bvadd ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x1962 ((_ sign_extend 48) in0_16)))
(let ((?x179 ((_ sign_extend 1) ?x1962)))
(let ((?x4910 ((_ sign_extend 48) in1_16)))
(let ((?x1029 ((_ sign_extend 1) ?x4910)))
(let (($x1936 (or false false)))
(let (($x1843 (or $x1936 $x1936 (or (and (distinct (bvadd ?x1029 ?x179) ((_ sign_extend 1) (bvadd ?x4910 ?x1962))) true)))))
(let (($x1828 (or $x1936 $x1936 (or (and (distinct (bvadd ?x179 ?x1029) ((_ sign_extend 1) (bvadd ?x1962 ?x4910))) true)))))
(and (not (or $x1828 false false)) (or (or $x1843 false false) (and (distinct ?x131 ?x5119) true)))))))))))))
(check-sat)
; query 65: function gsm_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1946 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x441 (or false false false)))
(let (($x30 (not $x441)))
(and $x30 (or $x441 (and (distinct ?x1946 ?x1946) true)))))))
(check-sat)
; query 66: function gsm_asr, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x357 (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x441 (or false false false)))
(let (($x30 (not $x441)))
(and $x30 (or $x441 (and (distinct ?x357 ?x357) true)))))))
(check-sat)
; query 67: function gsm_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x1936 (or false false)))
(let (($x182 (not $x1936)))
(and $x182 (or $x1936 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 68: function gsm_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x506 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1936 (or false false)))
(let (($x821 (or $x1936 false false)))
(let (($x31 (not $x821)))
(and $x31 (or $x821 (and (distinct ?x506 ?x506) true))))))))
(check-sat)
; query 69: function gsm_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x506 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x558 ((_ zero_extend 31) ?x506)))
(let (($x1936 (or false false)))
(let (($x821 (or $x1936 false false)))
(let (($x517 (or $x821 false)))
(and (not $x517) (or $x517 (and (distinct ?x558 ?x558) true)))))))))
(check-sat)
; query 70: function gsm_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x506 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x558 ((_ zero_extend 31) ?x506)))
(let ((?x1883 (bvsub (_ bv0 32) ?x558)))
(let (($x1162 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x558)) ((_ sign_extend 1) ?x1883)) true)))
(let (($x1936 (or false false)))
(let (($x821 (or $x1936 false false)))
(let (($x517 (or $x821 false)))
(let (($x567 (or false $x517 (or $x1162))))
(and (not $x567) (or $x567 (and (distinct ?x1883 ?x1883) true))))))))))))
(check-sat)
; query 71: function gsm_asr, block 4, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x506 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x558 ((_ zero_extend 31) ?x506)))
(let ((?x1883 (bvsub (_ bv0 32) ?x558)))
(let ((?x1080 ((_ extract 15 0) ?x1883)))
(let (($x1162 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x558)) ((_ sign_extend 1) ?x1883)) true)))
(let (($x1936 (or false false)))
(let (($x821 (or $x1936 false false)))
(let (($x517 (or $x821 false)))
(let (($x567 (or false $x517 (or $x1162))))
(let (($x1423 (or $x567 false)))
(and (not $x1423) (or $x1423 (and (distinct ?x1080 ?x1080) true))))))))))))))
(check-sat)
; query 72: function gsm_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1946 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x441 (or false false false)))
(let (($x30 (not $x441)))
(and $x30 (or $x441 (and (distinct ?x1946 ?x1946) true)))))))
(check-sat)
; query 73: function gsm_debug_longwords, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in15_32 () (_ BitVec 32))
(assert
 (let ((?x1332 (ite (bvslt in15_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x441 (or false false false)))
(let (($x30 (not $x441)))
(and $x30 (or $x441 (and (distinct ?x1332 ?x1332) true)))))))
(check-sat)
; query 74: function gsm_debug_words, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in16_32 () (_ BitVec 32))
(assert
 (let ((?x1569 (ite (bvslt in16_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x441 (or false false false)))
(let (($x30 (not $x441)))
(and $x30 (or $x441 (and (distinct ?x1569 ?x1569) true)))))))
(check-sat)
; query 75: function gsm_div, block 7, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1104 (ite (bvsge ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1936 (or false false)))
(let (($x1897 (or $x1936 $x1936 false)))
(and (not $x1897) (or $x1897 (and (distinct ?x1104 ?x1104) true)))))))
(check-sat)
; query 76: function gsm_div, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x1936 (or false false)))
(let (($x182 (not $x1936)))
(and $x182 (or $x1936 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 77: function gsm_div, block 7, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x1936 (or false false)))
(let (($x182 (not $x1936)))
(and $x182 (or $x1936 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 78: function gsm_div, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x1936 (or false false)))
(let (($x182 (not $x1936)))
(and $x182 (or $x1936 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 79: function gsm_div, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x1936 (or false false)))
(let (($x182 (not $x1936)))
(and $x182 (or $x1936 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 80: function gsm_div, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x1936 (or false false)))
(let (($x182 (not $x1936)))
(and $x182 (or $x1936 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 81: function gsm_div, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x309 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x85 (and (distinct ?x309 ?x309) true)))
(let (($x1936 (or false false)))
(let (($x821 (or $x1936 false false)))
(let (($x31 (not $x821)))
(and $x31 (or $x821 $x85))))))))
(check-sat)
; query 82: function gsm_mult, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x1936 (or false false)))
(let (($x182 (not $x1936)))
(and $x182 (or $x1936 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 83: function gsm_mult, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x253 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1936 (or false false)))
(let (($x821 (or $x1936 false false)))
(let (($x31 (not $x821)))
(and $x31 (or $x821 (and (distinct ?x253 ?x253) true))))))))
(check-sat)
; query 84: function gsm_mult, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x1936 (or false false)))
(let (($x182 (not $x1936)))
(and $x182 (or $x1936 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 85: function gsm_mult, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1992 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1936 (or false false)))
(let (($x821 (or $x1936 false false)))
(let (($x31 (not $x821)))
(and $x31 (or $x821 (and (distinct ?x1992 ?x1992) true))))))))
(check-sat)
; query 86: function gsm_mult_r, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x1936 (or false false)))
(let (($x182 (not $x1936)))
(and $x182 (or $x1936 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 87: function gsm_mult_r, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1992 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1936 (or false false)))
(let (($x821 (or $x1936 false false)))
(let (($x31 (not $x821)))
(and $x31 (or $x821 (and (distinct ?x1992 ?x1992) true))))))))
(check-sat)
; query 88: function gsm_mult_r, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x1936 (or false false)))
(let (($x182 (not $x1936)))
(and $x182 (or $x1936 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 89: function gsm_mult_r, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x253 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1936 (or false false)))
(let (($x821 (or $x1936 false false)))
(let (($x31 (not $x821)))
(and $x31 (or $x821 (and (distinct ?x253 ?x253) true))))))))
(check-sat)
; query 90: function gsm_norm, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1807 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x441 (or false false false)))
(let (($x30 (not $x441)))
(and $x30 (or $x441 (and (distinct ?x1807 ?x1807) true)))))))
(check-sat)
; query 91: function gsm_norm, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1807 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x1220 (bvxor ?x1807 (_ bv1 1))))
(let (($x441 (or false false false)))
(let (($x1999 (or $x441 false false)))
(and (not $x1999) (or $x1999 (and (distinct ?x1220 ?x1220) true))))))))
(check-sat)
; query 92: function gsm_norm, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1807 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x1220 (bvxor ?x1807 (_ bv1 1))))
(let ((?x1812 ((_ zero_extend 31) ?x1220)))
(let (($x441 (or false false false)))
(let (($x1999 (or $x441 false false)))
(let (($x2019 (or $x1999 false)))
(and (not $x2019) (or $x2019 (and (distinct ?x1812 ?x1812) true))))))))))
(check-sat)
; query 93: function gsm_norm, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1807 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x1220 (bvxor ?x1807 (_ bv1 1))))
(let ((?x1812 ((_ zero_extend 31) ?x1220)))
(let ((?x883 ((_ sign_extend 32) ?x1812)))
(let (($x441 (or false false false)))
(let (($x1999 (or $x441 false false)))
(let (($x2019 (or $x1999 false)))
(let (($x766 (or $x2019 false)))
(and (not $x766) (or $x766 (and (distinct ?x883 ?x883) true))))))))))))
(check-sat)
; query 94: function gsm_norm, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1807 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x1220 (bvxor ?x1807 (_ bv1 1))))
(let ((?x1812 ((_ zero_extend 31) ?x1220)))
(let ((?x883 ((_ sign_extend 32) ?x1812)))
(let ((?x1479 (ite (and (distinct (_ bv0 64) ?x883) true) (_ bv1 1) (_ bv0 1))))
(let (($x441 (or false false false)))
(let (($x1999 (or $x441 false false)))
(let (($x2019 (or $x1999 false)))
(let (($x766 (or $x2019 false)))
(let (($x822 (or $x766 false false)))
(and (not $x822) (or $x822 (and (distinct ?x1479 ?x1479) true))))))))))))))
(check-sat)
; query 95: function gsm_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x1936 (or false false)))
(let (($x182 (not $x1936)))
(and $x182 (or $x1936 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 96: function gsm_sub, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x1936 (or false false)))
(let (($x182 (not $x1936)))
(and $x182 (or $x1936 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 97: function gsm_sub, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x4910 ((_ sign_extend 48) in1_16)))
(let ((?x1962 ((_ sign_extend 48) in0_16)))
(let ((?x1898 (bvsub ?x1962 ?x4910)))
(let (($x1928 (and (distinct (bvsub ((_ sign_extend 1) ?x1962) ((_ sign_extend 1) ?x4910)) ((_ sign_extend 1) ?x1898)) true)))
(let (($x1936 (or false false)))
(let (($x2990 (or $x1936 $x1936 (or $x1928))))
(and (not $x2990) (or $x2990 (and (distinct ?x1898 ?x1898) true))))))))))
(check-sat)
; query 98: function gsm_sub, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1857 (ite (bvsgt (_ bv18446744073709518848 64) (bvsub ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x4910 ((_ sign_extend 48) in1_16)))
(let ((?x1029 ((_ sign_extend 1) ?x4910)))
(let ((?x1962 ((_ sign_extend 48) in0_16)))
(let ((?x179 ((_ sign_extend 1) ?x1962)))
(let (($x1936 (or false false)))
(let (($x2990 (or $x1936 $x1936 (or (and (distinct (bvsub ?x179 ?x1029) ((_ sign_extend 1) (bvsub ?x1962 ?x4910))) true)))))
(let (($x1051 (or $x2990 false false)))
(and (not $x1051) (or $x1051 (and (distinct ?x1857 ?x1857) true))))))))))))
(check-sat)
; query 99: function process_decode, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let (($x1936 (or false false)))
(let (($x182 (not $x1936)))
(and $x182 (or $x1936 (and (distinct ((_ sign_extend 32) in14_32) ((_ sign_extend 32) in14_32)) true))))))
(check-sat)
; query 100: function process_decode, block 16, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x1740 (ite (and (distinct (_ bv33 64) ((_ sign_extend 32) in14_32)) true) (_ bv1 1) (_ bv0 1))))
(let (($x1936 (or false false)))
(let (($x821 (or $x1936 false false)))
(let (($x31 (not $x821)))
(and $x31 (or $x821 (and (distinct ?x1740 ?x1740) true))))))))
(check-sat)
; query 101: function process_encode, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_32 () (_ BitVec 32))
(assert
 (let (($x1936 (or false false)))
(let (($x182 (not $x1936)))
(and $x182 (or $x1936 (and (distinct ((_ sign_extend 32) in13_32) ((_ sign_extend 32) in13_32)) true))))))
(check-sat)
; query 102: function process_encode, block 15, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_32 () (_ BitVec 32))
(assert
 (let ((?x2053 (ite (bvult ((_ sign_extend 32) in13_32) (_ bv160 64)) (_ bv1 1) (_ bv0 1))))
(let (($x1936 (or false false)))
(let (($x821 (or $x1936 false false)))
(let (($x31 (not $x821)))
(and $x31 (or $x821 (and (distinct ?x2053 ?x2053) true))))))))
(check-sat)
; query 103: function suffix, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_64 () (_ BitVec 64))
(declare-fun in3_64 () (_ BitVec 64))
(assert
 (let ((?x2764 (ite (bvule in3_64 in4_64) (_ bv1 1) (_ bv0 1))))
(let (($x441 (or false false false)))
(let (($x30 (not $x441)))
(and $x30 (or $x441 (and (distinct ?x2764 ?x2764) true)))))))
(check-sat)
