; OptiPhase-Sigma refinement certificate for sweep K47-R3-272
; query 0: function adpcm_coder, block 25, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in20_32 () (_ BitVec 32))
(assert
 (let (($x818 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in20_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in20_32))) true)))
(let (($x1215 (or false false (or $x818))))
(and (not $x1215) (or $x1215 (and (distinct (bvsub (_ bv0 32) in20_32) (bvsub (_ bv0 32) in20_32)) true))))))
(check-sat)
; query 1: function adpcm_coder, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(declare-fun in.017_32 () (_ BitVec 32))
(assert
 (let ((?x7 (bvsub in.017_32 in.020_32)))
(let (($x11 (and (distinct (bvsub ((_ sign_extend 1) in.017_32) ((_ sign_extend 1) in.020_32)) ((_ sign_extend 1) ?x7)) true)))
(let (($x83 (or false false (or $x11))))
(and (not $x83) (or $x83 (and (distinct ?x7 ?x7) true)))))))
(check-sat)
; query 2: function adpcm_coder, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(declare-fun in28_32 () (_ BitVec 32))
(assert
 (let (($x848 (and (distinct (bvadd ((_ sign_extend 1) in28_32) ((_ sign_extend 1) in.020_32)) ((_ sign_extend 1) (bvadd in28_32 in.020_32))) true)))
(let (($x145 (or false false (or $x848))))
(let (($x495 (or $x145 (and (distinct (bvadd in28_32 in.020_32) (bvadd in28_32 in.020_32)) true))))
(and (not $x145) $x495)))))
(check-sat)
; query 3: function adpcm_coder, block 36, name %37
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.014_32 () (_ BitVec 32))
(assert
 (let (($x79 (or false false false)))
(let (($x23 (not $x79)))
(and $x23 (or $x79 (and (distinct (bvor in.014_32 (_ bv2 32)) (bvor in.014_32 (_ bv2 32))) true))))))
(check-sat)
; query 4: function adpcm_coder, block 36, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in34_32 () (_ BitVec 32))
(declare-fun in.118_32 () (_ BitVec 32))
(assert
 (let (($x443 (and (distinct (bvsub ((_ sign_extend 1) in.118_32) ((_ sign_extend 1) in34_32)) ((_ sign_extend 1) (bvsub in.118_32 in34_32))) true)))
(let (($x290 (or false false (or $x443))))
(let (($x584 (or $x290 (and (distinct (bvsub in.118_32 in34_32) (bvsub in.118_32 in34_32)) true))))
(and (not $x290) $x584)))))
(check-sat)
; query 5: function adpcm_coder, block 36, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in34_32 () (_ BitVec 32))
(declare-fun in.08_32 () (_ BitVec 32))
(assert
 (let (($x494 (and (distinct (bvadd ((_ sign_extend 1) in.08_32) ((_ sign_extend 1) in34_32)) ((_ sign_extend 1) (bvadd in.08_32 in34_32))) true)))
(let (($x46 (or false false (or $x494))))
(let (($x235 (or $x46 (and (distinct (bvadd in.08_32 in34_32) (bvadd in.08_32 in34_32)) true))))
(and (not $x46) $x235)))))
(check-sat)
; query 6: function adpcm_coder, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.115_32 () (_ BitVec 32))
(assert
 (let (($x79 (or false false false)))
(let (($x23 (not $x79)))
(and $x23 (or $x79 (and (distinct (bvor in.115_32 (_ bv1 32)) (bvor in.115_32 (_ bv1 32))) true))))))
(check-sat)
; query 7: function adpcm_coder, block 43, name %45
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in41_32 () (_ BitVec 32))
(declare-fun in.19_32 () (_ BitVec 32))
(assert
 (let (($x583 (and (distinct (bvadd ((_ sign_extend 1) in.19_32) ((_ sign_extend 1) in41_32)) ((_ sign_extend 1) (bvadd in.19_32 in41_32))) true)))
(let (($x94 (or false false (or $x583))))
(let (($x50 (or $x94 (and (distinct (bvadd in.19_32 in41_32) (bvadd in.19_32 in41_32)) true))))
(and (not $x94) $x50)))))
(check-sat)
; query 8: function adpcm_coder, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.210_32 () (_ BitVec 32))
(declare-fun in.011_32 () (_ BitVec 32))
(assert
 (let ((?x1699 (bvsub in.011_32 in.210_32)))
(let (($x54 (and (distinct (bvsub ((_ sign_extend 1) in.011_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x1699)) true)))
(let (($x49 (or false false (or $x54))))
(and (not $x49) (or $x49 (and (distinct ?x1699 ?x1699) true)))))))
(check-sat)
; query 9: function adpcm_coder, block 50, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.210_32 () (_ BitVec 32))
(declare-fun in.011_32 () (_ BitVec 32))
(assert
 (let ((?x673 (bvadd in.011_32 in.210_32)))
(let (($x473 (and (distinct (bvadd ((_ sign_extend 1) in.011_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x673)) true)))
(let (($x307 (or false false (or $x473))))
(and (not $x307) (or $x307 (and (distinct ?x673 ?x673) true)))))))
(check-sat)
; query 10: function adpcm_coder, block 55, name %56
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.112_32 () (_ BitVec 32))
(assert
 (let ((?x185 (ite (bvsgt (_ bv4294934528 32) in.112_32) (_ bv1 1) (_ bv0 1))))
(let (($x79 (or false false false)))
(let (($x23 (not $x79)))
(and $x23 (or $x79 (and (distinct ?x185 ?x185) true)))))))
(check-sat)
; query 11: function adpcm_coder, block 75, name %76
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in60_32 () (_ BitVec 32))
(assert
 (let (($x633 (bvuge (_ bv4 32) (_ bv32 32))))
(let (($x60 (or (and (distinct (bvlshr (bvshl in60_32 (_ bv4 32)) (_ bv4 32)) in60_32) true) (and (distinct (bvashr (bvshl in60_32 (_ bv4 32)) (_ bv4 32)) in60_32) true))))
(let (($x122 (or (or false false $x60) $x633)))
(and (not (or (or false false false) $x633)) (or $x122 (and (distinct (bvshl in60_32 (_ bv4 32)) (bvshl in60_32 (_ bv4 32))) true)))))))
(check-sat)
; query 12: function adpcm_coder, block 75, name %77
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in60_32 () (_ BitVec 32))
(assert
 (let ((?x912 (bvshl in60_32 (_ bv4 32))))
(let ((?x1125 (bvand ?x912 (_ bv240 32))))
(let (($x633 (bvuge (_ bv4 32) (_ bv32 32))))
(let (($x60 (or (and (distinct (bvlshr ?x912 (_ bv4 32)) in60_32) true) (and (distinct (bvashr ?x912 (_ bv4 32)) in60_32) true))))
(let (($x122 (or (or false false $x60) $x633)))
(and (not (or (or (or false false false) $x633) false false)) (or (or $x122 false false) (and (distinct ?x1125 ?x1125) true)))))))))
(check-sat)
; query 13: function adpcm_decoder, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x1924 (ite (and (distinct (_ bv0 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x79 (or false false false)))
(let (($x23 (not $x79)))
(and $x23 (or $x79 (and (distinct ?x1924 ?x1924) true)))))))
(check-sat)
; query 14: function adpcm_decoder, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x79 (or false false false)))
(let (($x23 (not $x79)))
(and $x23 (or $x79 (and (distinct (bvand in.01_32 (_ bv15 32)) (bvand in.01_32 (_ bv15 32))) true))))))
(check-sat)
; query 15: function adpcm_decoder, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.012_32 () (_ BitVec 32))
(declare-fun in42_32 () (_ BitVec 32))
(assert
 (let (($x499 (and (distinct (bvadd ((_ sign_extend 1) in42_32) ((_ sign_extend 1) in.012_32)) ((_ sign_extend 1) (bvadd in42_32 in.012_32))) true)))
(let (($x1644 (or false false (or $x499))))
(let (($x165 (or $x1644 (and (distinct (bvadd in42_32 in.012_32) (bvadd in42_32 in.012_32)) true))))
(and (not $x1644) $x165)))))
(check-sat)
; query 16: function adpcm_decoder, block 50, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.012_32 () (_ BitVec 32))
(assert
 (let (($x79 (or false false false)))
(let (($x1107 (or $x79 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x703 (or $x1107 (and (distinct (bvashr in.012_32 (_ bv1 32)) (bvashr in.012_32 (_ bv1 32))) true))))
(and (not $x1107) $x703)))))
(check-sat)
; query 17: function adpcm_decoder, block 50, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.012_32 () (_ BitVec 32))
(declare-fun in.08_32 () (_ BitVec 32))
(assert
 (let ((?x35 (bvashr in.012_32 (_ bv1 32))))
(let ((?x1407 (bvadd in.08_32 ?x35)))
(let (($x1241 (and (distinct (bvadd ((_ sign_extend 1) in.08_32) ((_ sign_extend 1) ?x35)) ((_ sign_extend 1) ?x1407)) true)))
(let (($x79 (or false false false)))
(let (($x1107 (or $x79 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x1001 (or false $x1107 (or $x1241))))
(and (not $x1001) (or $x1001 (and (distinct ?x1407 ?x1407) true))))))))))
(check-sat)
; query 18: function adpcm_decoder, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.012_32 () (_ BitVec 32))
(assert
 (let (($x79 (or false false false)))
(let (($x731 (or $x79 (bvuge (_ bv2 32) (_ bv32 32)))))
(let (($x537 (or $x731 (and (distinct (bvashr in.012_32 (_ bv2 32)) (bvashr in.012_32 (_ bv2 32))) true))))
(and (not $x731) $x537)))))
(check-sat)
; query 19: function adpcm_decoder, block 56, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.012_32 () (_ BitVec 32))
(declare-fun in.19_32 () (_ BitVec 32))
(assert
 (let ((?x1349 (bvashr in.012_32 (_ bv2 32))))
(let ((?x1576 (bvadd in.19_32 ?x1349)))
(let (($x550 (and (distinct (bvadd ((_ sign_extend 1) in.19_32) ((_ sign_extend 1) ?x1349)) ((_ sign_extend 1) ?x1576)) true)))
(let (($x79 (or false false false)))
(let (($x731 (or $x79 (bvuge (_ bv2 32) (_ bv32 32)))))
(let (($x742 (or false $x731 (or $x550))))
(and (not $x742) (or $x742 (and (distinct ?x1576 ?x1576) true))))))))))
(check-sat)
; query 20: function adpcm_decoder, block 61, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.210_32 () (_ BitVec 32))
(declare-fun in.013_32 () (_ BitVec 32))
(assert
 (let ((?x345 (bvsub in.013_32 in.210_32)))
(let (($x64 (and (distinct (bvsub ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x345)) true)))
(let (($x1361 (or false false (or $x64))))
(and (not $x1361) (or $x1361 (and (distinct ?x345 ?x345) true)))))))
(check-sat)
; query 21: function adpcm_decoder, block 63, name %64
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.210_32 () (_ BitVec 32))
(declare-fun in.013_32 () (_ BitVec 32))
(assert
 (let ((?x1039 (bvadd in.013_32 in.210_32)))
(let (($x74 (and (distinct (bvadd ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x1039)) true)))
(let (($x972 (or false false (or $x74))))
(and (not $x972) (or $x972 (and (distinct ?x1039 ?x1039) true)))))))
(check-sat)
; query 22: function adpcm_decoder, block 68, name %69
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.114_32 () (_ BitVec 32))
(assert
 (let ((?x1562 (ite (bvsgt (_ bv4294934528 32) in.114_32) (_ bv1 1) (_ bv0 1))))
(let (($x79 (or false false false)))
(let (($x23 (not $x79)))
(and $x23 (or $x79 (and (distinct ?x1562 ?x1562) true)))))))
(check-sat)
; query 23: function adpcm_decoder, block 78, name %79
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x55 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv4294967295 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv4294967295 32)))) true)))
(let (($x1760 (or false false (or $x55))))
(and (not $x1760) (or $x1760 (and (distinct (bvadd in.02_32 (_ bv4294967295 32)) (bvadd in.02_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 24: function main, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x219 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x79 (or false false false)))
(let (($x23 (not $x79)))
(and $x23 (or $x79 (and (distinct ?x219 ?x219) true)))))))
(check-sat)
