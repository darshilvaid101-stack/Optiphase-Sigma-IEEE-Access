; OptiPhase-Sigma refinement certificate for sweep K19-R2-079
; query 0: function init_array, block 103, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x109 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x110 (or false false (or $x109))))
(and (not $x110) (or $x110 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function init_array, block 106, name %107
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.13_32 () (_ BitVec 32))
(assert
 (let (($x88 (and (distinct (bvadd ((_ sign_extend 1) in.13_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.13_32 (_ bv1 32)))) true)))
(let (($x45 (or false false (or $x88))))
(and (not $x45) (or $x45 (and (distinct (bvadd in.13_32 (_ bv1 32)) (bvadd in.13_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function init_array, block 109, name %110
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x13 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x116 (or false false (or $x13))))
(and (not $x116) (or $x116 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 3: function init_array, block 127, name %128
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let (($x70 (and (distinct (bvadd ((_ sign_extend 1) in.2_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.2_32 (_ bv1 32)))) true)))
(let (($x102 (or false false (or $x70))))
(and (not $x102) (or $x102 (and (distinct (bvadd in.2_32 (_ bv1 32)) (bvadd in.2_32 (_ bv1 32))) true))))))
(check-sat)
; query 4: function init_array, block 130, name %131
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.24_32 () (_ BitVec 32))
(assert
 (let (($x104 (and (distinct (bvadd ((_ sign_extend 1) in.24_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.24_32 (_ bv1 32)))) true)))
(let (($x153 (or false false (or $x104))))
(and (not $x153) (or $x153 (and (distinct (bvadd in.24_32 (_ bv1 32)) (bvadd in.24_32 (_ bv1 32))) true))))))
(check-sat)
; query 5: function init_array, block 21, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.07_32 () (_ BitVec 32))
(assert
 (let (($x125 (and (distinct (bvadd ((_ sign_extend 1) in.07_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.07_32 (_ bv1 32)))) true)))
(let (($x28 (or false false (or $x125))))
(and (not $x28) (or $x28 (and (distinct (bvadd in.07_32 (_ bv1 32)) (bvadd in.07_32 (_ bv1 32))) true))))))
(check-sat)
; query 6: function init_array, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.05_32 () (_ BitVec 32))
(assert
 (let (($x139 (and (distinct (bvadd ((_ sign_extend 1) in.05_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.05_32 (_ bv1 32)))) true)))
(let (($x6 (or false false (or $x139))))
(and (not $x6) (or $x6 (and (distinct (bvadd in.05_32 (_ bv1 32)) (bvadd in.05_32 (_ bv1 32))) true))))))
(check-sat)
; query 7: function init_array, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.18_32 () (_ BitVec 32))
(assert
 (let (($x58 (and (distinct (bvadd ((_ sign_extend 1) in.18_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.18_32 (_ bv1 32)))) true)))
(let (($x156 (or false false (or $x58))))
(and (not $x156) (or $x156 (and (distinct (bvadd in.18_32 (_ bv1 32)) (bvadd in.18_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function init_array, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.16_32 () (_ BitVec 32))
(assert
 (let (($x33 (and (distinct (bvadd ((_ sign_extend 1) in.16_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.16_32 (_ bv1 32)))) true)))
(let (($x34 (or false false (or $x33))))
(and (not $x34) (or $x34 (and (distinct (bvadd in.16_32 (_ bv1 32)) (bvadd in.16_32 (_ bv1 32))) true))))))
(check-sat)
; query 9: function init_array, block 58, name %59
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.18_32 () (_ BitVec 32))
(assert
 (let (($x58 (and (distinct (bvadd ((_ sign_extend 1) in.18_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.18_32 (_ bv1 32)))) true)))
(let (($x156 (or false false (or $x58))))
(and (not $x156) (or $x156 (and (distinct (bvadd in.18_32 (_ bv1 32)) (bvadd in.18_32 (_ bv1 32))) true))))))
(check-sat)
; query 10: function init_array, block 72, name %73
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x78 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x112 (or false false (or $x78))))
(and (not $x112) (or $x112 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 11: function init_array, block 75, name %76
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x74 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x75 (or false false (or $x74))))
(and (not $x75) (or $x75 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 12: function kernel_ludcmp, block 103, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.25_32 () (_ BitVec 32))
(assert
 (let (($x93 (and (distinct (bvadd ((_ sign_extend 1) in.25_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.25_32 (_ bv1 32)))) true)))
(let (($x105 (or false false (or $x93))))
(and (not $x105) (or $x105 (and (distinct (bvadd in.25_32 (_ bv1 32)) (bvadd in.25_32 (_ bv1 32))) true))))))
(check-sat)
; query 13: function kernel_ludcmp, block 108, name %109
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.18_32 () (_ BitVec 32))
(assert
 (let (($x58 (and (distinct (bvadd ((_ sign_extend 1) in.18_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.18_32 (_ bv1 32)))) true)))
(let (($x156 (or false false (or $x58))))
(and (not $x156) (or $x156 (and (distinct (bvadd in.18_32 (_ bv1 32)) (bvadd in.18_32 (_ bv1 32))) true))))))
(check-sat)
; query 14: function kernel_ludcmp, block 110, name %111
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x143 (and (distinct (bvsub ((_ sign_extend 1) in0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvsub in0_32 (_ bv1 32)))) true)))
(let (($x146 (or false false (or $x143))))
(and (not $x146) (or $x146 (and (distinct (bvsub in0_32 (_ bv1 32)) (bvsub in0_32 (_ bv1 32))) true))))))
(check-sat)
; query 15: function kernel_ludcmp, block 132, name %133
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.36_32 () (_ BitVec 32))
(assert
 (let (($x171 (and (distinct (bvadd ((_ sign_extend 1) in.36_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.36_32 (_ bv1 32)))) true)))
(let (($x157 (or false false (or $x171))))
(and (not $x157) (or $x157 (and (distinct (bvadd in.36_32 (_ bv1 32)) (bvadd in.36_32 (_ bv1 32))) true))))))
(check-sat)
; query 16: function kernel_ludcmp, block 143, name %144
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.29_32 () (_ BitVec 32))
(assert
 (let (($x182 (and (distinct (bvadd ((_ sign_extend 1) in.29_32) ((_ sign_extend 1) (_ bv4294967295 32))) ((_ sign_extend 1) (bvadd in.29_32 (_ bv4294967295 32)))) true)))
(let (($x184 (or false false (or $x182))))
(and (not $x184) (or $x184 (and (distinct (bvadd in.29_32 (_ bv4294967295 32)) (bvadd in.29_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 17: function kernel_ludcmp, block 32, name %33
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x78 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x112 (or false false (or $x78))))
(and (not $x112) (or $x112 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 18: function kernel_ludcmp, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_32 () (_ BitVec 32))
(assert
 (let (($x194 (and (distinct (bvadd ((_ sign_extend 1) in.03_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.03_32 (_ bv1 32)))) true)))
(let (($x196 (or false false (or $x194))))
(and (not $x196) (or $x196 (and (distinct (bvadd in.03_32 (_ bv1 32)) (bvadd in.03_32 (_ bv1 32))) true))))))
(check-sat)
; query 19: function kernel_ludcmp, block 71, name %72
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x206 (and (distinct (bvadd ((_ sign_extend 1) in.12_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.12_32 (_ bv1 32)))) true)))
(let (($x208 (or false false (or $x206))))
(and (not $x208) (or $x208 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 20: function kernel_ludcmp, block 78, name %79
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.14_32 () (_ BitVec 32))
(assert
 (let (($x218 (and (distinct (bvadd ((_ sign_extend 1) in.14_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.14_32 (_ bv1 32)))) true)))
(let (($x220 (or false false (or $x218))))
(and (not $x220) (or $x220 (and (distinct (bvadd in.14_32 (_ bv1 32)) (bvadd in.14_32 (_ bv1 32))) true))))))
(check-sat)
; query 21: function kernel_ludcmp, block 81, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.07_32 () (_ BitVec 32))
(assert
 (let (($x125 (and (distinct (bvadd ((_ sign_extend 1) in.07_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.07_32 (_ bv1 32)))) true)))
(let (($x28 (or false false (or $x125))))
(and (not $x28) (or $x28 (and (distinct (bvadd in.07_32 (_ bv1 32)) (bvadd in.07_32 (_ bv1 32))) true))))))
(check-sat)
; query 22: function polybench_flush_cache, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x78 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x112 (or false false (or $x78))))
(and (not $x112) (or $x112 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 23: function print_array, block 21, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x13 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x116 (or false false (or $x13))))
(and (not $x116) (or $x116 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 24: function xmalloc, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in7_32 () (_ BitVec 32))
(assert
 (let ((?x231 (ite (and (distinct (_ bv0 32) in7_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x228 (or false false false)))
(and (not $x228) (or $x228 (and (distinct ?x231 ?x231) true))))))
(check-sat)
