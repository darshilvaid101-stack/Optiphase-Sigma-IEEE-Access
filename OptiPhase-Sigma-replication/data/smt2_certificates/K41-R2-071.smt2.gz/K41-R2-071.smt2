; OptiPhase-Sigma refinement certificate for sweep K41-R2-071
; query 0: function decfile, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in17_32 () (_ BitVec 32))
(assert
 (let ((?x77 (ite (and (distinct (_ bv16 32) in17_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x171 (or false false false)))
(let (($x53 (not $x171)))
(and $x53 (or $x171 (and (distinct ?x77 ?x77) true)))))))
(check-sat)
; query 1: function decfile, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x18 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x478 (or false false (or $x18))))
(and (not $x478) (or $x478 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function decfile, block 82, name %83
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x393 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x104 (or false false (or $x393))))
(and (not $x104) (or $x104 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 3: function decfile, block 85, name %86
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x675 (ite (= (_ bv15 32) in.01.lcssa_32) (_ bv1 1) (_ bv0 1))))
(let (($x171 (or false false false)))
(let (($x53 (not $x171)))
(and $x53 (or $x171 (and (distinct ?x675 ?x675) true)))))))
(check-sat)
; query 4: function decfile, block 85, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x675 (ite (= (_ bv15 32) in.01.lcssa_32) (_ bv1 1) (_ bv0 1))))
(let ((?x127 ((_ zero_extend 63) ?x675)))
(let (($x171 (or false false false)))
(let (($x37 (or $x171 false)))
(and (not $x37) (or $x37 (and (distinct ?x127 ?x127) true))))))))
(check-sat)
; query 5: function decfile, block 85, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x675 (ite (= (_ bv15 32) in.01.lcssa_32) (_ bv1 1) (_ bv0 1))))
(let (($x42 (= (_ bv1 1) ?x675)))
(let ((?x83 (ite $x42 (_ bv1 32) (_ bv0 32))))
(let (($x171 (or false false false)))
(let (($x43 (or $x171 (ite $x42 false false))))
(and (not $x43) (or $x43 (and (distinct ?x83 ?x83) true)))))))))
(check-sat)
; query 6: function decfile, block 85, name %89
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x675 (ite (= (_ bv15 32) in.01.lcssa_32) (_ bv1 1) (_ bv0 1))))
(let (($x42 (= (_ bv1 1) ?x675)))
(let ((?x83 (ite $x42 (_ bv1 32) (_ bv0 32))))
(let ((?x61 (bvsub (_ bv1 32) ?x83)))
(let ((?x24 ((_ sign_extend 1) ?x61)))
(let (($x171 (or false false false)))
(let (($x43 (or $x171 (ite $x42 false false))))
(let (($x112 (or false $x43 (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv1 32)) ((_ sign_extend 1) ?x83)) ?x24) true)))))
(and (not $x112) (or $x112 (and (distinct ?x61 ?x61) true))))))))))))
(check-sat)
; query 7: function decfile, block 85, name %90
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01.lcssa_32 () (_ BitVec 32))
(declare-fun in46_32 () (_ BitVec 32))
(assert
 (let ((?x675 (ite (= (_ bv15 32) in.01.lcssa_32) (_ bv1 1) (_ bv0 1))))
(let (($x42 (= (_ bv1 1) ?x675)))
(let ((?x83 (ite $x42 (_ bv1 32) (_ bv0 32))))
(let ((?x61 (bvsub (_ bv1 32) ?x83)))
(let ((?x59 (bvadd in46_32 ?x61)))
(let (($x468 (and (distinct (bvadd ((_ sign_extend 1) in46_32) ((_ sign_extend 1) ?x61)) ((_ sign_extend 1) ?x59)) true)))
(let ((?x24 ((_ sign_extend 1) ?x61)))
(let (($x171 (or false false false)))
(let (($x43 (or $x171 (ite $x42 false false))))
(let (($x112 (or false $x43 (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv1 32)) ((_ sign_extend 1) ?x83)) ?x24) true)))))
(let (($x464 (or false $x112 (or $x468))))
(and (not $x464) (or $x464 (and (distinct ?x59 ?x59) true)))))))))))))))
(check-sat)
; query 8: function decfile, block 85, name %91
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01.lcssa_32 () (_ BitVec 32))
(declare-fun in46_32 () (_ BitVec 32))
(assert
 (let ((?x675 (ite (= (_ bv15 32) in.01.lcssa_32) (_ bv1 1) (_ bv0 1))))
(let (($x42 (= (_ bv1 1) ?x675)))
(let ((?x83 (ite $x42 (_ bv1 32) (_ bv0 32))))
(let ((?x61 (bvsub (_ bv1 32) ?x83)))
(let ((?x59 (bvadd in46_32 ?x61)))
(let ((?x44 (ite (and (distinct (_ bv0 32) ?x59) true) (_ bv1 1) (_ bv0 1))))
(let (($x468 (and (distinct (bvadd ((_ sign_extend 1) in46_32) ((_ sign_extend 1) ?x61)) ((_ sign_extend 1) ?x59)) true)))
(let ((?x24 ((_ sign_extend 1) ?x61)))
(let (($x171 (or false false false)))
(let (($x43 (or $x171 (ite $x42 false false))))
(let (($x112 (or false $x43 (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv1 32)) ((_ sign_extend 1) ?x83)) ?x24) true)))))
(let (($x464 (or false $x112 (or $x468))))
(let (($x698 (or $x464 false false)))
(and (not $x698) (or $x698 (and (distinct ?x44 ?x44) true)))))))))))))))))
(check-sat)
; query 9: function encfile, block 50, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_64 () (_ BitVec 64))
(assert
 (let (($x171 (or false false false)))
(let (($x53 (not $x171)))
(and $x53 (or $x171 (and (distinct (bvadd in.1_64 (_ bv1 64)) (bvadd in.1_64 (_ bv1 64))) true))))))
(check-sat)
; query 10: function encfile, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_64 () (_ BitVec 64))
(assert
 (let (($x171 (or false false false)))
(let (($x53 (not $x171)))
(and $x53 (or $x171 (and (distinct (bvadd in.2_64 (_ bv1 64)) (bvadd in.2_64 (_ bv1 64))) true))))))
(check-sat)
; query 11: function encfile, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.5_64 () (_ BitVec 64))
(assert
 (let (($x171 (or false false false)))
(let (($x53 (not $x171)))
(and $x53 (or $x171 (and (distinct (bvadd in.5_64 (_ bv1 64)) (bvadd in.5_64 (_ bv1 64))) true))))))
(check-sat)
; query 12: function fillrand, block 34, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x12 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x78 (or false false (or $x12))))
(and (not $x78) (or $x78 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 13: function main, block 41, name %42
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let (($x89 (or false false)))
(and (not $x89) (or $x89 (and (distinct ((_ sign_extend 24) in38_8) ((_ sign_extend 24) in38_8)) true)))))
(check-sat)
; query 14: function main, block 41, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let ((?x50 (ite (bvsge (_ bv57 32) ((_ sign_extend 24) in38_8)) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false)))
(let (($x176 (or $x89 false false)))
(let (($x70 (not $x176)))
(and $x70 (or $x176 (and (distinct ?x50 ?x50) true))))))))
(check-sat)
; query 15: function main, block 44, name %45
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x171 (or false false false)))
(let (($x178 (or $x171 (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x178) (or $x178 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvshl in.01_32 (_ bv4 32))) true))))))
(check-sat)
; query 16: function main, block 44, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let (($x89 (or false false)))
(and (not $x89) (or $x89 (and (distinct ((_ sign_extend 24) in38_8) ((_ sign_extend 24) in38_8)) true)))))
(check-sat)
; query 17: function main, block 44, name %47
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x81 ((_ sign_extend 24) in38_8)))
(let ((?x175 (bvshl in.01_32 (_ bv4 32))))
(let ((?x492 (bvadd ?x175 ?x81)))
(let ((?x30 ((_ sign_extend 1) ?x492)))
(let (($x89 (or false false)))
(let (($x171 (or false false false)))
(let (($x178 (or $x171 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x494 (or $x178 $x89 (or (and (distinct (bvadd ((_ sign_extend 1) ?x175) ((_ sign_extend 1) ?x81)) ?x30) true)))))
(and (not $x494) (or $x494 (and (distinct ?x492 ?x492) true))))))))))))
(check-sat)
; query 18: function main, block 44, name %48
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x81 ((_ sign_extend 24) in38_8)))
(let ((?x175 (bvshl in.01_32 (_ bv4 32))))
(let ((?x492 (bvadd ?x175 ?x81)))
(let ((?x799 (bvsub ?x492 (_ bv48 32))))
(let (($x158 (and (distinct (bvsub ((_ sign_extend 1) ?x492) ((_ sign_extend 1) (_ bv48 32))) ((_ sign_extend 1) ?x799)) true)))
(let ((?x30 ((_ sign_extend 1) ?x492)))
(let (($x89 (or false false)))
(let (($x171 (or false false false)))
(let (($x178 (or $x171 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x494 (or $x178 $x89 (or (and (distinct (bvadd ((_ sign_extend 1) ?x175) ((_ sign_extend 1) ?x81)) ?x30) true)))))
(let (($x238 (or $x494 false (or $x158))))
(and (not $x238) (or $x238 (and (distinct ?x799 ?x799) true)))))))))))))))
(check-sat)
; query 19: function main, block 49, name %50
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let (($x89 (or false false)))
(and (not $x89) (or $x89 (and (distinct ((_ sign_extend 24) in38_8) ((_ sign_extend 24) in38_8)) true)))))
(check-sat)
; query 20: function main, block 49, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let ((?x36 (ite (bvsle (_ bv65 32) ((_ sign_extend 24) in38_8)) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false)))
(let (($x176 (or $x89 false false)))
(let (($x70 (not $x176)))
(and $x70 (or $x176 (and (distinct ?x36 ?x36) true))))))))
(check-sat)
; query 21: function main, block 52, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let (($x89 (or false false)))
(and (not $x89) (or $x89 (and (distinct ((_ sign_extend 24) in38_8) ((_ sign_extend 24) in38_8)) true)))))
(check-sat)
; query 22: function main, block 52, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let ((?x708 (ite (bvsge (_ bv70 32) ((_ sign_extend 24) in38_8)) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false)))
(let (($x176 (or $x89 false false)))
(let (($x70 (not $x176)))
(and $x70 (or $x176 (and (distinct ?x708 ?x708) true))))))))
(check-sat)
; query 23: function main, block 55, name %56
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x171 (or false false false)))
(let (($x178 (or $x171 (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x178) (or $x178 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvshl in.01_32 (_ bv4 32))) true))))))
(check-sat)
; query 24: function main, block 55, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let (($x89 (or false false)))
(and (not $x89) (or $x89 (and (distinct ((_ sign_extend 24) in38_8) ((_ sign_extend 24) in38_8)) true)))))
(check-sat)
; query 25: function main, block 55, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x81 ((_ sign_extend 24) in38_8)))
(let ((?x175 (bvshl in.01_32 (_ bv4 32))))
(let ((?x492 (bvadd ?x175 ?x81)))
(let ((?x30 ((_ sign_extend 1) ?x492)))
(let (($x89 (or false false)))
(let (($x171 (or false false false)))
(let (($x178 (or $x171 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x494 (or $x178 $x89 (or (and (distinct (bvadd ((_ sign_extend 1) ?x175) ((_ sign_extend 1) ?x81)) ?x30) true)))))
(and (not $x494) (or $x494 (and (distinct ?x492 ?x492) true))))))))))))
(check-sat)
; query 26: function main, block 55, name %59
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x81 ((_ sign_extend 24) in38_8)))
(let ((?x175 (bvshl in.01_32 (_ bv4 32))))
(let ((?x492 (bvadd ?x175 ?x81)))
(let ((?x309 (bvsub ?x492 (_ bv65 32))))
(let ((?x479 ((_ sign_extend 1) ?x309)))
(let ((?x30 ((_ sign_extend 1) ?x492)))
(let (($x89 (or false false)))
(let (($x171 (or false false false)))
(let (($x178 (or $x171 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x494 (or $x178 $x89 (or (and (distinct (bvadd ((_ sign_extend 1) ?x175) ((_ sign_extend 1) ?x81)) ?x30) true)))))
(let (($x1060 (or $x494 false (or (and (distinct (bvsub ?x30 ((_ sign_extend 1) (_ bv65 32))) ?x479) true)))))
(and (not $x1060) (or $x1060 (and (distinct ?x309 ?x309) true)))))))))))))))
(check-sat)
; query 27: function main, block 55, name %60
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x81 ((_ sign_extend 24) in38_8)))
(let ((?x175 (bvshl in.01_32 (_ bv4 32))))
(let ((?x492 (bvadd ?x175 ?x81)))
(let ((?x309 (bvsub ?x492 (_ bv65 32))))
(let ((?x1004 (bvadd ?x309 (_ bv10 32))))
(let (($x1037 (and (distinct (bvadd ((_ sign_extend 1) ?x309) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x1004)) true)))
(let ((?x479 ((_ sign_extend 1) ?x309)))
(let ((?x30 ((_ sign_extend 1) ?x492)))
(let (($x89 (or false false)))
(let (($x171 (or false false false)))
(let (($x178 (or $x171 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x494 (or $x178 $x89 (or (and (distinct (bvadd ((_ sign_extend 1) ?x175) ((_ sign_extend 1) ?x81)) ?x30) true)))))
(let (($x1060 (or $x494 false (or (and (distinct (bvsub ?x30 ((_ sign_extend 1) (_ bv65 32))) ?x479) true)))))
(let (($x1032 (or $x1060 false (or $x1037))))
(and (not $x1032) (or $x1032 (and (distinct ?x1004 ?x1004) true))))))))))))))))))
(check-sat)
; query 28: function main, block 81, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x1134 (ite (bvsgt (_ bv32 32) in.06.lcssa_32) (_ bv1 1) (_ bv0 1))))
(let (($x171 (or false false false)))
(let (($x53 (not $x171)))
(and $x53 (or $x171 (and (distinct ?x1134 ?x1134) true)))))))
(check-sat)
; query 29: function main, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06.lcssa_32 () (_ BitVec 32))
(assert
 (let (($x171 (or false false false)))
(let (($x240 (or $x171 (and (distinct (bvand in.06.lcssa_32 (_ bv15 32)) (bvand in.06.lcssa_32 (_ bv15 32))) true))))
(let (($x53 (not $x171)))
(and $x53 $x240)))))
(check-sat)
; query 30: function main, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x389 (ite (and (distinct (_ bv0 32) (bvand in.06.lcssa_32 (_ bv15 32))) true) (_ bv1 1) (_ bv0 1))))
(let (($x171 (or false false false)))
(let (($x440 (or $x171 false false)))
(let (($x1497 (not $x440)))
(and $x1497 (or $x440 (and (distinct ?x389 ?x389) true))))))))
(check-sat)
; query 31: function set_key, block 11, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let (($x171 (or false false false)))
(let (($x53 (not $x171)))
(and $x53 (or $x171 (and (distinct (bvand in2_32 (_ bv1 32)) (bvand in2_32 (_ bv1 32))) true))))))
(check-sat)
; query 32: function set_key, block 11, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x838 (ite (and (distinct (_ bv0 32) (bvand in2_32 (_ bv1 32))) true) (_ bv1 1) (_ bv0 1))))
(let (($x171 (or false false false)))
(let (($x440 (or $x171 false false)))
(let (($x1497 (not $x440)))
(and $x1497 (or $x440 (and (distinct ?x838 ?x838) true))))))))
(check-sat)
; query 33: function set_key, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let (($x171 (or false false false)))
(let (($x53 (not $x171)))
(and $x53 (or $x171 (and (distinct (bvand in2_32 (_ bv2 32)) (bvand in2_32 (_ bv2 32))) true))))))
(check-sat)
; query 34: function set_key, block 14, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x544 (ite (and (distinct (_ bv0 32) (bvand in2_32 (_ bv2 32))) true) (_ bv1 1) (_ bv0 1))))
(let (($x171 (or false false false)))
(let (($x440 (or $x171 false false)))
(let (($x1497 (not $x440)))
(and $x1497 (or $x440 (and (distinct ?x544 ?x544) true))))))))
(check-sat)
; query 35: function set_key, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x193 (ite (and (distinct (_ bv0 64) in1_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x171 (or false false false)))
(let (($x53 (not $x171)))
(and $x53 (or $x171 (and (distinct ?x193 ?x193) true)))))))
(check-sat)
; query 36: function set_key, block 514, name %515
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_64 () (_ BitVec 64))
(assert
 (let (($x171 (or false false false)))
(let (($x53 (not $x171)))
(and $x53 (or $x171 (and (distinct (bvadd in.01_64 (_ bv1 64)) (bvadd in.01_64 (_ bv1 64))) true))))))
(check-sat)
; query 37: function set_key, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x740 (ite (bvult in1_64 (_ bv16 64)) (_ bv1 1) (_ bv0 1))))
(let (($x171 (or false false false)))
(let (($x53 (not $x171)))
(and $x53 (or $x171 (and (distinct ?x740 ?x740) true)))))))
(check-sat)
; query 38: function set_key, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x232 (ite (bvugt in1_64 (_ bv32 64)) (_ bv1 1) (_ bv0 1))))
(let (($x171 (or false false false)))
(let (($x53 (not $x171)))
(and $x53 (or $x171 (and (distinct ?x232 ?x232) true)))))))
(check-sat)
; query 39: function set_key, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let (($x171 (or false false false)))
(let (($x53 (not $x171)))
(and $x53 (or $x171 (and (distinct (bvand in1_64 (_ bv7 64)) (bvand in1_64 (_ bv7 64))) true))))))
(check-sat)
; query 40: function set_key, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x435 (ite (and (distinct (_ bv0 64) (bvand in1_64 (_ bv7 64))) true) (_ bv1 1) (_ bv0 1))))
(let (($x171 (or false false false)))
(let (($x440 (or $x171 false false)))
(let (($x1497 (not $x440)))
(and $x1497 (or $x440 (and (distinct ?x435 ?x435) true))))))))
(check-sat)
