; OptiPhase-Sigma refinement certificate for sweep K14-R2-014
; query 0: function xmalloc, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in7_32 () (_ BitVec 32))
(assert
 (let ((?x86 (ite (and (distinct (_ bv0 32) in7_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x36 (or false false false)))
(and (not $x36) (or $x36 (and (distinct ?x86 ?x86) true))))))
(check-sat)
