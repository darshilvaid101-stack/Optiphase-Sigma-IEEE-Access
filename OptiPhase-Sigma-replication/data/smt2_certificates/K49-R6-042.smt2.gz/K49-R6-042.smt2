; OptiPhase-Sigma refinement certificate for sweep K49-R6-042
; query 0: function APCM_inverse_quantization, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x135 (or false false)))
(let (($x180 (not $x135)))
(and $x180 (or $x135 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 1: function APCM_inverse_quantization, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x181 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x135 (or false false)))
(let (($x547 (or $x135 false false)))
(let (($x411 (not $x547)))
(and $x411 (or $x547 (and (distinct ?x181 ?x181) true))))))))
(check-sat)
; query 2: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x135 (or false false)))
(let (($x180 (not $x135)))
(and $x180 (or $x135 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 3: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x25 (ite (bvslt (_ bv15 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x135 (or false false)))
(let (($x547 (or $x135 false false)))
(let (($x411 (not $x547)))
(and $x411 (or $x547 (and (distinct ?x25 ?x25) true))))))))
(check-sat)
; query 4: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x135 (or false false)))
(let (($x180 (not $x135)))
(and $x180 (or $x135 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 5: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x41 (ite (bvsgt (_ bv40 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x135 (or false false)))
(let (($x547 (or $x135 false false)))
(let (($x411 (not $x547)))
(and $x411 (or $x547 (and (distinct ?x41 ?x41) true))))))))
(check-sat)
; query 6: function RPE_grid_positioning, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x135 (or false false)))
(let (($x180 (not $x135)))
(and $x180 (or $x135 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 7: function RPE_grid_positioning, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x297 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x396 (and (distinct ?x297 ?x297) true)))
(let (($x135 (or false false)))
(let (($x50 (or false $x135 false)))
(and (not $x50) (or $x50 $x396)))))))
(check-sat)
; query 8: function gsm_L_add, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x347 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x225 (or false false false)))
(let (($x147 (not $x225)))
(and $x147 (or $x225 (and (distinct ?x347 ?x347) true)))))))
(check-sat)
; query 9: function gsm_L_add, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x669 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvadd in0_64 in1_64))) true)))
(let (($x368 (or false false (or $x669))))
(let (($x42 (or $x368 (and (distinct (bvadd in0_64 in1_64) (bvadd in0_64 in1_64)) true))))
(and (not $x368) $x42)))))
(check-sat)
; query 10: function gsm_L_add, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x302 (bvadd in0_64 (_ bv1 64))))
(let ((?x151 (bvsub (_ bv0 64) ?x302)))
(let (($x244 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x302)) ((_ sign_extend 1) ?x151)) true)))
(let ((?x532 ((_ sign_extend 1) ?x302)))
(let (($x112 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x532) true)))))
(let (($x365 (or false $x112 (or $x244))))
(and (not $x365) (or $x365 (and (distinct ?x151 ?x151) true))))))))))
(check-sat)
; query 11: function gsm_L_add, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x71 (bvadd in1_64 (_ bv1 64))))
(let ((?x120 ((_ sign_extend 1) ?x71)))
(let (($x371 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x120) true)))))
(and (not $x371) (or $x371 (and (distinct ?x71 ?x71) true)))))))
(check-sat)
; query 12: function gsm_L_add, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x71 (bvadd in1_64 (_ bv1 64))))
(let ((?x45 (bvsub (_ bv0 64) ?x71)))
(let (($x83 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x71)) ((_ sign_extend 1) ?x45)) true)))
(let ((?x120 ((_ sign_extend 1) ?x71)))
(let (($x371 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x120) true)))))
(let (($x876 (or false $x371 (or $x83))))
(and (not $x876) (or $x876 (and (distinct ?x45 ?x45) true))))))))))
(check-sat)
; query 13: function gsm_L_add, block 8, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x71 (bvadd in1_64 (_ bv1 64))))
(let ((?x45 (bvsub (_ bv0 64) ?x71)))
(let ((?x302 (bvadd in0_64 (_ bv1 64))))
(let ((?x151 (bvsub (_ bv0 64) ?x302)))
(let ((?x12 (bvadd ?x151 ?x45)))
(let (($x83 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x71)) ((_ sign_extend 1) ?x45)) true)))
(let ((?x120 ((_ sign_extend 1) ?x71)))
(let (($x371 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x120) true)))))
(let (($x876 (or false $x371 (or $x83))))
(let (($x244 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x302)) ((_ sign_extend 1) ?x151)) true)))
(let ((?x532 ((_ sign_extend 1) ?x302)))
(let (($x112 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x532) true)))))
(let (($x365 (or false $x112 (or $x244))))
(let (($x397 (or $x365 $x876 false)))
(and (not $x397) (or $x397 (and (distinct ?x12 ?x12) true))))))))))))))))))
(check-sat)
; query 14: function gsm_L_add, block 8, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x71 (bvadd in1_64 (_ bv1 64))))
(let ((?x45 (bvsub (_ bv0 64) ?x71)))
(let ((?x302 (bvadd in0_64 (_ bv1 64))))
(let ((?x151 (bvsub (_ bv0 64) ?x302)))
(let ((?x12 (bvadd ?x151 ?x45)))
(let ((?x410 (ite (bvuge ?x12 (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x83 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x71)) ((_ sign_extend 1) ?x45)) true)))
(let ((?x120 ((_ sign_extend 1) ?x71)))
(let (($x371 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x120) true)))))
(let (($x876 (or false $x371 (or $x83))))
(let (($x244 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x302)) ((_ sign_extend 1) ?x151)) true)))
(let ((?x532 ((_ sign_extend 1) ?x302)))
(let (($x112 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x532) true)))))
(let (($x365 (or false $x112 (or $x244))))
(let (($x397 (or $x365 $x876 false)))
(let (($x96 (or $x397 false false)))
(and (not $x96) (or $x96 (and (distinct ?x410 ?x410) true))))))))))))))))))))
(check-sat)
; query 15: function gsm_L_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x302 (bvadd in0_64 (_ bv1 64))))
(let ((?x532 ((_ sign_extend 1) ?x302)))
(let (($x112 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x532) true)))))
(and (not $x112) (or $x112 (and (distinct ?x302 ?x302) true)))))))
(check-sat)
; query 16: function gsm_L_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x260 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x225 (or false false false)))
(let (($x147 (not $x225)))
(and $x147 (or $x225 (and (distinct ?x260 ?x260) true)))))))
(check-sat)
; query 17: function gsm_L_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x123 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x225 (or false false false)))
(let (($x147 (not $x225)))
(and $x147 (or $x225 (and (distinct ?x123 ?x123) true)))))))
(check-sat)
; query 18: function gsm_L_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x260 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x225 (or false false false)))
(let (($x147 (not $x225)))
(and $x147 (or $x225 (and (distinct ?x260 ?x260) true)))))))
(check-sat)
; query 19: function gsm_L_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x260 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x114 ((_ zero_extend 31) ?x260)))
(let (($x225 (or false false false)))
(let (($x80 (or $x225 false)))
(and (not $x80) (or $x80 (and (distinct ?x114 ?x114) true))))))))
(check-sat)
; query 20: function gsm_L_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x260 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x114 ((_ zero_extend 31) ?x260)))
(let ((?x11 (bvsub (_ bv0 32) ?x114)))
(let (($x16 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x114)) ((_ sign_extend 1) ?x11)) true)))
(let (($x225 (or false false false)))
(let (($x80 (or $x225 false)))
(let (($x63 (or false $x80 (or $x16))))
(and (not $x63) (or $x63 (and (distinct ?x11 ?x11) true)))))))))))
(check-sat)
; query 21: function gsm_L_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x260 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x114 ((_ zero_extend 31) ?x260)))
(let ((?x11 (bvsub (_ bv0 32) ?x114)))
(let ((?x350 ((_ sign_extend 32) ?x11)))
(let (($x16 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x114)) ((_ sign_extend 1) ?x11)) true)))
(let (($x225 (or false false false)))
(let (($x80 (or $x225 false)))
(let (($x63 (or false $x80 (or $x16))))
(let (($x249 (or $x63 false)))
(and (not $x249) (or $x249 (and (distinct ?x350 ?x350) true)))))))))))))
(check-sat)
; query 22: function gsm_L_asr, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x23 (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x225 (or false false false)))
(let (($x147 (not $x225)))
(and $x147 (or $x225 (and (distinct ?x23 ?x23) true)))))))
(check-sat)
; query 23: function gsm_L_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x123 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x225 (or false false false)))
(let (($x147 (not $x225)))
(and $x147 (or $x225 (and (distinct ?x123 ?x123) true)))))))
(check-sat)
; query 24: function gsm_L_sub, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x347 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x225 (or false false false)))
(let (($x147 (not $x225)))
(and $x147 (or $x225 (and (distinct ?x347 ?x347) true)))))))
(check-sat)
; query 25: function gsm_L_sub, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x263 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvsub in0_64 in1_64))) true)))
(let (($x73 (or false false (or $x263))))
(let (($x104 (or $x73 (and (distinct (bvsub in0_64 in1_64) (bvsub in0_64 in1_64)) true))))
(and (not $x73) $x104)))))
(check-sat)
; query 26: function gsm_L_sub, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x71 (bvadd in1_64 (_ bv1 64))))
(let ((?x45 (bvsub (_ bv0 64) ?x71)))
(let (($x83 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x71)) ((_ sign_extend 1) ?x45)) true)))
(let ((?x120 ((_ sign_extend 1) ?x71)))
(let (($x371 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x120) true)))))
(let (($x876 (or false $x371 (or $x83))))
(and (not $x876) (or $x876 (and (distinct ?x45 ?x45) true))))))))))
(check-sat)
; query 27: function gsm_L_sub, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x71 (bvadd in1_64 (_ bv1 64))))
(let ((?x45 (bvsub (_ bv0 64) ?x71)))
(let ((?x185 (bvadd in0_64 ?x45)))
(let (($x83 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x71)) ((_ sign_extend 1) ?x45)) true)))
(let ((?x120 ((_ sign_extend 1) ?x71)))
(let (($x371 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x120) true)))))
(let (($x876 (or false $x371 (or $x83))))
(let (($x74 (or false $x876 false)))
(and (not $x74) (or $x74 (and (distinct ?x185 ?x185) true))))))))))))
(check-sat)
; query 28: function gsm_L_sub, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x32 (ite (bvuge (bvadd in0_64 (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64)))) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x83 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) (bvadd in1_64 (_ bv1 64)))) ((_ sign_extend 1) (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64))))) true)))
(let ((?x71 (bvadd in1_64 (_ bv1 64))))
(let ((?x120 ((_ sign_extend 1) ?x71)))
(let (($x371 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x120) true)))))
(let (($x876 (or false $x371 (or $x83))))
(let (($x74 (or false $x876 false)))
(let (($x28 (or $x74 false false)))
(and (not $x28) (or $x28 (and (distinct ?x32 ?x32) true))))))))))))
(check-sat)
; query 29: function gsm_L_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x71 (bvadd in1_64 (_ bv1 64))))
(let ((?x120 ((_ sign_extend 1) ?x71)))
(let (($x371 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x120) true)))))
(and (not $x371) (or $x371 (and (distinct ?x71 ?x71) true)))))))
(check-sat)
; query 30: function gsm_L_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x72 (ite (bvsle (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x225 (or false false false)))
(let (($x147 (not $x225)))
(and $x147 (or $x225 (and (distinct ?x72 ?x72) true)))))))
(check-sat)
; query 31: function gsm_abs, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x135 (or false false)))
(let (($x180 (not $x135)))
(and $x180 (or $x135 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 32: function gsm_abs, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x58 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x135 (or false false)))
(let (($x547 (or $x135 false false)))
(let (($x411 (not $x547)))
(and $x411 (or $x547 (and (distinct ?x58 ?x58) true))))))))
(check-sat)
; query 33: function gsm_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x135 (or false false)))
(let (($x180 (not $x135)))
(and $x180 (or $x135 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 34: function gsm_add, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x135 (or false false)))
(let (($x180 (not $x135)))
(and $x180 (or $x135 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 35: function gsm_add, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x183 ((_ sign_extend 48) in1_16)))
(let ((?x577 ((_ sign_extend 48) in0_16)))
(let ((?x403 (bvadd ?x577 ?x183)))
(let (($x106 (and (distinct (bvadd ((_ sign_extend 1) ?x577) ((_ sign_extend 1) ?x183)) ((_ sign_extend 1) ?x403)) true)))
(let (($x135 (or false false)))
(let (($x574 (or $x135 $x135 (or $x106))))
(and (not $x574) (or $x574 (and (distinct ?x403 ?x403) true))))))))))
(check-sat)
; query 36: function gsm_add, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x190 (ite (bvsgt (_ bv18446744073709518848 64) (bvadd ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x183 ((_ sign_extend 48) in1_16)))
(let ((?x290 ((_ sign_extend 1) ?x183)))
(let ((?x577 ((_ sign_extend 48) in0_16)))
(let ((?x648 ((_ sign_extend 1) ?x577)))
(let (($x135 (or false false)))
(let (($x574 (or $x135 $x135 (or (and (distinct (bvadd ?x648 ?x290) ((_ sign_extend 1) (bvadd ?x577 ?x183))) true)))))
(let (($x440 (or $x574 false false)))
(and (not $x440) (or $x440 (and (distinct ?x190 ?x190) true))))))))))))
(check-sat)
; query 37: function gsm_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x494 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x225 (or false false false)))
(let (($x147 (not $x225)))
(and $x147 (or $x225 (and (distinct ?x494 ?x494) true)))))))
(check-sat)
; query 38: function gsm_asr, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x253 (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x225 (or false false false)))
(let (($x147 (not $x225)))
(and $x147 (or $x225 (and (distinct ?x253 ?x253) true)))))))
(check-sat)
; query 39: function gsm_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x135 (or false false)))
(let (($x180 (not $x135)))
(and $x180 (or $x135 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 40: function gsm_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x58 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x135 (or false false)))
(let (($x547 (or $x135 false false)))
(let (($x411 (not $x547)))
(and $x411 (or $x547 (and (distinct ?x58 ?x58) true))))))))
(check-sat)
; query 41: function gsm_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x58 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x590 ((_ zero_extend 31) ?x58)))
(let (($x135 (or false false)))
(let (($x547 (or $x135 false false)))
(let (($x122 (or $x547 false)))
(and (not $x122) (or $x122 (and (distinct ?x590 ?x590) true)))))))))
(check-sat)
; query 42: function gsm_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x58 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x590 ((_ zero_extend 31) ?x58)))
(let ((?x453 (bvsub (_ bv0 32) ?x590)))
(let (($x278 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x590)) ((_ sign_extend 1) ?x453)) true)))
(let (($x135 (or false false)))
(let (($x547 (or $x135 false false)))
(let (($x122 (or $x547 false)))
(let (($x351 (or false $x122 (or $x278))))
(and (not $x351) (or $x351 (and (distinct ?x453 ?x453) true))))))))))))
(check-sat)
; query 43: function gsm_asr, block 4, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x58 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x590 ((_ zero_extend 31) ?x58)))
(let ((?x453 (bvsub (_ bv0 32) ?x590)))
(let ((?x671 ((_ extract 15 0) ?x453)))
(let (($x278 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x590)) ((_ sign_extend 1) ?x453)) true)))
(let (($x135 (or false false)))
(let (($x547 (or $x135 false false)))
(let (($x122 (or $x547 false)))
(let (($x351 (or false $x122 (or $x278))))
(let (($x566 (or $x351 false)))
(and (not $x566) (or $x566 (and (distinct ?x671 ?x671) true))))))))))))))
(check-sat)
; query 44: function gsm_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x494 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x225 (or false false false)))
(let (($x147 (not $x225)))
(and $x147 (or $x225 (and (distinct ?x494 ?x494) true)))))))
(check-sat)
; query 45: function gsm_debug_longwords, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in15_32 () (_ BitVec 32))
(assert
 (let ((?x512 (ite (bvslt in15_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x225 (or false false false)))
(let (($x147 (not $x225)))
(and $x147 (or $x225 (and (distinct ?x512 ?x512) true)))))))
(check-sat)
; query 46: function gsm_debug_words, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in16_32 () (_ BitVec 32))
(assert
 (let ((?x633 (ite (bvslt in16_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x225 (or false false false)))
(let (($x147 (not $x225)))
(and $x147 (or $x225 (and (distinct ?x633 ?x633) true)))))))
(check-sat)
; query 47: function gsm_div, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x135 (or false false)))
(let (($x180 (not $x135)))
(and $x180 (or $x135 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 48: function gsm_div, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x135 (or false false)))
(let (($x180 (not $x135)))
(and $x180 (or $x135 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 49: function gsm_div, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x135 (or false false)))
(let (($x180 (not $x135)))
(and $x180 (or $x135 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 50: function gsm_div, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x297 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x396 (and (distinct ?x297 ?x297) true)))
(let (($x135 (or false false)))
(let (($x547 (or $x135 false false)))
(let (($x411 (not $x547)))
(and $x411 (or $x547 $x396))))))))
(check-sat)
; query 51: function gsm_norm, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x254 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x225 (or false false false)))
(let (($x147 (not $x225)))
(and $x147 (or $x225 (and (distinct ?x254 ?x254) true)))))))
(check-sat)
; query 52: function gsm_norm, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x254 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x314 (bvxor ?x254 (_ bv1 1))))
(let (($x225 (or false false false)))
(let (($x872 (or $x225 false false)))
(and (not $x872) (or $x872 (and (distinct ?x314 ?x314) true))))))))
(check-sat)
; query 53: function gsm_norm, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x254 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x314 (bvxor ?x254 (_ bv1 1))))
(let ((?x306 ((_ zero_extend 31) ?x314)))
(let (($x225 (or false false false)))
(let (($x872 (or $x225 false false)))
(let (($x234 (or $x872 false)))
(and (not $x234) (or $x234 (and (distinct ?x306 ?x306) true))))))))))
(check-sat)
; query 54: function gsm_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x135 (or false false)))
(let (($x180 (not $x135)))
(and $x180 (or $x135 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 55: function gsm_sub, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x135 (or false false)))
(let (($x180 (not $x135)))
(and $x180 (or $x135 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 56: function gsm_sub, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x183 ((_ sign_extend 48) in1_16)))
(let ((?x577 ((_ sign_extend 48) in0_16)))
(let ((?x367 (bvsub ?x577 ?x183)))
(let (($x536 (and (distinct (bvsub ((_ sign_extend 1) ?x577) ((_ sign_extend 1) ?x183)) ((_ sign_extend 1) ?x367)) true)))
(let (($x135 (or false false)))
(let (($x545 (or $x135 $x135 (or $x536))))
(and (not $x545) (or $x545 (and (distinct ?x367 ?x367) true))))))))))
(check-sat)
; query 57: function gsm_sub, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x259 (ite (bvsgt (_ bv18446744073709518848 64) (bvsub ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x183 ((_ sign_extend 48) in1_16)))
(let ((?x290 ((_ sign_extend 1) ?x183)))
(let ((?x577 ((_ sign_extend 48) in0_16)))
(let ((?x648 ((_ sign_extend 1) ?x577)))
(let (($x135 (or false false)))
(let (($x545 (or $x135 $x135 (or (and (distinct (bvsub ?x648 ?x290) ((_ sign_extend 1) (bvsub ?x577 ?x183))) true)))))
(let (($x944 (or $x545 false false)))
(and (not $x944) (or $x944 (and (distinct ?x259 ?x259) true))))))))))))
(check-sat)
