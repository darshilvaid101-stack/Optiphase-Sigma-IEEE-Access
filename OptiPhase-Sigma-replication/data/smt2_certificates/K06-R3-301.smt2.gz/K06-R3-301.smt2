; OptiPhase-Sigma refinement certificate for sweep K06-R3-301
; query 0: function xmalloc, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in7_32 () (_ BitVec 32))
(assert
 (let ((?x50 (ite (and (distinct (_ bv0 32) in7_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x45 (or false false false)))
(and (not $x45) (or $x45 (and (distinct ?x50 ?x50) true))))))
(check-sat)
