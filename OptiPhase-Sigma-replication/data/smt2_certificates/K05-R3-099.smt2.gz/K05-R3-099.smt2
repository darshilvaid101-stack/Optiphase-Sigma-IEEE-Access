; OptiPhase-Sigma refinement certificate for sweep K05-R3-099
