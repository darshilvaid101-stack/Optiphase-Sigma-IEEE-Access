; OptiPhase-Sigma refinement certificate for sweep K25-R5-377
