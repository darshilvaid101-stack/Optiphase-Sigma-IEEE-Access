; OptiPhase-Sigma refinement certificate for sweep K18-R6-012
