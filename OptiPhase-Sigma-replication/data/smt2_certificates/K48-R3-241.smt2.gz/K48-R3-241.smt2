; OptiPhase-Sigma refinement certificate for sweep K48-R3-241
; query 0: function APCM_inverse_quantization, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x382 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 1: function APCM_inverse_quantization, block 7, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x948 (ite (bvsge (_ bv7 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x382 (or false false)))
(let (($x851 (or $x382 false false)))
(let (($x97 (not $x851)))
(and $x97 (or $x851 (and (distinct ?x948 ?x948) true))))))))
(check-sat)
; query 2: function APCM_inverse_quantization, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x382 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 3: function APCM_inverse_quantization, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x39 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x382 (or false false)))
(let (($x851 (or $x382 false false)))
(let (($x97 (not $x851)))
(and $x97 (or $x851 (and (distinct ?x39 ?x39) true))))))))
(check-sat)
; query 4: function APCM_quantization, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x382 (and (distinct ((_ sign_extend 16) in13_16) ((_ sign_extend 16) in13_16)) true))))))
(check-sat)
; query 5: function APCM_quantization, block 16, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_16 () (_ BitVec 16))
(assert
 (let ((?x16 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in13_16)) (_ bv1 1) (_ bv0 1))))
(let (($x382 (or false false)))
(let (($x851 (or $x382 false false)))
(let (($x97 (not $x851)))
(and $x97 (or $x851 (and (distinct ?x16 ?x16) true))))))))
(check-sat)
; query 6: function APCM_quantization, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x382 (and (distinct ((_ sign_extend 16) in13_16) ((_ sign_extend 16) in13_16)) true))))))
(check-sat)
; query 7: function APCM_quantization, block 20, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_16 () (_ BitVec 16))
(assert
 (let ((?x365 ((_ sign_extend 16) in13_16)))
(let ((?x101 (bvsub (_ bv0 32) ?x365)))
(let (($x72 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x365)) ((_ sign_extend 1) ?x101)) true)))
(let (($x382 (or false false)))
(let (($x516 (or false $x382 (or $x72))))
(and (not $x516) (or $x516 (and (distinct ?x101 ?x101) true)))))))))
(check-sat)
; query 8: function APCM_quantization, block 25, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x382 (and (distinct ((_ sign_extend 16) in13_16) ((_ sign_extend 16) in13_16)) true))))))
(check-sat)
; query 9: function APCM_quantization, block 35, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_32 () (_ BitVec 32))
(assert
 (let (($x161 (and (distinct (bvadd ((_ sign_extend 1) in.03_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.03_32 (_ bv1 32)))) true)))
(let (($x173 (or false false (or $x161))))
(and (not $x173) (or $x173 (and (distinct (bvadd in.03_32 (_ bv1 32)) (bvadd in.03_32 (_ bv1 32))) true))))))
(check-sat)
; query 10: function APCM_quantization_xmaxc_to_exp_mant, block 24, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x382 (and (distinct ((_ sign_extend 16) in.0_16) ((_ sign_extend 16) in.0_16)) true))))))
(check-sat)
; query 11: function APCM_quantization_xmaxc_to_exp_mant, block 24, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let ((?x25 ((_ sign_extend 16) in.0_16)))
(let ((?x384 (bvshl ?x25 (_ bv1 32))))
(let (($x262 (bvuge (_ bv1 32) (_ bv32 32))))
(let (($x382 (or false false)))
(let (($x454 (or (or $x382 false (or (and (distinct (bvashr ?x384 (_ bv1 32)) ?x25) true))) $x262)))
(let (($x851 (or $x382 false false)))
(let (($x158 (or $x851 $x262)))
(let (($x486 (not $x158)))
(and $x486 (or $x454 (and (distinct ?x384 ?x384) true))))))))))))
(check-sat)
; query 12: function APCM_quantization_xmaxc_to_exp_mant, block 24, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let ((?x25 ((_ sign_extend 16) in.0_16)))
(let ((?x384 (bvshl ?x25 (_ bv1 32))))
(let ((?x521 (bvor ?x384 (_ bv1 32))))
(let (($x262 (bvuge (_ bv1 32) (_ bv32 32))))
(let (($x382 (or false false)))
(let (($x454 (or (or $x382 false (or (and (distinct (bvashr ?x384 (_ bv1 32)) ?x25) true))) $x262)))
(let (($x324 (or $x454 false false)))
(and (not (or (or (or $x382 false false) $x262) false false)) (or $x324 (and (distinct ?x521 ?x521) true)))))))))))
(check-sat)
; query 13: function APCM_quantization_xmaxc_to_exp_mant, block 24, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let ((?x25 ((_ sign_extend 16) in.0_16)))
(let ((?x384 (bvshl ?x25 (_ bv1 32))))
(let ((?x521 (bvor ?x384 (_ bv1 32))))
(let ((?x18 ((_ extract 15 0) ?x521)))
(let (($x262 (bvuge (_ bv1 32) (_ bv32 32))))
(let (($x382 (or false false)))
(let (($x454 (or (or $x382 false (or (and (distinct (bvashr ?x384 (_ bv1 32)) ?x25) true))) $x262)))
(let (($x324 (or $x454 false false)))
(let (($x519 (not (or (or (or (or $x382 false false) $x262) false false) false))))
(and $x519 (or (or $x324 false) (and (distinct ?x18 ?x18) true)))))))))))))
(check-sat)
; query 14: function APCM_quantization_xmaxc_to_exp_mant, block 24, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_16 () (_ BitVec 16))
(assert
 (let (($x127 (or false false false)))
(let (($x105 (not $x127)))
(and $x105 (or $x127 (and (distinct (bvadd in.12_16 (_ bv65535 16)) (bvadd in.12_16 (_ bv65535 16))) true))))))
(check-sat)
; query 15: function APCM_quantization_xmaxc_to_exp_mant, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x382 (and (distinct ((_ sign_extend 16) in.0_16) ((_ sign_extend 16) in.0_16)) true))))))
(check-sat)
; query 16: function APCM_quantization_xmaxc_to_exp_mant, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let ((?x25 ((_ sign_extend 16) in.0_16)))
(let ((?x167 (bvsub ?x25 (_ bv8 32))))
(let (($x64 (and (distinct (bvsub ((_ sign_extend 1) ?x25) ((_ sign_extend 1) (_ bv8 32))) ((_ sign_extend 1) ?x167)) true)))
(let (($x382 (or false false)))
(let (($x441 (or $x382 false (or $x64))))
(and (not $x441) (or $x441 (and (distinct ?x167 ?x167) true)))))))))
(check-sat)
; query 17: function APCM_quantization_xmaxc_to_exp_mant, block 30, name %33
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let ((?x25 ((_ sign_extend 16) in.0_16)))
(let ((?x167 (bvsub ?x25 (_ bv8 32))))
(let ((?x86 ((_ extract 15 0) ?x167)))
(let (($x64 (and (distinct (bvsub ((_ sign_extend 1) ?x25) ((_ sign_extend 1) (_ bv8 32))) ((_ sign_extend 1) ?x167)) true)))
(let (($x382 (or false false)))
(let (($x441 (or $x382 false (or $x64))))
(let (($x432 (or $x441 false)))
(and (not $x432) (or $x432 (and (distinct ?x86 ?x86) true)))))))))))
(check-sat)
; query 18: function APCM_quantization_xmaxc_to_exp_mant, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x382 (and (distinct ((_ sign_extend 16) in.2_16) ((_ sign_extend 16) in.2_16)) true))))))
(check-sat)
; query 19: function APCM_quantization_xmaxc_to_exp_mant, block 37, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_16 () (_ BitVec 16))
(assert
 (let ((?x333 (ite (bvsge (_ bv6 32) ((_ sign_extend 16) in.2_16)) (_ bv1 1) (_ bv0 1))))
(let (($x382 (or false false)))
(let (($x851 (or $x382 false false)))
(let (($x97 (not $x851)))
(and $x97 (or $x851 (and (distinct ?x333 ?x333) true))))))))
(check-sat)
; query 20: function APCM_quantization_xmaxc_to_exp_mant, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x9 ((_ sign_extend 16) in0_16)))
(let ((?x58 (bvashr ?x9 (_ bv3 32))))
(let ((?x53 (bvsub ?x58 (_ bv1 32))))
(let ((?x559 ((_ extract 15 0) ?x53)))
(let (($x208 (and (distinct (bvsub ((_ sign_extend 1) ?x58) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x53)) true)))
(let (($x382 (or false false)))
(let (($x851 (or $x382 false false)))
(let (($x151 (or $x851 (bvuge (_ bv3 32) (_ bv32 32)))))
(let (($x52 (or $x151 false (or $x208))))
(let (($x143 (or (or $x52 (or (and (distinct ((_ sign_extend 16) ?x559) ?x53) true))) (and (distinct ?x559 ?x559) true))))
(and (not (or $x52 false)) $x143))))))))))))
(check-sat)
; query 21: function APCM_quantization_xmaxc_to_exp_mant, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x382 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 22: function APCM_quantization_xmaxc_to_exp_mant, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x9 ((_ sign_extend 16) in0_16)))
(let ((?x58 (bvashr ?x9 (_ bv3 32))))
(let (($x382 (or false false)))
(let (($x851 (or $x382 false false)))
(let (($x151 (or $x851 (bvuge (_ bv3 32) (_ bv32 32)))))
(and (not $x151) (or $x151 (and (distinct ?x58 ?x58) true)))))))))
(check-sat)
; query 23: function APCM_quantization_xmaxc_to_exp_mant, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x9 ((_ sign_extend 16) in0_16)))
(let ((?x58 (bvashr ?x9 (_ bv3 32))))
(let ((?x53 (bvsub ?x58 (_ bv1 32))))
(let (($x208 (and (distinct (bvsub ((_ sign_extend 1) ?x58) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x53)) true)))
(let (($x382 (or false false)))
(let (($x851 (or $x382 false false)))
(let (($x151 (or $x851 (bvuge (_ bv3 32) (_ bv32 32)))))
(let (($x52 (or $x151 false (or $x208))))
(and (not $x52) (or $x52 (and (distinct ?x53 ?x53) true))))))))))))
(check-sat)
; query 24: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x382 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 25: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x232 (ite (bvslt (_ bv15 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x382 (or false false)))
(let (($x851 (or $x382 false false)))
(let (($x97 (not $x851)))
(and $x97 (or $x851 (and (distinct ?x232 ?x232) true))))))))
(check-sat)
; query 26: function Autocorrelation, block 39, name %40
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x10 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x100 (or false false (or $x10))))
(and (not $x100) (or $x100 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 27: function Autocorrelation, block 41, name %42
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x382 (and (distinct ((_ sign_extend 16) in.04_16) ((_ sign_extend 16) in.04_16)) true))))))
(check-sat)
; query 28: function Autocorrelation, block 41, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let ((?x181 (ite (= (_ bv0 32) ((_ sign_extend 16) in.04_16)) (_ bv1 1) (_ bv0 1))))
(let (($x382 (or false false)))
(let (($x851 (or $x382 false false)))
(let (($x97 (not $x851)))
(and $x97 (or $x851 (and (distinct ?x181 ?x181) true))))))))
(check-sat)
; query 29: function Autocorrelation, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x382 (and (distinct ((_ sign_extend 16) in.04_16) ((_ sign_extend 16) in.04_16)) true))))))
(check-sat)
; query 30: function Autocorrelation, block 45, name %47
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let ((?x50 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.04_16)) (_ bv1 1) (_ bv0 1))))
(let (($x382 (or false false)))
(let (($x851 (or $x382 false false)))
(let (($x97 (not $x851)))
(and $x97 (or $x851 (and (distinct ?x50 ?x50) true))))))))
(check-sat)
; query 31: function Autocorrelation, block 45, name %48
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let ((?x50 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.04_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x130 (bvxor ?x50 (_ bv1 1))))
(let (($x382 (or false false)))
(let (($x851 (or $x382 false false)))
(let (($x122 (or $x851 false false)))
(let (($x305 (not $x122)))
(and $x305 (or $x122 (and (distinct ?x130 ?x130) true))))))))))
(check-sat)
; query 32: function Autocorrelation, block 45, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let ((?x50 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.04_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x130 (bvxor ?x50 (_ bv1 1))))
(let ((?x131 ((_ zero_extend 31) ?x130)))
(let (($x382 (or false false)))
(let (($x851 (or $x382 false false)))
(let (($x122 (or $x851 false false)))
(let (($x48 (or $x122 false)))
(let (($x41 (not $x48)))
(and $x41 (or $x48 (and (distinct ?x131 ?x131) true))))))))))))
(check-sat)
; query 33: function Autocorrelation, block 45, name %50
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let ((?x50 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.04_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x130 (bvxor ?x50 (_ bv1 1))))
(let ((?x131 ((_ zero_extend 31) ?x130)))
(let ((?x88 ((_ zero_extend 32) ?x131)))
(let ((?x32 ((_ sign_extend 32) ?x131)))
(let (($x382 (or false false)))
(let (($x851 (or $x382 false false)))
(let (($x122 (or $x851 false false)))
(let (($x48 (or $x122 false)))
(let (($x618 (or $x48 (or (= ((_ extract 31 31) ?x131) (_ bv1 1))))))
(let (($x304 (or $x48 false)))
(let (($x90 (not $x304)))
(and $x90 (or $x618 (and (distinct ?x32 ?x88) true))))))))))))))))
(check-sat)
; query 34: function Autocorrelation, block 45, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let ((?x50 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.04_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x130 (bvxor ?x50 (_ bv1 1))))
(let ((?x131 ((_ zero_extend 31) ?x130)))
(let ((?x88 ((_ zero_extend 32) ?x131)))
(let (($x11 (and (distinct (ite (and (distinct (_ bv0 64) ((_ sign_extend 32) ?x131)) true) (_ bv1 1) (_ bv0 1)) (ite (and (distinct (_ bv0 64) ?x88) true) (_ bv1 1) (_ bv0 1))) true)))
(let (($x382 (or false false)))
(let (($x851 (or $x382 false false)))
(let (($x122 (or $x851 false false)))
(let (($x48 (or $x122 false)))
(let (($x618 (or $x48 (or (= ((_ extract 31 31) ?x131) (_ bv1 1))))))
(let (($x310 (not (or (or $x48 false) false false))))
(and $x310 (or (or $x618 false false) $x11))))))))))))))
(check-sat)
; query 35: function Calculation_of_the_LTP_parameters, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in11_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x382 (and (distinct ((_ sign_extend 16) in11_16) ((_ sign_extend 16) in11_16)) true))))))
(check-sat)
; query 36: function Calculation_of_the_LTP_parameters, block 14, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in11_16 () (_ BitVec 16))
(assert
 (let ((?x147 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in11_16)) (_ bv1 1) (_ bv0 1))))
(let (($x382 (or false false)))
(let (($x851 (or $x382 false false)))
(let (($x97 (not $x851)))
(and $x97 (or $x851 (and (distinct ?x147 ?x147) true))))))))
(check-sat)
; query 37: function Calculation_of_the_LTP_parameters, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in11_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x382 (and (distinct ((_ sign_extend 16) in11_16) ((_ sign_extend 16) in11_16)) true))))))
(check-sat)
; query 38: function Calculation_of_the_LTP_parameters, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in11_16 () (_ BitVec 16))
(assert
 (let ((?x63 ((_ sign_extend 16) in11_16)))
(let ((?x373 (bvsub (_ bv0 32) ?x63)))
(let (($x474 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x63)) ((_ sign_extend 1) ?x373)) true)))
(let (($x382 (or false false)))
(let (($x183 (or false $x382 (or $x474))))
(and (not $x183) (or $x183 (and (distinct ?x373 ?x373) true)))))))))
(check-sat)
; query 39: function Calculation_of_the_LTP_parameters, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in11_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x382 (and (distinct ((_ sign_extend 16) in11_16) ((_ sign_extend 16) in11_16)) true))))))
(check-sat)
; query 40: function Calculation_of_the_LTP_parameters, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_32 () (_ BitVec 32))
(assert
 (let (($x161 (and (distinct (bvadd ((_ sign_extend 1) in.03_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.03_32 (_ bv1 32)))) true)))
(let (($x173 (or false false (or $x161))))
(and (not $x173) (or $x173 (and (distinct (bvadd in.03_32 (_ bv1 32)) (bvadd in.03_32 (_ bv1 32))) true))))))
(check-sat)
; query 41: function Calculation_of_the_LTP_parameters, block 35, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x382 (and (distinct ((_ sign_extend 16) in.02_16) ((_ sign_extend 16) in.02_16)) true))))))
(check-sat)
; query 42: function Calculation_of_the_LTP_parameters, block 35, name %37
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x337 (ite (= (_ bv0 32) ((_ sign_extend 16) in.02_16)) (_ bv1 1) (_ bv0 1))))
(let (($x382 (or false false)))
(let (($x851 (or $x382 false false)))
(let (($x97 (not $x851)))
(and $x97 (or $x851 (and (distinct ?x337 ?x337) true))))))))
(check-sat)
; query 43: function Calculation_of_the_LTP_parameters, block 39, name %40
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x382 (and (distinct ((_ sign_extend 16) in.02_16) ((_ sign_extend 16) in.02_16)) true))))))
(check-sat)
; query 44: function Calculation_of_the_LTP_parameters, block 39, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x197 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.02_16)) (_ bv1 1) (_ bv0 1))))
(let (($x382 (or false false)))
(let (($x851 (or $x382 false false)))
(let (($x97 (not $x851)))
(and $x97 (or $x851 (and (distinct ?x197 ?x197) true))))))))
(check-sat)
; query 45: function Calculation_of_the_LTP_parameters, block 39, name %42
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x197 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.02_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x156 (bvxor ?x197 (_ bv1 1))))
(let (($x382 (or false false)))
(let (($x851 (or $x382 false false)))
(let (($x122 (or $x851 false false)))
(let (($x305 (not $x122)))
(and $x305 (or $x122 (and (distinct ?x156 ?x156) true))))))))))
(check-sat)
; query 46: function Calculation_of_the_LTP_parameters, block 39, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x197 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.02_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x156 (bvxor ?x197 (_ bv1 1))))
(let ((?x596 ((_ zero_extend 31) ?x156)))
(let (($x382 (or false false)))
(let (($x851 (or $x382 false false)))
(let (($x122 (or $x851 false false)))
(let (($x48 (or $x122 false)))
(let (($x41 (not $x48)))
(and $x41 (or $x48 (and (distinct ?x596 ?x596) true))))))))))))
(check-sat)
; query 47: function Calculation_of_the_LTP_parameters, block 39, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x197 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.02_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x156 (bvxor ?x197 (_ bv1 1))))
(let ((?x596 ((_ zero_extend 31) ?x156)))
(let ((?x348 ((_ zero_extend 32) ?x596)))
(let ((?x577 ((_ sign_extend 32) ?x596)))
(let (($x382 (or false false)))
(let (($x851 (or $x382 false false)))
(let (($x122 (or $x851 false false)))
(let (($x48 (or $x122 false)))
(let (($x231 (or $x48 (or (= ((_ extract 31 31) ?x596) (_ bv1 1))))))
(let (($x304 (or $x48 false)))
(let (($x90 (not $x304)))
(and $x90 (or $x231 (and (distinct ?x577 ?x348) true))))))))))))))))
(check-sat)
; query 48: function Calculation_of_the_LTP_parameters, block 39, name %45
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x197 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.02_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x156 (bvxor ?x197 (_ bv1 1))))
(let ((?x596 ((_ zero_extend 31) ?x156)))
(let ((?x348 ((_ zero_extend 32) ?x596)))
(let (($x567 (and (distinct (ite (and (distinct (_ bv0 64) ((_ sign_extend 32) ?x596)) true) (_ bv1 1) (_ bv0 1)) (ite (and (distinct (_ bv0 64) ?x348) true) (_ bv1 1) (_ bv0 1))) true)))
(let (($x382 (or false false)))
(let (($x851 (or $x382 false false)))
(let (($x122 (or $x851 false false)))
(let (($x48 (or $x122 false)))
(let (($x231 (or $x48 (or (= ((_ extract 31 31) ?x596) (_ bv1 1))))))
(let (($x310 (not (or (or $x48 false) false false))))
(and $x310 (or (or $x231 false false) $x567))))))))))))))
(check-sat)
; query 49: function Decoding_of_the_coded_Log_Area_Ratios, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in20_64 () (_ BitVec 64))
(assert
 (let ((?x397 (ite (bvsge (_ bv18446744073709518848 64) in20_64) (_ bv1 1) (_ bv0 1))))
(let (($x127 (or false false false)))
(let (($x105 (not $x127)))
(and $x105 (or $x127 (and (distinct ?x397 ?x397) true)))))))
(check-sat)
; query 50: function Decoding_of_the_coded_Log_Area_Ratios, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in6_64 () (_ BitVec 64))
(assert
 (let ((?x492 (ite (bvslt (_ bv0 64) in6_64) (_ bv1 1) (_ bv0 1))))
(let (($x127 (or false false false)))
(let (($x105 (not $x127)))
(and $x105 (or $x127 (and (distinct ?x492 ?x492) true)))))))
(check-sat)
; query 51: function Decoding_of_the_coded_Log_Area_Ratios, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in6_64 () (_ BitVec 64))
(assert
 (let ((?x492 (ite (bvslt (_ bv0 64) in6_64) (_ bv1 1) (_ bv0 1))))
(let ((?x361 ((_ zero_extend 63) ?x492)))
(let (($x127 (or false false false)))
(let (($x553 (or $x127 false)))
(let (($x2071 (not $x553)))
(and $x2071 (or $x553 (and (distinct ?x361 ?x361) true)))))))))
(check-sat)
; query 52: function Decoding_of_the_coded_Log_Area_Ratios, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in6_64 () (_ BitVec 64))
(assert
 (let ((?x492 (ite (bvslt (_ bv0 64) in6_64) (_ bv1 1) (_ bv0 1))))
(let (($x836 (= (_ bv1 1) ?x492)))
(let ((?x317 (ite $x836 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x127 (or false false false)))
(let (($x378 (or $x127 (ite $x836 false false))))
(and (not $x378) (or $x378 (and (distinct ?x317 ?x317) true)))))))))
(check-sat)
; query 53: function Decoding_of_the_coded_Log_Area_Ratios, block 9, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in6_64 () (_ BitVec 64))
(assert
 (let ((?x492 (ite (bvslt (_ bv0 64) in6_64) (_ bv1 1) (_ bv0 1))))
(let (($x836 (= (_ bv1 1) ?x492)))
(let ((?x317 (ite $x836 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x860 ((_ sign_extend 32) ?x317)))
(let (($x127 (or false false false)))
(let (($x378 (or $x127 (ite $x836 false false))))
(let (($x426 (or $x378 false)))
(and (not $x426) (or $x426 (and (distinct ?x860 ?x860) true)))))))))))
(check-sat)
; query 54: function Gsm_Coder, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in39_64 () (_ BitVec 64))
(assert
 (let ((?x1921 (ite (bvslt (_ bv0 64) in39_64) (_ bv1 1) (_ bv0 1))))
(let (($x127 (or false false false)))
(let (($x105 (not $x127)))
(and $x105 (or $x127 (and (distinct ?x1921 ?x1921) true)))))))
(check-sat)
; query 55: function Gsm_Coder, block 42, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in39_64 () (_ BitVec 64))
(assert
 (let ((?x1921 (ite (bvslt (_ bv0 64) in39_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1911 ((_ zero_extend 63) ?x1921)))
(let (($x127 (or false false false)))
(let (($x553 (or $x127 false)))
(let (($x2071 (not $x553)))
(and $x2071 (or $x553 (and (distinct ?x1911 ?x1911) true)))))))))
(check-sat)
; query 56: function Gsm_Coder, block 42, name %45
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in39_64 () (_ BitVec 64))
(assert
 (let ((?x1921 (ite (bvslt (_ bv0 64) in39_64) (_ bv1 1) (_ bv0 1))))
(let (($x1931 (= (_ bv1 1) ?x1921)))
(let ((?x1901 (ite $x1931 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x127 (or false false false)))
(let (($x1881 (or $x127 (ite $x1931 false false))))
(and (not $x1881) (or $x1881 (and (distinct ?x1901 ?x1901) true)))))))))
(check-sat)
; query 57: function Gsm_Coder, block 42, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in39_64 () (_ BitVec 64))
(assert
 (let ((?x1921 (ite (bvslt (_ bv0 64) in39_64) (_ bv1 1) (_ bv0 1))))
(let (($x1931 (= (_ bv1 1) ?x1921)))
(let ((?x1901 (ite $x1931 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x1861 ((_ sign_extend 32) ?x1901)))
(let (($x127 (or false false false)))
(let (($x1881 (or $x127 (ite $x1931 false false))))
(let (($x1841 (or $x1881 false)))
(and (not $x1841) (or $x1841 (and (distinct ?x1861 ?x1861) true)))))))))))
(check-sat)
; query 58: function Gsm_Coder, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1788 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x1795 (or false false (or $x1788))))
(and (not $x1795) (or $x1795 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 59: function Gsm_Decoder, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1788 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x1795 (or false false (or $x1788))))
(and (not $x1795) (or $x1795 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 60: function Gsm_Long_Term_Synthesis_Filtering, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x382 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 61: function Gsm_Long_Term_Synthesis_Filtering, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x382 (and (distinct ((_ sign_extend 16) in19_16) ((_ sign_extend 16) in19_16)) true))))))
(check-sat)
; query 62: function Gsm_Long_Term_Synthesis_Filtering, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x1805 (ite (bvsge (_ bv120 32) ((_ sign_extend 16) in19_16)) (_ bv1 1) (_ bv0 1))))
(let (($x382 (or false false)))
(let (($x851 (or $x382 false false)))
(let (($x97 (not $x851)))
(and $x97 (or $x851 (and (distinct ?x1805 ?x1805) true))))))))
(check-sat)
; query 63: function Gsm_Long_Term_Synthesis_Filtering, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1814 (ite (bvslt (_ bv120 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x382 (or false false)))
(let (($x851 (or $x382 false false)))
(let (($x97 (not $x851)))
(and $x97 (or $x851 (and (distinct ?x1814 ?x1814) true))))))))
(check-sat)
; query 64: function Gsm_Long_Term_Synthesis_Filtering, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x382 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 65: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x382 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 66: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1809 (ite (bvsgt (_ bv40 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x382 (or false false)))
(let (($x851 (or $x382 false false)))
(let (($x97 (not $x851)))
(and $x97 (or $x851 (and (distinct ?x1809 ?x1809) true))))))))
(check-sat)
; query 67: function LARp_to_rp, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x382 (and (distinct ((_ sign_extend 16) in19_16) ((_ sign_extend 16) in19_16)) true))))))
(check-sat)
; query 68: function LARp_to_rp, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x1796 ((_ sign_extend 16) in19_16)))
(let ((?x1825 (bvshl ?x1796 (_ bv1 32))))
(let (($x262 (bvuge (_ bv1 32) (_ bv32 32))))
(let (($x382 (or false false)))
(let (($x1827 (or (or $x382 false (or (and (distinct (bvashr ?x1825 (_ bv1 32)) ?x1796) true))) $x262)))
(let (($x851 (or $x382 false false)))
(let (($x158 (or $x851 $x262)))
(let (($x486 (not $x158)))
(and $x486 (or $x1827 (and (distinct ?x1825 ?x1825) true))))))))))))
(check-sat)
; query 69: function LARp_to_rp, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x1796 ((_ sign_extend 16) in19_16)))
(let ((?x1825 (bvshl ?x1796 (_ bv1 32))))
(let ((?x279 ((_ sign_extend 32) ?x1825)))
(let (($x262 (bvuge (_ bv1 32) (_ bv32 32))))
(let (($x382 (or false false)))
(let (($x1827 (or (or $x382 false (or (and (distinct (bvashr ?x1825 (_ bv1 32)) ?x1796) true))) $x262)))
(and (not (or (or (or $x382 false false) $x262) false)) (or (or $x1827 false) (and (distinct ?x279 ?x279) true))))))))))
(check-sat)
; query 70: function LARp_to_rp, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x382 (and (distinct ((_ sign_extend 16) in19_16) ((_ sign_extend 16) in19_16)) true))))))
(check-sat)
; query 71: function LARp_to_rp, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x1845 (ite (bvsgt (_ bv20070 32) ((_ sign_extend 16) in19_16)) (_ bv1 1) (_ bv0 1))))
(let (($x382 (or false false)))
(let (($x851 (or $x382 false false)))
(let (($x97 (not $x851)))
(and $x97 (or $x851 (and (distinct ?x1845 ?x1845) true))))))))
(check-sat)
; query 72: function LARp_to_rp, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x382 (and (distinct ((_ sign_extend 16) in19_16) ((_ sign_extend 16) in19_16)) true))))))
(check-sat)
; query 73: function LARp_to_rp, block 29, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x1796 ((_ sign_extend 16) in19_16)))
(let ((?x1838 (bvadd ?x1796 (_ bv11059 32))))
(let (($x1865 (and (distinct (bvadd ((_ sign_extend 1) ?x1796) ((_ sign_extend 1) (_ bv11059 32))) ((_ sign_extend 1) ?x1838)) true)))
(let (($x382 (or false false)))
(let (($x1846 (or $x382 false (or $x1865))))
(and (not $x1846) (or $x1846 (and (distinct ?x1838 ?x1838) true)))))))))
(check-sat)
; query 74: function LARp_to_rp, block 29, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x1796 ((_ sign_extend 16) in19_16)))
(let ((?x1838 (bvadd ?x1796 (_ bv11059 32))))
(let ((?x1862 ((_ sign_extend 32) ?x1838)))
(let (($x1865 (and (distinct (bvadd ((_ sign_extend 1) ?x1796) ((_ sign_extend 1) (_ bv11059 32))) ((_ sign_extend 1) ?x1838)) true)))
(let (($x382 (or false false)))
(let (($x1846 (or $x382 false (or $x1865))))
(let (($x1839 (or $x1846 false)))
(and (not $x1839) (or $x1839 (and (distinct ?x1862 ?x1862) true)))))))))))
(check-sat)
; query 75: function LARp_to_rp, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x382 (and (distinct ((_ sign_extend 16) in19_16) ((_ sign_extend 16) in19_16)) true))))))
(check-sat)
; query 76: function LARp_to_rp, block 33, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x1796 ((_ sign_extend 16) in19_16)))
(let ((?x1855 (bvashr ?x1796 (_ bv2 32))))
(let (($x382 (or false false)))
(let (($x851 (or $x382 false false)))
(let (($x753 (or $x851 (bvuge (_ bv2 32) (_ bv32 32)))))
(and (not $x753) (or $x753 (and (distinct ?x1855 ?x1855) true)))))))))
(check-sat)
; query 77: function LARp_to_rp, block 33, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x1796 ((_ sign_extend 16) in19_16)))
(let ((?x1855 (bvashr ?x1796 (_ bv2 32))))
(let ((?x294 ((_ sign_extend 32) ?x1855)))
(let (($x382 (or false false)))
(let (($x851 (or $x382 false false)))
(let (($x753 (or $x851 (bvuge (_ bv2 32) (_ bv32 32)))))
(let (($x1853 (or $x753 false)))
(and (not $x1853) (or $x1853 (and (distinct ?x294 ?x294) true)))))))))))
(check-sat)
; query 78: function LARp_to_rp, block 33, name %37
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x1796 ((_ sign_extend 16) in19_16)))
(let ((?x1855 (bvashr ?x1796 (_ bv2 32))))
(let ((?x294 ((_ sign_extend 32) ?x1855)))
(let ((?x1876 (bvadd ?x294 (_ bv26112 64))))
(let ((?x1877 ((_ sign_extend 1) ?x1876)))
(let (($x382 (or false false)))
(let (($x851 (or $x382 false false)))
(let (($x753 (or $x851 (bvuge (_ bv2 32) (_ bv32 32)))))
(let (($x1853 (or $x753 false)))
(let (($x357 (or $x1853 false (or (and (distinct (bvadd ((_ sign_extend 1) ?x294) ((_ sign_extend 1) (_ bv26112 64))) ?x1877) true)))))
(and (not $x357) (or $x357 (and (distinct ?x1876 ?x1876) true))))))))))))))
(check-sat)
; query 79: function LARp_to_rp, block 33, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x1796 ((_ sign_extend 16) in19_16)))
(let ((?x1855 (bvashr ?x1796 (_ bv2 32))))
(let ((?x294 ((_ sign_extend 32) ?x1855)))
(let ((?x1876 (bvadd ?x294 (_ bv26112 64))))
(let ((?x1879 (bvsub ?x1876 (_ bv18446744073709518848 64))))
(let (($x1886 (and (distinct (bvsub ((_ sign_extend 1) ?x1876) ((_ sign_extend 1) (_ bv18446744073709518848 64))) ((_ sign_extend 1) ?x1879)) true)))
(let ((?x1877 ((_ sign_extend 1) ?x1876)))
(let (($x382 (or false false)))
(let (($x851 (or $x382 false false)))
(let (($x753 (or $x851 (bvuge (_ bv2 32) (_ bv32 32)))))
(let (($x1853 (or $x753 false)))
(let (($x357 (or $x1853 false (or (and (distinct (bvadd ((_ sign_extend 1) ?x294) ((_ sign_extend 1) (_ bv26112 64))) ?x1877) true)))))
(let (($x1894 (or $x357 false (or $x1886))))
(and (not $x1894) (or $x1894 (and (distinct ?x1879 ?x1879) true)))))))))))))))))
(check-sat)
; query 80: function LARp_to_rp, block 33, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x1796 ((_ sign_extend 16) in19_16)))
(let ((?x1855 (bvashr ?x1796 (_ bv2 32))))
(let ((?x294 ((_ sign_extend 32) ?x1855)))
(let ((?x1876 (bvadd ?x294 (_ bv26112 64))))
(let ((?x1879 (bvsub ?x1876 (_ bv18446744073709518848 64))))
(let ((?x1889 (ite (bvugt ?x1879 (_ bv65535 64)) (_ bv1 1) (_ bv0 1))))
(let (($x1886 (and (distinct (bvsub ((_ sign_extend 1) ?x1876) ((_ sign_extend 1) (_ bv18446744073709518848 64))) ((_ sign_extend 1) ?x1879)) true)))
(let ((?x1877 ((_ sign_extend 1) ?x1876)))
(let (($x382 (or false false)))
(let (($x851 (or $x382 false false)))
(let (($x753 (or $x851 (bvuge (_ bv2 32) (_ bv32 32)))))
(let (($x1853 (or $x753 false)))
(let (($x357 (or $x1853 false (or (and (distinct (bvadd ((_ sign_extend 1) ?x294) ((_ sign_extend 1) (_ bv26112 64))) ?x1877) true)))))
(let (($x1894 (or $x357 false (or $x1886))))
(let (($x1888 (or $x1894 false false)))
(and (not $x1888) (or $x1888 (and (distinct ?x1889 ?x1889) true)))))))))))))))))))
(check-sat)
; query 81: function Long_term_analysis_filtering, block 117, name %118
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in114_64 () (_ BitVec 64))
(assert
 (let ((?x358 (ite (bvsge (_ bv18446744073709518848 64) in114_64) (_ bv1 1) (_ bv0 1))))
(let (($x127 (or false false false)))
(let (($x105 (not $x127)))
(and $x105 (or $x127 (and (distinct ?x358 ?x358) true)))))))
(check-sat)
; query 82: function Long_term_analysis_filtering, block 128, name %129
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let (($x1935 (and (distinct (bvadd ((_ sign_extend 1) in.2_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.2_32 (_ bv1 32)))) true)))
(let (($x1932 (or false false (or $x1935))))
(and (not $x1932) (or $x1932 (and (distinct (bvadd in.2_32 (_ bv1 32)) (bvadd in.2_32 (_ bv1 32))) true))))))
(check-sat)
; query 83: function Long_term_analysis_filtering, block 158, name %159
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in155_64 () (_ BitVec 64))
(assert
 (let ((?x1945 (ite (bvsge (_ bv18446744073709518848 64) in155_64) (_ bv1 1) (_ bv0 1))))
(let (($x127 (or false false false)))
(let (($x105 (not $x127)))
(and $x105 (or $x127 (and (distinct ?x1945 ?x1945) true)))))))
(check-sat)
; query 84: function Long_term_analysis_filtering, block 169, name %170
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.3_32 () (_ BitVec 32))
(assert
 (let (($x1955 (and (distinct (bvadd ((_ sign_extend 1) in.3_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.3_32 (_ bv1 32)))) true)))
(let (($x1953 (or false false (or $x1955))))
(and (not $x1953) (or $x1953 (and (distinct (bvadd in.3_32 (_ bv1 32)) (bvadd in.3_32 (_ bv1 32))) true))))))
(check-sat)
; query 85: function Long_term_analysis_filtering, block 35, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in32_64 () (_ BitVec 64))
(assert
 (let ((?x1965 (ite (bvsge (_ bv18446744073709518848 64) in32_64) (_ bv1 1) (_ bv0 1))))
(let (($x127 (or false false false)))
(let (($x105 (not $x127)))
(and $x105 (or $x127 (and (distinct ?x1965 ?x1965) true)))))))
(check-sat)
; query 86: function Long_term_analysis_filtering, block 46, name %47
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1788 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x1795 (or false false (or $x1788))))
(and (not $x1795) (or $x1795 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 87: function Long_term_analysis_filtering, block 76, name %77
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in73_64 () (_ BitVec 64))
(assert
 (let ((?x1974 (ite (bvsge (_ bv18446744073709518848 64) in73_64) (_ bv1 1) (_ bv0 1))))
(let (($x127 (or false false false)))
(let (($x105 (not $x127)))
(and $x105 (or $x127 (and (distinct ?x1974 ?x1974) true)))))))
(check-sat)
; query 88: function Long_term_analysis_filtering, block 87, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x1982 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x1969 (or false false (or $x1982))))
(and (not $x1969) (or $x1969 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 89: function Postprocessing, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in17_64 () (_ BitVec 64))
(assert
 (let ((?x1995 (ite (bvslt (_ bv0 64) in17_64) (_ bv1 1) (_ bv0 1))))
(let (($x127 (or false false false)))
(let (($x105 (not $x127)))
(and $x105 (or $x127 (and (distinct ?x1995 ?x1995) true)))))))
(check-sat)
; query 90: function Postprocessing, block 20, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in17_64 () (_ BitVec 64))
(assert
 (let ((?x1995 (ite (bvslt (_ bv0 64) in17_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1977 ((_ zero_extend 63) ?x1995)))
(let (($x127 (or false false false)))
(let (($x553 (or $x127 false)))
(let (($x2071 (not $x553)))
(and $x2071 (or $x553 (and (distinct ?x1977 ?x1977) true)))))))))
(check-sat)
; query 91: function Postprocessing, block 20, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in17_64 () (_ BitVec 64))
(assert
 (let ((?x1995 (ite (bvslt (_ bv0 64) in17_64) (_ bv1 1) (_ bv0 1))))
(let (($x401 (= (_ bv1 1) ?x1995)))
(let ((?x1992 (ite $x401 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x127 (or false false false)))
(let (($x1984 (or $x127 (ite $x401 false false))))
(and (not $x1984) (or $x1984 (and (distinct ?x1992 ?x1992) true)))))))))
(check-sat)
; query 92: function Postprocessing, block 20, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in17_64 () (_ BitVec 64))
(assert
 (let ((?x1995 (ite (bvslt (_ bv0 64) in17_64) (_ bv1 1) (_ bv0 1))))
(let (($x401 (= (_ bv1 1) ?x1995)))
(let ((?x1992 (ite $x401 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x1985 ((_ sign_extend 32) ?x1992)))
(let (($x127 (or false false false)))
(let (($x1984 (or $x127 (ite $x401 false false))))
(let (($x1988 (or $x1984 false)))
(and (not $x1988) (or $x1988 (and (distinct ?x1985 ?x1985) true)))))))))))
(check-sat)
; query 93: function Postprocessing, block 34, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in31_64 () (_ BitVec 64))
(assert
 (let ((?x2013 (ite (bvslt (_ bv0 64) in31_64) (_ bv1 1) (_ bv0 1))))
(let (($x127 (or false false false)))
(let (($x105 (not $x127)))
(and $x105 (or $x127 (and (distinct ?x2013 ?x2013) true)))))))
(check-sat)
; query 94: function Postprocessing, block 34, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in31_64 () (_ BitVec 64))
(assert
 (let ((?x2013 (ite (bvslt (_ bv0 64) in31_64) (_ bv1 1) (_ bv0 1))))
(let ((?x2008 ((_ zero_extend 63) ?x2013)))
(let (($x127 (or false false false)))
(let (($x553 (or $x127 false)))
(let (($x2071 (not $x553)))
(and $x2071 (or $x553 (and (distinct ?x2008 ?x2008) true)))))))))
(check-sat)
; query 95: function Postprocessing, block 34, name %37
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in31_64 () (_ BitVec 64))
(assert
 (let ((?x2013 (ite (bvslt (_ bv0 64) in31_64) (_ bv1 1) (_ bv0 1))))
(let (($x2009 (= (_ bv1 1) ?x2013)))
(let ((?x2016 (ite $x2009 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x127 (or false false false)))
(let (($x2022 (or $x127 (ite $x2009 false false))))
(and (not $x2022) (or $x2022 (and (distinct ?x2016 ?x2016) true)))))))))
(check-sat)
; query 96: function Postprocessing, block 34, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in31_64 () (_ BitVec 64))
(assert
 (let ((?x2013 (ite (bvslt (_ bv0 64) in31_64) (_ bv1 1) (_ bv0 1))))
(let (($x2009 (= (_ bv1 1) ?x2013)))
(let ((?x2016 (ite $x2009 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x2023 ((_ sign_extend 32) ?x2016)))
(let (($x127 (or false false false)))
(let (($x2022 (or $x127 (ite $x2009 false false))))
(let (($x2017 (or $x2022 false)))
(and (not $x2017) (or $x2017 (and (distinct ?x2023 ?x2023) true)))))))))))
(check-sat)
; query 97: function RPE_grid_positioning, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x382 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 98: function RPE_grid_positioning, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x103 (ite (bvsge (_ bv3 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x382 (or false false)))
(let (($x851 (or $x382 false false)))
(let (($x97 (not $x851)))
(and $x97 (or $x851 (and (distinct ?x103 ?x103) true))))))))
(check-sat)
; query 99: function RPE_grid_positioning, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x382 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 100: function RPE_grid_positioning, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x2048 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x2057 (and (distinct ?x2048 ?x2048) true)))
(let (($x382 (or false false)))
(let (($x2072 (or false $x382 false)))
(and (not $x2072) (or $x2072 $x2057)))))))
(check-sat)
; query 101: function RPE_grid_selection, block 308, name %309
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_32 () (_ BitVec 32))
(assert
 (let (($x161 (and (distinct (bvadd ((_ sign_extend 1) in.03_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.03_32 (_ bv1 32)))) true)))
(let (($x173 (or false false (or $x161))))
(and (not $x173) (or $x173 (and (distinct (bvadd in.03_32 (_ bv1 32)) (bvadd in.03_32 (_ bv1 32))) true))))))
(check-sat)
; query 102: function Short_term_analysis_filtering, block 34, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in31_64 () (_ BitVec 64))
(assert
 (let ((?x2013 (ite (bvslt (_ bv0 64) in31_64) (_ bv1 1) (_ bv0 1))))
(let (($x127 (or false false false)))
(let (($x105 (not $x127)))
(and $x105 (or $x127 (and (distinct ?x2013 ?x2013) true)))))))
(check-sat)
; query 103: function Short_term_analysis_filtering, block 34, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in31_64 () (_ BitVec 64))
(assert
 (let ((?x2013 (ite (bvslt (_ bv0 64) in31_64) (_ bv1 1) (_ bv0 1))))
(let ((?x2008 ((_ zero_extend 63) ?x2013)))
(let (($x127 (or false false false)))
(let (($x553 (or $x127 false)))
(let (($x2071 (not $x553)))
(and $x2071 (or $x553 (and (distinct ?x2008 ?x2008) true)))))))))
(check-sat)
; query 104: function Short_term_analysis_filtering, block 34, name %37
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in31_64 () (_ BitVec 64))
(assert
 (let ((?x2013 (ite (bvslt (_ bv0 64) in31_64) (_ bv1 1) (_ bv0 1))))
(let (($x2009 (= (_ bv1 1) ?x2013)))
(let ((?x2016 (ite $x2009 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x127 (or false false false)))
(let (($x2022 (or $x127 (ite $x2009 false false))))
(and (not $x2022) (or $x2022 (and (distinct ?x2016 ?x2016) true)))))))))
(check-sat)
; query 105: function Short_term_analysis_filtering, block 34, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in31_64 () (_ BitVec 64))
(assert
 (let ((?x2013 (ite (bvslt (_ bv0 64) in31_64) (_ bv1 1) (_ bv0 1))))
(let (($x2009 (= (_ bv1 1) ?x2013)))
(let ((?x2016 (ite $x2009 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x2023 ((_ sign_extend 32) ?x2016)))
(let (($x127 (or false false false)))
(let (($x2022 (or $x127 (ite $x2009 false false))))
(let (($x2017 (or $x2022 false)))
(and (not $x2017) (or $x2017 (and (distinct ?x2023 ?x2023) true)))))))))))
(check-sat)
; query 106: function Short_term_analysis_filtering, block 54, name %55
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in51_64 () (_ BitVec 64))
(assert
 (let ((?x745 (ite (bvslt (_ bv0 64) in51_64) (_ bv1 1) (_ bv0 1))))
(let (($x127 (or false false false)))
(let (($x105 (not $x127)))
(and $x105 (or $x127 (and (distinct ?x745 ?x745) true)))))))
(check-sat)
; query 107: function Short_term_analysis_filtering, block 54, name %56
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in51_64 () (_ BitVec 64))
(assert
 (let ((?x745 (ite (bvslt (_ bv0 64) in51_64) (_ bv1 1) (_ bv0 1))))
(let ((?x2062 ((_ zero_extend 63) ?x745)))
(let (($x127 (or false false false)))
(let (($x553 (or $x127 false)))
(let (($x2071 (not $x553)))
(and $x2071 (or $x553 (and (distinct ?x2062 ?x2062) true)))))))))
(check-sat)
; query 108: function Short_term_analysis_filtering, block 54, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in51_64 () (_ BitVec 64))
(assert
 (let ((?x745 (ite (bvslt (_ bv0 64) in51_64) (_ bv1 1) (_ bv0 1))))
(let (($x2058 (= (_ bv1 1) ?x745)))
(let ((?x2066 (ite $x2058 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x127 (or false false false)))
(let (($x2052 (or $x127 (ite $x2058 false false))))
(and (not $x2052) (or $x2052 (and (distinct ?x2066 ?x2066) true)))))))))
(check-sat)
; query 109: function Short_term_analysis_filtering, block 54, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in51_64 () (_ BitVec 64))
(assert
 (let ((?x745 (ite (bvslt (_ bv0 64) in51_64) (_ bv1 1) (_ bv0 1))))
(let (($x2058 (= (_ bv1 1) ?x745)))
(let ((?x2066 (ite $x2058 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x2036 ((_ sign_extend 32) ?x2066)))
(let (($x127 (or false false false)))
(let (($x2052 (or $x127 (ite $x2058 false false))))
(let (($x2049 (or $x2052 false)))
(and (not $x2049) (or $x2049 (and (distinct ?x2036 ?x2036) true)))))))))))
(check-sat)
; query 110: function Short_term_analysis_filtering, block 63, name %64
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_32 () (_ BitVec 32))
(assert
 (let (($x161 (and (distinct (bvadd ((_ sign_extend 1) in.03_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.03_32 (_ bv1 32)))) true)))
(let (($x173 (or false false (or $x161))))
(and (not $x173) (or $x173 (and (distinct (bvadd in.03_32 (_ bv1 32)) (bvadd in.03_32 (_ bv1 32))) true))))))
(check-sat)
; query 111: function Short_term_synthesis_filtering, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in23_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x382 (and (distinct ((_ sign_extend 16) in23_16) ((_ sign_extend 16) in23_16)) true))))))
(check-sat)
; query 112: function Short_term_synthesis_filtering, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in23_16 () (_ BitVec 16))
(assert
 (let ((?x2077 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in23_16)) (_ bv1 1) (_ bv0 1))))
(let (($x382 (or false false)))
(let (($x851 (or $x382 false false)))
(let (($x97 (not $x851)))
(and $x97 (or $x851 (and (distinct ?x2077 ?x2077) true))))))))
(check-sat)
; query 113: function Short_term_synthesis_filtering, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in20_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x382 (and (distinct ((_ sign_extend 48) in20_16) ((_ sign_extend 48) in20_16)) true))))))
(check-sat)
; query 114: function Short_term_synthesis_filtering, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in23_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x382 (and (distinct ((_ sign_extend 48) in23_16) ((_ sign_extend 48) in23_16)) true))))))
(check-sat)
; query 115: function Short_term_synthesis_filtering, block 30, name %33
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in23_16 () (_ BitVec 16))
(declare-fun in20_16 () (_ BitVec 16))
(assert
 (let ((?x2088 ((_ sign_extend 48) in23_16)))
(let ((?x2083 ((_ sign_extend 48) in20_16)))
(let ((?x636 (bvmul ?x2083 ?x2088)))
(let (($x1478 (and (distinct (bvmul ((_ sign_extend 64) ?x2083) ((_ sign_extend 64) ?x2088)) ((_ sign_extend 64) ?x636)) true)))
(let (($x382 (or false false)))
(let (($x2093 (or $x382 $x382 (or $x1478))))
(and (not $x2093) (or $x2093 (and (distinct ?x636 ?x636) true))))))))))
(check-sat)
; query 116: function Short_term_synthesis_filtering, block 30, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in23_16 () (_ BitVec 16))
(declare-fun in20_16 () (_ BitVec 16))
(assert
 (let ((?x2088 ((_ sign_extend 48) in23_16)))
(let ((?x2083 ((_ sign_extend 48) in20_16)))
(let ((?x636 (bvmul ?x2083 ?x2088)))
(let ((?x381 (bvadd ?x636 (_ bv16384 64))))
(let (($x540 (and (distinct (bvadd ((_ sign_extend 1) ?x636) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x381)) true)))
(let (($x1478 (and (distinct (bvmul ((_ sign_extend 64) ?x2083) ((_ sign_extend 64) ?x2088)) ((_ sign_extend 64) ?x636)) true)))
(let (($x382 (or false false)))
(let (($x2093 (or $x382 $x382 (or $x1478))))
(let (($x1483 (or $x2093 false (or $x540))))
(and (not $x1483) (or $x1483 (and (distinct ?x381 ?x381) true)))))))))))))
(check-sat)
; query 117: function Short_term_synthesis_filtering, block 30, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in23_16 () (_ BitVec 16))
(declare-fun in20_16 () (_ BitVec 16))
(assert
 (let ((?x2088 ((_ sign_extend 48) in23_16)))
(let ((?x2083 ((_ sign_extend 48) in20_16)))
(let ((?x636 (bvmul ?x2083 ?x2088)))
(let ((?x381 (bvadd ?x636 (_ bv16384 64))))
(let ((?x1043 (bvashr ?x381 (_ bv15 64))))
(let (($x1490 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x540 (and (distinct (bvadd ((_ sign_extend 1) ?x636) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x381)) true)))
(let (($x1478 (and (distinct (bvmul ((_ sign_extend 64) ?x2083) ((_ sign_extend 64) ?x2088)) ((_ sign_extend 64) ?x636)) true)))
(let (($x382 (or false false)))
(let (($x2093 (or $x382 $x382 (or $x1478))))
(let (($x1483 (or $x2093 false (or $x540))))
(let (($x1491 (or (or $x1483 false false) $x1490)))
(and (not $x1491) (or $x1491 (and (distinct ?x1043 ?x1043) true))))))))))))))))
(check-sat)
; query 118: function Short_term_synthesis_filtering, block 30, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in23_16 () (_ BitVec 16))
(declare-fun in20_16 () (_ BitVec 16))
(assert
 (let ((?x2088 ((_ sign_extend 48) in23_16)))
(let ((?x2083 ((_ sign_extend 48) in20_16)))
(let ((?x636 (bvmul ?x2083 ?x2088)))
(let ((?x381 (bvadd ?x636 (_ bv16384 64))))
(let ((?x1043 (bvashr ?x381 (_ bv15 64))))
(let ((?x1496 (bvand (_ bv65535 64) ?x1043)))
(let (($x1490 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x540 (and (distinct (bvadd ((_ sign_extend 1) ?x636) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x381)) true)))
(let (($x1478 (and (distinct (bvmul ((_ sign_extend 64) ?x2083) ((_ sign_extend 64) ?x2088)) ((_ sign_extend 64) ?x636)) true)))
(let (($x382 (or false false)))
(let (($x2093 (or $x382 $x382 (or $x1478))))
(let (($x1483 (or $x2093 false (or $x540))))
(let (($x1491 (or (or $x1483 false false) $x1490)))
(let (($x1488 (or false $x1491 false)))
(and (not $x1488) (or $x1488 (and (distinct ?x1496 ?x1496) true))))))))))))))))))
(check-sat)
; query 119: function Short_term_synthesis_filtering, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in42_64 () (_ BitVec 64))
(assert
 (let ((?x878 (ite (bvsge (_ bv18446744073709518848 64) in42_64) (_ bv1 1) (_ bv0 1))))
(let (($x127 (or false false false)))
(let (($x105 (not $x127)))
(and $x105 (or $x127 (and (distinct ?x878 ?x878) true)))))))
(check-sat)
; query 120: function Short_term_synthesis_filtering, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x382 (and (distinct ((_ sign_extend 16) in53_16) ((_ sign_extend 16) in53_16)) true))))))
(check-sat)
; query 121: function Short_term_synthesis_filtering, block 56, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let ((?x1517 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in53_16)) (_ bv1 1) (_ bv0 1))))
(let (($x382 (or false false)))
(let (($x851 (or $x382 false false)))
(let (($x97 (not $x851)))
(and $x97 (or $x851 (and (distinct ?x1517 ?x1517) true))))))))
(check-sat)
; query 122: function Short_term_synthesis_filtering, block 60, name %61
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in20_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x382 (and (distinct ((_ sign_extend 48) in20_16) ((_ sign_extend 48) in20_16)) true))))))
(check-sat)
; query 123: function Short_term_synthesis_filtering, block 60, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x382 (and (distinct ((_ sign_extend 48) in53_16) ((_ sign_extend 48) in53_16)) true))))))
(check-sat)
; query 124: function Short_term_synthesis_filtering, block 60, name %63
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(declare-fun in20_16 () (_ BitVec 16))
(assert
 (let ((?x1525 ((_ sign_extend 48) in53_16)))
(let ((?x2083 ((_ sign_extend 48) in20_16)))
(let ((?x1533 (bvmul ?x2083 ?x1525)))
(let (($x1531 (and (distinct (bvmul ((_ sign_extend 64) ?x2083) ((_ sign_extend 64) ?x1525)) ((_ sign_extend 64) ?x1533)) true)))
(let (($x382 (or false false)))
(let (($x671 (or $x382 $x382 (or $x1531))))
(and (not $x671) (or $x671 (and (distinct ?x1533 ?x1533) true))))))))))
(check-sat)
; query 125: function Short_term_synthesis_filtering, block 60, name %64
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(declare-fun in20_16 () (_ BitVec 16))
(assert
 (let ((?x1525 ((_ sign_extend 48) in53_16)))
(let ((?x2083 ((_ sign_extend 48) in20_16)))
(let ((?x1533 (bvmul ?x2083 ?x1525)))
(let ((?x1535 (bvadd ?x1533 (_ bv16384 64))))
(let (($x1536 (and (distinct (bvadd ((_ sign_extend 1) ?x1533) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x1535)) true)))
(let (($x1531 (and (distinct (bvmul ((_ sign_extend 64) ?x2083) ((_ sign_extend 64) ?x1525)) ((_ sign_extend 64) ?x1533)) true)))
(let (($x382 (or false false)))
(let (($x671 (or $x382 $x382 (or $x1531))))
(let (($x1539 (or $x671 false (or $x1536))))
(and (not $x1539) (or $x1539 (and (distinct ?x1535 ?x1535) true)))))))))))))
(check-sat)
; query 126: function Short_term_synthesis_filtering, block 60, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(declare-fun in20_16 () (_ BitVec 16))
(assert
 (let ((?x1525 ((_ sign_extend 48) in53_16)))
(let ((?x2083 ((_ sign_extend 48) in20_16)))
(let ((?x1533 (bvmul ?x2083 ?x1525)))
(let ((?x1535 (bvadd ?x1533 (_ bv16384 64))))
(let ((?x1545 (bvashr ?x1535 (_ bv15 64))))
(let (($x1490 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1536 (and (distinct (bvadd ((_ sign_extend 1) ?x1533) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x1535)) true)))
(let (($x1531 (and (distinct (bvmul ((_ sign_extend 64) ?x2083) ((_ sign_extend 64) ?x1525)) ((_ sign_extend 64) ?x1533)) true)))
(let (($x382 (or false false)))
(let (($x671 (or $x382 $x382 (or $x1531))))
(let (($x1539 (or $x671 false (or $x1536))))
(let (($x1537 (or (or $x1539 false false) $x1490)))
(and (not $x1537) (or $x1537 (and (distinct ?x1545 ?x1545) true))))))))))))))))
(check-sat)
; query 127: function Short_term_synthesis_filtering, block 60, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(declare-fun in20_16 () (_ BitVec 16))
(assert
 (let ((?x1525 ((_ sign_extend 48) in53_16)))
(let ((?x2083 ((_ sign_extend 48) in20_16)))
(let ((?x1533 (bvmul ?x2083 ?x1525)))
(let ((?x1535 (bvadd ?x1533 (_ bv16384 64))))
(let ((?x1545 (bvashr ?x1535 (_ bv15 64))))
(let ((?x1543 (bvand (_ bv65535 64) ?x1545)))
(let (($x1490 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1536 (and (distinct (bvadd ((_ sign_extend 1) ?x1533) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x1535)) true)))
(let (($x1531 (and (distinct (bvmul ((_ sign_extend 64) ?x2083) ((_ sign_extend 64) ?x1525)) ((_ sign_extend 64) ?x1533)) true)))
(let (($x382 (or false false)))
(let (($x671 (or $x382 $x382 (or $x1531))))
(let (($x1539 (or $x671 false (or $x1536))))
(let (($x1537 (or (or $x1539 false false) $x1490)))
(let (($x1547 (or false $x1537 false)))
(and (not $x1547) (or $x1547 (and (distinct ?x1543 ?x1543) true))))))))))))))))))
(check-sat)
; query 128: function Short_term_synthesis_filtering, block 78, name %79
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in75_64 () (_ BitVec 64))
(assert
 (let ((?x1581 (ite (bvslt (_ bv0 64) in75_64) (_ bv1 1) (_ bv0 1))))
(let (($x127 (or false false false)))
(let (($x105 (not $x127)))
(and $x105 (or $x127 (and (distinct ?x1581 ?x1581) true)))))))
(check-sat)
; query 129: function Short_term_synthesis_filtering, block 78, name %80
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in75_64 () (_ BitVec 64))
(assert
 (let ((?x1581 (ite (bvslt (_ bv0 64) in75_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1590 ((_ zero_extend 63) ?x1581)))
(let (($x127 (or false false false)))
(let (($x553 (or $x127 false)))
(let (($x2071 (not $x553)))
(and $x2071 (or $x553 (and (distinct ?x1590 ?x1590) true)))))))))
(check-sat)
; query 130: function Short_term_synthesis_filtering, block 78, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in75_64 () (_ BitVec 64))
(assert
 (let ((?x1581 (ite (bvslt (_ bv0 64) in75_64) (_ bv1 1) (_ bv0 1))))
(let (($x1559 (= (_ bv1 1) ?x1581)))
(let ((?x1567 (ite $x1559 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x127 (or false false false)))
(let (($x1565 (or $x127 (ite $x1559 false false))))
(and (not $x1565) (or $x1565 (and (distinct ?x1567 ?x1567) true)))))))))
(check-sat)
; query 131: function Short_term_synthesis_filtering, block 78, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in75_64 () (_ BitVec 64))
(assert
 (let ((?x1581 (ite (bvslt (_ bv0 64) in75_64) (_ bv1 1) (_ bv0 1))))
(let (($x1559 (= (_ bv1 1) ?x1581)))
(let ((?x1567 (ite $x1559 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x1568 ((_ sign_extend 32) ?x1567)))
(let (($x127 (or false false false)))
(let (($x1565 (or $x127 (ite $x1559 false false))))
(let (($x1566 (or $x1565 false)))
(and (not $x1566) (or $x1566 (and (distinct ?x1568 ?x1568) true)))))))))))
(check-sat)
; query 132: function Transformation_to_Log_Area_Ratios, block 12, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x382 (and (distinct ((_ sign_extend 16) in5_16) ((_ sign_extend 16) in5_16)) true))))))
(check-sat)
; query 133: function Transformation_to_Log_Area_Ratios, block 12, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_16 () (_ BitVec 16))
(assert
 (let ((?x1592 ((_ sign_extend 16) in5_16)))
(let ((?x846 (bvsub (_ bv0 32) ?x1592)))
(let (($x1570 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1592)) ((_ sign_extend 1) ?x846)) true)))
(let (($x382 (or false false)))
(let (($x1598 (or false $x382 (or $x1570))))
(and (not $x1598) (or $x1598 (and (distinct ?x846 ?x846) true)))))))))
(check-sat)
; query 134: function Transformation_to_Log_Area_Ratios, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x382 (and (distinct ((_ sign_extend 16) in5_16) ((_ sign_extend 16) in5_16)) true))))))
(check-sat)
; query 135: function Transformation_to_Log_Area_Ratios, block 77, name %78
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x382 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 136: function Transformation_to_Log_Area_Ratios, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_16 () (_ BitVec 16))
(assert
 (let ((?x1608 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in5_16)) (_ bv1 1) (_ bv0 1))))
(let (($x382 (or false false)))
(let (($x851 (or $x382 false false)))
(let (($x97 (not $x851)))
(and $x97 (or $x851 (and (distinct ?x1608 ?x1608) true))))))))
(check-sat)
; query 137: function Transformation_to_Log_Area_Ratios, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x382 (and (distinct ((_ sign_extend 16) in5_16) ((_ sign_extend 16) in5_16)) true))))))
(check-sat)
; query 138: function Weighting_filter, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in70_64 () (_ BitVec 64))
(assert
 (let ((?x1583 (ite (bvslt (_ bv32767 64) in70_64) (_ bv1 1) (_ bv0 1))))
(let (($x127 (or false false false)))
(let (($x105 (not $x127)))
(and $x105 (or $x127 (and (distinct ?x1583 ?x1583) true)))))))
(check-sat)
; query 139: function Weighting_filter, block 84, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1788 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x1795 (or false false (or $x1788))))
(and (not $x1795) (or $x1795 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 140: function alaw_input, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x1099 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x1675 (or false false (or $x1099))))
(and (not $x1675) (or $x1675 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 141: function alaw_input, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let ((?x1620 (ite (= (_ bv4294967295 32) in.1_32) (_ bv1 1) (_ bv0 1))))
(let (($x127 (or false false false)))
(let (($x105 (not $x127)))
(and $x105 (or $x127 (and (distinct ?x1620 ?x1620) true)))))))
(check-sat)
; query 142: function gsm_L_add, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_64 () (_ BitVec 64))
(assert
 (let ((?x1617 (bvsub (_ bv0 64) in13_64)))
(let ((?x1618 ((_ sign_extend 1) ?x1617)))
(let (($x1686 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in13_64)) ?x1618) true)))))
(and (not $x1686) (or $x1686 (and (distinct ?x1617 ?x1617) true)))))))
(check-sat)
; query 143: function gsm_L_add, block 16, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_64 () (_ BitVec 64))
(assert
 (let ((?x1617 (bvsub (_ bv0 64) in13_64)))
(let ((?x1684 (bvsub ?x1617 (_ bv2 64))))
(let (($x1690 (and (distinct (bvsub ((_ sign_extend 1) ?x1617) ((_ sign_extend 1) (_ bv2 64))) ((_ sign_extend 1) ?x1684)) true)))
(let ((?x1618 ((_ sign_extend 1) ?x1617)))
(let (($x1686 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in13_64)) ?x1618) true)))))
(let (($x1627 (or $x1686 false (or $x1690))))
(and (not $x1627) (or $x1627 (and (distinct ?x1684 ?x1684) true))))))))))
(check-sat)
; query 144: function gsm_L_add, block 21, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1628 (ite (bvsge (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x127 (or false false false)))
(let (($x105 (not $x127)))
(and $x105 (or $x127 (and (distinct ?x1628 ?x1628) true)))))))
(check-sat)
; query 145: function gsm_L_add, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1698 (bvadd in0_64 in1_64)))
(let (($x1703 (and (distinct ?x1698 ?x1698) true)))
(let (($x1694 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) ?x1698)) true)))
(let (($x1701 (or false false (or $x1694))))
(and (not $x1701) (or $x1701 $x1703)))))))
(check-sat)
; query 146: function gsm_L_add, block 25, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1698 (bvadd in0_64 in1_64)))
(let (($x1703 (and (distinct ?x1698 ?x1698) true)))
(let (($x1642 (and (distinct (bvadd ((_ zero_extend 1) in0_64) ((_ zero_extend 1) in1_64)) ((_ zero_extend 1) ?x1698)) true)))
(let (($x1648 (or false false (or $x1642))))
(let (($x127 (or false false false)))
(let (($x105 (not $x127)))
(and $x105 (or $x1648 $x1703)))))))))
(check-sat)
; query 147: function gsm_L_add, block 25, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1644 (ite (bvugt (bvadd in0_64 in1_64) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x1642 (and (distinct (bvadd ((_ zero_extend 1) in0_64) ((_ zero_extend 1) in1_64)) ((_ zero_extend 1) (bvadd in0_64 in1_64))) true)))
(let (($x1648 (or false false (or $x1642))))
(let (($x127 (or false false false)))
(let (($x1645 (or $x127 false false)))
(let (($x1708 (not $x1645)))
(and $x1708 (or (or $x1648 false false) (and (distinct ?x1644 ?x1644) true))))))))))
(check-sat)
; query 148: function gsm_L_add, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1656 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x127 (or false false false)))
(let (($x105 (not $x127)))
(and $x105 (or $x127 (and (distinct ?x1656 ?x1656) true)))))))
(check-sat)
; query 149: function gsm_L_add, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1698 (bvadd in0_64 in1_64)))
(let (($x1703 (and (distinct ?x1698 ?x1698) true)))
(let (($x1694 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) ?x1698)) true)))
(let (($x1701 (or false false (or $x1694))))
(and (not $x1701) (or $x1701 $x1703)))))))
(check-sat)
; query 150: function gsm_L_add, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1654 (bvadd in0_64 (_ bv1 64))))
(let ((?x1657 (bvsub (_ bv0 64) ?x1654)))
(let (($x1659 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1654)) ((_ sign_extend 1) ?x1657)) true)))
(let ((?x1650 ((_ sign_extend 1) ?x1654)))
(let (($x1715 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1650) true)))))
(let (($x1663 (or false $x1715 (or $x1659))))
(and (not $x1663) (or $x1663 (and (distinct ?x1657 ?x1657) true))))))))))
(check-sat)
; query 151: function gsm_L_add, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1666 (bvadd in1_64 (_ bv1 64))))
(let ((?x1667 ((_ sign_extend 1) ?x1666)))
(let (($x1722 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1667) true)))))
(and (not $x1722) (or $x1722 (and (distinct ?x1666 ?x1666) true)))))))
(check-sat)
; query 152: function gsm_L_add, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1666 (bvadd in1_64 (_ bv1 64))))
(let ((?x1664 (bvsub (_ bv0 64) ?x1666)))
(let (($x1662 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1666)) ((_ sign_extend 1) ?x1664)) true)))
(let ((?x1667 ((_ sign_extend 1) ?x1666)))
(let (($x1722 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1667) true)))))
(let (($x1665 (or false $x1722 (or $x1662))))
(and (not $x1665) (or $x1665 (and (distinct ?x1664 ?x1664) true))))))))))
(check-sat)
; query 153: function gsm_L_add, block 8, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1666 (bvadd in1_64 (_ bv1 64))))
(let ((?x1664 (bvsub (_ bv0 64) ?x1666)))
(let ((?x1654 (bvadd in0_64 (_ bv1 64))))
(let ((?x1657 (bvsub (_ bv0 64) ?x1654)))
(let ((?x1670 (bvadd ?x1657 ?x1664)))
(let (($x1725 (and (distinct (bvadd ((_ zero_extend 1) ?x1657) ((_ zero_extend 1) ?x1664)) ((_ zero_extend 1) ?x1670)) true)))
(let (($x1662 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1666)) ((_ sign_extend 1) ?x1664)) true)))
(let ((?x1667 ((_ sign_extend 1) ?x1666)))
(let (($x1722 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1667) true)))))
(let (($x1665 (or false $x1722 (or $x1662))))
(let (($x1659 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1654)) ((_ sign_extend 1) ?x1657)) true)))
(let ((?x1650 ((_ sign_extend 1) ?x1654)))
(let (($x1715 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1650) true)))))
(let (($x1663 (or false $x1715 (or $x1659))))
(let (($x1726 (or $x1663 $x1665 (or $x1725))))
(and (not (or $x1663 $x1665 false)) (or $x1726 (and (distinct ?x1670 ?x1670) true)))))))))))))))))))
(check-sat)
; query 154: function gsm_L_add, block 8, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1666 (bvadd in1_64 (_ bv1 64))))
(let ((?x1664 (bvsub (_ bv0 64) ?x1666)))
(let ((?x1654 (bvadd in0_64 (_ bv1 64))))
(let ((?x1657 (bvsub (_ bv0 64) ?x1654)))
(let ((?x1670 (bvadd ?x1657 ?x1664)))
(let ((?x1716 (ite (bvuge ?x1670 (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x1725 (and (distinct (bvadd ((_ zero_extend 1) ?x1657) ((_ zero_extend 1) ?x1664)) ((_ zero_extend 1) ?x1670)) true)))
(let (($x1662 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1666)) ((_ sign_extend 1) ?x1664)) true)))
(let ((?x1667 ((_ sign_extend 1) ?x1666)))
(let (($x1722 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1667) true)))))
(let (($x1665 (or false $x1722 (or $x1662))))
(let (($x1659 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1654)) ((_ sign_extend 1) ?x1657)) true)))
(let ((?x1650 ((_ sign_extend 1) ?x1654)))
(let (($x1715 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1650) true)))))
(let (($x1663 (or false $x1715 (or $x1659))))
(let (($x1726 (or $x1663 $x1665 (or $x1725))))
(and (not (or (or $x1663 $x1665 false) false false)) (or (or $x1726 false false) (and (distinct ?x1716 ?x1716) true))))))))))))))))))))
(check-sat)
; query 155: function gsm_L_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1654 (bvadd in0_64 (_ bv1 64))))
(let ((?x1650 ((_ sign_extend 1) ?x1654)))
(let (($x1715 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1650) true)))))
(and (not $x1715) (or $x1715 (and (distinct ?x1654 ?x1654) true)))))))
(check-sat)
; query 156: function gsm_L_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1754 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x127 (or false false false)))
(let (($x105 (not $x127)))
(and $x105 (or $x127 (and (distinct ?x1754 ?x1754) true)))))))
(check-sat)
; query 157: function gsm_L_asl, block 12, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x973 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x127 (or false false false)))
(let (($x105 (not $x127)))
(and $x105 (or $x127 (and (distinct ?x973 ?x973) true)))))))
(check-sat)
; query 158: function gsm_L_asl, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x1759 (or false (or (= ((_ extract 31 31) in1_32) (_ bv1 1))))))
(let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x1759 (and (distinct ((_ zero_extend 32) in1_32) ((_ zero_extend 32) in1_32)) true)))))))
(check-sat)
; query 159: function gsm_L_asl, block 17, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1750 ((_ zero_extend 32) in1_32)))
(let ((?x1772 (bvshl in0_64 ?x1750)))
(let (($x1756 (bvuge ?x1750 (_ bv64 64))))
(let (($x1757 (or (or false (or false (or (= ((_ extract 31 31) in1_32) (_ bv1 1)))) false) $x1756)))
(let (($x1403 (not (or (or false (or false false) false) $x1756))))
(and $x1403 (or $x1757 (and (distinct ?x1772 ?x1772) true)))))))))
(check-sat)
; query 160: function gsm_L_asl, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1763 (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x127 (or false false false)))
(let (($x105 (not $x127)))
(and $x105 (or $x127 (and (distinct ?x1763 ?x1763) true)))))))
(check-sat)
; query 161: function gsm_L_asl, block 7, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1754 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x898 ((_ zero_extend 31) ?x1754)))
(let ((?x1770 (bvsub (_ bv0 32) ?x898)))
(let (($x1330 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x898)) ((_ sign_extend 1) ?x1770)) true)))
(let (($x127 (or false false false)))
(let (($x553 (or $x127 false)))
(let (($x1332 (or false $x553 (or $x1330))))
(and (not $x1332) (or $x1332 (and (distinct ?x1770 ?x1770) true)))))))))))
(check-sat)
; query 162: function gsm_L_asl, block 7, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1754 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x898 ((_ zero_extend 31) ?x1754)))
(let ((?x1770 (bvsub (_ bv0 32) ?x898)))
(let ((?x1340 ((_ sign_extend 32) ?x1770)))
(let (($x1330 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x898)) ((_ sign_extend 1) ?x1770)) true)))
(let (($x127 (or false false false)))
(let (($x553 (or $x127 false)))
(let (($x1332 (or false $x553 (or $x1330))))
(let (($x1342 (or $x1332 false)))
(and (not $x1342) (or $x1342 (and (distinct ?x1340 ?x1340) true)))))))))))))
(check-sat)
; query 163: function gsm_L_asl, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1754 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x127 (or false false false)))
(let (($x105 (not $x127)))
(and $x105 (or $x127 (and (distinct ?x1754 ?x1754) true)))))))
(check-sat)
; query 164: function gsm_L_asl, block 7, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1754 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x898 ((_ zero_extend 31) ?x1754)))
(let (($x127 (or false false false)))
(let (($x553 (or $x127 false)))
(let (($x2071 (not $x553)))
(and $x2071 (or $x553 (and (distinct ?x898 ?x898) true)))))))))
(check-sat)
; query 165: function gsm_L_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1312 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x127 (or false false false)))
(let (($x105 (not $x127)))
(and $x105 (or $x127 (and (distinct ?x1312 ?x1312) true)))))))
(check-sat)
; query 166: function gsm_L_asr, block 12, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x973 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x127 (or false false false)))
(let (($x105 (not $x127)))
(and $x105 (or $x127 (and (distinct ?x973 ?x973) true)))))))
(check-sat)
; query 167: function gsm_L_asr, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x1252 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in1_32))) true)))
(let (($x1270 (or false false (or $x1252))))
(and (not $x1270) (or $x1270 (and (distinct (bvsub (_ bv0 32) in1_32) (bvsub (_ bv0 32) in1_32)) true))))))
(check-sat)
; query 168: function gsm_L_asr, block 14, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1250 (bvsub (_ bv0 32) in1_32)))
(let ((?x1260 ((_ zero_extend 32) ?x1250)))
(let (($x1252 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x1250)) true)))
(let (($x1270 (or false false (or $x1252))))
(let (($x1172 (or $x1270 (or (= ((_ extract 31 31) ?x1250) (_ bv1 1))))))
(and (not (or $x1270 false)) (or $x1172 (and (distinct ?x1260 ?x1260) true)))))))))
(check-sat)
; query 169: function gsm_L_asr, block 14, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1250 (bvsub (_ bv0 32) in1_32)))
(let ((?x1260 ((_ zero_extend 32) ?x1250)))
(let ((?x1232 (bvshl in0_64 ?x1260)))
(let (($x1240 (bvuge ?x1260 (_ bv64 64))))
(let (($x1252 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x1250)) true)))
(let (($x1270 (or false false (or $x1252))))
(let (($x1172 (or $x1270 (or (= ((_ extract 31 31) ?x1250) (_ bv1 1))))))
(and (not (or (or false (or $x1270 false) false) $x1240)) (or (or (or false $x1172 false) $x1240) (and (distinct ?x1232 ?x1232) true)))))))))))
(check-sat)
; query 170: function gsm_L_asr, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x1759 (or false (or (= ((_ extract 31 31) in1_32) (_ bv1 1))))))
(let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x1759 (and (distinct ((_ zero_extend 32) in1_32) ((_ zero_extend 32) in1_32)) true)))))))
(check-sat)
; query 171: function gsm_L_asr, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1750 ((_ zero_extend 32) in1_32)))
(let ((?x1120 (bvashr in0_64 ?x1750)))
(let (($x1756 (bvuge ?x1750 (_ bv64 64))))
(let (($x1757 (or (or false (or false (or (= ((_ extract 31 31) in1_32) (_ bv1 1)))) false) $x1756)))
(let (($x1403 (not (or (or false (or false false) false) $x1756))))
(and $x1403 (or $x1757 (and (distinct ?x1120 ?x1120) true)))))))))
(check-sat)
; query 172: function gsm_L_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1754 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x127 (or false false false)))
(let (($x105 (not $x127)))
(and $x105 (or $x127 (and (distinct ?x1754 ?x1754) true)))))))
(check-sat)
; query 173: function gsm_L_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1754 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x898 ((_ zero_extend 31) ?x1754)))
(let (($x127 (or false false false)))
(let (($x553 (or $x127 false)))
(let (($x2071 (not $x553)))
(and $x2071 (or $x553 (and (distinct ?x898 ?x898) true)))))))))
(check-sat)
; query 174: function gsm_L_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1754 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x898 ((_ zero_extend 31) ?x1754)))
(let ((?x1770 (bvsub (_ bv0 32) ?x898)))
(let (($x1330 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x898)) ((_ sign_extend 1) ?x1770)) true)))
(let (($x127 (or false false false)))
(let (($x553 (or $x127 false)))
(let (($x1332 (or false $x553 (or $x1330))))
(and (not $x1332) (or $x1332 (and (distinct ?x1770 ?x1770) true)))))))))))
(check-sat)
; query 175: function gsm_L_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1754 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x898 ((_ zero_extend 31) ?x1754)))
(let ((?x1770 (bvsub (_ bv0 32) ?x898)))
(let ((?x1340 ((_ sign_extend 32) ?x1770)))
(let (($x1330 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x898)) ((_ sign_extend 1) ?x1770)) true)))
(let (($x127 (or false false false)))
(let (($x553 (or $x127 false)))
(let (($x1332 (or false $x553 (or $x1330))))
(let (($x1342 (or $x1332 false)))
(and (not $x1342) (or $x1342 (and (distinct ?x1340 ?x1340) true)))))))))))))
(check-sat)
; query 176: function gsm_L_asr, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1763 (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x127 (or false false false)))
(let (($x105 (not $x127)))
(and $x105 (or $x127 (and (distinct ?x1763 ?x1763) true)))))))
(check-sat)
; query 177: function gsm_L_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1312 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x127 (or false false false)))
(let (($x105 (not $x127)))
(and $x105 (or $x127 (and (distinct ?x1312 ?x1312) true)))))))
(check-sat)
; query 178: function gsm_L_mult, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x382 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 179: function gsm_L_mult, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x652 (ite (and (distinct (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) true) (_ bv1 1) (_ bv0 1))))
(let (($x382 (or false false)))
(let (($x851 (or $x382 false false)))
(let (($x97 (not $x851)))
(and $x97 (or $x851 (and (distinct ?x652 ?x652) true))))))))
(check-sat)
; query 180: function gsm_L_mult, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x382 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 181: function gsm_L_mult, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x569 (ite (and (distinct (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) true) (_ bv1 1) (_ bv0 1))))
(let (($x382 (or false false)))
(let (($x851 (or $x382 false false)))
(let (($x97 (not $x851)))
(and $x97 (or $x851 (and (distinct ?x569 ?x569) true))))))))
(check-sat)
; query 182: function gsm_L_sub, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in11_64 () (_ BitVec 64))
(assert
 (let (($x882 (and (distinct (bvadd ((_ zero_extend 1) in11_64) ((_ zero_extend 1) (_ bv1 64))) ((_ zero_extend 1) (bvadd in11_64 (_ bv1 64)))) true)))
(let (($x188 (and (distinct (bvadd ((_ sign_extend 1) in11_64) ((_ sign_extend 1) (_ bv1 64))) ((_ sign_extend 1) (bvadd in11_64 (_ bv1 64)))) true)))
(let (($x506 (or (or false false (or $x188 $x882)) (and (distinct (bvadd in11_64 (_ bv1 64)) (bvadd in11_64 (_ bv1 64))) true))))
(let (($x127 (or false false false)))
(let (($x105 (not $x127)))
(and $x105 $x506)))))))
(check-sat)
; query 183: function gsm_L_sub, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1628 (ite (bvsge (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x127 (or false false false)))
(let (($x105 (not $x127)))
(and $x105 (or $x127 (and (distinct ?x1628 ?x1628) true)))))))
(check-sat)
; query 184: function gsm_L_sub, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x118 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvsub in0_64 in1_64))) true)))
(let (($x425 (or false false (or $x118))))
(let (($x457 (or $x425 (and (distinct (bvsub in0_64 in1_64) (bvsub in0_64 in1_64)) true))))
(and (not $x425) $x457)))))
(check-sat)
; query 185: function gsm_L_sub, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1654 (bvadd in0_64 (_ bv1 64))))
(let ((?x1650 ((_ sign_extend 1) ?x1654)))
(let (($x1715 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1650) true)))))
(and (not $x1715) (or $x1715 (and (distinct ?x1654 ?x1654) true)))))))
(check-sat)
; query 186: function gsm_L_sub, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1654 (bvadd in0_64 (_ bv1 64))))
(let ((?x1657 (bvsub (_ bv0 64) ?x1654)))
(let (($x1659 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1654)) ((_ sign_extend 1) ?x1657)) true)))
(let ((?x1650 ((_ sign_extend 1) ?x1654)))
(let (($x1715 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1650) true)))))
(let (($x1663 (or false $x1715 (or $x1659))))
(and (not $x1663) (or $x1663 (and (distinct ?x1657 ?x1657) true))))))))))
(check-sat)
; query 187: function gsm_L_sub, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1654 (bvadd in0_64 (_ bv1 64))))
(let ((?x1657 (bvsub (_ bv0 64) ?x1654)))
(let ((?x575 (bvadd ?x1657 in1_64)))
(let (($x396 (and (distinct (bvadd ((_ zero_extend 1) ?x1657) ((_ zero_extend 1) in1_64)) ((_ zero_extend 1) ?x575)) true)))
(let (($x1659 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1654)) ((_ sign_extend 1) ?x1657)) true)))
(let ((?x1650 ((_ sign_extend 1) ?x1654)))
(let (($x1715 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1650) true)))))
(let (($x1663 (or false $x1715 (or $x1659))))
(let (($x224 (or $x1663 false (or $x396))))
(and (not (or $x1663 false false)) (or $x224 (and (distinct ?x575 ?x575) true)))))))))))))
(check-sat)
; query 188: function gsm_L_sub, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x563 (ite (bvuge (bvadd (bvsub (_ bv0 64) (bvadd in0_64 (_ bv1 64))) in1_64) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let ((?x1639 ((_ zero_extend 1) in1_64)))
(let ((?x1654 (bvadd in0_64 (_ bv1 64))))
(let ((?x1657 (bvsub (_ bv0 64) ?x1654)))
(let ((?x1717 ((_ zero_extend 1) ?x1657)))
(let (($x1659 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1654)) ((_ sign_extend 1) ?x1657)) true)))
(let ((?x1650 ((_ sign_extend 1) ?x1654)))
(let (($x1715 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x1650) true)))))
(let (($x1663 (or false $x1715 (or $x1659))))
(let (($x224 (or $x1663 false (or (and (distinct (bvadd ?x1717 ?x1639) ((_ zero_extend 1) (bvadd ?x1657 in1_64))) true)))))
(and (not (or (or $x1663 false false) false false)) (or (or $x224 false false) (and (distinct ?x563 ?x563) true))))))))))))))
(check-sat)
; query 189: function gsm_L_sub, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_64 () (_ BitVec 64))
(assert
 (let ((?x881 (bvsub (_ bv0 64) in25_64)))
(let ((?x774 ((_ sign_extend 1) ?x881)))
(let (($x446 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in25_64)) ?x774) true)))))
(and (not $x446) (or $x446 (and (distinct ?x881 ?x881) true)))))))
(check-sat)
; query 190: function gsm_L_sub, block 28, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_64 () (_ BitVec 64))
(assert
 (let ((?x881 (bvsub (_ bv0 64) in25_64)))
(let ((?x215 (bvsub ?x881 (_ bv1 64))))
(let (($x994 (and (distinct (bvsub ((_ zero_extend 1) ?x881) ((_ zero_extend 1) (_ bv1 64))) ((_ zero_extend 1) ?x215)) true)))
(let (($x449 (and (distinct (bvsub ((_ sign_extend 1) ?x881) ((_ sign_extend 1) (_ bv1 64))) ((_ sign_extend 1) ?x215)) true)))
(let ((?x774 ((_ sign_extend 1) ?x881)))
(let (($x446 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in25_64)) ?x774) true)))))
(and (not (or $x446 false (or $x449))) (or (or $x446 false (or $x449 $x994)) (and (distinct ?x215 ?x215) true))))))))))
(check-sat)
; query 191: function gsm_L_sub, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1656 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x127 (or false false false)))
(let (($x105 (not $x127)))
(and $x105 (or $x127 (and (distinct ?x1656 ?x1656) true)))))))
(check-sat)
; query 192: function gsm_L_sub, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x118 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvsub in0_64 in1_64))) true)))
(let (($x425 (or false false (or $x118))))
(let (($x457 (or $x425 (and (distinct (bvsub in0_64 in1_64) (bvsub in0_64 in1_64)) true))))
(and (not $x425) $x457)))))
(check-sat)
; query 193: function gsm_L_sub, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1666 (bvadd in1_64 (_ bv1 64))))
(let ((?x1664 (bvsub (_ bv0 64) ?x1666)))
(let (($x1662 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1666)) ((_ sign_extend 1) ?x1664)) true)))
(let ((?x1667 ((_ sign_extend 1) ?x1666)))
(let (($x1722 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1667) true)))))
(let (($x1665 (or false $x1722 (or $x1662))))
(and (not $x1665) (or $x1665 (and (distinct ?x1664 ?x1664) true))))))))))
(check-sat)
; query 194: function gsm_L_sub, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1666 (bvadd in1_64 (_ bv1 64))))
(let ((?x1664 (bvsub (_ bv0 64) ?x1666)))
(let ((?x826 (bvadd in0_64 ?x1664)))
(let (($x677 (and (distinct (bvadd ((_ zero_extend 1) in0_64) ((_ zero_extend 1) ?x1664)) ((_ zero_extend 1) ?x826)) true)))
(let (($x1662 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1666)) ((_ sign_extend 1) ?x1664)) true)))
(let ((?x1667 ((_ sign_extend 1) ?x1666)))
(let (($x1722 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1667) true)))))
(let (($x1665 (or false $x1722 (or $x1662))))
(let (($x698 (or false $x1665 (or $x677))))
(and (not (or false $x1665 false)) (or $x698 (and (distinct ?x826 ?x826) true)))))))))))))
(check-sat)
; query 195: function gsm_L_sub, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x604 (ite (bvuge (bvadd in0_64 (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64)))) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let ((?x1666 (bvadd in1_64 (_ bv1 64))))
(let ((?x1664 (bvsub (_ bv0 64) ?x1666)))
(let ((?x1723 ((_ zero_extend 1) ?x1664)))
(let ((?x900 ((_ zero_extend 1) in0_64)))
(let (($x1662 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1666)) ((_ sign_extend 1) ?x1664)) true)))
(let ((?x1667 ((_ sign_extend 1) ?x1666)))
(let (($x1722 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1667) true)))))
(let (($x1665 (or false $x1722 (or $x1662))))
(let (($x698 (or false $x1665 (or (and (distinct (bvadd ?x900 ?x1723) ((_ zero_extend 1) (bvadd in0_64 ?x1664))) true)))))
(and (not (or (or false $x1665 false) false false)) (or (or $x698 false false) (and (distinct ?x604 ?x604) true))))))))))))))
(check-sat)
; query 196: function gsm_L_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1666 (bvadd in1_64 (_ bv1 64))))
(let ((?x1667 ((_ sign_extend 1) ?x1666)))
(let (($x1722 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1667) true)))))
(and (not $x1722) (or $x1722 (and (distinct ?x1666 ?x1666) true)))))))
(check-sat)
; query 197: function gsm_L_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x943 (ite (bvsle (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x127 (or false false false)))
(let (($x105 (not $x127)))
(and $x105 (or $x127 (and (distinct ?x943 ?x943) true)))))))
(check-sat)
; query 198: function gsm_abs, block 13, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x382 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 199: function gsm_abs, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x382 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 200: function gsm_abs, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x536 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x382 (or false false)))
(let (($x851 (or $x382 false false)))
(let (($x97 (not $x851)))
(and $x97 (or $x851 (and (distinct ?x536 ?x536) true))))))))
(check-sat)
; query 201: function gsm_abs, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x9 ((_ sign_extend 16) in0_16)))
(let ((?x651 (bvsub (_ bv0 32) ?x9)))
(let (($x285 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x9)) ((_ sign_extend 1) ?x651)) true)))
(let (($x382 (or false false)))
(let (($x377 (or false $x382 (or $x285))))
(and (not $x377) (or $x377 (and (distinct ?x651 ?x651) true)))))))))
(check-sat)
; query 202: function gsm_abs, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x382 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 203: function gsm_abs, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x382 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 204: function gsm_abs, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x225 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x382 (or false false)))
(let (($x851 (or $x382 false false)))
(let (($x97 (not $x851)))
(and $x97 (or $x851 (and (distinct ?x225 ?x225) true))))))))
(check-sat)
; query 205: function gsm_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_64 () (_ BitVec 64))
(assert
 (let ((?x775 (ite (bvslt (_ bv32767 64) in5_64) (_ bv1 1) (_ bv0 1))))
(let (($x127 (or false false false)))
(let (($x105 (not $x127)))
(and $x105 (or $x127 (and (distinct ?x775 ?x775) true)))))))
(check-sat)
; query 206: function gsm_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x382 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 207: function gsm_add, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x382 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 208: function gsm_add, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1419 ((_ sign_extend 48) in1_16)))
(let ((?x1421 ((_ sign_extend 48) in0_16)))
(let ((?x1436 (bvadd ?x1421 ?x1419)))
(let (($x1424 (and (distinct (bvadd ((_ sign_extend 1) ?x1421) ((_ sign_extend 1) ?x1419)) ((_ sign_extend 1) ?x1436)) true)))
(let (($x382 (or false false)))
(let (($x1427 (or $x382 $x382 (or $x1424))))
(and (not $x1427) (or $x1427 (and (distinct ?x1436 ?x1436) true))))))))))
(check-sat)
; query 209: function gsm_add, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1426 (ite (bvsgt (_ bv18446744073709518848 64) (bvadd ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x1419 ((_ sign_extend 48) in1_16)))
(let ((?x1418 ((_ sign_extend 1) ?x1419)))
(let ((?x1421 ((_ sign_extend 48) in0_16)))
(let ((?x1429 ((_ sign_extend 1) ?x1421)))
(let (($x382 (or false false)))
(let (($x1427 (or $x382 $x382 (or (and (distinct (bvadd ?x1429 ?x1418) ((_ sign_extend 1) (bvadd ?x1421 ?x1419))) true)))))
(let (($x1428 (or $x1427 false false)))
(and (not $x1428) (or $x1428 (and (distinct ?x1426 ?x1426) true))))))))))))
(check-sat)
; query 210: function gsm_asl, block 13, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x973 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x127 (or false false false)))
(let (($x105 (not $x127)))
(and $x105 (or $x127 (and (distinct ?x973 ?x973) true)))))))
(check-sat)
; query 211: function gsm_asl, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x382 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 212: function gsm_asl, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x9 ((_ sign_extend 16) in0_16)))
(let ((?x1454 (bvshl ?x9 in1_32)))
(let (($x1448 (bvuge in1_32 (_ bv32 32))))
(let (($x382 (or false false)))
(let (($x1457 (or (or $x382 false (or (and (distinct (bvashr ?x1454 in1_32) ?x9) true))) $x1448)))
(let (($x851 (or $x382 false false)))
(let (($x1449 (or $x851 $x1448)))
(let (($x1463 (not $x1449)))
(and $x1463 (or $x1457 (and (distinct ?x1454 ?x1454) true))))))))))))
(check-sat)
; query 213: function gsm_asl, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x9 ((_ sign_extend 16) in0_16)))
(let ((?x1454 (bvshl ?x9 in1_32)))
(let ((?x1455 ((_ extract 15 0) ?x1454)))
(let (($x1448 (bvuge in1_32 (_ bv32 32))))
(let (($x382 (or false false)))
(let (($x1457 (or (or $x382 false (or (and (distinct (bvashr ?x1454 in1_32) ?x9) true))) $x1448)))
(let (($x1464 (not (or (or (or $x382 false false) $x1448) false))))
(and $x1464 (or (or $x1457 false) (and (distinct ?x1455 ?x1455) true)))))))))))
(check-sat)
; query 214: function gsm_asl, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1468 (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x127 (or false false false)))
(let (($x105 (not $x127)))
(and $x105 (or $x127 (and (distinct ?x1468 ?x1468) true)))))))
(check-sat)
; query 215: function gsm_asl, block 7, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x225 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1782 ((_ zero_extend 31) ?x225)))
(let (($x382 (or false false)))
(let (($x851 (or $x382 false false)))
(let (($x1474 (or $x851 false)))
(and (not $x1474) (or $x1474 (and (distinct ?x1782 ?x1782) true)))))))))
(check-sat)
; query 216: function gsm_asl, block 7, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x225 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1782 ((_ zero_extend 31) ?x225)))
(let ((?x1475 (bvsub (_ bv0 32) ?x1782)))
(let (($x1466 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1782)) ((_ sign_extend 1) ?x1475)) true)))
(let (($x382 (or false false)))
(let (($x851 (or $x382 false false)))
(let (($x1474 (or $x851 false)))
(let (($x729 (or false $x1474 (or $x1466))))
(and (not $x729) (or $x729 (and (distinct ?x1475 ?x1475) true))))))))))))
(check-sat)
; query 217: function gsm_asl, block 7, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x225 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1782 ((_ zero_extend 31) ?x225)))
(let ((?x1475 (bvsub (_ bv0 32) ?x1782)))
(let ((?x2094 ((_ extract 15 0) ?x1475)))
(let (($x1466 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1782)) ((_ sign_extend 1) ?x1475)) true)))
(let (($x382 (or false false)))
(let (($x851 (or $x382 false false)))
(let (($x1474 (or $x851 false)))
(let (($x729 (or false $x1474 (or $x1466))))
(let (($x508 (or (or $x729 (or (and (distinct ((_ sign_extend 16) ?x2094) ?x1475) true))) (and (distinct ?x2094 ?x2094) true))))
(and (not (or $x729 false)) $x508))))))))))))
(check-sat)
; query 218: function gsm_asl, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x382 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 219: function gsm_asl, block 7, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x225 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x382 (or false false)))
(let (($x851 (or $x382 false false)))
(let (($x97 (not $x851)))
(and $x97 (or $x851 (and (distinct ?x225 ?x225) true))))))))
(check-sat)
; query 220: function gsm_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x720 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x127 (or false false false)))
(let (($x105 (not $x127)))
(and $x105 (or $x127 (and (distinct ?x720 ?x720) true)))))))
(check-sat)
; query 221: function gsm_asr, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1468 (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x127 (or false false false)))
(let (($x105 (not $x127)))
(and $x105 (or $x127 (and (distinct ?x1468 ?x1468) true)))))))
(check-sat)
; query 222: function gsm_asr, block 13, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x973 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x127 (or false false false)))
(let (($x105 (not $x127)))
(and $x105 (or $x127 (and (distinct ?x973 ?x973) true)))))))
(check-sat)
; query 223: function gsm_asr, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x382 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 224: function gsm_asr, block 15, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x1252 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in1_32))) true)))
(let (($x1270 (or false false (or $x1252))))
(and (not $x1270) (or $x1270 (and (distinct (bvsub (_ bv0 32) in1_32) (bvsub (_ bv0 32) in1_32)) true))))))
(check-sat)
; query 225: function gsm_asr, block 15, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1250 (bvsub (_ bv0 32) in1_32)))
(let ((?x9 ((_ sign_extend 16) in0_16)))
(let ((?x661 (bvshl ?x9 ?x1250)))
(let (($x247 (bvuge ?x1250 (_ bv32 32))))
(let (($x1252 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x1250)) true)))
(let (($x1270 (or false false (or $x1252))))
(let (($x382 (or false false)))
(let (($x571 (or (or $x382 $x1270 (or (and (distinct (bvashr ?x661 ?x1250) ?x9) true))) $x247)))
(and (not (or (or $x382 $x1270 false) $x247)) (or $x571 (and (distinct ?x661 ?x661) true))))))))))))
(check-sat)
; query 226: function gsm_asr, block 15, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1250 (bvsub (_ bv0 32) in1_32)))
(let ((?x9 ((_ sign_extend 16) in0_16)))
(let ((?x661 (bvshl ?x9 ?x1250)))
(let ((?x637 ((_ extract 15 0) ?x661)))
(let (($x247 (bvuge ?x1250 (_ bv32 32))))
(let (($x1252 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x1250)) true)))
(let (($x1270 (or false false (or $x1252))))
(let (($x382 (or false false)))
(let (($x571 (or (or $x382 $x1270 (or (and (distinct (bvashr ?x661 ?x1250) ?x9) true))) $x247)))
(and (not (or (or (or $x382 $x1270 false) $x247) false)) (or (or $x571 false) (and (distinct ?x637 ?x637) true)))))))))))))
(check-sat)
; query 227: function gsm_asr, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x382 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 228: function gsm_asr, block 20, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x9 ((_ sign_extend 16) in0_16)))
(let ((?x494 (bvashr ?x9 in1_32)))
(let (($x1448 (bvuge in1_32 (_ bv32 32))))
(let (($x382 (or false false)))
(let (($x851 (or $x382 false false)))
(let (($x1449 (or $x851 $x1448)))
(let (($x1463 (not $x1449)))
(and $x1463 (or $x1449 (and (distinct ?x494 ?x494) true)))))))))))
(check-sat)
; query 229: function gsm_asr, block 20, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x9 ((_ sign_extend 16) in0_16)))
(let ((?x494 (bvashr ?x9 in1_32)))
(let ((?x588 ((_ extract 15 0) ?x494)))
(let (($x1448 (bvuge in1_32 (_ bv32 32))))
(let (($x382 (or false false)))
(let (($x851 (or $x382 false false)))
(let (($x1449 (or $x851 $x1448)))
(let (($x903 (or (or $x1449 (or (and (distinct ((_ sign_extend 16) ?x588) ?x494) true))) (and (distinct ?x588 ?x588) true))))
(let (($x1464 (not (or $x1449 false))))
(and $x1464 $x903)))))))))))
(check-sat)
; query 230: function gsm_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x382 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 231: function gsm_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x225 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x382 (or false false)))
(let (($x851 (or $x382 false false)))
(let (($x97 (not $x851)))
(and $x97 (or $x851 (and (distinct ?x225 ?x225) true))))))))
(check-sat)
; query 232: function gsm_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x225 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1782 ((_ zero_extend 31) ?x225)))
(let (($x382 (or false false)))
(let (($x851 (or $x382 false false)))
(let (($x1474 (or $x851 false)))
(and (not $x1474) (or $x1474 (and (distinct ?x1782 ?x1782) true)))))))))
(check-sat)
; query 233: function gsm_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x225 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1782 ((_ zero_extend 31) ?x225)))
(let ((?x1475 (bvsub (_ bv0 32) ?x1782)))
(let (($x1466 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1782)) ((_ sign_extend 1) ?x1475)) true)))
(let (($x382 (or false false)))
(let (($x851 (or $x382 false false)))
(let (($x1474 (or $x851 false)))
(let (($x729 (or false $x1474 (or $x1466))))
(and (not $x729) (or $x729 (and (distinct ?x1475 ?x1475) true))))))))))))
(check-sat)
; query 234: function gsm_asr, block 4, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x225 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1782 ((_ zero_extend 31) ?x225)))
(let ((?x1475 (bvsub (_ bv0 32) ?x1782)))
(let ((?x2094 ((_ extract 15 0) ?x1475)))
(let (($x1466 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1782)) ((_ sign_extend 1) ?x1475)) true)))
(let (($x382 (or false false)))
(let (($x851 (or $x382 false false)))
(let (($x1474 (or $x851 false)))
(let (($x729 (or false $x1474 (or $x1466))))
(let (($x508 (or (or $x729 (or (and (distinct ((_ sign_extend 16) ?x2094) ?x1475) true))) (and (distinct ?x2094 ?x2094) true))))
(and (not (or $x729 false)) $x508))))))))))))
(check-sat)
; query 235: function gsm_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x720 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x127 (or false false false)))
(let (($x105 (not $x127)))
(and $x105 (or $x127 (and (distinct ?x720 ?x720) true)))))))
(check-sat)
; query 236: function gsm_debug_longwords, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in15_32 () (_ BitVec 32))
(assert
 (let ((?x848 (ite (bvslt in15_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x127 (or false false false)))
(let (($x105 (not $x127)))
(and $x105 (or $x127 (and (distinct ?x848 ?x848) true)))))))
(check-sat)
; query 237: function gsm_debug_words, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in16_32 () (_ BitVec 32))
(assert
 (let ((?x1031 (ite (bvslt in16_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x127 (or false false false)))
(let (($x105 (not $x127)))
(and $x105 (or $x127 (and (distinct ?x1031 ?x1031) true)))))))
(check-sat)
; query 238: function gsm_div, block 7, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x858 (ite (bvsge ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x382 (or false false)))
(let (($x721 (or $x382 $x382 false)))
(and (not $x721) (or $x721 (and (distinct ?x858 ?x858) true)))))))
(check-sat)
; query 239: function gsm_div, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x382 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 240: function gsm_div, block 7, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x382 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 241: function gsm_div, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x382 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 242: function gsm_div, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x382 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 243: function gsm_div, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x382 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 244: function gsm_div, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x2048 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x2057 (and (distinct ?x2048 ?x2048) true)))
(let (($x382 (or false false)))
(let (($x851 (or $x382 false false)))
(let (($x97 (not $x851)))
(and $x97 (or $x851 $x2057))))))))
(check-sat)
; query 245: function gsm_mult, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x382 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 246: function gsm_mult, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x997 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x382 (or false false)))
(let (($x851 (or $x382 false false)))
(let (($x97 (not $x851)))
(and $x97 (or $x851 (and (distinct ?x997 ?x997) true))))))))
(check-sat)
; query 247: function gsm_mult, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x382 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 248: function gsm_mult, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x382 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 249: function gsm_mult, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1419 ((_ sign_extend 48) in1_16)))
(let ((?x1421 ((_ sign_extend 48) in0_16)))
(let ((?x942 (bvmul ?x1421 ?x1419)))
(let (($x1087 (and (distinct (bvmul ((_ sign_extend 64) ?x1421) ((_ sign_extend 64) ?x1419)) ((_ sign_extend 64) ?x942)) true)))
(let (($x382 (or false false)))
(let (($x686 (or $x382 $x382 (or $x1087))))
(and (not $x686) (or $x686 (and (distinct ?x942 ?x942) true))))))))))
(check-sat)
; query 250: function gsm_mult, block 9, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1419 ((_ sign_extend 48) in1_16)))
(let ((?x1421 ((_ sign_extend 48) in0_16)))
(let ((?x942 (bvmul ?x1421 ?x1419)))
(let ((?x822 (bvashr ?x942 (_ bv15 64))))
(let (($x1490 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1087 (and (distinct (bvmul ((_ sign_extend 64) ?x1421) ((_ sign_extend 64) ?x1419)) ((_ sign_extend 64) ?x942)) true)))
(let (($x382 (or false false)))
(let (($x686 (or $x382 $x382 (or $x1087))))
(let (($x1035 (or (or $x686 false false) $x1490)))
(and (not $x1035) (or $x1035 (and (distinct ?x822 ?x822) true)))))))))))))
(check-sat)
; query 251: function gsm_mult, block 9, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1419 ((_ sign_extend 48) in1_16)))
(let ((?x1421 ((_ sign_extend 48) in0_16)))
(let ((?x942 (bvmul ?x1421 ?x1419)))
(let ((?x822 (bvashr ?x942 (_ bv15 64))))
(let ((?x969 ((_ extract 15 0) ?x822)))
(let (($x1490 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1087 (and (distinct (bvmul ((_ sign_extend 64) ?x1421) ((_ sign_extend 64) ?x1419)) ((_ sign_extend 64) ?x942)) true)))
(let (($x382 (or false false)))
(let (($x686 (or $x382 $x382 (or $x1087))))
(let (($x1035 (or (or $x686 false false) $x1490)))
(let (($x818 (or $x1035 false)))
(and (not $x818) (or $x818 (and (distinct ?x969 ?x969) true)))))))))))))))
(check-sat)
; query 252: function gsm_mult, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x382 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 253: function gsm_mult, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x536 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x382 (or false false)))
(let (($x851 (or $x382 false false)))
(let (($x97 (not $x851)))
(and $x97 (or $x851 (and (distinct ?x536 ?x536) true))))))))
(check-sat)
; query 254: function gsm_mult_r, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x382 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 255: function gsm_mult_r, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x536 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x382 (or false false)))
(let (($x851 (or $x382 false false)))
(let (($x97 (not $x851)))
(and $x97 (or $x851 (and (distinct ?x536 ?x536) true))))))))
(check-sat)
; query 256: function gsm_mult_r, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x382 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 257: function gsm_mult_r, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x382 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 258: function gsm_mult_r, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1419 ((_ sign_extend 48) in1_16)))
(let ((?x1421 ((_ sign_extend 48) in0_16)))
(let ((?x942 (bvmul ?x1421 ?x1419)))
(let (($x1087 (and (distinct (bvmul ((_ sign_extend 64) ?x1421) ((_ sign_extend 64) ?x1419)) ((_ sign_extend 64) ?x942)) true)))
(let (($x382 (or false false)))
(let (($x686 (or $x382 $x382 (or $x1087))))
(and (not $x686) (or $x686 (and (distinct ?x942 ?x942) true))))))))))
(check-sat)
; query 259: function gsm_mult_r, block 9, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1419 ((_ sign_extend 48) in1_16)))
(let ((?x1421 ((_ sign_extend 48) in0_16)))
(let ((?x942 (bvmul ?x1421 ?x1419)))
(let ((?x711 (bvadd ?x942 (_ bv16384 64))))
(let (($x814 (and (distinct (bvadd ((_ sign_extend 1) ?x942) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x711)) true)))
(let (($x1087 (and (distinct (bvmul ((_ sign_extend 64) ?x1421) ((_ sign_extend 64) ?x1419)) ((_ sign_extend 64) ?x942)) true)))
(let (($x382 (or false false)))
(let (($x686 (or $x382 $x382 (or $x1087))))
(let (($x688 (or $x686 false (or $x814))))
(and (not $x688) (or $x688 (and (distinct ?x711 ?x711) true)))))))))))))
(check-sat)
; query 260: function gsm_mult_r, block 9, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1419 ((_ sign_extend 48) in1_16)))
(let ((?x1421 ((_ sign_extend 48) in0_16)))
(let ((?x942 (bvmul ?x1421 ?x1419)))
(let ((?x711 (bvadd ?x942 (_ bv16384 64))))
(let ((?x907 (bvashr ?x711 (_ bv15 64))))
(let (($x1490 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x814 (and (distinct (bvadd ((_ sign_extend 1) ?x942) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x711)) true)))
(let (($x1087 (and (distinct (bvmul ((_ sign_extend 64) ?x1421) ((_ sign_extend 64) ?x1419)) ((_ sign_extend 64) ?x942)) true)))
(let (($x382 (or false false)))
(let (($x686 (or $x382 $x382 (or $x1087))))
(let (($x688 (or $x686 false (or $x814))))
(let (($x937 (or (or $x688 false false) $x1490)))
(and (not $x937) (or $x937 (and (distinct ?x907 ?x907) true))))))))))))))))
(check-sat)
; query 261: function gsm_mult_r, block 9, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1419 ((_ sign_extend 48) in1_16)))
(let ((?x1421 ((_ sign_extend 48) in0_16)))
(let ((?x942 (bvmul ?x1421 ?x1419)))
(let ((?x711 (bvadd ?x942 (_ bv16384 64))))
(let ((?x907 (bvashr ?x711 (_ bv15 64))))
(let ((?x897 (bvand ?x907 (_ bv65535 64))))
(let (($x1490 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x814 (and (distinct (bvadd ((_ sign_extend 1) ?x942) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x711)) true)))
(let (($x1087 (and (distinct (bvmul ((_ sign_extend 64) ?x1421) ((_ sign_extend 64) ?x1419)) ((_ sign_extend 64) ?x942)) true)))
(let (($x382 (or false false)))
(let (($x686 (or $x382 $x382 (or $x1087))))
(let (($x688 (or $x686 false (or $x814))))
(let (($x937 (or (or $x688 false false) $x1490)))
(let (($x795 (or $x937 false false)))
(and (not $x795) (or $x795 (and (distinct ?x897 ?x897) true))))))))))))))))))
(check-sat)
; query 262: function gsm_mult_r, block 9, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1419 ((_ sign_extend 48) in1_16)))
(let ((?x1421 ((_ sign_extend 48) in0_16)))
(let ((?x942 (bvmul ?x1421 ?x1419)))
(let ((?x711 (bvadd ?x942 (_ bv16384 64))))
(let ((?x907 (bvashr ?x711 (_ bv15 64))))
(let ((?x897 (bvand ?x907 (_ bv65535 64))))
(let ((?x953 ((_ extract 15 0) ?x897)))
(let (($x1490 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x814 (and (distinct (bvadd ((_ sign_extend 1) ?x942) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x711)) true)))
(let (($x1087 (and (distinct (bvmul ((_ sign_extend 64) ?x1421) ((_ sign_extend 64) ?x1419)) ((_ sign_extend 64) ?x942)) true)))
(let (($x382 (or false false)))
(let (($x686 (or $x382 $x382 (or $x1087))))
(let (($x688 (or $x686 false (or $x814))))
(let (($x937 (or (or $x688 false false) $x1490)))
(let (($x795 (or $x937 false false)))
(let (($x790 (or (or $x795 (or (and (distinct ((_ zero_extend 48) ?x953) ?x897) true))) (and (distinct ?x953 ?x953) true))))
(and (not (or $x795 false)) $x790))))))))))))))))))
(check-sat)
; query 263: function gsm_mult_r, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x382 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 264: function gsm_mult_r, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x997 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x382 (or false false)))
(let (($x851 (or $x382 false false)))
(let (($x97 (not $x851)))
(and $x97 (or $x851 (and (distinct ?x997 ?x997) true))))))))
(check-sat)
; query 265: function gsm_norm, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1041 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x127 (or false false false)))
(let (($x105 (not $x127)))
(and $x105 (or $x127 (and (distinct ?x1041 ?x1041) true)))))))
(check-sat)
; query 266: function gsm_norm, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1041 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x672 (bvxor ?x1041 (_ bv1 1))))
(let (($x127 (or false false false)))
(let (($x1645 (or $x127 false false)))
(let (($x1708 (not $x1645)))
(and $x1708 (or $x1645 (and (distinct ?x672 ?x672) true)))))))))
(check-sat)
; query 267: function gsm_norm, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1041 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x672 (bvxor ?x1041 (_ bv1 1))))
(let ((?x970 ((_ zero_extend 31) ?x672)))
(let (($x127 (or false false false)))
(let (($x1645 (or $x127 false false)))
(let (($x1109 (or $x1645 false)))
(and (not $x1109) (or $x1109 (and (distinct ?x970 ?x970) true))))))))))
(check-sat)
; query 268: function gsm_norm, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1041 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x672 (bvxor ?x1041 (_ bv1 1))))
(let ((?x970 ((_ zero_extend 31) ?x672)))
(let ((?x995 ((_ zero_extend 32) ?x970)))
(let ((?x1024 ((_ sign_extend 32) ?x970)))
(let (($x127 (or false false false)))
(let (($x1645 (or $x127 false false)))
(let (($x1109 (or $x1645 false)))
(let (($x1015 (or $x1109 (or (= ((_ extract 31 31) ?x970) (_ bv1 1))))))
(and (not (or $x1109 false)) (or $x1015 (and (distinct ?x1024 ?x995) true)))))))))))))
(check-sat)
; query 269: function gsm_norm, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1041 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x672 (bvxor ?x1041 (_ bv1 1))))
(let ((?x970 ((_ zero_extend 31) ?x672)))
(let ((?x995 ((_ zero_extend 32) ?x970)))
(let (($x699 (and (distinct (ite (and (distinct (_ bv0 64) ((_ sign_extend 32) ?x970)) true) (_ bv1 1) (_ bv0 1)) (ite (and (distinct (_ bv0 64) ?x995) true) (_ bv1 1) (_ bv0 1))) true)))
(let (($x127 (or false false false)))
(let (($x1645 (or $x127 false false)))
(let (($x1109 (or $x1645 false)))
(let (($x1015 (or $x1109 (or (= ((_ extract 31 31) ?x970) (_ bv1 1))))))
(and (not (or (or $x1109 false) false false)) (or (or $x1015 false false) $x699))))))))))))
(check-sat)
; query 270: function gsm_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_64 () (_ BitVec 64))
(assert
 (let ((?x775 (ite (bvslt (_ bv32767 64) in5_64) (_ bv1 1) (_ bv0 1))))
(let (($x127 (or false false false)))
(let (($x105 (not $x127)))
(and $x105 (or $x127 (and (distinct ?x775 ?x775) true)))))))
(check-sat)
; query 271: function gsm_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x382 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 272: function gsm_sub, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x382 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 273: function gsm_sub, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1419 ((_ sign_extend 48) in1_16)))
(let ((?x1421 ((_ sign_extend 48) in0_16)))
(let ((?x803 (bvsub ?x1421 ?x1419)))
(let (($x805 (and (distinct (bvsub ((_ sign_extend 1) ?x1421) ((_ sign_extend 1) ?x1419)) ((_ sign_extend 1) ?x803)) true)))
(let (($x382 (or false false)))
(let (($x1044 (or $x382 $x382 (or $x805))))
(and (not $x1044) (or $x1044 (and (distinct ?x803 ?x803) true))))))))))
(check-sat)
; query 274: function gsm_sub, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1062 (ite (bvsgt (_ bv18446744073709518848 64) (bvsub ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x1419 ((_ sign_extend 48) in1_16)))
(let ((?x1418 ((_ sign_extend 1) ?x1419)))
(let ((?x1421 ((_ sign_extend 48) in0_16)))
(let ((?x1429 ((_ sign_extend 1) ?x1421)))
(let (($x382 (or false false)))
(let (($x1044 (or $x382 $x382 (or (and (distinct (bvsub ?x1429 ?x1418) ((_ sign_extend 1) (bvsub ?x1421 ?x1419))) true)))))
(let (($x1102 (or $x1044 false false)))
(and (not $x1102) (or $x1102 (and (distinct ?x1062 ?x1062) true))))))))))))
(check-sat)
; query 275: function ok_to_replace, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1100 (ite (and (distinct (_ bv4294967295 32) in.01_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x127 (or false false false)))
(let (($x105 (not $x127)))
(and $x105 (or $x127 (and (distinct ?x1100 ?x1100) true)))))))
(check-sat)
; query 276: function ok_to_replace, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in16_32 () (_ BitVec 32))
(assert
 (let ((?x1101 (ite (= (_ bv121 32) in16_32) (_ bv1 1) (_ bv0 1))))
(let (($x127 (or false false false)))
(let (($x105 (not $x127)))
(and $x105 (or $x127 (and (distinct ?x1101 ?x1101) true)))))))
(check-sat)
; query 277: function process_decode, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let (($x1098 (or false (or (= ((_ extract 31 31) in14_32) (_ bv1 1))))))
(let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x1098 (and (distinct ((_ sign_extend 32) in14_32) ((_ zero_extend 32) in14_32)) true)))))))
(check-sat)
; query 278: function process_decode, block 16, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let (($x801 (and (distinct (ite (and (distinct (_ bv33 64) ((_ sign_extend 32) in14_32)) true) (_ bv1 1) (_ bv0 1)) (ite (and (distinct (_ bv33 64) ((_ zero_extend 32) in14_32)) true) (_ bv1 1) (_ bv0 1))) true)))
(let (($x758 (or (or (or false (or (= ((_ extract 31 31) in14_32) (_ bv1 1)))) false false) $x801)))
(let (($x382 (or false false)))
(let (($x851 (or $x382 false false)))
(let (($x97 (not $x851)))
(and $x97 $x758)))))))
(check-sat)
; query 279: function process_encode, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_32 () (_ BitVec 32))
(assert
 (let (($x980 (or false (or (= ((_ extract 31 31) in13_32) (_ bv1 1))))))
(let (($x382 (or false false)))
(let (($x908 (not $x382)))
(and $x908 (or $x980 (and (distinct ((_ sign_extend 32) in13_32) ((_ zero_extend 32) in13_32)) true)))))))
(check-sat)
; query 280: function process_encode, block 15, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_32 () (_ BitVec 32))
(assert
 (let (($x1053 (and (distinct (ite (bvult ((_ sign_extend 32) in13_32) (_ bv160 64)) (_ bv1 1) (_ bv0 1)) (ite (bvult ((_ zero_extend 32) in13_32) (_ bv160 64)) (_ bv1 1) (_ bv0 1))) true)))
(let (($x1106 (or (or (or false (or (= ((_ extract 31 31) in13_32) (_ bv1 1)))) false false) $x1053)))
(let (($x382 (or false false)))
(let (($x851 (or $x382 false false)))
(let (($x97 (not $x851)))
(and $x97 $x1106)))))))
(check-sat)
; query 281: function process_encode, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_32 () (_ BitVec 32))
(assert
 (let ((?x976 (ite (bvsgt (_ bv0 32) in13_32) (_ bv1 1) (_ bv0 1))))
(let (($x127 (or false false false)))
(let (($x105 (not $x127)))
(and $x105 (or $x127 (and (distinct ?x976 ?x976) true)))))))
(check-sat)
; query 282: function suffix, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_64 () (_ BitVec 64))
(declare-fun in3_64 () (_ BitVec 64))
(assert
 (let ((?x1059 (ite (bvule in3_64 in4_64) (_ bv1 1) (_ bv0 1))))
(let (($x127 (or false false false)))
(let (($x105 (not $x127)))
(and $x105 (or $x127 (and (distinct ?x1059 ?x1059) true)))))))
(check-sat)
; query 283: function ulaw_input, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x1099 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x1675 (or false false (or $x1099))))
(and (not $x1675) (or $x1675 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 284: function ulaw_input, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let ((?x1620 (ite (= (_ bv4294967295 32) in.1_32) (_ bv1 1) (_ bv0 1))))
(let (($x127 (or false false false)))
(let (($x105 (not $x127)))
(and $x105 (or $x127 (and (distinct ?x1620 ?x1620) true)))))))
(check-sat)
