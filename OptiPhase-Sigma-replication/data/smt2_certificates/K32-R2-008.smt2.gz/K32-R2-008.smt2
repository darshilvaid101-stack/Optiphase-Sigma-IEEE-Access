; OptiPhase-Sigma refinement certificate for sweep K32-R2-008
