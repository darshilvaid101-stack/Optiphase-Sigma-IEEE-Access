; OptiPhase-Sigma refinement certificate for sweep K41-R2-024
; query 0: function decfile, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in17_32 () (_ BitVec 32))
(assert
 (let ((?x60 (ite (and (distinct (_ bv16 32) in17_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x14 (or false false false)))
(let (($x152 (not $x14)))
(and $x152 (or $x14 (and (distinct ?x60 ?x60) true)))))))
(check-sat)
; query 1: function decfile, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x103 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x34 (or false false (or $x103))))
(and (not $x34) (or $x34 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function decfile, block 82, name %83
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x169 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x44 (or false false (or $x169))))
(and (not $x44) (or $x44 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 3: function encfile, block 50, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_64 () (_ BitVec 64))
(assert
 (let (($x14 (or false false false)))
(let (($x152 (not $x14)))
(and $x152 (or $x14 (and (distinct (bvadd in.1_64 (_ bv1 64)) (bvadd in.1_64 (_ bv1 64))) true))))))
(check-sat)
; query 4: function encfile, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_64 () (_ BitVec 64))
(assert
 (let (($x14 (or false false false)))
(let (($x152 (not $x14)))
(and $x152 (or $x14 (and (distinct (bvadd in.2_64 (_ bv1 64)) (bvadd in.2_64 (_ bv1 64))) true))))))
(check-sat)
; query 5: function encfile, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.5_64 () (_ BitVec 64))
(assert
 (let (($x14 (or false false false)))
(let (($x152 (not $x14)))
(and $x152 (or $x14 (and (distinct (bvadd in.5_64 (_ bv1 64)) (bvadd in.5_64 (_ bv1 64))) true))))))
(check-sat)
; query 6: function fillrand, block 34, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x162 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x65 (or false false (or $x162))))
(and (not $x65) (or $x65 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 7: function main, block 41, name %42
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let (($x900 (or false false)))
(and (not $x900) (or $x900 (and (distinct ((_ sign_extend 24) in38_8) ((_ sign_extend 24) in38_8)) true)))))
(check-sat)
; query 8: function main, block 41, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let ((?x15 (ite (bvsge (_ bv57 32) ((_ sign_extend 24) in38_8)) (_ bv1 1) (_ bv0 1))))
(let (($x900 (or false false)))
(let (($x200 (or $x900 false false)))
(let (($x297 (not $x200)))
(and $x297 (or $x200 (and (distinct ?x15 ?x15) true))))))))
(check-sat)
; query 9: function main, block 44, name %45
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x14 (or false false false)))
(let (($x113 (or $x14 (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x113) (or $x113 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvshl in.01_32 (_ bv4 32))) true))))))
(check-sat)
; query 10: function main, block 44, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let (($x900 (or false false)))
(and (not $x900) (or $x900 (and (distinct ((_ sign_extend 24) in38_8) ((_ sign_extend 24) in38_8)) true)))))
(check-sat)
; query 11: function main, block 44, name %47
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x33 ((_ sign_extend 24) in38_8)))
(let ((?x108 (bvshl in.01_32 (_ bv4 32))))
(let ((?x57 (bvadd ?x108 ?x33)))
(let ((?x175 ((_ sign_extend 1) ?x57)))
(let (($x900 (or false false)))
(let (($x14 (or false false false)))
(let (($x113 (or $x14 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x129 (or $x113 $x900 (or (and (distinct (bvadd ((_ sign_extend 1) ?x108) ((_ sign_extend 1) ?x33)) ?x175) true)))))
(and (not $x129) (or $x129 (and (distinct ?x57 ?x57) true))))))))))))
(check-sat)
; query 12: function main, block 44, name %48
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x33 ((_ sign_extend 24) in38_8)))
(let ((?x108 (bvshl in.01_32 (_ bv4 32))))
(let ((?x57 (bvadd ?x108 ?x33)))
(let ((?x142 (bvsub ?x57 (_ bv48 32))))
(let (($x155 (and (distinct (bvsub ((_ sign_extend 1) ?x57) ((_ sign_extend 1) (_ bv48 32))) ((_ sign_extend 1) ?x142)) true)))
(let ((?x175 ((_ sign_extend 1) ?x57)))
(let (($x900 (or false false)))
(let (($x14 (or false false false)))
(let (($x113 (or $x14 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x129 (or $x113 $x900 (or (and (distinct (bvadd ((_ sign_extend 1) ?x108) ((_ sign_extend 1) ?x33)) ?x175) true)))))
(let (($x11 (or $x129 false (or $x155))))
(and (not $x11) (or $x11 (and (distinct ?x142 ?x142) true)))))))))))))))
(check-sat)
; query 13: function main, block 49, name %50
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let (($x900 (or false false)))
(and (not $x900) (or $x900 (and (distinct ((_ sign_extend 24) in38_8) ((_ sign_extend 24) in38_8)) true)))))
(check-sat)
; query 14: function main, block 49, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let ((?x112 (ite (bvsle (_ bv65 32) ((_ sign_extend 24) in38_8)) (_ bv1 1) (_ bv0 1))))
(let (($x900 (or false false)))
(let (($x200 (or $x900 false false)))
(let (($x297 (not $x200)))
(and $x297 (or $x200 (and (distinct ?x112 ?x112) true))))))))
(check-sat)
; query 15: function main, block 52, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let (($x900 (or false false)))
(and (not $x900) (or $x900 (and (distinct ((_ sign_extend 24) in38_8) ((_ sign_extend 24) in38_8)) true)))))
(check-sat)
; query 16: function main, block 52, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let ((?x140 (ite (bvsge (_ bv70 32) ((_ sign_extend 24) in38_8)) (_ bv1 1) (_ bv0 1))))
(let (($x900 (or false false)))
(let (($x200 (or $x900 false false)))
(let (($x297 (not $x200)))
(and $x297 (or $x200 (and (distinct ?x140 ?x140) true))))))))
(check-sat)
; query 17: function main, block 55, name %56
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x14 (or false false false)))
(let (($x113 (or $x14 (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x113) (or $x113 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvshl in.01_32 (_ bv4 32))) true))))))
(check-sat)
; query 18: function main, block 55, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let (($x900 (or false false)))
(and (not $x900) (or $x900 (and (distinct ((_ sign_extend 24) in38_8) ((_ sign_extend 24) in38_8)) true)))))
(check-sat)
; query 19: function main, block 55, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x33 ((_ sign_extend 24) in38_8)))
(let ((?x108 (bvshl in.01_32 (_ bv4 32))))
(let ((?x57 (bvadd ?x108 ?x33)))
(let ((?x175 ((_ sign_extend 1) ?x57)))
(let (($x900 (or false false)))
(let (($x14 (or false false false)))
(let (($x113 (or $x14 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x129 (or $x113 $x900 (or (and (distinct (bvadd ((_ sign_extend 1) ?x108) ((_ sign_extend 1) ?x33)) ?x175) true)))))
(and (not $x129) (or $x129 (and (distinct ?x57 ?x57) true))))))))))))
(check-sat)
; query 20: function main, block 55, name %59
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x33 ((_ sign_extend 24) in38_8)))
(let ((?x108 (bvshl in.01_32 (_ bv4 32))))
(let ((?x57 (bvadd ?x108 ?x33)))
(let ((?x134 (bvsub ?x57 (_ bv65 32))))
(let ((?x50 ((_ sign_extend 1) ?x134)))
(let ((?x175 ((_ sign_extend 1) ?x57)))
(let (($x900 (or false false)))
(let (($x14 (or false false false)))
(let (($x113 (or $x14 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x129 (or $x113 $x900 (or (and (distinct (bvadd ((_ sign_extend 1) ?x108) ((_ sign_extend 1) ?x33)) ?x175) true)))))
(let (($x173 (or $x129 false (or (and (distinct (bvsub ?x175 ((_ sign_extend 1) (_ bv65 32))) ?x50) true)))))
(and (not $x173) (or $x173 (and (distinct ?x134 ?x134) true)))))))))))))))
(check-sat)
; query 21: function main, block 55, name %60
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x33 ((_ sign_extend 24) in38_8)))
(let ((?x108 (bvshl in.01_32 (_ bv4 32))))
(let ((?x57 (bvadd ?x108 ?x33)))
(let ((?x134 (bvsub ?x57 (_ bv65 32))))
(let ((?x97 (bvadd ?x134 (_ bv10 32))))
(let (($x146 (and (distinct (bvadd ((_ sign_extend 1) ?x134) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x97)) true)))
(let ((?x50 ((_ sign_extend 1) ?x134)))
(let ((?x175 ((_ sign_extend 1) ?x57)))
(let (($x900 (or false false)))
(let (($x14 (or false false false)))
(let (($x113 (or $x14 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x129 (or $x113 $x900 (or (and (distinct (bvadd ((_ sign_extend 1) ?x108) ((_ sign_extend 1) ?x33)) ?x175) true)))))
(let (($x173 (or $x129 false (or (and (distinct (bvsub ?x175 ((_ sign_extend 1) (_ bv65 32))) ?x50) true)))))
(let (($x36 (or $x173 false (or $x146))))
(and (not $x36) (or $x36 (and (distinct ?x97 ?x97) true))))))))))))))))))
(check-sat)
; query 22: function main, block 81, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x147 (ite (bvsgt (_ bv32 32) in.06.lcssa_32) (_ bv1 1) (_ bv0 1))))
(let (($x14 (or false false false)))
(let (($x152 (not $x14)))
(and $x152 (or $x14 (and (distinct ?x147 ?x147) true)))))))
(check-sat)
; query 23: function main, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06.lcssa_32 () (_ BitVec 32))
(assert
 (let (($x14 (or false false false)))
(let (($x597 (or $x14 (and (distinct (bvand in.06.lcssa_32 (_ bv15 32)) (bvand in.06.lcssa_32 (_ bv15 32))) true))))
(let (($x152 (not $x14)))
(and $x152 $x597)))))
(check-sat)
; query 24: function main, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x178 (ite (and (distinct (_ bv0 32) (bvand in.06.lcssa_32 (_ bv15 32))) true) (_ bv1 1) (_ bv0 1))))
(let (($x14 (or false false false)))
(let (($x410 (or $x14 false false)))
(let (($x45 (not $x410)))
(and $x45 (or $x410 (and (distinct ?x178 ?x178) true))))))))
(check-sat)
; query 25: function set_key, block 11, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let (($x14 (or false false false)))
(let (($x152 (not $x14)))
(and $x152 (or $x14 (and (distinct (bvand in2_32 (_ bv1 32)) (bvand in2_32 (_ bv1 32))) true))))))
(check-sat)
; query 26: function set_key, block 11, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x463 (ite (and (distinct (_ bv0 32) (bvand in2_32 (_ bv1 32))) true) (_ bv1 1) (_ bv0 1))))
(let (($x14 (or false false false)))
(let (($x410 (or $x14 false false)))
(let (($x45 (not $x410)))
(and $x45 (or $x410 (and (distinct ?x463 ?x463) true))))))))
(check-sat)
; query 27: function set_key, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let (($x14 (or false false false)))
(let (($x152 (not $x14)))
(and $x152 (or $x14 (and (distinct (bvand in2_32 (_ bv2 32)) (bvand in2_32 (_ bv2 32))) true))))))
(check-sat)
; query 28: function set_key, block 14, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x706 (ite (and (distinct (_ bv0 32) (bvand in2_32 (_ bv2 32))) true) (_ bv1 1) (_ bv0 1))))
(let (($x14 (or false false false)))
(let (($x410 (or $x14 false false)))
(let (($x45 (not $x410)))
(and $x45 (or $x410 (and (distinct ?x706 ?x706) true))))))))
(check-sat)
; query 29: function set_key, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x31 (ite (and (distinct (_ bv0 64) in1_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x14 (or false false false)))
(let (($x152 (not $x14)))
(and $x152 (or $x14 (and (distinct ?x31 ?x31) true)))))))
(check-sat)
; query 30: function set_key, block 514, name %515
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_64 () (_ BitVec 64))
(assert
 (let (($x14 (or false false false)))
(let (($x152 (not $x14)))
(and $x152 (or $x14 (and (distinct (bvadd in.01_64 (_ bv1 64)) (bvadd in.01_64 (_ bv1 64))) true))))))
(check-sat)
; query 31: function set_key, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x195 (ite (bvult in1_64 (_ bv16 64)) (_ bv1 1) (_ bv0 1))))
(let (($x14 (or false false false)))
(let (($x152 (not $x14)))
(and $x152 (or $x14 (and (distinct ?x195 ?x195) true)))))))
(check-sat)
; query 32: function set_key, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x228 (ite (bvugt in1_64 (_ bv32 64)) (_ bv1 1) (_ bv0 1))))
(let (($x14 (or false false false)))
(let (($x152 (not $x14)))
(and $x152 (or $x14 (and (distinct ?x228 ?x228) true)))))))
(check-sat)
; query 33: function set_key, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let (($x14 (or false false false)))
(let (($x152 (not $x14)))
(and $x152 (or $x14 (and (distinct (bvand in1_64 (_ bv7 64)) (bvand in1_64 (_ bv7 64))) true))))))
(check-sat)
; query 34: function set_key, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x398 (ite (and (distinct (_ bv0 64) (bvand in1_64 (_ bv7 64))) true) (_ bv1 1) (_ bv0 1))))
(let (($x14 (or false false false)))
(let (($x410 (or $x14 false false)))
(let (($x45 (not $x410)))
(and $x45 (or $x410 (and (distinct ?x398 ?x398) true))))))))
(check-sat)
