; OptiPhase-Sigma refinement certificate for sweep K43-R6-050
