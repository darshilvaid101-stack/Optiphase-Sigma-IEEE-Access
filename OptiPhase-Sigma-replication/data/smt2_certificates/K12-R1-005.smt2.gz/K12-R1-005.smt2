; OptiPhase-Sigma refinement certificate for sweep K12-R1-005
