; OptiPhase-Sigma refinement certificate for sweep K47-R6-057
; query 0: function main, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x128 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x123 (or false false false)))
(and (not $x123) (or $x123 (and (distinct ?x128 ?x128) true))))))
(check-sat)
