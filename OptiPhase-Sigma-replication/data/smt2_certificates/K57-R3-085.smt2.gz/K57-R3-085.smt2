; OptiPhase-Sigma refinement certificate for sweep K57-R3-085
; query 0: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x48 (or false false false)))
(let (($x894 (not $x48)))
(and $x894 (or $x48 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x478 (bvadd in.01_32 (_ bv1 32))))
(let ((?x382 (bvmul ?x478 ?x478)))
(let (($x48 (or false false false)))
(let (($x67 (or $x48 $x48 false)))
(and (not $x67) (or $x67 (and (distinct ?x382 ?x382) true))))))))
(check-sat)
; query 2: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x628 (and (distinct (bvmul (bvmul (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) (_ bv2 32)) (bvshl (bvmul (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) (_ bv3 32))) true)))
(let (($x48 (or false false false)))
(let (($x67 (or $x48 $x48 false)))
(let (($x379 (or $x67 false false)))
(and (not $x379) (or (or $x379 (bvuge (_ bv3 32) (_ bv32 32))) $x628)))))))
(check-sat)
; query 3: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x1380 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x48 (or false false false)))
(let (($x894 (not $x48)))
(and $x894 (or $x48 (and (distinct ?x1380 ?x1380) true)))))))
(check-sat)
; query 4: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x48 (or false false false)))
(let (($x894 (not $x48)))
(and $x894 (or $x48 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 5: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x609 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x48 (or false false false)))
(let (($x894 (not $x48)))
(and $x894 (or $x48 (and (distinct ?x609 ?x609) true)))))))
(check-sat)
