; OptiPhase-Sigma refinement certificate for sweep K37-R3-300
; query 0: function bit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x62 (and (distinct (bvsub ((_ sign_extend 1) (_ bv31 32)) ((_ sign_extend 1) in0_32)) ((_ sign_extend 1) (bvsub (_ bv31 32) in0_32))) true)))
(let (($x52 (or false false (or $x62))))
(and (not $x52) (or $x52 (and (distinct (bvsub (_ bv31 32) in0_32) (bvsub (_ bv31 32) in0_32)) true))))))
(check-sat)
; query 1: function bit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x89 (bvsub (_ bv31 32) in0_32)))
(let ((?x6 (bvshl (_ bv1 32) ?x89)))
(let (($x62 (and (distinct (bvsub ((_ sign_extend 1) (_ bv31 32)) ((_ sign_extend 1) in0_32)) ((_ sign_extend 1) ?x89)) true)))
(let (($x52 (or false false (or $x62))))
(let (($x128 (or (or false $x52 false) (bvuge ?x89 (_ bv32 32)))))
(and (not $x128) (or $x128 (and (distinct ?x6 ?x6) true)))))))))
(check-sat)
; query 2: function bit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x89 (bvsub (_ bv31 32) in0_32)))
(let ((?x6 (bvshl (_ bv1 32) ?x89)))
(let ((?x144 ((_ sign_extend 32) ?x6)))
(let (($x62 (and (distinct (bvsub ((_ sign_extend 1) (_ bv31 32)) ((_ sign_extend 1) in0_32)) ((_ sign_extend 1) ?x89)) true)))
(let (($x52 (or false false (or $x62))))
(let (($x128 (or (or false $x52 false) (bvuge ?x89 (_ bv32 32)))))
(let (($x39 (or $x128 false)))
(and (not $x39) (or $x39 (and (distinct ?x144 ?x144) true)))))))))))
(check-sat)
; query 3: function bit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x89 (bvsub (_ bv31 32) in0_32)))
(let ((?x6 (bvshl (_ bv1 32) ?x89)))
(let ((?x144 ((_ sign_extend 32) ?x6)))
(let ((?x389 (bvand in1_64 ?x144)))
(let (($x62 (and (distinct (bvsub ((_ sign_extend 1) (_ bv31 32)) ((_ sign_extend 1) in0_32)) ((_ sign_extend 1) ?x89)) true)))
(let (($x52 (or false false (or $x62))))
(let (($x128 (or (or false $x52 false) (bvuge ?x89 (_ bv32 32)))))
(let (($x39 (or $x128 false)))
(let (($x253 (or false $x39 false)))
(and (not $x253) (or $x253 (and (distinct ?x389 ?x389) true)))))))))))))
(check-sat)
