; OptiPhase-Sigma refinement certificate for sweep K44-R4-329
; query 0: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x139 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x75 (or false false false)))
(let (($x11 (not $x75)))
(and $x11 (or $x75 (and (distinct ?x139 ?x139) true)))))))
(check-sat)
; query 1: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x428 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x75 (or false false false)))
(let (($x11 (not $x75)))
(and $x11 (or $x75 (and (distinct ?x428 ?x428) true)))))))
(check-sat)
