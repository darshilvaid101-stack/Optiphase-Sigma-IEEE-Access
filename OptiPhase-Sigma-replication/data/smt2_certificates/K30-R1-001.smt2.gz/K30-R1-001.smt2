; OptiPhase-Sigma refinement certificate for sweep K30-R1-001
; query 0: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x120 (ite (bvsgt (_ bv2 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x34 (or false false false)))
(and (not $x34) (or $x34 (and (distinct ?x120 ?x120) true))))))
(check-sat)
