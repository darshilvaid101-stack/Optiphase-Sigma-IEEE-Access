; OptiPhase-Sigma refinement certificate for sweep K01-R3-180
; query 0: function xmalloc, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in7_32 () (_ BitVec 32))
(assert
 (let ((?x85 (ite (and (distinct (_ bv0 32) in7_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x81 (or false false false)))
(and (not $x81) (or $x81 (and (distinct ?x85 ?x85) true))))))
(check-sat)
