; OptiPhase-Sigma refinement certificate for sweep K52-R4-351
