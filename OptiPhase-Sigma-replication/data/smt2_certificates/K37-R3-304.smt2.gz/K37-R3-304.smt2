; OptiPhase-Sigma refinement certificate for sweep K37-R3-304
; query 0: function bit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x122 (and (distinct (bvsub ((_ sign_extend 1) (_ bv31 32)) ((_ sign_extend 1) in0_32)) ((_ sign_extend 1) (bvsub (_ bv31 32) in0_32))) true)))
(let (($x15 (or false false (or $x122))))
(and (not $x15) (or $x15 (and (distinct (bvsub (_ bv31 32) in0_32) (bvsub (_ bv31 32) in0_32)) true))))))
(check-sat)
; query 1: function bit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x354 (bvsub (_ bv31 32) in0_32)))
(let ((?x33 (bvshl (_ bv1 32) ?x354)))
(let (($x122 (and (distinct (bvsub ((_ sign_extend 1) (_ bv31 32)) ((_ sign_extend 1) in0_32)) ((_ sign_extend 1) ?x354)) true)))
(let (($x15 (or false false (or $x122))))
(let (($x123 (or (or false $x15 false) (bvuge ?x354 (_ bv32 32)))))
(and (not $x123) (or $x123 (and (distinct ?x33 ?x33) true)))))))))
(check-sat)
; query 2: function bit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x354 (bvsub (_ bv31 32) in0_32)))
(let ((?x33 (bvshl (_ bv1 32) ?x354)))
(let ((?x102 ((_ sign_extend 32) ?x33)))
(let (($x122 (and (distinct (bvsub ((_ sign_extend 1) (_ bv31 32)) ((_ sign_extend 1) in0_32)) ((_ sign_extend 1) ?x354)) true)))
(let (($x15 (or false false (or $x122))))
(let (($x123 (or (or false $x15 false) (bvuge ?x354 (_ bv32 32)))))
(let (($x53 (or $x123 false)))
(and (not $x53) (or $x53 (and (distinct ?x102 ?x102) true)))))))))))
(check-sat)
; query 3: function bit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x354 (bvsub (_ bv31 32) in0_32)))
(let ((?x33 (bvshl (_ bv1 32) ?x354)))
(let ((?x102 ((_ sign_extend 32) ?x33)))
(let ((?x60 (bvand in1_64 ?x102)))
(let (($x122 (and (distinct (bvsub ((_ sign_extend 1) (_ bv31 32)) ((_ sign_extend 1) in0_32)) ((_ sign_extend 1) ?x354)) true)))
(let (($x15 (or false false (or $x122))))
(let (($x123 (or (or false $x15 false) (bvuge ?x354 (_ bv32 32)))))
(let (($x53 (or $x123 false)))
(let (($x324 (or false $x53 false)))
(and (not $x324) (or $x324 (and (distinct ?x60 ?x60) true)))))))))))))
(check-sat)
