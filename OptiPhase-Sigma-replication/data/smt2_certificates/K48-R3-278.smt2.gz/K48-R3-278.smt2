; OptiPhase-Sigma refinement certificate for sweep K48-R3-278
; query 0: function APCM_inverse_quantization, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x180 (or false false)))
(let (($x229 (not $x180)))
(and $x229 (or $x180 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 1: function APCM_inverse_quantization, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x104 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x180 (or false false)))
(let (($x225 (or $x180 false false)))
(let (($x45 (not $x225)))
(and $x45 (or $x225 (and (distinct ?x104 ?x104) true))))))))
(check-sat)
; query 2: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x180 (or false false)))
(let (($x229 (not $x180)))
(and $x229 (or $x180 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 3: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x99 (ite (bvslt (_ bv15 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x180 (or false false)))
(let (($x225 (or $x180 false false)))
(let (($x45 (not $x225)))
(and $x45 (or $x225 (and (distinct ?x99 ?x99) true))))))))
(check-sat)
; query 4: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x180 (or false false)))
(let (($x229 (not $x180)))
(and $x229 (or $x180 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 5: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x60 (ite (bvsgt (_ bv40 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x180 (or false false)))
(let (($x225 (or $x180 false false)))
(let (($x45 (not $x225)))
(and $x45 (or $x225 (and (distinct ?x60 ?x60) true))))))))
(check-sat)
; query 6: function RPE_grid_positioning, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x180 (or false false)))
(let (($x229 (not $x180)))
(and $x229 (or $x180 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 7: function RPE_grid_positioning, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x398 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x141 (and (distinct ?x398 ?x398) true)))
(let (($x180 (or false false)))
(let (($x188 (or false $x180 false)))
(and (not $x188) (or $x188 $x141)))))))
(check-sat)
; query 8: function gsm_L_add, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x160 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x28 (or false false false)))
(let (($x297 (not $x28)))
(and $x297 (or $x28 (and (distinct ?x160 ?x160) true)))))))
(check-sat)
; query 9: function gsm_L_add, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let (($x46 (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) in0_64)) ((_ sign_extend 1) (bvadd in1_64 in0_64))) true)))
(let (($x525 (or (or false false (or $x46)) (and (distinct (bvadd in0_64 in1_64) (bvadd in1_64 in0_64)) true))))
(let (($x900 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvadd in0_64 in1_64))) true)))
(and (not (or false false (or $x900))) $x525)))))
(check-sat)
; query 10: function gsm_L_add, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x15 (bvadd in0_64 (_ bv1 64))))
(let ((?x122 (bvsub (_ bv0 64) ?x15)))
(let (($x33 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x15)) ((_ sign_extend 1) ?x122)) true)))
(let ((?x149 ((_ sign_extend 1) ?x15)))
(let (($x96 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x149) true)))))
(let (($x35 (or false $x96 (or $x33))))
(and (not $x35) (or $x35 (and (distinct ?x122 ?x122) true))))))))))
(check-sat)
; query 11: function gsm_L_add, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x192 (bvadd in1_64 (_ bv1 64))))
(let ((?x49 ((_ sign_extend 1) ?x192)))
(let (($x227 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x49) true)))))
(and (not $x227) (or $x227 (and (distinct ?x192 ?x192) true)))))))
(check-sat)
; query 12: function gsm_L_add, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x192 (bvadd in1_64 (_ bv1 64))))
(let ((?x1071 (bvsub (_ bv0 64) ?x192)))
(let (($x108 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x192)) ((_ sign_extend 1) ?x1071)) true)))
(let ((?x49 ((_ sign_extend 1) ?x192)))
(let (($x227 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x49) true)))))
(let (($x226 (or false $x227 (or $x108))))
(and (not $x226) (or $x226 (and (distinct ?x1071 ?x1071) true))))))))))
(check-sat)
; query 13: function gsm_L_add, block 8, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x15 (bvadd in0_64 (_ bv1 64))))
(let ((?x122 (bvsub (_ bv0 64) ?x15)))
(let ((?x192 (bvadd in1_64 (_ bv1 64))))
(let ((?x1071 (bvsub (_ bv0 64) ?x192)))
(let ((?x61 (bvadd ?x1071 ?x122)))
(let ((?x53 (bvadd ?x122 ?x1071)))
(let (($x33 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x15)) ((_ sign_extend 1) ?x122)) true)))
(let ((?x149 ((_ sign_extend 1) ?x15)))
(let (($x96 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x149) true)))))
(let (($x35 (or false $x96 (or $x33))))
(let (($x108 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x192)) ((_ sign_extend 1) ?x1071)) true)))
(let ((?x49 ((_ sign_extend 1) ?x192)))
(let (($x227 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x49) true)))))
(let (($x226 (or false $x227 (or $x108))))
(let (($x10 (or $x226 $x35 false)))
(and (not (or $x35 $x226 false)) (or $x10 (and (distinct ?x53 ?x61) true)))))))))))))))))))
(check-sat)
; query 14: function gsm_L_add, block 8, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x15 (bvadd in0_64 (_ bv1 64))))
(let ((?x122 (bvsub (_ bv0 64) ?x15)))
(let ((?x192 (bvadd in1_64 (_ bv1 64))))
(let ((?x1071 (bvsub (_ bv0 64) ?x192)))
(let ((?x61 (bvadd ?x1071 ?x122)))
(let (($x24 (and (distinct (ite (bvuge (bvadd ?x122 ?x1071) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1)) (ite (bvuge ?x61 (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))) true)))
(let (($x33 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x15)) ((_ sign_extend 1) ?x122)) true)))
(let ((?x149 ((_ sign_extend 1) ?x15)))
(let (($x96 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x149) true)))))
(let (($x35 (or false $x96 (or $x33))))
(let (($x108 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x192)) ((_ sign_extend 1) ?x1071)) true)))
(let ((?x49 ((_ sign_extend 1) ?x192)))
(let (($x227 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x49) true)))))
(let (($x226 (or false $x227 (or $x108))))
(let (($x10 (or $x226 $x35 false)))
(and (not (or (or $x35 $x226 false) false false)) (or (or $x10 false false) $x24))))))))))))))))))
(check-sat)
; query 15: function gsm_L_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x15 (bvadd in0_64 (_ bv1 64))))
(let ((?x149 ((_ sign_extend 1) ?x15)))
(let (($x96 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x149) true)))))
(and (not $x96) (or $x96 (and (distinct ?x15 ?x15) true)))))))
(check-sat)
; query 16: function gsm_L_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x116 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x28 (or false false false)))
(let (($x297 (not $x28)))
(and $x297 (or $x28 (and (distinct ?x116 ?x116) true)))))))
(check-sat)
; query 17: function gsm_L_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x161 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x28 (or false false false)))
(let (($x297 (not $x28)))
(and $x297 (or $x28 (and (distinct ?x161 ?x161) true)))))))
(check-sat)
; query 18: function gsm_L_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x116 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x28 (or false false false)))
(let (($x297 (not $x28)))
(and $x297 (or $x28 (and (distinct ?x116 ?x116) true)))))))
(check-sat)
; query 19: function gsm_L_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x116 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x74 ((_ zero_extend 31) ?x116)))
(let (($x28 (or false false false)))
(let (($x54 (or $x28 false)))
(and (not $x54) (or $x54 (and (distinct ?x74 ?x74) true))))))))
(check-sat)
; query 20: function gsm_L_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x116 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x74 ((_ zero_extend 31) ?x116)))
(let ((?x16 (bvsub (_ bv0 32) ?x74)))
(let (($x71 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x74)) ((_ sign_extend 1) ?x16)) true)))
(let (($x28 (or false false false)))
(let (($x54 (or $x28 false)))
(let (($x112 (or false $x54 (or $x71))))
(and (not $x112) (or $x112 (and (distinct ?x16 ?x16) true)))))))))))
(check-sat)
; query 21: function gsm_L_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x116 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x74 ((_ zero_extend 31) ?x116)))
(let ((?x16 (bvsub (_ bv0 32) ?x74)))
(let ((?x146 ((_ sign_extend 32) ?x16)))
(let (($x71 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x74)) ((_ sign_extend 1) ?x16)) true)))
(let (($x28 (or false false false)))
(let (($x54 (or $x28 false)))
(let (($x112 (or false $x54 (or $x71))))
(let (($x36 (or $x112 false)))
(and (not $x36) (or $x36 (and (distinct ?x146 ?x146) true)))))))))))))
(check-sat)
; query 22: function gsm_L_asr, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x597 (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x28 (or false false false)))
(let (($x297 (not $x28)))
(and $x297 (or $x28 (and (distinct ?x597 ?x597) true)))))))
(check-sat)
; query 23: function gsm_L_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x161 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x28 (or false false false)))
(let (($x297 (not $x28)))
(and $x297 (or $x28 (and (distinct ?x161 ?x161) true)))))))
(check-sat)
; query 24: function gsm_L_sub, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x160 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x28 (or false false false)))
(let (($x297 (not $x28)))
(and $x297 (or $x28 (and (distinct ?x160 ?x160) true)))))))
(check-sat)
; query 25: function gsm_L_sub, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x150 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvsub in0_64 in1_64))) true)))
(let (($x183 (or false false (or $x150))))
(let (($x176 (or $x183 (and (distinct (bvsub in0_64 in1_64) (bvsub in0_64 in1_64)) true))))
(and (not $x183) $x176)))))
(check-sat)
; query 26: function gsm_L_sub, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x192 (bvadd in1_64 (_ bv1 64))))
(let ((?x1071 (bvsub (_ bv0 64) ?x192)))
(let (($x108 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x192)) ((_ sign_extend 1) ?x1071)) true)))
(let ((?x49 ((_ sign_extend 1) ?x192)))
(let (($x227 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x49) true)))))
(let (($x226 (or false $x227 (or $x108))))
(and (not $x226) (or $x226 (and (distinct ?x1071 ?x1071) true))))))))))
(check-sat)
; query 27: function gsm_L_sub, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x192 (bvadd in1_64 (_ bv1 64))))
(let ((?x1071 (bvsub (_ bv0 64) ?x192)))
(let ((?x52 (bvadd ?x1071 in0_64)))
(let ((?x463 (bvadd in0_64 ?x1071)))
(let (($x108 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x192)) ((_ sign_extend 1) ?x1071)) true)))
(let ((?x49 ((_ sign_extend 1) ?x192)))
(let (($x227 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x49) true)))))
(let (($x226 (or false $x227 (or $x108))))
(let (($x616 (or $x226 false false)))
(and (not (or false $x226 false)) (or $x616 (and (distinct ?x463 ?x52) true)))))))))))))
(check-sat)
; query 28: function gsm_L_sub, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x84 (ite (bvuge (bvadd (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64))) in0_64) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let ((?x17 (ite (bvuge (bvadd in0_64 (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64)))) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x108 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) (bvadd in1_64 (_ bv1 64)))) ((_ sign_extend 1) (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64))))) true)))
(let ((?x192 (bvadd in1_64 (_ bv1 64))))
(let ((?x49 ((_ sign_extend 1) ?x192)))
(let (($x227 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x49) true)))))
(let (($x226 (or false $x227 (or $x108))))
(let (($x616 (or $x226 false false)))
(and (not (or (or false $x226 false) false false)) (or (or $x616 false false) (and (distinct ?x17 ?x84) true))))))))))))
(check-sat)
; query 29: function gsm_L_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x192 (bvadd in1_64 (_ bv1 64))))
(let ((?x49 ((_ sign_extend 1) ?x192)))
(let (($x227 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x49) true)))))
(and (not $x227) (or $x227 (and (distinct ?x192 ?x192) true)))))))
(check-sat)
; query 30: function gsm_L_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x706 (ite (bvsle (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x28 (or false false false)))
(let (($x297 (not $x28)))
(and $x297 (or $x28 (and (distinct ?x706 ?x706) true)))))))
(check-sat)
; query 31: function gsm_abs, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x180 (or false false)))
(let (($x229 (not $x180)))
(and $x229 (or $x180 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 32: function gsm_abs, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x606 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x180 (or false false)))
(let (($x225 (or $x180 false false)))
(let (($x45 (not $x225)))
(and $x45 (or $x225 (and (distinct ?x606 ?x606) true))))))))
(check-sat)
; query 33: function gsm_abs, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x180 (or false false)))
(let (($x229 (not $x180)))
(and $x229 (or $x180 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 34: function gsm_abs, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x72 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x180 (or false false)))
(let (($x225 (or $x180 false false)))
(let (($x45 (not $x225)))
(and $x45 (or $x225 (and (distinct ?x72 ?x72) true))))))))
(check-sat)
; query 35: function gsm_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x180 (or false false)))
(let (($x229 (not $x180)))
(and $x229 (or $x180 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 36: function gsm_add, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x180 (or false false)))
(let (($x229 (not $x180)))
(and $x229 (or $x180 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 37: function gsm_add, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x234 ((_ sign_extend 48) in0_16)))
(let ((?x170 ((_ sign_extend 48) in1_16)))
(let ((?x808 (bvadd ?x170 ?x234)))
(let ((?x26 (bvadd ?x234 ?x170)))
(let (($x409 (and (distinct (bvadd ((_ sign_extend 1) ?x170) ((_ sign_extend 1) ?x234)) ((_ sign_extend 1) ?x808)) true)))
(let (($x180 (or false false)))
(let (($x237 (or $x180 $x180 (or $x409))))
(let (($x317 (and (distinct (bvadd ((_ sign_extend 1) ?x234) ((_ sign_extend 1) ?x170)) ((_ sign_extend 1) ?x26)) true)))
(let (($x223 (or $x180 $x180 (or $x317))))
(and (not $x223) (or $x237 (and (distinct ?x26 ?x808) true)))))))))))))
(check-sat)
; query 38: function gsm_add, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x326 (ite (bvsgt (_ bv18446744073709518848 64) (bvadd ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in0_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x564 (ite (bvsgt (_ bv18446744073709518848 64) (bvadd ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x234 ((_ sign_extend 48) in0_16)))
(let ((?x87 ((_ sign_extend 1) ?x234)))
(let ((?x170 ((_ sign_extend 48) in1_16)))
(let ((?x232 ((_ sign_extend 1) ?x170)))
(let (($x180 (or false false)))
(let (($x237 (or $x180 $x180 (or (and (distinct (bvadd ?x232 ?x87) ((_ sign_extend 1) (bvadd ?x170 ?x234))) true)))))
(let (($x223 (or $x180 $x180 (or (and (distinct (bvadd ?x87 ?x232) ((_ sign_extend 1) (bvadd ?x234 ?x170))) true)))))
(and (not (or $x223 false false)) (or (or $x237 false false) (and (distinct ?x564 ?x326) true)))))))))))))
(check-sat)
; query 39: function gsm_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x637 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x28 (or false false false)))
(let (($x297 (not $x28)))
(and $x297 (or $x28 (and (distinct ?x637 ?x637) true)))))))
(check-sat)
; query 40: function gsm_asr, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x607 (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x28 (or false false false)))
(let (($x297 (not $x28)))
(and $x297 (or $x28 (and (distinct ?x607 ?x607) true)))))))
(check-sat)
; query 41: function gsm_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x180 (or false false)))
(let (($x229 (not $x180)))
(and $x229 (or $x180 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 42: function gsm_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x72 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x180 (or false false)))
(let (($x225 (or $x180 false false)))
(let (($x45 (not $x225)))
(and $x45 (or $x225 (and (distinct ?x72 ?x72) true))))))))
(check-sat)
; query 43: function gsm_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x72 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x392 ((_ zero_extend 31) ?x72)))
(let (($x180 (or false false)))
(let (($x225 (or $x180 false false)))
(let (($x309 (or $x225 false)))
(and (not $x309) (or $x309 (and (distinct ?x392 ?x392) true)))))))))
(check-sat)
; query 44: function gsm_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x72 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x392 ((_ zero_extend 31) ?x72)))
(let ((?x482 (bvsub (_ bv0 32) ?x392)))
(let (($x554 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x392)) ((_ sign_extend 1) ?x482)) true)))
(let (($x180 (or false false)))
(let (($x225 (or $x180 false false)))
(let (($x309 (or $x225 false)))
(let (($x115 (or false $x309 (or $x554))))
(and (not $x115) (or $x115 (and (distinct ?x482 ?x482) true))))))))))))
(check-sat)
; query 45: function gsm_asr, block 4, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x72 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x392 ((_ zero_extend 31) ?x72)))
(let ((?x482 (bvsub (_ bv0 32) ?x392)))
(let ((?x929 ((_ extract 15 0) ?x482)))
(let (($x554 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x392)) ((_ sign_extend 1) ?x482)) true)))
(let (($x180 (or false false)))
(let (($x225 (or $x180 false false)))
(let (($x309 (or $x225 false)))
(let (($x115 (or false $x309 (or $x554))))
(let (($x832 (or $x115 false)))
(and (not $x832) (or $x832 (and (distinct ?x929 ?x929) true))))))))))))))
(check-sat)
; query 46: function gsm_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x637 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x28 (or false false false)))
(let (($x297 (not $x28)))
(and $x297 (or $x28 (and (distinct ?x637 ?x637) true)))))))
(check-sat)
; query 47: function gsm_debug_longwords, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in15_32 () (_ BitVec 32))
(assert
 (let ((?x614 (ite (bvslt in15_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x28 (or false false false)))
(let (($x297 (not $x28)))
(and $x297 (or $x28 (and (distinct ?x614 ?x614) true)))))))
(check-sat)
; query 48: function gsm_debug_words, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in16_32 () (_ BitVec 32))
(assert
 (let ((?x692 (ite (bvslt in16_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x28 (or false false false)))
(let (($x297 (not $x28)))
(and $x297 (or $x28 (and (distinct ?x692 ?x692) true)))))))
(check-sat)
; query 49: function gsm_div, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x180 (or false false)))
(let (($x229 (not $x180)))
(and $x229 (or $x180 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 50: function gsm_div, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x180 (or false false)))
(let (($x229 (not $x180)))
(and $x229 (or $x180 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 51: function gsm_div, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x180 (or false false)))
(let (($x229 (not $x180)))
(and $x229 (or $x180 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 52: function gsm_div, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x398 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x141 (and (distinct ?x398 ?x398) true)))
(let (($x180 (or false false)))
(let (($x225 (or $x180 false false)))
(let (($x45 (not $x225)))
(and $x45 (or $x225 $x141))))))))
(check-sat)
; query 53: function gsm_norm, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x116 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x28 (or false false false)))
(let (($x297 (not $x28)))
(and $x297 (or $x28 (and (distinct ?x116 (ite (bvsge (_ bv18446744072635809792 64) in0_64) (_ bv1 1) (_ bv0 1))) true)))))))
(check-sat)
; query 54: function gsm_norm, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x613 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x28 (or false false false)))
(let (($x297 (not $x28)))
(and $x297 (or $x28 (and (distinct ?x613 ?x613) true)))))))
(check-sat)
; query 55: function gsm_norm, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x613 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x447 (bvxor ?x613 (_ bv1 1))))
(let (($x28 (or false false false)))
(let (($x770 (or $x28 false false)))
(and (not $x770) (or $x770 (and (distinct ?x447 ?x447) true))))))))
(check-sat)
; query 56: function gsm_norm, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x613 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x447 (bvxor ?x613 (_ bv1 1))))
(let ((?x737 ((_ zero_extend 31) ?x447)))
(let (($x28 (or false false false)))
(let (($x770 (or $x28 false false)))
(let (($x1047 (or $x770 false)))
(and (not $x1047) (or $x1047 (and (distinct ?x737 ?x737) true))))))))))
(check-sat)
; query 57: function gsm_norm, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x613 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x447 (bvxor ?x613 (_ bv1 1))))
(let ((?x737 ((_ zero_extend 31) ?x447)))
(let ((?x283 ((_ sign_extend 32) ?x737)))
(let (($x28 (or false false false)))
(let (($x770 (or $x28 false false)))
(let (($x1047 (or $x770 false)))
(let (($x455 (or $x1047 false)))
(and (not $x455) (or $x455 (and (distinct ?x283 ?x283) true))))))))))))
(check-sat)
; query 58: function gsm_norm, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x613 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x447 (bvxor ?x613 (_ bv1 1))))
(let ((?x737 ((_ zero_extend 31) ?x447)))
(let ((?x283 ((_ sign_extend 32) ?x737)))
(let ((?x657 (ite (and (distinct (_ bv0 64) ?x283) true) (_ bv1 1) (_ bv0 1))))
(let (($x28 (or false false false)))
(let (($x770 (or $x28 false false)))
(let (($x1047 (or $x770 false)))
(let (($x455 (or $x1047 false)))
(let (($x325 (or $x455 false false)))
(and (not $x325) (or $x325 (and (distinct ?x657 ?x657) true))))))))))))))
(check-sat)
; query 59: function gsm_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x180 (or false false)))
(let (($x229 (not $x180)))
(and $x229 (or $x180 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 60: function gsm_sub, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x180 (or false false)))
(let (($x229 (not $x180)))
(and $x229 (or $x180 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 61: function gsm_sub, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x170 ((_ sign_extend 48) in1_16)))
(let ((?x234 ((_ sign_extend 48) in0_16)))
(let ((?x546 (bvsub ?x234 ?x170)))
(let (($x868 (and (distinct (bvsub ((_ sign_extend 1) ?x234) ((_ sign_extend 1) ?x170)) ((_ sign_extend 1) ?x546)) true)))
(let (($x180 (or false false)))
(let (($x919 (or $x180 $x180 (or $x868))))
(and (not $x919) (or $x919 (and (distinct ?x546 ?x546) true))))))))))
(check-sat)
; query 62: function gsm_sub, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x405 (ite (bvsgt (_ bv18446744073709518848 64) (bvsub ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x170 ((_ sign_extend 48) in1_16)))
(let ((?x232 ((_ sign_extend 1) ?x170)))
(let ((?x234 ((_ sign_extend 48) in0_16)))
(let ((?x87 ((_ sign_extend 1) ?x234)))
(let (($x180 (or false false)))
(let (($x919 (or $x180 $x180 (or (and (distinct (bvsub ?x87 ?x232) ((_ sign_extend 1) (bvsub ?x234 ?x170))) true)))))
(let (($x520 (or $x919 false false)))
(and (not $x520) (or $x520 (and (distinct ?x405 ?x405) true))))))))))))
(check-sat)
; query 63: function process_decode, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let (($x180 (or false false)))
(let (($x229 (not $x180)))
(and $x229 (or $x180 (and (distinct ((_ sign_extend 32) in14_32) ((_ sign_extend 32) in14_32)) true))))))
(check-sat)
; query 64: function process_decode, block 16, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x239 (ite (and (distinct (_ bv33 64) ((_ sign_extend 32) in14_32)) true) (_ bv1 1) (_ bv0 1))))
(let (($x180 (or false false)))
(let (($x225 (or $x180 false false)))
(let (($x45 (not $x225)))
(and $x45 (or $x225 (and (distinct ?x239 ?x239) true))))))))
(check-sat)
; query 65: function process_encode, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_32 () (_ BitVec 32))
(assert
 (let (($x180 (or false false)))
(let (($x229 (not $x180)))
(and $x229 (or $x180 (and (distinct ((_ sign_extend 32) in13_32) ((_ sign_extend 32) in13_32)) true))))))
(check-sat)
; query 66: function process_encode, block 15, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_32 () (_ BitVec 32))
(assert
 (let ((?x591 (ite (bvult ((_ sign_extend 32) in13_32) (_ bv160 64)) (_ bv1 1) (_ bv0 1))))
(let (($x180 (or false false)))
(let (($x225 (or $x180 false false)))
(let (($x45 (not $x225)))
(and $x45 (or $x225 (and (distinct ?x591 ?x591) true))))))))
(check-sat)
