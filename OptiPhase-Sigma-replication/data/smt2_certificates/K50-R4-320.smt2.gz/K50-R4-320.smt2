; OptiPhase-Sigma refinement certificate for sweep K50-R4-320
; query 0: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x135 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x648 (or false false false)))
(and (not $x648) (or $x648 (and (distinct ?x135 ?x135) true))))))
(check-sat)
