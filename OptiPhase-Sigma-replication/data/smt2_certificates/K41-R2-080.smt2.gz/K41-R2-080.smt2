; OptiPhase-Sigma refinement certificate for sweep K41-R2-080
; query 0: function decfile, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in17_32 () (_ BitVec 32))
(assert
 (let ((?x896 (ite (and (distinct (_ bv16 32) in17_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x42 (or false false false)))
(let (($x612 (not $x42)))
(and $x612 (or $x42 (and (distinct ?x896 ?x896) true)))))))
(check-sat)
; query 1: function decfile, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x67 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x90 (or false false (or $x67))))
(and (not $x90) (or $x90 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function decfile, block 82, name %83
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x47 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x382 (or false false (or $x47))))
(and (not $x382) (or $x382 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 3: function decfile, block 85, name %86
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x55 (ite (= (_ bv15 32) in.01_32) (_ bv1 1) (_ bv0 1))))
(let (($x42 (or false false false)))
(let (($x612 (not $x42)))
(and $x612 (or $x42 (and (distinct ?x55 ?x55) true)))))))
(check-sat)
; query 4: function decfile, block 85, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x55 (ite (= (_ bv15 32) in.01_32) (_ bv1 1) (_ bv0 1))))
(let ((?x91 ((_ zero_extend 63) ?x55)))
(let (($x42 (or false false false)))
(let (($x116 (or $x42 false)))
(and (not $x116) (or $x116 (and (distinct ?x91 ?x91) true))))))))
(check-sat)
; query 5: function decfile, block 85, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x55 (ite (= (_ bv15 32) in.01_32) (_ bv1 1) (_ bv0 1))))
(let (($x15 (= (_ bv1 1) ?x55)))
(let ((?x26 (ite $x15 (_ bv1 32) (_ bv0 32))))
(let (($x42 (or false false false)))
(let (($x122 (or $x42 (ite $x15 false false))))
(and (not $x122) (or $x122 (and (distinct ?x26 ?x26) true)))))))))
(check-sat)
; query 6: function decfile, block 85, name %89
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x55 (ite (= (_ bv15 32) in.01_32) (_ bv1 1) (_ bv0 1))))
(let (($x15 (= (_ bv1 1) ?x55)))
(let ((?x26 (ite $x15 (_ bv1 32) (_ bv0 32))))
(let ((?x87 (bvsub (_ bv1 32) ?x26)))
(let ((?x33 ((_ sign_extend 1) ?x87)))
(let (($x42 (or false false false)))
(let (($x122 (or $x42 (ite $x15 false false))))
(let (($x64 (or false $x122 (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv1 32)) ((_ sign_extend 1) ?x26)) ?x33) true)))))
(and (not $x64) (or $x64 (and (distinct ?x87 ?x87) true))))))))))))
(check-sat)
; query 7: function decfile, block 85, name %90
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(declare-fun in46_32 () (_ BitVec 32))
(assert
 (let ((?x55 (ite (= (_ bv15 32) in.01_32) (_ bv1 1) (_ bv0 1))))
(let (($x15 (= (_ bv1 1) ?x55)))
(let ((?x26 (ite $x15 (_ bv1 32) (_ bv0 32))))
(let ((?x87 (bvsub (_ bv1 32) ?x26)))
(let ((?x127 (bvadd in46_32 ?x87)))
(let (($x120 (and (distinct (bvadd ((_ sign_extend 1) in46_32) ((_ sign_extend 1) ?x87)) ((_ sign_extend 1) ?x127)) true)))
(let ((?x33 ((_ sign_extend 1) ?x87)))
(let (($x42 (or false false false)))
(let (($x122 (or $x42 (ite $x15 false false))))
(let (($x64 (or false $x122 (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv1 32)) ((_ sign_extend 1) ?x26)) ?x33) true)))))
(let (($x480 (or false $x64 (or $x120))))
(and (not $x480) (or $x480 (and (distinct ?x127 ?x127) true)))))))))))))))
(check-sat)
; query 8: function decfile, block 85, name %91
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(declare-fun in46_32 () (_ BitVec 32))
(assert
 (let ((?x55 (ite (= (_ bv15 32) in.01_32) (_ bv1 1) (_ bv0 1))))
(let (($x15 (= (_ bv1 1) ?x55)))
(let ((?x26 (ite $x15 (_ bv1 32) (_ bv0 32))))
(let ((?x87 (bvsub (_ bv1 32) ?x26)))
(let ((?x127 (bvadd in46_32 ?x87)))
(let ((?x533 (ite (and (distinct (_ bv0 32) ?x127) true) (_ bv1 1) (_ bv0 1))))
(let (($x120 (and (distinct (bvadd ((_ sign_extend 1) in46_32) ((_ sign_extend 1) ?x87)) ((_ sign_extend 1) ?x127)) true)))
(let ((?x33 ((_ sign_extend 1) ?x87)))
(let (($x42 (or false false false)))
(let (($x122 (or $x42 (ite $x15 false false))))
(let (($x64 (or false $x122 (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv1 32)) ((_ sign_extend 1) ?x26)) ?x33) true)))))
(let (($x480 (or false $x64 (or $x120))))
(let (($x60 (or $x480 false false)))
(and (not $x60) (or $x60 (and (distinct ?x533 ?x533) true)))))))))))))))))
(check-sat)
; query 9: function encfile, block 50, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_64 () (_ BitVec 64))
(assert
 (let (($x42 (or false false false)))
(let (($x612 (not $x42)))
(and $x612 (or $x42 (and (distinct (bvadd in.1_64 (_ bv1 64)) (bvadd in.1_64 (_ bv1 64))) true))))))
(check-sat)
; query 10: function encfile, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_64 () (_ BitVec 64))
(assert
 (let (($x42 (or false false false)))
(let (($x612 (not $x42)))
(and $x612 (or $x42 (and (distinct (bvadd in.2_64 (_ bv1 64)) (bvadd in.2_64 (_ bv1 64))) true))))))
(check-sat)
; query 11: function encfile, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.5_64 () (_ BitVec 64))
(assert
 (let (($x42 (or false false false)))
(let (($x612 (not $x42)))
(and $x612 (or $x42 (and (distinct (bvadd in.5_64 (_ bv1 64)) (bvadd in.5_64 (_ bv1 64))) true))))))
(check-sat)
; query 12: function fillrand, block 34, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x483 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x541 (or false false (or $x483))))
(and (not $x541) (or $x541 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 13: function main, block 41, name %42
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let (($x8 (or false false)))
(and (not $x8) (or $x8 (and (distinct ((_ sign_extend 24) in38_8) ((_ sign_extend 24) in38_8)) true)))))
(check-sat)
; query 14: function main, block 41, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let ((?x144 (ite (bvsge (_ bv57 32) ((_ sign_extend 24) in38_8)) (_ bv1 1) (_ bv0 1))))
(let (($x8 (or false false)))
(let (($x9 (or $x8 false false)))
(let (($x140 (not $x9)))
(and $x140 (or $x9 (and (distinct ?x144 ?x144) true))))))))
(check-sat)
; query 15: function main, block 44, name %45
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x42 (or false false false)))
(let (($x61 (or $x42 (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x61) (or $x61 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvshl in.01_32 (_ bv4 32))) true))))))
(check-sat)
; query 16: function main, block 44, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let (($x8 (or false false)))
(and (not $x8) (or $x8 (and (distinct ((_ sign_extend 24) in38_8) ((_ sign_extend 24) in38_8)) true)))))
(check-sat)
; query 17: function main, block 44, name %47
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x37 ((_ sign_extend 24) in38_8)))
(let ((?x490 (bvshl in.01_32 (_ bv4 32))))
(let ((?x615 (bvadd ?x490 ?x37)))
(let ((?x644 ((_ sign_extend 1) ?x615)))
(let (($x8 (or false false)))
(let (($x42 (or false false false)))
(let (($x61 (or $x42 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x752 (or $x61 $x8 (or (and (distinct (bvadd ((_ sign_extend 1) ?x490) ((_ sign_extend 1) ?x37)) ?x644) true)))))
(and (not $x752) (or $x752 (and (distinct ?x615 ?x615) true))))))))))))
(check-sat)
; query 18: function main, block 44, name %48
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x37 ((_ sign_extend 24) in38_8)))
(let ((?x490 (bvshl in.01_32 (_ bv4 32))))
(let ((?x615 (bvadd ?x490 ?x37)))
(let ((?x129 (bvsub ?x615 (_ bv48 32))))
(let (($x57 (and (distinct (bvsub ((_ sign_extend 1) ?x615) ((_ sign_extend 1) (_ bv48 32))) ((_ sign_extend 1) ?x129)) true)))
(let ((?x644 ((_ sign_extend 1) ?x615)))
(let (($x8 (or false false)))
(let (($x42 (or false false false)))
(let (($x61 (or $x42 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x752 (or $x61 $x8 (or (and (distinct (bvadd ((_ sign_extend 1) ?x490) ((_ sign_extend 1) ?x37)) ?x644) true)))))
(let (($x514 (or $x752 false (or $x57))))
(and (not $x514) (or $x514 (and (distinct ?x129 ?x129) true)))))))))))))))
(check-sat)
; query 19: function main, block 49, name %50
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let (($x8 (or false false)))
(and (not $x8) (or $x8 (and (distinct ((_ sign_extend 24) in38_8) ((_ sign_extend 24) in38_8)) true)))))
(check-sat)
; query 20: function main, block 49, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let ((?x102 (ite (bvsle (_ bv65 32) ((_ sign_extend 24) in38_8)) (_ bv1 1) (_ bv0 1))))
(let (($x8 (or false false)))
(let (($x9 (or $x8 false false)))
(let (($x140 (not $x9)))
(and $x140 (or $x9 (and (distinct ?x102 ?x102) true))))))))
(check-sat)
; query 21: function main, block 52, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let (($x8 (or false false)))
(and (not $x8) (or $x8 (and (distinct ((_ sign_extend 24) in38_8) ((_ sign_extend 24) in38_8)) true)))))
(check-sat)
; query 22: function main, block 52, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let ((?x384 (ite (bvsge (_ bv70 32) ((_ sign_extend 24) in38_8)) (_ bv1 1) (_ bv0 1))))
(let (($x8 (or false false)))
(let (($x9 (or $x8 false false)))
(let (($x140 (not $x9)))
(and $x140 (or $x9 (and (distinct ?x384 ?x384) true))))))))
(check-sat)
; query 23: function main, block 55, name %56
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x42 (or false false false)))
(let (($x61 (or $x42 (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x61) (or $x61 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvshl in.01_32 (_ bv4 32))) true))))))
(check-sat)
; query 24: function main, block 55, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let (($x8 (or false false)))
(and (not $x8) (or $x8 (and (distinct ((_ sign_extend 24) in38_8) ((_ sign_extend 24) in38_8)) true)))))
(check-sat)
; query 25: function main, block 55, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x37 ((_ sign_extend 24) in38_8)))
(let ((?x490 (bvshl in.01_32 (_ bv4 32))))
(let ((?x615 (bvadd ?x490 ?x37)))
(let ((?x644 ((_ sign_extend 1) ?x615)))
(let (($x8 (or false false)))
(let (($x42 (or false false false)))
(let (($x61 (or $x42 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x752 (or $x61 $x8 (or (and (distinct (bvadd ((_ sign_extend 1) ?x490) ((_ sign_extend 1) ?x37)) ?x644) true)))))
(and (not $x752) (or $x752 (and (distinct ?x615 ?x615) true))))))))))))
(check-sat)
; query 26: function main, block 55, name %59
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x37 ((_ sign_extend 24) in38_8)))
(let ((?x490 (bvshl in.01_32 (_ bv4 32))))
(let ((?x615 (bvadd ?x490 ?x37)))
(let ((?x191 (bvsub ?x615 (_ bv65 32))))
(let ((?x1246 ((_ sign_extend 1) ?x191)))
(let ((?x644 ((_ sign_extend 1) ?x615)))
(let (($x8 (or false false)))
(let (($x42 (or false false false)))
(let (($x61 (or $x42 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x752 (or $x61 $x8 (or (and (distinct (bvadd ((_ sign_extend 1) ?x490) ((_ sign_extend 1) ?x37)) ?x644) true)))))
(let (($x1252 (or $x752 false (or (and (distinct (bvsub ?x644 ((_ sign_extend 1) (_ bv65 32))) ?x1246) true)))))
(and (not $x1252) (or $x1252 (and (distinct ?x191 ?x191) true)))))))))))))))
(check-sat)
; query 27: function main, block 55, name %60
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x37 ((_ sign_extend 24) in38_8)))
(let ((?x490 (bvshl in.01_32 (_ bv4 32))))
(let ((?x615 (bvadd ?x490 ?x37)))
(let ((?x191 (bvsub ?x615 (_ bv65 32))))
(let ((?x1162 (bvadd ?x191 (_ bv10 32))))
(let (($x704 (and (distinct (bvadd ((_ sign_extend 1) ?x191) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x1162)) true)))
(let ((?x1246 ((_ sign_extend 1) ?x191)))
(let ((?x644 ((_ sign_extend 1) ?x615)))
(let (($x8 (or false false)))
(let (($x42 (or false false false)))
(let (($x61 (or $x42 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x752 (or $x61 $x8 (or (and (distinct (bvadd ((_ sign_extend 1) ?x490) ((_ sign_extend 1) ?x37)) ?x644) true)))))
(let (($x1252 (or $x752 false (or (and (distinct (bvsub ?x644 ((_ sign_extend 1) (_ bv65 32))) ?x1246) true)))))
(let (($x1745 (or $x1252 false (or $x704))))
(and (not $x1745) (or $x1745 (and (distinct ?x1162 ?x1162) true))))))))))))))))))
(check-sat)
; query 28: function main, block 81, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_32 () (_ BitVec 32))
(assert
 (let ((?x206 (ite (bvsgt (_ bv32 32) in.06_32) (_ bv1 1) (_ bv0 1))))
(let (($x42 (or false false false)))
(let (($x612 (not $x42)))
(and $x612 (or $x42 (and (distinct ?x206 ?x206) true)))))))
(check-sat)
; query 29: function main, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_32 () (_ BitVec 32))
(assert
 (let (($x42 (or false false false)))
(let (($x612 (not $x42)))
(and $x612 (or $x42 (and (distinct (bvand in.06_32 (_ bv15 32)) (bvand in.06_32 (_ bv15 32))) true))))))
(check-sat)
; query 30: function main, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_32 () (_ BitVec 32))
(assert
 (let ((?x1268 (ite (and (distinct (_ bv0 32) (bvand in.06_32 (_ bv15 32))) true) (_ bv1 1) (_ bv0 1))))
(let (($x42 (or false false false)))
(let (($x274 (or $x42 false false)))
(let (($x261 (not $x274)))
(and $x261 (or $x274 (and (distinct ?x1268 ?x1268) true))))))))
(check-sat)
; query 31: function set_key, block 11, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let (($x42 (or false false false)))
(let (($x612 (not $x42)))
(and $x612 (or $x42 (and (distinct (bvand in2_32 (_ bv1 32)) (bvand in2_32 (_ bv1 32))) true))))))
(check-sat)
; query 32: function set_key, block 11, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x746 (ite (and (distinct (_ bv0 32) (bvand in2_32 (_ bv1 32))) true) (_ bv1 1) (_ bv0 1))))
(let (($x42 (or false false false)))
(let (($x274 (or $x42 false false)))
(let (($x261 (not $x274)))
(and $x261 (or $x274 (and (distinct ?x746 ?x746) true))))))))
(check-sat)
; query 33: function set_key, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let (($x42 (or false false false)))
(let (($x612 (not $x42)))
(and $x612 (or $x42 (and (distinct (bvand in2_32 (_ bv2 32)) (bvand in2_32 (_ bv2 32))) true))))))
(check-sat)
; query 34: function set_key, block 14, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x107 (ite (and (distinct (_ bv0 32) (bvand in2_32 (_ bv2 32))) true) (_ bv1 1) (_ bv0 1))))
(let (($x42 (or false false false)))
(let (($x274 (or $x42 false false)))
(let (($x261 (not $x274)))
(and $x261 (or $x274 (and (distinct ?x107 ?x107) true))))))))
(check-sat)
; query 35: function set_key, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x420 (ite (and (distinct (_ bv0 64) in1_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x42 (or false false false)))
(let (($x612 (not $x42)))
(and $x612 (or $x42 (and (distinct ?x420 ?x420) true)))))))
(check-sat)
; query 36: function set_key, block 514, name %515
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_64 () (_ BitVec 64))
(assert
 (let (($x42 (or false false false)))
(let (($x612 (not $x42)))
(and $x612 (or $x42 (and (distinct (bvadd in.01_64 (_ bv1 64)) (bvadd in.01_64 (_ bv1 64))) true))))))
(check-sat)
; query 37: function set_key, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1065 (ite (bvult in1_64 (_ bv16 64)) (_ bv1 1) (_ bv0 1))))
(let (($x42 (or false false false)))
(let (($x612 (not $x42)))
(and $x612 (or $x42 (and (distinct ?x1065 ?x1065) true)))))))
(check-sat)
; query 38: function set_key, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x328 (ite (bvugt in1_64 (_ bv32 64)) (_ bv1 1) (_ bv0 1))))
(let (($x42 (or false false false)))
(let (($x612 (not $x42)))
(and $x612 (or $x42 (and (distinct ?x328 ?x328) true)))))))
(check-sat)
; query 39: function set_key, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let (($x42 (or false false false)))
(let (($x612 (not $x42)))
(and $x612 (or $x42 (and (distinct (bvand in1_64 (_ bv7 64)) (bvand in1_64 (_ bv7 64))) true))))))
(check-sat)
; query 40: function set_key, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x95 (ite (and (distinct (_ bv0 64) (bvand in1_64 (_ bv7 64))) true) (_ bv1 1) (_ bv0 1))))
(let (($x42 (or false false false)))
(let (($x274 (or $x42 false false)))
(let (($x261 (not $x274)))
(and $x261 (or $x274 (and (distinct ?x95 ?x95) true))))))))
(check-sat)
