; OptiPhase-Sigma refinement certificate for sweep K49-R5-403
; query 0: function gsm_L_add, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let (($x529 (and (distinct (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv18446744073709551615 64) in1_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x72 (or false false false)))
(let (($x720 (not $x72)))
(and $x720 (or $x72 $x529))))))
(check-sat)
; query 1: function gsm_L_add, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x730 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvadd in0_64 in1_64))) true)))
(let (($x30 (or false false (or $x730))))
(let (($x751 (or $x30 (and (distinct (bvadd in0_64 in1_64) (bvadd in0_64 in1_64)) true))))
(and (not $x30) $x751)))))
(check-sat)
; query 2: function gsm_L_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x170 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x72 (or false false false)))
(let (($x720 (not $x72)))
(and $x720 (or $x72 (and (distinct ?x170 ?x170) true)))))))
(check-sat)
; query 3: function gsm_L_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x357 (and (distinct (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv31 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x72 (or false false false)))
(let (($x720 (not $x72)))
(and $x720 (or $x72 $x357))))))
(check-sat)
; query 4: function gsm_L_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x357 (and (distinct (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv31 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x72 (or false false false)))
(let (($x720 (not $x72)))
(and $x720 (or $x72 $x357))))))
(check-sat)
; query 5: function gsm_L_sub, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let (($x529 (and (distinct (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv18446744073709551615 64) in1_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x72 (or false false false)))
(let (($x720 (not $x72)))
(and $x720 (or $x72 $x529))))))
(check-sat)
; query 6: function gsm_L_sub, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x65 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvsub in0_64 in1_64))) true)))
(let (($x330 (or false false (or $x65))))
(let (($x69 (or $x330 (and (distinct (bvsub in0_64 in1_64) (bvsub in0_64 in1_64)) true))))
(and (not $x330) $x69)))))
(check-sat)
; query 7: function gsm_L_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x413 (and (distinct (ite (bvsle (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv18446744073709551615 64) in0_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x72 (or false false false)))
(let (($x720 (not $x72)))
(and $x720 (or $x72 $x413))))))
(check-sat)
; query 8: function gsm_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x703 (and (distinct (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv15 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x72 (or false false false)))
(let (($x720 (not $x72)))
(and $x720 (or $x72 $x703))))))
(check-sat)
; query 9: function gsm_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x703 (and (distinct (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv15 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x72 (or false false false)))
(let (($x720 (not $x72)))
(and $x720 (or $x72 $x703))))))
(check-sat)
