; OptiPhase-Sigma refinement certificate for sweep K15-R1-005
