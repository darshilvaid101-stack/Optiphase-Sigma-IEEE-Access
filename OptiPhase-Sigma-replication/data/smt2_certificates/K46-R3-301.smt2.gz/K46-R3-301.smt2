; OptiPhase-Sigma refinement certificate for sweep K46-R3-301
; query 0: function adpcm_coder, block 25, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in20_32 () (_ BitVec 32))
(assert
 (let (($x103 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in20_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in20_32))) true)))
(let (($x220 (or false false (or $x103))))
(and (not $x220) (or $x220 (and (distinct (bvsub (_ bv0 32) in20_32) (bvsub (_ bv0 32) in20_32)) true))))))
(check-sat)
; query 1: function adpcm_coder, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(declare-fun in.017_32 () (_ BitVec 32))
(assert
 (let ((?x76 (bvsub in.017_32 in.020_32)))
(let (($x1458 (and (distinct (bvsub ((_ sign_extend 1) in.017_32) ((_ sign_extend 1) in.020_32)) ((_ sign_extend 1) ?x76)) true)))
(let (($x109 (or false false (or $x1458))))
(and (not $x109) (or $x109 (and (distinct ?x76 ?x76) true)))))))
(check-sat)
; query 2: function adpcm_coder, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(declare-fun in28_32 () (_ BitVec 32))
(assert
 (let (($x1156 (and (distinct (bvadd ((_ sign_extend 1) in28_32) ((_ sign_extend 1) in.020_32)) ((_ sign_extend 1) (bvadd in28_32 in.020_32))) true)))
(let (($x458 (or false false (or $x1156))))
(let (($x15 (or $x458 (and (distinct (bvadd in28_32 in.020_32) (bvadd in28_32 in.020_32)) true))))
(and (not $x458) $x15)))))
(check-sat)
; query 3: function adpcm_coder, block 36, name %37
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.014_32 () (_ BitVec 32))
(assert
 (let (($x1586 (or false false false)))
(let (($x99 (not $x1586)))
(and $x99 (or $x1586 (and (distinct (bvor in.014_32 (_ bv2 32)) (bvor in.014_32 (_ bv2 32))) true))))))
(check-sat)
; query 4: function adpcm_coder, block 36, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in34_32 () (_ BitVec 32))
(declare-fun in.118_32 () (_ BitVec 32))
(assert
 (let (($x96 (and (distinct (bvsub ((_ sign_extend 1) in.118_32) ((_ sign_extend 1) in34_32)) ((_ sign_extend 1) (bvsub in.118_32 in34_32))) true)))
(let (($x249 (or false false (or $x96))))
(let (($x707 (or $x249 (and (distinct (bvsub in.118_32 in34_32) (bvsub in.118_32 in34_32)) true))))
(and (not $x249) $x707)))))
(check-sat)
; query 5: function adpcm_coder, block 36, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in34_32 () (_ BitVec 32))
(declare-fun in.08_32 () (_ BitVec 32))
(assert
 (let (($x28 (and (distinct (bvadd ((_ sign_extend 1) in.08_32) ((_ sign_extend 1) in34_32)) ((_ sign_extend 1) (bvadd in.08_32 in34_32))) true)))
(let (($x831 (or false false (or $x28))))
(let (($x115 (or $x831 (and (distinct (bvadd in.08_32 in34_32) (bvadd in.08_32 in34_32)) true))))
(and (not $x831) $x115)))))
(check-sat)
; query 6: function adpcm_coder, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.115_32 () (_ BitVec 32))
(assert
 (let (($x1586 (or false false false)))
(let (($x99 (not $x1586)))
(and $x99 (or $x1586 (and (distinct (bvor in.115_32 (_ bv1 32)) (bvor in.115_32 (_ bv1 32))) true))))))
(check-sat)
; query 7: function adpcm_coder, block 43, name %45
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in41_32 () (_ BitVec 32))
(declare-fun in.19_32 () (_ BitVec 32))
(assert
 (let (($x176 (and (distinct (bvadd ((_ sign_extend 1) in.19_32) ((_ sign_extend 1) in41_32)) ((_ sign_extend 1) (bvadd in.19_32 in41_32))) true)))
(let (($x217 (or false false (or $x176))))
(let (($x321 (or $x217 (and (distinct (bvadd in.19_32 in41_32) (bvadd in.19_32 in41_32)) true))))
(and (not $x217) $x321)))))
(check-sat)
; query 8: function adpcm_coder, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.210_32 () (_ BitVec 32))
(declare-fun in.011_32 () (_ BitVec 32))
(assert
 (let ((?x287 (bvsub in.011_32 in.210_32)))
(let (($x349 (and (distinct (bvsub ((_ sign_extend 1) in.011_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x287)) true)))
(let (($x622 (or false false (or $x349))))
(and (not $x622) (or $x622 (and (distinct ?x287 ?x287) true)))))))
(check-sat)
; query 9: function adpcm_coder, block 50, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.210_32 () (_ BitVec 32))
(declare-fun in.011_32 () (_ BitVec 32))
(assert
 (let ((?x786 (bvadd in.011_32 in.210_32)))
(let (($x1566 (and (distinct (bvadd ((_ sign_extend 1) in.011_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x786)) true)))
(let (($x1234 (or false false (or $x1566))))
(and (not $x1234) (or $x1234 (and (distinct ?x786 ?x786) true)))))))
(check-sat)
; query 10: function adpcm_decoder, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x1598 (ite (and (distinct (_ bv0 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x1586 (or false false false)))
(let (($x99 (not $x1586)))
(and $x99 (or $x1586 (and (distinct ?x1598 ?x1598) true)))))))
(check-sat)
; query 11: function adpcm_decoder, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x1586 (or false false false)))
(let (($x99 (not $x1586)))
(and $x99 (or $x1586 (and (distinct (bvand in.01_32 (_ bv15 32)) (bvand in.01_32 (_ bv15 32))) true))))))
(check-sat)
; query 12: function adpcm_decoder, block 61, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.210_32 () (_ BitVec 32))
(declare-fun in.013_32 () (_ BitVec 32))
(assert
 (let ((?x1224 (bvadd in.013_32 in.210_32)))
(let ((?x1590 (bvsub in.013_32 in.210_32)))
(let (($x266 (and (distinct (bvadd ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x1224)) true)))
(let (($x1588 (and (distinct (bvsub ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x1590)) true)))
(and (not (or false false (or $x1588))) (or (or false false (or $x266)) (and (distinct ?x1590 ?x1224) true))))))))
(check-sat)
; query 13: function main, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x949 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x1586 (or false false false)))
(let (($x99 (not $x1586)))
(and $x99 (or $x1586 (and (distinct ?x949 ?x949) true)))))))
(check-sat)
