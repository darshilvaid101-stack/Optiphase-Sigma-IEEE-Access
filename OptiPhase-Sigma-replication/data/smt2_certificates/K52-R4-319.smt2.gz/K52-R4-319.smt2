; OptiPhase-Sigma refinement certificate for sweep K52-R4-319
; query 0: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x1857 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x100 (or false false false)))
(let (($x1879 (not $x100)))
(and $x1879 (or $x100 (and (distinct ?x1857 ?x1857) true)))))))
(check-sat)
; query 1: function s162, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x1874 (ite (bvslt (_ bv0 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x100 (or false false false)))
(let (($x1879 (not $x100)))
(and $x1879 (or $x100 (and (distinct ?x1874 ?x1874) true)))))))
(check-sat)
