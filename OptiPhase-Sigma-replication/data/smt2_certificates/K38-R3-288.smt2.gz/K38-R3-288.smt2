; OptiPhase-Sigma refinement certificate for sweep K38-R3-288
; query 0: function BF_cbc_encrypt, block 126, name %127
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.010_64 () (_ BitVec 64))
(assert
 (let (($x1025 (and (distinct (bvsub ((_ sign_extend 1) in.010_64) ((_ sign_extend 1) (_ bv8 64))) ((_ sign_extend 1) (bvsub in.010_64 (_ bv8 64)))) true)))
(let (($x140 (or false false (or $x1025))))
(and (not $x140) (or $x140 (and (distinct (bvsub in.010_64 (_ bv8 64)) (bvsub in.010_64 (_ bv8 64))) true))))))
(check-sat)
; query 1: function BF_cfb64_encrypt, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.07_32 () (_ BitVec 32))
(assert
 (let ((?x51 (ite (= (_ bv0 32) in.07_32) (_ bv1 1) (_ bv0 1))))
(let (($x274 (or false false false)))
(and (not $x274) (or $x274 (and (distinct ?x51 ?x51) true))))))
(check-sat)
; query 2: function BF_set_key, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x406 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x696 (or false false (or $x406))))
(and (not $x696) (or $x696 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 3: function BF_set_key, block 69, name %70
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.13_32 () (_ BitVec 32))
(assert
 (let (($x113 (and (distinct (bvadd ((_ sign_extend 1) in.13_32) ((_ sign_extend 1) (_ bv2 32))) ((_ sign_extend 1) (bvadd in.13_32 (_ bv2 32)))) true)))
(let (($x360 (or false false (or $x113))))
(and (not $x360) (or $x360 (and (distinct (bvadd in.13_32 (_ bv2 32)) (bvadd in.13_32 (_ bv2 32))) true))))))
(check-sat)
; query 4: function BF_set_key, block 87, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.24_32 () (_ BitVec 32))
(assert
 (let (($x35 (and (distinct (bvadd ((_ sign_extend 1) in.24_32) ((_ sign_extend 1) (_ bv2 32))) ((_ sign_extend 1) (bvadd in.24_32 (_ bv2 32)))) true)))
(let (($x386 (or false false (or $x35))))
(and (not $x386) (or $x386 (and (distinct (bvadd in.24_32 (_ bv2 32)) (bvadd in.24_32 (_ bv2 32))) true))))))
(check-sat)
; query 5: function main, block 60, name %61
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x223 (or false false)))
(and (not $x223) (or $x223 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 6: function main, block 60, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x334 (ite (bvsge (_ bv57 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x223 (or false false)))
(let (($x137 (or $x223 false false)))
(let (($x5 (not $x137)))
(and $x5 (or $x137 (and (distinct ?x334 ?x334) true))))))))
(check-sat)
; query 7: function main, block 63, name %64
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x274 (or false false false)))
(and (not (or $x274 (bvuge (_ bv4 32) (_ bv32 32)))) (or $x274 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvmul in.01_32 (_ bv16 32))) true)))))
(check-sat)
; query 8: function main, block 63, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x223 (or false false)))
(and (not $x223) (or $x223 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 9: function main, block 63, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x52 (bvmul in.01_32 (_ bv16 32))))
(let ((?x259 (bvadd ?x52 (_ bv4294967248 32))))
(let ((?x309 ((_ sign_extend 24) in57_8)))
(let ((?x6 (bvshl in.01_32 (_ bv4 32))))
(let ((?x46 (bvadd ?x6 ?x309)))
(let (($x274 (or false false false)))
(let (($x446 (or $x274 false false)))
(let ((?x148 ((_ sign_extend 1) ?x46)))
(let (($x223 (or false false)))
(let (($x29 (or $x274 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x40 (or $x29 $x223 (or (and (distinct (bvadd ((_ sign_extend 1) ?x6) ((_ sign_extend 1) ?x309)) ?x148) true)))))
(let (($x158 (not $x40)))
(and $x158 (or $x446 (and (distinct ?x46 ?x259) true))))))))))))))))
(check-sat)
; query 10: function main, block 63, name %67
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x309 ((_ sign_extend 24) in57_8)))
(let ((?x6 (bvshl in.01_32 (_ bv4 32))))
(let ((?x46 (bvadd ?x6 ?x309)))
(let ((?x28 (bvsub ?x46 (_ bv48 32))))
(let (($x223 (or false false)))
(let (($x274 (or false false false)))
(let (($x446 (or $x274 false false)))
(let (($x38 (or $x446 $x223 false)))
(let (($x57 (or $x38 (and (distinct ?x28 (bvadd (bvadd (bvmul in.01_32 (_ bv16 32)) (_ bv4294967248 32)) ?x309)) true))))
(let (($x584 (and (distinct (bvsub ((_ sign_extend 1) ?x46) ((_ sign_extend 1) (_ bv48 32))) ((_ sign_extend 1) ?x28)) true)))
(let ((?x148 ((_ sign_extend 1) ?x46)))
(let (($x29 (or $x274 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x40 (or $x29 $x223 (or (and (distinct (bvadd ((_ sign_extend 1) ?x6) ((_ sign_extend 1) ?x309)) ?x148) true)))))
(and (not (or $x40 false (or $x584))) $x57)))))))))))))))
(check-sat)
; query 11: function main, block 68, name %69
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x223 (or false false)))
(and (not $x223) (or $x223 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 12: function main, block 68, name %70
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x135 (ite (bvsle (_ bv65 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x223 (or false false)))
(let (($x137 (or $x223 false false)))
(let (($x5 (not $x137)))
(and $x5 (or $x137 (and (distinct ?x135 ?x135) true))))))))
(check-sat)
; query 13: function main, block 71, name %72
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x223 (or false false)))
(and (not $x223) (or $x223 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 14: function main, block 71, name %73
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x81 (ite (bvsge (_ bv70 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x223 (or false false)))
(let (($x137 (or $x223 false false)))
(let (($x5 (not $x137)))
(and $x5 (or $x137 (and (distinct ?x81 ?x81) true))))))))
(check-sat)
; query 15: function main, block 74, name %75
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x274 (or false false false)))
(and (not (or $x274 (bvuge (_ bv4 32) (_ bv32 32)))) (or $x274 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvmul in.01_32 (_ bv16 32))) true)))))
(check-sat)
; query 16: function main, block 74, name %76
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x223 (or false false)))
(and (not $x223) (or $x223 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 17: function main, block 74, name %77
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x52 (bvmul in.01_32 (_ bv16 32))))
(let ((?x294 (bvadd ?x52 (_ bv4294967241 32))))
(let ((?x309 ((_ sign_extend 24) in57_8)))
(let ((?x6 (bvshl in.01_32 (_ bv4 32))))
(let ((?x46 (bvadd ?x6 ?x309)))
(let (($x274 (or false false false)))
(let (($x446 (or $x274 false false)))
(let ((?x148 ((_ sign_extend 1) ?x46)))
(let (($x223 (or false false)))
(let (($x29 (or $x274 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x40 (or $x29 $x223 (or (and (distinct (bvadd ((_ sign_extend 1) ?x6) ((_ sign_extend 1) ?x309)) ?x148) true)))))
(let (($x158 (not $x40)))
(and $x158 (or $x446 (and (distinct ?x46 ?x294) true))))))))))))))))
(check-sat)
; query 18: function main, block 74, name %78
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x309 ((_ sign_extend 24) in57_8)))
(let ((?x6 (bvshl in.01_32 (_ bv4 32))))
(let ((?x46 (bvadd ?x6 ?x309)))
(let ((?x559 (bvsub ?x46 (_ bv65 32))))
(let (($x223 (or false false)))
(let (($x274 (or false false false)))
(let (($x446 (or $x274 false false)))
(let (($x38 (or $x446 $x223 false)))
(let (($x130 (or $x38 (and (distinct ?x559 (bvadd (bvadd (bvmul in.01_32 (_ bv16 32)) (_ bv4294967241 32)) ?x309)) true))))
(let (($x171 (and (distinct (bvsub ((_ sign_extend 1) ?x46) ((_ sign_extend 1) (_ bv65 32))) ((_ sign_extend 1) ?x559)) true)))
(let ((?x148 ((_ sign_extend 1) ?x46)))
(let (($x29 (or $x274 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x40 (or $x29 $x223 (or (and (distinct (bvadd ((_ sign_extend 1) ?x6) ((_ sign_extend 1) ?x309)) ?x148) true)))))
(and (not (or $x40 false (or $x171))) $x130)))))))))))))))
(check-sat)
