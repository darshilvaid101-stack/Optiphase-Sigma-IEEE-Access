; OptiPhase-Sigma refinement certificate for sweep K06-R4-323
