; OptiPhase-Sigma refinement certificate for sweep K45-R4-338
; query 0: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x306 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x126 (or false false false)))
(let (($x153 (not $x126)))
(and $x153 (or $x126 (and (distinct ?x306 ?x306) true)))))))
(check-sat)
; query 1: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x120 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x126 (or false false false)))
(let (($x153 (not $x126)))
(and $x153 (or $x126 (and (distinct ?x120 ?x120) true)))))))
(check-sat)
