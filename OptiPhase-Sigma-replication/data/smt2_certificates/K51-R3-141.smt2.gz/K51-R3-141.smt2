; OptiPhase-Sigma refinement certificate for sweep K51-R3-141
; query 0: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x1864 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x133 (or false false false)))
(let (($x1658 (not $x133)))
(and $x1658 (or $x133 (and (distinct ?x1864 ?x1864) true)))))))
(check-sat)
; query 1: function s115, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x1728 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x1648 (or false false (or $x1728))))
(and (not $x1648) (or $x1648 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function set1d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x475 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x133 (or false false false)))
(let (($x1658 (not $x133)))
(and $x1658 (or $x133 (and (distinct ?x475 ?x475) true)))))))
(check-sat)
; query 3: function set1ds, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x1840 (ite (= (_ bv4294967295 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x133 (or false false false)))
(let (($x1658 (not $x133)))
(and $x1658 (or $x133 (and (distinct ?x1840 ?x1840) true)))))))
(check-sat)
; query 4: function set2d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x475 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x133 (or false false false)))
(let (($x1658 (not $x133)))
(and $x1658 (or $x133 (and (distinct ?x475 ?x475) true)))))))
(check-sat)
