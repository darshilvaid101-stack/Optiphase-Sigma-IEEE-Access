; OptiPhase-Sigma refinement certificate for sweep K42-R3-093
; query 0: function sha_transform, block 12, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x148 (and (distinct (bvadd ((_ zero_extend 1) in.01_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x77 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x315 (or (or false false (or $x77 $x148)) (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))
(and (not (or false false (or $x77))) $x315)))))
(check-sat)
; query 1: function sha_transform, block 39, name %40
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x32 (and (distinct (bvadd ((_ zero_extend 1) in.12_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.12_32 (_ bv1 32)))) true)))
(let (($x48 (and (distinct (bvadd ((_ sign_extend 1) in.12_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.12_32 (_ bv1 32)))) true)))
(let (($x74 (or (or false false (or $x48 $x32)) (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))
(and (not (or false false (or $x48))) $x74)))))
(check-sat)
