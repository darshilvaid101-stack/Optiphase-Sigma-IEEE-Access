; OptiPhase-Sigma refinement certificate for sweep K44-R6-008
; query 0: function Index_to_frequency, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x49 (ite (bvuge in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x311 (or false false false)))
(let (($x244 (not $x311)))
(and $x244 (or $x311 (and (distinct ?x49 ?x49) true)))))))
(check-sat)
; query 1: function IsPowerOfTwo, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x311 (or false false false)))
(let (($x244 (not $x311)))
(and $x244 (or $x311 (and (distinct (bvsub in0_32 (_ bv1 32)) (bvsub in0_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function IsPowerOfTwo, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x98 (bvsub in0_32 (_ bv1 32))))
(let ((?x120 (bvand in0_32 ?x98)))
(let (($x311 (or false false false)))
(let (($x428 (or false $x311 false)))
(and (not $x428) (or $x428 (and (distinct ?x120 ?x120) true))))))))
(check-sat)
; query 3: function IsPowerOfTwo, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x405 (ite (and (distinct (_ bv0 32) (bvand in0_32 (bvsub in0_32 (_ bv1 32)))) true) (_ bv1 1) (_ bv0 1))))
(let (($x311 (or false false false)))
(let (($x428 (or false $x311 false)))
(let (($x281 (or $x428 false false)))
(and (not $x281) (or $x281 (and (distinct ?x405 ?x405) true))))))))
(check-sat)
; query 4: function IsPowerOfTwo, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x19 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x311 (or false false false)))
(let (($x244 (not $x311)))
(and $x244 (or $x311 (and (distinct ?x19 ?x19) true)))))))
(check-sat)
; query 5: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x19 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x311 (or false false false)))
(let (($x244 (not $x311)))
(and $x244 (or $x311 (and (distinct ?x19 ?x19) true)))))))
(check-sat)
; query 6: function fft_float, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x450 (ite (and (distinct (_ bv0 32) in1_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x311 (or false false false)))
(let (($x244 (not $x311)))
(and $x244 (or $x311 (and (distinct ?x450 ?x450) true)))))))
(check-sat)
; query 7: function main, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x96 (ite (= (_ bv4 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x311 (or false false false)))
(let (($x244 (not $x311)))
(and $x244 (or $x311 (and (distinct ?x96 ?x96) true)))))))
(check-sat)
; query 8: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x217 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x311 (or false false false)))
(let (($x244 (not $x311)))
(and $x244 (or $x311 (and (distinct ?x217 ?x217) true)))))))
(check-sat)
