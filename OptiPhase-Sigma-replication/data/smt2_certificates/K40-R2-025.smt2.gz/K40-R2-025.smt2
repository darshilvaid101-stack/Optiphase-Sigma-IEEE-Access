; OptiPhase-Sigma refinement certificate for sweep K40-R2-025
; query 0: function decfile, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in17_32 () (_ BitVec 32))
(assert
 (let ((?x170 (ite (and (distinct (_ bv16 32) in17_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x369 (or false false false)))
(let (($x514 (not $x369)))
(and $x514 (or $x369 (and (distinct ?x170 ?x170) true)))))))
(check-sat)
; query 1: function decfile, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x295 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x99 (or false false (or $x295))))
(and (not $x99) (or $x99 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function decfile, block 82, name %83
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x39 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x167 (or false false (or $x39))))
(and (not $x167) (or $x167 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 3: function encfile, block 50, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_64 () (_ BitVec 64))
(assert
 (let (($x369 (or false false false)))
(let (($x514 (not $x369)))
(and $x514 (or $x369 (and (distinct (bvadd in.1_64 (_ bv1 64)) (bvadd in.1_64 (_ bv1 64))) true))))))
(check-sat)
; query 4: function encfile, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_64 () (_ BitVec 64))
(assert
 (let (($x369 (or false false false)))
(let (($x514 (not $x369)))
(and $x514 (or $x369 (and (distinct (bvadd in.2_64 (_ bv1 64)) (bvadd in.2_64 (_ bv1 64))) true))))))
(check-sat)
; query 5: function encfile, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.5_64 () (_ BitVec 64))
(assert
 (let (($x369 (or false false false)))
(let (($x514 (not $x369)))
(and $x514 (or $x369 (and (distinct (bvadd in.5_64 (_ bv1 64)) (bvadd in.5_64 (_ bv1 64))) true))))))
(check-sat)
; query 6: function fillrand, block 34, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x315 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x137 (or false false (or $x315))))
(and (not $x137) (or $x137 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 7: function main, block 41, name %42
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let (($x382 (or false false)))
(and (not $x382) (or $x382 (and (distinct ((_ sign_extend 24) in38_8) ((_ sign_extend 24) in38_8)) true)))))
(check-sat)
; query 8: function main, block 41, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let ((?x533 (ite (bvsge (_ bv57 32) ((_ sign_extend 24) in38_8)) (_ bv1 1) (_ bv0 1))))
(let (($x382 (or false false)))
(let (($x130 (or $x382 false false)))
(let (($x276 (not $x130)))
(and $x276 (or $x130 (and (distinct ?x533 ?x533) true))))))))
(check-sat)
; query 9: function main, block 44, name %45
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x369 (or false false false)))
(let (($x80 (or $x369 (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x80) (or $x80 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvshl in.01_32 (_ bv4 32))) true))))))
(check-sat)
; query 10: function main, block 44, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let (($x382 (or false false)))
(and (not $x382) (or $x382 (and (distinct ((_ sign_extend 24) in38_8) ((_ sign_extend 24) in38_8)) true)))))
(check-sat)
; query 11: function main, block 44, name %47
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x72 ((_ sign_extend 24) in38_8)))
(let ((?x195 (bvshl in.01_32 (_ bv4 32))))
(let ((?x567 (bvadd ?x195 ?x72)))
(let ((?x113 ((_ sign_extend 1) ?x567)))
(let (($x382 (or false false)))
(let (($x369 (or false false false)))
(let (($x80 (or $x369 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x77 (or $x80 $x382 (or (and (distinct (bvadd ((_ sign_extend 1) ?x195) ((_ sign_extend 1) ?x72)) ?x113) true)))))
(and (not $x77) (or $x77 (and (distinct ?x567 ?x567) true))))))))))))
(check-sat)
; query 12: function main, block 44, name %48
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x72 ((_ sign_extend 24) in38_8)))
(let ((?x195 (bvshl in.01_32 (_ bv4 32))))
(let ((?x567 (bvadd ?x195 ?x72)))
(let ((?x96 (bvsub ?x567 (_ bv48 32))))
(let (($x79 (and (distinct (bvsub ((_ sign_extend 1) ?x567) ((_ sign_extend 1) (_ bv48 32))) ((_ sign_extend 1) ?x96)) true)))
(let ((?x113 ((_ sign_extend 1) ?x567)))
(let (($x382 (or false false)))
(let (($x369 (or false false false)))
(let (($x80 (or $x369 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x77 (or $x80 $x382 (or (and (distinct (bvadd ((_ sign_extend 1) ?x195) ((_ sign_extend 1) ?x72)) ?x113) true)))))
(let (($x114 (or $x77 false (or $x79))))
(and (not $x114) (or $x114 (and (distinct ?x96 ?x96) true)))))))))))))))
(check-sat)
; query 13: function main, block 49, name %50
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let (($x382 (or false false)))
(and (not $x382) (or $x382 (and (distinct ((_ sign_extend 24) in38_8) ((_ sign_extend 24) in38_8)) true)))))
(check-sat)
; query 14: function main, block 49, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let ((?x488 (ite (bvsle (_ bv65 32) ((_ sign_extend 24) in38_8)) (_ bv1 1) (_ bv0 1))))
(let (($x382 (or false false)))
(let (($x130 (or $x382 false false)))
(let (($x276 (not $x130)))
(and $x276 (or $x130 (and (distinct ?x488 ?x488) true))))))))
(check-sat)
; query 15: function main, block 52, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let (($x382 (or false false)))
(and (not $x382) (or $x382 (and (distinct ((_ sign_extend 24) in38_8) ((_ sign_extend 24) in38_8)) true)))))
(check-sat)
; query 16: function main, block 52, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let ((?x393 (ite (bvsge (_ bv70 32) ((_ sign_extend 24) in38_8)) (_ bv1 1) (_ bv0 1))))
(let (($x382 (or false false)))
(let (($x130 (or $x382 false false)))
(let (($x276 (not $x130)))
(and $x276 (or $x130 (and (distinct ?x393 ?x393) true))))))))
(check-sat)
; query 17: function main, block 55, name %56
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x369 (or false false false)))
(let (($x80 (or $x369 (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x80) (or $x80 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvshl in.01_32 (_ bv4 32))) true))))))
(check-sat)
; query 18: function main, block 55, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let (($x382 (or false false)))
(and (not $x382) (or $x382 (and (distinct ((_ sign_extend 24) in38_8) ((_ sign_extend 24) in38_8)) true)))))
(check-sat)
; query 19: function main, block 55, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x72 ((_ sign_extend 24) in38_8)))
(let ((?x195 (bvshl in.01_32 (_ bv4 32))))
(let ((?x567 (bvadd ?x195 ?x72)))
(let ((?x113 ((_ sign_extend 1) ?x567)))
(let (($x382 (or false false)))
(let (($x369 (or false false false)))
(let (($x80 (or $x369 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x77 (or $x80 $x382 (or (and (distinct (bvadd ((_ sign_extend 1) ?x195) ((_ sign_extend 1) ?x72)) ?x113) true)))))
(and (not $x77) (or $x77 (and (distinct ?x567 ?x567) true))))))))))))
(check-sat)
; query 20: function main, block 55, name %59
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x72 ((_ sign_extend 24) in38_8)))
(let ((?x195 (bvshl in.01_32 (_ bv4 32))))
(let ((?x567 (bvadd ?x195 ?x72)))
(let ((?x614 (bvsub ?x567 (_ bv65 32))))
(let ((?x182 ((_ sign_extend 1) ?x614)))
(let ((?x113 ((_ sign_extend 1) ?x567)))
(let (($x382 (or false false)))
(let (($x369 (or false false false)))
(let (($x80 (or $x369 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x77 (or $x80 $x382 (or (and (distinct (bvadd ((_ sign_extend 1) ?x195) ((_ sign_extend 1) ?x72)) ?x113) true)))))
(let (($x126 (or $x77 false (or (and (distinct (bvsub ?x113 ((_ sign_extend 1) (_ bv65 32))) ?x182) true)))))
(and (not $x126) (or $x126 (and (distinct ?x614 ?x614) true)))))))))))))))
(check-sat)
; query 21: function main, block 55, name %60
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x72 ((_ sign_extend 24) in38_8)))
(let ((?x195 (bvshl in.01_32 (_ bv4 32))))
(let ((?x567 (bvadd ?x195 ?x72)))
(let ((?x614 (bvsub ?x567 (_ bv65 32))))
(let ((?x23 (bvadd ?x614 (_ bv10 32))))
(let (($x14 (and (distinct (bvadd ((_ sign_extend 1) ?x614) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x23)) true)))
(let ((?x182 ((_ sign_extend 1) ?x614)))
(let ((?x113 ((_ sign_extend 1) ?x567)))
(let (($x382 (or false false)))
(let (($x369 (or false false false)))
(let (($x80 (or $x369 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x77 (or $x80 $x382 (or (and (distinct (bvadd ((_ sign_extend 1) ?x195) ((_ sign_extend 1) ?x72)) ?x113) true)))))
(let (($x126 (or $x77 false (or (and (distinct (bvsub ?x113 ((_ sign_extend 1) (_ bv65 32))) ?x182) true)))))
(let (($x159 (or $x126 false (or $x14))))
(and (not $x159) (or $x159 (and (distinct ?x23 ?x23) true))))))))))))))))))
(check-sat)
; query 22: function main, block 81, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x588 (ite (bvsgt (_ bv32 32) in.06.lcssa_32) (_ bv1 1) (_ bv0 1))))
(let (($x369 (or false false false)))
(let (($x514 (not $x369)))
(and $x514 (or $x369 (and (distinct ?x588 ?x588) true)))))))
(check-sat)
; query 23: function main, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06.lcssa_32 () (_ BitVec 32))
(assert
 (let (($x369 (or false false false)))
(let (($x44 (or $x369 (and (distinct (bvand in.06.lcssa_32 (_ bv15 32)) (bvand in.06.lcssa_32 (_ bv15 32))) true))))
(let (($x514 (not $x369)))
(and $x514 $x44)))))
(check-sat)
; query 24: function main, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x900 (ite (and (distinct (_ bv0 32) (bvand in.06.lcssa_32 (_ bv15 32))) true) (_ bv1 1) (_ bv0 1))))
(let (($x369 (or false false false)))
(let (($x36 (or $x369 false false)))
(let (($x591 (not $x36)))
(and $x591 (or $x36 (and (distinct ?x900 ?x900) true))))))))
(check-sat)
; query 25: function set_key, block 11, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let (($x369 (or false false false)))
(let (($x514 (not $x369)))
(and $x514 (or $x369 (and (distinct (bvand in2_32 (_ bv1 32)) (bvand in2_32 (_ bv1 32))) true))))))
(check-sat)
; query 26: function set_key, block 11, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x629 (ite (and (distinct (_ bv0 32) (bvand in2_32 (_ bv1 32))) true) (_ bv1 1) (_ bv0 1))))
(let (($x369 (or false false false)))
(let (($x36 (or $x369 false false)))
(let (($x591 (not $x36)))
(and $x591 (or $x36 (and (distinct ?x629 ?x629) true))))))))
(check-sat)
; query 27: function set_key, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let (($x369 (or false false false)))
(let (($x514 (not $x369)))
(and $x514 (or $x369 (and (distinct (bvand in2_32 (_ bv2 32)) (bvand in2_32 (_ bv2 32))) true))))))
(check-sat)
; query 28: function set_key, block 14, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x142 (ite (and (distinct (_ bv0 32) (bvand in2_32 (_ bv2 32))) true) (_ bv1 1) (_ bv0 1))))
(let (($x369 (or false false false)))
(let (($x36 (or $x369 false false)))
(let (($x591 (not $x36)))
(and $x591 (or $x36 (and (distinct ?x142 ?x142) true))))))))
(check-sat)
; query 29: function set_key, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x376 (ite (and (distinct (_ bv0 64) in1_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x369 (or false false false)))
(let (($x514 (not $x369)))
(and $x514 (or $x369 (and (distinct ?x376 ?x376) true)))))))
(check-sat)
; query 30: function set_key, block 514, name %515
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_64 () (_ BitVec 64))
(assert
 (let (($x369 (or false false false)))
(let (($x514 (not $x369)))
(and $x514 (or $x369 (and (distinct (bvadd in.01_64 (_ bv1 64)) (bvadd in.01_64 (_ bv1 64))) true))))))
(check-sat)
; query 31: function set_key, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x122 (ite (bvult in1_64 (_ bv16 64)) (_ bv1 1) (_ bv0 1))))
(let (($x369 (or false false false)))
(let (($x514 (not $x369)))
(and $x514 (or $x369 (and (distinct ?x122 ?x122) true)))))))
(check-sat)
; query 32: function set_key, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x420 (ite (bvugt in1_64 (_ bv32 64)) (_ bv1 1) (_ bv0 1))))
(let (($x369 (or false false false)))
(let (($x514 (not $x369)))
(and $x514 (or $x369 (and (distinct ?x420 ?x420) true)))))))
(check-sat)
; query 33: function set_key, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let (($x369 (or false false false)))
(let (($x514 (not $x369)))
(and $x514 (or $x369 (and (distinct (bvand in1_64 (_ bv7 64)) (bvand in1_64 (_ bv7 64))) true))))))
(check-sat)
; query 34: function set_key, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x476 (ite (and (distinct (_ bv0 64) (bvand in1_64 (_ bv7 64))) true) (_ bv1 1) (_ bv0 1))))
(let (($x369 (or false false false)))
(let (($x36 (or $x369 false false)))
(let (($x591 (not $x36)))
(and $x591 (or $x36 (and (distinct ?x476 ?x476) true))))))))
(check-sat)
