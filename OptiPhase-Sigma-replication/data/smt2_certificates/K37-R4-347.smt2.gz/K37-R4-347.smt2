; OptiPhase-Sigma refinement certificate for sweep K37-R4-347
