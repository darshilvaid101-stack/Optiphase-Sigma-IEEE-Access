; OptiPhase-Sigma refinement certificate for sweep K38-R5-379
; query 0: function BF_ofb64_encrypt, block 82, name %83
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x89 (ite (= (_ bv0 32) in.04_32) (_ bv1 1) (_ bv0 1))))
(let (($x369 (or false false false)))
(and (not $x369) (or $x369 (and (distinct ?x89 ?x89) true))))))
(check-sat)
