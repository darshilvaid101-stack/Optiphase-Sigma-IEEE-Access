; OptiPhase-Sigma refinement certificate for sweep K44-R4-333
; query 0: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x227 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x316 (or false false false)))
(let (($x169 (not $x316)))
(and $x169 (or $x316 (and (distinct ?x227 ?x227) true)))))))
(check-sat)
; query 1: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x126 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x316 (or false false false)))
(let (($x169 (not $x316)))
(and $x169 (or $x316 (and (distinct ?x126 ?x126) true)))))))
(check-sat)
