; OptiPhase-Sigma refinement certificate for sweep K54-R6-048
; query 0: function check, block 103, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x395 (ite (= (_ bv22 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x1335 (or false false false)))
(let (($x518 (not $x1335)))
(and $x518 (or $x1335 (and (distinct ?x395 (ite (= (_ bv0 32) in0_32) (_ bv1 1) (_ bv0 1))) true)))))))
(check-sat)
; query 1: function check, block 109, name %110
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x1376 (ite (= (_ bv33 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x1335 (or false false false)))
(let (($x518 (not $x1335)))
(and $x518 (or $x1335 (and (distinct ?x1376 (ite (= (_ bv12 32) in0_32) (_ bv1 1) (_ bv0 1))) true)))))))
(check-sat)
; query 2: function check, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x461 (ite (= (_ bv4 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x1335 (or false false false)))
(let (($x518 (not $x1335)))
(and $x518 (or $x1335 (and (distinct (ite (= (_ bv2 32) in0_32) (_ bv1 1) (_ bv0 1)) ?x461) true)))))))
(check-sat)
; query 3: function check, block 79, name %80
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x462 (ite (= (_ bv5 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x1335 (or false false false)))
(let (($x518 (not $x1335)))
(and $x518 (or $x1335 (and (distinct (ite (= (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1)) ?x462) true)))))))
(check-sat)
; query 4: function check, block 85, name %86
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x551 (ite (= (_ bv11 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let ((?x461 (ite (= (_ bv4 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x1335 (or false false false)))
(let (($x518 (not $x1335)))
(and $x518 (or $x1335 (and (distinct ?x461 ?x551) true))))))))
(check-sat)
; query 5: function check, block 91, name %92
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x395 (ite (= (_ bv22 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let ((?x462 (ite (= (_ bv5 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x1335 (or false false false)))
(let (($x518 (not $x1335)))
(and $x518 (or $x1335 (and (distinct ?x462 ?x395) true))))))))
(check-sat)
; query 6: function check, block 97, name %98
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x1376 (ite (= (_ bv33 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let ((?x551 (ite (= (_ bv11 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x1335 (or false false false)))
(let (($x518 (not $x1335)))
(and $x518 (or $x1335 (and (distinct ?x551 ?x1376) true))))))))
(check-sat)
; query 7: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x119 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x1335 (or false false false)))
(let (($x518 (not $x1335)))
(and $x518 (or $x1335 (and (distinct ?x119 ?x119) true)))))))
(check-sat)
; query 8: function set1d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x591 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x1335 (or false false false)))
(let (($x518 (not $x1335)))
(and $x518 (or $x1335 (and (distinct ?x591 ?x591) true)))))))
(check-sat)
; query 9: function set1ds, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x130 (ite (= (_ bv4294967295 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x1335 (or false false false)))
(let (($x518 (not $x1335)))
(and $x518 (or $x1335 (and (distinct ?x130 ?x130) true)))))))
(check-sat)
; query 10: function set2d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x591 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x1335 (or false false false)))
(let (($x518 (not $x1335)))
(and $x518 (or $x1335 (and (distinct ?x591 ?x591) true)))))))
(check-sat)
