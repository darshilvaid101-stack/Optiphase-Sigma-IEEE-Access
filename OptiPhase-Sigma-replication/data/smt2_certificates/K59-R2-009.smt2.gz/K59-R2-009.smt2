; OptiPhase-Sigma refinement certificate for sweep K59-R2-009
; query 0: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x3943 (or false false)))
(let (($x757 (not $x3943)))
(and $x757 (or $x3943 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 1: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x290 ((_ sign_extend 16) in3_16)))
(let ((?x472 (bvand ?x290 (_ bv127 32))))
(let (($x3943 (or false false)))
(let (($x365 (or $x3943 false false)))
(let (($x50 (not $x365)))
(and $x50 (or $x365 (and (distinct ?x472 ?x472) true)))))))))
(check-sat)
; query 2: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x290 ((_ sign_extend 16) in3_16)))
(let ((?x472 (bvand ?x290 (_ bv127 32))))
(let ((?x385 ((_ extract 15 0) ?x472)))
(let (($x3943 (or false false)))
(let (($x365 (or $x3943 false false)))
(let (($x298 (or $x365 false)))
(let (($x232 (not $x298)))
(and $x232 (or $x298 (and (distinct ?x385 ?x385) true)))))))))))
(check-sat)
; query 3: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x3943 (or false false)))
(let (($x757 (not $x3943)))
(and $x757 (or $x3943 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 4: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x3111 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x3943 (or false false)))
(let (($x365 (or $x3943 false false)))
(let (($x50 (not $x365)))
(and $x50 (or $x365 (and (distinct ?x3111 ?x3111) true))))))))
(check-sat)
; query 5: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x3118 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x35 (or false false false)))
(let (($x728 (not $x35)))
(and $x728 (or $x35 (and (distinct ?x3118 ?x3118) true)))))))
(check-sat)
; query 6: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x3662 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x35 (or false false false)))
(let (($x728 (not $x35)))
(and $x728 (or $x35 (and (distinct ?x3662 ?x3662) true)))))))
(check-sat)
; query 7: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x35 (or false false false)))
(let (($x728 (not $x35)))
(and $x728 (or $x35 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 8: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x367 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x364 (or false false (or $x367))))
(and (not $x364) (or $x364 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 9: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x536 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x349 ((_ zero_extend 31) ?x536)))
(let ((?x779 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x112 ((_ zero_extend 31) ?x779)))
(let ((?x76 (bvand ?x112 ?x349)))
(let ((?x310 (ite (and (distinct (_ bv0 32) ?x76) true) (_ bv1 1) (_ bv0 1))))
(let ((?x56 ((_ zero_extend 63) ?x310)))
(let (($x3943 (or false false)))
(let (($x365 (or $x3943 false false)))
(let (($x298 (or $x365 false)))
(let (($x12 (or $x298 $x298 false)))
(let (($x180 (or $x12 false false)))
(let (($x443 (or $x180 false)))
(and (not $x443) (or $x443 (and (distinct ?x56 ?x56) true)))))))))))))))))
(check-sat)
; query 10: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x536 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x349 ((_ zero_extend 31) ?x536)))
(let ((?x779 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x112 ((_ zero_extend 31) ?x779)))
(let ((?x76 (bvand ?x112 ?x349)))
(let ((?x310 (ite (and (distinct (_ bv0 32) ?x76) true) (_ bv1 1) (_ bv0 1))))
(let (($x871 (= (_ bv1 1) ?x310)))
(let ((?x96 (ite $x871 (_ bv1 32) (_ bv0 32))))
(let (($x3943 (or false false)))
(let (($x365 (or $x3943 false false)))
(let (($x298 (or $x365 false)))
(let (($x12 (or $x298 $x298 false)))
(let (($x180 (or $x12 false false)))
(let (($x275 (or $x180 (ite $x871 false false))))
(and (not $x275) (or $x275 (and (distinct ?x96 ?x96) true))))))))))))))))))
(check-sat)
; query 11: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x536 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x349 ((_ zero_extend 31) ?x536)))
(let ((?x779 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x112 ((_ zero_extend 31) ?x779)))
(let ((?x76 (bvand ?x112 ?x349)))
(let ((?x310 (ite (and (distinct (_ bv0 32) ?x76) true) (_ bv1 1) (_ bv0 1))))
(let (($x871 (= (_ bv1 1) ?x310)))
(let ((?x96 (ite $x871 (_ bv1 32) (_ bv0 32))))
(let ((?x155 ((_ extract 7 0) ?x96)))
(let (($x3943 (or false false)))
(let (($x365 (or $x3943 false false)))
(let (($x298 (or $x365 false)))
(let (($x12 (or $x298 $x298 false)))
(let (($x180 (or $x12 false false)))
(let (($x275 (or $x180 (ite $x871 false false))))
(let (($x85 (or $x275 false)))
(and (not $x85) (or $x85 (and (distinct ?x155 ?x155) true))))))))))))))))))))
(check-sat)
; query 12: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x3943 (or false false)))
(let (($x757 (not $x3943)))
(and $x757 (or $x3943 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 13: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x779 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x3943 (or false false)))
(let (($x365 (or $x3943 false false)))
(let (($x50 (not $x365)))
(and $x50 (or $x365 (and (distinct ?x779 ?x779) true))))))))
(check-sat)
; query 14: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x779 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x112 ((_ zero_extend 31) ?x779)))
(let (($x3943 (or false false)))
(let (($x365 (or $x3943 false false)))
(let (($x298 (or $x365 false)))
(let (($x232 (not $x298)))
(and $x232 (or $x298 (and (distinct ?x112 ?x112) true))))))))))
(check-sat)
; query 15: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x3943 (or false false)))
(let (($x757 (not $x3943)))
(and $x757 (or $x3943 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 16: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x536 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x3943 (or false false)))
(let (($x365 (or $x3943 false false)))
(let (($x50 (not $x365)))
(and $x50 (or $x365 (and (distinct ?x536 ?x536) true))))))))
(check-sat)
; query 17: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x536 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x349 ((_ zero_extend 31) ?x536)))
(let (($x3943 (or false false)))
(let (($x365 (or $x3943 false false)))
(let (($x298 (or $x365 false)))
(let (($x232 (not $x298)))
(and $x232 (or $x298 (and (distinct ?x349 ?x349) true))))))))))
(check-sat)
; query 18: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x536 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x349 ((_ zero_extend 31) ?x536)))
(let ((?x779 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x112 ((_ zero_extend 31) ?x779)))
(let ((?x76 (bvand ?x112 ?x349)))
(let (($x3943 (or false false)))
(let (($x365 (or $x3943 false false)))
(let (($x298 (or $x365 false)))
(let (($x12 (or $x298 $x298 false)))
(and (not $x12) (or $x12 (and (distinct ?x76 ?x76) true)))))))))))))
(check-sat)
; query 19: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x536 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x349 ((_ zero_extend 31) ?x536)))
(let ((?x779 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x112 ((_ zero_extend 31) ?x779)))
(let ((?x76 (bvand ?x112 ?x349)))
(let ((?x310 (ite (and (distinct (_ bv0 32) ?x76) true) (_ bv1 1) (_ bv0 1))))
(let (($x3943 (or false false)))
(let (($x365 (or $x3943 false false)))
(let (($x298 (or $x365 false)))
(let (($x12 (or $x298 $x298 false)))
(let (($x180 (or $x12 false false)))
(and (not $x180) (or $x180 (and (distinct ?x310 ?x310) true)))))))))))))))
(check-sat)
; query 20: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x293 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x35 (or false false false)))
(let (($x728 (not $x35)))
(and $x728 (or $x35 (and (distinct ?x293 ?x293) true)))))))
(check-sat)
