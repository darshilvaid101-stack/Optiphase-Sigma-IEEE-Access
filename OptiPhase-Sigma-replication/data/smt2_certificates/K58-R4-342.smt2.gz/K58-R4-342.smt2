; OptiPhase-Sigma refinement certificate for sweep K58-R4-342
; query 0: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x701 (or false false false)))
(let (($x86 (not $x701)))
(and $x86 (or $x701 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 1: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1536 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x701 (or false false false)))
(let (($x86 (not $x701)))
(and $x86 (or $x701 (and (distinct ?x1536 ?x1536) true)))))))
(check-sat)
