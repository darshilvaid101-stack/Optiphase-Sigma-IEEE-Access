; OptiPhase-Sigma refinement certificate for sweep K49-R3-278
; query 0: function APCM_inverse_quantization, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x225 (or false false)))
(let (($x451 (not $x225)))
(and $x451 (or $x225 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 1: function APCM_inverse_quantization, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x655 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x225 (or false false)))
(let (($x547 (or $x225 false false)))
(let (($x385 (not $x547)))
(and $x385 (or $x547 (and (distinct ?x655 ?x655) true))))))))
(check-sat)
; query 2: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x225 (or false false)))
(let (($x451 (not $x225)))
(and $x451 (or $x225 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 3: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x368 (ite (bvslt (_ bv15 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x225 (or false false)))
(let (($x547 (or $x225 false false)))
(let (($x385 (not $x547)))
(and $x385 (or $x547 (and (distinct ?x368 ?x368) true))))))))
(check-sat)
; query 4: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x225 (or false false)))
(let (($x451 (not $x225)))
(and $x451 (or $x225 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 5: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x111 (ite (bvsgt (_ bv40 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x225 (or false false)))
(let (($x547 (or $x225 false false)))
(let (($x385 (not $x547)))
(and $x385 (or $x547 (and (distinct ?x111 ?x111) true))))))))
(check-sat)
; query 6: function RPE_grid_positioning, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x225 (or false false)))
(let (($x451 (not $x225)))
(and $x451 (or $x225 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 7: function RPE_grid_positioning, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x239 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x876 (and (distinct ?x239 ?x239) true)))
(let (($x225 (or false false)))
(let (($x215 (or false $x225 false)))
(and (not $x215) (or $x215 $x876)))))))
(check-sat)
; query 8: function gsm_L_add, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x115 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false false)))
(let (($x168 (not $x187)))
(and $x168 (or $x187 (and (distinct ?x115 ?x115) true)))))))
(check-sat)
; query 9: function gsm_L_add, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let (($x397 (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) in0_64)) ((_ sign_extend 1) (bvadd in1_64 in0_64))) true)))
(let (($x372 (or (or false false (or $x397)) (and (distinct (bvadd in0_64 in1_64) (bvadd in1_64 in0_64)) true))))
(let (($x347 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvadd in0_64 in1_64))) true)))
(and (not (or false false (or $x347))) $x372)))))
(check-sat)
; query 10: function gsm_L_add, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x112 (bvadd in0_64 (_ bv1 64))))
(let ((?x7 (bvsub (_ bv0 64) ?x112)))
(let (($x69 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x112)) ((_ sign_extend 1) ?x7)) true)))
(let ((?x151 ((_ sign_extend 1) ?x112)))
(let (($x31 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x151) true)))))
(let (($x56 (or false $x31 (or $x69))))
(and (not $x56) (or $x56 (and (distinct ?x7 ?x7) true))))))))))
(check-sat)
; query 11: function gsm_L_add, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x51 (bvadd in1_64 (_ bv1 64))))
(let ((?x371 ((_ sign_extend 1) ?x51)))
(let (($x116 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x371) true)))))
(and (not $x116) (or $x116 (and (distinct ?x51 ?x51) true)))))))
(check-sat)
; query 12: function gsm_L_add, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x51 (bvadd in1_64 (_ bv1 64))))
(let ((?x157 (bvsub (_ bv0 64) ?x51)))
(let (($x15 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x51)) ((_ sign_extend 1) ?x157)) true)))
(let ((?x371 ((_ sign_extend 1) ?x51)))
(let (($x116 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x371) true)))))
(let (($x32 (or false $x116 (or $x15))))
(and (not $x32) (or $x32 (and (distinct ?x157 ?x157) true))))))))))
(check-sat)
; query 13: function gsm_L_add, block 8, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x112 (bvadd in0_64 (_ bv1 64))))
(let ((?x7 (bvsub (_ bv0 64) ?x112)))
(let ((?x51 (bvadd in1_64 (_ bv1 64))))
(let ((?x157 (bvsub (_ bv0 64) ?x51)))
(let ((?x16 (bvadd ?x157 ?x7)))
(let ((?x11 (bvadd ?x7 ?x157)))
(let (($x69 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x112)) ((_ sign_extend 1) ?x7)) true)))
(let ((?x151 ((_ sign_extend 1) ?x112)))
(let (($x31 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x151) true)))))
(let (($x56 (or false $x31 (or $x69))))
(let (($x15 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x51)) ((_ sign_extend 1) ?x157)) true)))
(let ((?x371 ((_ sign_extend 1) ?x51)))
(let (($x116 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x371) true)))))
(let (($x32 (or false $x116 (or $x15))))
(let (($x675 (or $x32 $x56 false)))
(and (not (or $x56 $x32 false)) (or $x675 (and (distinct ?x11 ?x16) true)))))))))))))))))))
(check-sat)
; query 14: function gsm_L_add, block 8, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x112 (bvadd in0_64 (_ bv1 64))))
(let ((?x7 (bvsub (_ bv0 64) ?x112)))
(let ((?x51 (bvadd in1_64 (_ bv1 64))))
(let ((?x157 (bvsub (_ bv0 64) ?x51)))
(let ((?x16 (bvadd ?x157 ?x7)))
(let (($x22 (and (distinct (ite (bvuge (bvadd ?x7 ?x157) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1)) (ite (bvuge ?x16 (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))) true)))
(let (($x69 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x112)) ((_ sign_extend 1) ?x7)) true)))
(let ((?x151 ((_ sign_extend 1) ?x112)))
(let (($x31 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x151) true)))))
(let (($x56 (or false $x31 (or $x69))))
(let (($x15 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x51)) ((_ sign_extend 1) ?x157)) true)))
(let ((?x371 ((_ sign_extend 1) ?x51)))
(let (($x116 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x371) true)))))
(let (($x32 (or false $x116 (or $x15))))
(let (($x675 (or $x32 $x56 false)))
(and (not (or (or $x56 $x32 false) false false)) (or (or $x675 false false) $x22))))))))))))))))))
(check-sat)
; query 15: function gsm_L_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x112 (bvadd in0_64 (_ bv1 64))))
(let ((?x151 ((_ sign_extend 1) ?x112)))
(let (($x31 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x151) true)))))
(and (not $x31) (or $x31 (and (distinct ?x112 ?x112) true)))))))
(check-sat)
; query 16: function gsm_L_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x13 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false false)))
(let (($x168 (not $x187)))
(and $x168 (or $x187 (and (distinct ?x13 ?x13) true)))))))
(check-sat)
; query 17: function gsm_L_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x350 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false false)))
(let (($x168 (not $x187)))
(and $x168 (or $x187 (and (distinct ?x350 ?x350) true)))))))
(check-sat)
; query 18: function gsm_L_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x13 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false false)))
(let (($x168 (not $x187)))
(and $x168 (or $x187 (and (distinct ?x13 ?x13) true)))))))
(check-sat)
; query 19: function gsm_L_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x13 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x334 ((_ zero_extend 31) ?x13)))
(let (($x187 (or false false false)))
(let (($x59 (or $x187 false)))
(and (not $x59) (or $x59 (and (distinct ?x334 ?x334) true))))))))
(check-sat)
; query 20: function gsm_L_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x13 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x334 ((_ zero_extend 31) ?x13)))
(let ((?x82 (bvsub (_ bv0 32) ?x334)))
(let (($x34 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x334)) ((_ sign_extend 1) ?x82)) true)))
(let (($x187 (or false false false)))
(let (($x59 (or $x187 false)))
(let (($x18 (or false $x59 (or $x34))))
(and (not $x18) (or $x18 (and (distinct ?x82 ?x82) true)))))))))))
(check-sat)
; query 21: function gsm_L_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x13 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x334 ((_ zero_extend 31) ?x13)))
(let ((?x82 (bvsub (_ bv0 32) ?x334)))
(let ((?x185 ((_ sign_extend 32) ?x82)))
(let (($x34 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x334)) ((_ sign_extend 1) ?x82)) true)))
(let (($x187 (or false false false)))
(let (($x59 (or $x187 false)))
(let (($x18 (or false $x59 (or $x34))))
(let (($x263 (or $x18 false)))
(and (not $x263) (or $x263 (and (distinct ?x185 ?x185) true)))))))))))))
(check-sat)
; query 22: function gsm_L_asr, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x124 (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false false)))
(let (($x168 (not $x187)))
(and $x168 (or $x187 (and (distinct ?x124 ?x124) true)))))))
(check-sat)
; query 23: function gsm_L_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x350 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false false)))
(let (($x168 (not $x187)))
(and $x168 (or $x187 (and (distinct ?x350 ?x350) true)))))))
(check-sat)
; query 24: function gsm_L_sub, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x115 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false false)))
(let (($x168 (not $x187)))
(and $x168 (or $x187 (and (distinct ?x115 ?x115) true)))))))
(check-sat)
; query 25: function gsm_L_sub, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x261 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvsub in0_64 in1_64))) true)))
(let (($x213 (or false false (or $x261))))
(let (($x30 (or $x213 (and (distinct (bvsub in0_64 in1_64) (bvsub in0_64 in1_64)) true))))
(and (not $x213) $x30)))))
(check-sat)
; query 26: function gsm_L_sub, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x51 (bvadd in1_64 (_ bv1 64))))
(let ((?x157 (bvsub (_ bv0 64) ?x51)))
(let (($x15 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x51)) ((_ sign_extend 1) ?x157)) true)))
(let ((?x371 ((_ sign_extend 1) ?x51)))
(let (($x116 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x371) true)))))
(let (($x32 (or false $x116 (or $x15))))
(and (not $x32) (or $x32 (and (distinct ?x157 ?x157) true))))))))))
(check-sat)
; query 27: function gsm_L_sub, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x51 (bvadd in1_64 (_ bv1 64))))
(let ((?x157 (bvsub (_ bv0 64) ?x51)))
(let ((?x429 (bvadd ?x157 in0_64)))
(let ((?x290 (bvadd in0_64 ?x157)))
(let (($x15 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x51)) ((_ sign_extend 1) ?x157)) true)))
(let ((?x371 ((_ sign_extend 1) ?x51)))
(let (($x116 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x371) true)))))
(let (($x32 (or false $x116 (or $x15))))
(let (($x648 (or $x32 false false)))
(and (not (or false $x32 false)) (or $x648 (and (distinct ?x290 ?x429) true)))))))))))))
(check-sat)
; query 28: function gsm_L_sub, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x345 (ite (bvuge (bvadd (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64))) in0_64) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let ((?x356 (ite (bvuge (bvadd in0_64 (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64)))) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x15 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) (bvadd in1_64 (_ bv1 64)))) ((_ sign_extend 1) (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64))))) true)))
(let ((?x51 (bvadd in1_64 (_ bv1 64))))
(let ((?x371 ((_ sign_extend 1) ?x51)))
(let (($x116 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x371) true)))))
(let (($x32 (or false $x116 (or $x15))))
(let (($x648 (or $x32 false false)))
(and (not (or (or false $x32 false) false false)) (or (or $x648 false false) (and (distinct ?x356 ?x345) true))))))))))))
(check-sat)
; query 29: function gsm_L_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x51 (bvadd in1_64 (_ bv1 64))))
(let ((?x371 ((_ sign_extend 1) ?x51)))
(let (($x116 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x371) true)))))
(and (not $x116) (or $x116 (and (distinct ?x51 ?x51) true)))))))
(check-sat)
; query 30: function gsm_L_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x253 (ite (bvsle (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false false)))
(let (($x168 (not $x187)))
(and $x168 (or $x187 (and (distinct ?x253 ?x253) true)))))))
(check-sat)
; query 31: function gsm_abs, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x225 (or false false)))
(let (($x451 (not $x225)))
(and $x451 (or $x225 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 32: function gsm_abs, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x298 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x225 (or false false)))
(let (($x547 (or $x225 false false)))
(let (($x385 (not $x547)))
(and $x385 (or $x547 (and (distinct ?x298 ?x298) true))))))))
(check-sat)
; query 33: function gsm_abs, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x225 (or false false)))
(let (($x451 (not $x225)))
(and $x451 (or $x225 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 34: function gsm_abs, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x590 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x225 (or false false)))
(let (($x547 (or $x225 false false)))
(let (($x385 (not $x547)))
(and $x385 (or $x547 (and (distinct ?x590 ?x590) true))))))))
(check-sat)
; query 35: function gsm_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x225 (or false false)))
(let (($x451 (not $x225)))
(and $x451 (or $x225 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 36: function gsm_add, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x225 (or false false)))
(let (($x451 (not $x225)))
(and $x451 (or $x225 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 37: function gsm_add, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x88 ((_ sign_extend 48) in0_16)))
(let ((?x602 ((_ sign_extend 48) in1_16)))
(let ((?x351 (bvadd ?x602 ?x88)))
(let ((?x122 (bvadd ?x88 ?x602)))
(let (($x566 (and (distinct (bvadd ((_ sign_extend 1) ?x602) ((_ sign_extend 1) ?x88)) ((_ sign_extend 1) ?x351)) true)))
(let (($x225 (or false false)))
(let (($x843 (or $x225 $x225 (or $x566))))
(let (($x145 (and (distinct (bvadd ((_ sign_extend 1) ?x88) ((_ sign_extend 1) ?x602)) ((_ sign_extend 1) ?x122)) true)))
(let (($x453 (or $x225 $x225 (or $x145))))
(and (not $x453) (or $x843 (and (distinct ?x122 ?x351) true)))))))))))))
(check-sat)
; query 38: function gsm_add, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x432 (ite (bvsgt (_ bv18446744073709518848 64) (bvadd ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in0_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x466 (ite (bvsgt (_ bv18446744073709518848 64) (bvadd ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x88 ((_ sign_extend 48) in0_16)))
(let ((?x118 ((_ sign_extend 1) ?x88)))
(let ((?x602 ((_ sign_extend 48) in1_16)))
(let ((?x481 ((_ sign_extend 1) ?x602)))
(let (($x225 (or false false)))
(let (($x843 (or $x225 $x225 (or (and (distinct (bvadd ?x481 ?x118) ((_ sign_extend 1) (bvadd ?x602 ?x88))) true)))))
(let (($x453 (or $x225 $x225 (or (and (distinct (bvadd ?x118 ?x481) ((_ sign_extend 1) (bvadd ?x88 ?x602))) true)))))
(and (not (or $x453 false false)) (or (or $x843 false false) (and (distinct ?x466 ?x432) true)))))))))))))
(check-sat)
; query 39: function gsm_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x138 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false false)))
(let (($x168 (not $x187)))
(and $x168 (or $x187 (and (distinct ?x138 ?x138) true)))))))
(check-sat)
; query 40: function gsm_asr, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x621 (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false false)))
(let (($x168 (not $x187)))
(and $x168 (or $x187 (and (distinct ?x621 ?x621) true)))))))
(check-sat)
; query 41: function gsm_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x225 (or false false)))
(let (($x451 (not $x225)))
(and $x451 (or $x225 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 42: function gsm_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x590 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x225 (or false false)))
(let (($x547 (or $x225 false false)))
(let (($x385 (not $x547)))
(and $x385 (or $x547 (and (distinct ?x590 ?x590) true))))))))
(check-sat)
; query 43: function gsm_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x590 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x859 ((_ zero_extend 31) ?x590)))
(let (($x225 (or false false)))
(let (($x547 (or $x225 false false)))
(let (($x77 (or $x547 false)))
(and (not $x77) (or $x77 (and (distinct ?x859 ?x859) true)))))))))
(check-sat)
; query 44: function gsm_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x590 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x859 ((_ zero_extend 31) ?x590)))
(let ((?x269 (bvsub (_ bv0 32) ?x859)))
(let (($x271 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x859)) ((_ sign_extend 1) ?x269)) true)))
(let (($x225 (or false false)))
(let (($x547 (or $x225 false false)))
(let (($x77 (or $x547 false)))
(let (($x70 (or false $x77 (or $x271))))
(and (not $x70) (or $x70 (and (distinct ?x269 ?x269) true))))))))))))
(check-sat)
; query 45: function gsm_asr, block 4, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x590 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x859 ((_ zero_extend 31) ?x590)))
(let ((?x269 (bvsub (_ bv0 32) ?x859)))
(let ((?x369 ((_ extract 15 0) ?x269)))
(let (($x271 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x859)) ((_ sign_extend 1) ?x269)) true)))
(let (($x225 (or false false)))
(let (($x547 (or $x225 false false)))
(let (($x77 (or $x547 false)))
(let (($x70 (or false $x77 (or $x271))))
(let (($x477 (or $x70 false)))
(and (not $x477) (or $x477 (and (distinct ?x369 ?x369) true))))))))))))))
(check-sat)
; query 46: function gsm_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x138 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false false)))
(let (($x168 (not $x187)))
(and $x168 (or $x187 (and (distinct ?x138 ?x138) true)))))))
(check-sat)
; query 47: function gsm_debug_longwords, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in15_32 () (_ BitVec 32))
(assert
 (let ((?x623 (ite (bvslt in15_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false false)))
(let (($x168 (not $x187)))
(and $x168 (or $x187 (and (distinct ?x623 ?x623) true)))))))
(check-sat)
; query 48: function gsm_debug_words, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in16_32 () (_ BitVec 32))
(assert
 (let ((?x495 (ite (bvslt in16_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false false)))
(let (($x168 (not $x187)))
(and $x168 (or $x187 (and (distinct ?x495 ?x495) true)))))))
(check-sat)
; query 49: function gsm_div, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x225 (or false false)))
(let (($x451 (not $x225)))
(and $x451 (or $x225 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 50: function gsm_div, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x225 (or false false)))
(let (($x451 (not $x225)))
(and $x451 (or $x225 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 51: function gsm_div, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x225 (or false false)))
(let (($x451 (not $x225)))
(and $x451 (or $x225 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 52: function gsm_div, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x239 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x876 (and (distinct ?x239 ?x239) true)))
(let (($x225 (or false false)))
(let (($x547 (or $x225 false false)))
(let (($x385 (not $x547)))
(and $x385 (or $x547 $x876))))))))
(check-sat)
; query 53: function gsm_norm, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x13 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false false)))
(let (($x168 (not $x187)))
(and $x168 (or $x187 (and (distinct ?x13 (ite (bvsge (_ bv18446744072635809792 64) in0_64) (_ bv1 1) (_ bv0 1))) true)))))))
(check-sat)
; query 54: function gsm_norm, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x349 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false false)))
(let (($x168 (not $x187)))
(and $x168 (or $x187 (and (distinct ?x349 ?x349) true)))))))
(check-sat)
; query 55: function gsm_norm, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x349 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x919 (bvxor ?x349 (_ bv1 1))))
(let (($x187 (or false false false)))
(let (($x150 (or $x187 false false)))
(and (not $x150) (or $x150 (and (distinct ?x919 ?x919) true))))))))
(check-sat)
; query 56: function gsm_norm, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x349 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x919 (bvxor ?x349 (_ bv1 1))))
(let ((?x803 ((_ zero_extend 31) ?x919)))
(let (($x187 (or false false false)))
(let (($x150 (or $x187 false false)))
(let (($x331 (or $x150 false)))
(and (not $x331) (or $x331 (and (distinct ?x803 ?x803) true))))))))))
(check-sat)
; query 57: function gsm_norm, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x349 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x919 (bvxor ?x349 (_ bv1 1))))
(let ((?x803 ((_ zero_extend 31) ?x919)))
(let ((?x811 ((_ sign_extend 32) ?x803)))
(let (($x187 (or false false false)))
(let (($x150 (or $x187 false false)))
(let (($x331 (or $x150 false)))
(let (($x806 (or $x331 false)))
(and (not $x806) (or $x806 (and (distinct ?x811 ?x811) true))))))))))))
(check-sat)
; query 58: function gsm_norm, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x349 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x919 (bvxor ?x349 (_ bv1 1))))
(let ((?x803 ((_ zero_extend 31) ?x919)))
(let ((?x811 ((_ sign_extend 32) ?x803)))
(let ((?x412 (ite (and (distinct (_ bv0 64) ?x811) true) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false false)))
(let (($x150 (or $x187 false false)))
(let (($x331 (or $x150 false)))
(let (($x806 (or $x331 false)))
(let (($x490 (or $x806 false false)))
(and (not $x490) (or $x490 (and (distinct ?x412 ?x412) true))))))))))))))
(check-sat)
; query 59: function gsm_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x225 (or false false)))
(let (($x451 (not $x225)))
(and $x451 (or $x225 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 60: function gsm_sub, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x225 (or false false)))
(let (($x451 (not $x225)))
(and $x451 (or $x225 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 61: function gsm_sub, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x602 ((_ sign_extend 48) in1_16)))
(let ((?x88 ((_ sign_extend 48) in0_16)))
(let ((?x916 (bvsub ?x88 ?x602)))
(let (($x970 (and (distinct (bvsub ((_ sign_extend 1) ?x88) ((_ sign_extend 1) ?x602)) ((_ sign_extend 1) ?x916)) true)))
(let (($x225 (or false false)))
(let (($x557 (or $x225 $x225 (or $x970))))
(and (not $x557) (or $x557 (and (distinct ?x916 ?x916) true))))))))))
(check-sat)
; query 62: function gsm_sub, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x78 (ite (bvsgt (_ bv18446744073709518848 64) (bvsub ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x602 ((_ sign_extend 48) in1_16)))
(let ((?x481 ((_ sign_extend 1) ?x602)))
(let ((?x88 ((_ sign_extend 48) in0_16)))
(let ((?x118 ((_ sign_extend 1) ?x88)))
(let (($x225 (or false false)))
(let (($x557 (or $x225 $x225 (or (and (distinct (bvsub ?x118 ?x481) ((_ sign_extend 1) (bvsub ?x88 ?x602))) true)))))
(let (($x737 (or $x557 false false)))
(and (not $x737) (or $x737 (and (distinct ?x78 ?x78) true))))))))))))
(check-sat)
; query 63: function process_decode, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let (($x225 (or false false)))
(let (($x451 (not $x225)))
(and $x451 (or $x225 (and (distinct ((_ sign_extend 32) in14_32) ((_ sign_extend 32) in14_32)) true))))))
(check-sat)
; query 64: function process_decode, block 16, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x55 (ite (and (distinct (_ bv33 64) ((_ sign_extend 32) in14_32)) true) (_ bv1 1) (_ bv0 1))))
(let (($x225 (or false false)))
(let (($x547 (or $x225 false false)))
(let (($x385 (not $x547)))
(and $x385 (or $x547 (and (distinct ?x55 ?x55) true))))))))
(check-sat)
; query 65: function process_encode, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_32 () (_ BitVec 32))
(assert
 (let (($x225 (or false false)))
(let (($x451 (not $x225)))
(and $x451 (or $x225 (and (distinct ((_ sign_extend 32) in13_32) ((_ sign_extend 32) in13_32)) true))))))
(check-sat)
; query 66: function process_encode, block 15, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_32 () (_ BitVec 32))
(assert
 (let ((?x728 (ite (bvult ((_ sign_extend 32) in13_32) (_ bv160 64)) (_ bv1 1) (_ bv0 1))))
(let (($x225 (or false false)))
(let (($x547 (or $x225 false false)))
(let (($x385 (not $x547)))
(and $x385 (or $x547 (and (distinct ?x728 ?x728) true))))))))
(check-sat)
