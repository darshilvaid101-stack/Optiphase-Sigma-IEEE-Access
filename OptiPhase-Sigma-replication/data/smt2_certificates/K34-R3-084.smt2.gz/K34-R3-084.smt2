; OptiPhase-Sigma refinement certificate for sweep K34-R3-084
; query 0: function edge_draw, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let ((?x484 (ite (= (_ bv0 32) in4_32) (_ bv1 1) (_ bv0 1))))
(let (($x480 (or false false false)))
(and (not $x480) (or $x480 (and (distinct ?x484 ?x484) true))))))
(check-sat)
