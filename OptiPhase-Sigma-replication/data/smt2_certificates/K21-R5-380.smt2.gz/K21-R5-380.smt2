; OptiPhase-Sigma refinement certificate for sweep K21-R5-380
