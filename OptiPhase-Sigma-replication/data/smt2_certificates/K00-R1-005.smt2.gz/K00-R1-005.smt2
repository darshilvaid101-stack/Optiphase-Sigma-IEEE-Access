; OptiPhase-Sigma refinement certificate for sweep K00-R1-005
