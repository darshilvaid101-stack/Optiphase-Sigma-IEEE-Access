; OptiPhase-Sigma refinement certificate for sweep K50-R3-160
; query 0: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x339 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x58 (or false false false)))
(let (($x1868 (not $x58)))
(and $x1868 (or $x58 (and (distinct ?x339 ?x339) true)))))))
(check-sat)
; query 1: function set1d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x1354 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x58 (or false false false)))
(let (($x1868 (not $x58)))
(and $x1868 (or $x58 (and (distinct ?x1354 ?x1354) true)))))))
(check-sat)
; query 2: function set1ds, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x46 (ite (= (_ bv4294967295 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x58 (or false false false)))
(let (($x1868 (not $x58)))
(and $x1868 (or $x58 (and (distinct ?x46 ?x46) true)))))))
(check-sat)
; query 3: function set2d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x1354 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x58 (or false false false)))
(let (($x1868 (not $x58)))
(and $x1868 (or $x58 (and (distinct ?x1354 ?x1354) true)))))))
(check-sat)
