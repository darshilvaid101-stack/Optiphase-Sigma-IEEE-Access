; OptiPhase-Sigma refinement certificate for sweep K28-R3-223
; query 0: function xmalloc, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in7_32 () (_ BitVec 32))
(assert
 (let ((?x63 (ite (and (distinct (_ bv0 32) in7_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x38 (or false false false)))
(and (not $x38) (or $x38 (and (distinct ?x63 ?x63) true))))))
(check-sat)
