; OptiPhase-Sigma refinement certificate for sweep K45-R4-350
; query 0: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x281 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x104 (or false false false)))
(let (($x249 (not $x104)))
(and $x249 (or $x104 (and (distinct ?x281 ?x281) true)))))))
(check-sat)
; query 1: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x853 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x104 (or false false false)))
(let (($x249 (not $x104)))
(and $x249 (or $x104 (and (distinct ?x853 ?x853) true)))))))
(check-sat)
