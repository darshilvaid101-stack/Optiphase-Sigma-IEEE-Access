; OptiPhase-Sigma refinement certificate for sweep K30-R3-127
; query 0: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x103 (ite (bvsgt (_ bv2 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x447 (or false false false)))
(and (not $x447) (or $x447 (and (distinct ?x103 ?x103) true))))))
(check-sat)
