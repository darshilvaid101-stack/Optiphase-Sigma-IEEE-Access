; OptiPhase-Sigma refinement certificate for sweep K57-R6-031
; query 0: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x721 (or false false false)))
(let (($x33 (not $x721)))
(and $x33 (or $x721 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x805 (bvadd in.01_32 (_ bv1 32))))
(let ((?x362 (bvmul ?x805 ?x805)))
(let (($x721 (or false false false)))
(let (($x63 (or $x721 $x721 false)))
(and (not $x63) (or $x63 (and (distinct ?x362 ?x362) true))))))))
(check-sat)
; query 2: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x539 (and (distinct (bvmul (bvmul (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) (_ bv2 32)) (bvshl (bvmul (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) (_ bv3 32))) true)))
(let (($x721 (or false false false)))
(let (($x63 (or $x721 $x721 false)))
(let (($x343 (or $x63 false false)))
(and (not $x343) (or (or $x343 (bvuge (_ bv3 32) (_ bv32 32))) $x539)))))))
(check-sat)
; query 3: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x113 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x721 (or false false false)))
(let (($x33 (not $x721)))
(and $x33 (or $x721 (and (distinct ?x113 ?x113) true)))))))
(check-sat)
; query 4: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x721 (or false false false)))
(let (($x33 (not $x721)))
(and $x33 (or $x721 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 5: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x2062 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x721 (or false false false)))
(let (($x33 (not $x721)))
(and $x33 (or $x721 (and (distinct ?x2062 ?x2062) true)))))))
(check-sat)
