; OptiPhase-Sigma refinement certificate for sweep K44-R3-172
; query 0: function IsPowerOfTwo, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x152 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x14 (or false false false)))
(let (($x126 (not $x14)))
(and $x126 (or $x14 (and (distinct ?x152 ?x152) true)))))))
(check-sat)
; query 1: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x152 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x14 (or false false false)))
(let (($x126 (not $x14)))
(and $x126 (or $x14 (and (distinct ?x152 ?x152) true)))))))
(check-sat)
; query 2: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x410 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x14 (or false false false)))
(let (($x126 (not $x14)))
(and $x126 (or $x14 (and (distinct ?x410 ?x410) true)))))))
(check-sat)
