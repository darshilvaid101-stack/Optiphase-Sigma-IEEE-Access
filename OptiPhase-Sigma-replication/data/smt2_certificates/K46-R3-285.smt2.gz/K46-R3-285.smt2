; OptiPhase-Sigma refinement certificate for sweep K46-R3-285
; query 0: function adpcm_decoder, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x74 (ite (and (distinct (_ bv0 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x167 (or false false false)))
(let (($x7 (not $x167)))
(and $x7 (or $x167 (and (distinct ?x74 ?x74) true)))))))
(check-sat)
; query 1: function adpcm_decoder, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x167 (or false false false)))
(let (($x7 (not $x167)))
(and $x7 (or $x167 (and (distinct (bvand in.01_32 (_ bv15 32)) (bvand in.01_32 (_ bv15 32))) true))))))
(check-sat)
; query 2: function adpcm_decoder, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.012_32 () (_ BitVec 32))
(declare-fun in42_32 () (_ BitVec 32))
(assert
 (let (($x229 (and (distinct (bvadd ((_ sign_extend 1) in42_32) ((_ sign_extend 1) in.012_32)) ((_ sign_extend 1) (bvadd in42_32 in.012_32))) true)))
(let (($x115 (or false false (or $x229))))
(let (($x27 (or $x115 (and (distinct (bvadd in42_32 in.012_32) (bvadd in42_32 in.012_32)) true))))
(and (not $x115) $x27)))))
(check-sat)
; query 3: function adpcm_decoder, block 50, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.012_32 () (_ BitVec 32))
(assert
 (let (($x167 (or false false false)))
(let (($x17 (or $x167 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x79 (or $x17 (and (distinct (bvashr in.012_32 (_ bv1 32)) (bvashr in.012_32 (_ bv1 32))) true))))
(and (not $x17) $x79)))))
(check-sat)
; query 4: function adpcm_decoder, block 50, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.012_32 () (_ BitVec 32))
(declare-fun in.08_32 () (_ BitVec 32))
(assert
 (let ((?x311 (bvashr in.012_32 (_ bv1 32))))
(let ((?x89 (bvadd in.08_32 ?x311)))
(let (($x77 (and (distinct (bvadd ((_ sign_extend 1) in.08_32) ((_ sign_extend 1) ?x311)) ((_ sign_extend 1) ?x89)) true)))
(let (($x167 (or false false false)))
(let (($x17 (or $x167 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x714 (or false $x17 (or $x77))))
(and (not $x714) (or $x714 (and (distinct ?x89 ?x89) true))))))))))
(check-sat)
; query 5: function adpcm_decoder, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.012_32 () (_ BitVec 32))
(assert
 (let (($x167 (or false false false)))
(let (($x191 (or $x167 (bvuge (_ bv2 32) (_ bv32 32)))))
(let (($x113 (or $x191 (and (distinct (bvashr in.012_32 (_ bv2 32)) (bvashr in.012_32 (_ bv2 32))) true))))
(and (not $x191) $x113)))))
(check-sat)
; query 6: function adpcm_decoder, block 56, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.012_32 () (_ BitVec 32))
(declare-fun in.19_32 () (_ BitVec 32))
(assert
 (let ((?x279 (bvashr in.012_32 (_ bv2 32))))
(let ((?x209 (bvadd in.19_32 ?x279)))
(let (($x224 (and (distinct (bvadd ((_ sign_extend 1) in.19_32) ((_ sign_extend 1) ?x279)) ((_ sign_extend 1) ?x209)) true)))
(let (($x167 (or false false false)))
(let (($x191 (or $x167 (bvuge (_ bv2 32) (_ bv32 32)))))
(let (($x212 (or false $x191 (or $x224))))
(and (not $x212) (or $x212 (and (distinct ?x209 ?x209) true))))))))))
(check-sat)
; query 7: function adpcm_decoder, block 61, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.210_32 () (_ BitVec 32))
(declare-fun in.013_32 () (_ BitVec 32))
(assert
 (let ((?x71 (bvsub in.013_32 in.210_32)))
(let (($x117 (and (distinct (bvsub ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x71)) true)))
(let (($x51 (or false false (or $x117))))
(and (not $x51) (or $x51 (and (distinct ?x71 ?x71) true)))))))
(check-sat)
; query 8: function adpcm_decoder, block 63, name %64
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.013_32 () (_ BitVec 32))
(declare-fun in.210_32 () (_ BitVec 32))
(assert
 (let ((?x67 (bvadd in.210_32 in.013_32)))
(let ((?x14 (bvadd in.013_32 in.210_32)))
(let (($x131 (and (distinct (bvadd ((_ sign_extend 1) in.210_32) ((_ sign_extend 1) in.013_32)) ((_ sign_extend 1) ?x67)) true)))
(let (($x11 (and (distinct (bvadd ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x14)) true)))
(and (not (or false false (or $x11))) (or (or false false (or $x131)) (and (distinct ?x14 ?x67) true))))))))
(check-sat)
; query 9: function adpcm_decoder, block 68, name %69
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.114_32 () (_ BitVec 32))
(assert
 (let ((?x118 (ite (bvsgt (_ bv4294934528 32) in.114_32) (_ bv1 1) (_ bv0 1))))
(let (($x167 (or false false false)))
(let (($x7 (not $x167)))
(and $x7 (or $x167 (and (distinct ?x118 ?x118) true)))))))
(check-sat)
; query 10: function adpcm_decoder, block 78, name %79
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x101 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv4294967295 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv4294967295 32)))) true)))
(let (($x8 (or false false (or $x101))))
(and (not $x8) (or $x8 (and (distinct (bvadd in.02_32 (_ bv4294967295 32)) (bvadd in.02_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 11: function main, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x10 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x167 (or false false false)))
(let (($x7 (not $x167)))
(and $x7 (or $x167 (and (distinct ?x10 ?x10) true)))))))
(check-sat)
