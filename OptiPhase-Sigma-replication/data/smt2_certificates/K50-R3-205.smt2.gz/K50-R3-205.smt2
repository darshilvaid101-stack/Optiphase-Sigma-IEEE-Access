; OptiPhase-Sigma refinement certificate for sweep K50-R3-205
; query 0: function check, block 103, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x218 (ite (= (_ bv22 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x306 (or false false false)))
(let (($x451 (not $x306)))
(and $x451 (or $x306 (and (distinct ?x218 (ite (= (_ bv0 32) in0_32) (_ bv1 1) (_ bv0 1))) true)))))))
(check-sat)
; query 1: function check, block 109, name %110
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x554 (ite (= (_ bv33 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x306 (or false false false)))
(let (($x451 (not $x306)))
(and $x451 (or $x306 (and (distinct ?x554 (ite (= (_ bv12 32) in0_32) (_ bv1 1) (_ bv0 1))) true)))))))
(check-sat)
; query 2: function check, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x281 (ite (= (_ bv4 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x306 (or false false false)))
(let (($x451 (not $x306)))
(and $x451 (or $x306 (and (distinct (ite (= (_ bv2 32) in0_32) (_ bv1 1) (_ bv0 1)) ?x281) true)))))))
(check-sat)
; query 3: function check, block 79, name %80
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x806 (ite (= (_ bv5 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x306 (or false false false)))
(let (($x451 (not $x306)))
(and $x451 (or $x306 (and (distinct (ite (= (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1)) ?x806) true)))))))
(check-sat)
; query 4: function check, block 85, name %86
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x241 (ite (= (_ bv11 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let ((?x281 (ite (= (_ bv4 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x306 (or false false false)))
(let (($x451 (not $x306)))
(and $x451 (or $x306 (and (distinct ?x281 ?x241) true))))))))
(check-sat)
; query 5: function check, block 91, name %92
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x218 (ite (= (_ bv22 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let ((?x806 (ite (= (_ bv5 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x306 (or false false false)))
(let (($x451 (not $x306)))
(and $x451 (or $x306 (and (distinct ?x806 ?x218) true))))))))
(check-sat)
; query 6: function check, block 97, name %98
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x554 (ite (= (_ bv33 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let ((?x241 (ite (= (_ bv11 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x306 (or false false false)))
(let (($x451 (not $x306)))
(and $x451 (or $x306 (and (distinct ?x241 ?x554) true))))))))
(check-sat)
; query 7: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x102 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x306 (or false false false)))
(let (($x451 (not $x306)))
(and $x451 (or $x306 (and (distinct ?x102 ?x102) true)))))))
(check-sat)
; query 8: function s1119, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x564 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x275 (or false false (or $x564))))
(and (not $x275) (or $x275 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 9: function set1d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x153 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x306 (or false false false)))
(let (($x451 (not $x306)))
(and $x451 (or $x306 (and (distinct ?x153 ?x153) true)))))))
(check-sat)
; query 10: function set1ds, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x173 (ite (= (_ bv4294967295 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x306 (or false false false)))
(let (($x451 (not $x306)))
(and $x451 (or $x306 (and (distinct ?x173 ?x173) true)))))))
(check-sat)
; query 11: function set2d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x153 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x306 (or false false false)))
(let (($x451 (not $x306)))
(and $x451 (or $x306 (and (distinct ?x153 ?x153) true)))))))
(check-sat)
