; OptiPhase-Sigma refinement certificate for sweep K03-R3-167
; query 0: function xmalloc, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in7_32 () (_ BitVec 32))
(assert
 (let ((?x14 (ite (and (distinct (_ bv0 32) in7_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x10 (or false false false)))
(and (not $x10) (or $x10 (and (distinct ?x14 ?x14) true))))))
(check-sat)
