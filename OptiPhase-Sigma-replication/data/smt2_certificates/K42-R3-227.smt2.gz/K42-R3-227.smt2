; OptiPhase-Sigma refinement certificate for sweep K42-R3-227
; query 0: function sha_transform, block 12, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x86 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x30 (or false false (or $x86))))
(and (not $x30) (or $x30 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function sha_transform, block 122, name %123
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.4_32 () (_ BitVec 32))
(assert
 (let (($x70 (and (distinct (bvadd ((_ sign_extend 1) in.4_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.4_32 (_ bv1 32)))) true)))
(let (($x275 (or false false (or $x70))))
(and (not $x275) (or $x275 (and (distinct (bvadd in.4_32 (_ bv1 32)) (bvadd in.4_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function sha_transform, block 143, name %144
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.5_32 () (_ BitVec 32))
(assert
 (let (($x31 (and (distinct (bvadd ((_ sign_extend 1) in.5_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.5_32 (_ bv1 32)))) true)))
(let (($x11 (or false false (or $x31))))
(and (not $x11) (or $x11 (and (distinct (bvadd in.5_32 (_ bv1 32)) (bvadd in.5_32 (_ bv1 32))) true))))))
(check-sat)
; query 3: function sha_transform, block 39, name %40
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x235 (and (distinct (bvadd ((_ sign_extend 1) in.12_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.12_32 (_ bv1 32)))) true)))
(let (($x290 (or false false (or $x235))))
(and (not $x290) (or $x290 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 4: function sha_transform, block 77, name %78
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.23_32 () (_ BitVec 32))
(assert
 (let (($x297 (and (distinct (bvadd ((_ sign_extend 1) in.23_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.23_32 (_ bv1 32)))) true)))
(let (($x119 (or false false (or $x297))))
(and (not $x119) (or $x119 (and (distinct (bvadd in.23_32 (_ bv1 32)) (bvadd in.23_32 (_ bv1 32))) true))))))
(check-sat)
; query 5: function sha_transform, block 98, name %99
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.34_32 () (_ BitVec 32))
(assert
 (let (($x111 (and (distinct (bvadd ((_ sign_extend 1) in.34_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.34_32 (_ bv1 32)))) true)))
(let (($x562 (or false false (or $x111))))
(and (not $x562) (or $x562 (and (distinct (bvadd in.34_32 (_ bv1 32)) (bvadd in.34_32 (_ bv1 32))) true))))))
(check-sat)
