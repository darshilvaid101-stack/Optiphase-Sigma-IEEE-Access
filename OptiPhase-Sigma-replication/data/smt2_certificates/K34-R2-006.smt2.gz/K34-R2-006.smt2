; OptiPhase-Sigma refinement certificate for sweep K34-R2-006
; query 0: function corner_draw, block 11, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x339 (ite (= (_ bv0 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x341 (or false false false)))
(let (($x193 (not $x341)))
(and $x193 (or $x341 (and (distinct ?x339 ?x339) true)))))))
(check-sat)
; query 1: function edge_draw, block 39, name %40
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x101 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x497 (or false false (or $x101))))
(and (not $x497) (or $x497 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function edge_draw, block 57, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x522 (and (distinct (bvadd ((_ sign_extend 1) in.12_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.12_32 (_ bv1 32)))) true)))
(let (($x126 (or false false (or $x522))))
(and (not $x126) (or $x126 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 3: function edge_draw, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let ((?x66 (ite (= (_ bv0 32) in4_32) (_ bv1 1) (_ bv0 1))))
(let (($x341 (or false false false)))
(let (($x193 (not $x341)))
(and $x193 (or $x341 (and (distinct ?x66 ?x66) true)))))))
(check-sat)
; query 4: function enlarge, block 106, name %107
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x24 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x133 (or false false (or $x24))))
(and (not $x133) (or $x133 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 5: function enlarge, block 158, name %159
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x102 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x42 (or false false (or $x102))))
(and (not $x42) (or $x42 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 6: function enlarge, block 161, name %162
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let (($x63 (and (distinct (bvadd ((_ sign_extend 1) in.2_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.2_32 (_ bv1 32)))) true)))
(let (($x10 (or false false (or $x63))))
(and (not $x10) (or $x10 (and (distinct (bvadd in.2_32 (_ bv1 32)) (bvadd in.2_32 (_ bv1 32))) true))))))
(check-sat)
; query 7: function enlarge, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x101 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x497 (or false false (or $x101))))
(and (not $x497) (or $x497 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function getint, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x333 (ite (bvsle (_ bv48 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x341 (or false false false)))
(let (($x193 (not $x341)))
(and $x193 (or $x341 (and (distinct ?x333 ?x333) true)))))))
(check-sat)
; query 9: function getint, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x99 (ite (bvsge (_ bv57 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x341 (or false false false)))
(let (($x193 (not $x341)))
(and $x193 (or $x341 (and (distinct ?x99 ?x99) true)))))))
(check-sat)
; query 10: function getint, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in26_32 () (_ BitVec 32))
(assert
 (let ((?x219 (ite (bvsgt (_ bv48 32) in26_32) (_ bv1 1) (_ bv0 1))))
(let (($x341 (or false false false)))
(let (($x193 (not $x341)))
(and $x193 (or $x341 (and (distinct ?x219 ?x219) true)))))))
(check-sat)
; query 11: function getint, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in26_32 () (_ BitVec 32))
(assert
 (let ((?x326 (ite (bvslt (_ bv57 32) in26_32) (_ bv1 1) (_ bv0 1))))
(let (($x341 (or false false false)))
(let (($x193 (not $x341)))
(and $x193 (or $x341 (and (distinct ?x326 ?x326) true)))))))
(check-sat)
; query 12: function getint, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x61 (ite (= (_ bv4294967295 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x341 (or false false false)))
(let (($x193 (not $x341)))
(and $x193 (or $x341 (and (distinct ?x61 ?x61) true)))))))
(check-sat)
; query 13: function int_to_uchar, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_32 () (_ BitVec 32))
(assert
 (let (($x33 (and (distinct (bvadd ((_ sign_extend 1) in.03_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.03_32 (_ bv1 32)))) true)))
(let (($x46 (or false false (or $x33))))
(and (not $x46) (or $x46 (and (distinct (bvadd in.03_32 (_ bv1 32)) (bvadd in.03_32 (_ bv1 32))) true))))))
(check-sat)
; query 14: function int_to_uchar, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.14_32 () (_ BitVec 32))
(assert
 (let (($x77 (and (distinct (bvadd ((_ sign_extend 1) in.14_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.14_32 (_ bv1 32)))) true)))
(let (($x41 (or false false (or $x77))))
(and (not $x41) (or $x41 (and (distinct (bvadd in.14_32 (_ bv1 32)) (bvadd in.14_32 (_ bv1 32))) true))))))
(check-sat)
; query 15: function main, block 129, name %130
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.011.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x190 (ite (and (distinct (_ bv0 32) in.011.lcssa_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x341 (or false false false)))
(let (($x193 (not $x341)))
(and $x193 (or $x341 (and (distinct ?x190 ?x190) true)))))))
(check-sat)
; query 16: function main, block 160, name %161
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x54 (ite (and (distinct (_ bv0 32) in.01.lcssa_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x341 (or false false false)))
(let (($x193 (not $x341)))
(and $x193 (or $x341 (and (distinct ?x54 ?x54) true)))))))
(check-sat)
; query 17: function main, block 35, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x246 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x13 (or false false (or $x246))))
(and (not $x13) (or $x13 (and (distinct (bvadd in.020_32 (_ bv1 32)) (bvadd in.020_32 (_ bv1 32))) true))))))
(check-sat)
; query 18: function main, block 35, name %37
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let ((?x44 (ite (bvsge (bvadd in.020_32 (_ bv1 32)) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x246 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x13 (or false false (or $x246))))
(let (($x124 (or $x13 false false)))
(and (not $x124) (or $x124 (and (distinct ?x44 ?x44) true))))))))
(check-sat)
; query 19: function main, block 49, name %50
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x246 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x13 (or false false (or $x246))))
(and (not $x13) (or $x13 (and (distinct (bvadd in.020_32 (_ bv1 32)) (bvadd in.020_32 (_ bv1 32))) true))))))
(check-sat)
; query 20: function main, block 49, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let ((?x44 (ite (bvsge (bvadd in.020_32 (_ bv1 32)) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x246 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x13 (or false false (or $x246))))
(let (($x124 (or $x13 false false)))
(and (not $x124) (or $x124 (and (distinct ?x44 ?x44) true))))))))
(check-sat)
; query 21: function main, block 66, name %67
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x75 (ite (= (_ bv0 32) in.0.lcssa_32) (_ bv1 1) (_ bv0 1))))
(let (($x341 (or false false false)))
(let (($x193 (not $x341)))
(and $x193 (or $x341 (and (distinct ?x75 ?x75) true)))))))
(check-sat)
; query 22: function main, block 84, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.07.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x155 (ite (and (distinct (_ bv0 32) in.07.lcssa_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x341 (or false false false)))
(let (($x193 (not $x341)))
(and $x193 (or $x341 (and (distinct ?x155 ?x155) true)))))))
(check-sat)
; query 23: function median, block 103, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x102 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x42 (or false false (or $x102))))
(and (not $x42) (or $x42 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 24: function median, block 106, name %107
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x101 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x497 (or false false (or $x101))))
(and (not $x497) (or $x497 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 25: function setup_brightness_lut, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x101 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x497 (or false false (or $x101))))
(and (not $x497) (or $x497 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 26: function susan_corners, block 1066, name %1067
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x102 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x42 (or false false (or $x102))))
(and (not $x42) (or $x42 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 27: function susan_corners, block 1069, name %1070
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x101 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x497 (or false false (or $x101))))
(and (not $x497) (or $x497 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 28: function susan_corners, block 1549, name %1550
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x24 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x133 (or false false (or $x24))))
(and (not $x133) (or $x133 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 29: function susan_corners, block 1552, name %1553
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x522 (and (distinct (bvadd ((_ sign_extend 1) in.12_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.12_32 (_ bv1 32)))) true)))
(let (($x126 (or false false (or $x522))))
(and (not $x126) (or $x126 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 30: function susan_corners, block 845, name %846
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in839_32 () (_ BitVec 32))
(declare-fun in840_32 () (_ BitVec 32))
(assert
 (let ((?x181 (ite (bvslt in840_32 in839_32) (_ bv1 1) (_ bv0 1))))
(let (($x341 (or false false false)))
(let (($x193 (not $x341)))
(and $x193 (or $x341 (and (distinct ?x181 ?x181) true)))))))
(check-sat)
; query 31: function susan_corners_quick, block 1469, name %1470
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x24 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x133 (or false false (or $x24))))
(and (not $x133) (or $x133 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 32: function susan_corners_quick, block 1472, name %1473
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x522 (and (distinct (bvadd ((_ sign_extend 1) in.12_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.12_32 (_ bv1 32)))) true)))
(let (($x126 (or false false (or $x522))))
(and (not $x126) (or $x126 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 33: function susan_corners_quick, block 433, name %434
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x102 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x42 (or false false (or $x102))))
(and (not $x42) (or $x42 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 34: function susan_corners_quick, block 436, name %437
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x101 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x497 (or false false (or $x101))))
(and (not $x497) (or $x497 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 35: function susan_edges, block 1432, name %1433
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1417_32 () (_ BitVec 32))
(assert
 (let ((?x496 (ite (bvslt (_ bv0 32) in1417_32) (_ bv1 1) (_ bv0 1))))
(let (($x341 (or false false false)))
(let (($x193 (not $x341)))
(and $x193 (or $x341 (and (distinct ?x496 ?x496) true)))))))
(check-sat)
; query 36: function susan_edges, block 1486, name %1487
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.116_32 () (_ BitVec 32))
(assert
 (let (($x129 (and (distinct (bvadd ((_ sign_extend 1) in.116_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.116_32 (_ bv1 32)))) true)))
(let (($x145 (or false false (or $x129))))
(and (not $x145) (or $x145 (and (distinct (bvadd in.116_32 (_ bv1 32)) (bvadd in.116_32 (_ bv1 32))) true))))))
(check-sat)
; query 37: function susan_edges, block 1489, name %1490
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.114_32 () (_ BitVec 32))
(assert
 (let (($x834 (and (distinct (bvadd ((_ sign_extend 1) in.114_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.114_32 (_ bv1 32)))) true)))
(let (($x895 (or false false (or $x834))))
(and (not $x895) (or $x895 (and (distinct (bvadd in.114_32 (_ bv1 32)) (bvadd in.114_32 (_ bv1 32))) true))))))
(check-sat)
; query 38: function susan_edges, block 379, name %380
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.015_32 () (_ BitVec 32))
(assert
 (let (($x484 (and (distinct (bvadd ((_ sign_extend 1) in.015_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.015_32 (_ bv1 32)))) true)))
(let (($x613 (or false false (or $x484))))
(and (not $x613) (or $x613 (and (distinct (bvadd in.015_32 (_ bv1 32)) (bvadd in.015_32 (_ bv1 32))) true))))))
(check-sat)
; query 39: function susan_edges, block 382, name %383
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.013_32 () (_ BitVec 32))
(assert
 (let (($x1049 (and (distinct (bvadd ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.013_32 (_ bv1 32)))) true)))
(let (($x384 (or false false (or $x1049))))
(and (not $x384) (or $x384 (and (distinct (bvadd in.013_32 (_ bv1 32)) (bvadd in.013_32 (_ bv1 32))) true))))))
(check-sat)
; query 40: function susan_edges, block 850, name %851
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in834_32 () (_ BitVec 32))
(assert
 (let ((?x867 (ite (= (_ bv0 32) in834_32) (_ bv1 1) (_ bv0 1))))
(let (($x341 (or false false false)))
(let (($x193 (not $x341)))
(and $x193 (or $x341 (and (distinct ?x867 ?x867) true)))))))
(check-sat)
; query 41: function susan_edges, block 870, name %871
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x495 (ite (bvslt (_ bv0 32) in.0_32) (_ bv1 1) (_ bv0 1))))
(let (($x341 (or false false false)))
(let (($x193 (not $x341)))
(and $x193 (or $x341 (and (distinct ?x495 ?x495) true)))))))
(check-sat)
; query 42: function susan_edges_small, block 119, name %120
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.09_32 () (_ BitVec 32))
(assert
 (let (($x452 (and (distinct (bvadd ((_ sign_extend 1) in.09_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.09_32 (_ bv1 32)))) true)))
(let (($x713 (or false false (or $x452))))
(and (not $x713) (or $x713 (and (distinct (bvadd in.09_32 (_ bv1 32)) (bvadd in.09_32 (_ bv1 32))) true))))))
(check-sat)
; query 43: function susan_edges_small, block 122, name %123
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.07_32 () (_ BitVec 32))
(assert
 (let (($x392 (and (distinct (bvadd ((_ sign_extend 1) in.07_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.07_32 (_ bv1 32)))) true)))
(let (($x1070 (or false false (or $x392))))
(and (not $x1070) (or $x1070 (and (distinct (bvadd in.07_32 (_ bv1 32)) (bvadd in.07_32 (_ bv1 32))) true))))))
(check-sat)
; query 44: function susan_edges_small, block 258, name %259
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in243_32 () (_ BitVec 32))
(assert
 (let ((?x361 (ite (= (_ bv0 32) in243_32) (_ bv1 1) (_ bv0 1))))
(let (($x341 (or false false false)))
(let (($x193 (not $x341)))
(and $x193 (or $x341 (and (distinct ?x361 ?x361) true)))))))
(check-sat)
; query 45: function susan_edges_small, block 278, name %279
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x495 (ite (bvslt (_ bv0 32) in.0_32) (_ bv1 1) (_ bv0 1))))
(let (($x341 (or false false false)))
(let (($x193 (not $x341)))
(and $x193 (or $x341 (and (distinct ?x495 ?x495) true)))))))
(check-sat)
; query 46: function susan_edges_small, block 426, name %427
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in411_32 () (_ BitVec 32))
(assert
 (let ((?x721 (ite (bvslt (_ bv0 32) in411_32) (_ bv1 1) (_ bv0 1))))
(let (($x341 (or false false false)))
(let (($x193 (not $x341)))
(and $x193 (or $x341 (and (distinct ?x721 ?x721) true)))))))
(check-sat)
; query 47: function susan_edges_small, block 458, name %459
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.110_32 () (_ BitVec 32))
(assert
 (let (($x374 (and (distinct (bvadd ((_ sign_extend 1) in.110_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.110_32 (_ bv1 32)))) true)))
(let (($x426 (or false false (or $x374))))
(and (not $x426) (or $x426 (and (distinct (bvadd in.110_32 (_ bv1 32)) (bvadd in.110_32 (_ bv1 32))) true))))))
(check-sat)
; query 48: function susan_edges_small, block 461, name %462
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.18_32 () (_ BitVec 32))
(assert
 (let (($x382 (and (distinct (bvadd ((_ sign_extend 1) in.18_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.18_32 (_ bv1 32)))) true)))
(let (($x408 (or false false (or $x382))))
(and (not $x408) (or $x408 (and (distinct (bvadd in.18_32 (_ bv1 32)) (bvadd in.18_32 (_ bv1 32))) true))))))
(check-sat)
; query 49: function susan_principle, block 378, name %379
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x102 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x42 (or false false (or $x102))))
(and (not $x42) (or $x42 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 50: function susan_principle, block 381, name %382
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x101 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x497 (or false false (or $x101))))
(and (not $x497) (or $x497 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 51: function susan_principle_small, block 118, name %119
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x102 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x42 (or false false (or $x102))))
(and (not $x42) (or $x42 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 52: function susan_principle_small, block 121, name %122
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x101 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x497 (or false false (or $x101))))
(and (not $x497) (or $x497 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 53: function susan_smoothing, block 123, name %124
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.09_32 () (_ BitVec 32))
(assert
 (let (($x462 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in.09_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in.09_32))) true)))
(let (($x477 (or false false (or $x462))))
(and (not $x477) (or $x477 (and (distinct (bvsub (_ bv0 32) in.09_32) (bvsub (_ bv0 32) in.09_32)) true))))))
(check-sat)
; query 54: function susan_smoothing, block 143, name %144
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.016_32 () (_ BitVec 32))
(assert
 (let (($x637 (and (distinct (bvadd ((_ sign_extend 1) in.016_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.016_32 (_ bv1 32)))) true)))
(let (($x896 (or false false (or $x637))))
(and (not $x896) (or $x896 (and (distinct (bvadd in.016_32 (_ bv1 32)) (bvadd in.016_32 (_ bv1 32))) true))))))
(check-sat)
; query 55: function susan_smoothing, block 148, name %149
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.017_32 () (_ BitVec 32))
(assert
 (let (($x350 (and (distinct (bvadd ((_ sign_extend 1) in.017_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.017_32 (_ bv1 32)))) true)))
(let (($x770 (or false false (or $x350))))
(and (not $x770) (or $x770 (and (distinct (bvadd in.017_32 (_ bv1 32)) (bvadd in.017_32 (_ bv1 32))) true))))))
(check-sat)
; query 56: function susan_smoothing, block 165, name %166
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.114_32 () (_ BitVec 32))
(assert
 (let (($x834 (and (distinct (bvadd ((_ sign_extend 1) in.114_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.114_32 (_ bv1 32)))) true)))
(let (($x895 (or false false (or $x834))))
(and (not $x895) (or $x895 (and (distinct (bvadd in.114_32 (_ bv1 32)) (bvadd in.114_32 (_ bv1 32))) true))))))
(check-sat)
; query 57: function susan_smoothing, block 168, name %169
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.111_32 () (_ BitVec 32))
(assert
 (let (($x192 (and (distinct (bvadd ((_ sign_extend 1) in.111_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.111_32 (_ bv1 32)))) true)))
(let (($x355 (or false false (or $x192))))
(and (not $x355) (or $x355 (and (distinct (bvadd in.111_32 (_ bv1 32)) (bvadd in.111_32 (_ bv1 32))) true))))))
(check-sat)
; query 58: function susan_smoothing, block 21, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x420 (ite (= (_ bv0 32) (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x341 (or false false false)))
(let (($x193 (not $x341)))
(and $x193 (or $x341 (and (distinct ?x420 ?x420) true)))))))
(check-sat)
; query 59: function susan_smoothing, block 319, name %320
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.215_32 () (_ BitVec 32))
(assert
 (let (($x649 (and (distinct (bvadd ((_ sign_extend 1) in.215_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.215_32 (_ bv1 32)))) true)))
(let (($x937 (or false false (or $x649))))
(and (not $x937) (or $x937 (and (distinct (bvadd in.215_32 (_ bv1 32)) (bvadd in.215_32 (_ bv1 32))) true))))))
(check-sat)
; query 60: function susan_smoothing, block 322, name %323
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.212_32 () (_ BitVec 32))
(assert
 (let (($x849 (and (distinct (bvadd ((_ sign_extend 1) in.212_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.212_32 (_ bv1 32)))) true)))
(let (($x576 (or false false (or $x849))))
(and (not $x576) (or $x576 (and (distinct (bvadd in.212_32 (_ bv1 32)) (bvadd in.212_32 (_ bv1 32))) true))))))
(check-sat)
; query 61: function susan_smoothing, block 67, name %68
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.09_32 () (_ BitVec 32))
(assert
 (let (($x462 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in.09_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in.09_32))) true)))
(let (($x477 (or false false (or $x462))))
(and (not $x477) (or $x477 (and (distinct (bvsub (_ bv0 32) in.09_32) (bvsub (_ bv0 32) in.09_32)) true))))))
(check-sat)
; query 62: function susan_smoothing, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.013_32 () (_ BitVec 32))
(assert
 (let (($x1049 (and (distinct (bvadd ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.013_32 (_ bv1 32)))) true)))
(let (($x384 (or false false (or $x1049))))
(and (not $x384) (or $x384 (and (distinct (bvadd in.013_32 (_ bv1 32)) (bvadd in.013_32 (_ bv1 32))) true))))))
(check-sat)
; query 63: function susan_smoothing, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.010_32 () (_ BitVec 32))
(assert
 (let (($x332 (and (distinct (bvadd ((_ sign_extend 1) in.010_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.010_32 (_ bv1 32)))) true)))
(let (($x272 (or false false (or $x332))))
(and (not $x272) (or $x272 (and (distinct (bvadd in.010_32 (_ bv1 32)) (bvadd in.010_32 (_ bv1 32))) true))))))
(check-sat)
; query 64: function susan_thin, block 100, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in93_32 () (_ BitVec 32))
(assert
 (let ((?x508 (ite (= (_ bv1 32) in93_32) (_ bv1 1) (_ bv0 1))))
(let (($x341 (or false false false)))
(let (($x193 (not $x341)))
(and $x193 (or $x341 (and (distinct ?x508 ?x508) true)))))))
(check-sat)
; query 65: function susan_thin, block 428, name %429
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.022_32 () (_ BitVec 32))
(assert
 (let (($x203 (and (distinct (bvadd ((_ sign_extend 1) in.022_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.022_32 (_ bv1 32)))) true)))
(let (($x167 (or false false (or $x203))))
(and (not $x167) (or $x167 (and (distinct (bvadd in.022_32 (_ bv1 32)) (bvadd in.022_32 (_ bv1 32))) true))))))
(check-sat)
; query 66: function susan_thin, block 431, name %432
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.018_32 () (_ BitVec 32))
(assert
 (let (($x855 (and (distinct (bvadd ((_ sign_extend 1) in.018_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.018_32 (_ bv1 32)))) true)))
(let (($x851 (or false false (or $x855))))
(and (not $x851) (or $x851 (and (distinct (bvadd in.018_32 (_ bv1 32)) (bvadd in.018_32 (_ bv1 32))) true))))))
(check-sat)
; query 67: function susan_thin, block 469, name %470
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.235.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x490 (bvadd in.235.lcssa_32 in.235.lcssa_32)))
(let ((?x324 ((_ sign_extend 1) ?x490)))
(let (($x416 (and (distinct (bvadd ((_ sign_extend 1) in.235.lcssa_32) ((_ sign_extend 1) in.235.lcssa_32)) ?x324) true)))
(let (($x388 (or false false (or $x416))))
(and (not $x388) (or $x388 (and (distinct ?x490 ?x490) true))))))))
(check-sat)
; query 68: function susan_thin, block 469, name %471
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.228.lcssa_32 () (_ BitVec 32))
(declare-fun in.235.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x490 (bvadd in.235.lcssa_32 in.235.lcssa_32)))
(let ((?x501 (bvadd ?x490 in.228.lcssa_32)))
(let (($x629 (and (distinct (bvadd ((_ sign_extend 1) ?x490) ((_ sign_extend 1) in.228.lcssa_32)) ((_ sign_extend 1) ?x501)) true)))
(let ((?x324 ((_ sign_extend 1) ?x490)))
(let (($x416 (and (distinct (bvadd ((_ sign_extend 1) in.235.lcssa_32) ((_ sign_extend 1) in.235.lcssa_32)) ?x324) true)))
(let (($x388 (or false false (or $x416))))
(let (($x464 (or $x388 false (or $x629))))
(and (not $x464) (or $x464 (and (distinct ?x501 ?x501) true)))))))))))
(check-sat)
; query 69: function susan_thin, block 469, name %472
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.228.lcssa_32 () (_ BitVec 32))
(declare-fun in.235.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x490 (bvadd in.235.lcssa_32 in.235.lcssa_32)))
(let ((?x501 (bvadd ?x490 in.228.lcssa_32)))
(let ((?x502 (ite (bvsgt (_ bv3 32) ?x501) (_ bv1 1) (_ bv0 1))))
(let (($x629 (and (distinct (bvadd ((_ sign_extend 1) ?x490) ((_ sign_extend 1) in.228.lcssa_32)) ((_ sign_extend 1) ?x501)) true)))
(let ((?x324 ((_ sign_extend 1) ?x490)))
(let (($x416 (and (distinct (bvadd ((_ sign_extend 1) in.235.lcssa_32) ((_ sign_extend 1) in.235.lcssa_32)) ?x324) true)))
(let (($x388 (or false false (or $x416))))
(let (($x464 (or $x388 false (or $x629))))
(let (($x817 (or $x464 false false)))
(and (not $x817) (or $x817 (and (distinct ?x502 ?x502) true)))))))))))))
(check-sat)
; query 70: function susan_thin, block 473, name %474
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.235.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x729 (bvsub in.235.lcssa_32 (_ bv1 32))))
(let ((?x597 ((_ sign_extend 1) ?x729)))
(let (($x276 (and (distinct (bvsub ((_ sign_extend 1) in.235.lcssa_32) ((_ sign_extend 1) (_ bv1 32))) ?x597) true)))
(let (($x657 (or false false (or $x276))))
(and (not $x657) (or $x657 (and (distinct ?x729 ?x729) true))))))))
(check-sat)
; query 71: function susan_thin, block 473, name %475
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.235.lcssa_32 () (_ BitVec 32))
(declare-fun in.14_32 () (_ BitVec 32))
(assert
 (let ((?x729 (bvsub in.235.lcssa_32 (_ bv1 32))))
(let ((?x197 (bvadd in.14_32 ?x729)))
(let (($x626 (and (distinct (bvadd ((_ sign_extend 1) in.14_32) ((_ sign_extend 1) ?x729)) ((_ sign_extend 1) ?x197)) true)))
(let ((?x597 ((_ sign_extend 1) ?x729)))
(let (($x276 (and (distinct (bvsub ((_ sign_extend 1) in.235.lcssa_32) ((_ sign_extend 1) (_ bv1 32))) ?x597) true)))
(let (($x657 (or false false (or $x276))))
(let (($x362 (or false $x657 (or $x626))))
(and (not $x362) (or $x362 (and (distinct ?x197 ?x197) true)))))))))))
(check-sat)
; query 72: function susan_thin, block 473, name %476
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.228.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x82 (bvsub in.228.lcssa_32 (_ bv2 32))))
(let ((?x327 ((_ sign_extend 1) ?x82)))
(let (($x977 (and (distinct (bvsub ((_ sign_extend 1) in.228.lcssa_32) ((_ sign_extend 1) (_ bv2 32))) ?x327) true)))
(let (($x753 (or false false (or $x977))))
(and (not $x753) (or $x753 (and (distinct ?x82 ?x82) true))))))))
(check-sat)
; query 73: function susan_thin, block 473, name %477
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.228.lcssa_32 () (_ BitVec 32))
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x82 (bvsub in.228.lcssa_32 (_ bv2 32))))
(let ((?x536 (bvadd in.0_32 ?x82)))
(let (($x371 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) ?x82)) ((_ sign_extend 1) ?x536)) true)))
(let ((?x327 ((_ sign_extend 1) ?x82)))
(let (($x977 (and (distinct (bvsub ((_ sign_extend 1) in.228.lcssa_32) ((_ sign_extend 1) (_ bv2 32))) ?x327) true)))
(let (($x753 (or false false (or $x977))))
(let (($x750 (or false $x753 (or $x371))))
(and (not $x750) (or $x750 (and (distinct ?x536 ?x536) true)))))))))))
(check-sat)
; query 74: function susan_thin, block 473, name %478
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.235.lcssa_32 () (_ BitVec 32))
(declare-fun in.14_32 () (_ BitVec 32))
(assert
 (let ((?x391 (ite (bvsgt (_ bv4 32) (bvadd in.14_32 (bvsub in.235.lcssa_32 (_ bv1 32)))) (_ bv1 1) (_ bv0 1))))
(let ((?x729 (bvsub in.235.lcssa_32 (_ bv1 32))))
(let ((?x597 ((_ sign_extend 1) ?x729)))
(let ((?x182 ((_ sign_extend 1) in.14_32)))
(let (($x276 (and (distinct (bvsub ((_ sign_extend 1) in.235.lcssa_32) ((_ sign_extend 1) (_ bv1 32))) ?x597) true)))
(let (($x657 (or false false (or $x276))))
(let (($x362 (or false $x657 (or (and (distinct (bvadd ?x182 ?x597) ((_ sign_extend 1) (bvadd in.14_32 ?x729))) true)))))
(let (($x247 (or $x362 false false)))
(and (not $x247) (or $x247 (and (distinct ?x391 ?x391) true))))))))))))
(check-sat)
; query 75: function susan_thin, block 533, name %534
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in528_32 () (_ BitVec 32))
(declare-fun in498_32 () (_ BitVec 32))
(assert
 (let (($x341 (or false false false)))
(let (($x675 (or $x341 (and (distinct (bvor in498_32 in528_32) (bvor in498_32 in528_32)) true))))
(let (($x193 (not $x341)))
(and $x193 $x675)))))
(check-sat)
; query 76: function susan_thin, block 533, name %535
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in518_32 () (_ BitVec 32))
(declare-fun in508_32 () (_ BitVec 32))
(assert
 (let (($x341 (or false false false)))
(let (($x274 (or $x341 (and (distinct (bvor in508_32 in518_32) (bvor in508_32 in518_32)) true))))
(let (($x193 (not $x341)))
(and $x193 $x274)))))
(check-sat)
; query 77: function susan_thin, block 533, name %536
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in518_32 () (_ BitVec 32))
(declare-fun in508_32 () (_ BitVec 32))
(declare-fun in528_32 () (_ BitVec 32))
(declare-fun in498_32 () (_ BitVec 32))
(assert
 (let ((?x308 (bvor in508_32 in518_32)))
(let ((?x883 (bvor in498_32 in528_32)))
(let ((?x481 (bvand ?x883 ?x308)))
(let (($x341 (or false false false)))
(let (($x861 (or $x341 $x341 false)))
(let (($x482 (not $x861)))
(and $x482 (or $x861 (and (distinct ?x481 ?x481) true))))))))))
(check-sat)
; query 78: function susan_thin, block 533, name %537
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in518_32 () (_ BitVec 32))
(declare-fun in508_32 () (_ BitVec 32))
(declare-fun in528_32 () (_ BitVec 32))
(declare-fun in498_32 () (_ BitVec 32))
(assert
 (let ((?x308 (bvor in508_32 in518_32)))
(let ((?x883 (bvor in498_32 in528_32)))
(let ((?x481 (bvand ?x883 ?x308)))
(let ((?x780 (ite (and (distinct (_ bv0 32) ?x481) true) (_ bv1 1) (_ bv0 1))))
(let (($x341 (or false false false)))
(let (($x861 (or $x341 $x341 false)))
(let (($x623 (or $x861 false false)))
(let (($x299 (not $x623)))
(and $x299 (or $x623 (and (distinct ?x780 ?x780) true))))))))))))
(check-sat)
; query 79: function susan_thin, block 538, name %539
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in498_32 () (_ BitVec 32))
(assert
 (let ((?x865 (ite (and (distinct (_ bv0 32) in498_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x341 (or false false false)))
(let (($x193 (not $x341)))
(and $x193 (or $x341 (and (distinct ?x865 ?x865) true)))))))
(check-sat)
; query 80: function susan_thin, block 540, name %541
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in508_32 () (_ BitVec 32))
(assert
 (let ((?x559 (ite (and (distinct (_ bv0 32) in508_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x341 (or false false false)))
(let (($x193 (not $x341)))
(and $x193 (or $x341 (and (distinct ?x559 ?x559) true)))))))
(check-sat)
; query 81: function susan_thin, block 545, name %546
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in508_32 () (_ BitVec 32))
(assert
 (let ((?x559 (ite (and (distinct (_ bv0 32) in508_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x341 (or false false false)))
(let (($x193 (not $x341)))
(and $x193 (or $x341 (and (distinct ?x559 ?x559) true)))))))
(check-sat)
; query 82: function susan_thin, block 563, name %564
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.325_32 () (_ BitVec 32))
(assert
 (let ((?x330 (ite (= (_ bv0 32) in.325_32) (_ bv1 1) (_ bv0 1))))
(let (($x341 (or false false false)))
(let (($x193 (not $x341)))
(and $x193 (or $x341 (and (distinct ?x330 ?x330) true)))))))
(check-sat)
; query 83: function susan_thin, block 597, name %598
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.321_32 () (_ BitVec 32))
(assert
 (let ((?x980 (ite (= (_ bv0 32) in.321_32) (_ bv1 1) (_ bv0 1))))
(let (($x341 (or false false false)))
(let (($x193 (not $x341)))
(and $x193 (or $x341 (and (distinct ?x980 ?x980) true)))))))
(check-sat)
; query 84: function susan_thin, block 685, name %686
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in662_32 () (_ BitVec 32))
(declare-fun in680_32 () (_ BitVec 32))
(assert
 (let (($x341 (or false false false)))
(let (($x518 (or $x341 (and (distinct (bvor in680_32 in662_32) (bvor in680_32 in662_32)) true))))
(let (($x193 (not $x341)))
(and $x193 $x518)))))
(check-sat)
; query 85: function susan_thin, block 685, name %687
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in671_32 () (_ BitVec 32))
(declare-fun in653_32 () (_ BitVec 32))
(assert
 (let (($x341 (or false false false)))
(let (($x658 (or $x341 (and (distinct (bvor in653_32 in671_32) (bvor in653_32 in671_32)) true))))
(let (($x193 (not $x341)))
(and $x193 $x658)))))
(check-sat)
; query 86: function susan_thin, block 685, name %688
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in671_32 () (_ BitVec 32))
(declare-fun in653_32 () (_ BitVec 32))
(declare-fun in662_32 () (_ BitVec 32))
(declare-fun in680_32 () (_ BitVec 32))
(assert
 (let ((?x898 (bvor in653_32 in671_32)))
(let ((?x396 (bvor in680_32 in662_32)))
(let ((?x556 (bvand ?x396 ?x898)))
(let (($x341 (or false false false)))
(let (($x861 (or $x341 $x341 false)))
(let (($x482 (not $x861)))
(and $x482 (or $x861 (and (distinct ?x556 ?x556) true))))))))))
(check-sat)
; query 87: function susan_thin, block 685, name %689
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in671_32 () (_ BitVec 32))
(declare-fun in653_32 () (_ BitVec 32))
(declare-fun in662_32 () (_ BitVec 32))
(declare-fun in680_32 () (_ BitVec 32))
(assert
 (let ((?x898 (bvor in653_32 in671_32)))
(let ((?x396 (bvor in680_32 in662_32)))
(let ((?x556 (bvand ?x396 ?x898)))
(let ((?x602 (ite (and (distinct (_ bv0 32) ?x556) true) (_ bv1 1) (_ bv0 1))))
(let (($x341 (or false false false)))
(let (($x861 (or $x341 $x341 false)))
(let (($x623 (or $x861 false false)))
(let (($x299 (not $x623)))
(and $x299 (or $x623 (and (distinct ?x602 ?x602) true))))))))))))
(check-sat)
; query 88: function susan_thin, block 915, name %916
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.13_32 () (_ BitVec 32))
(assert
 (let (($x644 (and (distinct (bvadd ((_ sign_extend 1) in.13_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.13_32 (_ bv1 32)))) true)))
(let (($x194 (or false false (or $x644))))
(and (not $x194) (or $x194 (and (distinct (bvadd in.13_32 (_ bv1 32)) (bvadd in.13_32 (_ bv1 32))) true))))))
(check-sat)
; query 89: function susan_thin, block 918, name %919
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.14.lcssa_32 () (_ BitVec 32))
(assert
 (let (($x300 (and (distinct (bvadd ((_ sign_extend 1) in.14.lcssa_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.14.lcssa_32 (_ bv1 32)))) true)))
(let (($x558 (or false false (or $x300))))
(let (($x1011 (or $x558 (and (distinct (bvadd in.14.lcssa_32 (_ bv1 32)) (bvadd in.14.lcssa_32 (_ bv1 32))) true))))
(and (not $x558) $x1011)))))
(check-sat)
