; OptiPhase-Sigma refinement certificate for sweep K10-R6-013
