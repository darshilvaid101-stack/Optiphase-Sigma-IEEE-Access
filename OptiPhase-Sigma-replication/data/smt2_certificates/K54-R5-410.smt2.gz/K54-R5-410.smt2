; OptiPhase-Sigma refinement certificate for sweep K54-R5-410
; query 0: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x649 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x32 (or false false false)))
(let (($x592 (not $x32)))
(and $x592 (or $x32 (and (distinct ?x649 ?x649) true)))))))
(check-sat)
; query 1: function set1d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x337 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x32 (or false false false)))
(let (($x592 (not $x32)))
(and $x592 (or $x32 (and (distinct ?x337 ?x337) true)))))))
(check-sat)
; query 2: function set1ds, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x320 (ite (= (_ bv4294967295 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x32 (or false false false)))
(let (($x592 (not $x32)))
(and $x592 (or $x32 (and (distinct ?x320 ?x320) true)))))))
(check-sat)
; query 3: function set2d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x337 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x32 (or false false false)))
(let (($x592 (not $x32)))
(and $x592 (or $x32 (and (distinct ?x337 ?x337) true)))))))
(check-sat)
