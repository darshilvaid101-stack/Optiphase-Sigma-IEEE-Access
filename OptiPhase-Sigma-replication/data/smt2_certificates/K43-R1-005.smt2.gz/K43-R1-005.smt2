; OptiPhase-Sigma refinement certificate for sweep K43-R1-005
; query 0: function main, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x448 (ite (and (distinct (_ bv0 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x432 (or false false false)))
(and (not $x432) (or $x432 (and (distinct ?x448 ?x448) true))))))
(check-sat)
; query 1: function main, block 17, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x448 (ite (and (distinct (_ bv0 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let ((?x454 ((_ zero_extend 31) ?x448)))
(let (($x432 (or false false false)))
(let (($x35 (or $x432 false)))
(and (not $x35) (or $x35 (and (distinct ?x454 ?x454) true))))))))
(check-sat)
