; OptiPhase-Sigma refinement certificate for sweep K55-R2-079
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x592 (or false false)))
(let (($x488 (not $x592)))
(and $x488 (or $x592 (and (distinct ((_ sign_extend 16) in25_16) ((_ sign_extend 16) in25_16)) true))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let ((?x337 (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))))
(let (($x592 (or false false)))
(let (($x1669 (or $x592 false false)))
(let (($x77 (not $x1669)))
(and $x77 (or $x1669 (and (distinct ?x337 ?x337) true))))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x592 (or false false)))
(let (($x488 (not $x592)))
(and $x488 (or $x592 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x1022 ((_ sign_extend 16) in3_16)))
(let ((?x320 (bvand ?x1022 (_ bv127 32))))
(let (($x592 (or false false)))
(let (($x1669 (or $x592 false false)))
(let (($x77 (not $x1669)))
(and $x77 (or $x1669 (and (distinct ?x320 ?x320) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x1022 ((_ sign_extend 16) in3_16)))
(let ((?x320 (bvand ?x1022 (_ bv127 32))))
(let ((?x144 ((_ extract 15 0) ?x320)))
(let (($x592 (or false false)))
(let (($x1669 (or $x592 false false)))
(let (($x555 (or $x1669 false)))
(let (($x528 (not $x555)))
(and $x528 (or $x555 (and (distinct ?x144 ?x144) true)))))))))))
(check-sat)
; query 5: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x592 (or false false)))
(let (($x488 (not $x592)))
(and $x488 (or $x592 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 6: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x33 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x592 (or false false)))
(let (($x1669 (or $x592 false false)))
(let (($x77 (not $x1669)))
(and $x77 (or $x1669 (and (distinct ?x33 ?x33) true))))))))
(check-sat)
; query 7: function core_bench_list, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x95 (or false false false)))
(let (($x28 (not $x95)))
(and $x28 (or $x95 (and (distinct (bvadd in.0_16 (_ bv1 16)) (bvadd in.0_16 (_ bv1 16))) true))))))
(check-sat)
; query 8: function core_bench_list, block 82, name %83
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let (($x592 (or false false)))
(let (($x488 (not $x592)))
(and $x488 (or $x592 (and (distinct ((_ zero_extend 16) in.02_16) ((_ zero_extend 16) in.02_16)) true))))))
(check-sat)
; query 9: function core_bench_list, block 82, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x235 ((_ zero_extend 16) in.02_16)))
(let ((?x1179 (bvmul ?x235 (_ bv4 32))))
(let (($x155 (and (distinct (bvmul ((_ sign_extend 32) ?x235) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x1179)) true)))
(let (($x592 (or false false)))
(let (($x631 (or $x592 false (or $x155))))
(and (not $x631) (or $x631 (and (distinct ?x1179 ?x1179) true)))))))))
(check-sat)
; query 10: function core_bench_list, block 82, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let (($x592 (or false false)))
(let (($x488 (not $x592)))
(and $x488 (or $x592 (and (distinct ((_ zero_extend 16) in.04_16) ((_ zero_extend 16) in.04_16)) true))))))
(check-sat)
; query 11: function core_bench_list, block 82, name %86
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x104 ((_ zero_extend 16) in.04_16)))
(let ((?x235 ((_ zero_extend 16) in.02_16)))
(let ((?x1179 (bvmul ?x235 (_ bv4 32))))
(let ((?x725 (bvsub ?x1179 ?x104)))
(let ((?x15 ((_ sign_extend 1) ?x725)))
(let (($x592 (or false false)))
(let (($x155 (and (distinct (bvmul ((_ sign_extend 32) ?x235) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x1179)) true)))
(let (($x631 (or $x592 false (or $x155))))
(let (($x653 (or $x631 $x592 (or (and (distinct (bvsub ((_ sign_extend 1) ?x1179) ((_ sign_extend 1) ?x104)) ?x15) true)))))
(and (not $x653) (or $x653 (and (distinct ?x725 ?x725) true)))))))))))))
(check-sat)
; query 12: function core_bench_list, block 82, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x592 (or false false)))
(let (($x488 (not $x592)))
(and $x488 (or $x592 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 13: function core_bench_list, block 82, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x104 ((_ zero_extend 16) in.04_16)))
(let ((?x235 ((_ zero_extend 16) in.02_16)))
(let ((?x1179 (bvmul ?x235 (_ bv4 32))))
(let ((?x725 (bvsub ?x1179 ?x104)))
(let ((?x781 ((_ zero_extend 16) in.01_16)))
(let ((?x187 (bvadd ?x781 ?x725)))
(let (($x805 (and (distinct (bvadd ((_ sign_extend 1) ?x781) ((_ sign_extend 1) ?x725)) ((_ sign_extend 1) ?x187)) true)))
(let ((?x15 ((_ sign_extend 1) ?x725)))
(let (($x592 (or false false)))
(let (($x155 (and (distinct (bvmul ((_ sign_extend 32) ?x235) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x1179)) true)))
(let (($x631 (or $x592 false (or $x155))))
(let (($x653 (or $x631 $x592 (or (and (distinct (bvsub ((_ sign_extend 1) ?x1179) ((_ sign_extend 1) ?x104)) ?x15) true)))))
(let (($x101 (or $x592 $x653 (or $x805))))
(and (not $x101) (or $x101 (and (distinct ?x187 ?x187) true)))))))))))))))))
(check-sat)
; query 14: function core_bench_list, block 82, name %89
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x104 ((_ zero_extend 16) in.04_16)))
(let ((?x235 ((_ zero_extend 16) in.02_16)))
(let ((?x1179 (bvmul ?x235 (_ bv4 32))))
(let ((?x725 (bvsub ?x1179 ?x104)))
(let ((?x781 ((_ zero_extend 16) in.01_16)))
(let ((?x187 (bvadd ?x781 ?x725)))
(let ((?x68 ((_ extract 15 0) ?x187)))
(let (($x805 (and (distinct (bvadd ((_ sign_extend 1) ?x781) ((_ sign_extend 1) ?x725)) ((_ sign_extend 1) ?x187)) true)))
(let ((?x15 ((_ sign_extend 1) ?x725)))
(let (($x592 (or false false)))
(let (($x155 (and (distinct (bvmul ((_ sign_extend 32) ?x235) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x1179)) true)))
(let (($x631 (or $x592 false (or $x155))))
(let (($x653 (or $x631 $x592 (or (and (distinct (bvsub ((_ sign_extend 1) ?x1179) ((_ sign_extend 1) ?x104)) ?x15) true)))))
(let (($x101 (or $x592 $x653 (or $x805))))
(let (($x83 (or $x101 false)))
(and (not $x83) (or $x83 (and (distinct ?x68 ?x68) true)))))))))))))))))))
(check-sat)
; query 15: function core_bench_list, block 82, name %90
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x592 (or false false)))
(let (($x488 (not $x592)))
(and $x488 (or $x592 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 16: function core_bench_list, block 82, name %91
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x18 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x592 (or false false)))
(let (($x1669 (or $x592 false false)))
(let (($x77 (not $x1669)))
(and $x77 (or $x1669 (and (distinct ?x18 ?x18) true))))))))
(check-sat)
; query 17: function core_bench_state, block 105, name %106
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x95 (or false false false)))
(let (($x28 (not $x95)))
(and $x28 (or $x95 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 18: function core_bench_state, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x95 (or false false false)))
(let (($x28 (not $x95)))
(and $x28 (or $x95 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 19: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x166 (bvadd in.01_32 (_ bv1 32))))
(let (($x38715 (and (distinct ?x166 ?x166) true)))
(let (($x95 (or false false false)))
(let (($x28 (not $x95)))
(and $x28 (or $x95 $x38715)))))))
(check-sat)
; query 20: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x166 (bvadd in.01_32 (_ bv1 32))))
(let ((?x365 (bvmul ?x166 ?x166)))
(let (($x95 (or false false false)))
(let (($x511 (or $x95 $x95 false)))
(and (not $x511) (or $x511 (and (distinct ?x365 ?x365) true))))))))
(check-sat)
; query 21: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x166 (bvadd in.01_32 (_ bv1 32))))
(let ((?x365 (bvmul ?x166 ?x166)))
(let ((?x343 (bvmul ?x365 (_ bv2 32))))
(let (($x95 (or false false false)))
(let (($x511 (or $x95 $x95 false)))
(let (($x245 (or $x511 false false)))
(and (not $x245) (or $x245 (and (distinct ?x343 ?x343) true))))))))))
(check-sat)
; query 22: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x166 (bvadd in.01_32 (_ bv1 32))))
(let ((?x365 (bvmul ?x166 ?x166)))
(let ((?x343 (bvmul ?x365 (_ bv2 32))))
(let ((?x90 (bvmul ?x343 (_ bv4 32))))
(let (($x95 (or false false false)))
(let (($x511 (or $x95 $x95 false)))
(let (($x245 (or $x511 false false)))
(let (($x20 (or $x245 false false)))
(and (not $x20) (or $x20 (and (distinct ?x90 ?x90) true))))))))))))
(check-sat)
; query 23: function core_init_matrix, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x95 (or false false false)))
(let (($x28 (not $x95)))
(and $x28 (or $x95 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 24: function core_init_matrix, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x95 (or false false false)))
(let (($x28 (not $x95)))
(and $x28 (or $x95 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 25: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x80 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x95 (or false false false)))
(let (($x28 (not $x95)))
(and $x28 (or $x95 (and (distinct ?x80 ?x80) true)))))))
(check-sat)
; query 26: function core_init_state, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_32 () (_ BitVec 32))
(assert
 (let (($x95 (or false false false)))
(let (($x28 (not $x95)))
(and $x28 (or $x95 (and (distinct (bvadd in.06_32 (_ bv1 32)) (bvadd in.06_32 (_ bv1 32))) true))))))
(check-sat)
; query 27: function core_init_state, block 65, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let (($x95 (or false false false)))
(let (($x28 (not $x95)))
(and $x28 (or $x95 (and (distinct (bvadd in4_32 (_ bv1 32)) (bvadd in4_32 (_ bv1 32))) true))))))
(check-sat)
; query 28: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x42912 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x95 (or false false false)))
(let (($x28 (not $x95)))
(and $x28 (or $x95 (and (distinct ?x42912 ?x42912) true)))))))
(check-sat)
; query 29: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x95 (or false false false)))
(let (($x28 (not $x95)))
(and $x28 (or $x95 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 30: function core_list_init, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x166 (bvadd in.01_32 (_ bv1 32))))
(let (($x38715 (and (distinct ?x166 ?x166) true)))
(let (($x95 (or false false false)))
(let (($x28 (not $x95)))
(and $x28 (or $x95 $x38715)))))))
(check-sat)
; query 31: function core_list_mergesort, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x166 (bvadd in.01_32 (_ bv1 32))))
(let (($x38715 (and (distinct ?x166 ?x166) true)))
(let (($x42368 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x166)) true)))
(let (($x239 (or false false (or $x42368))))
(and (not $x239) (or $x239 $x38715)))))))
(check-sat)
; query 32: function core_list_mergesort, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x432 (ite (bvslt (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x95 (or false false false)))
(let (($x28 (not $x95)))
(and $x28 (or $x95 (and (distinct ?x432 ?x432) true)))))))
(check-sat)
; query 33: function core_list_mergesort, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.224_32 () (_ BitVec 32))
(assert
 (let ((?x1426 (ite (= (_ bv0 32) in.224_32) (_ bv1 1) (_ bv0 1))))
(let (($x95 (or false false false)))
(let (($x28 (not $x95)))
(and $x28 (or $x95 (and (distinct ?x1426 ?x1426) true)))))))
(check-sat)
; query 34: function core_list_mergesort, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x1452 (ite (= (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x95 (or false false false)))
(let (($x28 (not $x95)))
(and $x28 (or $x95 (and (distinct ?x1452 ?x1452) true)))))))
(check-sat)
; query 35: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x44028 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x41979 (or false false (or $x44028))))
(and (not $x41979) (or $x41979 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 36: function core_list_mergesort, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x18969 (and (distinct (bvmul ((_ sign_extend 32) in.020_32) ((_ sign_extend 32) (_ bv2 32))) ((_ sign_extend 32) (bvmul in.020_32 (_ bv2 32)))) true)))
(let (($x1167 (or false false (or $x18969))))
(and (not $x1167) (or $x1167 (and (distinct (bvmul in.020_32 (_ bv2 32)) (bvmul in.020_32 (_ bv2 32))) true))))))
(check-sat)
; query 37: function core_state_transition, block 102, name %103
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x592 (or false false)))
(let (($x488 (not $x592)))
(and $x488 (or $x592 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 38: function core_state_transition, block 102, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1141 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x592 (or false false)))
(let (($x1669 (or $x592 false false)))
(let (($x77 (not $x1669)))
(and $x77 (or $x1669 (and (distinct ?x1141 ?x1141) true))))))))
(check-sat)
; query 39: function core_state_transition, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x592 (or false false)))
(let (($x488 (not $x592)))
(and $x488 (or $x592 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 40: function core_state_transition, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x17216 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x592 (or false false)))
(let (($x1669 (or $x592 false false)))
(let (($x77 (not $x1669)))
(and $x77 (or $x1669 (and (distinct ?x17216 ?x17216) true))))))))
(check-sat)
; query 41: function core_state_transition, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x592 (or false false)))
(let (($x488 (not $x592)))
(and $x488 (or $x592 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 42: function core_state_transition, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1141 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x592 (or false false)))
(let (($x1669 (or $x592 false false)))
(let (($x77 (not $x1669)))
(and $x77 (or $x1669 (and (distinct ?x1141 ?x1141) true))))))))
(check-sat)
; query 43: function core_state_transition, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x592 (or false false)))
(let (($x488 (not $x592)))
(and $x488 (or $x592 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 44: function core_state_transition, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x16145 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x592 (or false false)))
(let (($x1669 (or $x592 false false)))
(let (($x77 (not $x1669)))
(and $x77 (or $x1669 (and (distinct ?x16145 ?x16145) true))))))))
(check-sat)
; query 45: function core_state_transition, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x592 (or false false)))
(let (($x488 (not $x592)))
(and $x488 (or $x592 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 46: function core_state_transition, block 51, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x16145 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x592 (or false false)))
(let (($x1669 (or $x592 false false)))
(let (($x77 (not $x1669)))
(and $x77 (or $x1669 (and (distinct ?x16145 ?x16145) true))))))))
(check-sat)
; query 47: function core_state_transition, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x592 (or false false)))
(let (($x488 (not $x592)))
(and $x488 (or $x592 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 48: function core_state_transition, block 64, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x16145 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x592 (or false false)))
(let (($x1669 (or $x592 false false)))
(let (($x77 (not $x1669)))
(and $x77 (or $x1669 (and (distinct ?x16145 ?x16145) true))))))))
(check-sat)
; query 49: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x44037 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x95 (or false false false)))
(let (($x28 (not $x95)))
(and $x28 (or $x95 (and (distinct ?x44037 ?x44037) true)))))))
(check-sat)
; query 50: function core_state_transition, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x592 (or false false)))
(let (($x488 (not $x592)))
(and $x488 (or $x592 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 51: function core_state_transition, block 80, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x39249 (ite (= (_ bv69 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x592 (or false false)))
(let (($x1669 (or $x592 false false)))
(let (($x77 (not $x1669)))
(and $x77 (or $x1669 (and (distinct ?x39249 ?x39249) true))))))))
(check-sat)
; query 52: function core_state_transition, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x592 (or false false)))
(let (($x488 (not $x592)))
(and $x488 (or $x592 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 53: function core_state_transition, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x39257 (ite (= (_ bv101 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x592 (or false false)))
(let (($x1669 (or $x592 false false)))
(let (($x77 (not $x1669)))
(and $x77 (or $x1669 (and (distinct ?x39257 ?x39257) true))))))))
(check-sat)
; query 54: function core_state_transition, block 99, name %100
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x592 (or false false)))
(let (($x488 (not $x592)))
(and $x488 (or $x592 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 55: function core_state_transition, block 99, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x17216 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x592 (or false false)))
(let (($x1669 (or $x592 false false)))
(let (($x77 (not $x1669)))
(and $x77 (or $x1669 (and (distinct ?x17216 ?x17216) true))))))))
(check-sat)
; query 56: function crcu8, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x592 (or false false)))
(let (($x488 (not $x592)))
(and $x488 (or $x592 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 57: function crcu8, block 19, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x781 ((_ zero_extend 16) in.01_16)))
(let ((?x8876 (bvxor ?x781 (_ bv16386 32))))
(let (($x592 (or false false)))
(let (($x1669 (or $x592 false false)))
(let (($x77 (not $x1669)))
(and $x77 (or $x1669 (and (distinct ?x8876 ?x8876) true)))))))))
(check-sat)
; query 58: function crcu8, block 19, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x781 ((_ zero_extend 16) in.01_16)))
(let ((?x8876 (bvxor ?x781 (_ bv16386 32))))
(let ((?x39241 ((_ extract 15 0) ?x8876)))
(let (($x592 (or false false)))
(let (($x1669 (or $x592 false false)))
(let (($x555 (or $x1669 false)))
(let (($x528 (not $x555)))
(and $x528 (or $x555 (and (distinct ?x39241 ?x39241) true)))))))))))
(check-sat)
; query 59: function crcu8, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x592 (or false false)))
(let (($x488 (not $x592)))
(and $x488 (or $x592 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 60: function crcu8, block 29, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x21767 ((_ zero_extend 16) in27_16)))
(let ((?x19424 (bvor ?x21767 (_ bv32768 32))))
(let (($x592 (or false false)))
(let (($x1669 (or $x592 false false)))
(let (($x77 (not $x1669)))
(and $x77 (or $x1669 (and (distinct ?x19424 ?x19424) true)))))))))
(check-sat)
; query 61: function crcu8, block 29, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x21767 ((_ zero_extend 16) in27_16)))
(let ((?x19424 (bvor ?x21767 (_ bv32768 32))))
(let ((?x13173 ((_ extract 15 0) ?x19424)))
(let (($x592 (or false false)))
(let (($x1669 (or $x592 false false)))
(let (($x555 (or $x1669 false)))
(let (($x528 (not $x555)))
(and $x528 (or $x555 (and (distinct ?x13173 ?x13173) true)))))))))))
(check-sat)
; query 62: function crcu8, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x592 (or false false)))
(let (($x488 (not $x592)))
(and $x488 (or $x592 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 63: function crcu8, block 33, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x21767 ((_ zero_extend 16) in27_16)))
(let ((?x42199 (bvand ?x21767 (_ bv32767 32))))
(let (($x592 (or false false)))
(let (($x1669 (or $x592 false false)))
(let (($x77 (not $x1669)))
(and $x77 (or $x1669 (and (distinct ?x42199 ?x42199) true)))))))))
(check-sat)
; query 64: function crcu8, block 33, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x21767 ((_ zero_extend 16) in27_16)))
(let ((?x42199 (bvand ?x21767 (_ bv32767 32))))
(let ((?x38704 ((_ extract 15 0) ?x42199)))
(let (($x592 (or false false)))
(let (($x1669 (or $x592 false false)))
(let (($x555 (or $x1669 false)))
(let (($x528 (not $x555)))
(and $x528 (or $x555 (and (distinct ?x38704 ?x38704) true)))))))))))
(check-sat)
; query 65: function crcu8, block 38, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_8 () (_ BitVec 8))
(assert
 (let (($x95 (or false false false)))
(let (($x28 (not $x95)))
(and $x28 (or $x95 (and (distinct (bvadd in.02_8 (_ bv1 8)) (bvadd in.02_8 (_ bv1 8))) true))))))
(check-sat)
; query 66: function crcu8, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x44283 ((_ extract 7 0) in.01_16)))
(let ((?x420 ((_ zero_extend 24) ?x44283)))
(let (($x592 (or false false)))
(let (($x43089 (or $x592 false)))
(and (not $x43089) (or $x43089 (and (distinct ?x420 ?x420) true))))))))
(check-sat)
; query 67: function crcu8, block 6, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x44283 ((_ extract 7 0) in.01_16)))
(let ((?x420 ((_ zero_extend 24) ?x44283)))
(let ((?x715 (bvand ?x420 (_ bv1 32))))
(let (($x592 (or false false)))
(let (($x43089 (or $x592 false)))
(let (($x8131 (or $x43089 false false)))
(and (not $x8131) (or $x8131 (and (distinct ?x715 ?x715) true))))))))))
(check-sat)
; query 68: function crcu8, block 6, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x44283 ((_ extract 7 0) in.01_16)))
(let ((?x420 ((_ zero_extend 24) ?x44283)))
(let ((?x715 (bvand ?x420 (_ bv1 32))))
(let ((?x1849 ((_ zero_extend 24) in.0_8)))
(let ((?x43909 (bvand ?x1849 (_ bv1 32))))
(let ((?x9501 (bvxor ?x43909 ?x715)))
(let (($x592 (or false false)))
(let (($x43089 (or $x592 false)))
(let (($x8131 (or $x43089 false false)))
(let (($x1669 (or $x592 false false)))
(let (($x7152 (or $x1669 $x8131 false)))
(and (not $x7152) (or $x7152 (and (distinct ?x9501 ?x9501) true)))))))))))))))
(check-sat)
; query 69: function crcu8, block 6, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x44283 ((_ extract 7 0) in.01_16)))
(let ((?x420 ((_ zero_extend 24) ?x44283)))
(let ((?x715 (bvand ?x420 (_ bv1 32))))
(let ((?x1849 ((_ zero_extend 24) in.0_8)))
(let ((?x43909 (bvand ?x1849 (_ bv1 32))))
(let ((?x9501 (bvxor ?x43909 ?x715)))
(let ((?x7874 ((_ extract 7 0) ?x9501)))
(let (($x592 (or false false)))
(let (($x43089 (or $x592 false)))
(let (($x8131 (or $x43089 false false)))
(let (($x1669 (or $x592 false false)))
(let (($x7152 (or $x1669 $x8131 false)))
(let (($x823 (or $x7152 false)))
(and (not $x823) (or $x823 (and (distinct ?x7874 ?x7874) true)))))))))))))))))
(check-sat)
; query 70: function crcu8, block 6, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x592 (or false false)))
(let (($x488 (not $x592)))
(and $x488 (or $x592 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 71: function crcu8, block 6, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1849 ((_ zero_extend 24) in.0_8)))
(let ((?x21360 (bvashr ?x1849 (_ bv1 32))))
(let (($x592 (or false false)))
(let (($x1669 (or $x592 false false)))
(let (($x6953 (or $x1669 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not $x6953) (or $x6953 (and (distinct ?x21360 ?x21360) true)))))))))
(check-sat)
; query 72: function crcu8, block 6, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1849 ((_ zero_extend 24) in.0_8)))
(let ((?x21360 (bvashr ?x1849 (_ bv1 32))))
(let ((?x1600 ((_ extract 7 0) ?x21360)))
(let (($x592 (or false false)))
(let (($x1669 (or $x592 false false)))
(let (($x6953 (or $x1669 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x7316 (or $x6953 false)))
(and (not $x7316) (or $x7316 (and (distinct ?x1600 ?x1600) true)))))))))))
(check-sat)
; query 73: function crcu8, block 6, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x44283 ((_ extract 7 0) in.01_16)))
(let ((?x420 ((_ zero_extend 24) ?x44283)))
(let ((?x715 (bvand ?x420 (_ bv1 32))))
(let ((?x1849 ((_ zero_extend 24) in.0_8)))
(let ((?x43909 (bvand ?x1849 (_ bv1 32))))
(let ((?x9501 (bvxor ?x43909 ?x715)))
(let ((?x7874 ((_ extract 7 0) ?x9501)))
(let ((?x1644 ((_ zero_extend 24) ?x7874)))
(let (($x592 (or false false)))
(let (($x43089 (or $x592 false)))
(let (($x8131 (or $x43089 false false)))
(let (($x1669 (or $x592 false false)))
(let (($x7152 (or $x1669 $x8131 false)))
(let (($x823 (or $x7152 false)))
(let (($x42776 (or $x823 false)))
(and (not $x42776) (or $x42776 (and (distinct ?x1644 ?x1644) true)))))))))))))))))))
(check-sat)
; query 74: function crcu8, block 6, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x44283 ((_ extract 7 0) in.01_16)))
(let ((?x420 ((_ zero_extend 24) ?x44283)))
(let ((?x715 (bvand ?x420 (_ bv1 32))))
(let ((?x1849 ((_ zero_extend 24) in.0_8)))
(let ((?x43909 (bvand ?x1849 (_ bv1 32))))
(let ((?x9501 (bvxor ?x43909 ?x715)))
(let ((?x7874 ((_ extract 7 0) ?x9501)))
(let ((?x1644 ((_ zero_extend 24) ?x7874)))
(let ((?x20339 (ite (= (_ bv1 32) ?x1644) (_ bv1 1) (_ bv0 1))))
(let (($x592 (or false false)))
(let (($x43089 (or $x592 false)))
(let (($x8131 (or $x43089 false false)))
(let (($x1669 (or $x592 false false)))
(let (($x7152 (or $x1669 $x8131 false)))
(let (($x823 (or $x7152 false)))
(let (($x42776 (or $x823 false)))
(let (($x1601 (or $x42776 false false)))
(and (not $x1601) (or $x1601 (and (distinct ?x20339 ?x20339) true)))))))))))))))))))))
(check-sat)
; query 75: function crcu8, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x592 (or false false)))
(let (($x488 (not $x592)))
(and $x488 (or $x592 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 76: function crcu8, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1849 ((_ zero_extend 24) in.0_8)))
(let ((?x43909 (bvand ?x1849 (_ bv1 32))))
(let (($x592 (or false false)))
(let (($x1669 (or $x592 false false)))
(let (($x77 (not $x1669)))
(and $x77 (or $x1669 (and (distinct ?x43909 ?x43909) true)))))))))
(check-sat)
; query 77: function crcu8, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x592 (or false false)))
(let (($x488 (not $x592)))
(and $x488 (or $x592 (and (distinct ((_ extract 7 0) in.01_16) ((_ extract 7 0) in.01_16)) true))))))
(check-sat)
; query 78: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x2014 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2288 ((_ zero_extend 31) ?x2014)))
(let ((?x16210 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x38522 ((_ zero_extend 31) ?x16210)))
(let ((?x646 (bvand ?x38522 ?x2288)))
(let ((?x38592 (ite (and (distinct (_ bv0 32) ?x646) true) (_ bv1 1) (_ bv0 1))))
(let ((?x251 ((_ zero_extend 63) ?x38592)))
(let (($x592 (or false false)))
(let (($x1669 (or $x592 false false)))
(let (($x555 (or $x1669 false)))
(let (($x40808 (or $x555 $x555 false)))
(let (($x724 (or $x40808 false false)))
(let (($x980 (or $x724 false)))
(and (not $x980) (or $x980 (and (distinct ?x251 ?x251) true)))))))))))))))))
(check-sat)
; query 79: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x2014 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2288 ((_ zero_extend 31) ?x2014)))
(let ((?x16210 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x38522 ((_ zero_extend 31) ?x16210)))
(let ((?x646 (bvand ?x38522 ?x2288)))
(let ((?x38592 (ite (and (distinct (_ bv0 32) ?x646) true) (_ bv1 1) (_ bv0 1))))
(let (($x38750 (= (_ bv1 1) ?x38592)))
(let ((?x39059 (ite $x38750 (_ bv1 32) (_ bv0 32))))
(let (($x592 (or false false)))
(let (($x1669 (or $x592 false false)))
(let (($x555 (or $x1669 false)))
(let (($x40808 (or $x555 $x555 false)))
(let (($x724 (or $x40808 false false)))
(let (($x39996 (or $x724 (ite $x38750 false false))))
(and (not $x39996) (or $x39996 (and (distinct ?x39059 ?x39059) true))))))))))))))))))
(check-sat)
; query 80: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x2014 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2288 ((_ zero_extend 31) ?x2014)))
(let ((?x16210 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x38522 ((_ zero_extend 31) ?x16210)))
(let ((?x646 (bvand ?x38522 ?x2288)))
(let ((?x38592 (ite (and (distinct (_ bv0 32) ?x646) true) (_ bv1 1) (_ bv0 1))))
(let (($x38750 (= (_ bv1 1) ?x38592)))
(let ((?x39059 (ite $x38750 (_ bv1 32) (_ bv0 32))))
(let ((?x44696 ((_ extract 7 0) ?x39059)))
(let (($x592 (or false false)))
(let (($x1669 (or $x592 false false)))
(let (($x555 (or $x1669 false)))
(let (($x40808 (or $x555 $x555 false)))
(let (($x724 (or $x40808 false false)))
(let (($x39996 (or $x724 (ite $x38750 false false))))
(let (($x16865 (or $x39996 false)))
(and (not $x16865) (or $x16865 (and (distinct ?x44696 ?x44696) true))))))))))))))))))))
(check-sat)
; query 81: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x592 (or false false)))
(let (($x488 (not $x592)))
(and $x488 (or $x592 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 82: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x16210 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x592 (or false false)))
(let (($x1669 (or $x592 false false)))
(let (($x77 (not $x1669)))
(and $x77 (or $x1669 (and (distinct ?x16210 ?x16210) true))))))))
(check-sat)
; query 83: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x16210 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x38522 ((_ zero_extend 31) ?x16210)))
(let (($x592 (or false false)))
(let (($x1669 (or $x592 false false)))
(let (($x555 (or $x1669 false)))
(let (($x528 (not $x555)))
(and $x528 (or $x555 (and (distinct ?x38522 ?x38522) true))))))))))
(check-sat)
; query 84: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x592 (or false false)))
(let (($x488 (not $x592)))
(and $x488 (or $x592 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 85: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x2014 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x592 (or false false)))
(let (($x1669 (or $x592 false false)))
(let (($x77 (not $x1669)))
(and $x77 (or $x1669 (and (distinct ?x2014 ?x2014) true))))))))
(check-sat)
; query 86: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x2014 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2288 ((_ zero_extend 31) ?x2014)))
(let (($x592 (or false false)))
(let (($x1669 (or $x592 false false)))
(let (($x555 (or $x1669 false)))
(let (($x528 (not $x555)))
(and $x528 (or $x555 (and (distinct ?x2288 ?x2288) true))))))))))
(check-sat)
; query 87: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x2014 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2288 ((_ zero_extend 31) ?x2014)))
(let ((?x16210 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x38522 ((_ zero_extend 31) ?x16210)))
(let ((?x646 (bvand ?x38522 ?x2288)))
(let (($x592 (or false false)))
(let (($x1669 (or $x592 false false)))
(let (($x555 (or $x1669 false)))
(let (($x40808 (or $x555 $x555 false)))
(and (not $x40808) (or $x40808 (and (distinct ?x646 ?x646) true)))))))))))))
(check-sat)
; query 88: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x2014 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2288 ((_ zero_extend 31) ?x2014)))
(let ((?x16210 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x38522 ((_ zero_extend 31) ?x16210)))
(let ((?x646 (bvand ?x38522 ?x2288)))
(let ((?x38592 (ite (and (distinct (_ bv0 32) ?x646) true) (_ bv1 1) (_ bv0 1))))
(let (($x592 (or false false)))
(let (($x1669 (or $x592 false false)))
(let (($x555 (or $x1669 false)))
(let (($x40808 (or $x555 $x555 false)))
(let (($x724 (or $x40808 false false)))
(and (not $x724) (or $x724 (and (distinct ?x38592 ?x38592) true)))))))))))))))
(check-sat)
; query 89: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x21465 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x95 (or false false false)))
(let (($x28 (not $x95)))
(and $x28 (or $x95 (and (distinct ?x21465 ?x21465) true)))))))
(check-sat)
; query 90: function matrix_add_const, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x95 (or false false false)))
(let (($x28 (not $x95)))
(and $x28 (or $x95 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 91: function matrix_add_const, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x166 (bvadd in.01_32 (_ bv1 32))))
(let (($x38715 (and (distinct ?x166 ?x166) true)))
(let (($x95 (or false false false)))
(let (($x28 (not $x95)))
(and $x28 (or $x95 $x38715)))))))
(check-sat)
; query 92: function matrix_mul_const, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x95 (or false false false)))
(let (($x28 (not $x95)))
(and $x28 (or $x95 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 93: function matrix_mul_const, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x166 (bvadd in.01_32 (_ bv1 32))))
(let (($x38715 (and (distinct ?x166 ?x166) true)))
(let (($x95 (or false false false)))
(let (($x28 (not $x95)))
(and $x28 (or $x95 $x38715)))))))
(check-sat)
; query 94: function matrix_mul_matrix, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x95 (or false false false)))
(let (($x28 (not $x95)))
(and $x28 (or $x95 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 95: function matrix_mul_matrix, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x166 (bvadd in.01_32 (_ bv1 32))))
(let (($x38715 (and (distinct ?x166 ?x166) true)))
(let (($x95 (or false false false)))
(let (($x28 (not $x95)))
(and $x28 (or $x95 $x38715)))))))
(check-sat)
; query 96: function matrix_mul_matrix, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x95 (or false false false)))
(let (($x28 (not $x95)))
(and $x28 (or $x95 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 97: function matrix_mul_matrix_bitextract, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x95 (or false false false)))
(let (($x28 (not $x95)))
(and $x28 (or $x95 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 98: function matrix_mul_matrix_bitextract, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x166 (bvadd in.01_32 (_ bv1 32))))
(let (($x38715 (and (distinct ?x166 ?x166) true)))
(let (($x95 (or false false false)))
(let (($x28 (not $x95)))
(and $x28 (or $x95 $x38715)))))))
(check-sat)
; query 99: function matrix_mul_matrix_bitextract, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x95 (or false false false)))
(let (($x28 (not $x95)))
(and $x28 (or $x95 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 100: function matrix_mul_vect, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x95 (or false false false)))
(let (($x28 (not $x95)))
(and $x28 (or $x95 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 101: function matrix_mul_vect, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x166 (bvadd in.01_32 (_ bv1 32))))
(let (($x38715 (and (distinct ?x166 ?x166) true)))
(let (($x95 (or false false false)))
(let (($x28 (not $x95)))
(and $x28 (or $x95 $x38715)))))))
(check-sat)
; query 102: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x592 (or false false)))
(let (($x488 (not $x592)))
(and $x488 (or $x592 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 103: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x333 ((_ sign_extend 16) in.1_16)))
(let ((?x17725 (bvadd ?x333 (_ bv10 32))))
(let (($x13892 (and (distinct (bvadd ((_ sign_extend 1) ?x333) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x17725)) true)))
(let (($x592 (or false false)))
(let (($x1019 (or $x592 false (or $x13892))))
(and (not $x1019) (or $x1019 (and (distinct ?x17725 ?x17725) true)))))))))
(check-sat)
; query 104: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x333 ((_ sign_extend 16) in.1_16)))
(let ((?x17725 (bvadd ?x333 (_ bv10 32))))
(let ((?x15758 ((_ extract 15 0) ?x17725)))
(let (($x13892 (and (distinct (bvadd ((_ sign_extend 1) ?x333) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x17725)) true)))
(let (($x592 (or false false)))
(let (($x1019 (or $x592 false (or $x13892))))
(let (($x21071 (or $x1019 false)))
(and (not $x21071) (or $x21071 (and (distinct ?x15758 ?x15758) true)))))))))))
(check-sat)
; query 105: function matrix_sum, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x44521 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x95 (or false false false)))
(let (($x28 (not $x95)))
(and $x28 (or $x95 (and (distinct ?x44521 ?x44521) true)))))))
(check-sat)
; query 106: function matrix_sum, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x44521 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let ((?x10735 ((_ zero_extend 63) ?x44521)))
(let (($x95 (or false false false)))
(let (($x1300 (or $x95 false)))
(and (not $x1300) (or $x1300 (and (distinct ?x10735 ?x10735) true))))))))
(check-sat)
; query 107: function matrix_sum, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x44521 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x14070 (= (_ bv1 1) ?x44521)))
(let ((?x16234 (ite $x14070 (_ bv1 32) (_ bv0 32))))
(let (($x95 (or false false false)))
(let (($x967 (or $x95 (ite $x14070 false false))))
(and (not $x967) (or $x967 (and (distinct ?x16234 ?x16234) true)))))))))
(check-sat)
; query 108: function matrix_sum, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x592 (or false false)))
(let (($x488 (not $x592)))
(and $x488 (or $x592 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 109: function matrix_sum, block 22, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x44521 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x14070 (= (_ bv1 1) ?x44521)))
(let ((?x16234 (ite $x14070 (_ bv1 32) (_ bv0 32))))
(let ((?x333 ((_ sign_extend 16) in.1_16)))
(let ((?x21141 (bvadd ?x333 ?x16234)))
(let (($x2070 (and (distinct (bvadd ((_ sign_extend 1) ?x333) ((_ sign_extend 1) ?x16234)) ((_ sign_extend 1) ?x21141)) true)))
(let (($x95 (or false false false)))
(let (($x967 (or $x95 (ite $x14070 false false))))
(let (($x592 (or false false)))
(let (($x40161 (or $x592 $x967 (or $x2070))))
(and (not $x40161) (or $x40161 (and (distinct ?x21141 ?x21141) true))))))))))))))
(check-sat)
; query 110: function matrix_sum, block 22, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x44521 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x14070 (= (_ bv1 1) ?x44521)))
(let ((?x16234 (ite $x14070 (_ bv1 32) (_ bv0 32))))
(let ((?x333 ((_ sign_extend 16) in.1_16)))
(let ((?x21141 (bvadd ?x333 ?x16234)))
(let ((?x43369 ((_ extract 15 0) ?x21141)))
(let (($x2070 (and (distinct (bvadd ((_ sign_extend 1) ?x333) ((_ sign_extend 1) ?x16234)) ((_ sign_extend 1) ?x21141)) true)))
(let (($x95 (or false false false)))
(let (($x967 (or $x95 (ite $x14070 false false))))
(let (($x592 (or false false)))
(let (($x40161 (or $x592 $x967 (or $x2070))))
(let (($x44103 (or $x40161 false)))
(and (not $x44103) (or $x44103 (and (distinct ?x43369 ?x43369) true))))))))))))))))
(check-sat)
; query 111: function matrix_sum, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x95 (or false false false)))
(let (($x28 (not $x95)))
(and $x28 (or $x95 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 112: function matrix_sum, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x166 (bvadd in.01_32 (_ bv1 32))))
(let (($x38715 (and (distinct ?x166 ?x166) true)))
(let (($x95 (or false false false)))
(let (($x28 (not $x95)))
(and $x28 (or $x95 $x38715)))))))
(check-sat)
; query 113: function parseval, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.23_32 () (_ BitVec 32))
(assert
 (let (($x17929 (and (distinct (bvmul ((_ sign_extend 32) in.23_32) ((_ sign_extend 32) (_ bv1024 32))) ((_ sign_extend 32) (bvmul in.23_32 (_ bv1024 32)))) true)))
(let (($x39453 (or false false (or $x17929))))
(and (not $x39453) (or $x39453 (and (distinct (bvmul in.23_32 (_ bv1024 32)) (bvmul in.23_32 (_ bv1024 32))) true))))))
(check-sat)
; query 114: function parseval, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.34_32 () (_ BitVec 32))
(assert
 (let (($x40383 (and (distinct (bvmul ((_ sign_extend 32) in.34_32) ((_ sign_extend 32) (_ bv1048576 32))) ((_ sign_extend 32) (bvmul in.34_32 (_ bv1048576 32)))) true)))
(let (($x16897 (or false false (or $x40383))))
(and (not $x16897) (or $x16897 (and (distinct (bvmul in.34_32 (_ bv1048576 32)) (bvmul in.34_32 (_ bv1048576 32))) true))))))
(check-sat)
; query 115: function partition_memory, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x95 (or false false false)))
(let (($x28 (not $x95)))
(and $x28 (or $x95 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
