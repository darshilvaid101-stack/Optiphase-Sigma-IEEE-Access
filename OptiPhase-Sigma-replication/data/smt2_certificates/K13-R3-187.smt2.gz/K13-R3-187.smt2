; OptiPhase-Sigma refinement certificate for sweep K13-R3-187
; query 0: function init_array, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x116 (and (distinct (bvadd ((_ zero_extend 1) in.0_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x66 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x121 (or (or false false (or $x66 $x116)) (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))
(and (not (or false false (or $x66))) $x121)))))
(check-sat)
; query 1: function init_array, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x74 (and (distinct (bvadd ((_ zero_extend 1) in.01_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x77 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x72 (or (or false false (or $x77 $x74)) (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))
(and (not (or false false (or $x77))) $x72)))))
(check-sat)
; query 2: function init_array, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x20 (and (distinct (bvadd ((_ zero_extend 1) in.02_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x54 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x80 (or (or false false (or $x54 $x20)) (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))
(and (not (or false false (or $x54))) $x80)))))
(check-sat)
; query 3: function init_array, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x41 (and (distinct (bvadd ((_ zero_extend 1) in.1_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x24 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x51 (or (or false false (or $x24 $x41)) (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))
(and (not (or false false (or $x24))) $x51)))))
(check-sat)
; query 4: function init_array, block 54, name %55
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.13_32 () (_ BitVec 32))
(assert
 (let (($x120 (and (distinct (bvadd ((_ zero_extend 1) in.13_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.13_32 (_ bv1 32)))) true)))
(let (($x47 (and (distinct (bvadd ((_ sign_extend 1) in.13_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.13_32 (_ bv1 32)))) true)))
(let (($x59 (or (or false false (or $x47 $x120)) (and (distinct (bvadd in.13_32 (_ bv1 32)) (bvadd in.13_32 (_ bv1 32))) true))))
(and (not (or false false (or $x47))) $x59)))))
(check-sat)
; query 5: function kernel_doitgen, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x116 (and (distinct (bvadd ((_ zero_extend 1) in.0_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x66 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x121 (or (or false false (or $x66 $x116)) (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))
(and (not (or false false (or $x66))) $x121)))))
(check-sat)
; query 6: function kernel_doitgen, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x74 (and (distinct (bvadd ((_ zero_extend 1) in.01_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x77 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x72 (or (or false false (or $x77 $x74)) (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))
(and (not (or false false (or $x77))) $x72)))))
(check-sat)
; query 7: function kernel_doitgen, block 55, name %56
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x41 (and (distinct (bvadd ((_ zero_extend 1) in.1_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x24 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x51 (or (or false false (or $x24 $x41)) (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))
(and (not (or false false (or $x24))) $x51)))))
(check-sat)
; query 8: function kernel_doitgen, block 58, name %59
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x20 (and (distinct (bvadd ((_ zero_extend 1) in.02_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x54 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x80 (or (or false false (or $x54 $x20)) (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))
(and (not (or false false (or $x54))) $x80)))))
(check-sat)
; query 9: function kernel_doitgen, block 61, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_32 () (_ BitVec 32))
(assert
 (let (($x93 (and (distinct (bvadd ((_ zero_extend 1) in.03_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.03_32 (_ bv1 32)))) true)))
(let (($x98 (and (distinct (bvadd ((_ sign_extend 1) in.03_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.03_32 (_ bv1 32)))) true)))
(let (($x109 (or (or false false (or $x98 $x93)) (and (distinct (bvadd in.03_32 (_ bv1 32)) (bvadd in.03_32 (_ bv1 32))) true))))
(and (not (or false false (or $x98))) $x109)))))
(check-sat)
