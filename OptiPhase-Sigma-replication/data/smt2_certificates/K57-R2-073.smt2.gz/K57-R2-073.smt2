; OptiPhase-Sigma refinement certificate for sweep K57-R2-073
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x896 (or false false)))
(let (($x15 (not $x896)))
(and $x15 (or $x896 (and (distinct ((_ sign_extend 16) in25_16) ((_ sign_extend 16) in25_16)) true))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let ((?x1575 (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))))
(let (($x896 (or false false)))
(let (($x449 (or $x896 false false)))
(let (($x24 (not $x449)))
(and $x24 (or $x449 (and (distinct ?x1575 ?x1575) true))))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x896 (or false false)))
(let (($x15 (not $x896)))
(and $x15 (or $x896 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x398 ((_ sign_extend 16) in3_16)))
(let ((?x287 (bvand ?x398 (_ bv127 32))))
(let (($x896 (or false false)))
(let (($x449 (or $x896 false false)))
(let (($x24 (not $x449)))
(and $x24 (or $x449 (and (distinct ?x287 ?x287) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x398 ((_ sign_extend 16) in3_16)))
(let ((?x287 (bvand ?x398 (_ bv127 32))))
(let ((?x340 ((_ extract 15 0) ?x287)))
(let (($x896 (or false false)))
(let (($x449 (or $x896 false false)))
(let (($x763 (or $x449 false)))
(let (($x78 (not $x763)))
(and $x78 (or $x763 (and (distinct ?x340 ?x340) true)))))))))))
(check-sat)
; query 5: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x896 (or false false)))
(let (($x15 (not $x896)))
(and $x15 (or $x896 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 6: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x1499 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x896 (or false false)))
(let (($x449 (or $x896 false false)))
(let (($x24 (not $x449)))
(and $x24 (or $x449 (and (distinct ?x1499 ?x1499) true))))))))
(check-sat)
; query 7: function core_bench_list, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x1685 (or false false false)))
(let (($x60 (not $x1685)))
(and $x60 (or $x1685 (and (distinct (bvadd in.0_16 (_ bv1 16)) (bvadd in.0_16 (_ bv1 16))) true))))))
(check-sat)
; query 8: function core_bench_state, block 105, name %106
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x1685 (or false false false)))
(let (($x60 (not $x1685)))
(and $x60 (or $x1685 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 9: function core_bench_state, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1685 (or false false false)))
(let (($x60 (not $x1685)))
(and $x60 (or $x1685 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 10: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x83 (bvadd in.01_32 (_ bv1 32))))
(let (($x147 (and (distinct ?x83 ?x83) true)))
(let (($x1685 (or false false false)))
(let (($x60 (not $x1685)))
(and $x60 (or $x1685 $x147)))))))
(check-sat)
; query 11: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x83 (bvadd in.01_32 (_ bv1 32))))
(let ((?x559 (bvmul ?x83 ?x83)))
(let (($x1685 (or false false false)))
(let (($x52 (or $x1685 $x1685 false)))
(and (not $x52) (or $x52 (and (distinct ?x559 ?x559) true))))))))
(check-sat)
; query 12: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x83 (bvadd in.01_32 (_ bv1 32))))
(let ((?x559 (bvmul ?x83 ?x83)))
(let ((?x500 (bvmul ?x559 (_ bv2 32))))
(let (($x1685 (or false false false)))
(let (($x52 (or $x1685 $x1685 false)))
(let (($x12 (or $x52 false false)))
(and (not $x12) (or $x12 (and (distinct ?x500 ?x500) true))))))))))
(check-sat)
; query 13: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x83 (bvadd in.01_32 (_ bv1 32))))
(let ((?x559 (bvmul ?x83 ?x83)))
(let ((?x500 (bvmul ?x559 (_ bv2 32))))
(let ((?x544 (bvmul ?x500 (_ bv4 32))))
(let (($x1685 (or false false false)))
(let (($x52 (or $x1685 $x1685 false)))
(let (($x12 (or $x52 false false)))
(let (($x533 (or $x12 false false)))
(and (not $x533) (or $x533 (and (distinct ?x544 ?x544) true))))))))))))
(check-sat)
; query 14: function core_init_matrix, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x1685 (or false false false)))
(let (($x60 (not $x1685)))
(and $x60 (or $x1685 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 15: function core_init_matrix, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x1685 (or false false false)))
(let (($x60 (not $x1685)))
(and $x60 (or $x1685 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 16: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x594 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x1685 (or false false false)))
(let (($x60 (not $x1685)))
(and $x60 (or $x1685 (and (distinct ?x594 ?x594) true)))))))
(check-sat)
; query 17: function core_init_state, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_32 () (_ BitVec 32))
(assert
 (let (($x1685 (or false false false)))
(let (($x60 (not $x1685)))
(and $x60 (or $x1685 (and (distinct (bvadd in.06_32 (_ bv1 32)) (bvadd in.06_32 (_ bv1 32))) true))))))
(check-sat)
; query 18: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x555 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x1685 (or false false false)))
(let (($x60 (not $x1685)))
(and $x60 (or $x1685 (and (distinct ?x555 ?x555) true)))))))
(check-sat)
; query 19: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x1685 (or false false false)))
(let (($x60 (not $x1685)))
(and $x60 (or $x1685 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 20: function core_list_init, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x83 (bvadd in.01_32 (_ bv1 32))))
(let (($x147 (and (distinct ?x83 ?x83) true)))
(let (($x1685 (or false false false)))
(let (($x60 (not $x1685)))
(and $x60 (or $x1685 $x147)))))))
(check-sat)
; query 21: function core_list_mergesort, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x83 (bvadd in.01_32 (_ bv1 32))))
(let (($x147 (and (distinct ?x83 ?x83) true)))
(let (($x427 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x83)) true)))
(let (($x127 (or false false (or $x427))))
(and (not $x127) (or $x127 $x147)))))))
(check-sat)
; query 22: function core_list_mergesort, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x47 (ite (bvslt (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x1685 (or false false false)))
(let (($x60 (not $x1685)))
(and $x60 (or $x1685 (and (distinct ?x47 ?x47) true)))))))
(check-sat)
; query 23: function core_list_mergesort, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.224_32 () (_ BitVec 32))
(assert
 (let ((?x42 (ite (= (_ bv0 32) in.224_32) (_ bv1 1) (_ bv0 1))))
(let (($x1685 (or false false false)))
(let (($x60 (not $x1685)))
(and $x60 (or $x1685 (and (distinct ?x42 ?x42) true)))))))
(check-sat)
; query 24: function core_list_mergesort, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x531 (ite (= (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x1685 (or false false false)))
(let (($x60 (not $x1685)))
(and $x60 (or $x1685 (and (distinct ?x531 ?x531) true)))))))
(check-sat)
; query 25: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x296 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x19 (or false false (or $x296))))
(and (not $x19) (or $x19 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 26: function core_list_mergesort, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x72 (and (distinct (bvmul ((_ sign_extend 32) in.020_32) ((_ sign_extend 32) (_ bv2 32))) ((_ sign_extend 32) (bvmul in.020_32 (_ bv2 32)))) true)))
(let (($x23 (or false false (or $x72))))
(and (not $x23) (or $x23 (and (distinct (bvmul in.020_32 (_ bv2 32)) (bvmul in.020_32 (_ bv2 32))) true))))))
(check-sat)
; query 27: function core_state_transition, block 102, name %103
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x896 (or false false)))
(let (($x15 (not $x896)))
(and $x15 (or $x896 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 28: function core_state_transition, block 102, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x2614 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x896 (or false false)))
(let (($x449 (or $x896 false false)))
(let (($x24 (not $x449)))
(and $x24 (or $x449 (and (distinct ?x2614 ?x2614) true))))))))
(check-sat)
; query 29: function core_state_transition, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x896 (or false false)))
(let (($x15 (not $x896)))
(and $x15 (or $x896 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 30: function core_state_transition, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x627 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x896 (or false false)))
(let (($x449 (or $x896 false false)))
(let (($x24 (not $x449)))
(and $x24 (or $x449 (and (distinct ?x627 ?x627) true))))))))
(check-sat)
; query 31: function core_state_transition, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x896 (or false false)))
(let (($x15 (not $x896)))
(and $x15 (or $x896 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 32: function core_state_transition, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x2614 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x896 (or false false)))
(let (($x449 (or $x896 false false)))
(let (($x24 (not $x449)))
(and $x24 (or $x449 (and (distinct ?x2614 ?x2614) true))))))))
(check-sat)
; query 33: function core_state_transition, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x896 (or false false)))
(let (($x15 (not $x896)))
(and $x15 (or $x896 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 34: function core_state_transition, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x117 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x896 (or false false)))
(let (($x449 (or $x896 false false)))
(let (($x24 (not $x449)))
(and $x24 (or $x449 (and (distinct ?x117 ?x117) true))))))))
(check-sat)
; query 35: function core_state_transition, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x896 (or false false)))
(let (($x15 (not $x896)))
(and $x15 (or $x896 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 36: function core_state_transition, block 51, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x117 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x896 (or false false)))
(let (($x449 (or $x896 false false)))
(let (($x24 (not $x449)))
(and $x24 (or $x449 (and (distinct ?x117 ?x117) true))))))))
(check-sat)
; query 37: function core_state_transition, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x896 (or false false)))
(let (($x15 (not $x896)))
(and $x15 (or $x896 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 38: function core_state_transition, block 64, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x117 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x896 (or false false)))
(let (($x449 (or $x896 false false)))
(let (($x24 (not $x449)))
(and $x24 (or $x449 (and (distinct ?x117 ?x117) true))))))))
(check-sat)
; query 39: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x93 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x1685 (or false false false)))
(let (($x60 (not $x1685)))
(and $x60 (or $x1685 (and (distinct ?x93 ?x93) true)))))))
(check-sat)
; query 40: function core_state_transition, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x896 (or false false)))
(let (($x15 (not $x896)))
(and $x15 (or $x896 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 41: function core_state_transition, block 80, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1750 (ite (= (_ bv69 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x896 (or false false)))
(let (($x449 (or $x896 false false)))
(let (($x24 (not $x449)))
(and $x24 (or $x449 (and (distinct ?x1750 ?x1750) true))))))))
(check-sat)
; query 42: function core_state_transition, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x896 (or false false)))
(let (($x15 (not $x896)))
(and $x15 (or $x896 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 43: function core_state_transition, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1634 (ite (= (_ bv101 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x896 (or false false)))
(let (($x449 (or $x896 false false)))
(let (($x24 (not $x449)))
(and $x24 (or $x449 (and (distinct ?x1634 ?x1634) true))))))))
(check-sat)
; query 44: function core_state_transition, block 99, name %100
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x896 (or false false)))
(let (($x15 (not $x896)))
(and $x15 (or $x896 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 45: function core_state_transition, block 99, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x627 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x896 (or false false)))
(let (($x449 (or $x896 false false)))
(let (($x24 (not $x449)))
(and $x24 (or $x449 (and (distinct ?x627 ?x627) true))))))))
(check-sat)
; query 46: function crcu8, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x896 (or false false)))
(let (($x15 (not $x896)))
(and $x15 (or $x896 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 47: function crcu8, block 19, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x885 ((_ zero_extend 16) in.01_16)))
(let ((?x222 (bvxor ?x885 (_ bv16386 32))))
(let (($x896 (or false false)))
(let (($x449 (or $x896 false false)))
(let (($x24 (not $x449)))
(and $x24 (or $x449 (and (distinct ?x222 ?x222) true)))))))))
(check-sat)
; query 48: function crcu8, block 19, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x885 ((_ zero_extend 16) in.01_16)))
(let ((?x222 (bvxor ?x885 (_ bv16386 32))))
(let ((?x1617 ((_ extract 15 0) ?x222)))
(let (($x896 (or false false)))
(let (($x449 (or $x896 false false)))
(let (($x763 (or $x449 false)))
(let (($x78 (not $x763)))
(and $x78 (or $x763 (and (distinct ?x1617 ?x1617) true)))))))))))
(check-sat)
; query 49: function crcu8, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x896 (or false false)))
(let (($x15 (not $x896)))
(and $x15 (or $x896 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 50: function crcu8, block 29, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1837 ((_ zero_extend 16) in27_16)))
(let ((?x1689 (bvor ?x1837 (_ bv32768 32))))
(let (($x896 (or false false)))
(let (($x449 (or $x896 false false)))
(let (($x24 (not $x449)))
(and $x24 (or $x449 (and (distinct ?x1689 ?x1689) true)))))))))
(check-sat)
; query 51: function crcu8, block 29, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1837 ((_ zero_extend 16) in27_16)))
(let ((?x1689 (bvor ?x1837 (_ bv32768 32))))
(let ((?x1791 ((_ extract 15 0) ?x1689)))
(let (($x896 (or false false)))
(let (($x449 (or $x896 false false)))
(let (($x763 (or $x449 false)))
(let (($x78 (not $x763)))
(and $x78 (or $x763 (and (distinct ?x1791 ?x1791) true)))))))))))
(check-sat)
; query 52: function crcu8, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x896 (or false false)))
(let (($x15 (not $x896)))
(and $x15 (or $x896 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 53: function crcu8, block 33, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1837 ((_ zero_extend 16) in27_16)))
(let ((?x883 (bvand ?x1837 (_ bv32767 32))))
(let (($x896 (or false false)))
(let (($x449 (or $x896 false false)))
(let (($x24 (not $x449)))
(and $x24 (or $x449 (and (distinct ?x883 ?x883) true)))))))))
(check-sat)
; query 54: function crcu8, block 33, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1837 ((_ zero_extend 16) in27_16)))
(let ((?x883 (bvand ?x1837 (_ bv32767 32))))
(let ((?x227 ((_ extract 15 0) ?x883)))
(let (($x896 (or false false)))
(let (($x449 (or $x896 false false)))
(let (($x763 (or $x449 false)))
(let (($x78 (not $x763)))
(and $x78 (or $x763 (and (distinct ?x227 ?x227) true)))))))))))
(check-sat)
; query 55: function crcu8, block 38, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_8 () (_ BitVec 8))
(assert
 (let (($x1685 (or false false false)))
(let (($x60 (not $x1685)))
(and $x60 (or $x1685 (and (distinct (bvadd in.02_8 (_ bv1 8)) (bvadd in.02_8 (_ bv1 8))) true))))))
(check-sat)
; query 56: function crcu8, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x219 ((_ extract 7 0) in.01_16)))
(let ((?x458 ((_ zero_extend 24) ?x219)))
(let (($x896 (or false false)))
(let (($x70 (or $x896 false)))
(and (not $x70) (or $x70 (and (distinct ?x458 ?x458) true))))))))
(check-sat)
; query 57: function crcu8, block 6, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x219 ((_ extract 7 0) in.01_16)))
(let ((?x458 ((_ zero_extend 24) ?x219)))
(let ((?x704 (bvand ?x458 (_ bv1 32))))
(let (($x896 (or false false)))
(let (($x70 (or $x896 false)))
(let (($x1887 (or $x70 false false)))
(and (not $x1887) (or $x1887 (and (distinct ?x704 ?x704) true))))))))))
(check-sat)
; query 58: function crcu8, block 6, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x219 ((_ extract 7 0) in.01_16)))
(let ((?x458 ((_ zero_extend 24) ?x219)))
(let ((?x704 (bvand ?x458 (_ bv1 32))))
(let ((?x163 ((_ zero_extend 24) in.0_8)))
(let ((?x2252 (bvand ?x163 (_ bv1 32))))
(let ((?x1246 (bvxor ?x2252 ?x704)))
(let (($x896 (or false false)))
(let (($x70 (or $x896 false)))
(let (($x1887 (or $x70 false false)))
(let (($x449 (or $x896 false false)))
(let (($x1492 (or $x449 $x1887 false)))
(and (not $x1492) (or $x1492 (and (distinct ?x1246 ?x1246) true)))))))))))))))
(check-sat)
; query 59: function crcu8, block 6, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x219 ((_ extract 7 0) in.01_16)))
(let ((?x458 ((_ zero_extend 24) ?x219)))
(let ((?x704 (bvand ?x458 (_ bv1 32))))
(let ((?x163 ((_ zero_extend 24) in.0_8)))
(let ((?x2252 (bvand ?x163 (_ bv1 32))))
(let ((?x1246 (bvxor ?x2252 ?x704)))
(let ((?x1334 ((_ extract 7 0) ?x1246)))
(let (($x896 (or false false)))
(let (($x70 (or $x896 false)))
(let (($x1887 (or $x70 false false)))
(let (($x449 (or $x896 false false)))
(let (($x1492 (or $x449 $x1887 false)))
(let (($x1042 (or $x1492 false)))
(and (not $x1042) (or $x1042 (and (distinct ?x1334 ?x1334) true)))))))))))))))))
(check-sat)
; query 60: function crcu8, block 6, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x896 (or false false)))
(let (($x15 (not $x896)))
(and $x15 (or $x896 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 61: function crcu8, block 6, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x163 ((_ zero_extend 24) in.0_8)))
(let ((?x218 (bvashr ?x163 (_ bv1 32))))
(let (($x896 (or false false)))
(let (($x449 (or $x896 false false)))
(let (($x605 (or $x449 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not $x605) (or $x605 (and (distinct ?x218 ?x218) true)))))))))
(check-sat)
; query 62: function crcu8, block 6, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x163 ((_ zero_extend 24) in.0_8)))
(let ((?x218 (bvashr ?x163 (_ bv1 32))))
(let ((?x318 ((_ extract 7 0) ?x218)))
(let (($x896 (or false false)))
(let (($x449 (or $x896 false false)))
(let (($x605 (or $x449 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x1185 (or $x605 false)))
(and (not $x1185) (or $x1185 (and (distinct ?x318 ?x318) true)))))))))))
(check-sat)
; query 63: function crcu8, block 6, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x219 ((_ extract 7 0) in.01_16)))
(let ((?x458 ((_ zero_extend 24) ?x219)))
(let ((?x704 (bvand ?x458 (_ bv1 32))))
(let ((?x163 ((_ zero_extend 24) in.0_8)))
(let ((?x2252 (bvand ?x163 (_ bv1 32))))
(let ((?x1246 (bvxor ?x2252 ?x704)))
(let ((?x1334 ((_ extract 7 0) ?x1246)))
(let ((?x179 ((_ zero_extend 24) ?x1334)))
(let (($x896 (or false false)))
(let (($x70 (or $x896 false)))
(let (($x1887 (or $x70 false false)))
(let (($x449 (or $x896 false false)))
(let (($x1492 (or $x449 $x1887 false)))
(let (($x1042 (or $x1492 false)))
(let (($x2515 (or $x1042 false)))
(and (not $x2515) (or $x2515 (and (distinct ?x179 ?x179) true)))))))))))))))))))
(check-sat)
; query 64: function crcu8, block 6, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x219 ((_ extract 7 0) in.01_16)))
(let ((?x458 ((_ zero_extend 24) ?x219)))
(let ((?x704 (bvand ?x458 (_ bv1 32))))
(let ((?x163 ((_ zero_extend 24) in.0_8)))
(let ((?x2252 (bvand ?x163 (_ bv1 32))))
(let ((?x1246 (bvxor ?x2252 ?x704)))
(let ((?x1334 ((_ extract 7 0) ?x1246)))
(let ((?x179 ((_ zero_extend 24) ?x1334)))
(let ((?x1530 (ite (= (_ bv1 32) ?x179) (_ bv1 1) (_ bv0 1))))
(let (($x896 (or false false)))
(let (($x70 (or $x896 false)))
(let (($x1887 (or $x70 false false)))
(let (($x449 (or $x896 false false)))
(let (($x1492 (or $x449 $x1887 false)))
(let (($x1042 (or $x1492 false)))
(let (($x2515 (or $x1042 false)))
(let (($x881 (or $x2515 false false)))
(and (not $x881) (or $x881 (and (distinct ?x1530 ?x1530) true)))))))))))))))))))))
(check-sat)
; query 65: function crcu8, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x896 (or false false)))
(let (($x15 (not $x896)))
(and $x15 (or $x896 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 66: function crcu8, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x163 ((_ zero_extend 24) in.0_8)))
(let ((?x2252 (bvand ?x163 (_ bv1 32))))
(let (($x896 (or false false)))
(let (($x449 (or $x896 false false)))
(let (($x24 (not $x449)))
(and $x24 (or $x449 (and (distinct ?x2252 ?x2252) true)))))))))
(check-sat)
; query 67: function crcu8, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x896 (or false false)))
(let (($x15 (not $x896)))
(and $x15 (or $x896 (and (distinct ((_ extract 7 0) in.01_16) ((_ extract 7 0) in.01_16)) true))))))
(check-sat)
; query 68: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1734 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1557 ((_ zero_extend 31) ?x1734)))
(let ((?x624 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1707 ((_ zero_extend 31) ?x624)))
(let ((?x1442 (bvand ?x1707 ?x1557)))
(let ((?x313 (ite (and (distinct (_ bv0 32) ?x1442) true) (_ bv1 1) (_ bv0 1))))
(let ((?x434 ((_ zero_extend 63) ?x313)))
(let (($x896 (or false false)))
(let (($x449 (or $x896 false false)))
(let (($x763 (or $x449 false)))
(let (($x5 (or $x763 $x763 false)))
(let (($x1861 (or $x5 false false)))
(let (($x1377 (or $x1861 false)))
(and (not $x1377) (or $x1377 (and (distinct ?x434 ?x434) true)))))))))))))))))
(check-sat)
; query 69: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1734 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1557 ((_ zero_extend 31) ?x1734)))
(let ((?x624 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1707 ((_ zero_extend 31) ?x624)))
(let ((?x1442 (bvand ?x1707 ?x1557)))
(let ((?x313 (ite (and (distinct (_ bv0 32) ?x1442) true) (_ bv1 1) (_ bv0 1))))
(let (($x1031 (= (_ bv1 1) ?x313)))
(let ((?x1687 (ite $x1031 (_ bv1 32) (_ bv0 32))))
(let (($x896 (or false false)))
(let (($x449 (or $x896 false false)))
(let (($x763 (or $x449 false)))
(let (($x5 (or $x763 $x763 false)))
(let (($x1861 (or $x5 false false)))
(let (($x1641 (or $x1861 (ite $x1031 false false))))
(and (not $x1641) (or $x1641 (and (distinct ?x1687 ?x1687) true))))))))))))))))))
(check-sat)
; query 70: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1734 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1557 ((_ zero_extend 31) ?x1734)))
(let ((?x624 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1707 ((_ zero_extend 31) ?x624)))
(let ((?x1442 (bvand ?x1707 ?x1557)))
(let ((?x313 (ite (and (distinct (_ bv0 32) ?x1442) true) (_ bv1 1) (_ bv0 1))))
(let (($x1031 (= (_ bv1 1) ?x313)))
(let ((?x1687 (ite $x1031 (_ bv1 32) (_ bv0 32))))
(let ((?x1025 ((_ extract 7 0) ?x1687)))
(let (($x896 (or false false)))
(let (($x449 (or $x896 false false)))
(let (($x763 (or $x449 false)))
(let (($x5 (or $x763 $x763 false)))
(let (($x1861 (or $x5 false false)))
(let (($x1641 (or $x1861 (ite $x1031 false false))))
(let (($x660 (or $x1641 false)))
(and (not $x660) (or $x660 (and (distinct ?x1025 ?x1025) true))))))))))))))))))))
(check-sat)
; query 71: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x896 (or false false)))
(let (($x15 (not $x896)))
(and $x15 (or $x896 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 72: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x624 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x896 (or false false)))
(let (($x449 (or $x896 false false)))
(let (($x24 (not $x449)))
(and $x24 (or $x449 (and (distinct ?x624 ?x624) true))))))))
(check-sat)
; query 73: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x624 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1707 ((_ zero_extend 31) ?x624)))
(let (($x896 (or false false)))
(let (($x449 (or $x896 false false)))
(let (($x763 (or $x449 false)))
(let (($x78 (not $x763)))
(and $x78 (or $x763 (and (distinct ?x1707 ?x1707) true))))))))))
(check-sat)
; query 74: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x896 (or false false)))
(let (($x15 (not $x896)))
(and $x15 (or $x896 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 75: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1734 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x896 (or false false)))
(let (($x449 (or $x896 false false)))
(let (($x24 (not $x449)))
(and $x24 (or $x449 (and (distinct ?x1734 ?x1734) true))))))))
(check-sat)
; query 76: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1734 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1557 ((_ zero_extend 31) ?x1734)))
(let (($x896 (or false false)))
(let (($x449 (or $x896 false false)))
(let (($x763 (or $x449 false)))
(let (($x78 (not $x763)))
(and $x78 (or $x763 (and (distinct ?x1557 ?x1557) true))))))))))
(check-sat)
; query 77: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1734 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1557 ((_ zero_extend 31) ?x1734)))
(let ((?x624 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1707 ((_ zero_extend 31) ?x624)))
(let ((?x1442 (bvand ?x1707 ?x1557)))
(let (($x896 (or false false)))
(let (($x449 (or $x896 false false)))
(let (($x763 (or $x449 false)))
(let (($x5 (or $x763 $x763 false)))
(and (not $x5) (or $x5 (and (distinct ?x1442 ?x1442) true)))))))))))))
(check-sat)
; query 78: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1734 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1557 ((_ zero_extend 31) ?x1734)))
(let ((?x624 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1707 ((_ zero_extend 31) ?x624)))
(let ((?x1442 (bvand ?x1707 ?x1557)))
(let ((?x313 (ite (and (distinct (_ bv0 32) ?x1442) true) (_ bv1 1) (_ bv0 1))))
(let (($x896 (or false false)))
(let (($x449 (or $x896 false false)))
(let (($x763 (or $x449 false)))
(let (($x5 (or $x763 $x763 false)))
(let (($x1861 (or $x5 false false)))
(and (not $x1861) (or $x1861 (and (distinct ?x313 ?x313) true)))))))))))))))
(check-sat)
; query 79: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1580 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x1685 (or false false false)))
(let (($x60 (not $x1685)))
(and $x60 (or $x1685 (and (distinct ?x1580 ?x1580) true)))))))
(check-sat)
; query 80: function matrix_add_const, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1685 (or false false false)))
(let (($x60 (not $x1685)))
(and $x60 (or $x1685 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 81: function matrix_add_const, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x83 (bvadd in.01_32 (_ bv1 32))))
(let (($x147 (and (distinct ?x83 ?x83) true)))
(let (($x1685 (or false false false)))
(let (($x60 (not $x1685)))
(and $x60 (or $x1685 $x147)))))))
(check-sat)
; query 82: function matrix_mul_const, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1685 (or false false false)))
(let (($x60 (not $x1685)))
(and $x60 (or $x1685 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 83: function matrix_mul_const, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x83 (bvadd in.01_32 (_ bv1 32))))
(let (($x147 (and (distinct ?x83 ?x83) true)))
(let (($x1685 (or false false false)))
(let (($x60 (not $x1685)))
(and $x60 (or $x1685 $x147)))))))
(check-sat)
; query 84: function matrix_mul_matrix, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1685 (or false false false)))
(let (($x60 (not $x1685)))
(and $x60 (or $x1685 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 85: function matrix_mul_matrix, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x83 (bvadd in.01_32 (_ bv1 32))))
(let (($x147 (and (distinct ?x83 ?x83) true)))
(let (($x1685 (or false false false)))
(let (($x60 (not $x1685)))
(and $x60 (or $x1685 $x147)))))))
(check-sat)
; query 86: function matrix_mul_matrix, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x1685 (or false false false)))
(let (($x60 (not $x1685)))
(and $x60 (or $x1685 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 87: function matrix_mul_matrix_bitextract, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1685 (or false false false)))
(let (($x60 (not $x1685)))
(and $x60 (or $x1685 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 88: function matrix_mul_matrix_bitextract, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x83 (bvadd in.01_32 (_ bv1 32))))
(let (($x147 (and (distinct ?x83 ?x83) true)))
(let (($x1685 (or false false false)))
(let (($x60 (not $x1685)))
(and $x60 (or $x1685 $x147)))))))
(check-sat)
; query 89: function matrix_mul_matrix_bitextract, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x1685 (or false false false)))
(let (($x60 (not $x1685)))
(and $x60 (or $x1685 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 90: function matrix_mul_vect, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1685 (or false false false)))
(let (($x60 (not $x1685)))
(and $x60 (or $x1685 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 91: function matrix_mul_vect, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x83 (bvadd in.01_32 (_ bv1 32))))
(let (($x147 (and (distinct ?x83 ?x83) true)))
(let (($x1685 (or false false false)))
(let (($x60 (not $x1685)))
(and $x60 (or $x1685 $x147)))))))
(check-sat)
; query 92: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x896 (or false false)))
(let (($x15 (not $x896)))
(and $x15 (or $x896 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 93: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x522 ((_ sign_extend 16) in.1_16)))
(let ((?x180 (bvadd ?x522 (_ bv10 32))))
(let (($x1336 (and (distinct (bvadd ((_ sign_extend 1) ?x522) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x180)) true)))
(let (($x896 (or false false)))
(let (($x761 (or $x896 false (or $x1336))))
(and (not $x761) (or $x761 (and (distinct ?x180 ?x180) true)))))))))
(check-sat)
; query 94: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x522 ((_ sign_extend 16) in.1_16)))
(let ((?x180 (bvadd ?x522 (_ bv10 32))))
(let ((?x1960 ((_ extract 15 0) ?x180)))
(let (($x1336 (and (distinct (bvadd ((_ sign_extend 1) ?x522) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x180)) true)))
(let (($x896 (or false false)))
(let (($x761 (or $x896 false (or $x1336))))
(let (($x745 (or $x761 false)))
(and (not $x745) (or $x745 (and (distinct ?x1960 ?x1960) true)))))))))))
(check-sat)
; query 95: function matrix_sum, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x1487 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x1685 (or false false false)))
(let (($x60 (not $x1685)))
(and $x60 (or $x1685 (and (distinct ?x1487 ?x1487) true)))))))
(check-sat)
; query 96: function matrix_sum, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x1487 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let ((?x333 ((_ zero_extend 63) ?x1487)))
(let (($x1685 (or false false false)))
(let (($x133 (or $x1685 false)))
(and (not $x133) (or $x133 (and (distinct ?x333 ?x333) true))))))))
(check-sat)
; query 97: function matrix_sum, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x1487 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x1177 (= (_ bv1 1) ?x1487)))
(let ((?x1320 (ite $x1177 (_ bv1 32) (_ bv0 32))))
(let (($x1685 (or false false false)))
(let (($x422 (or $x1685 (ite $x1177 false false))))
(and (not $x422) (or $x422 (and (distinct ?x1320 ?x1320) true)))))))))
(check-sat)
; query 98: function matrix_sum, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x896 (or false false)))
(let (($x15 (not $x896)))
(and $x15 (or $x896 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 99: function matrix_sum, block 22, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x1487 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x1177 (= (_ bv1 1) ?x1487)))
(let ((?x1320 (ite $x1177 (_ bv1 32) (_ bv0 32))))
(let ((?x522 ((_ sign_extend 16) in.1_16)))
(let ((?x1797 (bvadd ?x522 ?x1320)))
(let (($x1732 (and (distinct (bvadd ((_ sign_extend 1) ?x522) ((_ sign_extend 1) ?x1320)) ((_ sign_extend 1) ?x1797)) true)))
(let (($x1685 (or false false false)))
(let (($x422 (or $x1685 (ite $x1177 false false))))
(let (($x896 (or false false)))
(let (($x1210 (or $x896 $x422 (or $x1732))))
(and (not $x1210) (or $x1210 (and (distinct ?x1797 ?x1797) true))))))))))))))
(check-sat)
; query 100: function matrix_sum, block 22, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x1487 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x1177 (= (_ bv1 1) ?x1487)))
(let ((?x1320 (ite $x1177 (_ bv1 32) (_ bv0 32))))
(let ((?x522 ((_ sign_extend 16) in.1_16)))
(let ((?x1797 (bvadd ?x522 ?x1320)))
(let ((?x363 ((_ extract 15 0) ?x1797)))
(let (($x1732 (and (distinct (bvadd ((_ sign_extend 1) ?x522) ((_ sign_extend 1) ?x1320)) ((_ sign_extend 1) ?x1797)) true)))
(let (($x1685 (or false false false)))
(let (($x422 (or $x1685 (ite $x1177 false false))))
(let (($x896 (or false false)))
(let (($x1210 (or $x896 $x422 (or $x1732))))
(let (($x1892 (or $x1210 false)))
(and (not $x1892) (or $x1892 (and (distinct ?x363 ?x363) true))))))))))))))))
(check-sat)
; query 101: function matrix_sum, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1685 (or false false false)))
(let (($x60 (not $x1685)))
(and $x60 (or $x1685 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 102: function matrix_sum, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x83 (bvadd in.01_32 (_ bv1 32))))
(let (($x147 (and (distinct ?x83 ?x83) true)))
(let (($x1685 (or false false false)))
(let (($x60 (not $x1685)))
(and $x60 (or $x1685 $x147)))))))
(check-sat)
; query 103: function parseval, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.23_32 () (_ BitVec 32))
(assert
 (let (($x1006 (and (distinct (bvmul ((_ sign_extend 32) in.23_32) ((_ sign_extend 32) (_ bv1024 32))) ((_ sign_extend 32) (bvmul in.23_32 (_ bv1024 32)))) true)))
(let (($x2638 (or false false (or $x1006))))
(and (not $x2638) (or $x2638 (and (distinct (bvmul in.23_32 (_ bv1024 32)) (bvmul in.23_32 (_ bv1024 32))) true))))))
(check-sat)
; query 104: function parseval, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.34_32 () (_ BitVec 32))
(assert
 (let (($x537 (and (distinct (bvmul ((_ sign_extend 32) in.34_32) ((_ sign_extend 32) (_ bv1048576 32))) ((_ sign_extend 32) (bvmul in.34_32 (_ bv1048576 32)))) true)))
(let (($x1094 (or false false (or $x537))))
(and (not $x1094) (or $x1094 (and (distinct (bvmul in.34_32 (_ bv1048576 32)) (bvmul in.34_32 (_ bv1048576 32))) true))))))
(check-sat)
; query 105: function partition_memory, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1685 (or false false false)))
(let (($x60 (not $x1685)))
(and $x60 (or $x1685 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
