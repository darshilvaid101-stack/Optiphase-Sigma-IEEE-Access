; OptiPhase-Sigma refinement certificate for sweep K21-R2-012
