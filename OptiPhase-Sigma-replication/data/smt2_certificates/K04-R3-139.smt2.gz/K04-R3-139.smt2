; OptiPhase-Sigma refinement certificate for sweep K04-R3-139
