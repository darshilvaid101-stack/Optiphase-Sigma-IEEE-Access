; OptiPhase-Sigma refinement certificate for sweep K08-R3-099
