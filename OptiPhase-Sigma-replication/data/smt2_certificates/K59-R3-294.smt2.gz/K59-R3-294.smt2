; OptiPhase-Sigma refinement certificate for sweep K59-R3-294
; query 0: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x1071 (or false false false)))
(let (($x192 (not $x1071)))
(and $x192 (or $x1071 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x591 (bvadd in.01_32 (_ bv1 32))))
(let ((?x276 (bvmul ?x591 ?x591)))
(let (($x1071 (or false false false)))
(let (($x123 (or $x1071 $x1071 false)))
(and (not $x123) (or $x123 (and (distinct ?x276 ?x276) true))))))))
(check-sat)
; query 2: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x591 (bvadd in.01_32 (_ bv1 32))))
(let ((?x276 (bvmul ?x591 ?x591)))
(let ((?x658 (bvmul ?x276 (_ bv2 32))))
(let (($x1071 (or false false false)))
(let (($x123 (or $x1071 $x1071 false)))
(let (($x453 (or $x123 false false)))
(and (not $x453) (or $x453 (and (distinct ?x658 ?x658) true))))))))))
(check-sat)
; query 3: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x591 (bvadd in.01_32 (_ bv1 32))))
(let ((?x276 (bvmul ?x591 ?x591)))
(let ((?x658 (bvmul ?x276 (_ bv2 32))))
(let ((?x131 (bvmul ?x658 (_ bv4 32))))
(let (($x1071 (or false false false)))
(let (($x123 (or $x1071 $x1071 false)))
(let (($x453 (or $x123 false false)))
(let (($x159 (or $x453 false false)))
(and (not $x159) (or $x159 (and (distinct ?x131 ?x131) true))))))))))))
(check-sat)
; query 4: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x1140 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x1071 (or false false false)))
(let (($x192 (not $x1071)))
(and $x192 (or $x1071 (and (distinct ?x1140 ?x1140) true)))))))
(check-sat)
; query 5: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x500 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x1071 (or false false false)))
(let (($x192 (not $x1071)))
(and $x192 (or $x1071 (and (distinct ?x500 ?x500) true)))))))
(check-sat)
; query 6: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x1071 (or false false false)))
(let (($x192 (not $x1071)))
(and $x192 (or $x1071 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 7: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x1174 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x944 (or false false (or $x1174))))
(and (not $x944) (or $x944 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x103 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x1071 (or false false false)))
(let (($x192 (not $x1071)))
(and $x192 (or $x1071 (and (distinct ?x103 ?x103) true)))))))
(check-sat)
; query 9: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x233 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x1071 (or false false false)))
(let (($x192 (not $x1071)))
(and $x192 (or $x1071 (and (distinct ?x233 ?x233) true)))))))
(check-sat)
; query 10: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x241 (or false false)))
(and (not $x241) (or $x241 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true)))))
(check-sat)
; query 11: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x225 ((_ sign_extend 16) in.1_16)))
(let ((?x125 (bvadd ?x225 (_ bv10 32))))
(let (($x919 (and (distinct (bvadd ((_ sign_extend 1) ?x225) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x125)) true)))
(let (($x241 (or false false)))
(let (($x90 (or $x241 false (or $x919))))
(and (not $x90) (or $x90 (and (distinct ?x125 ?x125) true)))))))))
(check-sat)
; query 12: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x225 ((_ sign_extend 16) in.1_16)))
(let ((?x125 (bvadd ?x225 (_ bv10 32))))
(let ((?x625 ((_ extract 15 0) ?x125)))
(let (($x919 (and (distinct (bvadd ((_ sign_extend 1) ?x225) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x125)) true)))
(let (($x241 (or false false)))
(let (($x90 (or $x241 false (or $x919))))
(let (($x96 (or $x90 false)))
(and (not $x96) (or $x96 (and (distinct ?x625 ?x625) true)))))))))))
(check-sat)
