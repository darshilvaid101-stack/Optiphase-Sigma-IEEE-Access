; OptiPhase-Sigma refinement certificate for sweep K57-R2-070
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x1564 (or false false)))
(let (($x479 (not $x1564)))
(and $x479 (or $x1564 (and (distinct ((_ sign_extend 16) in25_16) ((_ sign_extend 16) in25_16)) true))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let ((?x1516 (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1564 (or false false)))
(let (($x1060 (or $x1564 false false)))
(let (($x61 (not $x1060)))
(and $x61 (or $x1060 (and (distinct ?x1516 ?x1516) true))))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x1564 (or false false)))
(let (($x479 (not $x1564)))
(and $x479 (or $x1564 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x328 ((_ sign_extend 16) in3_16)))
(let ((?x338 (bvand ?x328 (_ bv127 32))))
(let (($x1564 (or false false)))
(let (($x1060 (or $x1564 false false)))
(let (($x61 (not $x1060)))
(and $x61 (or $x1060 (and (distinct ?x338 ?x338) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x328 ((_ sign_extend 16) in3_16)))
(let ((?x338 (bvand ?x328 (_ bv127 32))))
(let ((?x99 ((_ extract 15 0) ?x338)))
(let (($x1564 (or false false)))
(let (($x1060 (or $x1564 false false)))
(let (($x443 (or $x1060 false)))
(let (($x920 (not $x443)))
(and $x920 (or $x443 (and (distinct ?x99 ?x99) true)))))))))))
(check-sat)
; query 5: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x1564 (or false false)))
(let (($x479 (not $x1564)))
(and $x479 (or $x1564 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 6: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x317 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x1564 (or false false)))
(let (($x1060 (or $x1564 false false)))
(let (($x61 (not $x1060)))
(and $x61 (or $x1060 (and (distinct ?x317 ?x317) true))))))))
(check-sat)
; query 7: function core_bench_list, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x17 (or false false false)))
(let (($x575 (not $x17)))
(and $x575 (or $x17 (and (distinct (bvadd in.0_16 (_ bv1 16)) (bvadd in.0_16 (_ bv1 16))) true))))))
(check-sat)
; query 8: function core_bench_state, block 105, name %106
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x17 (or false false false)))
(let (($x575 (not $x17)))
(and $x575 (or $x17 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 9: function core_bench_state, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x17 (or false false false)))
(let (($x575 (not $x17)))
(and $x575 (or $x17 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 10: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x110 (bvadd in.01_32 (_ bv1 32))))
(let (($x38 (and (distinct ?x110 ?x110) true)))
(let (($x17 (or false false false)))
(let (($x575 (not $x17)))
(and $x575 (or $x17 $x38)))))))
(check-sat)
; query 11: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x110 (bvadd in.01_32 (_ bv1 32))))
(let ((?x249 (bvmul ?x110 ?x110)))
(let (($x17 (or false false false)))
(let (($x1394 (or $x17 $x17 false)))
(and (not $x1394) (or $x1394 (and (distinct ?x249 ?x249) true))))))))
(check-sat)
; query 12: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x110 (bvadd in.01_32 (_ bv1 32))))
(let ((?x249 (bvmul ?x110 ?x110)))
(let ((?x69 (bvmul ?x249 (_ bv2 32))))
(let (($x17 (or false false false)))
(let (($x1394 (or $x17 $x17 false)))
(let (($x790 (or $x1394 false false)))
(and (not $x790) (or $x790 (and (distinct ?x69 ?x69) true))))))))))
(check-sat)
; query 13: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x110 (bvadd in.01_32 (_ bv1 32))))
(let ((?x249 (bvmul ?x110 ?x110)))
(let ((?x69 (bvmul ?x249 (_ bv2 32))))
(let ((?x6 (bvmul ?x69 (_ bv4 32))))
(let (($x17 (or false false false)))
(let (($x1394 (or $x17 $x17 false)))
(let (($x790 (or $x1394 false false)))
(let (($x517 (or $x790 false false)))
(and (not $x517) (or $x517 (and (distinct ?x6 ?x6) true))))))))))))
(check-sat)
; query 14: function core_init_matrix, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x17 (or false false false)))
(let (($x575 (not $x17)))
(and $x575 (or $x17 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 15: function core_init_matrix, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x17 (or false false false)))
(let (($x575 (not $x17)))
(and $x575 (or $x17 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 16: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x1497 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x17 (or false false false)))
(let (($x575 (not $x17)))
(and $x575 (or $x17 (and (distinct ?x1497 ?x1497) true)))))))
(check-sat)
; query 17: function core_init_state, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_32 () (_ BitVec 32))
(assert
 (let (($x17 (or false false false)))
(let (($x575 (not $x17)))
(and $x575 (or $x17 (and (distinct (bvadd in.06_32 (_ bv1 32)) (bvadd in.06_32 (_ bv1 32))) true))))))
(check-sat)
; query 18: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x764 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x17 (or false false false)))
(let (($x575 (not $x17)))
(and $x575 (or $x17 (and (distinct ?x764 ?x764) true)))))))
(check-sat)
; query 19: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x17 (or false false false)))
(let (($x575 (not $x17)))
(and $x575 (or $x17 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 20: function core_list_init, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x110 (bvadd in.01_32 (_ bv1 32))))
(let (($x38 (and (distinct ?x110 ?x110) true)))
(let (($x17 (or false false false)))
(let (($x575 (not $x17)))
(and $x575 (or $x17 $x38)))))))
(check-sat)
; query 21: function core_list_mergesort, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x110 (bvadd in.01_32 (_ bv1 32))))
(let (($x38 (and (distinct ?x110 ?x110) true)))
(let (($x137 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x110)) true)))
(let (($x1078 (or false false (or $x137))))
(and (not $x1078) (or $x1078 $x38)))))))
(check-sat)
; query 22: function core_list_mergesort, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x602 (ite (bvslt (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x17 (or false false false)))
(let (($x575 (not $x17)))
(and $x575 (or $x17 (and (distinct ?x602 ?x602) true)))))))
(check-sat)
; query 23: function core_list_mergesort, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.224_32 () (_ BitVec 32))
(assert
 (let ((?x121 (ite (= (_ bv0 32) in.224_32) (_ bv1 1) (_ bv0 1))))
(let (($x17 (or false false false)))
(let (($x575 (not $x17)))
(and $x575 (or $x17 (and (distinct ?x121 ?x121) true)))))))
(check-sat)
; query 24: function core_list_mergesort, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x48 (ite (= (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x17 (or false false false)))
(let (($x575 (not $x17)))
(and $x575 (or $x17 (and (distinct ?x48 ?x48) true)))))))
(check-sat)
; query 25: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x655 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x152 (or false false (or $x655))))
(and (not $x152) (or $x152 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 26: function core_list_mergesort, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x435 (and (distinct (bvmul ((_ sign_extend 32) in.020_32) ((_ sign_extend 32) (_ bv2 32))) ((_ sign_extend 32) (bvmul in.020_32 (_ bv2 32)))) true)))
(let (($x163 (or false false (or $x435))))
(and (not $x163) (or $x163 (and (distinct (bvmul in.020_32 (_ bv2 32)) (bvmul in.020_32 (_ bv2 32))) true))))))
(check-sat)
; query 27: function core_state_transition, block 102, name %103
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1564 (or false false)))
(let (($x479 (not $x1564)))
(and $x479 (or $x1564 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 28: function core_state_transition, block 102, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1398 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1564 (or false false)))
(let (($x1060 (or $x1564 false false)))
(let (($x61 (not $x1060)))
(and $x61 (or $x1060 (and (distinct ?x1398 ?x1398) true))))))))
(check-sat)
; query 29: function core_state_transition, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1564 (or false false)))
(let (($x479 (not $x1564)))
(and $x479 (or $x1564 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 30: function core_state_transition, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x187 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1564 (or false false)))
(let (($x1060 (or $x1564 false false)))
(let (($x61 (not $x1060)))
(and $x61 (or $x1060 (and (distinct ?x187 ?x187) true))))))))
(check-sat)
; query 31: function core_state_transition, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1564 (or false false)))
(let (($x479 (not $x1564)))
(and $x479 (or $x1564 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 32: function core_state_transition, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1398 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1564 (or false false)))
(let (($x1060 (or $x1564 false false)))
(let (($x61 (not $x1060)))
(and $x61 (or $x1060 (and (distinct ?x1398 ?x1398) true))))))))
(check-sat)
; query 33: function core_state_transition, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1564 (or false false)))
(let (($x479 (not $x1564)))
(and $x479 (or $x1564 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 34: function core_state_transition, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x241 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1564 (or false false)))
(let (($x1060 (or $x1564 false false)))
(let (($x61 (not $x1060)))
(and $x61 (or $x1060 (and (distinct ?x241 ?x241) true))))))))
(check-sat)
; query 35: function core_state_transition, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1564 (or false false)))
(let (($x479 (not $x1564)))
(and $x479 (or $x1564 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 36: function core_state_transition, block 51, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x241 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1564 (or false false)))
(let (($x1060 (or $x1564 false false)))
(let (($x61 (not $x1060)))
(and $x61 (or $x1060 (and (distinct ?x241 ?x241) true))))))))
(check-sat)
; query 37: function core_state_transition, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1564 (or false false)))
(let (($x479 (not $x1564)))
(and $x479 (or $x1564 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 38: function core_state_transition, block 64, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x241 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1564 (or false false)))
(let (($x1060 (or $x1564 false false)))
(let (($x61 (not $x1060)))
(and $x61 (or $x1060 (and (distinct ?x241 ?x241) true))))))))
(check-sat)
; query 39: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x1355 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x17 (or false false false)))
(let (($x575 (not $x17)))
(and $x575 (or $x17 (and (distinct ?x1355 ?x1355) true)))))))
(check-sat)
; query 40: function core_state_transition, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1564 (or false false)))
(let (($x479 (not $x1564)))
(and $x479 (or $x1564 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 41: function core_state_transition, block 80, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1328 (ite (= (_ bv69 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1564 (or false false)))
(let (($x1060 (or $x1564 false false)))
(let (($x61 (not $x1060)))
(and $x61 (or $x1060 (and (distinct ?x1328 ?x1328) true))))))))
(check-sat)
; query 42: function core_state_transition, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1564 (or false false)))
(let (($x479 (not $x1564)))
(and $x479 (or $x1564 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 43: function core_state_transition, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1410 (ite (= (_ bv101 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1564 (or false false)))
(let (($x1060 (or $x1564 false false)))
(let (($x61 (not $x1060)))
(and $x61 (or $x1060 (and (distinct ?x1410 ?x1410) true))))))))
(check-sat)
; query 44: function core_state_transition, block 99, name %100
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1564 (or false false)))
(let (($x479 (not $x1564)))
(and $x479 (or $x1564 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 45: function core_state_transition, block 99, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x187 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1564 (or false false)))
(let (($x1060 (or $x1564 false false)))
(let (($x61 (not $x1060)))
(and $x61 (or $x1060 (and (distinct ?x187 ?x187) true))))))))
(check-sat)
; query 46: function crcu8, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x1564 (or false false)))
(let (($x479 (not $x1564)))
(and $x479 (or $x1564 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 47: function crcu8, block 19, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x1364 ((_ zero_extend 16) in.01_16)))
(let ((?x171 (bvxor ?x1364 (_ bv16386 32))))
(let (($x1564 (or false false)))
(let (($x1060 (or $x1564 false false)))
(let (($x61 (not $x1060)))
(and $x61 (or $x1060 (and (distinct ?x171 ?x171) true)))))))))
(check-sat)
; query 48: function crcu8, block 19, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x1364 ((_ zero_extend 16) in.01_16)))
(let ((?x171 (bvxor ?x1364 (_ bv16386 32))))
(let ((?x937 ((_ extract 15 0) ?x171)))
(let (($x1564 (or false false)))
(let (($x1060 (or $x1564 false false)))
(let (($x443 (or $x1060 false)))
(let (($x920 (not $x443)))
(and $x920 (or $x443 (and (distinct ?x937 ?x937) true)))))))))))
(check-sat)
; query 49: function crcu8, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x1564 (or false false)))
(let (($x479 (not $x1564)))
(and $x479 (or $x1564 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 50: function crcu8, block 29, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1555 ((_ zero_extend 16) in27_16)))
(let ((?x1309 (bvor ?x1555 (_ bv32768 32))))
(let (($x1564 (or false false)))
(let (($x1060 (or $x1564 false false)))
(let (($x61 (not $x1060)))
(and $x61 (or $x1060 (and (distinct ?x1309 ?x1309) true)))))))))
(check-sat)
; query 51: function crcu8, block 29, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1555 ((_ zero_extend 16) in27_16)))
(let ((?x1309 (bvor ?x1555 (_ bv32768 32))))
(let ((?x627 ((_ extract 15 0) ?x1309)))
(let (($x1564 (or false false)))
(let (($x1060 (or $x1564 false false)))
(let (($x443 (or $x1060 false)))
(let (($x920 (not $x443)))
(and $x920 (or $x443 (and (distinct ?x627 ?x627) true)))))))))))
(check-sat)
; query 52: function crcu8, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x1564 (or false false)))
(let (($x479 (not $x1564)))
(and $x479 (or $x1564 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 53: function crcu8, block 33, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1555 ((_ zero_extend 16) in27_16)))
(let ((?x815 (bvand ?x1555 (_ bv32767 32))))
(let (($x1564 (or false false)))
(let (($x1060 (or $x1564 false false)))
(let (($x61 (not $x1060)))
(and $x61 (or $x1060 (and (distinct ?x815 ?x815) true)))))))))
(check-sat)
; query 54: function crcu8, block 33, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1555 ((_ zero_extend 16) in27_16)))
(let ((?x815 (bvand ?x1555 (_ bv32767 32))))
(let ((?x1409 ((_ extract 15 0) ?x815)))
(let (($x1564 (or false false)))
(let (($x1060 (or $x1564 false false)))
(let (($x443 (or $x1060 false)))
(let (($x920 (not $x443)))
(and $x920 (or $x443 (and (distinct ?x1409 ?x1409) true)))))))))))
(check-sat)
; query 55: function crcu8, block 38, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_8 () (_ BitVec 8))
(assert
 (let (($x17 (or false false false)))
(let (($x575 (not $x17)))
(and $x575 (or $x17 (and (distinct (bvadd in.02_8 (_ bv1 8)) (bvadd in.02_8 (_ bv1 8))) true))))))
(check-sat)
; query 56: function crcu8, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x535 ((_ extract 7 0) in.01_16)))
(let ((?x1340 ((_ zero_extend 24) ?x535)))
(let (($x1564 (or false false)))
(let (($x244 (or $x1564 false)))
(and (not $x244) (or $x244 (and (distinct ?x1340 ?x1340) true))))))))
(check-sat)
; query 57: function crcu8, block 6, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x535 ((_ extract 7 0) in.01_16)))
(let ((?x1340 ((_ zero_extend 24) ?x535)))
(let ((?x1006 (bvand ?x1340 (_ bv1 32))))
(let (($x1564 (or false false)))
(let (($x244 (or $x1564 false)))
(let (($x1079 (or $x244 false false)))
(and (not $x1079) (or $x1079 (and (distinct ?x1006 ?x1006) true))))))))))
(check-sat)
; query 58: function crcu8, block 6, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x535 ((_ extract 7 0) in.01_16)))
(let ((?x1340 ((_ zero_extend 24) ?x535)))
(let ((?x1006 (bvand ?x1340 (_ bv1 32))))
(let ((?x743 ((_ zero_extend 24) in.0_8)))
(let ((?x831 (bvand ?x743 (_ bv1 32))))
(let ((?x1396 (bvxor ?x831 ?x1006)))
(let (($x1564 (or false false)))
(let (($x244 (or $x1564 false)))
(let (($x1079 (or $x244 false false)))
(let (($x1060 (or $x1564 false false)))
(let (($x1543 (or $x1060 $x1079 false)))
(and (not $x1543) (or $x1543 (and (distinct ?x1396 ?x1396) true)))))))))))))))
(check-sat)
; query 59: function crcu8, block 6, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x535 ((_ extract 7 0) in.01_16)))
(let ((?x1340 ((_ zero_extend 24) ?x535)))
(let ((?x1006 (bvand ?x1340 (_ bv1 32))))
(let ((?x743 ((_ zero_extend 24) in.0_8)))
(let ((?x831 (bvand ?x743 (_ bv1 32))))
(let ((?x1396 (bvxor ?x831 ?x1006)))
(let ((?x803 ((_ extract 7 0) ?x1396)))
(let (($x1564 (or false false)))
(let (($x244 (or $x1564 false)))
(let (($x1079 (or $x244 false false)))
(let (($x1060 (or $x1564 false false)))
(let (($x1543 (or $x1060 $x1079 false)))
(let (($x138 (or $x1543 false)))
(and (not $x138) (or $x138 (and (distinct ?x803 ?x803) true)))))))))))))))))
(check-sat)
; query 60: function crcu8, block 6, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x1564 (or false false)))
(let (($x479 (not $x1564)))
(and $x479 (or $x1564 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 61: function crcu8, block 6, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x743 ((_ zero_extend 24) in.0_8)))
(let ((?x253 (bvashr ?x743 (_ bv1 32))))
(let (($x1564 (or false false)))
(let (($x1060 (or $x1564 false false)))
(let (($x1032 (or $x1060 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not $x1032) (or $x1032 (and (distinct ?x253 ?x253) true)))))))))
(check-sat)
; query 62: function crcu8, block 6, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x743 ((_ zero_extend 24) in.0_8)))
(let ((?x253 (bvashr ?x743 (_ bv1 32))))
(let ((?x330 ((_ extract 7 0) ?x253)))
(let (($x1564 (or false false)))
(let (($x1060 (or $x1564 false false)))
(let (($x1032 (or $x1060 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x193 (or $x1032 false)))
(and (not $x193) (or $x193 (and (distinct ?x330 ?x330) true)))))))))))
(check-sat)
; query 63: function crcu8, block 6, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x535 ((_ extract 7 0) in.01_16)))
(let ((?x1340 ((_ zero_extend 24) ?x535)))
(let ((?x1006 (bvand ?x1340 (_ bv1 32))))
(let ((?x743 ((_ zero_extend 24) in.0_8)))
(let ((?x831 (bvand ?x743 (_ bv1 32))))
(let ((?x1396 (bvxor ?x831 ?x1006)))
(let ((?x803 ((_ extract 7 0) ?x1396)))
(let ((?x1361 ((_ zero_extend 24) ?x803)))
(let (($x1564 (or false false)))
(let (($x244 (or $x1564 false)))
(let (($x1079 (or $x244 false false)))
(let (($x1060 (or $x1564 false false)))
(let (($x1543 (or $x1060 $x1079 false)))
(let (($x138 (or $x1543 false)))
(let (($x1058 (or $x138 false)))
(and (not $x1058) (or $x1058 (and (distinct ?x1361 ?x1361) true)))))))))))))))))))
(check-sat)
; query 64: function crcu8, block 6, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x535 ((_ extract 7 0) in.01_16)))
(let ((?x1340 ((_ zero_extend 24) ?x535)))
(let ((?x1006 (bvand ?x1340 (_ bv1 32))))
(let ((?x743 ((_ zero_extend 24) in.0_8)))
(let ((?x831 (bvand ?x743 (_ bv1 32))))
(let ((?x1396 (bvxor ?x831 ?x1006)))
(let ((?x803 ((_ extract 7 0) ?x1396)))
(let ((?x1361 ((_ zero_extend 24) ?x803)))
(let ((?x202 (ite (= (_ bv1 32) ?x1361) (_ bv1 1) (_ bv0 1))))
(let (($x1564 (or false false)))
(let (($x244 (or $x1564 false)))
(let (($x1079 (or $x244 false false)))
(let (($x1060 (or $x1564 false false)))
(let (($x1543 (or $x1060 $x1079 false)))
(let (($x138 (or $x1543 false)))
(let (($x1058 (or $x138 false)))
(let (($x780 (or $x1058 false false)))
(and (not $x780) (or $x780 (and (distinct ?x202 ?x202) true)))))))))))))))))))))
(check-sat)
; query 65: function crcu8, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x1564 (or false false)))
(let (($x479 (not $x1564)))
(and $x479 (or $x1564 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 66: function crcu8, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x743 ((_ zero_extend 24) in.0_8)))
(let ((?x831 (bvand ?x743 (_ bv1 32))))
(let (($x1564 (or false false)))
(let (($x1060 (or $x1564 false false)))
(let (($x61 (not $x1060)))
(and $x61 (or $x1060 (and (distinct ?x831 ?x831) true)))))))))
(check-sat)
; query 67: function crcu8, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x1564 (or false false)))
(let (($x479 (not $x1564)))
(and $x479 (or $x1564 (and (distinct ((_ extract 7 0) in.01_16) ((_ extract 7 0) in.01_16)) true))))))
(check-sat)
; query 68: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x555 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x508 ((_ zero_extend 31) ?x555)))
(let ((?x598 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x513 ((_ zero_extend 31) ?x598)))
(let ((?x46 (bvand ?x513 ?x508)))
(let ((?x603 (ite (and (distinct (_ bv0 32) ?x46) true) (_ bv1 1) (_ bv0 1))))
(let ((?x953 ((_ zero_extend 63) ?x603)))
(let (($x1564 (or false false)))
(let (($x1060 (or $x1564 false false)))
(let (($x443 (or $x1060 false)))
(let (($x921 (or $x443 $x443 false)))
(let (($x809 (or $x921 false false)))
(let (($x1502 (or $x809 false)))
(and (not $x1502) (or $x1502 (and (distinct ?x953 ?x953) true)))))))))))))))))
(check-sat)
; query 69: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x555 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x508 ((_ zero_extend 31) ?x555)))
(let ((?x598 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x513 ((_ zero_extend 31) ?x598)))
(let ((?x46 (bvand ?x513 ?x508)))
(let ((?x603 (ite (and (distinct (_ bv0 32) ?x46) true) (_ bv1 1) (_ bv0 1))))
(let (($x600 (= (_ bv1 1) ?x603)))
(let ((?x1100 (ite $x600 (_ bv1 32) (_ bv0 32))))
(let (($x1564 (or false false)))
(let (($x1060 (or $x1564 false false)))
(let (($x443 (or $x1060 false)))
(let (($x921 (or $x443 $x443 false)))
(let (($x809 (or $x921 false false)))
(let (($x673 (or $x809 (ite $x600 false false))))
(and (not $x673) (or $x673 (and (distinct ?x1100 ?x1100) true))))))))))))))))))
(check-sat)
; query 70: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x555 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x508 ((_ zero_extend 31) ?x555)))
(let ((?x598 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x513 ((_ zero_extend 31) ?x598)))
(let ((?x46 (bvand ?x513 ?x508)))
(let ((?x603 (ite (and (distinct (_ bv0 32) ?x46) true) (_ bv1 1) (_ bv0 1))))
(let (($x600 (= (_ bv1 1) ?x603)))
(let ((?x1100 (ite $x600 (_ bv1 32) (_ bv0 32))))
(let ((?x832 ((_ extract 7 0) ?x1100)))
(let (($x1564 (or false false)))
(let (($x1060 (or $x1564 false false)))
(let (($x443 (or $x1060 false)))
(let (($x921 (or $x443 $x443 false)))
(let (($x809 (or $x921 false false)))
(let (($x673 (or $x809 (ite $x600 false false))))
(let (($x501 (or $x673 false)))
(and (not $x501) (or $x501 (and (distinct ?x832 ?x832) true))))))))))))))))))))
(check-sat)
; query 71: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x1564 (or false false)))
(let (($x479 (not $x1564)))
(and $x479 (or $x1564 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 72: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x598 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1564 (or false false)))
(let (($x1060 (or $x1564 false false)))
(let (($x61 (not $x1060)))
(and $x61 (or $x1060 (and (distinct ?x598 ?x598) true))))))))
(check-sat)
; query 73: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x598 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x513 ((_ zero_extend 31) ?x598)))
(let (($x1564 (or false false)))
(let (($x1060 (or $x1564 false false)))
(let (($x443 (or $x1060 false)))
(let (($x920 (not $x443)))
(and $x920 (or $x443 (and (distinct ?x513 ?x513) true))))))))))
(check-sat)
; query 74: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x1564 (or false false)))
(let (($x479 (not $x1564)))
(and $x479 (or $x1564 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 75: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x555 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1564 (or false false)))
(let (($x1060 (or $x1564 false false)))
(let (($x61 (not $x1060)))
(and $x61 (or $x1060 (and (distinct ?x555 ?x555) true))))))))
(check-sat)
; query 76: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x555 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x508 ((_ zero_extend 31) ?x555)))
(let (($x1564 (or false false)))
(let (($x1060 (or $x1564 false false)))
(let (($x443 (or $x1060 false)))
(let (($x920 (not $x443)))
(and $x920 (or $x443 (and (distinct ?x508 ?x508) true))))))))))
(check-sat)
; query 77: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x555 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x508 ((_ zero_extend 31) ?x555)))
(let ((?x598 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x513 ((_ zero_extend 31) ?x598)))
(let ((?x46 (bvand ?x513 ?x508)))
(let (($x1564 (or false false)))
(let (($x1060 (or $x1564 false false)))
(let (($x443 (or $x1060 false)))
(let (($x921 (or $x443 $x443 false)))
(and (not $x921) (or $x921 (and (distinct ?x46 ?x46) true)))))))))))))
(check-sat)
; query 78: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x555 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x508 ((_ zero_extend 31) ?x555)))
(let ((?x598 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x513 ((_ zero_extend 31) ?x598)))
(let ((?x46 (bvand ?x513 ?x508)))
(let ((?x603 (ite (and (distinct (_ bv0 32) ?x46) true) (_ bv1 1) (_ bv0 1))))
(let (($x1564 (or false false)))
(let (($x1060 (or $x1564 false false)))
(let (($x443 (or $x1060 false)))
(let (($x921 (or $x443 $x443 false)))
(let (($x809 (or $x921 false false)))
(and (not $x809) (or $x809 (and (distinct ?x603 ?x603) true)))))))))))))))
(check-sat)
; query 79: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1081 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x17 (or false false false)))
(let (($x575 (not $x17)))
(and $x575 (or $x17 (and (distinct ?x1081 ?x1081) true)))))))
(check-sat)
; query 80: function matrix_add_const, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x17 (or false false false)))
(let (($x575 (not $x17)))
(and $x575 (or $x17 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 81: function matrix_add_const, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x110 (bvadd in.01_32 (_ bv1 32))))
(let (($x38 (and (distinct ?x110 ?x110) true)))
(let (($x17 (or false false false)))
(let (($x575 (not $x17)))
(and $x575 (or $x17 $x38)))))))
(check-sat)
; query 82: function matrix_mul_const, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x17 (or false false false)))
(let (($x575 (not $x17)))
(and $x575 (or $x17 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 83: function matrix_mul_const, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x110 (bvadd in.01_32 (_ bv1 32))))
(let (($x38 (and (distinct ?x110 ?x110) true)))
(let (($x17 (or false false false)))
(let (($x575 (not $x17)))
(and $x575 (or $x17 $x38)))))))
(check-sat)
; query 84: function matrix_mul_matrix, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x17 (or false false false)))
(let (($x575 (not $x17)))
(and $x575 (or $x17 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 85: function matrix_mul_matrix, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x110 (bvadd in.01_32 (_ bv1 32))))
(let (($x38 (and (distinct ?x110 ?x110) true)))
(let (($x17 (or false false false)))
(let (($x575 (not $x17)))
(and $x575 (or $x17 $x38)))))))
(check-sat)
; query 86: function matrix_mul_matrix, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x17 (or false false false)))
(let (($x575 (not $x17)))
(and $x575 (or $x17 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 87: function matrix_mul_matrix_bitextract, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x17 (or false false false)))
(let (($x575 (not $x17)))
(and $x575 (or $x17 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 88: function matrix_mul_matrix_bitextract, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x110 (bvadd in.01_32 (_ bv1 32))))
(let (($x38 (and (distinct ?x110 ?x110) true)))
(let (($x17 (or false false false)))
(let (($x575 (not $x17)))
(and $x575 (or $x17 $x38)))))))
(check-sat)
; query 89: function matrix_mul_matrix_bitextract, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x17 (or false false false)))
(let (($x575 (not $x17)))
(and $x575 (or $x17 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 90: function matrix_mul_vect, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x17 (or false false false)))
(let (($x575 (not $x17)))
(and $x575 (or $x17 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 91: function matrix_mul_vect, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x110 (bvadd in.01_32 (_ bv1 32))))
(let (($x38 (and (distinct ?x110 ?x110) true)))
(let (($x17 (or false false false)))
(let (($x575 (not $x17)))
(and $x575 (or $x17 $x38)))))))
(check-sat)
; query 92: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x1564 (or false false)))
(let (($x479 (not $x1564)))
(and $x479 (or $x1564 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 93: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x462 ((_ sign_extend 16) in.1_16)))
(let ((?x567 (bvadd ?x462 (_ bv10 32))))
(let (($x197 (and (distinct (bvadd ((_ sign_extend 1) ?x462) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x567)) true)))
(let (($x1564 (or false false)))
(let (($x1103 (or $x1564 false (or $x197))))
(and (not $x1103) (or $x1103 (and (distinct ?x567 ?x567) true)))))))))
(check-sat)
; query 94: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x462 ((_ sign_extend 16) in.1_16)))
(let ((?x567 (bvadd ?x462 (_ bv10 32))))
(let ((?x897 ((_ extract 15 0) ?x567)))
(let (($x197 (and (distinct (bvadd ((_ sign_extend 1) ?x462) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x567)) true)))
(let (($x1564 (or false false)))
(let (($x1103 (or $x1564 false (or $x197))))
(let (($x1406 (or $x1103 false)))
(and (not $x1406) (or $x1406 (and (distinct ?x897 ?x897) true)))))))))))
(check-sat)
; query 95: function matrix_sum, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x470 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x17 (or false false false)))
(let (($x575 (not $x17)))
(and $x575 (or $x17 (and (distinct ?x470 ?x470) true)))))))
(check-sat)
; query 96: function matrix_sum, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x470 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let ((?x838 ((_ zero_extend 63) ?x470)))
(let (($x17 (or false false false)))
(let (($x145 (or $x17 false)))
(and (not $x145) (or $x145 (and (distinct ?x838 ?x838) true))))))))
(check-sat)
; query 97: function matrix_sum, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x470 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x539 (= (_ bv1 1) ?x470)))
(let ((?x1049 (ite $x539 (_ bv1 32) (_ bv0 32))))
(let (($x17 (or false false false)))
(let (($x690 (or $x17 (ite $x539 false false))))
(and (not $x690) (or $x690 (and (distinct ?x1049 ?x1049) true)))))))))
(check-sat)
; query 98: function matrix_sum, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x1564 (or false false)))
(let (($x479 (not $x1564)))
(and $x479 (or $x1564 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 99: function matrix_sum, block 22, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x470 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x539 (= (_ bv1 1) ?x470)))
(let ((?x1049 (ite $x539 (_ bv1 32) (_ bv0 32))))
(let ((?x462 ((_ sign_extend 16) in.1_16)))
(let ((?x203 (bvadd ?x462 ?x1049)))
(let (($x1401 (and (distinct (bvadd ((_ sign_extend 1) ?x462) ((_ sign_extend 1) ?x1049)) ((_ sign_extend 1) ?x203)) true)))
(let (($x17 (or false false false)))
(let (($x690 (or $x17 (ite $x539 false false))))
(let (($x1564 (or false false)))
(let (($x1018 (or $x1564 $x690 (or $x1401))))
(and (not $x1018) (or $x1018 (and (distinct ?x203 ?x203) true))))))))))))))
(check-sat)
; query 100: function matrix_sum, block 22, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x470 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x539 (= (_ bv1 1) ?x470)))
(let ((?x1049 (ite $x539 (_ bv1 32) (_ bv0 32))))
(let ((?x462 ((_ sign_extend 16) in.1_16)))
(let ((?x203 (bvadd ?x462 ?x1049)))
(let ((?x825 ((_ extract 15 0) ?x203)))
(let (($x1401 (and (distinct (bvadd ((_ sign_extend 1) ?x462) ((_ sign_extend 1) ?x1049)) ((_ sign_extend 1) ?x203)) true)))
(let (($x17 (or false false false)))
(let (($x690 (or $x17 (ite $x539 false false))))
(let (($x1564 (or false false)))
(let (($x1018 (or $x1564 $x690 (or $x1401))))
(let (($x960 (or $x1018 false)))
(and (not $x960) (or $x960 (and (distinct ?x825 ?x825) true))))))))))))))))
(check-sat)
; query 101: function matrix_sum, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x17 (or false false false)))
(let (($x575 (not $x17)))
(and $x575 (or $x17 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 102: function matrix_sum, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x110 (bvadd in.01_32 (_ bv1 32))))
(let (($x38 (and (distinct ?x110 ?x110) true)))
(let (($x17 (or false false false)))
(let (($x575 (not $x17)))
(and $x575 (or $x17 $x38)))))))
(check-sat)
; query 103: function parseval, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.23_32 () (_ BitVec 32))
(assert
 (let (($x1116 (and (distinct (bvmul ((_ sign_extend 32) in.23_32) ((_ sign_extend 32) (_ bv1024 32))) ((_ sign_extend 32) (bvmul in.23_32 (_ bv1024 32)))) true)))
(let (($x438 (or false false (or $x1116))))
(and (not $x438) (or $x438 (and (distinct (bvmul in.23_32 (_ bv1024 32)) (bvmul in.23_32 (_ bv1024 32))) true))))))
(check-sat)
; query 104: function parseval, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.34_32 () (_ BitVec 32))
(assert
 (let (($x767 (and (distinct (bvmul ((_ sign_extend 32) in.34_32) ((_ sign_extend 32) (_ bv1048576 32))) ((_ sign_extend 32) (bvmul in.34_32 (_ bv1048576 32)))) true)))
(let (($x1005 (or false false (or $x767))))
(and (not $x1005) (or $x1005 (and (distinct (bvmul in.34_32 (_ bv1048576 32)) (bvmul in.34_32 (_ bv1048576 32))) true))))))
(check-sat)
; query 105: function partition_memory, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x17 (or false false false)))
(let (($x575 (not $x17)))
(and $x575 (or $x17 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
