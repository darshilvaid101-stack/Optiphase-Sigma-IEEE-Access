; OptiPhase-Sigma refinement certificate for sweep K36-R2-029
; query 0: function dijkstra, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x53 (ite (= in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x82 (or false false false)))
(and (not $x82) (or $x82 (and (distinct ?x53 ?x53) true))))))
(check-sat)
; query 1: function main, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x78 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x61 (or false false (or $x78))))
(and (not $x61) (or $x61 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function main, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x321 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x66 (or false false (or $x321))))
(and (not $x66) (or $x66 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 3: function main, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x117 (and (distinct (bvadd ((_ sign_extend 1) in.12_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.12_32 (_ bv1 32)))) true)))
(let (($x15 (or false false (or $x117))))
(and (not $x15) (or $x15 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 4: function main, block 37, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in35_32 () (_ BitVec 32))
(assert
 (let (($x738 (and (distinct (bvadd ((_ sign_extend 1) in35_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in35_32 (_ bv1 32)))) true)))
(let (($x38 (or false false (or $x738))))
(and (not $x38) (or $x38 (and (distinct (bvadd in35_32 (_ bv1 32)) (bvadd in35_32 (_ bv1 32))) true))))))
(check-sat)
