; OptiPhase-Sigma refinement certificate for sweep K59-R3-297
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x1901 (or false false)))
(let (($x12 (not $x1901)))
(and $x12 (or $x1901 (and (distinct ((_ sign_extend 16) in25_16) ((_ sign_extend 16) in25_16)) true))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let ((?x221 (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1901 (or false false)))
(let (($x752 (or $x1901 false false)))
(let (($x460 (not $x752)))
(and $x460 (or $x752 (and (distinct ?x221 ?x221) true))))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x1901 (or false false)))
(let (($x12 (not $x1901)))
(and $x12 (or $x1901 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x1721 ((_ sign_extend 16) in3_16)))
(let ((?x1868 (bvand ?x1721 (_ bv127 32))))
(let (($x1901 (or false false)))
(let (($x752 (or $x1901 false false)))
(let (($x460 (not $x752)))
(and $x460 (or $x752 (and (distinct ?x1868 ?x1868) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x1721 ((_ sign_extend 16) in3_16)))
(let ((?x1868 (bvand ?x1721 (_ bv127 32))))
(let ((?x68 ((_ extract 15 0) ?x1868)))
(let (($x1901 (or false false)))
(let (($x752 (or $x1901 false false)))
(let (($x86 (or $x752 false)))
(let (($x107 (not $x86)))
(and $x107 (or $x86 (and (distinct ?x68 ?x68) true)))))))))))
(check-sat)
; query 5: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x1901 (or false false)))
(let (($x12 (not $x1901)))
(and $x12 (or $x1901 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 6: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x163 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x1901 (or false false)))
(let (($x752 (or $x1901 false false)))
(let (($x460 (not $x752)))
(and $x460 (or $x752 (and (distinct ?x163 ?x163) true))))))))
(check-sat)
; query 7: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x776 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x101 (or false false false)))
(let (($x94 (not $x101)))
(and $x94 (or $x101 (and (distinct ?x776 ?x776) true)))))))
(check-sat)
; query 8: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x101 (or false false false)))
(let (($x94 (not $x101)))
(and $x94 (or $x101 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 9: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x132 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x616 ((_ zero_extend 31) ?x132)))
(let ((?x136 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1213 ((_ zero_extend 31) ?x136)))
(let ((?x1695 (bvand ?x1213 ?x616)))
(let ((?x72 (ite (and (distinct (_ bv0 32) ?x1695) true) (_ bv1 1) (_ bv0 1))))
(let ((?x1711 ((_ zero_extend 63) ?x72)))
(let (($x1901 (or false false)))
(let (($x752 (or $x1901 false false)))
(let (($x86 (or $x752 false)))
(let (($x339 (or $x86 $x86 false)))
(let (($x1429 (or $x339 false false)))
(let (($x123 (or $x1429 false)))
(and (not $x123) (or $x123 (and (distinct ?x1711 ?x1711) true)))))))))))))))))
(check-sat)
; query 10: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x132 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x616 ((_ zero_extend 31) ?x132)))
(let ((?x136 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1213 ((_ zero_extend 31) ?x136)))
(let ((?x1695 (bvand ?x1213 ?x616)))
(let ((?x72 (ite (and (distinct (_ bv0 32) ?x1695) true) (_ bv1 1) (_ bv0 1))))
(let (($x1354 (= (_ bv1 1) ?x72)))
(let ((?x92 (ite $x1354 (_ bv1 32) (_ bv0 32))))
(let (($x1901 (or false false)))
(let (($x752 (or $x1901 false false)))
(let (($x86 (or $x752 false)))
(let (($x339 (or $x86 $x86 false)))
(let (($x1429 (or $x339 false false)))
(let (($x974 (or $x1429 (ite $x1354 false false))))
(and (not $x974) (or $x974 (and (distinct ?x92 ?x92) true))))))))))))))))))
(check-sat)
; query 11: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x132 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x616 ((_ zero_extend 31) ?x132)))
(let ((?x136 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1213 ((_ zero_extend 31) ?x136)))
(let ((?x1695 (bvand ?x1213 ?x616)))
(let ((?x72 (ite (and (distinct (_ bv0 32) ?x1695) true) (_ bv1 1) (_ bv0 1))))
(let (($x1354 (= (_ bv1 1) ?x72)))
(let ((?x92 (ite $x1354 (_ bv1 32) (_ bv0 32))))
(let ((?x99 ((_ extract 7 0) ?x92)))
(let (($x1901 (or false false)))
(let (($x752 (or $x1901 false false)))
(let (($x86 (or $x752 false)))
(let (($x339 (or $x86 $x86 false)))
(let (($x1429 (or $x339 false false)))
(let (($x974 (or $x1429 (ite $x1354 false false))))
(let (($x647 (or $x974 false)))
(and (not $x647) (or $x647 (and (distinct ?x99 ?x99) true))))))))))))))))))))
(check-sat)
; query 12: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x1901 (or false false)))
(let (($x12 (not $x1901)))
(and $x12 (or $x1901 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 13: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x136 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1901 (or false false)))
(let (($x752 (or $x1901 false false)))
(let (($x460 (not $x752)))
(and $x460 (or $x752 (and (distinct ?x136 ?x136) true))))))))
(check-sat)
; query 14: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x136 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1213 ((_ zero_extend 31) ?x136)))
(let (($x1901 (or false false)))
(let (($x752 (or $x1901 false false)))
(let (($x86 (or $x752 false)))
(let (($x107 (not $x86)))
(and $x107 (or $x86 (and (distinct ?x1213 ?x1213) true))))))))))
(check-sat)
; query 15: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x1901 (or false false)))
(let (($x12 (not $x1901)))
(and $x12 (or $x1901 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 16: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x132 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1901 (or false false)))
(let (($x752 (or $x1901 false false)))
(let (($x460 (not $x752)))
(and $x460 (or $x752 (and (distinct ?x132 ?x132) true))))))))
(check-sat)
; query 17: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x132 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x616 ((_ zero_extend 31) ?x132)))
(let (($x1901 (or false false)))
(let (($x752 (or $x1901 false false)))
(let (($x86 (or $x752 false)))
(let (($x107 (not $x86)))
(and $x107 (or $x86 (and (distinct ?x616 ?x616) true))))))))))
(check-sat)
; query 18: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x132 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x616 ((_ zero_extend 31) ?x132)))
(let ((?x136 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1213 ((_ zero_extend 31) ?x136)))
(let ((?x1695 (bvand ?x1213 ?x616)))
(let (($x1901 (or false false)))
(let (($x752 (or $x1901 false false)))
(let (($x86 (or $x752 false)))
(let (($x339 (or $x86 $x86 false)))
(and (not $x339) (or $x339 (and (distinct ?x1695 ?x1695) true)))))))))))))
(check-sat)
; query 19: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x132 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x616 ((_ zero_extend 31) ?x132)))
(let ((?x136 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1213 ((_ zero_extend 31) ?x136)))
(let ((?x1695 (bvand ?x1213 ?x616)))
(let ((?x72 (ite (and (distinct (_ bv0 32) ?x1695) true) (_ bv1 1) (_ bv0 1))))
(let (($x1901 (or false false)))
(let (($x752 (or $x1901 false false)))
(let (($x86 (or $x752 false)))
(let (($x339 (or $x86 $x86 false)))
(let (($x1429 (or $x339 false false)))
(and (not $x1429) (or $x1429 (and (distinct ?x72 ?x72) true)))))))))))))))
(check-sat)
; query 20: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1728 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x101 (or false false false)))
(let (($x94 (not $x101)))
(and $x94 (or $x101 (and (distinct ?x1728 ?x1728) true)))))))
(check-sat)
