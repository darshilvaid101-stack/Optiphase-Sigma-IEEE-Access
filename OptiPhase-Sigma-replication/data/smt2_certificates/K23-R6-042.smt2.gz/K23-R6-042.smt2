; OptiPhase-Sigma refinement certificate for sweep K23-R6-042
; query 0: function kernel_nussinov, block 11, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x176 (and (distinct (bvsub ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvsub in.01_32 (_ bv1 32)))) true)))
(let (($x152 (or false false (or $x176))))
(and (not $x152) (or $x152 (and (distinct (bvsub in.01_32 (_ bv1 32)) (bvsub in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function kernel_nussinov, block 11, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x569 (ite (bvsle (_ bv0 32) (bvsub in.01_32 (_ bv1 32))) (_ bv1 1) (_ bv0 1))))
(let (($x176 (and (distinct (bvsub ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvsub in.01_32 (_ bv1 32)))) true)))
(let (($x152 (or false false (or $x176))))
(let (($x566 (or $x152 false false)))
(and (not $x566) (or $x566 (and (distinct ?x569 ?x569) true))))))))
(check-sat)
; query 2: function kernel_nussinov, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x160 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x10 (or false false (or $x160))))
(and (not $x10) (or $x10 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 3: function kernel_nussinov, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x129 (and (distinct (bvsub ((_ sign_extend 1) in0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvsub in0_32 (_ bv1 32)))) true)))
(let (($x80 (or false false (or $x129))))
(and (not $x80) (or $x80 (and (distinct (bvsub in0_32 (_ bv1 32)) (bvsub in0_32 (_ bv1 32))) true))))))
(check-sat)
