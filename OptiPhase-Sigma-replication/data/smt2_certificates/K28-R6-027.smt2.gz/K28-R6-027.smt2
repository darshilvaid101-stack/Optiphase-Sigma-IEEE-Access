; OptiPhase-Sigma refinement certificate for sweep K28-R6-027
