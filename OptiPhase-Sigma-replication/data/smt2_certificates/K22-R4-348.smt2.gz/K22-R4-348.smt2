; OptiPhase-Sigma refinement certificate for sweep K22-R4-348
