; OptiPhase-Sigma refinement certificate for sweep K50-R3-294
; query 0: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x22 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x96 (or false false false)))
(let (($x65 (not $x96)))
(and $x65 (or $x96 (and (distinct ?x22 ?x22) true)))))))
(check-sat)
; query 1: function s115, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x46 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x757 (or false false (or $x46))))
(and (not $x757) (or $x757 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function set1d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x385 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x96 (or false false false)))
(let (($x65 (not $x96)))
(and $x65 (or $x96 (and (distinct ?x385 ?x385) true)))))))
(check-sat)
; query 3: function set1ds, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x259 (ite (= (_ bv4294967295 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x96 (or false false false)))
(let (($x65 (not $x96)))
(and $x65 (or $x96 (and (distinct ?x259 ?x259) true)))))))
(check-sat)
; query 4: function set2d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x385 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x96 (or false false false)))
(let (($x65 (not $x96)))
(and $x65 (or $x96 (and (distinct ?x385 ?x385) true)))))))
(check-sat)
