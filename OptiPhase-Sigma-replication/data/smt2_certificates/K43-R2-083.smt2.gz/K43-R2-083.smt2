; OptiPhase-Sigma refinement certificate for sweep K43-R2-083
; query 0: function crc32buf, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_64 () (_ BitVec 64))
(assert
 (let (($x76 (or false false false)))
(let (($x132 (not $x76)))
(and $x132 (or $x76 (and (distinct (bvxor in.02_64 (_ bv18446744073709551615 64)) (bvxor in.02_64 (_ bv18446744073709551615 64))) true))))))
(check-sat)
; query 1: function main, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x497 (ite (and (distinct (_ bv0 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x76 (or false false false)))
(let (($x132 (not $x76)))
(and $x132 (or $x76 (and (distinct ?x497 ?x497) true)))))))
(check-sat)
; query 2: function main, block 17, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x497 (ite (and (distinct (_ bv0 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let ((?x813 ((_ zero_extend 31) ?x497)))
(let (($x76 (or false false false)))
(let (($x103 (or $x76 false)))
(and (not $x103) (or $x103 (and (distinct ?x813 ?x813) true))))))))
(check-sat)
