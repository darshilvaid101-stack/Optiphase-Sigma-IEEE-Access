; OptiPhase-Sigma refinement certificate for sweep K51-R3-232
; query 0: function check, block 103, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x443 (ite (= (_ bv22 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x648 (or false false false)))
(let (($x180 (not $x648)))
(and $x180 (or $x648 (and (distinct ?x443 ?x443) true)))))))
(check-sat)
; query 1: function check, block 109, name %110
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x135 (ite (= (_ bv33 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x648 (or false false false)))
(let (($x180 (not $x648)))
(and $x180 (or $x648 (and (distinct ?x135 ?x135) true)))))))
(check-sat)
; query 2: function check, block 115, name %116
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x501 (ite (= (_ bv0 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x648 (or false false false)))
(let (($x180 (not $x648)))
(and $x180 (or $x648 (and (distinct ?x501 ?x501) true)))))))
(check-sat)
; query 3: function check, block 121, name %122
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x235 (ite (= (_ bv12 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x648 (or false false false)))
(let (($x180 (not $x648)))
(and $x180 (or $x648 (and (distinct ?x235 ?x235) true)))))))
(check-sat)
; query 4: function check, block 128, name %129
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x46 (ite (= (_ bv25 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x648 (or false false false)))
(let (($x180 (not $x648)))
(and $x180 (or $x648 (and (distinct ?x46 ?x46) true)))))))
(check-sat)
; query 5: function check, block 135, name %136
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x12 (ite (= (_ bv13 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x648 (or false false false)))
(let (($x180 (not $x648)))
(and $x180 (or $x648 (and (distinct ?x12 ?x12) true)))))))
(check-sat)
; query 6: function check, block 142, name %143
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x518 (ite (= (_ bv123 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x648 (or false false false)))
(let (($x180 (not $x648)))
(and $x180 (or $x648 (and (distinct ?x518 ?x518) true)))))))
(check-sat)
; query 7: function check, block 150, name %151
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x429 (ite (= (_ bv1122 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x648 (or false false false)))
(let (($x180 (not $x648)))
(and $x180 (or $x648 (and (distinct ?x429 ?x429) true)))))))
(check-sat)
; query 8: function check, block 157, name %158
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x645 (ite (= (_ bv112233 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x648 (or false false false)))
(let (($x180 (not $x648)))
(and $x180 (or $x648 (and (distinct ?x645 ?x645) true)))))))
(check-sat)
; query 9: function check, block 165, name %166
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x7 (ite (= (_ bv111 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x648 (or false false false)))
(let (($x180 (not $x648)))
(and $x180 (or $x648 (and (distinct ?x7 ?x7) true)))))))
(check-sat)
; query 10: function check, block 172, name %173
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x228 (ite (= (_ bv4294967295 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x648 (or false false false)))
(let (($x180 (not $x648)))
(and $x180 (or $x648 (and (distinct ?x228 ?x228) true)))))))
(check-sat)
; query 11: function check, block 179, name %180
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x225 (ite (= (_ bv4294967284 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x648 (or false false false)))
(let (($x180 (not $x648)))
(and $x180 (or $x648 (and (distinct ?x225 ?x225) true)))))))
(check-sat)
; query 12: function check, block 55, name %56
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.012_32 () (_ BitVec 32))
(assert
 (let (($x368 (and (distinct (bvadd ((_ zero_extend 1) in.012_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.012_32 (_ bv1 32)))) true)))
(let (($x779 (and (distinct (bvadd ((_ sign_extend 1) in.012_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.012_32 (_ bv1 32)))) true)))
(let (($x302 (or (or false false (or $x779 $x368)) (and (distinct (bvadd in.012_32 (_ bv1 32)) (bvadd in.012_32 (_ bv1 32))) true))))
(and (not (or false false (or $x779))) $x302)))))
(check-sat)
; query 13: function check, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x112 (ite (= (_ bv2 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x648 (or false false false)))
(let (($x180 (not $x648)))
(and $x180 (or $x648 (and (distinct ?x112 ?x112) true)))))))
(check-sat)
; query 14: function check, block 79, name %80
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x380 (ite (= (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x648 (or false false false)))
(let (($x180 (not $x648)))
(and $x180 (or $x648 (and (distinct ?x380 ?x380) true)))))))
(check-sat)
; query 15: function check, block 85, name %86
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x746 (ite (= (_ bv4 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x648 (or false false false)))
(let (($x180 (not $x648)))
(and $x180 (or $x648 (and (distinct ?x746 ?x746) true)))))))
(check-sat)
; query 16: function check, block 91, name %92
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x85 (ite (= (_ bv5 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x648 (or false false false)))
(let (($x180 (not $x648)))
(and $x180 (or $x648 (and (distinct ?x85 ?x85) true)))))))
(check-sat)
; query 17: function check, block 97, name %98
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x157 (ite (= (_ bv11 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x648 (or false false false)))
(let (($x180 (not $x648)))
(and $x180 (or $x648 (and (distinct ?x157 ?x157) true)))))))
(check-sat)
; query 18: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x410 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x648 (or false false false)))
(let (($x180 (not $x648)))
(and $x180 (or $x648 (and (distinct ?x410 ?x410) true)))))))
(check-sat)
; query 19: function s000, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x675 (and (distinct (bvadd ((_ zero_extend 1) in.0_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x260 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x80 (or (or false false (or $x260 $x675)) (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))
(and (not (or false false (or $x260))) $x80)))))
(check-sat)
; query 20: function s000, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x408 (and (distinct (bvadd ((_ zero_extend 1) in.01_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x407 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x249 (or (or false false (or $x407 $x408)) (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))
(and (not (or false false (or $x407))) $x249)))))
(check-sat)
; query 21: function s111, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x110 (and (distinct (bvadd ((_ zero_extend 1) in.0_32) ((_ zero_extend 1) (_ bv2 32))) ((_ zero_extend 1) (bvadd in.0_32 (_ bv2 32)))) true)))
(let (($x597 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv2 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv2 32)))) true)))
(let (($x73 (or (or false false (or $x597 $x110)) (and (distinct (bvadd in.0_32 (_ bv2 32)) (bvadd in.0_32 (_ bv2 32))) true))))
(and (not (or false false (or $x597))) $x73)))))
(check-sat)
; query 22: function s111, block 24, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x408 (and (distinct (bvadd ((_ zero_extend 1) in.01_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x407 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x249 (or (or false false (or $x407 $x408)) (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))
(and (not (or false false (or $x407))) $x249)))))
(check-sat)
; query 23: function s1111, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x675 (and (distinct (bvadd ((_ zero_extend 1) in.0_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x260 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x80 (or (or false false (or $x260 $x675)) (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))
(and (not (or false false (or $x260))) $x80)))))
(check-sat)
; query 24: function s1111, block 52, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x408 (and (distinct (bvadd ((_ zero_extend 1) in.01_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x407 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x249 (or (or false false (or $x407 $x408)) (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))
(and (not (or false false (or $x407))) $x249)))))
(check-sat)
; query 25: function s1112, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x960 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv4294967295 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv4294967295 32)))) true)))
(let (($x241 (or false false (or $x960))))
(and (not $x241) (or $x241 (and (distinct (bvadd in.0_32 (_ bv4294967295 32)) (bvadd in.0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 26: function s1112, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x408 (and (distinct (bvadd ((_ zero_extend 1) in.01_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x407 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x249 (or (or false false (or $x407 $x408)) (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))
(and (not (or false false (or $x407))) $x249)))))
(check-sat)
; query 27: function s1113, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x675 (and (distinct (bvadd ((_ zero_extend 1) in.0_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x260 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x80 (or (or false false (or $x260 $x675)) (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))
(and (not (or false false (or $x260))) $x80)))))
(check-sat)
; query 28: function s1113, block 21, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x408 (and (distinct (bvadd ((_ zero_extend 1) in.01_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x407 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x249 (or (or false false (or $x407 $x408)) (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))
(and (not (or false false (or $x407))) $x249)))))
(check-sat)
; query 29: function s1115, block 34, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x675 (and (distinct (bvadd ((_ zero_extend 1) in.0_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x260 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x80 (or (or false false (or $x260 $x675)) (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))
(and (not (or false false (or $x260))) $x80)))))
(check-sat)
; query 30: function s1115, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x408 (and (distinct (bvadd ((_ zero_extend 1) in.01_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x407 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x249 (or (or false false (or $x407 $x408)) (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))
(and (not (or false false (or $x407))) $x249)))))
(check-sat)
; query 31: function s1115, block 41, name %42
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x207 (and (distinct (bvadd ((_ zero_extend 1) in.02_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x124 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x740 (or (or false false (or $x124 $x207)) (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))
(and (not (or false false (or $x124))) $x740)))))
(check-sat)
; query 32: function s1119, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x675 (and (distinct (bvadd ((_ zero_extend 1) in.0_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x260 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x80 (or (or false false (or $x260 $x675)) (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))
(and (not (or false false (or $x260))) $x80)))))
(check-sat)
; query 33: function s1119, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x408 (and (distinct (bvadd ((_ zero_extend 1) in.01_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x407 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x249 (or (or false false (or $x407 $x408)) (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))
(and (not (or false false (or $x407))) $x249)))))
(check-sat)
; query 34: function s1119, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x207 (and (distinct (bvadd ((_ zero_extend 1) in.02_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x124 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x740 (or (or false false (or $x124 $x207)) (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))
(and (not (or false false (or $x124))) $x740)))))
(check-sat)
; query 35: function s112, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x960 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv4294967295 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv4294967295 32)))) true)))
(let (($x241 (or false false (or $x960))))
(and (not $x241) (or $x241 (and (distinct (bvadd in.0_32 (_ bv4294967295 32)) (bvadd in.0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 36: function s112, block 24, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x408 (and (distinct (bvadd ((_ zero_extend 1) in.01_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x407 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x249 (or (or false false (or $x407 $x408)) (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))
(and (not (or false false (or $x407))) $x249)))))
(check-sat)
; query 37: function s113, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x675 (and (distinct (bvadd ((_ zero_extend 1) in.0_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x260 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x80 (or (or false false (or $x260 $x675)) (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))
(and (not (or false false (or $x260))) $x80)))))
(check-sat)
; query 38: function s113, block 21, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x408 (and (distinct (bvadd ((_ zero_extend 1) in.01_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x407 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x249 (or (or false false (or $x407 $x408)) (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))
(and (not (or false false (or $x407))) $x249)))))
(check-sat)
; query 39: function s114, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x675 (and (distinct (bvadd ((_ zero_extend 1) in.0_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x260 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x80 (or (or false false (or $x260 $x675)) (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))
(and (not (or false false (or $x260))) $x80)))))
(check-sat)
; query 40: function s114, block 32, name %33
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x408 (and (distinct (bvadd ((_ zero_extend 1) in.01_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x407 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x249 (or (or false false (or $x407 $x408)) (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))
(and (not (or false false (or $x407))) $x249)))))
(check-sat)
; query 41: function s114, block 36, name %37
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x207 (and (distinct (bvadd ((_ zero_extend 1) in.02_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x124 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x740 (or (or false false (or $x124 $x207)) (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))
(and (not (or false false (or $x124))) $x740)))))
(check-sat)
; query 42: function s116, block 68, name %69
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x198 (and (distinct (bvadd ((_ zero_extend 1) in.0_32) ((_ zero_extend 1) (_ bv5 32))) ((_ zero_extend 1) (bvadd in.0_32 (_ bv5 32)))) true)))
(let (($x403 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv5 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv5 32)))) true)))
(let (($x567 (or (or false false (or $x403 $x198)) (and (distinct (bvadd in.0_32 (_ bv5 32)) (bvadd in.0_32 (_ bv5 32))) true))))
(and (not (or false false (or $x403))) $x567)))))
(check-sat)
; query 43: function s116, block 72, name %73
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x408 (and (distinct (bvadd ((_ zero_extend 1) in.01_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x407 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x249 (or (or false false (or $x407 $x408)) (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))
(and (not (or false false (or $x407))) $x249)))))
(check-sat)
; query 44: function set1d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x275 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x648 (or false false false)))
(let (($x180 (not $x648)))
(and $x180 (or $x648 (and (distinct ?x275 ?x275) true)))))))
(check-sat)
; query 45: function set1ds, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x107 (ite (= (_ bv4294967295 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x648 (or false false false)))
(let (($x180 (not $x648)))
(and $x180 (or $x648 (and (distinct ?x107 ?x107) true)))))))
(check-sat)
; query 46: function set2d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x275 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x648 (or false false false)))
(let (($x180 (not $x648)))
(and $x180 (or $x648 (and (distinct ?x275 ?x275) true)))))))
(check-sat)
