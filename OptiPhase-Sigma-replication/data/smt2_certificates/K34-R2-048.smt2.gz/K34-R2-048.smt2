; OptiPhase-Sigma refinement certificate for sweep K34-R2-048
; query 0: function corner_draw, block 11, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x17 (ite (= (_ bv0 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x450 (not $x52)))
(and $x450 (or $x52 (and (distinct ?x17 ?x17) true)))))))
(check-sat)
; query 1: function edge_draw, block 39, name %40
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x68 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x258 (or false false (or $x68))))
(and (not $x258) (or $x258 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function edge_draw, block 57, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x622 (and (distinct (bvadd ((_ sign_extend 1) in.12_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.12_32 (_ bv1 32)))) true)))
(let (($x69 (or false false (or $x622))))
(and (not $x69) (or $x69 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 3: function edge_draw, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let ((?x79 (ite (= (_ bv0 32) in4_32) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x450 (not $x52)))
(and $x450 (or $x52 (and (distinct ?x79 ?x79) true)))))))
(check-sat)
; query 4: function enlarge, block 106, name %107
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x96 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x41 (or false false (or $x96))))
(and (not $x41) (or $x41 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 5: function enlarge, block 158, name %159
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x92 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x98 (or false false (or $x92))))
(and (not $x98) (or $x98 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 6: function enlarge, block 161, name %162
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let (($x256 (and (distinct (bvadd ((_ sign_extend 1) in.2_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.2_32 (_ bv1 32)))) true)))
(let (($x562 (or false false (or $x256))))
(and (not $x562) (or $x562 (and (distinct (bvadd in.2_32 (_ bv1 32)) (bvadd in.2_32 (_ bv1 32))) true))))))
(check-sat)
; query 7: function enlarge, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x68 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x258 (or false false (or $x68))))
(and (not $x258) (or $x258 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function getint, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x23 (ite (bvsle (_ bv48 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x450 (not $x52)))
(and $x450 (or $x52 (and (distinct ?x23 ?x23) true)))))))
(check-sat)
; query 9: function getint, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x133 (ite (bvsge (_ bv57 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x450 (not $x52)))
(and $x450 (or $x52 (and (distinct ?x133 ?x133) true)))))))
(check-sat)
; query 10: function getint, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in26_32 () (_ BitVec 32))
(assert
 (let ((?x459 (ite (bvsgt (_ bv48 32) in26_32) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x450 (not $x52)))
(and $x450 (or $x52 (and (distinct ?x459 ?x459) true)))))))
(check-sat)
; query 11: function getint, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in26_32 () (_ BitVec 32))
(assert
 (let ((?x187 (ite (bvslt (_ bv57 32) in26_32) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x450 (not $x52)))
(and $x450 (or $x52 (and (distinct ?x187 ?x187) true)))))))
(check-sat)
; query 12: function getint, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x121 (ite (= (_ bv4294967295 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x450 (not $x52)))
(and $x450 (or $x52 (and (distinct ?x121 ?x121) true)))))))
(check-sat)
; query 13: function int_to_uchar, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_32 () (_ BitVec 32))
(assert
 (let (($x319 (and (distinct (bvadd ((_ sign_extend 1) in.03_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.03_32 (_ bv1 32)))) true)))
(let (($x47 (or false false (or $x319))))
(and (not $x47) (or $x47 (and (distinct (bvadd in.03_32 (_ bv1 32)) (bvadd in.03_32 (_ bv1 32))) true))))))
(check-sat)
; query 14: function int_to_uchar, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x120 (and (distinct (bvsub ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) in.0_32)) ((_ sign_extend 1) (bvsub in.01_32 in.0_32))) true)))
(let (($x125 (or false false (or $x120))))
(let (($x107 (or $x125 (and (distinct (bvsub in.01_32 in.0_32) (bvsub in.01_32 in.0_32)) true))))
(and (not $x125) $x107)))))
(check-sat)
; query 15: function int_to_uchar, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.14_32 () (_ BitVec 32))
(assert
 (let (($x32 (and (distinct (bvadd ((_ sign_extend 1) in.14_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.14_32 (_ bv1 32)))) true)))
(let (($x392 (or false false (or $x32))))
(and (not $x392) (or $x392 (and (distinct (bvadd in.14_32 (_ bv1 32)) (bvadd in.14_32 (_ bv1 32))) true))))))
(check-sat)
; query 16: function main, block 129, name %130
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.011_32 () (_ BitVec 32))
(assert
 (let ((?x583 (ite (and (distinct (_ bv0 32) in.011_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x450 (not $x52)))
(and $x450 (or $x52 (and (distinct ?x583 ?x583) true)))))))
(check-sat)
; query 17: function main, block 160, name %161
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x349 (ite (and (distinct (_ bv0 32) in.01_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x450 (not $x52)))
(and $x450 (or $x52 (and (distinct ?x349 ?x349) true)))))))
(check-sat)
; query 18: function main, block 35, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x162 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x366 (or false false (or $x162))))
(and (not $x366) (or $x366 (and (distinct (bvadd in.020_32 (_ bv1 32)) (bvadd in.020_32 (_ bv1 32))) true))))))
(check-sat)
; query 19: function main, block 35, name %37
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let ((?x230 (ite (bvsge (bvadd in.020_32 (_ bv1 32)) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x162 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x366 (or false false (or $x162))))
(let (($x240 (or $x366 false false)))
(and (not $x240) (or $x240 (and (distinct ?x230 ?x230) true))))))))
(check-sat)
; query 20: function main, block 49, name %50
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x162 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x366 (or false false (or $x162))))
(and (not $x366) (or $x366 (and (distinct (bvadd in.020_32 (_ bv1 32)) (bvadd in.020_32 (_ bv1 32))) true))))))
(check-sat)
; query 21: function main, block 49, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let ((?x230 (ite (bvsge (bvadd in.020_32 (_ bv1 32)) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x162 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x366 (or false false (or $x162))))
(let (($x240 (or $x366 false false)))
(and (not $x240) (or $x240 (and (distinct ?x230 ?x230) true))))))))
(check-sat)
; query 22: function main, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.014_32 () (_ BitVec 32))
(assert
 (let ((?x371 (ite (= (_ bv1 32) in.014_32) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x450 (not $x52)))
(and $x450 (or $x52 (and (distinct ?x371 ?x371) true)))))))
(check-sat)
; query 23: function main, block 66, name %67
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x22 (ite (= (_ bv0 32) in.0_32) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x450 (not $x52)))
(and $x450 (or $x52 (and (distinct ?x22 ?x22) true)))))))
(check-sat)
; query 24: function main, block 84, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.07_32 () (_ BitVec 32))
(assert
 (let ((?x62 (ite (and (distinct (_ bv0 32) in.07_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x450 (not $x52)))
(and $x450 (or $x52 (and (distinct ?x62 ?x62) true)))))))
(check-sat)
; query 25: function median, block 103, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x92 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x98 (or false false (or $x92))))
(and (not $x98) (or $x98 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 26: function median, block 106, name %107
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x68 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x258 (or false false (or $x68))))
(and (not $x258) (or $x258 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 27: function setup_brightness_lut, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x68 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x258 (or false false (or $x68))))
(and (not $x258) (or $x258 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 28: function susan_corners, block 1066, name %1067
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x92 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x98 (or false false (or $x92))))
(and (not $x98) (or $x98 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 29: function susan_corners, block 1069, name %1070
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x68 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x258 (or false false (or $x68))))
(and (not $x258) (or $x258 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 30: function susan_corners, block 1549, name %1550
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x96 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x41 (or false false (or $x96))))
(and (not $x41) (or $x41 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 31: function susan_corners, block 1552, name %1553
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x622 (and (distinct (bvadd ((_ sign_extend 1) in.12_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.12_32 (_ bv1 32)))) true)))
(let (($x69 (or false false (or $x622))))
(and (not $x69) (or $x69 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 32: function susan_corners, block 845, name %846
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in839_32 () (_ BitVec 32))
(declare-fun in840_32 () (_ BitVec 32))
(assert
 (let ((?x31 (ite (bvslt in840_32 in839_32) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x450 (not $x52)))
(and $x450 (or $x52 (and (distinct ?x31 ?x31) true)))))))
(check-sat)
; query 33: function susan_corners_quick, block 1469, name %1470
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x96 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x41 (or false false (or $x96))))
(and (not $x41) (or $x41 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 34: function susan_corners_quick, block 1472, name %1473
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x622 (and (distinct (bvadd ((_ sign_extend 1) in.12_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.12_32 (_ bv1 32)))) true)))
(let (($x69 (or false false (or $x622))))
(and (not $x69) (or $x69 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 35: function susan_corners_quick, block 433, name %434
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x92 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x98 (or false false (or $x92))))
(and (not $x98) (or $x98 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 36: function susan_corners_quick, block 436, name %437
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x68 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x258 (or false false (or $x68))))
(and (not $x258) (or $x258 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 37: function susan_edges, block 1432, name %1433
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1417_32 () (_ BitVec 32))
(assert
 (let ((?x13 (ite (bvslt (_ bv0 32) in1417_32) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x450 (not $x52)))
(and $x450 (or $x52 (and (distinct ?x13 ?x13) true)))))))
(check-sat)
; query 38: function susan_edges, block 1486, name %1487
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.116_32 () (_ BitVec 32))
(assert
 (let (($x176 (and (distinct (bvadd ((_ sign_extend 1) in.116_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.116_32 (_ bv1 32)))) true)))
(let (($x201 (or false false (or $x176))))
(and (not $x201) (or $x201 (and (distinct (bvadd in.116_32 (_ bv1 32)) (bvadd in.116_32 (_ bv1 32))) true))))))
(check-sat)
; query 39: function susan_edges, block 1489, name %1490
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.114_32 () (_ BitVec 32))
(assert
 (let (($x581 (and (distinct (bvadd ((_ sign_extend 1) in.114_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.114_32 (_ bv1 32)))) true)))
(let (($x527 (or false false (or $x581))))
(and (not $x527) (or $x527 (and (distinct (bvadd in.114_32 (_ bv1 32)) (bvadd in.114_32 (_ bv1 32))) true))))))
(check-sat)
; query 40: function susan_edges, block 379, name %380
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.015_32 () (_ BitVec 32))
(assert
 (let (($x382 (and (distinct (bvadd ((_ sign_extend 1) in.015_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.015_32 (_ bv1 32)))) true)))
(let (($x634 (or false false (or $x382))))
(and (not $x634) (or $x634 (and (distinct (bvadd in.015_32 (_ bv1 32)) (bvadd in.015_32 (_ bv1 32))) true))))))
(check-sat)
; query 41: function susan_edges, block 382, name %383
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.013_32 () (_ BitVec 32))
(assert
 (let (($x473 (and (distinct (bvadd ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.013_32 (_ bv1 32)))) true)))
(let (($x447 (or false false (or $x473))))
(and (not $x447) (or $x447 (and (distinct (bvadd in.013_32 (_ bv1 32)) (bvadd in.013_32 (_ bv1 32))) true))))))
(check-sat)
; query 42: function susan_edges, block 850, name %851
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in834_32 () (_ BitVec 32))
(assert
 (let ((?x152 (ite (= (_ bv0 32) in834_32) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x450 (not $x52)))
(and $x450 (or $x52 (and (distinct ?x152 ?x152) true)))))))
(check-sat)
; query 43: function susan_edges, block 870, name %871
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x974 (ite (bvslt (_ bv0 32) in.0_32) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x450 (not $x52)))
(and $x450 (or $x52 (and (distinct ?x974 ?x974) true)))))))
(check-sat)
; query 44: function susan_edges_small, block 119, name %120
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.09_32 () (_ BitVec 32))
(assert
 (let (($x909 (and (distinct (bvadd ((_ sign_extend 1) in.09_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.09_32 (_ bv1 32)))) true)))
(let (($x419 (or false false (or $x909))))
(and (not $x419) (or $x419 (and (distinct (bvadd in.09_32 (_ bv1 32)) (bvadd in.09_32 (_ bv1 32))) true))))))
(check-sat)
; query 45: function susan_edges_small, block 122, name %123
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.07_32 () (_ BitVec 32))
(assert
 (let (($x689 (and (distinct (bvadd ((_ sign_extend 1) in.07_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.07_32 (_ bv1 32)))) true)))
(let (($x1089 (or false false (or $x689))))
(and (not $x1089) (or $x1089 (and (distinct (bvadd in.07_32 (_ bv1 32)) (bvadd in.07_32 (_ bv1 32))) true))))))
(check-sat)
; query 46: function susan_edges_small, block 258, name %259
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in243_32 () (_ BitVec 32))
(assert
 (let ((?x275 (ite (= (_ bv0 32) in243_32) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x450 (not $x52)))
(and $x450 (or $x52 (and (distinct ?x275 ?x275) true)))))))
(check-sat)
; query 47: function susan_edges_small, block 278, name %279
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x974 (ite (bvslt (_ bv0 32) in.0_32) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x450 (not $x52)))
(and $x450 (or $x52 (and (distinct ?x974 ?x974) true)))))))
(check-sat)
; query 48: function susan_edges_small, block 426, name %427
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in411_32 () (_ BitVec 32))
(assert
 (let ((?x777 (ite (bvslt (_ bv0 32) in411_32) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x450 (not $x52)))
(and $x450 (or $x52 (and (distinct ?x777 ?x777) true)))))))
(check-sat)
; query 49: function susan_edges_small, block 458, name %459
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.110_32 () (_ BitVec 32))
(assert
 (let (($x571 (and (distinct (bvadd ((_ sign_extend 1) in.110_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.110_32 (_ bv1 32)))) true)))
(let (($x184 (or false false (or $x571))))
(and (not $x184) (or $x184 (and (distinct (bvadd in.110_32 (_ bv1 32)) (bvadd in.110_32 (_ bv1 32))) true))))))
(check-sat)
; query 50: function susan_edges_small, block 461, name %462
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.18_32 () (_ BitVec 32))
(assert
 (let (($x55 (and (distinct (bvadd ((_ sign_extend 1) in.18_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.18_32 (_ bv1 32)))) true)))
(let (($x859 (or false false (or $x55))))
(and (not $x859) (or $x859 (and (distinct (bvadd in.18_32 (_ bv1 32)) (bvadd in.18_32 (_ bv1 32))) true))))))
(check-sat)
; query 51: function susan_principle, block 378, name %379
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x92 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x98 (or false false (or $x92))))
(and (not $x98) (or $x98 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 52: function susan_principle, block 381, name %382
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x68 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x258 (or false false (or $x68))))
(and (not $x258) (or $x258 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 53: function susan_principle_small, block 118, name %119
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x92 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x98 (or false false (or $x92))))
(and (not $x98) (or $x98 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 54: function susan_principle_small, block 121, name %122
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x68 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x258 (or false false (or $x68))))
(and (not $x258) (or $x258 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 55: function susan_smoothing, block 123, name %124
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.09_32 () (_ BitVec 32))
(assert
 (let (($x779 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in.09_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in.09_32))) true)))
(let (($x136 (or false false (or $x779))))
(and (not $x136) (or $x136 (and (distinct (bvsub (_ bv0 32) in.09_32) (bvsub (_ bv0 32) in.09_32)) true))))))
(check-sat)
; query 56: function susan_smoothing, block 143, name %144
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.016_32 () (_ BitVec 32))
(assert
 (let (($x772 (and (distinct (bvadd ((_ sign_extend 1) in.016_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.016_32 (_ bv1 32)))) true)))
(let (($x685 (or false false (or $x772))))
(and (not $x685) (or $x685 (and (distinct (bvadd in.016_32 (_ bv1 32)) (bvadd in.016_32 (_ bv1 32))) true))))))
(check-sat)
; query 57: function susan_smoothing, block 148, name %149
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.017_32 () (_ BitVec 32))
(assert
 (let (($x403 (and (distinct (bvadd ((_ sign_extend 1) in.017_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.017_32 (_ bv1 32)))) true)))
(let (($x354 (or false false (or $x403))))
(and (not $x354) (or $x354 (and (distinct (bvadd in.017_32 (_ bv1 32)) (bvadd in.017_32 (_ bv1 32))) true))))))
(check-sat)
; query 58: function susan_smoothing, block 150, name %151
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.018_32 () (_ BitVec 32))
(assert
 (let (($x757 (and (distinct (bvsub ((_ sign_extend 1) in.018_32) ((_ sign_extend 1) (_ bv10000 32))) ((_ sign_extend 1) (bvsub in.018_32 (_ bv10000 32)))) true)))
(let (($x732 (or false false (or $x757))))
(and (not $x732) (or $x732 (and (distinct (bvsub in.018_32 (_ bv10000 32)) (bvsub in.018_32 (_ bv10000 32))) true))))))
(check-sat)
; query 59: function susan_smoothing, block 150, name %152
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.018_32 () (_ BitVec 32))
(assert
 (let ((?x412 (ite (= (_ bv0 32) (bvsub in.018_32 (_ bv10000 32))) (_ bv1 1) (_ bv0 1))))
(let (($x757 (and (distinct (bvsub ((_ sign_extend 1) in.018_32) ((_ sign_extend 1) (_ bv10000 32))) ((_ sign_extend 1) (bvsub in.018_32 (_ bv10000 32)))) true)))
(let (($x732 (or false false (or $x757))))
(let (($x49 (or $x732 false false)))
(and (not $x49) (or $x49 (and (distinct ?x412 ?x412) true))))))))
(check-sat)
; query 60: function susan_smoothing, block 165, name %166
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.114_32 () (_ BitVec 32))
(assert
 (let (($x581 (and (distinct (bvadd ((_ sign_extend 1) in.114_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.114_32 (_ bv1 32)))) true)))
(let (($x527 (or false false (or $x581))))
(and (not $x527) (or $x527 (and (distinct (bvadd in.114_32 (_ bv1 32)) (bvadd in.114_32 (_ bv1 32))) true))))))
(check-sat)
; query 61: function susan_smoothing, block 168, name %169
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.111_32 () (_ BitVec 32))
(assert
 (let (($x339 (and (distinct (bvadd ((_ sign_extend 1) in.111_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.111_32 (_ bv1 32)))) true)))
(let (($x36 (or false false (or $x339))))
(and (not $x36) (or $x36 (and (distinct (bvadd in.111_32 (_ bv1 32)) (bvadd in.111_32 (_ bv1 32))) true))))))
(check-sat)
; query 62: function susan_smoothing, block 21, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x413 (ite (= (_ bv0 32) (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x450 (not $x52)))
(and $x450 (or $x52 (and (distinct ?x413 ?x413) true)))))))
(check-sat)
; query 63: function susan_smoothing, block 319, name %320
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.215_32 () (_ BitVec 32))
(assert
 (let (($x91 (and (distinct (bvadd ((_ sign_extend 1) in.215_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.215_32 (_ bv1 32)))) true)))
(let (($x405 (or false false (or $x91))))
(and (not $x405) (or $x405 (and (distinct (bvadd in.215_32 (_ bv1 32)) (bvadd in.215_32 (_ bv1 32))) true))))))
(check-sat)
; query 64: function susan_smoothing, block 322, name %323
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.212_32 () (_ BitVec 32))
(assert
 (let (($x649 (and (distinct (bvadd ((_ sign_extend 1) in.212_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.212_32 (_ bv1 32)))) true)))
(let (($x429 (or false false (or $x649))))
(and (not $x429) (or $x429 (and (distinct (bvadd in.212_32 (_ bv1 32)) (bvadd in.212_32 (_ bv1 32))) true))))))
(check-sat)
; query 65: function susan_smoothing, block 67, name %68
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.09_32 () (_ BitVec 32))
(assert
 (let (($x779 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in.09_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in.09_32))) true)))
(let (($x136 (or false false (or $x779))))
(and (not $x136) (or $x136 (and (distinct (bvsub (_ bv0 32) in.09_32) (bvsub (_ bv0 32) in.09_32)) true))))))
(check-sat)
; query 66: function susan_smoothing, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.013_32 () (_ BitVec 32))
(assert
 (let (($x473 (and (distinct (bvadd ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.013_32 (_ bv1 32)))) true)))
(let (($x447 (or false false (or $x473))))
(and (not $x447) (or $x447 (and (distinct (bvadd in.013_32 (_ bv1 32)) (bvadd in.013_32 (_ bv1 32))) true))))))
(check-sat)
; query 67: function susan_smoothing, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.010_32 () (_ BitVec 32))
(assert
 (let (($x920 (and (distinct (bvadd ((_ sign_extend 1) in.010_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.010_32 (_ bv1 32)))) true)))
(let (($x704 (or false false (or $x920))))
(and (not $x704) (or $x704 (and (distinct (bvadd in.010_32 (_ bv1 32)) (bvadd in.010_32 (_ bv1 32))) true))))))
(check-sat)
; query 68: function susan_thin, block 100, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in93_32 () (_ BitVec 32))
(assert
 (let ((?x556 (ite (= (_ bv1 32) in93_32) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x450 (not $x52)))
(and $x450 (or $x52 (and (distinct ?x556 ?x556) true)))))))
(check-sat)
; query 69: function susan_thin, block 428, name %429
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.022_32 () (_ BitVec 32))
(assert
 (let (($x137 (and (distinct (bvadd ((_ sign_extend 1) in.022_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.022_32 (_ bv1 32)))) true)))
(let (($x724 (or false false (or $x137))))
(and (not $x724) (or $x724 (and (distinct (bvadd in.022_32 (_ bv1 32)) (bvadd in.022_32 (_ bv1 32))) true))))))
(check-sat)
; query 70: function susan_thin, block 431, name %432
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.018_32 () (_ BitVec 32))
(assert
 (let (($x824 (and (distinct (bvadd ((_ sign_extend 1) in.018_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.018_32 (_ bv1 32)))) true)))
(let (($x601 (or false false (or $x824))))
(and (not $x601) (or $x601 (and (distinct (bvadd in.018_32 (_ bv1 32)) (bvadd in.018_32 (_ bv1 32))) true))))))
(check-sat)
; query 71: function susan_thin, block 433, name %434
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.040_32 () (_ BitVec 32))
(assert
 (let ((?x620 (ite (bvslt (_ bv0 32) in.040_32) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x450 (not $x52)))
(and $x450 (or $x52 (and (distinct ?x620 ?x620) true)))))))
(check-sat)
; query 72: function susan_thin, block 469, name %470
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.235_32 () (_ BitVec 32))
(assert
 (let ((?x914 (bvadd in.235_32 in.235_32)))
(let ((?x338 ((_ sign_extend 1) ?x914)))
(let (($x489 (and (distinct (bvadd ((_ sign_extend 1) in.235_32) ((_ sign_extend 1) in.235_32)) ?x338) true)))
(let (($x740 (or false false (or $x489))))
(and (not $x740) (or $x740 (and (distinct ?x914 ?x914) true))))))))
(check-sat)
; query 73: function susan_thin, block 469, name %471
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.228_32 () (_ BitVec 32))
(declare-fun in.235_32 () (_ BitVec 32))
(assert
 (let ((?x914 (bvadd in.235_32 in.235_32)))
(let ((?x626 (bvadd ?x914 in.228_32)))
(let (($x280 (and (distinct (bvadd ((_ sign_extend 1) ?x914) ((_ sign_extend 1) in.228_32)) ((_ sign_extend 1) ?x626)) true)))
(let ((?x338 ((_ sign_extend 1) ?x914)))
(let (($x489 (and (distinct (bvadd ((_ sign_extend 1) in.235_32) ((_ sign_extend 1) in.235_32)) ?x338) true)))
(let (($x740 (or false false (or $x489))))
(let (($x67 (or $x740 false (or $x280))))
(and (not $x67) (or $x67 (and (distinct ?x626 ?x626) true)))))))))))
(check-sat)
; query 74: function susan_thin, block 469, name %472
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.228_32 () (_ BitVec 32))
(declare-fun in.235_32 () (_ BitVec 32))
(assert
 (let ((?x462 (ite (bvsgt (_ bv3 32) (bvadd (bvadd in.235_32 in.235_32) in.228_32)) (_ bv1 1) (_ bv0 1))))
(let ((?x570 ((_ sign_extend 1) in.228_32)))
(let ((?x914 (bvadd in.235_32 in.235_32)))
(let ((?x338 ((_ sign_extend 1) ?x914)))
(let (($x706 (or (and (distinct (bvadd ?x338 ?x570) ((_ sign_extend 1) (bvadd ?x914 in.228_32))) true))))
(let (($x489 (and (distinct (bvadd ((_ sign_extend 1) in.235_32) ((_ sign_extend 1) in.235_32)) ?x338) true)))
(let (($x740 (or false false (or $x489))))
(let (($x67 (or $x740 false $x706)))
(let (($x269 (or $x67 false false)))
(and (not $x269) (or $x269 (and (distinct ?x462 ?x462) true)))))))))))))
(check-sat)
; query 75: function susan_thin, block 473, name %474
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.235_32 () (_ BitVec 32))
(assert
 (let ((?x552 (bvsub in.235_32 (_ bv1 32))))
(let ((?x488 ((_ sign_extend 1) ?x552)))
(let (($x313 (or (and (distinct (bvsub ((_ sign_extend 1) in.235_32) ((_ sign_extend 1) (_ bv1 32))) ?x488) true))))
(let (($x309 (or false false $x313)))
(and (not $x309) (or $x309 (and (distinct ?x552 ?x552) true))))))))
(check-sat)
; query 76: function susan_thin, block 473, name %475
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.235_32 () (_ BitVec 32))
(declare-fun in.14_32 () (_ BitVec 32))
(assert
 (let ((?x552 (bvsub in.235_32 (_ bv1 32))))
(let ((?x486 (bvadd in.14_32 ?x552)))
(let (($x767 (and (distinct (bvadd ((_ sign_extend 1) in.14_32) ((_ sign_extend 1) ?x552)) ((_ sign_extend 1) ?x486)) true)))
(let ((?x488 ((_ sign_extend 1) ?x552)))
(let (($x313 (or (and (distinct (bvsub ((_ sign_extend 1) in.235_32) ((_ sign_extend 1) (_ bv1 32))) ?x488) true))))
(let (($x309 (or false false $x313)))
(let (($x239 (or false $x309 (or $x767))))
(and (not $x239) (or $x239 (and (distinct ?x486 ?x486) true)))))))))))
(check-sat)
; query 77: function susan_thin, block 473, name %476
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.228_32 () (_ BitVec 32))
(assert
 (let ((?x494 (bvsub in.228_32 (_ bv2 32))))
(let ((?x619 ((_ sign_extend 1) ?x494)))
(let (($x545 (or (and (distinct (bvsub ((_ sign_extend 1) in.228_32) ((_ sign_extend 1) (_ bv2 32))) ?x619) true))))
(let (($x299 (or false false $x545)))
(and (not $x299) (or $x299 (and (distinct ?x494 ?x494) true))))))))
(check-sat)
; query 78: function susan_thin, block 473, name %477
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.228_32 () (_ BitVec 32))
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x494 (bvsub in.228_32 (_ bv2 32))))
(let ((?x729 (bvadd in.0_32 ?x494)))
(let (($x630 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) ?x494)) ((_ sign_extend 1) ?x729)) true)))
(let ((?x619 ((_ sign_extend 1) ?x494)))
(let (($x545 (or (and (distinct (bvsub ((_ sign_extend 1) in.228_32) ((_ sign_extend 1) (_ bv2 32))) ?x619) true))))
(let (($x299 (or false false $x545)))
(let (($x888 (or false $x299 (or $x630))))
(and (not $x888) (or $x888 (and (distinct ?x729 ?x729) true)))))))))))
(check-sat)
; query 79: function susan_thin, block 473, name %478
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.235_32 () (_ BitVec 32))
(declare-fun in.14_32 () (_ BitVec 32))
(assert
 (let ((?x695 (ite (bvsgt (_ bv4 32) (bvadd in.14_32 (bvsub in.235_32 (_ bv1 32)))) (_ bv1 1) (_ bv0 1))))
(let (($x767 (and (distinct (bvadd ((_ sign_extend 1) in.14_32) ((_ sign_extend 1) (bvsub in.235_32 (_ bv1 32)))) ((_ sign_extend 1) (bvadd in.14_32 (bvsub in.235_32 (_ bv1 32))))) true)))
(let ((?x552 (bvsub in.235_32 (_ bv1 32))))
(let ((?x488 ((_ sign_extend 1) ?x552)))
(let (($x313 (or (and (distinct (bvsub ((_ sign_extend 1) in.235_32) ((_ sign_extend 1) (_ bv1 32))) ?x488) true))))
(let (($x309 (or false false $x313)))
(let (($x239 (or false $x309 (or $x767))))
(let (($x823 (or $x239 false false)))
(and (not $x823) (or $x823 (and (distinct ?x695 ?x695) true))))))))))))
(check-sat)
; query 80: function susan_thin, block 533, name %534
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in528_32 () (_ BitVec 32))
(declare-fun in498_32 () (_ BitVec 32))
(assert
 (let (($x52 (or false false false)))
(let (($x773 (or $x52 (and (distinct (bvor in498_32 in528_32) (bvor in498_32 in528_32)) true))))
(let (($x450 (not $x52)))
(and $x450 $x773)))))
(check-sat)
; query 81: function susan_thin, block 533, name %535
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in518_32 () (_ BitVec 32))
(declare-fun in508_32 () (_ BitVec 32))
(assert
 (let (($x52 (or false false false)))
(let (($x374 (or $x52 (and (distinct (bvor in508_32 in518_32) (bvor in508_32 in518_32)) true))))
(let (($x450 (not $x52)))
(and $x450 $x374)))))
(check-sat)
; query 82: function susan_thin, block 533, name %536
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in518_32 () (_ BitVec 32))
(declare-fun in508_32 () (_ BitVec 32))
(declare-fun in528_32 () (_ BitVec 32))
(declare-fun in498_32 () (_ BitVec 32))
(assert
 (let ((?x882 (bvor in508_32 in518_32)))
(let ((?x640 (bvor in498_32 in528_32)))
(let ((?x602 (bvand ?x640 ?x882)))
(let (($x52 (or false false false)))
(let (($x529 (or $x52 $x52 false)))
(let (($x656 (not $x529)))
(and $x656 (or $x529 (and (distinct ?x602 ?x602) true))))))))))
(check-sat)
; query 83: function susan_thin, block 533, name %537
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in518_32 () (_ BitVec 32))
(declare-fun in508_32 () (_ BitVec 32))
(declare-fun in528_32 () (_ BitVec 32))
(declare-fun in498_32 () (_ BitVec 32))
(assert
 (let ((?x882 (bvor in508_32 in518_32)))
(let ((?x640 (bvor in498_32 in528_32)))
(let ((?x602 (bvand ?x640 ?x882)))
(let ((?x730 (ite (and (distinct (_ bv0 32) ?x602) true) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x529 (or $x52 $x52 false)))
(let (($x765 (or $x529 false false)))
(let (($x478 (not $x765)))
(and $x478 (or $x765 (and (distinct ?x730 ?x730) true))))))))))))
(check-sat)
; query 84: function susan_thin, block 538, name %539
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in498_32 () (_ BitVec 32))
(assert
 (let ((?x436 (ite (and (distinct (_ bv0 32) in498_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x450 (not $x52)))
(and $x450 (or $x52 (and (distinct ?x436 ?x436) true)))))))
(check-sat)
; query 85: function susan_thin, block 540, name %541
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in508_32 () (_ BitVec 32))
(assert
 (let ((?x164 (ite (and (distinct (_ bv0 32) in508_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x450 (not $x52)))
(and $x450 (or $x52 (and (distinct ?x164 ?x164) true)))))))
(check-sat)
; query 86: function susan_thin, block 545, name %546
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in508_32 () (_ BitVec 32))
(assert
 (let ((?x164 (ite (and (distinct (_ bv0 32) in508_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x450 (not $x52)))
(and $x450 (or $x52 (and (distinct ?x164 ?x164) true)))))))
(check-sat)
; query 87: function susan_thin, block 563, name %564
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.325_32 () (_ BitVec 32))
(assert
 (let ((?x810 (ite (= (_ bv0 32) in.325_32) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x450 (not $x52)))
(and $x450 (or $x52 (and (distinct ?x810 ?x810) true)))))))
(check-sat)
; query 88: function susan_thin, block 597, name %598
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.321_32 () (_ BitVec 32))
(assert
 (let ((?x44 (ite (= (_ bv0 32) in.321_32) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x450 (not $x52)))
(and $x450 (or $x52 (and (distinct ?x44 ?x44) true)))))))
(check-sat)
; query 89: function susan_thin, block 685, name %686
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in662_32 () (_ BitVec 32))
(declare-fun in680_32 () (_ BitVec 32))
(assert
 (let (($x52 (or false false false)))
(let (($x353 (or $x52 (and (distinct (bvor in680_32 in662_32) (bvor in680_32 in662_32)) true))))
(let (($x450 (not $x52)))
(and $x450 $x353)))))
(check-sat)
; query 90: function susan_thin, block 685, name %687
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in671_32 () (_ BitVec 32))
(declare-fun in653_32 () (_ BitVec 32))
(assert
 (let (($x52 (or false false false)))
(let (($x845 (or $x52 (and (distinct (bvor in653_32 in671_32) (bvor in653_32 in671_32)) true))))
(let (($x450 (not $x52)))
(and $x450 $x845)))))
(check-sat)
; query 91: function susan_thin, block 685, name %688
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in671_32 () (_ BitVec 32))
(declare-fun in653_32 () (_ BitVec 32))
(declare-fun in662_32 () (_ BitVec 32))
(declare-fun in680_32 () (_ BitVec 32))
(assert
 (let ((?x430 (bvor in653_32 in671_32)))
(let ((?x468 (bvor in680_32 in662_32)))
(let ((?x547 (bvand ?x468 ?x430)))
(let (($x52 (or false false false)))
(let (($x529 (or $x52 $x52 false)))
(let (($x656 (not $x529)))
(and $x656 (or $x529 (and (distinct ?x547 ?x547) true))))))))))
(check-sat)
; query 92: function susan_thin, block 685, name %689
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in671_32 () (_ BitVec 32))
(declare-fun in653_32 () (_ BitVec 32))
(declare-fun in662_32 () (_ BitVec 32))
(declare-fun in680_32 () (_ BitVec 32))
(assert
 (let ((?x430 (bvor in653_32 in671_32)))
(let ((?x468 (bvor in680_32 in662_32)))
(let ((?x547 (bvand ?x468 ?x430)))
(let ((?x713 (ite (and (distinct (_ bv0 32) ?x547) true) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x529 (or $x52 $x52 false)))
(let (($x765 (or $x529 false false)))
(let (($x478 (not $x765)))
(and $x478 (or $x765 (and (distinct ?x713 ?x713) true))))))))))))
(check-sat)
; query 93: function susan_thin, block 915, name %916
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.13_32 () (_ BitVec 32))
(assert
 (let (($x243 (and (distinct (bvadd ((_ sign_extend 1) in.13_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.13_32 (_ bv1 32)))) true)))
(let (($x177 (or false false (or $x243))))
(and (not $x177) (or $x177 (and (distinct (bvadd in.13_32 (_ bv1 32)) (bvadd in.13_32 (_ bv1 32))) true))))))
(check-sat)
; query 94: function susan_thin, block 918, name %919
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.14_32 () (_ BitVec 32))
(assert
 (let (($x32 (and (distinct (bvadd ((_ sign_extend 1) in.14_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.14_32 (_ bv1 32)))) true)))
(let (($x392 (or false false (or $x32))))
(and (not $x392) (or $x392 (and (distinct (bvadd in.14_32 (_ bv1 32)) (bvadd in.14_32 (_ bv1 32))) true))))))
(check-sat)
