; OptiPhase-Sigma refinement certificate for sweep K39-R2-009
; query 0: function BF_ofb64_encrypt, block 82, name %83
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x273 (ite (= (_ bv0 32) in.04_32) (_ bv1 1) (_ bv0 1))))
(let (($x602 (or false false false)))
(and (not $x602) (or $x602 (and (distinct ?x273 ?x273) true))))))
(check-sat)
