; OptiPhase-Sigma refinement certificate for sweep K58-R3-127
; query 0: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x394 (or false false false)))
(let (($x60 (not $x394)))
(and $x60 (or $x394 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x10 (bvadd in.01_32 (_ bv1 32))))
(let ((?x435 (bvmul ?x10 ?x10)))
(let (($x394 (or false false false)))
(let (($x594 (or $x394 $x394 false)))
(and (not $x594) (or $x594 (and (distinct ?x435 ?x435) true))))))))
(check-sat)
; query 2: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x15 (and (distinct (bvmul (bvmul (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) (_ bv2 32)) (bvshl (bvmul (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) (_ bv3 32))) true)))
(let (($x394 (or false false false)))
(let (($x594 (or $x394 $x394 false)))
(let (($x56 (or $x594 false false)))
(and (not $x56) (or (or $x56 (bvuge (_ bv3 32) (_ bv32 32))) $x15)))))))
(check-sat)
; query 3: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x83 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x394 (or false false false)))
(let (($x60 (not $x394)))
(and $x60 (or $x394 (and (distinct ?x83 ?x83) true)))))))
(check-sat)
; query 4: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x394 (or false false false)))
(let (($x60 (not $x394)))
(and $x60 (or $x394 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 5: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x287 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x394 (or false false false)))
(let (($x60 (not $x394)))
(and $x60 (or $x394 (and (distinct ?x287 ?x287) true)))))))
(check-sat)
