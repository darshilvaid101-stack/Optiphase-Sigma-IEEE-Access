; OptiPhase-Sigma refinement certificate for sweep K38-R5-404
