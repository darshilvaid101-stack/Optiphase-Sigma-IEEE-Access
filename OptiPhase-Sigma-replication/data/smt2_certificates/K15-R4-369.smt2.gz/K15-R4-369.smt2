; OptiPhase-Sigma refinement certificate for sweep K15-R4-369
