; OptiPhase-Sigma refinement certificate for sweep K56-R3-108
; query 0: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x374 (or false false)))
(let (($x58 (not $x374)))
(and $x58 (or $x374 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 1: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x1748 ((_ sign_extend 16) in3_16)))
(let ((?x221 (bvand ?x1748 (_ bv127 32))))
(let (($x374 (or false false)))
(let (($x1948 (or $x374 false false)))
(let (($x1354 (not $x1948)))
(and $x1354 (or $x1948 (and (distinct ?x221 ?x221) true)))))))))
(check-sat)
; query 2: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x1748 ((_ sign_extend 16) in3_16)))
(let ((?x221 (bvand ?x1748 (_ bv127 32))))
(let ((?x1213 ((_ extract 15 0) ?x221)))
(let (($x374 (or false false)))
(let (($x1948 (or $x374 false false)))
(let (($x1650 (or $x1948 false)))
(and (not $x1650) (or $x1650 (and (distinct ?x1213 ?x1213) true))))))))))
(check-sat)
; query 3: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x374 (or false false)))
(let (($x58 (not $x374)))
(and $x58 (or $x374 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 4: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x132 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x374 (or false false)))
(let (($x1948 (or $x374 false false)))
(let (($x1354 (not $x1948)))
(and $x1354 (or $x1948 (and (distinct ?x132 ?x132) true))))))))
(check-sat)
; query 5: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x56 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x661 (or false false false)))
(let (($x974 (not $x661)))
(and $x974 (or $x661 (and (distinct ?x56 ?x56) true)))))))
(check-sat)
; query 6: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x1836 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x661 (or false false false)))
(let (($x974 (not $x661)))
(and $x974 (or $x661 (and (distinct ?x1836 ?x1836) true)))))))
(check-sat)
; query 7: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x661 (or false false false)))
(let (($x974 (not $x661)))
(and $x974 (or $x661 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 8: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x700 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x92 (or false false (or $x700))))
(and (not $x92) (or $x92 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 9: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x11 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x661 (or false false false)))
(let (($x974 (not $x661)))
(and $x974 (or $x661 (and (distinct ?x11 ?x11) true)))))))
(check-sat)
