; OptiPhase-Sigma refinement certificate for sweep K45-R4-339
; query 0: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x90 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x121 (or false false false)))
(let (($x89 (not $x121)))
(and $x89 (or $x121 (and (distinct ?x90 ?x90) true)))))))
(check-sat)
; query 1: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x1321 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x121 (or false false false)))
(let (($x89 (not $x121)))
(and $x89 (or $x121 (and (distinct ?x1321 ?x1321) true)))))))
(check-sat)
