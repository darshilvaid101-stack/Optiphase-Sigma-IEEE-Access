; OptiPhase-Sigma refinement certificate for sweep K07-R2-012
