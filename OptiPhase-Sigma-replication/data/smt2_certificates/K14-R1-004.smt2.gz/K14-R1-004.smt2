; OptiPhase-Sigma refinement certificate for sweep K14-R1-004
