; OptiPhase-Sigma refinement certificate for sweep K23-R2-022
; query 0: function init_array, block 12, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x50 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x133 (or false false (or $x50))))
(and (not $x133) (or $x133 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function init_array, block 25, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x60 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x82 (or false false (or $x60))))
(and (not $x82) (or $x82 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function init_array, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x171 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x172 (or false false (or $x171))))
(and (not $x172) (or $x172 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 3: function kernel_nussinov, block 11, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x105 (and (distinct (bvsub ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvsub in.01_32 (_ bv1 32)))) true)))
(let (($x114 (or false false (or $x105))))
(and (not $x114) (or $x114 (and (distinct (bvsub in.01_32 (_ bv1 32)) (bvsub in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 4: function kernel_nussinov, block 11, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x31 (ite (bvsle (_ bv0 32) (bvsub in.01_32 (_ bv1 32))) (_ bv1 1) (_ bv0 1))))
(let (($x105 (and (distinct (bvsub ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvsub in.01_32 (_ bv1 32)))) true)))
(let (($x114 (or false false (or $x105))))
(let (($x119 (or $x114 false false)))
(and (not $x119) (or $x119 (and (distinct ?x31 ?x31) true))))))))
(check-sat)
; query 5: function kernel_nussinov, block 46, name %47
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x47 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x70 (or false false (or $x47))))
(and (not $x70) (or $x70 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 6: function kernel_nussinov, block 46, name %48
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x34 (ite (bvslt (bvadd in.02_32 (_ bv1 32)) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x47 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x70 (or false false (or $x47))))
(let (($x17 (or $x70 false false)))
(and (not $x17) (or $x17 (and (distinct ?x34 ?x34) true))))))))
(check-sat)
; query 7: function kernel_nussinov, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x47 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x70 (or false false (or $x47))))
(and (not $x70) (or $x70 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function kernel_nussinov, block 81, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x105 (and (distinct (bvsub ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvsub in.01_32 (_ bv1 32)))) true)))
(let (($x114 (or false false (or $x105))))
(and (not $x114) (or $x114 (and (distinct (bvsub in.01_32 (_ bv1 32)) (bvsub in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 9: function kernel_nussinov, block 81, name %83
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x31 (ite (bvsle (_ bv0 32) (bvsub in.01_32 (_ bv1 32))) (_ bv1 1) (_ bv0 1))))
(let (($x105 (and (distinct (bvsub ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvsub in.01_32 (_ bv1 32)))) true)))
(let (($x114 (or false false (or $x105))))
(let (($x119 (or $x114 false false)))
(and (not $x119) (or $x119 (and (distinct ?x31 ?x31) true))))))))
(check-sat)
; query 10: function kernel_nussinov, block 84, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x47 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x70 (or false false (or $x47))))
(and (not $x70) (or $x70 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 11: function kernel_nussinov, block 84, name %86
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x34 (ite (bvslt (bvadd in.02_32 (_ bv1 32)) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x47 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x70 (or false false (or $x47))))
(let (($x17 (or $x70 false false)))
(and (not $x17) (or $x17 (and (distinct ?x34 ?x34) true))))))))
(check-sat)
; query 12: function kernel_nussinov, block 87, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x105 (and (distinct (bvsub ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvsub in.01_32 (_ bv1 32)))) true)))
(let (($x114 (or false false (or $x105))))
(and (not $x114) (or $x114 (and (distinct (bvsub in.01_32 (_ bv1 32)) (bvsub in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 13: function kernel_nussinov, block 87, name %89
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x12 (ite (bvslt in.02_32 (bvsub in.01_32 (_ bv1 32))) (_ bv1 1) (_ bv0 1))))
(let (($x105 (and (distinct (bvsub ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvsub in.01_32 (_ bv1 32)))) true)))
(let (($x114 (or false false (or $x105))))
(let (($x120 (or false $x114 false)))
(and (not $x120) (or $x120 (and (distinct ?x12 ?x12) true))))))))
(check-sat)
; query 14: function kernel_nussinov, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x61 (and (distinct (bvsub ((_ sign_extend 1) in0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvsub in0_32 (_ bv1 32)))) true)))
(let (($x339 (or false false (or $x61))))
(and (not $x339) (or $x339 (and (distinct (bvsub in0_32 (_ bv1 32)) (bvsub in0_32 (_ bv1 32))) true))))))
(check-sat)
; query 15: function polybench_flush_cache, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x50 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x133 (or false false (or $x50))))
(and (not $x133) (or $x133 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 16: function print_array, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x50 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x133 (or false false (or $x50))))
(and (not $x133) (or $x133 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 17: function print_array, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x47 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x70 (or false false (or $x47))))
(and (not $x70) (or $x70 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
