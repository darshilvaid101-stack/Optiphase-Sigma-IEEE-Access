; OptiPhase-Sigma refinement certificate for sweep K47-R3-119
; query 0: function adpcm_decoder, block 61, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.210_32 () (_ BitVec 32))
(declare-fun in.013_32 () (_ BitVec 32))
(assert
 (let ((?x121 (bvadd in.013_32 in.210_32)))
(let ((?x110 (bvsub in.013_32 in.210_32)))
(let (($x153 (and (distinct (bvadd ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x121)) true)))
(let (($x161 (and (distinct (bvsub ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x110)) true)))
(and (not (or false false (or $x161))) (or (or false false (or $x153)) (and (distinct ?x110 ?x121) true))))))))
(check-sat)
; query 1: function main, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x94 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x89 (or false false false)))
(and (not $x89) (or $x89 (and (distinct ?x94 ?x94) true))))))
(check-sat)
