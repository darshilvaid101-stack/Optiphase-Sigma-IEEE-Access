; OptiPhase-Sigma refinement certificate for sweep K44-R6-058
; query 0: function IsPowerOfTwo, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x219 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x40 (or false false false)))
(let (($x148 (not $x40)))
(and $x148 (or $x40 (and (distinct ?x219 ?x219) true)))))))
(check-sat)
; query 1: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x219 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x40 (or false false false)))
(let (($x148 (not $x40)))
(and $x148 (or $x40 (and (distinct ?x219 ?x219) true)))))))
(check-sat)
; query 2: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x72 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x40 (or false false false)))
(let (($x148 (not $x40)))
(and $x148 (or $x40 (and (distinct ?x72 ?x72) true)))))))
(check-sat)
