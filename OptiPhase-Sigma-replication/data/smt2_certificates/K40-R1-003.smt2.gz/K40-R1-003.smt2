; OptiPhase-Sigma refinement certificate for sweep K40-R1-003
