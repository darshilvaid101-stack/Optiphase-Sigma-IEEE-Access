; OptiPhase-Sigma refinement certificate for sweep K49-R3-235
; query 0: function APCM_inverse_quantization, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x187 (or false false)))
(let (($x1711 (not $x187)))
(and $x1711 (or $x187 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 1: function APCM_inverse_quantization, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x9 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false)))
(let (($x49 (or $x187 false false)))
(let (($x43 (not $x49)))
(and $x43 (or $x49 (and (distinct ?x9 ?x9) true))))))))
(check-sat)
; query 2: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x187 (or false false)))
(let (($x1711 (not $x187)))
(and $x1711 (or $x187 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 3: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x96 (ite (bvslt (_ bv15 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false)))
(let (($x49 (or $x187 false false)))
(let (($x43 (not $x49)))
(and $x43 (or $x49 (and (distinct ?x96 ?x96) true))))))))
(check-sat)
; query 4: function Decoding_of_the_coded_Log_Area_Ratios, block 170, name %171
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in167_64 () (_ BitVec 64))
(assert
 (let (($x51 (and (distinct (ite (bvsge (_ bv18446744073709518848 64) in167_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv0 64) in167_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x41 (or false false false)))
(let (($x234 (not $x41)))
(and $x234 (or $x41 $x51))))))
(check-sat)
; query 5: function Decoding_of_the_coded_Log_Area_Ratios, block 268, name %269
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in265_64 () (_ BitVec 64))
(assert
 (let (($x132 (and (distinct (ite (bvsge (_ bv18446744073709518848 64) in265_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv0 64) in265_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x41 (or false false false)))
(let (($x234 (not $x41)))
(and $x234 (or $x41 $x132))))))
(check-sat)
; query 6: function Decoding_of_the_coded_Log_Area_Ratios, block 58, name %59
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in55_64 () (_ BitVec 64))
(assert
 (let (($x119 (and (distinct (ite (bvslt (_ bv0 64) in55_64) (_ bv1 1) (_ bv0 1)) (ite (bvsge (_ bv18446744073709518848 64) in55_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x41 (or false false false)))
(let (($x234 (not $x41)))
(and $x234 (or $x41 $x119))))))
(check-sat)
; query 7: function Decoding_of_the_coded_Log_Area_Ratios, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in6_64 () (_ BitVec 64))
(assert
 (let ((?x131 (ite (bvslt (_ bv0 64) in6_64) (_ bv1 1) (_ bv0 1))))
(let (($x41 (or false false false)))
(let (($x234 (not $x41)))
(and $x234 (or $x41 (and (distinct ?x131 ?x131) true)))))))
(check-sat)
; query 8: function Decoding_of_the_coded_Log_Area_Ratios, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in6_64 () (_ BitVec 64))
(assert
 (let ((?x131 (ite (bvslt (_ bv0 64) in6_64) (_ bv1 1) (_ bv0 1))))
(let ((?x610 ((_ zero_extend 63) ?x131)))
(let (($x41 (or false false false)))
(let (($x467 (or $x41 false)))
(let (($x90 (not $x467)))
(and $x90 (or $x467 (and (distinct ?x610 ?x610) true)))))))))
(check-sat)
; query 9: function Decoding_of_the_coded_Log_Area_Ratios, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in6_64 () (_ BitVec 64))
(assert
 (let ((?x131 (ite (bvslt (_ bv0 64) in6_64) (_ bv1 1) (_ bv0 1))))
(let (($x16 (= (_ bv1 1) ?x131)))
(let ((?x160 (ite $x16 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x41 (or false false false)))
(let (($x97 (or $x41 (ite $x16 false false))))
(and (not $x97) (or $x97 (and (distinct ?x160 ?x160) true)))))))))
(check-sat)
; query 10: function Decoding_of_the_coded_Log_Area_Ratios, block 9, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in6_64 () (_ BitVec 64))
(assert
 (let ((?x131 (ite (bvslt (_ bv0 64) in6_64) (_ bv1 1) (_ bv0 1))))
(let (($x16 (= (_ bv1 1) ?x131)))
(let ((?x160 (ite $x16 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x15 ((_ sign_extend 32) ?x160)))
(let (($x41 (or false false false)))
(let (($x97 (or $x41 (ite $x16 false false))))
(let (($x235 (or $x97 false)))
(and (not $x235) (or $x235 (and (distinct ?x15 ?x15) true)))))))))))
(check-sat)
; query 11: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x187 (or false false)))
(let (($x1711 (not $x187)))
(and $x1711 (or $x187 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 12: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x38 (ite (bvsgt (_ bv40 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false)))
(let (($x49 (or $x187 false false)))
(let (($x43 (not $x49)))
(and $x43 (or $x49 (and (distinct ?x38 ?x38) true))))))))
(check-sat)
; query 13: function RPE_grid_positioning, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x187 (or false false)))
(let (($x1711 (not $x187)))
(and $x1711 (or $x187 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 14: function RPE_grid_positioning, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x81 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x220 (and (distinct ?x81 ?x81) true)))
(let (($x187 (or false false)))
(let (($x184 (or false $x187 false)))
(and (not $x184) (or $x184 $x220)))))))
(check-sat)
; query 15: function Reflection_coefficients, block 174, name %175
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in171_64 () (_ BitVec 64))
(assert
 (let ((?x162 (ite (bvslt (_ bv0 64) in171_64) (_ bv1 1) (_ bv0 1))))
(let (($x41 (or false false false)))
(let (($x234 (not $x41)))
(and $x234 (or $x41 (and (distinct ?x162 ?x162) true)))))))
(check-sat)
; query 16: function Reflection_coefficients, block 174, name %176
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in171_64 () (_ BitVec 64))
(assert
 (let ((?x162 (ite (bvslt (_ bv0 64) in171_64) (_ bv1 1) (_ bv0 1))))
(let ((?x153 ((_ zero_extend 63) ?x162)))
(let (($x41 (or false false false)))
(let (($x467 (or $x41 false)))
(let (($x90 (not $x467)))
(and $x90 (or $x467 (and (distinct ?x153 ?x153) true)))))))))
(check-sat)
; query 17: function Reflection_coefficients, block 174, name %177
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in171_64 () (_ BitVec 64))
(assert
 (let ((?x162 (ite (bvslt (_ bv0 64) in171_64) (_ bv1 1) (_ bv0 1))))
(let (($x102 (= (_ bv1 1) ?x162)))
(let ((?x116 (ite $x102 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x41 (or false false false)))
(let (($x99 (or $x41 (ite $x102 false false))))
(and (not $x99) (or $x99 (and (distinct ?x116 ?x116) true)))))))))
(check-sat)
; query 18: function Reflection_coefficients, block 174, name %178
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in171_64 () (_ BitVec 64))
(assert
 (let ((?x162 (ite (bvslt (_ bv0 64) in171_64) (_ bv1 1) (_ bv0 1))))
(let (($x102 (= (_ bv1 1) ?x162)))
(let ((?x116 (ite $x102 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x7 ((_ sign_extend 32) ?x116)))
(let (($x41 (or false false false)))
(let (($x99 (or $x41 (ite $x102 false false))))
(let (($x143 (or $x99 false)))
(and (not $x143) (or $x143 (and (distinct ?x7 ?x7) true)))))))))))
(check-sat)
; query 19: function gsm_L_add, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_64 () (_ BitVec 64))
(assert
 (let ((?x6 (bvsub (_ bv0 64) in13_64)))
(let ((?x52 ((_ sign_extend 1) ?x6)))
(let (($x647 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in13_64)) ?x52) true)))))
(and (not $x647) (or $x647 (and (distinct ?x6 ?x6) true)))))))
(check-sat)
; query 20: function gsm_L_add, block 16, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_64 () (_ BitVec 64))
(assert
 (let ((?x6 (bvsub (_ bv0 64) in13_64)))
(let ((?x136 (bvsub ?x6 (_ bv2 64))))
(let (($x28 (and (distinct (bvsub ((_ sign_extend 1) ?x6) ((_ sign_extend 1) (_ bv2 64))) ((_ sign_extend 1) ?x136)) true)))
(let ((?x52 ((_ sign_extend 1) ?x6)))
(let (($x647 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in13_64)) ?x52) true)))))
(let (($x615 (or $x647 false (or $x28))))
(and (not $x615) (or $x615 (and (distinct ?x136 ?x136) true))))))))))
(check-sat)
; query 21: function gsm_L_add, block 21, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x180 (ite (bvsge (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x41 (or false false false)))
(let (($x234 (not $x41)))
(and $x234 (or $x41 (and (distinct ?x180 ?x180) true)))))))
(check-sat)
; query 22: function gsm_L_add, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2791 (bvadd in0_64 in1_64)))
(let (($x156 (and (distinct ?x2791 ?x2791) true)))
(let (($x42 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) ?x2791)) true)))
(let (($x83 (or false false (or $x42))))
(and (not $x83) (or $x83 $x156)))))))
(check-sat)
; query 23: function gsm_L_add, block 25, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2791 (bvadd in0_64 in1_64)))
(let (($x156 (and (distinct ?x2791 ?x2791) true)))
(let (($x27 (and (distinct (bvadd ((_ zero_extend 1) in0_64) ((_ zero_extend 1) in1_64)) ((_ zero_extend 1) ?x2791)) true)))
(let (($x77 (or false false (or $x27))))
(let (($x41 (or false false false)))
(let (($x234 (not $x41)))
(and $x234 (or $x77 $x156)))))))))
(check-sat)
; query 24: function gsm_L_add, block 25, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x163 (ite (bvugt (bvadd in0_64 in1_64) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x27 (and (distinct (bvadd ((_ zero_extend 1) in0_64) ((_ zero_extend 1) in1_64)) ((_ zero_extend 1) (bvadd in0_64 in1_64))) true)))
(let (($x77 (or false false (or $x27))))
(let (($x41 (or false false false)))
(let (($x65 (or $x41 false false)))
(let (($x1804 (not $x65)))
(and $x1804 (or (or $x77 false false) (and (distinct ?x163 ?x163) true))))))))))
(check-sat)
; query 25: function gsm_L_add, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x157 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x41 (or false false false)))
(let (($x234 (not $x41)))
(and $x234 (or $x41 (and (distinct ?x157 ?x157) true)))))))
(check-sat)
; query 26: function gsm_L_add, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2791 (bvadd in0_64 in1_64)))
(let (($x156 (and (distinct ?x2791 ?x2791) true)))
(let (($x42 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) ?x2791)) true)))
(let (($x83 (or false false (or $x42))))
(and (not $x83) (or $x83 $x156)))))))
(check-sat)
; query 27: function gsm_L_add, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x358 (bvadd in0_64 (_ bv1 64))))
(let ((?x183 (bvsub (_ bv0 64) ?x358)))
(let (($x1956 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x358)) ((_ sign_extend 1) ?x183)) true)))
(let ((?x634 ((_ sign_extend 1) ?x358)))
(let (($x2782 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x634) true)))))
(let (($x632 (or false $x2782 (or $x1956))))
(and (not $x632) (or $x632 (and (distinct ?x183 ?x183) true))))))))))
(check-sat)
; query 28: function gsm_L_add, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1926 (bvadd in1_64 (_ bv1 64))))
(let ((?x701 ((_ sign_extend 1) ?x1926)))
(let (($x1185 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x701) true)))))
(and (not $x1185) (or $x1185 (and (distinct ?x1926 ?x1926) true)))))))
(check-sat)
; query 29: function gsm_L_add, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1926 (bvadd in1_64 (_ bv1 64))))
(let ((?x1658 (bvsub (_ bv0 64) ?x1926)))
(let (($x1107 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1926)) ((_ sign_extend 1) ?x1658)) true)))
(let ((?x701 ((_ sign_extend 1) ?x1926)))
(let (($x1185 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x701) true)))))
(let (($x1469 (or false $x1185 (or $x1107))))
(and (not $x1469) (or $x1469 (and (distinct ?x1658 ?x1658) true))))))))))
(check-sat)
; query 30: function gsm_L_add, block 8, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1926 (bvadd in1_64 (_ bv1 64))))
(let ((?x1658 (bvsub (_ bv0 64) ?x1926)))
(let ((?x358 (bvadd in0_64 (_ bv1 64))))
(let ((?x183 (bvsub (_ bv0 64) ?x358)))
(let ((?x376 (bvadd ?x183 ?x1658)))
(let (($x695 (and (distinct (bvadd ((_ zero_extend 1) ?x183) ((_ zero_extend 1) ?x1658)) ((_ zero_extend 1) ?x376)) true)))
(let (($x1107 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1926)) ((_ sign_extend 1) ?x1658)) true)))
(let ((?x701 ((_ sign_extend 1) ?x1926)))
(let (($x1185 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x701) true)))))
(let (($x1469 (or false $x1185 (or $x1107))))
(let (($x1956 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x358)) ((_ sign_extend 1) ?x183)) true)))
(let ((?x634 ((_ sign_extend 1) ?x358)))
(let (($x2782 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x634) true)))))
(let (($x632 (or false $x2782 (or $x1956))))
(let (($x1928 (or $x632 $x1469 (or $x695))))
(and (not (or $x632 $x1469 false)) (or $x1928 (and (distinct ?x376 ?x376) true)))))))))))))))))))
(check-sat)
; query 31: function gsm_L_add, block 8, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1926 (bvadd in1_64 (_ bv1 64))))
(let ((?x1658 (bvsub (_ bv0 64) ?x1926)))
(let ((?x358 (bvadd in0_64 (_ bv1 64))))
(let ((?x183 (bvsub (_ bv0 64) ?x358)))
(let ((?x376 (bvadd ?x183 ?x1658)))
(let ((?x1573 (ite (bvuge ?x376 (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x695 (and (distinct (bvadd ((_ zero_extend 1) ?x183) ((_ zero_extend 1) ?x1658)) ((_ zero_extend 1) ?x376)) true)))
(let (($x1107 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1926)) ((_ sign_extend 1) ?x1658)) true)))
(let ((?x701 ((_ sign_extend 1) ?x1926)))
(let (($x1185 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x701) true)))))
(let (($x1469 (or false $x1185 (or $x1107))))
(let (($x1956 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x358)) ((_ sign_extend 1) ?x183)) true)))
(let ((?x634 ((_ sign_extend 1) ?x358)))
(let (($x2782 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x634) true)))))
(let (($x632 (or false $x2782 (or $x1956))))
(let (($x1928 (or $x632 $x1469 (or $x695))))
(and (not (or (or $x632 $x1469 false) false false)) (or (or $x1928 false false) (and (distinct ?x1573 ?x1573) true))))))))))))))))))))
(check-sat)
; query 32: function gsm_L_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x358 (bvadd in0_64 (_ bv1 64))))
(let ((?x634 ((_ sign_extend 1) ?x358)))
(let (($x2782 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x634) true)))))
(and (not $x2782) (or $x2782 (and (distinct ?x358 ?x358) true)))))))
(check-sat)
; query 33: function gsm_L_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2786 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x41 (or false false false)))
(let (($x234 (not $x41)))
(and $x234 (or $x41 (and (distinct ?x2786 ?x2786) true)))))))
(check-sat)
; query 34: function gsm_L_asl, block 12, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1370 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x41 (or false false false)))
(let (($x234 (not $x41)))
(and $x234 (or $x41 (and (distinct ?x1370 ?x1370) true)))))))
(check-sat)
; query 35: function gsm_L_asl, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x689 (or false (or (= ((_ extract 31 31) in1_32) (_ bv1 1))))))
(let (($x187 (or false false)))
(let (($x1711 (not $x187)))
(and $x1711 (or $x689 (and (distinct ((_ zero_extend 32) in1_32) ((_ zero_extend 32) in1_32)) true)))))))
(check-sat)
; query 36: function gsm_L_asl, block 17, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2667 ((_ zero_extend 32) in1_32)))
(let ((?x1788 (bvshl in0_64 ?x2667)))
(let (($x1197 (bvuge ?x2667 (_ bv64 64))))
(let (($x403 (or (or false (or false (or (= ((_ extract 31 31) in1_32) (_ bv1 1)))) false) $x1197)))
(let (($x2685 (not (or (or false (or false false) false) $x1197))))
(and $x2685 (or $x403 (and (distinct ?x1788 ?x1788) true)))))))))
(check-sat)
; query 37: function gsm_L_asl, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x591 (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x41 (or false false false)))
(let (($x234 (not $x41)))
(and $x234 (or $x41 (and (distinct ?x591 ?x591) true)))))))
(check-sat)
; query 38: function gsm_L_asl, block 7, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2786 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x2459 ((_ zero_extend 31) ?x2786)))
(let ((?x889 (bvsub (_ bv0 32) ?x2459)))
(let (($x482 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x2459)) ((_ sign_extend 1) ?x889)) true)))
(let (($x41 (or false false false)))
(let (($x467 (or $x41 false)))
(let (($x886 (or false $x467 (or $x482))))
(and (not $x886) (or $x886 (and (distinct ?x889 ?x889) true)))))))))))
(check-sat)
; query 39: function gsm_L_asl, block 7, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2786 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x2459 ((_ zero_extend 31) ?x2786)))
(let ((?x889 (bvsub (_ bv0 32) ?x2459)))
(let ((?x1710 ((_ sign_extend 32) ?x889)))
(let (($x482 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x2459)) ((_ sign_extend 1) ?x889)) true)))
(let (($x41 (or false false false)))
(let (($x467 (or $x41 false)))
(let (($x886 (or false $x467 (or $x482))))
(let (($x1790 (or $x886 false)))
(and (not $x1790) (or $x1790 (and (distinct ?x1710 ?x1710) true)))))))))))))
(check-sat)
; query 40: function gsm_L_asl, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2786 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x41 (or false false false)))
(let (($x234 (not $x41)))
(and $x234 (or $x41 (and (distinct ?x2786 ?x2786) true)))))))
(check-sat)
; query 41: function gsm_L_asl, block 7, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2786 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x2459 ((_ zero_extend 31) ?x2786)))
(let (($x41 (or false false false)))
(let (($x467 (or $x41 false)))
(let (($x90 (not $x467)))
(and $x90 (or $x467 (and (distinct ?x2459 ?x2459) true)))))))))
(check-sat)
; query 42: function gsm_L_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1024 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x41 (or false false false)))
(let (($x234 (not $x41)))
(and $x234 (or $x41 (and (distinct ?x1024 ?x1024) true)))))))
(check-sat)
; query 43: function gsm_L_asr, block 12, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1370 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x41 (or false false false)))
(let (($x234 (not $x41)))
(and $x234 (or $x41 (and (distinct ?x1370 ?x1370) true)))))))
(check-sat)
; query 44: function gsm_L_asr, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x1017 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in1_32))) true)))
(let (($x2779 (or false false (or $x1017))))
(and (not $x2779) (or $x2779 (and (distinct (bvsub (_ bv0 32) in1_32) (bvsub (_ bv0 32) in1_32)) true))))))
(check-sat)
; query 45: function gsm_L_asr, block 14, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x212 (bvsub (_ bv0 32) in1_32)))
(let ((?x1510 ((_ zero_extend 32) ?x212)))
(let (($x1017 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x212)) true)))
(let (($x2779 (or false false (or $x1017))))
(let (($x2722 (or $x2779 (or (= ((_ extract 31 31) ?x212) (_ bv1 1))))))
(and (not (or $x2779 false)) (or $x2722 (and (distinct ?x1510 ?x1510) true)))))))))
(check-sat)
; query 46: function gsm_L_asr, block 14, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x212 (bvsub (_ bv0 32) in1_32)))
(let ((?x1510 ((_ zero_extend 32) ?x212)))
(let ((?x832 (bvshl in0_64 ?x1510)))
(let (($x1212 (bvuge ?x1510 (_ bv64 64))))
(let (($x1017 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x212)) true)))
(let (($x2779 (or false false (or $x1017))))
(let (($x2722 (or $x2779 (or (= ((_ extract 31 31) ?x212) (_ bv1 1))))))
(and (not (or (or false (or $x2779 false) false) $x1212)) (or (or (or false $x2722 false) $x1212) (and (distinct ?x832 ?x832) true)))))))))))
(check-sat)
; query 47: function gsm_L_asr, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x689 (or false (or (= ((_ extract 31 31) in1_32) (_ bv1 1))))))
(let (($x187 (or false false)))
(let (($x1711 (not $x187)))
(and $x1711 (or $x689 (and (distinct ((_ zero_extend 32) in1_32) ((_ zero_extend 32) in1_32)) true)))))))
(check-sat)
; query 48: function gsm_L_asr, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2667 ((_ zero_extend 32) in1_32)))
(let ((?x652 (bvashr in0_64 ?x2667)))
(let (($x1197 (bvuge ?x2667 (_ bv64 64))))
(let (($x403 (or (or false (or false (or (= ((_ extract 31 31) in1_32) (_ bv1 1)))) false) $x1197)))
(let (($x2685 (not (or (or false (or false false) false) $x1197))))
(and $x2685 (or $x403 (and (distinct ?x652 ?x652) true)))))))))
(check-sat)
; query 49: function gsm_L_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2786 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x41 (or false false false)))
(let (($x234 (not $x41)))
(and $x234 (or $x41 (and (distinct ?x2786 ?x2786) true)))))))
(check-sat)
; query 50: function gsm_L_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2786 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x2459 ((_ zero_extend 31) ?x2786)))
(let (($x41 (or false false false)))
(let (($x467 (or $x41 false)))
(let (($x90 (not $x467)))
(and $x90 (or $x467 (and (distinct ?x2459 ?x2459) true)))))))))
(check-sat)
; query 51: function gsm_L_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2786 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x2459 ((_ zero_extend 31) ?x2786)))
(let ((?x889 (bvsub (_ bv0 32) ?x2459)))
(let (($x482 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x2459)) ((_ sign_extend 1) ?x889)) true)))
(let (($x41 (or false false false)))
(let (($x467 (or $x41 false)))
(let (($x886 (or false $x467 (or $x482))))
(and (not $x886) (or $x886 (and (distinct ?x889 ?x889) true)))))))))))
(check-sat)
; query 52: function gsm_L_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2786 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x2459 ((_ zero_extend 31) ?x2786)))
(let ((?x889 (bvsub (_ bv0 32) ?x2459)))
(let ((?x1710 ((_ sign_extend 32) ?x889)))
(let (($x482 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x2459)) ((_ sign_extend 1) ?x889)) true)))
(let (($x41 (or false false false)))
(let (($x467 (or $x41 false)))
(let (($x886 (or false $x467 (or $x482))))
(let (($x1790 (or $x886 false)))
(and (not $x1790) (or $x1790 (and (distinct ?x1710 ?x1710) true)))))))))))))
(check-sat)
; query 53: function gsm_L_asr, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x591 (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x41 (or false false false)))
(let (($x234 (not $x41)))
(and $x234 (or $x41 (and (distinct ?x591 ?x591) true)))))))
(check-sat)
; query 54: function gsm_L_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1024 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x41 (or false false false)))
(let (($x234 (not $x41)))
(and $x234 (or $x41 (and (distinct ?x1024 ?x1024) true)))))))
(check-sat)
; query 55: function gsm_L_mult, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x187 (or false false)))
(let (($x1711 (not $x187)))
(and $x1711 (or $x187 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 56: function gsm_L_mult, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x2660 (ite (and (distinct (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) true) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false)))
(let (($x49 (or $x187 false false)))
(let (($x43 (not $x49)))
(and $x43 (or $x49 (and (distinct ?x2660 ?x2660) true))))))))
(check-sat)
; query 57: function gsm_L_mult, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x187 (or false false)))
(let (($x1711 (not $x187)))
(and $x1711 (or $x187 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 58: function gsm_L_mult, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1960 (ite (and (distinct (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) true) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false)))
(let (($x49 (or $x187 false false)))
(let (($x43 (not $x49)))
(and $x43 (or $x49 (and (distinct ?x1960 ?x1960) true))))))))
(check-sat)
; query 59: function gsm_L_sub, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in11_64 () (_ BitVec 64))
(assert
 (let (($x1322 (and (distinct (bvadd ((_ zero_extend 1) in11_64) ((_ zero_extend 1) (_ bv1 64))) ((_ zero_extend 1) (bvadd in11_64 (_ bv1 64)))) true)))
(let (($x2487 (and (distinct (bvadd ((_ sign_extend 1) in11_64) ((_ sign_extend 1) (_ bv1 64))) ((_ sign_extend 1) (bvadd in11_64 (_ bv1 64)))) true)))
(let (($x714 (or (or false false (or $x2487 $x1322)) (and (distinct (bvadd in11_64 (_ bv1 64)) (bvadd in11_64 (_ bv1 64))) true))))
(let (($x41 (or false false false)))
(let (($x234 (not $x41)))
(and $x234 $x714)))))))
(check-sat)
; query 60: function gsm_L_sub, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x180 (ite (bvsge (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x41 (or false false false)))
(let (($x234 (not $x41)))
(and $x234 (or $x41 (and (distinct ?x180 ?x180) true)))))))
(check-sat)
; query 61: function gsm_L_sub, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x466 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvsub in0_64 in1_64))) true)))
(let (($x6918 (or false false (or $x466))))
(let (($x2729 (or $x6918 (and (distinct (bvsub in0_64 in1_64) (bvsub in0_64 in1_64)) true))))
(and (not $x6918) $x2729)))))
(check-sat)
; query 62: function gsm_L_sub, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x358 (bvadd in0_64 (_ bv1 64))))
(let ((?x634 ((_ sign_extend 1) ?x358)))
(let (($x2782 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x634) true)))))
(and (not $x2782) (or $x2782 (and (distinct ?x358 ?x358) true)))))))
(check-sat)
; query 63: function gsm_L_sub, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x358 (bvadd in0_64 (_ bv1 64))))
(let ((?x183 (bvsub (_ bv0 64) ?x358)))
(let (($x1956 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x358)) ((_ sign_extend 1) ?x183)) true)))
(let ((?x634 ((_ sign_extend 1) ?x358)))
(let (($x2782 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x634) true)))))
(let (($x632 (or false $x2782 (or $x1956))))
(and (not $x632) (or $x632 (and (distinct ?x183 ?x183) true))))))))))
(check-sat)
; query 64: function gsm_L_sub, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x358 (bvadd in0_64 (_ bv1 64))))
(let ((?x183 (bvsub (_ bv0 64) ?x358)))
(let ((?x2633 (bvadd ?x183 in1_64)))
(let (($x2084 (and (distinct (bvadd ((_ zero_extend 1) ?x183) ((_ zero_extend 1) in1_64)) ((_ zero_extend 1) ?x2633)) true)))
(let (($x1956 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x358)) ((_ sign_extend 1) ?x183)) true)))
(let ((?x634 ((_ sign_extend 1) ?x358)))
(let (($x2782 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x634) true)))))
(let (($x632 (or false $x2782 (or $x1956))))
(let (($x1832 (or $x632 false (or $x2084))))
(and (not (or $x632 false false)) (or $x1832 (and (distinct ?x2633 ?x2633) true)))))))))))))
(check-sat)
; query 65: function gsm_L_sub, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2662 (ite (bvuge (bvadd (bvsub (_ bv0 64) (bvadd in0_64 (_ bv1 64))) in1_64) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let ((?x148 ((_ zero_extend 1) in1_64)))
(let ((?x358 (bvadd in0_64 (_ bv1 64))))
(let ((?x183 (bvsub (_ bv0 64) ?x358)))
(let ((?x1283 ((_ zero_extend 1) ?x183)))
(let (($x1956 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x358)) ((_ sign_extend 1) ?x183)) true)))
(let ((?x634 ((_ sign_extend 1) ?x358)))
(let (($x2782 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x634) true)))))
(let (($x632 (or false $x2782 (or $x1956))))
(let (($x1832 (or $x632 false (or (and (distinct (bvadd ?x1283 ?x148) ((_ zero_extend 1) (bvadd ?x183 in1_64))) true)))))
(and (not (or (or $x632 false false) false false)) (or (or $x1832 false false) (and (distinct ?x2662 ?x2662) true))))))))))))))
(check-sat)
; query 66: function gsm_L_sub, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_64 () (_ BitVec 64))
(assert
 (let ((?x5312 (bvsub (_ bv0 64) in25_64)))
(let ((?x1344 ((_ sign_extend 1) ?x5312)))
(let (($x4408 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in25_64)) ?x1344) true)))))
(and (not $x4408) (or $x4408 (and (distinct ?x5312 ?x5312) true)))))))
(check-sat)
; query 67: function gsm_L_sub, block 28, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_64 () (_ BitVec 64))
(assert
 (let ((?x5312 (bvsub (_ bv0 64) in25_64)))
(let ((?x1791 (bvsub ?x5312 (_ bv1 64))))
(let (($x2094 (and (distinct (bvsub ((_ zero_extend 1) ?x5312) ((_ zero_extend 1) (_ bv1 64))) ((_ zero_extend 1) ?x1791)) true)))
(let (($x3791 (and (distinct (bvsub ((_ sign_extend 1) ?x5312) ((_ sign_extend 1) (_ bv1 64))) ((_ sign_extend 1) ?x1791)) true)))
(let ((?x1344 ((_ sign_extend 1) ?x5312)))
(let (($x4408 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in25_64)) ?x1344) true)))))
(and (not (or $x4408 false (or $x3791))) (or (or $x4408 false (or $x3791 $x2094)) (and (distinct ?x1791 ?x1791) true))))))))))
(check-sat)
; query 68: function gsm_L_sub, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x157 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x41 (or false false false)))
(let (($x234 (not $x41)))
(and $x234 (or $x41 (and (distinct ?x157 ?x157) true)))))))
(check-sat)
; query 69: function gsm_L_sub, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x466 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvsub in0_64 in1_64))) true)))
(let (($x6918 (or false false (or $x466))))
(let (($x2729 (or $x6918 (and (distinct (bvsub in0_64 in1_64) (bvsub in0_64 in1_64)) true))))
(and (not $x6918) $x2729)))))
(check-sat)
; query 70: function gsm_L_sub, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1926 (bvadd in1_64 (_ bv1 64))))
(let ((?x1658 (bvsub (_ bv0 64) ?x1926)))
(let (($x1107 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1926)) ((_ sign_extend 1) ?x1658)) true)))
(let ((?x701 ((_ sign_extend 1) ?x1926)))
(let (($x1185 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x701) true)))))
(let (($x1469 (or false $x1185 (or $x1107))))
(and (not $x1469) (or $x1469 (and (distinct ?x1658 ?x1658) true))))))))))
(check-sat)
; query 71: function gsm_L_sub, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1926 (bvadd in1_64 (_ bv1 64))))
(let ((?x1658 (bvsub (_ bv0 64) ?x1926)))
(let ((?x7229 (bvadd in0_64 ?x1658)))
(let (($x1200 (and (distinct (bvadd ((_ zero_extend 1) in0_64) ((_ zero_extend 1) ?x1658)) ((_ zero_extend 1) ?x7229)) true)))
(let (($x1107 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1926)) ((_ sign_extend 1) ?x1658)) true)))
(let ((?x701 ((_ sign_extend 1) ?x1926)))
(let (($x1185 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x701) true)))))
(let (($x1469 (or false $x1185 (or $x1107))))
(let (($x1743 (or false $x1469 (or $x1200))))
(and (not (or false $x1469 false)) (or $x1743 (and (distinct ?x7229 ?x7229) true)))))))))))))
(check-sat)
; query 72: function gsm_L_sub, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x6113 (ite (bvuge (bvadd in0_64 (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64)))) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let ((?x1926 (bvadd in1_64 (_ bv1 64))))
(let ((?x1658 (bvsub (_ bv0 64) ?x1926)))
(let ((?x1938 ((_ zero_extend 1) ?x1658)))
(let ((?x93 ((_ zero_extend 1) in0_64)))
(let (($x1107 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1926)) ((_ sign_extend 1) ?x1658)) true)))
(let ((?x701 ((_ sign_extend 1) ?x1926)))
(let (($x1185 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x701) true)))))
(let (($x1469 (or false $x1185 (or $x1107))))
(let (($x1743 (or false $x1469 (or (and (distinct (bvadd ?x93 ?x1938) ((_ zero_extend 1) (bvadd in0_64 ?x1658))) true)))))
(and (not (or (or false $x1469 false) false false)) (or (or $x1743 false false) (and (distinct ?x6113 ?x6113) true))))))))))))))
(check-sat)
; query 73: function gsm_L_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1926 (bvadd in1_64 (_ bv1 64))))
(let ((?x701 ((_ sign_extend 1) ?x1926)))
(let (($x1185 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x701) true)))))
(and (not $x1185) (or $x1185 (and (distinct ?x1926 ?x1926) true)))))))
(check-sat)
; query 74: function gsm_L_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x4016 (ite (bvsle (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x41 (or false false false)))
(let (($x234 (not $x41)))
(and $x234 (or $x41 (and (distinct ?x4016 ?x4016) true)))))))
(check-sat)
; query 75: function gsm_abs, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x187 (or false false)))
(let (($x1711 (not $x187)))
(and $x1711 (or $x187 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 76: function gsm_abs, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1803 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false)))
(let (($x49 (or $x187 false false)))
(let (($x43 (not $x49)))
(and $x43 (or $x49 (and (distinct ?x1803 ?x1803) true))))))))
(check-sat)
; query 77: function gsm_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_64 () (_ BitVec 64))
(assert
 (let ((?x2473 (ite (bvslt (_ bv32767 64) in5_64) (_ bv1 1) (_ bv0 1))))
(let (($x41 (or false false false)))
(let (($x234 (not $x41)))
(and $x234 (or $x41 (and (distinct ?x2473 ?x2473) true)))))))
(check-sat)
; query 78: function gsm_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x187 (or false false)))
(let (($x1711 (not $x187)))
(and $x1711 (or $x187 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 79: function gsm_add, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x187 (or false false)))
(let (($x1711 (not $x187)))
(and $x1711 (or $x187 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 80: function gsm_add, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x3724 ((_ sign_extend 48) in1_16)))
(let ((?x3136 ((_ sign_extend 48) in0_16)))
(let ((?x4892 (bvadd ?x3136 ?x3724)))
(let (($x2924 (and (distinct (bvadd ((_ sign_extend 1) ?x3136) ((_ sign_extend 1) ?x3724)) ((_ sign_extend 1) ?x4892)) true)))
(let (($x187 (or false false)))
(let (($x3168 (or $x187 $x187 (or $x2924))))
(and (not $x3168) (or $x3168 (and (distinct ?x4892 ?x4892) true))))))))))
(check-sat)
; query 81: function gsm_add, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x5783 (ite (bvsgt (_ bv18446744073709518848 64) (bvadd ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x3724 ((_ sign_extend 48) in1_16)))
(let ((?x677 ((_ sign_extend 1) ?x3724)))
(let ((?x3136 ((_ sign_extend 48) in0_16)))
(let ((?x1516 ((_ sign_extend 1) ?x3136)))
(let (($x187 (or false false)))
(let (($x3168 (or $x187 $x187 (or (and (distinct (bvadd ?x1516 ?x677) ((_ sign_extend 1) (bvadd ?x3136 ?x3724))) true)))))
(let (($x1051 (or $x3168 false false)))
(and (not $x1051) (or $x1051 (and (distinct ?x5783 ?x5783) true))))))))))))
(check-sat)
; query 82: function gsm_asl, block 13, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1370 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x41 (or false false false)))
(let (($x234 (not $x41)))
(and $x234 (or $x41 (and (distinct ?x1370 ?x1370) true)))))))
(check-sat)
; query 83: function gsm_asl, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x187 (or false false)))
(let (($x1711 (not $x187)))
(and $x1711 (or $x187 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 84: function gsm_asl, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x88 ((_ sign_extend 16) in0_16)))
(let ((?x2806 (bvshl ?x88 in1_32)))
(let (($x2581 (bvuge in1_32 (_ bv32 32))))
(let (($x187 (or false false)))
(let (($x1307 (or (or $x187 false (or (and (distinct (bvashr ?x2806 in1_32) ?x88) true))) $x2581)))
(let (($x49 (or $x187 false false)))
(let (($x2691 (or $x49 $x2581)))
(let (($x2744 (not $x2691)))
(and $x2744 (or $x1307 (and (distinct ?x2806 ?x2806) true))))))))))))
(check-sat)
; query 85: function gsm_asl, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x88 ((_ sign_extend 16) in0_16)))
(let ((?x2806 (bvshl ?x88 in1_32)))
(let ((?x858 ((_ extract 15 0) ?x2806)))
(let (($x2581 (bvuge in1_32 (_ bv32 32))))
(let (($x187 (or false false)))
(let (($x1307 (or (or $x187 false (or (and (distinct (bvashr ?x2806 in1_32) ?x88) true))) $x2581)))
(let (($x978 (not (or (or (or $x187 false false) $x2581) false))))
(and $x978 (or (or $x1307 false) (and (distinct ?x858 ?x858) true)))))))))))
(check-sat)
; query 86: function gsm_asl, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x304 (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x41 (or false false false)))
(let (($x234 (not $x41)))
(and $x234 (or $x41 (and (distinct ?x304 ?x304) true)))))))
(check-sat)
; query 87: function gsm_asl, block 7, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1803 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1816 ((_ zero_extend 31) ?x1803)))
(let (($x187 (or false false)))
(let (($x49 (or $x187 false false)))
(let (($x1414 (or $x49 false)))
(and (not $x1414) (or $x1414 (and (distinct ?x1816 ?x1816) true)))))))))
(check-sat)
; query 88: function gsm_asl, block 7, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1803 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1816 ((_ zero_extend 31) ?x1803)))
(let ((?x437 (bvsub (_ bv0 32) ?x1816)))
(let (($x7066 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1816)) ((_ sign_extend 1) ?x437)) true)))
(let (($x187 (or false false)))
(let (($x49 (or $x187 false false)))
(let (($x1414 (or $x49 false)))
(let (($x959 (or false $x1414 (or $x7066))))
(and (not $x959) (or $x959 (and (distinct ?x437 ?x437) true))))))))))))
(check-sat)
; query 89: function gsm_asl, block 7, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1803 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1816 ((_ zero_extend 31) ?x1803)))
(let ((?x437 (bvsub (_ bv0 32) ?x1816)))
(let ((?x1268 ((_ extract 15 0) ?x437)))
(let (($x7066 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1816)) ((_ sign_extend 1) ?x437)) true)))
(let (($x187 (or false false)))
(let (($x49 (or $x187 false false)))
(let (($x1414 (or $x49 false)))
(let (($x959 (or false $x1414 (or $x7066))))
(let (($x478 (or (or $x959 (or (and (distinct ((_ sign_extend 16) ?x1268) ?x437) true))) (and (distinct ?x1268 ?x1268) true))))
(and (not (or $x959 false)) $x478))))))))))))
(check-sat)
; query 90: function gsm_asl, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x187 (or false false)))
(let (($x1711 (not $x187)))
(and $x1711 (or $x187 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 91: function gsm_asl, block 7, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1803 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false)))
(let (($x49 (or $x187 false false)))
(let (($x43 (not $x49)))
(and $x43 (or $x49 (and (distinct ?x1803 ?x1803) true))))))))
(check-sat)
; query 92: function gsm_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x3626 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x41 (or false false false)))
(let (($x234 (not $x41)))
(and $x234 (or $x41 (and (distinct ?x3626 ?x3626) true)))))))
(check-sat)
; query 93: function gsm_asr, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x304 (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x41 (or false false false)))
(let (($x234 (not $x41)))
(and $x234 (or $x41 (and (distinct ?x304 ?x304) true)))))))
(check-sat)
; query 94: function gsm_asr, block 13, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1370 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x41 (or false false false)))
(let (($x234 (not $x41)))
(and $x234 (or $x41 (and (distinct ?x1370 ?x1370) true)))))))
(check-sat)
; query 95: function gsm_asr, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x187 (or false false)))
(let (($x1711 (not $x187)))
(and $x1711 (or $x187 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 96: function gsm_asr, block 15, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x1017 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in1_32))) true)))
(let (($x2779 (or false false (or $x1017))))
(and (not $x2779) (or $x2779 (and (distinct (bvsub (_ bv0 32) in1_32) (bvsub (_ bv0 32) in1_32)) true))))))
(check-sat)
; query 97: function gsm_asr, block 15, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x212 (bvsub (_ bv0 32) in1_32)))
(let ((?x88 ((_ sign_extend 16) in0_16)))
(let ((?x3187 (bvshl ?x88 ?x212)))
(let (($x570 (bvuge ?x212 (_ bv32 32))))
(let (($x1017 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x212)) true)))
(let (($x2779 (or false false (or $x1017))))
(let (($x187 (or false false)))
(let (($x1751 (or (or $x187 $x2779 (or (and (distinct (bvashr ?x3187 ?x212) ?x88) true))) $x570)))
(and (not (or (or $x187 $x2779 false) $x570)) (or $x1751 (and (distinct ?x3187 ?x3187) true))))))))))))
(check-sat)
; query 98: function gsm_asr, block 15, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x212 (bvsub (_ bv0 32) in1_32)))
(let ((?x88 ((_ sign_extend 16) in0_16)))
(let ((?x3187 (bvshl ?x88 ?x212)))
(let ((?x535 ((_ extract 15 0) ?x3187)))
(let (($x570 (bvuge ?x212 (_ bv32 32))))
(let (($x1017 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x212)) true)))
(let (($x2779 (or false false (or $x1017))))
(let (($x187 (or false false)))
(let (($x1751 (or (or $x187 $x2779 (or (and (distinct (bvashr ?x3187 ?x212) ?x88) true))) $x570)))
(and (not (or (or (or $x187 $x2779 false) $x570) false)) (or (or $x1751 false) (and (distinct ?x535 ?x535) true)))))))))))))
(check-sat)
; query 99: function gsm_asr, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x187 (or false false)))
(let (($x1711 (not $x187)))
(and $x1711 (or $x187 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 100: function gsm_asr, block 20, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x88 ((_ sign_extend 16) in0_16)))
(let ((?x549 (bvashr ?x88 in1_32)))
(let (($x2581 (bvuge in1_32 (_ bv32 32))))
(let (($x187 (or false false)))
(let (($x49 (or $x187 false false)))
(let (($x2691 (or $x49 $x2581)))
(let (($x2744 (not $x2691)))
(and $x2744 (or $x2691 (and (distinct ?x549 ?x549) true)))))))))))
(check-sat)
; query 101: function gsm_asr, block 20, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x88 ((_ sign_extend 16) in0_16)))
(let ((?x549 (bvashr ?x88 in1_32)))
(let ((?x2133 ((_ extract 15 0) ?x549)))
(let (($x2581 (bvuge in1_32 (_ bv32 32))))
(let (($x187 (or false false)))
(let (($x49 (or $x187 false false)))
(let (($x2691 (or $x49 $x2581)))
(let (($x605 (or (or $x2691 (or (and (distinct ((_ sign_extend 16) ?x2133) ?x549) true))) (and (distinct ?x2133 ?x2133) true))))
(let (($x978 (not (or $x2691 false))))
(and $x978 $x605)))))))))))
(check-sat)
; query 102: function gsm_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x187 (or false false)))
(let (($x1711 (not $x187)))
(and $x1711 (or $x187 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 103: function gsm_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1803 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false)))
(let (($x49 (or $x187 false false)))
(let (($x43 (not $x49)))
(and $x43 (or $x49 (and (distinct ?x1803 ?x1803) true))))))))
(check-sat)
; query 104: function gsm_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1803 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1816 ((_ zero_extend 31) ?x1803)))
(let (($x187 (or false false)))
(let (($x49 (or $x187 false false)))
(let (($x1414 (or $x49 false)))
(and (not $x1414) (or $x1414 (and (distinct ?x1816 ?x1816) true)))))))))
(check-sat)
; query 105: function gsm_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1803 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1816 ((_ zero_extend 31) ?x1803)))
(let ((?x437 (bvsub (_ bv0 32) ?x1816)))
(let (($x7066 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1816)) ((_ sign_extend 1) ?x437)) true)))
(let (($x187 (or false false)))
(let (($x49 (or $x187 false false)))
(let (($x1414 (or $x49 false)))
(let (($x959 (or false $x1414 (or $x7066))))
(and (not $x959) (or $x959 (and (distinct ?x437 ?x437) true))))))))))))
(check-sat)
; query 106: function gsm_asr, block 4, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1803 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1816 ((_ zero_extend 31) ?x1803)))
(let ((?x437 (bvsub (_ bv0 32) ?x1816)))
(let ((?x1268 ((_ extract 15 0) ?x437)))
(let (($x7066 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1816)) ((_ sign_extend 1) ?x437)) true)))
(let (($x187 (or false false)))
(let (($x49 (or $x187 false false)))
(let (($x1414 (or $x49 false)))
(let (($x959 (or false $x1414 (or $x7066))))
(let (($x478 (or (or $x959 (or (and (distinct ((_ sign_extend 16) ?x1268) ?x437) true))) (and (distinct ?x1268 ?x1268) true))))
(and (not (or $x959 false)) $x478))))))))))))
(check-sat)
; query 107: function gsm_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x3626 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x41 (or false false false)))
(let (($x234 (not $x41)))
(and $x234 (or $x41 (and (distinct ?x3626 ?x3626) true)))))))
(check-sat)
; query 108: function gsm_debug_longwords, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in15_32 () (_ BitVec 32))
(assert
 (let ((?x2261 (ite (bvslt in15_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x41 (or false false false)))
(let (($x234 (not $x41)))
(and $x234 (or $x41 (and (distinct ?x2261 ?x2261) true)))))))
(check-sat)
; query 109: function gsm_debug_words, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in16_32 () (_ BitVec 32))
(assert
 (let ((?x441 (ite (bvslt in16_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x41 (or false false false)))
(let (($x234 (not $x41)))
(and $x234 (or $x41 (and (distinct ?x441 ?x441) true)))))))
(check-sat)
; query 110: function gsm_div, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x187 (or false false)))
(let (($x1711 (not $x187)))
(and $x1711 (or $x187 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 111: function gsm_div, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x187 (or false false)))
(let (($x1711 (not $x187)))
(and $x1711 (or $x187 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 112: function gsm_div, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x187 (or false false)))
(let (($x1711 (not $x187)))
(and $x1711 (or $x187 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 113: function gsm_div, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x81 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x220 (and (distinct ?x81 ?x81) true)))
(let (($x187 (or false false)))
(let (($x49 (or $x187 false false)))
(let (($x43 (not $x49)))
(and $x43 (or $x49 $x220))))))))
(check-sat)
; query 114: function gsm_mult, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x187 (or false false)))
(let (($x1711 (not $x187)))
(and $x1711 (or $x187 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 115: function gsm_mult, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x794 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false)))
(let (($x49 (or $x187 false false)))
(let (($x43 (not $x49)))
(and $x43 (or $x49 (and (distinct ?x794 ?x794) true))))))))
(check-sat)
; query 116: function gsm_mult, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x187 (or false false)))
(let (($x1711 (not $x187)))
(and $x1711 (or $x187 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 117: function gsm_mult, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x187 (or false false)))
(let (($x1711 (not $x187)))
(and $x1711 (or $x187 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 118: function gsm_mult, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x3724 ((_ sign_extend 48) in1_16)))
(let ((?x3136 ((_ sign_extend 48) in0_16)))
(let ((?x1343 (bvmul ?x3136 ?x3724)))
(let (($x1570 (and (distinct (bvmul ((_ sign_extend 64) ?x3136) ((_ sign_extend 64) ?x3724)) ((_ sign_extend 64) ?x1343)) true)))
(let (($x187 (or false false)))
(let (($x1670 (or $x187 $x187 (or $x1570))))
(and (not $x1670) (or $x1670 (and (distinct ?x1343 ?x1343) true))))))))))
(check-sat)
; query 119: function gsm_mult, block 9, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x3724 ((_ sign_extend 48) in1_16)))
(let ((?x3136 ((_ sign_extend 48) in0_16)))
(let ((?x1343 (bvmul ?x3136 ?x3724)))
(let ((?x2637 (bvashr ?x1343 (_ bv15 64))))
(let (($x2073 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1570 (and (distinct (bvmul ((_ sign_extend 64) ?x3136) ((_ sign_extend 64) ?x3724)) ((_ sign_extend 64) ?x1343)) true)))
(let (($x187 (or false false)))
(let (($x1670 (or $x187 $x187 (or $x1570))))
(let (($x2543 (or (or $x1670 false false) $x2073)))
(and (not $x2543) (or $x2543 (and (distinct ?x2637 ?x2637) true)))))))))))))
(check-sat)
; query 120: function gsm_mult, block 9, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x3724 ((_ sign_extend 48) in1_16)))
(let ((?x3136 ((_ sign_extend 48) in0_16)))
(let ((?x1343 (bvmul ?x3136 ?x3724)))
(let ((?x2637 (bvashr ?x1343 (_ bv15 64))))
(let ((?x2650 ((_ extract 15 0) ?x2637)))
(let (($x2073 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1570 (and (distinct (bvmul ((_ sign_extend 64) ?x3136) ((_ sign_extend 64) ?x3724)) ((_ sign_extend 64) ?x1343)) true)))
(let (($x187 (or false false)))
(let (($x1670 (or $x187 $x187 (or $x1570))))
(let (($x2543 (or (or $x1670 false false) $x2073)))
(let (($x248 (or $x2543 false)))
(and (not $x248) (or $x248 (and (distinct ?x2650 ?x2650) true)))))))))))))))
(check-sat)
; query 121: function gsm_mult, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x187 (or false false)))
(let (($x1711 (not $x187)))
(and $x1711 (or $x187 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 122: function gsm_mult, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1027 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false)))
(let (($x49 (or $x187 false false)))
(let (($x43 (not $x49)))
(and $x43 (or $x49 (and (distinct ?x1027 ?x1027) true))))))))
(check-sat)
; query 123: function gsm_mult_r, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x187 (or false false)))
(let (($x1711 (not $x187)))
(and $x1711 (or $x187 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 124: function gsm_mult_r, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1027 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false)))
(let (($x49 (or $x187 false false)))
(let (($x43 (not $x49)))
(and $x43 (or $x49 (and (distinct ?x1027 ?x1027) true))))))))
(check-sat)
; query 125: function gsm_mult_r, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x187 (or false false)))
(let (($x1711 (not $x187)))
(and $x1711 (or $x187 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 126: function gsm_mult_r, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x187 (or false false)))
(let (($x1711 (not $x187)))
(and $x1711 (or $x187 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 127: function gsm_mult_r, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x3724 ((_ sign_extend 48) in1_16)))
(let ((?x3136 ((_ sign_extend 48) in0_16)))
(let ((?x1343 (bvmul ?x3136 ?x3724)))
(let (($x1570 (and (distinct (bvmul ((_ sign_extend 64) ?x3136) ((_ sign_extend 64) ?x3724)) ((_ sign_extend 64) ?x1343)) true)))
(let (($x187 (or false false)))
(let (($x1670 (or $x187 $x187 (or $x1570))))
(and (not $x1670) (or $x1670 (and (distinct ?x1343 ?x1343) true))))))))))
(check-sat)
; query 128: function gsm_mult_r, block 9, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x3724 ((_ sign_extend 48) in1_16)))
(let ((?x3136 ((_ sign_extend 48) in0_16)))
(let ((?x1343 (bvmul ?x3136 ?x3724)))
(let ((?x750 (bvadd ?x1343 (_ bv16384 64))))
(let (($x5621 (and (distinct (bvadd ((_ sign_extend 1) ?x1343) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x750)) true)))
(let (($x1570 (and (distinct (bvmul ((_ sign_extend 64) ?x3136) ((_ sign_extend 64) ?x3724)) ((_ sign_extend 64) ?x1343)) true)))
(let (($x187 (or false false)))
(let (($x1670 (or $x187 $x187 (or $x1570))))
(let (($x4726 (or $x1670 false (or $x5621))))
(and (not $x4726) (or $x4726 (and (distinct ?x750 ?x750) true)))))))))))))
(check-sat)
; query 129: function gsm_mult_r, block 9, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x3724 ((_ sign_extend 48) in1_16)))
(let ((?x3136 ((_ sign_extend 48) in0_16)))
(let ((?x1343 (bvmul ?x3136 ?x3724)))
(let ((?x750 (bvadd ?x1343 (_ bv16384 64))))
(let ((?x5198 (bvashr ?x750 (_ bv15 64))))
(let (($x2073 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x5621 (and (distinct (bvadd ((_ sign_extend 1) ?x1343) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x750)) true)))
(let (($x1570 (and (distinct (bvmul ((_ sign_extend 64) ?x3136) ((_ sign_extend 64) ?x3724)) ((_ sign_extend 64) ?x1343)) true)))
(let (($x187 (or false false)))
(let (($x1670 (or $x187 $x187 (or $x1570))))
(let (($x4726 (or $x1670 false (or $x5621))))
(let (($x4894 (or (or $x4726 false false) $x2073)))
(and (not $x4894) (or $x4894 (and (distinct ?x5198 ?x5198) true))))))))))))))))
(check-sat)
; query 130: function gsm_mult_r, block 9, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x3724 ((_ sign_extend 48) in1_16)))
(let ((?x3136 ((_ sign_extend 48) in0_16)))
(let ((?x1343 (bvmul ?x3136 ?x3724)))
(let ((?x750 (bvadd ?x1343 (_ bv16384 64))))
(let ((?x5198 (bvashr ?x750 (_ bv15 64))))
(let ((?x2762 (bvand ?x5198 (_ bv65535 64))))
(let (($x2073 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x5621 (and (distinct (bvadd ((_ sign_extend 1) ?x1343) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x750)) true)))
(let (($x1570 (and (distinct (bvmul ((_ sign_extend 64) ?x3136) ((_ sign_extend 64) ?x3724)) ((_ sign_extend 64) ?x1343)) true)))
(let (($x187 (or false false)))
(let (($x1670 (or $x187 $x187 (or $x1570))))
(let (($x4726 (or $x1670 false (or $x5621))))
(let (($x4894 (or (or $x4726 false false) $x2073)))
(let (($x5790 (or $x4894 false false)))
(and (not $x5790) (or $x5790 (and (distinct ?x2762 ?x2762) true))))))))))))))))))
(check-sat)
; query 131: function gsm_mult_r, block 9, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x3724 ((_ sign_extend 48) in1_16)))
(let ((?x3136 ((_ sign_extend 48) in0_16)))
(let ((?x1343 (bvmul ?x3136 ?x3724)))
(let ((?x750 (bvadd ?x1343 (_ bv16384 64))))
(let ((?x5198 (bvashr ?x750 (_ bv15 64))))
(let ((?x2762 (bvand ?x5198 (_ bv65535 64))))
(let ((?x1889 ((_ extract 15 0) ?x2762)))
(let (($x2073 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x5621 (and (distinct (bvadd ((_ sign_extend 1) ?x1343) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x750)) true)))
(let (($x1570 (and (distinct (bvmul ((_ sign_extend 64) ?x3136) ((_ sign_extend 64) ?x3724)) ((_ sign_extend 64) ?x1343)) true)))
(let (($x187 (or false false)))
(let (($x1670 (or $x187 $x187 (or $x1570))))
(let (($x4726 (or $x1670 false (or $x5621))))
(let (($x4894 (or (or $x4726 false false) $x2073)))
(let (($x5790 (or $x4894 false false)))
(let (($x1879 (or (or $x5790 (or (and (distinct ((_ zero_extend 48) ?x1889) ?x2762) true))) (and (distinct ?x1889 ?x1889) true))))
(and (not (or $x5790 false)) $x1879))))))))))))))))))
(check-sat)
; query 132: function gsm_mult_r, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x187 (or false false)))
(let (($x1711 (not $x187)))
(and $x1711 (or $x187 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 133: function gsm_mult_r, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x794 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false)))
(let (($x49 (or $x187 false false)))
(let (($x43 (not $x49)))
(and $x43 (or $x49 (and (distinct ?x794 ?x794) true))))))))
(check-sat)
; query 134: function gsm_norm, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x5414 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x41 (or false false false)))
(let (($x234 (not $x41)))
(and $x234 (or $x41 (and (distinct ?x5414 ?x5414) true)))))))
(check-sat)
; query 135: function gsm_norm, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x5414 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x1593 (bvxor ?x5414 (_ bv1 1))))
(let (($x41 (or false false false)))
(let (($x65 (or $x41 false false)))
(let (($x1804 (not $x65)))
(and $x1804 (or $x65 (and (distinct ?x1593 ?x1593) true)))))))))
(check-sat)
; query 136: function gsm_norm, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x5414 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x1593 (bvxor ?x5414 (_ bv1 1))))
(let ((?x1068 ((_ zero_extend 31) ?x1593)))
(let (($x41 (or false false false)))
(let (($x65 (or $x41 false false)))
(let (($x3932 (or $x65 false)))
(and (not $x3932) (or $x3932 (and (distinct ?x1068 ?x1068) true))))))))))
(check-sat)
; query 137: function gsm_norm, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x5414 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x1593 (bvxor ?x5414 (_ bv1 1))))
(let ((?x1068 ((_ zero_extend 31) ?x1593)))
(let (($x41 (or false false false)))
(let (($x65 (or $x41 false false)))
(let (($x3932 (or $x65 false)))
(let (($x5761 (or (or $x3932 (or (= ((_ extract 31 31) ?x1068) (_ bv1 1)))) (and (distinct ((_ sign_extend 32) ?x1068) ((_ zero_extend 32) ?x1068)) true))))
(and (not (or $x3932 false)) $x5761)))))))))
(check-sat)
; query 138: function gsm_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_64 () (_ BitVec 64))
(assert
 (let ((?x2473 (ite (bvslt (_ bv32767 64) in5_64) (_ bv1 1) (_ bv0 1))))
(let (($x41 (or false false false)))
(let (($x234 (not $x41)))
(and $x234 (or $x41 (and (distinct ?x2473 ?x2473) true)))))))
(check-sat)
; query 139: function gsm_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x187 (or false false)))
(let (($x1711 (not $x187)))
(and $x1711 (or $x187 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 140: function gsm_sub, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x187 (or false false)))
(let (($x1711 (not $x187)))
(and $x1711 (or $x187 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 141: function gsm_sub, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x3724 ((_ sign_extend 48) in1_16)))
(let ((?x3136 ((_ sign_extend 48) in0_16)))
(let ((?x2874 (bvsub ?x3136 ?x3724)))
(let (($x1141 (and (distinct (bvsub ((_ sign_extend 1) ?x3136) ((_ sign_extend 1) ?x3724)) ((_ sign_extend 1) ?x2874)) true)))
(let (($x187 (or false false)))
(let (($x1047 (or $x187 $x187 (or $x1141))))
(and (not $x1047) (or $x1047 (and (distinct ?x2874 ?x2874) true))))))))))
(check-sat)
; query 142: function gsm_sub, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x296 (ite (bvsgt (_ bv18446744073709518848 64) (bvsub ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x3724 ((_ sign_extend 48) in1_16)))
(let ((?x677 ((_ sign_extend 1) ?x3724)))
(let ((?x3136 ((_ sign_extend 48) in0_16)))
(let ((?x1516 ((_ sign_extend 1) ?x3136)))
(let (($x187 (or false false)))
(let (($x1047 (or $x187 $x187 (or (and (distinct (bvsub ?x1516 ?x677) ((_ sign_extend 1) (bvsub ?x3136 ?x3724))) true)))))
(let (($x3423 (or $x1047 false false)))
(and (not $x3423) (or $x3423 (and (distinct ?x296 ?x296) true))))))))))))
(check-sat)
; query 143: function ok_to_replace, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1566 (ite (and (distinct (_ bv4294967295 32) in.01_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x41 (or false false false)))
(let (($x234 (not $x41)))
(and $x234 (or $x41 (and (distinct ?x1566 ?x1566) true)))))))
(check-sat)
; query 144: function suffix, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_64 () (_ BitVec 64))
(declare-fun in3_64 () (_ BitVec 64))
(assert
 (let ((?x2716 (ite (bvule in3_64 in4_64) (_ bv1 1) (_ bv0 1))))
(let (($x41 (or false false false)))
(let (($x234 (not $x41)))
(and $x234 (or $x41 (and (distinct ?x2716 ?x2716) true)))))))
(check-sat)
