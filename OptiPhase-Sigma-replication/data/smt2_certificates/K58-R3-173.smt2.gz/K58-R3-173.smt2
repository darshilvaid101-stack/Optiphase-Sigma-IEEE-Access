; OptiPhase-Sigma refinement certificate for sweep K58-R3-173
; query 0: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x269 (or false false)))
(let (($x61 (not $x269)))
(and $x61 (or $x269 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 1: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x723 ((_ sign_extend 16) in3_16)))
(let ((?x16 (bvand ?x723 (_ bv127 32))))
(let (($x269 (or false false)))
(let (($x526 (or $x269 false false)))
(let (($x867 (not $x526)))
(and $x867 (or $x526 (and (distinct ?x16 ?x16) true)))))))))
(check-sat)
; query 2: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x723 ((_ sign_extend 16) in3_16)))
(let ((?x16 (bvand ?x723 (_ bv127 32))))
(let ((?x119 ((_ extract 15 0) ?x16)))
(let (($x269 (or false false)))
(let (($x526 (or $x269 false false)))
(let (($x535 (or $x526 false)))
(let (($x426 (not $x535)))
(and $x426 (or $x535 (and (distinct ?x119 ?x119) true)))))))))))
(check-sat)
; query 3: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x269 (or false false)))
(let (($x61 (not $x269)))
(and $x61 (or $x269 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 4: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x45 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x269 (or false false)))
(let (($x526 (or $x269 false false)))
(let (($x867 (not $x526)))
(and $x867 (or $x526 (and (distinct ?x45 ?x45) true))))))))
(check-sat)
; query 5: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x350 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x279 (or false false false)))
(let (($x452 (not $x279)))
(and $x452 (or $x279 (and (distinct ?x350 ?x350) true)))))))
(check-sat)
; query 6: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x19 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x279 (or false false false)))
(let (($x452 (not $x279)))
(and $x452 (or $x279 (and (distinct ?x19 ?x19) true)))))))
(check-sat)
; query 7: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x279 (or false false false)))
(let (($x452 (not $x279)))
(and $x452 (or $x279 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 8: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x88 (and (distinct (bvadd ((_ zero_extend 1) in.021_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x524 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x143 (or (or false false (or $x524 $x88)) (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))
(and (not (or false false (or $x524))) $x143)))))
(check-sat)
; query 9: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x558 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x81 ((_ zero_extend 31) ?x558)))
(let ((?x323 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1287 ((_ zero_extend 31) ?x323)))
(let ((?x547 (bvand ?x1287 ?x81)))
(let ((?x862 (ite (and (distinct (_ bv0 32) ?x547) true) (_ bv1 1) (_ bv0 1))))
(let ((?x832 ((_ zero_extend 63) ?x862)))
(let (($x269 (or false false)))
(let (($x526 (or $x269 false false)))
(let (($x535 (or $x526 false)))
(let (($x639 (or $x535 $x535 false)))
(let (($x241 (or $x639 false false)))
(let (($x102 (or $x241 false)))
(and (not $x102) (or $x102 (and (distinct ?x832 ?x832) true)))))))))))))))))
(check-sat)
; query 10: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x558 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x81 ((_ zero_extend 31) ?x558)))
(let ((?x323 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1287 ((_ zero_extend 31) ?x323)))
(let ((?x547 (bvand ?x1287 ?x81)))
(let ((?x862 (ite (and (distinct (_ bv0 32) ?x547) true) (_ bv1 1) (_ bv0 1))))
(let (($x278 (= (_ bv1 1) ?x862)))
(let ((?x126 (ite $x278 (_ bv1 32) (_ bv0 32))))
(let (($x269 (or false false)))
(let (($x526 (or $x269 false false)))
(let (($x535 (or $x526 false)))
(let (($x639 (or $x535 $x535 false)))
(let (($x241 (or $x639 false false)))
(let (($x65 (or $x241 (ite $x278 false false))))
(and (not $x65) (or $x65 (and (distinct ?x126 ?x126) true))))))))))))))))))
(check-sat)
; query 11: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x558 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x81 ((_ zero_extend 31) ?x558)))
(let ((?x323 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1287 ((_ zero_extend 31) ?x323)))
(let ((?x547 (bvand ?x1287 ?x81)))
(let ((?x862 (ite (and (distinct (_ bv0 32) ?x547) true) (_ bv1 1) (_ bv0 1))))
(let (($x278 (= (_ bv1 1) ?x862)))
(let ((?x126 (ite $x278 (_ bv1 32) (_ bv0 32))))
(let ((?x130 ((_ extract 7 0) ?x126)))
(let (($x269 (or false false)))
(let (($x526 (or $x269 false false)))
(let (($x535 (or $x526 false)))
(let (($x639 (or $x535 $x535 false)))
(let (($x241 (or $x639 false false)))
(let (($x65 (or $x241 (ite $x278 false false))))
(let (($x141 (or $x65 false)))
(and (not $x141) (or $x141 (and (distinct ?x130 ?x130) true))))))))))))))))))))
(check-sat)
; query 12: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x269 (or false false)))
(let (($x61 (not $x269)))
(and $x61 (or $x269 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 13: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x323 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x269 (or false false)))
(let (($x526 (or $x269 false false)))
(let (($x867 (not $x526)))
(and $x867 (or $x526 (and (distinct ?x323 ?x323) true))))))))
(check-sat)
; query 14: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x323 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1287 ((_ zero_extend 31) ?x323)))
(let (($x269 (or false false)))
(let (($x526 (or $x269 false false)))
(let (($x535 (or $x526 false)))
(let (($x426 (not $x535)))
(and $x426 (or $x535 (and (distinct ?x1287 ?x1287) true))))))))))
(check-sat)
; query 15: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x269 (or false false)))
(let (($x61 (not $x269)))
(and $x61 (or $x269 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 16: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x558 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x269 (or false false)))
(let (($x526 (or $x269 false false)))
(let (($x867 (not $x526)))
(and $x867 (or $x526 (and (distinct ?x558 ?x558) true))))))))
(check-sat)
; query 17: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x558 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x81 ((_ zero_extend 31) ?x558)))
(let (($x269 (or false false)))
(let (($x526 (or $x269 false false)))
(let (($x535 (or $x526 false)))
(let (($x426 (not $x535)))
(and $x426 (or $x535 (and (distinct ?x81 ?x81) true))))))))))
(check-sat)
; query 18: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x558 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x81 ((_ zero_extend 31) ?x558)))
(let ((?x323 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1287 ((_ zero_extend 31) ?x323)))
(let ((?x547 (bvand ?x1287 ?x81)))
(let (($x269 (or false false)))
(let (($x526 (or $x269 false false)))
(let (($x535 (or $x526 false)))
(let (($x639 (or $x535 $x535 false)))
(and (not $x639) (or $x639 (and (distinct ?x547 ?x547) true)))))))))))))
(check-sat)
; query 19: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x558 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x81 ((_ zero_extend 31) ?x558)))
(let ((?x323 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1287 ((_ zero_extend 31) ?x323)))
(let ((?x547 (bvand ?x1287 ?x81)))
(let ((?x862 (ite (and (distinct (_ bv0 32) ?x547) true) (_ bv1 1) (_ bv0 1))))
(let (($x269 (or false false)))
(let (($x526 (or $x269 false false)))
(let (($x535 (or $x526 false)))
(let (($x639 (or $x535 $x535 false)))
(let (($x241 (or $x639 false false)))
(and (not $x241) (or $x241 (and (distinct ?x862 ?x862) true)))))))))))))))
(check-sat)
; query 20: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x93 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x279 (or false false false)))
(let (($x452 (not $x279)))
(and $x452 (or $x279 (and (distinct ?x93 ?x93) true)))))))
(check-sat)
