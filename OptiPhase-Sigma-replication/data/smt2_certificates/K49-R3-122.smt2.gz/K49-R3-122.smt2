; OptiPhase-Sigma refinement certificate for sweep K49-R3-122
; query 0: function APCM_inverse_quantization, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x1128 (or false false)))
(let (($x935 (not $x1128)))
(and $x935 (or $x1128 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 1: function APCM_inverse_quantization, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x166 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1128 (or false false)))
(let (($x426 (or $x1128 false false)))
(let (($x365 (not $x426)))
(and $x365 (or $x426 (and (distinct ?x166 ?x166) true))))))))
(check-sat)
; query 2: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x1128 (or false false)))
(let (($x935 (not $x1128)))
(and $x935 (or $x1128 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 3: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x342 (ite (bvslt (_ bv15 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1128 (or false false)))
(let (($x426 (or $x1128 false false)))
(let (($x365 (not $x426)))
(and $x365 (or $x426 (and (distinct ?x342 ?x342) true))))))))
(check-sat)
; query 4: function Decoding_of_the_coded_Log_Area_Ratios, block 317, name %318
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in314_64 () (_ BitVec 64))
(assert
 (let (($x435 (and (distinct (ite (bvsge (_ bv18446744073709518848 64) in314_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv0 64) in314_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x313 (or false false false)))
(let (($x42 (not $x313)))
(and $x42 (or $x313 $x435))))))
(check-sat)
; query 5: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x1128 (or false false)))
(let (($x935 (not $x1128)))
(and $x935 (or $x1128 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 6: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x198 (ite (bvsgt (_ bv40 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1128 (or false false)))
(let (($x426 (or $x1128 false false)))
(let (($x365 (not $x426)))
(and $x365 (or $x426 (and (distinct ?x198 ?x198) true))))))))
(check-sat)
; query 7: function Quantization_and_coding, block 24, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_32 () (_ BitVec 32))
(declare-fun in21_64 () (_ BitVec 64))
(assert
 (let (($x1489 (and (distinct (ite (bvslt (_ bv0 64) in21_64) (_ bv1 1) (_ bv0 1)) (ite (bvsgt (_ bv4294967264 32) in21_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x313 (or false false false)))
(let (($x42 (not $x313)))
(and $x42 (or $x313 $x1489))))))
(check-sat)
; query 8: function Quantization_and_coding, block 261, name %262
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in258_32 () (_ BitVec 32))
(declare-fun in258_64 () (_ BitVec 64))
(assert
 (let (($x399 (and (distinct (ite (bvslt (_ bv0 64) in258_64) (_ bv1 1) (_ bv0 1)) (ite (bvsgt (_ bv4294967292 32) in258_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x313 (or false false false)))
(let (($x42 (not $x313)))
(and $x42 (or $x313 $x399))))))
(check-sat)
; query 9: function RPE_grid_positioning, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x1128 (or false false)))
(let (($x935 (not $x1128)))
(and $x935 (or $x1128 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 10: function RPE_grid_positioning, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x639 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x631 (and (distinct ?x639 ?x639) true)))
(let (($x1128 (or false false)))
(let (($x26 (or false $x1128 false)))
(and (not $x26) (or $x26 $x631)))))))
(check-sat)
; query 11: function alaw_input, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x524 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x227 (or false false (or $x524))))
(and (not $x227) (or $x227 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 12: function alaw_input, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let ((?x37 (ite (= (_ bv4294967295 32) in.1_32) (_ bv1 1) (_ bv0 1))))
(let (($x313 (or false false false)))
(let (($x42 (not $x313)))
(and $x42 (or $x313 (and (distinct ?x37 ?x37) true)))))))
(check-sat)
; query 13: function gsm_L_add, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_64 () (_ BitVec 64))
(assert
 (let ((?x488 (bvsub (_ bv0 64) in13_64)))
(let ((?x7 ((_ sign_extend 1) ?x488)))
(let (($x661 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in13_64)) ?x7) true)))))
(and (not $x661) (or $x661 (and (distinct ?x488 ?x488) true)))))))
(check-sat)
; query 14: function gsm_L_add, block 16, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_64 () (_ BitVec 64))
(assert
 (let ((?x488 (bvsub (_ bv0 64) in13_64)))
(let ((?x725 (bvsub ?x488 (_ bv2 64))))
(let (($x123 (and (distinct (bvsub ((_ sign_extend 1) ?x488) ((_ sign_extend 1) (_ bv2 64))) ((_ sign_extend 1) ?x725)) true)))
(let ((?x7 ((_ sign_extend 1) ?x488)))
(let (($x661 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in13_64)) ?x7) true)))))
(let (($x151 (or $x661 false (or $x123))))
(and (not $x151) (or $x151 (and (distinct ?x725 ?x725) true))))))))))
(check-sat)
; query 15: function gsm_L_add, block 21, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x204 (ite (bvsge (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x313 (or false false false)))
(let (($x42 (not $x313)))
(and $x42 (or $x313 (and (distinct ?x204 ?x204) true)))))))
(check-sat)
; query 16: function gsm_L_add, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x333 (bvadd in0_64 in1_64)))
(let (($x60 (and (distinct ?x333 ?x333) true)))
(let (($x79 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) ?x333)) true)))
(let (($x122 (or false false (or $x79))))
(and (not $x122) (or $x122 $x60)))))))
(check-sat)
; query 17: function gsm_L_add, block 25, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x333 (bvadd in0_64 in1_64)))
(let (($x60 (and (distinct ?x333 ?x333) true)))
(let (($x498 (and (distinct (bvadd ((_ zero_extend 1) in0_64) ((_ zero_extend 1) in1_64)) ((_ zero_extend 1) ?x333)) true)))
(let (($x104 (or false false (or $x498))))
(let (($x313 (or false false false)))
(let (($x42 (not $x313)))
(and $x42 (or $x104 $x60)))))))))
(check-sat)
; query 18: function gsm_L_add, block 25, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x44 (ite (bvugt (bvadd in0_64 in1_64) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x498 (and (distinct (bvadd ((_ zero_extend 1) in0_64) ((_ zero_extend 1) in1_64)) ((_ zero_extend 1) (bvadd in0_64 in1_64))) true)))
(let (($x104 (or false false (or $x498))))
(let (($x313 (or false false false)))
(let (($x650 (or $x313 false false)))
(let (($x646 (not $x650)))
(and $x646 (or (or $x104 false false) (and (distinct ?x44 ?x44) true))))))))))
(check-sat)
; query 19: function gsm_L_add, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x18 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x313 (or false false false)))
(let (($x42 (not $x313)))
(and $x42 (or $x313 (and (distinct ?x18 ?x18) true)))))))
(check-sat)
; query 20: function gsm_L_add, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x333 (bvadd in0_64 in1_64)))
(let (($x60 (and (distinct ?x333 ?x333) true)))
(let (($x79 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) ?x333)) true)))
(let (($x122 (or false false (or $x79))))
(and (not $x122) (or $x122 $x60)))))))
(check-sat)
; query 21: function gsm_L_add, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x86 (bvadd in0_64 (_ bv1 64))))
(let ((?x429 (bvsub (_ bv0 64) ?x86)))
(let (($x746 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x86)) ((_ sign_extend 1) ?x429)) true)))
(let ((?x66 ((_ sign_extend 1) ?x86)))
(let (($x96 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x66) true)))))
(let (($x14 (or false $x96 (or $x746))))
(and (not $x14) (or $x14 (and (distinct ?x429 ?x429) true))))))))))
(check-sat)
; query 22: function gsm_L_add, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1643 (bvadd in1_64 (_ bv1 64))))
(let ((?x6 ((_ sign_extend 1) ?x1643)))
(let (($x124 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x6) true)))))
(and (not $x124) (or $x124 (and (distinct ?x1643 ?x1643) true)))))))
(check-sat)
; query 23: function gsm_L_add, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1643 (bvadd in1_64 (_ bv1 64))))
(let ((?x1204 (bvsub (_ bv0 64) ?x1643)))
(let (($x315 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1643)) ((_ sign_extend 1) ?x1204)) true)))
(let ((?x6 ((_ sign_extend 1) ?x1643)))
(let (($x124 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x6) true)))))
(let (($x341 (or false $x124 (or $x315))))
(and (not $x341) (or $x341 (and (distinct ?x1204 ?x1204) true))))))))))
(check-sat)
; query 24: function gsm_L_add, block 8, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1643 (bvadd in1_64 (_ bv1 64))))
(let ((?x1204 (bvsub (_ bv0 64) ?x1643)))
(let ((?x86 (bvadd in0_64 (_ bv1 64))))
(let ((?x429 (bvsub (_ bv0 64) ?x86)))
(let ((?x312 (bvadd ?x429 ?x1204)))
(let (($x1579 (and (distinct (bvadd ((_ zero_extend 1) ?x429) ((_ zero_extend 1) ?x1204)) ((_ zero_extend 1) ?x312)) true)))
(let (($x315 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1643)) ((_ sign_extend 1) ?x1204)) true)))
(let ((?x6 ((_ sign_extend 1) ?x1643)))
(let (($x124 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x6) true)))))
(let (($x341 (or false $x124 (or $x315))))
(let (($x746 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x86)) ((_ sign_extend 1) ?x429)) true)))
(let ((?x66 ((_ sign_extend 1) ?x86)))
(let (($x96 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x66) true)))))
(let (($x14 (or false $x96 (or $x746))))
(let (($x856 (or $x14 $x341 (or $x1579))))
(and (not (or $x14 $x341 false)) (or $x856 (and (distinct ?x312 ?x312) true)))))))))))))))))))
(check-sat)
; query 25: function gsm_L_add, block 8, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1643 (bvadd in1_64 (_ bv1 64))))
(let ((?x1204 (bvsub (_ bv0 64) ?x1643)))
(let ((?x86 (bvadd in0_64 (_ bv1 64))))
(let ((?x429 (bvsub (_ bv0 64) ?x86)))
(let ((?x312 (bvadd ?x429 ?x1204)))
(let ((?x38 (ite (bvuge ?x312 (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x1579 (and (distinct (bvadd ((_ zero_extend 1) ?x429) ((_ zero_extend 1) ?x1204)) ((_ zero_extend 1) ?x312)) true)))
(let (($x315 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1643)) ((_ sign_extend 1) ?x1204)) true)))
(let ((?x6 ((_ sign_extend 1) ?x1643)))
(let (($x124 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x6) true)))))
(let (($x341 (or false $x124 (or $x315))))
(let (($x746 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x86)) ((_ sign_extend 1) ?x429)) true)))
(let ((?x66 ((_ sign_extend 1) ?x86)))
(let (($x96 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x66) true)))))
(let (($x14 (or false $x96 (or $x746))))
(let (($x856 (or $x14 $x341 (or $x1579))))
(and (not (or (or $x14 $x341 false) false false)) (or (or $x856 false false) (and (distinct ?x38 ?x38) true))))))))))))))))))))
(check-sat)
; query 26: function gsm_L_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x86 (bvadd in0_64 (_ bv1 64))))
(let ((?x66 ((_ sign_extend 1) ?x86)))
(let (($x96 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x66) true)))))
(and (not $x96) (or $x96 (and (distinct ?x86 ?x86) true)))))))
(check-sat)
; query 27: function gsm_L_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x648 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x313 (or false false false)))
(let (($x42 (not $x313)))
(and $x42 (or $x313 (and (distinct ?x648 ?x648) true)))))))
(check-sat)
; query 28: function gsm_L_asl, block 12, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1428 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x313 (or false false false)))
(let (($x42 (not $x313)))
(and $x42 (or $x313 (and (distinct ?x1428 ?x1428) true)))))))
(check-sat)
; query 29: function gsm_L_asl, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x575 (or false (or (= ((_ extract 31 31) in1_32) (_ bv1 1))))))
(let (($x1128 (or false false)))
(let (($x935 (not $x1128)))
(and $x935 (or $x575 (and (distinct ((_ zero_extend 32) in1_32) ((_ zero_extend 32) in1_32)) true)))))))
(check-sat)
; query 30: function gsm_L_asl, block 17, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x91 ((_ zero_extend 32) in1_32)))
(let ((?x1208 (bvshl in0_64 ?x91)))
(let (($x1238 (bvuge ?x91 (_ bv64 64))))
(let (($x1518 (or (or false (or false (or (= ((_ extract 31 31) in1_32) (_ bv1 1)))) false) $x1238)))
(let (($x1119 (not (or (or false (or false false) false) $x1238))))
(and $x1119 (or $x1518 (and (distinct ?x1208 ?x1208) true)))))))))
(check-sat)
; query 31: function gsm_L_asl, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1353 (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x313 (or false false false)))
(let (($x42 (not $x313)))
(and $x42 (or $x313 (and (distinct ?x1353 ?x1353) true)))))))
(check-sat)
; query 32: function gsm_L_asl, block 7, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x648 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1125 ((_ zero_extend 31) ?x648)))
(let ((?x1427 (bvsub (_ bv0 32) ?x1125)))
(let (($x875 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1125)) ((_ sign_extend 1) ?x1427)) true)))
(let (($x313 (or false false false)))
(let (($x1116 (or $x313 false)))
(let (($x352 (or false $x1116 (or $x875))))
(and (not $x352) (or $x352 (and (distinct ?x1427 ?x1427) true)))))))))))
(check-sat)
; query 33: function gsm_L_asl, block 7, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x648 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1125 ((_ zero_extend 31) ?x648)))
(let ((?x1427 (bvsub (_ bv0 32) ?x1125)))
(let ((?x381 ((_ sign_extend 32) ?x1427)))
(let (($x875 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1125)) ((_ sign_extend 1) ?x1427)) true)))
(let (($x313 (or false false false)))
(let (($x1116 (or $x313 false)))
(let (($x352 (or false $x1116 (or $x875))))
(let (($x1058 (or $x352 false)))
(and (not $x1058) (or $x1058 (and (distinct ?x381 ?x381) true)))))))))))))
(check-sat)
; query 34: function gsm_L_asl, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x648 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x313 (or false false false)))
(let (($x42 (not $x313)))
(and $x42 (or $x313 (and (distinct ?x648 ?x648) true)))))))
(check-sat)
; query 35: function gsm_L_asl, block 7, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x648 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1125 ((_ zero_extend 31) ?x648)))
(let (($x313 (or false false false)))
(let (($x1116 (or $x313 false)))
(and (not $x1116) (or $x1116 (and (distinct ?x1125 ?x1125) true))))))))
(check-sat)
; query 36: function gsm_L_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x760 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x313 (or false false false)))
(let (($x42 (not $x313)))
(and $x42 (or $x313 (and (distinct ?x760 ?x760) true)))))))
(check-sat)
; query 37: function gsm_L_asr, block 12, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1428 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x313 (or false false false)))
(let (($x42 (not $x313)))
(and $x42 (or $x313 (and (distinct ?x1428 ?x1428) true)))))))
(check-sat)
; query 38: function gsm_L_asr, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x534 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in1_32))) true)))
(let (($x1283 (or false false (or $x534))))
(and (not $x1283) (or $x1283 (and (distinct (bvsub (_ bv0 32) in1_32) (bvsub (_ bv0 32) in1_32)) true))))))
(check-sat)
; query 39: function gsm_L_asr, block 14, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1225 (bvsub (_ bv0 32) in1_32)))
(let ((?x518 ((_ zero_extend 32) ?x1225)))
(let (($x534 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x1225)) true)))
(let (($x1283 (or false false (or $x534))))
(let (($x1221 (or $x1283 (or (= ((_ extract 31 31) ?x1225) (_ bv1 1))))))
(and (not (or $x1283 false)) (or $x1221 (and (distinct ?x518 ?x518) true)))))))))
(check-sat)
; query 40: function gsm_L_asr, block 14, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1225 (bvsub (_ bv0 32) in1_32)))
(let ((?x518 ((_ zero_extend 32) ?x1225)))
(let ((?x1913 (bvshl in0_64 ?x518)))
(let (($x213 (bvuge ?x518 (_ bv64 64))))
(let (($x534 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x1225)) true)))
(let (($x1283 (or false false (or $x534))))
(let (($x1221 (or $x1283 (or (= ((_ extract 31 31) ?x1225) (_ bv1 1))))))
(and (not (or (or false (or $x1283 false) false) $x213)) (or (or (or false $x1221 false) $x213) (and (distinct ?x1913 ?x1913) true)))))))))))
(check-sat)
; query 41: function gsm_L_asr, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x575 (or false (or (= ((_ extract 31 31) in1_32) (_ bv1 1))))))
(let (($x1128 (or false false)))
(let (($x935 (not $x1128)))
(and $x935 (or $x575 (and (distinct ((_ zero_extend 32) in1_32) ((_ zero_extend 32) in1_32)) true)))))))
(check-sat)
; query 42: function gsm_L_asr, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x91 ((_ zero_extend 32) in1_32)))
(let ((?x1667 (bvashr in0_64 ?x91)))
(let (($x1238 (bvuge ?x91 (_ bv64 64))))
(let (($x1518 (or (or false (or false (or (= ((_ extract 31 31) in1_32) (_ bv1 1)))) false) $x1238)))
(let (($x1119 (not (or (or false (or false false) false) $x1238))))
(and $x1119 (or $x1518 (and (distinct ?x1667 ?x1667) true)))))))))
(check-sat)
; query 43: function gsm_L_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x648 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x313 (or false false false)))
(let (($x42 (not $x313)))
(and $x42 (or $x313 (and (distinct ?x648 ?x648) true)))))))
(check-sat)
; query 44: function gsm_L_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x648 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1125 ((_ zero_extend 31) ?x648)))
(let (($x313 (or false false false)))
(let (($x1116 (or $x313 false)))
(and (not $x1116) (or $x1116 (and (distinct ?x1125 ?x1125) true))))))))
(check-sat)
; query 45: function gsm_L_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x648 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1125 ((_ zero_extend 31) ?x648)))
(let ((?x1427 (bvsub (_ bv0 32) ?x1125)))
(let (($x875 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1125)) ((_ sign_extend 1) ?x1427)) true)))
(let (($x313 (or false false false)))
(let (($x1116 (or $x313 false)))
(let (($x352 (or false $x1116 (or $x875))))
(and (not $x352) (or $x352 (and (distinct ?x1427 ?x1427) true)))))))))))
(check-sat)
; query 46: function gsm_L_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x648 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1125 ((_ zero_extend 31) ?x648)))
(let ((?x1427 (bvsub (_ bv0 32) ?x1125)))
(let ((?x381 ((_ sign_extend 32) ?x1427)))
(let (($x875 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1125)) ((_ sign_extend 1) ?x1427)) true)))
(let (($x313 (or false false false)))
(let (($x1116 (or $x313 false)))
(let (($x352 (or false $x1116 (or $x875))))
(let (($x1058 (or $x352 false)))
(and (not $x1058) (or $x1058 (and (distinct ?x381 ?x381) true)))))))))))))
(check-sat)
; query 47: function gsm_L_asr, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1353 (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x313 (or false false false)))
(let (($x42 (not $x313)))
(and $x42 (or $x313 (and (distinct ?x1353 ?x1353) true)))))))
(check-sat)
; query 48: function gsm_L_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x760 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x313 (or false false false)))
(let (($x42 (not $x313)))
(and $x42 (or $x313 (and (distinct ?x760 ?x760) true)))))))
(check-sat)
; query 49: function gsm_L_mult, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x1128 (or false false)))
(let (($x935 (not $x1128)))
(and $x935 (or $x1128 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 50: function gsm_L_mult, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1011 (ite (and (distinct (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) true) (_ bv1 1) (_ bv0 1))))
(let (($x1128 (or false false)))
(let (($x426 (or $x1128 false false)))
(let (($x365 (not $x426)))
(and $x365 (or $x426 (and (distinct ?x1011 ?x1011) true))))))))
(check-sat)
; query 51: function gsm_L_mult, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x1128 (or false false)))
(let (($x935 (not $x1128)))
(and $x935 (or $x1128 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 52: function gsm_L_mult, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1833 (ite (and (distinct (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) true) (_ bv1 1) (_ bv0 1))))
(let (($x1128 (or false false)))
(let (($x426 (or $x1128 false false)))
(let (($x365 (not $x426)))
(and $x365 (or $x426 (and (distinct ?x1833 ?x1833) true))))))))
(check-sat)
; query 53: function gsm_L_sub, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in11_64 () (_ BitVec 64))
(assert
 (let (($x1022 (and (distinct (bvadd ((_ zero_extend 1) in11_64) ((_ zero_extend 1) (_ bv1 64))) ((_ zero_extend 1) (bvadd in11_64 (_ bv1 64)))) true)))
(let (($x637 (and (distinct (bvadd ((_ sign_extend 1) in11_64) ((_ sign_extend 1) (_ bv1 64))) ((_ sign_extend 1) (bvadd in11_64 (_ bv1 64)))) true)))
(let (($x77 (or (or false false (or $x637 $x1022)) (and (distinct (bvadd in11_64 (_ bv1 64)) (bvadd in11_64 (_ bv1 64))) true))))
(let (($x313 (or false false false)))
(let (($x42 (not $x313)))
(and $x42 $x77)))))))
(check-sat)
; query 54: function gsm_L_sub, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x204 (ite (bvsge (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x313 (or false false false)))
(let (($x42 (not $x313)))
(and $x42 (or $x313 (and (distinct ?x204 ?x204) true)))))))
(check-sat)
; query 55: function gsm_L_sub, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x662 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvsub in0_64 in1_64))) true)))
(let (($x1188 (or false false (or $x662))))
(let (($x1413 (or $x1188 (and (distinct (bvsub in0_64 in1_64) (bvsub in0_64 in1_64)) true))))
(and (not $x1188) $x1413)))))
(check-sat)
; query 56: function gsm_L_sub, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x86 (bvadd in0_64 (_ bv1 64))))
(let ((?x66 ((_ sign_extend 1) ?x86)))
(let (($x96 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x66) true)))))
(and (not $x96) (or $x96 (and (distinct ?x86 ?x86) true)))))))
(check-sat)
; query 57: function gsm_L_sub, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x86 (bvadd in0_64 (_ bv1 64))))
(let ((?x429 (bvsub (_ bv0 64) ?x86)))
(let (($x746 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x86)) ((_ sign_extend 1) ?x429)) true)))
(let ((?x66 ((_ sign_extend 1) ?x86)))
(let (($x96 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x66) true)))))
(let (($x14 (or false $x96 (or $x746))))
(and (not $x14) (or $x14 (and (distinct ?x429 ?x429) true))))))))))
(check-sat)
; query 58: function gsm_L_sub, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x86 (bvadd in0_64 (_ bv1 64))))
(let ((?x429 (bvsub (_ bv0 64) ?x86)))
(let ((?x642 (bvadd ?x429 in1_64)))
(let (($x1602 (and (distinct (bvadd ((_ zero_extend 1) ?x429) ((_ zero_extend 1) in1_64)) ((_ zero_extend 1) ?x642)) true)))
(let (($x746 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x86)) ((_ sign_extend 1) ?x429)) true)))
(let ((?x66 ((_ sign_extend 1) ?x86)))
(let (($x96 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x66) true)))))
(let (($x14 (or false $x96 (or $x746))))
(let (($x608 (or $x14 false (or $x1602))))
(and (not (or $x14 false false)) (or $x608 (and (distinct ?x642 ?x642) true)))))))))))))
(check-sat)
; query 59: function gsm_L_sub, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x20 (ite (bvuge (bvadd (bvsub (_ bv0 64) (bvadd in0_64 (_ bv1 64))) in1_64) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let ((?x111 ((_ zero_extend 1) in1_64)))
(let ((?x86 (bvadd in0_64 (_ bv1 64))))
(let ((?x429 (bvsub (_ bv0 64) ?x86)))
(let ((?x1732 ((_ zero_extend 1) ?x429)))
(let (($x746 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x86)) ((_ sign_extend 1) ?x429)) true)))
(let ((?x66 ((_ sign_extend 1) ?x86)))
(let (($x96 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x66) true)))))
(let (($x14 (or false $x96 (or $x746))))
(let (($x608 (or $x14 false (or (and (distinct (bvadd ?x1732 ?x111) ((_ zero_extend 1) (bvadd ?x429 in1_64))) true)))))
(and (not (or (or $x14 false false) false false)) (or (or $x608 false false) (and (distinct ?x20 ?x20) true))))))))))))))
(check-sat)
; query 60: function gsm_L_sub, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_64 () (_ BitVec 64))
(assert
 (let ((?x369 (bvsub (_ bv0 64) in25_64)))
(let ((?x849 ((_ sign_extend 1) ?x369)))
(let (($x2032 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in25_64)) ?x849) true)))))
(and (not $x2032) (or $x2032 (and (distinct ?x369 ?x369) true)))))))
(check-sat)
; query 61: function gsm_L_sub, block 28, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_64 () (_ BitVec 64))
(assert
 (let ((?x369 (bvsub (_ bv0 64) in25_64)))
(let ((?x1733 (bvsub ?x369 (_ bv1 64))))
(let (($x1496 (and (distinct (bvsub ((_ zero_extend 1) ?x369) ((_ zero_extend 1) (_ bv1 64))) ((_ zero_extend 1) ?x1733)) true)))
(let (($x1418 (and (distinct (bvsub ((_ sign_extend 1) ?x369) ((_ sign_extend 1) (_ bv1 64))) ((_ sign_extend 1) ?x1733)) true)))
(let ((?x849 ((_ sign_extend 1) ?x369)))
(let (($x2032 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in25_64)) ?x849) true)))))
(and (not (or $x2032 false (or $x1418))) (or (or $x2032 false (or $x1418 $x1496)) (and (distinct ?x1733 ?x1733) true))))))))))
(check-sat)
; query 62: function gsm_L_sub, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x18 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x313 (or false false false)))
(let (($x42 (not $x313)))
(and $x42 (or $x313 (and (distinct ?x18 ?x18) true)))))))
(check-sat)
; query 63: function gsm_L_sub, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x662 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvsub in0_64 in1_64))) true)))
(let (($x1188 (or false false (or $x662))))
(let (($x1413 (or $x1188 (and (distinct (bvsub in0_64 in1_64) (bvsub in0_64 in1_64)) true))))
(and (not $x1188) $x1413)))))
(check-sat)
; query 64: function gsm_L_sub, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1643 (bvadd in1_64 (_ bv1 64))))
(let ((?x1204 (bvsub (_ bv0 64) ?x1643)))
(let (($x315 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1643)) ((_ sign_extend 1) ?x1204)) true)))
(let ((?x6 ((_ sign_extend 1) ?x1643)))
(let (($x124 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x6) true)))))
(let (($x341 (or false $x124 (or $x315))))
(and (not $x341) (or $x341 (and (distinct ?x1204 ?x1204) true))))))))))
(check-sat)
; query 65: function gsm_L_sub, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1643 (bvadd in1_64 (_ bv1 64))))
(let ((?x1204 (bvsub (_ bv0 64) ?x1643)))
(let ((?x1946 (bvadd in0_64 ?x1204)))
(let (($x1191 (and (distinct (bvadd ((_ zero_extend 1) in0_64) ((_ zero_extend 1) ?x1204)) ((_ zero_extend 1) ?x1946)) true)))
(let (($x315 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1643)) ((_ sign_extend 1) ?x1204)) true)))
(let ((?x6 ((_ sign_extend 1) ?x1643)))
(let (($x124 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x6) true)))))
(let (($x341 (or false $x124 (or $x315))))
(let (($x1473 (or false $x341 (or $x1191))))
(and (not (or false $x341 false)) (or $x1473 (and (distinct ?x1946 ?x1946) true)))))))))))))
(check-sat)
; query 66: function gsm_L_sub, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x539 (ite (bvuge (bvadd in0_64 (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64)))) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let ((?x1643 (bvadd in1_64 (_ bv1 64))))
(let ((?x1204 (bvsub (_ bv0 64) ?x1643)))
(let ((?x98 ((_ zero_extend 1) ?x1204)))
(let ((?x23 ((_ zero_extend 1) in0_64)))
(let (($x315 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1643)) ((_ sign_extend 1) ?x1204)) true)))
(let ((?x6 ((_ sign_extend 1) ?x1643)))
(let (($x124 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x6) true)))))
(let (($x341 (or false $x124 (or $x315))))
(let (($x1473 (or false $x341 (or (and (distinct (bvadd ?x23 ?x98) ((_ zero_extend 1) (bvadd in0_64 ?x1204))) true)))))
(and (not (or (or false $x341 false) false false)) (or (or $x1473 false false) (and (distinct ?x539 ?x539) true))))))))))))))
(check-sat)
; query 67: function gsm_L_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1643 (bvadd in1_64 (_ bv1 64))))
(let ((?x6 ((_ sign_extend 1) ?x1643)))
(let (($x124 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x6) true)))))
(and (not $x124) (or $x124 (and (distinct ?x1643 ?x1643) true)))))))
(check-sat)
; query 68: function gsm_L_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x357 (ite (bvsle (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x313 (or false false false)))
(let (($x42 (not $x313)))
(and $x42 (or $x313 (and (distinct ?x357 ?x357) true)))))))
(check-sat)
; query 69: function gsm_abs, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x1128 (or false false)))
(let (($x935 (not $x1128)))
(and $x935 (or $x1128 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 70: function gsm_abs, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x203 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1128 (or false false)))
(let (($x426 (or $x1128 false false)))
(let (($x365 (not $x426)))
(and $x365 (or $x426 (and (distinct ?x203 ?x203) true))))))))
(check-sat)
; query 71: function gsm_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_64 () (_ BitVec 64))
(assert
 (let ((?x1529 (ite (bvslt (_ bv32767 64) in5_64) (_ bv1 1) (_ bv0 1))))
(let (($x313 (or false false false)))
(let (($x42 (not $x313)))
(and $x42 (or $x313 (and (distinct ?x1529 ?x1529) true)))))))
(check-sat)
; query 72: function gsm_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x1128 (or false false)))
(let (($x935 (not $x1128)))
(and $x935 (or $x1128 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 73: function gsm_add, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x1128 (or false false)))
(let (($x935 (not $x1128)))
(and $x935 (or $x1128 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 74: function gsm_add, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1920 ((_ sign_extend 48) in1_16)))
(let ((?x1053 ((_ sign_extend 48) in0_16)))
(let ((?x1431 (bvadd ?x1053 ?x1920)))
(let (($x792 (and (distinct (bvadd ((_ sign_extend 1) ?x1053) ((_ sign_extend 1) ?x1920)) ((_ sign_extend 1) ?x1431)) true)))
(let (($x1128 (or false false)))
(let (($x697 (or $x1128 $x1128 (or $x792))))
(and (not $x697) (or $x697 (and (distinct ?x1431 ?x1431) true))))))))))
(check-sat)
; query 75: function gsm_add, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x927 (ite (bvsgt (_ bv18446744073709518848 64) (bvadd ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x1920 ((_ sign_extend 48) in1_16)))
(let ((?x1616 ((_ sign_extend 1) ?x1920)))
(let ((?x1053 ((_ sign_extend 48) in0_16)))
(let ((?x954 ((_ sign_extend 1) ?x1053)))
(let (($x1128 (or false false)))
(let (($x697 (or $x1128 $x1128 (or (and (distinct (bvadd ?x954 ?x1616) ((_ sign_extend 1) (bvadd ?x1053 ?x1920))) true)))))
(let (($x479 (or $x697 false false)))
(and (not $x479) (or $x479 (and (distinct ?x927 ?x927) true))))))))))))
(check-sat)
; query 76: function gsm_asl, block 13, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1428 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x313 (or false false false)))
(let (($x42 (not $x313)))
(and $x42 (or $x313 (and (distinct ?x1428 ?x1428) true)))))))
(check-sat)
; query 77: function gsm_asl, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x1128 (or false false)))
(let (($x935 (not $x1128)))
(and $x935 (or $x1128 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 78: function gsm_asl, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x640 ((_ sign_extend 16) in0_16)))
(let ((?x1649 (bvshl ?x640 in1_32)))
(let (($x886 (bvuge in1_32 (_ bv32 32))))
(let (($x1128 (or false false)))
(let (($x441 (or (or $x1128 false (or (and (distinct (bvashr ?x1649 in1_32) ?x640) true))) $x886)))
(let (($x426 (or $x1128 false false)))
(let (($x1357 (or $x426 $x886)))
(let (($x1302 (not $x1357)))
(and $x1302 (or $x441 (and (distinct ?x1649 ?x1649) true))))))))))))
(check-sat)
; query 79: function gsm_asl, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x640 ((_ sign_extend 16) in0_16)))
(let ((?x1649 (bvshl ?x640 in1_32)))
(let ((?x1559 ((_ extract 15 0) ?x1649)))
(let (($x886 (bvuge in1_32 (_ bv32 32))))
(let (($x1128 (or false false)))
(let (($x441 (or (or $x1128 false (or (and (distinct (bvashr ?x1649 in1_32) ?x640) true))) $x886)))
(let (($x1172 (not (or (or (or $x1128 false false) $x886) false))))
(and $x1172 (or (or $x441 false) (and (distinct ?x1559 ?x1559) true)))))))))))
(check-sat)
; query 80: function gsm_asl, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1440 (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x313 (or false false false)))
(let (($x42 (not $x313)))
(and $x42 (or $x313 (and (distinct ?x1440 ?x1440) true)))))))
(check-sat)
; query 81: function gsm_asl, block 7, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x203 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x510 ((_ zero_extend 31) ?x203)))
(let (($x1128 (or false false)))
(let (($x426 (or $x1128 false false)))
(let (($x1175 (or $x426 false)))
(and (not $x1175) (or $x1175 (and (distinct ?x510 ?x510) true)))))))))
(check-sat)
; query 82: function gsm_asl, block 7, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x203 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x510 ((_ zero_extend 31) ?x203)))
(let ((?x882 (bvsub (_ bv0 32) ?x510)))
(let (($x1301 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x510)) ((_ sign_extend 1) ?x882)) true)))
(let (($x1128 (or false false)))
(let (($x426 (or $x1128 false false)))
(let (($x1175 (or $x426 false)))
(let (($x468 (or false $x1175 (or $x1301))))
(and (not $x468) (or $x468 (and (distinct ?x882 ?x882) true))))))))))))
(check-sat)
; query 83: function gsm_asl, block 7, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x203 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x510 ((_ zero_extend 31) ?x203)))
(let ((?x882 (bvsub (_ bv0 32) ?x510)))
(let ((?x913 ((_ extract 15 0) ?x882)))
(let (($x1301 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x510)) ((_ sign_extend 1) ?x882)) true)))
(let (($x1128 (or false false)))
(let (($x426 (or $x1128 false false)))
(let (($x1175 (or $x426 false)))
(let (($x468 (or false $x1175 (or $x1301))))
(let (($x1714 (or (or $x468 (or (and (distinct ((_ sign_extend 16) ?x913) ?x882) true))) (and (distinct ?x913 ?x913) true))))
(and (not (or $x468 false)) $x1714))))))))))))
(check-sat)
; query 84: function gsm_asl, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x1128 (or false false)))
(let (($x935 (not $x1128)))
(and $x935 (or $x1128 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 85: function gsm_asl, block 7, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x203 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1128 (or false false)))
(let (($x426 (or $x1128 false false)))
(let (($x365 (not $x426)))
(and $x365 (or $x426 (and (distinct ?x203 ?x203) true))))))))
(check-sat)
; query 86: function gsm_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x598 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x313 (or false false false)))
(let (($x42 (not $x313)))
(and $x42 (or $x313 (and (distinct ?x598 ?x598) true)))))))
(check-sat)
; query 87: function gsm_asr, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1440 (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x313 (or false false false)))
(let (($x42 (not $x313)))
(and $x42 (or $x313 (and (distinct ?x1440 ?x1440) true)))))))
(check-sat)
; query 88: function gsm_asr, block 13, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1428 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x313 (or false false false)))
(let (($x42 (not $x313)))
(and $x42 (or $x313 (and (distinct ?x1428 ?x1428) true)))))))
(check-sat)
; query 89: function gsm_asr, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x1128 (or false false)))
(let (($x935 (not $x1128)))
(and $x935 (or $x1128 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 90: function gsm_asr, block 15, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x534 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in1_32))) true)))
(let (($x1283 (or false false (or $x534))))
(and (not $x1283) (or $x1283 (and (distinct (bvsub (_ bv0 32) in1_32) (bvsub (_ bv0 32) in1_32)) true))))))
(check-sat)
; query 91: function gsm_asr, block 15, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1225 (bvsub (_ bv0 32) in1_32)))
(let ((?x640 ((_ sign_extend 16) in0_16)))
(let ((?x1205 (bvshl ?x640 ?x1225)))
(let (($x197 (bvuge ?x1225 (_ bv32 32))))
(let (($x534 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x1225)) true)))
(let (($x1283 (or false false (or $x534))))
(let (($x1128 (or false false)))
(let (($x1992 (or (or $x1128 $x1283 (or (and (distinct (bvashr ?x1205 ?x1225) ?x640) true))) $x197)))
(and (not (or (or $x1128 $x1283 false) $x197)) (or $x1992 (and (distinct ?x1205 ?x1205) true))))))))))))
(check-sat)
; query 92: function gsm_asr, block 15, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1225 (bvsub (_ bv0 32) in1_32)))
(let ((?x640 ((_ sign_extend 16) in0_16)))
(let ((?x1205 (bvshl ?x640 ?x1225)))
(let ((?x1456 ((_ extract 15 0) ?x1205)))
(let (($x197 (bvuge ?x1225 (_ bv32 32))))
(let (($x534 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x1225)) true)))
(let (($x1283 (or false false (or $x534))))
(let (($x1128 (or false false)))
(let (($x1992 (or (or $x1128 $x1283 (or (and (distinct (bvashr ?x1205 ?x1225) ?x640) true))) $x197)))
(and (not (or (or (or $x1128 $x1283 false) $x197) false)) (or (or $x1992 false) (and (distinct ?x1456 ?x1456) true)))))))))))))
(check-sat)
; query 93: function gsm_asr, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x1128 (or false false)))
(let (($x935 (not $x1128)))
(and $x935 (or $x1128 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 94: function gsm_asr, block 20, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x640 ((_ sign_extend 16) in0_16)))
(let ((?x1589 (bvashr ?x640 in1_32)))
(let (($x886 (bvuge in1_32 (_ bv32 32))))
(let (($x1128 (or false false)))
(let (($x426 (or $x1128 false false)))
(let (($x1357 (or $x426 $x886)))
(let (($x1302 (not $x1357)))
(and $x1302 (or $x1357 (and (distinct ?x1589 ?x1589) true)))))))))))
(check-sat)
; query 95: function gsm_asr, block 20, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x640 ((_ sign_extend 16) in0_16)))
(let ((?x1589 (bvashr ?x640 in1_32)))
(let ((?x841 ((_ extract 15 0) ?x1589)))
(let (($x886 (bvuge in1_32 (_ bv32 32))))
(let (($x1128 (or false false)))
(let (($x426 (or $x1128 false false)))
(let (($x1357 (or $x426 $x886)))
(let (($x1607 (or (or $x1357 (or (and (distinct ((_ sign_extend 16) ?x841) ?x1589) true))) (and (distinct ?x841 ?x841) true))))
(let (($x1172 (not (or $x1357 false))))
(and $x1172 $x1607)))))))))))
(check-sat)
; query 96: function gsm_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x1128 (or false false)))
(let (($x935 (not $x1128)))
(and $x935 (or $x1128 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 97: function gsm_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x203 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1128 (or false false)))
(let (($x426 (or $x1128 false false)))
(let (($x365 (not $x426)))
(and $x365 (or $x426 (and (distinct ?x203 ?x203) true))))))))
(check-sat)
; query 98: function gsm_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x203 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x510 ((_ zero_extend 31) ?x203)))
(let (($x1128 (or false false)))
(let (($x426 (or $x1128 false false)))
(let (($x1175 (or $x426 false)))
(and (not $x1175) (or $x1175 (and (distinct ?x510 ?x510) true)))))))))
(check-sat)
; query 99: function gsm_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x203 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x510 ((_ zero_extend 31) ?x203)))
(let ((?x882 (bvsub (_ bv0 32) ?x510)))
(let (($x1301 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x510)) ((_ sign_extend 1) ?x882)) true)))
(let (($x1128 (or false false)))
(let (($x426 (or $x1128 false false)))
(let (($x1175 (or $x426 false)))
(let (($x468 (or false $x1175 (or $x1301))))
(and (not $x468) (or $x468 (and (distinct ?x882 ?x882) true))))))))))))
(check-sat)
; query 100: function gsm_asr, block 4, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x203 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x510 ((_ zero_extend 31) ?x203)))
(let ((?x882 (bvsub (_ bv0 32) ?x510)))
(let ((?x913 ((_ extract 15 0) ?x882)))
(let (($x1301 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x510)) ((_ sign_extend 1) ?x882)) true)))
(let (($x1128 (or false false)))
(let (($x426 (or $x1128 false false)))
(let (($x1175 (or $x426 false)))
(let (($x468 (or false $x1175 (or $x1301))))
(let (($x1714 (or (or $x468 (or (and (distinct ((_ sign_extend 16) ?x913) ?x882) true))) (and (distinct ?x913 ?x913) true))))
(and (not (or $x468 false)) $x1714))))))))))))
(check-sat)
; query 101: function gsm_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x598 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x313 (or false false false)))
(let (($x42 (not $x313)))
(and $x42 (or $x313 (and (distinct ?x598 ?x598) true)))))))
(check-sat)
; query 102: function gsm_debug_longwords, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in15_32 () (_ BitVec 32))
(assert
 (let ((?x1006 (ite (bvslt in15_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x313 (or false false false)))
(let (($x42 (not $x313)))
(and $x42 (or $x313 (and (distinct ?x1006 ?x1006) true)))))))
(check-sat)
; query 103: function gsm_debug_words, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in16_32 () (_ BitVec 32))
(assert
 (let ((?x1092 (ite (bvslt in16_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x313 (or false false false)))
(let (($x42 (not $x313)))
(and $x42 (or $x313 (and (distinct ?x1092 ?x1092) true)))))))
(check-sat)
; query 104: function gsm_div, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x1128 (or false false)))
(let (($x935 (not $x1128)))
(and $x935 (or $x1128 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 105: function gsm_div, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x1128 (or false false)))
(let (($x935 (not $x1128)))
(and $x935 (or $x1128 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 106: function gsm_div, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x1128 (or false false)))
(let (($x935 (not $x1128)))
(and $x935 (or $x1128 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 107: function gsm_div, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x639 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x631 (and (distinct ?x639 ?x639) true)))
(let (($x1128 (or false false)))
(let (($x426 (or $x1128 false false)))
(let (($x365 (not $x426)))
(and $x365 (or $x426 $x631))))))))
(check-sat)
; query 108: function gsm_mult, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x1128 (or false false)))
(let (($x935 (not $x1128)))
(and $x935 (or $x1128 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 109: function gsm_mult, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x12 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1128 (or false false)))
(let (($x426 (or $x1128 false false)))
(let (($x365 (not $x426)))
(and $x365 (or $x426 (and (distinct ?x12 ?x12) true))))))))
(check-sat)
; query 110: function gsm_mult, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x1128 (or false false)))
(let (($x935 (not $x1128)))
(and $x935 (or $x1128 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 111: function gsm_mult, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x1128 (or false false)))
(let (($x935 (not $x1128)))
(and $x935 (or $x1128 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 112: function gsm_mult, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1920 ((_ sign_extend 48) in1_16)))
(let ((?x1053 ((_ sign_extend 48) in0_16)))
(let ((?x1742 (bvmul ?x1053 ?x1920)))
(let (($x682 (and (distinct (bvmul ((_ sign_extend 64) ?x1053) ((_ sign_extend 64) ?x1920)) ((_ sign_extend 64) ?x1742)) true)))
(let (($x1128 (or false false)))
(let (($x1780 (or $x1128 $x1128 (or $x682))))
(and (not $x1780) (or $x1780 (and (distinct ?x1742 ?x1742) true))))))))))
(check-sat)
; query 113: function gsm_mult, block 9, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1920 ((_ sign_extend 48) in1_16)))
(let ((?x1053 ((_ sign_extend 48) in0_16)))
(let ((?x1742 (bvmul ?x1053 ?x1920)))
(let ((?x1575 (bvashr ?x1742 (_ bv15 64))))
(let (($x46 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x682 (and (distinct (bvmul ((_ sign_extend 64) ?x1053) ((_ sign_extend 64) ?x1920)) ((_ sign_extend 64) ?x1742)) true)))
(let (($x1128 (or false false)))
(let (($x1780 (or $x1128 $x1128 (or $x682))))
(let (($x423 (or (or $x1780 false false) $x46)))
(and (not $x423) (or $x423 (and (distinct ?x1575 ?x1575) true)))))))))))))
(check-sat)
; query 114: function gsm_mult, block 9, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1920 ((_ sign_extend 48) in1_16)))
(let ((?x1053 ((_ sign_extend 48) in0_16)))
(let ((?x1742 (bvmul ?x1053 ?x1920)))
(let ((?x1575 (bvashr ?x1742 (_ bv15 64))))
(let ((?x1609 ((_ extract 15 0) ?x1575)))
(let (($x46 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x682 (and (distinct (bvmul ((_ sign_extend 64) ?x1053) ((_ sign_extend 64) ?x1920)) ((_ sign_extend 64) ?x1742)) true)))
(let (($x1128 (or false false)))
(let (($x1780 (or $x1128 $x1128 (or $x682))))
(let (($x423 (or (or $x1780 false false) $x46)))
(let (($x76 (or $x423 false)))
(and (not $x76) (or $x76 (and (distinct ?x1609 ?x1609) true)))))))))))))))
(check-sat)
; query 115: function gsm_mult, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x1128 (or false false)))
(let (($x935 (not $x1128)))
(and $x935 (or $x1128 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 116: function gsm_mult, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x905 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1128 (or false false)))
(let (($x426 (or $x1128 false false)))
(let (($x365 (not $x426)))
(and $x365 (or $x426 (and (distinct ?x905 ?x905) true))))))))
(check-sat)
; query 117: function gsm_mult_r, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x1128 (or false false)))
(let (($x935 (not $x1128)))
(and $x935 (or $x1128 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 118: function gsm_mult_r, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x905 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1128 (or false false)))
(let (($x426 (or $x1128 false false)))
(let (($x365 (not $x426)))
(and $x365 (or $x426 (and (distinct ?x905 ?x905) true))))))))
(check-sat)
; query 119: function gsm_mult_r, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x1128 (or false false)))
(let (($x935 (not $x1128)))
(and $x935 (or $x1128 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 120: function gsm_mult_r, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x1128 (or false false)))
(let (($x935 (not $x1128)))
(and $x935 (or $x1128 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 121: function gsm_mult_r, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1920 ((_ sign_extend 48) in1_16)))
(let ((?x1053 ((_ sign_extend 48) in0_16)))
(let ((?x1742 (bvmul ?x1053 ?x1920)))
(let (($x682 (and (distinct (bvmul ((_ sign_extend 64) ?x1053) ((_ sign_extend 64) ?x1920)) ((_ sign_extend 64) ?x1742)) true)))
(let (($x1128 (or false false)))
(let (($x1780 (or $x1128 $x1128 (or $x682))))
(and (not $x1780) (or $x1780 (and (distinct ?x1742 ?x1742) true))))))))))
(check-sat)
; query 122: function gsm_mult_r, block 9, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1920 ((_ sign_extend 48) in1_16)))
(let ((?x1053 ((_ sign_extend 48) in0_16)))
(let ((?x1742 (bvmul ?x1053 ?x1920)))
(let ((?x1210 (bvadd ?x1742 (_ bv16384 64))))
(let (($x1531 (and (distinct (bvadd ((_ sign_extend 1) ?x1742) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x1210)) true)))
(let (($x682 (and (distinct (bvmul ((_ sign_extend 64) ?x1053) ((_ sign_extend 64) ?x1920)) ((_ sign_extend 64) ?x1742)) true)))
(let (($x1128 (or false false)))
(let (($x1780 (or $x1128 $x1128 (or $x682))))
(let (($x1808 (or $x1780 false (or $x1531))))
(and (not $x1808) (or $x1808 (and (distinct ?x1210 ?x1210) true)))))))))))))
(check-sat)
; query 123: function gsm_mult_r, block 9, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1920 ((_ sign_extend 48) in1_16)))
(let ((?x1053 ((_ sign_extend 48) in0_16)))
(let ((?x1742 (bvmul ?x1053 ?x1920)))
(let ((?x1210 (bvadd ?x1742 (_ bv16384 64))))
(let ((?x1452 (bvashr ?x1210 (_ bv15 64))))
(let (($x46 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1531 (and (distinct (bvadd ((_ sign_extend 1) ?x1742) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x1210)) true)))
(let (($x682 (and (distinct (bvmul ((_ sign_extend 64) ?x1053) ((_ sign_extend 64) ?x1920)) ((_ sign_extend 64) ?x1742)) true)))
(let (($x1128 (or false false)))
(let (($x1780 (or $x1128 $x1128 (or $x682))))
(let (($x1808 (or $x1780 false (or $x1531))))
(let (($x1101 (or (or $x1808 false false) $x46)))
(and (not $x1101) (or $x1101 (and (distinct ?x1452 ?x1452) true))))))))))))))))
(check-sat)
; query 124: function gsm_mult_r, block 9, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1920 ((_ sign_extend 48) in1_16)))
(let ((?x1053 ((_ sign_extend 48) in0_16)))
(let ((?x1742 (bvmul ?x1053 ?x1920)))
(let ((?x1210 (bvadd ?x1742 (_ bv16384 64))))
(let ((?x1452 (bvashr ?x1210 (_ bv15 64))))
(let ((?x1987 (bvand ?x1452 (_ bv65535 64))))
(let (($x46 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1531 (and (distinct (bvadd ((_ sign_extend 1) ?x1742) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x1210)) true)))
(let (($x682 (and (distinct (bvmul ((_ sign_extend 64) ?x1053) ((_ sign_extend 64) ?x1920)) ((_ sign_extend 64) ?x1742)) true)))
(let (($x1128 (or false false)))
(let (($x1780 (or $x1128 $x1128 (or $x682))))
(let (($x1808 (or $x1780 false (or $x1531))))
(let (($x1101 (or (or $x1808 false false) $x46)))
(let (($x2001 (or $x1101 false false)))
(and (not $x2001) (or $x2001 (and (distinct ?x1987 ?x1987) true))))))))))))))))))
(check-sat)
; query 125: function gsm_mult_r, block 9, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1920 ((_ sign_extend 48) in1_16)))
(let ((?x1053 ((_ sign_extend 48) in0_16)))
(let ((?x1742 (bvmul ?x1053 ?x1920)))
(let ((?x1210 (bvadd ?x1742 (_ bv16384 64))))
(let ((?x1452 (bvashr ?x1210 (_ bv15 64))))
(let ((?x1987 (bvand ?x1452 (_ bv65535 64))))
(let ((?x1672 ((_ extract 15 0) ?x1987)))
(let (($x46 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1531 (and (distinct (bvadd ((_ sign_extend 1) ?x1742) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x1210)) true)))
(let (($x682 (and (distinct (bvmul ((_ sign_extend 64) ?x1053) ((_ sign_extend 64) ?x1920)) ((_ sign_extend 64) ?x1742)) true)))
(let (($x1128 (or false false)))
(let (($x1780 (or $x1128 $x1128 (or $x682))))
(let (($x1808 (or $x1780 false (or $x1531))))
(let (($x1101 (or (or $x1808 false false) $x46)))
(let (($x2001 (or $x1101 false false)))
(let (($x1076 (or (or $x2001 (or (and (distinct ((_ zero_extend 48) ?x1672) ?x1987) true))) (and (distinct ?x1672 ?x1672) true))))
(and (not (or $x2001 false)) $x1076))))))))))))))))))
(check-sat)
; query 126: function gsm_mult_r, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x1128 (or false false)))
(let (($x935 (not $x1128)))
(and $x935 (or $x1128 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 127: function gsm_mult_r, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x12 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1128 (or false false)))
(let (($x426 (or $x1128 false false)))
(let (($x365 (not $x426)))
(and $x365 (or $x426 (and (distinct ?x12 ?x12) true))))))))
(check-sat)
; query 128: function gsm_norm, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x648 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x313 (or false false false)))
(let (($x42 (not $x313)))
(and $x42 (or $x313 (and (distinct ?x648 (ite (bvsge (_ bv18446744072635809792 64) in0_64) (_ bv1 1) (_ bv0 1))) true)))))))
(check-sat)
; query 129: function gsm_norm, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x275 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x313 (or false false false)))
(let (($x42 (not $x313)))
(and $x42 (or $x313 (and (distinct ?x275 ?x275) true)))))))
(check-sat)
; query 130: function gsm_norm, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x275 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x890 (bvxor ?x275 (_ bv1 1))))
(let (($x313 (or false false false)))
(let (($x650 (or $x313 false false)))
(let (($x646 (not $x650)))
(and $x646 (or $x650 (and (distinct ?x890 ?x890) true)))))))))
(check-sat)
; query 131: function gsm_norm, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x275 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x890 (bvxor ?x275 (_ bv1 1))))
(let ((?x1599 ((_ zero_extend 31) ?x890)))
(let (($x313 (or false false false)))
(let (($x650 (or $x313 false false)))
(let (($x635 (or $x650 false)))
(and (not $x635) (or $x635 (and (distinct ?x1599 ?x1599) true))))))))))
(check-sat)
; query 132: function gsm_norm, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x275 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x890 (bvxor ?x275 (_ bv1 1))))
(let ((?x1599 ((_ zero_extend 31) ?x890)))
(let (($x313 (or false false false)))
(let (($x650 (or $x313 false false)))
(let (($x635 (or $x650 false)))
(let (($x712 (or (or $x635 (or (= ((_ extract 31 31) ?x1599) (_ bv1 1)))) (and (distinct ((_ sign_extend 32) ?x1599) ((_ zero_extend 32) ?x1599)) true))))
(and (not (or $x635 false)) $x712)))))))))
(check-sat)
; query 133: function gsm_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_64 () (_ BitVec 64))
(assert
 (let ((?x1529 (ite (bvslt (_ bv32767 64) in5_64) (_ bv1 1) (_ bv0 1))))
(let (($x313 (or false false false)))
(let (($x42 (not $x313)))
(and $x42 (or $x313 (and (distinct ?x1529 ?x1529) true)))))))
(check-sat)
; query 134: function gsm_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x1128 (or false false)))
(let (($x935 (not $x1128)))
(and $x935 (or $x1128 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 135: function gsm_sub, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x1128 (or false false)))
(let (($x935 (not $x1128)))
(and $x935 (or $x1128 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 136: function gsm_sub, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1920 ((_ sign_extend 48) in1_16)))
(let ((?x1053 ((_ sign_extend 48) in0_16)))
(let ((?x2057 (bvsub ?x1053 ?x1920)))
(let (($x723 (and (distinct (bvsub ((_ sign_extend 1) ?x1053) ((_ sign_extend 1) ?x1920)) ((_ sign_extend 1) ?x2057)) true)))
(let (($x1128 (or false false)))
(let (($x998 (or $x1128 $x1128 (or $x723))))
(and (not $x998) (or $x998 (and (distinct ?x2057 ?x2057) true))))))))))
(check-sat)
; query 137: function gsm_sub, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1862 (ite (bvsgt (_ bv18446744073709518848 64) (bvsub ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x1920 ((_ sign_extend 48) in1_16)))
(let ((?x1616 ((_ sign_extend 1) ?x1920)))
(let ((?x1053 ((_ sign_extend 48) in0_16)))
(let ((?x954 ((_ sign_extend 1) ?x1053)))
(let (($x1128 (or false false)))
(let (($x998 (or $x1128 $x1128 (or (and (distinct (bvsub ?x954 ?x1616) ((_ sign_extend 1) (bvsub ?x1053 ?x1920))) true)))))
(let (($x499 (or $x998 false false)))
(and (not $x499) (or $x499 (and (distinct ?x1862 ?x1862) true))))))))))))
(check-sat)
; query 138: function ok_to_replace, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1792 (ite (and (distinct (_ bv4294967295 32) in.01_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x313 (or false false false)))
(let (($x42 (not $x313)))
(and $x42 (or $x313 (and (distinct ?x1792 ?x1792) true)))))))
(check-sat)
; query 139: function ok_to_replace, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in16_32 () (_ BitVec 32))
(assert
 (let ((?x802 (ite (= (_ bv121 32) in16_32) (_ bv1 1) (_ bv0 1))))
(let (($x313 (or false false false)))
(let (($x42 (not $x313)))
(and $x42 (or $x313 (and (distinct ?x802 ?x802) true)))))))
(check-sat)
; query 140: function suffix, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_64 () (_ BitVec 64))
(declare-fun in3_64 () (_ BitVec 64))
(assert
 (let ((?x691 (ite (bvule in3_64 in4_64) (_ bv1 1) (_ bv0 1))))
(let (($x313 (or false false false)))
(let (($x42 (not $x313)))
(and $x42 (or $x313 (and (distinct ?x691 ?x691) true)))))))
(check-sat)
; query 141: function ulaw_input, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x524 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x227 (or false false (or $x524))))
(and (not $x227) (or $x227 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 142: function ulaw_input, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let ((?x37 (ite (= (_ bv4294967295 32) in.1_32) (_ bv1 1) (_ bv0 1))))
(let (($x313 (or false false false)))
(let (($x42 (not $x313)))
(and $x42 (or $x313 (and (distinct ?x37 ?x37) true)))))))
(check-sat)
