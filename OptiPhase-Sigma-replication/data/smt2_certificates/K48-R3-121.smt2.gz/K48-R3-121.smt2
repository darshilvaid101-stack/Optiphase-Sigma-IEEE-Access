; OptiPhase-Sigma refinement certificate for sweep K48-R3-121
; query 0: function APCM_inverse_quantization, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x1429 (or false false)))
(let (($x430 (not $x1429)))
(and $x430 (or $x1429 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 1: function APCM_inverse_quantization, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x135 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1429 (or false false)))
(let (($x24 (or $x1429 false false)))
(let (($x82 (not $x24)))
(and $x82 (or $x24 (and (distinct ?x135 ?x135) true))))))))
(check-sat)
; query 2: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x1429 (or false false)))
(let (($x430 (not $x1429)))
(and $x430 (or $x1429 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 3: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x125 (ite (bvslt (_ bv15 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1429 (or false false)))
(let (($x24 (or $x1429 false false)))
(let (($x82 (not $x24)))
(and $x82 (or $x24 (and (distinct ?x125 ?x125) true))))))))
(check-sat)
; query 4: function Decoding_of_the_coded_Log_Area_Ratios, block 268, name %269
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in265_64 () (_ BitVec 64))
(assert
 (let (($x155 (and (distinct (ite (bvsge (_ bv18446744073709518848 64) in265_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv0 64) in265_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x67 (or false false false)))
(let (($x187 (not $x67)))
(and $x187 (or $x67 $x155))))))
(check-sat)
; query 5: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x1429 (or false false)))
(let (($x430 (not $x1429)))
(and $x430 (or $x1429 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 6: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x27 (ite (bvsgt (_ bv40 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1429 (or false false)))
(let (($x24 (or $x1429 false false)))
(let (($x82 (not $x24)))
(and $x82 (or $x24 (and (distinct ?x27 ?x27) true))))))))
(check-sat)
; query 7: function Quantization_and_coding, block 311, name %312
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in308_32 () (_ BitVec 32))
(declare-fun in308_64 () (_ BitVec 64))
(assert
 (let (($x15 (and (distinct (ite (bvslt (_ bv0 64) in308_64) (_ bv1 1) (_ bv0 1)) (ite (bvsgt (_ bv4294967292 32) in308_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x67 (or false false false)))
(let (($x187 (not $x67)))
(and $x187 (or $x67 $x15))))))
(check-sat)
; query 8: function RPE_grid_positioning, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x1429 (or false false)))
(let (($x430 (not $x1429)))
(and $x430 (or $x1429 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 9: function RPE_grid_positioning, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x121 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1203 (and (distinct ?x121 ?x121) true)))
(let (($x1429 (or false false)))
(let (($x61 (or false $x1429 false)))
(and (not $x61) (or $x61 $x1203)))))))
(check-sat)
; query 10: function alaw_input, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x68 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x399 (or false false (or $x68))))
(and (not $x399) (or $x399 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 11: function alaw_input, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let ((?x528 (ite (= (_ bv4294967295 32) in.1_32) (_ bv1 1) (_ bv0 1))))
(let (($x67 (or false false false)))
(let (($x187 (not $x67)))
(and $x187 (or $x67 (and (distinct ?x528 ?x528) true)))))))
(check-sat)
; query 12: function gsm_L_add, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_64 () (_ BitVec 64))
(assert
 (let ((?x368 (bvsub (_ bv0 64) in13_64)))
(let ((?x619 ((_ sign_extend 1) ?x368)))
(let (($x127 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in13_64)) ?x619) true)))))
(and (not $x127) (or $x127 (and (distinct ?x368 ?x368) true)))))))
(check-sat)
; query 13: function gsm_L_add, block 16, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_64 () (_ BitVec 64))
(assert
 (let ((?x368 (bvsub (_ bv0 64) in13_64)))
(let ((?x72 (bvsub ?x368 (_ bv2 64))))
(let (($x321 (and (distinct (bvsub ((_ sign_extend 1) ?x368) ((_ sign_extend 1) (_ bv2 64))) ((_ sign_extend 1) ?x72)) true)))
(let ((?x619 ((_ sign_extend 1) ?x368)))
(let (($x127 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in13_64)) ?x619) true)))))
(let (($x661 (or $x127 false (or $x321))))
(and (not $x661) (or $x661 (and (distinct ?x72 ?x72) true))))))))))
(check-sat)
; query 14: function gsm_L_add, block 21, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x73 (ite (bvsge (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x67 (or false false false)))
(let (($x187 (not $x67)))
(and $x187 (or $x67 (and (distinct ?x73 ?x73) true)))))))
(check-sat)
; query 15: function gsm_L_add, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x227 (bvadd in0_64 in1_64)))
(let (($x94 (and (distinct ?x227 ?x227) true)))
(let (($x96 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) ?x227)) true)))
(let (($x42 (or false false (or $x96))))
(and (not $x42) (or $x42 $x94)))))))
(check-sat)
; query 16: function gsm_L_add, block 25, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x227 (bvadd in0_64 in1_64)))
(let (($x94 (and (distinct ?x227 ?x227) true)))
(let (($x67 (or false false false)))
(let (($x187 (not $x67)))
(and $x187 (or $x67 $x94)))))))
(check-sat)
; query 17: function gsm_L_add, block 25, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x386 (ite (bvugt (bvadd in0_64 in1_64) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x67 (or false false false)))
(let (($x48 (or $x67 false false)))
(let (($x17 (not $x48)))
(and $x17 (or $x48 (and (distinct ?x386 ?x386) true))))))))
(check-sat)
; query 18: function gsm_L_add, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x51 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x67 (or false false false)))
(let (($x187 (not $x67)))
(and $x187 (or $x67 (and (distinct ?x51 ?x51) true)))))))
(check-sat)
; query 19: function gsm_L_add, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x227 (bvadd in0_64 in1_64)))
(let (($x94 (and (distinct ?x227 ?x227) true)))
(let (($x96 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) ?x227)) true)))
(let (($x42 (or false false (or $x96))))
(and (not $x42) (or $x42 $x94)))))))
(check-sat)
; query 20: function gsm_L_add, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x614 (bvadd in0_64 (_ bv1 64))))
(let ((?x362 (bvsub (_ bv0 64) ?x614)))
(let (($x134 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x614)) ((_ sign_extend 1) ?x362)) true)))
(let ((?x296 ((_ sign_extend 1) ?x614)))
(let (($x432 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x296) true)))))
(let (($x151 (or false $x432 (or $x134))))
(and (not $x151) (or $x151 (and (distinct ?x362 ?x362) true))))))))))
(check-sat)
; query 21: function gsm_L_add, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x564 (bvadd in1_64 (_ bv1 64))))
(let ((?x983 ((_ sign_extend 1) ?x564)))
(let (($x21 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x983) true)))))
(and (not $x21) (or $x21 (and (distinct ?x564 ?x564) true)))))))
(check-sat)
; query 22: function gsm_L_add, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x564 (bvadd in1_64 (_ bv1 64))))
(let ((?x88 (bvsub (_ bv0 64) ?x564)))
(let (($x341 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x564)) ((_ sign_extend 1) ?x88)) true)))
(let ((?x983 ((_ sign_extend 1) ?x564)))
(let (($x21 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x983) true)))))
(let (($x520 (or false $x21 (or $x341))))
(and (not $x520) (or $x520 (and (distinct ?x88 ?x88) true))))))))))
(check-sat)
; query 23: function gsm_L_add, block 8, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x564 (bvadd in1_64 (_ bv1 64))))
(let ((?x88 (bvsub (_ bv0 64) ?x564)))
(let ((?x614 (bvadd in0_64 (_ bv1 64))))
(let ((?x362 (bvsub (_ bv0 64) ?x614)))
(let ((?x602 (bvadd ?x362 ?x88)))
(let (($x341 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x564)) ((_ sign_extend 1) ?x88)) true)))
(let ((?x983 ((_ sign_extend 1) ?x564)))
(let (($x21 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x983) true)))))
(let (($x520 (or false $x21 (or $x341))))
(let (($x134 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x614)) ((_ sign_extend 1) ?x362)) true)))
(let ((?x296 ((_ sign_extend 1) ?x614)))
(let (($x432 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x296) true)))))
(let (($x151 (or false $x432 (or $x134))))
(let (($x38 (or $x151 $x520 false)))
(and (not $x38) (or $x38 (and (distinct ?x602 ?x602) true))))))))))))))))))
(check-sat)
; query 24: function gsm_L_add, block 8, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x564 (bvadd in1_64 (_ bv1 64))))
(let ((?x88 (bvsub (_ bv0 64) ?x564)))
(let ((?x614 (bvadd in0_64 (_ bv1 64))))
(let ((?x362 (bvsub (_ bv0 64) ?x614)))
(let ((?x602 (bvadd ?x362 ?x88)))
(let ((?x1184 (ite (bvuge ?x602 (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x341 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x564)) ((_ sign_extend 1) ?x88)) true)))
(let ((?x983 ((_ sign_extend 1) ?x564)))
(let (($x21 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x983) true)))))
(let (($x520 (or false $x21 (or $x341))))
(let (($x134 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x614)) ((_ sign_extend 1) ?x362)) true)))
(let ((?x296 ((_ sign_extend 1) ?x614)))
(let (($x432 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x296) true)))))
(let (($x151 (or false $x432 (or $x134))))
(let (($x38 (or $x151 $x520 false)))
(let (($x132 (or $x38 false false)))
(and (not $x132) (or $x132 (and (distinct ?x1184 ?x1184) true))))))))))))))))))))
(check-sat)
; query 25: function gsm_L_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x614 (bvadd in0_64 (_ bv1 64))))
(let ((?x296 ((_ sign_extend 1) ?x614)))
(let (($x432 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x296) true)))))
(and (not $x432) (or $x432 (and (distinct ?x614 ?x614) true)))))))
(check-sat)
; query 26: function gsm_L_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1126 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x67 (or false false false)))
(let (($x187 (not $x67)))
(and $x187 (or $x67 (and (distinct ?x1126 ?x1126) true)))))))
(check-sat)
; query 27: function gsm_L_asl, block 12, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1059 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x67 (or false false false)))
(let (($x187 (not $x67)))
(and $x187 (or $x67 (and (distinct ?x1059 ?x1059) true)))))))
(check-sat)
; query 28: function gsm_L_asl, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x1429 (or false false)))
(let (($x430 (not $x1429)))
(and $x430 (or $x1429 (and (distinct ((_ zero_extend 32) in1_32) ((_ zero_extend 32) in1_32)) true))))))
(check-sat)
; query 29: function gsm_L_asl, block 17, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1282 ((_ zero_extend 32) in1_32)))
(let ((?x511 (bvshl in0_64 ?x1282)))
(let (($x1429 (or false false)))
(let (($x61 (or false $x1429 false)))
(let (($x1208 (or $x61 (bvuge ?x1282 (_ bv64 64)))))
(let (($x110 (not $x1208)))
(and $x110 (or $x1208 (and (distinct ?x511 ?x511) true))))))))))
(check-sat)
; query 30: function gsm_L_asl, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x77 (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x67 (or false false false)))
(let (($x187 (not $x67)))
(and $x187 (or $x67 (and (distinct ?x77 ?x77) true)))))))
(check-sat)
; query 31: function gsm_L_asl, block 7, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1126 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x145 ((_ zero_extend 31) ?x1126)))
(let ((?x1413 (bvsub (_ bv0 32) ?x145)))
(let (($x1338 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x145)) ((_ sign_extend 1) ?x1413)) true)))
(let (($x67 (or false false false)))
(let (($x1323 (or $x67 false)))
(let (($x1353 (or false $x1323 (or $x1338))))
(and (not $x1353) (or $x1353 (and (distinct ?x1413 ?x1413) true)))))))))))
(check-sat)
; query 32: function gsm_L_asl, block 7, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1126 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x145 ((_ zero_extend 31) ?x1126)))
(let ((?x1413 (bvsub (_ bv0 32) ?x145)))
(let ((?x1443 ((_ sign_extend 32) ?x1413)))
(let (($x1338 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x145)) ((_ sign_extend 1) ?x1413)) true)))
(let (($x67 (or false false false)))
(let (($x1323 (or $x67 false)))
(let (($x1353 (or false $x1323 (or $x1338))))
(let (($x1458 (or $x1353 false)))
(and (not $x1458) (or $x1458 (and (distinct ?x1443 ?x1443) true)))))))))))))
(check-sat)
; query 33: function gsm_L_asl, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1126 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x67 (or false false false)))
(let (($x187 (not $x67)))
(and $x187 (or $x67 (and (distinct ?x1126 ?x1126) true)))))))
(check-sat)
; query 34: function gsm_L_asl, block 7, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1126 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x145 ((_ zero_extend 31) ?x1126)))
(let (($x67 (or false false false)))
(let (($x1323 (or $x67 false)))
(and (not $x1323) (or $x1323 (and (distinct ?x145 ?x145) true))))))))
(check-sat)
; query 35: function gsm_L_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1549 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x67 (or false false false)))
(let (($x187 (not $x67)))
(and $x187 (or $x67 (and (distinct ?x1549 ?x1549) true)))))))
(check-sat)
; query 36: function gsm_L_asr, block 12, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1059 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x67 (or false false false)))
(let (($x187 (not $x67)))
(and $x187 (or $x67 (and (distinct ?x1059 ?x1059) true)))))))
(check-sat)
; query 37: function gsm_L_asr, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x875 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in1_32))) true)))
(let (($x352 (or false false (or $x875))))
(and (not $x352) (or $x352 (and (distinct (bvsub (_ bv0 32) in1_32) (bvsub (_ bv0 32) in1_32)) true))))))
(check-sat)
; query 38: function gsm_L_asr, block 14, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1444 (bvsub (_ bv0 32) in1_32)))
(let ((?x1955 ((_ zero_extend 32) ?x1444)))
(let (($x875 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x1444)) true)))
(let (($x352 (or false false (or $x875))))
(let (($x758 (or $x352 false)))
(and (not $x758) (or $x758 (and (distinct ?x1955 ?x1955) true)))))))))
(check-sat)
; query 39: function gsm_L_asr, block 14, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1444 (bvsub (_ bv0 32) in1_32)))
(let ((?x1955 ((_ zero_extend 32) ?x1444)))
(let ((?x1192 (bvshl in0_64 ?x1955)))
(let (($x875 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x1444)) true)))
(let (($x352 (or false false (or $x875))))
(let (($x758 (or $x352 false)))
(let (($x326 (or (or false $x758 false) (bvuge ?x1955 (_ bv64 64)))))
(and (not $x326) (or $x326 (and (distinct ?x1192 ?x1192) true)))))))))))
(check-sat)
; query 40: function gsm_L_asr, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x1429 (or false false)))
(let (($x430 (not $x1429)))
(and $x430 (or $x1429 (and (distinct ((_ zero_extend 32) in1_32) ((_ zero_extend 32) in1_32)) true))))))
(check-sat)
; query 41: function gsm_L_asr, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1282 ((_ zero_extend 32) in1_32)))
(let ((?x805 (bvashr in0_64 ?x1282)))
(let (($x1429 (or false false)))
(let (($x61 (or false $x1429 false)))
(let (($x1208 (or $x61 (bvuge ?x1282 (_ bv64 64)))))
(let (($x110 (not $x1208)))
(and $x110 (or $x1208 (and (distinct ?x805 ?x805) true))))))))))
(check-sat)
; query 42: function gsm_L_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1126 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x67 (or false false false)))
(let (($x187 (not $x67)))
(and $x187 (or $x67 (and (distinct ?x1126 ?x1126) true)))))))
(check-sat)
; query 43: function gsm_L_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1126 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x145 ((_ zero_extend 31) ?x1126)))
(let (($x67 (or false false false)))
(let (($x1323 (or $x67 false)))
(and (not $x1323) (or $x1323 (and (distinct ?x145 ?x145) true))))))))
(check-sat)
; query 44: function gsm_L_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1126 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x145 ((_ zero_extend 31) ?x1126)))
(let ((?x1413 (bvsub (_ bv0 32) ?x145)))
(let (($x1338 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x145)) ((_ sign_extend 1) ?x1413)) true)))
(let (($x67 (or false false false)))
(let (($x1323 (or $x67 false)))
(let (($x1353 (or false $x1323 (or $x1338))))
(and (not $x1353) (or $x1353 (and (distinct ?x1413 ?x1413) true)))))))))))
(check-sat)
; query 45: function gsm_L_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1126 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x145 ((_ zero_extend 31) ?x1126)))
(let ((?x1413 (bvsub (_ bv0 32) ?x145)))
(let ((?x1443 ((_ sign_extend 32) ?x1413)))
(let (($x1338 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x145)) ((_ sign_extend 1) ?x1413)) true)))
(let (($x67 (or false false false)))
(let (($x1323 (or $x67 false)))
(let (($x1353 (or false $x1323 (or $x1338))))
(let (($x1458 (or $x1353 false)))
(and (not $x1458) (or $x1458 (and (distinct ?x1443 ?x1443) true)))))))))))))
(check-sat)
; query 46: function gsm_L_asr, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x77 (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x67 (or false false false)))
(let (($x187 (not $x67)))
(and $x187 (or $x67 (and (distinct ?x77 ?x77) true)))))))
(check-sat)
; query 47: function gsm_L_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1549 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x67 (or false false false)))
(let (($x187 (not $x67)))
(and $x187 (or $x67 (and (distinct ?x1549 ?x1549) true)))))))
(check-sat)
; query 48: function gsm_L_mult, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x1429 (or false false)))
(let (($x430 (not $x1429)))
(and $x430 (or $x1429 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 49: function gsm_L_mult, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1210 (ite (and (distinct (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) true) (_ bv1 1) (_ bv0 1))))
(let (($x1429 (or false false)))
(let (($x24 (or $x1429 false false)))
(let (($x82 (not $x24)))
(and $x82 (or $x24 (and (distinct ?x1210 ?x1210) true))))))))
(check-sat)
; query 50: function gsm_L_mult, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x1429 (or false false)))
(let (($x430 (not $x1429)))
(and $x430 (or $x1429 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 51: function gsm_L_mult, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1179 (ite (and (distinct (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) true) (_ bv1 1) (_ bv0 1))))
(let (($x1429 (or false false)))
(let (($x24 (or $x1429 false false)))
(let (($x82 (not $x24)))
(and $x82 (or $x24 (and (distinct ?x1179 ?x1179) true))))))))
(check-sat)
; query 52: function gsm_L_sub, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in11_64 () (_ BitVec 64))
(assert
 (let (($x67 (or false false false)))
(let (($x187 (not $x67)))
(and $x187 (or $x67 (and (distinct (bvadd in11_64 (_ bv1 64)) (bvadd in11_64 (_ bv1 64))) true))))))
(check-sat)
; query 53: function gsm_L_sub, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x73 (ite (bvsge (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x67 (or false false false)))
(let (($x187 (not $x67)))
(and $x187 (or $x67 (and (distinct ?x73 ?x73) true)))))))
(check-sat)
; query 54: function gsm_L_sub, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x1294 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvsub in0_64 in1_64))) true)))
(let (($x1223 (or false false (or $x1294))))
(let (($x896 (or $x1223 (and (distinct (bvsub in0_64 in1_64) (bvsub in0_64 in1_64)) true))))
(and (not $x1223) $x896)))))
(check-sat)
; query 55: function gsm_L_sub, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x614 (bvadd in0_64 (_ bv1 64))))
(let ((?x296 ((_ sign_extend 1) ?x614)))
(let (($x432 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x296) true)))))
(and (not $x432) (or $x432 (and (distinct ?x614 ?x614) true)))))))
(check-sat)
; query 56: function gsm_L_sub, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x614 (bvadd in0_64 (_ bv1 64))))
(let ((?x362 (bvsub (_ bv0 64) ?x614)))
(let (($x134 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x614)) ((_ sign_extend 1) ?x362)) true)))
(let ((?x296 ((_ sign_extend 1) ?x614)))
(let (($x432 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x296) true)))))
(let (($x151 (or false $x432 (or $x134))))
(and (not $x151) (or $x151 (and (distinct ?x362 ?x362) true))))))))))
(check-sat)
; query 57: function gsm_L_sub, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x614 (bvadd in0_64 (_ bv1 64))))
(let ((?x362 (bvsub (_ bv0 64) ?x614)))
(let ((?x360 (bvadd ?x362 in1_64)))
(let (($x134 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x614)) ((_ sign_extend 1) ?x362)) true)))
(let ((?x296 ((_ sign_extend 1) ?x614)))
(let (($x432 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x296) true)))))
(let (($x151 (or false $x432 (or $x134))))
(let (($x1249 (or $x151 false false)))
(and (not $x1249) (or $x1249 (and (distinct ?x360 ?x360) true))))))))))))
(check-sat)
; query 58: function gsm_L_sub, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1269 (ite (bvuge (bvadd (bvsub (_ bv0 64) (bvadd in0_64 (_ bv1 64))) in1_64) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x134 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) (bvadd in0_64 (_ bv1 64)))) ((_ sign_extend 1) (bvsub (_ bv0 64) (bvadd in0_64 (_ bv1 64))))) true)))
(let ((?x614 (bvadd in0_64 (_ bv1 64))))
(let ((?x296 ((_ sign_extend 1) ?x614)))
(let (($x432 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x296) true)))))
(let (($x151 (or false $x432 (or $x134))))
(let (($x1249 (or $x151 false false)))
(let (($x1268 (or $x1249 false false)))
(and (not $x1268) (or $x1268 (and (distinct ?x1269 ?x1269) true))))))))))))
(check-sat)
; query 59: function gsm_L_sub, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_64 () (_ BitVec 64))
(assert
 (let ((?x1858 (bvsub (_ bv0 64) in25_64)))
(let ((?x743 ((_ sign_extend 1) ?x1858)))
(let (($x1819 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in25_64)) ?x743) true)))))
(and (not $x1819) (or $x1819 (and (distinct ?x1858 ?x1858) true)))))))
(check-sat)
; query 60: function gsm_L_sub, block 28, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_64 () (_ BitVec 64))
(assert
 (let ((?x1858 (bvsub (_ bv0 64) in25_64)))
(let ((?x105 (bvsub ?x1858 (_ bv1 64))))
(let (($x832 (and (distinct (bvsub ((_ sign_extend 1) ?x1858) ((_ sign_extend 1) (_ bv1 64))) ((_ sign_extend 1) ?x105)) true)))
(let ((?x743 ((_ sign_extend 1) ?x1858)))
(let (($x1819 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in25_64)) ?x743) true)))))
(let (($x922 (or $x1819 false (or $x832))))
(and (not $x922) (or $x922 (and (distinct ?x105 ?x105) true))))))))))
(check-sat)
; query 61: function gsm_L_sub, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x51 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x67 (or false false false)))
(let (($x187 (not $x67)))
(and $x187 (or $x67 (and (distinct ?x51 ?x51) true)))))))
(check-sat)
; query 62: function gsm_L_sub, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x1294 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvsub in0_64 in1_64))) true)))
(let (($x1223 (or false false (or $x1294))))
(let (($x896 (or $x1223 (and (distinct (bvsub in0_64 in1_64) (bvsub in0_64 in1_64)) true))))
(and (not $x1223) $x896)))))
(check-sat)
; query 63: function gsm_L_sub, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x564 (bvadd in1_64 (_ bv1 64))))
(let ((?x88 (bvsub (_ bv0 64) ?x564)))
(let (($x341 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x564)) ((_ sign_extend 1) ?x88)) true)))
(let ((?x983 ((_ sign_extend 1) ?x564)))
(let (($x21 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x983) true)))))
(let (($x520 (or false $x21 (or $x341))))
(and (not $x520) (or $x520 (and (distinct ?x88 ?x88) true))))))))))
(check-sat)
; query 64: function gsm_L_sub, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x564 (bvadd in1_64 (_ bv1 64))))
(let ((?x88 (bvsub (_ bv0 64) ?x564)))
(let ((?x1736 (bvadd in0_64 ?x88)))
(let (($x341 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x564)) ((_ sign_extend 1) ?x88)) true)))
(let ((?x983 ((_ sign_extend 1) ?x564)))
(let (($x21 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x983) true)))))
(let (($x520 (or false $x21 (or $x341))))
(let (($x1232 (or false $x520 false)))
(and (not $x1232) (or $x1232 (and (distinct ?x1736 ?x1736) true))))))))))))
(check-sat)
; query 65: function gsm_L_sub, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x442 (ite (bvuge (bvadd in0_64 (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64)))) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x341 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) (bvadd in1_64 (_ bv1 64)))) ((_ sign_extend 1) (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64))))) true)))
(let ((?x564 (bvadd in1_64 (_ bv1 64))))
(let ((?x983 ((_ sign_extend 1) ?x564)))
(let (($x21 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x983) true)))))
(let (($x520 (or false $x21 (or $x341))))
(let (($x1232 (or false $x520 false)))
(let (($x1705 (or $x1232 false false)))
(and (not $x1705) (or $x1705 (and (distinct ?x442 ?x442) true))))))))))))
(check-sat)
; query 66: function gsm_L_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x564 (bvadd in1_64 (_ bv1 64))))
(let ((?x983 ((_ sign_extend 1) ?x564)))
(let (($x21 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x983) true)))))
(and (not $x21) (or $x21 (and (distinct ?x564 ?x564) true)))))))
(check-sat)
; query 67: function gsm_L_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1748 (ite (bvsle (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x67 (or false false false)))
(let (($x187 (not $x67)))
(and $x187 (or $x67 (and (distinct ?x1748 ?x1748) true)))))))
(check-sat)
; query 68: function gsm_abs, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x1429 (or false false)))
(let (($x430 (not $x1429)))
(and $x430 (or $x1429 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 69: function gsm_abs, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1681 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1429 (or false false)))
(let (($x24 (or $x1429 false false)))
(let (($x82 (not $x24)))
(and $x82 (or $x24 (and (distinct ?x1681 ?x1681) true))))))))
(check-sat)
; query 70: function gsm_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_64 () (_ BitVec 64))
(assert
 (let ((?x1022 (ite (bvslt (_ bv32767 64) in5_64) (_ bv1 1) (_ bv0 1))))
(let (($x67 (or false false false)))
(let (($x187 (not $x67)))
(and $x187 (or $x67 (and (distinct ?x1022 ?x1022) true)))))))
(check-sat)
; query 71: function gsm_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x1429 (or false false)))
(let (($x430 (not $x1429)))
(and $x430 (or $x1429 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 72: function gsm_add, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x1429 (or false false)))
(let (($x430 (not $x1429)))
(and $x430 (or $x1429 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 73: function gsm_add, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x722 ((_ sign_extend 48) in1_16)))
(let ((?x403 ((_ sign_extend 48) in0_16)))
(let ((?x736 (bvadd ?x403 ?x722)))
(let (($x1070 (and (distinct (bvadd ((_ sign_extend 1) ?x403) ((_ sign_extend 1) ?x722)) ((_ sign_extend 1) ?x736)) true)))
(let (($x1429 (or false false)))
(let (($x886 (or $x1429 $x1429 (or $x1070))))
(and (not $x886) (or $x886 (and (distinct ?x736 ?x736) true))))))))))
(check-sat)
; query 74: function gsm_add, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1602 (ite (bvsgt (_ bv18446744073709518848 64) (bvadd ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x722 ((_ sign_extend 48) in1_16)))
(let ((?x962 ((_ sign_extend 1) ?x722)))
(let ((?x403 ((_ sign_extend 48) in0_16)))
(let ((?x1938 ((_ sign_extend 1) ?x403)))
(let (($x1429 (or false false)))
(let (($x886 (or $x1429 $x1429 (or (and (distinct (bvadd ?x1938 ?x962) ((_ sign_extend 1) (bvadd ?x403 ?x722))) true)))))
(let (($x1946 (or $x886 false false)))
(and (not $x1946) (or $x1946 (and (distinct ?x1602 ?x1602) true))))))))))))
(check-sat)
; query 75: function gsm_asl, block 13, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1059 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x67 (or false false false)))
(let (($x187 (not $x67)))
(and $x187 (or $x67 (and (distinct ?x1059 ?x1059) true)))))))
(check-sat)
; query 76: function gsm_asl, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x1429 (or false false)))
(let (($x430 (not $x1429)))
(and $x430 (or $x1429 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 77: function gsm_asl, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x781 ((_ sign_extend 16) in0_16)))
(let ((?x1978 (bvshl ?x781 in1_32)))
(let (($x1429 (or false false)))
(let (($x24 (or $x1429 false false)))
(let (($x750 (or $x24 (bvuge in1_32 (_ bv32 32)))))
(let (($x361 (not $x750)))
(and $x361 (or $x750 (and (distinct ?x1978 ?x1978) true))))))))))
(check-sat)
; query 78: function gsm_asl, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x781 ((_ sign_extend 16) in0_16)))
(let ((?x1978 (bvshl ?x781 in1_32)))
(let ((?x1660 ((_ extract 15 0) ?x1978)))
(let (($x1429 (or false false)))
(let (($x24 (or $x1429 false false)))
(let (($x750 (or $x24 (bvuge in1_32 (_ bv32 32)))))
(let (($x401 (or $x750 false)))
(let (($x357 (not $x401)))
(and $x357 (or $x401 (and (distinct ?x1660 ?x1660) true))))))))))))
(check-sat)
; query 79: function gsm_asl, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x316 (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x67 (or false false false)))
(let (($x187 (not $x67)))
(and $x187 (or $x67 (and (distinct ?x316 ?x316) true)))))))
(check-sat)
; query 80: function gsm_asl, block 7, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1681 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x184 ((_ zero_extend 31) ?x1681)))
(let (($x1429 (or false false)))
(let (($x24 (or $x1429 false false)))
(let (($x1993 (or $x24 false)))
(and (not $x1993) (or $x1993 (and (distinct ?x184 ?x184) true)))))))))
(check-sat)
; query 81: function gsm_asl, block 7, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1681 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x184 ((_ zero_extend 31) ?x1681)))
(let ((?x1189 (bvsub (_ bv0 32) ?x184)))
(let (($x1664 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x184)) ((_ sign_extend 1) ?x1189)) true)))
(let (($x1429 (or false false)))
(let (($x24 (or $x1429 false false)))
(let (($x1993 (or $x24 false)))
(let (($x478 (or false $x1993 (or $x1664))))
(and (not $x478) (or $x478 (and (distinct ?x1189 ?x1189) true))))))))))))
(check-sat)
; query 82: function gsm_asl, block 7, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1681 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x184 ((_ zero_extend 31) ?x1681)))
(let ((?x1189 (bvsub (_ bv0 32) ?x184)))
(let ((?x497 ((_ extract 15 0) ?x1189)))
(let (($x1664 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x184)) ((_ sign_extend 1) ?x1189)) true)))
(let (($x1429 (or false false)))
(let (($x24 (or $x1429 false false)))
(let (($x1993 (or $x24 false)))
(let (($x478 (or false $x1993 (or $x1664))))
(let (($x2018 (or $x478 false)))
(and (not $x2018) (or $x2018 (and (distinct ?x497 ?x497) true))))))))))))))
(check-sat)
; query 83: function gsm_asl, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x1429 (or false false)))
(let (($x430 (not $x1429)))
(and $x430 (or $x1429 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 84: function gsm_asl, block 7, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1681 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1429 (or false false)))
(let (($x24 (or $x1429 false false)))
(let (($x82 (not $x24)))
(and $x82 (or $x24 (and (distinct ?x1681 ?x1681) true))))))))
(check-sat)
; query 85: function gsm_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1667 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x67 (or false false false)))
(let (($x187 (not $x67)))
(and $x187 (or $x67 (and (distinct ?x1667 ?x1667) true)))))))
(check-sat)
; query 86: function gsm_asr, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x316 (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x67 (or false false false)))
(let (($x187 (not $x67)))
(and $x187 (or $x67 (and (distinct ?x316 ?x316) true)))))))
(check-sat)
; query 87: function gsm_asr, block 13, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1059 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x67 (or false false false)))
(let (($x187 (not $x67)))
(and $x187 (or $x67 (and (distinct ?x1059 ?x1059) true)))))))
(check-sat)
; query 88: function gsm_asr, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x1429 (or false false)))
(let (($x430 (not $x1429)))
(and $x430 (or $x1429 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 89: function gsm_asr, block 15, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x875 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in1_32))) true)))
(let (($x352 (or false false (or $x875))))
(and (not $x352) (or $x352 (and (distinct (bvsub (_ bv0 32) in1_32) (bvsub (_ bv0 32) in1_32)) true))))))
(check-sat)
; query 90: function gsm_asr, block 15, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1444 (bvsub (_ bv0 32) in1_32)))
(let ((?x781 ((_ sign_extend 16) in0_16)))
(let ((?x485 (bvshl ?x781 ?x1444)))
(let (($x875 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x1444)) true)))
(let (($x352 (or false false (or $x875))))
(let (($x1429 (or false false)))
(let (($x984 (or (or $x1429 $x352 false) (bvuge ?x1444 (_ bv32 32)))))
(and (not $x984) (or $x984 (and (distinct ?x485 ?x485) true)))))))))))
(check-sat)
; query 91: function gsm_asr, block 15, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1444 (bvsub (_ bv0 32) in1_32)))
(let ((?x781 ((_ sign_extend 16) in0_16)))
(let ((?x485 (bvshl ?x781 ?x1444)))
(let ((?x591 ((_ extract 15 0) ?x485)))
(let (($x875 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x1444)) true)))
(let (($x352 (or false false (or $x875))))
(let (($x1429 (or false false)))
(let (($x984 (or (or $x1429 $x352 false) (bvuge ?x1444 (_ bv32 32)))))
(let (($x749 (or $x984 false)))
(and (not $x749) (or $x749 (and (distinct ?x591 ?x591) true)))))))))))))
(check-sat)
; query 92: function gsm_asr, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x1429 (or false false)))
(let (($x430 (not $x1429)))
(and $x430 (or $x1429 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 93: function gsm_asr, block 20, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x781 ((_ sign_extend 16) in0_16)))
(let ((?x818 (bvashr ?x781 in1_32)))
(let (($x1429 (or false false)))
(let (($x24 (or $x1429 false false)))
(let (($x750 (or $x24 (bvuge in1_32 (_ bv32 32)))))
(let (($x361 (not $x750)))
(and $x361 (or $x750 (and (distinct ?x818 ?x818) true))))))))))
(check-sat)
; query 94: function gsm_asr, block 20, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x781 ((_ sign_extend 16) in0_16)))
(let ((?x818 (bvashr ?x781 in1_32)))
(let ((?x1580 ((_ extract 15 0) ?x818)))
(let (($x1429 (or false false)))
(let (($x24 (or $x1429 false false)))
(let (($x750 (or $x24 (bvuge in1_32 (_ bv32 32)))))
(let (($x401 (or $x750 false)))
(let (($x357 (not $x401)))
(and $x357 (or $x401 (and (distinct ?x1580 ?x1580) true))))))))))))
(check-sat)
; query 95: function gsm_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x1429 (or false false)))
(let (($x430 (not $x1429)))
(and $x430 (or $x1429 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 96: function gsm_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1681 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1429 (or false false)))
(let (($x24 (or $x1429 false false)))
(let (($x82 (not $x24)))
(and $x82 (or $x24 (and (distinct ?x1681 ?x1681) true))))))))
(check-sat)
; query 97: function gsm_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1681 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x184 ((_ zero_extend 31) ?x1681)))
(let (($x1429 (or false false)))
(let (($x24 (or $x1429 false false)))
(let (($x1993 (or $x24 false)))
(and (not $x1993) (or $x1993 (and (distinct ?x184 ?x184) true)))))))))
(check-sat)
; query 98: function gsm_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1681 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x184 ((_ zero_extend 31) ?x1681)))
(let ((?x1189 (bvsub (_ bv0 32) ?x184)))
(let (($x1664 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x184)) ((_ sign_extend 1) ?x1189)) true)))
(let (($x1429 (or false false)))
(let (($x24 (or $x1429 false false)))
(let (($x1993 (or $x24 false)))
(let (($x478 (or false $x1993 (or $x1664))))
(and (not $x478) (or $x478 (and (distinct ?x1189 ?x1189) true))))))))))))
(check-sat)
; query 99: function gsm_asr, block 4, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1681 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x184 ((_ zero_extend 31) ?x1681)))
(let ((?x1189 (bvsub (_ bv0 32) ?x184)))
(let ((?x497 ((_ extract 15 0) ?x1189)))
(let (($x1664 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x184)) ((_ sign_extend 1) ?x1189)) true)))
(let (($x1429 (or false false)))
(let (($x24 (or $x1429 false false)))
(let (($x1993 (or $x24 false)))
(let (($x478 (or false $x1993 (or $x1664))))
(let (($x2018 (or $x478 false)))
(and (not $x2018) (or $x2018 (and (distinct ?x497 ?x497) true))))))))))))))
(check-sat)
; query 100: function gsm_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1667 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x67 (or false false false)))
(let (($x187 (not $x67)))
(and $x187 (or $x67 (and (distinct ?x1667 ?x1667) true)))))))
(check-sat)
; query 101: function gsm_debug_longwords, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in15_32 () (_ BitVec 32))
(assert
 (let ((?x1622 (ite (bvslt in15_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x67 (or false false false)))
(let (($x187 (not $x67)))
(and $x187 (or $x67 (and (distinct ?x1622 ?x1622) true)))))))
(check-sat)
; query 102: function gsm_debug_words, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in16_32 () (_ BitVec 32))
(assert
 (let ((?x1589 (ite (bvslt in16_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x67 (or false false false)))
(let (($x187 (not $x67)))
(and $x187 (or $x67 (and (distinct ?x1589 ?x1589) true)))))))
(check-sat)
; query 103: function gsm_div, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x1429 (or false false)))
(let (($x430 (not $x1429)))
(and $x430 (or $x1429 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 104: function gsm_div, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x1429 (or false false)))
(let (($x430 (not $x1429)))
(and $x430 (or $x1429 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 105: function gsm_div, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x1429 (or false false)))
(let (($x430 (not $x1429)))
(and $x430 (or $x1429 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 106: function gsm_div, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x121 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1203 (and (distinct ?x121 ?x121) true)))
(let (($x1429 (or false false)))
(let (($x24 (or $x1429 false false)))
(let (($x82 (not $x24)))
(and $x82 (or $x24 $x1203))))))))
(check-sat)
; query 107: function gsm_mult, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x1429 (or false false)))
(let (($x430 (not $x1429)))
(and $x430 (or $x1429 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 108: function gsm_mult, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1568 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1429 (or false false)))
(let (($x24 (or $x1429 false false)))
(let (($x82 (not $x24)))
(and $x82 (or $x24 (and (distinct ?x1568 ?x1568) true))))))))
(check-sat)
; query 109: function gsm_mult, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x1429 (or false false)))
(let (($x430 (not $x1429)))
(and $x430 (or $x1429 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 110: function gsm_mult, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x1429 (or false false)))
(let (($x430 (not $x1429)))
(and $x430 (or $x1429 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 111: function gsm_mult, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x722 ((_ sign_extend 48) in1_16)))
(let ((?x403 ((_ sign_extend 48) in0_16)))
(let ((?x1077 (bvmul ?x403 ?x722)))
(let (($x1620 (and (distinct (bvmul ((_ sign_extend 64) ?x403) ((_ sign_extend 64) ?x722)) ((_ sign_extend 64) ?x1077)) true)))
(let (($x1429 (or false false)))
(let (($x275 (or $x1429 $x1429 (or $x1620))))
(and (not $x275) (or $x275 (and (distinct ?x1077 ?x1077) true))))))))))
(check-sat)
; query 112: function gsm_mult, block 9, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x722 ((_ sign_extend 48) in1_16)))
(let ((?x403 ((_ sign_extend 48) in0_16)))
(let ((?x1077 (bvmul ?x403 ?x722)))
(let ((?x680 (bvashr ?x1077 (_ bv15 64))))
(let (($x924 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1620 (and (distinct (bvmul ((_ sign_extend 64) ?x403) ((_ sign_extend 64) ?x722)) ((_ sign_extend 64) ?x1077)) true)))
(let (($x1429 (or false false)))
(let (($x275 (or $x1429 $x1429 (or $x1620))))
(let (($x643 (or (or $x275 false false) $x924)))
(and (not $x643) (or $x643 (and (distinct ?x680 ?x680) true)))))))))))))
(check-sat)
; query 113: function gsm_mult, block 9, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x722 ((_ sign_extend 48) in1_16)))
(let ((?x403 ((_ sign_extend 48) in0_16)))
(let ((?x1077 (bvmul ?x403 ?x722)))
(let ((?x680 (bvashr ?x1077 (_ bv15 64))))
(let ((?x371 ((_ extract 15 0) ?x680)))
(let (($x924 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1620 (and (distinct (bvmul ((_ sign_extend 64) ?x403) ((_ sign_extend 64) ?x722)) ((_ sign_extend 64) ?x1077)) true)))
(let (($x1429 (or false false)))
(let (($x275 (or $x1429 $x1429 (or $x1620))))
(let (($x643 (or (or $x275 false false) $x924)))
(let (($x981 (or $x643 false)))
(and (not $x981) (or $x981 (and (distinct ?x371 ?x371) true)))))))))))))))
(check-sat)
; query 114: function gsm_mult, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x1429 (or false false)))
(let (($x430 (not $x1429)))
(and $x430 (or $x1429 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 115: function gsm_mult, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x928 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1429 (or false false)))
(let (($x24 (or $x1429 false false)))
(let (($x82 (not $x24)))
(and $x82 (or $x24 (and (distinct ?x928 ?x928) true))))))))
(check-sat)
; query 116: function gsm_mult_r, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x1429 (or false false)))
(let (($x430 (not $x1429)))
(and $x430 (or $x1429 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 117: function gsm_mult_r, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x928 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1429 (or false false)))
(let (($x24 (or $x1429 false false)))
(let (($x82 (not $x24)))
(and $x82 (or $x24 (and (distinct ?x928 ?x928) true))))))))
(check-sat)
; query 118: function gsm_mult_r, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x1429 (or false false)))
(let (($x430 (not $x1429)))
(and $x430 (or $x1429 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 119: function gsm_mult_r, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x1429 (or false false)))
(let (($x430 (not $x1429)))
(and $x430 (or $x1429 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 120: function gsm_mult_r, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x722 ((_ sign_extend 48) in1_16)))
(let ((?x403 ((_ sign_extend 48) in0_16)))
(let ((?x1077 (bvmul ?x403 ?x722)))
(let (($x1620 (and (distinct (bvmul ((_ sign_extend 64) ?x403) ((_ sign_extend 64) ?x722)) ((_ sign_extend 64) ?x1077)) true)))
(let (($x1429 (or false false)))
(let (($x275 (or $x1429 $x1429 (or $x1620))))
(and (not $x275) (or $x275 (and (distinct ?x1077 ?x1077) true))))))))))
(check-sat)
; query 121: function gsm_mult_r, block 9, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x722 ((_ sign_extend 48) in1_16)))
(let ((?x403 ((_ sign_extend 48) in0_16)))
(let ((?x1077 (bvmul ?x403 ?x722)))
(let ((?x809 (bvadd ?x1077 (_ bv16384 64))))
(let (($x92 (and (distinct (bvadd ((_ sign_extend 1) ?x1077) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x809)) true)))
(let (($x1620 (and (distinct (bvmul ((_ sign_extend 64) ?x403) ((_ sign_extend 64) ?x722)) ((_ sign_extend 64) ?x1077)) true)))
(let (($x1429 (or false false)))
(let (($x275 (or $x1429 $x1429 (or $x1620))))
(let (($x1231 (or $x275 false (or $x92))))
(and (not $x1231) (or $x1231 (and (distinct ?x809 ?x809) true)))))))))))))
(check-sat)
; query 122: function gsm_mult_r, block 9, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x722 ((_ sign_extend 48) in1_16)))
(let ((?x403 ((_ sign_extend 48) in0_16)))
(let ((?x1077 (bvmul ?x403 ?x722)))
(let ((?x809 (bvadd ?x1077 (_ bv16384 64))))
(let ((?x1456 (bvashr ?x809 (_ bv15 64))))
(let (($x924 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x92 (and (distinct (bvadd ((_ sign_extend 1) ?x1077) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x809)) true)))
(let (($x1620 (and (distinct (bvmul ((_ sign_extend 64) ?x403) ((_ sign_extend 64) ?x722)) ((_ sign_extend 64) ?x1077)) true)))
(let (($x1429 (or false false)))
(let (($x275 (or $x1429 $x1429 (or $x1620))))
(let (($x1231 (or $x275 false (or $x92))))
(let (($x332 (or (or $x1231 false false) $x924)))
(and (not $x332) (or $x332 (and (distinct ?x1456 ?x1456) true))))))))))))))))
(check-sat)
; query 123: function gsm_mult_r, block 9, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x722 ((_ sign_extend 48) in1_16)))
(let ((?x403 ((_ sign_extend 48) in0_16)))
(let ((?x1077 (bvmul ?x403 ?x722)))
(let ((?x809 (bvadd ?x1077 (_ bv16384 64))))
(let ((?x1456 (bvashr ?x809 (_ bv15 64))))
(let ((?x1381 (bvand ?x1456 (_ bv65535 64))))
(let (($x924 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x92 (and (distinct (bvadd ((_ sign_extend 1) ?x1077) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x809)) true)))
(let (($x1620 (and (distinct (bvmul ((_ sign_extend 64) ?x403) ((_ sign_extend 64) ?x722)) ((_ sign_extend 64) ?x1077)) true)))
(let (($x1429 (or false false)))
(let (($x275 (or $x1429 $x1429 (or $x1620))))
(let (($x1231 (or $x275 false (or $x92))))
(let (($x332 (or (or $x1231 false false) $x924)))
(let (($x1501 (or $x332 false false)))
(and (not $x1501) (or $x1501 (and (distinct ?x1381 ?x1381) true))))))))))))))))))
(check-sat)
; query 124: function gsm_mult_r, block 9, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x722 ((_ sign_extend 48) in1_16)))
(let ((?x403 ((_ sign_extend 48) in0_16)))
(let ((?x1077 (bvmul ?x403 ?x722)))
(let ((?x809 (bvadd ?x1077 (_ bv16384 64))))
(let ((?x1456 (bvashr ?x809 (_ bv15 64))))
(let ((?x1381 (bvand ?x1456 (_ bv65535 64))))
(let ((?x1531 ((_ extract 15 0) ?x1381)))
(let (($x924 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x92 (and (distinct (bvadd ((_ sign_extend 1) ?x1077) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x809)) true)))
(let (($x1620 (and (distinct (bvmul ((_ sign_extend 64) ?x403) ((_ sign_extend 64) ?x722)) ((_ sign_extend 64) ?x1077)) true)))
(let (($x1429 (or false false)))
(let (($x275 (or $x1429 $x1429 (or $x1620))))
(let (($x1231 (or $x275 false (or $x92))))
(let (($x332 (or (or $x1231 false false) $x924)))
(let (($x1501 (or $x332 false false)))
(let (($x1454 (or $x1501 false)))
(and (not $x1454) (or $x1454 (and (distinct ?x1531 ?x1531) true))))))))))))))))))))
(check-sat)
; query 125: function gsm_mult_r, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x1429 (or false false)))
(let (($x430 (not $x1429)))
(and $x430 (or $x1429 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 126: function gsm_mult_r, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1568 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1429 (or false false)))
(let (($x24 (or $x1429 false false)))
(let (($x82 (not $x24)))
(and $x82 (or $x24 (and (distinct ?x1568 ?x1568) true))))))))
(check-sat)
; query 127: function gsm_norm, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1303 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x67 (or false false false)))
(let (($x187 (not $x67)))
(and $x187 (or $x67 (and (distinct ?x1303 ?x1303) true)))))))
(check-sat)
; query 128: function gsm_norm, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1303 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x1346 (bvxor ?x1303 (_ bv1 1))))
(let (($x67 (or false false false)))
(let (($x48 (or $x67 false false)))
(let (($x17 (not $x48)))
(and $x17 (or $x48 (and (distinct ?x1346 ?x1346) true)))))))))
(check-sat)
; query 129: function gsm_norm, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1303 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x1346 (bvxor ?x1303 (_ bv1 1))))
(let ((?x1316 ((_ zero_extend 31) ?x1346)))
(let (($x67 (or false false false)))
(let (($x48 (or $x67 false false)))
(let (($x1452 (or $x48 false)))
(and (not $x1452) (or $x1452 (and (distinct ?x1316 ?x1316) true))))))))))
(check-sat)
; query 130: function gsm_norm, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1303 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x1346 (bvxor ?x1303 (_ bv1 1))))
(let ((?x1316 ((_ zero_extend 31) ?x1346)))
(let ((?x1286 ((_ sign_extend 32) ?x1316)))
(let (($x67 (or false false false)))
(let (($x48 (or $x67 false false)))
(let (($x1452 (or $x48 false)))
(let (($x1513 (or $x1452 false)))
(and (not $x1513) (or $x1513 (and (distinct ?x1286 ?x1286) true))))))))))))
(check-sat)
; query 131: function gsm_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_64 () (_ BitVec 64))
(assert
 (let ((?x1022 (ite (bvslt (_ bv32767 64) in5_64) (_ bv1 1) (_ bv0 1))))
(let (($x67 (or false false false)))
(let (($x187 (not $x67)))
(and $x187 (or $x67 (and (distinct ?x1022 ?x1022) true)))))))
(check-sat)
; query 132: function gsm_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x1429 (or false false)))
(let (($x430 (not $x1429)))
(and $x430 (or $x1429 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 133: function gsm_sub, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x1429 (or false false)))
(let (($x430 (not $x1429)))
(and $x430 (or $x1429 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 134: function gsm_sub, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x722 ((_ sign_extend 48) in1_16)))
(let ((?x403 ((_ sign_extend 48) in0_16)))
(let ((?x1483 (bvsub ?x403 ?x722)))
(let (($x1234 (and (distinct (bvsub ((_ sign_extend 1) ?x403) ((_ sign_extend 1) ?x722)) ((_ sign_extend 1) ?x1483)) true)))
(let (($x1429 (or false false)))
(let (($x807 (or $x1429 $x1429 (or $x1234))))
(and (not $x807) (or $x807 (and (distinct ?x1483 ?x1483) true))))))))))
(check-sat)
; query 135: function gsm_sub, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x34 (ite (bvsgt (_ bv18446744073709518848 64) (bvsub ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x722 ((_ sign_extend 48) in1_16)))
(let ((?x962 ((_ sign_extend 1) ?x722)))
(let ((?x403 ((_ sign_extend 48) in0_16)))
(let ((?x1938 ((_ sign_extend 1) ?x403)))
(let (($x1429 (or false false)))
(let (($x807 (or $x1429 $x1429 (or (and (distinct (bvsub ?x1938 ?x962) ((_ sign_extend 1) (bvsub ?x403 ?x722))) true)))))
(let (($x382 (or $x807 false false)))
(and (not $x382) (or $x382 (and (distinct ?x34 ?x34) true))))))))))))
(check-sat)
; query 136: function ok_to_replace, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x219 (ite (and (distinct (_ bv4294967295 32) in.01_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x67 (or false false false)))
(let (($x187 (not $x67)))
(and $x187 (or $x67 (and (distinct ?x219 ?x219) true)))))))
(check-sat)
; query 137: function ok_to_replace, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in16_32 () (_ BitVec 32))
(assert
 (let ((?x160 (ite (= (_ bv121 32) in16_32) (_ bv1 1) (_ bv0 1))))
(let (($x67 (or false false false)))
(let (($x187 (not $x67)))
(and $x187 (or $x67 (and (distinct ?x160 ?x160) true)))))))
(check-sat)
; query 138: function suffix, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_64 () (_ BitVec 64))
(declare-fun in3_64 () (_ BitVec 64))
(assert
 (let ((?x1142 (ite (bvule in3_64 in4_64) (_ bv1 1) (_ bv0 1))))
(let (($x67 (or false false false)))
(let (($x187 (not $x67)))
(and $x187 (or $x67 (and (distinct ?x1142 ?x1142) true)))))))
(check-sat)
; query 139: function ulaw_input, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x68 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x399 (or false false (or $x68))))
(and (not $x399) (or $x399 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 140: function ulaw_input, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let ((?x528 (ite (= (_ bv4294967295 32) in.1_32) (_ bv1 1) (_ bv0 1))))
(let (($x67 (or false false false)))
(let (($x187 (not $x67)))
(and $x187 (or $x67 (and (distinct ?x528 ?x528) true)))))))
(check-sat)
