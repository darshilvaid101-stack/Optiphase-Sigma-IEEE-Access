; OptiPhase-Sigma refinement certificate for sweep K59-R3-265
; query 0: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x1923 (or false false false)))
(let (($x104 (not $x1923)))
(and $x104 (or $x1923 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x225 (bvadd in.01_32 (_ bv1 32))))
(let ((?x409 (bvmul ?x225 ?x225)))
(let (($x1923 (or false false false)))
(let (($x666 (or $x1923 $x1923 false)))
(and (not $x666) (or $x666 (and (distinct ?x409 ?x409) true))))))))
(check-sat)
; query 2: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x225 (bvadd in.01_32 (_ bv1 32))))
(let ((?x409 (bvmul ?x225 ?x225)))
(let ((?x57 (bvmul ?x409 (_ bv2 32))))
(let (($x1923 (or false false false)))
(let (($x666 (or $x1923 $x1923 false)))
(let (($x106 (or $x666 false false)))
(and (not $x106) (or $x106 (and (distinct ?x57 ?x57) true))))))))))
(check-sat)
; query 3: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x225 (bvadd in.01_32 (_ bv1 32))))
(let ((?x409 (bvmul ?x225 ?x225)))
(let ((?x57 (bvmul ?x409 (_ bv2 32))))
(let ((?x121 (bvmul ?x57 (_ bv4 32))))
(let (($x1923 (or false false false)))
(let (($x666 (or $x1923 $x1923 false)))
(let (($x106 (or $x666 false false)))
(let (($x1528 (or $x106 false false)))
(and (not $x1528) (or $x1528 (and (distinct ?x121 ?x121) true))))))))))))
(check-sat)
; query 4: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x48 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x1923 (or false false false)))
(let (($x104 (not $x1923)))
(and $x104 (or $x1923 (and (distinct ?x48 ?x48) true)))))))
(check-sat)
; query 5: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x67 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x1923 (or false false false)))
(let (($x104 (not $x1923)))
(and $x104 (or $x1923 (and (distinct ?x67 ?x67) true)))))))
(check-sat)
; query 6: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x1923 (or false false false)))
(let (($x104 (not $x1923)))
(and $x104 (or $x1923 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 7: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x192 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x156 (or false false (or $x192))))
(and (not $x156) (or $x156 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x265 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x1923 (or false false false)))
(let (($x104 (not $x1923)))
(and $x104 (or $x1923 (and (distinct ?x265 ?x265) true)))))))
(check-sat)
; query 9: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x586 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x1923 (or false false false)))
(let (($x104 (not $x1923)))
(and $x104 (or $x1923 (and (distinct ?x586 ?x586) true)))))))
(check-sat)
; query 10: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x40 (or false false)))
(and (not $x40) (or $x40 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true)))))
(check-sat)
; query 11: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x1389 ((_ sign_extend 16) in.1_16)))
(let ((?x2078 (bvadd ?x1389 (_ bv10 32))))
(let (($x2851 (and (distinct (bvadd ((_ sign_extend 1) ?x1389) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x2078)) true)))
(let (($x40 (or false false)))
(let (($x44 (or $x40 false (or $x2851))))
(and (not $x44) (or $x44 (and (distinct ?x2078 ?x2078) true)))))))))
(check-sat)
; query 12: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x1389 ((_ sign_extend 16) in.1_16)))
(let ((?x2078 (bvadd ?x1389 (_ bv10 32))))
(let ((?x6389 ((_ extract 15 0) ?x2078)))
(let (($x2851 (and (distinct (bvadd ((_ sign_extend 1) ?x1389) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x2078)) true)))
(let (($x40 (or false false)))
(let (($x44 (or $x40 false (or $x2851))))
(let (($x2768 (or $x44 false)))
(and (not $x2768) (or $x2768 (and (distinct ?x6389 ?x6389) true)))))))))))
(check-sat)
; query 13: function matrix_sum, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x980 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x1923 (or false false false)))
(let (($x104 (not $x1923)))
(and $x104 (or $x1923 (and (distinct ?x980 ?x980) true)))))))
(check-sat)
; query 14: function matrix_sum, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x980 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let ((?x3043 ((_ zero_extend 63) ?x980)))
(let (($x1923 (or false false false)))
(let (($x112 (or $x1923 false)))
(and (not $x112) (or $x112 (and (distinct ?x3043 ?x3043) true))))))))
(check-sat)
; query 15: function matrix_sum, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x980 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x103 (= (_ bv1 1) ?x980)))
(let ((?x9 (ite $x103 (_ bv1 32) (_ bv0 32))))
(let (($x1923 (or false false false)))
(let (($x96 (or $x1923 (ite $x103 false false))))
(and (not $x96) (or $x96 (and (distinct ?x9 ?x9) true)))))))))
(check-sat)
; query 16: function matrix_sum, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x40 (or false false)))
(and (not $x40) (or $x40 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true)))))
(check-sat)
; query 17: function matrix_sum, block 22, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x980 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x103 (= (_ bv1 1) ?x980)))
(let ((?x9 (ite $x103 (_ bv1 32) (_ bv0 32))))
(let ((?x1389 ((_ sign_extend 16) in.1_16)))
(let ((?x1446 (bvadd ?x1389 ?x9)))
(let (($x234 (and (distinct (bvadd ((_ sign_extend 1) ?x1389) ((_ sign_extend 1) ?x9)) ((_ sign_extend 1) ?x1446)) true)))
(let (($x1923 (or false false false)))
(let (($x96 (or $x1923 (ite $x103 false false))))
(let (($x40 (or false false)))
(let (($x101 (or $x40 $x96 (or $x234))))
(and (not $x101) (or $x101 (and (distinct ?x1446 ?x1446) true))))))))))))))
(check-sat)
; query 18: function matrix_sum, block 22, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x980 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x103 (= (_ bv1 1) ?x980)))
(let ((?x9 (ite $x103 (_ bv1 32) (_ bv0 32))))
(let ((?x1389 ((_ sign_extend 16) in.1_16)))
(let ((?x1446 (bvadd ?x1389 ?x9)))
(let ((?x158 ((_ extract 15 0) ?x1446)))
(let (($x234 (and (distinct (bvadd ((_ sign_extend 1) ?x1389) ((_ sign_extend 1) ?x9)) ((_ sign_extend 1) ?x1446)) true)))
(let (($x1923 (or false false false)))
(let (($x96 (or $x1923 (ite $x103 false false))))
(let (($x40 (or false false)))
(let (($x101 (or $x40 $x96 (or $x234))))
(let (($x1787 (or $x101 false)))
(and (not $x1787) (or $x1787 (and (distinct ?x158 ?x158) true))))))))))))))))
(check-sat)
