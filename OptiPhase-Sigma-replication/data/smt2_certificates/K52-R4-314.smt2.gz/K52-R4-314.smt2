; OptiPhase-Sigma refinement certificate for sweep K52-R4-314
; query 0: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x871 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x443 (or false false false)))
(let (($x181 (not $x443)))
(and $x181 (or $x443 (and (distinct ?x871 ?x871) true)))))))
(check-sat)
; query 1: function s162, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x290 (ite (bvslt (_ bv0 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x443 (or false false false)))
(let (($x181 (not $x443)))
(and $x181 (or $x443 (and (distinct ?x290 ?x290) true)))))))
(check-sat)
