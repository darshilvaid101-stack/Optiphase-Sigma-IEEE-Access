; OptiPhase-Sigma refinement certificate for sweep K20-R3-145
