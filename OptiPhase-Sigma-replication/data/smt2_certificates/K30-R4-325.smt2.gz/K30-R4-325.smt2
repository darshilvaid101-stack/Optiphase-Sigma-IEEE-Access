; OptiPhase-Sigma refinement certificate for sweep K30-R4-325
; query 0: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x630 (ite (bvsgt (_ bv2 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x200 (or false false false)))
(and (not $x200) (or $x200 (and (distinct ?x630 ?x630) true))))))
(check-sat)
