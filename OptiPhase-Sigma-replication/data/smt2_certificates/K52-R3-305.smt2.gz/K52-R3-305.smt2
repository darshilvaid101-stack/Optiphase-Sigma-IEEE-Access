; OptiPhase-Sigma refinement certificate for sweep K52-R3-305
; query 0: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x216 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x1389 (or false false false)))
(let (($x57 (not $x1389)))
(and $x57 (or $x1389 (and (distinct ?x216 ?x216) true)))))))
(check-sat)
; query 1: function s162, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x1566 (ite (bvslt (_ bv0 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x1389 (or false false false)))
(let (($x57 (not $x1389)))
(and $x57 (or $x1389 (and (distinct ?x1566 ?x1566) true)))))))
(check-sat)
; query 2: function s276, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1658 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x1446 (or false false (or $x1658))))
(and (not $x1446) (or $x1446 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 3: function s276, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x145 (ite (bvsgt (_ bv16000 32) (bvadd in.0_32 (_ bv1 32))) (_ bv1 1) (_ bv0 1))))
(let (($x1658 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x1446 (or false false (or $x1658))))
(let (($x1787 (or $x1446 false false)))
(and (not $x1787) (or $x1787 (and (distinct ?x145 ?x145) true))))))))
(check-sat)
; query 4: function set1d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x3581 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x1389 (or false false false)))
(let (($x57 (not $x1389)))
(and $x57 (or $x1389 (and (distinct ?x3581 ?x3581) true)))))))
(check-sat)
; query 5: function set1ds, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x43 (ite (= (_ bv4294967295 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x1389 (or false false false)))
(let (($x57 (not $x1389)))
(and $x57 (or $x1389 (and (distinct ?x43 ?x43) true)))))))
(check-sat)
; query 6: function set2d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x3581 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x1389 (or false false false)))
(let (($x57 (not $x1389)))
(and $x57 (or $x1389 (and (distinct ?x3581 ?x3581) true)))))))
(check-sat)
