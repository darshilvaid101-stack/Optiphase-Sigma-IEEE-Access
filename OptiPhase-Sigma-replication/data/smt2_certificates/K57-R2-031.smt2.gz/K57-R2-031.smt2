; OptiPhase-Sigma refinement certificate for sweep K57-R2-031
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x311 (not $x64)))
(and $x311 (or $x64 (and (distinct ((_ sign_extend 16) in25_16) ((_ sign_extend 16) in25_16)) true))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let ((?x1856 (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x1968 (or $x64 false false)))
(let (($x86 (not $x1968)))
(and $x86 (or $x1968 (and (distinct ?x1856 ?x1856) true))))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x311 (not $x64)))
(and $x311 (or $x64 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x628 ((_ sign_extend 16) in3_16)))
(let ((?x1380 (bvand ?x628 (_ bv127 32))))
(let (($x64 (or false false)))
(let (($x1968 (or $x64 false false)))
(let (($x86 (not $x1968)))
(and $x86 (or $x1968 (and (distinct ?x1380 ?x1380) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x628 ((_ sign_extend 16) in3_16)))
(let ((?x1380 (bvand ?x628 (_ bv127 32))))
(let ((?x744 ((_ extract 15 0) ?x1380)))
(let (($x64 (or false false)))
(let (($x1968 (or $x64 false false)))
(let (($x43 (or $x1968 false)))
(let (($x71 (not $x43)))
(and $x71 (or $x43 (and (distinct ?x744 ?x744) true)))))))))))
(check-sat)
; query 5: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x64 (or false false)))
(let (($x311 (not $x64)))
(and $x311 (or $x64 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 6: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x1039 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x1968 (or $x64 false false)))
(let (($x86 (not $x1968)))
(and $x86 (or $x1968 (and (distinct ?x1039 ?x1039) true))))))))
(check-sat)
; query 7: function core_bench_list, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x191 (or false false false)))
(let (($x48 (not $x191)))
(and $x48 (or $x191 (and (distinct (bvadd in.0_16 (_ bv1 16)) (bvadd in.0_16 (_ bv1 16))) true))))))
(check-sat)
; query 8: function core_bench_list, block 82, name %83
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x311 (not $x64)))
(and $x311 (or $x64 (and (distinct ((_ zero_extend 16) in.02_16) ((_ zero_extend 16) in.02_16)) true))))))
(check-sat)
; query 9: function core_bench_list, block 82, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x127 ((_ zero_extend 16) in.02_16)))
(let ((?x882 (bvmul ?x127 (_ bv4 32))))
(let (($x536 (and (distinct (bvmul ((_ sign_extend 32) ?x127) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x882)) true)))
(let (($x64 (or false false)))
(let (($x200 (or $x64 false (or $x536))))
(and (not $x200) (or $x200 (and (distinct ?x882 ?x882) true)))))))))
(check-sat)
; query 10: function core_bench_list, block 82, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x311 (not $x64)))
(and $x311 (or $x64 (and (distinct ((_ zero_extend 16) in.04_16) ((_ zero_extend 16) in.04_16)) true))))))
(check-sat)
; query 11: function core_bench_list, block 82, name %86
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x6691 ((_ zero_extend 16) in.04_16)))
(let ((?x127 ((_ zero_extend 16) in.02_16)))
(let ((?x882 (bvmul ?x127 (_ bv4 32))))
(let ((?x338 (bvsub ?x882 ?x6691)))
(let ((?x3821 ((_ sign_extend 1) ?x338)))
(let (($x64 (or false false)))
(let (($x536 (and (distinct (bvmul ((_ sign_extend 32) ?x127) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x882)) true)))
(let (($x200 (or $x64 false (or $x536))))
(let (($x107 (or $x200 $x64 (or (and (distinct (bvsub ((_ sign_extend 1) ?x882) ((_ sign_extend 1) ?x6691)) ?x3821) true)))))
(and (not $x107) (or $x107 (and (distinct ?x338 ?x338) true)))))))))))))
(check-sat)
; query 12: function core_bench_list, block 82, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x311 (not $x64)))
(and $x311 (or $x64 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 13: function core_bench_list, block 82, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x6691 ((_ zero_extend 16) in.04_16)))
(let ((?x127 ((_ zero_extend 16) in.02_16)))
(let ((?x882 (bvmul ?x127 (_ bv4 32))))
(let ((?x338 (bvsub ?x882 ?x6691)))
(let ((?x820 ((_ zero_extend 16) in.01_16)))
(let ((?x151 (bvadd ?x820 ?x338)))
(let (($x84 (and (distinct (bvadd ((_ sign_extend 1) ?x820) ((_ sign_extend 1) ?x338)) ((_ sign_extend 1) ?x151)) true)))
(let ((?x3821 ((_ sign_extend 1) ?x338)))
(let (($x64 (or false false)))
(let (($x536 (and (distinct (bvmul ((_ sign_extend 32) ?x127) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x882)) true)))
(let (($x200 (or $x64 false (or $x536))))
(let (($x107 (or $x200 $x64 (or (and (distinct (bvsub ((_ sign_extend 1) ?x882) ((_ sign_extend 1) ?x6691)) ?x3821) true)))))
(let (($x742 (or $x64 $x107 (or $x84))))
(and (not $x742) (or $x742 (and (distinct ?x151 ?x151) true)))))))))))))))))
(check-sat)
; query 14: function core_bench_list, block 82, name %89
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x6691 ((_ zero_extend 16) in.04_16)))
(let ((?x127 ((_ zero_extend 16) in.02_16)))
(let ((?x882 (bvmul ?x127 (_ bv4 32))))
(let ((?x338 (bvsub ?x882 ?x6691)))
(let ((?x820 ((_ zero_extend 16) in.01_16)))
(let ((?x151 (bvadd ?x820 ?x338)))
(let ((?x1532 ((_ extract 15 0) ?x151)))
(let (($x84 (and (distinct (bvadd ((_ sign_extend 1) ?x820) ((_ sign_extend 1) ?x338)) ((_ sign_extend 1) ?x151)) true)))
(let ((?x3821 ((_ sign_extend 1) ?x338)))
(let (($x64 (or false false)))
(let (($x536 (and (distinct (bvmul ((_ sign_extend 32) ?x127) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x882)) true)))
(let (($x200 (or $x64 false (or $x536))))
(let (($x107 (or $x200 $x64 (or (and (distinct (bvsub ((_ sign_extend 1) ?x882) ((_ sign_extend 1) ?x6691)) ?x3821) true)))))
(let (($x742 (or $x64 $x107 (or $x84))))
(let (($x816 (or $x742 false)))
(and (not $x816) (or $x816 (and (distinct ?x1532 ?x1532) true)))))))))))))))))))
(check-sat)
; query 15: function core_bench_list, block 82, name %90
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x311 (not $x64)))
(and $x311 (or $x64 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 16: function core_bench_list, block 82, name %91
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x687 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x1968 (or $x64 false false)))
(let (($x86 (not $x1968)))
(and $x86 (or $x1968 (and (distinct ?x687 ?x687) true))))))))
(check-sat)
; query 17: function core_bench_state, block 105, name %106
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x191 (or false false false)))
(let (($x48 (not $x191)))
(and $x48 (or $x191 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 18: function core_bench_state, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x191 (or false false false)))
(let (($x48 (not $x191)))
(and $x48 (or $x191 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 19: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x41 (bvadd in.01_32 (_ bv1 32))))
(let (($x68 (and (distinct ?x41 ?x41) true)))
(let (($x191 (or false false false)))
(let (($x48 (not $x191)))
(and $x48 (or $x191 $x68)))))))
(check-sat)
; query 20: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x41 (bvadd in.01_32 (_ bv1 32))))
(let ((?x116 (bvmul ?x41 ?x41)))
(let (($x191 (or false false false)))
(let (($x444 (or $x191 $x191 false)))
(and (not $x444) (or $x444 (and (distinct ?x116 ?x116) true))))))))
(check-sat)
; query 21: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x41 (bvadd in.01_32 (_ bv1 32))))
(let ((?x116 (bvmul ?x41 ?x41)))
(let ((?x652 (bvmul ?x116 (_ bv2 32))))
(let (($x191 (or false false false)))
(let (($x444 (or $x191 $x191 false)))
(let (($x7 (or $x444 false false)))
(and (not $x7) (or $x7 (and (distinct ?x652 ?x652) true))))))))))
(check-sat)
; query 22: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x41 (bvadd in.01_32 (_ bv1 32))))
(let ((?x116 (bvmul ?x41 ?x41)))
(let ((?x652 (bvmul ?x116 (_ bv2 32))))
(let ((?x546 (bvmul ?x652 (_ bv4 32))))
(let (($x191 (or false false false)))
(let (($x444 (or $x191 $x191 false)))
(let (($x7 (or $x444 false false)))
(let (($x73 (or $x7 false false)))
(and (not $x73) (or $x73 (and (distinct ?x546 ?x546) true))))))))))))
(check-sat)
; query 23: function core_init_matrix, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x191 (or false false false)))
(let (($x48 (not $x191)))
(and $x48 (or $x191 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 24: function core_init_matrix, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x191 (or false false false)))
(let (($x48 (not $x191)))
(and $x48 (or $x191 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 25: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x1226 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x191 (or false false false)))
(let (($x48 (not $x191)))
(and $x48 (or $x191 (and (distinct ?x1226 ?x1226) true)))))))
(check-sat)
; query 26: function core_init_state, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_32 () (_ BitVec 32))
(assert
 (let (($x191 (or false false false)))
(let (($x48 (not $x191)))
(and $x48 (or $x191 (and (distinct (bvadd in.06_32 (_ bv1 32)) (bvadd in.06_32 (_ bv1 32))) true))))))
(check-sat)
; query 27: function core_init_state, block 65, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let (($x191 (or false false false)))
(let (($x48 (not $x191)))
(and $x48 (or $x191 (and (distinct (bvadd in4_32 (_ bv1 32)) (bvadd in4_32 (_ bv1 32))) true))))))
(check-sat)
; query 28: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x602 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x191 (or false false false)))
(let (($x48 (not $x191)))
(and $x48 (or $x191 (and (distinct ?x602 ?x602) true)))))))
(check-sat)
; query 29: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x191 (or false false false)))
(let (($x48 (not $x191)))
(and $x48 (or $x191 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 30: function core_list_init, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x41 (bvadd in.01_32 (_ bv1 32))))
(let (($x68 (and (distinct ?x41 ?x41) true)))
(let (($x191 (or false false false)))
(let (($x48 (not $x191)))
(and $x48 (or $x191 $x68)))))))
(check-sat)
; query 31: function core_list_mergesort, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x41 (bvadd in.01_32 (_ bv1 32))))
(let (($x68 (and (distinct ?x41 ?x41) true)))
(let (($x5696 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x41)) true)))
(let (($x5295 (or false false (or $x5696))))
(and (not $x5295) (or $x5295 $x68)))))))
(check-sat)
; query 32: function core_list_mergesort, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x4142 (ite (bvslt (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x191 (or false false false)))
(let (($x48 (not $x191)))
(and $x48 (or $x191 (and (distinct ?x4142 ?x4142) true)))))))
(check-sat)
; query 33: function core_list_mergesort, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.224_32 () (_ BitVec 32))
(assert
 (let ((?x4346 (ite (= (_ bv0 32) in.224_32) (_ bv1 1) (_ bv0 1))))
(let (($x191 (or false false false)))
(let (($x48 (not $x191)))
(and $x48 (or $x191 (and (distinct ?x4346 ?x4346) true)))))))
(check-sat)
; query 34: function core_list_mergesort, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x262 (ite (= (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x191 (or false false false)))
(let (($x48 (not $x191)))
(and $x48 (or $x191 (and (distinct ?x262 ?x262) true)))))))
(check-sat)
; query 35: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x4091 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x5422 (or false false (or $x4091))))
(and (not $x5422) (or $x5422 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 36: function core_list_mergesort, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x6129 (and (distinct (bvmul ((_ sign_extend 32) in.020_32) ((_ sign_extend 32) (_ bv2 32))) ((_ sign_extend 32) (bvmul in.020_32 (_ bv2 32)))) true)))
(let (($x7789 (or false false (or $x6129))))
(and (not $x7789) (or $x7789 (and (distinct (bvmul in.020_32 (_ bv2 32)) (bvmul in.020_32 (_ bv2 32))) true))))))
(check-sat)
; query 37: function core_state_transition, block 102, name %103
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x64 (or false false)))
(let (($x311 (not $x64)))
(and $x311 (or $x64 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 38: function core_state_transition, block 102, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x4699 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x1968 (or $x64 false false)))
(let (($x86 (not $x1968)))
(and $x86 (or $x1968 (and (distinct ?x4699 ?x4699) true))))))))
(check-sat)
; query 39: function core_state_transition, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x64 (or false false)))
(let (($x311 (not $x64)))
(and $x311 (or $x64 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 40: function core_state_transition, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x2693 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x1968 (or $x64 false false)))
(let (($x86 (not $x1968)))
(and $x86 (or $x1968 (and (distinct ?x2693 ?x2693) true))))))))
(check-sat)
; query 41: function core_state_transition, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x64 (or false false)))
(let (($x311 (not $x64)))
(and $x311 (or $x64 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 42: function core_state_transition, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x4699 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x1968 (or $x64 false false)))
(let (($x86 (not $x1968)))
(and $x86 (or $x1968 (and (distinct ?x4699 ?x4699) true))))))))
(check-sat)
; query 43: function core_state_transition, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x64 (or false false)))
(let (($x311 (not $x64)))
(and $x311 (or $x64 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 44: function core_state_transition, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x2742 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x1968 (or $x64 false false)))
(let (($x86 (not $x1968)))
(and $x86 (or $x1968 (and (distinct ?x2742 ?x2742) true))))))))
(check-sat)
; query 45: function core_state_transition, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x64 (or false false)))
(let (($x311 (not $x64)))
(and $x311 (or $x64 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 46: function core_state_transition, block 51, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x2742 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x1968 (or $x64 false false)))
(let (($x86 (not $x1968)))
(and $x86 (or $x1968 (and (distinct ?x2742 ?x2742) true))))))))
(check-sat)
; query 47: function core_state_transition, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x64 (or false false)))
(let (($x311 (not $x64)))
(and $x311 (or $x64 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 48: function core_state_transition, block 64, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x2742 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x1968 (or $x64 false false)))
(let (($x86 (not $x1968)))
(and $x86 (or $x1968 (and (distinct ?x2742 ?x2742) true))))))))
(check-sat)
; query 49: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x3698 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x191 (or false false false)))
(let (($x48 (not $x191)))
(and $x48 (or $x191 (and (distinct ?x3698 ?x3698) true)))))))
(check-sat)
; query 50: function core_state_transition, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x64 (or false false)))
(let (($x311 (not $x64)))
(and $x311 (or $x64 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 51: function core_state_transition, block 80, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x6322 (ite (= (_ bv69 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x1968 (or $x64 false false)))
(let (($x86 (not $x1968)))
(and $x86 (or $x1968 (and (distinct ?x6322 ?x6322) true))))))))
(check-sat)
; query 52: function core_state_transition, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x64 (or false false)))
(let (($x311 (not $x64)))
(and $x311 (or $x64 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 53: function core_state_transition, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x5721 (ite (= (_ bv101 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x1968 (or $x64 false false)))
(let (($x86 (not $x1968)))
(and $x86 (or $x1968 (and (distinct ?x5721 ?x5721) true))))))))
(check-sat)
; query 54: function core_state_transition, block 99, name %100
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x64 (or false false)))
(let (($x311 (not $x64)))
(and $x311 (or $x64 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 55: function core_state_transition, block 99, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x2693 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x1968 (or $x64 false false)))
(let (($x86 (not $x1968)))
(and $x86 (or $x1968 (and (distinct ?x2693 ?x2693) true))))))))
(check-sat)
; query 56: function crcu8, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x311 (not $x64)))
(and $x311 (or $x64 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 57: function crcu8, block 19, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x820 ((_ zero_extend 16) in.01_16)))
(let ((?x4258 (bvxor ?x820 (_ bv16386 32))))
(let (($x64 (or false false)))
(let (($x1968 (or $x64 false false)))
(let (($x86 (not $x1968)))
(and $x86 (or $x1968 (and (distinct ?x4258 ?x4258) true)))))))))
(check-sat)
; query 58: function crcu8, block 19, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x820 ((_ zero_extend 16) in.01_16)))
(let ((?x4258 (bvxor ?x820 (_ bv16386 32))))
(let ((?x2407 ((_ extract 15 0) ?x4258)))
(let (($x64 (or false false)))
(let (($x1968 (or $x64 false false)))
(let (($x43 (or $x1968 false)))
(let (($x71 (not $x43)))
(and $x71 (or $x43 (and (distinct ?x2407 ?x2407) true)))))))))))
(check-sat)
; query 59: function crcu8, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x311 (not $x64)))
(and $x311 (or $x64 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 60: function crcu8, block 29, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x4036 ((_ zero_extend 16) in27_16)))
(let ((?x607 (bvor ?x4036 (_ bv32768 32))))
(let (($x64 (or false false)))
(let (($x1968 (or $x64 false false)))
(let (($x86 (not $x1968)))
(and $x86 (or $x1968 (and (distinct ?x607 ?x607) true)))))))))
(check-sat)
; query 61: function crcu8, block 29, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x4036 ((_ zero_extend 16) in27_16)))
(let ((?x607 (bvor ?x4036 (_ bv32768 32))))
(let ((?x8024 ((_ extract 15 0) ?x607)))
(let (($x64 (or false false)))
(let (($x1968 (or $x64 false false)))
(let (($x43 (or $x1968 false)))
(let (($x71 (not $x43)))
(and $x71 (or $x43 (and (distinct ?x8024 ?x8024) true)))))))))))
(check-sat)
; query 62: function crcu8, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x311 (not $x64)))
(and $x311 (or $x64 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 63: function crcu8, block 33, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x4036 ((_ zero_extend 16) in27_16)))
(let ((?x923 (bvand ?x4036 (_ bv32767 32))))
(let (($x64 (or false false)))
(let (($x1968 (or $x64 false false)))
(let (($x86 (not $x1968)))
(and $x86 (or $x1968 (and (distinct ?x923 ?x923) true)))))))))
(check-sat)
; query 64: function crcu8, block 33, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x4036 ((_ zero_extend 16) in27_16)))
(let ((?x923 (bvand ?x4036 (_ bv32767 32))))
(let ((?x6643 ((_ extract 15 0) ?x923)))
(let (($x64 (or false false)))
(let (($x1968 (or $x64 false false)))
(let (($x43 (or $x1968 false)))
(let (($x71 (not $x43)))
(and $x71 (or $x43 (and (distinct ?x6643 ?x6643) true)))))))))))
(check-sat)
; query 65: function crcu8, block 38, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_8 () (_ BitVec 8))
(assert
 (let (($x191 (or false false false)))
(let (($x48 (not $x191)))
(and $x48 (or $x191 (and (distinct (bvadd in.02_8 (_ bv1 8)) (bvadd in.02_8 (_ bv1 8))) true))))))
(check-sat)
; query 66: function crcu8, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x248 ((_ extract 7 0) in.01_16)))
(let ((?x5340 ((_ zero_extend 24) ?x248)))
(let (($x64 (or false false)))
(let (($x1588 (or $x64 false)))
(and (not $x1588) (or $x1588 (and (distinct ?x5340 ?x5340) true))))))))
(check-sat)
; query 67: function crcu8, block 6, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x248 ((_ extract 7 0) in.01_16)))
(let ((?x5340 ((_ zero_extend 24) ?x248)))
(let ((?x437 (bvand ?x5340 (_ bv1 32))))
(let (($x64 (or false false)))
(let (($x1588 (or $x64 false)))
(let (($x1449 (or $x1588 false false)))
(and (not $x1449) (or $x1449 (and (distinct ?x437 ?x437) true))))))))))
(check-sat)
; query 68: function crcu8, block 6, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x248 ((_ extract 7 0) in.01_16)))
(let ((?x5340 ((_ zero_extend 24) ?x248)))
(let ((?x437 (bvand ?x5340 (_ bv1 32))))
(let ((?x985 ((_ zero_extend 24) in.0_8)))
(let ((?x2897 (bvand ?x985 (_ bv1 32))))
(let ((?x2216 (bvxor ?x2897 ?x437)))
(let (($x64 (or false false)))
(let (($x1588 (or $x64 false)))
(let (($x1449 (or $x1588 false false)))
(let (($x1968 (or $x64 false false)))
(let (($x2347 (or $x1968 $x1449 false)))
(and (not $x2347) (or $x2347 (and (distinct ?x2216 ?x2216) true)))))))))))))))
(check-sat)
; query 69: function crcu8, block 6, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x248 ((_ extract 7 0) in.01_16)))
(let ((?x5340 ((_ zero_extend 24) ?x248)))
(let ((?x437 (bvand ?x5340 (_ bv1 32))))
(let ((?x985 ((_ zero_extend 24) in.0_8)))
(let ((?x2897 (bvand ?x985 (_ bv1 32))))
(let ((?x2216 (bvxor ?x2897 ?x437)))
(let ((?x3688 ((_ extract 7 0) ?x2216)))
(let (($x64 (or false false)))
(let (($x1588 (or $x64 false)))
(let (($x1449 (or $x1588 false false)))
(let (($x1968 (or $x64 false false)))
(let (($x2347 (or $x1968 $x1449 false)))
(let (($x1612 (or $x2347 false)))
(and (not $x1612) (or $x1612 (and (distinct ?x3688 ?x3688) true)))))))))))))))))
(check-sat)
; query 70: function crcu8, block 6, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x64 (or false false)))
(let (($x311 (not $x64)))
(and $x311 (or $x64 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 71: function crcu8, block 6, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x985 ((_ zero_extend 24) in.0_8)))
(let ((?x75 (bvashr ?x985 (_ bv1 32))))
(let (($x64 (or false false)))
(let (($x1968 (or $x64 false false)))
(let (($x1965 (or $x1968 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not $x1965) (or $x1965 (and (distinct ?x75 ?x75) true)))))))))
(check-sat)
; query 72: function crcu8, block 6, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x985 ((_ zero_extend 24) in.0_8)))
(let ((?x75 (bvashr ?x985 (_ bv1 32))))
(let ((?x147 ((_ extract 7 0) ?x75)))
(let (($x64 (or false false)))
(let (($x1968 (or $x64 false false)))
(let (($x1965 (or $x1968 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x2244 (or $x1965 false)))
(and (not $x2244) (or $x2244 (and (distinct ?x147 ?x147) true)))))))))))
(check-sat)
; query 73: function crcu8, block 6, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x248 ((_ extract 7 0) in.01_16)))
(let ((?x5340 ((_ zero_extend 24) ?x248)))
(let ((?x437 (bvand ?x5340 (_ bv1 32))))
(let ((?x985 ((_ zero_extend 24) in.0_8)))
(let ((?x2897 (bvand ?x985 (_ bv1 32))))
(let ((?x2216 (bvxor ?x2897 ?x437)))
(let ((?x3688 ((_ extract 7 0) ?x2216)))
(let ((?x1051 ((_ zero_extend 24) ?x3688)))
(let (($x64 (or false false)))
(let (($x1588 (or $x64 false)))
(let (($x1449 (or $x1588 false false)))
(let (($x1968 (or $x64 false false)))
(let (($x2347 (or $x1968 $x1449 false)))
(let (($x1612 (or $x2347 false)))
(let (($x2179 (or $x1612 false)))
(and (not $x2179) (or $x2179 (and (distinct ?x1051 ?x1051) true)))))))))))))))))))
(check-sat)
; query 74: function crcu8, block 6, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x248 ((_ extract 7 0) in.01_16)))
(let ((?x5340 ((_ zero_extend 24) ?x248)))
(let ((?x437 (bvand ?x5340 (_ bv1 32))))
(let ((?x985 ((_ zero_extend 24) in.0_8)))
(let ((?x2897 (bvand ?x985 (_ bv1 32))))
(let ((?x2216 (bvxor ?x2897 ?x437)))
(let ((?x3688 ((_ extract 7 0) ?x2216)))
(let ((?x1051 ((_ zero_extend 24) ?x3688)))
(let ((?x284 (ite (= (_ bv1 32) ?x1051) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x1588 (or $x64 false)))
(let (($x1449 (or $x1588 false false)))
(let (($x1968 (or $x64 false false)))
(let (($x2347 (or $x1968 $x1449 false)))
(let (($x1612 (or $x2347 false)))
(let (($x2179 (or $x1612 false)))
(let (($x4676 (or $x2179 false false)))
(and (not $x4676) (or $x4676 (and (distinct ?x284 ?x284) true)))))))))))))))))))))
(check-sat)
; query 75: function crcu8, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x64 (or false false)))
(let (($x311 (not $x64)))
(and $x311 (or $x64 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 76: function crcu8, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x985 ((_ zero_extend 24) in.0_8)))
(let ((?x2897 (bvand ?x985 (_ bv1 32))))
(let (($x64 (or false false)))
(let (($x1968 (or $x64 false false)))
(let (($x86 (not $x1968)))
(and $x86 (or $x1968 (and (distinct ?x2897 ?x2897) true)))))))))
(check-sat)
; query 77: function crcu8, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x311 (not $x64)))
(and $x311 (or $x64 (and (distinct ((_ extract 7 0) in.01_16) ((_ extract 7 0) in.01_16)) true))))))
(check-sat)
; query 78: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x4511 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2666 ((_ zero_extend 31) ?x4511)))
(let ((?x539 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x3336 ((_ zero_extend 31) ?x539)))
(let ((?x443 (bvand ?x3336 ?x2666)))
(let ((?x4889 (ite (and (distinct (_ bv0 32) ?x443) true) (_ bv1 1) (_ bv0 1))))
(let ((?x6781 ((_ zero_extend 63) ?x4889)))
(let (($x64 (or false false)))
(let (($x1968 (or $x64 false false)))
(let (($x43 (or $x1968 false)))
(let (($x98 (or $x43 $x43 false)))
(let (($x4271 (or $x98 false false)))
(let (($x3828 (or $x4271 false)))
(and (not $x3828) (or $x3828 (and (distinct ?x6781 ?x6781) true)))))))))))))))))
(check-sat)
; query 79: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x4511 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2666 ((_ zero_extend 31) ?x4511)))
(let ((?x539 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x3336 ((_ zero_extend 31) ?x539)))
(let ((?x443 (bvand ?x3336 ?x2666)))
(let ((?x4889 (ite (and (distinct (_ bv0 32) ?x443) true) (_ bv1 1) (_ bv0 1))))
(let (($x943 (= (_ bv1 1) ?x4889)))
(let ((?x533 (ite $x943 (_ bv1 32) (_ bv0 32))))
(let (($x64 (or false false)))
(let (($x1968 (or $x64 false false)))
(let (($x43 (or $x1968 false)))
(let (($x98 (or $x43 $x43 false)))
(let (($x4271 (or $x98 false false)))
(let (($x2543 (or $x4271 (ite $x943 false false))))
(and (not $x2543) (or $x2543 (and (distinct ?x533 ?x533) true))))))))))))))))))
(check-sat)
; query 80: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x4511 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2666 ((_ zero_extend 31) ?x4511)))
(let ((?x539 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x3336 ((_ zero_extend 31) ?x539)))
(let ((?x443 (bvand ?x3336 ?x2666)))
(let ((?x4889 (ite (and (distinct (_ bv0 32) ?x443) true) (_ bv1 1) (_ bv0 1))))
(let (($x943 (= (_ bv1 1) ?x4889)))
(let ((?x533 (ite $x943 (_ bv1 32) (_ bv0 32))))
(let ((?x680 ((_ extract 7 0) ?x533)))
(let (($x64 (or false false)))
(let (($x1968 (or $x64 false false)))
(let (($x43 (or $x1968 false)))
(let (($x98 (or $x43 $x43 false)))
(let (($x4271 (or $x98 false false)))
(let (($x2543 (or $x4271 (ite $x943 false false))))
(let (($x1045 (or $x2543 false)))
(and (not $x1045) (or $x1045 (and (distinct ?x680 ?x680) true))))))))))))))))))))
(check-sat)
; query 81: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x64 (or false false)))
(let (($x311 (not $x64)))
(and $x311 (or $x64 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 82: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x539 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x1968 (or $x64 false false)))
(let (($x86 (not $x1968)))
(and $x86 (or $x1968 (and (distinct ?x539 ?x539) true))))))))
(check-sat)
; query 83: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x539 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x3336 ((_ zero_extend 31) ?x539)))
(let (($x64 (or false false)))
(let (($x1968 (or $x64 false false)))
(let (($x43 (or $x1968 false)))
(let (($x71 (not $x43)))
(and $x71 (or $x43 (and (distinct ?x3336 ?x3336) true))))))))))
(check-sat)
; query 84: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x64 (or false false)))
(let (($x311 (not $x64)))
(and $x311 (or $x64 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 85: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x4511 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x1968 (or $x64 false false)))
(let (($x86 (not $x1968)))
(and $x86 (or $x1968 (and (distinct ?x4511 ?x4511) true))))))))
(check-sat)
; query 86: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x4511 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2666 ((_ zero_extend 31) ?x4511)))
(let (($x64 (or false false)))
(let (($x1968 (or $x64 false false)))
(let (($x43 (or $x1968 false)))
(let (($x71 (not $x43)))
(and $x71 (or $x43 (and (distinct ?x2666 ?x2666) true))))))))))
(check-sat)
; query 87: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x4511 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2666 ((_ zero_extend 31) ?x4511)))
(let ((?x539 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x3336 ((_ zero_extend 31) ?x539)))
(let ((?x443 (bvand ?x3336 ?x2666)))
(let (($x64 (or false false)))
(let (($x1968 (or $x64 false false)))
(let (($x43 (or $x1968 false)))
(let (($x98 (or $x43 $x43 false)))
(and (not $x98) (or $x98 (and (distinct ?x443 ?x443) true)))))))))))))
(check-sat)
; query 88: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x4511 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2666 ((_ zero_extend 31) ?x4511)))
(let ((?x539 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x3336 ((_ zero_extend 31) ?x539)))
(let ((?x443 (bvand ?x3336 ?x2666)))
(let ((?x4889 (ite (and (distinct (_ bv0 32) ?x443) true) (_ bv1 1) (_ bv0 1))))
(let (($x64 (or false false)))
(let (($x1968 (or $x64 false false)))
(let (($x43 (or $x1968 false)))
(let (($x98 (or $x43 $x43 false)))
(let (($x4271 (or $x98 false false)))
(and (not $x4271) (or $x4271 (and (distinct ?x4889 ?x4889) true)))))))))))))))
(check-sat)
; query 89: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x2730 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x191 (or false false false)))
(let (($x48 (not $x191)))
(and $x48 (or $x191 (and (distinct ?x2730 ?x2730) true)))))))
(check-sat)
; query 90: function matrix_add_const, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x191 (or false false false)))
(let (($x48 (not $x191)))
(and $x48 (or $x191 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 91: function matrix_add_const, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x41 (bvadd in.01_32 (_ bv1 32))))
(let (($x68 (and (distinct ?x41 ?x41) true)))
(let (($x191 (or false false false)))
(let (($x48 (not $x191)))
(and $x48 (or $x191 $x68)))))))
(check-sat)
; query 92: function matrix_mul_const, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x191 (or false false false)))
(let (($x48 (not $x191)))
(and $x48 (or $x191 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 93: function matrix_mul_const, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x41 (bvadd in.01_32 (_ bv1 32))))
(let (($x68 (and (distinct ?x41 ?x41) true)))
(let (($x191 (or false false false)))
(let (($x48 (not $x191)))
(and $x48 (or $x191 $x68)))))))
(check-sat)
; query 94: function matrix_mul_matrix, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x191 (or false false false)))
(let (($x48 (not $x191)))
(and $x48 (or $x191 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 95: function matrix_mul_matrix, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x41 (bvadd in.01_32 (_ bv1 32))))
(let (($x68 (and (distinct ?x41 ?x41) true)))
(let (($x191 (or false false false)))
(let (($x48 (not $x191)))
(and $x48 (or $x191 $x68)))))))
(check-sat)
; query 96: function matrix_mul_matrix, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x191 (or false false false)))
(let (($x48 (not $x191)))
(and $x48 (or $x191 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 97: function matrix_mul_matrix_bitextract, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x191 (or false false false)))
(let (($x48 (not $x191)))
(and $x48 (or $x191 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 98: function matrix_mul_matrix_bitextract, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x41 (bvadd in.01_32 (_ bv1 32))))
(let (($x68 (and (distinct ?x41 ?x41) true)))
(let (($x191 (or false false false)))
(let (($x48 (not $x191)))
(and $x48 (or $x191 $x68)))))))
(check-sat)
; query 99: function matrix_mul_matrix_bitextract, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x191 (or false false false)))
(let (($x48 (not $x191)))
(and $x48 (or $x191 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 100: function matrix_mul_vect, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x191 (or false false false)))
(let (($x48 (not $x191)))
(and $x48 (or $x191 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 101: function matrix_mul_vect, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x41 (bvadd in.01_32 (_ bv1 32))))
(let (($x68 (and (distinct ?x41 ?x41) true)))
(let (($x191 (or false false false)))
(let (($x48 (not $x191)))
(and $x48 (or $x191 $x68)))))))
(check-sat)
; query 102: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x311 (not $x64)))
(and $x311 (or $x64 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 103: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x165 ((_ sign_extend 16) in.1_16)))
(let ((?x1413 (bvadd ?x165 (_ bv10 32))))
(let (($x1500 (and (distinct (bvadd ((_ sign_extend 1) ?x165) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x1413)) true)))
(let (($x64 (or false false)))
(let (($x1682 (or $x64 false (or $x1500))))
(and (not $x1682) (or $x1682 (and (distinct ?x1413 ?x1413) true)))))))))
(check-sat)
; query 104: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x165 ((_ sign_extend 16) in.1_16)))
(let ((?x1413 (bvadd ?x165 (_ bv10 32))))
(let ((?x1203 ((_ extract 15 0) ?x1413)))
(let (($x1500 (and (distinct (bvadd ((_ sign_extend 1) ?x165) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x1413)) true)))
(let (($x64 (or false false)))
(let (($x1682 (or $x64 false (or $x1500))))
(let (($x1485 (or $x1682 false)))
(and (not $x1485) (or $x1485 (and (distinct ?x1203 ?x1203) true)))))))))))
(check-sat)
; query 105: function matrix_sum, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x2596 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x191 (or false false false)))
(let (($x48 (not $x191)))
(and $x48 (or $x191 (and (distinct ?x2596 ?x2596) true)))))))
(check-sat)
; query 106: function matrix_sum, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x2596 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let ((?x1656 ((_ zero_extend 63) ?x2596)))
(let (($x191 (or false false false)))
(let (($x2207 (or $x191 false)))
(and (not $x2207) (or $x2207 (and (distinct ?x1656 ?x1656) true))))))))
(check-sat)
; query 107: function matrix_sum, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x2596 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x2529 (= (_ bv1 1) ?x2596)))
(let ((?x3204 (ite $x2529 (_ bv1 32) (_ bv0 32))))
(let (($x191 (or false false false)))
(let (($x1334 (or $x191 (ite $x2529 false false))))
(and (not $x1334) (or $x1334 (and (distinct ?x3204 ?x3204) true)))))))))
(check-sat)
; query 108: function matrix_sum, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x64 (or false false)))
(let (($x311 (not $x64)))
(and $x311 (or $x64 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 109: function matrix_sum, block 22, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x2596 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x2529 (= (_ bv1 1) ?x2596)))
(let ((?x3204 (ite $x2529 (_ bv1 32) (_ bv0 32))))
(let ((?x165 ((_ sign_extend 16) in.1_16)))
(let ((?x2218 (bvadd ?x165 ?x3204)))
(let (($x4839 (and (distinct (bvadd ((_ sign_extend 1) ?x165) ((_ sign_extend 1) ?x3204)) ((_ sign_extend 1) ?x2218)) true)))
(let (($x191 (or false false false)))
(let (($x1334 (or $x191 (ite $x2529 false false))))
(let (($x64 (or false false)))
(let (($x3972 (or $x64 $x1334 (or $x4839))))
(and (not $x3972) (or $x3972 (and (distinct ?x2218 ?x2218) true))))))))))))))
(check-sat)
; query 110: function matrix_sum, block 22, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x2596 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x2529 (= (_ bv1 1) ?x2596)))
(let ((?x3204 (ite $x2529 (_ bv1 32) (_ bv0 32))))
(let ((?x165 ((_ sign_extend 16) in.1_16)))
(let ((?x2218 (bvadd ?x165 ?x3204)))
(let ((?x401 ((_ extract 15 0) ?x2218)))
(let (($x4839 (and (distinct (bvadd ((_ sign_extend 1) ?x165) ((_ sign_extend 1) ?x3204)) ((_ sign_extend 1) ?x2218)) true)))
(let (($x191 (or false false false)))
(let (($x1334 (or $x191 (ite $x2529 false false))))
(let (($x64 (or false false)))
(let (($x3972 (or $x64 $x1334 (or $x4839))))
(let (($x762 (or $x3972 false)))
(and (not $x762) (or $x762 (and (distinct ?x401 ?x401) true))))))))))))))))
(check-sat)
; query 111: function matrix_sum, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x191 (or false false false)))
(let (($x48 (not $x191)))
(and $x48 (or $x191 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 112: function matrix_sum, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x41 (bvadd in.01_32 (_ bv1 32))))
(let (($x68 (and (distinct ?x41 ?x41) true)))
(let (($x191 (or false false false)))
(let (($x48 (not $x191)))
(and $x48 (or $x191 $x68)))))))
(check-sat)
; query 113: function parseval, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.23_32 () (_ BitVec 32))
(assert
 (let (($x10741 (and (distinct (bvmul ((_ sign_extend 32) in.23_32) ((_ sign_extend 32) (_ bv1024 32))) ((_ sign_extend 32) (bvmul in.23_32 (_ bv1024 32)))) true)))
(let (($x2521 (or false false (or $x10741))))
(and (not $x2521) (or $x2521 (and (distinct (bvmul in.23_32 (_ bv1024 32)) (bvmul in.23_32 (_ bv1024 32))) true))))))
(check-sat)
; query 114: function parseval, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.34_32 () (_ BitVec 32))
(assert
 (let (($x7795 (and (distinct (bvmul ((_ sign_extend 32) in.34_32) ((_ sign_extend 32) (_ bv1048576 32))) ((_ sign_extend 32) (bvmul in.34_32 (_ bv1048576 32)))) true)))
(let (($x6053 (or false false (or $x7795))))
(and (not $x6053) (or $x6053 (and (distinct (bvmul in.34_32 (_ bv1048576 32)) (bvmul in.34_32 (_ bv1048576 32))) true))))))
(check-sat)
; query 115: function partition_memory, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x191 (or false false false)))
(let (($x48 (not $x191)))
(and $x48 (or $x191 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
