; OptiPhase-Sigma refinement certificate for sweep K07-R4-343
