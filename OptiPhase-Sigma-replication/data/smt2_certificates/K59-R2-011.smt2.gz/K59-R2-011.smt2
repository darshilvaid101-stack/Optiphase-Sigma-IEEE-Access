; OptiPhase-Sigma refinement certificate for sweep K59-R2-011
; query 0: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x278 (or false false false)))
(let (($x60 (not $x278)))
(and $x60 (or $x278 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x353 (bvadd in.01_32 (_ bv1 32))))
(let ((?x623 (bvmul ?x353 ?x353)))
(let (($x278 (or false false false)))
(let (($x896 (or $x278 $x278 false)))
(and (not $x896) (or $x896 (and (distinct ?x623 ?x623) true))))))))
(check-sat)
; query 2: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x353 (bvadd in.01_32 (_ bv1 32))))
(let ((?x623 (bvmul ?x353 ?x353)))
(let ((?x119 (bvmul ?x623 (_ bv2 32))))
(let (($x278 (or false false false)))
(let (($x896 (or $x278 $x278 false)))
(let (($x729 (or $x896 false false)))
(and (not $x729) (or $x729 (and (distinct ?x119 ?x119) true))))))))))
(check-sat)
; query 3: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x353 (bvadd in.01_32 (_ bv1 32))))
(let ((?x623 (bvmul ?x353 ?x353)))
(let ((?x119 (bvmul ?x623 (_ bv2 32))))
(let ((?x480 (bvmul ?x119 (_ bv4 32))))
(let (($x278 (or false false false)))
(let (($x896 (or $x278 $x278 false)))
(let (($x729 (or $x896 false false)))
(let (($x1059 (or $x729 false false)))
(and (not $x1059) (or $x1059 (and (distinct ?x480 ?x480) true))))))))))))
(check-sat)
; query 4: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x182 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x278 (or false false false)))
(let (($x60 (not $x278)))
(and $x60 (or $x278 (and (distinct ?x182 ?x182) true)))))))
(check-sat)
; query 5: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x602 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x278 (or false false false)))
(let (($x60 (not $x278)))
(and $x60 (or $x278 (and (distinct ?x602 ?x602) true)))))))
(check-sat)
; query 6: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x278 (or false false false)))
(let (($x60 (not $x278)))
(and $x60 (or $x278 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 7: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x473 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x134 (or false false (or $x473))))
(and (not $x134) (or $x134 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x1847 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x278 (or false false false)))
(let (($x60 (not $x278)))
(and $x60 (or $x278 (and (distinct ?x1847 ?x1847) true)))))))
(check-sat)
; query 9: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1065 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x278 (or false false false)))
(let (($x60 (not $x278)))
(and $x60 (or $x278 (and (distinct ?x1065 ?x1065) true)))))))
(check-sat)
; query 10: function matrix_add_const, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x278 (or false false false)))
(let (($x60 (not $x278)))
(and $x60 (or $x278 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 11: function matrix_add_const, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x278 (or false false false)))
(let (($x60 (not $x278)))
(and $x60 (or $x278 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 12: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x365 (or false false)))
(and (not $x365) (or $x365 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true)))))
(check-sat)
; query 13: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x78 ((_ sign_extend 16) in.1_16)))
(let ((?x604 (bvadd ?x78 (_ bv10 32))))
(let (($x71 (and (distinct (bvadd ((_ sign_extend 1) ?x78) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x604)) true)))
(let (($x365 (or false false)))
(let (($x120 (or $x365 false (or $x71))))
(and (not $x120) (or $x120 (and (distinct ?x604 ?x604) true)))))))))
(check-sat)
; query 14: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x78 ((_ sign_extend 16) in.1_16)))
(let ((?x604 (bvadd ?x78 (_ bv10 32))))
(let ((?x501 ((_ extract 15 0) ?x604)))
(let (($x71 (and (distinct (bvadd ((_ sign_extend 1) ?x78) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x604)) true)))
(let (($x365 (or false false)))
(let (($x120 (or $x365 false (or $x71))))
(let (($x103 (or $x120 false)))
(and (not $x103) (or $x103 (and (distinct ?x501 ?x501) true)))))))))))
(check-sat)
