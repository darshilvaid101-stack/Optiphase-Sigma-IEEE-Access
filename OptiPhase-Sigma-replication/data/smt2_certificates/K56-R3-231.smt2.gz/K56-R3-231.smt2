; OptiPhase-Sigma refinement certificate for sweep K56-R3-231
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x298 (or false false)))
(let (($x365 (not $x298)))
(and $x365 (or $x298 (and (distinct ((_ sign_extend 16) in25_16) ((_ sign_extend 16) in25_16)) true))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let ((?x757 (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))))
(let (($x298 (or false false)))
(let (($x501 (or $x298 false false)))
(let (($x472 (not $x501)))
(and $x472 (or $x501 (and (distinct ?x757 ?x757) true))))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x298 (or false false)))
(let (($x365 (not $x298)))
(and $x365 (or $x298 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x347 ((_ sign_extend 16) in3_16)))
(let ((?x111 (bvand ?x347 (_ bv127 32))))
(let (($x298 (or false false)))
(let (($x501 (or $x298 false false)))
(let (($x472 (not $x501)))
(and $x472 (or $x501 (and (distinct ?x111 ?x111) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x347 ((_ sign_extend 16) in3_16)))
(let ((?x111 (bvand ?x347 (_ bv127 32))))
(let ((?x518 ((_ extract 15 0) ?x111)))
(let (($x298 (or false false)))
(let (($x501 (or $x298 false false)))
(let (($x669 (or $x501 false)))
(let (($x9 (not $x669)))
(and $x9 (or $x669 (and (distinct ?x518 ?x518) true)))))))))))
(check-sat)
; query 5: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x298 (or false false)))
(let (($x365 (not $x298)))
(and $x365 (or $x298 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 6: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x443 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x298 (or false false)))
(let (($x501 (or $x298 false false)))
(let (($x472 (not $x501)))
(and $x472 (or $x501 (and (distinct ?x443 ?x443) true))))))))
(check-sat)
; query 7: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x35 (or false false false)))
(let (($x180 (not $x35)))
(and $x180 (or $x35 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x871 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x35 (or false false false)))
(let (($x180 (not $x35)))
(and $x180 (or $x35 (and (distinct ?x871 ?x871) true)))))))
(check-sat)
; query 9: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x158 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x35 (or false false false)))
(let (($x180 (not $x35)))
(and $x180 (or $x35 (and (distinct ?x158 ?x158) true)))))))
(check-sat)
; query 10: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x35 (or false false false)))
(let (($x180 (not $x35)))
(and $x180 (or $x35 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 11: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x340 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x179 (or false false (or $x340))))
(and (not $x179) (or $x179 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 12: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x577 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x35 (or false false false)))
(let (($x180 (not $x35)))
(and $x180 (or $x35 (and (distinct ?x577 ?x577) true)))))))
(check-sat)
; query 13: function crcu8, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x298 (or false false)))
(let (($x365 (not $x298)))
(and $x365 (or $x298 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 14: function crcu8, block 19, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x429 ((_ zero_extend 16) in.01_16)))
(let ((?x730 (bvxor ?x429 (_ bv16386 32))))
(let (($x298 (or false false)))
(let (($x501 (or $x298 false false)))
(let (($x472 (not $x501)))
(and $x472 (or $x501 (and (distinct ?x730 ?x730) true)))))))))
(check-sat)
; query 15: function crcu8, block 19, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x429 ((_ zero_extend 16) in.01_16)))
(let ((?x730 (bvxor ?x429 (_ bv16386 32))))
(let ((?x235 ((_ extract 15 0) ?x730)))
(let (($x298 (or false false)))
(let (($x501 (or $x298 false false)))
(let (($x669 (or $x501 false)))
(let (($x9 (not $x669)))
(and $x9 (or $x669 (and (distinct ?x235 ?x235) true)))))))))))
(check-sat)
; query 16: function crcu8, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x378 ((_ extract 7 0) in.01_16)))
(let ((?x229 ((_ zero_extend 24) ?x378)))
(let (($x298 (or false false)))
(let (($x293 (or $x298 false)))
(and (not $x293) (or $x293 (and (distinct ?x229 ?x229) true))))))))
(check-sat)
; query 17: function crcu8, block 6, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x378 ((_ extract 7 0) in.01_16)))
(let ((?x229 ((_ zero_extend 24) ?x378)))
(let ((?x147 (bvand ?x229 (_ bv1 32))))
(let (($x298 (or false false)))
(let (($x293 (or $x298 false)))
(let (($x476 (or $x293 false false)))
(and (not $x476) (or $x476 (and (distinct ?x147 ?x147) true))))))))))
(check-sat)
; query 18: function crcu8, block 6, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x378 ((_ extract 7 0) in.01_16)))
(let ((?x229 ((_ zero_extend 24) ?x378)))
(let ((?x147 (bvand ?x229 (_ bv1 32))))
(let ((?x124 ((_ zero_extend 24) in.0_8)))
(let ((?x355 (bvand ?x124 (_ bv1 32))))
(let ((?x239 (bvxor ?x355 ?x147)))
(let (($x298 (or false false)))
(let (($x293 (or $x298 false)))
(let (($x476 (or $x293 false false)))
(let (($x501 (or $x298 false false)))
(let (($x118 (or $x501 $x476 false)))
(and (not $x118) (or $x118 (and (distinct ?x239 ?x239) true)))))))))))))))
(check-sat)
; query 19: function crcu8, block 6, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x378 ((_ extract 7 0) in.01_16)))
(let ((?x229 ((_ zero_extend 24) ?x378)))
(let ((?x147 (bvand ?x229 (_ bv1 32))))
(let ((?x124 ((_ zero_extend 24) in.0_8)))
(let ((?x355 (bvand ?x124 (_ bv1 32))))
(let ((?x239 (bvxor ?x355 ?x147)))
(let ((?x126 ((_ extract 7 0) ?x239)))
(let (($x298 (or false false)))
(let (($x293 (or $x298 false)))
(let (($x476 (or $x293 false false)))
(let (($x501 (or $x298 false false)))
(let (($x118 (or $x501 $x476 false)))
(let (($x159 (or $x118 false)))
(and (not $x159) (or $x159 (and (distinct ?x126 ?x126) true)))))))))))))))))
(check-sat)
; query 20: function crcu8, block 6, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x298 (or false false)))
(let (($x365 (not $x298)))
(and $x365 (or $x298 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 21: function crcu8, block 6, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x124 ((_ zero_extend 24) in.0_8)))
(let ((?x25 (bvashr ?x124 (_ bv1 32))))
(let (($x298 (or false false)))
(let (($x501 (or $x298 false false)))
(let (($x392 (or $x501 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not $x392) (or $x392 (and (distinct ?x25 ?x25) true)))))))))
(check-sat)
; query 22: function crcu8, block 6, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x124 ((_ zero_extend 24) in.0_8)))
(let ((?x25 (bvashr ?x124 (_ bv1 32))))
(let ((?x297 ((_ extract 7 0) ?x25)))
(let (($x298 (or false false)))
(let (($x501 (or $x298 false false)))
(let (($x392 (or $x501 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x396 (or $x392 false)))
(and (not $x396) (or $x396 (and (distinct ?x297 ?x297) true)))))))))))
(check-sat)
; query 23: function crcu8, block 6, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x378 ((_ extract 7 0) in.01_16)))
(let ((?x229 ((_ zero_extend 24) ?x378)))
(let ((?x147 (bvand ?x229 (_ bv1 32))))
(let ((?x124 ((_ zero_extend 24) in.0_8)))
(let ((?x355 (bvand ?x124 (_ bv1 32))))
(let ((?x239 (bvxor ?x355 ?x147)))
(let ((?x126 ((_ extract 7 0) ?x239)))
(let ((?x727 ((_ zero_extend 24) ?x126)))
(let (($x298 (or false false)))
(let (($x293 (or $x298 false)))
(let (($x476 (or $x293 false false)))
(let (($x501 (or $x298 false false)))
(let (($x118 (or $x501 $x476 false)))
(let (($x159 (or $x118 false)))
(let (($x225 (or $x159 false)))
(and (not $x225) (or $x225 (and (distinct ?x727 ?x727) true)))))))))))))))))))
(check-sat)
; query 24: function crcu8, block 6, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x378 ((_ extract 7 0) in.01_16)))
(let ((?x229 ((_ zero_extend 24) ?x378)))
(let ((?x147 (bvand ?x229 (_ bv1 32))))
(let ((?x124 ((_ zero_extend 24) in.0_8)))
(let ((?x355 (bvand ?x124 (_ bv1 32))))
(let ((?x239 (bvxor ?x355 ?x147)))
(let ((?x126 ((_ extract 7 0) ?x239)))
(let ((?x727 ((_ zero_extend 24) ?x126)))
(let ((?x655 (ite (= (_ bv1 32) ?x727) (_ bv1 1) (_ bv0 1))))
(let (($x298 (or false false)))
(let (($x293 (or $x298 false)))
(let (($x476 (or $x293 false false)))
(let (($x501 (or $x298 false false)))
(let (($x118 (or $x501 $x476 false)))
(let (($x159 (or $x118 false)))
(let (($x225 (or $x159 false)))
(let (($x280 (or $x225 false false)))
(and (not $x280) (or $x280 (and (distinct ?x655 ?x655) true)))))))))))))))))))))
(check-sat)
; query 25: function crcu8, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x298 (or false false)))
(let (($x365 (not $x298)))
(and $x365 (or $x298 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 26: function crcu8, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x124 ((_ zero_extend 24) in.0_8)))
(let ((?x355 (bvand ?x124 (_ bv1 32))))
(let (($x298 (or false false)))
(let (($x501 (or $x298 false false)))
(let (($x472 (not $x501)))
(and $x472 (or $x501 (and (distinct ?x355 ?x355) true)))))))))
(check-sat)
; query 27: function crcu8, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x298 (or false false)))
(let (($x365 (not $x298)))
(and $x365 (or $x298 (and (distinct ((_ extract 7 0) in.01_16) ((_ extract 7 0) in.01_16)) true))))))
(check-sat)
; query 28: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x3911 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x3329 ((_ zero_extend 31) ?x3911)))
(let ((?x3126 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x3343 ((_ zero_extend 31) ?x3126)))
(let ((?x3365 (bvand ?x3343 ?x3329)))
(let ((?x94 (ite (and (distinct (_ bv0 32) ?x3365) true) (_ bv1 1) (_ bv0 1))))
(let ((?x3378 ((_ zero_extend 63) ?x94)))
(let (($x298 (or false false)))
(let (($x501 (or $x298 false false)))
(let (($x669 (or $x501 false)))
(let (($x3360 (or $x669 $x669 false)))
(let (($x3124 (or $x3360 false false)))
(let (($x3376 (or $x3124 false)))
(and (not $x3376) (or $x3376 (and (distinct ?x3378 ?x3378) true)))))))))))))))))
(check-sat)
; query 29: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x3911 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x3329 ((_ zero_extend 31) ?x3911)))
(let ((?x3126 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x3343 ((_ zero_extend 31) ?x3126)))
(let ((?x3365 (bvand ?x3343 ?x3329)))
(let ((?x94 (ite (and (distinct (_ bv0 32) ?x3365) true) (_ bv1 1) (_ bv0 1))))
(let (($x3641 (= (_ bv1 1) ?x94)))
(let ((?x3642 (ite $x3641 (_ bv1 32) (_ bv0 32))))
(let (($x298 (or false false)))
(let (($x501 (or $x298 false false)))
(let (($x669 (or $x501 false)))
(let (($x3360 (or $x669 $x669 false)))
(let (($x3124 (or $x3360 false false)))
(let (($x3649 (or $x3124 (ite $x3641 false false))))
(and (not $x3649) (or $x3649 (and (distinct ?x3642 ?x3642) true))))))))))))))))))
(check-sat)
; query 30: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x3911 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x3329 ((_ zero_extend 31) ?x3911)))
(let ((?x3126 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x3343 ((_ zero_extend 31) ?x3126)))
(let ((?x3365 (bvand ?x3343 ?x3329)))
(let ((?x94 (ite (and (distinct (_ bv0 32) ?x3365) true) (_ bv1 1) (_ bv0 1))))
(let (($x3641 (= (_ bv1 1) ?x94)))
(let ((?x3642 (ite $x3641 (_ bv1 32) (_ bv0 32))))
(let ((?x3650 ((_ extract 7 0) ?x3642)))
(let (($x298 (or false false)))
(let (($x501 (or $x298 false false)))
(let (($x669 (or $x501 false)))
(let (($x3360 (or $x669 $x669 false)))
(let (($x3124 (or $x3360 false false)))
(let (($x3649 (or $x3124 (ite $x3641 false false))))
(let (($x668 (or $x3649 false)))
(and (not $x668) (or $x668 (and (distinct ?x3650 ?x3650) true))))))))))))))))))))
(check-sat)
; query 31: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x298 (or false false)))
(let (($x365 (not $x298)))
(and $x365 (or $x298 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 32: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x3126 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x298 (or false false)))
(let (($x501 (or $x298 false false)))
(let (($x472 (not $x501)))
(and $x472 (or $x501 (and (distinct ?x3126 ?x3126) true))))))))
(check-sat)
; query 33: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x3126 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x3343 ((_ zero_extend 31) ?x3126)))
(let (($x298 (or false false)))
(let (($x501 (or $x298 false false)))
(let (($x669 (or $x501 false)))
(let (($x9 (not $x669)))
(and $x9 (or $x669 (and (distinct ?x3343 ?x3343) true))))))))))
(check-sat)
; query 34: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x298 (or false false)))
(let (($x365 (not $x298)))
(and $x365 (or $x298 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 35: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x3911 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x298 (or false false)))
(let (($x501 (or $x298 false false)))
(let (($x472 (not $x501)))
(and $x472 (or $x501 (and (distinct ?x3911 ?x3911) true))))))))
(check-sat)
; query 36: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x3911 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x3329 ((_ zero_extend 31) ?x3911)))
(let (($x298 (or false false)))
(let (($x501 (or $x298 false false)))
(let (($x669 (or $x501 false)))
(let (($x9 (not $x669)))
(and $x9 (or $x669 (and (distinct ?x3329 ?x3329) true))))))))))
(check-sat)
; query 37: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x3911 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x3329 ((_ zero_extend 31) ?x3911)))
(let ((?x3126 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x3343 ((_ zero_extend 31) ?x3126)))
(let ((?x3365 (bvand ?x3343 ?x3329)))
(let (($x298 (or false false)))
(let (($x501 (or $x298 false false)))
(let (($x669 (or $x501 false)))
(let (($x3360 (or $x669 $x669 false)))
(and (not $x3360) (or $x3360 (and (distinct ?x3365 ?x3365) true)))))))))))))
(check-sat)
; query 38: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x3911 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x3329 ((_ zero_extend 31) ?x3911)))
(let ((?x3126 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x3343 ((_ zero_extend 31) ?x3126)))
(let ((?x3365 (bvand ?x3343 ?x3329)))
(let ((?x94 (ite (and (distinct (_ bv0 32) ?x3365) true) (_ bv1 1) (_ bv0 1))))
(let (($x298 (or false false)))
(let (($x501 (or $x298 false false)))
(let (($x669 (or $x501 false)))
(let (($x3360 (or $x669 $x669 false)))
(let (($x3124 (or $x3360 false false)))
(and (not $x3124) (or $x3124 (and (distinct ?x94 ?x94) true)))))))))))))))
(check-sat)
; query 39: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x203 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x35 (or false false false)))
(let (($x180 (not $x35)))
(and $x180 (or $x35 (and (distinct ?x203 ?x203) true)))))))
(check-sat)
; query 40: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x298 (or false false)))
(let (($x365 (not $x298)))
(and $x365 (or $x298 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 41: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x276 ((_ sign_extend 16) in.1_16)))
(let ((?x2389 (bvadd ?x276 (_ bv10 32))))
(let (($x785 (and (distinct (bvadd ((_ sign_extend 1) ?x276) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x2389)) true)))
(let (($x298 (or false false)))
(let (($x3381 (or $x298 false (or $x785))))
(and (not $x3381) (or $x3381 (and (distinct ?x2389 ?x2389) true)))))))))
(check-sat)
; query 42: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x276 ((_ sign_extend 16) in.1_16)))
(let ((?x2389 (bvadd ?x276 (_ bv10 32))))
(let ((?x3380 ((_ extract 15 0) ?x2389)))
(let (($x785 (and (distinct (bvadd ((_ sign_extend 1) ?x276) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x2389)) true)))
(let (($x298 (or false false)))
(let (($x3381 (or $x298 false (or $x785))))
(let (($x3382 (or $x3381 false)))
(and (not $x3382) (or $x3382 (and (distinct ?x3380 ?x3380) true)))))))))))
(check-sat)
; query 43: function matrix_sum, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x3659 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x35 (or false false false)))
(let (($x180 (not $x35)))
(and $x180 (or $x35 (and (distinct ?x3659 ?x3659) true)))))))
(check-sat)
; query 44: function matrix_sum, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x3659 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let ((?x3660 ((_ zero_extend 63) ?x3659)))
(let (($x35 (or false false false)))
(let (($x3110 (or $x35 false)))
(and (not $x3110) (or $x3110 (and (distinct ?x3660 ?x3660) true))))))))
(check-sat)
; query 45: function matrix_sum, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x3659 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x3115 (= (_ bv1 1) ?x3659)))
(let ((?x3111 (ite $x3115 (_ bv1 32) (_ bv0 32))))
(let (($x35 (or false false false)))
(let (($x2857 (or $x35 (ite $x3115 false false))))
(and (not $x2857) (or $x2857 (and (distinct ?x3111 ?x3111) true)))))))))
(check-sat)
; query 46: function matrix_sum, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x298 (or false false)))
(let (($x365 (not $x298)))
(and $x365 (or $x298 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 47: function matrix_sum, block 22, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x3659 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x3115 (= (_ bv1 1) ?x3659)))
(let ((?x3111 (ite $x3115 (_ bv1 32) (_ bv0 32))))
(let ((?x276 ((_ sign_extend 16) in.1_16)))
(let ((?x3118 (bvadd ?x276 ?x3111)))
(let (($x1924 (and (distinct (bvadd ((_ sign_extend 1) ?x276) ((_ sign_extend 1) ?x3111)) ((_ sign_extend 1) ?x3118)) true)))
(let (($x35 (or false false false)))
(let (($x2857 (or $x35 (ite $x3115 false false))))
(let (($x298 (or false false)))
(let (($x2369 (or $x298 $x2857 (or $x1924))))
(and (not $x2369) (or $x2369 (and (distinct ?x3118 ?x3118) true))))))))))))))
(check-sat)
; query 48: function matrix_sum, block 22, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x3659 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x3115 (= (_ bv1 1) ?x3659)))
(let ((?x3111 (ite $x3115 (_ bv1 32) (_ bv0 32))))
(let ((?x276 ((_ sign_extend 16) in.1_16)))
(let ((?x3118 (bvadd ?x276 ?x3111)))
(let ((?x2383 ((_ extract 15 0) ?x3118)))
(let (($x1924 (and (distinct (bvadd ((_ sign_extend 1) ?x276) ((_ sign_extend 1) ?x3111)) ((_ sign_extend 1) ?x3118)) true)))
(let (($x35 (or false false false)))
(let (($x2857 (or $x35 (ite $x3115 false false))))
(let (($x298 (or false false)))
(let (($x2369 (or $x298 $x2857 (or $x1924))))
(let (($x2611 (or $x2369 false)))
(and (not $x2611) (or $x2611 (and (distinct ?x2383 ?x2383) true))))))))))))))))
(check-sat)
