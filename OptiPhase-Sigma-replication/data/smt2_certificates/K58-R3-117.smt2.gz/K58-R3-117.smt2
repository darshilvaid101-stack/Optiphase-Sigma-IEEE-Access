; OptiPhase-Sigma refinement certificate for sweep K58-R3-117
; query 0: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x402 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x1575 (or false false false)))
(let (($x394 (not $x1575)))
(and $x394 (or $x1575 (and (distinct ?x402 ?x402) true)))))))
(check-sat)
; query 1: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x1575 (or false false false)))
(let (($x394 (not $x1575)))
(and $x394 (or $x1575 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 2: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x15 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x1575 (or false false false)))
(let (($x394 (not $x1575)))
(and $x394 (or $x1575 (and (distinct ?x15 ?x15) true)))))))
(check-sat)
; query 3: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x882 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x1575 (or false false false)))
(let (($x394 (not $x1575)))
(and $x394 (or $x1575 (and (distinct ?x882 ?x882) true)))))))
(check-sat)
