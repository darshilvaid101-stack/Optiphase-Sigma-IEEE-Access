; OptiPhase-Sigma refinement certificate for sweep K17-R1-001
