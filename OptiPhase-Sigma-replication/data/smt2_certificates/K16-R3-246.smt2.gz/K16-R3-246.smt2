; OptiPhase-Sigma refinement certificate for sweep K16-R3-246
; query 0: function xmalloc, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in7_32 () (_ BitVec 32))
(assert
 (let ((?x126 (ite (and (distinct (_ bv0 32) in7_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x139 (or false false false)))
(and (not $x139) (or $x139 (and (distinct ?x126 ?x126) true))))))
(check-sat)
