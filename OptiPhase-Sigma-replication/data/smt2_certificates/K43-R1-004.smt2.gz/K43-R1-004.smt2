; OptiPhase-Sigma refinement certificate for sweep K43-R1-004
