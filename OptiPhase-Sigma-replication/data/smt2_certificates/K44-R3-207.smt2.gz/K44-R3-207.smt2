; OptiPhase-Sigma refinement certificate for sweep K44-R3-207
; query 0: function Index_to_frequency, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x72 (ite (bvuge in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x66 (or false false false)))
(let (($x219 (not $x66)))
(and $x219 (or $x66 (and (distinct ?x72 ?x72) true)))))))
(check-sat)
; query 1: function IsPowerOfTwo, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x66 (or false false false)))
(let (($x219 (not $x66)))
(and $x219 (or $x66 (and (distinct (bvsub in0_32 (_ bv1 32)) (bvsub in0_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function IsPowerOfTwo, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x621 (bvsub in0_32 (_ bv1 32))))
(let ((?x98 (bvand in0_32 ?x621)))
(let (($x66 (or false false false)))
(let (($x19 (or false $x66 false)))
(and (not $x19) (or $x19 (and (distinct ?x98 ?x98) true))))))))
(check-sat)
; query 3: function IsPowerOfTwo, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x318 (ite (and (distinct (_ bv0 32) (bvand in0_32 (bvsub in0_32 (_ bv1 32)))) true) (_ bv1 1) (_ bv0 1))))
(let (($x66 (or false false false)))
(let (($x19 (or false $x66 false)))
(let (($x140 (or $x19 false false)))
(and (not $x140) (or $x140 (and (distinct ?x318 ?x318) true))))))))
(check-sat)
; query 4: function IsPowerOfTwo, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x1025 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x66 (or false false false)))
(let (($x219 (not $x66)))
(and $x219 (or $x66 (and (distinct ?x1025 ?x1025) true)))))))
(check-sat)
; query 5: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x1025 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x66 (or false false false)))
(let (($x219 (not $x66)))
(and $x219 (or $x66 (and (distinct ?x1025 ?x1025) true)))))))
(check-sat)
; query 6: function fft_float, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x48 (ite (and (distinct (_ bv0 32) in1_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x66 (or false false false)))
(let (($x219 (not $x66)))
(and $x219 (or $x66 (and (distinct ?x48 ?x48) true)))))))
(check-sat)
; query 7: function fft_float, block 161, name %162
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x48 (ite (and (distinct (_ bv0 32) in1_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x66 (or false false false)))
(let (($x219 (not $x66)))
(and $x219 (or $x66 (and (distinct ?x48 ?x48) true)))))))
(check-sat)
; query 8: function main, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x431 (ite (= (_ bv4 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x66 (or false false false)))
(let (($x219 (not $x66)))
(and $x219 (or $x66 (and (distinct ?x431 ?x431) true)))))))
(check-sat)
; query 9: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x415 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x66 (or false false false)))
(let (($x219 (not $x66)))
(and $x219 (or $x66 (and (distinct ?x415 ?x415) true)))))))
(check-sat)
