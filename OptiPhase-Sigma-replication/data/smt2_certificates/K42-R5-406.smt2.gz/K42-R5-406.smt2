; OptiPhase-Sigma refinement certificate for sweep K42-R5-406
