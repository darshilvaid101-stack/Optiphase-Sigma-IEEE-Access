; OptiPhase-Sigma refinement certificate for sweep K47-R3-193
; query 0: function adpcm_coder, block 25, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in20_32 () (_ BitVec 32))
(assert
 (let (($x108 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in20_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in20_32))) true)))
(let (($x458 (or false false (or $x108))))
(and (not $x458) (or $x458 (and (distinct (bvsub (_ bv0 32) in20_32) (bvsub (_ bv0 32) in20_32)) true))))))
(check-sat)
; query 1: function adpcm_coder, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(declare-fun in.017_32 () (_ BitVec 32))
(assert
 (let ((?x161 (bvsub in.017_32 in.020_32)))
(let (($x73 (and (distinct (bvsub ((_ sign_extend 1) in.017_32) ((_ sign_extend 1) in.020_32)) ((_ sign_extend 1) ?x161)) true)))
(let (($x173 (or false false (or $x73))))
(and (not $x173) (or $x173 (and (distinct ?x161 ?x161) true)))))))
(check-sat)
; query 2: function adpcm_coder, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(declare-fun in28_32 () (_ BitVec 32))
(assert
 (let (($x62 (and (distinct (bvadd ((_ sign_extend 1) in28_32) ((_ sign_extend 1) in.020_32)) ((_ sign_extend 1) (bvadd in28_32 in.020_32))) true)))
(let (($x454 (or false false (or $x62))))
(let (($x509 (or $x454 (and (distinct (bvadd in28_32 in.020_32) (bvadd in28_32 in.020_32)) true))))
(and (not $x454) $x509)))))
(check-sat)
; query 3: function adpcm_coder, block 36, name %37
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.014_32 () (_ BitVec 32))
(assert
 (let (($x613 (or false false false)))
(let (($x309 (not $x613)))
(and $x309 (or $x613 (and (distinct (bvor in.014_32 (_ bv2 32)) (bvor in.014_32 (_ bv2 32))) true))))))
(check-sat)
; query 4: function adpcm_coder, block 36, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in34_32 () (_ BitVec 32))
(declare-fun in.118_32 () (_ BitVec 32))
(assert
 (let (($x432 (and (distinct (bvsub ((_ sign_extend 1) in.118_32) ((_ sign_extend 1) in34_32)) ((_ sign_extend 1) (bvsub in.118_32 in34_32))) true)))
(let (($x386 (or false false (or $x432))))
(let (($x82 (or $x386 (and (distinct (bvsub in.118_32 in34_32) (bvsub in.118_32 in34_32)) true))))
(and (not $x386) $x82)))))
(check-sat)
; query 5: function adpcm_coder, block 36, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in34_32 () (_ BitVec 32))
(declare-fun in.08_32 () (_ BitVec 32))
(assert
 (let (($x30 (and (distinct (bvadd ((_ sign_extend 1) in.08_32) ((_ sign_extend 1) in34_32)) ((_ sign_extend 1) (bvadd in.08_32 in34_32))) true)))
(let (($x404 (or false false (or $x30))))
(let (($x427 (or $x404 (and (distinct (bvadd in.08_32 in34_32) (bvadd in.08_32 in34_32)) true))))
(and (not $x404) $x427)))))
(check-sat)
; query 6: function adpcm_coder, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.115_32 () (_ BitVec 32))
(assert
 (let (($x613 (or false false false)))
(let (($x309 (not $x613)))
(and $x309 (or $x613 (and (distinct (bvor in.115_32 (_ bv1 32)) (bvor in.115_32 (_ bv1 32))) true))))))
(check-sat)
; query 7: function adpcm_coder, block 43, name %45
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in41_32 () (_ BitVec 32))
(declare-fun in.19_32 () (_ BitVec 32))
(assert
 (let (($x262 (and (distinct (bvadd ((_ sign_extend 1) in.19_32) ((_ sign_extend 1) in41_32)) ((_ sign_extend 1) (bvadd in.19_32 in41_32))) true)))
(let (($x94 (or false false (or $x262))))
(let (($x462 (or $x94 (and (distinct (bvadd in.19_32 in41_32) (bvadd in.19_32 in41_32)) true))))
(and (not $x94) $x462)))))
(check-sat)
; query 8: function adpcm_coder, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.210_32 () (_ BitVec 32))
(declare-fun in.011_32 () (_ BitVec 32))
(assert
 (let ((?x519 (bvsub in.011_32 in.210_32)))
(let (($x105 (and (distinct (bvsub ((_ sign_extend 1) in.011_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x519)) true)))
(let (($x229 (or false false (or $x105))))
(and (not $x229) (or $x229 (and (distinct ?x519 ?x519) true)))))))
(check-sat)
; query 9: function adpcm_coder, block 50, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.210_32 () (_ BitVec 32))
(declare-fun in.011_32 () (_ BitVec 32))
(assert
 (let ((?x51 (bvadd in.011_32 in.210_32)))
(let (($x116 (and (distinct (bvadd ((_ sign_extend 1) in.011_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x51)) true)))
(let (($x68 (or false false (or $x116))))
(and (not $x68) (or $x68 (and (distinct ?x51 ?x51) true)))))))
(check-sat)
; query 10: function adpcm_coder, block 55, name %56
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.112_32 () (_ BitVec 32))
(assert
 (let ((?x331 (ite (bvsgt (_ bv4294934528 32) in.112_32) (_ bv1 1) (_ bv0 1))))
(let (($x613 (or false false false)))
(let (($x309 (not $x613)))
(and $x309 (or $x613 (and (distinct ?x331 ?x331) true)))))))
(check-sat)
; query 11: function adpcm_coder, block 75, name %76
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in60_32 () (_ BitVec 32))
(assert
 (let (($x613 (or false false false)))
(let (($x610 (or $x613 (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x610) (or $x610 (and (distinct (bvshl in60_32 (_ bv4 32)) (bvshl in60_32 (_ bv4 32))) true))))))
(check-sat)
; query 12: function adpcm_coder, block 75, name %77
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in60_32 () (_ BitVec 32))
(assert
 (let ((?x87 (bvshl in60_32 (_ bv4 32))))
(let ((?x376 (bvand ?x87 (_ bv240 32))))
(let (($x613 (or false false false)))
(let (($x610 (or $x613 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x80 (or $x610 false false)))
(and (not $x80) (or $x80 (and (distinct ?x376 ?x376) true)))))))))
(check-sat)
; query 13: function adpcm_coder, block 87, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x234 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv4294967295 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv4294967295 32)))) true)))
(let (($x42 (or false false (or $x234))))
(and (not $x42) (or $x42 (and (distinct (bvadd in.02_32 (_ bv4294967295 32)) (bvadd in.02_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 14: function adpcm_decoder, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x10 (ite (and (distinct (_ bv0 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x613 (or false false false)))
(let (($x309 (not $x613)))
(and $x309 (or $x613 (and (distinct ?x10 ?x10) true)))))))
(check-sat)
; query 15: function adpcm_decoder, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x613 (or false false false)))
(let (($x309 (not $x613)))
(and $x309 (or $x613 (and (distinct (bvand in.01_32 (_ bv15 32)) (bvand in.01_32 (_ bv15 32))) true))))))
(check-sat)
; query 16: function adpcm_decoder, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.012_32 () (_ BitVec 32))
(declare-fun in42_32 () (_ BitVec 32))
(assert
 (let (($x303 (and (distinct (bvadd ((_ sign_extend 1) in42_32) ((_ sign_extend 1) in.012_32)) ((_ sign_extend 1) (bvadd in42_32 in.012_32))) true)))
(let (($x122 (or false false (or $x303))))
(let (($x131 (or $x122 (and (distinct (bvadd in42_32 in.012_32) (bvadd in42_32 in.012_32)) true))))
(and (not $x122) $x131)))))
(check-sat)
; query 17: function adpcm_decoder, block 50, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.012_32 () (_ BitVec 32))
(assert
 (let (($x613 (or false false false)))
(let (($x67 (or $x613 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x88 (or $x67 (and (distinct (bvashr in.012_32 (_ bv1 32)) (bvashr in.012_32 (_ bv1 32))) true))))
(and (not $x67) $x88)))))
(check-sat)
; query 18: function adpcm_decoder, block 50, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.012_32 () (_ BitVec 32))
(declare-fun in.08_32 () (_ BitVec 32))
(assert
 (let ((?x313 (bvashr in.012_32 (_ bv1 32))))
(let ((?x618 (bvadd in.08_32 ?x313)))
(let (($x263 (and (distinct (bvadd ((_ sign_extend 1) in.08_32) ((_ sign_extend 1) ?x313)) ((_ sign_extend 1) ?x618)) true)))
(let (($x613 (or false false false)))
(let (($x67 (or $x613 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x138 (or false $x67 (or $x263))))
(and (not $x138) (or $x138 (and (distinct ?x618 ?x618) true))))))))))
(check-sat)
; query 19: function adpcm_decoder, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.012_32 () (_ BitVec 32))
(assert
 (let (($x613 (or false false false)))
(let (($x252 (or $x613 (bvuge (_ bv2 32) (_ bv32 32)))))
(let (($x382 (or $x252 (and (distinct (bvashr in.012_32 (_ bv2 32)) (bvashr in.012_32 (_ bv2 32))) true))))
(and (not $x252) $x382)))))
(check-sat)
; query 20: function adpcm_decoder, block 56, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.012_32 () (_ BitVec 32))
(declare-fun in.19_32 () (_ BitVec 32))
(assert
 (let ((?x616 (bvashr in.012_32 (_ bv2 32))))
(let ((?x392 (bvadd in.19_32 ?x616)))
(let (($x438 (and (distinct (bvadd ((_ sign_extend 1) in.19_32) ((_ sign_extend 1) ?x616)) ((_ sign_extend 1) ?x392)) true)))
(let (($x613 (or false false false)))
(let (($x252 (or $x613 (bvuge (_ bv2 32) (_ bv32 32)))))
(let (($x11 (or false $x252 (or $x438))))
(and (not $x11) (or $x11 (and (distinct ?x392 ?x392) true))))))))))
(check-sat)
; query 21: function adpcm_decoder, block 61, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.210_32 () (_ BitVec 32))
(declare-fun in.013_32 () (_ BitVec 32))
(assert
 (let ((?x339 (bvsub in.013_32 in.210_32)))
(let (($x329 (and (distinct (bvsub ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x339)) true)))
(let (($x475 (or false false (or $x329))))
(and (not $x475) (or $x475 (and (distinct ?x339 ?x339) true)))))))
(check-sat)
; query 22: function adpcm_decoder, block 63, name %64
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.210_32 () (_ BitVec 32))
(declare-fun in.013_32 () (_ BitVec 32))
(assert
 (let ((?x55 (bvadd in.013_32 in.210_32)))
(let (($x504 (and (distinct (bvadd ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x55)) true)))
(let (($x184 (or false false (or $x504))))
(and (not $x184) (or $x184 (and (distinct ?x55 ?x55) true)))))))
(check-sat)
; query 23: function adpcm_decoder, block 68, name %69
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.114_32 () (_ BitVec 32))
(assert
 (let ((?x379 (ite (bvsgt (_ bv4294934528 32) in.114_32) (_ bv1 1) (_ bv0 1))))
(let (($x613 (or false false false)))
(let (($x309 (not $x613)))
(and $x309 (or $x613 (and (distinct ?x379 ?x379) true)))))))
(check-sat)
; query 24: function adpcm_decoder, block 78, name %79
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x234 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv4294967295 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv4294967295 32)))) true)))
(let (($x42 (or false false (or $x234))))
(and (not $x42) (or $x42 (and (distinct (bvadd in.02_32 (_ bv4294967295 32)) (bvadd in.02_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 25: function main, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x489 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x613 (or false false false)))
(let (($x309 (not $x613)))
(and $x309 (or $x613 (and (distinct ?x489 ?x489) true)))))))
(check-sat)
