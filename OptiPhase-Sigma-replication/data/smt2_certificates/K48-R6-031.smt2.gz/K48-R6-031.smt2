; OptiPhase-Sigma refinement certificate for sweep K48-R6-031
; query 0: function Decoding_of_the_coded_Log_Area_Ratios, block 107, name %108
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in104_64 () (_ BitVec 64))
(assert
 (let ((?x147 (ite (bvslt (_ bv0 64) in104_64) (_ bv1 1) (_ bv0 1))))
(let (($x8 (or false false false)))
(let (($x2781 (not $x8)))
(and $x2781 (or $x8 (and (distinct ?x147 ?x147) true)))))))
(check-sat)
; query 1: function Decoding_of_the_coded_Log_Area_Ratios, block 107, name %109
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in104_64 () (_ BitVec 64))
(assert
 (let (($x38 (and (distinct ((_ zero_extend 63) (ite (bvslt (_ bv0 64) in104_64) (_ bv1 1) (_ bv0 1))) (ite (= (_ bv1 1) (ite (bvslt (_ bv0 64) in104_64) (_ bv1 1) (_ bv0 1))) (_ bv32767 64) (_ bv18446744073709518848 64))) true)))
(let (($x8 (or false false false)))
(let (($x87 (or $x8 (ite (= (_ bv1 1) (ite (bvslt (_ bv0 64) in104_64) (_ bv1 1) (_ bv0 1))) false false))))
(and (not (or $x8 false)) (or $x87 $x38))))))
(check-sat)
; query 2: function Decoding_of_the_coded_Log_Area_Ratios, block 219, name %220
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in216_64 () (_ BitVec 64))
(assert
 (let (($x10 (and (distinct (ite (bvsge (_ bv18446744073709518848 64) in216_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv0 64) in216_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x8 (or false false false)))
(let (($x2781 (not $x8)))
(and $x2781 (or $x8 $x10))))))
(check-sat)
; query 3: function gsm_L_add, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let (($x146 (and (distinct (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv18446744073709551615 64) in1_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x8 (or false false false)))
(let (($x2781 (not $x8)))
(and $x2781 (or $x8 $x146))))))
(check-sat)
; query 4: function gsm_L_add, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x18 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvadd in0_64 in1_64))) true)))
(let (($x349 (or false false (or $x18))))
(let (($x124 (or $x349 (and (distinct (bvadd in0_64 in1_64) (bvadd in0_64 in1_64)) true))))
(and (not $x349) $x124)))))
(check-sat)
; query 5: function gsm_L_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x56 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x8 (or false false false)))
(let (($x2781 (not $x8)))
(and $x2781 (or $x8 (and (distinct ?x56 ?x56) true)))))))
(check-sat)
; query 6: function gsm_L_asl, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x460 (and (distinct (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvsgt (_ bv4294967265 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x8 (or false false false)))
(let (($x2781 (not $x8)))
(and $x2781 (or $x8 $x460))))))
(check-sat)
; query 7: function gsm_L_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x75 (and (distinct (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv31 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x8 (or false false false)))
(let (($x2781 (not $x8)))
(and $x2781 (or $x8 $x75))))))
(check-sat)
; query 8: function gsm_L_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x75 (and (distinct (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv31 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x8 (or false false false)))
(let (($x2781 (not $x8)))
(and $x2781 (or $x8 $x75))))))
(check-sat)
; query 9: function gsm_L_sub, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x244 (bvsub in0_64 in1_64)))
(let (($x30 (and (distinct ?x244 ?x244) true)))
(let (($x507 (and (distinct (bvsub ((_ zero_extend 1) in0_64) ((_ zero_extend 1) in1_64)) ((_ zero_extend 1) ?x244)) true)))
(let (($x557 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) ?x244)) true)))
(let (($x32 (or false false (or $x557))))
(let (($x407 (not $x32)))
(and $x407 (or (or false false (or $x507)) $x30)))))))))
(check-sat)
; query 10: function gsm_L_sub, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let (($x146 (and (distinct (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv18446744073709551615 64) in1_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x8 (or false false false)))
(let (($x2781 (not $x8)))
(and $x2781 (or $x8 $x146))))))
(check-sat)
; query 11: function gsm_L_sub, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x244 (bvsub in0_64 in1_64)))
(let (($x30 (and (distinct ?x244 ?x244) true)))
(let (($x557 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) ?x244)) true)))
(let (($x32 (or false false (or $x557))))
(let (($x407 (not $x32)))
(and $x407 (or $x32 $x30))))))))
(check-sat)
; query 12: function gsm_L_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x572 (and (distinct (ite (bvsle (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv18446744073709551615 64) in0_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x8 (or false false false)))
(let (($x2781 (not $x8)))
(and $x2781 (or $x8 $x572))))))
(check-sat)
; query 13: function gsm_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_64 () (_ BitVec 64))
(assert
 (let ((?x278 (ite (bvslt (_ bv32767 64) in5_64) (_ bv1 1) (_ bv0 1))))
(let (($x8 (or false false false)))
(let (($x2781 (not $x8)))
(and $x2781 (or $x8 (and (distinct ?x278 ?x278) true)))))))
(check-sat)
; query 14: function gsm_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x398 (or false false)))
(let (($x753 (not $x398)))
(and $x753 (or $x398 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 15: function gsm_add, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x398 (or false false)))
(let (($x753 (not $x398)))
(and $x753 (or $x398 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 16: function gsm_add, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x564 ((_ sign_extend 48) in1_16)))
(let ((?x37 ((_ sign_extend 48) in0_16)))
(let ((?x281 (bvadd ?x37 ?x564)))
(let (($x70 (and (distinct (bvadd ((_ sign_extend 1) ?x37) ((_ sign_extend 1) ?x564)) ((_ sign_extend 1) ?x281)) true)))
(let (($x398 (or false false)))
(let (($x543 (or $x398 $x398 (or $x70))))
(and (not $x543) (or $x543 (and (distinct ?x281 ?x281) true))))))))))
(check-sat)
; query 17: function gsm_add, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x98 (ite (bvsgt (_ bv18446744073709518848 64) (bvadd ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x564 ((_ sign_extend 48) in1_16)))
(let ((?x477 ((_ sign_extend 1) ?x564)))
(let ((?x37 ((_ sign_extend 48) in0_16)))
(let ((?x181 ((_ sign_extend 1) ?x37)))
(let (($x398 (or false false)))
(let (($x543 (or $x398 $x398 (or (and (distinct (bvadd ?x181 ?x477) ((_ sign_extend 1) (bvadd ?x37 ?x564))) true)))))
(let (($x19 (or $x543 false false)))
(and (not $x19) (or $x19 (and (distinct ?x98 ?x98) true))))))))))))
(check-sat)
; query 18: function gsm_asl, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x275 (and (distinct (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvsgt (_ bv4294967281 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x8 (or false false false)))
(let (($x2781 (not $x8)))
(and $x2781 (or $x8 $x275))))))
(check-sat)
; query 19: function gsm_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x481 (and (distinct (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv15 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x8 (or false false false)))
(let (($x2781 (not $x8)))
(and $x2781 (or $x8 $x481))))))
(check-sat)
; query 20: function gsm_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x481 (and (distinct (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv15 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x8 (or false false false)))
(let (($x2781 (not $x8)))
(and $x2781 (or $x8 $x481))))))
(check-sat)
; query 21: function gsm_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_64 () (_ BitVec 64))
(assert
 (let ((?x278 (ite (bvslt (_ bv32767 64) in5_64) (_ bv1 1) (_ bv0 1))))
(let (($x8 (or false false false)))
(let (($x2781 (not $x8)))
(and $x2781 (or $x8 (and (distinct ?x278 ?x278) true)))))))
(check-sat)
; query 22: function gsm_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x398 (or false false)))
(let (($x753 (not $x398)))
(and $x753 (or $x398 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 23: function gsm_sub, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x398 (or false false)))
(let (($x753 (not $x398)))
(and $x753 (or $x398 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 24: function gsm_sub, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x564 ((_ sign_extend 48) in1_16)))
(let ((?x37 ((_ sign_extend 48) in0_16)))
(let ((?x630 (bvsub ?x37 ?x564)))
(let (($x24 (and (distinct (bvsub ((_ sign_extend 1) ?x37) ((_ sign_extend 1) ?x564)) ((_ sign_extend 1) ?x630)) true)))
(let (($x398 (or false false)))
(let (($x323 (or $x398 $x398 (or $x24))))
(and (not $x323) (or $x323 (and (distinct ?x630 ?x630) true))))))))))
(check-sat)
; query 25: function gsm_sub, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x41 (ite (bvsgt (_ bv18446744073709518848 64) (bvsub ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x564 ((_ sign_extend 48) in1_16)))
(let ((?x477 ((_ sign_extend 1) ?x564)))
(let ((?x37 ((_ sign_extend 48) in0_16)))
(let ((?x181 ((_ sign_extend 1) ?x37)))
(let (($x398 (or false false)))
(let (($x323 (or $x398 $x398 (or (and (distinct (bvsub ?x181 ?x477) ((_ sign_extend 1) (bvsub ?x37 ?x564))) true)))))
(let (($x44 (or $x323 false false)))
(and (not $x44) (or $x44 (and (distinct ?x41 ?x41) true))))))))))))
(check-sat)
