; OptiPhase-Sigma refinement certificate for sweep K09-R2-064
