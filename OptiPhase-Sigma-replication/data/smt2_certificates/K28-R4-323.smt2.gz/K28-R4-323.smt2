; OptiPhase-Sigma refinement certificate for sweep K28-R4-323
