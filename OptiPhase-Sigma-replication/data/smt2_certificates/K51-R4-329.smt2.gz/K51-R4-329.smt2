; OptiPhase-Sigma refinement certificate for sweep K51-R4-329
