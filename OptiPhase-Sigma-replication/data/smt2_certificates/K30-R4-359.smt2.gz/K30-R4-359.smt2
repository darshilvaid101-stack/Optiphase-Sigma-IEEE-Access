; OptiPhase-Sigma refinement certificate for sweep K30-R4-359
; query 0: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x257 (ite (bvsgt (_ bv2 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x100 (or false false false)))
(and (not $x100) (or $x100 (and (distinct ?x257 ?x257) true))))))
(check-sat)
