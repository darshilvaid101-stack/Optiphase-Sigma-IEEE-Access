; OptiPhase-Sigma refinement certificate for sweep K10-R2-012
