; OptiPhase-Sigma refinement certificate for sweep K47-R6-029
; query 0: function main, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x7 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x848 (or false false false)))
(and (not $x848) (or $x848 (and (distinct ?x7 ?x7) true))))))
(check-sat)
