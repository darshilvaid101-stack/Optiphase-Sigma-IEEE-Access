; OptiPhase-Sigma refinement certificate for sweep K39-R2-088
; query 0: function BF_cbc_encrypt, block 126, name %127
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.010_64 () (_ BitVec 64))
(assert
 (let (($x234 (and (distinct (bvsub ((_ sign_extend 1) in.010_64) ((_ sign_extend 1) (_ bv8 64))) ((_ sign_extend 1) (bvsub in.010_64 (_ bv8 64)))) true)))
(let (($x83 (or false false (or $x234))))
(and (not $x83) (or $x83 (and (distinct (bvsub in.010_64 (_ bv8 64)) (bvsub in.010_64 (_ bv8 64))) true))))))
(check-sat)
; query 1: function BF_cbc_encrypt, block 128, name %129
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.010_64 () (_ BitVec 64))
(assert
 (let ((?x189 (ite (and (distinct (_ bv18446744073709551608 64) in.010_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x134 (not $x52)))
(and $x134 (or $x52 (and (distinct ?x189 ?x189) true)))))))
(check-sat)
; query 2: function BF_cbc_encrypt, block 366, name %367
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.111_64 () (_ BitVec 64))
(assert
 (let (($x91 (and (distinct (bvsub ((_ sign_extend 1) in.111_64) ((_ sign_extend 1) (_ bv8 64))) ((_ sign_extend 1) (bvsub in.111_64 (_ bv8 64)))) true)))
(let (($x122 (or false false (or $x91))))
(and (not $x122) (or $x122 (and (distinct (bvsub in.111_64 (_ bv8 64)) (bvsub in.111_64 (_ bv8 64))) true))))))
(check-sat)
; query 3: function BF_cbc_encrypt, block 368, name %369
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.111_64 () (_ BitVec 64))
(assert
 (let ((?x89 (ite (and (distinct (_ bv18446744073709551608 64) in.111_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x134 (not $x52)))
(and $x134 (or $x52 (and (distinct ?x89 ?x89) true)))))))
(check-sat)
; query 4: function BF_cfb64_encrypt, block 111, name %112
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.18_32 () (_ BitVec 32))
(assert
 (let ((?x576 (ite (= (_ bv0 32) in.18_32) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x134 (not $x52)))
(and $x134 (or $x52 (and (distinct ?x576 ?x576) true)))))))
(check-sat)
; query 5: function BF_cfb64_encrypt, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.07_32 () (_ BitVec 32))
(assert
 (let ((?x16 (ite (= (_ bv0 32) in.07_32) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x134 (not $x52)))
(and $x134 (or $x52 (and (distinct ?x16 ?x16) true)))))))
(check-sat)
; query 6: function BF_ofb64_encrypt, block 135, name %136
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x61 (ite (and (distinct (_ bv0 32) in.02_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x134 (not $x52)))
(and $x134 (or $x52 (and (distinct ?x61 ?x61) true)))))))
(check-sat)
; query 7: function BF_ofb64_encrypt, block 82, name %83
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x467 (ite (= (_ bv0 32) in.04_32) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x134 (not $x52)))
(and $x134 (or $x52 (and (distinct ?x467 ?x467) true)))))))
(check-sat)
; query 8: function BF_set_key, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x190 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x96 (or false false (or $x190))))
(and (not $x96) (or $x96 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 9: function BF_set_key, block 69, name %70
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.13_32 () (_ BitVec 32))
(assert
 (let (($x78 (and (distinct (bvadd ((_ sign_extend 1) in.13_32) ((_ sign_extend 1) (_ bv2 32))) ((_ sign_extend 1) (bvadd in.13_32 (_ bv2 32)))) true)))
(let (($x225 (or false false (or $x78))))
(and (not $x225) (or $x225 (and (distinct (bvadd in.13_32 (_ bv2 32)) (bvadd in.13_32 (_ bv2 32))) true))))))
(check-sat)
; query 10: function BF_set_key, block 87, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.24_32 () (_ BitVec 32))
(assert
 (let (($x227 (and (distinct (bvadd ((_ sign_extend 1) in.24_32) ((_ sign_extend 1) (_ bv2 32))) ((_ sign_extend 1) (bvadd in.24_32 (_ bv2 32)))) true)))
(let (($x129 (or false false (or $x227))))
(and (not $x129) (or $x129 (and (distinct (bvadd in.24_32 (_ bv2 32)) (bvadd in.24_32 (_ bv2 32))) true))))))
(check-sat)
; query 11: function main, block 124, name %125
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let ((?x235 (ite (bvsgt (_ bv40 32) in.2_32) (_ bv1 1) (_ bv0 1))))
(let (($x52 (or false false false)))
(let (($x134 (not $x52)))
(and $x134 (or $x52 (and (distinct ?x235 ?x235) true)))))))
(check-sat)
; query 12: function main, block 147, name %148
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x99 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x47 (or false false (or $x99))))
(and (not $x47) (or $x47 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 13: function main, block 60, name %61
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x95 (or false false)))
(and (not $x95) (or $x95 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 14: function main, block 60, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x647 (ite (bvsge (_ bv57 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x95 (or false false)))
(let (($x282 (or $x95 false false)))
(let (($x81 (not $x282)))
(and $x81 (or $x282 (and (distinct ?x647 ?x647) true))))))))
(check-sat)
; query 15: function main, block 63, name %64
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x52 (or false false false)))
(let (($x49 (or $x52 (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x49) (or $x49 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvshl in.01_32 (_ bv4 32))) true))))))
(check-sat)
; query 16: function main, block 63, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x95 (or false false)))
(and (not $x95) (or $x95 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 17: function main, block 63, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x104 ((_ sign_extend 24) in57_8)))
(let ((?x130 (bvshl in.01_32 (_ bv4 32))))
(let ((?x169 (bvadd ?x130 ?x104)))
(let ((?x608 ((_ sign_extend 1) ?x169)))
(let (($x95 (or false false)))
(let (($x52 (or false false false)))
(let (($x49 (or $x52 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x40 (or $x49 $x95 (or (and (distinct (bvadd ((_ sign_extend 1) ?x130) ((_ sign_extend 1) ?x104)) ?x608) true)))))
(and (not $x40) (or $x40 (and (distinct ?x169 ?x169) true))))))))))))
(check-sat)
; query 18: function main, block 63, name %67
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x104 ((_ sign_extend 24) in57_8)))
(let ((?x130 (bvshl in.01_32 (_ bv4 32))))
(let ((?x169 (bvadd ?x130 ?x104)))
(let ((?x74 (bvsub ?x169 (_ bv48 32))))
(let (($x41 (and (distinct (bvsub ((_ sign_extend 1) ?x169) ((_ sign_extend 1) (_ bv48 32))) ((_ sign_extend 1) ?x74)) true)))
(let ((?x608 ((_ sign_extend 1) ?x169)))
(let (($x95 (or false false)))
(let (($x52 (or false false false)))
(let (($x49 (or $x52 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x40 (or $x49 $x95 (or (and (distinct (bvadd ((_ sign_extend 1) ?x130) ((_ sign_extend 1) ?x104)) ?x608) true)))))
(let (($x63 (or $x40 false (or $x41))))
(and (not $x63) (or $x63 (and (distinct ?x74 ?x74) true)))))))))))))))
(check-sat)
; query 19: function main, block 68, name %69
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x95 (or false false)))
(and (not $x95) (or $x95 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 20: function main, block 68, name %70
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x93 (ite (bvsle (_ bv65 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x95 (or false false)))
(let (($x282 (or $x95 false false)))
(let (($x81 (not $x282)))
(and $x81 (or $x282 (and (distinct ?x93 ?x93) true))))))))
(check-sat)
; query 21: function main, block 71, name %72
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x95 (or false false)))
(and (not $x95) (or $x95 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 22: function main, block 71, name %73
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x70 (ite (bvsge (_ bv70 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x95 (or false false)))
(let (($x282 (or $x95 false false)))
(let (($x81 (not $x282)))
(and $x81 (or $x282 (and (distinct ?x70 ?x70) true))))))))
(check-sat)
; query 23: function main, block 74, name %75
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x52 (or false false false)))
(let (($x49 (or $x52 (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x49) (or $x49 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvshl in.01_32 (_ bv4 32))) true))))))
(check-sat)
; query 24: function main, block 74, name %76
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x95 (or false false)))
(and (not $x95) (or $x95 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 25: function main, block 74, name %77
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x104 ((_ sign_extend 24) in57_8)))
(let ((?x130 (bvshl in.01_32 (_ bv4 32))))
(let ((?x169 (bvadd ?x130 ?x104)))
(let ((?x608 ((_ sign_extend 1) ?x169)))
(let (($x95 (or false false)))
(let (($x52 (or false false false)))
(let (($x49 (or $x52 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x40 (or $x49 $x95 (or (and (distinct (bvadd ((_ sign_extend 1) ?x130) ((_ sign_extend 1) ?x104)) ?x608) true)))))
(and (not $x40) (or $x40 (and (distinct ?x169 ?x169) true))))))))))))
(check-sat)
; query 26: function main, block 74, name %78
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x104 ((_ sign_extend 24) in57_8)))
(let ((?x130 (bvshl in.01_32 (_ bv4 32))))
(let ((?x169 (bvadd ?x130 ?x104)))
(let ((?x1055 (bvsub ?x169 (_ bv65 32))))
(let ((?x180 ((_ sign_extend 1) ?x1055)))
(let ((?x608 ((_ sign_extend 1) ?x169)))
(let (($x95 (or false false)))
(let (($x52 (or false false false)))
(let (($x49 (or $x52 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x40 (or $x49 $x95 (or (and (distinct (bvadd ((_ sign_extend 1) ?x130) ((_ sign_extend 1) ?x104)) ?x608) true)))))
(let (($x28 (or $x40 false (or (and (distinct (bvsub ?x608 ((_ sign_extend 1) (_ bv65 32))) ?x180) true)))))
(and (not $x28) (or $x28 (and (distinct ?x1055 ?x1055) true)))))))))))))))
(check-sat)
; query 27: function main, block 74, name %79
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x104 ((_ sign_extend 24) in57_8)))
(let ((?x130 (bvshl in.01_32 (_ bv4 32))))
(let ((?x169 (bvadd ?x130 ?x104)))
(let ((?x1055 (bvsub ?x169 (_ bv65 32))))
(let ((?x179 (bvadd ?x1055 (_ bv10 32))))
(let (($x277 (and (distinct (bvadd ((_ sign_extend 1) ?x1055) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x179)) true)))
(let ((?x180 ((_ sign_extend 1) ?x1055)))
(let ((?x608 ((_ sign_extend 1) ?x169)))
(let (($x95 (or false false)))
(let (($x52 (or false false false)))
(let (($x49 (or $x52 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x40 (or $x49 $x95 (or (and (distinct (bvadd ((_ sign_extend 1) ?x130) ((_ sign_extend 1) ?x104)) ?x608) true)))))
(let (($x28 (or $x40 false (or (and (distinct (bvsub ?x608 ((_ sign_extend 1) (_ bv65 32))) ?x180) true)))))
(let (($x162 (or $x28 false (or $x277))))
(and (not $x162) (or $x162 (and (distinct ?x179 ?x179) true))))))))))))))))))
(check-sat)
