; OptiPhase-Sigma refinement certificate for sweep K54-R6-017
; query 0: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x79 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x101 (or false false false)))
(let (($x1097 (not $x101)))
(and $x1097 (or $x101 (and (distinct ?x79 ?x79) true)))))))
(check-sat)
; query 1: function set1d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x818 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x101 (or false false false)))
(let (($x1097 (not $x101)))
(and $x1097 (or $x101 (and (distinct ?x818 ?x818) true)))))))
(check-sat)
; query 2: function set1ds, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x61 (ite (= (_ bv4294967295 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x101 (or false false false)))
(let (($x1097 (not $x101)))
(and $x1097 (or $x101 (and (distinct ?x61 ?x61) true)))))))
(check-sat)
; query 3: function set2d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x818 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x101 (or false false false)))
(let (($x1097 (not $x101)))
(and $x1097 (or $x101 (and (distinct ?x818 ?x818) true)))))))
(check-sat)
