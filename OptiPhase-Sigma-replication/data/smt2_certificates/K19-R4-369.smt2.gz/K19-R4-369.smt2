; OptiPhase-Sigma refinement certificate for sweep K19-R4-369
