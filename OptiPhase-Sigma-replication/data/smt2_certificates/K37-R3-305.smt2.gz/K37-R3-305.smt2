; OptiPhase-Sigma refinement certificate for sweep K37-R3-305
; query 0: function bit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x72 (and (distinct (bvsub ((_ sign_extend 1) (_ bv31 32)) ((_ sign_extend 1) in0_32)) ((_ sign_extend 1) (bvsub (_ bv31 32) in0_32))) true)))
(let (($x19 (or false false (or $x72))))
(and (not $x19) (or $x19 (and (distinct (bvsub (_ bv31 32) in0_32) (bvsub (_ bv31 32) in0_32)) true))))))
(check-sat)
; query 1: function bit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x1025 (bvsub (_ bv31 32) in0_32)))
(let ((?x590 (bvshl (_ bv1 32) ?x1025)))
(let (($x72 (and (distinct (bvsub ((_ sign_extend 1) (_ bv31 32)) ((_ sign_extend 1) in0_32)) ((_ sign_extend 1) ?x1025)) true)))
(let (($x19 (or false false (or $x72))))
(let (($x197 (or (or false $x19 false) (bvuge ?x1025 (_ bv32 32)))))
(and (not $x197) (or $x197 (and (distinct ?x590 ?x590) true)))))))))
(check-sat)
; query 2: function bit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x1025 (bvsub (_ bv31 32) in0_32)))
(let ((?x590 (bvshl (_ bv1 32) ?x1025)))
(let ((?x389 ((_ sign_extend 32) ?x590)))
(let (($x72 (and (distinct (bvsub ((_ sign_extend 1) (_ bv31 32)) ((_ sign_extend 1) in0_32)) ((_ sign_extend 1) ?x1025)) true)))
(let (($x19 (or false false (or $x72))))
(let (($x197 (or (or false $x19 false) (bvuge ?x1025 (_ bv32 32)))))
(let (($x224 (or $x197 false)))
(and (not $x224) (or $x224 (and (distinct ?x389 ?x389) true)))))))))))
(check-sat)
; query 3: function bit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x621 (and (distinct (bvand in1_64 ((_ sign_extend 32) (bvshl (_ bv1 32) (bvsub (_ bv31 32) in0_32)))) (bvand ((_ sign_extend 32) (bvshl (_ bv1 32) (bvsub (_ bv31 32) in0_32))) in1_64)) true)))
(let (($x72 (and (distinct (bvsub ((_ sign_extend 1) (_ bv31 32)) ((_ sign_extend 1) in0_32)) ((_ sign_extend 1) (bvsub (_ bv31 32) in0_32))) true)))
(let (($x19 (or false false (or $x72))))
(let (($x197 (or (or false $x19 false) (bvuge (bvsub (_ bv31 32) in0_32) (_ bv32 32)))))
(let (($x224 (or $x197 false)))
(and (not (or false $x224 false)) (or (or $x224 false false) $x621))))))))
(check-sat)
