; OptiPhase-Sigma refinement certificate for sweep K58-R2-072
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x86 (or false false)))
(let (($x2784 (not $x86)))
(and $x2784 (or $x86 (and (distinct ((_ sign_extend 16) in25_16) ((_ sign_extend 16) in25_16)) true))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let ((?x514 (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))))
(let (($x86 (or false false)))
(let (($x492 (or $x86 false false)))
(let (($x924 (not $x492)))
(and $x924 (or $x492 (and (distinct ?x514 ?x514) true))))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x86 (or false false)))
(let (($x2784 (not $x86)))
(and $x2784 (or $x86 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x604 ((_ sign_extend 16) in3_16)))
(let ((?x105 (bvand ?x604 (_ bv127 32))))
(let (($x86 (or false false)))
(let (($x492 (or $x86 false false)))
(let (($x924 (not $x492)))
(and $x924 (or $x492 (and (distinct ?x105 ?x105) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x604 ((_ sign_extend 16) in3_16)))
(let ((?x105 (bvand ?x604 (_ bv127 32))))
(let ((?x630 ((_ extract 15 0) ?x105)))
(let (($x86 (or false false)))
(let (($x492 (or $x86 false false)))
(let (($x64 (or $x492 false)))
(let (($x122 (not $x64)))
(and $x122 (or $x64 (and (distinct ?x630 ?x630) true)))))))))))
(check-sat)
; query 5: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x86 (or false false)))
(let (($x2784 (not $x86)))
(and $x2784 (or $x86 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 6: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x2785 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x86 (or false false)))
(let (($x492 (or $x86 false false)))
(let (($x924 (not $x492)))
(and $x924 (or $x492 (and (distinct ?x2785 ?x2785) true))))))))
(check-sat)
; query 7: function core_bench_list, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x562 (or false false false)))
(let (($x753 (not $x562)))
(and $x753 (or $x562 (and (distinct (bvadd in.0_16 (_ bv1 16)) (bvadd in.0_16 (_ bv1 16))) true))))))
(check-sat)
; query 8: function core_bench_list, block 82, name %83
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let (($x86 (or false false)))
(let (($x2784 (not $x86)))
(and $x2784 (or $x86 (and (distinct ((_ zero_extend 16) in.02_16) ((_ zero_extend 16) in.02_16)) true))))))
(check-sat)
; query 9: function core_bench_list, block 82, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x181 ((_ zero_extend 16) in.02_16)))
(let ((?x120 (bvmul ?x181 (_ bv4 32))))
(let (($x509 (and (distinct (bvmul ((_ sign_extend 32) ?x181) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x120)) true)))
(let (($x86 (or false false)))
(let (($x235 (or $x86 false (or $x509))))
(and (not $x235) (or $x235 (and (distinct ?x120 ?x120) true)))))))))
(check-sat)
; query 10: function core_bench_list, block 82, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let (($x86 (or false false)))
(let (($x2784 (not $x86)))
(and $x2784 (or $x86 (and (distinct ((_ zero_extend 16) in.04_16) ((_ zero_extend 16) in.04_16)) true))))))
(check-sat)
; query 11: function core_bench_list, block 82, name %86
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x476 ((_ zero_extend 16) in.04_16)))
(let ((?x181 ((_ zero_extend 16) in.02_16)))
(let ((?x120 (bvmul ?x181 (_ bv4 32))))
(let ((?x477 (bvsub ?x120 ?x476)))
(let ((?x114 ((_ sign_extend 1) ?x477)))
(let (($x86 (or false false)))
(let (($x509 (and (distinct (bvmul ((_ sign_extend 32) ?x181) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x120)) true)))
(let (($x235 (or $x86 false (or $x509))))
(let (($x98 (or $x235 $x86 (or (and (distinct (bvsub ((_ sign_extend 1) ?x120) ((_ sign_extend 1) ?x476)) ?x114) true)))))
(and (not $x98) (or $x98 (and (distinct ?x477 ?x477) true)))))))))))))
(check-sat)
; query 12: function core_bench_list, block 82, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x86 (or false false)))
(let (($x2784 (not $x86)))
(and $x2784 (or $x86 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 13: function core_bench_list, block 82, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x476 ((_ zero_extend 16) in.04_16)))
(let ((?x181 ((_ zero_extend 16) in.02_16)))
(let ((?x120 (bvmul ?x181 (_ bv4 32))))
(let ((?x477 (bvsub ?x120 ?x476)))
(let ((?x927 ((_ zero_extend 16) in.01_16)))
(let ((?x24 (bvadd ?x927 ?x477)))
(let (($x524 (and (distinct (bvadd ((_ sign_extend 1) ?x927) ((_ sign_extend 1) ?x477)) ((_ sign_extend 1) ?x24)) true)))
(let ((?x114 ((_ sign_extend 1) ?x477)))
(let (($x86 (or false false)))
(let (($x509 (and (distinct (bvmul ((_ sign_extend 32) ?x181) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x120)) true)))
(let (($x235 (or $x86 false (or $x509))))
(let (($x98 (or $x235 $x86 (or (and (distinct (bvsub ((_ sign_extend 1) ?x120) ((_ sign_extend 1) ?x476)) ?x114) true)))))
(let (($x18 (or $x86 $x98 (or $x524))))
(and (not $x18) (or $x18 (and (distinct ?x24 ?x24) true)))))))))))))))))
(check-sat)
; query 14: function core_bench_list, block 82, name %89
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x476 ((_ zero_extend 16) in.04_16)))
(let ((?x181 ((_ zero_extend 16) in.02_16)))
(let ((?x120 (bvmul ?x181 (_ bv4 32))))
(let ((?x477 (bvsub ?x120 ?x476)))
(let ((?x927 ((_ zero_extend 16) in.01_16)))
(let ((?x24 (bvadd ?x927 ?x477)))
(let ((?x420 ((_ extract 15 0) ?x24)))
(let (($x524 (and (distinct (bvadd ((_ sign_extend 1) ?x927) ((_ sign_extend 1) ?x477)) ((_ sign_extend 1) ?x24)) true)))
(let ((?x114 ((_ sign_extend 1) ?x477)))
(let (($x86 (or false false)))
(let (($x509 (and (distinct (bvmul ((_ sign_extend 32) ?x181) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x120)) true)))
(let (($x235 (or $x86 false (or $x509))))
(let (($x98 (or $x235 $x86 (or (and (distinct (bvsub ((_ sign_extend 1) ?x120) ((_ sign_extend 1) ?x476)) ?x114) true)))))
(let (($x18 (or $x86 $x98 (or $x524))))
(let (($x323 (or $x18 false)))
(and (not $x323) (or $x323 (and (distinct ?x420 ?x420) true)))))))))))))))))))
(check-sat)
; query 15: function core_bench_list, block 82, name %90
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x86 (or false false)))
(let (($x2784 (not $x86)))
(and $x2784 (or $x86 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 16: function core_bench_list, block 82, name %91
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x8 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x86 (or false false)))
(let (($x492 (or $x86 false false)))
(let (($x924 (not $x492)))
(and $x924 (or $x492 (and (distinct ?x8 ?x8) true))))))))
(check-sat)
; query 17: function core_bench_state, block 105, name %106
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x562 (or false false false)))
(let (($x753 (not $x562)))
(and $x753 (or $x562 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 18: function core_bench_state, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x562 (or false false false)))
(let (($x753 (not $x562)))
(and $x753 (or $x562 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 19: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x83 (bvadd in.01_32 (_ bv1 32))))
(let (($x720 (and (distinct ?x83 ?x83) true)))
(let (($x562 (or false false false)))
(let (($x753 (not $x562)))
(and $x753 (or $x562 $x720)))))))
(check-sat)
; query 20: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x83 (bvadd in.01_32 (_ bv1 32))))
(let ((?x793 (bvmul ?x83 ?x83)))
(let (($x562 (or false false false)))
(let (($x182 (or $x562 $x562 false)))
(and (not $x182) (or $x182 (and (distinct ?x793 ?x793) true))))))))
(check-sat)
; query 21: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x83 (bvadd in.01_32 (_ bv1 32))))
(let ((?x793 (bvmul ?x83 ?x83)))
(let ((?x49 (bvmul ?x793 (_ bv2 32))))
(let (($x562 (or false false false)))
(let (($x182 (or $x562 $x562 false)))
(let (($x43 (or $x182 false false)))
(and (not $x43) (or $x43 (and (distinct ?x49 ?x49) true))))))))))
(check-sat)
; query 22: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x83 (bvadd in.01_32 (_ bv1 32))))
(let ((?x793 (bvmul ?x83 ?x83)))
(let ((?x49 (bvmul ?x793 (_ bv2 32))))
(let ((?x977 (bvmul ?x49 (_ bv4 32))))
(let (($x562 (or false false false)))
(let (($x182 (or $x562 $x562 false)))
(let (($x43 (or $x182 false false)))
(let (($x1014 (or $x43 false false)))
(and (not $x1014) (or $x1014 (and (distinct ?x977 ?x977) true))))))))))))
(check-sat)
; query 23: function core_init_matrix, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x562 (or false false false)))
(let (($x753 (not $x562)))
(and $x753 (or $x562 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 24: function core_init_matrix, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x562 (or false false false)))
(let (($x753 (not $x562)))
(and $x753 (or $x562 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 25: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x153 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x562 (or false false false)))
(let (($x753 (not $x562)))
(and $x753 (or $x562 (and (distinct ?x153 ?x153) true)))))))
(check-sat)
; query 26: function core_init_state, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_32 () (_ BitVec 32))
(assert
 (let (($x562 (or false false false)))
(let (($x753 (not $x562)))
(and $x753 (or $x562 (and (distinct (bvadd in.06_32 (_ bv1 32)) (bvadd in.06_32 (_ bv1 32))) true))))))
(check-sat)
; query 27: function core_init_state, block 65, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let (($x562 (or false false false)))
(let (($x753 (not $x562)))
(and $x753 (or $x562 (and (distinct (bvadd in4_32 (_ bv1 32)) (bvadd in4_32 (_ bv1 32))) true))))))
(check-sat)
; query 28: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x407 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x562 (or false false false)))
(let (($x753 (not $x562)))
(and $x753 (or $x562 (and (distinct ?x407 ?x407) true)))))))
(check-sat)
; query 29: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x562 (or false false false)))
(let (($x753 (not $x562)))
(and $x753 (or $x562 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 30: function core_list_init, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x83 (bvadd in.01_32 (_ bv1 32))))
(let (($x720 (and (distinct ?x83 ?x83) true)))
(let (($x562 (or false false false)))
(let (($x753 (not $x562)))
(and $x753 (or $x562 $x720)))))))
(check-sat)
; query 31: function core_list_mergesort, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x83 (bvadd in.01_32 (_ bv1 32))))
(let (($x720 (and (distinct ?x83 ?x83) true)))
(let (($x393 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x83)) true)))
(let (($x799 (or false false (or $x393))))
(and (not $x799) (or $x799 $x720)))))))
(check-sat)
; query 32: function core_list_mergesort, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x66 (ite (bvslt (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x562 (or false false false)))
(let (($x753 (not $x562)))
(and $x753 (or $x562 (and (distinct ?x66 ?x66) true)))))))
(check-sat)
; query 33: function core_list_mergesort, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.224_32 () (_ BitVec 32))
(assert
 (let ((?x1084 (ite (= (_ bv0 32) in.224_32) (_ bv1 1) (_ bv0 1))))
(let (($x562 (or false false false)))
(let (($x753 (not $x562)))
(and $x753 (or $x562 (and (distinct ?x1084 ?x1084) true)))))))
(check-sat)
; query 34: function core_list_mergesort, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x1744 (ite (= (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x562 (or false false false)))
(let (($x753 (not $x562)))
(and $x753 (or $x562 (and (distinct ?x1744 ?x1744) true)))))))
(check-sat)
; query 35: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x1306 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x557 (or false false (or $x1306))))
(and (not $x557) (or $x557 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 36: function core_list_mergesort, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x143 (and (distinct (bvmul ((_ sign_extend 32) in.020_32) ((_ sign_extend 32) (_ bv2 32))) ((_ sign_extend 32) (bvmul in.020_32 (_ bv2 32)))) true)))
(let (($x1910 (or false false (or $x143))))
(and (not $x1910) (or $x1910 (and (distinct (bvmul in.020_32 (_ bv2 32)) (bvmul in.020_32 (_ bv2 32))) true))))))
(check-sat)
; query 37: function core_state_transition, block 102, name %103
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x86 (or false false)))
(let (($x2784 (not $x86)))
(and $x2784 (or $x86 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 38: function core_state_transition, block 102, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1410 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x86 (or false false)))
(let (($x492 (or $x86 false false)))
(let (($x924 (not $x492)))
(and $x924 (or $x492 (and (distinct ?x1410 ?x1410) true))))))))
(check-sat)
; query 39: function core_state_transition, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x86 (or false false)))
(let (($x2784 (not $x86)))
(and $x2784 (or $x86 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 40: function core_state_transition, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x791 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x86 (or false false)))
(let (($x492 (or $x86 false false)))
(let (($x924 (not $x492)))
(and $x924 (or $x492 (and (distinct ?x791 ?x791) true))))))))
(check-sat)
; query 41: function core_state_transition, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x86 (or false false)))
(let (($x2784 (not $x86)))
(and $x2784 (or $x86 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 42: function core_state_transition, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1410 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x86 (or false false)))
(let (($x492 (or $x86 false false)))
(let (($x924 (not $x492)))
(and $x924 (or $x492 (and (distinct ?x1410 ?x1410) true))))))))
(check-sat)
; query 43: function core_state_transition, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x86 (or false false)))
(let (($x2784 (not $x86)))
(and $x2784 (or $x86 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 44: function core_state_transition, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1857 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x86 (or false false)))
(let (($x492 (or $x86 false false)))
(let (($x924 (not $x492)))
(and $x924 (or $x492 (and (distinct ?x1857 ?x1857) true))))))))
(check-sat)
; query 45: function core_state_transition, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x86 (or false false)))
(let (($x2784 (not $x86)))
(and $x2784 (or $x86 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 46: function core_state_transition, block 51, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1857 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x86 (or false false)))
(let (($x492 (or $x86 false false)))
(let (($x924 (not $x492)))
(and $x924 (or $x492 (and (distinct ?x1857 ?x1857) true))))))))
(check-sat)
; query 47: function core_state_transition, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x86 (or false false)))
(let (($x2784 (not $x86)))
(and $x2784 (or $x86 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 48: function core_state_transition, block 64, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1857 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x86 (or false false)))
(let (($x492 (or $x86 false false)))
(let (($x924 (not $x492)))
(and $x924 (or $x492 (and (distinct ?x1857 ?x1857) true))))))))
(check-sat)
; query 49: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x483 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x562 (or false false false)))
(let (($x753 (not $x562)))
(and $x753 (or $x562 (and (distinct ?x483 ?x483) true)))))))
(check-sat)
; query 50: function core_state_transition, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x86 (or false false)))
(let (($x2784 (not $x86)))
(and $x2784 (or $x86 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 51: function core_state_transition, block 80, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1843 (ite (= (_ bv69 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x86 (or false false)))
(let (($x492 (or $x86 false false)))
(let (($x924 (not $x492)))
(and $x924 (or $x492 (and (distinct ?x1843 ?x1843) true))))))))
(check-sat)
; query 52: function core_state_transition, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x86 (or false false)))
(let (($x2784 (not $x86)))
(and $x2784 (or $x86 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 53: function core_state_transition, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1940 (ite (= (_ bv101 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x86 (or false false)))
(let (($x492 (or $x86 false false)))
(let (($x924 (not $x492)))
(and $x924 (or $x492 (and (distinct ?x1940 ?x1940) true))))))))
(check-sat)
; query 54: function core_state_transition, block 99, name %100
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x86 (or false false)))
(let (($x2784 (not $x86)))
(and $x2784 (or $x86 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 55: function core_state_transition, block 99, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x791 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x86 (or false false)))
(let (($x492 (or $x86 false false)))
(let (($x924 (not $x492)))
(and $x924 (or $x492 (and (distinct ?x791 ?x791) true))))))))
(check-sat)
; query 56: function crcu8, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x86 (or false false)))
(let (($x2784 (not $x86)))
(and $x2784 (or $x86 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 57: function crcu8, block 19, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x927 ((_ zero_extend 16) in.01_16)))
(let ((?x111 (bvxor ?x927 (_ bv16386 32))))
(let (($x86 (or false false)))
(let (($x492 (or $x86 false false)))
(let (($x924 (not $x492)))
(and $x924 (or $x492 (and (distinct ?x111 ?x111) true)))))))))
(check-sat)
; query 58: function crcu8, block 19, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x927 ((_ zero_extend 16) in.01_16)))
(let ((?x111 (bvxor ?x927 (_ bv16386 32))))
(let ((?x1617 ((_ extract 15 0) ?x111)))
(let (($x86 (or false false)))
(let (($x492 (or $x86 false false)))
(let (($x64 (or $x492 false)))
(let (($x122 (not $x64)))
(and $x122 (or $x64 (and (distinct ?x1617 ?x1617) true)))))))))))
(check-sat)
; query 59: function crcu8, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x86 (or false false)))
(let (($x2784 (not $x86)))
(and $x2784 (or $x86 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 60: function crcu8, block 29, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1294 ((_ zero_extend 16) in27_16)))
(let ((?x12 (bvor ?x1294 (_ bv32768 32))))
(let (($x86 (or false false)))
(let (($x492 (or $x86 false false)))
(let (($x924 (not $x492)))
(and $x924 (or $x492 (and (distinct ?x12 ?x12) true)))))))))
(check-sat)
; query 61: function crcu8, block 29, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1294 ((_ zero_extend 16) in27_16)))
(let ((?x12 (bvor ?x1294 (_ bv32768 32))))
(let ((?x1387 ((_ extract 15 0) ?x12)))
(let (($x86 (or false false)))
(let (($x492 (or $x86 false false)))
(let (($x64 (or $x492 false)))
(let (($x122 (not $x64)))
(and $x122 (or $x64 (and (distinct ?x1387 ?x1387) true)))))))))))
(check-sat)
; query 62: function crcu8, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x86 (or false false)))
(let (($x2784 (not $x86)))
(and $x2784 (or $x86 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 63: function crcu8, block 33, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1294 ((_ zero_extend 16) in27_16)))
(let ((?x1236 (bvand ?x1294 (_ bv32767 32))))
(let (($x86 (or false false)))
(let (($x492 (or $x86 false false)))
(let (($x924 (not $x492)))
(and $x924 (or $x492 (and (distinct ?x1236 ?x1236) true)))))))))
(check-sat)
; query 64: function crcu8, block 33, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1294 ((_ zero_extend 16) in27_16)))
(let ((?x1236 (bvand ?x1294 (_ bv32767 32))))
(let ((?x1268 ((_ extract 15 0) ?x1236)))
(let (($x86 (or false false)))
(let (($x492 (or $x86 false false)))
(let (($x64 (or $x492 false)))
(let (($x122 (not $x64)))
(and $x122 (or $x64 (and (distinct ?x1268 ?x1268) true)))))))))))
(check-sat)
; query 65: function crcu8, block 38, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_8 () (_ BitVec 8))
(assert
 (let (($x562 (or false false false)))
(let (($x753 (not $x562)))
(and $x753 (or $x562 (and (distinct (bvadd in.02_8 (_ bv1 8)) (bvadd in.02_8 (_ bv1 8))) true))))))
(check-sat)
; query 66: function crcu8, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x171 ((_ extract 7 0) in.01_16)))
(let ((?x858 ((_ zero_extend 24) ?x171)))
(let (($x86 (or false false)))
(let (($x2783 (or $x86 false)))
(and (not $x2783) (or $x2783 (and (distinct ?x858 ?x858) true))))))))
(check-sat)
; query 67: function crcu8, block 6, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x171 ((_ extract 7 0) in.01_16)))
(let ((?x858 ((_ zero_extend 24) ?x171)))
(let ((?x2013 (bvand ?x858 (_ bv1 32))))
(let (($x86 (or false false)))
(let (($x2783 (or $x86 false)))
(let (($x2313 (or $x2783 false false)))
(and (not $x2313) (or $x2313 (and (distinct ?x2013 ?x2013) true))))))))))
(check-sat)
; query 68: function crcu8, block 6, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x171 ((_ extract 7 0) in.01_16)))
(let ((?x858 ((_ zero_extend 24) ?x171)))
(let ((?x2013 (bvand ?x858 (_ bv1 32))))
(let ((?x1335 ((_ zero_extend 24) in.0_8)))
(let ((?x1782 (bvand ?x1335 (_ bv1 32))))
(let ((?x2005 (bvxor ?x1782 ?x2013)))
(let (($x86 (or false false)))
(let (($x2783 (or $x86 false)))
(let (($x2313 (or $x2783 false false)))
(let (($x492 (or $x86 false false)))
(let (($x1835 (or $x492 $x2313 false)))
(and (not $x1835) (or $x1835 (and (distinct ?x2005 ?x2005) true)))))))))))))))
(check-sat)
; query 69: function crcu8, block 6, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x171 ((_ extract 7 0) in.01_16)))
(let ((?x858 ((_ zero_extend 24) ?x171)))
(let ((?x2013 (bvand ?x858 (_ bv1 32))))
(let ((?x1335 ((_ zero_extend 24) in.0_8)))
(let ((?x1782 (bvand ?x1335 (_ bv1 32))))
(let ((?x2005 (bvxor ?x1782 ?x2013)))
(let ((?x892 ((_ extract 7 0) ?x2005)))
(let (($x86 (or false false)))
(let (($x2783 (or $x86 false)))
(let (($x2313 (or $x2783 false false)))
(let (($x492 (or $x86 false false)))
(let (($x1835 (or $x492 $x2313 false)))
(let (($x826 (or $x1835 false)))
(and (not $x826) (or $x826 (and (distinct ?x892 ?x892) true)))))))))))))))))
(check-sat)
; query 70: function crcu8, block 6, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x86 (or false false)))
(let (($x2784 (not $x86)))
(and $x2784 (or $x86 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 71: function crcu8, block 6, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1335 ((_ zero_extend 24) in.0_8)))
(let ((?x990 (bvashr ?x1335 (_ bv1 32))))
(let (($x86 (or false false)))
(let (($x492 (or $x86 false false)))
(let (($x1152 (or $x492 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not $x1152) (or $x1152 (and (distinct ?x990 ?x990) true)))))))))
(check-sat)
; query 72: function crcu8, block 6, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1335 ((_ zero_extend 24) in.0_8)))
(let ((?x990 (bvashr ?x1335 (_ bv1 32))))
(let ((?x588 ((_ extract 7 0) ?x990)))
(let (($x86 (or false false)))
(let (($x492 (or $x86 false false)))
(let (($x1152 (or $x492 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x884 (or $x1152 false)))
(and (not $x884) (or $x884 (and (distinct ?x588 ?x588) true)))))))))))
(check-sat)
; query 73: function crcu8, block 6, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x171 ((_ extract 7 0) in.01_16)))
(let ((?x858 ((_ zero_extend 24) ?x171)))
(let ((?x2013 (bvand ?x858 (_ bv1 32))))
(let ((?x1335 ((_ zero_extend 24) in.0_8)))
(let ((?x1782 (bvand ?x1335 (_ bv1 32))))
(let ((?x2005 (bvxor ?x1782 ?x2013)))
(let ((?x892 ((_ extract 7 0) ?x2005)))
(let ((?x1109 ((_ zero_extend 24) ?x892)))
(let (($x86 (or false false)))
(let (($x2783 (or $x86 false)))
(let (($x2313 (or $x2783 false false)))
(let (($x492 (or $x86 false false)))
(let (($x1835 (or $x492 $x2313 false)))
(let (($x826 (or $x1835 false)))
(let (($x626 (or $x826 false)))
(and (not $x626) (or $x626 (and (distinct ?x1109 ?x1109) true)))))))))))))))))))
(check-sat)
; query 74: function crcu8, block 6, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x171 ((_ extract 7 0) in.01_16)))
(let ((?x858 ((_ zero_extend 24) ?x171)))
(let ((?x2013 (bvand ?x858 (_ bv1 32))))
(let ((?x1335 ((_ zero_extend 24) in.0_8)))
(let ((?x1782 (bvand ?x1335 (_ bv1 32))))
(let ((?x2005 (bvxor ?x1782 ?x2013)))
(let ((?x892 ((_ extract 7 0) ?x2005)))
(let ((?x1109 ((_ zero_extend 24) ?x892)))
(let ((?x1297 (ite (= (_ bv1 32) ?x1109) (_ bv1 1) (_ bv0 1))))
(let (($x86 (or false false)))
(let (($x2783 (or $x86 false)))
(let (($x2313 (or $x2783 false false)))
(let (($x492 (or $x86 false false)))
(let (($x1835 (or $x492 $x2313 false)))
(let (($x826 (or $x1835 false)))
(let (($x626 (or $x826 false)))
(let (($x188 (or $x626 false false)))
(and (not $x188) (or $x188 (and (distinct ?x1297 ?x1297) true)))))))))))))))))))))
(check-sat)
; query 75: function crcu8, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x86 (or false false)))
(let (($x2784 (not $x86)))
(and $x2784 (or $x86 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 76: function crcu8, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1335 ((_ zero_extend 24) in.0_8)))
(let ((?x1782 (bvand ?x1335 (_ bv1 32))))
(let (($x86 (or false false)))
(let (($x492 (or $x86 false false)))
(let (($x924 (not $x492)))
(and $x924 (or $x492 (and (distinct ?x1782 ?x1782) true)))))))))
(check-sat)
; query 77: function crcu8, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x86 (or false false)))
(let (($x2784 (not $x86)))
(and $x2784 (or $x86 (and (distinct ((_ extract 7 0) in.01_16) ((_ extract 7 0) in.01_16)) true))))))
(check-sat)
; query 78: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x841 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2043 ((_ zero_extend 31) ?x841)))
(let ((?x1119 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x152 ((_ zero_extend 31) ?x1119)))
(let ((?x1278 (bvand ?x152 ?x2043)))
(let ((?x1325 (ite (and (distinct (_ bv0 32) ?x1278) true) (_ bv1 1) (_ bv0 1))))
(let ((?x81 ((_ zero_extend 63) ?x1325)))
(let (($x86 (or false false)))
(let (($x492 (or $x86 false false)))
(let (($x64 (or $x492 false)))
(let (($x1947 (or $x64 $x64 false)))
(let (($x1198 (or $x1947 false false)))
(let (($x732 (or $x1198 false)))
(and (not $x732) (or $x732 (and (distinct ?x81 ?x81) true)))))))))))))))))
(check-sat)
; query 79: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x841 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2043 ((_ zero_extend 31) ?x841)))
(let ((?x1119 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x152 ((_ zero_extend 31) ?x1119)))
(let ((?x1278 (bvand ?x152 ?x2043)))
(let ((?x1325 (ite (and (distinct (_ bv0 32) ?x1278) true) (_ bv1 1) (_ bv0 1))))
(let (($x919 (= (_ bv1 1) ?x1325)))
(let ((?x1723 (ite $x919 (_ bv1 32) (_ bv0 32))))
(let (($x86 (or false false)))
(let (($x492 (or $x86 false false)))
(let (($x64 (or $x492 false)))
(let (($x1947 (or $x64 $x64 false)))
(let (($x1198 (or $x1947 false false)))
(let (($x1925 (or $x1198 (ite $x919 false false))))
(and (not $x1925) (or $x1925 (and (distinct ?x1723 ?x1723) true))))))))))))))))))
(check-sat)
; query 80: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x841 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2043 ((_ zero_extend 31) ?x841)))
(let ((?x1119 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x152 ((_ zero_extend 31) ?x1119)))
(let ((?x1278 (bvand ?x152 ?x2043)))
(let ((?x1325 (ite (and (distinct (_ bv0 32) ?x1278) true) (_ bv1 1) (_ bv0 1))))
(let (($x919 (= (_ bv1 1) ?x1325)))
(let ((?x1723 (ite $x919 (_ bv1 32) (_ bv0 32))))
(let ((?x212 ((_ extract 7 0) ?x1723)))
(let (($x86 (or false false)))
(let (($x492 (or $x86 false false)))
(let (($x64 (or $x492 false)))
(let (($x1947 (or $x64 $x64 false)))
(let (($x1198 (or $x1947 false false)))
(let (($x1925 (or $x1198 (ite $x919 false false))))
(let (($x1674 (or $x1925 false)))
(and (not $x1674) (or $x1674 (and (distinct ?x212 ?x212) true))))))))))))))))))))
(check-sat)
; query 81: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x86 (or false false)))
(let (($x2784 (not $x86)))
(and $x2784 (or $x86 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 82: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1119 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x86 (or false false)))
(let (($x492 (or $x86 false false)))
(let (($x924 (not $x492)))
(and $x924 (or $x492 (and (distinct ?x1119 ?x1119) true))))))))
(check-sat)
; query 83: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1119 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x152 ((_ zero_extend 31) ?x1119)))
(let (($x86 (or false false)))
(let (($x492 (or $x86 false false)))
(let (($x64 (or $x492 false)))
(let (($x122 (not $x64)))
(and $x122 (or $x64 (and (distinct ?x152 ?x152) true))))))))))
(check-sat)
; query 84: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x86 (or false false)))
(let (($x2784 (not $x86)))
(and $x2784 (or $x86 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 85: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x841 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x86 (or false false)))
(let (($x492 (or $x86 false false)))
(let (($x924 (not $x492)))
(and $x924 (or $x492 (and (distinct ?x841 ?x841) true))))))))
(check-sat)
; query 86: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x841 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2043 ((_ zero_extend 31) ?x841)))
(let (($x86 (or false false)))
(let (($x492 (or $x86 false false)))
(let (($x64 (or $x492 false)))
(let (($x122 (not $x64)))
(and $x122 (or $x64 (and (distinct ?x2043 ?x2043) true))))))))))
(check-sat)
; query 87: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x841 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2043 ((_ zero_extend 31) ?x841)))
(let ((?x1119 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x152 ((_ zero_extend 31) ?x1119)))
(let ((?x1278 (bvand ?x152 ?x2043)))
(let (($x86 (or false false)))
(let (($x492 (or $x86 false false)))
(let (($x64 (or $x492 false)))
(let (($x1947 (or $x64 $x64 false)))
(and (not $x1947) (or $x1947 (and (distinct ?x1278 ?x1278) true)))))))))))))
(check-sat)
; query 88: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x841 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2043 ((_ zero_extend 31) ?x841)))
(let ((?x1119 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x152 ((_ zero_extend 31) ?x1119)))
(let ((?x1278 (bvand ?x152 ?x2043)))
(let ((?x1325 (ite (and (distinct (_ bv0 32) ?x1278) true) (_ bv1 1) (_ bv0 1))))
(let (($x86 (or false false)))
(let (($x492 (or $x86 false false)))
(let (($x64 (or $x492 false)))
(let (($x1947 (or $x64 $x64 false)))
(let (($x1198 (or $x1947 false false)))
(and (not $x1198) (or $x1198 (and (distinct ?x1325 ?x1325) true)))))))))))))))
(check-sat)
; query 89: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1498 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x562 (or false false false)))
(let (($x753 (not $x562)))
(and $x753 (or $x562 (and (distinct ?x1498 ?x1498) true)))))))
(check-sat)
; query 90: function matrix_add_const, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x562 (or false false false)))
(let (($x753 (not $x562)))
(and $x753 (or $x562 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 91: function matrix_add_const, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x83 (bvadd in.01_32 (_ bv1 32))))
(let (($x720 (and (distinct ?x83 ?x83) true)))
(let (($x562 (or false false false)))
(let (($x753 (not $x562)))
(and $x753 (or $x562 $x720)))))))
(check-sat)
; query 92: function matrix_mul_const, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x562 (or false false false)))
(let (($x753 (not $x562)))
(and $x753 (or $x562 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 93: function matrix_mul_const, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x83 (bvadd in.01_32 (_ bv1 32))))
(let (($x720 (and (distinct ?x83 ?x83) true)))
(let (($x562 (or false false false)))
(let (($x753 (not $x562)))
(and $x753 (or $x562 $x720)))))))
(check-sat)
; query 94: function matrix_mul_matrix, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x562 (or false false false)))
(let (($x753 (not $x562)))
(and $x753 (or $x562 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 95: function matrix_mul_matrix, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x83 (bvadd in.01_32 (_ bv1 32))))
(let (($x720 (and (distinct ?x83 ?x83) true)))
(let (($x562 (or false false false)))
(let (($x753 (not $x562)))
(and $x753 (or $x562 $x720)))))))
(check-sat)
; query 96: function matrix_mul_matrix, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x562 (or false false false)))
(let (($x753 (not $x562)))
(and $x753 (or $x562 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 97: function matrix_mul_matrix_bitextract, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x562 (or false false false)))
(let (($x753 (not $x562)))
(and $x753 (or $x562 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 98: function matrix_mul_matrix_bitextract, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x83 (bvadd in.01_32 (_ bv1 32))))
(let (($x720 (and (distinct ?x83 ?x83) true)))
(let (($x562 (or false false false)))
(let (($x753 (not $x562)))
(and $x753 (or $x562 $x720)))))))
(check-sat)
; query 99: function matrix_mul_matrix_bitextract, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x562 (or false false false)))
(let (($x753 (not $x562)))
(and $x753 (or $x562 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 100: function matrix_mul_vect, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x562 (or false false false)))
(let (($x753 (not $x562)))
(and $x753 (or $x562 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 101: function matrix_mul_vect, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x83 (bvadd in.01_32 (_ bv1 32))))
(let (($x720 (and (distinct ?x83 ?x83) true)))
(let (($x562 (or false false false)))
(let (($x753 (not $x562)))
(and $x753 (or $x562 $x720)))))))
(check-sat)
; query 102: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x86 (or false false)))
(let (($x2784 (not $x86)))
(and $x2784 (or $x86 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 103: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x1984 ((_ sign_extend 16) in.1_16)))
(let ((?x1288 (bvadd ?x1984 (_ bv10 32))))
(let (($x140 (and (distinct (bvadd ((_ sign_extend 1) ?x1984) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x1288)) true)))
(let (($x86 (or false false)))
(let (($x283 (or $x86 false (or $x140))))
(and (not $x283) (or $x283 (and (distinct ?x1288 ?x1288) true)))))))))
(check-sat)
; query 104: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x1984 ((_ sign_extend 16) in.1_16)))
(let ((?x1288 (bvadd ?x1984 (_ bv10 32))))
(let ((?x1759 ((_ extract 15 0) ?x1288)))
(let (($x140 (and (distinct (bvadd ((_ sign_extend 1) ?x1984) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x1288)) true)))
(let (($x86 (or false false)))
(let (($x283 (or $x86 false (or $x140))))
(let (($x363 (or $x283 false)))
(and (not $x363) (or $x363 (and (distinct ?x1759 ?x1759) true)))))))))))
(check-sat)
; query 105: function matrix_sum, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x321 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x562 (or false false false)))
(let (($x753 (not $x562)))
(and $x753 (or $x562 (and (distinct ?x321 ?x321) true)))))))
(check-sat)
; query 106: function matrix_sum, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x321 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let ((?x1935 ((_ zero_extend 63) ?x321)))
(let (($x562 (or false false false)))
(let (($x2066 (or $x562 false)))
(and (not $x2066) (or $x2066 (and (distinct ?x1935 ?x1935) true))))))))
(check-sat)
; query 107: function matrix_sum, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x321 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x1279 (= (_ bv1 1) ?x321)))
(let ((?x1808 (ite $x1279 (_ bv1 32) (_ bv0 32))))
(let (($x562 (or false false false)))
(let (($x1729 (or $x562 (ite $x1279 false false))))
(and (not $x1729) (or $x1729 (and (distinct ?x1808 ?x1808) true)))))))))
(check-sat)
; query 108: function matrix_sum, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x86 (or false false)))
(let (($x2784 (not $x86)))
(and $x2784 (or $x86 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 109: function matrix_sum, block 22, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x321 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x1279 (= (_ bv1 1) ?x321)))
(let ((?x1808 (ite $x1279 (_ bv1 32) (_ bv0 32))))
(let ((?x1984 ((_ sign_extend 16) in.1_16)))
(let ((?x9 (bvadd ?x1984 ?x1808)))
(let (($x981 (and (distinct (bvadd ((_ sign_extend 1) ?x1984) ((_ sign_extend 1) ?x1808)) ((_ sign_extend 1) ?x9)) true)))
(let (($x562 (or false false false)))
(let (($x1729 (or $x562 (ite $x1279 false false))))
(let (($x86 (or false false)))
(let (($x1736 (or $x86 $x1729 (or $x981))))
(and (not $x1736) (or $x1736 (and (distinct ?x9 ?x9) true))))))))))))))
(check-sat)
; query 110: function matrix_sum, block 22, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x321 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x1279 (= (_ bv1 1) ?x321)))
(let ((?x1808 (ite $x1279 (_ bv1 32) (_ bv0 32))))
(let ((?x1984 ((_ sign_extend 16) in.1_16)))
(let ((?x9 (bvadd ?x1984 ?x1808)))
(let ((?x1868 ((_ extract 15 0) ?x9)))
(let (($x981 (and (distinct (bvadd ((_ sign_extend 1) ?x1984) ((_ sign_extend 1) ?x1808)) ((_ sign_extend 1) ?x9)) true)))
(let (($x562 (or false false false)))
(let (($x1729 (or $x562 (ite $x1279 false false))))
(let (($x86 (or false false)))
(let (($x1736 (or $x86 $x1729 (or $x981))))
(let (($x1971 (or $x1736 false)))
(and (not $x1971) (or $x1971 (and (distinct ?x1868 ?x1868) true))))))))))))))))
(check-sat)
; query 111: function matrix_sum, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x562 (or false false false)))
(let (($x753 (not $x562)))
(and $x753 (or $x562 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 112: function matrix_sum, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x83 (bvadd in.01_32 (_ bv1 32))))
(let (($x720 (and (distinct ?x83 ?x83) true)))
(let (($x562 (or false false false)))
(let (($x753 (not $x562)))
(and $x753 (or $x562 $x720)))))))
(check-sat)
; query 113: function parseval, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.23_32 () (_ BitVec 32))
(assert
 (let (($x1920 (and (distinct (bvmul ((_ sign_extend 32) in.23_32) ((_ sign_extend 32) (_ bv1024 32))) ((_ sign_extend 32) (bvmul in.23_32 (_ bv1024 32)))) true)))
(let (($x1893 (or false false (or $x1920))))
(and (not $x1893) (or $x1893 (and (distinct (bvmul in.23_32 (_ bv1024 32)) (bvmul in.23_32 (_ bv1024 32))) true))))))
(check-sat)
; query 114: function parseval, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.34_32 () (_ BitVec 32))
(assert
 (let (($x2062 (and (distinct (bvmul ((_ sign_extend 32) in.34_32) ((_ sign_extend 32) (_ bv1048576 32))) ((_ sign_extend 32) (bvmul in.34_32 (_ bv1048576 32)))) true)))
(let (($x1648 (or false false (or $x2062))))
(and (not $x1648) (or $x1648 (and (distinct (bvmul in.34_32 (_ bv1048576 32)) (bvmul in.34_32 (_ bv1048576 32))) true))))))
(check-sat)
; query 115: function partition_memory, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x562 (or false false false)))
(let (($x753 (not $x562)))
(and $x753 (or $x562 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 116: function run_crc_loop, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x83 (bvadd in.01_32 (_ bv1 32))))
(let (($x720 (and (distinct ?x83 ?x83) true)))
(let (($x562 (or false false false)))
(let (($x753 (not $x562)))
(and $x753 (or $x562 $x720)))))))
(check-sat)
