; OptiPhase-Sigma refinement certificate for sweep K21-R5-400
; query 0: function kernel_deriche, block 105, name %106
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.110_32 () (_ BitVec 32))
(assert
 (let (($x20 (and (distinct (bvadd ((_ zero_extend 1) in.110_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.110_32 (_ bv1 32)))) true)))
(let (($x318 (and (distinct (bvadd ((_ sign_extend 1) in.110_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.110_32 (_ bv1 32)))) true)))
(let (($x304 (or (or false false (or $x318 $x20)) (and (distinct (bvadd in.110_32 (_ bv1 32)) (bvadd in.110_32 (_ bv1 32))) true))))
(and (not (or false false (or $x318))) $x304)))))
(check-sat)
