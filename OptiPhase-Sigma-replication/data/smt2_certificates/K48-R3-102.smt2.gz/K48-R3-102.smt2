; OptiPhase-Sigma refinement certificate for sweep K48-R3-102
; query 0: function APCM_inverse_quantization, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x759 (or false false)))
(let (($x540 (not $x759)))
(and $x540 (or $x759 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 1: function APCM_inverse_quantization, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x243 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x759 (or false false)))
(let (($x293 (or $x759 false false)))
(let (($x283 (not $x293)))
(and $x283 (or $x293 (and (distinct ?x243 ?x243) true))))))))
(check-sat)
; query 2: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x759 (or false false)))
(let (($x540 (not $x759)))
(and $x540 (or $x759 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 3: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x223 (ite (bvslt (_ bv15 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x759 (or false false)))
(let (($x293 (or $x759 false false)))
(let (($x283 (not $x293)))
(and $x283 (or $x293 (and (distinct ?x223 ?x223) true))))))))
(check-sat)
; query 4: function Decoding_of_the_coded_Log_Area_Ratios, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in6_64 () (_ BitVec 64))
(assert
 (let ((?x35 (ite (bvslt (_ bv0 64) in6_64) (_ bv1 1) (_ bv0 1))))
(let (($x320 (or false false false)))
(let (($x678 (not $x320)))
(and $x678 (or $x320 (and (distinct ?x35 ?x35) true)))))))
(check-sat)
; query 5: function Decoding_of_the_coded_Log_Area_Ratios, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in6_64 () (_ BitVec 64))
(assert
 (let ((?x35 (ite (bvslt (_ bv0 64) in6_64) (_ bv1 1) (_ bv0 1))))
(let ((?x167 ((_ zero_extend 63) ?x35)))
(let (($x320 (or false false false)))
(let (($x229 (or $x320 false)))
(let (($x104 (not $x229)))
(and $x104 (or $x229 (and (distinct ?x167 ?x167) true)))))))))
(check-sat)
; query 6: function Decoding_of_the_coded_Log_Area_Ratios, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in6_64 () (_ BitVec 64))
(assert
 (let ((?x35 (ite (bvslt (_ bv0 64) in6_64) (_ bv1 1) (_ bv0 1))))
(let (($x49 (= (_ bv1 1) ?x35)))
(let ((?x836 (ite $x49 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x320 (or false false false)))
(let (($x86 (or $x320 (ite $x49 false false))))
(and (not $x86) (or $x86 (and (distinct ?x836 ?x836) true)))))))))
(check-sat)
; query 7: function Decoding_of_the_coded_Log_Area_Ratios, block 9, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in6_64 () (_ BitVec 64))
(assert
 (let ((?x35 (ite (bvslt (_ bv0 64) in6_64) (_ bv1 1) (_ bv0 1))))
(let (($x49 (= (_ bv1 1) ?x35)))
(let ((?x836 (ite $x49 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x12 ((_ sign_extend 32) ?x836)))
(let (($x320 (or false false false)))
(let (($x86 (or $x320 (ite $x49 false false))))
(let (($x608 (or $x86 false)))
(and (not $x608) (or $x608 (and (distinct ?x12 ?x12) true)))))))))))
(check-sat)
; query 8: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x759 (or false false)))
(let (($x540 (not $x759)))
(and $x540 (or $x759 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 9: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x271 (ite (bvsgt (_ bv40 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x759 (or false false)))
(let (($x293 (or $x759 false false)))
(let (($x283 (not $x293)))
(and $x283 (or $x293 (and (distinct ?x271 ?x271) true))))))))
(check-sat)
; query 10: function Quantization_and_coding, block 11, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in8_64 () (_ BitVec 64))
(assert
 (let ((?x466 (ite (bvslt (_ bv0 64) in8_64) (_ bv1 1) (_ bv0 1))))
(let (($x320 (or false false false)))
(let (($x678 (not $x320)))
(and $x678 (or $x320 (and (distinct ?x466 ?x466) true)))))))
(check-sat)
; query 11: function Quantization_and_coding, block 11, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in8_64 () (_ BitVec 64))
(assert
 (let ((?x466 (ite (bvslt (_ bv0 64) in8_64) (_ bv1 1) (_ bv0 1))))
(let ((?x119 ((_ zero_extend 63) ?x466)))
(let (($x320 (or false false false)))
(let (($x229 (or $x320 false)))
(let (($x104 (not $x229)))
(and $x104 (or $x229 (and (distinct ?x119 ?x119) true)))))))))
(check-sat)
; query 12: function Quantization_and_coding, block 11, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in8_64 () (_ BitVec 64))
(assert
 (let ((?x466 (ite (bvslt (_ bv0 64) in8_64) (_ bv1 1) (_ bv0 1))))
(let (($x130 (= (_ bv1 1) ?x466)))
(let ((?x100 (ite $x130 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x320 (or false false false)))
(let (($x807 (or $x320 (ite $x130 false false))))
(and (not $x807) (or $x807 (and (distinct ?x100 ?x100) true)))))))))
(check-sat)
; query 13: function Quantization_and_coding, block 11, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in8_64 () (_ BitVec 64))
(assert
 (let ((?x466 (ite (bvslt (_ bv0 64) in8_64) (_ bv1 1) (_ bv0 1))))
(let (($x130 (= (_ bv1 1) ?x466)))
(let ((?x100 (ite $x130 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x50 ((_ sign_extend 32) ?x100)))
(let (($x320 (or false false false)))
(let (($x807 (or $x320 (ite $x130 false false))))
(let (($x884 (or $x807 false)))
(and (not $x884) (or $x884 (and (distinct ?x50 ?x50) true)))))))))))
(check-sat)
; query 14: function Quantization_and_coding, block 111, name %112
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in108_64 () (_ BitVec 64))
(assert
 (let ((?x230 (ite (bvslt (_ bv0 64) in108_64) (_ bv1 1) (_ bv0 1))))
(let (($x320 (or false false false)))
(let (($x678 (not $x320)))
(and $x678 (or $x320 (and (distinct ?x230 ?x230) true)))))))
(check-sat)
; query 15: function Quantization_and_coding, block 111, name %113
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in108_64 () (_ BitVec 64))
(assert
 (let ((?x230 (ite (bvslt (_ bv0 64) in108_64) (_ bv1 1) (_ bv0 1))))
(let ((?x231 ((_ zero_extend 63) ?x230)))
(let (($x320 (or false false false)))
(let (($x229 (or $x320 false)))
(let (($x104 (not $x229)))
(and $x104 (or $x229 (and (distinct ?x231 ?x231) true)))))))))
(check-sat)
; query 16: function Quantization_and_coding, block 111, name %114
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in108_64 () (_ BitVec 64))
(assert
 (let ((?x230 (ite (bvslt (_ bv0 64) in108_64) (_ bv1 1) (_ bv0 1))))
(let (($x235 (= (_ bv1 1) ?x230)))
(let ((?x151 (ite $x235 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x320 (or false false false)))
(let (($x252 (or $x320 (ite $x235 false false))))
(and (not $x252) (or $x252 (and (distinct ?x151 ?x151) true)))))))))
(check-sat)
; query 17: function Quantization_and_coding, block 111, name %115
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in108_64 () (_ BitVec 64))
(assert
 (let ((?x230 (ite (bvslt (_ bv0 64) in108_64) (_ bv1 1) (_ bv0 1))))
(let (($x235 (= (_ bv1 1) ?x230)))
(let ((?x151 (ite $x235 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x45 ((_ sign_extend 32) ?x151)))
(let (($x320 (or false false false)))
(let (($x252 (or $x320 (ite $x235 false false))))
(let (($x220 (or $x252 false)))
(and (not $x220) (or $x220 (and (distinct ?x45 ?x45) true)))))))))))
(check-sat)
; query 18: function RPE_grid_positioning, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x759 (or false false)))
(let (($x540 (not $x759)))
(and $x540 (or $x759 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 19: function RPE_grid_positioning, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x432 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x159 (and (distinct ?x432 ?x432) true)))
(let (($x759 (or false false)))
(let (($x129 (or false $x759 false)))
(and (not $x129) (or $x129 $x159)))))))
(check-sat)
; query 20: function gsm_L_add, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x164 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x320 (or false false false)))
(let (($x678 (not $x320)))
(and $x678 (or $x320 (and (distinct ?x164 ?x164) true)))))))
(check-sat)
; query 21: function gsm_L_add, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x80 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvadd in0_64 in1_64))) true)))
(let (($x89 (or false false (or $x80))))
(let (($x173 (or $x89 (and (distinct (bvadd in0_64 in1_64) (bvadd in0_64 in1_64)) true))))
(and (not $x89) $x173)))))
(check-sat)
; query 22: function gsm_L_add, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x144 (bvadd in0_64 (_ bv1 64))))
(let ((?x72 (bvsub (_ bv0 64) ?x144)))
(let (($x15 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x144)) ((_ sign_extend 1) ?x72)) true)))
(let ((?x142 ((_ sign_extend 1) ?x144)))
(let (($x63 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x142) true)))))
(let (($x221 (or false $x63 (or $x15))))
(and (not $x221) (or $x221 (and (distinct ?x72 ?x72) true))))))))))
(check-sat)
; query 23: function gsm_L_add, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x360 (bvadd in1_64 (_ bv1 64))))
(let ((?x140 ((_ sign_extend 1) ?x360)))
(let (($x20 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x140) true)))))
(and (not $x20) (or $x20 (and (distinct ?x360 ?x360) true)))))))
(check-sat)
; query 24: function gsm_L_add, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x360 (bvadd in1_64 (_ bv1 64))))
(let ((?x70 (bvsub (_ bv0 64) ?x360)))
(let (($x365 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x360)) ((_ sign_extend 1) ?x70)) true)))
(let ((?x140 ((_ sign_extend 1) ?x360)))
(let (($x20 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x140) true)))))
(let (($x96 (or false $x20 (or $x365))))
(and (not $x96) (or $x96 (and (distinct ?x70 ?x70) true))))))))))
(check-sat)
; query 25: function gsm_L_add, block 8, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x360 (bvadd in1_64 (_ bv1 64))))
(let ((?x70 (bvsub (_ bv0 64) ?x360)))
(let ((?x144 (bvadd in0_64 (_ bv1 64))))
(let ((?x72 (bvsub (_ bv0 64) ?x144)))
(let ((?x908 (bvadd ?x72 ?x70)))
(let (($x365 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x360)) ((_ sign_extend 1) ?x70)) true)))
(let ((?x140 ((_ sign_extend 1) ?x360)))
(let (($x20 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x140) true)))))
(let (($x96 (or false $x20 (or $x365))))
(let (($x15 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x144)) ((_ sign_extend 1) ?x72)) true)))
(let ((?x142 ((_ sign_extend 1) ?x144)))
(let (($x63 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x142) true)))))
(let (($x221 (or false $x63 (or $x15))))
(let (($x44 (or $x221 $x96 false)))
(and (not $x44) (or $x44 (and (distinct ?x908 ?x908) true))))))))))))))))))
(check-sat)
; query 26: function gsm_L_add, block 8, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x360 (bvadd in1_64 (_ bv1 64))))
(let ((?x70 (bvsub (_ bv0 64) ?x360)))
(let ((?x144 (bvadd in0_64 (_ bv1 64))))
(let ((?x72 (bvsub (_ bv0 64) ?x144)))
(let ((?x908 (bvadd ?x72 ?x70)))
(let ((?x331 (ite (bvuge ?x908 (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x365 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x360)) ((_ sign_extend 1) ?x70)) true)))
(let ((?x140 ((_ sign_extend 1) ?x360)))
(let (($x20 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x140) true)))))
(let (($x96 (or false $x20 (or $x365))))
(let (($x15 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x144)) ((_ sign_extend 1) ?x72)) true)))
(let ((?x142 ((_ sign_extend 1) ?x144)))
(let (($x63 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x142) true)))))
(let (($x221 (or false $x63 (or $x15))))
(let (($x44 (or $x221 $x96 false)))
(let (($x289 (or $x44 false false)))
(and (not $x289) (or $x289 (and (distinct ?x331 ?x331) true))))))))))))))))))))
(check-sat)
; query 27: function gsm_L_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x144 (bvadd in0_64 (_ bv1 64))))
(let ((?x142 ((_ sign_extend 1) ?x144)))
(let (($x63 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x142) true)))))
(and (not $x63) (or $x63 (and (distinct ?x144 ?x144) true)))))))
(check-sat)
; query 28: function gsm_L_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x324 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x320 (or false false false)))
(let (($x678 (not $x320)))
(and $x678 (or $x320 (and (distinct ?x324 ?x324) true)))))))
(check-sat)
; query 29: function gsm_L_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x24 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x320 (or false false false)))
(let (($x678 (not $x320)))
(and $x678 (or $x320 (and (distinct ?x24 ?x24) true)))))))
(check-sat)
; query 30: function gsm_L_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x324 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x320 (or false false false)))
(let (($x678 (not $x320)))
(and $x678 (or $x320 (and (distinct ?x324 ?x324) true)))))))
(check-sat)
; query 31: function gsm_L_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x324 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x585 ((_ zero_extend 31) ?x324)))
(let (($x320 (or false false false)))
(let (($x229 (or $x320 false)))
(let (($x104 (not $x229)))
(and $x104 (or $x229 (and (distinct ?x585 ?x585) true)))))))))
(check-sat)
; query 32: function gsm_L_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x324 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x585 ((_ zero_extend 31) ?x324)))
(let ((?x102 (bvsub (_ bv0 32) ?x585)))
(let (($x227 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x585)) ((_ sign_extend 1) ?x102)) true)))
(let (($x320 (or false false false)))
(let (($x229 (or $x320 false)))
(let (($x168 (or false $x229 (or $x227))))
(and (not $x168) (or $x168 (and (distinct ?x102 ?x102) true)))))))))))
(check-sat)
; query 33: function gsm_L_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x324 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x585 ((_ zero_extend 31) ?x324)))
(let ((?x102 (bvsub (_ bv0 32) ?x585)))
(let ((?x103 ((_ sign_extend 32) ?x102)))
(let (($x227 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x585)) ((_ sign_extend 1) ?x102)) true)))
(let (($x320 (or false false false)))
(let (($x229 (or $x320 false)))
(let (($x168 (or false $x229 (or $x227))))
(let (($x47 (or $x168 false)))
(and (not $x47) (or $x47 (and (distinct ?x103 ?x103) true)))))))))))))
(check-sat)
; query 34: function gsm_L_asr, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x650 (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x320 (or false false false)))
(let (($x678 (not $x320)))
(and $x678 (or $x320 (and (distinct ?x650 ?x650) true)))))))
(check-sat)
; query 35: function gsm_L_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x24 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x320 (or false false false)))
(let (($x678 (not $x320)))
(and $x678 (or $x320 (and (distinct ?x24 ?x24) true)))))))
(check-sat)
; query 36: function gsm_L_sub, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x164 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x320 (or false false false)))
(let (($x678 (not $x320)))
(and $x678 (or $x320 (and (distinct ?x164 ?x164) true)))))))
(check-sat)
; query 37: function gsm_L_sub, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x581 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvsub in0_64 in1_64))) true)))
(let (($x470 (or false false (or $x581))))
(let (($x543 (or $x470 (and (distinct (bvsub in0_64 in1_64) (bvsub in0_64 in1_64)) true))))
(and (not $x470) $x543)))))
(check-sat)
; query 38: function gsm_L_sub, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x360 (bvadd in1_64 (_ bv1 64))))
(let ((?x70 (bvsub (_ bv0 64) ?x360)))
(let (($x365 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x360)) ((_ sign_extend 1) ?x70)) true)))
(let ((?x140 ((_ sign_extend 1) ?x360)))
(let (($x20 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x140) true)))))
(let (($x96 (or false $x20 (or $x365))))
(and (not $x96) (or $x96 (and (distinct ?x70 ?x70) true))))))))))
(check-sat)
; query 39: function gsm_L_sub, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x360 (bvadd in1_64 (_ bv1 64))))
(let ((?x70 (bvsub (_ bv0 64) ?x360)))
(let ((?x864 (bvadd in0_64 ?x70)))
(let (($x365 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x360)) ((_ sign_extend 1) ?x70)) true)))
(let ((?x140 ((_ sign_extend 1) ?x360)))
(let (($x20 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x140) true)))))
(let (($x96 (or false $x20 (or $x365))))
(let (($x336 (or false $x96 false)))
(and (not $x336) (or $x336 (and (distinct ?x864 ?x864) true))))))))))))
(check-sat)
; query 40: function gsm_L_sub, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x351 (ite (bvuge (bvadd in0_64 (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64)))) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x365 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) (bvadd in1_64 (_ bv1 64)))) ((_ sign_extend 1) (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64))))) true)))
(let ((?x360 (bvadd in1_64 (_ bv1 64))))
(let ((?x140 ((_ sign_extend 1) ?x360)))
(let (($x20 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x140) true)))))
(let (($x96 (or false $x20 (or $x365))))
(let (($x336 (or false $x96 false)))
(let (($x597 (or $x336 false false)))
(and (not $x597) (or $x597 (and (distinct ?x351 ?x351) true))))))))))))
(check-sat)
; query 41: function gsm_L_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x360 (bvadd in1_64 (_ bv1 64))))
(let ((?x140 ((_ sign_extend 1) ?x360)))
(let (($x20 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x140) true)))))
(and (not $x20) (or $x20 (and (distinct ?x360 ?x360) true)))))))
(check-sat)
; query 42: function gsm_L_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x479 (ite (bvsle (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x320 (or false false false)))
(let (($x678 (not $x320)))
(and $x678 (or $x320 (and (distinct ?x479 ?x479) true)))))))
(check-sat)
; query 43: function gsm_abs, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x759 (or false false)))
(let (($x540 (not $x759)))
(and $x540 (or $x759 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 44: function gsm_abs, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x895 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x759 (or false false)))
(let (($x293 (or $x759 false false)))
(let (($x283 (not $x293)))
(and $x283 (or $x293 (and (distinct ?x895 ?x895) true))))))))
(check-sat)
; query 45: function gsm_abs, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x759 (or false false)))
(let (($x540 (not $x759)))
(and $x540 (or $x759 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 46: function gsm_abs, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x274 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x759 (or false false)))
(let (($x293 (or $x759 false false)))
(let (($x283 (not $x293)))
(and $x283 (or $x293 (and (distinct ?x274 ?x274) true))))))))
(check-sat)
; query 47: function gsm_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x759 (or false false)))
(let (($x540 (not $x759)))
(and $x540 (or $x759 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 48: function gsm_add, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x759 (or false false)))
(let (($x540 (not $x759)))
(and $x540 (or $x759 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 49: function gsm_add, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x359 ((_ sign_extend 48) in1_16)))
(let ((?x111 ((_ sign_extend 48) in0_16)))
(let ((?x176 (bvadd ?x111 ?x359)))
(let (($x628 (and (distinct (bvadd ((_ sign_extend 1) ?x111) ((_ sign_extend 1) ?x359)) ((_ sign_extend 1) ?x176)) true)))
(let (($x759 (or false false)))
(let (($x183 (or $x759 $x759 (or $x628))))
(and (not $x183) (or $x183 (and (distinct ?x176 ?x176) true))))))))))
(check-sat)
; query 50: function gsm_add, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x588 (ite (bvsgt (_ bv18446744073709518848 64) (bvadd ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x359 ((_ sign_extend 48) in1_16)))
(let ((?x434 ((_ sign_extend 1) ?x359)))
(let ((?x111 ((_ sign_extend 48) in0_16)))
(let ((?x423 ((_ sign_extend 1) ?x111)))
(let (($x759 (or false false)))
(let (($x183 (or $x759 $x759 (or (and (distinct (bvadd ?x423 ?x434) ((_ sign_extend 1) (bvadd ?x111 ?x359))) true)))))
(let (($x363 (or $x183 false false)))
(and (not $x363) (or $x363 (and (distinct ?x588 ?x588) true))))))))))))
(check-sat)
; query 51: function gsm_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x94 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x320 (or false false false)))
(let (($x678 (not $x320)))
(and $x678 (or $x320 (and (distinct ?x94 ?x94) true)))))))
(check-sat)
; query 52: function gsm_asr, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x205 (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x320 (or false false false)))
(let (($x678 (not $x320)))
(and $x678 (or $x320 (and (distinct ?x205 ?x205) true)))))))
(check-sat)
; query 53: function gsm_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x759 (or false false)))
(let (($x540 (not $x759)))
(and $x540 (or $x759 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 54: function gsm_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x274 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x759 (or false false)))
(let (($x293 (or $x759 false false)))
(let (($x283 (not $x293)))
(and $x283 (or $x293 (and (distinct ?x274 ?x274) true))))))))
(check-sat)
; query 55: function gsm_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x274 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x843 ((_ zero_extend 31) ?x274)))
(let (($x759 (or false false)))
(let (($x293 (or $x759 false false)))
(let (($x1991 (or $x293 false)))
(and (not $x1991) (or $x1991 (and (distinct ?x843 ?x843) true)))))))))
(check-sat)
; query 56: function gsm_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x274 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x843 ((_ zero_extend 31) ?x274)))
(let ((?x1951 (bvsub (_ bv0 32) ?x843)))
(let (($x1941 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x843)) ((_ sign_extend 1) ?x1951)) true)))
(let (($x759 (or false false)))
(let (($x293 (or $x759 false false)))
(let (($x1991 (or $x293 false)))
(let (($x1921 (or false $x1991 (or $x1941))))
(and (not $x1921) (or $x1921 (and (distinct ?x1951 ?x1951) true))))))))))))
(check-sat)
; query 57: function gsm_asr, block 4, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x274 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x843 ((_ zero_extend 31) ?x274)))
(let ((?x1951 (bvsub (_ bv0 32) ?x843)))
(let ((?x1911 ((_ extract 15 0) ?x1951)))
(let (($x1941 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x843)) ((_ sign_extend 1) ?x1951)) true)))
(let (($x759 (or false false)))
(let (($x293 (or $x759 false false)))
(let (($x1991 (or $x293 false)))
(let (($x1921 (or false $x1991 (or $x1941))))
(let (($x1901 (or $x1921 false)))
(and (not $x1901) (or $x1901 (and (distinct ?x1911 ?x1911) true))))))))))))))
(check-sat)
; query 58: function gsm_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x94 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x320 (or false false false)))
(let (($x678 (not $x320)))
(and $x678 (or $x320 (and (distinct ?x94 ?x94) true)))))))
(check-sat)
; query 59: function gsm_div, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x759 (or false false)))
(let (($x540 (not $x759)))
(and $x540 (or $x759 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 60: function gsm_div, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x759 (or false false)))
(let (($x540 (not $x759)))
(and $x540 (or $x759 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 61: function gsm_div, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x759 (or false false)))
(let (($x540 (not $x759)))
(and $x540 (or $x759 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 62: function gsm_div, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x432 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x159 (and (distinct ?x432 ?x432) true)))
(let (($x759 (or false false)))
(let (($x293 (or $x759 false false)))
(let (($x283 (not $x293)))
(and $x283 (or $x293 $x159))))))))
(check-sat)
; query 63: function gsm_norm, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x324 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x320 (or false false false)))
(let (($x678 (not $x320)))
(and $x678 (or $x320 (and (distinct ?x324 (ite (bvsge (_ bv18446744072635809792 64) in0_64) (_ bv1 1) (_ bv0 1))) true)))))))
(check-sat)
; query 64: function gsm_norm, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1795 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x320 (or false false false)))
(let (($x678 (not $x320)))
(and $x678 (or $x320 (and (distinct ?x1795 ?x1795) true)))))))
(check-sat)
; query 65: function gsm_norm, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1795 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x461 (bvxor ?x1795 (_ bv1 1))))
(let (($x320 (or false false false)))
(let (($x1792 (or $x320 false false)))
(and (not $x1792) (or $x1792 (and (distinct ?x461 ?x461) true))))))))
(check-sat)
; query 66: function gsm_norm, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1795 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x461 (bvxor ?x1795 (_ bv1 1))))
(let ((?x399 ((_ zero_extend 31) ?x461)))
(let (($x320 (or false false false)))
(let (($x1792 (or $x320 false false)))
(let (($x306 (or $x1792 false)))
(and (not $x306) (or $x306 (and (distinct ?x399 ?x399) true))))))))))
(check-sat)
; query 67: function gsm_norm, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1795 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x461 (bvxor ?x1795 (_ bv1 1))))
(let ((?x399 ((_ zero_extend 31) ?x461)))
(let ((?x900 ((_ sign_extend 32) ?x399)))
(let (($x320 (or false false false)))
(let (($x1792 (or $x320 false false)))
(let (($x306 (or $x1792 false)))
(let (($x1787 (or $x306 false)))
(and (not $x1787) (or $x1787 (and (distinct ?x900 ?x900) true))))))))))))
(check-sat)
; query 68: function gsm_norm, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1795 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x461 (bvxor ?x1795 (_ bv1 1))))
(let ((?x399 ((_ zero_extend 31) ?x461)))
(let ((?x900 ((_ sign_extend 32) ?x399)))
(let ((?x1790 (ite (and (distinct (_ bv0 64) ?x900) true) (_ bv1 1) (_ bv0 1))))
(let (($x320 (or false false false)))
(let (($x1792 (or $x320 false false)))
(let (($x306 (or $x1792 false)))
(let (($x1787 (or $x306 false)))
(let (($x463 (or $x1787 false false)))
(and (not $x463) (or $x463 (and (distinct ?x1790 ?x1790) true))))))))))))))
(check-sat)
; query 69: function gsm_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x759 (or false false)))
(let (($x540 (not $x759)))
(and $x540 (or $x759 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 70: function gsm_sub, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x759 (or false false)))
(let (($x540 (not $x759)))
(and $x540 (or $x759 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 71: function gsm_sub, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x359 ((_ sign_extend 48) in1_16)))
(let ((?x111 ((_ sign_extend 48) in0_16)))
(let ((?x1824 (bvsub ?x111 ?x359)))
(let (($x1825 (and (distinct (bvsub ((_ sign_extend 1) ?x111) ((_ sign_extend 1) ?x359)) ((_ sign_extend 1) ?x1824)) true)))
(let (($x759 (or false false)))
(let (($x1823 (or $x759 $x759 (or $x1825))))
(and (not $x1823) (or $x1823 (and (distinct ?x1824 ?x1824) true))))))))))
(check-sat)
; query 72: function gsm_sub, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1826 (ite (bvsgt (_ bv18446744073709518848 64) (bvsub ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x359 ((_ sign_extend 48) in1_16)))
(let ((?x434 ((_ sign_extend 1) ?x359)))
(let ((?x111 ((_ sign_extend 48) in0_16)))
(let ((?x423 ((_ sign_extend 1) ?x111)))
(let (($x759 (or false false)))
(let (($x1823 (or $x759 $x759 (or (and (distinct (bvsub ?x423 ?x434) ((_ sign_extend 1) (bvsub ?x111 ?x359))) true)))))
(let (($x1819 (or $x1823 false false)))
(and (not $x1819) (or $x1819 (and (distinct ?x1826 ?x1826) true))))))))))))
(check-sat)
; query 73: function process_decode, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let (($x759 (or false false)))
(let (($x540 (not $x759)))
(and $x540 (or $x759 (and (distinct ((_ sign_extend 32) in14_32) ((_ sign_extend 32) in14_32)) true))))))
(check-sat)
; query 74: function process_decode, block 16, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x600 (ite (and (distinct (_ bv33 64) ((_ sign_extend 32) in14_32)) true) (_ bv1 1) (_ bv0 1))))
(let (($x759 (or false false)))
(let (($x293 (or $x759 false false)))
(let (($x283 (not $x293)))
(and $x283 (or $x293 (and (distinct ?x600 ?x600) true))))))))
(check-sat)
; query 75: function process_encode, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_32 () (_ BitVec 32))
(assert
 (let (($x759 (or false false)))
(let (($x540 (not $x759)))
(and $x540 (or $x759 (and (distinct ((_ sign_extend 32) in13_32) ((_ sign_extend 32) in13_32)) true))))))
(check-sat)
; query 76: function process_encode, block 15, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_32 () (_ BitVec 32))
(assert
 (let ((?x1853 (ite (bvult ((_ sign_extend 32) in13_32) (_ bv160 64)) (_ bv1 1) (_ bv0 1))))
(let (($x759 (or false false)))
(let (($x293 (or $x759 false false)))
(let (($x283 (not $x293)))
(and $x283 (or $x293 (and (distinct ?x1853 ?x1853) true))))))))
(check-sat)
