; OptiPhase-Sigma refinement certificate for sweep K59-R3-249
; query 0: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x480 (or false false false)))
(let (($x308 (not $x480)))
(and $x308 (or $x480 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x615 (bvadd in.01_32 (_ bv1 32))))
(let ((?x98 (bvmul ?x615 ?x615)))
(let (($x480 (or false false false)))
(let (($x556 (or $x480 $x480 false)))
(and (not $x556) (or $x556 (and (distinct ?x98 ?x98) true))))))))
(check-sat)
; query 2: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x615 (bvadd in.01_32 (_ bv1 32))))
(let ((?x98 (bvmul ?x615 ?x615)))
(let ((?x36 (bvmul ?x98 (_ bv2 32))))
(let (($x480 (or false false false)))
(let (($x556 (or $x480 $x480 false)))
(let (($x196 (or $x556 false false)))
(and (not $x196) (or $x196 (and (distinct ?x36 ?x36) true))))))))))
(check-sat)
; query 3: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x615 (bvadd in.01_32 (_ bv1 32))))
(let ((?x98 (bvmul ?x615 ?x615)))
(let ((?x36 (bvmul ?x98 (_ bv2 32))))
(let ((?x226 (bvmul ?x36 (_ bv4 32))))
(let (($x480 (or false false false)))
(let (($x556 (or $x480 $x480 false)))
(let (($x196 (or $x556 false false)))
(let (($x1248 (or $x196 false false)))
(and (not $x1248) (or $x1248 (and (distinct ?x226 ?x226) true))))))))))))
(check-sat)
; query 4: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x71 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x480 (or false false false)))
(let (($x308 (not $x480)))
(and $x308 (or $x480 (and (distinct ?x71 ?x71) true)))))))
(check-sat)
; query 5: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x501 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x480 (or false false false)))
(let (($x308 (not $x480)))
(and $x308 (or $x480 (and (distinct ?x501 ?x501) true)))))))
(check-sat)
; query 6: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x480 (or false false false)))
(let (($x308 (not $x480)))
(and $x308 (or $x480 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 7: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x396 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x100 (or false false (or $x396))))
(and (not $x100) (or $x100 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x729 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x480 (or false false false)))
(let (($x308 (not $x480)))
(and $x308 (or $x480 (and (distinct ?x729 ?x729) true)))))))
(check-sat)
; query 9: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x54 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x480 (or false false false)))
(let (($x308 (not $x480)))
(and $x308 (or $x480 (and (distinct ?x54 ?x54) true)))))))
(check-sat)
; query 10: function matrix_add_const, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x480 (or false false false)))
(let (($x308 (not $x480)))
(and $x308 (or $x480 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 11: function matrix_add_const, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x480 (or false false false)))
(let (($x308 (not $x480)))
(and $x308 (or $x480 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 12: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x473 (or false false)))
(and (not $x473) (or $x473 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true)))))
(check-sat)
; query 13: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x938 ((_ sign_extend 16) in.1_16)))
(let ((?x1685 (bvadd ?x938 (_ bv10 32))))
(let (($x500 (and (distinct (bvadd ((_ sign_extend 1) ?x938) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x1685)) true)))
(let (($x473 (or false false)))
(let (($x153 (or $x473 false (or $x500))))
(and (not $x153) (or $x153 (and (distinct ?x1685 ?x1685) true)))))))))
(check-sat)
; query 14: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x938 ((_ sign_extend 16) in.1_16)))
(let ((?x1685 (bvadd ?x938 (_ bv10 32))))
(let ((?x105 ((_ extract 15 0) ?x1685)))
(let (($x500 (and (distinct (bvadd ((_ sign_extend 1) ?x938) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x1685)) true)))
(let (($x473 (or false false)))
(let (($x153 (or $x473 false (or $x500))))
(let (($x381 (or $x153 false)))
(and (not $x381) (or $x381 (and (distinct ?x105 ?x105) true)))))))))))
(check-sat)
