; OptiPhase-Sigma refinement certificate for sweep K54-R3-172
; query 0: function check, block 115, name %116
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x876 (and (distinct (ite (= (_ bv0 32) in0_32) (_ bv1 1) (_ bv0 1)) (ite (= (_ bv13 32) in0_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x2662 (or false false false)))
(let (($x582 (not $x2662)))
(and $x582 (or $x2662 $x876))))))
(check-sat)
; query 1: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x562 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x2662 (or false false false)))
(let (($x582 (not $x2662)))
(and $x582 (or $x2662 (and (distinct ?x562 ?x562) true)))))))
(check-sat)
; query 2: function set1d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x775 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x2662 (or false false false)))
(let (($x582 (not $x2662)))
(and $x582 (or $x2662 (and (distinct ?x775 ?x775) true)))))))
(check-sat)
; query 3: function set1ds, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x467 (ite (= (_ bv4294967295 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x2662 (or false false false)))
(let (($x582 (not $x2662)))
(and $x582 (or $x2662 (and (distinct ?x467 ?x467) true)))))))
(check-sat)
; query 4: function set2d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x775 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x2662 (or false false false)))
(let (($x582 (not $x2662)))
(and $x582 (or $x2662 (and (distinct ?x775 ?x775) true)))))))
(check-sat)
