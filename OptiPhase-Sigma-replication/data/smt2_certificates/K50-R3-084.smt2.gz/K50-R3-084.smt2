; OptiPhase-Sigma refinement certificate for sweep K50-R3-084
; query 0: function check, block 142, name %143
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x1922 (and (distinct (ite (= (_ bv123 32) in0_32) (_ bv1 1) (_ bv0 1)) (ite (= (_ bv1122 32) in0_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x133 (or false false false)))
(let (($x1951 (not $x133)))
(and $x1951 (or $x133 $x1922))))))
(check-sat)
; query 1: function check, block 157, name %158
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x596 (and (distinct (ite (= (_ bv112233 32) in0_32) (_ bv1 1) (_ bv0 1)) (ite (= (_ bv111 32) in0_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x133 (or false false false)))
(let (($x1951 (not $x133)))
(and $x1951 (or $x133 $x596))))))
(check-sat)
; query 2: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x80 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x133 (or false false false)))
(let (($x1951 (not $x133)))
(and $x1951 (or $x133 (and (distinct ?x80 ?x80) true)))))))
(check-sat)
; query 3: function set1d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x68 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x133 (or false false false)))
(let (($x1951 (not $x133)))
(and $x1951 (or $x133 (and (distinct ?x68 ?x68) true)))))))
(check-sat)
; query 4: function set1ds, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x1738 (ite (= (_ bv4294967295 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x133 (or false false false)))
(let (($x1951 (not $x133)))
(and $x1951 (or $x133 (and (distinct ?x1738 ?x1738) true)))))))
(check-sat)
; query 5: function set2d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x68 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x133 (or false false false)))
(let (($x1951 (not $x133)))
(and $x1951 (or $x133 (and (distinct ?x68 ?x68) true)))))))
(check-sat)
