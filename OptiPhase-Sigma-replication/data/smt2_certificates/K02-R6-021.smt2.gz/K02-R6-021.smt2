; OptiPhase-Sigma refinement certificate for sweep K02-R6-021
