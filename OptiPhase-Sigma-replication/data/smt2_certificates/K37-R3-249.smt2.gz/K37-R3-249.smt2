; OptiPhase-Sigma refinement certificate for sweep K37-R3-249
; query 0: function bit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x381 (and (distinct (bvsub ((_ sign_extend 1) (_ bv31 32)) ((_ sign_extend 1) in0_32)) ((_ sign_extend 1) (bvsub (_ bv31 32) in0_32))) true)))
(let (($x296 (or false false (or $x381))))
(and (not $x296) (or $x296 (and (distinct (bvsub (_ bv31 32) in0_32) (bvsub (_ bv31 32) in0_32)) true))))))
(check-sat)
; query 1: function bit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x49 (bvsub (_ bv31 32) in0_32)))
(let ((?x541 (bvshl (_ bv1 32) ?x49)))
(let (($x381 (and (distinct (bvsub ((_ sign_extend 1) (_ bv31 32)) ((_ sign_extend 1) in0_32)) ((_ sign_extend 1) ?x49)) true)))
(let (($x296 (or false false (or $x381))))
(let (($x10 (or (or false $x296 false) (bvuge ?x49 (_ bv32 32)))))
(and (not $x10) (or $x10 (and (distinct ?x541 ?x541) true)))))))))
(check-sat)
; query 2: function bit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x49 (bvsub (_ bv31 32) in0_32)))
(let ((?x541 (bvshl (_ bv1 32) ?x49)))
(let ((?x427 ((_ sign_extend 32) ?x541)))
(let (($x381 (and (distinct (bvsub ((_ sign_extend 1) (_ bv31 32)) ((_ sign_extend 1) in0_32)) ((_ sign_extend 1) ?x49)) true)))
(let (($x296 (or false false (or $x381))))
(let (($x10 (or (or false $x296 false) (bvuge ?x49 (_ bv32 32)))))
(let (($x150 (or $x10 false)))
(and (not $x150) (or $x150 (and (distinct ?x427 ?x427) true)))))))))))
(check-sat)
; query 3: function bit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x49 (bvsub (_ bv31 32) in0_32)))
(let ((?x541 (bvshl (_ bv1 32) ?x49)))
(let ((?x427 ((_ sign_extend 32) ?x541)))
(let ((?x19 (bvand in1_64 ?x427)))
(let (($x381 (and (distinct (bvsub ((_ sign_extend 1) (_ bv31 32)) ((_ sign_extend 1) in0_32)) ((_ sign_extend 1) ?x49)) true)))
(let (($x296 (or false false (or $x381))))
(let (($x10 (or (or false $x296 false) (bvuge ?x49 (_ bv32 32)))))
(let (($x150 (or $x10 false)))
(let (($x42 (or false $x150 false)))
(and (not $x42) (or $x42 (and (distinct ?x19 ?x19) true)))))))))))))
(check-sat)
