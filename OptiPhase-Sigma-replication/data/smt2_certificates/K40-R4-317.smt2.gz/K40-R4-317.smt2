; OptiPhase-Sigma refinement certificate for sweep K40-R4-317
; query 0: function set_key, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let (($x809 (or false false false)))
(and (not $x809) (or $x809 (and (distinct (bvand in1_64 (_ bv7 64)) (bvand in1_64 (_ bv7 64))) true)))))
(check-sat)
; query 1: function set_key, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x415 (ite (and (distinct (_ bv0 64) (bvand in1_64 (_ bv7 64))) true) (_ bv1 1) (_ bv0 1))))
(let (($x809 (or false false false)))
(let (($x19 (or $x809 false false)))
(and (not $x19) (or $x19 (and (distinct ?x415 ?x415) true)))))))
(check-sat)
