; OptiPhase-Sigma refinement certificate for sweep K45-R4-324
; query 0: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x49 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x340 (or false false false)))
(let (($x150 (not $x340)))
(and $x150 (or $x340 (and (distinct ?x49 ?x49) true)))))))
(check-sat)
; query 1: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x172 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x340 (or false false false)))
(let (($x150 (not $x340)))
(and $x150 (or $x340 (and (distinct ?x172 ?x172) true)))))))
(check-sat)
