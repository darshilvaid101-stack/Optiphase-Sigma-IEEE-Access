; OptiPhase-Sigma refinement certificate for sweep K37-R3-256
; query 0: function bit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x33 (and (distinct (bvsub ((_ sign_extend 1) (_ bv31 32)) ((_ sign_extend 1) in0_32)) ((_ sign_extend 1) (bvsub (_ bv31 32) in0_32))) true)))
(let (($x98 (or false false (or $x33))))
(and (not $x98) (or $x98 (and (distinct (bvsub (_ bv31 32) in0_32) (bvsub (_ bv31 32) in0_32)) true))))))
(check-sat)
; query 1: function bit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x323 (bvsub (_ bv31 32) in0_32)))
(let ((?x127 (bvshl (_ bv1 32) ?x323)))
(let (($x33 (and (distinct (bvsub ((_ sign_extend 1) (_ bv31 32)) ((_ sign_extend 1) in0_32)) ((_ sign_extend 1) ?x323)) true)))
(let (($x98 (or false false (or $x33))))
(let (($x121 (or (or false $x98 false) (bvuge ?x323 (_ bv32 32)))))
(and (not $x121) (or $x121 (and (distinct ?x127 ?x127) true)))))))))
(check-sat)
; query 2: function bit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x323 (bvsub (_ bv31 32) in0_32)))
(let ((?x127 (bvshl (_ bv1 32) ?x323)))
(let ((?x64 ((_ sign_extend 32) ?x127)))
(let (($x33 (and (distinct (bvsub ((_ sign_extend 1) (_ bv31 32)) ((_ sign_extend 1) in0_32)) ((_ sign_extend 1) ?x323)) true)))
(let (($x98 (or false false (or $x33))))
(let (($x121 (or (or false $x98 false) (bvuge ?x323 (_ bv32 32)))))
(let (($x19 (or $x121 false)))
(and (not $x19) (or $x19 (and (distinct ?x64 ?x64) true)))))))))))
(check-sat)
; query 3: function bit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x323 (bvsub (_ bv31 32) in0_32)))
(let ((?x127 (bvshl (_ bv1 32) ?x323)))
(let ((?x64 ((_ sign_extend 32) ?x127)))
(let ((?x147 (bvand in1_64 ?x64)))
(let (($x33 (and (distinct (bvsub ((_ sign_extend 1) (_ bv31 32)) ((_ sign_extend 1) in0_32)) ((_ sign_extend 1) ?x323)) true)))
(let (($x98 (or false false (or $x33))))
(let (($x121 (or (or false $x98 false) (bvuge ?x323 (_ bv32 32)))))
(let (($x19 (or $x121 false)))
(let (($x15 (or false $x19 false)))
(and (not $x15) (or $x15 (and (distinct ?x147 ?x147) true)))))))))))))
(check-sat)
; query 4: function main, block 104, name %105
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (and (not (or false false)) (or (or false false) (and (distinct ((_ extract 31 0) (_ bv4294967295 64)) ((_ extract 31 0) (_ bv4294967295 64))) true))))
(check-sat)
; query 5: function main, block 104, name %106
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x104 (or false false)))
(let (($x135 (or $x104 false false)))
(let (($x83 (or $x135 (and (distinct (bvand ((_ extract 31 0) (_ bv4294967295 64)) (_ bv4278190080 32)) (bvand ((_ extract 31 0) (_ bv4294967295 64)) (_ bv4278190080 32))) true))))
(let (($x39 (not $x135)))
(and $x39 $x83))))))
(check-sat)
; query 6: function main, block 104, name %107
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x75 ((_ extract 31 0) (_ bv4294967295 64))))
(let ((?x71 (bvand ?x75 (_ bv4278190080 32))))
(let ((?x125 (bvlshr ?x71 (_ bv24 32))))
(let (($x104 (or false false)))
(let (($x135 (or $x104 false false)))
(let (($x653 (or $x135 false false)))
(let (($x446 (or $x653 (bvuge (_ bv24 32) (_ bv32 32)))))
(let (($x82 (not $x446)))
(and $x82 (or $x446 (and (distinct ?x125 ?x125) true))))))))))))
(check-sat)
; query 7: function main, block 104, name %108
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (and (not (or false false)) (or (or false false) (and (distinct ((_ extract 31 0) (_ bv4294967295 64)) ((_ extract 31 0) (_ bv4294967295 64))) true))))
(check-sat)
; query 8: function main, block 104, name %109
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x104 (or false false)))
(let (($x135 (or $x104 false false)))
(let (($x61 (or $x135 (and (distinct (bvand ((_ extract 31 0) (_ bv4294967295 64)) (_ bv16711680 32)) (bvand ((_ extract 31 0) (_ bv4294967295 64)) (_ bv16711680 32))) true))))
(let (($x39 (not $x135)))
(and $x39 $x61))))))
(check-sat)
; query 9: function main, block 104, name %110
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x75 ((_ extract 31 0) (_ bv4294967295 64))))
(let ((?x392 (bvand ?x75 (_ bv16711680 32))))
(let ((?x123 (bvlshr ?x392 (_ bv8 32))))
(let (($x104 (or false false)))
(let (($x135 (or $x104 false false)))
(let (($x653 (or $x135 false false)))
(let (($x240 (or $x653 (bvuge (_ bv8 32) (_ bv32 32)))))
(let (($x42 (not $x240)))
(and $x42 (or $x240 (and (distinct ?x123 ?x123) true))))))))))))
(check-sat)
; query 10: function main, block 104, name %111
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x75 ((_ extract 31 0) (_ bv4294967295 64))))
(let ((?x392 (bvand ?x75 (_ bv16711680 32))))
(let ((?x123 (bvlshr ?x392 (_ bv8 32))))
(let ((?x71 (bvand ?x75 (_ bv4278190080 32))))
(let ((?x125 (bvlshr ?x71 (_ bv24 32))))
(let ((?x44 (bvor ?x125 ?x123)))
(let (($x104 (or false false)))
(let (($x135 (or $x104 false false)))
(let (($x653 (or $x135 false false)))
(let (($x240 (or $x653 (bvuge (_ bv8 32) (_ bv32 32)))))
(let (($x446 (or $x653 (bvuge (_ bv24 32) (_ bv32 32)))))
(let (($x30 (or $x446 $x240 false)))
(and (not $x30) (or $x30 (and (distinct ?x44 ?x44) true))))))))))))))))
(check-sat)
; query 11: function main, block 104, name %112
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (and (not (or false false)) (or (or false false) (and (distinct ((_ extract 31 0) (_ bv4294967295 64)) ((_ extract 31 0) (_ bv4294967295 64))) true))))
(check-sat)
; query 12: function main, block 104, name %113
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x104 (or false false)))
(let (($x135 (or $x104 false false)))
(let (($x458 (or $x135 (and (distinct (bvand ((_ extract 31 0) (_ bv4294967295 64)) (_ bv65280 32)) (bvand ((_ extract 31 0) (_ bv4294967295 64)) (_ bv65280 32))) true))))
(let (($x39 (not $x135)))
(and $x39 $x458))))))
(check-sat)
; query 13: function main, block 104, name %114
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x75 ((_ extract 31 0) (_ bv4294967295 64))))
(let ((?x13 (bvand ?x75 (_ bv65280 32))))
(let ((?x469 (bvshl ?x13 (_ bv8 32))))
(let (($x104 (or false false)))
(let (($x135 (or $x104 false false)))
(let (($x653 (or $x135 false false)))
(let (($x240 (or $x653 (bvuge (_ bv8 32) (_ bv32 32)))))
(let (($x42 (not $x240)))
(and $x42 (or $x240 (and (distinct ?x469 ?x469) true))))))))))))
(check-sat)
; query 14: function main, block 104, name %115
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x75 ((_ extract 31 0) (_ bv4294967295 64))))
(let ((?x13 (bvand ?x75 (_ bv65280 32))))
(let ((?x469 (bvshl ?x13 (_ bv8 32))))
(let ((?x392 (bvand ?x75 (_ bv16711680 32))))
(let ((?x123 (bvlshr ?x392 (_ bv8 32))))
(let ((?x71 (bvand ?x75 (_ bv4278190080 32))))
(let ((?x125 (bvlshr ?x71 (_ bv24 32))))
(let ((?x44 (bvor ?x125 ?x123)))
(let ((?x63 (bvor ?x44 ?x469)))
(let (($x104 (or false false)))
(let (($x135 (or $x104 false false)))
(let (($x653 (or $x135 false false)))
(let (($x240 (or $x653 (bvuge (_ bv8 32) (_ bv32 32)))))
(let (($x446 (or $x653 (bvuge (_ bv24 32) (_ bv32 32)))))
(let (($x30 (or $x446 $x240 false)))
(let (($x6 (or $x30 $x240 false)))
(and (not $x6) (or $x6 (and (distinct ?x63 ?x63) true))))))))))))))))))))
(check-sat)
; query 15: function main, block 104, name %116
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (and (not (or false false)) (or (or false false) (and (distinct ((_ extract 31 0) (_ bv4294967295 64)) ((_ extract 31 0) (_ bv4294967295 64))) true))))
(check-sat)
; query 16: function main, block 104, name %117
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x104 (or false false)))
(let (($x135 (or $x104 false false)))
(let (($x79 (or $x135 (and (distinct (bvand ((_ extract 31 0) (_ bv4294967295 64)) (_ bv255 32)) (bvand ((_ extract 31 0) (_ bv4294967295 64)) (_ bv255 32))) true))))
(let (($x39 (not $x135)))
(and $x39 $x79))))))
(check-sat)
; query 17: function main, block 104, name %118
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x75 ((_ extract 31 0) (_ bv4294967295 64))))
(let ((?x487 (bvand ?x75 (_ bv255 32))))
(let ((?x62 (bvshl ?x487 (_ bv24 32))))
(let (($x104 (or false false)))
(let (($x135 (or $x104 false false)))
(let (($x653 (or $x135 false false)))
(let (($x446 (or $x653 (bvuge (_ bv24 32) (_ bv32 32)))))
(let (($x82 (not $x446)))
(and $x82 (or $x446 (and (distinct ?x62 ?x62) true))))))))))))
(check-sat)
; query 18: function main, block 104, name %119
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x75 ((_ extract 31 0) (_ bv4294967295 64))))
(let ((?x487 (bvand ?x75 (_ bv255 32))))
(let ((?x62 (bvshl ?x487 (_ bv24 32))))
(let ((?x13 (bvand ?x75 (_ bv65280 32))))
(let ((?x469 (bvshl ?x13 (_ bv8 32))))
(let ((?x392 (bvand ?x75 (_ bv16711680 32))))
(let ((?x123 (bvlshr ?x392 (_ bv8 32))))
(let ((?x71 (bvand ?x75 (_ bv4278190080 32))))
(let ((?x125 (bvlshr ?x71 (_ bv24 32))))
(let ((?x44 (bvor ?x125 ?x123)))
(let ((?x63 (bvor ?x44 ?x469)))
(let ((?x22 (bvor ?x63 ?x62)))
(let (($x104 (or false false)))
(let (($x135 (or $x104 false false)))
(let (($x653 (or $x135 false false)))
(let (($x446 (or $x653 (bvuge (_ bv24 32) (_ bv32 32)))))
(let (($x240 (or $x653 (bvuge (_ bv8 32) (_ bv32 32)))))
(let (($x30 (or $x446 $x240 false)))
(let (($x6 (or $x30 $x240 false)))
(let (($x362 (or $x6 $x446 false)))
(and (not $x362) (or $x362 (and (distinct ?x22 ?x22) true))))))))))))))))))))))))
(check-sat)
; query 19: function pat_insert, block 126, name %127
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x9 (ite (and (distinct (_ bv0 32) in.01_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x110 (or false false false)))
(and (not $x110) (or $x110 (and (distinct ?x9 ?x9) true))))))
(check-sat)
; query 20: function pat_insert, block 156, name %157
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.3_32 () (_ BitVec 32))
(assert
 (let (($x146 (and (distinct (bvadd ((_ sign_extend 1) in.3_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.3_32 (_ bv1 32)))) true)))
(let (($x130 (or false false (or $x146))))
(and (not $x130) (or $x130 (and (distinct (bvadd in.3_32 (_ bv1 32)) (bvadd in.3_32 (_ bv1 32))) true))))))
(check-sat)
; query 21: function pat_insert, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_32 () (_ BitVec 32))
(assert
 (let (($x95 (and (distinct (bvadd ((_ sign_extend 1) in.03_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.03_32 (_ bv1 32)))) true)))
(let (($x345 (or false false (or $x95))))
(and (not $x345) (or $x345 (and (distinct (bvadd in.03_32 (_ bv1 32)) (bvadd in.03_32 (_ bv1 32))) true))))))
(check-sat)
; query 22: function pat_remove, block 190, name %191
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x49 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x341 (or false false (or $x49))))
(and (not $x341) (or $x341 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 23: function pat_remove, block 230, name %231
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x48 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x640 (or false false (or $x48))))
(and (not $x640) (or $x640 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
