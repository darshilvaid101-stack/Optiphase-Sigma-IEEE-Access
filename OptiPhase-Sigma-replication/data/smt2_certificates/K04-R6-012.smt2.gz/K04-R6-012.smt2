; OptiPhase-Sigma refinement certificate for sweep K04-R6-012
