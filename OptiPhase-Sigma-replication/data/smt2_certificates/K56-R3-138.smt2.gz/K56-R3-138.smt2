; OptiPhase-Sigma refinement certificate for sweep K56-R3-138
; query 0: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x43 (or false false false)))
(let (($x416 (not $x43)))
(and $x416 (or $x43 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x894 (bvadd in.01_32 (_ bv1 32))))
(let ((?x200 (bvmul ?x894 ?x894)))
(let (($x43 (or false false false)))
(let (($x882 (or $x43 $x43 false)))
(and (not $x882) (or $x882 (and (distinct ?x200 ?x200) true))))))))
(check-sat)
; query 2: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x894 (bvadd in.01_32 (_ bv1 32))))
(let ((?x200 (bvmul ?x894 ?x894)))
(let ((?x338 (bvmul ?x200 (_ bv2 32))))
(let (($x43 (or false false false)))
(let (($x882 (or $x43 $x43 false)))
(let (($x560 (or $x882 false false)))
(and (not $x560) (or $x560 (and (distinct ?x338 ?x338) true))))))))))
(check-sat)
; query 3: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x894 (bvadd in.01_32 (_ bv1 32))))
(let ((?x200 (bvmul ?x894 ?x894)))
(let ((?x338 (bvmul ?x200 (_ bv2 32))))
(let ((?x861 (bvmul ?x338 (_ bv4 32))))
(let (($x43 (or false false false)))
(let (($x882 (or $x43 $x43 false)))
(let (($x560 (or $x882 false false)))
(let (($x5736 (or $x560 false false)))
(and (not $x5736) (or $x5736 (and (distinct ?x861 ?x861) true))))))))))))
(check-sat)
; query 4: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x816 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x43 (or false false false)))
(let (($x416 (not $x43)))
(and $x416 (or $x43 (and (distinct ?x816 ?x816) true)))))))
(check-sat)
; query 5: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x1750 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x43 (or false false false)))
(let (($x416 (not $x43)))
(and $x416 (or $x43 (and (distinct ?x1750 ?x1750) true)))))))
(check-sat)
; query 6: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x43 (or false false false)))
(let (($x416 (not $x43)))
(and $x416 (or $x43 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 7: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x67 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x1095 (or false false (or $x67))))
(and (not $x1095) (or $x1095 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x17 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x43 (or false false false)))
(let (($x416 (not $x43)))
(and $x416 (or $x43 (and (distinct ?x17 ?x17) true)))))))
(check-sat)
; query 9: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x384 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x43 (or false false false)))
(let (($x416 (not $x43)))
(and $x416 (or $x43 (and (distinct ?x384 ?x384) true)))))))
(check-sat)
; query 10: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x1934 (or false false)))
(and (not $x1934) (or $x1934 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true)))))
(check-sat)
; query 11: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x616 ((_ sign_extend 16) in.1_16)))
(let ((?x238 (bvadd ?x616 (_ bv10 32))))
(let (($x115 (and (distinct (bvadd ((_ sign_extend 1) ?x616) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x238)) true)))
(let (($x1934 (or false false)))
(let (($x235 (or $x1934 false (or $x115))))
(and (not $x235) (or $x235 (and (distinct ?x238 ?x238) true)))))))))
(check-sat)
; query 12: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x616 ((_ sign_extend 16) in.1_16)))
(let ((?x238 (bvadd ?x616 (_ bv10 32))))
(let ((?x127 ((_ extract 15 0) ?x238)))
(let (($x115 (and (distinct (bvadd ((_ sign_extend 1) ?x616) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x238)) true)))
(let (($x1934 (or false false)))
(let (($x235 (or $x1934 false (or $x115))))
(let (($x48 (or $x235 false)))
(and (not $x48) (or $x48 (and (distinct ?x127 ?x127) true)))))))))))
(check-sat)
