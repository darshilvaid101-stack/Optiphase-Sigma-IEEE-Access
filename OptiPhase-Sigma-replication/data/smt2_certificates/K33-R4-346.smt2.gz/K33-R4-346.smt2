; OptiPhase-Sigma refinement certificate for sweep K33-R4-346
; query 0: function edge_draw, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let ((?x480 (ite (= (_ bv0 32) in4_32) (_ bv1 1) (_ bv0 1))))
(let (($x456 (or false false false)))
(and (not $x456) (or $x456 (and (distinct ?x480 ?x480) true))))))
(check-sat)
