; OptiPhase-Sigma refinement certificate for sweep K34-R3-092
; query 0: function edge_draw, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let ((?x93 (ite (= (_ bv0 32) in4_32) (_ bv1 1) (_ bv0 1))))
(let (($x200 (or false false false)))
(and (not $x200) (or $x200 (and (distinct ?x93 ?x93) true))))))
(check-sat)
