; OptiPhase-Sigma refinement certificate for sweep K35-R3-120
; query 0: function corner_draw, block 11, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x660 (ite (= (_ bv0 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x32 (or false false false)))
(and (not $x32) (or $x32 (and (distinct ?x660 ?x660) true))))))
(check-sat)
; query 1: function main, block 35, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x54 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x554 (or false false (or $x54))))
(and (not $x554) (or $x554 (and (distinct (bvadd in.020_32 (_ bv1 32)) (bvadd in.020_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function main, block 35, name %37
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let ((?x117 (ite (bvsge (bvadd in.020_32 (_ bv1 32)) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x54 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x554 (or false false (or $x54))))
(let (($x97 (or $x554 false false)))
(and (not $x97) (or $x97 (and (distinct ?x117 ?x117) true))))))))
(check-sat)
; query 3: function main, block 49, name %50
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x54 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x554 (or false false (or $x54))))
(and (not $x554) (or $x554 (and (distinct (bvadd in.020_32 (_ bv1 32)) (bvadd in.020_32 (_ bv1 32))) true))))))
(check-sat)
; query 4: function main, block 49, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let ((?x117 (ite (bvsge (bvadd in.020_32 (_ bv1 32)) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x54 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x554 (or false false (or $x54))))
(let (($x97 (or $x554 false false)))
(and (not $x97) (or $x97 (and (distinct ?x117 ?x117) true))))))))
(check-sat)
