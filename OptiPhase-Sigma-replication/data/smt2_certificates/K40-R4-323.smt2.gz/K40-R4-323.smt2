; OptiPhase-Sigma refinement certificate for sweep K40-R4-323
; query 0: function set_key, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let (($x94 (or false false false)))
(and (not $x94) (or $x94 (and (distinct (bvand in1_64 (_ bv7 64)) (bvand in1_64 (_ bv7 64))) true)))))
(check-sat)
; query 1: function set_key, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x137 (ite (and (distinct (_ bv0 64) (bvand in1_64 (_ bv7 64))) true) (_ bv1 1) (_ bv0 1))))
(let (($x94 (or false false false)))
(let (($x88 (or $x94 false false)))
(and (not $x88) (or $x88 (and (distinct ?x137 ?x137) true)))))))
(check-sat)
