; OptiPhase-Sigma refinement certificate for sweep K37-R2-080
; query 0: function bit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x50 (and (distinct (bvsub ((_ sign_extend 1) (_ bv31 32)) ((_ sign_extend 1) in0_32)) ((_ sign_extend 1) (bvsub (_ bv31 32) in0_32))) true)))
(let (($x153 (or false false (or $x50))))
(and (not $x153) (or $x153 (and (distinct (bvsub (_ bv31 32) in0_32) (bvsub (_ bv31 32) in0_32)) true))))))
(check-sat)
; query 1: function bit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x96 (bvsub (_ bv31 32) in0_32)))
(let ((?x130 (bvshl (_ bv1 32) ?x96)))
(let (($x50 (and (distinct (bvsub ((_ sign_extend 1) (_ bv31 32)) ((_ sign_extend 1) in0_32)) ((_ sign_extend 1) ?x96)) true)))
(let (($x153 (or false false (or $x50))))
(let (($x65 (or (or false $x153 false) (bvuge ?x96 (_ bv32 32)))))
(and (not $x65) (or $x65 (and (distinct ?x130 ?x130) true)))))))))
(check-sat)
; query 2: function bit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x96 (bvsub (_ bv31 32) in0_32)))
(let ((?x130 (bvshl (_ bv1 32) ?x96)))
(let ((?x100 ((_ sign_extend 32) ?x130)))
(let (($x50 (and (distinct (bvsub ((_ sign_extend 1) (_ bv31 32)) ((_ sign_extend 1) in0_32)) ((_ sign_extend 1) ?x96)) true)))
(let (($x153 (or false false (or $x50))))
(let (($x65 (or (or false $x153 false) (bvuge ?x96 (_ bv32 32)))))
(let (($x29 (or $x65 false)))
(and (not $x29) (or $x29 (and (distinct ?x100 ?x100) true)))))))))))
(check-sat)
; query 3: function bit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x96 (bvsub (_ bv31 32) in0_32)))
(let ((?x130 (bvshl (_ bv1 32) ?x96)))
(let ((?x100 ((_ sign_extend 32) ?x130)))
(let ((?x315 (bvand in1_64 ?x100)))
(let (($x50 (and (distinct (bvsub ((_ sign_extend 1) (_ bv31 32)) ((_ sign_extend 1) in0_32)) ((_ sign_extend 1) ?x96)) true)))
(let (($x153 (or false false (or $x50))))
(let (($x65 (or (or false $x153 false) (bvuge ?x96 (_ bv32 32)))))
(let (($x29 (or $x65 false)))
(let (($x131 (or false $x29 false)))
(and (not $x131) (or $x131 (and (distinct ?x315 ?x315) true)))))))))))))
(check-sat)
; query 4: function main, block 104, name %105
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (and (not (or false false)) (or (or false false) (and (distinct ((_ extract 31 0) (_ bv4294967295 64)) ((_ extract 31 0) (_ bv4294967295 64))) true))))
(check-sat)
; query 5: function main, block 104, name %106
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x107 (or false false)))
(let (($x140 (or $x107 false false)))
(let (($x56 (or $x140 (and (distinct (bvand ((_ extract 31 0) (_ bv4294967295 64)) (_ bv4278190080 32)) (bvand ((_ extract 31 0) (_ bv4294967295 64)) (_ bv4278190080 32))) true))))
(let (($x46 (not $x140)))
(and $x46 $x56))))))
(check-sat)
; query 6: function main, block 104, name %107
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x104 ((_ extract 31 0) (_ bv4294967295 64))))
(let ((?x191 (bvand ?x104 (_ bv4278190080 32))))
(let ((?x249 (bvlshr ?x191 (_ bv24 32))))
(let (($x107 (or false false)))
(let (($x140 (or $x107 false false)))
(let (($x637 (or $x140 false false)))
(let (($x653 (or $x637 (bvuge (_ bv24 32) (_ bv32 32)))))
(let (($x143 (not $x653)))
(and $x143 (or $x653 (and (distinct ?x249 ?x249) true))))))))))))
(check-sat)
; query 7: function main, block 104, name %108
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (and (not (or false false)) (or (or false false) (and (distinct ((_ extract 31 0) (_ bv4294967295 64)) ((_ extract 31 0) (_ bv4294967295 64))) true))))
(check-sat)
; query 8: function main, block 104, name %109
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x107 (or false false)))
(let (($x140 (or $x107 false false)))
(let (($x109 (or $x140 (and (distinct (bvand ((_ extract 31 0) (_ bv4294967295 64)) (_ bv16711680 32)) (bvand ((_ extract 31 0) (_ bv4294967295 64)) (_ bv16711680 32))) true))))
(let (($x46 (not $x140)))
(and $x46 $x109))))))
(check-sat)
; query 9: function main, block 104, name %110
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x104 ((_ extract 31 0) (_ bv4294967295 64))))
(let ((?x37 (bvand ?x104 (_ bv16711680 32))))
(let ((?x122 (bvlshr ?x37 (_ bv8 32))))
(let (($x107 (or false false)))
(let (($x140 (or $x107 false false)))
(let (($x637 (or $x140 false false)))
(let (($x197 (or $x637 (bvuge (_ bv8 32) (_ bv32 32)))))
(let (($x126 (not $x197)))
(and $x126 (or $x197 (and (distinct ?x122 ?x122) true))))))))))))
(check-sat)
; query 10: function main, block 104, name %111
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x104 ((_ extract 31 0) (_ bv4294967295 64))))
(let ((?x37 (bvand ?x104 (_ bv16711680 32))))
(let ((?x122 (bvlshr ?x37 (_ bv8 32))))
(let ((?x191 (bvand ?x104 (_ bv4278190080 32))))
(let ((?x249 (bvlshr ?x191 (_ bv24 32))))
(let ((?x679 (bvor ?x249 ?x122)))
(let (($x107 (or false false)))
(let (($x140 (or $x107 false false)))
(let (($x637 (or $x140 false false)))
(let (($x197 (or $x637 (bvuge (_ bv8 32) (_ bv32 32)))))
(let (($x653 (or $x637 (bvuge (_ bv24 32) (_ bv32 32)))))
(let (($x83 (or $x653 $x197 false)))
(and (not $x83) (or $x83 (and (distinct ?x679 ?x679) true))))))))))))))))
(check-sat)
; query 11: function main, block 104, name %112
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (and (not (or false false)) (or (or false false) (and (distinct ((_ extract 31 0) (_ bv4294967295 64)) ((_ extract 31 0) (_ bv4294967295 64))) true))))
(check-sat)
; query 12: function main, block 104, name %113
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x107 (or false false)))
(let (($x140 (or $x107 false false)))
(let (($x116 (or $x140 (and (distinct (bvand ((_ extract 31 0) (_ bv4294967295 64)) (_ bv65280 32)) (bvand ((_ extract 31 0) (_ bv4294967295 64)) (_ bv65280 32))) true))))
(let (($x46 (not $x140)))
(and $x46 $x116))))))
(check-sat)
; query 13: function main, block 104, name %114
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x104 ((_ extract 31 0) (_ bv4294967295 64))))
(let ((?x609 (bvand ?x104 (_ bv65280 32))))
(let ((?x212 (bvshl ?x609 (_ bv8 32))))
(let (($x107 (or false false)))
(let (($x140 (or $x107 false false)))
(let (($x637 (or $x140 false false)))
(let (($x197 (or $x637 (bvuge (_ bv8 32) (_ bv32 32)))))
(let (($x126 (not $x197)))
(and $x126 (or $x197 (and (distinct ?x212 ?x212) true))))))))))))
(check-sat)
; query 14: function main, block 104, name %115
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x104 ((_ extract 31 0) (_ bv4294967295 64))))
(let ((?x609 (bvand ?x104 (_ bv65280 32))))
(let ((?x212 (bvshl ?x609 (_ bv8 32))))
(let ((?x37 (bvand ?x104 (_ bv16711680 32))))
(let ((?x122 (bvlshr ?x37 (_ bv8 32))))
(let ((?x191 (bvand ?x104 (_ bv4278190080 32))))
(let ((?x249 (bvlshr ?x191 (_ bv24 32))))
(let ((?x679 (bvor ?x249 ?x122)))
(let ((?x232 (bvor ?x679 ?x212)))
(let (($x107 (or false false)))
(let (($x140 (or $x107 false false)))
(let (($x637 (or $x140 false false)))
(let (($x197 (or $x637 (bvuge (_ bv8 32) (_ bv32 32)))))
(let (($x653 (or $x637 (bvuge (_ bv24 32) (_ bv32 32)))))
(let (($x83 (or $x653 $x197 false)))
(let (($x316 (or $x83 $x197 false)))
(and (not $x316) (or $x316 (and (distinct ?x232 ?x232) true))))))))))))))))))))
(check-sat)
; query 15: function main, block 104, name %116
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (and (not (or false false)) (or (or false false) (and (distinct ((_ extract 31 0) (_ bv4294967295 64)) ((_ extract 31 0) (_ bv4294967295 64))) true))))
(check-sat)
; query 16: function main, block 104, name %117
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x107 (or false false)))
(let (($x140 (or $x107 false false)))
(let (($x63 (or $x140 (and (distinct (bvand ((_ extract 31 0) (_ bv4294967295 64)) (_ bv255 32)) (bvand ((_ extract 31 0) (_ bv4294967295 64)) (_ bv255 32))) true))))
(let (($x46 (not $x140)))
(and $x46 $x63))))))
(check-sat)
; query 17: function main, block 104, name %118
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x104 ((_ extract 31 0) (_ bv4294967295 64))))
(let ((?x147 (bvand ?x104 (_ bv255 32))))
(let ((?x169 (bvshl ?x147 (_ bv24 32))))
(let (($x107 (or false false)))
(let (($x140 (or $x107 false false)))
(let (($x637 (or $x140 false false)))
(let (($x653 (or $x637 (bvuge (_ bv24 32) (_ bv32 32)))))
(let (($x143 (not $x653)))
(and $x143 (or $x653 (and (distinct ?x169 ?x169) true))))))))))))
(check-sat)
; query 18: function main, block 104, name %119
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x104 ((_ extract 31 0) (_ bv4294967295 64))))
(let ((?x147 (bvand ?x104 (_ bv255 32))))
(let ((?x169 (bvshl ?x147 (_ bv24 32))))
(let ((?x609 (bvand ?x104 (_ bv65280 32))))
(let ((?x212 (bvshl ?x609 (_ bv8 32))))
(let ((?x37 (bvand ?x104 (_ bv16711680 32))))
(let ((?x122 (bvlshr ?x37 (_ bv8 32))))
(let ((?x191 (bvand ?x104 (_ bv4278190080 32))))
(let ((?x249 (bvlshr ?x191 (_ bv24 32))))
(let ((?x679 (bvor ?x249 ?x122)))
(let ((?x232 (bvor ?x679 ?x212)))
(let ((?x674 (bvor ?x232 ?x169)))
(let (($x107 (or false false)))
(let (($x140 (or $x107 false false)))
(let (($x637 (or $x140 false false)))
(let (($x653 (or $x637 (bvuge (_ bv24 32) (_ bv32 32)))))
(let (($x197 (or $x637 (bvuge (_ bv8 32) (_ bv32 32)))))
(let (($x83 (or $x653 $x197 false)))
(let (($x316 (or $x83 $x197 false)))
(let (($x564 (or $x316 $x653 false)))
(and (not $x564) (or $x564 (and (distinct ?x674 ?x674) true))))))))))))))))))))))))
(check-sat)
; query 19: function pat_insert, block 126, name %127
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x228 (ite (and (distinct (_ bv0 32) in.01_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x8 (or false false false)))
(and (not $x8) (or $x8 (and (distinct ?x228 ?x228) true))))))
(check-sat)
; query 20: function pat_insert, block 156, name %157
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.3_32 () (_ BitVec 32))
(assert
 (let (($x120 (and (distinct (bvadd ((_ sign_extend 1) in.3_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.3_32 (_ bv1 32)))) true)))
(let (($x76 (or false false (or $x120))))
(and (not $x76) (or $x76 (and (distinct (bvadd in.3_32 (_ bv1 32)) (bvadd in.3_32 (_ bv1 32))) true))))))
(check-sat)
; query 21: function pat_insert, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_32 () (_ BitVec 32))
(assert
 (let (($x59 (and (distinct (bvadd ((_ sign_extend 1) in.03_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.03_32 (_ bv1 32)))) true)))
(let (($x118 (or false false (or $x59))))
(and (not $x118) (or $x118 (and (distinct (bvadd in.03_32 (_ bv1 32)) (bvadd in.03_32 (_ bv1 32))) true))))))
(check-sat)
; query 22: function pat_remove, block 190, name %191
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x78 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x70 (or false false (or $x78))))
(and (not $x70) (or $x70 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 23: function pat_remove, block 230, name %231
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x181 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x75 (or false false (or $x181))))
(and (not $x75) (or $x75 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
