; OptiPhase-Sigma refinement certificate for sweep K35-R3-254
; query 0: function corner_draw, block 11, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x56 (ite (= (_ bv0 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x758 (or false false false)))
(let (($x18 (not $x758)))
(and $x18 (or $x758 (and (distinct ?x56 ?x56) true)))))))
(check-sat)
; query 1: function edge_draw, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let ((?x793 (ite (= (_ bv0 32) in4_32) (_ bv1 1) (_ bv0 1))))
(let (($x758 (or false false false)))
(let (($x18 (not $x758)))
(and $x18 (or $x758 (and (distinct ?x793 ?x793) true)))))))
(check-sat)
; query 2: function enlarge, block 106, name %107
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x509 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x278 (or false false (or $x509))))
(and (not $x278) (or $x278 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 3: function enlarge, block 158, name %159
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x114 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x662 (or false false (or $x114))))
(and (not $x662) (or $x662 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 4: function enlarge, block 161, name %162
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let (($x15 (and (distinct (bvadd ((_ sign_extend 1) in.2_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.2_32 (_ bv1 32)))) true)))
(let (($x88 (or false false (or $x15))))
(and (not $x88) (or $x88 (and (distinct (bvadd in.2_32 (_ bv1 32)) (bvadd in.2_32 (_ bv1 32))) true))))))
(check-sat)
; query 5: function enlarge, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x313 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x407 (or false false (or $x313))))
(and (not $x407) (or $x407 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 6: function getint, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x566 (ite (bvsle (_ bv48 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x758 (or false false false)))
(let (($x18 (not $x758)))
(and $x18 (or $x758 (and (distinct ?x566 ?x566) true)))))))
(check-sat)
; query 7: function getint, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x295 (ite (bvsge (_ bv57 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x758 (or false false false)))
(let (($x18 (not $x758)))
(and $x18 (or $x758 (and (distinct ?x295 ?x295) true)))))))
(check-sat)
; query 8: function getint, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in26_32 () (_ BitVec 32))
(assert
 (let ((?x499 (ite (bvsgt (_ bv48 32) in26_32) (_ bv1 1) (_ bv0 1))))
(let (($x758 (or false false false)))
(let (($x18 (not $x758)))
(and $x18 (or $x758 (and (distinct ?x499 ?x499) true)))))))
(check-sat)
; query 9: function getint, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in26_32 () (_ BitVec 32))
(assert
 (let ((?x59 (ite (bvslt (_ bv57 32) in26_32) (_ bv1 1) (_ bv0 1))))
(let (($x758 (or false false false)))
(let (($x18 (not $x758)))
(and $x18 (or $x758 (and (distinct ?x59 ?x59) true)))))))
(check-sat)
; query 10: function getint, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x17 (ite (= (_ bv4294967295 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x758 (or false false false)))
(let (($x18 (not $x758)))
(and $x18 (or $x758 (and (distinct ?x17 ?x17) true)))))))
(check-sat)
; query 11: function int_to_uchar, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_32 () (_ BitVec 32))
(assert
 (let (($x163 (and (distinct (bvadd ((_ sign_extend 1) in.03_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.03_32 (_ bv1 32)))) true)))
(let (($x143 (or false false (or $x163))))
(and (not $x143) (or $x143 (and (distinct (bvadd in.03_32 (_ bv1 32)) (bvadd in.03_32 (_ bv1 32))) true))))))
(check-sat)
; query 12: function int_to_uchar, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.14_32 () (_ BitVec 32))
(assert
 (let (($x282 (and (distinct (bvadd ((_ sign_extend 1) in.14_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.14_32 (_ bv1 32)))) true)))
(let (($x460 (or false false (or $x282))))
(and (not $x460) (or $x460 (and (distinct (bvadd in.14_32 (_ bv1 32)) (bvadd in.14_32 (_ bv1 32))) true))))))
(check-sat)
; query 13: function main, block 35, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x235 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x420 (or false false (or $x235))))
(and (not $x420) (or $x420 (and (distinct (bvadd in.020_32 (_ bv1 32)) (bvadd in.020_32 (_ bv1 32))) true))))))
(check-sat)
; query 14: function main, block 35, name %37
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let ((?x497 (ite (bvsge (bvadd in.020_32 (_ bv1 32)) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x235 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x420 (or false false (or $x235))))
(let (($x121 (or $x420 false false)))
(and (not $x121) (or $x121 (and (distinct ?x497 ?x497) true))))))))
(check-sat)
; query 15: function main, block 49, name %50
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x235 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x420 (or false false (or $x235))))
(and (not $x420) (or $x420 (and (distinct (bvadd in.020_32 (_ bv1 32)) (bvadd in.020_32 (_ bv1 32))) true))))))
(check-sat)
; query 16: function main, block 49, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let ((?x497 (ite (bvsge (bvadd in.020_32 (_ bv1 32)) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x235 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x420 (or false false (or $x235))))
(let (($x121 (or $x420 false false)))
(and (not $x121) (or $x121 (and (distinct ?x497 ?x497) true))))))))
(check-sat)
; query 17: function setup_brightness_lut, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x313 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x407 (or false false (or $x313))))
(and (not $x407) (or $x407 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 18: function susan_corners, block 1066, name %1067
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x114 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x662 (or false false (or $x114))))
(and (not $x662) (or $x662 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 19: function susan_corners, block 1069, name %1070
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x313 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x407 (or false false (or $x313))))
(and (not $x407) (or $x407 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 20: function susan_corners, block 1549, name %1550
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x509 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x278 (or false false (or $x509))))
(and (not $x278) (or $x278 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 21: function susan_corners, block 1552, name %1553
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x216 (and (distinct (bvadd ((_ sign_extend 1) in.12_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.12_32 (_ bv1 32)))) true)))
(let (($x111 (or false false (or $x216))))
(and (not $x111) (or $x111 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 22: function susan_corners, block 845, name %846
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in839_32 () (_ BitVec 32))
(declare-fun in840_32 () (_ BitVec 32))
(assert
 (let ((?x108 (ite (bvslt in840_32 in839_32) (_ bv1 1) (_ bv0 1))))
(let (($x758 (or false false false)))
(let (($x18 (not $x758)))
(and $x18 (or $x758 (and (distinct ?x108 ?x108) true)))))))
(check-sat)
; query 23: function susan_corners_quick, block 1469, name %1470
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x509 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x278 (or false false (or $x509))))
(and (not $x278) (or $x278 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 24: function susan_corners_quick, block 1472, name %1473
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x216 (and (distinct (bvadd ((_ sign_extend 1) in.12_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.12_32 (_ bv1 32)))) true)))
(let (($x111 (or false false (or $x216))))
(and (not $x111) (or $x111 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 25: function susan_corners_quick, block 433, name %434
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x114 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x662 (or false false (or $x114))))
(and (not $x662) (or $x662 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 26: function susan_corners_quick, block 436, name %437
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x313 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x407 (or false false (or $x313))))
(and (not $x407) (or $x407 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 27: function susan_edges, block 1432, name %1433
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1417_32 () (_ BitVec 32))
(assert
 (let ((?x526 (ite (bvslt (_ bv0 32) in1417_32) (_ bv1 1) (_ bv0 1))))
(let (($x758 (or false false false)))
(let (($x18 (not $x758)))
(and $x18 (or $x758 (and (distinct ?x526 ?x526) true)))))))
(check-sat)
; query 28: function susan_edges, block 1486, name %1487
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.116_32 () (_ BitVec 32))
(assert
 (let (($x146 (and (distinct (bvadd ((_ sign_extend 1) in.116_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.116_32 (_ bv1 32)))) true)))
(let (($x507 (or false false (or $x146))))
(and (not $x507) (or $x507 (and (distinct (bvadd in.116_32 (_ bv1 32)) (bvadd in.116_32 (_ bv1 32))) true))))))
(check-sat)
; query 29: function susan_edges, block 1489, name %1490
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.114_32 () (_ BitVec 32))
(assert
 (let (($x50 (and (distinct (bvadd ((_ sign_extend 1) in.114_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.114_32 (_ bv1 32)))) true)))
(let (($x384 (or false false (or $x50))))
(and (not $x384) (or $x384 (and (distinct (bvadd in.114_32 (_ bv1 32)) (bvadd in.114_32 (_ bv1 32))) true))))))
(check-sat)
; query 30: function susan_edges, block 379, name %380
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.015_32 () (_ BitVec 32))
(assert
 (let (($x307 (and (distinct (bvadd ((_ sign_extend 1) in.015_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.015_32 (_ bv1 32)))) true)))
(let (($x99 (or false false (or $x307))))
(and (not $x99) (or $x99 (and (distinct (bvadd in.015_32 (_ bv1 32)) (bvadd in.015_32 (_ bv1 32))) true))))))
(check-sat)
; query 31: function susan_edges, block 382, name %383
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.013_32 () (_ BitVec 32))
(assert
 (let (($x66 (and (distinct (bvadd ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.013_32 (_ bv1 32)))) true)))
(let (($x611 (or false false (or $x66))))
(and (not $x611) (or $x611 (and (distinct (bvadd in.013_32 (_ bv1 32)) (bvadd in.013_32 (_ bv1 32))) true))))))
(check-sat)
; query 32: function susan_edges, block 850, name %851
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in834_32 () (_ BitVec 32))
(assert
 (let ((?x53 (ite (= (_ bv0 32) in834_32) (_ bv1 1) (_ bv0 1))))
(let (($x758 (or false false false)))
(let (($x18 (not $x758)))
(and $x18 (or $x758 (and (distinct ?x53 ?x53) true)))))))
(check-sat)
; query 33: function susan_edges, block 870, name %871
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x242 (ite (bvslt (_ bv0 32) in.0_32) (_ bv1 1) (_ bv0 1))))
(let (($x758 (or false false false)))
(let (($x18 (not $x758)))
(and $x18 (or $x758 (and (distinct ?x242 ?x242) true)))))))
(check-sat)
; query 34: function susan_edges_small, block 119, name %120
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.09_32 () (_ BitVec 32))
(assert
 (let (($x259 (and (distinct (bvadd ((_ sign_extend 1) in.09_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.09_32 (_ bv1 32)))) true)))
(let (($x54 (or false false (or $x259))))
(and (not $x54) (or $x54 (and (distinct (bvadd in.09_32 (_ bv1 32)) (bvadd in.09_32 (_ bv1 32))) true))))))
(check-sat)
; query 35: function susan_edges_small, block 122, name %123
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.07_32 () (_ BitVec 32))
(assert
 (let (($x704 (and (distinct (bvadd ((_ sign_extend 1) in.07_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.07_32 (_ bv1 32)))) true)))
(let (($x67 (or false false (or $x704))))
(and (not $x67) (or $x67 (and (distinct (bvadd in.07_32 (_ bv1 32)) (bvadd in.07_32 (_ bv1 32))) true))))))
(check-sat)
; query 36: function susan_edges_small, block 258, name %259
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in243_32 () (_ BitVec 32))
(assert
 (let ((?x617 (ite (= (_ bv0 32) in243_32) (_ bv1 1) (_ bv0 1))))
(let (($x758 (or false false false)))
(let (($x18 (not $x758)))
(and $x18 (or $x758 (and (distinct ?x617 ?x617) true)))))))
(check-sat)
; query 37: function susan_edges_small, block 278, name %279
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x242 (ite (bvslt (_ bv0 32) in.0_32) (_ bv1 1) (_ bv0 1))))
(let (($x758 (or false false false)))
(let (($x18 (not $x758)))
(and $x18 (or $x758 (and (distinct ?x242 ?x242) true)))))))
(check-sat)
; query 38: function susan_edges_small, block 426, name %427
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in411_32 () (_ BitVec 32))
(assert
 (let ((?x577 (ite (bvslt (_ bv0 32) in411_32) (_ bv1 1) (_ bv0 1))))
(let (($x758 (or false false false)))
(let (($x18 (not $x758)))
(and $x18 (or $x758 (and (distinct ?x577 ?x577) true)))))))
(check-sat)
; query 39: function susan_edges_small, block 458, name %459
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.110_32 () (_ BitVec 32))
(assert
 (let (($x838 (and (distinct (bvadd ((_ sign_extend 1) in.110_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.110_32 (_ bv1 32)))) true)))
(let (($x573 (or false false (or $x838))))
(and (not $x573) (or $x573 (and (distinct (bvadd in.110_32 (_ bv1 32)) (bvadd in.110_32 (_ bv1 32))) true))))))
(check-sat)
; query 40: function susan_edges_small, block 461, name %462
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.18_32 () (_ BitVec 32))
(assert
 (let (($x351 (and (distinct (bvadd ((_ sign_extend 1) in.18_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.18_32 (_ bv1 32)))) true)))
(let (($x284 (or false false (or $x351))))
(and (not $x284) (or $x284 (and (distinct (bvadd in.18_32 (_ bv1 32)) (bvadd in.18_32 (_ bv1 32))) true))))))
(check-sat)
; query 41: function susan_principle, block 378, name %379
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x114 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x662 (or false false (or $x114))))
(and (not $x662) (or $x662 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 42: function susan_principle, block 381, name %382
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x313 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x407 (or false false (or $x313))))
(and (not $x407) (or $x407 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 43: function susan_principle_small, block 118, name %119
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x114 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x662 (or false false (or $x114))))
(and (not $x662) (or $x662 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 44: function susan_principle_small, block 121, name %122
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x313 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x407 (or false false (or $x313))))
(and (not $x407) (or $x407 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 45: function susan_smoothing, block 123, name %124
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.09_32 () (_ BitVec 32))
(assert
 (let (($x681 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in.09_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in.09_32))) true)))
(let (($x553 (or false false (or $x681))))
(and (not $x553) (or $x553 (and (distinct (bvsub (_ bv0 32) in.09_32) (bvsub (_ bv0 32) in.09_32)) true))))))
(check-sat)
; query 46: function susan_smoothing, block 143, name %144
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.016_32 () (_ BitVec 32))
(assert
 (let (($x784 (and (distinct (bvadd ((_ sign_extend 1) in.016_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.016_32 (_ bv1 32)))) true)))
(let (($x438 (or false false (or $x784))))
(and (not $x438) (or $x438 (and (distinct (bvadd in.016_32 (_ bv1 32)) (bvadd in.016_32 (_ bv1 32))) true))))))
(check-sat)
; query 47: function susan_smoothing, block 148, name %149
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.017_32 () (_ BitVec 32))
(assert
 (let (($x592 (and (distinct (bvadd ((_ sign_extend 1) in.017_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.017_32 (_ bv1 32)))) true)))
(let (($x574 (or false false (or $x592))))
(and (not $x574) (or $x574 (and (distinct (bvadd in.017_32 (_ bv1 32)) (bvadd in.017_32 (_ bv1 32))) true))))))
(check-sat)
; query 48: function susan_smoothing, block 165, name %166
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.114_32 () (_ BitVec 32))
(assert
 (let (($x50 (and (distinct (bvadd ((_ sign_extend 1) in.114_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.114_32 (_ bv1 32)))) true)))
(let (($x384 (or false false (or $x50))))
(and (not $x384) (or $x384 (and (distinct (bvadd in.114_32 (_ bv1 32)) (bvadd in.114_32 (_ bv1 32))) true))))))
(check-sat)
; query 49: function susan_smoothing, block 168, name %169
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.111_32 () (_ BitVec 32))
(assert
 (let (($x134 (and (distinct (bvadd ((_ sign_extend 1) in.111_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.111_32 (_ bv1 32)))) true)))
(let (($x688 (or false false (or $x134))))
(and (not $x688) (or $x688 (and (distinct (bvadd in.111_32 (_ bv1 32)) (bvadd in.111_32 (_ bv1 32))) true))))))
(check-sat)
; query 50: function susan_smoothing, block 21, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x214 (ite (= (_ bv0 32) (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x758 (or false false false)))
(let (($x18 (not $x758)))
(and $x18 (or $x758 (and (distinct ?x214 ?x214) true)))))))
(check-sat)
; query 51: function susan_smoothing, block 319, name %320
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.215_32 () (_ BitVec 32))
(assert
 (let (($x240 (and (distinct (bvadd ((_ sign_extend 1) in.215_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.215_32 (_ bv1 32)))) true)))
(let (($x533 (or false false (or $x240))))
(and (not $x533) (or $x533 (and (distinct (bvadd in.215_32 (_ bv1 32)) (bvadd in.215_32 (_ bv1 32))) true))))))
(check-sat)
; query 52: function susan_smoothing, block 322, name %323
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.212_32 () (_ BitVec 32))
(assert
 (let (($x710 (and (distinct (bvadd ((_ sign_extend 1) in.212_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.212_32 (_ bv1 32)))) true)))
(let (($x968 (or false false (or $x710))))
(and (not $x968) (or $x968 (and (distinct (bvadd in.212_32 (_ bv1 32)) (bvadd in.212_32 (_ bv1 32))) true))))))
(check-sat)
; query 53: function susan_smoothing, block 67, name %68
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.09_32 () (_ BitVec 32))
(assert
 (let (($x681 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in.09_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in.09_32))) true)))
(let (($x553 (or false false (or $x681))))
(and (not $x553) (or $x553 (and (distinct (bvsub (_ bv0 32) in.09_32) (bvsub (_ bv0 32) in.09_32)) true))))))
(check-sat)
; query 54: function susan_smoothing, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.013_32 () (_ BitVec 32))
(assert
 (let (($x66 (and (distinct (bvadd ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.013_32 (_ bv1 32)))) true)))
(let (($x611 (or false false (or $x66))))
(and (not $x611) (or $x611 (and (distinct (bvadd in.013_32 (_ bv1 32)) (bvadd in.013_32 (_ bv1 32))) true))))))
(check-sat)
; query 55: function susan_smoothing, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.010_32 () (_ BitVec 32))
(assert
 (let (($x571 (and (distinct (bvadd ((_ sign_extend 1) in.010_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.010_32 (_ bv1 32)))) true)))
(let (($x713 (or false false (or $x571))))
(and (not $x713) (or $x713 (and (distinct (bvadd in.010_32 (_ bv1 32)) (bvadd in.010_32 (_ bv1 32))) true))))))
(check-sat)
; query 56: function susan_thin, block 100, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in93_32 () (_ BitVec 32))
(assert
 (let ((?x769 (ite (= (_ bv1 32) in93_32) (_ bv1 1) (_ bv0 1))))
(let (($x758 (or false false false)))
(let (($x18 (not $x758)))
(and $x18 (or $x758 (and (distinct ?x769 ?x769) true)))))))
(check-sat)
