; OptiPhase-Sigma refinement certificate for sweep K56-R2-076
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x1395 (or false false)))
(let (($x969 (not $x1395)))
(and $x969 (or $x1395 (and (distinct ((_ sign_extend 16) in25_16) ((_ sign_extend 16) in25_16)) true))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let ((?x229 (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1395 (or false false)))
(let (($x274 (or $x1395 false false)))
(let (($x114 (not $x274)))
(and $x114 (or $x274 (and (distinct ?x229 ?x229) true))))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x1395 (or false false)))
(let (($x969 (not $x1395)))
(and $x969 (or $x1395 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x21 ((_ sign_extend 16) in3_16)))
(let ((?x132 (bvand ?x21 (_ bv127 32))))
(let (($x1395 (or false false)))
(let (($x274 (or $x1395 false false)))
(let (($x114 (not $x274)))
(and $x114 (or $x274 (and (distinct ?x132 ?x132) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x21 ((_ sign_extend 16) in3_16)))
(let ((?x132 (bvand ?x21 (_ bv127 32))))
(let ((?x818 ((_ extract 15 0) ?x132)))
(let (($x1395 (or false false)))
(let (($x274 (or $x1395 false false)))
(let (($x79 (or $x274 false)))
(let (($x1060 (not $x79)))
(and $x1060 (or $x79 (and (distinct ?x818 ?x818) true)))))))))))
(check-sat)
; query 5: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x1395 (or false false)))
(let (($x969 (not $x1395)))
(and $x969 (or $x1395 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 6: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x110 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x1395 (or false false)))
(let (($x274 (or $x1395 false false)))
(let (($x114 (not $x274)))
(and $x114 (or $x274 (and (distinct ?x110 ?x110) true))))))))
(check-sat)
; query 7: function core_bench_list, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x796 (or false false false)))
(let (($x317 (not $x796)))
(and $x317 (or $x796 (and (distinct (bvadd in.0_16 (_ bv1 16)) (bvadd in.0_16 (_ bv1 16))) true))))))
(check-sat)
; query 8: function core_bench_state, block 105, name %106
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x796 (or false false false)))
(let (($x317 (not $x796)))
(and $x317 (or $x796 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 9: function core_bench_state, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x796 (or false false false)))
(let (($x317 (not $x796)))
(and $x317 (or $x796 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 10: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x785 (bvadd in.01_32 (_ bv1 32))))
(let (($x25 (and (distinct ?x785 ?x785) true)))
(let (($x796 (or false false false)))
(let (($x317 (not $x796)))
(and $x317 (or $x796 $x25)))))))
(check-sat)
; query 11: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x785 (bvadd in.01_32 (_ bv1 32))))
(let ((?x249 (bvmul ?x785 ?x785)))
(let (($x796 (or false false false)))
(let (($x440 (or $x796 $x796 false)))
(and (not $x440) (or $x440 (and (distinct ?x249 ?x249) true))))))))
(check-sat)
; query 12: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x785 (bvadd in.01_32 (_ bv1 32))))
(let ((?x249 (bvmul ?x785 ?x785)))
(let ((?x58 (bvmul ?x249 (_ bv2 32))))
(let (($x796 (or false false false)))
(let (($x440 (or $x796 $x796 false)))
(let (($x238 (or $x440 false false)))
(and (not $x238) (or $x238 (and (distinct ?x58 ?x58) true))))))))))
(check-sat)
; query 13: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x785 (bvadd in.01_32 (_ bv1 32))))
(let ((?x249 (bvmul ?x785 ?x785)))
(let ((?x58 (bvmul ?x249 (_ bv2 32))))
(let ((?x122 (bvmul ?x58 (_ bv4 32))))
(let (($x796 (or false false false)))
(let (($x440 (or $x796 $x796 false)))
(let (($x238 (or $x440 false false)))
(let (($x52 (or $x238 false false)))
(and (not $x52) (or $x52 (and (distinct ?x122 ?x122) true))))))))))))
(check-sat)
; query 14: function core_init_matrix, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x796 (or false false false)))
(let (($x317 (not $x796)))
(and $x317 (or $x796 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 15: function core_init_matrix, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x796 (or false false false)))
(let (($x317 (not $x796)))
(and $x317 (or $x796 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 16: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x1497 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x796 (or false false false)))
(let (($x317 (not $x796)))
(and $x317 (or $x796 (and (distinct ?x1497 ?x1497) true)))))))
(check-sat)
; query 17: function core_init_state, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_32 () (_ BitVec 32))
(assert
 (let (($x796 (or false false false)))
(let (($x317 (not $x796)))
(and $x317 (or $x796 (and (distinct (bvadd in.06_32 (_ bv1 32)) (bvadd in.06_32 (_ bv1 32))) true))))))
(check-sat)
; query 18: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x764 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x796 (or false false false)))
(let (($x317 (not $x796)))
(and $x317 (or $x796 (and (distinct ?x764 ?x764) true)))))))
(check-sat)
; query 19: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x796 (or false false false)))
(let (($x317 (not $x796)))
(and $x317 (or $x796 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 20: function core_list_init, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x785 (bvadd in.01_32 (_ bv1 32))))
(let (($x25 (and (distinct ?x785 ?x785) true)))
(let (($x796 (or false false false)))
(let (($x317 (not $x796)))
(and $x317 (or $x796 $x25)))))))
(check-sat)
; query 21: function core_list_mergesort, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x785 (bvadd in.01_32 (_ bv1 32))))
(let (($x25 (and (distinct ?x785 ?x785) true)))
(let (($x131 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x785)) true)))
(let (($x1078 (or false false (or $x131))))
(and (not $x1078) (or $x1078 $x25)))))))
(check-sat)
; query 22: function core_list_mergesort, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x602 (ite (bvslt (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x796 (or false false false)))
(let (($x317 (not $x796)))
(and $x317 (or $x796 (and (distinct ?x602 ?x602) true)))))))
(check-sat)
; query 23: function core_list_mergesort, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.224_32 () (_ BitVec 32))
(assert
 (let ((?x121 (ite (= (_ bv0 32) in.224_32) (_ bv1 1) (_ bv0 1))))
(let (($x796 (or false false false)))
(let (($x317 (not $x796)))
(and $x317 (or $x796 (and (distinct ?x121 ?x121) true)))))))
(check-sat)
; query 24: function core_list_mergesort, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x48 (ite (= (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x796 (or false false false)))
(let (($x317 (not $x796)))
(and $x317 (or $x796 (and (distinct ?x48 ?x48) true)))))))
(check-sat)
; query 25: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x655 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x152 (or false false (or $x655))))
(and (not $x152) (or $x152 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 26: function core_list_mergesort, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x82 (and (distinct (bvmul ((_ sign_extend 32) in.020_32) ((_ sign_extend 32) (_ bv2 32))) ((_ sign_extend 32) (bvmul in.020_32 (_ bv2 32)))) true)))
(let (($x163 (or false false (or $x82))))
(and (not $x163) (or $x163 (and (distinct (bvmul in.020_32 (_ bv2 32)) (bvmul in.020_32 (_ bv2 32))) true))))))
(check-sat)
; query 27: function core_state_transition, block 102, name %103
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1395 (or false false)))
(let (($x969 (not $x1395)))
(and $x969 (or $x1395 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 28: function core_state_transition, block 102, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x20 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1395 (or false false)))
(let (($x274 (or $x1395 false false)))
(let (($x114 (not $x274)))
(and $x114 (or $x274 (and (distinct ?x20 ?x20) true))))))))
(check-sat)
; query 29: function core_state_transition, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1395 (or false false)))
(let (($x969 (not $x1395)))
(and $x969 (or $x1395 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 30: function core_state_transition, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x187 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1395 (or false false)))
(let (($x274 (or $x1395 false false)))
(let (($x114 (not $x274)))
(and $x114 (or $x274 (and (distinct ?x187 ?x187) true))))))))
(check-sat)
; query 31: function core_state_transition, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1395 (or false false)))
(let (($x969 (not $x1395)))
(and $x969 (or $x1395 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 32: function core_state_transition, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x20 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1395 (or false false)))
(let (($x274 (or $x1395 false false)))
(let (($x114 (not $x274)))
(and $x114 (or $x274 (and (distinct ?x20 ?x20) true))))))))
(check-sat)
; query 33: function core_state_transition, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1395 (or false false)))
(let (($x969 (not $x1395)))
(and $x969 (or $x1395 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 34: function core_state_transition, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x241 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1395 (or false false)))
(let (($x274 (or $x1395 false false)))
(let (($x114 (not $x274)))
(and $x114 (or $x274 (and (distinct ?x241 ?x241) true))))))))
(check-sat)
; query 35: function core_state_transition, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1395 (or false false)))
(let (($x969 (not $x1395)))
(and $x969 (or $x1395 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 36: function core_state_transition, block 51, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x241 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1395 (or false false)))
(let (($x274 (or $x1395 false false)))
(let (($x114 (not $x274)))
(and $x114 (or $x274 (and (distinct ?x241 ?x241) true))))))))
(check-sat)
; query 37: function core_state_transition, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1395 (or false false)))
(let (($x969 (not $x1395)))
(and $x969 (or $x1395 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 38: function core_state_transition, block 64, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x241 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1395 (or false false)))
(let (($x274 (or $x1395 false false)))
(let (($x114 (not $x274)))
(and $x114 (or $x274 (and (distinct ?x241 ?x241) true))))))))
(check-sat)
; query 39: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x1355 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x796 (or false false false)))
(let (($x317 (not $x796)))
(and $x317 (or $x796 (and (distinct ?x1355 ?x1355) true)))))))
(check-sat)
; query 40: function core_state_transition, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1395 (or false false)))
(let (($x969 (not $x1395)))
(and $x969 (or $x1395 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 41: function core_state_transition, block 80, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1328 (ite (= (_ bv69 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1395 (or false false)))
(let (($x274 (or $x1395 false false)))
(let (($x114 (not $x274)))
(and $x114 (or $x274 (and (distinct ?x1328 ?x1328) true))))))))
(check-sat)
; query 42: function core_state_transition, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1395 (or false false)))
(let (($x969 (not $x1395)))
(and $x969 (or $x1395 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 43: function core_state_transition, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1410 (ite (= (_ bv101 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1395 (or false false)))
(let (($x274 (or $x1395 false false)))
(let (($x114 (not $x274)))
(and $x114 (or $x274 (and (distinct ?x1410 ?x1410) true))))))))
(check-sat)
; query 44: function core_state_transition, block 99, name %100
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1395 (or false false)))
(let (($x969 (not $x1395)))
(and $x969 (or $x1395 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 45: function core_state_transition, block 99, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x187 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1395 (or false false)))
(let (($x274 (or $x1395 false false)))
(let (($x114 (not $x274)))
(and $x114 (or $x274 (and (distinct ?x187 ?x187) true))))))))
(check-sat)
; query 46: function crcu8, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x1395 (or false false)))
(let (($x969 (not $x1395)))
(and $x969 (or $x1395 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 47: function crcu8, block 19, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x1364 ((_ zero_extend 16) in.01_16)))
(let ((?x672 (bvxor ?x1364 (_ bv16386 32))))
(let (($x1395 (or false false)))
(let (($x274 (or $x1395 false false)))
(let (($x114 (not $x274)))
(and $x114 (or $x274 (and (distinct ?x672 ?x672) true)))))))))
(check-sat)
; query 48: function crcu8, block 19, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x1364 ((_ zero_extend 16) in.01_16)))
(let ((?x672 (bvxor ?x1364 (_ bv16386 32))))
(let ((?x1539 ((_ extract 15 0) ?x672)))
(let (($x1395 (or false false)))
(let (($x274 (or $x1395 false false)))
(let (($x79 (or $x274 false)))
(let (($x1060 (not $x79)))
(and $x1060 (or $x79 (and (distinct ?x1539 ?x1539) true)))))))))))
(check-sat)
; query 49: function crcu8, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x1395 (or false false)))
(let (($x969 (not $x1395)))
(and $x969 (or $x1395 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 50: function crcu8, block 29, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1555 ((_ zero_extend 16) in27_16)))
(let ((?x1312 (bvor ?x1555 (_ bv32768 32))))
(let (($x1395 (or false false)))
(let (($x274 (or $x1395 false false)))
(let (($x114 (not $x274)))
(and $x114 (or $x274 (and (distinct ?x1312 ?x1312) true)))))))))
(check-sat)
; query 51: function crcu8, block 29, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1555 ((_ zero_extend 16) in27_16)))
(let ((?x1312 (bvor ?x1555 (_ bv32768 32))))
(let ((?x1091 ((_ extract 15 0) ?x1312)))
(let (($x1395 (or false false)))
(let (($x274 (or $x1395 false false)))
(let (($x79 (or $x274 false)))
(let (($x1060 (not $x79)))
(and $x1060 (or $x79 (and (distinct ?x1091 ?x1091) true)))))))))))
(check-sat)
; query 52: function crcu8, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x1395 (or false false)))
(let (($x969 (not $x1395)))
(and $x969 (or $x1395 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 53: function crcu8, block 33, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1555 ((_ zero_extend 16) in27_16)))
(let ((?x815 (bvand ?x1555 (_ bv32767 32))))
(let (($x1395 (or false false)))
(let (($x274 (or $x1395 false false)))
(let (($x114 (not $x274)))
(and $x114 (or $x274 (and (distinct ?x815 ?x815) true)))))))))
(check-sat)
; query 54: function crcu8, block 33, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1555 ((_ zero_extend 16) in27_16)))
(let ((?x815 (bvand ?x1555 (_ bv32767 32))))
(let ((?x1099 ((_ extract 15 0) ?x815)))
(let (($x1395 (or false false)))
(let (($x274 (or $x1395 false false)))
(let (($x79 (or $x274 false)))
(let (($x1060 (not $x79)))
(and $x1060 (or $x79 (and (distinct ?x1099 ?x1099) true)))))))))))
(check-sat)
; query 55: function crcu8, block 38, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_8 () (_ BitVec 8))
(assert
 (let (($x796 (or false false false)))
(let (($x317 (not $x796)))
(and $x317 (or $x796 (and (distinct (bvadd in.02_8 (_ bv1 8)) (bvadd in.02_8 (_ bv1 8))) true))))))
(check-sat)
; query 56: function crcu8, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x831 ((_ extract 7 0) in.01_16)))
(let ((?x535 ((_ zero_extend 24) ?x831)))
(let (($x1395 (or false false)))
(let (($x423 (or $x1395 false)))
(and (not $x423) (or $x423 (and (distinct ?x535 ?x535) true))))))))
(check-sat)
; query 57: function crcu8, block 6, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x831 ((_ extract 7 0) in.01_16)))
(let ((?x535 ((_ zero_extend 24) ?x831)))
(let ((?x1396 (bvand ?x535 (_ bv1 32))))
(let (($x1395 (or false false)))
(let (($x423 (or $x1395 false)))
(let (($x1006 (or $x423 false false)))
(and (not $x1006) (or $x1006 (and (distinct ?x1396 ?x1396) true))))))))))
(check-sat)
; query 58: function crcu8, block 6, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x831 ((_ extract 7 0) in.01_16)))
(let ((?x535 ((_ zero_extend 24) ?x831)))
(let ((?x1396 (bvand ?x535 (_ bv1 32))))
(let ((?x330 ((_ zero_extend 24) in.0_8)))
(let ((?x193 (bvand ?x330 (_ bv1 32))))
(let ((?x1361 (bvxor ?x193 ?x1396)))
(let (($x1395 (or false false)))
(let (($x423 (or $x1395 false)))
(let (($x1006 (or $x423 false false)))
(let (($x274 (or $x1395 false false)))
(let (($x55 (or $x274 $x1006 false)))
(and (not $x55) (or $x55 (and (distinct ?x1361 ?x1361) true)))))))))))))))
(check-sat)
; query 59: function crcu8, block 6, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x831 ((_ extract 7 0) in.01_16)))
(let ((?x535 ((_ zero_extend 24) ?x831)))
(let ((?x1396 (bvand ?x535 (_ bv1 32))))
(let ((?x330 ((_ zero_extend 24) in.0_8)))
(let ((?x193 (bvand ?x330 (_ bv1 32))))
(let ((?x1361 (bvxor ?x193 ?x1396)))
(let ((?x1128 ((_ extract 7 0) ?x1361)))
(let (($x1395 (or false false)))
(let (($x423 (or $x1395 false)))
(let (($x1006 (or $x423 false false)))
(let (($x274 (or $x1395 false false)))
(let (($x55 (or $x274 $x1006 false)))
(let (($x202 (or $x55 false)))
(and (not $x202) (or $x202 (and (distinct ?x1128 ?x1128) true)))))))))))))))))
(check-sat)
; query 60: function crcu8, block 6, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x1395 (or false false)))
(let (($x969 (not $x1395)))
(and $x969 (or $x1395 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 61: function crcu8, block 6, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x330 ((_ zero_extend 24) in.0_8)))
(let ((?x480 (bvashr ?x330 (_ bv1 32))))
(let (($x1395 (or false false)))
(let (($x274 (or $x1395 false false)))
(let (($x500 (or $x274 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not $x500) (or $x500 (and (distinct ?x480 ?x480) true)))))))))
(check-sat)
; query 62: function crcu8, block 6, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x330 ((_ zero_extend 24) in.0_8)))
(let ((?x480 (bvashr ?x330 (_ bv1 32))))
(let ((?x1362 ((_ extract 7 0) ?x480)))
(let (($x1395 (or false false)))
(let (($x274 (or $x1395 false false)))
(let (($x500 (or $x274 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x309 (or $x500 false)))
(and (not $x309) (or $x309 (and (distinct ?x1362 ?x1362) true)))))))))))
(check-sat)
; query 63: function crcu8, block 6, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x831 ((_ extract 7 0) in.01_16)))
(let ((?x535 ((_ zero_extend 24) ?x831)))
(let ((?x1396 (bvand ?x535 (_ bv1 32))))
(let ((?x330 ((_ zero_extend 24) in.0_8)))
(let ((?x193 (bvand ?x330 (_ bv1 32))))
(let ((?x1361 (bvxor ?x193 ?x1396)))
(let ((?x1128 ((_ extract 7 0) ?x1361)))
(let ((?x1363 ((_ zero_extend 24) ?x1128)))
(let (($x1395 (or false false)))
(let (($x423 (or $x1395 false)))
(let (($x1006 (or $x423 false false)))
(let (($x274 (or $x1395 false false)))
(let (($x55 (or $x274 $x1006 false)))
(let (($x202 (or $x55 false)))
(let (($x141 (or $x202 false)))
(and (not $x141) (or $x141 (and (distinct ?x1363 ?x1363) true)))))))))))))))))))
(check-sat)
; query 64: function crcu8, block 6, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x831 ((_ extract 7 0) in.01_16)))
(let ((?x535 ((_ zero_extend 24) ?x831)))
(let ((?x1396 (bvand ?x535 (_ bv1 32))))
(let ((?x330 ((_ zero_extend 24) in.0_8)))
(let ((?x193 (bvand ?x330 (_ bv1 32))))
(let ((?x1361 (bvxor ?x193 ?x1396)))
(let ((?x1128 ((_ extract 7 0) ?x1361)))
(let ((?x1363 ((_ zero_extend 24) ?x1128)))
(let ((?x354 (ite (= (_ bv1 32) ?x1363) (_ bv1 1) (_ bv0 1))))
(let (($x1395 (or false false)))
(let (($x423 (or $x1395 false)))
(let (($x1006 (or $x423 false false)))
(let (($x274 (or $x1395 false false)))
(let (($x55 (or $x274 $x1006 false)))
(let (($x202 (or $x55 false)))
(let (($x141 (or $x202 false)))
(let (($x958 (or $x141 false false)))
(and (not $x958) (or $x958 (and (distinct ?x354 ?x354) true)))))))))))))))))))))
(check-sat)
; query 65: function crcu8, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x1395 (or false false)))
(let (($x969 (not $x1395)))
(and $x969 (or $x1395 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 66: function crcu8, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x330 ((_ zero_extend 24) in.0_8)))
(let ((?x193 (bvand ?x330 (_ bv1 32))))
(let (($x1395 (or false false)))
(let (($x274 (or $x1395 false false)))
(let (($x114 (not $x274)))
(and $x114 (or $x274 (and (distinct ?x193 ?x193) true)))))))))
(check-sat)
; query 67: function crcu8, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x1395 (or false false)))
(let (($x969 (not $x1395)))
(and $x969 (or $x1395 (and (distinct ((_ extract 7 0) in.01_16) ((_ extract 7 0) in.01_16)) true))))))
(check-sat)
; query 68: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x484 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x809 ((_ zero_extend 31) ?x484)))
(let ((?x555 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x508 ((_ zero_extend 31) ?x555)))
(let ((?x603 (bvand ?x508 ?x809)))
(let ((?x1502 (ite (and (distinct (_ bv0 32) ?x603) true) (_ bv1 1) (_ bv0 1))))
(let ((?x600 ((_ zero_extend 63) ?x1502)))
(let (($x1395 (or false false)))
(let (($x274 (or $x1395 false false)))
(let (($x79 (or $x274 false)))
(let (($x846 (or $x79 $x79 false)))
(let (($x1573 (or $x846 false false)))
(let (($x810 (or $x1573 false)))
(and (not $x810) (or $x810 (and (distinct ?x600 ?x600) true)))))))))))))))))
(check-sat)
; query 69: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x484 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x809 ((_ zero_extend 31) ?x484)))
(let ((?x555 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x508 ((_ zero_extend 31) ?x555)))
(let ((?x603 (bvand ?x508 ?x809)))
(let ((?x1502 (ite (and (distinct (_ bv0 32) ?x603) true) (_ bv1 1) (_ bv0 1))))
(let (($x832 (= (_ bv1 1) ?x1502)))
(let ((?x965 (ite $x832 (_ bv1 32) (_ bv0 32))))
(let (($x1395 (or false false)))
(let (($x274 (or $x1395 false false)))
(let (($x79 (or $x274 false)))
(let (($x846 (or $x79 $x79 false)))
(let (($x1573 (or $x846 false false)))
(let (($x1017 (or $x1573 (ite $x832 false false))))
(and (not $x1017) (or $x1017 (and (distinct ?x965 ?x965) true))))))))))))))))))
(check-sat)
; query 70: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x484 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x809 ((_ zero_extend 31) ?x484)))
(let ((?x555 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x508 ((_ zero_extend 31) ?x555)))
(let ((?x603 (bvand ?x508 ?x809)))
(let ((?x1502 (ite (and (distinct (_ bv0 32) ?x603) true) (_ bv1 1) (_ bv0 1))))
(let (($x832 (= (_ bv1 1) ?x1502)))
(let ((?x965 (ite $x832 (_ bv1 32) (_ bv0 32))))
(let ((?x424 ((_ extract 7 0) ?x965)))
(let (($x1395 (or false false)))
(let (($x274 (or $x1395 false false)))
(let (($x79 (or $x274 false)))
(let (($x846 (or $x79 $x79 false)))
(let (($x1573 (or $x846 false false)))
(let (($x1017 (or $x1573 (ite $x832 false false))))
(let (($x781 (or $x1017 false)))
(and (not $x781) (or $x781 (and (distinct ?x424 ?x424) true))))))))))))))))))))
(check-sat)
; query 71: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x1395 (or false false)))
(let (($x969 (not $x1395)))
(and $x969 (or $x1395 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 72: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x555 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1395 (or false false)))
(let (($x274 (or $x1395 false false)))
(let (($x114 (not $x274)))
(and $x114 (or $x274 (and (distinct ?x555 ?x555) true))))))))
(check-sat)
; query 73: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x555 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x508 ((_ zero_extend 31) ?x555)))
(let (($x1395 (or false false)))
(let (($x274 (or $x1395 false false)))
(let (($x79 (or $x274 false)))
(let (($x1060 (not $x79)))
(and $x1060 (or $x79 (and (distinct ?x508 ?x508) true))))))))))
(check-sat)
; query 74: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x1395 (or false false)))
(let (($x969 (not $x1395)))
(and $x969 (or $x1395 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 75: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x484 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1395 (or false false)))
(let (($x274 (or $x1395 false false)))
(let (($x114 (not $x274)))
(and $x114 (or $x274 (and (distinct ?x484 ?x484) true))))))))
(check-sat)
; query 76: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x484 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x809 ((_ zero_extend 31) ?x484)))
(let (($x1395 (or false false)))
(let (($x274 (or $x1395 false false)))
(let (($x79 (or $x274 false)))
(let (($x1060 (not $x79)))
(and $x1060 (or $x79 (and (distinct ?x809 ?x809) true))))))))))
(check-sat)
; query 77: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x484 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x809 ((_ zero_extend 31) ?x484)))
(let ((?x555 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x508 ((_ zero_extend 31) ?x555)))
(let ((?x603 (bvand ?x508 ?x809)))
(let (($x1395 (or false false)))
(let (($x274 (or $x1395 false false)))
(let (($x79 (or $x274 false)))
(let (($x846 (or $x79 $x79 false)))
(and (not $x846) (or $x846 (and (distinct ?x603 ?x603) true)))))))))))))
(check-sat)
; query 78: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x484 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x809 ((_ zero_extend 31) ?x484)))
(let ((?x555 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x508 ((_ zero_extend 31) ?x555)))
(let ((?x603 (bvand ?x508 ?x809)))
(let ((?x1502 (ite (and (distinct (_ bv0 32) ?x603) true) (_ bv1 1) (_ bv0 1))))
(let (($x1395 (or false false)))
(let (($x274 (or $x1395 false false)))
(let (($x79 (or $x274 false)))
(let (($x846 (or $x79 $x79 false)))
(let (($x1573 (or $x846 false false)))
(and (not $x1573) (or $x1573 (and (distinct ?x1502 ?x1502) true)))))))))))))))
(check-sat)
; query 79: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1081 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x796 (or false false false)))
(let (($x317 (not $x796)))
(and $x317 (or $x796 (and (distinct ?x1081 ?x1081) true)))))))
(check-sat)
; query 80: function matrix_add_const, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x796 (or false false false)))
(let (($x317 (not $x796)))
(and $x317 (or $x796 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 81: function matrix_add_const, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x785 (bvadd in.01_32 (_ bv1 32))))
(let (($x25 (and (distinct ?x785 ?x785) true)))
(let (($x796 (or false false false)))
(let (($x317 (not $x796)))
(and $x317 (or $x796 $x25)))))))
(check-sat)
; query 82: function matrix_mul_const, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x796 (or false false false)))
(let (($x317 (not $x796)))
(and $x317 (or $x796 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 83: function matrix_mul_const, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x785 (bvadd in.01_32 (_ bv1 32))))
(let (($x25 (and (distinct ?x785 ?x785) true)))
(let (($x796 (or false false false)))
(let (($x317 (not $x796)))
(and $x317 (or $x796 $x25)))))))
(check-sat)
; query 84: function matrix_mul_matrix, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x796 (or false false false)))
(let (($x317 (not $x796)))
(and $x317 (or $x796 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 85: function matrix_mul_matrix, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x785 (bvadd in.01_32 (_ bv1 32))))
(let (($x25 (and (distinct ?x785 ?x785) true)))
(let (($x796 (or false false false)))
(let (($x317 (not $x796)))
(and $x317 (or $x796 $x25)))))))
(check-sat)
; query 86: function matrix_mul_matrix, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x796 (or false false false)))
(let (($x317 (not $x796)))
(and $x317 (or $x796 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 87: function matrix_mul_matrix_bitextract, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x796 (or false false false)))
(let (($x317 (not $x796)))
(and $x317 (or $x796 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 88: function matrix_mul_matrix_bitextract, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x785 (bvadd in.01_32 (_ bv1 32))))
(let (($x25 (and (distinct ?x785 ?x785) true)))
(let (($x796 (or false false false)))
(let (($x317 (not $x796)))
(and $x317 (or $x796 $x25)))))))
(check-sat)
; query 89: function matrix_mul_matrix_bitextract, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x796 (or false false false)))
(let (($x317 (not $x796)))
(and $x317 (or $x796 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 90: function matrix_mul_vect, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x796 (or false false false)))
(let (($x317 (not $x796)))
(and $x317 (or $x796 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 91: function matrix_mul_vect, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x785 (bvadd in.01_32 (_ bv1 32))))
(let (($x25 (and (distinct ?x785 ?x785) true)))
(let (($x796 (or false false false)))
(let (($x317 (not $x796)))
(and $x317 (or $x796 $x25)))))))
(check-sat)
; query 92: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x1395 (or false false)))
(let (($x969 (not $x1395)))
(and $x969 (or $x1395 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 93: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x462 ((_ sign_extend 16) in.1_16)))
(let ((?x577 (bvadd ?x462 (_ bv10 32))))
(let (($x897 (and (distinct (bvadd ((_ sign_extend 1) ?x462) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x577)) true)))
(let (($x1395 (or false false)))
(let (($x650 (or $x1395 false (or $x897))))
(and (not $x650) (or $x650 (and (distinct ?x577 ?x577) true)))))))))
(check-sat)
; query 94: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x462 ((_ sign_extend 16) in.1_16)))
(let ((?x577 (bvadd ?x462 (_ bv10 32))))
(let ((?x189 ((_ extract 15 0) ?x577)))
(let (($x897 (and (distinct (bvadd ((_ sign_extend 1) ?x462) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x577)) true)))
(let (($x1395 (or false false)))
(let (($x650 (or $x1395 false (or $x897))))
(let (($x120 (or $x650 false)))
(and (not $x120) (or $x120 (and (distinct ?x189 ?x189) true)))))))))))
(check-sat)
; query 95: function matrix_sum, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x470 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x796 (or false false false)))
(let (($x317 (not $x796)))
(and $x317 (or $x796 (and (distinct ?x470 ?x470) true)))))))
(check-sat)
; query 96: function matrix_sum, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x470 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let ((?x690 ((_ zero_extend 63) ?x470)))
(let (($x796 (or false false false)))
(let (($x1049 (or $x796 false)))
(and (not $x1049) (or $x1049 (and (distinct ?x690 ?x690) true))))))))
(check-sat)
; query 97: function matrix_sum, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x470 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x335 (= (_ bv1 1) ?x470)))
(let ((?x825 (ite $x335 (_ bv1 32) (_ bv0 32))))
(let (($x796 (or false false false)))
(let (($x786 (or $x796 (ite $x335 false false))))
(and (not $x786) (or $x786 (and (distinct ?x825 ?x825) true)))))))))
(check-sat)
; query 98: function matrix_sum, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x1395 (or false false)))
(let (($x969 (not $x1395)))
(and $x969 (or $x1395 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 99: function matrix_sum, block 22, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x470 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x335 (= (_ bv1 1) ?x470)))
(let ((?x825 (ite $x335 (_ bv1 32) (_ bv0 32))))
(let ((?x462 ((_ sign_extend 16) in.1_16)))
(let ((?x1560 (bvadd ?x462 ?x825)))
(let (($x1581 (and (distinct (bvadd ((_ sign_extend 1) ?x462) ((_ sign_extend 1) ?x825)) ((_ sign_extend 1) ?x1560)) true)))
(let (($x796 (or false false false)))
(let (($x786 (or $x796 (ite $x335 false false))))
(let (($x1395 (or false false)))
(let (($x211 (or $x1395 $x786 (or $x1581))))
(and (not $x211) (or $x211 (and (distinct ?x1560 ?x1560) true))))))))))))))
(check-sat)
; query 100: function matrix_sum, block 22, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x470 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x335 (= (_ bv1 1) ?x470)))
(let ((?x825 (ite $x335 (_ bv1 32) (_ bv0 32))))
(let ((?x462 ((_ sign_extend 16) in.1_16)))
(let ((?x1560 (bvadd ?x462 ?x825)))
(let ((?x1548 ((_ extract 15 0) ?x1560)))
(let (($x1581 (and (distinct (bvadd ((_ sign_extend 1) ?x462) ((_ sign_extend 1) ?x825)) ((_ sign_extend 1) ?x1560)) true)))
(let (($x796 (or false false false)))
(let (($x786 (or $x796 (ite $x335 false false))))
(let (($x1395 (or false false)))
(let (($x211 (or $x1395 $x786 (or $x1581))))
(let (($x245 (or $x211 false)))
(and (not $x245) (or $x245 (and (distinct ?x1548 ?x1548) true))))))))))))))))
(check-sat)
; query 101: function matrix_sum, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x796 (or false false false)))
(let (($x317 (not $x796)))
(and $x317 (or $x796 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 102: function matrix_sum, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x785 (bvadd in.01_32 (_ bv1 32))))
(let (($x25 (and (distinct ?x785 ?x785) true)))
(let (($x796 (or false false false)))
(let (($x317 (not $x796)))
(and $x317 (or $x796 $x25)))))))
(check-sat)
; query 103: function parseval, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.23_32 () (_ BitVec 32))
(assert
 (let (($x632 (and (distinct (bvmul ((_ sign_extend 32) in.23_32) ((_ sign_extend 32) (_ bv1024 32))) ((_ sign_extend 32) (bvmul in.23_32 (_ bv1024 32)))) true)))
(let (($x438 (or false false (or $x632))))
(and (not $x438) (or $x438 (and (distinct (bvmul in.23_32 (_ bv1024 32)) (bvmul in.23_32 (_ bv1024 32))) true))))))
(check-sat)
; query 104: function parseval, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.34_32 () (_ BitVec 32))
(assert
 (let (($x1074 (and (distinct (bvmul ((_ sign_extend 32) in.34_32) ((_ sign_extend 32) (_ bv1048576 32))) ((_ sign_extend 32) (bvmul in.34_32 (_ bv1048576 32)))) true)))
(let (($x1005 (or false false (or $x1074))))
(and (not $x1005) (or $x1005 (and (distinct (bvmul in.34_32 (_ bv1048576 32)) (bvmul in.34_32 (_ bv1048576 32))) true))))))
(check-sat)
; query 105: function partition_memory, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x796 (or false false false)))
(let (($x317 (not $x796)))
(and $x317 (or $x796 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
