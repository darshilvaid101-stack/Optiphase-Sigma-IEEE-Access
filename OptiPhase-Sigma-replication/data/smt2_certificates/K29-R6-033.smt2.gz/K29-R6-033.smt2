; OptiPhase-Sigma refinement certificate for sweep K29-R6-033
