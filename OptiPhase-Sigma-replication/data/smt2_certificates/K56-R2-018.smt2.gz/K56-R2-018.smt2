; OptiPhase-Sigma refinement certificate for sweep K56-R2-018
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x354 (or false false)))
(let (($x135 (not $x354)))
(and $x135 (or $x354 (and (distinct ((_ sign_extend 16) in25_16) ((_ sign_extend 16) in25_16)) true))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let ((?x234 (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))))
(let (($x354 (or false false)))
(let (($x207 (or $x354 false false)))
(let (($x337 (not $x207)))
(and $x337 (or $x207 (and (distinct ?x234 ?x234) true))))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x354 (or false false)))
(let (($x135 (not $x354)))
(and $x135 (or $x354 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x171 ((_ sign_extend 16) in3_16)))
(let ((?x538 (bvand ?x171 (_ bv127 32))))
(let (($x354 (or false false)))
(let (($x207 (or $x354 false false)))
(let (($x337 (not $x207)))
(and $x337 (or $x207 (and (distinct ?x538 ?x538) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x171 ((_ sign_extend 16) in3_16)))
(let ((?x538 (bvand ?x171 (_ bv127 32))))
(let ((?x86 ((_ extract 15 0) ?x538)))
(let (($x354 (or false false)))
(let (($x207 (or $x354 false false)))
(let (($x844 (or $x207 false)))
(let (($x710 (not $x844)))
(and $x710 (or $x844 (and (distinct ?x86 ?x86) true)))))))))))
(check-sat)
; query 5: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x354 (or false false)))
(let (($x135 (not $x354)))
(and $x135 (or $x354 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 6: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x809 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x354 (or false false)))
(let (($x207 (or $x354 false false)))
(let (($x337 (not $x207)))
(and $x337 (or $x207 (and (distinct ?x809 ?x809) true))))))))
(check-sat)
; query 7: function core_bench_list, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x98 (or false false false)))
(let (($x57 (not $x98)))
(and $x57 (or $x98 (and (distinct (bvadd in.0_16 (_ bv1 16)) (bvadd in.0_16 (_ bv1 16))) true))))))
(check-sat)
; query 8: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x696 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x98 (or false false false)))
(let (($x57 (not $x98)))
(and $x57 (or $x98 (and (distinct ?x696 ?x696) true)))))))
(check-sat)
; query 9: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x488 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x98 (or false false false)))
(let (($x57 (not $x98)))
(and $x57 (or $x98 (and (distinct ?x488 ?x488) true)))))))
(check-sat)
; query 10: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x98 (or false false false)))
(let (($x57 (not $x98)))
(and $x57 (or $x98 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 11: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x590 (and (distinct (bvadd ((_ zero_extend 1) in.021_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x266 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x369 (or (or false false (or $x266 $x590)) (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))
(and (not (or false false (or $x266))) $x369)))))
(check-sat)
; query 12: function core_state_transition, block 102, name %103
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x354 (or false false)))
(let (($x135 (not $x354)))
(and $x135 (or $x354 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 13: function core_state_transition, block 102, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x274 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x354 (or false false)))
(let (($x207 (or $x354 false false)))
(let (($x337 (not $x207)))
(and $x337 (or $x207 (and (distinct ?x274 ?x274) true))))))))
(check-sat)
; query 14: function core_state_transition, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x354 (or false false)))
(let (($x135 (not $x354)))
(and $x135 (or $x354 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 15: function core_state_transition, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x90 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x354 (or false false)))
(let (($x207 (or $x354 false false)))
(let (($x337 (not $x207)))
(and $x337 (or $x207 (and (distinct ?x90 ?x90) true))))))))
(check-sat)
; query 16: function core_state_transition, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x354 (or false false)))
(let (($x135 (not $x354)))
(and $x135 (or $x354 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 17: function core_state_transition, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x274 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x354 (or false false)))
(let (($x207 (or $x354 false false)))
(let (($x337 (not $x207)))
(and $x337 (or $x207 (and (distinct ?x274 ?x274) true))))))))
(check-sat)
; query 18: function core_state_transition, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x354 (or false false)))
(let (($x135 (not $x354)))
(and $x135 (or $x354 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 19: function core_state_transition, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x12 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x354 (or false false)))
(let (($x207 (or $x354 false false)))
(let (($x337 (not $x207)))
(and $x337 (or $x207 (and (distinct ?x12 ?x12) true))))))))
(check-sat)
; query 20: function core_state_transition, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x354 (or false false)))
(let (($x135 (not $x354)))
(and $x135 (or $x354 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 21: function core_state_transition, block 51, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x12 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x354 (or false false)))
(let (($x207 (or $x354 false false)))
(let (($x337 (not $x207)))
(and $x337 (or $x207 (and (distinct ?x12 ?x12) true))))))))
(check-sat)
; query 22: function core_state_transition, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x354 (or false false)))
(let (($x135 (not $x354)))
(and $x135 (or $x354 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 23: function core_state_transition, block 64, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x12 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x354 (or false false)))
(let (($x207 (or $x354 false false)))
(let (($x337 (not $x207)))
(and $x337 (or $x207 (and (distinct ?x12 ?x12) true))))))))
(check-sat)
; query 24: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x42 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x98 (or false false false)))
(let (($x57 (not $x98)))
(and $x57 (or $x98 (and (distinct ?x42 ?x42) true)))))))
(check-sat)
; query 25: function core_state_transition, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x354 (or false false)))
(let (($x135 (not $x354)))
(and $x135 (or $x354 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 26: function core_state_transition, block 80, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x62 (ite (= (_ bv69 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x354 (or false false)))
(let (($x207 (or $x354 false false)))
(let (($x337 (not $x207)))
(and $x337 (or $x207 (and (distinct ?x62 ?x62) true))))))))
(check-sat)
; query 27: function core_state_transition, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x354 (or false false)))
(let (($x135 (not $x354)))
(and $x135 (or $x354 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 28: function core_state_transition, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x92 (ite (= (_ bv101 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x354 (or false false)))
(let (($x207 (or $x354 false false)))
(let (($x337 (not $x207)))
(and $x337 (or $x207 (and (distinct ?x92 ?x92) true))))))))
(check-sat)
; query 29: function core_state_transition, block 99, name %100
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x354 (or false false)))
(let (($x135 (not $x354)))
(and $x135 (or $x354 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 30: function core_state_transition, block 99, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x90 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x354 (or false false)))
(let (($x207 (or $x354 false false)))
(let (($x337 (not $x207)))
(and $x337 (or $x207 (and (distinct ?x90 ?x90) true))))))))
(check-sat)
; query 31: function crcu8, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x354 (or false false)))
(let (($x135 (not $x354)))
(and $x135 (or $x354 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 32: function crcu8, block 19, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x592 ((_ zero_extend 16) in.01_16)))
(let ((?x1431 (bvxor ?x592 (_ bv16386 32))))
(let (($x354 (or false false)))
(let (($x207 (or $x354 false false)))
(let (($x337 (not $x207)))
(and $x337 (or $x207 (and (distinct ?x1431 ?x1431) true)))))))))
(check-sat)
; query 33: function crcu8, block 19, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x592 ((_ zero_extend 16) in.01_16)))
(let ((?x1431 (bvxor ?x592 (_ bv16386 32))))
(let ((?x428 ((_ extract 15 0) ?x1431)))
(let (($x354 (or false false)))
(let (($x207 (or $x354 false false)))
(let (($x844 (or $x207 false)))
(let (($x710 (not $x844)))
(and $x710 (or $x844 (and (distinct ?x428 ?x428) true)))))))))))
(check-sat)
; query 34: function crcu8, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x354 (or false false)))
(let (($x135 (not $x354)))
(and $x135 (or $x354 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 35: function crcu8, block 29, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x458 ((_ zero_extend 16) in27_16)))
(let ((?x1152 (bvor ?x458 (_ bv32768 32))))
(let (($x354 (or false false)))
(let (($x207 (or $x354 false false)))
(let (($x337 (not $x207)))
(and $x337 (or $x207 (and (distinct ?x1152 ?x1152) true)))))))))
(check-sat)
; query 36: function crcu8, block 29, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x458 ((_ zero_extend 16) in27_16)))
(let ((?x1152 (bvor ?x458 (_ bv32768 32))))
(let ((?x523 ((_ extract 15 0) ?x1152)))
(let (($x354 (or false false)))
(let (($x207 (or $x354 false false)))
(let (($x844 (or $x207 false)))
(let (($x710 (not $x844)))
(and $x710 (or $x844 (and (distinct ?x523 ?x523) true)))))))))))
(check-sat)
; query 37: function crcu8, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x354 (or false false)))
(let (($x135 (not $x354)))
(and $x135 (or $x354 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 38: function crcu8, block 33, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x458 ((_ zero_extend 16) in27_16)))
(let ((?x50 (bvand ?x458 (_ bv32767 32))))
(let (($x354 (or false false)))
(let (($x207 (or $x354 false false)))
(let (($x337 (not $x207)))
(and $x337 (or $x207 (and (distinct ?x50 ?x50) true)))))))))
(check-sat)
; query 39: function crcu8, block 33, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x458 ((_ zero_extend 16) in27_16)))
(let ((?x50 (bvand ?x458 (_ bv32767 32))))
(let ((?x701 ((_ extract 15 0) ?x50)))
(let (($x354 (or false false)))
(let (($x207 (or $x354 false false)))
(let (($x844 (or $x207 false)))
(let (($x710 (not $x844)))
(and $x710 (or $x844 (and (distinct ?x701 ?x701) true)))))))))))
(check-sat)
; query 40: function crcu8, block 38, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_8 () (_ BitVec 8))
(assert
 (let (($x1198 (and (distinct (bvadd ((_ zero_extend 1) in.02_8) ((_ zero_extend 1) (_ bv1 8))) ((_ zero_extend 1) (bvadd in.02_8 (_ bv1 8)))) true)))
(let (($x684 (and (distinct (bvadd ((_ sign_extend 1) in.02_8) ((_ sign_extend 1) (_ bv1 8))) ((_ sign_extend 1) (bvadd in.02_8 (_ bv1 8)))) true)))
(let (($x251 (or (or false false (or $x684 $x1198)) (and (distinct (bvadd in.02_8 (_ bv1 8)) (bvadd in.02_8 (_ bv1 8))) true))))
(let (($x98 (or false false false)))
(let (($x57 (not $x98)))
(and $x57 $x251)))))))
(check-sat)
; query 41: function crcu8, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x628 ((_ extract 7 0) in.01_16)))
(let ((?x20 ((_ zero_extend 24) ?x628)))
(let (($x354 (or false false)))
(let (($x1196 (or $x354 false)))
(and (not $x1196) (or $x1196 (and (distinct ?x20 ?x20) true))))))))
(check-sat)
; query 42: function crcu8, block 6, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x628 ((_ extract 7 0) in.01_16)))
(let ((?x20 ((_ zero_extend 24) ?x628)))
(let ((?x1476 (bvand ?x20 (_ bv1 32))))
(let (($x354 (or false false)))
(let (($x1196 (or $x354 false)))
(let (($x1195 (or $x1196 false false)))
(and (not $x1195) (or $x1195 (and (distinct ?x1476 ?x1476) true))))))))))
(check-sat)
; query 43: function crcu8, block 6, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x628 ((_ extract 7 0) in.01_16)))
(let ((?x20 ((_ zero_extend 24) ?x628)))
(let ((?x1476 (bvand ?x20 (_ bv1 32))))
(let ((?x27 ((_ zero_extend 24) in.0_8)))
(let ((?x675 (bvand ?x27 (_ bv1 32))))
(let ((?x550 (bvxor ?x675 ?x1476)))
(let (($x354 (or false false)))
(let (($x1196 (or $x354 false)))
(let (($x1195 (or $x1196 false false)))
(let (($x207 (or $x354 false false)))
(let (($x114 (or $x207 $x1195 false)))
(and (not $x114) (or $x114 (and (distinct ?x550 ?x550) true)))))))))))))))
(check-sat)
; query 44: function crcu8, block 6, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x628 ((_ extract 7 0) in.01_16)))
(let ((?x20 ((_ zero_extend 24) ?x628)))
(let ((?x1476 (bvand ?x20 (_ bv1 32))))
(let ((?x27 ((_ zero_extend 24) in.0_8)))
(let ((?x675 (bvand ?x27 (_ bv1 32))))
(let ((?x550 (bvxor ?x675 ?x1476)))
(let ((?x988 ((_ extract 7 0) ?x550)))
(let (($x354 (or false false)))
(let (($x1196 (or $x354 false)))
(let (($x1195 (or $x1196 false false)))
(let (($x207 (or $x354 false false)))
(let (($x114 (or $x207 $x1195 false)))
(let (($x1478 (or $x114 false)))
(and (not $x1478) (or $x1478 (and (distinct ?x988 ?x988) true)))))))))))))))))
(check-sat)
; query 45: function crcu8, block 6, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x354 (or false false)))
(let (($x135 (not $x354)))
(and $x135 (or $x354 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 46: function crcu8, block 6, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x27 ((_ zero_extend 24) in.0_8)))
(let ((?x1186 (bvashr ?x27 (_ bv1 32))))
(let (($x354 (or false false)))
(let (($x207 (or $x354 false false)))
(let (($x242 (or $x207 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not $x242) (or $x242 (and (distinct ?x1186 ?x1186) true)))))))))
(check-sat)
; query 47: function crcu8, block 6, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x27 ((_ zero_extend 24) in.0_8)))
(let ((?x1186 (bvashr ?x27 (_ bv1 32))))
(let ((?x140 ((_ extract 7 0) ?x1186)))
(let (($x354 (or false false)))
(let (($x207 (or $x354 false false)))
(let (($x242 (or $x207 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x1165 (or $x242 false)))
(and (not $x1165) (or $x1165 (and (distinct ?x140 ?x140) true)))))))))))
(check-sat)
; query 48: function crcu8, block 6, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x628 ((_ extract 7 0) in.01_16)))
(let ((?x20 ((_ zero_extend 24) ?x628)))
(let ((?x1476 (bvand ?x20 (_ bv1 32))))
(let ((?x27 ((_ zero_extend 24) in.0_8)))
(let ((?x675 (bvand ?x27 (_ bv1 32))))
(let ((?x550 (bvxor ?x675 ?x1476)))
(let ((?x988 ((_ extract 7 0) ?x550)))
(let ((?x1110 ((_ zero_extend 24) ?x988)))
(let (($x354 (or false false)))
(let (($x1196 (or $x354 false)))
(let (($x1195 (or $x1196 false false)))
(let (($x207 (or $x354 false false)))
(let (($x114 (or $x207 $x1195 false)))
(let (($x1478 (or $x114 false)))
(let (($x25 (or $x1478 false)))
(and (not $x25) (or $x25 (and (distinct ?x1110 ?x1110) true)))))))))))))))))))
(check-sat)
; query 49: function crcu8, block 6, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x628 ((_ extract 7 0) in.01_16)))
(let ((?x20 ((_ zero_extend 24) ?x628)))
(let ((?x1476 (bvand ?x20 (_ bv1 32))))
(let ((?x27 ((_ zero_extend 24) in.0_8)))
(let ((?x675 (bvand ?x27 (_ bv1 32))))
(let ((?x550 (bvxor ?x675 ?x1476)))
(let ((?x988 ((_ extract 7 0) ?x550)))
(let ((?x1110 ((_ zero_extend 24) ?x988)))
(let ((?x1154 (ite (= (_ bv1 32) ?x1110) (_ bv1 1) (_ bv0 1))))
(let (($x354 (or false false)))
(let (($x1196 (or $x354 false)))
(let (($x1195 (or $x1196 false false)))
(let (($x207 (or $x354 false false)))
(let (($x114 (or $x207 $x1195 false)))
(let (($x1478 (or $x114 false)))
(let (($x25 (or $x1478 false)))
(let (($x197 (or $x25 false false)))
(and (not $x197) (or $x197 (and (distinct ?x1154 ?x1154) true)))))))))))))))))))))
(check-sat)
; query 50: function crcu8, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x354 (or false false)))
(let (($x135 (not $x354)))
(and $x135 (or $x354 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 51: function crcu8, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x27 ((_ zero_extend 24) in.0_8)))
(let ((?x675 (bvand ?x27 (_ bv1 32))))
(let (($x354 (or false false)))
(let (($x207 (or $x354 false false)))
(let (($x337 (not $x207)))
(and $x337 (or $x207 (and (distinct ?x675 ?x675) true)))))))))
(check-sat)
; query 52: function crcu8, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x354 (or false false)))
(let (($x135 (not $x354)))
(and $x135 (or $x354 (and (distinct ((_ extract 7 0) in.01_16) ((_ extract 7 0) in.01_16)) true))))))
(check-sat)
; query 53: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x818 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x284 ((_ zero_extend 31) ?x818)))
(let ((?x87 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1237 ((_ zero_extend 31) ?x87)))
(let ((?x1007 (bvand ?x1237 ?x284)))
(let ((?x1184 (ite (and (distinct (_ bv0 32) ?x1007) true) (_ bv1 1) (_ bv0 1))))
(let ((?x497 ((_ zero_extend 63) ?x1184)))
(let (($x354 (or false false)))
(let (($x207 (or $x354 false false)))
(let (($x844 (or $x207 false)))
(let (($x1193 (or $x844 $x844 false)))
(let (($x1185 (or $x1193 false false)))
(let (($x1172 (or $x1185 false)))
(and (not $x1172) (or $x1172 (and (distinct ?x497 ?x497) true)))))))))))))))))
(check-sat)
; query 54: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x818 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x284 ((_ zero_extend 31) ?x818)))
(let ((?x87 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1237 ((_ zero_extend 31) ?x87)))
(let ((?x1007 (bvand ?x1237 ?x284)))
(let ((?x1184 (ite (and (distinct (_ bv0 32) ?x1007) true) (_ bv1 1) (_ bv0 1))))
(let (($x372 (= (_ bv1 1) ?x1184)))
(let ((?x239 (ite $x372 (_ bv1 32) (_ bv0 32))))
(let (($x354 (or false false)))
(let (($x207 (or $x354 false false)))
(let (($x844 (or $x207 false)))
(let (($x1193 (or $x844 $x844 false)))
(let (($x1185 (or $x1193 false false)))
(let (($x245 (or $x1185 (ite $x372 false false))))
(and (not $x245) (or $x245 (and (distinct ?x239 ?x239) true))))))))))))))))))
(check-sat)
; query 55: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x818 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x284 ((_ zero_extend 31) ?x818)))
(let ((?x87 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1237 ((_ zero_extend 31) ?x87)))
(let ((?x1007 (bvand ?x1237 ?x284)))
(let ((?x1184 (ite (and (distinct (_ bv0 32) ?x1007) true) (_ bv1 1) (_ bv0 1))))
(let (($x372 (= (_ bv1 1) ?x1184)))
(let ((?x239 (ite $x372 (_ bv1 32) (_ bv0 32))))
(let ((?x637 ((_ extract 7 0) ?x239)))
(let (($x354 (or false false)))
(let (($x207 (or $x354 false false)))
(let (($x844 (or $x207 false)))
(let (($x1193 (or $x844 $x844 false)))
(let (($x1185 (or $x1193 false false)))
(let (($x245 (or $x1185 (ite $x372 false false))))
(let (($x815 (or $x245 false)))
(and (not $x815) (or $x815 (and (distinct ?x637 ?x637) true))))))))))))))))))))
(check-sat)
; query 56: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x354 (or false false)))
(let (($x135 (not $x354)))
(and $x135 (or $x354 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 57: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x87 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x354 (or false false)))
(let (($x207 (or $x354 false false)))
(let (($x337 (not $x207)))
(and $x337 (or $x207 (and (distinct ?x87 ?x87) true))))))))
(check-sat)
; query 58: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x87 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1237 ((_ zero_extend 31) ?x87)))
(let (($x354 (or false false)))
(let (($x207 (or $x354 false false)))
(let (($x844 (or $x207 false)))
(let (($x710 (not $x844)))
(and $x710 (or $x844 (and (distinct ?x1237 ?x1237) true))))))))))
(check-sat)
; query 59: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x354 (or false false)))
(let (($x135 (not $x354)))
(and $x135 (or $x354 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 60: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x818 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x354 (or false false)))
(let (($x207 (or $x354 false false)))
(let (($x337 (not $x207)))
(and $x337 (or $x207 (and (distinct ?x818 ?x818) true))))))))
(check-sat)
; query 61: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x818 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x284 ((_ zero_extend 31) ?x818)))
(let (($x354 (or false false)))
(let (($x207 (or $x354 false false)))
(let (($x844 (or $x207 false)))
(let (($x710 (not $x844)))
(and $x710 (or $x844 (and (distinct ?x284 ?x284) true))))))))))
(check-sat)
; query 62: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x818 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x284 ((_ zero_extend 31) ?x818)))
(let ((?x87 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1237 ((_ zero_extend 31) ?x87)))
(let ((?x1007 (bvand ?x1237 ?x284)))
(let (($x354 (or false false)))
(let (($x207 (or $x354 false false)))
(let (($x844 (or $x207 false)))
(let (($x1193 (or $x844 $x844 false)))
(and (not $x1193) (or $x1193 (and (distinct ?x1007 ?x1007) true)))))))))))))
(check-sat)
; query 63: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x818 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x284 ((_ zero_extend 31) ?x818)))
(let ((?x87 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1237 ((_ zero_extend 31) ?x87)))
(let ((?x1007 (bvand ?x1237 ?x284)))
(let ((?x1184 (ite (and (distinct (_ bv0 32) ?x1007) true) (_ bv1 1) (_ bv0 1))))
(let (($x354 (or false false)))
(let (($x207 (or $x354 false false)))
(let (($x844 (or $x207 false)))
(let (($x1193 (or $x844 $x844 false)))
(let (($x1185 (or $x1193 false false)))
(and (not $x1185) (or $x1185 (and (distinct ?x1184 ?x1184) true)))))))))))))))
(check-sat)
; query 64: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1091 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x98 (or false false false)))
(let (($x57 (not $x98)))
(and $x57 (or $x98 (and (distinct ?x1091 ?x1091) true)))))))
(check-sat)
; query 65: function matrix_mul_matrix, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x98 (or false false false)))
(let (($x57 (not $x98)))
(and $x57 (or $x98 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 66: function matrix_mul_matrix_bitextract, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x98 (or false false false)))
(let (($x57 (not $x98)))
(and $x57 (or $x98 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 67: function parseval, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.23_32 () (_ BitVec 32))
(assert
 (let (($x477 (and (distinct (bvmul ((_ sign_extend 32) in.23_32) ((_ sign_extend 32) (_ bv1024 32))) ((_ sign_extend 32) (bvmul in.23_32 (_ bv1024 32)))) true)))
(let (($x890 (or false false (or $x477))))
(and (not $x890) (or $x890 (and (distinct (bvmul in.23_32 (_ bv1024 32)) (bvmul in.23_32 (_ bv1024 32))) true))))))
(check-sat)
; query 68: function parseval, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.34_32 () (_ BitVec 32))
(assert
 (let (($x864 (and (distinct (bvmul ((_ sign_extend 32) in.34_32) ((_ sign_extend 32) (_ bv1048576 32))) ((_ sign_extend 32) (bvmul in.34_32 (_ bv1048576 32)))) true)))
(let (($x385 (or false false (or $x864))))
(and (not $x385) (or $x385 (and (distinct (bvmul in.34_32 (_ bv1048576 32)) (bvmul in.34_32 (_ bv1048576 32))) true))))))
(check-sat)
