; OptiPhase-Sigma refinement certificate for sweep K12-R3-111
