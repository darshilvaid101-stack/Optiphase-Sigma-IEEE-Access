; OptiPhase-Sigma refinement certificate for sweep K59-R6-024
; query 0: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x1340 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x9873 (or false false false)))
(let (($x446 (not $x9873)))
(and $x446 (or $x9873 (and (distinct ?x1340 ?x1340) true)))))))
(check-sat)
; query 1: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x9873 (or false false false)))
(let (($x446 (not $x9873)))
(and $x446 (or $x9873 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 2: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x39241 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x9873 (or false false false)))
(let (($x446 (not $x9873)))
(and $x446 (or $x9873 (and (distinct ?x39241 ?x39241) true)))))))
(check-sat)
; query 3: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x38715 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x9873 (or false false false)))
(let (($x446 (not $x9873)))
(and $x446 (or $x9873 (and (distinct ?x38715 ?x38715) true)))))))
(check-sat)
