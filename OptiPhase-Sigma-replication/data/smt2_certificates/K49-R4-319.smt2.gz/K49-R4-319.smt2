; OptiPhase-Sigma refinement certificate for sweep K49-R4-319
; query 0: function APCM_inverse_quantization, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x42 (or false false)))
(let (($x176 (not $x42)))
(and $x176 (or $x42 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 1: function APCM_inverse_quantization, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x37 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x42 (or false false)))
(let (($x48 (or $x42 false false)))
(let (($x39 (not $x48)))
(and $x39 (or $x48 (and (distinct ?x37 ?x37) true))))))))
(check-sat)
; query 2: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x42 (or false false)))
(let (($x176 (not $x42)))
(and $x176 (or $x42 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 3: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x64 (ite (bvslt (_ bv15 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x42 (or false false)))
(let (($x48 (or $x42 false false)))
(let (($x39 (not $x48)))
(and $x39 (or $x48 (and (distinct ?x64 ?x64) true))))))))
(check-sat)
; query 4: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x42 (or false false)))
(let (($x176 (not $x42)))
(and $x176 (or $x42 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 5: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x206 (ite (bvsgt (_ bv40 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x42 (or false false)))
(let (($x48 (or $x42 false false)))
(let (($x39 (not $x48)))
(and $x39 (or $x48 (and (distinct ?x206 ?x206) true))))))))
(check-sat)
; query 6: function RPE_grid_positioning, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x42 (or false false)))
(let (($x176 (not $x42)))
(and $x176 (or $x42 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 7: function RPE_grid_positioning, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x538 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x24 (and (distinct ?x538 ?x538) true)))
(let (($x42 (or false false)))
(let (($x166 (or false $x42 false)))
(and (not $x166) (or $x166 $x24)))))))
(check-sat)
; query 8: function gsm_L_add, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x135 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x320 (or false false false)))
(let (($x858 (not $x320)))
(and $x858 (or $x320 (and (distinct ?x135 ?x135) true)))))))
(check-sat)
; query 9: function gsm_L_add, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x29 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvadd in0_64 in1_64))) true)))
(let (($x94 (or false false (or $x29))))
(let (($x781 (or $x94 (and (distinct (bvadd in0_64 in1_64) (bvadd in0_64 in1_64)) true))))
(and (not $x94) $x781)))))
(check-sat)
; query 10: function gsm_L_add, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x321 (bvadd in0_64 (_ bv1 64))))
(let ((?x436 (bvsub (_ bv0 64) ?x321)))
(let (($x566 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x321)) ((_ sign_extend 1) ?x436)) true)))
(let ((?x474 ((_ sign_extend 1) ?x321)))
(let (($x1489 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x474) true)))))
(let (($x631 (or false $x1489 (or $x566))))
(and (not $x631) (or $x631 (and (distinct ?x436 ?x436) true))))))))))
(check-sat)
; query 11: function gsm_L_add, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x487 (bvadd in1_64 (_ bv1 64))))
(let ((?x778 ((_ sign_extend 1) ?x487)))
(let (($x82 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x778) true)))))
(and (not $x82) (or $x82 (and (distinct ?x487 ?x487) true)))))))
(check-sat)
; query 12: function gsm_L_add, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x487 (bvadd in1_64 (_ bv1 64))))
(let ((?x362 (bvsub (_ bv0 64) ?x487)))
(let (($x524 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x487)) ((_ sign_extend 1) ?x362)) true)))
(let ((?x778 ((_ sign_extend 1) ?x487)))
(let (($x82 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x778) true)))))
(let (($x227 (or false $x82 (or $x524))))
(and (not $x227) (or $x227 (and (distinct ?x362 ?x362) true))))))))))
(check-sat)
; query 13: function gsm_L_add, block 8, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x487 (bvadd in1_64 (_ bv1 64))))
(let ((?x362 (bvsub (_ bv0 64) ?x487)))
(let ((?x321 (bvadd in0_64 (_ bv1 64))))
(let ((?x436 (bvsub (_ bv0 64) ?x321)))
(let ((?x359 (bvadd ?x436 ?x362)))
(let (($x7 (and (distinct (bvadd ((_ zero_extend 1) ?x436) ((_ zero_extend 1) ?x362)) ((_ zero_extend 1) ?x359)) true)))
(let (($x524 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x487)) ((_ sign_extend 1) ?x362)) true)))
(let ((?x778 ((_ sign_extend 1) ?x487)))
(let (($x82 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x778) true)))))
(let (($x227 (or false $x82 (or $x524))))
(let (($x566 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x321)) ((_ sign_extend 1) ?x436)) true)))
(let ((?x474 ((_ sign_extend 1) ?x321)))
(let (($x1489 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x474) true)))))
(let (($x631 (or false $x1489 (or $x566))))
(let (($x661 (or $x631 $x227 (or $x7))))
(and (not (or $x631 $x227 false)) (or $x661 (and (distinct ?x359 ?x359) true)))))))))))))))))))
(check-sat)
; query 14: function gsm_L_add, block 8, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x487 (bvadd in1_64 (_ bv1 64))))
(let ((?x362 (bvsub (_ bv0 64) ?x487)))
(let ((?x321 (bvadd in0_64 (_ bv1 64))))
(let ((?x436 (bvsub (_ bv0 64) ?x321)))
(let ((?x359 (bvadd ?x436 ?x362)))
(let ((?x117 (ite (bvuge ?x359 (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x7 (and (distinct (bvadd ((_ zero_extend 1) ?x436) ((_ zero_extend 1) ?x362)) ((_ zero_extend 1) ?x359)) true)))
(let (($x524 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x487)) ((_ sign_extend 1) ?x362)) true)))
(let ((?x778 ((_ sign_extend 1) ?x487)))
(let (($x82 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x778) true)))))
(let (($x227 (or false $x82 (or $x524))))
(let (($x566 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x321)) ((_ sign_extend 1) ?x436)) true)))
(let ((?x474 ((_ sign_extend 1) ?x321)))
(let (($x1489 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x474) true)))))
(let (($x631 (or false $x1489 (or $x566))))
(let (($x661 (or $x631 $x227 (or $x7))))
(and (not (or (or $x631 $x227 false) false false)) (or (or $x661 false false) (and (distinct ?x117 ?x117) true))))))))))))))))))))
(check-sat)
; query 15: function gsm_L_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x321 (bvadd in0_64 (_ bv1 64))))
(let ((?x474 ((_ sign_extend 1) ?x321)))
(let (($x1489 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x474) true)))))
(and (not $x1489) (or $x1489 (and (distinct ?x321 ?x321) true)))))))
(check-sat)
; query 16: function gsm_L_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x823 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x320 (or false false false)))
(let (($x858 (not $x320)))
(and $x858 (or $x320 (and (distinct ?x823 ?x823) true)))))))
(check-sat)
; query 17: function gsm_L_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x343 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x320 (or false false false)))
(let (($x858 (not $x320)))
(and $x858 (or $x320 (and (distinct ?x343 ?x343) true)))))))
(check-sat)
; query 18: function gsm_L_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x823 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x320 (or false false false)))
(let (($x858 (not $x320)))
(and $x858 (or $x320 (and (distinct ?x823 ?x823) true)))))))
(check-sat)
; query 19: function gsm_L_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x823 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x123 ((_ zero_extend 31) ?x823)))
(let (($x320 (or false false false)))
(let (($x151 (or $x320 false)))
(and (not $x151) (or $x151 (and (distinct ?x123 ?x123) true))))))))
(check-sat)
; query 20: function gsm_L_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x823 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x123 ((_ zero_extend 31) ?x823)))
(let ((?x33 (bvsub (_ bv0 32) ?x123)))
(let (($x386 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x123)) ((_ sign_extend 1) ?x33)) true)))
(let (($x320 (or false false false)))
(let (($x151 (or $x320 false)))
(let (($x85 (or false $x151 (or $x386))))
(and (not $x85) (or $x85 (and (distinct ?x33 ?x33) true)))))))))))
(check-sat)
; query 21: function gsm_L_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x823 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x123 ((_ zero_extend 31) ?x823)))
(let ((?x33 (bvsub (_ bv0 32) ?x123)))
(let ((?x392 ((_ sign_extend 32) ?x33)))
(let (($x386 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x123)) ((_ sign_extend 1) ?x33)) true)))
(let (($x320 (or false false false)))
(let (($x151 (or $x320 false)))
(let (($x85 (or false $x151 (or $x386))))
(let (($x50 (or $x85 false)))
(and (not $x50) (or $x50 (and (distinct ?x392 ?x392) true)))))))))))))
(check-sat)
; query 22: function gsm_L_asr, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x71 (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x320 (or false false false)))
(let (($x858 (not $x320)))
(and $x858 (or $x320 (and (distinct ?x71 ?x71) true)))))))
(check-sat)
; query 23: function gsm_L_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x343 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x320 (or false false false)))
(let (($x858 (not $x320)))
(and $x858 (or $x320 (and (distinct ?x343 ?x343) true)))))))
(check-sat)
; query 24: function gsm_L_sub, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x135 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x320 (or false false false)))
(let (($x858 (not $x320)))
(and $x858 (or $x320 (and (distinct ?x135 ?x135) true)))))))
(check-sat)
; query 25: function gsm_L_sub, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x746 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvsub in0_64 in1_64))) true)))
(let (($x240 (or false false (or $x746))))
(let (($x1064 (or $x240 (and (distinct (bvsub in0_64 in1_64) (bvsub in0_64 in1_64)) true))))
(and (not $x240) $x1064)))))
(check-sat)
; query 26: function gsm_L_sub, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x487 (bvadd in1_64 (_ bv1 64))))
(let ((?x362 (bvsub (_ bv0 64) ?x487)))
(let (($x524 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x487)) ((_ sign_extend 1) ?x362)) true)))
(let ((?x778 ((_ sign_extend 1) ?x487)))
(let (($x82 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x778) true)))))
(let (($x227 (or false $x82 (or $x524))))
(and (not $x227) (or $x227 (and (distinct ?x362 ?x362) true))))))))))
(check-sat)
; query 27: function gsm_L_sub, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x487 (bvadd in1_64 (_ bv1 64))))
(let ((?x362 (bvsub (_ bv0 64) ?x487)))
(let ((?x1643 (bvadd in0_64 ?x362)))
(let (($x1196 (and (distinct (bvadd ((_ zero_extend 1) in0_64) ((_ zero_extend 1) ?x362)) ((_ zero_extend 1) ?x1643)) true)))
(let (($x524 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x487)) ((_ sign_extend 1) ?x362)) true)))
(let ((?x778 ((_ sign_extend 1) ?x487)))
(let (($x82 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x778) true)))))
(let (($x227 (or false $x82 (or $x524))))
(let (($x1204 (or false $x227 (or $x1196))))
(and (not (or false $x227 false)) (or $x1204 (and (distinct ?x1643 ?x1643) true)))))))))))))
(check-sat)
; query 28: function gsm_L_sub, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x124 (ite (bvuge (bvadd in0_64 (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64)))) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let ((?x487 (bvadd in1_64 (_ bv1 64))))
(let ((?x362 (bvsub (_ bv0 64) ?x487)))
(let ((?x759 ((_ zero_extend 1) ?x362)))
(let (($x1196 (and (distinct (bvadd ((_ zero_extend 1) in0_64) ?x759) ((_ zero_extend 1) (bvadd in0_64 ?x362))) true)))
(let (($x524 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x487)) ((_ sign_extend 1) ?x362)) true)))
(let ((?x778 ((_ sign_extend 1) ?x487)))
(let (($x82 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x778) true)))))
(let (($x227 (or false $x82 (or $x524))))
(let (($x1204 (or false $x227 (or $x1196))))
(and (not (or (or false $x227 false) false false)) (or (or $x1204 false false) (and (distinct ?x124 ?x124) true))))))))))))))
(check-sat)
; query 29: function gsm_L_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x487 (bvadd in1_64 (_ bv1 64))))
(let ((?x778 ((_ sign_extend 1) ?x487)))
(let (($x82 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x778) true)))))
(and (not $x82) (or $x82 (and (distinct ?x487 ?x487) true)))))))
(check-sat)
; query 30: function gsm_L_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x341 (ite (bvsle (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x320 (or false false false)))
(let (($x858 (not $x320)))
(and $x858 (or $x320 (and (distinct ?x341 ?x341) true)))))))
(check-sat)
; query 31: function gsm_abs, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x42 (or false false)))
(let (($x176 (not $x42)))
(and $x176 (or $x42 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 32: function gsm_abs, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x132 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x42 (or false false)))
(let (($x48 (or $x42 false false)))
(let (($x39 (not $x48)))
(and $x39 (or $x48 (and (distinct ?x132 ?x132) true))))))))
(check-sat)
; query 33: function gsm_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x42 (or false false)))
(let (($x176 (not $x42)))
(and $x176 (or $x42 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 34: function gsm_add, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x42 (or false false)))
(let (($x176 (not $x42)))
(and $x176 (or $x42 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 35: function gsm_add, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x714 ((_ sign_extend 48) in1_16)))
(let ((?x98 ((_ sign_extend 48) in0_16)))
(let ((?x1367 (bvadd ?x98 ?x714)))
(let (($x318 (and (distinct (bvadd ((_ sign_extend 1) ?x98) ((_ sign_extend 1) ?x714)) ((_ sign_extend 1) ?x1367)) true)))
(let (($x42 (or false false)))
(let (($x1534 (or $x42 $x42 (or $x318))))
(and (not $x1534) (or $x1534 (and (distinct ?x1367 ?x1367) true))))))))))
(check-sat)
; query 36: function gsm_add, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1161 (ite (bvsgt (_ bv18446744073709518848 64) (bvadd ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x714 ((_ sign_extend 48) in1_16)))
(let ((?x600 ((_ sign_extend 1) ?x714)))
(let ((?x98 ((_ sign_extend 48) in0_16)))
(let ((?x1442 ((_ sign_extend 1) ?x98)))
(let (($x42 (or false false)))
(let (($x1534 (or $x42 $x42 (or (and (distinct (bvadd ?x1442 ?x600) ((_ sign_extend 1) (bvadd ?x98 ?x714))) true)))))
(let (($x1488 (or $x1534 false false)))
(and (not $x1488) (or $x1488 (and (distinct ?x1161 ?x1161) true))))))))))))
(check-sat)
; query 37: function gsm_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x648 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x320 (or false false false)))
(let (($x858 (not $x320)))
(and $x858 (or $x320 (and (distinct ?x648 ?x648) true)))))))
(check-sat)
; query 38: function gsm_asr, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1160 (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x320 (or false false false)))
(let (($x858 (not $x320)))
(and $x858 (or $x320 (and (distinct ?x1160 ?x1160) true)))))))
(check-sat)
; query 39: function gsm_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x42 (or false false)))
(let (($x176 (not $x42)))
(and $x176 (or $x42 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 40: function gsm_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x132 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x42 (or false false)))
(let (($x48 (or $x42 false false)))
(let (($x39 (not $x48)))
(and $x39 (or $x48 (and (distinct ?x132 ?x132) true))))))))
(check-sat)
; query 41: function gsm_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x132 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1383 ((_ zero_extend 31) ?x132)))
(let (($x42 (or false false)))
(let (($x48 (or $x42 false false)))
(let (($x1458 (or $x48 false)))
(and (not $x1458) (or $x1458 (and (distinct ?x1383 ?x1383) true)))))))))
(check-sat)
; query 42: function gsm_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x132 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1383 ((_ zero_extend 31) ?x132)))
(let ((?x624 (bvsub (_ bv0 32) ?x1383)))
(let (($x1131 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1383)) ((_ sign_extend 1) ?x624)) true)))
(let (($x42 (or false false)))
(let (($x48 (or $x42 false false)))
(let (($x1458 (or $x48 false)))
(let (($x1116 (or false $x1458 (or $x1131))))
(and (not $x1116) (or $x1116 (and (distinct ?x624 ?x624) true))))))))))))
(check-sat)
; query 43: function gsm_asr, block 4, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x132 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1383 ((_ zero_extend 31) ?x132)))
(let ((?x624 (bvsub (_ bv0 32) ?x1383)))
(let ((?x1487 ((_ extract 15 0) ?x624)))
(let (($x1131 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1383)) ((_ sign_extend 1) ?x624)) true)))
(let (($x42 (or false false)))
(let (($x48 (or $x42 false false)))
(let (($x1458 (or $x48 false)))
(let (($x1116 (or false $x1458 (or $x1131))))
(let (($x1583 (or (or $x1116 (or (and (distinct ((_ sign_extend 16) ?x1487) ?x624) true))) (and (distinct ?x1487 ?x1487) true))))
(and (not (or $x1116 false)) $x1583))))))))))))
(check-sat)
; query 44: function gsm_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x648 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x320 (or false false false)))
(let (($x858 (not $x320)))
(and $x858 (or $x320 (and (distinct ?x648 ?x648) true)))))))
(check-sat)
; query 45: function gsm_debug_longwords, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in15_32 () (_ BitVec 32))
(assert
 (let ((?x389 (ite (bvslt in15_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x320 (or false false false)))
(let (($x858 (not $x320)))
(and $x858 (or $x320 (and (distinct ?x389 ?x389) true)))))))
(check-sat)
; query 46: function gsm_debug_words, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in16_32 () (_ BitVec 32))
(assert
 (let ((?x736 (ite (bvslt in16_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x320 (or false false false)))
(let (($x858 (not $x320)))
(and $x858 (or $x320 (and (distinct ?x736 ?x736) true)))))))
(check-sat)
; query 47: function gsm_div, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x42 (or false false)))
(let (($x176 (not $x42)))
(and $x176 (or $x42 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 48: function gsm_div, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x42 (or false false)))
(let (($x176 (not $x42)))
(and $x176 (or $x42 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 49: function gsm_div, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x42 (or false false)))
(let (($x176 (not $x42)))
(and $x176 (or $x42 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 50: function gsm_div, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x538 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x24 (and (distinct ?x538 ?x538) true)))
(let (($x42 (or false false)))
(let (($x48 (or $x42 false false)))
(let (($x39 (not $x48)))
(and $x39 (or $x48 $x24))))))))
(check-sat)
; query 51: function gsm_norm, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1225 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x320 (or false false false)))
(let (($x858 (not $x320)))
(and $x858 (or $x320 (and (distinct ?x1225 ?x1225) true)))))))
(check-sat)
; query 52: function gsm_norm, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1225 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x1283 (bvxor ?x1225 (_ bv1 1))))
(let (($x320 (or false false false)))
(let (($x534 (or $x320 false false)))
(and (not $x534) (or $x534 (and (distinct ?x1283 ?x1283) true))))))))
(check-sat)
; query 53: function gsm_norm, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1225 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x1283 (bvxor ?x1225 (_ bv1 1))))
(let ((?x485 ((_ zero_extend 31) ?x1283)))
(let (($x320 (or false false false)))
(let (($x534 (or $x320 false false)))
(let (($x1565 (or $x534 false)))
(and (not $x1565) (or $x1565 (and (distinct ?x485 ?x485) true))))))))))
(check-sat)
; query 54: function gsm_norm, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1225 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x1283 (bvxor ?x1225 (_ bv1 1))))
(let ((?x485 ((_ zero_extend 31) ?x1283)))
(let (($x320 (or false false false)))
(let (($x534 (or $x320 false false)))
(let (($x1565 (or $x534 false)))
(let (($x360 (or (or $x1565 (or (= ((_ extract 31 31) ?x485) (_ bv1 1)))) (and (distinct ((_ sign_extend 32) ?x485) ((_ zero_extend 32) ?x485)) true))))
(and (not (or $x1565 false)) $x360)))))))))
(check-sat)
; query 55: function gsm_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x42 (or false false)))
(let (($x176 (not $x42)))
(and $x176 (or $x42 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 56: function gsm_sub, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x42 (or false false)))
(let (($x176 (not $x42)))
(and $x176 (or $x42 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 57: function gsm_sub, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x714 ((_ sign_extend 48) in1_16)))
(let ((?x98 ((_ sign_extend 48) in0_16)))
(let ((?x805 (bvsub ?x98 ?x714)))
(let (($x1284 (and (distinct (bvsub ((_ sign_extend 1) ?x98) ((_ sign_extend 1) ?x714)) ((_ sign_extend 1) ?x805)) true)))
(let (($x42 (or false false)))
(let (($x1011 (or $x42 $x42 (or $x1284))))
(and (not $x1011) (or $x1011 (and (distinct ?x805 ?x805) true))))))))))
(check-sat)
; query 58: function gsm_sub, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1070 (ite (bvsgt (_ bv18446744073709518848 64) (bvsub ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x714 ((_ sign_extend 48) in1_16)))
(let ((?x600 ((_ sign_extend 1) ?x714)))
(let ((?x98 ((_ sign_extend 48) in0_16)))
(let ((?x1442 ((_ sign_extend 1) ?x98)))
(let (($x42 (or false false)))
(let (($x1011 (or $x42 $x42 (or (and (distinct (bvsub ?x1442 ?x600) ((_ sign_extend 1) (bvsub ?x98 ?x714))) true)))))
(let (($x1239 (or $x1011 false false)))
(and (not $x1239) (or $x1239 (and (distinct ?x1070 ?x1070) true))))))))))))
(check-sat)
