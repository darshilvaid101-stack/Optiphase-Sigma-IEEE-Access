; OptiPhase-Sigma refinement certificate for sweep K57-R3-220
; query 0: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x499 (or false false false)))
(let (($x449 (not $x499)))
(and $x449 (or $x499 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x252 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x499 (or false false false)))
(let (($x449 (not $x499)))
(and $x449 (or $x499 (and (distinct ?x252 ?x252) true)))))))
(check-sat)
; query 2: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x128 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x499 (or false false false)))
(let (($x449 (not $x499)))
(and $x449 (or $x499 (and (distinct ?x128 ?x128) true)))))))
(check-sat)
; query 3: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x499 (or false false false)))
(let (($x449 (not $x499)))
(and $x449 (or $x499 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 4: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x460 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x287 (or false false (or $x460))))
(and (not $x287) (or $x287 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 5: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x20 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x499 (or false false false)))
(let (($x449 (not $x499)))
(and $x449 (or $x499 (and (distinct ?x20 ?x20) true)))))))
(check-sat)
; query 6: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1499 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x499 (or false false false)))
(let (($x449 (not $x499)))
(and $x449 (or $x499 (and (distinct ?x1499 ?x1499) true)))))))
(check-sat)
; query 7: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x729 (or false false)))
(and (not $x729) (or $x729 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true)))))
(check-sat)
; query 8: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x83 ((_ sign_extend 16) in.1_16)))
(let ((?x283 (bvadd ?x83 (_ bv10 32))))
(let (($x71 (and (distinct (bvadd ((_ sign_extend 1) ?x83) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x283)) true)))
(let (($x729 (or false false)))
(let (($x12 (or $x729 false (or $x71))))
(and (not $x12) (or $x12 (and (distinct ?x283 ?x283) true)))))))))
(check-sat)
; query 9: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x83 ((_ sign_extend 16) in.1_16)))
(let ((?x283 (bvadd ?x83 (_ bv10 32))))
(let ((?x473 ((_ extract 15 0) ?x283)))
(let (($x71 (and (distinct (bvadd ((_ sign_extend 1) ?x83) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x283)) true)))
(let (($x729 (or false false)))
(let (($x12 (or $x729 false (or $x71))))
(let (($x604 (or $x12 false)))
(and (not $x604) (or $x604 (and (distinct ?x473 ?x473) true)))))))))))
(check-sat)
; query 10: function matrix_sum, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x100 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x499 (or false false false)))
(let (($x449 (not $x499)))
(and $x449 (or $x499 (and (distinct ?x100 ?x100) true)))))))
(check-sat)
; query 11: function matrix_sum, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x100 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let ((?x196 ((_ zero_extend 63) ?x100)))
(let (($x499 (or false false false)))
(let (($x774 (or $x499 false)))
(and (not $x774) (or $x774 (and (distinct ?x196 ?x196) true))))))))
(check-sat)
; query 12: function matrix_sum, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x100 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x484 (= (_ bv1 1) ?x100)))
(let ((?x253 (ite $x484 (_ bv1 32) (_ bv0 32))))
(let (($x499 (or false false false)))
(let (($x52 (or $x499 (ite $x484 false false))))
(and (not $x52) (or $x52 (and (distinct ?x253 ?x253) true)))))))))
(check-sat)
; query 13: function matrix_sum, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x729 (or false false)))
(and (not $x729) (or $x729 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true)))))
(check-sat)
; query 14: function matrix_sum, block 22, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x100 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x484 (= (_ bv1 1) ?x100)))
(let ((?x253 (ite $x484 (_ bv1 32) (_ bv0 32))))
(let ((?x83 ((_ sign_extend 16) in.1_16)))
(let ((?x27 (bvadd ?x83 ?x253)))
(let (($x602 (and (distinct (bvadd ((_ sign_extend 1) ?x83) ((_ sign_extend 1) ?x253)) ((_ sign_extend 1) ?x27)) true)))
(let (($x499 (or false false false)))
(let (($x52 (or $x499 (ite $x484 false false))))
(let (($x729 (or false false)))
(let (($x1462 (or $x729 $x52 (or $x602))))
(and (not $x1462) (or $x1462 (and (distinct ?x27 ?x27) true))))))))))))))
(check-sat)
; query 15: function matrix_sum, block 22, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x100 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x484 (= (_ bv1 1) ?x100)))
(let ((?x253 (ite $x484 (_ bv1 32) (_ bv0 32))))
(let ((?x83 ((_ sign_extend 16) in.1_16)))
(let ((?x27 (bvadd ?x83 ?x253)))
(let ((?x381 ((_ extract 15 0) ?x27)))
(let (($x602 (and (distinct (bvadd ((_ sign_extend 1) ?x83) ((_ sign_extend 1) ?x253)) ((_ sign_extend 1) ?x27)) true)))
(let (($x499 (or false false false)))
(let (($x52 (or $x499 (ite $x484 false false))))
(let (($x729 (or false false)))
(let (($x1462 (or $x729 $x52 (or $x602))))
(let (($x480 (or $x1462 false)))
(and (not $x480) (or $x480 (and (distinct ?x381 ?x381) true))))))))))))))))
(check-sat)
