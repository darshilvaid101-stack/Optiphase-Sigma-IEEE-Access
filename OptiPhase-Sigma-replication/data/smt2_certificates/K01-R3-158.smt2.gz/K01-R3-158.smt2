; OptiPhase-Sigma refinement certificate for sweep K01-R3-158
