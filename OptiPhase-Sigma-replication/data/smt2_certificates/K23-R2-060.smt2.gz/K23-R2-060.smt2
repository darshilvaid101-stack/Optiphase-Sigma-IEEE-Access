; OptiPhase-Sigma refinement certificate for sweep K23-R2-060
; query 0: function init_array, block 12, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x225 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x229 (or false false (or $x225))))
(and (not $x229) (or $x229 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function init_array, block 25, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x30 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x85 (or false false (or $x30))))
(and (not $x85) (or $x85 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function init_array, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x221 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x217 (or false false (or $x221))))
(and (not $x217) (or $x217 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 3: function kernel_nussinov, block 11, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x76 (and (distinct (bvsub ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvsub in.01_32 (_ bv1 32)))) true)))
(let (($x123 (or false false (or $x76))))
(and (not $x123) (or $x123 (and (distinct (bvsub in.01_32 (_ bv1 32)) (bvsub in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 4: function kernel_nussinov, block 11, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x143 (ite (bvsle (_ bv0 32) (bvsub in.01_32 (_ bv1 32))) (_ bv1 1) (_ bv0 1))))
(let (($x76 (and (distinct (bvsub ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvsub in.01_32 (_ bv1 32)))) true)))
(let (($x123 (or false false (or $x76))))
(let (($x128 (or $x123 false false)))
(and (not $x128) (or $x128 (and (distinct ?x143 ?x143) true))))))))
(check-sat)
; query 5: function kernel_nussinov, block 185, name %186
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x103 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x66 (or false false (or $x103))))
(and (not $x66) (or $x66 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 6: function kernel_nussinov, block 233, name %234
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x30 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x85 (or false false (or $x30))))
(and (not $x85) (or $x85 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 7: function kernel_nussinov, block 236, name %237
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x225 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x229 (or false false (or $x225))))
(and (not $x229) (or $x229 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function kernel_nussinov, block 239, name %240
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x126 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv4294967295 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv4294967295 32)))) true)))
(let (($x41 (or false false (or $x126))))
(and (not $x41) (or $x41 (and (distinct (bvadd in.02_32 (_ bv4294967295 32)) (bvadd in.02_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 9: function kernel_nussinov, block 46, name %47
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x103 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x66 (or false false (or $x103))))
(and (not $x66) (or $x66 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 10: function kernel_nussinov, block 46, name %48
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x22 (ite (bvslt (bvadd in.02_32 (_ bv1 32)) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x103 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x66 (or false false (or $x103))))
(let (($x87 (or $x66 false false)))
(and (not $x87) (or $x87 (and (distinct ?x22 ?x22) true))))))))
(check-sat)
; query 11: function kernel_nussinov, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x103 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x66 (or false false (or $x103))))
(and (not $x66) (or $x66 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 12: function kernel_nussinov, block 81, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x76 (and (distinct (bvsub ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvsub in.01_32 (_ bv1 32)))) true)))
(let (($x123 (or false false (or $x76))))
(and (not $x123) (or $x123 (and (distinct (bvsub in.01_32 (_ bv1 32)) (bvsub in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 13: function kernel_nussinov, block 81, name %83
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x143 (ite (bvsle (_ bv0 32) (bvsub in.01_32 (_ bv1 32))) (_ bv1 1) (_ bv0 1))))
(let (($x76 (and (distinct (bvsub ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvsub in.01_32 (_ bv1 32)))) true)))
(let (($x123 (or false false (or $x76))))
(let (($x128 (or $x123 false false)))
(and (not $x128) (or $x128 (and (distinct ?x143 ?x143) true))))))))
(check-sat)
; query 14: function kernel_nussinov, block 84, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x103 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x66 (or false false (or $x103))))
(and (not $x66) (or $x66 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 15: function kernel_nussinov, block 84, name %86
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x22 (ite (bvslt (bvadd in.02_32 (_ bv1 32)) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x103 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x66 (or false false (or $x103))))
(let (($x87 (or $x66 false false)))
(and (not $x87) (or $x87 (and (distinct ?x22 ?x22) true))))))))
(check-sat)
; query 16: function kernel_nussinov, block 87, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x76 (and (distinct (bvsub ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvsub in.01_32 (_ bv1 32)))) true)))
(let (($x123 (or false false (or $x76))))
(and (not $x123) (or $x123 (and (distinct (bvsub in.01_32 (_ bv1 32)) (bvsub in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 17: function kernel_nussinov, block 87, name %89
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x65 (ite (bvslt in.02_32 (bvsub in.01_32 (_ bv1 32))) (_ bv1 1) (_ bv0 1))))
(let (($x76 (and (distinct (bvsub ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvsub in.01_32 (_ bv1 32)))) true)))
(let (($x123 (or false false (or $x76))))
(let (($x70 (or false $x123 false)))
(and (not $x70) (or $x70 (and (distinct ?x65 ?x65) true))))))))
(check-sat)
; query 18: function kernel_nussinov, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x26 (and (distinct (bvsub ((_ sign_extend 1) in0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvsub in0_32 (_ bv1 32)))) true)))
(let (($x68 (or false false (or $x26))))
(and (not $x68) (or $x68 (and (distinct (bvsub in0_32 (_ bv1 32)) (bvsub in0_32 (_ bv1 32))) true))))))
(check-sat)
; query 19: function polybench_flush_cache, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x225 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x229 (or false false (or $x225))))
(and (not $x229) (or $x229 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 20: function print_array, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x225 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x229 (or false false (or $x225))))
(and (not $x229) (or $x229 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 21: function print_array, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x103 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x66 (or false false (or $x103))))
(and (not $x66) (or $x66 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 22: function xmalloc, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in7_32 () (_ BitVec 32))
(assert
 (let ((?x119 (ite (and (distinct (_ bv0 32) in7_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x47 (or false false false)))
(and (not $x47) (or $x47 (and (distinct ?x119 ?x119) true))))))
(check-sat)
