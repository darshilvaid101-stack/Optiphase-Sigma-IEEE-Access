; OptiPhase-Sigma refinement certificate for sweep K41-R4-320
; query 0: function set_key, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let (($x86 (or false false false)))
(and (not $x86) (or $x86 (and (distinct (bvand in1_64 (_ bv7 64)) (bvand in1_64 (_ bv7 64))) true)))))
(check-sat)
; query 1: function set_key, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x384 (ite (and (distinct (_ bv0 64) (bvand in1_64 (_ bv7 64))) true) (_ bv1 1) (_ bv0 1))))
(let (($x86 (or false false false)))
(let (($x192 (or $x86 false false)))
(and (not $x192) (or $x192 (and (distinct ?x384 ?x384) true)))))))
(check-sat)
