; OptiPhase-Sigma refinement certificate for sweep K28-R3-190
