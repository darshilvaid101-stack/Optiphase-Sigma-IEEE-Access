; OptiPhase-Sigma refinement certificate for sweep K49-R6-015
; query 0: function Decoding_of_the_coded_Log_Area_Ratios, block 107, name %108
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in104_64 () (_ BitVec 64))
(assert
 (let ((?x362 (ite (bvslt (_ bv0 64) in104_64) (_ bv1 1) (_ bv0 1))))
(let (($x849 (or false false false)))
(let (($x1703 (not $x849)))
(and $x1703 (or $x849 (and (distinct ?x362 ?x362) true)))))))
(check-sat)
; query 1: function Decoding_of_the_coded_Log_Area_Ratios, block 107, name %109
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in104_64 () (_ BitVec 64))
(assert
 (let (($x319 (and (distinct ((_ zero_extend 63) (ite (bvslt (_ bv0 64) in104_64) (_ bv1 1) (_ bv0 1))) (ite (= (_ bv1 1) (ite (bvslt (_ bv0 64) in104_64) (_ bv1 1) (_ bv0 1))) (_ bv32767 64) (_ bv18446744073709518848 64))) true)))
(let (($x849 (or false false false)))
(let (($x258 (or $x849 (ite (= (_ bv1 1) (ite (bvslt (_ bv0 64) in104_64) (_ bv1 1) (_ bv0 1))) false false))))
(and (not (or $x849 false)) (or $x258 $x319))))))
(check-sat)
; query 2: function Decoding_of_the_coded_Log_Area_Ratios, block 219, name %220
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in216_64 () (_ BitVec 64))
(assert
 (let (($x2402 (and (distinct (ite (bvsge (_ bv18446744073709518848 64) in216_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv0 64) in216_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x849 (or false false false)))
(let (($x1703 (not $x849)))
(and $x1703 (or $x849 $x2402))))))
(check-sat)
; query 3: function gsm_L_add, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let (($x1586 (and (distinct (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv18446744073709551615 64) in1_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x849 (or false false false)))
(let (($x1703 (not $x849)))
(and $x1703 (or $x849 $x1586))))))
(check-sat)
; query 4: function gsm_L_add, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x259 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvadd in0_64 in1_64))) true)))
(let (($x1464 (or false false (or $x259))))
(let (($x1156 (or $x1464 (and (distinct (bvadd in0_64 in1_64) (bvadd in0_64 in1_64)) true))))
(and (not $x1464) $x1156)))))
(check-sat)
; query 5: function gsm_L_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x97 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x849 (or false false false)))
(let (($x1703 (not $x849)))
(and $x1703 (or $x849 (and (distinct ?x97 ?x97) true)))))))
(check-sat)
; query 6: function gsm_L_asl, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x921 (and (distinct (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvsgt (_ bv4294967265 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x849 (or false false false)))
(let (($x1703 (not $x849)))
(and $x1703 (or $x849 $x921))))))
(check-sat)
; query 7: function gsm_L_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x777 (and (distinct (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv31 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x849 (or false false false)))
(let (($x1703 (not $x849)))
(and $x1703 (or $x849 $x777))))))
(check-sat)
; query 8: function gsm_L_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x777 (and (distinct (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv31 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x849 (or false false false)))
(let (($x1703 (not $x849)))
(and $x1703 (or $x849 $x777))))))
(check-sat)
; query 9: function gsm_L_sub, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x72 (bvsub in0_64 in1_64)))
(let (($x83 (and (distinct ?x72 ?x72) true)))
(let (($x321 (and (distinct (bvsub ((_ zero_extend 1) in0_64) ((_ zero_extend 1) in1_64)) ((_ zero_extend 1) ?x72)) true)))
(let (($x1066 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) ?x72)) true)))
(let (($x287 (or false false (or $x1066))))
(let (($x450 (not $x287)))
(and $x450 (or (or false false (or $x321)) $x83)))))))))
(check-sat)
; query 10: function gsm_L_sub, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let (($x1586 (and (distinct (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv18446744073709551615 64) in1_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x849 (or false false false)))
(let (($x1703 (not $x849)))
(and $x1703 (or $x849 $x1586))))))
(check-sat)
; query 11: function gsm_L_sub, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x72 (bvsub in0_64 in1_64)))
(let (($x83 (and (distinct ?x72 ?x72) true)))
(let (($x1066 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) ?x72)) true)))
(let (($x287 (or false false (or $x1066))))
(let (($x450 (not $x287)))
(and $x450 (or $x287 $x83))))))))
(check-sat)
; query 12: function gsm_L_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x534 (and (distinct (ite (bvsle (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv18446744073709551615 64) in0_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x849 (or false false false)))
(let (($x1703 (not $x849)))
(and $x1703 (or $x849 $x534))))))
(check-sat)
; query 13: function gsm_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_64 () (_ BitVec 64))
(assert
 (let ((?x62 (ite (bvslt (_ bv32767 64) in5_64) (_ bv1 1) (_ bv0 1))))
(let (($x849 (or false false false)))
(let (($x1703 (not $x849)))
(and $x1703 (or $x849 (and (distinct ?x62 ?x62) true)))))))
(check-sat)
; query 14: function gsm_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x132 (or false false)))
(let (($x546 (not $x132)))
(and $x546 (or $x132 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 15: function gsm_add, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x132 (or false false)))
(let (($x546 (not $x132)))
(and $x546 (or $x132 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 16: function gsm_add, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1046 ((_ sign_extend 48) in1_16)))
(let ((?x765 ((_ sign_extend 48) in0_16)))
(let ((?x497 (bvadd ?x765 ?x1046)))
(let (($x545 (and (distinct (bvadd ((_ sign_extend 1) ?x765) ((_ sign_extend 1) ?x1046)) ((_ sign_extend 1) ?x497)) true)))
(let (($x132 (or false false)))
(let (($x130 (or $x132 $x132 (or $x545))))
(and (not $x130) (or $x130 (and (distinct ?x497 ?x497) true))))))))))
(check-sat)
; query 17: function gsm_add, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x333 (ite (bvsgt (_ bv18446744073709518848 64) (bvadd ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x1046 ((_ sign_extend 48) in1_16)))
(let ((?x622 ((_ sign_extend 1) ?x1046)))
(let ((?x765 ((_ sign_extend 48) in0_16)))
(let ((?x190 ((_ sign_extend 1) ?x765)))
(let (($x132 (or false false)))
(let (($x130 (or $x132 $x132 (or (and (distinct (bvadd ?x190 ?x622) ((_ sign_extend 1) (bvadd ?x765 ?x1046))) true)))))
(let (($x7 (or $x130 false false)))
(and (not $x7) (or $x7 (and (distinct ?x333 ?x333) true))))))))))))
(check-sat)
; query 18: function gsm_asl, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x473 (and (distinct (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvsgt (_ bv4294967281 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x849 (or false false false)))
(let (($x1703 (not $x849)))
(and $x1703 (or $x849 $x473))))))
(check-sat)
; query 19: function gsm_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x168 (and (distinct (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv15 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x849 (or false false false)))
(let (($x1703 (not $x849)))
(and $x1703 (or $x849 $x168))))))
(check-sat)
; query 20: function gsm_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x168 (and (distinct (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv15 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x849 (or false false false)))
(let (($x1703 (not $x849)))
(and $x1703 (or $x849 $x168))))))
(check-sat)
; query 21: function gsm_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_64 () (_ BitVec 64))
(assert
 (let ((?x62 (ite (bvslt (_ bv32767 64) in5_64) (_ bv1 1) (_ bv0 1))))
(let (($x849 (or false false false)))
(let (($x1703 (not $x849)))
(and $x1703 (or $x849 (and (distinct ?x62 ?x62) true)))))))
(check-sat)
; query 22: function gsm_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x132 (or false false)))
(let (($x546 (not $x132)))
(and $x546 (or $x132 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 23: function gsm_sub, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x132 (or false false)))
(let (($x546 (not $x132)))
(and $x546 (or $x132 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 24: function gsm_sub, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1046 ((_ sign_extend 48) in1_16)))
(let ((?x765 ((_ sign_extend 48) in0_16)))
(let ((?x1374 (bvsub ?x765 ?x1046)))
(let (($x1894 (and (distinct (bvsub ((_ sign_extend 1) ?x765) ((_ sign_extend 1) ?x1046)) ((_ sign_extend 1) ?x1374)) true)))
(let (($x132 (or false false)))
(let (($x707 (or $x132 $x132 (or $x1894))))
(and (not $x707) (or $x707 (and (distinct ?x1374 ?x1374) true))))))))))
(check-sat)
; query 25: function gsm_sub, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1469 (ite (bvsgt (_ bv18446744073709518848 64) (bvsub ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x1046 ((_ sign_extend 48) in1_16)))
(let ((?x622 ((_ sign_extend 1) ?x1046)))
(let ((?x765 ((_ sign_extend 48) in0_16)))
(let ((?x190 ((_ sign_extend 1) ?x765)))
(let (($x132 (or false false)))
(let (($x707 (or $x132 $x132 (or (and (distinct (bvsub ?x190 ?x622) ((_ sign_extend 1) (bvsub ?x765 ?x1046))) true)))))
(let (($x660 (or $x707 false false)))
(and (not $x660) (or $x660 (and (distinct ?x1469 ?x1469) true))))))))))))
(check-sat)
