; OptiPhase-Sigma refinement certificate for sweep K16-R4-364
