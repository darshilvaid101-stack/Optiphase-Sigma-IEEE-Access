; OptiPhase-Sigma refinement certificate for sweep K58-R3-279
; query 0: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x121 (or false false false)))
(let (($x57 (not $x121)))
(and $x57 (or $x121 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x7026 (bvadd in.01_32 (_ bv1 32))))
(let ((?x188 (bvmul ?x7026 (_ bv8 32))))
(let ((?x128 (bvmul ?x7026 ?x7026)))
(let (($x121 (or false false false)))
(let (($x104 (or $x121 false false)))
(and (not (or $x121 $x121 false)) (or $x104 (and (distinct ?x128 ?x188) true)))))))))
(check-sat)
; query 2: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x1161 (and (distinct (bvmul (bvmul (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) (_ bv2 32)) (bvmul (bvmul (bvadd in.01_32 (_ bv1 32)) (_ bv8 32)) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x121 (or false false false)))
(let (($x104 (or $x121 false false)))
(and (not (or (or $x121 $x121 false) false false)) (or (or $x104 $x121 false) $x1161))))))
(check-sat)
; query 3: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x67 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x121 (or false false false)))
(let (($x57 (not $x121)))
(and $x57 (or $x121 (and (distinct ?x67 ?x67) true)))))))
(check-sat)
; query 4: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x145 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x121 (or false false false)))
(let (($x57 (not $x121)))
(and $x57 (or $x121 (and (distinct ?x145 ?x145) true)))))))
(check-sat)
; query 5: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x121 (or false false false)))
(let (($x57 (not $x121)))
(and $x57 (or $x121 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 6: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x173 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x4371 (or false false (or $x173))))
(and (not $x4371) (or $x4371 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 7: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x685 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x121 (or false false false)))
(let (($x57 (not $x121)))
(and $x57 (or $x121 (and (distinct ?x685 ?x685) true)))))))
(check-sat)
; query 8: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x43 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x121 (or false false false)))
(let (($x57 (not $x121)))
(and $x57 (or $x121 (and (distinct ?x43 ?x43) true)))))))
(check-sat)
; query 9: function matrix_add_const, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x121 (or false false false)))
(let (($x57 (not $x121)))
(and $x57 (or $x121 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 10: function matrix_add_const, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x121 (or false false false)))
(let (($x57 (not $x121)))
(and $x57 (or $x121 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 11: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x544 (or false false)))
(and (not $x544) (or $x544 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true)))))
(check-sat)
; query 12: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x220 ((_ sign_extend 16) in.1_16)))
(let ((?x3171 (bvadd ?x220 (_ bv10 32))))
(let (($x2716 (and (distinct (bvadd ((_ sign_extend 1) ?x220) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x3171)) true)))
(let (($x544 (or false false)))
(let (($x51 (or $x544 false (or $x2716))))
(and (not $x51) (or $x51 (and (distinct ?x3171 ?x3171) true)))))))))
(check-sat)
; query 13: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x220 ((_ sign_extend 16) in.1_16)))
(let ((?x3171 (bvadd ?x220 (_ bv10 32))))
(let ((?x96 ((_ extract 15 0) ?x3171)))
(let (($x2716 (and (distinct (bvadd ((_ sign_extend 1) ?x220) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x3171)) true)))
(let (($x544 (or false false)))
(let (($x51 (or $x544 false (or $x2716))))
(let (($x33 (or $x51 false)))
(and (not $x33) (or $x33 (and (distinct ?x96 ?x96) true)))))))))))
(check-sat)
; query 14: function run_crc_loop, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x121 (or false false false)))
(let (($x57 (not $x121)))
(and $x57 (or $x121 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
