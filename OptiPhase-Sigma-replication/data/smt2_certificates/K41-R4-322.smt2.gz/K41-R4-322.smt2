; OptiPhase-Sigma refinement certificate for sweep K41-R4-322
; query 0: function set_key, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let (($x38 (or false false false)))
(and (not $x38) (or $x38 (and (distinct (bvand in1_64 (_ bv7 64)) (bvand in1_64 (_ bv7 64))) true)))))
(check-sat)
; query 1: function set_key, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x59 (ite (and (distinct (_ bv0 64) (bvand in1_64 (_ bv7 64))) true) (_ bv1 1) (_ bv0 1))))
(let (($x38 (or false false false)))
(let (($x93 (or $x38 false false)))
(and (not $x93) (or $x93 (and (distinct ?x59 ?x59) true)))))))
(check-sat)
