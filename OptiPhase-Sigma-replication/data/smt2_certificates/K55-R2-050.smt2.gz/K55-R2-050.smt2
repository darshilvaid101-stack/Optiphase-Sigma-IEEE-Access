; OptiPhase-Sigma refinement certificate for sweep K55-R2-050
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x142 (or false false)))
(let (($x279 (not $x142)))
(and $x279 (or $x142 (and (distinct ((_ sign_extend 16) in25_16) ((_ sign_extend 16) in25_16)) true))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let ((?x454 (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))))
(let (($x142 (or false false)))
(let (($x1909 (or $x142 false false)))
(let (($x183 (not $x1909)))
(and $x183 (or $x1909 (and (distinct ?x454 ?x454) true))))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x142 (or false false)))
(let (($x279 (not $x142)))
(and $x279 (or $x142 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x411 ((_ sign_extend 16) in3_16)))
(let ((?x84 (bvand ?x411 (_ bv127 32))))
(let (($x142 (or false false)))
(let (($x1909 (or $x142 false false)))
(let (($x183 (not $x1909)))
(and $x183 (or $x1909 (and (distinct ?x84 ?x84) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x411 ((_ sign_extend 16) in3_16)))
(let ((?x84 (bvand ?x411 (_ bv127 32))))
(let ((?x202 ((_ extract 15 0) ?x84)))
(let (($x142 (or false false)))
(let (($x1909 (or $x142 false false)))
(let (($x95 (or $x1909 false)))
(let (($x1679 (not $x95)))
(and $x1679 (or $x95 (and (distinct ?x202 ?x202) true)))))))))))
(check-sat)
; query 5: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x142 (or false false)))
(let (($x279 (not $x142)))
(and $x279 (or $x142 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 6: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x1919 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x142 (or false false)))
(let (($x1909 (or $x142 false false)))
(let (($x183 (not $x1909)))
(and $x183 (or $x1909 (and (distinct ?x1919 ?x1919) true))))))))
(check-sat)
; query 7: function core_bench_list, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x71 (or false false false)))
(let (($x243 (not $x71)))
(and $x243 (or $x71 (and (distinct (bvadd in.0_16 (_ bv1 16)) (bvadd in.0_16 (_ bv1 16))) true))))))
(check-sat)
; query 8: function core_bench_list, block 82, name %83
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let (($x142 (or false false)))
(let (($x279 (not $x142)))
(and $x279 (or $x142 (and (distinct ((_ zero_extend 16) in.02_16) ((_ zero_extend 16) in.02_16)) true))))))
(check-sat)
; query 9: function core_bench_list, block 82, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x1899 ((_ zero_extend 16) in.02_16)))
(let ((?x333 (bvmul ?x1899 (_ bv4 32))))
(let (($x217 (and (distinct (bvmul ((_ sign_extend 32) ?x1899) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x333)) true)))
(let (($x142 (or false false)))
(let (($x851 (or $x142 false (or $x217))))
(and (not $x851) (or $x851 (and (distinct ?x333 ?x333) true)))))))))
(check-sat)
; query 10: function core_bench_list, block 82, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let (($x142 (or false false)))
(let (($x279 (not $x142)))
(and $x279 (or $x142 (and (distinct ((_ zero_extend 16) in.04_16) ((_ zero_extend 16) in.04_16)) true))))))
(check-sat)
; query 11: function core_bench_list, block 82, name %86
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x85 ((_ zero_extend 16) in.04_16)))
(let ((?x1899 ((_ zero_extend 16) in.02_16)))
(let ((?x333 (bvmul ?x1899 (_ bv4 32))))
(let ((?x158 (bvsub ?x333 ?x85)))
(let ((?x18 ((_ sign_extend 1) ?x158)))
(let (($x142 (or false false)))
(let (($x217 (and (distinct (bvmul ((_ sign_extend 32) ?x1899) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x333)) true)))
(let (($x851 (or $x142 false (or $x217))))
(let (($x149 (or $x851 $x142 (or (and (distinct (bvsub ((_ sign_extend 1) ?x333) ((_ sign_extend 1) ?x85)) ?x18) true)))))
(and (not $x149) (or $x149 (and (distinct ?x158 ?x158) true)))))))))))))
(check-sat)
; query 12: function core_bench_list, block 82, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x142 (or false false)))
(let (($x279 (not $x142)))
(and $x279 (or $x142 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 13: function core_bench_list, block 82, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x85 ((_ zero_extend 16) in.04_16)))
(let ((?x1899 ((_ zero_extend 16) in.02_16)))
(let ((?x333 (bvmul ?x1899 (_ bv4 32))))
(let ((?x158 (bvsub ?x333 ?x85)))
(let ((?x76 ((_ zero_extend 16) in.01_16)))
(let ((?x24 (bvadd ?x76 ?x158)))
(let (($x192 (and (distinct (bvadd ((_ sign_extend 1) ?x76) ((_ sign_extend 1) ?x158)) ((_ sign_extend 1) ?x24)) true)))
(let ((?x18 ((_ sign_extend 1) ?x158)))
(let (($x142 (or false false)))
(let (($x217 (and (distinct (bvmul ((_ sign_extend 32) ?x1899) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x333)) true)))
(let (($x851 (or $x142 false (or $x217))))
(let (($x149 (or $x851 $x142 (or (and (distinct (bvsub ((_ sign_extend 1) ?x333) ((_ sign_extend 1) ?x85)) ?x18) true)))))
(let (($x168 (or $x142 $x149 (or $x192))))
(and (not $x168) (or $x168 (and (distinct ?x24 ?x24) true)))))))))))))))))
(check-sat)
; query 14: function core_bench_list, block 82, name %89
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x85 ((_ zero_extend 16) in.04_16)))
(let ((?x1899 ((_ zero_extend 16) in.02_16)))
(let ((?x333 (bvmul ?x1899 (_ bv4 32))))
(let ((?x158 (bvsub ?x333 ?x85)))
(let ((?x76 ((_ zero_extend 16) in.01_16)))
(let ((?x24 (bvadd ?x76 ?x158)))
(let ((?x384 ((_ extract 15 0) ?x24)))
(let (($x192 (and (distinct (bvadd ((_ sign_extend 1) ?x76) ((_ sign_extend 1) ?x158)) ((_ sign_extend 1) ?x24)) true)))
(let ((?x18 ((_ sign_extend 1) ?x158)))
(let (($x142 (or false false)))
(let (($x217 (and (distinct (bvmul ((_ sign_extend 32) ?x1899) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x333)) true)))
(let (($x851 (or $x142 false (or $x217))))
(let (($x149 (or $x851 $x142 (or (and (distinct (bvsub ((_ sign_extend 1) ?x333) ((_ sign_extend 1) ?x85)) ?x18) true)))))
(let (($x168 (or $x142 $x149 (or $x192))))
(let (($x51 (or $x168 false)))
(and (not $x51) (or $x51 (and (distinct ?x384 ?x384) true)))))))))))))))))))
(check-sat)
; query 15: function core_bench_list, block 82, name %90
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x142 (or false false)))
(let (($x279 (not $x142)))
(and $x279 (or $x142 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 16: function core_bench_list, block 82, name %91
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x141 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x142 (or false false)))
(let (($x1909 (or $x142 false false)))
(let (($x183 (not $x1909)))
(and $x183 (or $x1909 (and (distinct ?x141 ?x141) true))))))))
(check-sat)
; query 17: function core_bench_state, block 105, name %106
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x71 (or false false false)))
(let (($x243 (not $x71)))
(and $x243 (or $x71 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 18: function core_bench_state, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x71 (or false false false)))
(let (($x243 (not $x71)))
(and $x243 (or $x71 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 19: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x509 (bvadd in.01_32 (_ bv1 32))))
(let (($x386 (and (distinct ?x509 ?x509) true)))
(let (($x71 (or false false false)))
(let (($x243 (not $x71)))
(and $x243 (or $x71 $x386)))))))
(check-sat)
; query 20: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x509 (bvadd in.01_32 (_ bv1 32))))
(let ((?x35 (bvmul ?x509 ?x509)))
(let (($x71 (or false false false)))
(let (($x210 (or $x71 $x71 false)))
(and (not $x210) (or $x210 (and (distinct ?x35 ?x35) true))))))))
(check-sat)
; query 21: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x509 (bvadd in.01_32 (_ bv1 32))))
(let ((?x35 (bvmul ?x509 ?x509)))
(let ((?x262 (bvmul ?x35 (_ bv2 32))))
(let (($x71 (or false false false)))
(let (($x210 (or $x71 $x71 false)))
(let (($x96 (or $x210 false false)))
(and (not $x96) (or $x96 (and (distinct ?x262 ?x262) true))))))))))
(check-sat)
; query 22: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x509 (bvadd in.01_32 (_ bv1 32))))
(let ((?x35 (bvmul ?x509 ?x509)))
(let ((?x262 (bvmul ?x35 (_ bv2 32))))
(let ((?x229 (bvmul ?x262 (_ bv4 32))))
(let (($x71 (or false false false)))
(let (($x210 (or $x71 $x71 false)))
(let (($x96 (or $x210 false false)))
(let (($x173 (or $x96 false false)))
(and (not $x173) (or $x173 (and (distinct ?x229 ?x229) true))))))))))))
(check-sat)
; query 23: function core_init_matrix, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x71 (or false false false)))
(let (($x243 (not $x71)))
(and $x243 (or $x71 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 24: function core_init_matrix, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x71 (or false false false)))
(let (($x243 (not $x71)))
(and $x243 (or $x71 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 25: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x146 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x71 (or false false false)))
(let (($x243 (not $x71)))
(and $x243 (or $x71 (and (distinct ?x146 ?x146) true)))))))
(check-sat)
; query 26: function core_init_state, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_32 () (_ BitVec 32))
(assert
 (let (($x71 (or false false false)))
(let (($x243 (not $x71)))
(and $x243 (or $x71 (and (distinct (bvadd in.06_32 (_ bv1 32)) (bvadd in.06_32 (_ bv1 32))) true))))))
(check-sat)
; query 27: function core_init_state, block 65, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let (($x71 (or false false false)))
(let (($x243 (not $x71)))
(and $x243 (or $x71 (and (distinct (bvadd in4_32 (_ bv1 32)) (bvadd in4_32 (_ bv1 32))) true))))))
(check-sat)
; query 28: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x339 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x71 (or false false false)))
(let (($x243 (not $x71)))
(and $x243 (or $x71 (and (distinct ?x339 ?x339) true)))))))
(check-sat)
; query 29: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x71 (or false false false)))
(let (($x243 (not $x71)))
(and $x243 (or $x71 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 30: function core_list_init, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x509 (bvadd in.01_32 (_ bv1 32))))
(let (($x386 (and (distinct ?x509 ?x509) true)))
(let (($x71 (or false false false)))
(let (($x243 (not $x71)))
(and $x243 (or $x71 $x386)))))))
(check-sat)
; query 31: function core_list_mergesort, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x509 (bvadd in.01_32 (_ bv1 32))))
(let (($x386 (and (distinct ?x509 ?x509) true)))
(let (($x10 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x509)) true)))
(let (($x90 (or false false (or $x10))))
(and (not $x90) (or $x90 $x386)))))))
(check-sat)
; query 32: function core_list_mergesort, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x130 (ite (bvslt (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x71 (or false false false)))
(let (($x243 (not $x71)))
(and $x243 (or $x71 (and (distinct ?x130 ?x130) true)))))))
(check-sat)
; query 33: function core_list_mergesort, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.224_32 () (_ BitVec 32))
(assert
 (let ((?x175 (ite (= (_ bv0 32) in.224_32) (_ bv1 1) (_ bv0 1))))
(let (($x71 (or false false false)))
(let (($x243 (not $x71)))
(and $x243 (or $x71 (and (distinct ?x175 ?x175) true)))))))
(check-sat)
; query 34: function core_list_mergesort, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x74 (ite (= (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x71 (or false false false)))
(let (($x243 (not $x71)))
(and $x243 (or $x71 (and (distinct ?x74 ?x74) true)))))))
(check-sat)
; query 35: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x219 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x235 (or false false (or $x219))))
(and (not $x235) (or $x235 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 36: function core_list_mergesort, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x1967 (and (distinct (bvmul ((_ sign_extend 32) in.020_32) ((_ sign_extend 32) (_ bv2 32))) ((_ sign_extend 32) (bvmul in.020_32 (_ bv2 32)))) true)))
(let (($x6 (or false false (or $x1967))))
(and (not $x6) (or $x6 (and (distinct (bvmul in.020_32 (_ bv2 32)) (bvmul in.020_32 (_ bv2 32))) true))))))
(check-sat)
; query 37: function core_state_transition, block 102, name %103
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x142 (or false false)))
(let (($x279 (not $x142)))
(and $x279 (or $x142 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 38: function core_state_transition, block 102, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x2079 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x142 (or false false)))
(let (($x1909 (or $x142 false false)))
(let (($x183 (not $x1909)))
(and $x183 (or $x1909 (and (distinct ?x2079 ?x2079) true))))))))
(check-sat)
; query 39: function core_state_transition, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x142 (or false false)))
(let (($x279 (not $x142)))
(and $x279 (or $x142 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 40: function core_state_transition, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x45 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x142 (or false false)))
(let (($x1909 (or $x142 false false)))
(let (($x183 (not $x1909)))
(and $x183 (or $x1909 (and (distinct ?x45 ?x45) true))))))))
(check-sat)
; query 41: function core_state_transition, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x142 (or false false)))
(let (($x279 (not $x142)))
(and $x279 (or $x142 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 42: function core_state_transition, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x2079 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x142 (or false false)))
(let (($x1909 (or $x142 false false)))
(let (($x183 (not $x1909)))
(and $x183 (or $x1909 (and (distinct ?x2079 ?x2079) true))))))))
(check-sat)
; query 43: function core_state_transition, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x142 (or false false)))
(let (($x279 (not $x142)))
(and $x279 (or $x142 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 44: function core_state_transition, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1071 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x142 (or false false)))
(let (($x1909 (or $x142 false false)))
(let (($x183 (not $x1909)))
(and $x183 (or $x1909 (and (distinct ?x1071 ?x1071) true))))))))
(check-sat)
; query 45: function core_state_transition, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x142 (or false false)))
(let (($x279 (not $x142)))
(and $x279 (or $x142 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 46: function core_state_transition, block 51, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1071 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x142 (or false false)))
(let (($x1909 (or $x142 false false)))
(let (($x183 (not $x1909)))
(and $x183 (or $x1909 (and (distinct ?x1071 ?x1071) true))))))))
(check-sat)
; query 47: function core_state_transition, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x142 (or false false)))
(let (($x279 (not $x142)))
(and $x279 (or $x142 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 48: function core_state_transition, block 64, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1071 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x142 (or false false)))
(let (($x1909 (or $x142 false false)))
(let (($x183 (not $x1909)))
(and $x183 (or $x1909 (and (distinct ?x1071 ?x1071) true))))))))
(check-sat)
; query 49: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x1791 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x71 (or false false false)))
(let (($x243 (not $x71)))
(and $x243 (or $x71 (and (distinct ?x1791 ?x1791) true)))))))
(check-sat)
; query 50: function core_state_transition, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x142 (or false false)))
(let (($x279 (not $x142)))
(and $x279 (or $x142 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 51: function core_state_transition, block 80, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x674 (ite (= (_ bv69 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x142 (or false false)))
(let (($x1909 (or $x142 false false)))
(let (($x183 (not $x1909)))
(and $x183 (or $x1909 (and (distinct ?x674 ?x674) true))))))))
(check-sat)
; query 52: function core_state_transition, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x142 (or false false)))
(let (($x279 (not $x142)))
(and $x279 (or $x142 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 53: function core_state_transition, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1491 (ite (= (_ bv101 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x142 (or false false)))
(let (($x1909 (or $x142 false false)))
(let (($x183 (not $x1909)))
(and $x183 (or $x1909 (and (distinct ?x1491 ?x1491) true))))))))
(check-sat)
; query 54: function core_state_transition, block 99, name %100
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x142 (or false false)))
(let (($x279 (not $x142)))
(and $x279 (or $x142 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 55: function core_state_transition, block 99, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x45 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x142 (or false false)))
(let (($x1909 (or $x142 false false)))
(let (($x183 (not $x1909)))
(and $x183 (or $x1909 (and (distinct ?x45 ?x45) true))))))))
(check-sat)
; query 56: function crcu8, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x142 (or false false)))
(let (($x279 (not $x142)))
(and $x279 (or $x142 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 57: function crcu8, block 19, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x76 ((_ zero_extend 16) in.01_16)))
(let ((?x1903 (bvxor ?x76 (_ bv16386 32))))
(let (($x142 (or false false)))
(let (($x1909 (or $x142 false false)))
(let (($x183 (not $x1909)))
(and $x183 (or $x1909 (and (distinct ?x1903 ?x1903) true)))))))))
(check-sat)
; query 58: function crcu8, block 19, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x76 ((_ zero_extend 16) in.01_16)))
(let ((?x1903 (bvxor ?x76 (_ bv16386 32))))
(let ((?x1809 ((_ extract 15 0) ?x1903)))
(let (($x142 (or false false)))
(let (($x1909 (or $x142 false false)))
(let (($x95 (or $x1909 false)))
(let (($x1679 (not $x95)))
(and $x1679 (or $x95 (and (distinct ?x1809 ?x1809) true)))))))))))
(check-sat)
; query 59: function crcu8, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x142 (or false false)))
(let (($x279 (not $x142)))
(and $x279 (or $x142 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 60: function crcu8, block 29, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x109 ((_ zero_extend 16) in27_16)))
(let ((?x506 (bvor ?x109 (_ bv32768 32))))
(let (($x142 (or false false)))
(let (($x1909 (or $x142 false false)))
(let (($x183 (not $x1909)))
(and $x183 (or $x1909 (and (distinct ?x506 ?x506) true)))))))))
(check-sat)
; query 61: function crcu8, block 29, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x109 ((_ zero_extend 16) in27_16)))
(let ((?x506 (bvor ?x109 (_ bv32768 32))))
(let ((?x1789 ((_ extract 15 0) ?x506)))
(let (($x142 (or false false)))
(let (($x1909 (or $x142 false false)))
(let (($x95 (or $x1909 false)))
(let (($x1679 (not $x95)))
(and $x1679 (or $x95 (and (distinct ?x1789 ?x1789) true)))))))))))
(check-sat)
; query 62: function crcu8, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x142 (or false false)))
(let (($x279 (not $x142)))
(and $x279 (or $x142 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 63: function crcu8, block 33, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x109 ((_ zero_extend 16) in27_16)))
(let ((?x1240 (bvand ?x109 (_ bv32767 32))))
(let (($x142 (or false false)))
(let (($x1909 (or $x142 false false)))
(let (($x183 (not $x1909)))
(and $x183 (or $x1909 (and (distinct ?x1240 ?x1240) true)))))))))
(check-sat)
; query 64: function crcu8, block 33, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x109 ((_ zero_extend 16) in27_16)))
(let ((?x1240 (bvand ?x109 (_ bv32767 32))))
(let ((?x1569 ((_ extract 15 0) ?x1240)))
(let (($x142 (or false false)))
(let (($x1909 (or $x142 false false)))
(let (($x95 (or $x1909 false)))
(let (($x1679 (not $x95)))
(and $x1679 (or $x95 (and (distinct ?x1569 ?x1569) true)))))))))))
(check-sat)
; query 65: function crcu8, block 38, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_8 () (_ BitVec 8))
(assert
 (let (($x71 (or false false false)))
(let (($x243 (not $x71)))
(and $x243 (or $x71 (and (distinct (bvadd in.02_8 (_ bv1 8)) (bvadd in.02_8 (_ bv1 8))) true))))))
(check-sat)
; query 66: function crcu8, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x952 ((_ extract 7 0) in.01_16)))
(let ((?x337 ((_ zero_extend 24) ?x952)))
(let (($x142 (or false false)))
(let (($x883 (or $x142 false)))
(and (not $x883) (or $x883 (and (distinct ?x337 ?x337) true))))))))
(check-sat)
; query 67: function crcu8, block 6, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x952 ((_ extract 7 0) in.01_16)))
(let ((?x337 ((_ zero_extend 24) ?x952)))
(let ((?x1904 (bvand ?x337 (_ bv1 32))))
(let (($x142 (or false false)))
(let (($x883 (or $x142 false)))
(let (($x2051 (or $x883 false false)))
(and (not $x2051) (or $x2051 (and (distinct ?x1904 ?x1904) true))))))))))
(check-sat)
; query 68: function crcu8, block 6, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x952 ((_ extract 7 0) in.01_16)))
(let ((?x337 ((_ zero_extend 24) ?x952)))
(let ((?x1904 (bvand ?x337 (_ bv1 32))))
(let ((?x20 ((_ zero_extend 24) in.0_8)))
(let ((?x1475 (bvand ?x20 (_ bv1 32))))
(let ((?x1853 (bvxor ?x1475 ?x1904)))
(let (($x142 (or false false)))
(let (($x883 (or $x142 false)))
(let (($x2051 (or $x883 false false)))
(let (($x1909 (or $x142 false false)))
(let (($x1635 (or $x1909 $x2051 false)))
(and (not $x1635) (or $x1635 (and (distinct ?x1853 ?x1853) true)))))))))))))))
(check-sat)
; query 69: function crcu8, block 6, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x952 ((_ extract 7 0) in.01_16)))
(let ((?x337 ((_ zero_extend 24) ?x952)))
(let ((?x1904 (bvand ?x337 (_ bv1 32))))
(let ((?x20 ((_ zero_extend 24) in.0_8)))
(let ((?x1475 (bvand ?x20 (_ bv1 32))))
(let ((?x1853 (bvxor ?x1475 ?x1904)))
(let ((?x1651 ((_ extract 7 0) ?x1853)))
(let (($x142 (or false false)))
(let (($x883 (or $x142 false)))
(let (($x2051 (or $x883 false false)))
(let (($x1909 (or $x142 false false)))
(let (($x1635 (or $x1909 $x2051 false)))
(let (($x400 (or $x1635 false)))
(and (not $x400) (or $x400 (and (distinct ?x1651 ?x1651) true)))))))))))))))))
(check-sat)
; query 70: function crcu8, block 6, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x142 (or false false)))
(let (($x279 (not $x142)))
(and $x279 (or $x142 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 71: function crcu8, block 6, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x20 ((_ zero_extend 24) in.0_8)))
(let ((?x1883 (bvashr ?x20 (_ bv1 32))))
(let (($x142 (or false false)))
(let (($x1909 (or $x142 false false)))
(let (($x1857 (or $x1909 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not $x1857) (or $x1857 (and (distinct ?x1883 ?x1883) true)))))))))
(check-sat)
; query 72: function crcu8, block 6, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x20 ((_ zero_extend 24) in.0_8)))
(let ((?x1883 (bvashr ?x20 (_ bv1 32))))
(let ((?x1140 ((_ extract 7 0) ?x1883)))
(let (($x142 (or false false)))
(let (($x1909 (or $x142 false false)))
(let (($x1857 (or $x1909 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x5599 (or $x1857 false)))
(and (not $x5599) (or $x5599 (and (distinct ?x1140 ?x1140) true)))))))))))
(check-sat)
; query 73: function crcu8, block 6, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x952 ((_ extract 7 0) in.01_16)))
(let ((?x337 ((_ zero_extend 24) ?x952)))
(let ((?x1904 (bvand ?x337 (_ bv1 32))))
(let ((?x20 ((_ zero_extend 24) in.0_8)))
(let ((?x1475 (bvand ?x20 (_ bv1 32))))
(let ((?x1853 (bvxor ?x1475 ?x1904)))
(let ((?x1651 ((_ extract 7 0) ?x1853)))
(let ((?x1877 ((_ zero_extend 24) ?x1651)))
(let (($x142 (or false false)))
(let (($x883 (or $x142 false)))
(let (($x2051 (or $x883 false false)))
(let (($x1909 (or $x142 false false)))
(let (($x1635 (or $x1909 $x2051 false)))
(let (($x400 (or $x1635 false)))
(let (($x1051 (or $x400 false)))
(and (not $x1051) (or $x1051 (and (distinct ?x1877 ?x1877) true)))))))))))))))))))
(check-sat)
; query 74: function crcu8, block 6, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x952 ((_ extract 7 0) in.01_16)))
(let ((?x337 ((_ zero_extend 24) ?x952)))
(let ((?x1904 (bvand ?x337 (_ bv1 32))))
(let ((?x20 ((_ zero_extend 24) in.0_8)))
(let ((?x1475 (bvand ?x20 (_ bv1 32))))
(let ((?x1853 (bvxor ?x1475 ?x1904)))
(let ((?x1651 ((_ extract 7 0) ?x1853)))
(let ((?x1877 ((_ zero_extend 24) ?x1651)))
(let ((?x1908 (ite (= (_ bv1 32) ?x1877) (_ bv1 1) (_ bv0 1))))
(let (($x142 (or false false)))
(let (($x883 (or $x142 false)))
(let (($x2051 (or $x883 false false)))
(let (($x1909 (or $x142 false false)))
(let (($x1635 (or $x1909 $x2051 false)))
(let (($x400 (or $x1635 false)))
(let (($x1051 (or $x400 false)))
(let (($x1823 (or $x1051 false false)))
(and (not $x1823) (or $x1823 (and (distinct ?x1908 ?x1908) true)))))))))))))))))))))
(check-sat)
; query 75: function crcu8, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x142 (or false false)))
(let (($x279 (not $x142)))
(and $x279 (or $x142 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 76: function crcu8, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x20 ((_ zero_extend 24) in.0_8)))
(let ((?x1475 (bvand ?x20 (_ bv1 32))))
(let (($x142 (or false false)))
(let (($x1909 (or $x142 false false)))
(let (($x183 (not $x1909)))
(and $x183 (or $x1909 (and (distinct ?x1475 ?x1475) true)))))))))
(check-sat)
; query 77: function crcu8, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x142 (or false false)))
(let (($x279 (not $x142)))
(and $x279 (or $x142 (and (distinct ((_ extract 7 0) in.01_16) ((_ extract 7 0) in.01_16)) true))))))
(check-sat)
; query 78: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1931 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x558 ((_ zero_extend 31) ?x1931)))
(let ((?x871 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1678 ((_ zero_extend 31) ?x871)))
(let ((?x91 (bvand ?x1678 ?x558)))
(let ((?x5119 (ite (and (distinct (_ bv0 32) ?x91) true) (_ bv1 1) (_ bv0 1))))
(let ((?x617 ((_ zero_extend 63) ?x5119)))
(let (($x142 (or false false)))
(let (($x1909 (or $x142 false false)))
(let (($x95 (or $x1909 false)))
(let (($x106 (or $x95 $x95 false)))
(let (($x1987 (or $x106 false false)))
(let (($x1453 (or $x1987 false)))
(and (not $x1453) (or $x1453 (and (distinct ?x617 ?x617) true)))))))))))))))))
(check-sat)
; query 79: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1931 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x558 ((_ zero_extend 31) ?x1931)))
(let ((?x871 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1678 ((_ zero_extend 31) ?x871)))
(let ((?x91 (bvand ?x1678 ?x558)))
(let ((?x5119 (ite (and (distinct (_ bv0 32) ?x91) true) (_ bv1 1) (_ bv0 1))))
(let (($x300 (= (_ bv1 1) ?x5119)))
(let ((?x115 (ite $x300 (_ bv1 32) (_ bv0 32))))
(let (($x142 (or false false)))
(let (($x1909 (or $x142 false false)))
(let (($x95 (or $x1909 false)))
(let (($x106 (or $x95 $x95 false)))
(let (($x1987 (or $x106 false false)))
(let (($x1556 (or $x1987 (ite $x300 false false))))
(and (not $x1556) (or $x1556 (and (distinct ?x115 ?x115) true))))))))))))))))))
(check-sat)
; query 80: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1931 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x558 ((_ zero_extend 31) ?x1931)))
(let ((?x871 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1678 ((_ zero_extend 31) ?x871)))
(let ((?x91 (bvand ?x1678 ?x558)))
(let ((?x5119 (ite (and (distinct (_ bv0 32) ?x91) true) (_ bv1 1) (_ bv0 1))))
(let (($x300 (= (_ bv1 1) ?x5119)))
(let ((?x115 (ite $x300 (_ bv1 32) (_ bv0 32))))
(let ((?x354 ((_ extract 7 0) ?x115)))
(let (($x142 (or false false)))
(let (($x1909 (or $x142 false false)))
(let (($x95 (or $x1909 false)))
(let (($x106 (or $x95 $x95 false)))
(let (($x1987 (or $x106 false false)))
(let (($x1556 (or $x1987 (ite $x300 false false))))
(let (($x1959 (or $x1556 false)))
(and (not $x1959) (or $x1959 (and (distinct ?x354 ?x354) true))))))))))))))))))))
(check-sat)
; query 81: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x142 (or false false)))
(let (($x279 (not $x142)))
(and $x279 (or $x142 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 82: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x871 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x142 (or false false)))
(let (($x1909 (or $x142 false false)))
(let (($x183 (not $x1909)))
(and $x183 (or $x1909 (and (distinct ?x871 ?x871) true))))))))
(check-sat)
; query 83: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x871 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1678 ((_ zero_extend 31) ?x871)))
(let (($x142 (or false false)))
(let (($x1909 (or $x142 false false)))
(let (($x95 (or $x1909 false)))
(let (($x1679 (not $x95)))
(and $x1679 (or $x95 (and (distinct ?x1678 ?x1678) true))))))))))
(check-sat)
; query 84: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x142 (or false false)))
(let (($x279 (not $x142)))
(and $x279 (or $x142 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 85: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1931 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x142 (or false false)))
(let (($x1909 (or $x142 false false)))
(let (($x183 (not $x1909)))
(and $x183 (or $x1909 (and (distinct ?x1931 ?x1931) true))))))))
(check-sat)
; query 86: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1931 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x558 ((_ zero_extend 31) ?x1931)))
(let (($x142 (or false false)))
(let (($x1909 (or $x142 false false)))
(let (($x95 (or $x1909 false)))
(let (($x1679 (not $x95)))
(and $x1679 (or $x95 (and (distinct ?x558 ?x558) true))))))))))
(check-sat)
; query 87: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1931 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x558 ((_ zero_extend 31) ?x1931)))
(let ((?x871 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1678 ((_ zero_extend 31) ?x871)))
(let ((?x91 (bvand ?x1678 ?x558)))
(let (($x142 (or false false)))
(let (($x1909 (or $x142 false false)))
(let (($x95 (or $x1909 false)))
(let (($x106 (or $x95 $x95 false)))
(and (not $x106) (or $x106 (and (distinct ?x91 ?x91) true)))))))))))))
(check-sat)
; query 88: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1931 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x558 ((_ zero_extend 31) ?x1931)))
(let ((?x871 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1678 ((_ zero_extend 31) ?x871)))
(let ((?x91 (bvand ?x1678 ?x558)))
(let ((?x5119 (ite (and (distinct (_ bv0 32) ?x91) true) (_ bv1 1) (_ bv0 1))))
(let (($x142 (or false false)))
(let (($x1909 (or $x142 false false)))
(let (($x95 (or $x1909 false)))
(let (($x106 (or $x95 $x95 false)))
(let (($x1987 (or $x106 false false)))
(and (not $x1987) (or $x1987 (and (distinct ?x5119 ?x5119) true)))))))))))))))
(check-sat)
; query 89: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1599 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x71 (or false false false)))
(let (($x243 (not $x71)))
(and $x243 (or $x71 (and (distinct ?x1599 ?x1599) true)))))))
(check-sat)
; query 90: function matrix_add_const, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x71 (or false false false)))
(let (($x243 (not $x71)))
(and $x243 (or $x71 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 91: function matrix_add_const, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x509 (bvadd in.01_32 (_ bv1 32))))
(let (($x386 (and (distinct ?x509 ?x509) true)))
(let (($x71 (or false false false)))
(let (($x243 (not $x71)))
(and $x243 (or $x71 $x386)))))))
(check-sat)
; query 92: function matrix_mul_const, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x71 (or false false false)))
(let (($x243 (not $x71)))
(and $x243 (or $x71 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 93: function matrix_mul_const, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x509 (bvadd in.01_32 (_ bv1 32))))
(let (($x386 (and (distinct ?x509 ?x509) true)))
(let (($x71 (or false false false)))
(let (($x243 (not $x71)))
(and $x243 (or $x71 $x386)))))))
(check-sat)
; query 94: function matrix_mul_matrix, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x71 (or false false false)))
(let (($x243 (not $x71)))
(and $x243 (or $x71 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 95: function matrix_mul_matrix, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x509 (bvadd in.01_32 (_ bv1 32))))
(let (($x386 (and (distinct ?x509 ?x509) true)))
(let (($x71 (or false false false)))
(let (($x243 (not $x71)))
(and $x243 (or $x71 $x386)))))))
(check-sat)
; query 96: function matrix_mul_matrix, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x71 (or false false false)))
(let (($x243 (not $x71)))
(and $x243 (or $x71 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 97: function matrix_mul_matrix_bitextract, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x71 (or false false false)))
(let (($x243 (not $x71)))
(and $x243 (or $x71 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 98: function matrix_mul_matrix_bitextract, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x509 (bvadd in.01_32 (_ bv1 32))))
(let (($x386 (and (distinct ?x509 ?x509) true)))
(let (($x71 (or false false false)))
(let (($x243 (not $x71)))
(and $x243 (or $x71 $x386)))))))
(check-sat)
; query 99: function matrix_mul_matrix_bitextract, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x71 (or false false false)))
(let (($x243 (not $x71)))
(and $x243 (or $x71 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 100: function matrix_mul_vect, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x71 (or false false false)))
(let (($x243 (not $x71)))
(and $x243 (or $x71 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 101: function matrix_mul_vect, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x509 (bvadd in.01_32 (_ bv1 32))))
(let (($x386 (and (distinct ?x509 ?x509) true)))
(let (($x71 (or false false false)))
(let (($x243 (not $x71)))
(and $x243 (or $x71 $x386)))))))
(check-sat)
; query 102: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x142 (or false false)))
(let (($x279 (not $x142)))
(and $x279 (or $x142 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 103: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x1808 ((_ sign_extend 16) in.1_16)))
(let ((?x963 (bvadd ?x1808 (_ bv10 32))))
(let (($x208 (and (distinct (bvadd ((_ sign_extend 1) ?x1808) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x963)) true)))
(let (($x142 (or false false)))
(let (($x1778 (or $x142 false (or $x208))))
(and (not $x1778) (or $x1778 (and (distinct ?x963 ?x963) true)))))))))
(check-sat)
; query 104: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x1808 ((_ sign_extend 16) in.1_16)))
(let ((?x963 (bvadd ?x1808 (_ bv10 32))))
(let ((?x1607 ((_ extract 15 0) ?x963)))
(let (($x208 (and (distinct (bvadd ((_ sign_extend 1) ?x1808) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x963)) true)))
(let (($x142 (or false false)))
(let (($x1778 (or $x142 false (or $x208))))
(let (($x717 (or $x1778 false)))
(and (not $x717) (or $x717 (and (distinct ?x1607 ?x1607) true)))))))))))
(check-sat)
; query 105: function matrix_sum, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x1220 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x71 (or false false false)))
(let (($x243 (not $x71)))
(and $x243 (or $x71 (and (distinct ?x1220 ?x1220) true)))))))
(check-sat)
; query 106: function matrix_sum, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x1220 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let ((?x1661 ((_ zero_extend 63) ?x1220)))
(let (($x71 (or false false false)))
(let (($x1652 (or $x71 false)))
(and (not $x1652) (or $x1652 (and (distinct ?x1661 ?x1661) true))))))))
(check-sat)
; query 107: function matrix_sum, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x1220 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x1925 (= (_ bv1 1) ?x1220)))
(let ((?x1210 (ite $x1925 (_ bv1 32) (_ bv0 32))))
(let (($x71 (or false false false)))
(let (($x1532 (or $x71 (ite $x1925 false false))))
(and (not $x1532) (or $x1532 (and (distinct ?x1210 ?x1210) true)))))))))
(check-sat)
; query 108: function matrix_sum, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x142 (or false false)))
(let (($x279 (not $x142)))
(and $x279 (or $x142 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 109: function matrix_sum, block 22, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x1220 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x1925 (= (_ bv1 1) ?x1220)))
(let ((?x1210 (ite $x1925 (_ bv1 32) (_ bv0 32))))
(let ((?x1808 ((_ sign_extend 16) in.1_16)))
(let ((?x738 (bvadd ?x1808 ?x1210)))
(let (($x1541 (and (distinct (bvadd ((_ sign_extend 1) ?x1808) ((_ sign_extend 1) ?x1210)) ((_ sign_extend 1) ?x738)) true)))
(let (($x71 (or false false false)))
(let (($x1532 (or $x71 (ite $x1925 false false))))
(let (($x142 (or false false)))
(let (($x1752 (or $x142 $x1532 (or $x1541))))
(and (not $x1752) (or $x1752 (and (distinct ?x738 ?x738) true))))))))))))))
(check-sat)
; query 110: function matrix_sum, block 22, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x1220 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x1925 (= (_ bv1 1) ?x1220)))
(let ((?x1210 (ite $x1925 (_ bv1 32) (_ bv0 32))))
(let ((?x1808 ((_ sign_extend 16) in.1_16)))
(let ((?x738 (bvadd ?x1808 ?x1210)))
(let ((?x666 ((_ extract 15 0) ?x738)))
(let (($x1541 (and (distinct (bvadd ((_ sign_extend 1) ?x1808) ((_ sign_extend 1) ?x1210)) ((_ sign_extend 1) ?x738)) true)))
(let (($x71 (or false false false)))
(let (($x1532 (or $x71 (ite $x1925 false false))))
(let (($x142 (or false false)))
(let (($x1752 (or $x142 $x1532 (or $x1541))))
(let (($x554 (or $x1752 false)))
(and (not $x554) (or $x554 (and (distinct ?x666 ?x666) true))))))))))))))))
(check-sat)
; query 111: function matrix_sum, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x71 (or false false false)))
(let (($x243 (not $x71)))
(and $x243 (or $x71 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 112: function matrix_sum, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x509 (bvadd in.01_32 (_ bv1 32))))
(let (($x386 (and (distinct ?x509 ?x509) true)))
(let (($x71 (or false false false)))
(let (($x243 (not $x71)))
(and $x243 (or $x71 $x386)))))))
(check-sat)
; query 113: function parseval, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.23_32 () (_ BitVec 32))
(assert
 (let (($x2245 (and (distinct (bvmul ((_ sign_extend 32) in.23_32) ((_ sign_extend 32) (_ bv1024 32))) ((_ sign_extend 32) (bvmul in.23_32 (_ bv1024 32)))) true)))
(let (($x1590 (or false false (or $x2245))))
(and (not $x1590) (or $x1590 (and (distinct (bvmul in.23_32 (_ bv1024 32)) (bvmul in.23_32 (_ bv1024 32))) true))))))
(check-sat)
; query 114: function parseval, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.34_32 () (_ BitVec 32))
(assert
 (let (($x2044 (and (distinct (bvmul ((_ sign_extend 32) in.34_32) ((_ sign_extend 32) (_ bv1048576 32))) ((_ sign_extend 32) (bvmul in.34_32 (_ bv1048576 32)))) true)))
(let (($x5779 (or false false (or $x2044))))
(and (not $x5779) (or $x5779 (and (distinct (bvmul in.34_32 (_ bv1048576 32)) (bvmul in.34_32 (_ bv1048576 32))) true))))))
(check-sat)
; query 115: function partition_memory, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x71 (or false false false)))
(let (($x243 (not $x71)))
(and $x243 (or $x71 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
