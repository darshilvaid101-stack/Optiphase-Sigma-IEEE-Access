; OptiPhase-Sigma refinement certificate for sweep K37-R3-302
; query 0: function bit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x21 (and (distinct (bvsub ((_ sign_extend 1) (_ bv31 32)) ((_ sign_extend 1) in0_32)) ((_ sign_extend 1) (bvsub (_ bv31 32) in0_32))) true)))
(let (($x18 (or false false (or $x21))))
(and (not $x18) (or $x18 (and (distinct (bvsub (_ bv31 32) in0_32) (bvsub (_ bv31 32) in0_32)) true))))))
(check-sat)
; query 1: function bit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x187 (bvsub (_ bv31 32) in0_32)))
(let ((?x108 (bvshl (_ bv1 32) ?x187)))
(let (($x14 (bvuge ?x187 (_ bv32 32))))
(let (($x21 (and (distinct (bvsub ((_ sign_extend 1) (_ bv31 32)) ((_ sign_extend 1) in0_32)) ((_ sign_extend 1) ?x187)) true)))
(let (($x18 (or false false (or $x21))))
(let (($x126 (or (or false $x18 (or (and (distinct (_ bv1 32) (bvlshr ?x108 ?x187)) true))) $x14)))
(and (not (or (or false $x18 false) $x14)) (or $x126 (and (distinct ?x108 ?x108) true))))))))))
(check-sat)
; query 2: function bit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x187 (bvsub (_ bv31 32) in0_32)))
(let ((?x108 (bvshl (_ bv1 32) ?x187)))
(let ((?x249 ((_ sign_extend 32) ?x108)))
(let (($x14 (bvuge ?x187 (_ bv32 32))))
(let (($x21 (and (distinct (bvsub ((_ sign_extend 1) (_ bv31 32)) ((_ sign_extend 1) in0_32)) ((_ sign_extend 1) ?x187)) true)))
(let (($x18 (or false false (or $x21))))
(let (($x126 (or (or false $x18 (or (and (distinct (_ bv1 32) (bvlshr ?x108 ?x187)) true))) $x14)))
(let (($x160 (or $x126 false)))
(and (not (or (or (or false $x18 false) $x14) false)) (or $x160 (and (distinct ?x249 ?x249) true))))))))))))
(check-sat)
; query 3: function bit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x187 (bvsub (_ bv31 32) in0_32)))
(let ((?x108 (bvshl (_ bv1 32) ?x187)))
(let ((?x249 ((_ sign_extend 32) ?x108)))
(let ((?x25 (bvand in1_64 ?x249)))
(let (($x14 (bvuge ?x187 (_ bv32 32))))
(let (($x21 (and (distinct (bvsub ((_ sign_extend 1) (_ bv31 32)) ((_ sign_extend 1) in0_32)) ((_ sign_extend 1) ?x187)) true)))
(let (($x18 (or false false (or $x21))))
(let (($x126 (or (or false $x18 (or (and (distinct (_ bv1 32) (bvlshr ?x108 ?x187)) true))) $x14)))
(let (($x160 (or $x126 false)))
(let (($x198 (not (or false (or (or (or false $x18 false) $x14) false) false))))
(and $x198 (or (or false $x160 false) (and (distinct ?x25 ?x25) true))))))))))))))
(check-sat)
