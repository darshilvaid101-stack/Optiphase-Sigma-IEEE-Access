; OptiPhase-Sigma refinement certificate for sweep K54-R3-132
; query 0: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x42008 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x223 (or false false false)))
(let (($x430 (not $x223)))
(and $x430 (or $x223 (and (distinct ?x42008 ?x42008) true)))))))
(check-sat)
; query 1: function set1d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x267 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x223 (or false false false)))
(let (($x430 (not $x223)))
(and $x430 (or $x223 (and (distinct ?x267 ?x267) true)))))))
(check-sat)
; query 2: function set1ds, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x320 (ite (= (_ bv4294967295 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x223 (or false false false)))
(let (($x430 (not $x223)))
(and $x430 (or $x223 (and (distinct ?x320 ?x320) true)))))))
(check-sat)
; query 3: function set2d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x267 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x223 (or false false false)))
(let (($x430 (not $x223)))
(and $x430 (or $x223 (and (distinct ?x267 ?x267) true)))))))
(check-sat)
