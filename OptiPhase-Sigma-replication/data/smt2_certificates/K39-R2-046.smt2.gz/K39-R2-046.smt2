; OptiPhase-Sigma refinement certificate for sweep K39-R2-046
; query 0: function BF_cbc_encrypt, block 126, name %127
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.010_64 () (_ BitVec 64))
(assert
 (let (($x683 (and (distinct (bvsub ((_ sign_extend 1) in.010_64) ((_ sign_extend 1) (_ bv8 64))) ((_ sign_extend 1) (bvsub in.010_64 (_ bv8 64)))) true)))
(let (($x109 (or false false (or $x683))))
(and (not $x109) (or $x109 (and (distinct (bvsub in.010_64 (_ bv8 64)) (bvsub in.010_64 (_ bv8 64))) true))))))
(check-sat)
; query 1: function BF_cbc_encrypt, block 366, name %367
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.111_64 () (_ BitVec 64))
(assert
 (let (($x14 (and (distinct (bvsub ((_ sign_extend 1) in.111_64) ((_ sign_extend 1) (_ bv8 64))) ((_ sign_extend 1) (bvsub in.111_64 (_ bv8 64)))) true)))
(let (($x225 (or false false (or $x14))))
(and (not $x225) (or $x225 (and (distinct (bvsub in.111_64 (_ bv8 64)) (bvsub in.111_64 (_ bv8 64))) true))))))
(check-sat)
; query 2: function BF_cfb64_encrypt, block 111, name %112
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.18_32 () (_ BitVec 32))
(assert
 (let ((?x200 (ite (= (_ bv0 32) in.18_32) (_ bv1 1) (_ bv0 1))))
(let (($x135 (or false false false)))
(let (($x291 (not $x135)))
(and $x291 (or $x135 (and (distinct ?x200 ?x200) true)))))))
(check-sat)
; query 3: function BF_cfb64_encrypt, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.07_32 () (_ BitVec 32))
(assert
 (let ((?x297 (ite (= (_ bv0 32) in.07_32) (_ bv1 1) (_ bv0 1))))
(let (($x135 (or false false false)))
(let (($x291 (not $x135)))
(and $x291 (or $x135 (and (distinct ?x297 ?x297) true)))))))
(check-sat)
; query 4: function BF_ofb64_encrypt, block 82, name %83
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x296 (ite (= (_ bv0 32) in.04_32) (_ bv1 1) (_ bv0 1))))
(let (($x135 (or false false false)))
(let (($x291 (not $x135)))
(and $x291 (or $x135 (and (distinct ?x296 ?x296) true)))))))
(check-sat)
; query 5: function main, block 124, name %125
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let ((?x57 (ite (bvsgt (_ bv40 32) in.2_32) (_ bv1 1) (_ bv0 1))))
(let (($x135 (or false false false)))
(let (($x291 (not $x135)))
(and $x291 (or $x135 (and (distinct ?x57 ?x57) true)))))))
(check-sat)
; query 6: function main, block 147, name %148
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x74 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x68 (or false false (or $x74))))
(and (not $x68) (or $x68 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 7: function main, block 60, name %61
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x94 (or false false)))
(and (not $x94) (or $x94 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 8: function main, block 60, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x125 (ite (bvsge (_ bv57 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x94 (or false false)))
(let (($x130 (or $x94 false false)))
(let (($x93 (not $x130)))
(and $x93 (or $x130 (and (distinct ?x125 ?x125) true))))))))
(check-sat)
; query 9: function main, block 63, name %64
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x135 (or false false false)))
(let (($x187 (or $x135 (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x187) (or $x187 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvshl in.01_32 (_ bv4 32))) true))))))
(check-sat)
; query 10: function main, block 63, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x94 (or false false)))
(and (not $x94) (or $x94 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 11: function main, block 63, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x162 ((_ sign_extend 24) in57_8)))
(let ((?x137 (bvshl in.01_32 (_ bv4 32))))
(let ((?x188 (bvadd ?x137 ?x162)))
(let ((?x77 ((_ sign_extend 1) ?x188)))
(let (($x94 (or false false)))
(let (($x135 (or false false false)))
(let (($x187 (or $x135 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x65 (or $x187 $x94 (or (and (distinct (bvadd ((_ sign_extend 1) ?x137) ((_ sign_extend 1) ?x162)) ?x77) true)))))
(and (not $x65) (or $x65 (and (distinct ?x188 ?x188) true))))))))))))
(check-sat)
; query 12: function main, block 63, name %67
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x162 ((_ sign_extend 24) in57_8)))
(let ((?x137 (bvshl in.01_32 (_ bv4 32))))
(let ((?x188 (bvadd ?x137 ?x162)))
(let ((?x6 (bvsub ?x188 (_ bv48 32))))
(let (($x173 (and (distinct (bvsub ((_ sign_extend 1) ?x188) ((_ sign_extend 1) (_ bv48 32))) ((_ sign_extend 1) ?x6)) true)))
(let ((?x77 ((_ sign_extend 1) ?x188)))
(let (($x94 (or false false)))
(let (($x135 (or false false false)))
(let (($x187 (or $x135 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x65 (or $x187 $x94 (or (and (distinct (bvadd ((_ sign_extend 1) ?x137) ((_ sign_extend 1) ?x162)) ?x77) true)))))
(let (($x191 (or $x65 false (or $x173))))
(and (not $x191) (or $x191 (and (distinct ?x6 ?x6) true)))))))))))))))
(check-sat)
; query 13: function main, block 68, name %69
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x94 (or false false)))
(and (not $x94) (or $x94 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 14: function main, block 68, name %70
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x36 (ite (bvsle (_ bv65 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x94 (or false false)))
(let (($x130 (or $x94 false false)))
(let (($x93 (not $x130)))
(and $x93 (or $x130 (and (distinct ?x36 ?x36) true))))))))
(check-sat)
; query 15: function main, block 71, name %72
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x94 (or false false)))
(and (not $x94) (or $x94 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 16: function main, block 71, name %73
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x22 (ite (bvsge (_ bv70 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x94 (or false false)))
(let (($x130 (or $x94 false false)))
(let (($x93 (not $x130)))
(and $x93 (or $x130 (and (distinct ?x22 ?x22) true))))))))
(check-sat)
; query 17: function main, block 74, name %75
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x135 (or false false false)))
(let (($x187 (or $x135 (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x187) (or $x187 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvshl in.01_32 (_ bv4 32))) true))))))
(check-sat)
; query 18: function main, block 74, name %76
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x94 (or false false)))
(and (not $x94) (or $x94 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 19: function main, block 74, name %77
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x162 ((_ sign_extend 24) in57_8)))
(let ((?x137 (bvshl in.01_32 (_ bv4 32))))
(let ((?x188 (bvadd ?x137 ?x162)))
(let ((?x77 ((_ sign_extend 1) ?x188)))
(let (($x94 (or false false)))
(let (($x135 (or false false false)))
(let (($x187 (or $x135 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x65 (or $x187 $x94 (or (and (distinct (bvadd ((_ sign_extend 1) ?x137) ((_ sign_extend 1) ?x162)) ?x77) true)))))
(and (not $x65) (or $x65 (and (distinct ?x188 ?x188) true))))))))))))
(check-sat)
; query 20: function main, block 74, name %78
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x162 ((_ sign_extend 24) in57_8)))
(let ((?x137 (bvshl in.01_32 (_ bv4 32))))
(let ((?x188 (bvadd ?x137 ?x162)))
(let ((?x197 (bvsub ?x188 (_ bv65 32))))
(let ((?x159 ((_ sign_extend 1) ?x197)))
(let ((?x77 ((_ sign_extend 1) ?x188)))
(let (($x94 (or false false)))
(let (($x135 (or false false false)))
(let (($x187 (or $x135 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x65 (or $x187 $x94 (or (and (distinct (bvadd ((_ sign_extend 1) ?x137) ((_ sign_extend 1) ?x162)) ?x77) true)))))
(let (($x103 (or $x65 false (or (and (distinct (bvsub ?x77 ((_ sign_extend 1) (_ bv65 32))) ?x159) true)))))
(and (not $x103) (or $x103 (and (distinct ?x197 ?x197) true)))))))))))))))
(check-sat)
; query 21: function main, block 74, name %79
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x162 ((_ sign_extend 24) in57_8)))
(let ((?x137 (bvshl in.01_32 (_ bv4 32))))
(let ((?x188 (bvadd ?x137 ?x162)))
(let ((?x197 (bvsub ?x188 (_ bv65 32))))
(let ((?x44 (bvadd ?x197 (_ bv10 32))))
(let (($x180 (and (distinct (bvadd ((_ sign_extend 1) ?x197) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x44)) true)))
(let ((?x159 ((_ sign_extend 1) ?x197)))
(let ((?x77 ((_ sign_extend 1) ?x188)))
(let (($x94 (or false false)))
(let (($x135 (or false false false)))
(let (($x187 (or $x135 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x65 (or $x187 $x94 (or (and (distinct (bvadd ((_ sign_extend 1) ?x137) ((_ sign_extend 1) ?x162)) ?x77) true)))))
(let (($x103 (or $x65 false (or (and (distinct (bvsub ?x77 ((_ sign_extend 1) (_ bv65 32))) ?x159) true)))))
(let (($x122 (or $x103 false (or $x180))))
(and (not $x122) (or $x122 (and (distinct ?x44 ?x44) true))))))))))))))))))
(check-sat)
