; OptiPhase-Sigma refinement certificate for sweep K58-R2-006
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x908 (or false false)))
(let (($x30 (not $x908)))
(and $x30 (or $x908 (and (distinct ((_ sign_extend 16) in25_16) ((_ sign_extend 16) in25_16)) true))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let ((?x1874 (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))))
(let (($x908 (or false false)))
(let (($x84 (or $x908 false false)))
(let (($x159 (not $x84)))
(and $x159 (or $x84 (and (distinct ?x1874 ?x1874) true))))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x908 (or false false)))
(let (($x30 (not $x908)))
(and $x30 (or $x908 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x172 ((_ sign_extend 16) in3_16)))
(let ((?x29 (bvand ?x172 (_ bv127 32))))
(let (($x908 (or false false)))
(let (($x84 (or $x908 false false)))
(let (($x159 (not $x84)))
(and $x159 (or $x84 (and (distinct ?x29 ?x29) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x172 ((_ sign_extend 16) in3_16)))
(let ((?x29 (bvand ?x172 (_ bv127 32))))
(let ((?x1899 ((_ extract 15 0) ?x29)))
(let (($x908 (or false false)))
(let (($x84 (or $x908 false false)))
(let (($x85 (or $x84 false)))
(let (($x206 (not $x85)))
(and $x206 (or $x85 (and (distinct ?x1899 ?x1899) true)))))))))))
(check-sat)
; query 5: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x908 (or false false)))
(let (($x30 (not $x908)))
(and $x30 (or $x908 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 6: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x616 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x908 (or false false)))
(let (($x84 (or $x908 false false)))
(let (($x159 (not $x84)))
(and $x159 (or $x84 (and (distinct ?x616 ?x616) true))))))))
(check-sat)
; query 7: function core_bench_list, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x441 (or false false false)))
(let (($x712 (not $x441)))
(and $x712 (or $x441 (and (distinct (bvadd in.0_16 (_ bv1 16)) (bvadd in.0_16 (_ bv1 16))) true))))))
(check-sat)
; query 8: function core_bench_list, block 82, name %83
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let (($x908 (or false false)))
(let (($x30 (not $x908)))
(and $x30 (or $x908 (and (distinct ((_ zero_extend 16) in.02_16) ((_ zero_extend 16) in.02_16)) true))))))
(check-sat)
; query 9: function core_bench_list, block 82, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x234 ((_ zero_extend 16) in.02_16)))
(let ((?x11 (bvmul ?x234 (_ bv4 32))))
(let (($x365 (and (distinct (bvmul ((_ sign_extend 32) ?x234) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x11)) true)))
(let (($x908 (or false false)))
(let (($x1098 (or $x908 false (or $x365))))
(and (not $x1098) (or $x1098 (and (distinct ?x11 ?x11) true)))))))))
(check-sat)
; query 10: function core_bench_list, block 82, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let (($x908 (or false false)))
(let (($x30 (not $x908)))
(and $x30 (or $x908 (and (distinct ((_ zero_extend 16) in.04_16) ((_ zero_extend 16) in.04_16)) true))))))
(check-sat)
; query 11: function core_bench_list, block 82, name %86
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x434 ((_ zero_extend 16) in.04_16)))
(let ((?x234 ((_ zero_extend 16) in.02_16)))
(let ((?x11 (bvmul ?x234 (_ bv4 32))))
(let ((?x821 (bvsub ?x11 ?x434)))
(let ((?x1679 ((_ sign_extend 1) ?x821)))
(let (($x908 (or false false)))
(let (($x365 (and (distinct (bvmul ((_ sign_extend 32) ?x234) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x11)) true)))
(let (($x1098 (or $x908 false (or $x365))))
(let (($x328 (or $x1098 $x908 (or (and (distinct (bvsub ((_ sign_extend 1) ?x11) ((_ sign_extend 1) ?x434)) ?x1679) true)))))
(and (not $x328) (or $x328 (and (distinct ?x821 ?x821) true)))))))))))))
(check-sat)
; query 12: function core_bench_list, block 82, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x908 (or false false)))
(let (($x30 (not $x908)))
(and $x30 (or $x908 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 13: function core_bench_list, block 82, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x434 ((_ zero_extend 16) in.04_16)))
(let ((?x234 ((_ zero_extend 16) in.02_16)))
(let ((?x11 (bvmul ?x234 (_ bv4 32))))
(let ((?x821 (bvsub ?x11 ?x434)))
(let ((?x507 ((_ zero_extend 16) in.01_16)))
(let ((?x1889 (bvadd ?x507 ?x821)))
(let (($x65 (and (distinct (bvadd ((_ sign_extend 1) ?x507) ((_ sign_extend 1) ?x821)) ((_ sign_extend 1) ?x1889)) true)))
(let ((?x1679 ((_ sign_extend 1) ?x821)))
(let (($x908 (or false false)))
(let (($x365 (and (distinct (bvmul ((_ sign_extend 32) ?x234) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x11)) true)))
(let (($x1098 (or $x908 false (or $x365))))
(let (($x328 (or $x1098 $x908 (or (and (distinct (bvsub ((_ sign_extend 1) ?x11) ((_ sign_extend 1) ?x434)) ?x1679) true)))))
(let (($x232 (or $x908 $x328 (or $x65))))
(and (not $x232) (or $x232 (and (distinct ?x1889 ?x1889) true)))))))))))))))))
(check-sat)
; query 14: function core_bench_list, block 82, name %89
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x434 ((_ zero_extend 16) in.04_16)))
(let ((?x234 ((_ zero_extend 16) in.02_16)))
(let ((?x11 (bvmul ?x234 (_ bv4 32))))
(let ((?x821 (bvsub ?x11 ?x434)))
(let ((?x507 ((_ zero_extend 16) in.01_16)))
(let ((?x1889 (bvadd ?x507 ?x821)))
(let ((?x243 ((_ extract 15 0) ?x1889)))
(let (($x65 (and (distinct (bvadd ((_ sign_extend 1) ?x507) ((_ sign_extend 1) ?x821)) ((_ sign_extend 1) ?x1889)) true)))
(let ((?x1679 ((_ sign_extend 1) ?x821)))
(let (($x908 (or false false)))
(let (($x365 (and (distinct (bvmul ((_ sign_extend 32) ?x234) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x11)) true)))
(let (($x1098 (or $x908 false (or $x365))))
(let (($x328 (or $x1098 $x908 (or (and (distinct (bvsub ((_ sign_extend 1) ?x11) ((_ sign_extend 1) ?x434)) ?x1679) true)))))
(let (($x232 (or $x908 $x328 (or $x65))))
(let (($x1422 (or $x232 false)))
(and (not $x1422) (or $x1422 (and (distinct ?x243 ?x243) true)))))))))))))))))))
(check-sat)
; query 15: function core_bench_list, block 82, name %90
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x908 (or false false)))
(let (($x30 (not $x908)))
(and $x30 (or $x908 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 16: function core_bench_list, block 82, name %91
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x76 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x908 (or false false)))
(let (($x84 (or $x908 false false)))
(let (($x159 (not $x84)))
(and $x159 (or $x84 (and (distinct ?x76 ?x76) true))))))))
(check-sat)
; query 17: function core_bench_state, block 105, name %106
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x441 (or false false false)))
(let (($x712 (not $x441)))
(and $x712 (or $x441 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 18: function core_bench_state, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x441 (or false false false)))
(let (($x712 (not $x441)))
(and $x712 (or $x441 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 19: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x9000 (bvadd in.01_32 (_ bv1 32))))
(let (($x4450 (and (distinct ?x9000 ?x9000) true)))
(let (($x441 (or false false false)))
(let (($x712 (not $x441)))
(and $x712 (or $x441 $x4450)))))))
(check-sat)
; query 20: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x9000 (bvadd in.01_32 (_ bv1 32))))
(let ((?x362 (bvmul ?x9000 ?x9000)))
(let (($x441 (or false false false)))
(let (($x8722 (or $x441 $x441 false)))
(and (not $x8722) (or $x8722 (and (distinct ?x362 ?x362) true))))))))
(check-sat)
; query 21: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x9000 (bvadd in.01_32 (_ bv1 32))))
(let ((?x362 (bvmul ?x9000 ?x9000)))
(let ((?x229 (bvmul ?x362 (_ bv2 32))))
(let (($x441 (or false false false)))
(let (($x8722 (or $x441 $x441 false)))
(let (($x9439 (or $x8722 false false)))
(and (not $x9439) (or $x9439 (and (distinct ?x229 ?x229) true))))))))))
(check-sat)
; query 22: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x9000 (bvadd in.01_32 (_ bv1 32))))
(let ((?x362 (bvmul ?x9000 ?x9000)))
(let ((?x229 (bvmul ?x362 (_ bv2 32))))
(let ((?x86 (bvmul ?x229 (_ bv4 32))))
(let (($x441 (or false false false)))
(let (($x8722 (or $x441 $x441 false)))
(let (($x9439 (or $x8722 false false)))
(let (($x2953 (or $x9439 false false)))
(and (not $x2953) (or $x2953 (and (distinct ?x86 ?x86) true))))))))))))
(check-sat)
; query 23: function core_init_matrix, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x441 (or false false false)))
(let (($x712 (not $x441)))
(and $x712 (or $x441 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 24: function core_init_matrix, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x441 (or false false false)))
(let (($x712 (not $x441)))
(and $x712 (or $x441 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 25: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x8246 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x441 (or false false false)))
(let (($x712 (not $x441)))
(and $x712 (or $x441 (and (distinct ?x8246 ?x8246) true)))))))
(check-sat)
; query 26: function core_init_state, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_32 () (_ BitVec 32))
(assert
 (let (($x441 (or false false false)))
(let (($x712 (not $x441)))
(and $x712 (or $x441 (and (distinct (bvadd in.06_32 (_ bv1 32)) (bvadd in.06_32 (_ bv1 32))) true))))))
(check-sat)
; query 27: function core_init_state, block 65, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let (($x441 (or false false false)))
(let (($x712 (not $x441)))
(and $x712 (or $x441 (and (distinct (bvadd in4_32 (_ bv1 32)) (bvadd in4_32 (_ bv1 32))) true))))))
(check-sat)
; query 28: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x1004 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x441 (or false false false)))
(let (($x712 (not $x441)))
(and $x712 (or $x441 (and (distinct ?x1004 ?x1004) true)))))))
(check-sat)
; query 29: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x441 (or false false false)))
(let (($x712 (not $x441)))
(and $x712 (or $x441 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 30: function core_list_init, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x9000 (bvadd in.01_32 (_ bv1 32))))
(let (($x4450 (and (distinct ?x9000 ?x9000) true)))
(let (($x441 (or false false false)))
(let (($x712 (not $x441)))
(and $x712 (or $x441 $x4450)))))))
(check-sat)
; query 31: function core_list_mergesort, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x9000 (bvadd in.01_32 (_ bv1 32))))
(let (($x4450 (and (distinct ?x9000 ?x9000) true)))
(let (($x2014 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x9000)) true)))
(let (($x8668 (or false false (or $x2014))))
(and (not $x8668) (or $x8668 $x4450)))))))
(check-sat)
; query 32: function core_list_mergesort, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x6741 (ite (bvslt (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x441 (or false false false)))
(let (($x712 (not $x441)))
(and $x712 (or $x441 (and (distinct ?x6741 ?x6741) true)))))))
(check-sat)
; query 33: function core_list_mergesort, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.224_32 () (_ BitVec 32))
(assert
 (let ((?x5916 (ite (= (_ bv0 32) in.224_32) (_ bv1 1) (_ bv0 1))))
(let (($x441 (or false false false)))
(let (($x712 (not $x441)))
(and $x712 (or $x441 (and (distinct ?x5916 ?x5916) true)))))))
(check-sat)
; query 34: function core_list_mergesort, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x8301 (ite (= (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x441 (or false false false)))
(let (($x712 (not $x441)))
(and $x712 (or $x441 (and (distinct ?x8301 ?x8301) true)))))))
(check-sat)
; query 35: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x2879 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x8909 (or false false (or $x2879))))
(and (not $x8909) (or $x8909 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 36: function core_list_mergesort, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x2529 (and (distinct (bvmul ((_ sign_extend 32) in.020_32) ((_ sign_extend 32) (_ bv2 32))) ((_ sign_extend 32) (bvmul in.020_32 (_ bv2 32)))) true)))
(let (($x3481 (or false false (or $x2529))))
(and (not $x3481) (or $x3481 (and (distinct (bvmul in.020_32 (_ bv2 32)) (bvmul in.020_32 (_ bv2 32))) true))))))
(check-sat)
; query 37: function core_state_transition, block 102, name %103
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x908 (or false false)))
(let (($x30 (not $x908)))
(and $x30 (or $x908 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 38: function core_state_transition, block 102, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1353 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x908 (or false false)))
(let (($x84 (or $x908 false false)))
(let (($x159 (not $x84)))
(and $x159 (or $x84 (and (distinct ?x1353 ?x1353) true))))))))
(check-sat)
; query 39: function core_state_transition, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x908 (or false false)))
(let (($x30 (not $x908)))
(and $x30 (or $x908 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 40: function core_state_transition, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x7989 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x908 (or false false)))
(let (($x84 (or $x908 false false)))
(let (($x159 (not $x84)))
(and $x159 (or $x84 (and (distinct ?x7989 ?x7989) true))))))))
(check-sat)
; query 41: function core_state_transition, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x908 (or false false)))
(let (($x30 (not $x908)))
(and $x30 (or $x908 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 42: function core_state_transition, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1353 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x908 (or false false)))
(let (($x84 (or $x908 false false)))
(let (($x159 (not $x84)))
(and $x159 (or $x84 (and (distinct ?x1353 ?x1353) true))))))))
(check-sat)
; query 43: function core_state_transition, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x908 (or false false)))
(let (($x30 (not $x908)))
(and $x30 (or $x908 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 44: function core_state_transition, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x744 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x908 (or false false)))
(let (($x84 (or $x908 false false)))
(let (($x159 (not $x84)))
(and $x159 (or $x84 (and (distinct ?x744 ?x744) true))))))))
(check-sat)
; query 45: function core_state_transition, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x908 (or false false)))
(let (($x30 (not $x908)))
(and $x30 (or $x908 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 46: function core_state_transition, block 51, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x744 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x908 (or false false)))
(let (($x84 (or $x908 false false)))
(let (($x159 (not $x84)))
(and $x159 (or $x84 (and (distinct ?x744 ?x744) true))))))))
(check-sat)
; query 47: function core_state_transition, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x908 (or false false)))
(let (($x30 (not $x908)))
(and $x30 (or $x908 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 48: function core_state_transition, block 64, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x744 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x908 (or false false)))
(let (($x84 (or $x908 false false)))
(let (($x159 (not $x84)))
(and $x159 (or $x84 (and (distinct ?x744 ?x744) true))))))))
(check-sat)
; query 49: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x5837 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x441 (or false false false)))
(let (($x712 (not $x441)))
(and $x712 (or $x441 (and (distinct ?x5837 ?x5837) true)))))))
(check-sat)
; query 50: function core_state_transition, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x908 (or false false)))
(let (($x30 (not $x908)))
(and $x30 (or $x908 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 51: function core_state_transition, block 80, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1513 (ite (= (_ bv69 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x908 (or false false)))
(let (($x84 (or $x908 false false)))
(let (($x159 (not $x84)))
(and $x159 (or $x84 (and (distinct ?x1513 ?x1513) true))))))))
(check-sat)
; query 52: function core_state_transition, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x908 (or false false)))
(let (($x30 (not $x908)))
(and $x30 (or $x908 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 53: function core_state_transition, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x4298 (ite (= (_ bv101 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x908 (or false false)))
(let (($x84 (or $x908 false false)))
(let (($x159 (not $x84)))
(and $x159 (or $x84 (and (distinct ?x4298 ?x4298) true))))))))
(check-sat)
; query 54: function core_state_transition, block 99, name %100
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x908 (or false false)))
(let (($x30 (not $x908)))
(and $x30 (or $x908 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 55: function core_state_transition, block 99, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x7989 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x908 (or false false)))
(let (($x84 (or $x908 false false)))
(let (($x159 (not $x84)))
(and $x159 (or $x84 (and (distinct ?x7989 ?x7989) true))))))))
(check-sat)
; query 56: function crcu8, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x908 (or false false)))
(let (($x30 (not $x908)))
(and $x30 (or $x908 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 57: function crcu8, block 19, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x507 ((_ zero_extend 16) in.01_16)))
(let ((?x8528 (bvxor ?x507 (_ bv16386 32))))
(let (($x908 (or false false)))
(let (($x84 (or $x908 false false)))
(let (($x159 (not $x84)))
(and $x159 (or $x84 (and (distinct ?x8528 ?x8528) true)))))))))
(check-sat)
; query 58: function crcu8, block 19, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x507 ((_ zero_extend 16) in.01_16)))
(let ((?x8528 (bvxor ?x507 (_ bv16386 32))))
(let ((?x9342 ((_ extract 15 0) ?x8528)))
(let (($x908 (or false false)))
(let (($x84 (or $x908 false false)))
(let (($x85 (or $x84 false)))
(let (($x206 (not $x85)))
(and $x206 (or $x85 (and (distinct ?x9342 ?x9342) true)))))))))))
(check-sat)
; query 59: function crcu8, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x908 (or false false)))
(let (($x30 (not $x908)))
(and $x30 (or $x908 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 60: function crcu8, block 29, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x5115 ((_ zero_extend 16) in27_16)))
(let ((?x7786 (bvor ?x5115 (_ bv32768 32))))
(let (($x908 (or false false)))
(let (($x84 (or $x908 false false)))
(let (($x159 (not $x84)))
(and $x159 (or $x84 (and (distinct ?x7786 ?x7786) true)))))))))
(check-sat)
; query 61: function crcu8, block 29, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x5115 ((_ zero_extend 16) in27_16)))
(let ((?x7786 (bvor ?x5115 (_ bv32768 32))))
(let ((?x878 ((_ extract 15 0) ?x7786)))
(let (($x908 (or false false)))
(let (($x84 (or $x908 false false)))
(let (($x85 (or $x84 false)))
(let (($x206 (not $x85)))
(and $x206 (or $x85 (and (distinct ?x878 ?x878) true)))))))))))
(check-sat)
; query 62: function crcu8, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x908 (or false false)))
(let (($x30 (not $x908)))
(and $x30 (or $x908 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 63: function crcu8, block 33, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x5115 ((_ zero_extend 16) in27_16)))
(let ((?x9338 (bvand ?x5115 (_ bv32767 32))))
(let (($x908 (or false false)))
(let (($x84 (or $x908 false false)))
(let (($x159 (not $x84)))
(and $x159 (or $x84 (and (distinct ?x9338 ?x9338) true)))))))))
(check-sat)
; query 64: function crcu8, block 33, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x5115 ((_ zero_extend 16) in27_16)))
(let ((?x9338 (bvand ?x5115 (_ bv32767 32))))
(let ((?x9668 ((_ extract 15 0) ?x9338)))
(let (($x908 (or false false)))
(let (($x84 (or $x908 false false)))
(let (($x85 (or $x84 false)))
(let (($x206 (not $x85)))
(and $x206 (or $x85 (and (distinct ?x9668 ?x9668) true)))))))))))
(check-sat)
; query 65: function crcu8, block 38, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_8 () (_ BitVec 8))
(assert
 (let (($x441 (or false false false)))
(let (($x712 (not $x441)))
(and $x712 (or $x441 (and (distinct (bvadd in.02_8 (_ bv1 8)) (bvadd in.02_8 (_ bv1 8))) true))))))
(check-sat)
; query 66: function crcu8, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x2640 ((_ extract 7 0) in.01_16)))
(let ((?x4660 ((_ zero_extend 24) ?x2640)))
(let (($x908 (or false false)))
(let (($x8244 (or $x908 false)))
(and (not $x8244) (or $x8244 (and (distinct ?x4660 ?x4660) true))))))))
(check-sat)
; query 67: function crcu8, block 6, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x2640 ((_ extract 7 0) in.01_16)))
(let ((?x4660 ((_ zero_extend 24) ?x2640)))
(let ((?x805 (bvand ?x4660 (_ bv1 32))))
(let (($x908 (or false false)))
(let (($x8244 (or $x908 false)))
(let (($x2169 (or $x8244 false false)))
(and (not $x2169) (or $x2169 (and (distinct ?x805 ?x805) true))))))))))
(check-sat)
; query 68: function crcu8, block 6, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x2640 ((_ extract 7 0) in.01_16)))
(let ((?x4660 ((_ zero_extend 24) ?x2640)))
(let ((?x805 (bvand ?x4660 (_ bv1 32))))
(let ((?x4772 ((_ zero_extend 24) in.0_8)))
(let ((?x6019 (bvand ?x4772 (_ bv1 32))))
(let ((?x9664 (bvxor ?x6019 ?x805)))
(let (($x908 (or false false)))
(let (($x8244 (or $x908 false)))
(let (($x2169 (or $x8244 false false)))
(let (($x84 (or $x908 false false)))
(let (($x119 (or $x84 $x2169 false)))
(and (not $x119) (or $x119 (and (distinct ?x9664 ?x9664) true)))))))))))))))
(check-sat)
; query 69: function crcu8, block 6, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x2640 ((_ extract 7 0) in.01_16)))
(let ((?x4660 ((_ zero_extend 24) ?x2640)))
(let ((?x805 (bvand ?x4660 (_ bv1 32))))
(let ((?x4772 ((_ zero_extend 24) in.0_8)))
(let ((?x6019 (bvand ?x4772 (_ bv1 32))))
(let ((?x9664 (bvxor ?x6019 ?x805)))
(let ((?x9790 ((_ extract 7 0) ?x9664)))
(let (($x908 (or false false)))
(let (($x8244 (or $x908 false)))
(let (($x2169 (or $x8244 false false)))
(let (($x84 (or $x908 false false)))
(let (($x119 (or $x84 $x2169 false)))
(let (($x9335 (or $x119 false)))
(and (not $x9335) (or $x9335 (and (distinct ?x9790 ?x9790) true)))))))))))))))))
(check-sat)
; query 70: function crcu8, block 6, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x908 (or false false)))
(let (($x30 (not $x908)))
(and $x30 (or $x908 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 71: function crcu8, block 6, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x4772 ((_ zero_extend 24) in.0_8)))
(let ((?x4959 (bvashr ?x4772 (_ bv1 32))))
(let (($x908 (or false false)))
(let (($x84 (or $x908 false false)))
(let (($x4280 (or $x84 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not $x4280) (or $x4280 (and (distinct ?x4959 ?x4959) true)))))))))
(check-sat)
; query 72: function crcu8, block 6, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x4772 ((_ zero_extend 24) in.0_8)))
(let ((?x4959 (bvashr ?x4772 (_ bv1 32))))
(let ((?x1178 ((_ extract 7 0) ?x4959)))
(let (($x908 (or false false)))
(let (($x84 (or $x908 false false)))
(let (($x4280 (or $x84 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x7832 (or $x4280 false)))
(and (not $x7832) (or $x7832 (and (distinct ?x1178 ?x1178) true)))))))))))
(check-sat)
; query 73: function crcu8, block 6, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x2640 ((_ extract 7 0) in.01_16)))
(let ((?x4660 ((_ zero_extend 24) ?x2640)))
(let ((?x805 (bvand ?x4660 (_ bv1 32))))
(let ((?x4772 ((_ zero_extend 24) in.0_8)))
(let ((?x6019 (bvand ?x4772 (_ bv1 32))))
(let ((?x9664 (bvxor ?x6019 ?x805)))
(let ((?x9790 ((_ extract 7 0) ?x9664)))
(let ((?x9347 ((_ zero_extend 24) ?x9790)))
(let (($x908 (or false false)))
(let (($x8244 (or $x908 false)))
(let (($x2169 (or $x8244 false false)))
(let (($x84 (or $x908 false false)))
(let (($x119 (or $x84 $x2169 false)))
(let (($x9335 (or $x119 false)))
(let (($x2175 (or $x9335 false)))
(and (not $x2175) (or $x2175 (and (distinct ?x9347 ?x9347) true)))))))))))))))))))
(check-sat)
; query 74: function crcu8, block 6, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x2640 ((_ extract 7 0) in.01_16)))
(let ((?x4660 ((_ zero_extend 24) ?x2640)))
(let ((?x805 (bvand ?x4660 (_ bv1 32))))
(let ((?x4772 ((_ zero_extend 24) in.0_8)))
(let ((?x6019 (bvand ?x4772 (_ bv1 32))))
(let ((?x9664 (bvxor ?x6019 ?x805)))
(let ((?x9790 ((_ extract 7 0) ?x9664)))
(let ((?x9347 ((_ zero_extend 24) ?x9790)))
(let ((?x9003 (ite (= (_ bv1 32) ?x9347) (_ bv1 1) (_ bv0 1))))
(let (($x908 (or false false)))
(let (($x8244 (or $x908 false)))
(let (($x2169 (or $x8244 false false)))
(let (($x84 (or $x908 false false)))
(let (($x119 (or $x84 $x2169 false)))
(let (($x9335 (or $x119 false)))
(let (($x2175 (or $x9335 false)))
(let (($x2152 (or $x2175 false false)))
(and (not $x2152) (or $x2152 (and (distinct ?x9003 ?x9003) true)))))))))))))))))))))
(check-sat)
; query 75: function crcu8, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x908 (or false false)))
(let (($x30 (not $x908)))
(and $x30 (or $x908 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 76: function crcu8, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x4772 ((_ zero_extend 24) in.0_8)))
(let ((?x6019 (bvand ?x4772 (_ bv1 32))))
(let (($x908 (or false false)))
(let (($x84 (or $x908 false false)))
(let (($x159 (not $x84)))
(and $x159 (or $x84 (and (distinct ?x6019 ?x6019) true)))))))))
(check-sat)
; query 77: function crcu8, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x908 (or false false)))
(let (($x30 (not $x908)))
(and $x30 (or $x908 (and (distinct ((_ extract 7 0) in.01_16) ((_ extract 7 0) in.01_16)) true))))))
(check-sat)
; query 78: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x8245 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x4604 ((_ zero_extend 31) ?x8245)))
(let ((?x5509 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x8868 ((_ zero_extend 31) ?x5509)))
(let ((?x8427 (bvand ?x8868 ?x4604)))
(let ((?x1455 (ite (and (distinct (_ bv0 32) ?x8427) true) (_ bv1 1) (_ bv0 1))))
(let ((?x289 ((_ zero_extend 63) ?x1455)))
(let (($x908 (or false false)))
(let (($x84 (or $x908 false false)))
(let (($x85 (or $x84 false)))
(let (($x296 (or $x85 $x85 false)))
(let (($x9701 (or $x296 false false)))
(let (($x2171 (or $x9701 false)))
(and (not $x2171) (or $x2171 (and (distinct ?x289 ?x289) true)))))))))))))))))
(check-sat)
; query 79: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x8245 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x4604 ((_ zero_extend 31) ?x8245)))
(let ((?x5509 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x8868 ((_ zero_extend 31) ?x5509)))
(let ((?x8427 (bvand ?x8868 ?x4604)))
(let ((?x1455 (ite (and (distinct (_ bv0 32) ?x8427) true) (_ bv1 1) (_ bv0 1))))
(let (($x834 (= (_ bv1 1) ?x1455)))
(let ((?x4517 (ite $x834 (_ bv1 32) (_ bv0 32))))
(let (($x908 (or false false)))
(let (($x84 (or $x908 false false)))
(let (($x85 (or $x84 false)))
(let (($x296 (or $x85 $x85 false)))
(let (($x9701 (or $x296 false false)))
(let (($x7766 (or $x9701 (ite $x834 false false))))
(and (not $x7766) (or $x7766 (and (distinct ?x4517 ?x4517) true))))))))))))))))))
(check-sat)
; query 80: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x8245 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x4604 ((_ zero_extend 31) ?x8245)))
(let ((?x5509 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x8868 ((_ zero_extend 31) ?x5509)))
(let ((?x8427 (bvand ?x8868 ?x4604)))
(let ((?x1455 (ite (and (distinct (_ bv0 32) ?x8427) true) (_ bv1 1) (_ bv0 1))))
(let (($x834 (= (_ bv1 1) ?x1455)))
(let ((?x4517 (ite $x834 (_ bv1 32) (_ bv0 32))))
(let ((?x4482 ((_ extract 7 0) ?x4517)))
(let (($x908 (or false false)))
(let (($x84 (or $x908 false false)))
(let (($x85 (or $x84 false)))
(let (($x296 (or $x85 $x85 false)))
(let (($x9701 (or $x296 false false)))
(let (($x7766 (or $x9701 (ite $x834 false false))))
(let (($x9324 (or $x7766 false)))
(and (not $x9324) (or $x9324 (and (distinct ?x4482 ?x4482) true))))))))))))))))))))
(check-sat)
; query 81: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x908 (or false false)))
(let (($x30 (not $x908)))
(and $x30 (or $x908 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 82: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x5509 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x908 (or false false)))
(let (($x84 (or $x908 false false)))
(let (($x159 (not $x84)))
(and $x159 (or $x84 (and (distinct ?x5509 ?x5509) true))))))))
(check-sat)
; query 83: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x5509 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x8868 ((_ zero_extend 31) ?x5509)))
(let (($x908 (or false false)))
(let (($x84 (or $x908 false false)))
(let (($x85 (or $x84 false)))
(let (($x206 (not $x85)))
(and $x206 (or $x85 (and (distinct ?x8868 ?x8868) true))))))))))
(check-sat)
; query 84: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x908 (or false false)))
(let (($x30 (not $x908)))
(and $x30 (or $x908 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 85: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x8245 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x908 (or false false)))
(let (($x84 (or $x908 false false)))
(let (($x159 (not $x84)))
(and $x159 (or $x84 (and (distinct ?x8245 ?x8245) true))))))))
(check-sat)
; query 86: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x8245 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x4604 ((_ zero_extend 31) ?x8245)))
(let (($x908 (or false false)))
(let (($x84 (or $x908 false false)))
(let (($x85 (or $x84 false)))
(let (($x206 (not $x85)))
(and $x206 (or $x85 (and (distinct ?x4604 ?x4604) true))))))))))
(check-sat)
; query 87: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x8245 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x4604 ((_ zero_extend 31) ?x8245)))
(let ((?x5509 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x8868 ((_ zero_extend 31) ?x5509)))
(let ((?x8427 (bvand ?x8868 ?x4604)))
(let (($x908 (or false false)))
(let (($x84 (or $x908 false false)))
(let (($x85 (or $x84 false)))
(let (($x296 (or $x85 $x85 false)))
(and (not $x296) (or $x296 (and (distinct ?x8427 ?x8427) true)))))))))))))
(check-sat)
; query 88: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x8245 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x4604 ((_ zero_extend 31) ?x8245)))
(let ((?x5509 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x8868 ((_ zero_extend 31) ?x5509)))
(let ((?x8427 (bvand ?x8868 ?x4604)))
(let ((?x1455 (ite (and (distinct (_ bv0 32) ?x8427) true) (_ bv1 1) (_ bv0 1))))
(let (($x908 (or false false)))
(let (($x84 (or $x908 false false)))
(let (($x85 (or $x84 false)))
(let (($x296 (or $x85 $x85 false)))
(let (($x9701 (or $x296 false false)))
(and (not $x9701) (or $x9701 (and (distinct ?x1455 ?x1455) true)))))))))))))))
(check-sat)
; query 89: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x9254 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x441 (or false false false)))
(let (($x712 (not $x441)))
(and $x712 (or $x441 (and (distinct ?x9254 ?x9254) true)))))))
(check-sat)
; query 90: function matrix_add_const, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x441 (or false false false)))
(let (($x712 (not $x441)))
(and $x712 (or $x441 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 91: function matrix_add_const, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x9000 (bvadd in.01_32 (_ bv1 32))))
(let (($x4450 (and (distinct ?x9000 ?x9000) true)))
(let (($x441 (or false false false)))
(let (($x712 (not $x441)))
(and $x712 (or $x441 $x4450)))))))
(check-sat)
; query 92: function matrix_mul_const, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x441 (or false false false)))
(let (($x712 (not $x441)))
(and $x712 (or $x441 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 93: function matrix_mul_const, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x9000 (bvadd in.01_32 (_ bv1 32))))
(let (($x4450 (and (distinct ?x9000 ?x9000) true)))
(let (($x441 (or false false false)))
(let (($x712 (not $x441)))
(and $x712 (or $x441 $x4450)))))))
(check-sat)
; query 94: function matrix_mul_matrix, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x441 (or false false false)))
(let (($x712 (not $x441)))
(and $x712 (or $x441 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 95: function matrix_mul_matrix, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x9000 (bvadd in.01_32 (_ bv1 32))))
(let (($x4450 (and (distinct ?x9000 ?x9000) true)))
(let (($x441 (or false false false)))
(let (($x712 (not $x441)))
(and $x712 (or $x441 $x4450)))))))
(check-sat)
; query 96: function matrix_mul_matrix, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x441 (or false false false)))
(let (($x712 (not $x441)))
(and $x712 (or $x441 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 97: function matrix_mul_matrix_bitextract, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x441 (or false false false)))
(let (($x712 (not $x441)))
(and $x712 (or $x441 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 98: function matrix_mul_matrix_bitextract, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x9000 (bvadd in.01_32 (_ bv1 32))))
(let (($x4450 (and (distinct ?x9000 ?x9000) true)))
(let (($x441 (or false false false)))
(let (($x712 (not $x441)))
(and $x712 (or $x441 $x4450)))))))
(check-sat)
; query 99: function matrix_mul_matrix_bitextract, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x441 (or false false false)))
(let (($x712 (not $x441)))
(and $x712 (or $x441 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 100: function matrix_mul_vect, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x441 (or false false false)))
(let (($x712 (not $x441)))
(and $x712 (or $x441 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 101: function matrix_mul_vect, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x9000 (bvadd in.01_32 (_ bv1 32))))
(let (($x4450 (and (distinct ?x9000 ?x9000) true)))
(let (($x441 (or false false false)))
(let (($x712 (not $x441)))
(and $x712 (or $x441 $x4450)))))))
(check-sat)
; query 102: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x908 (or false false)))
(let (($x30 (not $x908)))
(and $x30 (or $x908 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 103: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x1430 ((_ sign_extend 16) in.1_16)))
(let ((?x622 (bvadd ?x1430 (_ bv10 32))))
(let (($x3034 (and (distinct (bvadd ((_ sign_extend 1) ?x1430) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x622)) true)))
(let (($x908 (or false false)))
(let (($x6161 (or $x908 false (or $x3034))))
(and (not $x6161) (or $x6161 (and (distinct ?x622 ?x622) true)))))))))
(check-sat)
; query 104: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x1430 ((_ sign_extend 16) in.1_16)))
(let ((?x622 (bvadd ?x1430 (_ bv10 32))))
(let ((?x2568 ((_ extract 15 0) ?x622)))
(let (($x3034 (and (distinct (bvadd ((_ sign_extend 1) ?x1430) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x622)) true)))
(let (($x908 (or false false)))
(let (($x6161 (or $x908 false (or $x3034))))
(let (($x1335 (or $x6161 false)))
(and (not $x1335) (or $x1335 (and (distinct ?x2568 ?x2568) true)))))))))))
(check-sat)
; query 105: function matrix_sum, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x337 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x441 (or false false false)))
(let (($x712 (not $x441)))
(and $x712 (or $x441 (and (distinct ?x337 ?x337) true)))))))
(check-sat)
; query 106: function matrix_sum, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x337 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let ((?x3404 ((_ zero_extend 63) ?x337)))
(let (($x441 (or false false false)))
(let (($x1164 (or $x441 false)))
(and (not $x1164) (or $x1164 (and (distinct ?x3404 ?x3404) true))))))))
(check-sat)
; query 107: function matrix_sum, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x337 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x2376 (= (_ bv1 1) ?x337)))
(let ((?x8130 (ite $x2376 (_ bv1 32) (_ bv0 32))))
(let (($x441 (or false false false)))
(let (($x5759 (or $x441 (ite $x2376 false false))))
(and (not $x5759) (or $x5759 (and (distinct ?x8130 ?x8130) true)))))))))
(check-sat)
; query 108: function matrix_sum, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x908 (or false false)))
(let (($x30 (not $x908)))
(and $x30 (or $x908 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 109: function matrix_sum, block 22, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x337 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x2376 (= (_ bv1 1) ?x337)))
(let ((?x8130 (ite $x2376 (_ bv1 32) (_ bv0 32))))
(let ((?x1430 ((_ sign_extend 16) in.1_16)))
(let ((?x973 (bvadd ?x1430 ?x8130)))
(let (($x40 (and (distinct (bvadd ((_ sign_extend 1) ?x1430) ((_ sign_extend 1) ?x8130)) ((_ sign_extend 1) ?x973)) true)))
(let (($x441 (or false false false)))
(let (($x5759 (or $x441 (ite $x2376 false false))))
(let (($x908 (or false false)))
(let (($x1669 (or $x908 $x5759 (or $x40))))
(and (not $x1669) (or $x1669 (and (distinct ?x973 ?x973) true))))))))))))))
(check-sat)
; query 110: function matrix_sum, block 22, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x337 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x2376 (= (_ bv1 1) ?x337)))
(let ((?x8130 (ite $x2376 (_ bv1 32) (_ bv0 32))))
(let ((?x1430 ((_ sign_extend 16) in.1_16)))
(let ((?x973 (bvadd ?x1430 ?x8130)))
(let ((?x1815 ((_ extract 15 0) ?x973)))
(let (($x40 (and (distinct (bvadd ((_ sign_extend 1) ?x1430) ((_ sign_extend 1) ?x8130)) ((_ sign_extend 1) ?x973)) true)))
(let (($x441 (or false false false)))
(let (($x5759 (or $x441 (ite $x2376 false false))))
(let (($x908 (or false false)))
(let (($x1669 (or $x908 $x5759 (or $x40))))
(let (($x2023 (or $x1669 false)))
(and (not $x2023) (or $x2023 (and (distinct ?x1815 ?x1815) true))))))))))))))))
(check-sat)
; query 111: function matrix_sum, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x441 (or false false false)))
(let (($x712 (not $x441)))
(and $x712 (or $x441 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 112: function matrix_sum, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x9000 (bvadd in.01_32 (_ bv1 32))))
(let (($x4450 (and (distinct ?x9000 ?x9000) true)))
(let (($x441 (or false false false)))
(let (($x712 (not $x441)))
(and $x712 (or $x441 $x4450)))))))
(check-sat)
; query 113: function parseval, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.23_32 () (_ BitVec 32))
(assert
 (let (($x1525 (and (distinct (bvmul ((_ sign_extend 32) in.23_32) ((_ sign_extend 32) (_ bv1024 32))) ((_ sign_extend 32) (bvmul in.23_32 (_ bv1024 32)))) true)))
(let (($x9114 (or false false (or $x1525))))
(and (not $x9114) (or $x9114 (and (distinct (bvmul in.23_32 (_ bv1024 32)) (bvmul in.23_32 (_ bv1024 32))) true))))))
(check-sat)
; query 114: function parseval, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.34_32 () (_ BitVec 32))
(assert
 (let (($x4785 (and (distinct (bvmul ((_ sign_extend 32) in.34_32) ((_ sign_extend 32) (_ bv1048576 32))) ((_ sign_extend 32) (bvmul in.34_32 (_ bv1048576 32)))) true)))
(let (($x9120 (or false false (or $x4785))))
(and (not $x9120) (or $x9120 (and (distinct (bvmul in.34_32 (_ bv1048576 32)) (bvmul in.34_32 (_ bv1048576 32))) true))))))
(check-sat)
; query 115: function partition_memory, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x441 (or false false false)))
(let (($x712 (not $x441)))
(and $x712 (or $x441 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 116: function run_crc_loop, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x9000 (bvadd in.01_32 (_ bv1 32))))
(let (($x4450 (and (distinct ?x9000 ?x9000) true)))
(let (($x441 (or false false false)))
(let (($x712 (not $x441)))
(and $x712 (or $x441 $x4450)))))))
(check-sat)
