; OptiPhase-Sigma refinement certificate for sweep K35-R2-026
; query 0: function corner_draw, block 11, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x698 (ite (= (_ bv0 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x743 (or false false false)))
(let (($x27 (not $x743)))
(and $x27 (or $x743 (and (distinct ?x698 ?x698) true)))))))
(check-sat)
; query 1: function edge_draw, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let ((?x114 (ite (= (_ bv0 32) in4_32) (_ bv1 1) (_ bv0 1))))
(let (($x743 (or false false false)))
(let (($x27 (not $x743)))
(and $x27 (or $x743 (and (distinct ?x114 ?x114) true)))))))
(check-sat)
; query 2: function enlarge, block 106, name %107
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x340 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x116 (or false false (or $x340))))
(and (not $x116) (or $x116 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 3: function enlarge, block 158, name %159
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x559 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x106 (or false false (or $x559))))
(and (not $x106) (or $x106 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 4: function enlarge, block 161, name %162
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let (($x13 (and (distinct (bvadd ((_ sign_extend 1) in.2_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.2_32 (_ bv1 32)))) true)))
(let (($x260 (or false false (or $x13))))
(and (not $x260) (or $x260 (and (distinct (bvadd in.2_32 (_ bv1 32)) (bvadd in.2_32 (_ bv1 32))) true))))))
(check-sat)
; query 5: function enlarge, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x5 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x126 (or false false (or $x5))))
(and (not $x126) (or $x126 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 6: function getint, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x108 (ite (bvsle (_ bv48 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x743 (or false false false)))
(let (($x27 (not $x743)))
(and $x27 (or $x743 (and (distinct ?x108 ?x108) true)))))))
(check-sat)
; query 7: function getint, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x33 (ite (bvsge (_ bv57 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x743 (or false false false)))
(let (($x27 (not $x743)))
(and $x27 (or $x743 (and (distinct ?x33 ?x33) true)))))))
(check-sat)
; query 8: function getint, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in26_32 () (_ BitVec 32))
(assert
 (let ((?x62 (ite (bvsgt (_ bv48 32) in26_32) (_ bv1 1) (_ bv0 1))))
(let (($x743 (or false false false)))
(let (($x27 (not $x743)))
(and $x27 (or $x743 (and (distinct ?x62 ?x62) true)))))))
(check-sat)
; query 9: function getint, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in26_32 () (_ BitVec 32))
(assert
 (let ((?x97 (ite (bvslt (_ bv57 32) in26_32) (_ bv1 1) (_ bv0 1))))
(let (($x743 (or false false false)))
(let (($x27 (not $x743)))
(and $x27 (or $x743 (and (distinct ?x97 ?x97) true)))))))
(check-sat)
; query 10: function getint, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x26 (ite (= (_ bv4294967295 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x743 (or false false false)))
(let (($x27 (not $x743)))
(and $x27 (or $x743 (and (distinct ?x26 ?x26) true)))))))
(check-sat)
; query 11: function int_to_uchar, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_32 () (_ BitVec 32))
(assert
 (let (($x93 (and (distinct (bvadd ((_ sign_extend 1) in.03_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.03_32 (_ bv1 32)))) true)))
(let (($x69 (or false false (or $x93))))
(and (not $x69) (or $x69 (and (distinct (bvadd in.03_32 (_ bv1 32)) (bvadd in.03_32 (_ bv1 32))) true))))))
(check-sat)
; query 12: function int_to_uchar, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.14_32 () (_ BitVec 32))
(assert
 (let (($x117 (and (distinct (bvadd ((_ sign_extend 1) in.14_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.14_32 (_ bv1 32)))) true)))
(let (($x66 (or false false (or $x117))))
(and (not $x66) (or $x66 (and (distinct (bvadd in.14_32 (_ bv1 32)) (bvadd in.14_32 (_ bv1 32))) true))))))
(check-sat)
; query 13: function main, block 129, name %130
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.011.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x384 (ite (and (distinct (_ bv0 32) in.011.lcssa_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x743 (or false false false)))
(let (($x27 (not $x743)))
(and $x27 (or $x743 (and (distinct ?x384 ?x384) true)))))))
(check-sat)
; query 14: function main, block 160, name %161
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x104 (ite (and (distinct (_ bv0 32) in.01.lcssa_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x743 (or false false false)))
(let (($x27 (not $x743)))
(and $x27 (or $x743 (and (distinct ?x104 ?x104) true)))))))
(check-sat)
; query 15: function main, block 35, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x704 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x47 (or false false (or $x704))))
(and (not $x47) (or $x47 (and (distinct (bvadd in.020_32 (_ bv1 32)) (bvadd in.020_32 (_ bv1 32))) true))))))
(check-sat)
; query 16: function main, block 35, name %37
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let ((?x390 (ite (bvsge (bvadd in.020_32 (_ bv1 32)) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x704 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x47 (or false false (or $x704))))
(let (($x276 (or $x47 false false)))
(and (not $x276) (or $x276 (and (distinct ?x390 ?x390) true))))))))
(check-sat)
; query 17: function main, block 49, name %50
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x704 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x47 (or false false (or $x704))))
(and (not $x47) (or $x47 (and (distinct (bvadd in.020_32 (_ bv1 32)) (bvadd in.020_32 (_ bv1 32))) true))))))
(check-sat)
; query 18: function main, block 49, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let ((?x390 (ite (bvsge (bvadd in.020_32 (_ bv1 32)) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x704 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x47 (or false false (or $x704))))
(let (($x276 (or $x47 false false)))
(and (not $x276) (or $x276 (and (distinct ?x390 ?x390) true))))))))
(check-sat)
; query 19: function main, block 66, name %67
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x556 (ite (= (_ bv0 32) in.0.lcssa_32) (_ bv1 1) (_ bv0 1))))
(let (($x743 (or false false false)))
(let (($x27 (not $x743)))
(and $x27 (or $x743 (and (distinct ?x556 ?x556) true)))))))
(check-sat)
; query 20: function main, block 84, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.07.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x56 (ite (and (distinct (_ bv0 32) in.07.lcssa_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x743 (or false false false)))
(let (($x27 (not $x743)))
(and $x27 (or $x743 (and (distinct ?x56 ?x56) true)))))))
(check-sat)
; query 21: function median, block 103, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x559 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x106 (or false false (or $x559))))
(and (not $x106) (or $x106 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 22: function median, block 106, name %107
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x5 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x126 (or false false (or $x5))))
(and (not $x126) (or $x126 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 23: function setup_brightness_lut, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x5 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x126 (or false false (or $x5))))
(and (not $x126) (or $x126 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 24: function susan_corners, block 1066, name %1067
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x559 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x106 (or false false (or $x559))))
(and (not $x106) (or $x106 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 25: function susan_corners, block 1069, name %1070
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x5 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x126 (or false false (or $x5))))
(and (not $x126) (or $x126 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 26: function susan_corners, block 1549, name %1550
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x340 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x116 (or false false (or $x340))))
(and (not $x116) (or $x116 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 27: function susan_corners, block 1552, name %1553
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x295 (and (distinct (bvadd ((_ sign_extend 1) in.12_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.12_32 (_ bv1 32)))) true)))
(let (($x48 (or false false (or $x295))))
(and (not $x48) (or $x48 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 28: function susan_corners, block 845, name %846
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in839_32 () (_ BitVec 32))
(declare-fun in840_32 () (_ BitVec 32))
(assert
 (let ((?x30 (ite (bvslt in840_32 in839_32) (_ bv1 1) (_ bv0 1))))
(let (($x743 (or false false false)))
(let (($x27 (not $x743)))
(and $x27 (or $x743 (and (distinct ?x30 ?x30) true)))))))
(check-sat)
; query 29: function susan_corners_quick, block 1469, name %1470
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x340 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x116 (or false false (or $x340))))
(and (not $x116) (or $x116 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 30: function susan_corners_quick, block 1472, name %1473
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x295 (and (distinct (bvadd ((_ sign_extend 1) in.12_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.12_32 (_ bv1 32)))) true)))
(let (($x48 (or false false (or $x295))))
(and (not $x48) (or $x48 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 31: function susan_corners_quick, block 433, name %434
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x559 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x106 (or false false (or $x559))))
(and (not $x106) (or $x106 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 32: function susan_corners_quick, block 436, name %437
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x5 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x126 (or false false (or $x5))))
(and (not $x126) (or $x126 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 33: function susan_edges, block 1432, name %1433
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1417_32 () (_ BitVec 32))
(assert
 (let ((?x198 (ite (bvslt (_ bv0 32) in1417_32) (_ bv1 1) (_ bv0 1))))
(let (($x743 (or false false false)))
(let (($x27 (not $x743)))
(and $x27 (or $x743 (and (distinct ?x198 ?x198) true)))))))
(check-sat)
; query 34: function susan_edges, block 1486, name %1487
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.116_32 () (_ BitVec 32))
(assert
 (let (($x36 (and (distinct (bvadd ((_ sign_extend 1) in.116_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.116_32 (_ bv1 32)))) true)))
(let (($x364 (or false false (or $x36))))
(and (not $x364) (or $x364 (and (distinct (bvadd in.116_32 (_ bv1 32)) (bvadd in.116_32 (_ bv1 32))) true))))))
(check-sat)
; query 35: function susan_edges, block 1489, name %1490
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.114_32 () (_ BitVec 32))
(assert
 (let (($x277 (and (distinct (bvadd ((_ sign_extend 1) in.114_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.114_32 (_ bv1 32)))) true)))
(let (($x644 (or false false (or $x277))))
(and (not $x644) (or $x644 (and (distinct (bvadd in.114_32 (_ bv1 32)) (bvadd in.114_32 (_ bv1 32))) true))))))
(check-sat)
; query 36: function susan_edges, block 379, name %380
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.015_32 () (_ BitVec 32))
(assert
 (let (($x650 (and (distinct (bvadd ((_ sign_extend 1) in.015_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.015_32 (_ bv1 32)))) true)))
(let (($x448 (or false false (or $x650))))
(and (not $x448) (or $x448 (and (distinct (bvadd in.015_32 (_ bv1 32)) (bvadd in.015_32 (_ bv1 32))) true))))))
(check-sat)
; query 37: function susan_edges, block 382, name %383
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.013_32 () (_ BitVec 32))
(assert
 (let (($x72 (and (distinct (bvadd ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.013_32 (_ bv1 32)))) true)))
(let (($x239 (or false false (or $x72))))
(and (not $x239) (or $x239 (and (distinct (bvadd in.013_32 (_ bv1 32)) (bvadd in.013_32 (_ bv1 32))) true))))))
(check-sat)
; query 38: function susan_edges, block 850, name %851
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in834_32 () (_ BitVec 32))
(assert
 (let ((?x326 (ite (= (_ bv0 32) in834_32) (_ bv1 1) (_ bv0 1))))
(let (($x743 (or false false false)))
(let (($x27 (not $x743)))
(and $x27 (or $x743 (and (distinct ?x326 ?x326) true)))))))
(check-sat)
; query 39: function susan_edges, block 870, name %871
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x828 (ite (bvslt (_ bv0 32) in.0_32) (_ bv1 1) (_ bv0 1))))
(let (($x743 (or false false false)))
(let (($x27 (not $x743)))
(and $x27 (or $x743 (and (distinct ?x828 ?x828) true)))))))
(check-sat)
; query 40: function susan_edges_small, block 119, name %120
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.09_32 () (_ BitVec 32))
(assert
 (let (($x278 (and (distinct (bvadd ((_ sign_extend 1) in.09_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.09_32 (_ bv1 32)))) true)))
(let (($x581 (or false false (or $x278))))
(and (not $x581) (or $x581 (and (distinct (bvadd in.09_32 (_ bv1 32)) (bvadd in.09_32 (_ bv1 32))) true))))))
(check-sat)
; query 41: function susan_edges_small, block 122, name %123
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.07_32 () (_ BitVec 32))
(assert
 (let (($x280 (and (distinct (bvadd ((_ sign_extend 1) in.07_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.07_32 (_ bv1 32)))) true)))
(let (($x197 (or false false (or $x280))))
(and (not $x197) (or $x197 (and (distinct (bvadd in.07_32 (_ bv1 32)) (bvadd in.07_32 (_ bv1 32))) true))))))
(check-sat)
; query 42: function susan_edges_small, block 258, name %259
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in243_32 () (_ BitVec 32))
(assert
 (let ((?x311 (ite (= (_ bv0 32) in243_32) (_ bv1 1) (_ bv0 1))))
(let (($x743 (or false false false)))
(let (($x27 (not $x743)))
(and $x27 (or $x743 (and (distinct ?x311 ?x311) true)))))))
(check-sat)
; query 43: function susan_edges_small, block 278, name %279
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x828 (ite (bvslt (_ bv0 32) in.0_32) (_ bv1 1) (_ bv0 1))))
(let (($x743 (or false false false)))
(let (($x27 (not $x743)))
(and $x27 (or $x743 (and (distinct ?x828 ?x828) true)))))))
(check-sat)
; query 44: function susan_edges_small, block 426, name %427
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in411_32 () (_ BitVec 32))
(assert
 (let ((?x332 (ite (bvslt (_ bv0 32) in411_32) (_ bv1 1) (_ bv0 1))))
(let (($x743 (or false false false)))
(let (($x27 (not $x743)))
(and $x27 (or $x743 (and (distinct ?x332 ?x332) true)))))))
(check-sat)
; query 45: function susan_edges_small, block 458, name %459
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.110_32 () (_ BitVec 32))
(assert
 (let (($x617 (and (distinct (bvadd ((_ sign_extend 1) in.110_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.110_32 (_ bv1 32)))) true)))
(let (($x240 (or false false (or $x617))))
(and (not $x240) (or $x240 (and (distinct (bvadd in.110_32 (_ bv1 32)) (bvadd in.110_32 (_ bv1 32))) true))))))
(check-sat)
; query 46: function susan_edges_small, block 461, name %462
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.18_32 () (_ BitVec 32))
(assert
 (let (($x368 (and (distinct (bvadd ((_ sign_extend 1) in.18_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.18_32 (_ bv1 32)))) true)))
(let (($x577 (or false false (or $x368))))
(and (not $x577) (or $x577 (and (distinct (bvadd in.18_32 (_ bv1 32)) (bvadd in.18_32 (_ bv1 32))) true))))))
(check-sat)
; query 47: function susan_principle, block 378, name %379
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x559 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x106 (or false false (or $x559))))
(and (not $x106) (or $x106 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 48: function susan_principle, block 381, name %382
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x5 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x126 (or false false (or $x5))))
(and (not $x126) (or $x126 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 49: function susan_principle_small, block 118, name %119
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x559 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x106 (or false false (or $x559))))
(and (not $x106) (or $x106 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 50: function susan_principle_small, block 121, name %122
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x5 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x126 (or false false (or $x5))))
(and (not $x126) (or $x126 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 51: function susan_smoothing, block 123, name %124
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.09_32 () (_ BitVec 32))
(assert
 (let (($x944 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in.09_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in.09_32))) true)))
(let (($x857 (or false false (or $x944))))
(and (not $x857) (or $x857 (and (distinct (bvsub (_ bv0 32) in.09_32) (bvsub (_ bv0 32) in.09_32)) true))))))
(check-sat)
; query 52: function susan_smoothing, block 143, name %144
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.016_32 () (_ BitVec 32))
(assert
 (let (($x456 (and (distinct (bvadd ((_ sign_extend 1) in.016_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.016_32 (_ bv1 32)))) true)))
(let (($x304 (or false false (or $x456))))
(and (not $x304) (or $x304 (and (distinct (bvadd in.016_32 (_ bv1 32)) (bvadd in.016_32 (_ bv1 32))) true))))))
(check-sat)
; query 53: function susan_smoothing, block 148, name %149
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.017_32 () (_ BitVec 32))
(assert
 (let (($x730 (and (distinct (bvadd ((_ sign_extend 1) in.017_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.017_32 (_ bv1 32)))) true)))
(let (($x267 (or false false (or $x730))))
(and (not $x267) (or $x267 (and (distinct (bvadd in.017_32 (_ bv1 32)) (bvadd in.017_32 (_ bv1 32))) true))))))
(check-sat)
; query 54: function susan_smoothing, block 165, name %166
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.114_32 () (_ BitVec 32))
(assert
 (let (($x277 (and (distinct (bvadd ((_ sign_extend 1) in.114_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.114_32 (_ bv1 32)))) true)))
(let (($x644 (or false false (or $x277))))
(and (not $x644) (or $x644 (and (distinct (bvadd in.114_32 (_ bv1 32)) (bvadd in.114_32 (_ bv1 32))) true))))))
(check-sat)
; query 55: function susan_smoothing, block 168, name %169
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.111_32 () (_ BitVec 32))
(assert
 (let (($x595 (and (distinct (bvadd ((_ sign_extend 1) in.111_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.111_32 (_ bv1 32)))) true)))
(let (($x996 (or false false (or $x595))))
(and (not $x996) (or $x996 (and (distinct (bvadd in.111_32 (_ bv1 32)) (bvadd in.111_32 (_ bv1 32))) true))))))
(check-sat)
; query 56: function susan_smoothing, block 21, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x818 (ite (= (_ bv0 32) (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x743 (or false false false)))
(let (($x27 (not $x743)))
(and $x27 (or $x743 (and (distinct ?x818 ?x818) true)))))))
(check-sat)
; query 57: function susan_smoothing, block 319, name %320
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.215_32 () (_ BitVec 32))
(assert
 (let (($x850 (and (distinct (bvadd ((_ sign_extend 1) in.215_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.215_32 (_ bv1 32)))) true)))
(let (($x331 (or false false (or $x850))))
(and (not $x331) (or $x331 (and (distinct (bvadd in.215_32 (_ bv1 32)) (bvadd in.215_32 (_ bv1 32))) true))))))
(check-sat)
; query 58: function susan_smoothing, block 322, name %323
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.212_32 () (_ BitVec 32))
(assert
 (let (($x942 (and (distinct (bvadd ((_ sign_extend 1) in.212_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.212_32 (_ bv1 32)))) true)))
(let (($x336 (or false false (or $x942))))
(and (not $x336) (or $x336 (and (distinct (bvadd in.212_32 (_ bv1 32)) (bvadd in.212_32 (_ bv1 32))) true))))))
(check-sat)
; query 59: function susan_smoothing, block 67, name %68
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.09_32 () (_ BitVec 32))
(assert
 (let (($x944 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in.09_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in.09_32))) true)))
(let (($x857 (or false false (or $x944))))
(and (not $x857) (or $x857 (and (distinct (bvsub (_ bv0 32) in.09_32) (bvsub (_ bv0 32) in.09_32)) true))))))
(check-sat)
; query 60: function susan_smoothing, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.013_32 () (_ BitVec 32))
(assert
 (let (($x72 (and (distinct (bvadd ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.013_32 (_ bv1 32)))) true)))
(let (($x239 (or false false (or $x72))))
(and (not $x239) (or $x239 (and (distinct (bvadd in.013_32 (_ bv1 32)) (bvadd in.013_32 (_ bv1 32))) true))))))
(check-sat)
; query 61: function susan_smoothing, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.010_32 () (_ BitVec 32))
(assert
 (let (($x536 (and (distinct (bvadd ((_ sign_extend 1) in.010_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.010_32 (_ bv1 32)))) true)))
(let (($x144 (or false false (or $x536))))
(and (not $x144) (or $x144 (and (distinct (bvadd in.010_32 (_ bv1 32)) (bvadd in.010_32 (_ bv1 32))) true))))))
(check-sat)
; query 62: function susan_thin, block 100, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in93_32 () (_ BitVec 32))
(assert
 (let ((?x584 (ite (= (_ bv1 32) in93_32) (_ bv1 1) (_ bv0 1))))
(let (($x743 (or false false false)))
(let (($x27 (not $x743)))
(and $x27 (or $x743 (and (distinct ?x584 ?x584) true)))))))
(check-sat)
; query 63: function susan_thin, block 428, name %429
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.022_32 () (_ BitVec 32))
(assert
 (let (($x513 (and (distinct (bvadd ((_ sign_extend 1) in.022_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.022_32 (_ bv1 32)))) true)))
(let (($x440 (or false false (or $x513))))
(and (not $x440) (or $x440 (and (distinct (bvadd in.022_32 (_ bv1 32)) (bvadd in.022_32 (_ bv1 32))) true))))))
(check-sat)
; query 64: function susan_thin, block 431, name %432
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.018_32 () (_ BitVec 32))
(assert
 (let (($x183 (and (distinct (bvadd ((_ sign_extend 1) in.018_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.018_32 (_ bv1 32)))) true)))
(let (($x496 (or false false (or $x183))))
(and (not $x496) (or $x496 (and (distinct (bvadd in.018_32 (_ bv1 32)) (bvadd in.018_32 (_ bv1 32))) true))))))
(check-sat)
; query 65: function susan_thin, block 469, name %470
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.235.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x874 (bvadd in.235.lcssa_32 in.235.lcssa_32)))
(let ((?x833 ((_ sign_extend 1) ?x874)))
(let (($x286 (and (distinct (bvadd ((_ sign_extend 1) in.235.lcssa_32) ((_ sign_extend 1) in.235.lcssa_32)) ?x833) true)))
(let (($x415 (or false false (or $x286))))
(and (not $x415) (or $x415 (and (distinct ?x874 ?x874) true))))))))
(check-sat)
; query 66: function susan_thin, block 469, name %471
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.228.lcssa_32 () (_ BitVec 32))
(declare-fun in.235.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x874 (bvadd in.235.lcssa_32 in.235.lcssa_32)))
(let ((?x631 (bvadd ?x874 in.228.lcssa_32)))
(let (($x825 (and (distinct (bvadd ((_ sign_extend 1) ?x874) ((_ sign_extend 1) in.228.lcssa_32)) ((_ sign_extend 1) ?x631)) true)))
(let ((?x833 ((_ sign_extend 1) ?x874)))
(let (($x286 (and (distinct (bvadd ((_ sign_extend 1) in.235.lcssa_32) ((_ sign_extend 1) in.235.lcssa_32)) ?x833) true)))
(let (($x415 (or false false (or $x286))))
(let (($x578 (or $x415 false (or $x825))))
(and (not $x578) (or $x578 (and (distinct ?x631 ?x631) true)))))))))))
(check-sat)
; query 67: function susan_thin, block 469, name %472
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.228.lcssa_32 () (_ BitVec 32))
(declare-fun in.235.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x874 (bvadd in.235.lcssa_32 in.235.lcssa_32)))
(let ((?x631 (bvadd ?x874 in.228.lcssa_32)))
(let ((?x297 (ite (bvsgt (_ bv3 32) ?x631) (_ bv1 1) (_ bv0 1))))
(let (($x825 (and (distinct (bvadd ((_ sign_extend 1) ?x874) ((_ sign_extend 1) in.228.lcssa_32)) ((_ sign_extend 1) ?x631)) true)))
(let ((?x833 ((_ sign_extend 1) ?x874)))
(let (($x286 (and (distinct (bvadd ((_ sign_extend 1) in.235.lcssa_32) ((_ sign_extend 1) in.235.lcssa_32)) ?x833) true)))
(let (($x415 (or false false (or $x286))))
(let (($x578 (or $x415 false (or $x825))))
(let (($x343 (or $x578 false false)))
(and (not $x343) (or $x343 (and (distinct ?x297 ?x297) true)))))))))))))
(check-sat)
; query 68: function susan_thin, block 473, name %474
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.235.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x731 (bvsub in.235.lcssa_32 (_ bv1 32))))
(let ((?x534 ((_ sign_extend 1) ?x731)))
(let (($x915 (and (distinct (bvsub ((_ sign_extend 1) in.235.lcssa_32) ((_ sign_extend 1) (_ bv1 32))) ?x534) true)))
(let (($x431 (or false false (or $x915))))
(and (not $x431) (or $x431 (and (distinct ?x731 ?x731) true))))))))
(check-sat)
; query 69: function susan_thin, block 473, name %475
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.235.lcssa_32 () (_ BitVec 32))
(declare-fun in.14_32 () (_ BitVec 32))
(assert
 (let ((?x731 (bvsub in.235.lcssa_32 (_ bv1 32))))
(let ((?x430 (bvadd in.14_32 ?x731)))
(let (($x590 (and (distinct (bvadd ((_ sign_extend 1) in.14_32) ((_ sign_extend 1) ?x731)) ((_ sign_extend 1) ?x430)) true)))
(let ((?x534 ((_ sign_extend 1) ?x731)))
(let (($x915 (and (distinct (bvsub ((_ sign_extend 1) in.235.lcssa_32) ((_ sign_extend 1) (_ bv1 32))) ?x534) true)))
(let (($x431 (or false false (or $x915))))
(let (($x760 (or false $x431 (or $x590))))
(and (not $x760) (or $x760 (and (distinct ?x430 ?x430) true)))))))))))
(check-sat)
; query 70: function susan_thin, block 473, name %476
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.228.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x927 (bvsub in.228.lcssa_32 (_ bv2 32))))
(let ((?x283 ((_ sign_extend 1) ?x927)))
(let (($x900 (and (distinct (bvsub ((_ sign_extend 1) in.228.lcssa_32) ((_ sign_extend 1) (_ bv2 32))) ?x283) true)))
(let (($x258 (or false false (or $x900))))
(and (not $x258) (or $x258 (and (distinct ?x927 ?x927) true))))))))
(check-sat)
; query 71: function susan_thin, block 473, name %477
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.228.lcssa_32 () (_ BitVec 32))
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x927 (bvsub in.228.lcssa_32 (_ bv2 32))))
(let ((?x645 (bvadd in.0_32 ?x927)))
(let (($x287 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) ?x927)) ((_ sign_extend 1) ?x645)) true)))
(let ((?x283 ((_ sign_extend 1) ?x927)))
(let (($x900 (and (distinct (bvsub ((_ sign_extend 1) in.228.lcssa_32) ((_ sign_extend 1) (_ bv2 32))) ?x283) true)))
(let (($x258 (or false false (or $x900))))
(let (($x481 (or false $x258 (or $x287))))
(and (not $x481) (or $x481 (and (distinct ?x645 ?x645) true)))))))))))
(check-sat)
; query 72: function susan_thin, block 473, name %478
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.235.lcssa_32 () (_ BitVec 32))
(declare-fun in.14_32 () (_ BitVec 32))
(assert
 (let ((?x603 (ite (bvsgt (_ bv4 32) (bvadd in.14_32 (bvsub in.235.lcssa_32 (_ bv1 32)))) (_ bv1 1) (_ bv0 1))))
(let ((?x731 (bvsub in.235.lcssa_32 (_ bv1 32))))
(let ((?x534 ((_ sign_extend 1) ?x731)))
(let ((?x35 ((_ sign_extend 1) in.14_32)))
(let (($x915 (and (distinct (bvsub ((_ sign_extend 1) in.235.lcssa_32) ((_ sign_extend 1) (_ bv1 32))) ?x534) true)))
(let (($x431 (or false false (or $x915))))
(let (($x760 (or false $x431 (or (and (distinct (bvadd ?x35 ?x534) ((_ sign_extend 1) (bvadd in.14_32 ?x731))) true)))))
(let (($x256 (or $x760 false false)))
(and (not $x256) (or $x256 (and (distinct ?x603 ?x603) true))))))))))))
(check-sat)
; query 73: function susan_thin, block 533, name %534
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in528_32 () (_ BitVec 32))
(declare-fun in498_32 () (_ BitVec 32))
(assert
 (let (($x743 (or false false false)))
(let (($x689 (or $x743 (and (distinct (bvor in498_32 in528_32) (bvor in498_32 in528_32)) true))))
(let (($x27 (not $x743)))
(and $x27 $x689)))))
(check-sat)
; query 74: function susan_thin, block 533, name %535
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in518_32 () (_ BitVec 32))
(declare-fun in508_32 () (_ BitVec 32))
(assert
 (let (($x743 (or false false false)))
(let (($x888 (or $x743 (and (distinct (bvor in508_32 in518_32) (bvor in508_32 in518_32)) true))))
(let (($x27 (not $x743)))
(and $x27 $x888)))))
(check-sat)
; query 75: function susan_thin, block 533, name %536
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in518_32 () (_ BitVec 32))
(declare-fun in508_32 () (_ BitVec 32))
(declare-fun in528_32 () (_ BitVec 32))
(declare-fun in498_32 () (_ BitVec 32))
(assert
 (let ((?x829 (bvor in508_32 in518_32)))
(let ((?x478 (bvor in498_32 in528_32)))
(let ((?x830 (bvand ?x478 ?x829)))
(let (($x743 (or false false false)))
(let (($x596 (or $x743 $x743 false)))
(let (($x498 (not $x596)))
(and $x498 (or $x596 (and (distinct ?x830 ?x830) true))))))))))
(check-sat)
; query 76: function susan_thin, block 533, name %537
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in518_32 () (_ BitVec 32))
(declare-fun in508_32 () (_ BitVec 32))
(declare-fun in528_32 () (_ BitVec 32))
(declare-fun in498_32 () (_ BitVec 32))
(assert
 (let ((?x829 (bvor in508_32 in518_32)))
(let ((?x478 (bvor in498_32 in528_32)))
(let ((?x830 (bvand ?x478 ?x829)))
(let ((?x589 (ite (and (distinct (_ bv0 32) ?x830) true) (_ bv1 1) (_ bv0 1))))
(let (($x743 (or false false false)))
(let (($x596 (or $x743 $x743 false)))
(let (($x548 (or $x596 false false)))
(let (($x635 (not $x548)))
(and $x635 (or $x548 (and (distinct ?x589 ?x589) true))))))))))))
(check-sat)
; query 77: function susan_thin, block 538, name %539
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in498_32 () (_ BitVec 32))
(assert
 (let ((?x657 (ite (and (distinct (_ bv0 32) in498_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x743 (or false false false)))
(let (($x27 (not $x743)))
(and $x27 (or $x743 (and (distinct ?x657 ?x657) true)))))))
(check-sat)
; query 78: function susan_thin, block 540, name %541
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in508_32 () (_ BitVec 32))
(assert
 (let ((?x714 (ite (and (distinct (_ bv0 32) in508_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x743 (or false false false)))
(let (($x27 (not $x743)))
(and $x27 (or $x743 (and (distinct ?x714 ?x714) true)))))))
(check-sat)
; query 79: function susan_thin, block 545, name %546
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in508_32 () (_ BitVec 32))
(assert
 (let ((?x714 (ite (and (distinct (_ bv0 32) in508_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x743 (or false false false)))
(let (($x27 (not $x743)))
(and $x27 (or $x743 (and (distinct ?x714 ?x714) true)))))))
(check-sat)
; query 80: function susan_thin, block 563, name %564
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.325_32 () (_ BitVec 32))
(assert
 (let ((?x706 (ite (= (_ bv0 32) in.325_32) (_ bv1 1) (_ bv0 1))))
(let (($x743 (or false false false)))
(let (($x27 (not $x743)))
(and $x27 (or $x743 (and (distinct ?x706 ?x706) true)))))))
(check-sat)
; query 81: function susan_thin, block 597, name %598
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.321_32 () (_ BitVec 32))
(assert
 (let ((?x363 (ite (= (_ bv0 32) in.321_32) (_ bv1 1) (_ bv0 1))))
(let (($x743 (or false false false)))
(let (($x27 (not $x743)))
(and $x27 (or $x743 (and (distinct ?x363 ?x363) true)))))))
(check-sat)
; query 82: function susan_thin, block 685, name %686
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in662_32 () (_ BitVec 32))
(declare-fun in680_32 () (_ BitVec 32))
(assert
 (let (($x743 (or false false false)))
(let (($x398 (or $x743 (and (distinct (bvor in680_32 in662_32) (bvor in680_32 in662_32)) true))))
(let (($x27 (not $x743)))
(and $x27 $x398)))))
(check-sat)
; query 83: function susan_thin, block 685, name %687
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in671_32 () (_ BitVec 32))
(declare-fun in653_32 () (_ BitVec 32))
(assert
 (let (($x743 (or false false false)))
(let (($x339 (or $x743 (and (distinct (bvor in653_32 in671_32) (bvor in653_32 in671_32)) true))))
(let (($x27 (not $x743)))
(and $x27 $x339)))))
(check-sat)
; query 84: function susan_thin, block 685, name %688
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in671_32 () (_ BitVec 32))
(declare-fun in653_32 () (_ BitVec 32))
(declare-fun in662_32 () (_ BitVec 32))
(declare-fun in680_32 () (_ BitVec 32))
(assert
 (let ((?x316 (bvor in653_32 in671_32)))
(let ((?x868 (bvor in680_32 in662_32)))
(let ((?x246 (bvand ?x868 ?x316)))
(let (($x743 (or false false false)))
(let (($x596 (or $x743 $x743 false)))
(let (($x498 (not $x596)))
(and $x498 (or $x596 (and (distinct ?x246 ?x246) true))))))))))
(check-sat)
; query 85: function susan_thin, block 685, name %689
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in671_32 () (_ BitVec 32))
(declare-fun in653_32 () (_ BitVec 32))
(declare-fun in662_32 () (_ BitVec 32))
(declare-fun in680_32 () (_ BitVec 32))
(assert
 (let ((?x316 (bvor in653_32 in671_32)))
(let ((?x868 (bvor in680_32 in662_32)))
(let ((?x246 (bvand ?x868 ?x316)))
(let ((?x389 (ite (and (distinct (_ bv0 32) ?x246) true) (_ bv1 1) (_ bv0 1))))
(let (($x743 (or false false false)))
(let (($x596 (or $x743 $x743 false)))
(let (($x548 (or $x596 false false)))
(let (($x635 (not $x548)))
(and $x635 (or $x548 (and (distinct ?x389 ?x389) true))))))))))))
(check-sat)
; query 86: function susan_thin, block 915, name %916
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.13_32 () (_ BitVec 32))
(assert
 (let (($x361 (and (distinct (bvadd ((_ sign_extend 1) in.13_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.13_32 (_ bv1 32)))) true)))
(let (($x98 (or false false (or $x361))))
(and (not $x98) (or $x98 (and (distinct (bvadd in.13_32 (_ bv1 32)) (bvadd in.13_32 (_ bv1 32))) true))))))
(check-sat)
; query 87: function susan_thin, block 918, name %919
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.14.lcssa_32 () (_ BitVec 32))
(assert
 (let (($x993 (and (distinct (bvadd ((_ sign_extend 1) in.14.lcssa_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.14.lcssa_32 (_ bv1 32)))) true)))
(let (($x746 (or false false (or $x993))))
(let (($x397 (or $x746 (and (distinct (bvadd in.14.lcssa_32 (_ bv1 32)) (bvadd in.14.lcssa_32 (_ bv1 32))) true))))
(and (not $x746) $x397)))))
(check-sat)
