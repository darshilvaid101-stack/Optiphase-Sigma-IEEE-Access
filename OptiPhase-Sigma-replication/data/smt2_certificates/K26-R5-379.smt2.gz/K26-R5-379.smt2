; OptiPhase-Sigma refinement certificate for sweep K26-R5-379
