; OptiPhase-Sigma refinement certificate for sweep K45-R2-050
; query 0: function Index_to_frequency, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x124 (ite (bvuge in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x40 (or false false false)))
(let (($x32 (not $x40)))
(and $x32 (or $x40 (and (distinct ?x124 ?x124) true)))))))
(check-sat)
; query 1: function IsPowerOfTwo, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x40 (or false false false)))
(let (($x32 (not $x40)))
(and $x32 (or $x40 (and (distinct (bvsub in0_32 (_ bv1 32)) (bvsub in0_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function IsPowerOfTwo, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x384 (bvsub in0_32 (_ bv1 32))))
(let ((?x823 (bvand in0_32 ?x384)))
(let (($x40 (or false false false)))
(let (($x227 (or false $x40 false)))
(and (not $x227) (or $x227 (and (distinct ?x823 ?x823) true))))))))
(check-sat)
; query 3: function IsPowerOfTwo, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x66 (ite (and (distinct (_ bv0 32) (bvand in0_32 (bvsub in0_32 (_ bv1 32)))) true) (_ bv1 1) (_ bv0 1))))
(let (($x40 (or false false false)))
(let (($x227 (or false $x40 false)))
(let (($x48 (or $x227 false false)))
(and (not $x48) (or $x48 (and (distinct ?x66 ?x66) true))))))))
(check-sat)
; query 4: function IsPowerOfTwo, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x462 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x40 (or false false false)))
(let (($x32 (not $x40)))
(and $x32 (or $x40 (and (distinct ?x462 ?x462) true)))))))
(check-sat)
; query 5: function NumberOfBitsNeeded, block 13, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x40 (or false false false)))
(let (($x32 (not $x40)))
(and $x32 (or $x40 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 6: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x462 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x40 (or false false false)))
(let (($x32 (not $x40)))
(and $x32 (or $x40 (and (distinct ?x462 ?x462) true)))))))
(check-sat)
; query 7: function ReverseBits, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x40 (or false false false)))
(let (($x32 (not $x40)))
(and $x32 (or $x40 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function ReverseBits, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x40 (or false false false)))
(let (($x224 (or $x40 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x185 (not $x224)))
(and $x185 (or $x224 (and (distinct (bvshl in.01_32 (_ bv1 32)) (bvshl in.01_32 (_ bv1 32))) true)))))))
(check-sat)
; query 9: function ReverseBits, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x40 (or false false false)))
(let (($x32 (not $x40)))
(and $x32 (or $x40 (and (distinct (bvand in.0_32 (_ bv1 32)) (bvand in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 10: function ReverseBits, block 5, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x51 (bvand in.0_32 (_ bv1 32))))
(let ((?x68 (bvshl in.01_32 (_ bv1 32))))
(let ((?x139 (bvor ?x68 ?x51)))
(let (($x40 (or false false false)))
(let (($x224 (or $x40 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x37 (or $x224 $x40 false)))
(and (not $x37) (or $x37 (and (distinct ?x139 ?x139) true))))))))))
(check-sat)
; query 11: function ReverseBits, block 5, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x40 (or false false false)))
(let (($x224 (or $x40 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x185 (not $x224)))
(and $x185 (or $x224 (and (distinct (bvlshr in.0_32 (_ bv1 32)) (bvlshr in.0_32 (_ bv1 32))) true)))))))
(check-sat)
; query 12: function fft_float, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x72 (ite (and (distinct (_ bv0 32) in1_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x40 (or false false false)))
(let (($x32 (not $x40)))
(and $x32 (or $x40 (and (distinct ?x72 ?x72) true)))))))
(check-sat)
; query 13: function fft_float, block 152, name %153
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let (($x40 (or false false false)))
(let (($x32 (not $x40)))
(and $x32 (or $x40 (and (distinct (bvadd in.04_32 (_ bv1 32)) (bvadd in.04_32 (_ bv1 32))) true))))))
(check-sat)
; query 14: function fft_float, block 152, name %154
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_32 () (_ BitVec 32))
(assert
 (let (($x40 (or false false false)))
(let (($x32 (not $x40)))
(and $x32 (or $x40 (and (distinct (bvadd in.03_32 (_ bv1 32)) (bvadd in.03_32 (_ bv1 32))) true))))))
(check-sat)
; query 15: function fft_float, block 156, name %157
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x40 (or false false false)))
(let (($x88 (or $x40 (and (distinct (bvadd in.1_32 in.02_32) (bvadd in.1_32 in.02_32)) true))))
(let (($x32 (not $x40)))
(and $x32 $x88)))))
(check-sat)
; query 16: function fft_float, block 159, name %160
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x40 (or false false false)))
(let (($x224 (or $x40 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x185 (not $x224)))
(and $x185 (or $x224 (and (distinct (bvshl in.02_32 (_ bv1 32)) (bvshl in.02_32 (_ bv1 32))) true)))))))
(check-sat)
; query 17: function fft_float, block 161, name %162
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x72 (ite (and (distinct (_ bv0 32) in1_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x40 (or false false false)))
(let (($x32 (not $x40)))
(and $x32 (or $x40 (and (distinct ?x72 ?x72) true)))))))
(check-sat)
; query 18: function fft_float, block 180, name %181
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let (($x40 (or false false false)))
(let (($x32 (not $x40)))
(and $x32 (or $x40 (and (distinct (bvadd in.2_32 (_ bv1 32)) (bvadd in.2_32 (_ bv1 32))) true))))))
(check-sat)
; query 19: function fft_float, block 41, name %42
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.05_32 () (_ BitVec 32))
(assert
 (let (($x40 (or false false false)))
(let (($x32 (not $x40)))
(and $x32 (or $x40 (and (distinct (bvadd in.05_32 (_ bv1 32)) (bvadd in.05_32 (_ bv1 32))) true))))))
(check-sat)
; query 20: function main, block 110, name %111
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x40 (or false false false)))
(let (($x32 (not $x40)))
(and $x32 (or $x40 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 21: function main, block 113, name %114
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x40 (or false false false)))
(let (($x32 (not $x40)))
(and $x32 (or $x40 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 22: function main, block 126, name %127
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let (($x40 (or false false false)))
(let (($x32 (not $x40)))
(and $x32 (or $x40 (and (distinct (bvadd in.2_32 (_ bv1 32)) (bvadd in.2_32 (_ bv1 32))) true))))))
(check-sat)
; query 23: function main, block 139, name %140
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.3_32 () (_ BitVec 32))
(assert
 (let (($x40 (or false false false)))
(let (($x32 (not $x40)))
(and $x32 (or $x40 (and (distinct (bvadd in.3_32 (_ bv1 32)) (bvadd in.3_32 (_ bv1 32))) true))))))
(check-sat)
; query 24: function main, block 57, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x40 (or false false false)))
(let (($x32 (not $x40)))
(and $x32 (or $x40 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 25: function main, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x29 (ite (= (_ bv4 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x40 (or false false false)))
(let (($x32 (not $x40)))
(and $x32 (or $x40 (and (distinct ?x29 ?x29) true)))))))
(check-sat)
; query 26: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x86 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x40 (or false false false)))
(let (($x32 (not $x40)))
(and $x32 (or $x40 (and (distinct ?x86 ?x86) true)))))))
(check-sat)
