; OptiPhase-Sigma refinement certificate for sweep K27-R4-335
