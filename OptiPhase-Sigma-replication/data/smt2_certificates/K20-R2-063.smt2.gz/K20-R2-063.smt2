; OptiPhase-Sigma refinement certificate for sweep K20-R2-063
