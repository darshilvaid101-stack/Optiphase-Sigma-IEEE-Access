; OptiPhase-Sigma refinement certificate for sweep K41-R1-001
