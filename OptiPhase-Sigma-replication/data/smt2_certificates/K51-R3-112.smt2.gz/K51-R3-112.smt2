; OptiPhase-Sigma refinement certificate for sweep K51-R3-112
; query 0: function check, block 142, name %143
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x587 (and (distinct (ite (= (_ bv123 32) in0_32) (_ bv1 1) (_ bv0 1)) (ite (= (_ bv1122 32) in0_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x295 (or false false false)))
(let (($x88 (not $x295)))
(and $x88 (or $x295 $x587))))))
(check-sat)
; query 1: function check, block 157, name %158
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x306 (and (distinct (ite (= (_ bv112233 32) in0_32) (_ bv1 1) (_ bv0 1)) (ite (= (_ bv111 32) in0_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x295 (or false false false)))
(let (($x88 (not $x295)))
(and $x88 (or $x295 $x306))))))
(check-sat)
; query 2: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x48 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x295 (or false false false)))
(let (($x88 (not $x295)))
(and $x88 (or $x295 (and (distinct ?x48 ?x48) true)))))))
(check-sat)
; query 3: function s115, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x872 (and (distinct (bvadd ((_ zero_extend 1) in.01_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x813 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x106 (or (or false false (or $x813 $x872)) (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))
(and (not (or false false (or $x813))) $x106)))))
(check-sat)
; query 4: function set1d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x142 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x295 (or false false false)))
(let (($x88 (not $x295)))
(and $x88 (or $x295 (and (distinct ?x142 ?x142) true)))))))
(check-sat)
; query 5: function set1ds, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x91 (ite (= (_ bv4294967295 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x295 (or false false false)))
(let (($x88 (not $x295)))
(and $x88 (or $x295 (and (distinct ?x91 ?x91) true)))))))
(check-sat)
; query 6: function set2d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x142 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x295 (or false false false)))
(let (($x88 (not $x295)))
(and $x88 (or $x295 (and (distinct ?x142 ?x142) true)))))))
(check-sat)
