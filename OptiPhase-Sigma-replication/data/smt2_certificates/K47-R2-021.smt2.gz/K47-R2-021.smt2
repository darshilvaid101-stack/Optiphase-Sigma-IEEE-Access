; OptiPhase-Sigma refinement certificate for sweep K47-R2-021
; query 0: function adpcm_coder, block 25, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in20_32 () (_ BitVec 32))
(assert
 (let (($x555 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in20_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in20_32))) true)))
(let (($x86 (or false false (or $x555))))
(and (not $x86) (or $x86 (and (distinct (bvsub (_ bv0 32) in20_32) (bvsub (_ bv0 32) in20_32)) true))))))
(check-sat)
; query 1: function adpcm_coder, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(declare-fun in.017_32 () (_ BitVec 32))
(assert
 (let ((?x848 (bvsub in.017_32 in.020_32)))
(let (($x145 (and (distinct (bvsub ((_ sign_extend 1) in.017_32) ((_ sign_extend 1) in.020_32)) ((_ sign_extend 1) ?x848)) true)))
(let (($x300 (or false false (or $x145))))
(and (not $x300) (or $x300 (and (distinct ?x848 ?x848) true)))))))
(check-sat)
; query 2: function adpcm_coder, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(declare-fun in28_32 () (_ BitVec 32))
(assert
 (let (($x467 (and (distinct (bvadd ((_ sign_extend 1) in28_32) ((_ sign_extend 1) in.020_32)) ((_ sign_extend 1) (bvadd in28_32 in.020_32))) true)))
(let (($x1278 (or false false (or $x467))))
(let (($x44 (or $x1278 (and (distinct (bvadd in28_32 in.020_32) (bvadd in28_32 in.020_32)) true))))
(and (not $x1278) $x44)))))
(check-sat)
; query 3: function adpcm_coder, block 36, name %37
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.014_32 () (_ BitVec 32))
(assert
 (let (($x753 (or false false false)))
(let (($x275 (not $x753)))
(and $x275 (or $x753 (and (distinct (bvor in.014_32 (_ bv2 32)) (bvor in.014_32 (_ bv2 32))) true))))))
(check-sat)
; query 4: function adpcm_coder, block 36, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in34_32 () (_ BitVec 32))
(declare-fun in.118_32 () (_ BitVec 32))
(assert
 (let (($x23 (and (distinct (bvsub ((_ sign_extend 1) in.118_32) ((_ sign_extend 1) in34_32)) ((_ sign_extend 1) (bvsub in.118_32 in34_32))) true)))
(let (($x377 (or false false (or $x23))))
(let (($x584 (or $x377 (and (distinct (bvsub in.118_32 in34_32) (bvsub in.118_32 in34_32)) true))))
(and (not $x377) $x584)))))
(check-sat)
; query 5: function adpcm_coder, block 36, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in34_32 () (_ BitVec 32))
(declare-fun in.08_32 () (_ BitVec 32))
(assert
 (let (($x717 (and (distinct (bvadd ((_ sign_extend 1) in.08_32) ((_ sign_extend 1) in34_32)) ((_ sign_extend 1) (bvadd in.08_32 in34_32))) true)))
(let (($x250 (or false false (or $x717))))
(let (($x121 (or $x250 (and (distinct (bvadd in.08_32 in34_32) (bvadd in.08_32 in34_32)) true))))
(and (not $x250) $x121)))))
(check-sat)
; query 6: function adpcm_coder, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.115_32 () (_ BitVec 32))
(assert
 (let (($x753 (or false false false)))
(let (($x275 (not $x753)))
(and $x275 (or $x753 (and (distinct (bvor in.115_32 (_ bv1 32)) (bvor in.115_32 (_ bv1 32))) true))))))
(check-sat)
; query 7: function adpcm_coder, block 43, name %45
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in41_32 () (_ BitVec 32))
(declare-fun in.19_32 () (_ BitVec 32))
(assert
 (let (($x147 (and (distinct (bvadd ((_ sign_extend 1) in.19_32) ((_ sign_extend 1) in41_32)) ((_ sign_extend 1) (bvadd in.19_32 in41_32))) true)))
(let (($x69 (or false false (or $x147))))
(let (($x1699 (or $x69 (and (distinct (bvadd in.19_32 in41_32) (bvadd in.19_32 in41_32)) true))))
(and (not $x69) $x1699)))))
(check-sat)
; query 8: function adpcm_coder, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.210_32 () (_ BitVec 32))
(declare-fun in.011_32 () (_ BitVec 32))
(assert
 (let ((?x81 (bvsub in.011_32 in.210_32)))
(let (($x473 (and (distinct (bvsub ((_ sign_extend 1) in.011_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x81)) true)))
(let (($x217 (or false false (or $x473))))
(and (not $x217) (or $x217 (and (distinct ?x81 ?x81) true)))))))
(check-sat)
; query 9: function adpcm_coder, block 50, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.210_32 () (_ BitVec 32))
(declare-fun in.011_32 () (_ BitVec 32))
(assert
 (let ((?x9 (bvadd in.011_32 in.210_32)))
(let (($x1219 (and (distinct (bvadd ((_ sign_extend 1) in.011_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x9)) true)))
(let (($x656 (or false false (or $x1219))))
(and (not $x656) (or $x656 (and (distinct ?x9 ?x9) true)))))))
(check-sat)
; query 10: function adpcm_decoder, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x56 (ite (and (distinct (_ bv0 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x753 (or false false false)))
(let (($x275 (not $x753)))
(and $x275 (or $x753 (and (distinct ?x56 ?x56) true)))))))
(check-sat)
; query 11: function adpcm_decoder, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x753 (or false false false)))
(let (($x275 (not $x753)))
(and $x275 (or $x753 (and (distinct (bvand in.01_32 (_ bv15 32)) (bvand in.01_32 (_ bv15 32))) true))))))
(check-sat)
; query 12: function adpcm_decoder, block 61, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.210_32 () (_ BitVec 32))
(declare-fun in.013_32 () (_ BitVec 32))
(assert
 (let ((?x1190 (bvadd in.013_32 in.210_32)))
(let ((?x53 (bvsub in.013_32 in.210_32)))
(let (($x1309 (and (distinct (bvadd ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x1190)) true)))
(let (($x769 (and (distinct (bvsub ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x53)) true)))
(and (not (or false false (or $x769))) (or (or false false (or $x1309)) (and (distinct ?x53 ?x1190) true))))))))
(check-sat)
; query 13: function main, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x818 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x753 (or false false false)))
(let (($x275 (not $x753)))
(and $x275 (or $x753 (and (distinct ?x818 ?x818) true)))))))
(check-sat)
