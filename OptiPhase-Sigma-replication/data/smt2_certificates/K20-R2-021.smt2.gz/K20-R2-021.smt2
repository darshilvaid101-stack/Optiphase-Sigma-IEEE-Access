; OptiPhase-Sigma refinement certificate for sweep K20-R2-021
; query 0: function xmalloc, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in7_32 () (_ BitVec 32))
(assert
 (let ((?x227 (ite (and (distinct (_ bv0 32) in7_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x226 (or false false false)))
(and (not $x226) (or $x226 (and (distinct ?x227 ?x227) true))))))
(check-sat)
