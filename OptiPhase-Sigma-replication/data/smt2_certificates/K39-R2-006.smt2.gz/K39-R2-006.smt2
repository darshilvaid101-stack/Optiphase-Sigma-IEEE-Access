; OptiPhase-Sigma refinement certificate for sweep K39-R2-006
; query 0: function BF_cbc_encrypt, block 126, name %127
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.010_64 () (_ BitVec 64))
(assert
 (let (($x131 (and (distinct (bvsub ((_ sign_extend 1) in.010_64) ((_ sign_extend 1) (_ bv8 64))) ((_ sign_extend 1) (bvsub in.010_64 (_ bv8 64)))) true)))
(let (($x231 (or false false (or $x131))))
(and (not $x231) (or $x231 (and (distinct (bvsub in.010_64 (_ bv8 64)) (bvsub in.010_64 (_ bv8 64))) true))))))
(check-sat)
; query 1: function BF_cbc_encrypt, block 128, name %129
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.010_64 () (_ BitVec 64))
(assert
 (let ((?x90 (ite (and (distinct (_ bv18446744073709551608 64) in.010_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x66 (or false false false)))
(let (($x311 (not $x66)))
(and $x311 (or $x66 (and (distinct ?x90 ?x90) true)))))))
(check-sat)
; query 2: function BF_cbc_encrypt, block 366, name %367
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.111_64 () (_ BitVec 64))
(assert
 (let (($x13 (and (distinct (bvsub ((_ sign_extend 1) in.111_64) ((_ sign_extend 1) (_ bv8 64))) ((_ sign_extend 1) (bvsub in.111_64 (_ bv8 64)))) true)))
(let (($x628 (or false false (or $x13))))
(and (not $x628) (or $x628 (and (distinct (bvsub in.111_64 (_ bv8 64)) (bvsub in.111_64 (_ bv8 64))) true))))))
(check-sat)
; query 3: function BF_cbc_encrypt, block 368, name %369
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.111_64 () (_ BitVec 64))
(assert
 (let ((?x52 (ite (and (distinct (_ bv18446744073709551608 64) in.111_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x66 (or false false false)))
(let (($x311 (not $x66)))
(and $x311 (or $x66 (and (distinct ?x52 ?x52) true)))))))
(check-sat)
; query 4: function BF_cfb64_encrypt, block 111, name %112
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.18_32 () (_ BitVec 32))
(assert
 (let ((?x44 (ite (= (_ bv0 32) in.18_32) (_ bv1 1) (_ bv0 1))))
(let (($x66 (or false false false)))
(let (($x311 (not $x66)))
(and $x311 (or $x66 (and (distinct ?x44 ?x44) true)))))))
(check-sat)
; query 5: function BF_cfb64_encrypt, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.07_32 () (_ BitVec 32))
(assert
 (let ((?x42 (ite (= (_ bv0 32) in.07_32) (_ bv1 1) (_ bv0 1))))
(let (($x66 (or false false false)))
(let (($x311 (not $x66)))
(and $x311 (or $x66 (and (distinct ?x42 ?x42) true)))))))
(check-sat)
; query 6: function BF_ofb64_encrypt, block 135, name %136
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x80 (ite (and (distinct (_ bv0 32) in.02_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x66 (or false false false)))
(let (($x311 (not $x66)))
(and $x311 (or $x66 (and (distinct ?x80 ?x80) true)))))))
(check-sat)
; query 7: function BF_ofb64_encrypt, block 82, name %83
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x135 (ite (= (_ bv0 32) in.04_32) (_ bv1 1) (_ bv0 1))))
(let (($x66 (or false false false)))
(let (($x311 (not $x66)))
(and $x311 (or $x66 (and (distinct ?x135 ?x135) true)))))))
(check-sat)
; query 8: function BF_set_key, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x89 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x148 (or false false (or $x89))))
(and (not $x148) (or $x148 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 9: function BF_set_key, block 69, name %70
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.13_32 () (_ BitVec 32))
(assert
 (let (($x35 (and (distinct (bvadd ((_ sign_extend 1) in.13_32) ((_ sign_extend 1) (_ bv2 32))) ((_ sign_extend 1) (bvadd in.13_32 (_ bv2 32)))) true)))
(let (($x97 (or false false (or $x35))))
(and (not $x97) (or $x97 (and (distinct (bvadd in.13_32 (_ bv2 32)) (bvadd in.13_32 (_ bv2 32))) true))))))
(check-sat)
; query 10: function BF_set_key, block 87, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.24_32 () (_ BitVec 32))
(assert
 (let (($x55 (and (distinct (bvadd ((_ sign_extend 1) in.24_32) ((_ sign_extend 1) (_ bv2 32))) ((_ sign_extend 1) (bvadd in.24_32 (_ bv2 32)))) true)))
(let (($x130 (or false false (or $x55))))
(and (not $x130) (or $x130 (and (distinct (bvadd in.24_32 (_ bv2 32)) (bvadd in.24_32 (_ bv2 32))) true))))))
(check-sat)
; query 11: function main, block 124, name %125
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let ((?x65 (ite (bvsgt (_ bv40 32) in.2_32) (_ bv1 1) (_ bv0 1))))
(let (($x66 (or false false false)))
(let (($x311 (not $x66)))
(and $x311 (or $x66 (and (distinct ?x65 ?x65) true)))))))
(check-sat)
; query 12: function main, block 147, name %148
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x109 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x249 (or false false (or $x109))))
(and (not $x249) (or $x249 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 13: function main, block 60, name %61
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x167 (or false false)))
(and (not $x167) (or $x167 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 14: function main, block 60, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x93 (ite (bvsge (_ bv57 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x167 (or false false)))
(let (($x115 (or $x167 false false)))
(let (($x234 (not $x115)))
(and $x234 (or $x115 (and (distinct ?x93 ?x93) true))))))))
(check-sat)
; query 15: function main, block 63, name %64
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x66 (or false false false)))
(let (($x117 (or $x66 (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x117) (or $x117 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvshl in.01_32 (_ bv4 32))) true))))))
(check-sat)
; query 16: function main, block 63, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x167 (or false false)))
(and (not $x167) (or $x167 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 17: function main, block 63, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x191 ((_ sign_extend 24) in57_8)))
(let ((?x609 (bvshl in.01_32 (_ bv4 32))))
(let ((?x169 (bvadd ?x609 ?x191)))
(let ((?x105 ((_ sign_extend 1) ?x169)))
(let (($x167 (or false false)))
(let (($x66 (or false false false)))
(let (($x117 (or $x66 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x185 (or $x117 $x167 (or (and (distinct (bvadd ((_ sign_extend 1) ?x609) ((_ sign_extend 1) ?x191)) ?x105) true)))))
(and (not $x185) (or $x185 (and (distinct ?x169 ?x169) true))))))))))))
(check-sat)
; query 18: function main, block 63, name %67
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x191 ((_ sign_extend 24) in57_8)))
(let ((?x609 (bvshl in.01_32 (_ bv4 32))))
(let ((?x169 (bvadd ?x609 ?x191)))
(let ((?x614 (bvsub ?x169 (_ bv48 32))))
(let (($x447 (and (distinct (bvsub ((_ sign_extend 1) ?x169) ((_ sign_extend 1) (_ bv48 32))) ((_ sign_extend 1) ?x614)) true)))
(let ((?x105 ((_ sign_extend 1) ?x169)))
(let (($x167 (or false false)))
(let (($x66 (or false false false)))
(let (($x117 (or $x66 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x185 (or $x117 $x167 (or (and (distinct (bvadd ((_ sign_extend 1) ?x609) ((_ sign_extend 1) ?x191)) ?x105) true)))))
(let (($x25 (or $x185 false (or $x447))))
(and (not $x25) (or $x25 (and (distinct ?x614 ?x614) true)))))))))))))))
(check-sat)
; query 19: function main, block 68, name %69
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x167 (or false false)))
(and (not $x167) (or $x167 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 20: function main, block 68, name %70
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x78 (ite (bvsle (_ bv65 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x167 (or false false)))
(let (($x115 (or $x167 false false)))
(let (($x234 (not $x115)))
(and $x234 (or $x115 (and (distinct ?x78 ?x78) true))))))))
(check-sat)
; query 21: function main, block 71, name %72
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x167 (or false false)))
(and (not $x167) (or $x167 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 22: function main, block 71, name %73
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x76 (ite (bvsge (_ bv70 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x167 (or false false)))
(let (($x115 (or $x167 false false)))
(let (($x234 (not $x115)))
(and $x234 (or $x115 (and (distinct ?x76 ?x76) true))))))))
(check-sat)
; query 23: function main, block 74, name %75
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x66 (or false false false)))
(let (($x117 (or $x66 (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x117) (or $x117 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvshl in.01_32 (_ bv4 32))) true))))))
(check-sat)
; query 24: function main, block 74, name %76
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x167 (or false false)))
(and (not $x167) (or $x167 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 25: function main, block 74, name %77
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x191 ((_ sign_extend 24) in57_8)))
(let ((?x609 (bvshl in.01_32 (_ bv4 32))))
(let ((?x169 (bvadd ?x609 ?x191)))
(let ((?x105 ((_ sign_extend 1) ?x169)))
(let (($x167 (or false false)))
(let (($x66 (or false false false)))
(let (($x117 (or $x66 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x185 (or $x117 $x167 (or (and (distinct (bvadd ((_ sign_extend 1) ?x609) ((_ sign_extend 1) ?x191)) ?x105) true)))))
(and (not $x185) (or $x185 (and (distinct ?x169 ?x169) true))))))))))))
(check-sat)
; query 26: function main, block 74, name %78
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x191 ((_ sign_extend 24) in57_8)))
(let ((?x609 (bvshl in.01_32 (_ bv4 32))))
(let ((?x169 (bvadd ?x609 ?x191)))
(let ((?x88 (bvsub ?x169 (_ bv65 32))))
(let ((?x266 ((_ sign_extend 1) ?x88)))
(let ((?x105 ((_ sign_extend 1) ?x169)))
(let (($x167 (or false false)))
(let (($x66 (or false false false)))
(let (($x117 (or $x66 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x185 (or $x117 $x167 (or (and (distinct (bvadd ((_ sign_extend 1) ?x609) ((_ sign_extend 1) ?x191)) ?x105) true)))))
(let (($x382 (or $x185 false (or (and (distinct (bvsub ?x105 ((_ sign_extend 1) (_ bv65 32))) ?x266) true)))))
(and (not $x382) (or $x382 (and (distinct ?x88 ?x88) true)))))))))))))))
(check-sat)
; query 27: function main, block 74, name %79
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x191 ((_ sign_extend 24) in57_8)))
(let ((?x609 (bvshl in.01_32 (_ bv4 32))))
(let ((?x169 (bvadd ?x609 ?x191)))
(let ((?x88 (bvsub ?x169 (_ bv65 32))))
(let ((?x687 (bvadd ?x88 (_ bv10 32))))
(let (($x19 (and (distinct (bvadd ((_ sign_extend 1) ?x88) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x687)) true)))
(let ((?x266 ((_ sign_extend 1) ?x88)))
(let ((?x105 ((_ sign_extend 1) ?x169)))
(let (($x167 (or false false)))
(let (($x66 (or false false false)))
(let (($x117 (or $x66 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x185 (or $x117 $x167 (or (and (distinct (bvadd ((_ sign_extend 1) ?x609) ((_ sign_extend 1) ?x191)) ?x105) true)))))
(let (($x382 (or $x185 false (or (and (distinct (bvsub ?x105 ((_ sign_extend 1) (_ bv65 32))) ?x266) true)))))
(let (($x21 (or $x382 false (or $x19))))
(and (not $x21) (or $x21 (and (distinct ?x687 ?x687) true))))))))))))))))))
(check-sat)
