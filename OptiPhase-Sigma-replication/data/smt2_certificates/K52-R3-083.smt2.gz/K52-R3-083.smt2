; OptiPhase-Sigma refinement certificate for sweep K52-R3-083
; query 0: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x382 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x338 (or false false false)))
(let (($x1395 (not $x338)))
(and $x1395 (or $x338 (and (distinct ?x382 ?x382) true)))))))
(check-sat)
; query 1: function s162, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x1334 (ite (bvslt (_ bv0 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x338 (or false false false)))
(let (($x1395 (not $x338)))
(and $x1395 (or $x338 (and (distinct ?x1334 ?x1334) true)))))))
(check-sat)
