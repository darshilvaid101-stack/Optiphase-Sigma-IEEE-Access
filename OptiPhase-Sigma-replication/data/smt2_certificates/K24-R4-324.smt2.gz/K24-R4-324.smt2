; OptiPhase-Sigma refinement certificate for sweep K24-R4-324
