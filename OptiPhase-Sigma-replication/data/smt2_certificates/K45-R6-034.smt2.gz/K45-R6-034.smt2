; OptiPhase-Sigma refinement certificate for sweep K45-R6-034
; query 0: function IsPowerOfTwo, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x104 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x759 (or false false false)))
(let (($x313 (not $x759)))
(and $x313 (or $x759 (and (distinct ?x104 ?x104) true)))))))
(check-sat)
; query 1: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x104 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x759 (or false false false)))
(let (($x313 (not $x759)))
(and $x313 (or $x759 (and (distinct ?x104 ?x104) true)))))))
(check-sat)
; query 2: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x27 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x759 (or false false false)))
(let (($x313 (not $x759)))
(and $x313 (or $x759 (and (distinct ?x27 ?x27) true)))))))
(check-sat)
