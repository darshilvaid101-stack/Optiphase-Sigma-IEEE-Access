; OptiPhase-Sigma refinement certificate for sweep K31-R2-008
