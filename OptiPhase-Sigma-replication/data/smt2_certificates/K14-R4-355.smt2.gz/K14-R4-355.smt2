; OptiPhase-Sigma refinement certificate for sweep K14-R4-355
