; OptiPhase-Sigma refinement certificate for sweep K41-R3-187
; query 0: function set_key, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let (($x1278 (or false false false)))
(and (not $x1278) (or $x1278 (and (distinct (bvand in1_64 (_ bv7 64)) (bvand in1_64 (_ bv7 64))) true)))))
(check-sat)
