; OptiPhase-Sigma refinement certificate for sweep K34-R6-003
; query 0: function corner_draw, block 11, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x148 (ite (= (_ bv0 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x674 (or false false false)))
(let (($x129 (not $x674)))
(and $x129 (or $x674 (and (distinct ?x148 ?x148) true)))))))
(check-sat)
; query 1: function edge_draw, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let ((?x32 (ite (= (_ bv0 32) in4_32) (_ bv1 1) (_ bv0 1))))
(let (($x674 (or false false false)))
(let (($x129 (not $x674)))
(and $x129 (or $x674 (and (distinct ?x32 ?x32) true)))))))
(check-sat)
; query 2: function main, block 129, name %130
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.011_32 () (_ BitVec 32))
(assert
 (let ((?x10 (ite (and (distinct (_ bv0 32) in.011_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x674 (or false false false)))
(let (($x129 (not $x674)))
(and $x129 (or $x674 (and (distinct ?x10 ?x10) true)))))))
(check-sat)
; query 3: function main, block 160, name %161
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x27 (ite (and (distinct (_ bv0 32) in.01_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x674 (or false false false)))
(let (($x129 (not $x674)))
(and $x129 (or $x674 (and (distinct ?x27 ?x27) true)))))))
(check-sat)
; query 4: function main, block 35, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x50 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x31 (or false false (or $x50))))
(and (not $x31) (or $x31 (and (distinct (bvadd in.020_32 (_ bv1 32)) (bvadd in.020_32 (_ bv1 32))) true))))))
(check-sat)
; query 5: function main, block 35, name %37
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let ((?x123 (ite (bvsge (bvadd in.020_32 (_ bv1 32)) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x50 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x31 (or false false (or $x50))))
(let (($x118 (or $x31 false false)))
(and (not $x118) (or $x118 (and (distinct ?x123 ?x123) true))))))))
(check-sat)
; query 6: function main, block 49, name %50
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x50 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x31 (or false false (or $x50))))
(and (not $x31) (or $x31 (and (distinct (bvadd in.020_32 (_ bv1 32)) (bvadd in.020_32 (_ bv1 32))) true))))))
(check-sat)
; query 7: function main, block 49, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let ((?x123 (ite (bvsge (bvadd in.020_32 (_ bv1 32)) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x50 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x31 (or false false (or $x50))))
(let (($x118 (or $x31 false false)))
(and (not $x118) (or $x118 (and (distinct ?x123 ?x123) true))))))))
(check-sat)
; query 8: function main, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.014_32 () (_ BitVec 32))
(assert
 (let ((?x606 (ite (= (_ bv1 32) in.014_32) (_ bv1 1) (_ bv0 1))))
(let (($x674 (or false false false)))
(let (($x129 (not $x674)))
(and $x129 (or $x674 (and (distinct ?x606 ?x606) true)))))))
(check-sat)
; query 9: function main, block 66, name %67
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x125 (ite (= (_ bv0 32) in.0_32) (_ bv1 1) (_ bv0 1))))
(let (($x674 (or false false false)))
(let (($x129 (not $x674)))
(and $x129 (or $x674 (and (distinct ?x125 ?x125) true)))))))
(check-sat)
; query 10: function main, block 84, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.07_32 () (_ BitVec 32))
(assert
 (let ((?x119 (ite (and (distinct (_ bv0 32) in.07_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x674 (or false false false)))
(let (($x129 (not $x674)))
(and $x129 (or $x674 (and (distinct ?x119 ?x119) true)))))))
(check-sat)
