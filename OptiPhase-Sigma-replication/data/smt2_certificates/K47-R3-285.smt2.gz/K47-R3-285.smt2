; OptiPhase-Sigma refinement certificate for sweep K47-R3-285
; query 0: function adpcm_decoder, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x178 (ite (and (distinct (_ bv0 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x674 (or false false false)))
(let (($x168 (not $x674)))
(and $x168 (or $x674 (and (distinct ?x178 ?x178) true)))))))
(check-sat)
; query 1: function adpcm_decoder, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x674 (or false false false)))
(let (($x168 (not $x674)))
(and $x168 (or $x674 (and (distinct (bvand in.01_32 (_ bv15 32)) (bvand in.01_32 (_ bv15 32))) true))))))
(check-sat)
; query 2: function adpcm_decoder, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.012_32 () (_ BitVec 32))
(declare-fun in42_32 () (_ BitVec 32))
(assert
 (let (($x182 (and (distinct (bvadd ((_ sign_extend 1) in42_32) ((_ sign_extend 1) in.012_32)) ((_ sign_extend 1) (bvadd in42_32 in.012_32))) true)))
(let (($x177 (or false false (or $x182))))
(let (($x104 (or $x177 (and (distinct (bvadd in42_32 in.012_32) (bvadd in42_32 in.012_32)) true))))
(and (not $x177) $x104)))))
(check-sat)
; query 3: function adpcm_decoder, block 50, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.012_32 () (_ BitVec 32))
(assert
 (let (($x674 (or false false false)))
(let (($x152 (or $x674 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x302 (or $x152 (and (distinct (bvashr in.012_32 (_ bv1 32)) (bvashr in.012_32 (_ bv1 32))) true))))
(and (not $x152) $x302)))))
(check-sat)
; query 4: function adpcm_decoder, block 50, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.012_32 () (_ BitVec 32))
(declare-fun in.08_32 () (_ BitVec 32))
(assert
 (let ((?x99 (bvashr in.012_32 (_ bv1 32))))
(let ((?x2791 (bvadd in.08_32 ?x99)))
(let (($x467 (and (distinct (bvadd ((_ sign_extend 1) in.08_32) ((_ sign_extend 1) ?x99)) ((_ sign_extend 1) ?x2791)) true)))
(let (($x674 (or false false false)))
(let (($x152 (or $x674 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x67 (or false $x152 (or $x467))))
(and (not $x67) (or $x67 (and (distinct ?x2791 ?x2791) true))))))))))
(check-sat)
; query 5: function adpcm_decoder, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.012_32 () (_ BitVec 32))
(assert
 (let (($x674 (or false false false)))
(let (($x61 (or $x674 (bvuge (_ bv2 32) (_ bv32 32)))))
(let (($x155 (or $x61 (and (distinct (bvashr in.012_32 (_ bv2 32)) (bvashr in.012_32 (_ bv2 32))) true))))
(and (not $x61) $x155)))))
(check-sat)
; query 6: function adpcm_decoder, block 56, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.012_32 () (_ BitVec 32))
(declare-fun in.19_32 () (_ BitVec 32))
(assert
 (let ((?x143 (bvashr in.012_32 (_ bv2 32))))
(let ((?x81 (bvadd in.19_32 ?x143)))
(let (($x160 (and (distinct (bvadd ((_ sign_extend 1) in.19_32) ((_ sign_extend 1) ?x143)) ((_ sign_extend 1) ?x81)) true)))
(let (($x674 (or false false false)))
(let (($x61 (or $x674 (bvuge (_ bv2 32) (_ bv32 32)))))
(let (($x149 (or false $x61 (or $x160))))
(and (not $x149) (or $x149 (and (distinct ?x81 ?x81) true))))))))))
(check-sat)
; query 7: function adpcm_decoder, block 61, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.210_32 () (_ BitVec 32))
(declare-fun in.013_32 () (_ BitVec 32))
(assert
 (let ((?x47 (bvsub in.013_32 in.210_32)))
(let (($x128 (and (distinct (bvsub ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x47)) true)))
(let (($x610 (or false false (or $x128))))
(and (not $x610) (or $x610 (and (distinct ?x47 ?x47) true)))))))
(check-sat)
; query 8: function adpcm_decoder, block 63, name %64
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.013_32 () (_ BitVec 32))
(declare-fun in.210_32 () (_ BitVec 32))
(assert
 (let ((?x14 (bvadd in.210_32 in.013_32)))
(let ((?x32 (bvadd in.013_32 in.210_32)))
(let (($x175 (and (distinct (bvadd ((_ sign_extend 1) in.210_32) ((_ sign_extend 1) in.013_32)) ((_ sign_extend 1) ?x14)) true)))
(let (($x167 (and (distinct (bvadd ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x32)) true)))
(and (not (or false false (or $x167))) (or (or false false (or $x175)) (and (distinct ?x32 ?x14) true))))))))
(check-sat)
; query 9: function adpcm_decoder, block 68, name %69
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.114_32 () (_ BitVec 32))
(assert
 (let ((?x134 (ite (bvsgt (_ bv4294934528 32) in.114_32) (_ bv1 1) (_ bv0 1))))
(let (($x674 (or false false false)))
(let (($x168 (not $x674)))
(and $x168 (or $x674 (and (distinct ?x134 ?x134) true)))))))
(check-sat)
; query 10: function adpcm_decoder, block 78, name %79
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x180 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv4294967295 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv4294967295 32)))) true)))
(let (($x157 (or false false (or $x180))))
(and (not $x157) (or $x157 (and (distinct (bvadd in.02_32 (_ bv4294967295 32)) (bvadd in.02_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 11: function main, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x170 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x674 (or false false false)))
(let (($x168 (not $x674)))
(and $x168 (or $x674 (and (distinct ?x170 ?x170) true)))))))
(check-sat)
