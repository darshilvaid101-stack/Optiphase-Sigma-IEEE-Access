; OptiPhase-Sigma refinement certificate for sweep K33-R6-017
; query 0: function edge_draw, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let ((?x35 (ite (= (_ bv0 32) in4_32) (_ bv1 1) (_ bv0 1))))
(let (($x118 (or false false false)))
(let (($x294 (not $x118)))
(and $x294 (or $x118 (and (distinct ?x35 ?x35) true)))))))
(check-sat)
; query 1: function main, block 129, name %130
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.011.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x611 (ite (and (distinct (_ bv0 32) in.011.lcssa_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x118 (or false false false)))
(let (($x294 (not $x118)))
(and $x294 (or $x118 (and (distinct ?x611 ?x611) true)))))))
(check-sat)
; query 2: function main, block 160, name %161
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x122 (ite (and (distinct (_ bv0 32) in.01.lcssa_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x118 (or false false false)))
(let (($x294 (not $x118)))
(and $x294 (or $x118 (and (distinct ?x122 ?x122) true)))))))
(check-sat)
; query 3: function main, block 66, name %67
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x6 (ite (= (_ bv0 32) in.0.lcssa_32) (_ bv1 1) (_ bv0 1))))
(let (($x118 (or false false false)))
(let (($x294 (not $x118)))
(and $x294 (or $x118 (and (distinct ?x6 ?x6) true)))))))
(check-sat)
; query 4: function main, block 84, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.07.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x93 (ite (and (distinct (_ bv0 32) in.07.lcssa_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x118 (or false false false)))
(let (($x294 (not $x118)))
(and $x294 (or $x118 (and (distinct ?x93 ?x93) true)))))))
(check-sat)
