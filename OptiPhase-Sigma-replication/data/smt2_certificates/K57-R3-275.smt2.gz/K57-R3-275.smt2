; OptiPhase-Sigma refinement certificate for sweep K57-R3-275
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x623 (or false false)))
(let (($x16 (not $x623)))
(and $x16 (or $x623 (and (distinct ((_ sign_extend 16) in25_16) ((_ sign_extend 16) in25_16)) true))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let ((?x1813 (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))))
(let (($x623 (or false false)))
(let (($x43 (or $x623 false false)))
(let (($x641 (not $x43)))
(and $x641 (or $x43 (and (distinct ?x1813 ?x1813) true))))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x623 (or false false)))
(let (($x16 (not $x623)))
(and $x16 (or $x623 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x18 ((_ sign_extend 16) in3_16)))
(let ((?x67 (bvand ?x18 (_ bv127 32))))
(let (($x623 (or false false)))
(let (($x43 (or $x623 false false)))
(let (($x641 (not $x43)))
(and $x641 (or $x43 (and (distinct ?x67 ?x67) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x18 ((_ sign_extend 16) in3_16)))
(let ((?x67 (bvand ?x18 (_ bv127 32))))
(let ((?x1856 ((_ extract 15 0) ?x67)))
(let (($x623 (or false false)))
(let (($x43 (or $x623 false false)))
(let (($x382 (or $x43 false)))
(let (($x1814 (not $x382)))
(and $x1814 (or $x382 (and (distinct ?x1856 ?x1856) true)))))))))))
(check-sat)
; query 5: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x623 (or false false)))
(let (($x16 (not $x623)))
(and $x16 (or $x623 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 6: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x185 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x623 (or false false)))
(let (($x43 (or $x623 false false)))
(let (($x641 (not $x43)))
(and $x641 (or $x43 (and (distinct ?x185 ?x185) true))))))))
(check-sat)
; query 7: function core_bench_list, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x654 (or false false false)))
(let (($x169 (not $x654)))
(and $x169 (or $x654 (and (distinct (bvadd in.0_16 (_ bv1 16)) (bvadd in.0_16 (_ bv1 16))) true))))))
(check-sat)
; query 8: function core_bench_list, block 82, name %83
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let (($x623 (or false false)))
(let (($x16 (not $x623)))
(and $x16 (or $x623 (and (distinct ((_ zero_extend 16) in.02_16) ((_ zero_extend 16) in.02_16)) true))))))
(check-sat)
; query 9: function core_bench_list, block 82, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x536 ((_ zero_extend 16) in.02_16)))
(let ((?x3821 (bvmul ?x536 (_ bv4 32))))
(let (($x28 (and (distinct (bvmul ((_ sign_extend 32) ?x536) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x3821)) true)))
(let (($x623 (or false false)))
(let (($x338 (or $x623 false (or $x28))))
(and (not $x338) (or $x338 (and (distinct ?x3821 ?x3821) true)))))))))
(check-sat)
; query 10: function core_bench_list, block 82, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let (($x623 (or false false)))
(let (($x16 (not $x623)))
(and $x16 (or $x623 (and (distinct ((_ zero_extend 16) in.04_16) ((_ zero_extend 16) in.04_16)) true))))))
(check-sat)
; query 11: function core_bench_list, block 82, name %86
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x536 ((_ zero_extend 16) in.02_16)))
(let ((?x3821 (bvmul ?x536 (_ bv4 32))))
(let ((?x167 (bvadd ?x3821 (bvsub (_ bv0 32) ((_ zero_extend 16) in.04_16)))))
(let ((?x25 ((_ zero_extend 16) in.04_16)))
(let ((?x216 (bvsub ?x3821 ?x25)))
(let (($x28 (and (distinct (bvmul ((_ sign_extend 32) ?x536) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x3821)) true)))
(let (($x623 (or false false)))
(let (($x338 (or $x623 false (or $x28))))
(let (($x77 (or $x338 (or false $x623 false) false)))
(let ((?x84 ((_ sign_extend 1) ?x216)))
(let (($x235 (or $x338 $x623 (or (and (distinct (bvsub ((_ sign_extend 1) ?x3821) ((_ sign_extend 1) ?x25)) ?x84) true)))))
(and (not $x235) (or $x77 (and (distinct ?x216 ?x167) true)))))))))))))))
(check-sat)
; query 12: function core_bench_list, block 82, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x623 (or false false)))
(let (($x16 (not $x623)))
(and $x16 (or $x623 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 13: function core_bench_list, block 82, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x616 ((_ zero_extend 16) in.01_16)))
(let ((?x536 ((_ zero_extend 16) in.02_16)))
(let ((?x3821 (bvmul ?x536 (_ bv4 32))))
(let ((?x167 (bvadd ?x3821 (bvsub (_ bv0 32) ((_ zero_extend 16) in.04_16)))))
(let ((?x384 (bvadd ?x167 ?x616)))
(let ((?x25 ((_ zero_extend 16) in.04_16)))
(let ((?x216 (bvsub ?x3821 ?x25)))
(let ((?x199 (bvadd ?x616 ?x216)))
(let (($x107 (and (distinct (bvadd ((_ sign_extend 1) ?x167) ((_ sign_extend 1) ?x616)) ((_ sign_extend 1) ?x384)) true)))
(let (($x623 (or false false)))
(let (($x28 (and (distinct (bvmul ((_ sign_extend 32) ?x536) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x3821)) true)))
(let (($x338 (or $x623 false (or $x28))))
(let (($x77 (or $x338 (or false $x623 false) false)))
(let (($x151 (or $x77 $x623 (or $x107))))
(let (($x127 (and (distinct (bvadd ((_ sign_extend 1) ?x616) ((_ sign_extend 1) ?x216)) ((_ sign_extend 1) ?x199)) true)))
(let ((?x84 ((_ sign_extend 1) ?x216)))
(let (($x235 (or $x338 $x623 (or (and (distinct (bvsub ((_ sign_extend 1) ?x3821) ((_ sign_extend 1) ?x25)) ?x84) true)))))
(let (($x391 (or $x623 $x235 (or $x127))))
(and (not $x391) (or $x151 (and (distinct ?x199 ?x384) true))))))))))))))))))))))
(check-sat)
; query 14: function core_bench_list, block 82, name %89
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x616 ((_ zero_extend 16) in.01_16)))
(let ((?x536 ((_ zero_extend 16) in.02_16)))
(let ((?x3821 (bvmul ?x536 (_ bv4 32))))
(let ((?x167 (bvadd ?x3821 (bvsub (_ bv0 32) ((_ zero_extend 16) in.04_16)))))
(let ((?x384 (bvadd ?x167 ?x616)))
(let (($x176 (and (distinct ((_ extract 15 0) (bvadd ?x616 (bvsub ?x3821 ((_ zero_extend 16) in.04_16)))) ((_ extract 15 0) ?x384)) true)))
(let (($x107 (and (distinct (bvadd ((_ sign_extend 1) ?x167) ((_ sign_extend 1) ?x616)) ((_ sign_extend 1) ?x384)) true)))
(let (($x623 (or false false)))
(let (($x28 (and (distinct (bvmul ((_ sign_extend 32) ?x536) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x3821)) true)))
(let (($x338 (or $x623 false (or $x28))))
(let (($x77 (or $x338 (or false $x623 false) false)))
(let (($x151 (or $x77 $x623 (or $x107))))
(let ((?x25 ((_ zero_extend 16) in.04_16)))
(let ((?x216 (bvsub ?x3821 ?x25)))
(let ((?x84 ((_ sign_extend 1) ?x216)))
(let ((?x224 ((_ sign_extend 1) ?x616)))
(let (($x235 (or $x338 $x623 (or (and (distinct (bvsub ((_ sign_extend 1) ?x3821) ((_ sign_extend 1) ?x25)) ?x84) true)))))
(let (($x391 (or $x623 $x235 (or (and (distinct (bvadd ?x224 ?x84) ((_ sign_extend 1) (bvadd ?x616 ?x216))) true)))))
(and (not (or $x391 false)) (or (or $x151 false) $x176)))))))))))))))))))))
(check-sat)
; query 15: function core_bench_list, block 82, name %90
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x623 (or false false)))
(let (($x16 (not $x623)))
(and $x16 (or $x623 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 16: function core_bench_list, block 82, name %91
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x3431 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x623 (or false false)))
(let (($x43 (or $x623 false false)))
(let (($x641 (not $x43)))
(and $x641 (or $x43 (and (distinct ?x3431 ?x3431) true))))))))
(check-sat)
; query 17: function core_bench_state, block 105, name %106
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x654 (or false false false)))
(let (($x169 (not $x654)))
(and $x169 (or $x654 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 18: function core_bench_state, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x654 (or false false false)))
(let (($x169 (not $x654)))
(and $x169 (or $x654 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 19: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x652 (bvadd in.01_32 (_ bv1 32))))
(let (($x10508 (and (distinct ?x652 ?x652) true)))
(let (($x654 (or false false false)))
(let (($x169 (not $x654)))
(and $x169 (or $x654 $x10508)))))))
(check-sat)
; query 20: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x652 (bvadd in.01_32 (_ bv1 32))))
(let ((?x434 (bvmul ?x652 (_ bv8 32))))
(let ((?x334 (bvmul ?x652 ?x652)))
(let (($x654 (or false false false)))
(let (($x40 (or $x654 false false)))
(and (not (or $x654 $x654 false)) (or $x40 (and (distinct ?x334 ?x434) true)))))))))
(check-sat)
; query 21: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x1393 (and (distinct (bvmul (bvmul (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) (_ bv2 32)) (bvmul (bvmul (bvadd in.01_32 (_ bv1 32)) (_ bv8 32)) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x654 (or false false false)))
(let (($x40 (or $x654 false false)))
(and (not (or (or $x654 $x654 false) false false)) (or (or $x40 $x654 false) $x1393))))))
(check-sat)
; query 22: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x1226 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x654 (or false false false)))
(let (($x169 (not $x654)))
(and $x169 (or $x654 (and (distinct ?x1226 ?x1226) true)))))))
(check-sat)
; query 23: function core_init_state, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_32 () (_ BitVec 32))
(assert
 (let (($x654 (or false false false)))
(let (($x169 (not $x654)))
(and $x169 (or $x654 (and (distinct (bvadd in.06_32 (_ bv1 32)) (bvadd in.06_32 (_ bv1 32))) true))))))
(check-sat)
; query 24: function core_init_state, block 65, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let (($x654 (or false false false)))
(let (($x169 (not $x654)))
(and $x169 (or $x654 (and (distinct (bvadd in4_32 (_ bv1 32)) (bvadd in4_32 (_ bv1 32))) true))))))
(check-sat)
; query 25: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x82 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x654 (or false false false)))
(let (($x169 (not $x654)))
(and $x169 (or $x654 (and (distinct ?x82 ?x82) true)))))))
(check-sat)
; query 26: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x654 (or false false false)))
(let (($x169 (not $x654)))
(and $x169 (or $x654 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 27: function core_list_init, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x652 (bvadd in.01_32 (_ bv1 32))))
(let (($x10508 (and (distinct ?x652 ?x652) true)))
(let (($x654 (or false false false)))
(let (($x169 (not $x654)))
(and $x169 (or $x654 $x10508)))))))
(check-sat)
; query 28: function core_list_mergesort, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x652 (bvadd in.01_32 (_ bv1 32))))
(let (($x10508 (and (distinct ?x652 ?x652) true)))
(let (($x6143 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x652)) true)))
(let (($x701 (or false false (or $x6143))))
(and (not $x701) (or $x701 $x10508)))))))
(check-sat)
; query 29: function core_list_mergesort, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x5696 (ite (bvslt (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x654 (or false false false)))
(let (($x169 (not $x654)))
(and $x169 (or $x654 (and (distinct ?x5696 ?x5696) true)))))))
(check-sat)
; query 30: function core_list_mergesort, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.224_32 () (_ BitVec 32))
(assert
 (let ((?x7871 (ite (= (_ bv0 32) in.224_32) (_ bv1 1) (_ bv0 1))))
(let (($x654 (or false false false)))
(let (($x169 (not $x654)))
(and $x169 (or $x654 (and (distinct ?x7871 ?x7871) true)))))))
(check-sat)
; query 31: function core_list_mergesort, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x10288 (ite (= (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x654 (or false false false)))
(let (($x169 (not $x654)))
(and $x169 (or $x654 (and (distinct ?x10288 ?x10288) true)))))))
(check-sat)
; query 32: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x8686 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x1939 (or false false (or $x8686))))
(and (not $x1939) (or $x1939 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 33: function core_list_mergesort, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x8424 (and (distinct (bvmul ((_ sign_extend 32) in.020_32) ((_ sign_extend 32) (_ bv2 32))) ((_ sign_extend 32) (bvmul in.020_32 (_ bv2 32)))) true)))
(let (($x3439 (or false false (or $x8424))))
(and (not $x3439) (or $x3439 (and (distinct (bvmul in.020_32 (_ bv2 32)) (bvmul in.020_32 (_ bv2 32))) true))))))
(check-sat)
; query 34: function core_state_transition, block 102, name %103
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x623 (or false false)))
(let (($x16 (not $x623)))
(and $x16 (or $x623 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 35: function core_state_transition, block 102, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x4019 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x623 (or false false)))
(let (($x43 (or $x623 false false)))
(let (($x641 (not $x43)))
(and $x641 (or $x43 (and (distinct ?x4019 ?x4019) true))))))))
(check-sat)
; query 36: function core_state_transition, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x623 (or false false)))
(let (($x16 (not $x623)))
(and $x16 (or $x623 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 37: function core_state_transition, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x10645 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x623 (or false false)))
(let (($x43 (or $x623 false false)))
(let (($x641 (not $x43)))
(and $x641 (or $x43 (and (distinct ?x10645 ?x10645) true))))))))
(check-sat)
; query 38: function core_state_transition, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x623 (or false false)))
(let (($x16 (not $x623)))
(and $x16 (or $x623 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 39: function core_state_transition, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x4019 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x623 (or false false)))
(let (($x43 (or $x623 false false)))
(let (($x641 (not $x43)))
(and $x641 (or $x43 (and (distinct ?x4019 ?x4019) true))))))))
(check-sat)
; query 40: function core_state_transition, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x623 (or false false)))
(let (($x16 (not $x623)))
(and $x16 (or $x623 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 41: function core_state_transition, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x7481 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x623 (or false false)))
(let (($x43 (or $x623 false false)))
(let (($x641 (not $x43)))
(and $x641 (or $x43 (and (distinct ?x7481 ?x7481) true))))))))
(check-sat)
; query 42: function core_state_transition, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x623 (or false false)))
(let (($x16 (not $x623)))
(and $x16 (or $x623 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 43: function core_state_transition, block 51, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x7481 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x623 (or false false)))
(let (($x43 (or $x623 false false)))
(let (($x641 (not $x43)))
(and $x641 (or $x43 (and (distinct ?x7481 ?x7481) true))))))))
(check-sat)
; query 44: function core_state_transition, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x623 (or false false)))
(let (($x16 (not $x623)))
(and $x16 (or $x623 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 45: function core_state_transition, block 64, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x7481 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x623 (or false false)))
(let (($x43 (or $x623 false false)))
(let (($x641 (not $x43)))
(and $x641 (or $x43 (and (distinct ?x7481 ?x7481) true))))))))
(check-sat)
; query 46: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x6216 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x654 (or false false false)))
(let (($x169 (not $x654)))
(and $x169 (or $x654 (and (distinct ?x6216 ?x6216) true)))))))
(check-sat)
; query 47: function core_state_transition, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x623 (or false false)))
(let (($x16 (not $x623)))
(and $x16 (or $x623 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 48: function core_state_transition, block 80, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x3958 (ite (= (_ bv69 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x623 (or false false)))
(let (($x43 (or $x623 false false)))
(let (($x641 (not $x43)))
(and $x641 (or $x43 (and (distinct ?x3958 ?x3958) true))))))))
(check-sat)
; query 49: function core_state_transition, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x623 (or false false)))
(let (($x16 (not $x623)))
(and $x16 (or $x623 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 50: function core_state_transition, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x9140 (ite (= (_ bv101 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x623 (or false false)))
(let (($x43 (or $x623 false false)))
(let (($x641 (not $x43)))
(and $x641 (or $x43 (and (distinct ?x9140 ?x9140) true))))))))
(check-sat)
; query 51: function core_state_transition, block 99, name %100
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x623 (or false false)))
(let (($x16 (not $x623)))
(and $x16 (or $x623 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 52: function core_state_transition, block 99, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x10645 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x623 (or false false)))
(let (($x43 (or $x623 false false)))
(let (($x641 (not $x43)))
(and $x641 (or $x43 (and (distinct ?x10645 ?x10645) true))))))))
(check-sat)
; query 53: function crcu8, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x623 (or false false)))
(let (($x16 (not $x623)))
(and $x16 (or $x623 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 54: function crcu8, block 19, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x616 ((_ zero_extend 16) in.01_16)))
(let ((?x8182 (bvxor ?x616 (_ bv16386 32))))
(let (($x623 (or false false)))
(let (($x43 (or $x623 false false)))
(let (($x641 (not $x43)))
(and $x641 (or $x43 (and (distinct ?x8182 ?x8182) true)))))))))
(check-sat)
; query 55: function crcu8, block 19, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x616 ((_ zero_extend 16) in.01_16)))
(let ((?x8182 (bvxor ?x616 (_ bv16386 32))))
(let ((?x6947 ((_ extract 15 0) ?x8182)))
(let (($x623 (or false false)))
(let (($x43 (or $x623 false false)))
(let (($x382 (or $x43 false)))
(let (($x1814 (not $x382)))
(and $x1814 (or $x382 (and (distinct ?x6947 ?x6947) true)))))))))))
(check-sat)
; query 56: function crcu8, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x623 (or false false)))
(let (($x16 (not $x623)))
(and $x16 (or $x623 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 57: function crcu8, block 29, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x11125 ((_ zero_extend 16) in27_16)))
(let ((?x7605 (bvor ?x11125 (_ bv32768 32))))
(let (($x623 (or false false)))
(let (($x43 (or $x623 false false)))
(let (($x641 (not $x43)))
(and $x641 (or $x43 (and (distinct ?x7605 ?x7605) true)))))))))
(check-sat)
; query 58: function crcu8, block 29, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x11125 ((_ zero_extend 16) in27_16)))
(let ((?x7605 (bvor ?x11125 (_ bv32768 32))))
(let ((?x9884 ((_ extract 15 0) ?x7605)))
(let (($x623 (or false false)))
(let (($x43 (or $x623 false false)))
(let (($x382 (or $x43 false)))
(let (($x1814 (not $x382)))
(and $x1814 (or $x382 (and (distinct ?x9884 ?x9884) true)))))))))))
(check-sat)
; query 59: function crcu8, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x623 (or false false)))
(let (($x16 (not $x623)))
(and $x16 (or $x623 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 60: function crcu8, block 33, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x11125 ((_ zero_extend 16) in27_16)))
(let ((?x9890 (bvand ?x11125 (_ bv32767 32))))
(let (($x623 (or false false)))
(let (($x43 (or $x623 false false)))
(let (($x641 (not $x43)))
(and $x641 (or $x43 (and (distinct ?x9890 ?x9890) true)))))))))
(check-sat)
; query 61: function crcu8, block 33, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x11125 ((_ zero_extend 16) in27_16)))
(let ((?x9890 (bvand ?x11125 (_ bv32767 32))))
(let ((?x2669 ((_ extract 15 0) ?x9890)))
(let (($x623 (or false false)))
(let (($x43 (or $x623 false false)))
(let (($x382 (or $x43 false)))
(let (($x1814 (not $x382)))
(and $x1814 (or $x382 (and (distinct ?x2669 ?x2669) true)))))))))))
(check-sat)
; query 62: function crcu8, block 38, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_8 () (_ BitVec 8))
(assert
 (let (($x654 (or false false false)))
(let (($x169 (not $x654)))
(and $x169 (or $x654 (and (distinct (bvadd in.02_8 (_ bv1 8)) (bvadd in.02_8 (_ bv1 8))) true))))))
(check-sat)
; query 63: function crcu8, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x10980 ((_ extract 7 0) in.01_16)))
(let ((?x480 ((_ zero_extend 24) ?x10980)))
(let (($x623 (or false false)))
(let (($x11004 (or $x623 false)))
(and (not $x11004) (or $x11004 (and (distinct ?x480 ?x480) true))))))))
(check-sat)
; query 64: function crcu8, block 6, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x10980 ((_ extract 7 0) in.01_16)))
(let ((?x480 ((_ zero_extend 24) ?x10980)))
(let ((?x4028 (bvand ?x480 (_ bv1 32))))
(let (($x623 (or false false)))
(let (($x11004 (or $x623 false)))
(let (($x6091 (or $x11004 false false)))
(and (not $x6091) (or $x6091 (and (distinct ?x4028 ?x4028) true))))))))))
(check-sat)
; query 65: function crcu8, block 6, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x10980 ((_ extract 7 0) in.01_16)))
(let ((?x480 ((_ zero_extend 24) ?x10980)))
(let ((?x4028 (bvand ?x480 (_ bv1 32))))
(let ((?x4764 ((_ zero_extend 24) in.0_8)))
(let ((?x7753 (bvand ?x4764 (_ bv1 32))))
(let ((?x5951 (bvxor ?x7753 ?x4028)))
(let (($x623 (or false false)))
(let (($x11004 (or $x623 false)))
(let (($x6091 (or $x11004 false false)))
(let (($x43 (or $x623 false false)))
(let (($x4279 (or $x43 $x6091 false)))
(and (not $x4279) (or $x4279 (and (distinct ?x5951 ?x5951) true)))))))))))))))
(check-sat)
; query 66: function crcu8, block 6, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x10980 ((_ extract 7 0) in.01_16)))
(let ((?x480 ((_ zero_extend 24) ?x10980)))
(let ((?x4028 (bvand ?x480 (_ bv1 32))))
(let ((?x4764 ((_ zero_extend 24) in.0_8)))
(let ((?x7753 (bvand ?x4764 (_ bv1 32))))
(let ((?x5951 (bvxor ?x7753 ?x4028)))
(let ((?x10500 ((_ extract 7 0) ?x5951)))
(let (($x623 (or false false)))
(let (($x11004 (or $x623 false)))
(let (($x6091 (or $x11004 false false)))
(let (($x43 (or $x623 false false)))
(let (($x4279 (or $x43 $x6091 false)))
(let (($x9753 (or $x4279 false)))
(and (not $x9753) (or $x9753 (and (distinct ?x10500 ?x10500) true)))))))))))))))))
(check-sat)
; query 67: function crcu8, block 6, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x623 (or false false)))
(let (($x16 (not $x623)))
(and $x16 (or $x623 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 68: function crcu8, block 6, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x4764 ((_ zero_extend 24) in.0_8)))
(let ((?x4261 (bvashr ?x4764 (_ bv1 32))))
(let (($x623 (or false false)))
(let (($x43 (or $x623 false false)))
(let (($x5060 (or $x43 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not $x5060) (or $x5060 (and (distinct ?x4261 ?x4261) true)))))))))
(check-sat)
; query 69: function crcu8, block 6, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x4764 ((_ zero_extend 24) in.0_8)))
(let ((?x4261 (bvashr ?x4764 (_ bv1 32))))
(let ((?x5746 ((_ extract 7 0) ?x4261)))
(let (($x623 (or false false)))
(let (($x43 (or $x623 false false)))
(let (($x5060 (or $x43 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x10839 (or $x5060 false)))
(and (not $x10839) (or $x10839 (and (distinct ?x5746 ?x5746) true)))))))))))
(check-sat)
; query 70: function crcu8, block 6, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x10980 ((_ extract 7 0) in.01_16)))
(let ((?x480 ((_ zero_extend 24) ?x10980)))
(let ((?x4028 (bvand ?x480 (_ bv1 32))))
(let ((?x4764 ((_ zero_extend 24) in.0_8)))
(let ((?x7753 (bvand ?x4764 (_ bv1 32))))
(let ((?x5951 (bvxor ?x7753 ?x4028)))
(let ((?x10500 ((_ extract 7 0) ?x5951)))
(let ((?x1008 ((_ zero_extend 24) ?x10500)))
(let (($x623 (or false false)))
(let (($x11004 (or $x623 false)))
(let (($x6091 (or $x11004 false false)))
(let (($x43 (or $x623 false false)))
(let (($x4279 (or $x43 $x6091 false)))
(let (($x9753 (or $x4279 false)))
(let (($x3780 (or $x9753 false)))
(and (not $x3780) (or $x3780 (and (distinct ?x1008 ?x1008) true)))))))))))))))))))
(check-sat)
; query 71: function crcu8, block 6, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x10980 ((_ extract 7 0) in.01_16)))
(let ((?x480 ((_ zero_extend 24) ?x10980)))
(let ((?x4028 (bvand ?x480 (_ bv1 32))))
(let ((?x4764 ((_ zero_extend 24) in.0_8)))
(let ((?x7753 (bvand ?x4764 (_ bv1 32))))
(let ((?x5951 (bvxor ?x7753 ?x4028)))
(let ((?x10500 ((_ extract 7 0) ?x5951)))
(let ((?x1008 ((_ zero_extend 24) ?x10500)))
(let ((?x5339 (ite (= (_ bv1 32) ?x1008) (_ bv1 1) (_ bv0 1))))
(let (($x623 (or false false)))
(let (($x11004 (or $x623 false)))
(let (($x6091 (or $x11004 false false)))
(let (($x43 (or $x623 false false)))
(let (($x4279 (or $x43 $x6091 false)))
(let (($x9753 (or $x4279 false)))
(let (($x3780 (or $x9753 false)))
(let (($x2245 (or $x3780 false false)))
(and (not $x2245) (or $x2245 (and (distinct ?x5339 ?x5339) true)))))))))))))))))))))
(check-sat)
; query 72: function crcu8, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x623 (or false false)))
(let (($x16 (not $x623)))
(and $x16 (or $x623 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 73: function crcu8, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x4764 ((_ zero_extend 24) in.0_8)))
(let ((?x7753 (bvand ?x4764 (_ bv1 32))))
(let (($x623 (or false false)))
(let (($x43 (or $x623 false false)))
(let (($x641 (not $x43)))
(and $x641 (or $x43 (and (distinct ?x7753 ?x7753) true)))))))))
(check-sat)
; query 74: function crcu8, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x623 (or false false)))
(let (($x16 (not $x623)))
(and $x16 (or $x623 (and (distinct ((_ extract 7 0) in.01_16) ((_ extract 7 0) in.01_16)) true))))))
(check-sat)
; query 75: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x6478 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x654 (or false false false)))
(let (($x169 (not $x654)))
(and $x169 (or $x654 (and (distinct ?x6478 ?x6478) true)))))))
(check-sat)
; query 76: function matrix_add_const, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x654 (or false false false)))
(let (($x169 (not $x654)))
(and $x169 (or $x654 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 77: function matrix_add_const, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x652 (bvadd in.01_32 (_ bv1 32))))
(let (($x10508 (and (distinct ?x652 ?x652) true)))
(let (($x654 (or false false false)))
(let (($x169 (not $x654)))
(and $x169 (or $x654 $x10508)))))))
(check-sat)
; query 78: function matrix_mul_const, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x654 (or false false false)))
(let (($x169 (not $x654)))
(and $x169 (or $x654 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 79: function matrix_mul_const, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x652 (bvadd in.01_32 (_ bv1 32))))
(let (($x10508 (and (distinct ?x652 ?x652) true)))
(let (($x654 (or false false false)))
(let (($x169 (not $x654)))
(and $x169 (or $x654 $x10508)))))))
(check-sat)
; query 80: function matrix_mul_matrix, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x654 (or false false false)))
(let (($x169 (not $x654)))
(and $x169 (or $x654 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 81: function matrix_mul_matrix, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x652 (bvadd in.01_32 (_ bv1 32))))
(let (($x10508 (and (distinct ?x652 ?x652) true)))
(let (($x654 (or false false false)))
(let (($x169 (not $x654)))
(and $x169 (or $x654 $x10508)))))))
(check-sat)
; query 82: function matrix_mul_matrix, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x654 (or false false false)))
(let (($x169 (not $x654)))
(and $x169 (or $x654 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 83: function matrix_mul_matrix_bitextract, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x654 (or false false false)))
(let (($x169 (not $x654)))
(and $x169 (or $x654 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 84: function matrix_mul_matrix_bitextract, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x652 (bvadd in.01_32 (_ bv1 32))))
(let (($x10508 (and (distinct ?x652 ?x652) true)))
(let (($x654 (or false false false)))
(let (($x169 (not $x654)))
(and $x169 (or $x654 $x10508)))))))
(check-sat)
; query 85: function matrix_mul_matrix_bitextract, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x654 (or false false false)))
(let (($x169 (not $x654)))
(and $x169 (or $x654 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 86: function matrix_mul_vect, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x654 (or false false false)))
(let (($x169 (not $x654)))
(and $x169 (or $x654 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 87: function matrix_mul_vect, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x652 (bvadd in.01_32 (_ bv1 32))))
(let (($x10508 (and (distinct ?x652 ?x652) true)))
(let (($x654 (or false false false)))
(let (($x169 (not $x654)))
(and $x169 (or $x654 $x10508)))))))
(check-sat)
; query 88: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x623 (or false false)))
(let (($x16 (not $x623)))
(and $x16 (or $x623 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 89: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x7747 ((_ sign_extend 16) in.1_16)))
(let ((?x4917 (bvadd ?x7747 (_ bv10 32))))
(let (($x4761 (and (distinct (bvadd ((_ sign_extend 1) ?x7747) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x4917)) true)))
(let (($x623 (or false false)))
(let (($x10381 (or $x623 false (or $x4761))))
(and (not $x10381) (or $x10381 (and (distinct ?x4917 ?x4917) true)))))))))
(check-sat)
; query 90: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x7747 ((_ sign_extend 16) in.1_16)))
(let ((?x4917 (bvadd ?x7747 (_ bv10 32))))
(let ((?x3749 ((_ extract 15 0) ?x4917)))
(let (($x4761 (and (distinct (bvadd ((_ sign_extend 1) ?x7747) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x4917)) true)))
(let (($x623 (or false false)))
(let (($x10381 (or $x623 false (or $x4761))))
(let (($x8051 (or $x10381 false)))
(and (not $x8051) (or $x8051 (and (distinct ?x3749 ?x3749) true)))))))))))
(check-sat)
; query 91: function partition_memory, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x654 (or false false false)))
(let (($x169 (not $x654)))
(and $x169 (or $x654 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
