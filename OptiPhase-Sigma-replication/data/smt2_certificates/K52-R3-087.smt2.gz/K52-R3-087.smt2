; OptiPhase-Sigma refinement certificate for sweep K52-R3-087
; query 0: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x1333 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x347 (or false false false)))
(let (($x1334 (not $x347)))
(and $x1334 (or $x347 (and (distinct ?x1333 ?x1333) true)))))))
(check-sat)
; query 1: function set1d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x1536 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x347 (or false false false)))
(let (($x1334 (not $x347)))
(and $x1334 (or $x347 (and (distinct ?x1536 ?x1536) true)))))))
(check-sat)
; query 2: function set1ds, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x1564 (ite (= (_ bv4294967295 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x347 (or false false false)))
(let (($x1334 (not $x347)))
(and $x1334 (or $x347 (and (distinct ?x1564 ?x1564) true)))))))
(check-sat)
; query 3: function set2d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x1536 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x347 (or false false false)))
(let (($x1334 (not $x347)))
(and $x1334 (or $x347 (and (distinct ?x1536 ?x1536) true)))))))
(check-sat)
