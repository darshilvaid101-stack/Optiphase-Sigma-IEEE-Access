; OptiPhase-Sigma refinement certificate for sweep K30-R1-005
; query 0: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x49 (ite (bvsgt (_ bv2 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x92 (or false false false)))
(and (not $x92) (or $x92 (and (distinct ?x49 ?x49) true))))))
(check-sat)
