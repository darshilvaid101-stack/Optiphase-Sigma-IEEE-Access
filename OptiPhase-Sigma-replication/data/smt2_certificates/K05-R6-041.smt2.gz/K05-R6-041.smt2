; OptiPhase-Sigma refinement certificate for sweep K05-R6-041
