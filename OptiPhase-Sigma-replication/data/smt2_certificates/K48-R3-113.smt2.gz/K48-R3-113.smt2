; OptiPhase-Sigma refinement certificate for sweep K48-R3-113
; query 0: function APCM_inverse_quantization, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x523 (or false false)))
(let (($x440 (not $x523)))
(and $x440 (or $x523 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 1: function APCM_inverse_quantization, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x864 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x523 (or false false)))
(let (($x443 (or $x523 false false)))
(let (($x1588 (not $x443)))
(and $x1588 (or $x443 (and (distinct ?x864 ?x864) true))))))))
(check-sat)
; query 2: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x523 (or false false)))
(let (($x440 (not $x523)))
(and $x440 (or $x523 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 3: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x171 (ite (bvslt (_ bv15 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x523 (or false false)))
(let (($x443 (or $x523 false false)))
(let (($x1588 (not $x443)))
(and $x1588 (or $x443 (and (distinct ?x171 ?x171) true))))))))
(check-sat)
; query 4: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x523 (or false false)))
(let (($x440 (not $x523)))
(and $x440 (or $x523 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 5: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x868 (ite (bvsgt (_ bv40 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x523 (or false false)))
(let (($x443 (or $x523 false false)))
(let (($x1588 (not $x443)))
(and $x1588 (or $x443 (and (distinct ?x868 ?x868) true))))))))
(check-sat)
; query 6: function RPE_grid_positioning, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x523 (or false false)))
(let (($x440 (not $x523)))
(and $x440 (or $x523 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 7: function RPE_grid_positioning, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x77 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x174 (and (distinct ?x77 ?x77) true)))
(let (($x523 (or false false)))
(let (($x703 (or false $x523 false)))
(and (not $x703) (or $x703 $x174)))))))
(check-sat)
; query 8: function gsm_L_add, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x80 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false false)))
(let (($x249 (not $x187)))
(and $x249 (or $x187 (and (distinct ?x80 ?x80) true)))))))
(check-sat)
; query 9: function gsm_L_add, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x20 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvadd in0_64 in1_64))) true)))
(let (($x713 (or false false (or $x20))))
(let (($x173 (or $x713 (and (distinct (bvadd in0_64 in1_64) (bvadd in0_64 in1_64)) true))))
(and (not $x713) $x173)))))
(check-sat)
; query 10: function gsm_L_add, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x478 (bvadd in0_64 (_ bv1 64))))
(let ((?x114 (bvsub (_ bv0 64) ?x478)))
(let (($x83 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x478)) ((_ sign_extend 1) ?x114)) true)))
(let ((?x73 ((_ sign_extend 1) ?x478)))
(let (($x132 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x73) true)))))
(let (($x38 (or false $x132 (or $x83))))
(and (not $x38) (or $x38 (and (distinct ?x114 ?x114) true))))))))))
(check-sat)
; query 11: function gsm_L_add, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x123 (bvadd in1_64 (_ bv1 64))))
(let ((?x43 ((_ sign_extend 1) ?x123)))
(let (($x15 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x43) true)))))
(and (not $x15) (or $x15 (and (distinct ?x123 ?x123) true)))))))
(check-sat)
; query 12: function gsm_L_add, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x123 (bvadd in1_64 (_ bv1 64))))
(let ((?x464 (bvsub (_ bv0 64) ?x123)))
(let (($x587 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x123)) ((_ sign_extend 1) ?x464)) true)))
(let ((?x43 ((_ sign_extend 1) ?x123)))
(let (($x15 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x43) true)))))
(let (($x66 (or false $x15 (or $x587))))
(and (not $x66) (or $x66 (and (distinct ?x464 ?x464) true))))))))))
(check-sat)
; query 13: function gsm_L_add, block 8, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x123 (bvadd in1_64 (_ bv1 64))))
(let ((?x464 (bvsub (_ bv0 64) ?x123)))
(let ((?x478 (bvadd in0_64 (_ bv1 64))))
(let ((?x114 (bvsub (_ bv0 64) ?x478)))
(let ((?x79 (bvadd ?x114 ?x464)))
(let (($x587 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x123)) ((_ sign_extend 1) ?x464)) true)))
(let ((?x43 ((_ sign_extend 1) ?x123)))
(let (($x15 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x43) true)))))
(let (($x66 (or false $x15 (or $x587))))
(let (($x83 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x478)) ((_ sign_extend 1) ?x114)) true)))
(let ((?x73 ((_ sign_extend 1) ?x478)))
(let (($x132 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x73) true)))))
(let (($x38 (or false $x132 (or $x83))))
(let (($x96 (or $x38 $x66 false)))
(and (not $x96) (or $x96 (and (distinct ?x79 ?x79) true))))))))))))))))))
(check-sat)
; query 14: function gsm_L_add, block 8, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x123 (bvadd in1_64 (_ bv1 64))))
(let ((?x464 (bvsub (_ bv0 64) ?x123)))
(let ((?x478 (bvadd in0_64 (_ bv1 64))))
(let ((?x114 (bvsub (_ bv0 64) ?x478)))
(let ((?x79 (bvadd ?x114 ?x464)))
(let ((?x59 (ite (bvuge ?x79 (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x587 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x123)) ((_ sign_extend 1) ?x464)) true)))
(let ((?x43 ((_ sign_extend 1) ?x123)))
(let (($x15 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x43) true)))))
(let (($x66 (or false $x15 (or $x587))))
(let (($x83 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x478)) ((_ sign_extend 1) ?x114)) true)))
(let ((?x73 ((_ sign_extend 1) ?x478)))
(let (($x132 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x73) true)))))
(let (($x38 (or false $x132 (or $x83))))
(let (($x96 (or $x38 $x66 false)))
(let (($x100 (or $x96 false false)))
(and (not $x100) (or $x100 (and (distinct ?x59 ?x59) true))))))))))))))))))))
(check-sat)
; query 15: function gsm_L_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x478 (bvadd in0_64 (_ bv1 64))))
(let ((?x73 ((_ sign_extend 1) ?x478)))
(let (($x132 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x73) true)))))
(and (not $x132) (or $x132 (and (distinct ?x478 ?x478) true)))))))
(check-sat)
; query 16: function gsm_L_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x167 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false false)))
(let (($x249 (not $x187)))
(and $x249 (or $x187 (and (distinct ?x167 ?x167) true)))))))
(check-sat)
; query 17: function gsm_L_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x468 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false false)))
(let (($x249 (not $x187)))
(and $x249 (or $x187 (and (distinct ?x468 ?x468) true)))))))
(check-sat)
; query 18: function gsm_L_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x167 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false false)))
(let (($x249 (not $x187)))
(and $x249 (or $x187 (and (distinct ?x167 ?x167) true)))))))
(check-sat)
; query 19: function gsm_L_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x167 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x57 ((_ zero_extend 31) ?x167)))
(let (($x187 (or false false false)))
(let (($x210 (or $x187 false)))
(and (not $x210) (or $x210 (and (distinct ?x57 ?x57) true))))))))
(check-sat)
; query 20: function gsm_L_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x167 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x57 ((_ zero_extend 31) ?x167)))
(let ((?x122 (bvsub (_ bv0 32) ?x57)))
(let (($x22 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x57)) ((_ sign_extend 1) ?x122)) true)))
(let (($x187 (or false false false)))
(let (($x210 (or $x187 false)))
(let (($x31 (or false $x210 (or $x22))))
(and (not $x31) (or $x31 (and (distinct ?x122 ?x122) true)))))))))))
(check-sat)
; query 21: function gsm_L_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x167 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x57 ((_ zero_extend 31) ?x167)))
(let ((?x122 (bvsub (_ bv0 32) ?x57)))
(let ((?x50 ((_ sign_extend 32) ?x122)))
(let (($x22 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x57)) ((_ sign_extend 1) ?x122)) true)))
(let (($x187 (or false false false)))
(let (($x210 (or $x187 false)))
(let (($x31 (or false $x210 (or $x22))))
(let (($x47 (or $x31 false)))
(and (not $x47) (or $x47 (and (distinct ?x50 ?x50) true)))))))))))))
(check-sat)
; query 22: function gsm_L_asr, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1112 (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false false)))
(let (($x249 (not $x187)))
(and $x249 (or $x187 (and (distinct ?x1112 ?x1112) true)))))))
(check-sat)
; query 23: function gsm_L_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x468 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false false)))
(let (($x249 (not $x187)))
(and $x249 (or $x187 (and (distinct ?x468 ?x468) true)))))))
(check-sat)
; query 24: function gsm_L_sub, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x80 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false false)))
(let (($x249 (not $x187)))
(and $x249 (or $x187 (and (distinct ?x80 ?x80) true)))))))
(check-sat)
; query 25: function gsm_L_sub, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x84 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvsub in0_64 in1_64))) true)))
(let (($x423 (or false false (or $x84))))
(let (($x536 (or $x423 (and (distinct (bvsub in0_64 in1_64) (bvsub in0_64 in1_64)) true))))
(and (not $x423) $x536)))))
(check-sat)
; query 26: function gsm_L_sub, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x123 (bvadd in1_64 (_ bv1 64))))
(let ((?x464 (bvsub (_ bv0 64) ?x123)))
(let (($x587 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x123)) ((_ sign_extend 1) ?x464)) true)))
(let ((?x43 ((_ sign_extend 1) ?x123)))
(let (($x15 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x43) true)))))
(let (($x66 (or false $x15 (or $x587))))
(and (not $x66) (or $x66 (and (distinct ?x464 ?x464) true))))))))))
(check-sat)
; query 27: function gsm_L_sub, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x123 (bvadd in1_64 (_ bv1 64))))
(let ((?x464 (bvsub (_ bv0 64) ?x123)))
(let ((?x1539 (bvadd in0_64 ?x464)))
(let (($x587 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x123)) ((_ sign_extend 1) ?x464)) true)))
(let ((?x43 ((_ sign_extend 1) ?x123)))
(let (($x15 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x43) true)))))
(let (($x66 (or false $x15 (or $x587))))
(let (($x1108 (or false $x66 false)))
(and (not $x1108) (or $x1108 (and (distinct ?x1539 ?x1539) true))))))))))))
(check-sat)
; query 28: function gsm_L_sub, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x158 (ite (bvuge (bvadd in0_64 (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64)))) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x587 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) (bvadd in1_64 (_ bv1 64)))) ((_ sign_extend 1) (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64))))) true)))
(let ((?x123 (bvadd in1_64 (_ bv1 64))))
(let ((?x43 ((_ sign_extend 1) ?x123)))
(let (($x15 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x43) true)))))
(let (($x66 (or false $x15 (or $x587))))
(let (($x1108 (or false $x66 false)))
(let (($x308 (or $x1108 false false)))
(and (not $x308) (or $x308 (and (distinct ?x158 ?x158) true))))))))))))
(check-sat)
; query 29: function gsm_L_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x123 (bvadd in1_64 (_ bv1 64))))
(let ((?x43 ((_ sign_extend 1) ?x123)))
(let (($x15 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x43) true)))))
(and (not $x15) (or $x15 (and (distinct ?x123 ?x123) true)))))))
(check-sat)
; query 30: function gsm_L_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x147 (ite (bvsle (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false false)))
(let (($x249 (not $x187)))
(and $x249 (or $x187 (and (distinct ?x147 ?x147) true)))))))
(check-sat)
; query 31: function gsm_abs, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x523 (or false false)))
(let (($x440 (not $x523)))
(and $x440 (or $x523 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 32: function gsm_abs, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x708 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x523 (or false false)))
(let (($x443 (or $x523 false false)))
(let (($x1588 (not $x443)))
(and $x1588 (or $x443 (and (distinct ?x708 ?x708) true))))))))
(check-sat)
; query 33: function gsm_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x523 (or false false)))
(let (($x440 (not $x523)))
(and $x440 (or $x523 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 34: function gsm_add, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x523 (or false false)))
(let (($x440 (not $x523)))
(and $x440 (or $x523 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 35: function gsm_add, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x790 ((_ sign_extend 48) in1_16)))
(let ((?x670 ((_ sign_extend 48) in0_16)))
(let ((?x479 (bvadd ?x670 ?x790)))
(let (($x489 (and (distinct (bvadd ((_ sign_extend 1) ?x670) ((_ sign_extend 1) ?x790)) ((_ sign_extend 1) ?x479)) true)))
(let (($x523 (or false false)))
(let (($x1481 (or $x523 $x523 (or $x489))))
(and (not $x1481) (or $x1481 (and (distinct ?x479 ?x479) true))))))))))
(check-sat)
; query 36: function gsm_add, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x300 (ite (bvsgt (_ bv18446744073709518848 64) (bvadd ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x790 ((_ sign_extend 48) in1_16)))
(let ((?x1060 ((_ sign_extend 1) ?x790)))
(let ((?x670 ((_ sign_extend 48) in0_16)))
(let ((?x590 ((_ sign_extend 1) ?x670)))
(let (($x523 (or false false)))
(let (($x1481 (or $x523 $x523 (or (and (distinct (bvadd ?x590 ?x1060) ((_ sign_extend 1) (bvadd ?x670 ?x790))) true)))))
(let (($x1099 (or $x1481 false false)))
(and (not $x1099) (or $x1099 (and (distinct ?x300 ?x300) true))))))))))))
(check-sat)
; query 37: function gsm_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x309 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false false)))
(let (($x249 (not $x187)))
(and $x249 (or $x187 (and (distinct ?x309 ?x309) true)))))))
(check-sat)
; query 38: function gsm_asr, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x354 (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false false)))
(let (($x249 (not $x187)))
(and $x249 (or $x187 (and (distinct ?x354 ?x354) true)))))))
(check-sat)
; query 39: function gsm_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x523 (or false false)))
(let (($x440 (not $x523)))
(and $x440 (or $x523 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 40: function gsm_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x708 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x523 (or false false)))
(let (($x443 (or $x523 false false)))
(let (($x1588 (not $x443)))
(and $x1588 (or $x443 (and (distinct ?x708 ?x708) true))))))))
(check-sat)
; query 41: function gsm_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x708 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1092 ((_ zero_extend 31) ?x708)))
(let (($x523 (or false false)))
(let (($x443 (or $x523 false false)))
(let (($x843 (or $x443 false)))
(and (not $x843) (or $x843 (and (distinct ?x1092 ?x1092) true)))))))))
(check-sat)
; query 42: function gsm_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x708 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1092 ((_ zero_extend 31) ?x708)))
(let ((?x204 (bvsub (_ bv0 32) ?x1092)))
(let (($x838 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1092)) ((_ sign_extend 1) ?x204)) true)))
(let (($x523 (or false false)))
(let (($x443 (or $x523 false false)))
(let (($x843 (or $x443 false)))
(let (($x953 (or false $x843 (or $x838))))
(and (not $x953) (or $x953 (and (distinct ?x204 ?x204) true))))))))))))
(check-sat)
; query 43: function gsm_asr, block 4, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x708 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1092 ((_ zero_extend 31) ?x708)))
(let ((?x204 (bvsub (_ bv0 32) ?x1092)))
(let ((?x1543 ((_ extract 15 0) ?x204)))
(let (($x838 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1092)) ((_ sign_extend 1) ?x204)) true)))
(let (($x523 (or false false)))
(let (($x443 (or $x523 false false)))
(let (($x843 (or $x443 false)))
(let (($x953 (or false $x843 (or $x838))))
(let (($x532 (or $x953 false)))
(and (not $x532) (or $x532 (and (distinct ?x1543 ?x1543) true))))))))))))))
(check-sat)
; query 44: function gsm_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x309 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false false)))
(let (($x249 (not $x187)))
(and $x249 (or $x187 (and (distinct ?x309 ?x309) true)))))))
(check-sat)
; query 45: function gsm_debug_longwords, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in15_32 () (_ BitVec 32))
(assert
 (let ((?x1592 (ite (bvslt in15_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false false)))
(let (($x249 (not $x187)))
(and $x249 (or $x187 (and (distinct ?x1592 ?x1592) true)))))))
(check-sat)
; query 46: function gsm_debug_words, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in16_32 () (_ BitVec 32))
(assert
 (let ((?x1570 (ite (bvslt in16_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false false)))
(let (($x249 (not $x187)))
(and $x249 (or $x187 (and (distinct ?x1570 ?x1570) true)))))))
(check-sat)
; query 47: function gsm_div, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x523 (or false false)))
(let (($x440 (not $x523)))
(and $x440 (or $x523 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 48: function gsm_div, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x523 (or false false)))
(let (($x440 (not $x523)))
(and $x440 (or $x523 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 49: function gsm_div, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x523 (or false false)))
(let (($x440 (not $x523)))
(and $x440 (or $x523 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 50: function gsm_div, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x77 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x174 (and (distinct ?x77 ?x77) true)))
(let (($x523 (or false false)))
(let (($x443 (or $x523 false false)))
(let (($x1588 (not $x443)))
(and $x1588 (or $x443 $x174))))))))
(check-sat)
; query 51: function gsm_norm, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1572 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x187 (or false false false)))
(let (($x249 (not $x187)))
(and $x249 (or $x187 (and (distinct ?x1572 ?x1572) true)))))))
(check-sat)
; query 52: function gsm_norm, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1572 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x486 (bvxor ?x1572 (_ bv1 1))))
(let (($x187 (or false false false)))
(let (($x992 (or $x187 false false)))
(and (not $x992) (or $x992 (and (distinct ?x486 ?x486) true))))))))
(check-sat)
; query 53: function gsm_norm, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1572 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x486 (bvxor ?x1572 (_ bv1 1))))
(let ((?x753 ((_ zero_extend 31) ?x486)))
(let (($x187 (or false false false)))
(let (($x992 (or $x187 false false)))
(let (($x616 (or $x992 false)))
(and (not $x616) (or $x616 (and (distinct ?x753 ?x753) true))))))))))
(check-sat)
; query 54: function gsm_norm, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1572 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x486 (bvxor ?x1572 (_ bv1 1))))
(let ((?x753 ((_ zero_extend 31) ?x486)))
(let ((?x410 ((_ sign_extend 32) ?x753)))
(let (($x187 (or false false false)))
(let (($x992 (or $x187 false false)))
(let (($x616 (or $x992 false)))
(let (($x232 (or $x616 false)))
(and (not $x232) (or $x232 (and (distinct ?x410 ?x410) true))))))))))))
(check-sat)
; query 55: function gsm_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x523 (or false false)))
(let (($x440 (not $x523)))
(and $x440 (or $x523 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 56: function gsm_sub, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x523 (or false false)))
(let (($x440 (not $x523)))
(and $x440 (or $x523 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 57: function gsm_sub, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x790 ((_ sign_extend 48) in1_16)))
(let ((?x670 ((_ sign_extend 48) in0_16)))
(let ((?x347 (bvsub ?x670 ?x790)))
(let (($x764 (and (distinct (bvsub ((_ sign_extend 1) ?x670) ((_ sign_extend 1) ?x790)) ((_ sign_extend 1) ?x347)) true)))
(let (($x523 (or false false)))
(let (($x1564 (or $x523 $x523 (or $x764))))
(and (not $x1564) (or $x1564 (and (distinct ?x347 ?x347) true))))))))))
(check-sat)
; query 58: function gsm_sub, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x867 (ite (bvsgt (_ bv18446744073709518848 64) (bvsub ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x790 ((_ sign_extend 48) in1_16)))
(let ((?x1060 ((_ sign_extend 1) ?x790)))
(let ((?x670 ((_ sign_extend 48) in0_16)))
(let ((?x590 ((_ sign_extend 1) ?x670)))
(let (($x523 (or false false)))
(let (($x1564 (or $x523 $x523 (or (and (distinct (bvsub ?x590 ?x1060) ((_ sign_extend 1) (bvsub ?x670 ?x790))) true)))))
(let (($x920 (or $x1564 false false)))
(and (not $x920) (or $x920 (and (distinct ?x867 ?x867) true))))))))))))
(check-sat)
