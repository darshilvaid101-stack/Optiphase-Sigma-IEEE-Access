; OptiPhase-Sigma refinement certificate for sweep K59-R2-072
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x753 (or false false)))
(let (($x2782 (not $x753)))
(and $x2782 (or $x753 (and (distinct ((_ sign_extend 16) in25_16) ((_ sign_extend 16) in25_16)) true))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let ((?x490 (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))))
(let (($x753 (or false false)))
(let (($x616 (or $x753 false false)))
(let (($x98 (not $x616)))
(and $x98 (or $x616 (and (distinct ?x490 ?x490) true))))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x753 (or false false)))
(let (($x2782 (not $x753)))
(and $x2782 (or $x753 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x499 ((_ sign_extend 16) in3_16)))
(let ((?x28 (bvand ?x499 (_ bv127 32))))
(let (($x753 (or false false)))
(let (($x616 (or $x753 false false)))
(let (($x98 (not $x616)))
(and $x98 (or $x616 (and (distinct ?x28 ?x28) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x499 ((_ sign_extend 16) in3_16)))
(let ((?x28 (bvand ?x499 (_ bv127 32))))
(let ((?x20 ((_ extract 15 0) ?x28)))
(let (($x753 (or false false)))
(let (($x616 (or $x753 false false)))
(let (($x156 (or $x616 false)))
(let (($x126 (not $x156)))
(and $x126 (or $x156 (and (distinct ?x20 ?x20) true)))))))))))
(check-sat)
; query 5: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x753 (or false false)))
(let (($x2782 (not $x753)))
(and $x2782 (or $x753 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 6: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x924 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x753 (or false false)))
(let (($x616 (or $x753 false false)))
(let (($x98 (not $x616)))
(and $x98 (or $x616 (and (distinct ?x924 ?x924) true))))))))
(check-sat)
; query 7: function core_bench_list, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x514 (or false false false)))
(let (($x190 (not $x514)))
(and $x190 (or $x514 (and (distinct (bvadd in.0_16 (_ bv1 16)) (bvadd in.0_16 (_ bv1 16))) true))))))
(check-sat)
; query 8: function core_bench_list, block 82, name %83
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let (($x753 (or false false)))
(let (($x2782 (not $x753)))
(and $x2782 (or $x753 (and (distinct ((_ zero_extend 16) in.02_16) ((_ zero_extend 16) in.02_16)) true))))))
(check-sat)
; query 9: function core_bench_list, block 82, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x758 ((_ zero_extend 16) in.02_16)))
(let ((?x64 (bvmul ?x758 (_ bv4 32))))
(let (($x790 (and (distinct (bvmul ((_ sign_extend 32) ?x758) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x64)) true)))
(let (($x753 (or false false)))
(let (($x630 (or $x753 false (or $x790))))
(and (not $x630) (or $x630 (and (distinct ?x64 ?x64) true)))))))))
(check-sat)
; query 10: function core_bench_list, block 82, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let (($x753 (or false false)))
(let (($x2782 (not $x753)))
(and $x2782 (or $x753 (and (distinct ((_ zero_extend 16) in.04_16) ((_ zero_extend 16) in.04_16)) true))))))
(check-sat)
; query 11: function core_bench_list, block 82, name %86
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x35 ((_ zero_extend 16) in.04_16)))
(let ((?x758 ((_ zero_extend 16) in.02_16)))
(let ((?x64 (bvmul ?x758 (_ bv4 32))))
(let ((?x432 (bvsub ?x64 ?x35)))
(let ((?x960 ((_ sign_extend 1) ?x432)))
(let (($x753 (or false false)))
(let (($x790 (and (distinct (bvmul ((_ sign_extend 32) ?x758) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x64)) true)))
(let (($x630 (or $x753 false (or $x790))))
(let (($x6 (or $x630 $x753 (or (and (distinct (bvsub ((_ sign_extend 1) ?x64) ((_ sign_extend 1) ?x35)) ?x960) true)))))
(and (not $x6) (or $x6 (and (distinct ?x432 ?x432) true)))))))))))))
(check-sat)
; query 12: function core_bench_list, block 82, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x753 (or false false)))
(let (($x2782 (not $x753)))
(and $x2782 (or $x753 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 13: function core_bench_list, block 82, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x35 ((_ zero_extend 16) in.04_16)))
(let ((?x758 ((_ zero_extend 16) in.02_16)))
(let ((?x64 (bvmul ?x758 (_ bv4 32))))
(let ((?x432 (bvsub ?x64 ?x35)))
(let ((?x278 ((_ zero_extend 16) in.01_16)))
(let ((?x434 (bvadd ?x278 ?x432)))
(let (($x44 (and (distinct (bvadd ((_ sign_extend 1) ?x278) ((_ sign_extend 1) ?x432)) ((_ sign_extend 1) ?x434)) true)))
(let ((?x960 ((_ sign_extend 1) ?x432)))
(let (($x753 (or false false)))
(let (($x790 (and (distinct (bvmul ((_ sign_extend 32) ?x758) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x64)) true)))
(let (($x630 (or $x753 false (or $x790))))
(let (($x6 (or $x630 $x753 (or (and (distinct (bvsub ((_ sign_extend 1) ?x64) ((_ sign_extend 1) ?x35)) ?x960) true)))))
(let (($x45 (or $x753 $x6 (or $x44))))
(and (not $x45) (or $x45 (and (distinct ?x434 ?x434) true)))))))))))))))))
(check-sat)
; query 14: function core_bench_list, block 82, name %89
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x35 ((_ zero_extend 16) in.04_16)))
(let ((?x758 ((_ zero_extend 16) in.02_16)))
(let ((?x64 (bvmul ?x758 (_ bv4 32))))
(let ((?x432 (bvsub ?x64 ?x35)))
(let ((?x278 ((_ zero_extend 16) in.01_16)))
(let ((?x434 (bvadd ?x278 ?x432)))
(let ((?x148 ((_ extract 15 0) ?x434)))
(let (($x44 (and (distinct (bvadd ((_ sign_extend 1) ?x278) ((_ sign_extend 1) ?x432)) ((_ sign_extend 1) ?x434)) true)))
(let ((?x960 ((_ sign_extend 1) ?x432)))
(let (($x753 (or false false)))
(let (($x790 (and (distinct (bvmul ((_ sign_extend 32) ?x758) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x64)) true)))
(let (($x630 (or $x753 false (or $x790))))
(let (($x6 (or $x630 $x753 (or (and (distinct (bvsub ((_ sign_extend 1) ?x64) ((_ sign_extend 1) ?x35)) ?x960) true)))))
(let (($x45 (or $x753 $x6 (or $x44))))
(let (($x1730 (or $x45 false)))
(and (not $x1730) (or $x1730 (and (distinct ?x148 ?x148) true)))))))))))))))))))
(check-sat)
; query 15: function core_bench_list, block 82, name %90
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x753 (or false false)))
(let (($x2782 (not $x753)))
(and $x2782 (or $x753 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 16: function core_bench_list, block 82, name %91
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x340 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x753 (or false false)))
(let (($x616 (or $x753 false false)))
(let (($x98 (not $x616)))
(and $x98 (or $x616 (and (distinct ?x340 ?x340) true))))))))
(check-sat)
; query 17: function core_bench_state, block 105, name %106
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x514 (or false false false)))
(let (($x190 (not $x514)))
(and $x190 (or $x514 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 18: function core_bench_state, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x514 (or false false false)))
(let (($x190 (not $x514)))
(and $x190 (or $x514 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 19: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x622 (bvadd in.01_32 (_ bv1 32))))
(let (($x153 (and (distinct ?x622 ?x622) true)))
(let (($x514 (or false false false)))
(let (($x190 (not $x514)))
(and $x190 (or $x514 $x153)))))))
(check-sat)
; query 20: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x622 (bvadd in.01_32 (_ bv1 32))))
(let ((?x37 (bvmul ?x622 ?x622)))
(let (($x514 (or false false false)))
(let (($x88 (or $x514 $x514 false)))
(and (not $x88) (or $x88 (and (distinct ?x37 ?x37) true))))))))
(check-sat)
; query 21: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x622 (bvadd in.01_32 (_ bv1 32))))
(let ((?x37 (bvmul ?x622 ?x622)))
(let ((?x542 (bvmul ?x37 (_ bv2 32))))
(let (($x514 (or false false false)))
(let (($x88 (or $x514 $x514 false)))
(let (($x428 (or $x88 false false)))
(and (not $x428) (or $x428 (and (distinct ?x542 ?x542) true))))))))))
(check-sat)
; query 22: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x622 (bvadd in.01_32 (_ bv1 32))))
(let ((?x37 (bvmul ?x622 ?x622)))
(let ((?x542 (bvmul ?x37 (_ bv2 32))))
(let ((?x49 (bvmul ?x542 (_ bv4 32))))
(let (($x514 (or false false false)))
(let (($x88 (or $x514 $x514 false)))
(let (($x428 (or $x88 false false)))
(let (($x755 (or $x428 false false)))
(and (not $x755) (or $x755 (and (distinct ?x49 ?x49) true))))))))))))
(check-sat)
; query 23: function core_init_matrix, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x514 (or false false false)))
(let (($x190 (not $x514)))
(and $x190 (or $x514 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 24: function core_init_matrix, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x514 (or false false false)))
(let (($x190 (not $x514)))
(and $x190 (or $x514 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 25: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x881 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x514 (or false false false)))
(let (($x190 (not $x514)))
(and $x190 (or $x514 (and (distinct ?x881 ?x881) true)))))))
(check-sat)
; query 26: function core_init_state, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_32 () (_ BitVec 32))
(assert
 (let (($x514 (or false false false)))
(let (($x190 (not $x514)))
(and $x190 (or $x514 (and (distinct (bvadd in.06_32 (_ bv1 32)) (bvadd in.06_32 (_ bv1 32))) true))))))
(check-sat)
; query 27: function core_init_state, block 65, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let (($x514 (or false false false)))
(let (($x190 (not $x514)))
(and $x190 (or $x514 (and (distinct (bvadd in4_32 (_ bv1 32)) (bvadd in4_32 (_ bv1 32))) true))))))
(check-sat)
; query 28: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x281 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x514 (or false false false)))
(let (($x190 (not $x514)))
(and $x190 (or $x514 (and (distinct ?x281 ?x281) true)))))))
(check-sat)
; query 29: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x514 (or false false false)))
(let (($x190 (not $x514)))
(and $x190 (or $x514 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 30: function core_list_init, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x622 (bvadd in.01_32 (_ bv1 32))))
(let (($x153 (and (distinct ?x622 ?x622) true)))
(let (($x514 (or false false false)))
(let (($x190 (not $x514)))
(and $x190 (or $x514 $x153)))))))
(check-sat)
; query 31: function core_list_mergesort, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x622 (bvadd in.01_32 (_ bv1 32))))
(let (($x153 (and (distinct ?x622 ?x622) true)))
(let (($x1010 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x622)) true)))
(let (($x799 (or false false (or $x1010))))
(and (not $x799) (or $x799 $x153)))))))
(check-sat)
; query 32: function core_list_mergesort, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x66 (ite (bvslt (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x514 (or false false false)))
(let (($x190 (not $x514)))
(and $x190 (or $x514 (and (distinct ?x66 ?x66) true)))))))
(check-sat)
; query 33: function core_list_mergesort, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.224_32 () (_ BitVec 32))
(assert
 (let ((?x1084 (ite (= (_ bv0 32) in.224_32) (_ bv1 1) (_ bv0 1))))
(let (($x514 (or false false false)))
(let (($x190 (not $x514)))
(and $x190 (or $x514 (and (distinct ?x1084 ?x1084) true)))))))
(check-sat)
; query 34: function core_list_mergesort, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x1744 (ite (= (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x514 (or false false false)))
(let (($x190 (not $x514)))
(and $x190 (or $x514 (and (distinct ?x1744 ?x1744) true)))))))
(check-sat)
; query 35: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x1306 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x557 (or false false (or $x1306))))
(and (not $x557) (or $x557 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 36: function core_list_mergesort, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x168 (and (distinct (bvmul ((_ sign_extend 32) in.020_32) ((_ sign_extend 32) (_ bv2 32))) ((_ sign_extend 32) (bvmul in.020_32 (_ bv2 32)))) true)))
(let (($x1910 (or false false (or $x168))))
(and (not $x1910) (or $x1910 (and (distinct (bvmul in.020_32 (_ bv2 32)) (bvmul in.020_32 (_ bv2 32))) true))))))
(check-sat)
; query 37: function core_state_transition, block 102, name %103
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x753 (or false false)))
(let (($x2782 (not $x753)))
(and $x2782 (or $x753 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 38: function core_state_transition, block 102, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1922 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x753 (or false false)))
(let (($x616 (or $x753 false false)))
(let (($x98 (not $x616)))
(and $x98 (or $x616 (and (distinct ?x1922 ?x1922) true))))))))
(check-sat)
; query 39: function core_state_transition, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x753 (or false false)))
(let (($x2782 (not $x753)))
(and $x2782 (or $x753 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 40: function core_state_transition, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x791 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x753 (or false false)))
(let (($x616 (or $x753 false false)))
(let (($x98 (not $x616)))
(and $x98 (or $x616 (and (distinct ?x791 ?x791) true))))))))
(check-sat)
; query 41: function core_state_transition, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x753 (or false false)))
(let (($x2782 (not $x753)))
(and $x2782 (or $x753 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 42: function core_state_transition, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1922 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x753 (or false false)))
(let (($x616 (or $x753 false false)))
(let (($x98 (not $x616)))
(and $x98 (or $x616 (and (distinct ?x1922 ?x1922) true))))))))
(check-sat)
; query 43: function core_state_transition, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x753 (or false false)))
(let (($x2782 (not $x753)))
(and $x2782 (or $x753 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 44: function core_state_transition, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1857 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x753 (or false false)))
(let (($x616 (or $x753 false false)))
(let (($x98 (not $x616)))
(and $x98 (or $x616 (and (distinct ?x1857 ?x1857) true))))))))
(check-sat)
; query 45: function core_state_transition, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x753 (or false false)))
(let (($x2782 (not $x753)))
(and $x2782 (or $x753 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 46: function core_state_transition, block 51, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1857 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x753 (or false false)))
(let (($x616 (or $x753 false false)))
(let (($x98 (not $x616)))
(and $x98 (or $x616 (and (distinct ?x1857 ?x1857) true))))))))
(check-sat)
; query 47: function core_state_transition, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x753 (or false false)))
(let (($x2782 (not $x753)))
(and $x2782 (or $x753 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 48: function core_state_transition, block 64, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1857 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x753 (or false false)))
(let (($x616 (or $x753 false false)))
(let (($x98 (not $x616)))
(and $x98 (or $x616 (and (distinct ?x1857 ?x1857) true))))))))
(check-sat)
; query 49: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x483 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x514 (or false false false)))
(let (($x190 (not $x514)))
(and $x190 (or $x514 (and (distinct ?x483 ?x483) true)))))))
(check-sat)
; query 50: function core_state_transition, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x753 (or false false)))
(let (($x2782 (not $x753)))
(and $x2782 (or $x753 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 51: function core_state_transition, block 80, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1843 (ite (= (_ bv69 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x753 (or false false)))
(let (($x616 (or $x753 false false)))
(let (($x98 (not $x616)))
(and $x98 (or $x616 (and (distinct ?x1843 ?x1843) true))))))))
(check-sat)
; query 52: function core_state_transition, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x753 (or false false)))
(let (($x2782 (not $x753)))
(and $x2782 (or $x753 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 53: function core_state_transition, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1940 (ite (= (_ bv101 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x753 (or false false)))
(let (($x616 (or $x753 false false)))
(let (($x98 (not $x616)))
(and $x98 (or $x616 (and (distinct ?x1940 ?x1940) true))))))))
(check-sat)
; query 54: function core_state_transition, block 99, name %100
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x753 (or false false)))
(let (($x2782 (not $x753)))
(and $x2782 (or $x753 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 55: function core_state_transition, block 99, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x791 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x753 (or false false)))
(let (($x616 (or $x753 false false)))
(let (($x98 (not $x616)))
(and $x98 (or $x616 (and (distinct ?x791 ?x791) true))))))))
(check-sat)
; query 56: function crcu8, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x753 (or false false)))
(let (($x2782 (not $x753)))
(and $x2782 (or $x753 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 57: function crcu8, block 19, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x278 ((_ zero_extend 16) in.01_16)))
(let ((?x111 (bvxor ?x278 (_ bv16386 32))))
(let (($x753 (or false false)))
(let (($x616 (or $x753 false false)))
(let (($x98 (not $x616)))
(and $x98 (or $x616 (and (distinct ?x111 ?x111) true)))))))))
(check-sat)
; query 58: function crcu8, block 19, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x278 ((_ zero_extend 16) in.01_16)))
(let ((?x111 (bvxor ?x278 (_ bv16386 32))))
(let ((?x820 ((_ extract 15 0) ?x111)))
(let (($x753 (or false false)))
(let (($x616 (or $x753 false false)))
(let (($x156 (or $x616 false)))
(let (($x126 (not $x156)))
(and $x126 (or $x156 (and (distinct ?x820 ?x820) true)))))))))))
(check-sat)
; query 59: function crcu8, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x753 (or false false)))
(let (($x2782 (not $x753)))
(and $x2782 (or $x753 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 60: function crcu8, block 29, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1294 ((_ zero_extend 16) in27_16)))
(let ((?x92 (bvor ?x1294 (_ bv32768 32))))
(let (($x753 (or false false)))
(let (($x616 (or $x753 false false)))
(let (($x98 (not $x616)))
(and $x98 (or $x616 (and (distinct ?x92 ?x92) true)))))))))
(check-sat)
; query 61: function crcu8, block 29, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1294 ((_ zero_extend 16) in27_16)))
(let ((?x92 (bvor ?x1294 (_ bv32768 32))))
(let ((?x2078 ((_ extract 15 0) ?x92)))
(let (($x753 (or false false)))
(let (($x616 (or $x753 false false)))
(let (($x156 (or $x616 false)))
(let (($x126 (not $x156)))
(and $x126 (or $x156 (and (distinct ?x2078 ?x2078) true)))))))))))
(check-sat)
; query 62: function crcu8, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x753 (or false false)))
(let (($x2782 (not $x753)))
(and $x2782 (or $x753 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 63: function crcu8, block 33, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1294 ((_ zero_extend 16) in27_16)))
(let ((?x1236 (bvand ?x1294 (_ bv32767 32))))
(let (($x753 (or false false)))
(let (($x616 (or $x753 false false)))
(let (($x98 (not $x616)))
(and $x98 (or $x616 (and (distinct ?x1236 ?x1236) true)))))))))
(check-sat)
; query 64: function crcu8, block 33, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1294 ((_ zero_extend 16) in27_16)))
(let ((?x1236 (bvand ?x1294 (_ bv32767 32))))
(let ((?x1716 ((_ extract 15 0) ?x1236)))
(let (($x753 (or false false)))
(let (($x616 (or $x753 false false)))
(let (($x156 (or $x616 false)))
(let (($x126 (not $x156)))
(and $x126 (or $x156 (and (distinct ?x1716 ?x1716) true)))))))))))
(check-sat)
; query 65: function crcu8, block 38, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_8 () (_ BitVec 8))
(assert
 (let (($x514 (or false false false)))
(let (($x190 (not $x514)))
(and $x190 (or $x514 (and (distinct (bvadd in.02_8 (_ bv1 8)) (bvadd in.02_8 (_ bv1 8))) true))))))
(check-sat)
; query 66: function crcu8, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x858 ((_ extract 7 0) in.01_16)))
(let ((?x1157 ((_ zero_extend 24) ?x858)))
(let (($x753 (or false false)))
(let (($x456 (or $x753 false)))
(and (not $x456) (or $x456 (and (distinct ?x1157 ?x1157) true))))))))
(check-sat)
; query 67: function crcu8, block 6, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x858 ((_ extract 7 0) in.01_16)))
(let ((?x1157 ((_ zero_extend 24) ?x858)))
(let ((?x2313 (bvand ?x1157 (_ bv1 32))))
(let (($x753 (or false false)))
(let (($x456 (or $x753 false)))
(let (($x326 (or $x456 false false)))
(and (not $x326) (or $x326 (and (distinct ?x2313 ?x2313) true))))))))))
(check-sat)
; query 68: function crcu8, block 6, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x858 ((_ extract 7 0) in.01_16)))
(let ((?x1157 ((_ zero_extend 24) ?x858)))
(let ((?x2313 (bvand ?x1157 (_ bv1 32))))
(let ((?x987 ((_ zero_extend 24) in.0_8)))
(let ((?x171 (bvand ?x987 (_ bv1 32))))
(let ((?x2013 (bvxor ?x171 ?x2313)))
(let (($x753 (or false false)))
(let (($x456 (or $x753 false)))
(let (($x326 (or $x456 false false)))
(let (($x616 (or $x753 false false)))
(let (($x328 (or $x616 $x326 false)))
(and (not $x328) (or $x328 (and (distinct ?x2013 ?x2013) true)))))))))))))))
(check-sat)
; query 69: function crcu8, block 6, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x858 ((_ extract 7 0) in.01_16)))
(let ((?x1157 ((_ zero_extend 24) ?x858)))
(let ((?x2313 (bvand ?x1157 (_ bv1 32))))
(let ((?x987 ((_ zero_extend 24) in.0_8)))
(let ((?x171 (bvand ?x987 (_ bv1 32))))
(let ((?x2013 (bvxor ?x171 ?x2313)))
(let ((?x1566 ((_ extract 7 0) ?x2013)))
(let (($x753 (or false false)))
(let (($x456 (or $x753 false)))
(let (($x326 (or $x456 false false)))
(let (($x616 (or $x753 false false)))
(let (($x328 (or $x616 $x326 false)))
(let (($x603 (or $x328 false)))
(and (not $x603) (or $x603 (and (distinct ?x1566 ?x1566) true)))))))))))))))))
(check-sat)
; query 70: function crcu8, block 6, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x753 (or false false)))
(let (($x2782 (not $x753)))
(and $x2782 (or $x753 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 71: function crcu8, block 6, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x987 ((_ zero_extend 24) in.0_8)))
(let ((?x1068 (bvashr ?x987 (_ bv1 32))))
(let (($x753 (or false false)))
(let (($x616 (or $x753 false false)))
(let (($x1954 (or $x616 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not $x1954) (or $x1954 (and (distinct ?x1068 ?x1068) true)))))))))
(check-sat)
; query 72: function crcu8, block 6, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x987 ((_ zero_extend 24) in.0_8)))
(let ((?x1068 (bvashr ?x987 (_ bv1 32))))
(let ((?x1335 ((_ extract 7 0) ?x1068)))
(let (($x753 (or false false)))
(let (($x616 (or $x753 false false)))
(let (($x1954 (or $x616 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x1782 (or $x1954 false)))
(and (not $x1782) (or $x1782 (and (distinct ?x1335 ?x1335) true)))))))))))
(check-sat)
; query 73: function crcu8, block 6, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x858 ((_ extract 7 0) in.01_16)))
(let ((?x1157 ((_ zero_extend 24) ?x858)))
(let ((?x2313 (bvand ?x1157 (_ bv1 32))))
(let ((?x987 ((_ zero_extend 24) in.0_8)))
(let ((?x171 (bvand ?x987 (_ bv1 32))))
(let ((?x2013 (bvxor ?x171 ?x2313)))
(let ((?x1566 ((_ extract 7 0) ?x2013)))
(let ((?x2005 ((_ zero_extend 24) ?x1566)))
(let (($x753 (or false false)))
(let (($x456 (or $x753 false)))
(let (($x326 (or $x456 false false)))
(let (($x616 (or $x753 false false)))
(let (($x328 (or $x616 $x326 false)))
(let (($x603 (or $x328 false)))
(let (($x1245 (or $x603 false)))
(and (not $x1245) (or $x1245 (and (distinct ?x2005 ?x2005) true)))))))))))))))))))
(check-sat)
; query 74: function crcu8, block 6, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x858 ((_ extract 7 0) in.01_16)))
(let ((?x1157 ((_ zero_extend 24) ?x858)))
(let ((?x2313 (bvand ?x1157 (_ bv1 32))))
(let ((?x987 ((_ zero_extend 24) in.0_8)))
(let ((?x171 (bvand ?x987 (_ bv1 32))))
(let ((?x2013 (bvxor ?x171 ?x2313)))
(let ((?x1566 ((_ extract 7 0) ?x2013)))
(let ((?x2005 ((_ zero_extend 24) ?x1566)))
(let ((?x826 (ite (= (_ bv1 32) ?x2005) (_ bv1 1) (_ bv0 1))))
(let (($x753 (or false false)))
(let (($x456 (or $x753 false)))
(let (($x326 (or $x456 false false)))
(let (($x616 (or $x753 false false)))
(let (($x328 (or $x616 $x326 false)))
(let (($x603 (or $x328 false)))
(let (($x1245 (or $x603 false)))
(let (($x1524 (or $x1245 false false)))
(and (not $x1524) (or $x1524 (and (distinct ?x826 ?x826) true)))))))))))))))))))))
(check-sat)
; query 75: function crcu8, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x753 (or false false)))
(let (($x2782 (not $x753)))
(and $x2782 (or $x753 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 76: function crcu8, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x987 ((_ zero_extend 24) in.0_8)))
(let ((?x171 (bvand ?x987 (_ bv1 32))))
(let (($x753 (or false false)))
(let (($x616 (or $x753 false false)))
(let (($x98 (not $x616)))
(and $x98 (or $x616 (and (distinct ?x171 ?x171) true)))))))))
(check-sat)
; query 77: function crcu8, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x753 (or false false)))
(let (($x2782 (not $x753)))
(and $x2782 (or $x753 (and (distinct ((_ extract 7 0) in.01_16) ((_ extract 7 0) in.01_16)) true))))))
(check-sat)
; query 78: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1119 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x152 ((_ zero_extend 31) ?x1119)))
(let ((?x728 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x938 ((_ zero_extend 31) ?x728)))
(let ((?x187 (bvand ?x938 ?x152)))
(let ((?x1278 (ite (and (distinct (_ bv0 32) ?x187) true) (_ bv1 1) (_ bv0 1))))
(let ((?x82 ((_ zero_extend 63) ?x1278)))
(let (($x753 (or false false)))
(let (($x616 (or $x753 false false)))
(let (($x156 (or $x616 false)))
(let (($x254 (or $x156 $x156 false)))
(let (($x2043 (or $x254 false false)))
(let (($x1325 (or $x2043 false)))
(and (not $x1325) (or $x1325 (and (distinct ?x82 ?x82) true)))))))))))))))))
(check-sat)
; query 79: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1119 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x152 ((_ zero_extend 31) ?x1119)))
(let ((?x728 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x938 ((_ zero_extend 31) ?x728)))
(let ((?x187 (bvand ?x938 ?x152)))
(let ((?x1278 (ite (and (distinct (_ bv0 32) ?x187) true) (_ bv1 1) (_ bv0 1))))
(let (($x81 (= (_ bv1 1) ?x1278)))
(let ((?x1188 (ite $x81 (_ bv1 32) (_ bv0 32))))
(let (($x753 (or false false)))
(let (($x616 (or $x753 false false)))
(let (($x156 (or $x616 false)))
(let (($x254 (or $x156 $x156 false)))
(let (($x2043 (or $x254 false false)))
(let (($x276 (or $x2043 (ite $x81 false false))))
(and (not $x276) (or $x276 (and (distinct ?x1188 ?x1188) true))))))))))))))))))
(check-sat)
; query 80: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1119 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x152 ((_ zero_extend 31) ?x1119)))
(let ((?x728 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x938 ((_ zero_extend 31) ?x728)))
(let ((?x187 (bvand ?x938 ?x152)))
(let ((?x1278 (ite (and (distinct (_ bv0 32) ?x187) true) (_ bv1 1) (_ bv0 1))))
(let (($x81 (= (_ bv1 1) ?x1278)))
(let ((?x1188 (ite $x81 (_ bv1 32) (_ bv0 32))))
(let ((?x919 ((_ extract 7 0) ?x1188)))
(let (($x753 (or false false)))
(let (($x616 (or $x753 false false)))
(let (($x156 (or $x616 false)))
(let (($x254 (or $x156 $x156 false)))
(let (($x2043 (or $x254 false false)))
(let (($x276 (or $x2043 (ite $x81 false false))))
(let (($x364 (or $x276 false)))
(and (not $x364) (or $x364 (and (distinct ?x919 ?x919) true))))))))))))))))))))
(check-sat)
; query 81: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x753 (or false false)))
(let (($x2782 (not $x753)))
(and $x2782 (or $x753 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 82: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x728 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x753 (or false false)))
(let (($x616 (or $x753 false false)))
(let (($x98 (not $x616)))
(and $x98 (or $x616 (and (distinct ?x728 ?x728) true))))))))
(check-sat)
; query 83: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x728 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x938 ((_ zero_extend 31) ?x728)))
(let (($x753 (or false false)))
(let (($x616 (or $x753 false false)))
(let (($x156 (or $x616 false)))
(let (($x126 (not $x156)))
(and $x126 (or $x156 (and (distinct ?x938 ?x938) true))))))))))
(check-sat)
; query 84: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x753 (or false false)))
(let (($x2782 (not $x753)))
(and $x2782 (or $x753 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 85: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1119 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x753 (or false false)))
(let (($x616 (or $x753 false false)))
(let (($x98 (not $x616)))
(and $x98 (or $x616 (and (distinct ?x1119 ?x1119) true))))))))
(check-sat)
; query 86: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1119 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x152 ((_ zero_extend 31) ?x1119)))
(let (($x753 (or false false)))
(let (($x616 (or $x753 false false)))
(let (($x156 (or $x616 false)))
(let (($x126 (not $x156)))
(and $x126 (or $x156 (and (distinct ?x152 ?x152) true))))))))))
(check-sat)
; query 87: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1119 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x152 ((_ zero_extend 31) ?x1119)))
(let ((?x728 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x938 ((_ zero_extend 31) ?x728)))
(let ((?x187 (bvand ?x938 ?x152)))
(let (($x753 (or false false)))
(let (($x616 (or $x753 false false)))
(let (($x156 (or $x616 false)))
(let (($x254 (or $x156 $x156 false)))
(and (not $x254) (or $x254 (and (distinct ?x187 ?x187) true)))))))))))))
(check-sat)
; query 88: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1119 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x152 ((_ zero_extend 31) ?x1119)))
(let ((?x728 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x938 ((_ zero_extend 31) ?x728)))
(let ((?x187 (bvand ?x938 ?x152)))
(let ((?x1278 (ite (and (distinct (_ bv0 32) ?x187) true) (_ bv1 1) (_ bv0 1))))
(let (($x753 (or false false)))
(let (($x616 (or $x753 false false)))
(let (($x156 (or $x616 false)))
(let (($x254 (or $x156 $x156 false)))
(let (($x2043 (or $x254 false false)))
(and (not $x2043) (or $x2043 (and (distinct ?x1278 ?x1278) true)))))))))))))))
(check-sat)
; query 89: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1498 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x514 (or false false false)))
(let (($x190 (not $x514)))
(and $x190 (or $x514 (and (distinct ?x1498 ?x1498) true)))))))
(check-sat)
; query 90: function matrix_add_const, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x514 (or false false false)))
(let (($x190 (not $x514)))
(and $x190 (or $x514 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 91: function matrix_add_const, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x622 (bvadd in.01_32 (_ bv1 32))))
(let (($x153 (and (distinct ?x622 ?x622) true)))
(let (($x514 (or false false false)))
(let (($x190 (not $x514)))
(and $x190 (or $x514 $x153)))))))
(check-sat)
; query 92: function matrix_mul_const, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x514 (or false false false)))
(let (($x190 (not $x514)))
(and $x190 (or $x514 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 93: function matrix_mul_const, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x622 (bvadd in.01_32 (_ bv1 32))))
(let (($x153 (and (distinct ?x622 ?x622) true)))
(let (($x514 (or false false false)))
(let (($x190 (not $x514)))
(and $x190 (or $x514 $x153)))))))
(check-sat)
; query 94: function matrix_mul_matrix, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x514 (or false false false)))
(let (($x190 (not $x514)))
(and $x190 (or $x514 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 95: function matrix_mul_matrix, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x622 (bvadd in.01_32 (_ bv1 32))))
(let (($x153 (and (distinct ?x622 ?x622) true)))
(let (($x514 (or false false false)))
(let (($x190 (not $x514)))
(and $x190 (or $x514 $x153)))))))
(check-sat)
; query 96: function matrix_mul_matrix, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x514 (or false false false)))
(let (($x190 (not $x514)))
(and $x190 (or $x514 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 97: function matrix_mul_matrix_bitextract, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x514 (or false false false)))
(let (($x190 (not $x514)))
(and $x190 (or $x514 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 98: function matrix_mul_matrix_bitextract, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x622 (bvadd in.01_32 (_ bv1 32))))
(let (($x153 (and (distinct ?x622 ?x622) true)))
(let (($x514 (or false false false)))
(let (($x190 (not $x514)))
(and $x190 (or $x514 $x153)))))))
(check-sat)
; query 99: function matrix_mul_matrix_bitextract, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x514 (or false false false)))
(let (($x190 (not $x514)))
(and $x190 (or $x514 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 100: function matrix_mul_vect, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x514 (or false false false)))
(let (($x190 (not $x514)))
(and $x190 (or $x514 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 101: function matrix_mul_vect, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x622 (bvadd in.01_32 (_ bv1 32))))
(let (($x153 (and (distinct ?x622 ?x622) true)))
(let (($x514 (or false false false)))
(let (($x190 (not $x514)))
(and $x190 (or $x514 $x153)))))))
(check-sat)
; query 102: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x753 (or false false)))
(let (($x2782 (not $x753)))
(and $x2782 (or $x753 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 103: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x1984 ((_ sign_extend 16) in.1_16)))
(let ((?x1754 (bvadd ?x1984 (_ bv10 32))))
(let (($x2016 (and (distinct (bvadd ((_ sign_extend 1) ?x1984) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x1754)) true)))
(let (($x753 (or false false)))
(let (($x691 (or $x753 false (or $x2016))))
(and (not $x691) (or $x691 (and (distinct ?x1754 ?x1754) true)))))))))
(check-sat)
; query 104: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x1984 ((_ sign_extend 16) in.1_16)))
(let ((?x1754 (bvadd ?x1984 (_ bv10 32))))
(let ((?x140 ((_ extract 15 0) ?x1754)))
(let (($x2016 (and (distinct (bvadd ((_ sign_extend 1) ?x1984) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x1754)) true)))
(let (($x753 (or false false)))
(let (($x691 (or $x753 false (or $x2016))))
(let (($x1417 (or $x691 false)))
(and (not $x1417) (or $x1417 (and (distinct ?x140 ?x140) true)))))))))))
(check-sat)
; query 105: function matrix_sum, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x321 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x514 (or false false false)))
(let (($x190 (not $x514)))
(and $x190 (or $x514 (and (distinct ?x321 ?x321) true)))))))
(check-sat)
; query 106: function matrix_sum, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x321 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let ((?x1638 ((_ zero_extend 63) ?x321)))
(let (($x514 (or false false false)))
(let (($x818 (or $x514 false)))
(and (not $x818) (or $x818 (and (distinct ?x1638 ?x1638) true))))))))
(check-sat)
; query 107: function matrix_sum, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x321 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x106 (= (_ bv1 1) ?x321)))
(let ((?x2066 (ite $x106 (_ bv1 32) (_ bv0 32))))
(let (($x514 (or false false false)))
(let (($x1935 (or $x514 (ite $x106 false false))))
(and (not $x1935) (or $x1935 (and (distinct ?x2066 ?x2066) true)))))))))
(check-sat)
; query 108: function matrix_sum, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x753 (or false false)))
(let (($x2782 (not $x753)))
(and $x2782 (or $x753 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 109: function matrix_sum, block 22, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x321 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x106 (= (_ bv1 1) ?x321)))
(let ((?x2066 (ite $x106 (_ bv1 32) (_ bv0 32))))
(let ((?x1984 ((_ sign_extend 16) in.1_16)))
(let ((?x733 (bvadd ?x1984 ?x2066)))
(let (($x1271 (and (distinct (bvadd ((_ sign_extend 1) ?x1984) ((_ sign_extend 1) ?x2066)) ((_ sign_extend 1) ?x733)) true)))
(let (($x514 (or false false false)))
(let (($x1935 (or $x514 (ite $x106 false false))))
(let (($x753 (or false false)))
(let (($x1032 (or $x753 $x1935 (or $x1271))))
(and (not $x1032) (or $x1032 (and (distinct ?x733 ?x733) true))))))))))))))
(check-sat)
; query 110: function matrix_sum, block 22, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x321 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x106 (= (_ bv1 1) ?x321)))
(let ((?x2066 (ite $x106 (_ bv1 32) (_ bv0 32))))
(let ((?x1984 ((_ sign_extend 16) in.1_16)))
(let ((?x733 (bvadd ?x1984 ?x2066)))
(let ((?x1808 ((_ extract 15 0) ?x733)))
(let (($x1271 (and (distinct (bvadd ((_ sign_extend 1) ?x1984) ((_ sign_extend 1) ?x2066)) ((_ sign_extend 1) ?x733)) true)))
(let (($x514 (or false false false)))
(let (($x1935 (or $x514 (ite $x106 false false))))
(let (($x753 (or false false)))
(let (($x1032 (or $x753 $x1935 (or $x1271))))
(let (($x2054 (or $x1032 false)))
(and (not $x2054) (or $x2054 (and (distinct ?x1808 ?x1808) true))))))))))))))))
(check-sat)
; query 111: function matrix_sum, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x514 (or false false false)))
(let (($x190 (not $x514)))
(and $x190 (or $x514 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 112: function matrix_sum, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x622 (bvadd in.01_32 (_ bv1 32))))
(let (($x153 (and (distinct ?x622 ?x622) true)))
(let (($x514 (or false false false)))
(let (($x190 (not $x514)))
(and $x190 (or $x514 $x153)))))))
(check-sat)
; query 113: function parseval, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.23_32 () (_ BitVec 32))
(assert
 (let (($x1652 (and (distinct (bvmul ((_ sign_extend 32) in.23_32) ((_ sign_extend 32) (_ bv1024 32))) ((_ sign_extend 32) (bvmul in.23_32 (_ bv1024 32)))) true)))
(let (($x1893 (or false false (or $x1652))))
(and (not $x1893) (or $x1893 (and (distinct (bvmul in.23_32 (_ bv1024 32)) (bvmul in.23_32 (_ bv1024 32))) true))))))
(check-sat)
; query 114: function parseval, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.34_32 () (_ BitVec 32))
(assert
 (let (($x1258 (and (distinct (bvmul ((_ sign_extend 32) in.34_32) ((_ sign_extend 32) (_ bv1048576 32))) ((_ sign_extend 32) (bvmul in.34_32 (_ bv1048576 32)))) true)))
(let (($x1648 (or false false (or $x1258))))
(and (not $x1648) (or $x1648 (and (distinct (bvmul in.34_32 (_ bv1048576 32)) (bvmul in.34_32 (_ bv1048576 32))) true))))))
(check-sat)
; query 115: function partition_memory, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x514 (or false false false)))
(let (($x190 (not $x514)))
(and $x190 (or $x514 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 116: function run_matrix_multiply, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x514 (or false false false)))
(let (($x190 (not $x514)))
(and $x190 (or $x514 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 117: function run_matrix_multiply, block 34, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x622 (bvadd in.01_32 (_ bv1 32))))
(let (($x153 (and (distinct ?x622 ?x622) true)))
(let (($x514 (or false false false)))
(let (($x190 (not $x514)))
(and $x190 (or $x514 $x153)))))))
(check-sat)
