; OptiPhase-Sigma refinement certificate for sweep K55-R2-030
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x220 (or false (or (= ((_ extract 15 15) in25_16) (_ bv1 1))))))
(let (($x293 (or false false)))
(let (($x759 (not $x293)))
(and $x759 (or $x220 (and (distinct ((_ sign_extend 16) in25_16) ((_ zero_extend 16) in25_16)) true)))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x552 (and (distinct (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1)) (ite (bvsgt (_ bv34 32) ((_ zero_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))) true)))
(let (($x282 (or (or (or false (or (= ((_ extract 15 15) in25_16) (_ bv1 1)))) false false) $x552)))
(let (($x293 (or false false)))
(let (($x118 (or $x293 false false)))
(let (($x10 (not $x118)))
(and $x10 $x282)))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x293 (or false false)))
(let (($x759 (not $x293)))
(and $x759 (or $x293 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x328 ((_ sign_extend 16) in3_16)))
(let ((?x123 (bvand ?x328 (_ bv127 32))))
(let (($x293 (or false false)))
(let (($x118 (or $x293 false false)))
(let (($x10 (not $x118)))
(and $x10 (or $x118 (and (distinct ?x123 ?x123) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x328 ((_ sign_extend 16) in3_16)))
(let ((?x123 (bvand ?x328 (_ bv127 32))))
(let ((?x1932 ((_ extract 15 0) ?x123)))
(let (($x1944 (or (and (distinct ((_ zero_extend 16) ?x1932) ?x123) true) (and (distinct ((_ sign_extend 16) ?x1932) ?x123) true))))
(let (($x293 (or false false)))
(let (($x118 (or $x293 false false)))
(let (($x1879 (or $x118 false)))
(let (($x164 (not $x1879)))
(and $x164 (or (or $x118 $x1944) (and (distinct ?x1932 ?x1932) true))))))))))))
(check-sat)
; query 5: function core_bench_list, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x22 (or false false false)))
(let (($x157 (not $x22)))
(and $x157 (or $x22 (and (distinct (bvadd in.0_16 (_ bv1 16)) (bvadd in.0_16 (_ bv1 16))) true))))))
(check-sat)
; query 6: function core_bench_state, block 105, name %106
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let ((?x177 (bvadd in.1_32 (_ bv1 32))))
(let (($x283 (and (distinct ?x177 ?x177) true)))
(let (($x853 (and (distinct (bvadd ((_ zero_extend 1) in.1_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) ?x177)) true)))
(let (($x1884 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x177)) true)))
(let (($x22 (or false false false)))
(let (($x157 (not $x22)))
(and $x157 (or (or false false (or $x1884 $x853)) $x283)))))))))
(check-sat)
; query 7: function core_bench_state, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x506 (bvadd in.0_32 (_ bv1 32))))
(let (($x117 (and (distinct ?x506 ?x506) true)))
(let (($x281 (and (distinct (bvadd ((_ zero_extend 1) in.0_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) ?x506)) true)))
(let (($x226 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x506)) true)))
(let (($x22 (or false false false)))
(let (($x157 (not $x22)))
(and $x157 (or (or false false (or $x226 $x281)) $x117)))))))))
(check-sat)
; query 8: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x149 (bvadd in.01_32 (_ bv1 32))))
(let (($x668 (and (distinct ?x149 ?x149) true)))
(let (($x22 (or false false false)))
(let (($x157 (not $x22)))
(and $x157 (or $x22 $x668)))))))
(check-sat)
; query 9: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x149 (bvadd in.01_32 (_ bv1 32))))
(let ((?x229 (bvmul ?x149 ?x149)))
(let (($x22 (or false false false)))
(let (($x344 (or $x22 $x22 false)))
(and (not $x344) (or $x344 (and (distinct ?x229 ?x229) true))))))))
(check-sat)
; query 10: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x149 (bvadd in.01_32 (_ bv1 32))))
(let ((?x229 (bvmul ?x149 ?x149)))
(let ((?x139 (bvmul ?x229 (_ bv2 32))))
(let (($x22 (or false false false)))
(let (($x344 (or $x22 $x22 false)))
(let (($x777 (or $x344 false false)))
(and (not $x777) (or $x777 (and (distinct ?x139 ?x139) true))))))))))
(check-sat)
; query 11: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x149 (bvadd in.01_32 (_ bv1 32))))
(let ((?x229 (bvmul ?x149 ?x149)))
(let ((?x139 (bvmul ?x229 (_ bv2 32))))
(let ((?x48 (bvmul ?x139 (_ bv4 32))))
(let (($x22 (or false false false)))
(let (($x344 (or $x22 $x22 false)))
(let (($x777 (or $x344 false false)))
(let (($x202 (or $x777 false false)))
(and (not $x202) (or $x202 (and (distinct ?x48 ?x48) true))))))))))))
(check-sat)
; query 12: function core_init_matrix, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let ((?x177 (bvadd in.1_32 (_ bv1 32))))
(let (($x283 (and (distinct ?x177 ?x177) true)))
(let (($x22 (or false false false)))
(let (($x157 (not $x22)))
(and $x157 (or $x22 $x283)))))))
(check-sat)
; query 13: function core_init_matrix, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x22 (or false false false)))
(let (($x157 (not $x22)))
(and $x157 (or $x22 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 14: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x383 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x22 (or false false false)))
(let (($x157 (not $x22)))
(and $x157 (or $x22 (and (distinct ?x383 ?x383) true)))))))
(check-sat)
; query 15: function core_init_state, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_32 () (_ BitVec 32))
(assert
 (let (($x326 (and (distinct (bvadd ((_ zero_extend 1) in.06_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.06_32 (_ bv1 32)))) true)))
(let (($x9 (and (distinct (bvadd ((_ sign_extend 1) in.06_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.06_32 (_ bv1 32)))) true)))
(let (($x75 (or (or false false (or $x9 $x326)) (and (distinct (bvadd in.06_32 (_ bv1 32)) (bvadd in.06_32 (_ bv1 32))) true))))
(let (($x22 (or false false false)))
(let (($x157 (not $x22)))
(and $x157 $x75)))))))
(check-sat)
; query 16: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x89 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x22 (or false false false)))
(let (($x157 (not $x22)))
(and $x157 (or $x22 (and (distinct ?x89 ?x89) true)))))))
(check-sat)
; query 17: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x22 (or false false false)))
(let (($x157 (not $x22)))
(and $x157 (or $x22 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 18: function core_list_init, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x149 (bvadd in.01_32 (_ bv1 32))))
(let (($x668 (and (distinct ?x149 ?x149) true)))
(let (($x62 (and (distinct (bvadd ((_ zero_extend 1) in.01_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) ?x149)) true)))
(let (($x22 (or false false false)))
(let (($x157 (not $x22)))
(and $x157 (or (or false false (or $x62)) $x668))))))))
(check-sat)
; query 19: function core_list_mergesort, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x149 (bvadd in.01_32 (_ bv1 32))))
(let (($x668 (and (distinct ?x149 ?x149) true)))
(let (($x140 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x149)) true)))
(let (($x154 (or false false (or $x140))))
(and (not $x154) (or $x154 $x668)))))))
(check-sat)
; query 20: function core_list_mergesort, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x388 (ite (bvslt (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x22 (or false false false)))
(let (($x157 (not $x22)))
(and $x157 (or $x22 (and (distinct ?x388 ?x388) true)))))))
(check-sat)
; query 21: function core_list_mergesort, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.224_32 () (_ BitVec 32))
(assert
 (let ((?x396 (ite (= (_ bv0 32) in.224_32) (_ bv1 1) (_ bv0 1))))
(let (($x22 (or false false false)))
(let (($x157 (not $x22)))
(and $x157 (or $x22 (and (distinct ?x396 ?x396) true)))))))
(check-sat)
; query 22: function core_list_mergesort, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x302 (ite (= (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x22 (or false false false)))
(let (($x157 (not $x22)))
(and $x157 (or $x22 (and (distinct ?x302 ?x302) true)))))))
(check-sat)
; query 23: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x395 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x365 (or false false (or $x395))))
(and (not $x365) (or $x365 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 24: function core_list_mergesort, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x221 (and (distinct (bvmul ((_ sign_extend 32) in.020_32) ((_ sign_extend 32) (_ bv2 32))) ((_ sign_extend 32) (bvmul in.020_32 (_ bv2 32)))) true)))
(let (($x560 (or false false (or $x221))))
(and (not $x560) (or $x560 (and (distinct (bvmul in.020_32 (_ bv2 32)) (bvmul in.020_32 (_ bv2 32))) true))))))
(check-sat)
; query 25: function core_state_transition, block 102, name %103
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x293 (or false false)))
(let (($x759 (not $x293)))
(and $x759 (or $x293 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 26: function core_state_transition, block 102, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x159 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x293 (or false false)))
(let (($x118 (or $x293 false false)))
(let (($x10 (not $x118)))
(and $x10 (or $x118 (and (distinct ?x159 ?x159) true))))))))
(check-sat)
; query 27: function core_state_transition, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x293 (or false false)))
(let (($x759 (not $x293)))
(and $x759 (or $x293 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 28: function core_state_transition, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x14 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x293 (or false false)))
(let (($x118 (or $x293 false false)))
(let (($x10 (not $x118)))
(and $x10 (or $x118 (and (distinct ?x14 ?x14) true))))))))
(check-sat)
; query 29: function core_state_transition, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x293 (or false false)))
(let (($x759 (not $x293)))
(and $x759 (or $x293 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 30: function core_state_transition, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x159 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x293 (or false false)))
(let (($x118 (or $x293 false false)))
(let (($x10 (not $x118)))
(and $x10 (or $x118 (and (distinct ?x159 ?x159) true))))))))
(check-sat)
; query 31: function core_state_transition, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x293 (or false false)))
(let (($x759 (not $x293)))
(and $x759 (or $x293 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 32: function core_state_transition, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x418 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x293 (or false false)))
(let (($x118 (or $x293 false false)))
(let (($x10 (not $x118)))
(and $x10 (or $x118 (and (distinct ?x418 ?x418) true))))))))
(check-sat)
; query 33: function core_state_transition, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x293 (or false false)))
(let (($x759 (not $x293)))
(and $x759 (or $x293 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 34: function core_state_transition, block 51, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x418 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x293 (or false false)))
(let (($x118 (or $x293 false false)))
(let (($x10 (not $x118)))
(and $x10 (or $x118 (and (distinct ?x418 ?x418) true))))))))
(check-sat)
; query 35: function core_state_transition, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x293 (or false false)))
(let (($x759 (not $x293)))
(and $x759 (or $x293 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 36: function core_state_transition, block 64, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x418 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x293 (or false false)))
(let (($x118 (or $x293 false false)))
(let (($x10 (not $x118)))
(and $x10 (or $x118 (and (distinct ?x418 ?x418) true))))))))
(check-sat)
; query 37: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x589 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x22 (or false false false)))
(let (($x157 (not $x22)))
(and $x157 (or $x22 (and (distinct ?x589 ?x589) true)))))))
(check-sat)
; query 38: function core_state_transition, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x293 (or false false)))
(let (($x759 (not $x293)))
(and $x759 (or $x293 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 39: function core_state_transition, block 80, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x289 (ite (= (_ bv69 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x293 (or false false)))
(let (($x118 (or $x293 false false)))
(let (($x10 (not $x118)))
(and $x10 (or $x118 (and (distinct ?x289 ?x289) true))))))))
(check-sat)
; query 40: function core_state_transition, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x293 (or false false)))
(let (($x759 (not $x293)))
(and $x759 (or $x293 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 41: function core_state_transition, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x464 (ite (= (_ bv101 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x293 (or false false)))
(let (($x118 (or $x293 false false)))
(let (($x10 (not $x118)))
(and $x10 (or $x118 (and (distinct ?x464 ?x464) true))))))))
(check-sat)
; query 42: function core_state_transition, block 99, name %100
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x293 (or false false)))
(let (($x759 (not $x293)))
(and $x759 (or $x293 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 43: function core_state_transition, block 99, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x14 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x293 (or false false)))
(let (($x118 (or $x293 false false)))
(let (($x10 (not $x118)))
(and $x10 (or $x118 (and (distinct ?x14 ?x14) true))))))))
(check-sat)
; query 44: function crcu8, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x293 (or false false)))
(let (($x759 (not $x293)))
(and $x759 (or $x293 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 45: function crcu8, block 19, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x2062 ((_ zero_extend 16) in.01_16)))
(let ((?x335 (bvxor ?x2062 (_ bv16386 32))))
(let (($x293 (or false false)))
(let (($x118 (or $x293 false false)))
(let (($x10 (not $x118)))
(and $x10 (or $x118 (and (distinct ?x335 ?x335) true)))))))))
(check-sat)
; query 46: function crcu8, block 19, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x2062 ((_ zero_extend 16) in.01_16)))
(let ((?x335 (bvxor ?x2062 (_ bv16386 32))))
(let ((?x597 ((_ extract 15 0) ?x335)))
(let (($x293 (or false false)))
(let (($x118 (or $x293 false false)))
(let (($x1882 (or (or $x118 (or (and (distinct ((_ zero_extend 16) ?x597) ?x335) true))) (and (distinct ?x597 ?x597) true))))
(let (($x1879 (or $x118 false)))
(let (($x164 (not $x1879)))
(and $x164 $x1882))))))))))
(check-sat)
; query 47: function crcu8, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x629 (or false (or (= ((_ extract 15 15) in27_16) (_ bv1 1))))))
(let (($x293 (or false false)))
(let (($x759 (not $x293)))
(and $x759 (or $x629 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true)))))))
(check-sat)
; query 48: function crcu8, block 29, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1919 ((_ zero_extend 16) in27_16)))
(let ((?x308 (bvor ?x1919 (_ bv32768 32))))
(let (($x629 (or false (or (= ((_ extract 15 15) in27_16) (_ bv1 1))))))
(let (($x979 (or $x629 false false)))
(let (($x293 (or false false)))
(let (($x118 (or $x293 false false)))
(let (($x10 (not $x118)))
(and $x10 (or $x979 (and (distinct ?x308 ?x308) true)))))))))))
(check-sat)
; query 49: function crcu8, block 29, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1919 ((_ zero_extend 16) in27_16)))
(let ((?x308 (bvor ?x1919 (_ bv32768 32))))
(let ((?x1924 ((_ extract 15 0) ?x308)))
(let (($x629 (or false (or (= ((_ extract 15 15) in27_16) (_ bv1 1))))))
(let (($x979 (or $x629 false false)))
(let (($x1103 (or (or $x979 (or (and (distinct ((_ zero_extend 16) ?x1924) ?x308) true))) (and (distinct ?x1924 ?x1924) true))))
(let (($x293 (or false false)))
(let (($x118 (or $x293 false false)))
(let (($x1879 (or $x118 false)))
(let (($x164 (not $x1879)))
(and $x164 $x1103))))))))))))
(check-sat)
; query 50: function crcu8, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x521 ((_ extract 7 0) in.01_16)))
(let ((?x648 ((_ zero_extend 24) ?x521)))
(let (($x293 (or false false)))
(let (($x553 (or $x293 false)))
(and (not $x553) (or $x553 (and (distinct ?x648 ?x648) true))))))))
(check-sat)
; query 51: function crcu8, block 6, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x521 ((_ extract 7 0) in.01_16)))
(let ((?x648 ((_ zero_extend 24) ?x521)))
(let ((?x1818 (bvand ?x648 (_ bv1 32))))
(let (($x293 (or false false)))
(let (($x553 (or $x293 false)))
(let (($x1971 (or $x553 false false)))
(and (not $x1971) (or $x1971 (and (distinct ?x1818 ?x1818) true))))))))))
(check-sat)
; query 52: function crcu8, block 6, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x521 ((_ extract 7 0) in.01_16)))
(let ((?x648 ((_ zero_extend 24) ?x521)))
(let ((?x1818 (bvand ?x648 (_ bv1 32))))
(let ((?x1962 ((_ zero_extend 24) in.0_8)))
(let ((?x1534 (bvand ?x1962 (_ bv1 32))))
(let ((?x378 (bvxor ?x1534 ?x1818)))
(let (($x293 (or false false)))
(let (($x553 (or $x293 false)))
(let (($x1971 (or $x553 false false)))
(let (($x118 (or $x293 false false)))
(let (($x1925 (or $x118 $x1971 false)))
(and (not $x1925) (or $x1925 (and (distinct ?x378 ?x378) true)))))))))))))))
(check-sat)
; query 53: function crcu8, block 6, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x521 ((_ extract 7 0) in.01_16)))
(let ((?x648 ((_ zero_extend 24) ?x521)))
(let ((?x1818 (bvand ?x648 (_ bv1 32))))
(let ((?x1962 ((_ zero_extend 24) in.0_8)))
(let ((?x1534 (bvand ?x1962 (_ bv1 32))))
(let ((?x378 (bvxor ?x1534 ?x1818)))
(let ((?x1965 ((_ extract 7 0) ?x378)))
(let (($x1873 (or (and (distinct ((_ zero_extend 24) ?x1965) ?x378) true) (and (distinct ((_ sign_extend 24) ?x1965) ?x378) true))))
(let (($x293 (or false false)))
(let (($x553 (or $x293 false)))
(let (($x1971 (or $x553 false false)))
(let (($x118 (or $x293 false false)))
(let (($x1925 (or $x118 $x1971 false)))
(let (($x2042 (or $x1925 $x1873)))
(and (not (or $x1925 false)) (or $x2042 (and (distinct ?x1965 ?x1965) true))))))))))))))))))
(check-sat)
; query 54: function crcu8, block 6, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x293 (or false false)))
(let (($x759 (not $x293)))
(and $x759 (or $x293 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 55: function crcu8, block 6, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1962 ((_ zero_extend 24) in.0_8)))
(let ((?x1793 (bvlshr ?x1962 (_ bv1 32))))
(let ((?x1993 (bvashr ?x1962 (_ bv1 32))))
(let (($x293 (or false false)))
(let (($x118 (or $x293 false false)))
(let (($x1933 (or $x118 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not $x1933) (or $x1933 (and (distinct ?x1993 ?x1793) true))))))))))
(check-sat)
; query 56: function crcu8, block 6, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x1953 (and (distinct ((_ extract 7 0) (bvashr ((_ zero_extend 24) in.0_8) (_ bv1 32))) ((_ extract 7 0) (bvlshr ((_ zero_extend 24) in.0_8) (_ bv1 32)))) true)))
(let (($x293 (or false false)))
(let (($x118 (or $x293 false false)))
(let (($x1933 (or $x118 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x1979 (or $x1933 false)))
(and (not $x1979) (or $x1979 $x1953))))))))
(check-sat)
; query 57: function crcu8, block 6, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x521 ((_ extract 7 0) in.01_16)))
(let ((?x648 ((_ zero_extend 24) ?x521)))
(let ((?x1818 (bvand ?x648 (_ bv1 32))))
(let ((?x1962 ((_ zero_extend 24) in.0_8)))
(let ((?x1534 (bvand ?x1962 (_ bv1 32))))
(let ((?x378 (bvxor ?x1534 ?x1818)))
(let ((?x1965 ((_ extract 7 0) ?x378)))
(let ((?x647 ((_ zero_extend 24) ?x1965)))
(let (($x293 (or false false)))
(let (($x553 (or $x293 false)))
(let (($x1971 (or $x553 false false)))
(let (($x118 (or $x293 false false)))
(let (($x1925 (or $x118 $x1971 false)))
(let (($x2042 (or $x1925 (or (and (distinct ?x647 ?x378) true) (and (distinct ((_ sign_extend 24) ?x1965) ?x378) true)))))
(let (($x1957 (or $x2042 (or (= ((_ extract 7 7) ?x1965) (_ bv1 1))))))
(and (not (or (or $x1925 false) false)) (or $x1957 (and (distinct ?x647 ?x647) true)))))))))))))))))))
(check-sat)
; query 58: function crcu8, block 6, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x521 ((_ extract 7 0) in.01_16)))
(let ((?x648 ((_ zero_extend 24) ?x521)))
(let ((?x1818 (bvand ?x648 (_ bv1 32))))
(let ((?x1962 ((_ zero_extend 24) in.0_8)))
(let ((?x1534 (bvand ?x1962 (_ bv1 32))))
(let ((?x378 (bvxor ?x1534 ?x1818)))
(let ((?x1965 ((_ extract 7 0) ?x378)))
(let ((?x647 ((_ zero_extend 24) ?x1965)))
(let ((?x1934 (ite (= (_ bv1 32) ?x647) (_ bv1 1) (_ bv0 1))))
(let (($x293 (or false false)))
(let (($x553 (or $x293 false)))
(let (($x1971 (or $x553 false false)))
(let (($x118 (or $x293 false false)))
(let (($x1925 (or $x118 $x1971 false)))
(let (($x2042 (or $x1925 (or (and (distinct ?x647 ?x378) true) (and (distinct ((_ sign_extend 24) ?x1965) ?x378) true)))))
(let (($x1957 (or $x2042 (or (= ((_ extract 7 7) ?x1965) (_ bv1 1))))))
(and (not (or (or (or $x1925 false) false) false false)) (or (or $x1957 false false) (and (distinct ?x1934 ?x1934) true))))))))))))))))))))
(check-sat)
; query 59: function crcu8, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x293 (or false false)))
(let (($x759 (not $x293)))
(and $x759 (or $x293 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 60: function crcu8, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1962 ((_ zero_extend 24) in.0_8)))
(let ((?x1534 (bvand ?x1962 (_ bv1 32))))
(let (($x293 (or false false)))
(let (($x118 (or $x293 false false)))
(let (($x10 (not $x118)))
(and $x10 (or $x118 (and (distinct ?x1534 ?x1534) true)))))))))
(check-sat)
; query 61: function crcu8, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x293 (or false false)))
(let (($x759 (not $x293)))
(and $x759 (or $x293 (and (distinct ((_ extract 7 0) in.01_16) ((_ extract 7 0) in.01_16)) true))))))
(check-sat)
; query 62: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x93 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1929 ((_ zero_extend 31) ?x93)))
(let ((?x1531 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1892 ((_ zero_extend 31) ?x1531)))
(let ((?x1806 (bvand ?x1892 ?x1929)))
(let ((?x770 (ite (and (distinct (_ bv0 32) ?x1806) true) (_ bv1 1) (_ bv0 1))))
(let ((?x1888 ((_ zero_extend 63) ?x770)))
(let (($x293 (or false false)))
(let (($x118 (or $x293 false false)))
(let (($x1879 (or $x118 false)))
(let (($x2058 (or $x1879 $x1879 false)))
(let (($x1816 (or $x2058 false false)))
(let (($x1961 (or $x1816 false)))
(and (not $x1961) (or $x1961 (and (distinct ?x1888 ?x1888) true)))))))))))))))))
(check-sat)
; query 63: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x93 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1929 ((_ zero_extend 31) ?x93)))
(let ((?x1531 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1892 ((_ zero_extend 31) ?x1531)))
(let ((?x1806 (bvand ?x1892 ?x1929)))
(let ((?x770 (ite (and (distinct (_ bv0 32) ?x1806) true) (_ bv1 1) (_ bv0 1))))
(let (($x1903 (= (_ bv1 1) ?x770)))
(let ((?x1831 (ite $x1903 (_ bv1 32) (_ bv0 32))))
(let (($x293 (or false false)))
(let (($x118 (or $x293 false false)))
(let (($x1879 (or $x118 false)))
(let (($x2058 (or $x1879 $x1879 false)))
(let (($x1816 (or $x2058 false false)))
(let (($x363 (or $x1816 (ite $x1903 false false))))
(and (not $x363) (or $x363 (and (distinct ?x1831 ?x1831) true))))))))))))))))))
(check-sat)
; query 64: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x93 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1929 ((_ zero_extend 31) ?x93)))
(let ((?x1531 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1892 ((_ zero_extend 31) ?x1531)))
(let ((?x1806 (bvand ?x1892 ?x1929)))
(let ((?x770 (ite (and (distinct (_ bv0 32) ?x1806) true) (_ bv1 1) (_ bv0 1))))
(let (($x1903 (= (_ bv1 1) ?x770)))
(let ((?x1831 (ite $x1903 (_ bv1 32) (_ bv0 32))))
(let ((?x735 ((_ extract 7 0) ?x1831)))
(let (($x1829 (or (and (distinct ((_ zero_extend 24) ?x735) ?x1831) true) (and (distinct ((_ sign_extend 24) ?x735) ?x1831) true))))
(let (($x293 (or false false)))
(let (($x118 (or $x293 false false)))
(let (($x1879 (or $x118 false)))
(let (($x2058 (or $x1879 $x1879 false)))
(let (($x1816 (or $x2058 false false)))
(let (($x363 (or $x1816 (ite $x1903 false false))))
(and (not (or $x363 false)) (or (or $x363 $x1829) (and (distinct ?x735 ?x735) true))))))))))))))))))))
(check-sat)
; query 65: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x293 (or false false)))
(let (($x759 (not $x293)))
(and $x759 (or $x293 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 66: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1531 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x293 (or false false)))
(let (($x118 (or $x293 false false)))
(let (($x10 (not $x118)))
(and $x10 (or $x118 (and (distinct ?x1531 ?x1531) true))))))))
(check-sat)
; query 67: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1531 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1892 ((_ zero_extend 31) ?x1531)))
(let (($x293 (or false false)))
(let (($x118 (or $x293 false false)))
(let (($x1879 (or $x118 false)))
(let (($x164 (not $x1879)))
(and $x164 (or $x1879 (and (distinct ?x1892 ?x1892) true))))))))))
(check-sat)
; query 68: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x293 (or false false)))
(let (($x759 (not $x293)))
(and $x759 (or $x293 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 69: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x93 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x293 (or false false)))
(let (($x118 (or $x293 false false)))
(let (($x10 (not $x118)))
(and $x10 (or $x118 (and (distinct ?x93 ?x93) true))))))))
(check-sat)
; query 70: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x93 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1929 ((_ zero_extend 31) ?x93)))
(let (($x293 (or false false)))
(let (($x118 (or $x293 false false)))
(let (($x1879 (or $x118 false)))
(let (($x164 (not $x1879)))
(and $x164 (or $x1879 (and (distinct ?x1929 ?x1929) true))))))))))
(check-sat)
; query 71: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x93 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1929 ((_ zero_extend 31) ?x93)))
(let ((?x1531 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1892 ((_ zero_extend 31) ?x1531)))
(let ((?x1806 (bvand ?x1892 ?x1929)))
(let (($x293 (or false false)))
(let (($x118 (or $x293 false false)))
(let (($x1879 (or $x118 false)))
(let (($x2058 (or $x1879 $x1879 false)))
(and (not $x2058) (or $x2058 (and (distinct ?x1806 ?x1806) true)))))))))))))
(check-sat)
; query 72: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x93 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1929 ((_ zero_extend 31) ?x93)))
(let ((?x1531 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1892 ((_ zero_extend 31) ?x1531)))
(let ((?x1806 (bvand ?x1892 ?x1929)))
(let ((?x770 (ite (and (distinct (_ bv0 32) ?x1806) true) (_ bv1 1) (_ bv0 1))))
(let (($x293 (or false false)))
(let (($x118 (or $x293 false false)))
(let (($x1879 (or $x118 false)))
(let (($x2058 (or $x1879 $x1879 false)))
(let (($x1816 (or $x2058 false false)))
(and (not $x1816) (or $x1816 (and (distinct ?x770 ?x770) true)))))))))))))))
(check-sat)
; query 73: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x2083 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x22 (or false false false)))
(let (($x157 (not $x22)))
(and $x157 (or $x22 (and (distinct ?x2083 ?x2083) true)))))))
(check-sat)
; query 74: function matrix_add_const, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x506 (bvadd in.0_32 (_ bv1 32))))
(let (($x117 (and (distinct ?x506 ?x506) true)))
(let (($x22 (or false false false)))
(let (($x157 (not $x22)))
(and $x157 (or $x22 $x117)))))))
(check-sat)
; query 75: function matrix_add_const, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x149 (bvadd in.01_32 (_ bv1 32))))
(let (($x668 (and (distinct ?x149 ?x149) true)))
(let (($x22 (or false false false)))
(let (($x157 (not $x22)))
(and $x157 (or $x22 $x668)))))))
(check-sat)
; query 76: function matrix_mul_const, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x506 (bvadd in.0_32 (_ bv1 32))))
(let (($x117 (and (distinct ?x506 ?x506) true)))
(let (($x22 (or false false false)))
(let (($x157 (not $x22)))
(and $x157 (or $x22 $x117)))))))
(check-sat)
; query 77: function matrix_mul_const, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x149 (bvadd in.01_32 (_ bv1 32))))
(let (($x668 (and (distinct ?x149 ?x149) true)))
(let (($x22 (or false false false)))
(let (($x157 (not $x22)))
(and $x157 (or $x22 $x668)))))))
(check-sat)
; query 78: function matrix_mul_matrix, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x506 (bvadd in.0_32 (_ bv1 32))))
(let (($x117 (and (distinct ?x506 ?x506) true)))
(let (($x22 (or false false false)))
(let (($x157 (not $x22)))
(and $x157 (or $x22 $x117)))))))
(check-sat)
; query 79: function matrix_mul_matrix, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x149 (bvadd in.01_32 (_ bv1 32))))
(let (($x668 (and (distinct ?x149 ?x149) true)))
(let (($x22 (or false false false)))
(let (($x157 (not $x22)))
(and $x157 (or $x22 $x668)))))))
(check-sat)
; query 80: function matrix_mul_matrix, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x22 (or false false false)))
(let (($x157 (not $x22)))
(and $x157 (or $x22 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 81: function matrix_mul_matrix_bitextract, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x506 (bvadd in.0_32 (_ bv1 32))))
(let (($x117 (and (distinct ?x506 ?x506) true)))
(let (($x22 (or false false false)))
(let (($x157 (not $x22)))
(and $x157 (or $x22 $x117)))))))
(check-sat)
; query 82: function matrix_mul_matrix_bitextract, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x149 (bvadd in.01_32 (_ bv1 32))))
(let (($x668 (and (distinct ?x149 ?x149) true)))
(let (($x22 (or false false false)))
(let (($x157 (not $x22)))
(and $x157 (or $x22 $x668)))))))
(check-sat)
; query 83: function matrix_mul_matrix_bitextract, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x22 (or false false false)))
(let (($x157 (not $x22)))
(and $x157 (or $x22 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 84: function matrix_mul_vect, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x506 (bvadd in.0_32 (_ bv1 32))))
(let (($x117 (and (distinct ?x506 ?x506) true)))
(let (($x22 (or false false false)))
(let (($x157 (not $x22)))
(and $x157 (or $x22 $x117)))))))
(check-sat)
; query 85: function matrix_mul_vect, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x149 (bvadd in.01_32 (_ bv1 32))))
(let (($x668 (and (distinct ?x149 ?x149) true)))
(let (($x22 (or false false false)))
(let (($x157 (not $x22)))
(and $x157 (or $x22 $x668)))))))
(check-sat)
; query 86: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x293 (or false false)))
(let (($x759 (not $x293)))
(and $x759 (or $x293 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 87: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x2056 ((_ sign_extend 16) in.1_16)))
(let ((?x624 (bvadd ?x2056 (_ bv10 32))))
(let (($x473 (and (distinct (bvadd ((_ sign_extend 1) ?x2056) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x624)) true)))
(let (($x293 (or false false)))
(let (($x1808 (or $x293 false (or $x473))))
(and (not $x1808) (or $x1808 (and (distinct ?x624 ?x624) true)))))))))
(check-sat)
; query 88: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x2056 ((_ sign_extend 16) in.1_16)))
(let ((?x624 (bvadd ?x2056 (_ bv10 32))))
(let ((?x275 ((_ extract 15 0) ?x624)))
(let (($x473 (and (distinct (bvadd ((_ sign_extend 1) ?x2056) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x624)) true)))
(let (($x293 (or false false)))
(let (($x1808 (or $x293 false (or $x473))))
(let (($x745 (or $x1808 false)))
(and (not $x745) (or $x745 (and (distinct ?x275 ?x275) true)))))))))))
(check-sat)
; query 89: function matrix_sum, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x113 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x22 (or false false false)))
(let (($x157 (not $x22)))
(and $x157 (or $x22 (and (distinct ?x113 ?x113) true)))))))
(check-sat)
; query 90: function matrix_sum, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x113 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let ((?x1968 ((_ zero_extend 63) ?x113)))
(let (($x22 (or false false false)))
(let (($x1916 (or $x22 false)))
(and (not $x1916) (or $x1916 (and (distinct ?x1968 ?x1968) true))))))))
(check-sat)
; query 91: function matrix_sum, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x113 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x1905 (= (_ bv1 1) ?x113)))
(let ((?x1951 (ite $x1905 (_ bv1 32) (_ bv0 32))))
(let (($x22 (or false false false)))
(let (($x1898 (or $x22 (ite $x1905 false false))))
(and (not $x1898) (or $x1898 (and (distinct ?x1951 ?x1951) true)))))))))
(check-sat)
; query 92: function matrix_sum, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x293 (or false false)))
(let (($x759 (not $x293)))
(and $x759 (or $x293 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 93: function matrix_sum, block 22, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x113 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x1905 (= (_ bv1 1) ?x113)))
(let ((?x1951 (ite $x1905 (_ bv1 32) (_ bv0 32))))
(let ((?x2056 ((_ sign_extend 16) in.1_16)))
(let ((?x2035 (bvadd ?x2056 ?x1951)))
(let (($x2064 (and (distinct (bvadd ((_ sign_extend 1) ?x2056) ((_ sign_extend 1) ?x1951)) ((_ sign_extend 1) ?x2035)) true)))
(let (($x22 (or false false false)))
(let (($x1898 (or $x22 (ite $x1905 false false))))
(let (($x293 (or false false)))
(let (($x150 (or $x293 $x1898 (or $x2064))))
(and (not $x150) (or $x150 (and (distinct ?x2035 ?x2035) true))))))))))))))
(check-sat)
; query 94: function matrix_sum, block 22, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x113 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x1905 (= (_ bv1 1) ?x113)))
(let ((?x1951 (ite $x1905 (_ bv1 32) (_ bv0 32))))
(let ((?x2056 ((_ sign_extend 16) in.1_16)))
(let ((?x2035 (bvadd ?x2056 ?x1951)))
(let ((?x733 ((_ extract 15 0) ?x2035)))
(let (($x2064 (and (distinct (bvadd ((_ sign_extend 1) ?x2056) ((_ sign_extend 1) ?x1951)) ((_ sign_extend 1) ?x2035)) true)))
(let (($x22 (or false false false)))
(let (($x1898 (or $x22 (ite $x1905 false false))))
(let (($x293 (or false false)))
(let (($x150 (or $x293 $x1898 (or $x2064))))
(let (($x712 (or $x150 false)))
(and (not $x712) (or $x712 (and (distinct ?x733 ?x733) true))))))))))))))))
(check-sat)
; query 95: function matrix_sum, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x506 (bvadd in.0_32 (_ bv1 32))))
(let (($x117 (and (distinct ?x506 ?x506) true)))
(let (($x22 (or false false false)))
(let (($x157 (not $x22)))
(and $x157 (or $x22 $x117)))))))
(check-sat)
; query 96: function matrix_sum, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x149 (bvadd in.01_32 (_ bv1 32))))
(let (($x668 (and (distinct ?x149 ?x149) true)))
(let (($x22 (or false false false)))
(let (($x157 (not $x22)))
(and $x157 (or $x22 $x668)))))))
(check-sat)
; query 97: function parseval, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.23_32 () (_ BitVec 32))
(assert
 (let (($x625 (and (distinct (bvmul ((_ sign_extend 32) in.23_32) ((_ sign_extend 32) (_ bv1024 32))) ((_ sign_extend 32) (bvmul in.23_32 (_ bv1024 32)))) true)))
(let (($x713 (or false false (or $x625))))
(and (not $x713) (or $x713 (and (distinct (bvmul in.23_32 (_ bv1024 32)) (bvmul in.23_32 (_ bv1024 32))) true))))))
(check-sat)
; query 98: function parseval, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.34_32 () (_ BitVec 32))
(assert
 (let (($x571 (and (distinct (bvmul ((_ sign_extend 32) in.34_32) ((_ sign_extend 32) (_ bv1048576 32))) ((_ sign_extend 32) (bvmul in.34_32 (_ bv1048576 32)))) true)))
(let (($x1915 (or false false (or $x571))))
(and (not $x1915) (or $x1915 (and (distinct (bvmul in.34_32 (_ bv1048576 32)) (bvmul in.34_32 (_ bv1048576 32))) true))))))
(check-sat)
