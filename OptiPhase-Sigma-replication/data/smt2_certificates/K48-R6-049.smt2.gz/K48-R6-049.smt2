; OptiPhase-Sigma refinement certificate for sweep K48-R6-049
; query 0: function APCM_inverse_quantization, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x116 (or false false)))
(let (($x256 (not $x116)))
(and $x256 (or $x116 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 1: function APCM_inverse_quantization, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x362 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x116 (or false false)))
(let (($x220 (or $x116 false false)))
(let (($x1156 (not $x220)))
(and $x1156 (or $x220 (and (distinct ?x362 ?x362) true))))))))
(check-sat)
; query 2: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x116 (or false false)))
(let (($x256 (not $x116)))
(and $x256 (or $x116 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 3: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x212 (ite (bvslt (_ bv15 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x116 (or false false)))
(let (($x220 (or $x116 false false)))
(let (($x1156 (not $x220)))
(and $x1156 (or $x220 (and (distinct ?x212 ?x212) true))))))))
(check-sat)
; query 4: function Coefficients_0_12, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in15_64 () (_ BitVec 64))
(assert
 (let ((?x176 (ite (bvslt (_ bv0 64) in15_64) (_ bv1 1) (_ bv0 1))))
(let (($x2402 (or false false false)))
(let (($x470 (not $x2402)))
(and $x470 (or $x2402 (and (distinct ?x176 ?x176) true)))))))
(check-sat)
; query 5: function Coefficients_0_12, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in15_64 () (_ BitVec 64))
(assert
 (let ((?x176 (ite (bvslt (_ bv0 64) in15_64) (_ bv1 1) (_ bv0 1))))
(let ((?x79 ((_ zero_extend 63) ?x176)))
(let (($x2402 (or false false false)))
(let (($x217 (or $x2402 false)))
(let (($x366 (not $x217)))
(and $x366 (or $x217 (and (distinct ?x79 ?x79) true)))))))))
(check-sat)
; query 6: function Coefficients_0_12, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in15_64 () (_ BitVec 64))
(assert
 (let ((?x176 (ite (bvslt (_ bv0 64) in15_64) (_ bv1 1) (_ bv0 1))))
(let (($x733 (= (_ bv1 1) ?x176)))
(let ((?x1599 (ite $x733 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x2402 (or false false false)))
(let (($x113 (or $x2402 (ite $x733 false false))))
(and (not $x113) (or $x113 (and (distinct ?x1599 ?x1599) true)))))))))
(check-sat)
; query 7: function Coefficients_0_12, block 18, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in15_64 () (_ BitVec 64))
(assert
 (let ((?x176 (ite (bvslt (_ bv0 64) in15_64) (_ bv1 1) (_ bv0 1))))
(let (($x733 (= (_ bv1 1) ?x176)))
(let ((?x1599 (ite $x733 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x259 ((_ sign_extend 32) ?x1599)))
(let (($x2402 (or false false false)))
(let (($x113 (or $x2402 (ite $x733 false false))))
(let (($x2871 (or $x113 false)))
(and (not $x2871) (or $x2871 (and (distinct ?x259 ?x259) true)))))))))))
(check-sat)
; query 8: function Coefficients_27_39, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in15_64 () (_ BitVec 64))
(assert
 (let ((?x176 (ite (bvslt (_ bv0 64) in15_64) (_ bv1 1) (_ bv0 1))))
(let (($x2402 (or false false false)))
(let (($x470 (not $x2402)))
(and $x470 (or $x2402 (and (distinct ?x176 ?x176) true)))))))
(check-sat)
; query 9: function Coefficients_27_39, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in15_64 () (_ BitVec 64))
(assert
 (let ((?x176 (ite (bvslt (_ bv0 64) in15_64) (_ bv1 1) (_ bv0 1))))
(let ((?x79 ((_ zero_extend 63) ?x176)))
(let (($x2402 (or false false false)))
(let (($x217 (or $x2402 false)))
(let (($x366 (not $x217)))
(and $x366 (or $x217 (and (distinct ?x79 ?x79) true)))))))))
(check-sat)
; query 10: function Coefficients_27_39, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in15_64 () (_ BitVec 64))
(assert
 (let ((?x176 (ite (bvslt (_ bv0 64) in15_64) (_ bv1 1) (_ bv0 1))))
(let (($x733 (= (_ bv1 1) ?x176)))
(let ((?x1599 (ite $x733 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x2402 (or false false false)))
(let (($x113 (or $x2402 (ite $x733 false false))))
(and (not $x113) (or $x113 (and (distinct ?x1599 ?x1599) true)))))))))
(check-sat)
; query 11: function Coefficients_27_39, block 18, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in15_64 () (_ BitVec 64))
(assert
 (let ((?x176 (ite (bvslt (_ bv0 64) in15_64) (_ bv1 1) (_ bv0 1))))
(let (($x733 (= (_ bv1 1) ?x176)))
(let ((?x1599 (ite $x733 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x259 ((_ sign_extend 32) ?x1599)))
(let (($x2402 (or false false false)))
(let (($x113 (or $x2402 (ite $x733 false false))))
(let (($x2871 (or $x113 false)))
(and (not $x2871) (or $x2871 (and (distinct ?x259 ?x259) true)))))))))))
(check-sat)
; query 12: function Decoding_of_the_coded_Log_Area_Ratios, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in6_64 () (_ BitVec 64))
(assert
 (let ((?x28 (ite (bvslt (_ bv0 64) in6_64) (_ bv1 1) (_ bv0 1))))
(let (($x2402 (or false false false)))
(let (($x470 (not $x2402)))
(and $x470 (or $x2402 (and (distinct ?x28 ?x28) true)))))))
(check-sat)
; query 13: function Decoding_of_the_coded_Log_Area_Ratios, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in6_64 () (_ BitVec 64))
(assert
 (let ((?x28 (ite (bvslt (_ bv0 64) in6_64) (_ bv1 1) (_ bv0 1))))
(let ((?x2872 ((_ zero_extend 63) ?x28)))
(let (($x2402 (or false false false)))
(let (($x217 (or $x2402 false)))
(let (($x366 (not $x217)))
(and $x366 (or $x217 (and (distinct ?x2872 ?x2872) true)))))))))
(check-sat)
; query 14: function Decoding_of_the_coded_Log_Area_Ratios, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in6_64 () (_ BitVec 64))
(assert
 (let ((?x28 (ite (bvslt (_ bv0 64) in6_64) (_ bv1 1) (_ bv0 1))))
(let (($x63 (= (_ bv1 1) ?x28)))
(let ((?x115 (ite $x63 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x2402 (or false false false)))
(let (($x186 (or $x2402 (ite $x63 false false))))
(and (not $x186) (or $x186 (and (distinct ?x115 ?x115) true)))))))))
(check-sat)
; query 15: function Decoding_of_the_coded_Log_Area_Ratios, block 9, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in6_64 () (_ BitVec 64))
(assert
 (let ((?x28 (ite (bvslt (_ bv0 64) in6_64) (_ bv1 1) (_ bv0 1))))
(let (($x63 (= (_ bv1 1) ?x28)))
(let ((?x115 (ite $x63 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x12 ((_ sign_extend 32) ?x115)))
(let (($x2402 (or false false false)))
(let (($x186 (or $x2402 (ite $x63 false false))))
(let (($x72 (or $x186 false)))
(and (not $x72) (or $x72 (and (distinct ?x12 ?x12) true)))))))))))
(check-sat)
; query 16: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x116 (or false false)))
(let (($x256 (not $x116)))
(and $x256 (or $x116 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 17: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x41 (ite (bvsgt (_ bv40 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x116 (or false false)))
(let (($x220 (or $x116 false false)))
(let (($x1156 (not $x220)))
(and $x1156 (or $x220 (and (distinct ?x41 ?x41) true))))))))
(check-sat)
; query 18: function Postprocessing, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in17_64 () (_ BitVec 64))
(assert
 (let ((?x1458 (ite (bvslt (_ bv0 64) in17_64) (_ bv1 1) (_ bv0 1))))
(let (($x2402 (or false false false)))
(let (($x470 (not $x2402)))
(and $x470 (or $x2402 (and (distinct ?x1458 ?x1458) true)))))))
(check-sat)
; query 19: function Postprocessing, block 20, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in17_64 () (_ BitVec 64))
(assert
 (let ((?x1458 (ite (bvslt (_ bv0 64) in17_64) (_ bv1 1) (_ bv0 1))))
(let ((?x497 ((_ zero_extend 63) ?x1458)))
(let (($x2402 (or false false false)))
(let (($x217 (or $x2402 false)))
(let (($x366 (not $x217)))
(and $x366 (or $x217 (and (distinct ?x497 ?x497) true)))))))))
(check-sat)
; query 20: function Postprocessing, block 20, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in17_64 () (_ BitVec 64))
(assert
 (let ((?x1458 (ite (bvslt (_ bv0 64) in17_64) (_ bv1 1) (_ bv0 1))))
(let (($x665 (= (_ bv1 1) ?x1458)))
(let ((?x111 (ite $x665 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x2402 (or false false false)))
(let (($x190 (or $x2402 (ite $x665 false false))))
(and (not $x190) (or $x190 (and (distinct ?x111 ?x111) true)))))))))
(check-sat)
; query 21: function Postprocessing, block 20, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in17_64 () (_ BitVec 64))
(assert
 (let ((?x1458 (ite (bvslt (_ bv0 64) in17_64) (_ bv1 1) (_ bv0 1))))
(let (($x665 (= (_ bv1 1) ?x1458)))
(let ((?x111 (ite $x665 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x75 ((_ sign_extend 32) ?x111)))
(let (($x2402 (or false false false)))
(let (($x190 (or $x2402 (ite $x665 false false))))
(let (($x1596 (or $x190 false)))
(and (not $x1596) (or $x1596 (and (distinct ?x75 ?x75) true)))))))))))
(check-sat)
; query 22: function RPE_grid_positioning, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x116 (or false false)))
(let (($x256 (not $x116)))
(and $x256 (or $x116 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 23: function RPE_grid_positioning, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x39 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x163 (and (distinct ?x39 ?x39) true)))
(let (($x116 (or false false)))
(let (($x51 (or false $x116 false)))
(and (not $x51) (or $x51 $x163)))))))
(check-sat)
; query 24: function gsm_L_add, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_64 () (_ BitVec 64))
(assert
 (let ((?x1566 (bvsub (_ bv0 64) in13_64)))
(let ((?x569 ((_ sign_extend 1) ?x1566)))
(let (($x1139 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in13_64)) ?x569) true)))))
(and (not $x1139) (or $x1139 (and (distinct ?x1566 ?x1566) true)))))))
(check-sat)
; query 25: function gsm_L_add, block 16, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_64 () (_ BitVec 64))
(assert
 (let ((?x1566 (bvsub (_ bv0 64) in13_64)))
(let ((?x414 (bvsub ?x1566 (_ bv2 64))))
(let (($x1285 (and (distinct (bvsub ((_ sign_extend 1) ?x1566) ((_ sign_extend 1) (_ bv2 64))) ((_ sign_extend 1) ?x414)) true)))
(let ((?x569 ((_ sign_extend 1) ?x1566)))
(let (($x1139 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in13_64)) ?x569) true)))))
(let (($x167 (or $x1139 false (or $x1285))))
(and (not $x167) (or $x167 (and (distinct ?x414 ?x414) true))))))))))
(check-sat)
; query 26: function gsm_L_add, block 21, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x554 (ite (bvsge (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x2402 (or false false false)))
(let (($x470 (not $x2402)))
(and $x470 (or $x2402 (and (distinct ?x554 ?x554) true)))))))
(check-sat)
; query 27: function gsm_L_add, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x197 (bvadd in0_64 in1_64)))
(let (($x8 (and (distinct ?x197 ?x197) true)))
(let (($x266 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) ?x197)) true)))
(let (($x1894 (or false false (or $x266))))
(and (not $x1894) (or $x1894 $x8)))))))
(check-sat)
; query 28: function gsm_L_add, block 25, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x197 (bvadd in0_64 in1_64)))
(let (($x8 (and (distinct ?x197 ?x197) true)))
(let (($x2402 (or false false false)))
(let (($x470 (not $x2402)))
(and $x470 (or $x2402 $x8)))))))
(check-sat)
; query 29: function gsm_L_add, block 25, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1874 (ite (bvugt (bvadd in0_64 in1_64) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x2402 (or false false false)))
(let (($x375 (or $x2402 false false)))
(let (($x542 (not $x375)))
(and $x542 (or $x375 (and (distinct ?x1874 ?x1874) true))))))))
(check-sat)
; query 30: function gsm_L_add, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1384 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x2402 (or false false false)))
(let (($x470 (not $x2402)))
(and $x470 (or $x2402 (and (distinct ?x1384 ?x1384) true)))))))
(check-sat)
; query 31: function gsm_L_add, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x197 (bvadd in0_64 in1_64)))
(let (($x8 (and (distinct ?x197 ?x197) true)))
(let (($x266 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) ?x197)) true)))
(let (($x1894 (or false false (or $x266))))
(and (not $x1894) (or $x1894 $x8)))))))
(check-sat)
; query 32: function gsm_L_add, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1844 (bvadd in0_64 (_ bv1 64))))
(let ((?x225 (bvsub (_ bv0 64) ?x1844)))
(let (($x568 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1844)) ((_ sign_extend 1) ?x225)) true)))
(let ((?x373 ((_ sign_extend 1) ?x1844)))
(let (($x1854 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x373) true)))))
(let (($x46 (or false $x1854 (or $x568))))
(and (not $x46) (or $x46 (and (distinct ?x225 ?x225) true))))))))))
(check-sat)
; query 33: function gsm_L_add, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1080 (bvadd in1_64 (_ bv1 64))))
(let ((?x1051 ((_ sign_extend 1) ?x1080)))
(let (($x704 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1051) true)))))
(and (not $x704) (or $x704 (and (distinct ?x1080 ?x1080) true)))))))
(check-sat)
; query 34: function gsm_L_add, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1080 (bvadd in1_64 (_ bv1 64))))
(let ((?x744 (bvsub (_ bv0 64) ?x1080)))
(let (($x1188 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1080)) ((_ sign_extend 1) ?x744)) true)))
(let ((?x1051 ((_ sign_extend 1) ?x1080)))
(let (($x704 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1051) true)))))
(let (($x942 (or false $x704 (or $x1188))))
(and (not $x942) (or $x942 (and (distinct ?x744 ?x744) true))))))))))
(check-sat)
; query 35: function gsm_L_add, block 8, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1080 (bvadd in1_64 (_ bv1 64))))
(let ((?x744 (bvsub (_ bv0 64) ?x1080)))
(let ((?x1844 (bvadd in0_64 (_ bv1 64))))
(let ((?x225 (bvsub (_ bv0 64) ?x1844)))
(let ((?x1834 (bvadd ?x225 ?x744)))
(let (($x1188 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1080)) ((_ sign_extend 1) ?x744)) true)))
(let ((?x1051 ((_ sign_extend 1) ?x1080)))
(let (($x704 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1051) true)))))
(let (($x942 (or false $x704 (or $x1188))))
(let (($x568 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1844)) ((_ sign_extend 1) ?x225)) true)))
(let ((?x373 ((_ sign_extend 1) ?x1844)))
(let (($x1854 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x373) true)))))
(let (($x46 (or false $x1854 (or $x568))))
(let (($x1291 (or $x46 $x942 false)))
(and (not $x1291) (or $x1291 (and (distinct ?x1834 ?x1834) true))))))))))))))))))
(check-sat)
; query 36: function gsm_L_add, block 8, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1080 (bvadd in1_64 (_ bv1 64))))
(let ((?x744 (bvsub (_ bv0 64) ?x1080)))
(let ((?x1844 (bvadd in0_64 (_ bv1 64))))
(let ((?x225 (bvsub (_ bv0 64) ?x1844)))
(let ((?x1834 (bvadd ?x225 ?x744)))
(let ((?x214 (ite (bvuge ?x1834 (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x1188 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1080)) ((_ sign_extend 1) ?x744)) true)))
(let ((?x1051 ((_ sign_extend 1) ?x1080)))
(let (($x704 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1051) true)))))
(let (($x942 (or false $x704 (or $x1188))))
(let (($x568 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1844)) ((_ sign_extend 1) ?x225)) true)))
(let ((?x373 ((_ sign_extend 1) ?x1844)))
(let (($x1854 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x373) true)))))
(let (($x46 (or false $x1854 (or $x568))))
(let (($x1291 (or $x46 $x942 false)))
(let (($x750 (or $x1291 false false)))
(and (not $x750) (or $x750 (and (distinct ?x214 ?x214) true))))))))))))))))))))
(check-sat)
; query 37: function gsm_L_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1844 (bvadd in0_64 (_ bv1 64))))
(let ((?x373 ((_ sign_extend 1) ?x1844)))
(let (($x1854 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x373) true)))))
(and (not $x1854) (or $x1854 (and (distinct ?x1844 ?x1844) true)))))))
(check-sat)
; query 38: function gsm_L_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x80 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x2402 (or false false false)))
(let (($x470 (not $x2402)))
(and $x470 (or $x2402 (and (distinct ?x80 ?x80) true)))))))
(check-sat)
; query 39: function gsm_L_asl, block 12, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1090 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x2402 (or false false false)))
(let (($x470 (not $x2402)))
(and $x470 (or $x2402 (and (distinct ?x1090 ?x1090) true)))))))
(check-sat)
; query 40: function gsm_L_asl, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x116 (or false false)))
(let (($x256 (not $x116)))
(and $x256 (or $x116 (and (distinct ((_ zero_extend 32) in1_32) ((_ zero_extend 32) in1_32)) true))))))
(check-sat)
; query 41: function gsm_L_asl, block 17, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x702 ((_ zero_extend 32) in1_32)))
(let ((?x302 (bvshl in0_64 ?x702)))
(let (($x116 (or false false)))
(let (($x51 (or false $x116 false)))
(let (($x575 (or $x51 (bvuge ?x702 (_ bv64 64)))))
(let (($x981 (not $x575)))
(and $x981 (or $x575 (and (distinct ?x302 ?x302) true))))))))))
(check-sat)
; query 42: function gsm_L_asl, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x363 (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x2402 (or false false false)))
(let (($x470 (not $x2402)))
(and $x470 (or $x2402 (and (distinct ?x363 ?x363) true)))))))
(check-sat)
; query 43: function gsm_L_asl, block 7, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x80 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x226 ((_ zero_extend 31) ?x80)))
(let ((?x152 (bvsub (_ bv0 32) ?x226)))
(let (($x1601 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x226)) ((_ sign_extend 1) ?x152)) true)))
(let (($x2402 (or false false false)))
(let (($x217 (or $x2402 false)))
(let (($x1142 (or false $x217 (or $x1601))))
(and (not $x1142) (or $x1142 (and (distinct ?x152 ?x152) true)))))))))))
(check-sat)
; query 44: function gsm_L_asl, block 7, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x80 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x226 ((_ zero_extend 31) ?x80)))
(let ((?x152 (bvsub (_ bv0 32) ?x226)))
(let ((?x1335 ((_ sign_extend 32) ?x152)))
(let (($x1601 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x226)) ((_ sign_extend 1) ?x152)) true)))
(let (($x2402 (or false false false)))
(let (($x217 (or $x2402 false)))
(let (($x1142 (or false $x217 (or $x1601))))
(let (($x1240 (or $x1142 false)))
(and (not $x1240) (or $x1240 (and (distinct ?x1335 ?x1335) true)))))))))))))
(check-sat)
; query 45: function gsm_L_asl, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x80 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x2402 (or false false false)))
(let (($x470 (not $x2402)))
(and $x470 (or $x2402 (and (distinct ?x80 ?x80) true)))))))
(check-sat)
; query 46: function gsm_L_asl, block 7, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x80 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x226 ((_ zero_extend 31) ?x80)))
(let (($x2402 (or false false false)))
(let (($x217 (or $x2402 false)))
(let (($x366 (not $x217)))
(and $x366 (or $x217 (and (distinct ?x226 ?x226) true)))))))))
(check-sat)
; query 47: function gsm_L_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1418 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x2402 (or false false false)))
(let (($x470 (not $x2402)))
(and $x470 (or $x2402 (and (distinct ?x1418 ?x1418) true)))))))
(check-sat)
; query 48: function gsm_L_asr, block 12, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1090 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x2402 (or false false false)))
(let (($x470 (not $x2402)))
(and $x470 (or $x2402 (and (distinct ?x1090 ?x1090) true)))))))
(check-sat)
; query 49: function gsm_L_asr, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x332 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in1_32))) true)))
(let (($x547 (or false false (or $x332))))
(and (not $x547) (or $x547 (and (distinct (bvsub (_ bv0 32) in1_32) (bvsub (_ bv0 32) in1_32)) true))))))
(check-sat)
; query 50: function gsm_L_asr, block 14, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x937 (bvsub (_ bv0 32) in1_32)))
(let ((?x210 ((_ zero_extend 32) ?x937)))
(let (($x332 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x937)) true)))
(let (($x547 (or false false (or $x332))))
(let (($x1303 (or $x547 false)))
(and (not $x1303) (or $x1303 (and (distinct ?x210 ?x210) true)))))))))
(check-sat)
; query 51: function gsm_L_asr, block 14, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x937 (bvsub (_ bv0 32) in1_32)))
(let ((?x210 ((_ zero_extend 32) ?x937)))
(let ((?x841 (bvshl in0_64 ?x210)))
(let (($x332 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x937)) true)))
(let (($x547 (or false false (or $x332))))
(let (($x1303 (or $x547 false)))
(let (($x1206 (or (or false $x1303 false) (bvuge ?x210 (_ bv64 64)))))
(and (not $x1206) (or $x1206 (and (distinct ?x841 ?x841) true)))))))))))
(check-sat)
; query 52: function gsm_L_asr, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x116 (or false false)))
(let (($x256 (not $x116)))
(and $x256 (or $x116 (and (distinct ((_ zero_extend 32) in1_32) ((_ zero_extend 32) in1_32)) true))))))
(check-sat)
; query 53: function gsm_L_asr, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x702 ((_ zero_extend 32) in1_32)))
(let ((?x1965 (bvashr in0_64 ?x702)))
(let (($x116 (or false false)))
(let (($x51 (or false $x116 false)))
(let (($x575 (or $x51 (bvuge ?x702 (_ bv64 64)))))
(let (($x981 (not $x575)))
(and $x981 (or $x575 (and (distinct ?x1965 ?x1965) true))))))))))
(check-sat)
; query 54: function gsm_L_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x80 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x2402 (or false false false)))
(let (($x470 (not $x2402)))
(and $x470 (or $x2402 (and (distinct ?x80 ?x80) true)))))))
(check-sat)
; query 55: function gsm_L_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x80 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x226 ((_ zero_extend 31) ?x80)))
(let (($x2402 (or false false false)))
(let (($x217 (or $x2402 false)))
(let (($x366 (not $x217)))
(and $x366 (or $x217 (and (distinct ?x226 ?x226) true)))))))))
(check-sat)
; query 56: function gsm_L_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x80 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x226 ((_ zero_extend 31) ?x80)))
(let ((?x152 (bvsub (_ bv0 32) ?x226)))
(let (($x1601 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x226)) ((_ sign_extend 1) ?x152)) true)))
(let (($x2402 (or false false false)))
(let (($x217 (or $x2402 false)))
(let (($x1142 (or false $x217 (or $x1601))))
(and (not $x1142) (or $x1142 (and (distinct ?x152 ?x152) true)))))))))))
(check-sat)
; query 57: function gsm_L_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x80 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x226 ((_ zero_extend 31) ?x80)))
(let ((?x152 (bvsub (_ bv0 32) ?x226)))
(let ((?x1335 ((_ sign_extend 32) ?x152)))
(let (($x1601 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x226)) ((_ sign_extend 1) ?x152)) true)))
(let (($x2402 (or false false false)))
(let (($x217 (or $x2402 false)))
(let (($x1142 (or false $x217 (or $x1601))))
(let (($x1240 (or $x1142 false)))
(and (not $x1240) (or $x1240 (and (distinct ?x1335 ?x1335) true)))))))))))))
(check-sat)
; query 58: function gsm_L_asr, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x363 (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x2402 (or false false false)))
(let (($x470 (not $x2402)))
(and $x470 (or $x2402 (and (distinct ?x363 ?x363) true)))))))
(check-sat)
; query 59: function gsm_L_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1418 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x2402 (or false false false)))
(let (($x470 (not $x2402)))
(and $x470 (or $x2402 (and (distinct ?x1418 ?x1418) true)))))))
(check-sat)
; query 60: function gsm_L_mult, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x116 (or false false)))
(let (($x256 (not $x116)))
(and $x256 (or $x116 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 61: function gsm_L_mult, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1883 (ite (and (distinct (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) true) (_ bv1 1) (_ bv0 1))))
(let (($x116 (or false false)))
(let (($x220 (or $x116 false false)))
(let (($x1156 (not $x220)))
(and $x1156 (or $x220 (and (distinct ?x1883 ?x1883) true))))))))
(check-sat)
; query 62: function gsm_L_mult, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x116 (or false false)))
(let (($x256 (not $x116)))
(and $x256 (or $x116 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 63: function gsm_L_mult, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x587 (ite (and (distinct (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) true) (_ bv1 1) (_ bv0 1))))
(let (($x116 (or false false)))
(let (($x220 (or $x116 false false)))
(let (($x1156 (not $x220)))
(and $x1156 (or $x220 (and (distinct ?x587 ?x587) true))))))))
(check-sat)
; query 64: function gsm_L_sub, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in11_64 () (_ BitVec 64))
(assert
 (let (($x2402 (or false false false)))
(let (($x470 (not $x2402)))
(and $x470 (or $x2402 (and (distinct (bvadd in11_64 (_ bv1 64)) (bvadd in11_64 (_ bv1 64))) true))))))
(check-sat)
; query 65: function gsm_L_sub, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x554 (ite (bvsge (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x2402 (or false false false)))
(let (($x470 (not $x2402)))
(and $x470 (or $x2402 (and (distinct ?x554 ?x554) true)))))))
(check-sat)
; query 66: function gsm_L_sub, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x903 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvsub in0_64 in1_64))) true)))
(let (($x836 (or false false (or $x903))))
(let (($x1838 (or $x836 (and (distinct (bvsub in0_64 in1_64) (bvsub in0_64 in1_64)) true))))
(and (not $x836) $x1838)))))
(check-sat)
; query 67: function gsm_L_sub, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1844 (bvadd in0_64 (_ bv1 64))))
(let ((?x373 ((_ sign_extend 1) ?x1844)))
(let (($x1854 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x373) true)))))
(and (not $x1854) (or $x1854 (and (distinct ?x1844 ?x1844) true)))))))
(check-sat)
; query 68: function gsm_L_sub, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1844 (bvadd in0_64 (_ bv1 64))))
(let ((?x225 (bvsub (_ bv0 64) ?x1844)))
(let (($x568 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1844)) ((_ sign_extend 1) ?x225)) true)))
(let ((?x373 ((_ sign_extend 1) ?x1844)))
(let (($x1854 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x373) true)))))
(let (($x46 (or false $x1854 (or $x568))))
(and (not $x46) (or $x46 (and (distinct ?x225 ?x225) true))))))))))
(check-sat)
; query 69: function gsm_L_sub, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1844 (bvadd in0_64 (_ bv1 64))))
(let ((?x225 (bvsub (_ bv0 64) ?x1844)))
(let ((?x1836 (bvadd ?x225 in1_64)))
(let (($x568 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1844)) ((_ sign_extend 1) ?x225)) true)))
(let ((?x373 ((_ sign_extend 1) ?x1844)))
(let (($x1854 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x373) true)))))
(let (($x46 (or false $x1854 (or $x568))))
(let (($x1518 (or $x46 false false)))
(and (not $x1518) (or $x1518 (and (distinct ?x1836 ?x1836) true))))))))))))
(check-sat)
; query 70: function gsm_L_sub, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1405 (ite (bvuge (bvadd (bvsub (_ bv0 64) (bvadd in0_64 (_ bv1 64))) in1_64) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x568 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) (bvadd in0_64 (_ bv1 64)))) ((_ sign_extend 1) (bvsub (_ bv0 64) (bvadd in0_64 (_ bv1 64))))) true)))
(let ((?x1844 (bvadd in0_64 (_ bv1 64))))
(let ((?x373 ((_ sign_extend 1) ?x1844)))
(let (($x1854 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x373) true)))))
(let (($x46 (or false $x1854 (or $x568))))
(let (($x1518 (or $x46 false false)))
(let (($x1247 (or $x1518 false false)))
(and (not $x1247) (or $x1247 (and (distinct ?x1405 ?x1405) true))))))))))))
(check-sat)
; query 71: function gsm_L_sub, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_64 () (_ BitVec 64))
(assert
 (let ((?x1548 (bvsub (_ bv0 64) in25_64)))
(let ((?x826 ((_ sign_extend 1) ?x1548)))
(let (($x888 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in25_64)) ?x826) true)))))
(and (not $x888) (or $x888 (and (distinct ?x1548 ?x1548) true)))))))
(check-sat)
; query 72: function gsm_L_sub, block 28, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_64 () (_ BitVec 64))
(assert
 (let ((?x1548 (bvsub (_ bv0 64) in25_64)))
(let ((?x688 (bvsub ?x1548 (_ bv1 64))))
(let (($x330 (and (distinct (bvsub ((_ sign_extend 1) ?x1548) ((_ sign_extend 1) (_ bv1 64))) ((_ sign_extend 1) ?x688)) true)))
(let ((?x826 ((_ sign_extend 1) ?x1548)))
(let (($x888 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in25_64)) ?x826) true)))))
(let (($x65 (or $x888 false (or $x330))))
(and (not $x65) (or $x65 (and (distinct ?x688 ?x688) true))))))))))
(check-sat)
; query 73: function gsm_L_sub, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1384 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x2402 (or false false false)))
(let (($x470 (not $x2402)))
(and $x470 (or $x2402 (and (distinct ?x1384 ?x1384) true)))))))
(check-sat)
; query 74: function gsm_L_sub, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x903 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvsub in0_64 in1_64))) true)))
(let (($x836 (or false false (or $x903))))
(let (($x1838 (or $x836 (and (distinct (bvsub in0_64 in1_64) (bvsub in0_64 in1_64)) true))))
(and (not $x836) $x1838)))))
(check-sat)
; query 75: function gsm_L_sub, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1080 (bvadd in1_64 (_ bv1 64))))
(let ((?x744 (bvsub (_ bv0 64) ?x1080)))
(let (($x1188 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1080)) ((_ sign_extend 1) ?x744)) true)))
(let ((?x1051 ((_ sign_extend 1) ?x1080)))
(let (($x704 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1051) true)))))
(let (($x942 (or false $x704 (or $x1188))))
(and (not $x942) (or $x942 (and (distinct ?x744 ?x744) true))))))))))
(check-sat)
; query 76: function gsm_L_sub, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1080 (bvadd in1_64 (_ bv1 64))))
(let ((?x744 (bvsub (_ bv0 64) ?x1080)))
(let ((?x614 (bvadd in0_64 ?x744)))
(let (($x1188 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1080)) ((_ sign_extend 1) ?x744)) true)))
(let ((?x1051 ((_ sign_extend 1) ?x1080)))
(let (($x704 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1051) true)))))
(let (($x942 (or false $x704 (or $x1188))))
(let (($x481 (or false $x942 false)))
(and (not $x481) (or $x481 (and (distinct ?x614 ?x614) true))))))))))))
(check-sat)
; query 77: function gsm_L_sub, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x890 (ite (bvuge (bvadd in0_64 (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64)))) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x1188 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) (bvadd in1_64 (_ bv1 64)))) ((_ sign_extend 1) (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64))))) true)))
(let ((?x1080 (bvadd in1_64 (_ bv1 64))))
(let ((?x1051 ((_ sign_extend 1) ?x1080)))
(let (($x704 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1051) true)))))
(let (($x942 (or false $x704 (or $x1188))))
(let (($x481 (or false $x942 false)))
(let (($x764 (or $x481 false false)))
(and (not $x764) (or $x764 (and (distinct ?x890 ?x890) true))))))))))))
(check-sat)
; query 78: function gsm_L_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1080 (bvadd in1_64 (_ bv1 64))))
(let ((?x1051 ((_ sign_extend 1) ?x1080)))
(let (($x704 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1051) true)))))
(and (not $x704) (or $x704 (and (distinct ?x1080 ?x1080) true)))))))
(check-sat)
; query 79: function gsm_L_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x664 (ite (bvsle (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x2402 (or false false false)))
(let (($x470 (not $x2402)))
(and $x470 (or $x2402 (and (distinct ?x664 ?x664) true)))))))
(check-sat)
; query 80: function gsm_abs, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x116 (or false false)))
(let (($x256 (not $x116)))
(and $x256 (or $x116 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 81: function gsm_abs, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1237 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x116 (or false false)))
(let (($x220 (or $x116 false false)))
(let (($x1156 (not $x220)))
(and $x1156 (or $x220 (and (distinct ?x1237 ?x1237) true))))))))
(check-sat)
; query 82: function gsm_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_64 () (_ BitVec 64))
(assert
 (let ((?x1928 (ite (bvslt (_ bv32767 64) in5_64) (_ bv1 1) (_ bv0 1))))
(let (($x2402 (or false false false)))
(let (($x470 (not $x2402)))
(and $x470 (or $x2402 (and (distinct ?x1928 ?x1928) true)))))))
(check-sat)
; query 83: function gsm_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x116 (or false false)))
(let (($x256 (not $x116)))
(and $x256 (or $x116 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 84: function gsm_add, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x116 (or false false)))
(let (($x256 (not $x116)))
(and $x256 (or $x116 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 85: function gsm_add, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x343 ((_ sign_extend 48) in1_16)))
(let ((?x760 ((_ sign_extend 48) in0_16)))
(let ((?x1936 (bvadd ?x760 ?x343)))
(let (($x1383 (and (distinct (bvadd ((_ sign_extend 1) ?x760) ((_ sign_extend 1) ?x343)) ((_ sign_extend 1) ?x1936)) true)))
(let (($x116 (or false false)))
(let (($x254 (or $x116 $x116 (or $x1383))))
(and (not $x254) (or $x254 (and (distinct ?x1936 ?x1936) true))))))))))
(check-sat)
; query 86: function gsm_add, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x73 (ite (bvsgt (_ bv18446744073709518848 64) (bvadd ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x343 ((_ sign_extend 48) in1_16)))
(let ((?x17 ((_ sign_extend 1) ?x343)))
(let ((?x760 ((_ sign_extend 48) in0_16)))
(let ((?x997 ((_ sign_extend 1) ?x760)))
(let (($x116 (or false false)))
(let (($x254 (or $x116 $x116 (or (and (distinct (bvadd ?x997 ?x17) ((_ sign_extend 1) (bvadd ?x760 ?x343))) true)))))
(let (($x1573 (or $x254 false false)))
(and (not $x1573) (or $x1573 (and (distinct ?x73 ?x73) true))))))))))))
(check-sat)
; query 87: function gsm_asl, block 13, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1090 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x2402 (or false false false)))
(let (($x470 (not $x2402)))
(and $x470 (or $x2402 (and (distinct ?x1090 ?x1090) true)))))))
(check-sat)
; query 88: function gsm_asl, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x116 (or false false)))
(let (($x256 (not $x116)))
(and $x256 (or $x116 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 89: function gsm_asl, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1104 ((_ sign_extend 16) in0_16)))
(let ((?x953 (bvshl ?x1104 in1_32)))
(let (($x116 (or false false)))
(let (($x220 (or $x116 false false)))
(let (($x173 (or $x220 (bvuge in1_32 (_ bv32 32)))))
(let (($x1408 (not $x173)))
(and $x1408 (or $x173 (and (distinct ?x953 ?x953) true))))))))))
(check-sat)
; query 90: function gsm_asl, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1104 ((_ sign_extend 16) in0_16)))
(let ((?x953 (bvshl ?x1104 in1_32)))
(let ((?x988 ((_ extract 15 0) ?x953)))
(let (($x116 (or false false)))
(let (($x220 (or $x116 false false)))
(let (($x173 (or $x220 (bvuge in1_32 (_ bv32 32)))))
(let (($x1552 (or $x173 false)))
(let (($x1371 (not $x1552)))
(and $x1371 (or $x1552 (and (distinct ?x988 ?x988) true))))))))))))
(check-sat)
; query 91: function gsm_asl, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1484 (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x2402 (or false false false)))
(let (($x470 (not $x2402)))
(and $x470 (or $x2402 (and (distinct ?x1484 ?x1484) true)))))))
(check-sat)
; query 92: function gsm_asl, block 7, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1237 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x853 ((_ zero_extend 31) ?x1237)))
(let (($x116 (or false false)))
(let (($x220 (or $x116 false false)))
(let (($x1031 (or $x220 false)))
(and (not $x1031) (or $x1031 (and (distinct ?x853 ?x853) true)))))))))
(check-sat)
; query 93: function gsm_asl, block 7, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1237 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x853 ((_ zero_extend 31) ?x1237)))
(let ((?x696 (bvsub (_ bv0 32) ?x853)))
(let (($x774 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x853)) ((_ sign_extend 1) ?x696)) true)))
(let (($x116 (or false false)))
(let (($x220 (or $x116 false false)))
(let (($x1031 (or $x220 false)))
(let (($x1238 (or false $x1031 (or $x774))))
(and (not $x1238) (or $x1238 (and (distinct ?x696 ?x696) true))))))))))))
(check-sat)
; query 94: function gsm_asl, block 7, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1237 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x853 ((_ zero_extend 31) ?x1237)))
(let ((?x696 (bvsub (_ bv0 32) ?x853)))
(let ((?x1349 ((_ extract 15 0) ?x696)))
(let (($x774 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x853)) ((_ sign_extend 1) ?x696)) true)))
(let (($x116 (or false false)))
(let (($x220 (or $x116 false false)))
(let (($x1031 (or $x220 false)))
(let (($x1238 (or false $x1031 (or $x774))))
(let (($x1222 (or $x1238 false)))
(and (not $x1222) (or $x1222 (and (distinct ?x1349 ?x1349) true))))))))))))))
(check-sat)
; query 95: function gsm_asl, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x116 (or false false)))
(let (($x256 (not $x116)))
(and $x256 (or $x116 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 96: function gsm_asl, block 7, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1237 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x116 (or false false)))
(let (($x220 (or $x116 false false)))
(let (($x1156 (not $x220)))
(and $x1156 (or $x220 (and (distinct ?x1237 ?x1237) true))))))))
(check-sat)
; query 97: function gsm_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1760 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x2402 (or false false false)))
(let (($x470 (not $x2402)))
(and $x470 (or $x2402 (and (distinct ?x1760 ?x1760) true)))))))
(check-sat)
; query 98: function gsm_asr, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1484 (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x2402 (or false false false)))
(let (($x470 (not $x2402)))
(and $x470 (or $x2402 (and (distinct ?x1484 ?x1484) true)))))))
(check-sat)
; query 99: function gsm_asr, block 13, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1090 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x2402 (or false false false)))
(let (($x470 (not $x2402)))
(and $x470 (or $x2402 (and (distinct ?x1090 ?x1090) true)))))))
(check-sat)
; query 100: function gsm_asr, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x116 (or false false)))
(let (($x256 (not $x116)))
(and $x256 (or $x116 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 101: function gsm_asr, block 15, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x332 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in1_32))) true)))
(let (($x547 (or false false (or $x332))))
(and (not $x547) (or $x547 (and (distinct (bvsub (_ bv0 32) in1_32) (bvsub (_ bv0 32) in1_32)) true))))))
(check-sat)
; query 102: function gsm_asr, block 15, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x937 (bvsub (_ bv0 32) in1_32)))
(let ((?x1104 ((_ sign_extend 16) in0_16)))
(let ((?x1843 (bvshl ?x1104 ?x937)))
(let (($x332 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x937)) true)))
(let (($x547 (or false false (or $x332))))
(let (($x116 (or false false)))
(let (($x387 (or (or $x116 $x547 false) (bvuge ?x937 (_ bv32 32)))))
(and (not $x387) (or $x387 (and (distinct ?x1843 ?x1843) true)))))))))))
(check-sat)
; query 103: function gsm_asr, block 15, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x937 (bvsub (_ bv0 32) in1_32)))
(let ((?x1104 ((_ sign_extend 16) in0_16)))
(let ((?x1843 (bvshl ?x1104 ?x937)))
(let ((?x1087 ((_ extract 15 0) ?x1843)))
(let (($x332 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x937)) true)))
(let (($x547 (or false false (or $x332))))
(let (($x116 (or false false)))
(let (($x387 (or (or $x116 $x547 false) (bvuge ?x937 (_ bv32 32)))))
(let (($x1017 (or $x387 false)))
(and (not $x1017) (or $x1017 (and (distinct ?x1087 ?x1087) true)))))))))))))
(check-sat)
; query 104: function gsm_asr, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x116 (or false false)))
(let (($x256 (not $x116)))
(and $x256 (or $x116 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 105: function gsm_asr, block 20, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1104 ((_ sign_extend 16) in0_16)))
(let ((?x668 (bvashr ?x1104 in1_32)))
(let (($x116 (or false false)))
(let (($x220 (or $x116 false false)))
(let (($x173 (or $x220 (bvuge in1_32 (_ bv32 32)))))
(let (($x1408 (not $x173)))
(and $x1408 (or $x173 (and (distinct ?x668 ?x668) true))))))))))
(check-sat)
; query 106: function gsm_asr, block 20, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1104 ((_ sign_extend 16) in0_16)))
(let ((?x668 (bvashr ?x1104 in1_32)))
(let ((?x1863 ((_ extract 15 0) ?x668)))
(let (($x116 (or false false)))
(let (($x220 (or $x116 false false)))
(let (($x173 (or $x220 (bvuge in1_32 (_ bv32 32)))))
(let (($x1552 (or $x173 false)))
(let (($x1371 (not $x1552)))
(and $x1371 (or $x1552 (and (distinct ?x1863 ?x1863) true))))))))))))
(check-sat)
; query 107: function gsm_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x116 (or false false)))
(let (($x256 (not $x116)))
(and $x256 (or $x116 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 108: function gsm_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1237 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x116 (or false false)))
(let (($x220 (or $x116 false false)))
(let (($x1156 (not $x220)))
(and $x1156 (or $x220 (and (distinct ?x1237 ?x1237) true))))))))
(check-sat)
; query 109: function gsm_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1237 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x853 ((_ zero_extend 31) ?x1237)))
(let (($x116 (or false false)))
(let (($x220 (or $x116 false false)))
(let (($x1031 (or $x220 false)))
(and (not $x1031) (or $x1031 (and (distinct ?x853 ?x853) true)))))))))
(check-sat)
; query 110: function gsm_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1237 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x853 ((_ zero_extend 31) ?x1237)))
(let ((?x696 (bvsub (_ bv0 32) ?x853)))
(let (($x774 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x853)) ((_ sign_extend 1) ?x696)) true)))
(let (($x116 (or false false)))
(let (($x220 (or $x116 false false)))
(let (($x1031 (or $x220 false)))
(let (($x1238 (or false $x1031 (or $x774))))
(and (not $x1238) (or $x1238 (and (distinct ?x696 ?x696) true))))))))))))
(check-sat)
; query 111: function gsm_asr, block 4, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1237 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x853 ((_ zero_extend 31) ?x1237)))
(let ((?x696 (bvsub (_ bv0 32) ?x853)))
(let ((?x1349 ((_ extract 15 0) ?x696)))
(let (($x774 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x853)) ((_ sign_extend 1) ?x696)) true)))
(let (($x116 (or false false)))
(let (($x220 (or $x116 false false)))
(let (($x1031 (or $x220 false)))
(let (($x1238 (or false $x1031 (or $x774))))
(let (($x1222 (or $x1238 false)))
(and (not $x1222) (or $x1222 (and (distinct ?x1349 ?x1349) true))))))))))))))
(check-sat)
; query 112: function gsm_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1760 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x2402 (or false false false)))
(let (($x470 (not $x2402)))
(and $x470 (or $x2402 (and (distinct ?x1760 ?x1760) true)))))))
(check-sat)
; query 113: function gsm_debug_longwords, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in15_32 () (_ BitVec 32))
(assert
 (let ((?x1968 (ite (bvslt in15_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x2402 (or false false false)))
(let (($x470 (not $x2402)))
(and $x470 (or $x2402 (and (distinct ?x1968 ?x1968) true)))))))
(check-sat)
; query 114: function gsm_debug_words, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in16_32 () (_ BitVec 32))
(assert
 (let ((?x1963 (ite (bvslt in16_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x2402 (or false false false)))
(let (($x470 (not $x2402)))
(and $x470 (or $x2402 (and (distinct ?x1963 ?x1963) true)))))))
(check-sat)
; query 115: function gsm_div, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x116 (or false false)))
(let (($x256 (not $x116)))
(and $x256 (or $x116 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 116: function gsm_div, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x116 (or false false)))
(let (($x256 (not $x116)))
(and $x256 (or $x116 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 117: function gsm_div, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x116 (or false false)))
(let (($x256 (not $x116)))
(and $x256 (or $x116 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 118: function gsm_div, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x39 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x163 (and (distinct ?x39 ?x39) true)))
(let (($x116 (or false false)))
(let (($x220 (or $x116 false false)))
(let (($x1156 (not $x220)))
(and $x1156 (or $x220 $x163))))))))
(check-sat)
; query 119: function gsm_mult, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x116 (or false false)))
(let (($x256 (not $x116)))
(and $x256 (or $x116 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 120: function gsm_mult, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1977 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x116 (or false false)))
(let (($x220 (or $x116 false false)))
(let (($x1156 (not $x220)))
(and $x1156 (or $x220 (and (distinct ?x1977 ?x1977) true))))))))
(check-sat)
; query 121: function gsm_mult, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x116 (or false false)))
(let (($x256 (not $x116)))
(and $x256 (or $x116 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 122: function gsm_mult, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x116 (or false false)))
(let (($x256 (not $x116)))
(and $x256 (or $x116 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 123: function gsm_mult, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x343 ((_ sign_extend 48) in1_16)))
(let ((?x760 ((_ sign_extend 48) in0_16)))
(let ((?x1981 (bvmul ?x760 ?x343)))
(let (($x1987 (and (distinct (bvmul ((_ sign_extend 64) ?x760) ((_ sign_extend 64) ?x343)) ((_ sign_extend 64) ?x1981)) true)))
(let (($x116 (or false false)))
(let (($x1982 (or $x116 $x116 (or $x1987))))
(and (not $x1982) (or $x1982 (and (distinct ?x1981 ?x1981) true))))))))))
(check-sat)
; query 124: function gsm_mult, block 9, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x343 ((_ sign_extend 48) in1_16)))
(let ((?x760 ((_ sign_extend 48) in0_16)))
(let ((?x1981 (bvmul ?x760 ?x343)))
(let ((?x1997 (bvashr ?x1981 (_ bv15 64))))
(let (($x1998 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1987 (and (distinct (bvmul ((_ sign_extend 64) ?x760) ((_ sign_extend 64) ?x343)) ((_ sign_extend 64) ?x1981)) true)))
(let (($x116 (or false false)))
(let (($x1982 (or $x116 $x116 (or $x1987))))
(let (($x1999 (or (or $x1982 false false) $x1998)))
(and (not $x1999) (or $x1999 (and (distinct ?x1997 ?x1997) true)))))))))))))
(check-sat)
; query 125: function gsm_mult, block 9, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x343 ((_ sign_extend 48) in1_16)))
(let ((?x760 ((_ sign_extend 48) in0_16)))
(let ((?x1981 (bvmul ?x760 ?x343)))
(let ((?x1997 (bvashr ?x1981 (_ bv15 64))))
(let ((?x1992 ((_ extract 15 0) ?x1997)))
(let (($x1998 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1987 (and (distinct (bvmul ((_ sign_extend 64) ?x760) ((_ sign_extend 64) ?x343)) ((_ sign_extend 64) ?x1981)) true)))
(let (($x116 (or false false)))
(let (($x1982 (or $x116 $x116 (or $x1987))))
(let (($x1999 (or (or $x1982 false false) $x1998)))
(let (($x1993 (or $x1999 false)))
(and (not $x1993) (or $x1993 (and (distinct ?x1992 ?x1992) true)))))))))))))))
(check-sat)
; query 126: function gsm_mult, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x116 (or false false)))
(let (($x256 (not $x116)))
(and $x256 (or $x116 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 127: function gsm_mult, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x2017 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x116 (or false false)))
(let (($x220 (or $x116 false false)))
(let (($x1156 (not $x220)))
(and $x1156 (or $x220 (and (distinct ?x2017 ?x2017) true))))))))
(check-sat)
; query 128: function gsm_mult_r, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x116 (or false false)))
(let (($x256 (not $x116)))
(and $x256 (or $x116 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 129: function gsm_mult_r, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x2017 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x116 (or false false)))
(let (($x220 (or $x116 false false)))
(let (($x1156 (not $x220)))
(and $x1156 (or $x220 (and (distinct ?x2017 ?x2017) true))))))))
(check-sat)
; query 130: function gsm_mult_r, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x116 (or false false)))
(let (($x256 (not $x116)))
(and $x256 (or $x116 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 131: function gsm_mult_r, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x116 (or false false)))
(let (($x256 (not $x116)))
(and $x256 (or $x116 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 132: function gsm_mult_r, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x343 ((_ sign_extend 48) in1_16)))
(let ((?x760 ((_ sign_extend 48) in0_16)))
(let ((?x1981 (bvmul ?x760 ?x343)))
(let (($x1987 (and (distinct (bvmul ((_ sign_extend 64) ?x760) ((_ sign_extend 64) ?x343)) ((_ sign_extend 64) ?x1981)) true)))
(let (($x116 (or false false)))
(let (($x1982 (or $x116 $x116 (or $x1987))))
(and (not $x1982) (or $x1982 (and (distinct ?x1981 ?x1981) true))))))))))
(check-sat)
; query 133: function gsm_mult_r, block 9, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x343 ((_ sign_extend 48) in1_16)))
(let ((?x760 ((_ sign_extend 48) in0_16)))
(let ((?x1981 (bvmul ?x760 ?x343)))
(let ((?x2029 (bvadd ?x1981 (_ bv16384 64))))
(let (($x2010 (and (distinct (bvadd ((_ sign_extend 1) ?x1981) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x2029)) true)))
(let (($x1987 (and (distinct (bvmul ((_ sign_extend 64) ?x760) ((_ sign_extend 64) ?x343)) ((_ sign_extend 64) ?x1981)) true)))
(let (($x116 (or false false)))
(let (($x1982 (or $x116 $x116 (or $x1987))))
(let (($x2026 (or $x1982 false (or $x2010))))
(and (not $x2026) (or $x2026 (and (distinct ?x2029 ?x2029) true)))))))))))))
(check-sat)
; query 134: function gsm_mult_r, block 9, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x343 ((_ sign_extend 48) in1_16)))
(let ((?x760 ((_ sign_extend 48) in0_16)))
(let ((?x1981 (bvmul ?x760 ?x343)))
(let ((?x2029 (bvadd ?x1981 (_ bv16384 64))))
(let ((?x2023 (bvashr ?x2029 (_ bv15 64))))
(let (($x1998 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x2010 (and (distinct (bvadd ((_ sign_extend 1) ?x1981) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x2029)) true)))
(let (($x1987 (and (distinct (bvmul ((_ sign_extend 64) ?x760) ((_ sign_extend 64) ?x343)) ((_ sign_extend 64) ?x1981)) true)))
(let (($x116 (or false false)))
(let (($x1982 (or $x116 $x116 (or $x1987))))
(let (($x2026 (or $x1982 false (or $x2010))))
(let (($x2022 (or (or $x2026 false false) $x1998)))
(and (not $x2022) (or $x2022 (and (distinct ?x2023 ?x2023) true))))))))))))))))
(check-sat)
; query 135: function gsm_mult_r, block 9, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x343 ((_ sign_extend 48) in1_16)))
(let ((?x760 ((_ sign_extend 48) in0_16)))
(let ((?x1981 (bvmul ?x760 ?x343)))
(let ((?x2029 (bvadd ?x1981 (_ bv16384 64))))
(let ((?x2023 (bvashr ?x2029 (_ bv15 64))))
(let ((?x2038 (bvand ?x2023 (_ bv65535 64))))
(let (($x1998 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x2010 (and (distinct (bvadd ((_ sign_extend 1) ?x1981) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x2029)) true)))
(let (($x1987 (and (distinct (bvmul ((_ sign_extend 64) ?x760) ((_ sign_extend 64) ?x343)) ((_ sign_extend 64) ?x1981)) true)))
(let (($x116 (or false false)))
(let (($x1982 (or $x116 $x116 (or $x1987))))
(let (($x2026 (or $x1982 false (or $x2010))))
(let (($x2022 (or (or $x2026 false false) $x1998)))
(let (($x2031 (or $x2022 false false)))
(and (not $x2031) (or $x2031 (and (distinct ?x2038 ?x2038) true))))))))))))))))))
(check-sat)
; query 136: function gsm_mult_r, block 9, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x343 ((_ sign_extend 48) in1_16)))
(let ((?x760 ((_ sign_extend 48) in0_16)))
(let ((?x1981 (bvmul ?x760 ?x343)))
(let ((?x2029 (bvadd ?x1981 (_ bv16384 64))))
(let ((?x2023 (bvashr ?x2029 (_ bv15 64))))
(let ((?x2038 (bvand ?x2023 (_ bv65535 64))))
(let ((?x2039 ((_ extract 15 0) ?x2038)))
(let (($x1998 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x2010 (and (distinct (bvadd ((_ sign_extend 1) ?x1981) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x2029)) true)))
(let (($x1987 (and (distinct (bvmul ((_ sign_extend 64) ?x760) ((_ sign_extend 64) ?x343)) ((_ sign_extend 64) ?x1981)) true)))
(let (($x116 (or false false)))
(let (($x1982 (or $x116 $x116 (or $x1987))))
(let (($x2026 (or $x1982 false (or $x2010))))
(let (($x2022 (or (or $x2026 false false) $x1998)))
(let (($x2031 (or $x2022 false false)))
(let (($x1021 (or $x2031 false)))
(and (not $x1021) (or $x1021 (and (distinct ?x2039 ?x2039) true))))))))))))))))))))
(check-sat)
; query 137: function gsm_mult_r, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x116 (or false false)))
(let (($x256 (not $x116)))
(and $x256 (or $x116 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 138: function gsm_mult_r, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1977 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x116 (or false false)))
(let (($x220 (or $x116 false false)))
(let (($x1156 (not $x220)))
(and $x1156 (or $x220 (and (distinct ?x1977 ?x1977) true))))))))
(check-sat)
; query 139: function gsm_norm, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x603 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x2402 (or false false false)))
(let (($x470 (not $x2402)))
(and $x470 (or $x2402 (and (distinct ?x603 ?x603) true)))))))
(check-sat)
; query 140: function gsm_norm, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x603 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x2056 (bvxor ?x603 (_ bv1 1))))
(let (($x2402 (or false false false)))
(let (($x375 (or $x2402 false false)))
(let (($x542 (not $x375)))
(and $x542 (or $x375 (and (distinct ?x2056 ?x2056) true)))))))))
(check-sat)
; query 141: function gsm_norm, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x603 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x2056 (bvxor ?x603 (_ bv1 1))))
(let ((?x2057 ((_ zero_extend 31) ?x2056)))
(let (($x2402 (or false false false)))
(let (($x375 (or $x2402 false false)))
(let (($x2052 (or $x375 false)))
(and (not $x2052) (or $x2052 (and (distinct ?x2057 ?x2057) true))))))))))
(check-sat)
; query 142: function gsm_norm, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x603 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x2056 (bvxor ?x603 (_ bv1 1))))
(let ((?x2057 ((_ zero_extend 31) ?x2056)))
(let ((?x2053 ((_ sign_extend 32) ?x2057)))
(let (($x2402 (or false false false)))
(let (($x375 (or $x2402 false false)))
(let (($x2052 (or $x375 false)))
(let (($x2061 (or $x2052 false)))
(and (not $x2061) (or $x2061 (and (distinct ?x2053 ?x2053) true))))))))))))
(check-sat)
; query 143: function gsm_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_64 () (_ BitVec 64))
(assert
 (let ((?x1928 (ite (bvslt (_ bv32767 64) in5_64) (_ bv1 1) (_ bv0 1))))
(let (($x2402 (or false false false)))
(let (($x470 (not $x2402)))
(and $x470 (or $x2402 (and (distinct ?x1928 ?x1928) true)))))))
(check-sat)
; query 144: function gsm_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x116 (or false false)))
(let (($x256 (not $x116)))
(and $x256 (or $x116 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 145: function gsm_sub, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x116 (or false false)))
(let (($x256 (not $x116)))
(and $x256 (or $x116 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 146: function gsm_sub, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x343 ((_ sign_extend 48) in1_16)))
(let ((?x760 ((_ sign_extend 48) in0_16)))
(let ((?x2069 (bvsub ?x760 ?x343)))
(let (($x2075 (and (distinct (bvsub ((_ sign_extend 1) ?x760) ((_ sign_extend 1) ?x343)) ((_ sign_extend 1) ?x2069)) true)))
(let (($x116 (or false false)))
(let (($x2063 (or $x116 $x116 (or $x2075))))
(and (not $x2063) (or $x2063 (and (distinct ?x2069 ?x2069) true))))))))))
(check-sat)
; query 147: function gsm_sub, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x2087 (ite (bvsgt (_ bv18446744073709518848 64) (bvsub ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x343 ((_ sign_extend 48) in1_16)))
(let ((?x17 ((_ sign_extend 1) ?x343)))
(let ((?x760 ((_ sign_extend 48) in0_16)))
(let ((?x997 ((_ sign_extend 1) ?x760)))
(let (($x116 (or false false)))
(let (($x2063 (or $x116 $x116 (or (and (distinct (bvsub ?x997 ?x17) ((_ sign_extend 1) (bvsub ?x760 ?x343))) true)))))
(let (($x2086 (or $x2063 false false)))
(and (not $x2086) (or $x2086 (and (distinct ?x2087 ?x2087) true))))))))))))
(check-sat)
; query 148: function ok_to_replace, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x276 (ite (and (distinct (_ bv4294967295 32) in.01_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x2402 (or false false false)))
(let (($x470 (not $x2402)))
(and $x470 (or $x2402 (and (distinct ?x276 ?x276) true)))))))
(check-sat)
; query 149: function suffix, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_64 () (_ BitVec 64))
(declare-fun in3_64 () (_ BitVec 64))
(assert
 (let ((?x737 (ite (bvule in3_64 in4_64) (_ bv1 1) (_ bv0 1))))
(let (($x2402 (or false false false)))
(let (($x470 (not $x2402)))
(and $x470 (or $x2402 (and (distinct ?x737 ?x737) true)))))))
(check-sat)
