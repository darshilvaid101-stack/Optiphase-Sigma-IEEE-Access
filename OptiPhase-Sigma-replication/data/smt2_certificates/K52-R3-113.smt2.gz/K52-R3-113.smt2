; OptiPhase-Sigma refinement certificate for sweep K52-R3-113
; query 0: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x19 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x132 (or false false false)))
(let (($x138 (not $x132)))
(and $x138 (or $x132 (and (distinct ?x19 ?x19) true)))))))
(check-sat)
; query 1: function s162, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x87 (ite (bvslt (_ bv0 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x132 (or false false false)))
(let (($x138 (not $x132)))
(and $x138 (or $x132 (and (distinct ?x87 ?x87) true)))))))
(check-sat)
