; OptiPhase-Sigma refinement certificate for sweep K34-R1-005
