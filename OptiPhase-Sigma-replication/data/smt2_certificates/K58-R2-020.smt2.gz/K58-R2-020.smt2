; OptiPhase-Sigma refinement certificate for sweep K58-R2-020
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x311 (or false false)))
(let (($x56 (not $x311)))
(and $x56 (or $x311 (and (distinct ((_ sign_extend 16) in25_16) ((_ sign_extend 16) in25_16)) true))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let ((?x525 (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))))
(let (($x311 (or false false)))
(let (($x148 (or $x311 false false)))
(let (($x287 (not $x148)))
(and $x287 (or $x148 (and (distinct ?x525 ?x525) true))))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x311 (or false false)))
(let (($x56 (not $x311)))
(and $x56 (or $x311 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x128 ((_ sign_extend 16) in3_16)))
(let ((?x131 (bvand ?x128 (_ bv127 32))))
(let (($x311 (or false false)))
(let (($x148 (or $x311 false false)))
(let (($x287 (not $x148)))
(and $x287 (or $x148 (and (distinct ?x131 ?x131) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x128 ((_ sign_extend 16) in3_16)))
(let ((?x131 (bvand ?x128 (_ bv127 32))))
(let ((?x161 ((_ extract 15 0) ?x131)))
(let (($x311 (or false false)))
(let (($x148 (or $x311 false false)))
(let (($x1296 (or $x148 false)))
(let (($x290 (not $x1296)))
(and $x290 (or $x1296 (and (distinct ?x161 ?x161) true)))))))))))
(check-sat)
; query 5: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x311 (or false false)))
(let (($x56 (not $x311)))
(and $x56 (or $x311 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 6: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x276 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x311 (or false false)))
(let (($x148 (or $x311 false false)))
(let (($x287 (not $x148)))
(and $x287 (or $x148 (and (distinct ?x276 ?x276) true))))))))
(check-sat)
; query 7: function core_bench_list, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x500 (or false false false)))
(let (($x513 (not $x500)))
(and $x513 (or $x500 (and (distinct (bvadd in.0_16 (_ bv1 16)) (bvadd in.0_16 (_ bv1 16))) true))))))
(check-sat)
; query 8: function core_bench_state, block 105, name %106
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x500 (or false false false)))
(let (($x513 (not $x500)))
(and $x513 (or $x500 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 9: function core_bench_state, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x500 (or false false false)))
(let (($x513 (not $x500)))
(and $x513 (or $x500 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 10: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x141 (bvadd in.01_32 (_ bv1 32))))
(let (($x856 (and (distinct ?x141 ?x141) true)))
(let (($x500 (or false false false)))
(let (($x513 (not $x500)))
(and $x513 (or $x500 $x856)))))))
(check-sat)
; query 11: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x141 (bvadd in.01_32 (_ bv1 32))))
(let ((?x241 (bvmul ?x141 ?x141)))
(let (($x500 (or false false false)))
(let (($x107 (or $x500 $x500 false)))
(and (not $x107) (or $x107 (and (distinct ?x241 ?x241) true))))))))
(check-sat)
; query 12: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x141 (bvadd in.01_32 (_ bv1 32))))
(let ((?x241 (bvmul ?x141 ?x141)))
(let ((?x61 (bvmul ?x241 (_ bv2 32))))
(let (($x500 (or false false false)))
(let (($x107 (or $x500 $x500 false)))
(let (($x625 (or $x107 false false)))
(and (not $x625) (or $x625 (and (distinct ?x61 ?x61) true))))))))))
(check-sat)
; query 13: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x141 (bvadd in.01_32 (_ bv1 32))))
(let ((?x241 (bvmul ?x141 ?x141)))
(let ((?x61 (bvmul ?x241 (_ bv2 32))))
(let ((?x233 (bvmul ?x61 (_ bv4 32))))
(let (($x500 (or false false false)))
(let (($x107 (or $x500 $x500 false)))
(let (($x625 (or $x107 false false)))
(let (($x49 (or $x625 false false)))
(and (not $x49) (or $x49 (and (distinct ?x233 ?x233) true))))))))))))
(check-sat)
; query 14: function core_init_matrix, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x500 (or false false false)))
(let (($x513 (not $x500)))
(and $x513 (or $x500 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 15: function core_init_matrix, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x500 (or false false false)))
(let (($x513 (not $x500)))
(and $x513 (or $x500 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 16: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x121 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x500 (or false false false)))
(let (($x513 (not $x500)))
(and $x513 (or $x500 (and (distinct ?x121 ?x121) true)))))))
(check-sat)
; query 17: function core_init_state, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_32 () (_ BitVec 32))
(assert
 (let (($x500 (or false false false)))
(let (($x513 (not $x500)))
(and $x513 (or $x500 (and (distinct (bvadd in.06_32 (_ bv1 32)) (bvadd in.06_32 (_ bv1 32))) true))))))
(check-sat)
; query 18: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x8 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x500 (or false false false)))
(let (($x513 (not $x500)))
(and $x513 (or $x500 (and (distinct ?x8 ?x8) true)))))))
(check-sat)
; query 19: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x500 (or false false false)))
(let (($x513 (not $x500)))
(and $x513 (or $x500 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 20: function core_list_init, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x141 (bvadd in.01_32 (_ bv1 32))))
(let (($x856 (and (distinct ?x141 ?x141) true)))
(let (($x500 (or false false false)))
(let (($x513 (not $x500)))
(and $x513 (or $x500 $x856)))))))
(check-sat)
; query 21: function core_list_mergesort, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x141 (bvadd in.01_32 (_ bv1 32))))
(let (($x856 (and (distinct ?x141 ?x141) true)))
(let (($x35 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x141)) true)))
(let (($x64 (or false false (or $x35))))
(and (not $x64) (or $x64 $x856)))))))
(check-sat)
; query 22: function core_list_mergesort, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x162 (ite (bvslt (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x500 (or false false false)))
(let (($x513 (not $x500)))
(and $x513 (or $x500 (and (distinct ?x162 ?x162) true)))))))
(check-sat)
; query 23: function core_list_mergesort, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.224_32 () (_ BitVec 32))
(assert
 (let ((?x846 (ite (= (_ bv0 32) in.224_32) (_ bv1 1) (_ bv0 1))))
(let (($x500 (or false false false)))
(let (($x513 (not $x500)))
(and $x513 (or $x500 (and (distinct ?x846 ?x846) true)))))))
(check-sat)
; query 24: function core_list_mergesort, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x734 (ite (= (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x500 (or false false false)))
(let (($x513 (not $x500)))
(and $x513 (or $x500 (and (distinct ?x734 ?x734) true)))))))
(check-sat)
; query 25: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x11 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x226 (or false false (or $x11))))
(and (not $x226) (or $x226 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 26: function core_list_mergesort, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x97 (and (distinct (bvmul ((_ sign_extend 32) in.020_32) ((_ sign_extend 32) (_ bv2 32))) ((_ sign_extend 32) (bvmul in.020_32 (_ bv2 32)))) true)))
(let (($x650 (or false false (or $x97))))
(and (not $x650) (or $x650 (and (distinct (bvmul in.020_32 (_ bv2 32)) (bvmul in.020_32 (_ bv2 32))) true))))))
(check-sat)
; query 27: function core_state_transition, block 102, name %103
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x311 (or false false)))
(let (($x56 (not $x311)))
(and $x56 (or $x311 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 28: function core_state_transition, block 102, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1084 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x311 (or false false)))
(let (($x148 (or $x311 false false)))
(let (($x287 (not $x148)))
(and $x287 (or $x148 (and (distinct ?x1084 ?x1084) true))))))))
(check-sat)
; query 29: function core_state_transition, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x311 (or false false)))
(let (($x56 (not $x311)))
(and $x56 (or $x311 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 30: function core_state_transition, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x789 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x311 (or false false)))
(let (($x148 (or $x311 false false)))
(let (($x287 (not $x148)))
(and $x287 (or $x148 (and (distinct ?x789 ?x789) true))))))))
(check-sat)
; query 31: function core_state_transition, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x311 (or false false)))
(let (($x56 (not $x311)))
(and $x56 (or $x311 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 32: function core_state_transition, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1084 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x311 (or false false)))
(let (($x148 (or $x311 false false)))
(let (($x287 (not $x148)))
(and $x287 (or $x148 (and (distinct ?x1084 ?x1084) true))))))))
(check-sat)
; query 33: function core_state_transition, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x311 (or false false)))
(let (($x56 (not $x311)))
(and $x56 (or $x311 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 34: function core_state_transition, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x78 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x311 (or false false)))
(let (($x148 (or $x311 false false)))
(let (($x287 (not $x148)))
(and $x287 (or $x148 (and (distinct ?x78 ?x78) true))))))))
(check-sat)
; query 35: function core_state_transition, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x311 (or false false)))
(let (($x56 (not $x311)))
(and $x56 (or $x311 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 36: function core_state_transition, block 51, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x78 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x311 (or false false)))
(let (($x148 (or $x311 false false)))
(let (($x287 (not $x148)))
(and $x287 (or $x148 (and (distinct ?x78 ?x78) true))))))))
(check-sat)
; query 37: function core_state_transition, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x311 (or false false)))
(let (($x56 (not $x311)))
(and $x56 (or $x311 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 38: function core_state_transition, block 64, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x78 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x311 (or false false)))
(let (($x148 (or $x311 false false)))
(let (($x287 (not $x148)))
(and $x287 (or $x148 (and (distinct ?x78 ?x78) true))))))))
(check-sat)
; query 39: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x79 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x500 (or false false false)))
(let (($x513 (not $x500)))
(and $x513 (or $x500 (and (distinct ?x79 ?x79) true)))))))
(check-sat)
; query 40: function core_state_transition, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x311 (or false false)))
(let (($x56 (not $x311)))
(and $x56 (or $x311 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 41: function core_state_transition, block 80, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x34 (ite (= (_ bv69 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x311 (or false false)))
(let (($x148 (or $x311 false false)))
(let (($x287 (not $x148)))
(and $x287 (or $x148 (and (distinct ?x34 ?x34) true))))))))
(check-sat)
; query 42: function core_state_transition, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x311 (or false false)))
(let (($x56 (not $x311)))
(and $x56 (or $x311 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 43: function core_state_transition, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x169 (ite (= (_ bv101 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x311 (or false false)))
(let (($x148 (or $x311 false false)))
(let (($x287 (not $x148)))
(and $x287 (or $x148 (and (distinct ?x169 ?x169) true))))))))
(check-sat)
; query 44: function core_state_transition, block 99, name %100
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x311 (or false false)))
(let (($x56 (not $x311)))
(and $x56 (or $x311 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 45: function core_state_transition, block 99, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x789 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x311 (or false false)))
(let (($x148 (or $x311 false false)))
(let (($x287 (not $x148)))
(and $x287 (or $x148 (and (distinct ?x789 ?x789) true))))))))
(check-sat)
; query 46: function crcu8, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x311 (or false false)))
(let (($x56 (not $x311)))
(and $x56 (or $x311 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 47: function crcu8, block 19, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x44 ((_ zero_extend 16) in.01_16)))
(let ((?x303 (bvxor ?x44 (_ bv16386 32))))
(let (($x311 (or false false)))
(let (($x148 (or $x311 false false)))
(let (($x287 (not $x148)))
(and $x287 (or $x148 (and (distinct ?x303 ?x303) true)))))))))
(check-sat)
; query 48: function crcu8, block 19, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x44 ((_ zero_extend 16) in.01_16)))
(let ((?x303 (bvxor ?x44 (_ bv16386 32))))
(let ((?x1182 ((_ extract 15 0) ?x303)))
(let (($x311 (or false false)))
(let (($x148 (or $x311 false false)))
(let (($x1296 (or $x148 false)))
(let (($x290 (not $x1296)))
(and $x290 (or $x1296 (and (distinct ?x1182 ?x1182) true)))))))))))
(check-sat)
; query 49: function crcu8, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x311 (or false false)))
(let (($x56 (not $x311)))
(and $x56 (or $x311 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 50: function crcu8, block 29, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x184 ((_ zero_extend 16) in27_16)))
(let ((?x638 (bvor ?x184 (_ bv32768 32))))
(let (($x311 (or false false)))
(let (($x148 (or $x311 false false)))
(let (($x287 (not $x148)))
(and $x287 (or $x148 (and (distinct ?x638 ?x638) true)))))))))
(check-sat)
; query 51: function crcu8, block 29, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x184 ((_ zero_extend 16) in27_16)))
(let ((?x638 (bvor ?x184 (_ bv32768 32))))
(let ((?x581 ((_ extract 15 0) ?x638)))
(let (($x311 (or false false)))
(let (($x148 (or $x311 false false)))
(let (($x1296 (or $x148 false)))
(let (($x290 (not $x1296)))
(and $x290 (or $x1296 (and (distinct ?x581 ?x581) true)))))))))))
(check-sat)
; query 52: function crcu8, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x311 (or false false)))
(let (($x56 (not $x311)))
(and $x56 (or $x311 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 53: function crcu8, block 33, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x184 ((_ zero_extend 16) in27_16)))
(let ((?x834 (bvand ?x184 (_ bv32767 32))))
(let (($x311 (or false false)))
(let (($x148 (or $x311 false false)))
(let (($x287 (not $x148)))
(and $x287 (or $x148 (and (distinct ?x834 ?x834) true)))))))))
(check-sat)
; query 54: function crcu8, block 33, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x184 ((_ zero_extend 16) in27_16)))
(let ((?x834 (bvand ?x184 (_ bv32767 32))))
(let ((?x1046 ((_ extract 15 0) ?x834)))
(let (($x311 (or false false)))
(let (($x148 (or $x311 false false)))
(let (($x1296 (or $x148 false)))
(let (($x290 (not $x1296)))
(and $x290 (or $x1296 (and (distinct ?x1046 ?x1046) true)))))))))))
(check-sat)
; query 55: function crcu8, block 38, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_8 () (_ BitVec 8))
(assert
 (let (($x500 (or false false false)))
(let (($x513 (not $x500)))
(and $x513 (or $x500 (and (distinct (bvadd in.02_8 (_ bv1 8)) (bvadd in.02_8 (_ bv1 8))) true))))))
(check-sat)
; query 56: function crcu8, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x476 ((_ extract 7 0) in.01_16)))
(let ((?x422 ((_ zero_extend 24) ?x476)))
(let (($x311 (or false false)))
(let (($x706 (or $x311 false)))
(and (not $x706) (or $x706 (and (distinct ?x422 ?x422) true))))))))
(check-sat)
; query 57: function crcu8, block 6, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x476 ((_ extract 7 0) in.01_16)))
(let ((?x422 ((_ zero_extend 24) ?x476)))
(let ((?x1284 (bvand ?x422 (_ bv1 32))))
(let (($x311 (or false false)))
(let (($x706 (or $x311 false)))
(let (($x343 (or $x706 false false)))
(and (not $x343) (or $x343 (and (distinct ?x1284 ?x1284) true))))))))))
(check-sat)
; query 58: function crcu8, block 6, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x476 ((_ extract 7 0) in.01_16)))
(let ((?x422 ((_ zero_extend 24) ?x476)))
(let ((?x1284 (bvand ?x422 (_ bv1 32))))
(let ((?x62 ((_ zero_extend 24) in.0_8)))
(let ((?x140 (bvand ?x62 (_ bv1 32))))
(let ((?x69 (bvxor ?x140 ?x1284)))
(let (($x311 (or false false)))
(let (($x706 (or $x311 false)))
(let (($x343 (or $x706 false false)))
(let (($x148 (or $x311 false false)))
(let (($x901 (or $x148 $x343 false)))
(and (not $x901) (or $x901 (and (distinct ?x69 ?x69) true)))))))))))))))
(check-sat)
; query 59: function crcu8, block 6, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x476 ((_ extract 7 0) in.01_16)))
(let ((?x422 ((_ zero_extend 24) ?x476)))
(let ((?x1284 (bvand ?x422 (_ bv1 32))))
(let ((?x62 ((_ zero_extend 24) in.0_8)))
(let ((?x140 (bvand ?x62 (_ bv1 32))))
(let ((?x69 (bvxor ?x140 ?x1284)))
(let ((?x361 ((_ extract 7 0) ?x69)))
(let (($x311 (or false false)))
(let (($x706 (or $x311 false)))
(let (($x343 (or $x706 false false)))
(let (($x148 (or $x311 false false)))
(let (($x901 (or $x148 $x343 false)))
(let (($x116 (or $x901 false)))
(and (not $x116) (or $x116 (and (distinct ?x361 ?x361) true)))))))))))))))))
(check-sat)
; query 60: function crcu8, block 6, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x311 (or false false)))
(let (($x56 (not $x311)))
(and $x56 (or $x311 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 61: function crcu8, block 6, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x62 ((_ zero_extend 24) in.0_8)))
(let ((?x205 (bvashr ?x62 (_ bv1 32))))
(let (($x311 (or false false)))
(let (($x148 (or $x311 false false)))
(let (($x467 (or $x148 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not $x467) (or $x467 (and (distinct ?x205 ?x205) true)))))))))
(check-sat)
; query 62: function crcu8, block 6, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x62 ((_ zero_extend 24) in.0_8)))
(let ((?x205 (bvashr ?x62 (_ bv1 32))))
(let ((?x127 ((_ extract 7 0) ?x205)))
(let (($x311 (or false false)))
(let (($x148 (or $x311 false false)))
(let (($x467 (or $x148 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x10 (or $x467 false)))
(and (not $x10) (or $x10 (and (distinct ?x127 ?x127) true)))))))))))
(check-sat)
; query 63: function crcu8, block 6, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x476 ((_ extract 7 0) in.01_16)))
(let ((?x422 ((_ zero_extend 24) ?x476)))
(let ((?x1284 (bvand ?x422 (_ bv1 32))))
(let ((?x62 ((_ zero_extend 24) in.0_8)))
(let ((?x140 (bvand ?x62 (_ bv1 32))))
(let ((?x69 (bvxor ?x140 ?x1284)))
(let ((?x361 ((_ extract 7 0) ?x69)))
(let ((?x392 ((_ zero_extend 24) ?x361)))
(let (($x311 (or false false)))
(let (($x706 (or $x311 false)))
(let (($x343 (or $x706 false false)))
(let (($x148 (or $x311 false false)))
(let (($x901 (or $x148 $x343 false)))
(let (($x116 (or $x901 false)))
(let (($x1096 (or $x116 false)))
(and (not $x1096) (or $x1096 (and (distinct ?x392 ?x392) true)))))))))))))))))))
(check-sat)
; query 64: function crcu8, block 6, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x476 ((_ extract 7 0) in.01_16)))
(let ((?x422 ((_ zero_extend 24) ?x476)))
(let ((?x1284 (bvand ?x422 (_ bv1 32))))
(let ((?x62 ((_ zero_extend 24) in.0_8)))
(let ((?x140 (bvand ?x62 (_ bv1 32))))
(let ((?x69 (bvxor ?x140 ?x1284)))
(let ((?x361 ((_ extract 7 0) ?x69)))
(let ((?x392 ((_ zero_extend 24) ?x361)))
(let ((?x143 (ite (= (_ bv1 32) ?x392) (_ bv1 1) (_ bv0 1))))
(let (($x311 (or false false)))
(let (($x706 (or $x311 false)))
(let (($x343 (or $x706 false false)))
(let (($x148 (or $x311 false false)))
(let (($x901 (or $x148 $x343 false)))
(let (($x116 (or $x901 false)))
(let (($x1096 (or $x116 false)))
(let (($x436 (or $x1096 false false)))
(and (not $x436) (or $x436 (and (distinct ?x143 ?x143) true)))))))))))))))))))))
(check-sat)
; query 65: function crcu8, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x311 (or false false)))
(let (($x56 (not $x311)))
(and $x56 (or $x311 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 66: function crcu8, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x62 ((_ zero_extend 24) in.0_8)))
(let ((?x140 (bvand ?x62 (_ bv1 32))))
(let (($x311 (or false false)))
(let (($x148 (or $x311 false false)))
(let (($x287 (not $x148)))
(and $x287 (or $x148 (and (distinct ?x140 ?x140) true)))))))))
(check-sat)
; query 67: function crcu8, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x311 (or false false)))
(let (($x56 (not $x311)))
(and $x56 (or $x311 (and (distinct ((_ extract 7 0) in.01_16) ((_ extract 7 0) in.01_16)) true))))))
(check-sat)
; query 68: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x378 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x874 ((_ zero_extend 31) ?x378)))
(let ((?x757 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x114 ((_ zero_extend 31) ?x757)))
(let ((?x27 (bvand ?x114 ?x874)))
(let ((?x1008 (ite (and (distinct (_ bv0 32) ?x27) true) (_ bv1 1) (_ bv0 1))))
(let ((?x730 ((_ zero_extend 63) ?x1008)))
(let (($x311 (or false false)))
(let (($x148 (or $x311 false false)))
(let (($x1296 (or $x148 false)))
(let (($x198 (or $x1296 $x1296 false)))
(let (($x235 (or $x198 false false)))
(let (($x32 (or $x235 false)))
(and (not $x32) (or $x32 (and (distinct ?x730 ?x730) true)))))))))))))))))
(check-sat)
; query 69: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x378 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x874 ((_ zero_extend 31) ?x378)))
(let ((?x757 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x114 ((_ zero_extend 31) ?x757)))
(let ((?x27 (bvand ?x114 ?x874)))
(let ((?x1008 (ite (and (distinct (_ bv0 32) ?x27) true) (_ bv1 1) (_ bv0 1))))
(let (($x717 (= (_ bv1 1) ?x1008)))
(let ((?x749 (ite $x717 (_ bv1 32) (_ bv0 32))))
(let (($x311 (or false false)))
(let (($x148 (or $x311 false false)))
(let (($x1296 (or $x148 false)))
(let (($x198 (or $x1296 $x1296 false)))
(let (($x235 (or $x198 false false)))
(let (($x584 (or $x235 (ite $x717 false false))))
(and (not $x584) (or $x584 (and (distinct ?x749 ?x749) true))))))))))))))))))
(check-sat)
; query 70: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x378 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x874 ((_ zero_extend 31) ?x378)))
(let ((?x757 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x114 ((_ zero_extend 31) ?x757)))
(let ((?x27 (bvand ?x114 ?x874)))
(let ((?x1008 (ite (and (distinct (_ bv0 32) ?x27) true) (_ bv1 1) (_ bv0 1))))
(let (($x717 (= (_ bv1 1) ?x1008)))
(let ((?x749 (ite $x717 (_ bv1 32) (_ bv0 32))))
(let ((?x1031 ((_ extract 7 0) ?x749)))
(let (($x311 (or false false)))
(let (($x148 (or $x311 false false)))
(let (($x1296 (or $x148 false)))
(let (($x198 (or $x1296 $x1296 false)))
(let (($x235 (or $x198 false false)))
(let (($x584 (or $x235 (ite $x717 false false))))
(let (($x403 (or $x584 false)))
(and (not $x403) (or $x403 (and (distinct ?x1031 ?x1031) true))))))))))))))))))))
(check-sat)
; query 71: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x311 (or false false)))
(let (($x56 (not $x311)))
(and $x56 (or $x311 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 72: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x757 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x311 (or false false)))
(let (($x148 (or $x311 false false)))
(let (($x287 (not $x148)))
(and $x287 (or $x148 (and (distinct ?x757 ?x757) true))))))))
(check-sat)
; query 73: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x757 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x114 ((_ zero_extend 31) ?x757)))
(let (($x311 (or false false)))
(let (($x148 (or $x311 false false)))
(let (($x1296 (or $x148 false)))
(let (($x290 (not $x1296)))
(and $x290 (or $x1296 (and (distinct ?x114 ?x114) true))))))))))
(check-sat)
; query 74: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x311 (or false false)))
(let (($x56 (not $x311)))
(and $x56 (or $x311 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 75: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x378 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x311 (or false false)))
(let (($x148 (or $x311 false false)))
(let (($x287 (not $x148)))
(and $x287 (or $x148 (and (distinct ?x378 ?x378) true))))))))
(check-sat)
; query 76: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x378 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x874 ((_ zero_extend 31) ?x378)))
(let (($x311 (or false false)))
(let (($x148 (or $x311 false false)))
(let (($x1296 (or $x148 false)))
(let (($x290 (not $x1296)))
(and $x290 (or $x1296 (and (distinct ?x874 ?x874) true))))))))))
(check-sat)
; query 77: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x378 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x874 ((_ zero_extend 31) ?x378)))
(let ((?x757 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x114 ((_ zero_extend 31) ?x757)))
(let ((?x27 (bvand ?x114 ?x874)))
(let (($x311 (or false false)))
(let (($x148 (or $x311 false false)))
(let (($x1296 (or $x148 false)))
(let (($x198 (or $x1296 $x1296 false)))
(and (not $x198) (or $x198 (and (distinct ?x27 ?x27) true)))))))))))))
(check-sat)
; query 78: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x378 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x874 ((_ zero_extend 31) ?x378)))
(let ((?x757 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x114 ((_ zero_extend 31) ?x757)))
(let ((?x27 (bvand ?x114 ?x874)))
(let ((?x1008 (ite (and (distinct (_ bv0 32) ?x27) true) (_ bv1 1) (_ bv0 1))))
(let (($x311 (or false false)))
(let (($x148 (or $x311 false false)))
(let (($x1296 (or $x148 false)))
(let (($x198 (or $x1296 $x1296 false)))
(let (($x235 (or $x198 false false)))
(and (not $x235) (or $x235 (and (distinct ?x1008 ?x1008) true)))))))))))))))
(check-sat)
; query 79: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x546 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x500 (or false false false)))
(let (($x513 (not $x500)))
(and $x513 (or $x500 (and (distinct ?x546 ?x546) true)))))))
(check-sat)
; query 80: function matrix_add_const, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x500 (or false false false)))
(let (($x513 (not $x500)))
(and $x513 (or $x500 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 81: function matrix_add_const, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x141 (bvadd in.01_32 (_ bv1 32))))
(let (($x856 (and (distinct ?x141 ?x141) true)))
(let (($x500 (or false false false)))
(let (($x513 (not $x500)))
(and $x513 (or $x500 $x856)))))))
(check-sat)
; query 82: function matrix_mul_const, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x500 (or false false false)))
(let (($x513 (not $x500)))
(and $x513 (or $x500 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 83: function matrix_mul_const, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x141 (bvadd in.01_32 (_ bv1 32))))
(let (($x856 (and (distinct ?x141 ?x141) true)))
(let (($x500 (or false false false)))
(let (($x513 (not $x500)))
(and $x513 (or $x500 $x856)))))))
(check-sat)
; query 84: function matrix_mul_matrix, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x500 (or false false false)))
(let (($x513 (not $x500)))
(and $x513 (or $x500 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 85: function matrix_mul_matrix, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x141 (bvadd in.01_32 (_ bv1 32))))
(let (($x856 (and (distinct ?x141 ?x141) true)))
(let (($x500 (or false false false)))
(let (($x513 (not $x500)))
(and $x513 (or $x500 $x856)))))))
(check-sat)
; query 86: function matrix_mul_matrix, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x500 (or false false false)))
(let (($x513 (not $x500)))
(and $x513 (or $x500 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 87: function matrix_mul_matrix_bitextract, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x500 (or false false false)))
(let (($x513 (not $x500)))
(and $x513 (or $x500 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 88: function matrix_mul_matrix_bitextract, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x141 (bvadd in.01_32 (_ bv1 32))))
(let (($x856 (and (distinct ?x141 ?x141) true)))
(let (($x500 (or false false false)))
(let (($x513 (not $x500)))
(and $x513 (or $x500 $x856)))))))
(check-sat)
; query 89: function matrix_mul_matrix_bitextract, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x500 (or false false false)))
(let (($x513 (not $x500)))
(and $x513 (or $x500 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 90: function matrix_mul_vect, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x500 (or false false false)))
(let (($x513 (not $x500)))
(and $x513 (or $x500 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 91: function matrix_mul_vect, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x141 (bvadd in.01_32 (_ bv1 32))))
(let (($x856 (and (distinct ?x141 ?x141) true)))
(let (($x500 (or false false false)))
(let (($x513 (not $x500)))
(and $x513 (or $x500 $x856)))))))
(check-sat)
; query 92: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x311 (or false false)))
(let (($x56 (not $x311)))
(and $x56 (or $x311 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 93: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x456 ((_ sign_extend 16) in.1_16)))
(let ((?x507 (bvadd ?x456 (_ bv10 32))))
(let (($x372 (and (distinct (bvadd ((_ sign_extend 1) ?x456) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x507)) true)))
(let (($x311 (or false false)))
(let (($x350 (or $x311 false (or $x372))))
(and (not $x350) (or $x350 (and (distinct ?x507 ?x507) true)))))))))
(check-sat)
; query 94: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x456 ((_ sign_extend 16) in.1_16)))
(let ((?x507 (bvadd ?x456 (_ bv10 32))))
(let ((?x407 ((_ extract 15 0) ?x507)))
(let (($x372 (and (distinct (bvadd ((_ sign_extend 1) ?x456) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x507)) true)))
(let (($x311 (or false false)))
(let (($x350 (or $x311 false (or $x372))))
(let (($x442 (or $x350 false)))
(and (not $x442) (or $x442 (and (distinct ?x407 ?x407) true)))))))))))
(check-sat)
; query 95: function matrix_sum, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x265 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x500 (or false false false)))
(let (($x513 (not $x500)))
(and $x513 (or $x500 (and (distinct ?x265 ?x265) true)))))))
(check-sat)
; query 96: function matrix_sum, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x265 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let ((?x818 ((_ zero_extend 63) ?x265)))
(let (($x500 (or false false false)))
(let (($x830 (or $x500 false)))
(and (not $x830) (or $x830 (and (distinct ?x818 ?x818) true))))))))
(check-sat)
; query 97: function matrix_sum, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x265 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x404 (= (_ bv1 1) ?x265)))
(let ((?x115 (ite $x404 (_ bv1 32) (_ bv0 32))))
(let (($x500 (or false false false)))
(let (($x267 (or $x500 (ite $x404 false false))))
(and (not $x267) (or $x267 (and (distinct ?x115 ?x115) true)))))))))
(check-sat)
; query 98: function matrix_sum, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x311 (or false false)))
(let (($x56 (not $x311)))
(and $x56 (or $x311 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 99: function matrix_sum, block 22, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x265 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x404 (= (_ bv1 1) ?x265)))
(let ((?x115 (ite $x404 (_ bv1 32) (_ bv0 32))))
(let ((?x456 ((_ sign_extend 16) in.1_16)))
(let ((?x243 (bvadd ?x456 ?x115)))
(let (($x273 (and (distinct (bvadd ((_ sign_extend 1) ?x456) ((_ sign_extend 1) ?x115)) ((_ sign_extend 1) ?x243)) true)))
(let (($x500 (or false false false)))
(let (($x267 (or $x500 (ite $x404 false false))))
(let (($x311 (or false false)))
(let (($x212 (or $x311 $x267 (or $x273))))
(and (not $x212) (or $x212 (and (distinct ?x243 ?x243) true))))))))))))))
(check-sat)
; query 100: function matrix_sum, block 22, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x265 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x404 (= (_ bv1 1) ?x265)))
(let ((?x115 (ite $x404 (_ bv1 32) (_ bv0 32))))
(let ((?x456 ((_ sign_extend 16) in.1_16)))
(let ((?x243 (bvadd ?x456 ?x115)))
(let ((?x222 ((_ extract 15 0) ?x243)))
(let (($x273 (and (distinct (bvadd ((_ sign_extend 1) ?x456) ((_ sign_extend 1) ?x115)) ((_ sign_extend 1) ?x243)) true)))
(let (($x500 (or false false false)))
(let (($x267 (or $x500 (ite $x404 false false))))
(let (($x311 (or false false)))
(let (($x212 (or $x311 $x267 (or $x273))))
(let (($x168 (or $x212 false)))
(and (not $x168) (or $x168 (and (distinct ?x222 ?x222) true))))))))))))))))
(check-sat)
; query 101: function matrix_sum, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x500 (or false false false)))
(let (($x513 (not $x500)))
(and $x513 (or $x500 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 102: function matrix_sum, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x141 (bvadd in.01_32 (_ bv1 32))))
(let (($x856 (and (distinct ?x141 ?x141) true)))
(let (($x500 (or false false false)))
(let (($x513 (not $x500)))
(and $x513 (or $x500 $x856)))))))
(check-sat)
; query 103: function parseval, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.23_32 () (_ BitVec 32))
(assert
 (let (($x701 (and (distinct (bvmul ((_ sign_extend 32) in.23_32) ((_ sign_extend 32) (_ bv1024 32))) ((_ sign_extend 32) (bvmul in.23_32 (_ bv1024 32)))) true)))
(let (($x304 (or false false (or $x701))))
(and (not $x304) (or $x304 (and (distinct (bvmul in.23_32 (_ bv1024 32)) (bvmul in.23_32 (_ bv1024 32))) true))))))
(check-sat)
; query 104: function parseval, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.34_32 () (_ BitVec 32))
(assert
 (let (($x620 (and (distinct (bvmul ((_ sign_extend 32) in.34_32) ((_ sign_extend 32) (_ bv1048576 32))) ((_ sign_extend 32) (bvmul in.34_32 (_ bv1048576 32)))) true)))
(let (($x1364 (or false false (or $x620))))
(and (not $x1364) (or $x1364 (and (distinct (bvmul in.34_32 (_ bv1048576 32)) (bvmul in.34_32 (_ bv1048576 32))) true))))))
(check-sat)
; query 105: function partition_memory, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x500 (or false false false)))
(let (($x513 (not $x500)))
(and $x513 (or $x500 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 106: function run_crc_loop, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x141 (bvadd in.01_32 (_ bv1 32))))
(let (($x856 (and (distinct ?x141 ?x141) true)))
(let (($x500 (or false false false)))
(let (($x513 (not $x500)))
(and $x513 (or $x500 $x856)))))))
(check-sat)
