; OptiPhase-Sigma refinement certificate for sweep K45-R4-367
; query 0: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x153 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x179 (or false false false)))
(let (($x347 (not $x179)))
(and $x347 (or $x179 (and (distinct ?x153 ?x153) true)))))))
(check-sat)
; query 1: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x306 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x179 (or false false false)))
(let (($x347 (not $x179)))
(and $x347 (or $x179 (and (distinct ?x306 ?x306) true)))))))
(check-sat)
