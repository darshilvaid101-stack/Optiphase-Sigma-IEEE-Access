; OptiPhase-Sigma refinement certificate for sweep K49-R3-082
; query 0: function Decoding_of_the_coded_Log_Area_Ratios, block 107, name %108
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in104_64 () (_ BitVec 64))
(assert
 (let ((?x226 (ite (bvslt (_ bv0 64) in104_64) (_ bv1 1) (_ bv0 1))))
(let (($x44 (or false false false)))
(let (($x187 (not $x44)))
(and $x187 (or $x44 (and (distinct ?x226 ?x226) true)))))))
(check-sat)
; query 1: function Decoding_of_the_coded_Log_Area_Ratios, block 107, name %109
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in104_64 () (_ BitVec 64))
(assert
 (let (($x216 (and (distinct ((_ zero_extend 63) (ite (bvslt (_ bv0 64) in104_64) (_ bv1 1) (_ bv0 1))) (ite (= (_ bv1 1) (ite (bvslt (_ bv0 64) in104_64) (_ bv1 1) (_ bv0 1))) (_ bv32767 64) (_ bv18446744073709518848 64))) true)))
(let (($x44 (or false false false)))
(let (($x145 (or $x44 (ite (= (_ bv1 1) (ite (bvslt (_ bv0 64) in104_64) (_ bv1 1) (_ bv0 1))) false false))))
(and (not (or $x44 false)) (or $x145 $x216))))))
(check-sat)
; query 2: function Decoding_of_the_coded_Log_Area_Ratios, block 219, name %220
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in216_64 () (_ BitVec 64))
(assert
 (let (($x175 (and (distinct (ite (bvsge (_ bv18446744073709518848 64) in216_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv0 64) in216_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x44 (or false false false)))
(let (($x187 (not $x44)))
(and $x187 (or $x44 $x175))))))
(check-sat)
; query 3: function alaw_input, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x110 (and (distinct (bvadd ((_ zero_extend 1) in.02_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x40 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x1161 (or (or false false (or $x40 $x110)) (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))
(and (not (or false false (or $x40))) $x1161)))))
(check-sat)
; query 4: function alaw_input, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let ((?x9 (ite (= (_ bv4294967295 32) in.1_32) (_ bv1 1) (_ bv0 1))))
(let (($x44 (or false false false)))
(let (($x187 (not $x44)))
(and $x187 (or $x44 (and (distinct ?x9 ?x9) true)))))))
(check-sat)
; query 5: function gsm_L_add, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let (($x1321 (and (distinct (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv18446744073709551615 64) in1_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x44 (or false false false)))
(let (($x187 (not $x44)))
(and $x187 (or $x44 $x1321))))))
(check-sat)
; query 6: function gsm_L_add, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x13 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvadd in0_64 in1_64))) true)))
(let (($x177 (or false false (or $x13))))
(let (($x666 (or $x177 (and (distinct (bvadd in0_64 in1_64) (bvadd in0_64 in1_64)) true))))
(and (not $x177) $x666)))))
(check-sat)
; query 7: function gsm_L_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x144 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x44 (or false false false)))
(let (($x187 (not $x44)))
(and $x187 (or $x44 (and (distinct ?x144 ?x144) true)))))))
(check-sat)
; query 8: function gsm_L_asl, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x24 (and (distinct (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvsgt (_ bv4294967265 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x44 (or false false false)))
(let (($x187 (not $x44)))
(and $x187 (or $x44 $x24))))))
(check-sat)
; query 9: function gsm_L_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x116 (and (distinct (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv31 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x44 (or false false false)))
(let (($x187 (not $x44)))
(and $x187 (or $x44 $x116))))))
(check-sat)
; query 10: function gsm_L_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x116 (and (distinct (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv31 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x44 (or false false false)))
(let (($x187 (not $x44)))
(and $x187 (or $x44 $x116))))))
(check-sat)
; query 11: function gsm_L_sub, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x143 (bvsub in0_64 in1_64)))
(let (($x94 (and (distinct ?x143 ?x143) true)))
(let (($x128 (and (distinct (bvsub ((_ zero_extend 1) in0_64) ((_ zero_extend 1) in1_64)) ((_ zero_extend 1) ?x143)) true)))
(let (($x48 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) ?x143)) true)))
(let (($x84 (or false false (or $x48))))
(let (($x98 (not $x84)))
(and $x98 (or (or false false (or $x128)) $x94)))))))))
(check-sat)
; query 12: function gsm_L_sub, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let (($x1321 (and (distinct (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv18446744073709551615 64) in1_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x44 (or false false false)))
(let (($x187 (not $x44)))
(and $x187 (or $x44 $x1321))))))
(check-sat)
; query 13: function gsm_L_sub, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x143 (bvsub in0_64 in1_64)))
(let (($x94 (and (distinct ?x143 ?x143) true)))
(let (($x48 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) ?x143)) true)))
(let (($x84 (or false false (or $x48))))
(let (($x98 (not $x84)))
(and $x98 (or $x84 $x94))))))))
(check-sat)
; query 14: function gsm_L_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x103 (and (distinct (ite (bvsle (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv18446744073709551615 64) in0_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x44 (or false false false)))
(let (($x187 (not $x44)))
(and $x187 (or $x44 $x103))))))
(check-sat)
; query 15: function gsm_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_64 () (_ BitVec 64))
(assert
 (let ((?x95 (ite (bvslt (_ bv32767 64) in5_64) (_ bv1 1) (_ bv0 1))))
(let (($x44 (or false false false)))
(let (($x187 (not $x44)))
(and $x187 (or $x44 (and (distinct ?x95 ?x95) true)))))))
(check-sat)
; query 16: function gsm_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x615 (or false false)))
(let (($x82 (not $x615)))
(and $x82 (or $x615 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 17: function gsm_add, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x615 (or false false)))
(let (($x82 (not $x615)))
(and $x82 (or $x615 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 18: function gsm_add, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x39 ((_ sign_extend 48) in1_16)))
(let ((?x11 ((_ sign_extend 48) in0_16)))
(let ((?x173 (bvadd ?x11 ?x39)))
(let (($x35 (and (distinct (bvadd ((_ sign_extend 1) ?x11) ((_ sign_extend 1) ?x39)) ((_ sign_extend 1) ?x173)) true)))
(let (($x615 (or false false)))
(let (($x2791 (or $x615 $x615 (or $x35))))
(and (not $x2791) (or $x2791 (and (distinct ?x173 ?x173) true))))))))))
(check-sat)
; query 19: function gsm_add, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x105 (ite (bvsgt (_ bv18446744073709518848 64) (bvadd ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x39 ((_ sign_extend 48) in1_16)))
(let ((?x50 ((_ sign_extend 1) ?x39)))
(let ((?x11 ((_ sign_extend 48) in0_16)))
(let ((?x55 ((_ sign_extend 1) ?x11)))
(let (($x615 (or false false)))
(let (($x2791 (or $x615 $x615 (or (and (distinct (bvadd ?x55 ?x50) ((_ sign_extend 1) (bvadd ?x11 ?x39))) true)))))
(let (($x138 (or $x2791 false false)))
(and (not $x138) (or $x138 (and (distinct ?x105 ?x105) true))))))))))))
(check-sat)
; query 20: function gsm_asl, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x123 (and (distinct (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvsgt (_ bv4294967281 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x44 (or false false false)))
(let (($x187 (not $x44)))
(and $x187 (or $x44 $x123))))))
(check-sat)
; query 21: function gsm_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x150 (and (distinct (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv15 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x44 (or false false false)))
(let (($x187 (not $x44)))
(and $x187 (or $x44 $x150))))))
(check-sat)
; query 22: function gsm_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x150 (and (distinct (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv15 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x44 (or false false false)))
(let (($x187 (not $x44)))
(and $x187 (or $x44 $x150))))))
(check-sat)
; query 23: function gsm_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_64 () (_ BitVec 64))
(assert
 (let ((?x95 (ite (bvslt (_ bv32767 64) in5_64) (_ bv1 1) (_ bv0 1))))
(let (($x44 (or false false false)))
(let (($x187 (not $x44)))
(and $x187 (or $x44 (and (distinct ?x95 ?x95) true)))))))
(check-sat)
; query 24: function gsm_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x615 (or false false)))
(let (($x82 (not $x615)))
(and $x82 (or $x615 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 25: function gsm_sub, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x615 (or false false)))
(let (($x82 (not $x615)))
(and $x82 (or $x615 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 26: function gsm_sub, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x39 ((_ sign_extend 48) in1_16)))
(let ((?x11 ((_ sign_extend 48) in0_16)))
(let ((?x576 (bvsub ?x11 ?x39)))
(let (($x1900 (and (distinct (bvsub ((_ sign_extend 1) ?x11) ((_ sign_extend 1) ?x39)) ((_ sign_extend 1) ?x576)) true)))
(let (($x615 (or false false)))
(let (($x358 (or $x615 $x615 (or $x1900))))
(and (not $x358) (or $x358 (and (distinct ?x576 ?x576) true))))))))))
(check-sat)
; query 27: function gsm_sub, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1956 (ite (bvsgt (_ bv18446744073709518848 64) (bvsub ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x39 ((_ sign_extend 48) in1_16)))
(let ((?x50 ((_ sign_extend 1) ?x39)))
(let ((?x11 ((_ sign_extend 48) in0_16)))
(let ((?x55 ((_ sign_extend 1) ?x11)))
(let (($x615 (or false false)))
(let (($x358 (or $x615 $x615 (or (and (distinct (bvsub ?x55 ?x50) ((_ sign_extend 1) (bvsub ?x11 ?x39))) true)))))
(let (($x91 (or $x358 false false)))
(and (not $x91) (or $x91 (and (distinct ?x1956 ?x1956) true))))))))))))
(check-sat)
; query 28: function ulaw_input, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x110 (and (distinct (bvadd ((_ zero_extend 1) in.02_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x40 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x1161 (or (or false false (or $x40 $x110)) (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))
(and (not (or false false (or $x40))) $x1161)))))
(check-sat)
; query 29: function ulaw_input, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let ((?x9 (ite (= (_ bv4294967295 32) in.1_32) (_ bv1 1) (_ bv0 1))))
(let (($x44 (or false false false)))
(let (($x187 (not $x44)))
(and $x187 (or $x44 (and (distinct ?x9 ?x9) true)))))))
(check-sat)
