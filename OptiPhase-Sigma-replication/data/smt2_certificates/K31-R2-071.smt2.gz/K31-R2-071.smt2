; OptiPhase-Sigma refinement certificate for sweep K31-R2-071
; query 0: function main, block 107, name %108
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.5_32 () (_ BitVec 32))
(assert
 (let (($x653 (and (distinct (bvadd ((_ sign_extend 1) in.5_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.5_32 (_ bv1 32)))) true)))
(let (($x333 (or false false (or $x653))))
(and (not $x333) (or $x333 (and (distinct (bvadd in.5_32 (_ bv1 32)) (bvadd in.5_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function main, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x99 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x98 (or false false (or $x99))))
(and (not $x98) (or $x98 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function main, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x122 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x322 (or false false (or $x122))))
(and (not $x322) (or $x322 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 3: function main, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let (($x34 (and (distinct (bvadd ((_ sign_extend 1) in.2_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.2_32 (_ bv1 32)))) true)))
(let (($x116 (or false false (or $x34))))
(and (not $x116) (or $x116 (and (distinct (bvadd in.2_32 (_ bv1 32)) (bvadd in.2_32 (_ bv1 32))) true))))))
(check-sat)
; query 4: function main, block 57, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.3_32 () (_ BitVec 32))
(assert
 (let (($x100 (and (distinct (bvadd ((_ sign_extend 1) in.3_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.3_32 (_ bv1 32)))) true)))
(let (($x64 (or false false (or $x100))))
(and (not $x64) (or $x64 (and (distinct (bvadd in.3_32 (_ bv1 32)) (bvadd in.3_32 (_ bv1 32))) true))))))
(check-sat)
; query 5: function main, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.4_32 () (_ BitVec 32))
(assert
 (let (($x435 (and (distinct (bvadd ((_ sign_extend 1) in.4_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.4_32 (_ bv1 32)))) true)))
(let (($x488 (or false false (or $x435))))
(and (not $x488) (or $x488 (and (distinct (bvadd in.4_32 (_ bv1 32)) (bvadd in.4_32 (_ bv1 32))) true))))))
(check-sat)
; query 6: function usqrt, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x362 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x12 (or false false (or $x362))))
(and (not $x12) (or $x12 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
