; OptiPhase-Sigma refinement certificate for sweep K42-R2-080
; query 0: function byte_reverse, block 35, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x167 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x172 (or false false (or $x167))))
(and (not $x172) (or $x172 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function sha_transform, block 12, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x167 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x172 (or false false (or $x167))))
(and (not $x172) (or $x172 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function sha_transform, block 122, name %123
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.4_32 () (_ BitVec 32))
(assert
 (let (($x422 (and (distinct (bvadd ((_ sign_extend 1) in.4_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.4_32 (_ bv1 32)))) true)))
(let (($x411 (or false false (or $x422))))
(and (not $x411) (or $x411 (and (distinct (bvadd in.4_32 (_ bv1 32)) (bvadd in.4_32 (_ bv1 32))) true))))))
(check-sat)
; query 3: function sha_transform, block 143, name %144
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.5_32 () (_ BitVec 32))
(assert
 (let (($x427 (and (distinct (bvadd ((_ sign_extend 1) in.5_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.5_32 (_ bv1 32)))) true)))
(let (($x72 (or false false (or $x427))))
(and (not $x72) (or $x72 (and (distinct (bvadd in.5_32 (_ bv1 32)) (bvadd in.5_32 (_ bv1 32))) true))))))
(check-sat)
; query 4: function sha_transform, block 39, name %40
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x462 (and (distinct (bvadd ((_ sign_extend 1) in.12_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.12_32 (_ bv1 32)))) true)))
(let (($x126 (or false false (or $x462))))
(and (not $x126) (or $x126 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 5: function sha_transform, block 77, name %78
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.23_32 () (_ BitVec 32))
(assert
 (let (($x35 (and (distinct (bvadd ((_ sign_extend 1) in.23_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.23_32 (_ bv1 32)))) true)))
(let (($x418 (or false false (or $x35))))
(and (not $x418) (or $x418 (and (distinct (bvadd in.23_32 (_ bv1 32)) (bvadd in.23_32 (_ bv1 32))) true))))))
(check-sat)
; query 6: function sha_transform, block 98, name %99
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.34_32 () (_ BitVec 32))
(assert
 (let (($x71 (and (distinct (bvadd ((_ sign_extend 1) in.34_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.34_32 (_ bv1 32)))) true)))
(let (($x168 (or false false (or $x71))))
(and (not $x168) (or $x168 (and (distinct (bvadd in.34_32 (_ bv1 32)) (bvadd in.34_32 (_ bv1 32))) true))))))
(check-sat)
