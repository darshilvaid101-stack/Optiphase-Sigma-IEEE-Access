; OptiPhase-Sigma refinement certificate for sweep K20-R6-016
