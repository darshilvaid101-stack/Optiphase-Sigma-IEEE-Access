; OptiPhase-Sigma refinement certificate for sweep K44-R3-129
; query 0: function Index_to_frequency, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1498 (ite (bvuge in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x1497 (or false false false)))
(let (($x701 (not $x1497)))
(and $x701 (or $x1497 (and (distinct ?x1498 ?x1498) true)))))))
(check-sat)
; query 1: function IsPowerOfTwo, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x1497 (or false false false)))
(let (($x701 (not $x1497)))
(and $x701 (or $x1497 (and (distinct (bvsub in0_32 (_ bv1 32)) (bvsub in0_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function IsPowerOfTwo, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x713 (bvsub in0_32 (_ bv1 32))))
(let ((?x1588 (bvand in0_32 ?x713)))
(let (($x1497 (or false false false)))
(let (($x1590 (or false $x1497 false)))
(and (not $x1590) (or $x1590 (and (distinct ?x1588 ?x1588) true))))))))
(check-sat)
; query 3: function IsPowerOfTwo, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x77 (ite (and (distinct (_ bv0 32) (bvand in0_32 (bvsub in0_32 (_ bv1 32)))) true) (_ bv1 1) (_ bv0 1))))
(let (($x1497 (or false false false)))
(let (($x1590 (or false $x1497 false)))
(let (($x382 (or $x1590 false false)))
(and (not $x382) (or $x382 (and (distinct ?x77 ?x77) true))))))))
(check-sat)
; query 4: function IsPowerOfTwo, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x118 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x1497 (or false false false)))
(let (($x701 (not $x1497)))
(and $x701 (or $x1497 (and (distinct ?x118 ?x118) true)))))))
(check-sat)
; query 5: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x118 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x1497 (or false false false)))
(let (($x701 (not $x1497)))
(and $x701 (or $x1497 (and (distinct ?x118 ?x118) true)))))))
(check-sat)
; query 6: function fft_float, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x20 (ite (and (distinct (_ bv0 32) in1_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x1497 (or false false false)))
(let (($x701 (not $x1497)))
(and $x701 (or $x1497 (and (distinct ?x20 ?x20) true)))))))
(check-sat)
; query 7: function main, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x104 (ite (= (_ bv4 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x1497 (or false false false)))
(let (($x701 (not $x1497)))
(and $x701 (or $x1497 (and (distinct ?x104 ?x104) true)))))))
(check-sat)
; query 8: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x5 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x1497 (or false false false)))
(let (($x701 (not $x1497)))
(and $x701 (or $x1497 (and (distinct ?x5 ?x5) true)))))))
(check-sat)
