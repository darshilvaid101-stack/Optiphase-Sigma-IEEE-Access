; OptiPhase-Sigma refinement certificate for sweep K43-R3-139
