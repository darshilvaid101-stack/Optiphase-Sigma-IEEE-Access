; OptiPhase-Sigma refinement certificate for sweep K28-R5-408
