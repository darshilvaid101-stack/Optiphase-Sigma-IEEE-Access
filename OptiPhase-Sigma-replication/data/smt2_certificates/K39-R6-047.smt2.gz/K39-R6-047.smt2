; OptiPhase-Sigma refinement certificate for sweep K39-R6-047
; query 0: function BF_cbc_encrypt, block 126, name %127
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.010_64 () (_ BitVec 64))
(assert
 (let (($x106 (and (distinct (bvsub ((_ sign_extend 1) in.010_64) ((_ sign_extend 1) (_ bv8 64))) ((_ sign_extend 1) (bvsub in.010_64 (_ bv8 64)))) true)))
(let (($x6 (or false false (or $x106))))
(and (not $x6) (or $x6 (and (distinct (bvsub in.010_64 (_ bv8 64)) (bvsub in.010_64 (_ bv8 64))) true))))))
(check-sat)
; query 1: function BF_cbc_encrypt, block 128, name %129
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.010_64 () (_ BitVec 64))
(assert
 (let ((?x192 (ite (and (distinct (_ bv18446744073709551608 64) in.010_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x160 (or false false false)))
(let (($x615 (not $x160)))
(and $x615 (or $x160 (and (distinct ?x192 ?x192) true)))))))
(check-sat)
; query 2: function BF_cfb64_encrypt, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.07_32 () (_ BitVec 32))
(assert
 (let ((?x311 (ite (= (_ bv0 32) in.07_32) (_ bv1 1) (_ bv0 1))))
(let (($x160 (or false false false)))
(let (($x615 (not $x160)))
(and $x615 (or $x160 (and (distinct ?x311 ?x311) true)))))))
(check-sat)
; query 3: function BF_set_key, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x7 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x491 (or false false (or $x7))))
(and (not $x491) (or $x491 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 4: function BF_set_key, block 69, name %70
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.13_32 () (_ BitVec 32))
(assert
 (let (($x134 (and (distinct (bvadd ((_ sign_extend 1) in.13_32) ((_ sign_extend 1) (_ bv2 32))) ((_ sign_extend 1) (bvadd in.13_32 (_ bv2 32)))) true)))
(let (($x177 (or false false (or $x134))))
(and (not $x177) (or $x177 (and (distinct (bvadd in.13_32 (_ bv2 32)) (bvadd in.13_32 (_ bv2 32))) true))))))
(check-sat)
; query 5: function BF_set_key, block 87, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.24_32 () (_ BitVec 32))
(assert
 (let (($x27 (and (distinct (bvadd ((_ sign_extend 1) in.24_32) ((_ sign_extend 1) (_ bv2 32))) ((_ sign_extend 1) (bvadd in.24_32 (_ bv2 32)))) true)))
(let (($x91 (or false false (or $x27))))
(and (not $x91) (or $x91 (and (distinct (bvadd in.24_32 (_ bv2 32)) (bvadd in.24_32 (_ bv2 32))) true))))))
(check-sat)
; query 6: function main, block 60, name %61
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x125 (or false false)))
(and (not $x125) (or $x125 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 7: function main, block 60, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x97 (ite (bvsge (_ bv57 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x125 (or false false)))
(let (($x674 (or $x125 false false)))
(let (($x116 (not $x674)))
(and $x116 (or $x674 (and (distinct ?x97 ?x97) true))))))))
(check-sat)
; query 8: function main, block 63, name %64
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x160 (or false false false)))
(and (not (or $x160 (bvuge (_ bv4 32) (_ bv32 32)))) (or $x160 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvmul in.01_32 (_ bv16 32))) true)))))
(check-sat)
; query 9: function main, block 63, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x125 (or false false)))
(and (not $x125) (or $x125 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 10: function main, block 63, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x190 (bvmul in.01_32 (_ bv16 32))))
(let ((?x183 (bvadd ?x190 (_ bv4294967248 32))))
(let ((?x685 ((_ sign_extend 24) in57_8)))
(let ((?x302 (bvshl in.01_32 (_ bv4 32))))
(let ((?x75 (bvadd ?x302 ?x685)))
(let (($x160 (or false false false)))
(let (($x96 (or $x160 false false)))
(let ((?x139 ((_ sign_extend 1) ?x75)))
(let (($x125 (or false false)))
(let (($x246 (or $x160 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x467 (or $x246 $x125 (or (and (distinct (bvadd ((_ sign_extend 1) ?x302) ((_ sign_extend 1) ?x685)) ?x139) true)))))
(let (($x124 (not $x467)))
(and $x124 (or $x96 (and (distinct ?x75 ?x183) true))))))))))))))))
(check-sat)
; query 11: function main, block 63, name %67
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x685 ((_ sign_extend 24) in57_8)))
(let ((?x302 (bvshl in.01_32 (_ bv4 32))))
(let ((?x75 (bvadd ?x302 ?x685)))
(let ((?x590 (bvsub ?x75 (_ bv48 32))))
(let (($x125 (or false false)))
(let (($x160 (or false false false)))
(let (($x96 (or $x160 false false)))
(let (($x13 (or $x96 $x125 false)))
(let (($x225 (or $x13 (and (distinct ?x590 (bvadd (bvadd (bvmul in.01_32 (_ bv16 32)) (_ bv4294967248 32)) ?x685)) true))))
(let (($x606 (and (distinct (bvsub ((_ sign_extend 1) ?x75) ((_ sign_extend 1) (_ bv48 32))) ((_ sign_extend 1) ?x590)) true)))
(let ((?x139 ((_ sign_extend 1) ?x75)))
(let (($x246 (or $x160 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x467 (or $x246 $x125 (or (and (distinct (bvadd ((_ sign_extend 1) ?x302) ((_ sign_extend 1) ?x685)) ?x139) true)))))
(and (not (or $x467 false (or $x606))) $x225)))))))))))))))
(check-sat)
; query 12: function main, block 68, name %69
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x125 (or false false)))
(and (not $x125) (or $x125 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 13: function main, block 68, name %70
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x119 (ite (bvsle (_ bv65 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x125 (or false false)))
(let (($x674 (or $x125 false false)))
(let (($x116 (not $x674)))
(and $x116 (or $x674 (and (distinct ?x119 ?x119) true))))))))
(check-sat)
; query 14: function main, block 71, name %72
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x125 (or false false)))
(and (not $x125) (or $x125 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 15: function main, block 71, name %73
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x227 (ite (bvsge (_ bv70 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x125 (or false false)))
(let (($x674 (or $x125 false false)))
(let (($x116 (not $x674)))
(and $x116 (or $x674 (and (distinct ?x227 ?x227) true))))))))
(check-sat)
; query 16: function main, block 74, name %75
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x160 (or false false false)))
(and (not (or $x160 (bvuge (_ bv4 32) (_ bv32 32)))) (or $x160 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvmul in.01_32 (_ bv16 32))) true)))))
(check-sat)
; query 17: function main, block 74, name %76
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x125 (or false false)))
(and (not $x125) (or $x125 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 18: function main, block 74, name %77
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x190 (bvmul in.01_32 (_ bv16 32))))
(let ((?x167 (bvadd ?x190 (_ bv4294967241 32))))
(let ((?x685 ((_ sign_extend 24) in57_8)))
(let ((?x302 (bvshl in.01_32 (_ bv4 32))))
(let ((?x75 (bvadd ?x302 ?x685)))
(let (($x160 (or false false false)))
(let (($x96 (or $x160 false false)))
(let ((?x139 ((_ sign_extend 1) ?x75)))
(let (($x125 (or false false)))
(let (($x246 (or $x160 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x467 (or $x246 $x125 (or (and (distinct (bvadd ((_ sign_extend 1) ?x302) ((_ sign_extend 1) ?x685)) ?x139) true)))))
(let (($x124 (not $x467)))
(and $x124 (or $x96 (and (distinct ?x75 ?x167) true))))))))))))))))
(check-sat)
; query 19: function main, block 74, name %78
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x685 ((_ sign_extend 24) in57_8)))
(let ((?x302 (bvshl in.01_32 (_ bv4 32))))
(let ((?x75 (bvadd ?x302 ?x685)))
(let ((?x1321 (bvsub ?x75 (_ bv65 32))))
(let (($x125 (or false false)))
(let (($x160 (or false false false)))
(let (($x96 (or $x160 false false)))
(let (($x13 (or $x96 $x125 false)))
(let (($x77 (or $x13 (and (distinct ?x1321 (bvadd (bvadd (bvmul in.01_32 (_ bv16 32)) (_ bv4294967241 32)) ?x685)) true))))
(let (($x46 (and (distinct (bvsub ((_ sign_extend 1) ?x75) ((_ sign_extend 1) (_ bv65 32))) ((_ sign_extend 1) ?x1321)) true)))
(let ((?x139 ((_ sign_extend 1) ?x75)))
(let (($x246 (or $x160 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x467 (or $x246 $x125 (or (and (distinct (bvadd ((_ sign_extend 1) ?x302) ((_ sign_extend 1) ?x685)) ?x139) true)))))
(and (not (or $x467 false (or $x46))) $x77)))))))))))))))
(check-sat)
