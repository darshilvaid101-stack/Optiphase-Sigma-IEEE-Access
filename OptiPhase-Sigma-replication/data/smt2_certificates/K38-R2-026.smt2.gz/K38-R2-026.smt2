; OptiPhase-Sigma refinement certificate for sweep K38-R2-026
; query 0: function BF_cfb64_encrypt, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.07_32 () (_ BitVec 32))
(assert
 (let ((?x102 (ite (= (_ bv0 32) in.07_32) (_ bv1 1) (_ bv0 1))))
(let (($x674 (or false false false)))
(and (not $x674) (or $x674 (and (distinct ?x102 ?x102) true))))))
(check-sat)
; query 1: function BF_set_key, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x124 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x35 (or false false (or $x124))))
(and (not $x35) (or $x35 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function BF_set_key, block 69, name %70
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.13_32 () (_ BitVec 32))
(assert
 (let (($x185 (and (distinct (bvadd ((_ sign_extend 1) in.13_32) ((_ sign_extend 1) (_ bv2 32))) ((_ sign_extend 1) (bvadd in.13_32 (_ bv2 32)))) true)))
(let (($x134 (or false false (or $x185))))
(and (not $x134) (or $x134 (and (distinct (bvadd in.13_32 (_ bv2 32)) (bvadd in.13_32 (_ bv2 32))) true))))))
(check-sat)
; query 3: function BF_set_key, block 87, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.24_32 () (_ BitVec 32))
(assert
 (let (($x123 (and (distinct (bvadd ((_ sign_extend 1) in.24_32) ((_ sign_extend 1) (_ bv2 32))) ((_ sign_extend 1) (bvadd in.24_32 (_ bv2 32)))) true)))
(let (($x156 (or false false (or $x123))))
(and (not $x156) (or $x156 (and (distinct (bvadd in.24_32 (_ bv2 32)) (bvadd in.24_32 (_ bv2 32))) true))))))
(check-sat)
; query 4: function main, block 60, name %61
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x576 (or false false)))
(let (($x666 (not $x576)))
(and $x666 (or $x576 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true))))))
(check-sat)
; query 5: function main, block 60, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x72 (ite (bvsge (_ bv57 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x576 (or false false)))
(let (($x89 (or $x576 false false)))
(let (($x226 (not $x89)))
(and $x226 (or $x89 (and (distinct ?x72 ?x72) true))))))))
(check-sat)
; query 6: function main, block 63, name %64
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x674 (or false false false)))
(let (($x22 (or $x674 (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x22) (or $x22 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvshl in.01_32 (_ bv4 32))) true))))))
(check-sat)
; query 7: function main, block 63, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x576 (or false false)))
(let (($x666 (not $x576)))
(and $x666 (or $x576 (and (distinct ((_ sign_extend 24) in57_8) ((_ zero_extend 24) in57_8)) true))))))
(check-sat)
; query 8: function main, block 63, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x11 ((_ zero_extend 24) in57_8)))
(let ((?x116 (bvshl in.01_32 (_ bv4 32))))
(let ((?x136 (bvadd ?x116 ?x11)))
(let ((?x143 ((_ sign_extend 24) in57_8)))
(let ((?x51 (bvadd ?x116 ?x143)))
(let (($x576 (or false false)))
(let (($x674 (or false false false)))
(let (($x22 (or $x674 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x234 (or $x22 $x576 false)))
(let ((?x165 ((_ sign_extend 1) ?x51)))
(let (($x138 (or $x22 $x576 (or (and (distinct (bvadd ((_ sign_extend 1) ?x116) ((_ sign_extend 1) ?x143)) ?x165) true)))))
(and (not $x138) (or $x234 (and (distinct ?x51 ?x136) true)))))))))))))))
(check-sat)
; query 9: function main, block 63, name %67
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x143 ((_ sign_extend 24) in57_8)))
(let ((?x116 (bvshl in.01_32 (_ bv4 32))))
(let ((?x51 (bvadd ?x116 ?x143)))
(let ((?x232 (bvsub ?x51 (_ bv48 32))))
(let (($x576 (or false false)))
(let (($x674 (or false false false)))
(let (($x22 (or $x674 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x234 (or $x22 $x576 false)))
(let (($x83 (or $x234 false false)))
(let (($x40 (or $x83 (and (distinct ?x232 (bvsub (bvadd ?x116 ((_ zero_extend 24) in57_8)) (_ bv48 32))) true))))
(let (($x154 (and (distinct (bvsub ((_ sign_extend 1) ?x51) ((_ sign_extend 1) (_ bv48 32))) ((_ sign_extend 1) ?x232)) true)))
(let ((?x165 ((_ sign_extend 1) ?x51)))
(let (($x138 (or $x22 $x576 (or (and (distinct (bvadd ((_ sign_extend 1) ?x116) ((_ sign_extend 1) ?x143)) ?x165) true)))))
(and (not (or $x138 false (or $x154))) $x40)))))))))))))))
(check-sat)
; query 10: function main, block 68, name %69
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x576 (or false false)))
(let (($x666 (not $x576)))
(and $x666 (or $x576 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true))))))
(check-sat)
; query 11: function main, block 68, name %70
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x49 (ite (bvsle (_ bv65 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x576 (or false false)))
(let (($x89 (or $x576 false false)))
(let (($x226 (not $x89)))
(and $x226 (or $x89 (and (distinct ?x49 ?x49) true))))))))
(check-sat)
; query 12: function main, block 71, name %72
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x576 (or false false)))
(let (($x666 (not $x576)))
(and $x666 (or $x576 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true))))))
(check-sat)
; query 13: function main, block 71, name %73
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x105 (ite (bvsge (_ bv70 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x576 (or false false)))
(let (($x89 (or $x576 false false)))
(let (($x226 (not $x89)))
(and $x226 (or $x89 (and (distinct ?x105 ?x105) true))))))))
(check-sat)
; query 14: function main, block 74, name %75
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x674 (or false false false)))
(let (($x22 (or $x674 (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x22) (or $x22 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvshl in.01_32 (_ bv4 32))) true))))))
(check-sat)
; query 15: function main, block 74, name %76
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x576 (or false false)))
(let (($x666 (not $x576)))
(and $x666 (or $x576 (and (distinct ((_ sign_extend 24) in57_8) ((_ zero_extend 24) in57_8)) true))))))
(check-sat)
; query 16: function main, block 74, name %77
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x11 ((_ zero_extend 24) in57_8)))
(let ((?x116 (bvshl in.01_32 (_ bv4 32))))
(let ((?x136 (bvadd ?x116 ?x11)))
(let ((?x143 ((_ sign_extend 24) in57_8)))
(let ((?x51 (bvadd ?x116 ?x143)))
(let (($x576 (or false false)))
(let (($x674 (or false false false)))
(let (($x22 (or $x674 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x234 (or $x22 $x576 false)))
(let ((?x165 ((_ sign_extend 1) ?x51)))
(let (($x138 (or $x22 $x576 (or (and (distinct (bvadd ((_ sign_extend 1) ?x116) ((_ sign_extend 1) ?x143)) ?x165) true)))))
(and (not $x138) (or $x234 (and (distinct ?x51 ?x136) true)))))))))))))))
(check-sat)
; query 17: function main, block 74, name %78
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x11 ((_ zero_extend 24) in57_8)))
(let ((?x116 (bvshl in.01_32 (_ bv4 32))))
(let ((?x136 (bvadd ?x116 ?x11)))
(let ((?x177 (bvsub ?x136 (_ bv65 32))))
(let ((?x143 ((_ sign_extend 24) in57_8)))
(let ((?x51 (bvadd ?x116 ?x143)))
(let ((?x75 (bvsub ?x51 (_ bv65 32))))
(let (($x576 (or false false)))
(let (($x674 (or false false false)))
(let (($x22 (or $x674 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x234 (or $x22 $x576 false)))
(let (($x83 (or $x234 false false)))
(let ((?x467 ((_ sign_extend 1) ?x75)))
(let ((?x165 ((_ sign_extend 1) ?x51)))
(let (($x138 (or $x22 $x576 (or (and (distinct (bvadd ((_ sign_extend 1) ?x116) ((_ sign_extend 1) ?x143)) ?x165) true)))))
(let (($x61 (or $x138 false (or (and (distinct (bvsub ?x165 ((_ sign_extend 1) (_ bv65 32))) ?x467) true)))))
(and (not $x61) (or $x83 (and (distinct ?x75 ?x177) true))))))))))))))))))))
(check-sat)
; query 18: function main, block 74, name %79
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x11 ((_ zero_extend 24) in57_8)))
(let ((?x116 (bvshl in.01_32 (_ bv4 32))))
(let ((?x136 (bvadd ?x116 ?x11)))
(let ((?x177 (bvsub ?x136 (_ bv65 32))))
(let ((?x143 ((_ sign_extend 24) in57_8)))
(let ((?x51 (bvadd ?x116 ?x143)))
(let ((?x75 (bvsub ?x51 (_ bv65 32))))
(let ((?x103 (bvadd ?x75 (_ bv10 32))))
(let (($x576 (or false false)))
(let (($x674 (or false false false)))
(let (($x22 (or $x674 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x234 (or $x22 $x576 false)))
(let (($x83 (or $x234 false false)))
(let (($x175 (and (distinct (bvadd ((_ sign_extend 1) ?x75) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x103)) true)))
(let ((?x467 ((_ sign_extend 1) ?x75)))
(let ((?x165 ((_ sign_extend 1) ?x51)))
(let (($x138 (or $x22 $x576 (or (and (distinct (bvadd ((_ sign_extend 1) ?x116) ((_ sign_extend 1) ?x143)) ?x165) true)))))
(let (($x61 (or $x138 false (or (and (distinct (bvsub ?x165 ((_ sign_extend 1) (_ bv65 32))) ?x467) true)))))
(and (not (or $x61 false (or $x175))) (or (or $x83 false false) (and (distinct ?x103 (bvadd ?x177 (_ bv10 32))) true))))))))))))))))))))))
(check-sat)
