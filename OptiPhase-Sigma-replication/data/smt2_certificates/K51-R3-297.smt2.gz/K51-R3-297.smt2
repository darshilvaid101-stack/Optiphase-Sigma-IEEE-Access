; OptiPhase-Sigma refinement certificate for sweep K51-R3-297
; query 0: function check, block 157, name %158
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x23 (and (distinct (ite (= (_ bv112233 32) in0_32) (_ bv1 1) (_ bv0 1)) (ite (= (_ bv4294967295 32) in0_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x523 (or false false false)))
(let (($x110 (not $x523)))
(and $x110 (or $x523 $x23))))))
(check-sat)
; query 1: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x230 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x523 (or false false false)))
(let (($x110 (not $x523)))
(and $x110 (or $x523 (and (distinct ?x230 ?x230) true)))))))
(check-sat)
; query 2: function set1d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x102 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x523 (or false false false)))
(let (($x110 (not $x523)))
(and $x110 (or $x523 (and (distinct ?x102 ?x102) true)))))))
(check-sat)
; query 3: function set1ds, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x42 (ite (= (_ bv4294967295 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x523 (or false false false)))
(let (($x110 (not $x523)))
(and $x110 (or $x523 (and (distinct ?x42 ?x42) true)))))))
(check-sat)
; query 4: function set2d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x102 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x523 (or false false false)))
(let (($x110 (not $x523)))
(and $x110 (or $x523 (and (distinct ?x102 ?x102) true)))))))
(check-sat)
