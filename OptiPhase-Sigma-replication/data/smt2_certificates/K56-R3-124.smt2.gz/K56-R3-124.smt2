; OptiPhase-Sigma refinement certificate for sweep K56-R3-124
; query 0: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x2370 (or false false false)))
(let (($x2665 (not $x2370)))
(and $x2665 (or $x2370 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x54 (bvadd in.01_32 (_ bv1 32))))
(let ((?x582 (bvmul ?x54 ?x54)))
(let (($x2370 (or false false false)))
(let (($x92 (or $x2370 $x2370 false)))
(and (not $x92) (or $x92 (and (distinct ?x582 ?x582) true))))))))
(check-sat)
; query 2: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x54 (bvadd in.01_32 (_ bv1 32))))
(let ((?x582 (bvmul ?x54 ?x54)))
(let ((?x84 (bvmul ?x582 (_ bv2 32))))
(let (($x2370 (or false false false)))
(let (($x92 (or $x2370 $x2370 false)))
(let (($x94 (or $x92 false false)))
(and (not $x94) (or $x94 (and (distinct ?x84 ?x84) true))))))))))
(check-sat)
; query 3: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x54 (bvadd in.01_32 (_ bv1 32))))
(let ((?x582 (bvmul ?x54 ?x54)))
(let ((?x84 (bvmul ?x582 (_ bv2 32))))
(let ((?x2366 (bvmul ?x84 (_ bv4 32))))
(let (($x2370 (or false false false)))
(let (($x92 (or $x2370 $x2370 false)))
(let (($x94 (or $x92 false false)))
(let (($x442 (or $x94 false false)))
(and (not $x442) (or $x442 (and (distinct ?x2366 ?x2366) true))))))))))))
(check-sat)
; query 4: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x562 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x2370 (or false false false)))
(let (($x2665 (not $x2370)))
(and $x2665 (or $x2370 (and (distinct ?x562 ?x562) true)))))))
(check-sat)
; query 5: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x1152 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x2370 (or false false false)))
(let (($x2665 (not $x2370)))
(and $x2665 (or $x2370 (and (distinct ?x1152 ?x1152) true)))))))
(check-sat)
; query 6: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x2370 (or false false false)))
(let (($x2665 (not $x2370)))
(and $x2665 (or $x2370 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 7: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x100 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x107 (or false false (or $x100))))
(and (not $x107) (or $x107 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x277 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x2370 (or false false false)))
(let (($x2665 (not $x2370)))
(and $x2665 (or $x2370 (and (distinct ?x277 ?x277) true)))))))
(check-sat)
; query 9: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x31 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x2370 (or false false false)))
(let (($x2665 (not $x2370)))
(and $x2665 (or $x2370 (and (distinct ?x31 ?x31) true)))))))
(check-sat)
; query 10: function matrix_add_const, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x2370 (or false false false)))
(let (($x2665 (not $x2370)))
(and $x2665 (or $x2370 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 11: function matrix_add_const, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x2370 (or false false false)))
(let (($x2665 (not $x2370)))
(and $x2665 (or $x2370 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 12: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x2663 (or false false)))
(and (not $x2663) (or $x2663 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true)))))
(check-sat)
; query 13: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x1503 ((_ sign_extend 16) in.1_16)))
(let ((?x1193 (bvadd ?x1503 (_ bv10 32))))
(let (($x1309 (and (distinct (bvadd ((_ sign_extend 1) ?x1503) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x1193)) true)))
(let (($x2663 (or false false)))
(let (($x52 (or $x2663 false (or $x1309))))
(and (not $x52) (or $x52 (and (distinct ?x1193 ?x1193) true)))))))))
(check-sat)
; query 14: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x1503 ((_ sign_extend 16) in.1_16)))
(let ((?x1193 (bvadd ?x1503 (_ bv10 32))))
(let ((?x2159 ((_ extract 15 0) ?x1193)))
(let (($x1309 (and (distinct (bvadd ((_ sign_extend 1) ?x1503) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x1193)) true)))
(let (($x2663 (or false false)))
(let (($x52 (or $x2663 false (or $x1309))))
(let (($x467 (or $x52 false)))
(and (not $x467) (or $x467 (and (distinct ?x2159 ?x2159) true)))))))))))
(check-sat)
