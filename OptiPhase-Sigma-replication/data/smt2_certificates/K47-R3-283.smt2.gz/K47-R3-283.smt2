; OptiPhase-Sigma refinement certificate for sweep K47-R3-283
; query 0: function adpcm_decoder, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x21 (ite (and (distinct (_ bv0 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x435 (or false false false)))
(let (($x253 (not $x435)))
(and $x253 (or $x435 (and (distinct ?x21 ?x21) true)))))))
(check-sat)
; query 1: function adpcm_decoder, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x435 (or false false false)))
(let (($x253 (not $x435)))
(and $x253 (or $x435 (and (distinct (bvand in.01_32 (_ bv15 32)) (bvand in.01_32 (_ bv15 32))) true))))))
(check-sat)
; query 2: function adpcm_decoder, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.012_32 () (_ BitVec 32))
(declare-fun in42_32 () (_ BitVec 32))
(assert
 (let (($x19 (and (distinct (bvadd ((_ sign_extend 1) in42_32) ((_ sign_extend 1) in.012_32)) ((_ sign_extend 1) (bvadd in42_32 in.012_32))) true)))
(let (($x287 (or false false (or $x19))))
(let (($x515 (or $x287 (and (distinct (bvadd in42_32 in.012_32) (bvadd in42_32 in.012_32)) true))))
(and (not $x287) $x515)))))
(check-sat)
; query 3: function adpcm_decoder, block 50, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.012_32 () (_ BitVec 32))
(assert
 (let (($x435 (or false false false)))
(let (($x555 (or $x435 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x26 (or $x555 (and (distinct (bvashr in.012_32 (_ bv1 32)) (bvashr in.012_32 (_ bv1 32))) true))))
(and (not $x555) $x26)))))
(check-sat)
; query 4: function adpcm_decoder, block 50, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.012_32 () (_ BitVec 32))
(declare-fun in.08_32 () (_ BitVec 32))
(assert
 (let ((?x47 (bvashr in.012_32 (_ bv1 32))))
(let ((?x42 (bvadd in.08_32 ?x47)))
(let (($x427 (and (distinct (bvadd ((_ sign_extend 1) in.08_32) ((_ sign_extend 1) ?x47)) ((_ sign_extend 1) ?x42)) true)))
(let (($x435 (or false false false)))
(let (($x555 (or $x435 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x882 (or false $x555 (or $x427))))
(and (not $x882) (or $x882 (and (distinct ?x42 ?x42) true))))))))))
(check-sat)
; query 5: function adpcm_decoder, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.012_32 () (_ BitVec 32))
(assert
 (let (($x435 (or false false false)))
(let (($x153 (or $x435 (bvuge (_ bv2 32) (_ bv32 32)))))
(let (($x52 (or $x153 (and (distinct (bvashr in.012_32 (_ bv2 32)) (bvashr in.012_32 (_ bv2 32))) true))))
(and (not $x153) $x52)))))
(check-sat)
; query 6: function adpcm_decoder, block 56, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.012_32 () (_ BitVec 32))
(declare-fun in.19_32 () (_ BitVec 32))
(assert
 (let ((?x98 (bvashr in.012_32 (_ bv2 32))))
(let ((?x120 (bvadd in.19_32 ?x98)))
(let (($x173 (and (distinct (bvadd ((_ sign_extend 1) in.19_32) ((_ sign_extend 1) ?x98)) ((_ sign_extend 1) ?x120)) true)))
(let (($x435 (or false false false)))
(let (($x153 (or $x435 (bvuge (_ bv2 32) (_ bv32 32)))))
(let (($x71 (or false $x153 (or $x173))))
(and (not $x71) (or $x71 (and (distinct ?x120 ?x120) true))))))))))
(check-sat)
; query 7: function adpcm_decoder, block 61, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.210_32 () (_ BitVec 32))
(declare-fun in.013_32 () (_ BitVec 32))
(assert
 (let ((?x116 (bvsub in.013_32 in.210_32)))
(let (($x90 (and (distinct (bvsub ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x116)) true)))
(let (($x322 (or false false (or $x90))))
(and (not $x322) (or $x322 (and (distinct ?x116 ?x116) true)))))))
(check-sat)
; query 8: function adpcm_decoder, block 63, name %64
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.013_32 () (_ BitVec 32))
(declare-fun in.210_32 () (_ BitVec 32))
(assert
 (let ((?x68 (bvadd in.210_32 in.013_32)))
(let ((?x149 (bvadd in.013_32 in.210_32)))
(let (($x24 (and (distinct (bvadd ((_ sign_extend 1) in.210_32) ((_ sign_extend 1) in.013_32)) ((_ sign_extend 1) ?x68)) true)))
(let (($x79 (and (distinct (bvadd ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x149)) true)))
(and (not (or false false (or $x79))) (or (or false false (or $x24)) (and (distinct ?x149 ?x68) true))))))))
(check-sat)
; query 9: function adpcm_decoder, block 68, name %69
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.114_32 () (_ BitVec 32))
(assert
 (let ((?x480 (ite (bvsgt (_ bv4294934528 32) in.114_32) (_ bv1 1) (_ bv0 1))))
(let (($x435 (or false false false)))
(let (($x253 (not $x435)))
(and $x253 (or $x435 (and (distinct ?x480 ?x480) true)))))))
(check-sat)
; query 10: function adpcm_decoder, block 78, name %79
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x268 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv4294967295 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv4294967295 32)))) true)))
(let (($x508 (or false false (or $x268))))
(and (not $x508) (or $x508 (and (distinct (bvadd in.02_32 (_ bv4294967295 32)) (bvadd in.02_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 11: function main, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x8 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x435 (or false false false)))
(let (($x253 (not $x435)))
(and $x253 (or $x435 (and (distinct ?x8 ?x8) true)))))))
(check-sat)
