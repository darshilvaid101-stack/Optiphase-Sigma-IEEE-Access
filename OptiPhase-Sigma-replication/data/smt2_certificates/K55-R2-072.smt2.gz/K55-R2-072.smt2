; OptiPhase-Sigma refinement certificate for sweep K55-R2-072
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x1097 (or false false)))
(let (($x969 (not $x1097)))
(and $x969 (or $x1097 (and (distinct ((_ sign_extend 16) in25_16) ((_ sign_extend 16) in25_16)) true))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let ((?x818 (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1097 (or false false)))
(let (($x68 (or $x1097 false false)))
(let (($x999 (not $x68)))
(and $x999 (or $x68 (and (distinct ?x818 ?x818) true))))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x1097 (or false false)))
(let (($x969 (not $x1097)))
(and $x969 (or $x1097 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x893 ((_ sign_extend 16) in3_16)))
(let ((?x61 (bvand ?x893 (_ bv127 32))))
(let (($x1097 (or false false)))
(let (($x68 (or $x1097 false false)))
(let (($x999 (not $x68)))
(and $x999 (or $x68 (and (distinct ?x61 ?x61) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x893 ((_ sign_extend 16) in3_16)))
(let ((?x61 (bvand ?x893 (_ bv127 32))))
(let ((?x110 ((_ extract 15 0) ?x61)))
(let (($x1097 (or false false)))
(let (($x68 (or $x1097 false false)))
(let (($x765 (or $x68 false)))
(let (($x12 (not $x765)))
(and $x12 (or $x765 (and (distinct ?x110 ?x110) true)))))))))))
(check-sat)
; query 5: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x1097 (or false false)))
(let (($x969 (not $x1097)))
(and $x969 (or $x1097 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 6: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x317 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x1097 (or false false)))
(let (($x68 (or $x1097 false false)))
(let (($x999 (not $x68)))
(and $x999 (or $x68 (and (distinct ?x317 ?x317) true))))))))
(check-sat)
; query 7: function core_bench_list, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x328 (or false false false)))
(let (($x1395 (not $x328)))
(and $x1395 (or $x328 (and (distinct (bvadd in.0_16 (_ bv1 16)) (bvadd in.0_16 (_ bv1 16))) true))))))
(check-sat)
; query 8: function core_bench_state, block 105, name %106
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x328 (or false false false)))
(let (($x1395 (not $x328)))
(and $x1395 (or $x328 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 9: function core_bench_state, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x328 (or false false false)))
(let (($x1395 (not $x328)))
(and $x1395 (or $x328 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 10: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x785 (bvadd in.01_32 (_ bv1 32))))
(let (($x440 (and (distinct ?x785 ?x785) true)))
(let (($x328 (or false false false)))
(let (($x1395 (not $x328)))
(and $x1395 (or $x328 $x440)))))))
(check-sat)
; query 11: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x785 (bvadd in.01_32 (_ bv1 32))))
(let ((?x83 (bvmul ?x785 ?x785)))
(let (($x328 (or false false false)))
(let (($x238 (or $x328 $x328 false)))
(and (not $x238) (or $x238 (and (distinct ?x83 ?x83) true))))))))
(check-sat)
; query 12: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x785 (bvadd in.01_32 (_ bv1 32))))
(let ((?x83 (bvmul ?x785 ?x785)))
(let ((?x17 (bvmul ?x83 (_ bv2 32))))
(let (($x328 (or false false false)))
(let (($x238 (or $x328 $x328 false)))
(let (($x790 (or $x238 false false)))
(and (not $x790) (or $x790 (and (distinct ?x17 ?x17) true))))))))))
(check-sat)
; query 13: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x785 (bvadd in.01_32 (_ bv1 32))))
(let ((?x83 (bvmul ?x785 ?x785)))
(let ((?x17 (bvmul ?x83 (_ bv2 32))))
(let ((?x178 (bvmul ?x17 (_ bv4 32))))
(let (($x328 (or false false false)))
(let (($x238 (or $x328 $x328 false)))
(let (($x790 (or $x238 false false)))
(let (($x298 (or $x790 false false)))
(and (not $x298) (or $x298 (and (distinct ?x178 ?x178) true))))))))))))
(check-sat)
; query 14: function core_init_matrix, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x328 (or false false false)))
(let (($x1395 (not $x328)))
(and $x1395 (or $x328 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 15: function core_init_matrix, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x328 (or false false false)))
(let (($x1395 (not $x328)))
(and $x1395 (or $x328 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 16: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x1497 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x328 (or false false false)))
(let (($x1395 (not $x328)))
(and $x1395 (or $x328 (and (distinct ?x1497 ?x1497) true)))))))
(check-sat)
; query 17: function core_init_state, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_32 () (_ BitVec 32))
(assert
 (let (($x328 (or false false false)))
(let (($x1395 (not $x328)))
(and $x1395 (or $x328 (and (distinct (bvadd in.06_32 (_ bv1 32)) (bvadd in.06_32 (_ bv1 32))) true))))))
(check-sat)
; query 18: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x764 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x328 (or false false false)))
(let (($x1395 (not $x328)))
(and $x1395 (or $x328 (and (distinct ?x764 ?x764) true)))))))
(check-sat)
; query 19: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x328 (or false false false)))
(let (($x1395 (not $x328)))
(and $x1395 (or $x328 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 20: function core_list_init, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x785 (bvadd in.01_32 (_ bv1 32))))
(let (($x440 (and (distinct ?x785 ?x785) true)))
(let (($x328 (or false false false)))
(let (($x1395 (not $x328)))
(and $x1395 (or $x328 $x440)))))))
(check-sat)
; query 21: function core_list_mergesort, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x785 (bvadd in.01_32 (_ bv1 32))))
(let (($x440 (and (distinct ?x785 ?x785) true)))
(let (($x137 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x785)) true)))
(let (($x1078 (or false false (or $x137))))
(and (not $x1078) (or $x1078 $x440)))))))
(check-sat)
; query 22: function core_list_mergesort, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x602 (ite (bvslt (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x328 (or false false false)))
(let (($x1395 (not $x328)))
(and $x1395 (or $x328 (and (distinct ?x602 ?x602) true)))))))
(check-sat)
; query 23: function core_list_mergesort, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.224_32 () (_ BitVec 32))
(assert
 (let ((?x121 (ite (= (_ bv0 32) in.224_32) (_ bv1 1) (_ bv0 1))))
(let (($x328 (or false false false)))
(let (($x1395 (not $x328)))
(and $x1395 (or $x328 (and (distinct ?x121 ?x121) true)))))))
(check-sat)
; query 24: function core_list_mergesort, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x48 (ite (= (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x328 (or false false false)))
(let (($x1395 (not $x328)))
(and $x1395 (or $x328 (and (distinct ?x48 ?x48) true)))))))
(check-sat)
; query 25: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x655 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x152 (or false false (or $x655))))
(and (not $x152) (or $x152 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 26: function core_list_mergesort, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x435 (and (distinct (bvmul ((_ sign_extend 32) in.020_32) ((_ sign_extend 32) (_ bv2 32))) ((_ sign_extend 32) (bvmul in.020_32 (_ bv2 32)))) true)))
(let (($x163 (or false false (or $x435))))
(and (not $x163) (or $x163 (and (distinct (bvmul in.020_32 (_ bv2 32)) (bvmul in.020_32 (_ bv2 32))) true))))))
(check-sat)
; query 27: function core_state_transition, block 102, name %103
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1097 (or false false)))
(let (($x969 (not $x1097)))
(and $x969 (or $x1097 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 28: function core_state_transition, block 102, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1398 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1097 (or false false)))
(let (($x68 (or $x1097 false false)))
(let (($x999 (not $x68)))
(and $x999 (or $x68 (and (distinct ?x1398 ?x1398) true))))))))
(check-sat)
; query 29: function core_state_transition, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1097 (or false false)))
(let (($x969 (not $x1097)))
(and $x969 (or $x1097 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 30: function core_state_transition, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x187 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1097 (or false false)))
(let (($x68 (or $x1097 false false)))
(let (($x999 (not $x68)))
(and $x999 (or $x68 (and (distinct ?x187 ?x187) true))))))))
(check-sat)
; query 31: function core_state_transition, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1097 (or false false)))
(let (($x969 (not $x1097)))
(and $x969 (or $x1097 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 32: function core_state_transition, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1398 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1097 (or false false)))
(let (($x68 (or $x1097 false false)))
(let (($x999 (not $x68)))
(and $x999 (or $x68 (and (distinct ?x1398 ?x1398) true))))))))
(check-sat)
; query 33: function core_state_transition, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1097 (or false false)))
(let (($x969 (not $x1097)))
(and $x969 (or $x1097 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 34: function core_state_transition, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x241 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1097 (or false false)))
(let (($x68 (or $x1097 false false)))
(let (($x999 (not $x68)))
(and $x999 (or $x68 (and (distinct ?x241 ?x241) true))))))))
(check-sat)
; query 35: function core_state_transition, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1097 (or false false)))
(let (($x969 (not $x1097)))
(and $x969 (or $x1097 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 36: function core_state_transition, block 51, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x241 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1097 (or false false)))
(let (($x68 (or $x1097 false false)))
(let (($x999 (not $x68)))
(and $x999 (or $x68 (and (distinct ?x241 ?x241) true))))))))
(check-sat)
; query 37: function core_state_transition, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1097 (or false false)))
(let (($x969 (not $x1097)))
(and $x969 (or $x1097 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 38: function core_state_transition, block 64, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x241 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1097 (or false false)))
(let (($x68 (or $x1097 false false)))
(let (($x999 (not $x68)))
(and $x999 (or $x68 (and (distinct ?x241 ?x241) true))))))))
(check-sat)
; query 39: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x1355 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x328 (or false false false)))
(let (($x1395 (not $x328)))
(and $x1395 (or $x328 (and (distinct ?x1355 ?x1355) true)))))))
(check-sat)
; query 40: function core_state_transition, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1097 (or false false)))
(let (($x969 (not $x1097)))
(and $x969 (or $x1097 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 41: function core_state_transition, block 80, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1328 (ite (= (_ bv69 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1097 (or false false)))
(let (($x68 (or $x1097 false false)))
(let (($x999 (not $x68)))
(and $x999 (or $x68 (and (distinct ?x1328 ?x1328) true))))))))
(check-sat)
; query 42: function core_state_transition, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1097 (or false false)))
(let (($x969 (not $x1097)))
(and $x969 (or $x1097 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 43: function core_state_transition, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1410 (ite (= (_ bv101 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1097 (or false false)))
(let (($x68 (or $x1097 false false)))
(let (($x999 (not $x68)))
(and $x999 (or $x68 (and (distinct ?x1410 ?x1410) true))))))))
(check-sat)
; query 44: function core_state_transition, block 99, name %100
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1097 (or false false)))
(let (($x969 (not $x1097)))
(and $x969 (or $x1097 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 45: function core_state_transition, block 99, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x187 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1097 (or false false)))
(let (($x68 (or $x1097 false false)))
(let (($x999 (not $x68)))
(and $x999 (or $x68 (and (distinct ?x187 ?x187) true))))))))
(check-sat)
; query 46: function crcu8, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x1097 (or false false)))
(let (($x969 (not $x1097)))
(and $x969 (or $x1097 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 47: function crcu8, block 19, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x1364 ((_ zero_extend 16) in.01_16)))
(let ((?x171 (bvxor ?x1364 (_ bv16386 32))))
(let (($x1097 (or false false)))
(let (($x68 (or $x1097 false false)))
(let (($x999 (not $x68)))
(and $x999 (or $x68 (and (distinct ?x171 ?x171) true)))))))))
(check-sat)
; query 48: function crcu8, block 19, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x1364 ((_ zero_extend 16) in.01_16)))
(let ((?x171 (bvxor ?x1364 (_ bv16386 32))))
(let ((?x389 ((_ extract 15 0) ?x171)))
(let (($x1097 (or false false)))
(let (($x68 (or $x1097 false false)))
(let (($x765 (or $x68 false)))
(let (($x12 (not $x765)))
(and $x12 (or $x765 (and (distinct ?x389 ?x389) true)))))))))))
(check-sat)
; query 49: function crcu8, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x1097 (or false false)))
(let (($x969 (not $x1097)))
(and $x969 (or $x1097 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 50: function crcu8, block 29, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1555 ((_ zero_extend 16) in27_16)))
(let ((?x1309 (bvor ?x1555 (_ bv32768 32))))
(let (($x1097 (or false false)))
(let (($x68 (or $x1097 false false)))
(let (($x999 (not $x68)))
(and $x999 (or $x68 (and (distinct ?x1309 ?x1309) true)))))))))
(check-sat)
; query 51: function crcu8, block 29, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1555 ((_ zero_extend 16) in27_16)))
(let ((?x1309 (bvor ?x1555 (_ bv32768 32))))
(let ((?x44 ((_ extract 15 0) ?x1309)))
(let (($x1097 (or false false)))
(let (($x68 (or $x1097 false false)))
(let (($x765 (or $x68 false)))
(let (($x12 (not $x765)))
(and $x12 (or $x765 (and (distinct ?x44 ?x44) true)))))))))))
(check-sat)
; query 52: function crcu8, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x1097 (or false false)))
(let (($x969 (not $x1097)))
(and $x969 (or $x1097 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 53: function crcu8, block 33, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1555 ((_ zero_extend 16) in27_16)))
(let ((?x815 (bvand ?x1555 (_ bv32767 32))))
(let (($x1097 (or false false)))
(let (($x68 (or $x1097 false false)))
(let (($x999 (not $x68)))
(and $x999 (or $x68 (and (distinct ?x815 ?x815) true)))))))))
(check-sat)
; query 54: function crcu8, block 33, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1555 ((_ zero_extend 16) in27_16)))
(let ((?x815 (bvand ?x1555 (_ bv32767 32))))
(let ((?x578 ((_ extract 15 0) ?x815)))
(let (($x1097 (or false false)))
(let (($x68 (or $x1097 false false)))
(let (($x765 (or $x68 false)))
(let (($x12 (not $x765)))
(and $x12 (or $x765 (and (distinct ?x578 ?x578) true)))))))))))
(check-sat)
; query 55: function crcu8, block 38, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_8 () (_ BitVec 8))
(assert
 (let (($x328 (or false false false)))
(let (($x1395 (not $x328)))
(and $x1395 (or $x328 (and (distinct (bvadd in.02_8 (_ bv1 8)) (bvadd in.02_8 (_ bv1 8))) true))))))
(check-sat)
; query 56: function crcu8, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x193 ((_ extract 7 0) in.01_16)))
(let ((?x831 ((_ zero_extend 24) ?x193)))
(let (($x1097 (or false false)))
(let (($x253 (or $x1097 false)))
(and (not $x253) (or $x253 (and (distinct ?x831 ?x831) true))))))))
(check-sat)
; query 57: function crcu8, block 6, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x193 ((_ extract 7 0) in.01_16)))
(let ((?x831 ((_ zero_extend 24) ?x193)))
(let ((?x1361 (bvand ?x831 (_ bv1 32))))
(let (($x1097 (or false false)))
(let (($x253 (or $x1097 false)))
(let (($x1396 (or $x253 false false)))
(and (not $x1396) (or $x1396 (and (distinct ?x1361 ?x1361) true))))))))))
(check-sat)
; query 58: function crcu8, block 6, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x193 ((_ extract 7 0) in.01_16)))
(let ((?x831 ((_ zero_extend 24) ?x193)))
(let ((?x1361 (bvand ?x831 (_ bv1 32))))
(let ((?x1362 ((_ zero_extend 24) in.0_8)))
(let ((?x309 (bvand ?x1362 (_ bv1 32))))
(let ((?x1363 (bvxor ?x309 ?x1361)))
(let (($x1097 (or false false)))
(let (($x253 (or $x1097 false)))
(let (($x1396 (or $x253 false false)))
(let (($x68 (or $x1097 false false)))
(let (($x1338 (or $x68 $x1396 false)))
(and (not $x1338) (or $x1338 (and (distinct ?x1363 ?x1363) true)))))))))))))))
(check-sat)
; query 59: function crcu8, block 6, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x193 ((_ extract 7 0) in.01_16)))
(let ((?x831 ((_ zero_extend 24) ?x193)))
(let ((?x1361 (bvand ?x831 (_ bv1 32))))
(let ((?x1362 ((_ zero_extend 24) in.0_8)))
(let ((?x309 (bvand ?x1362 (_ bv1 32))))
(let ((?x1363 (bvxor ?x309 ?x1361)))
(let ((?x1340 ((_ extract 7 0) ?x1363)))
(let (($x1097 (or false false)))
(let (($x253 (or $x1097 false)))
(let (($x1396 (or $x253 false false)))
(let (($x68 (or $x1097 false false)))
(let (($x1338 (or $x68 $x1396 false)))
(let (($x354 (or $x1338 false)))
(and (not $x354) (or $x354 (and (distinct ?x1340 ?x1340) true)))))))))))))))))
(check-sat)
; query 60: function crcu8, block 6, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x1097 (or false false)))
(let (($x969 (not $x1097)))
(and $x969 (or $x1097 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 61: function crcu8, block 6, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1362 ((_ zero_extend 24) in.0_8)))
(let ((?x142 (bvashr ?x1362 (_ bv1 32))))
(let (($x1097 (or false false)))
(let (($x68 (or $x1097 false false)))
(let (($x1385 (or $x68 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not $x1385) (or $x1385 (and (distinct ?x142 ?x142) true)))))))))
(check-sat)
; query 62: function crcu8, block 6, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1362 ((_ zero_extend 24) in.0_8)))
(let ((?x142 (bvashr ?x1362 (_ bv1 32))))
(let ((?x1531 ((_ extract 7 0) ?x142)))
(let (($x1097 (or false false)))
(let (($x68 (or $x1097 false false)))
(let (($x1385 (or $x68 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x1481 (or $x1385 false)))
(and (not $x1481) (or $x1481 (and (distinct ?x1531 ?x1531) true)))))))))))
(check-sat)
; query 63: function crcu8, block 6, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x193 ((_ extract 7 0) in.01_16)))
(let ((?x831 ((_ zero_extend 24) ?x193)))
(let ((?x1361 (bvand ?x831 (_ bv1 32))))
(let ((?x1362 ((_ zero_extend 24) in.0_8)))
(let ((?x309 (bvand ?x1362 (_ bv1 32))))
(let ((?x1363 (bvxor ?x309 ?x1361)))
(let ((?x1340 ((_ extract 7 0) ?x1363)))
(let ((?x133 ((_ zero_extend 24) ?x1340)))
(let (($x1097 (or false false)))
(let (($x253 (or $x1097 false)))
(let (($x1396 (or $x253 false false)))
(let (($x68 (or $x1097 false false)))
(let (($x1338 (or $x68 $x1396 false)))
(let (($x354 (or $x1338 false)))
(let (($x173 (or $x354 false)))
(and (not $x173) (or $x173 (and (distinct ?x133 ?x133) true)))))))))))))))))))
(check-sat)
; query 64: function crcu8, block 6, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x193 ((_ extract 7 0) in.01_16)))
(let ((?x831 ((_ zero_extend 24) ?x193)))
(let ((?x1361 (bvand ?x831 (_ bv1 32))))
(let ((?x1362 ((_ zero_extend 24) in.0_8)))
(let ((?x309 (bvand ?x1362 (_ bv1 32))))
(let ((?x1363 (bvxor ?x309 ?x1361)))
(let ((?x1340 ((_ extract 7 0) ?x1363)))
(let ((?x133 ((_ zero_extend 24) ?x1340)))
(let ((?x418 (ite (= (_ bv1 32) ?x133) (_ bv1 1) (_ bv0 1))))
(let (($x1097 (or false false)))
(let (($x253 (or $x1097 false)))
(let (($x1396 (or $x253 false false)))
(let (($x68 (or $x1097 false false)))
(let (($x1338 (or $x68 $x1396 false)))
(let (($x354 (or $x1338 false)))
(let (($x173 (or $x354 false)))
(let (($x807 (or $x173 false false)))
(and (not $x807) (or $x807 (and (distinct ?x418 ?x418) true)))))))))))))))))))))
(check-sat)
; query 65: function crcu8, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x1097 (or false false)))
(let (($x969 (not $x1097)))
(and $x969 (or $x1097 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 66: function crcu8, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1362 ((_ zero_extend 24) in.0_8)))
(let ((?x309 (bvand ?x1362 (_ bv1 32))))
(let (($x1097 (or false false)))
(let (($x68 (or $x1097 false false)))
(let (($x999 (not $x68)))
(and $x999 (or $x68 (and (distinct ?x309 ?x309) true)))))))))
(check-sat)
; query 67: function crcu8, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x1097 (or false false)))
(let (($x969 (not $x1097)))
(and $x969 (or $x1097 (and (distinct ((_ extract 7 0) in.01_16) ((_ extract 7 0) in.01_16)) true))))))
(check-sat)
; query 68: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x953 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1573 ((_ zero_extend 31) ?x953)))
(let ((?x484 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x809 ((_ zero_extend 31) ?x484)))
(let ((?x1502 (bvand ?x809 ?x1573)))
(let ((?x810 (ite (and (distinct (_ bv0 32) ?x1502) true) (_ bv1 1) (_ bv0 1))))
(let ((?x832 ((_ zero_extend 63) ?x810)))
(let (($x1097 (or false false)))
(let (($x68 (or $x1097 false false)))
(let (($x765 (or $x68 false)))
(let (($x513 (or $x765 $x765 false)))
(let (($x332 (or $x513 false false)))
(let (($x598 (or $x332 false)))
(and (not $x598) (or $x598 (and (distinct ?x832 ?x832) true)))))))))))))))))
(check-sat)
; query 69: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x953 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1573 ((_ zero_extend 31) ?x953)))
(let ((?x484 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x809 ((_ zero_extend 31) ?x484)))
(let ((?x1502 (bvand ?x809 ?x1573)))
(let ((?x810 (ite (and (distinct (_ bv0 32) ?x1502) true) (_ bv1 1) (_ bv0 1))))
(let (($x424 (= (_ bv1 1) ?x810)))
(let ((?x763 (ite $x424 (_ bv1 32) (_ bv0 32))))
(let (($x1097 (or false false)))
(let (($x68 (or $x1097 false false)))
(let (($x765 (or $x68 false)))
(let (($x513 (or $x765 $x765 false)))
(let (($x332 (or $x513 false false)))
(let (($x494 (or $x332 (ite $x424 false false))))
(and (not $x494) (or $x494 (and (distinct ?x763 ?x763) true))))))))))))))))))
(check-sat)
; query 70: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x953 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1573 ((_ zero_extend 31) ?x953)))
(let ((?x484 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x809 ((_ zero_extend 31) ?x484)))
(let ((?x1502 (bvand ?x809 ?x1573)))
(let ((?x810 (ite (and (distinct (_ bv0 32) ?x1502) true) (_ bv1 1) (_ bv0 1))))
(let (($x424 (= (_ bv1 1) ?x810)))
(let ((?x763 (ite $x424 (_ bv1 32) (_ bv0 32))))
(let ((?x1039 ((_ extract 7 0) ?x763)))
(let (($x1097 (or false false)))
(let (($x68 (or $x1097 false false)))
(let (($x765 (or $x68 false)))
(let (($x513 (or $x765 $x765 false)))
(let (($x332 (or $x513 false false)))
(let (($x494 (or $x332 (ite $x424 false false))))
(let (($x294 (or $x494 false)))
(and (not $x294) (or $x294 (and (distinct ?x1039 ?x1039) true))))))))))))))))))))
(check-sat)
; query 71: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x1097 (or false false)))
(let (($x969 (not $x1097)))
(and $x969 (or $x1097 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 72: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x484 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1097 (or false false)))
(let (($x68 (or $x1097 false false)))
(let (($x999 (not $x68)))
(and $x999 (or $x68 (and (distinct ?x484 ?x484) true))))))))
(check-sat)
; query 73: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x484 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x809 ((_ zero_extend 31) ?x484)))
(let (($x1097 (or false false)))
(let (($x68 (or $x1097 false false)))
(let (($x765 (or $x68 false)))
(let (($x12 (not $x765)))
(and $x12 (or $x765 (and (distinct ?x809 ?x809) true))))))))))
(check-sat)
; query 74: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x1097 (or false false)))
(let (($x969 (not $x1097)))
(and $x969 (or $x1097 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 75: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x953 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1097 (or false false)))
(let (($x68 (or $x1097 false false)))
(let (($x999 (not $x68)))
(and $x999 (or $x68 (and (distinct ?x953 ?x953) true))))))))
(check-sat)
; query 76: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x953 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1573 ((_ zero_extend 31) ?x953)))
(let (($x1097 (or false false)))
(let (($x68 (or $x1097 false false)))
(let (($x765 (or $x68 false)))
(let (($x12 (not $x765)))
(and $x12 (or $x765 (and (distinct ?x1573 ?x1573) true))))))))))
(check-sat)
; query 77: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x953 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1573 ((_ zero_extend 31) ?x953)))
(let ((?x484 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x809 ((_ zero_extend 31) ?x484)))
(let ((?x1502 (bvand ?x809 ?x1573)))
(let (($x1097 (or false false)))
(let (($x68 (or $x1097 false false)))
(let (($x765 (or $x68 false)))
(let (($x513 (or $x765 $x765 false)))
(and (not $x513) (or $x513 (and (distinct ?x1502 ?x1502) true)))))))))))))
(check-sat)
; query 78: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x953 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1573 ((_ zero_extend 31) ?x953)))
(let ((?x484 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x809 ((_ zero_extend 31) ?x484)))
(let ((?x1502 (bvand ?x809 ?x1573)))
(let ((?x810 (ite (and (distinct (_ bv0 32) ?x1502) true) (_ bv1 1) (_ bv0 1))))
(let (($x1097 (or false false)))
(let (($x68 (or $x1097 false false)))
(let (($x765 (or $x68 false)))
(let (($x513 (or $x765 $x765 false)))
(let (($x332 (or $x513 false false)))
(and (not $x332) (or $x332 (and (distinct ?x810 ?x810) true)))))))))))))))
(check-sat)
; query 79: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1081 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x328 (or false false false)))
(let (($x1395 (not $x328)))
(and $x1395 (or $x328 (and (distinct ?x1081 ?x1081) true)))))))
(check-sat)
; query 80: function matrix_add_const, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x328 (or false false false)))
(let (($x1395 (not $x328)))
(and $x1395 (or $x328 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 81: function matrix_add_const, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x785 (bvadd in.01_32 (_ bv1 32))))
(let (($x440 (and (distinct ?x785 ?x785) true)))
(let (($x328 (or false false false)))
(let (($x1395 (not $x328)))
(and $x1395 (or $x328 $x440)))))))
(check-sat)
; query 82: function matrix_mul_const, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x328 (or false false false)))
(let (($x1395 (not $x328)))
(and $x1395 (or $x328 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 83: function matrix_mul_const, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x785 (bvadd in.01_32 (_ bv1 32))))
(let (($x440 (and (distinct ?x785 ?x785) true)))
(let (($x328 (or false false false)))
(let (($x1395 (not $x328)))
(and $x1395 (or $x328 $x440)))))))
(check-sat)
; query 84: function matrix_mul_matrix, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x328 (or false false false)))
(let (($x1395 (not $x328)))
(and $x1395 (or $x328 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 85: function matrix_mul_matrix, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x785 (bvadd in.01_32 (_ bv1 32))))
(let (($x440 (and (distinct ?x785 ?x785) true)))
(let (($x328 (or false false false)))
(let (($x1395 (not $x328)))
(and $x1395 (or $x328 $x440)))))))
(check-sat)
; query 86: function matrix_mul_matrix, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x328 (or false false false)))
(let (($x1395 (not $x328)))
(and $x1395 (or $x328 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 87: function matrix_mul_matrix_bitextract, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x328 (or false false false)))
(let (($x1395 (not $x328)))
(and $x1395 (or $x328 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 88: function matrix_mul_matrix_bitextract, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x785 (bvadd in.01_32 (_ bv1 32))))
(let (($x440 (and (distinct ?x785 ?x785) true)))
(let (($x328 (or false false false)))
(let (($x1395 (not $x328)))
(and $x1395 (or $x328 $x440)))))))
(check-sat)
; query 89: function matrix_mul_matrix_bitextract, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x328 (or false false false)))
(let (($x1395 (not $x328)))
(and $x1395 (or $x328 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 90: function matrix_mul_vect, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x328 (or false false false)))
(let (($x1395 (not $x328)))
(and $x1395 (or $x328 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 91: function matrix_mul_vect, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x785 (bvadd in.01_32 (_ bv1 32))))
(let (($x440 (and (distinct ?x785 ?x785) true)))
(let (($x328 (or false false false)))
(let (($x1395 (not $x328)))
(and $x1395 (or $x328 $x440)))))))
(check-sat)
; query 92: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x1097 (or false false)))
(let (($x969 (not $x1097)))
(and $x969 (or $x1097 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 93: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x462 ((_ sign_extend 16) in.1_16)))
(let ((?x1406 (bvadd ?x462 (_ bv10 32))))
(let (($x189 (and (distinct (bvadd ((_ sign_extend 1) ?x462) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x1406)) true)))
(let (($x1097 (or false false)))
(let (($x926 (or $x1097 false (or $x189))))
(and (not $x926) (or $x926 (and (distinct ?x1406 ?x1406) true)))))))))
(check-sat)
; query 94: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x462 ((_ sign_extend 16) in.1_16)))
(let ((?x1406 (bvadd ?x462 (_ bv10 32))))
(let ((?x1050 ((_ extract 15 0) ?x1406)))
(let (($x189 (and (distinct (bvadd ((_ sign_extend 1) ?x462) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x1406)) true)))
(let (($x1097 (or false false)))
(let (($x926 (or $x1097 false (or $x189))))
(let (($x1008 (or $x926 false)))
(and (not $x1008) (or $x1008 (and (distinct ?x1050 ?x1050) true)))))))))))
(check-sat)
; query 95: function matrix_sum, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x470 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x328 (or false false false)))
(let (($x1395 (not $x328)))
(and $x1395 (or $x328 (and (distinct ?x470 ?x470) true)))))))
(check-sat)
; query 96: function matrix_sum, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x470 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let ((?x786 ((_ zero_extend 63) ?x470)))
(let (($x328 (or false false false)))
(let (($x825 (or $x328 false)))
(and (not $x825) (or $x825 (and (distinct ?x786 ?x786) true))))))))
(check-sat)
; query 97: function matrix_sum, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x470 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x925 (= (_ bv1 1) ?x470)))
(let ((?x1548 (ite $x925 (_ bv1 32) (_ bv0 32))))
(let (($x328 (or false false false)))
(let (($x1086 (or $x328 (ite $x925 false false))))
(and (not $x1086) (or $x1086 (and (distinct ?x1548 ?x1548) true)))))))))
(check-sat)
; query 98: function matrix_sum, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x1097 (or false false)))
(let (($x969 (not $x1097)))
(and $x969 (or $x1097 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 99: function matrix_sum, block 22, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x470 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x925 (= (_ bv1 1) ?x470)))
(let ((?x1548 (ite $x925 (_ bv1 32) (_ bv0 32))))
(let ((?x462 ((_ sign_extend 16) in.1_16)))
(let ((?x27 (bvadd ?x462 ?x1548)))
(let (($x203 (and (distinct (bvadd ((_ sign_extend 1) ?x462) ((_ sign_extend 1) ?x1548)) ((_ sign_extend 1) ?x27)) true)))
(let (($x328 (or false false false)))
(let (($x1086 (or $x328 (ite $x925 false false))))
(let (($x1097 (or false false)))
(let (($x960 (or $x1097 $x1086 (or $x203))))
(and (not $x960) (or $x960 (and (distinct ?x27 ?x27) true))))))))))))))
(check-sat)
; query 100: function matrix_sum, block 22, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x470 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x925 (= (_ bv1 1) ?x470)))
(let ((?x1548 (ite $x925 (_ bv1 32) (_ bv0 32))))
(let ((?x462 ((_ sign_extend 16) in.1_16)))
(let ((?x27 (bvadd ?x462 ?x1548)))
(let ((?x910 ((_ extract 15 0) ?x27)))
(let (($x203 (and (distinct (bvadd ((_ sign_extend 1) ?x462) ((_ sign_extend 1) ?x1548)) ((_ sign_extend 1) ?x27)) true)))
(let (($x328 (or false false false)))
(let (($x1086 (or $x328 (ite $x925 false false))))
(let (($x1097 (or false false)))
(let (($x960 (or $x1097 $x1086 (or $x203))))
(let (($x1556 (or $x960 false)))
(and (not $x1556) (or $x1556 (and (distinct ?x910 ?x910) true))))))))))))))))
(check-sat)
; query 101: function matrix_sum, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x328 (or false false false)))
(let (($x1395 (not $x328)))
(and $x1395 (or $x328 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 102: function matrix_sum, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x785 (bvadd in.01_32 (_ bv1 32))))
(let (($x440 (and (distinct ?x785 ?x785) true)))
(let (($x328 (or false false false)))
(let (($x1395 (not $x328)))
(and $x1395 (or $x328 $x440)))))))
(check-sat)
; query 103: function parseval, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.23_32 () (_ BitVec 32))
(assert
 (let (($x1116 (and (distinct (bvmul ((_ sign_extend 32) in.23_32) ((_ sign_extend 32) (_ bv1024 32))) ((_ sign_extend 32) (bvmul in.23_32 (_ bv1024 32)))) true)))
(let (($x438 (or false false (or $x1116))))
(and (not $x438) (or $x438 (and (distinct (bvmul in.23_32 (_ bv1024 32)) (bvmul in.23_32 (_ bv1024 32))) true))))))
(check-sat)
; query 104: function parseval, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.34_32 () (_ BitVec 32))
(assert
 (let (($x767 (and (distinct (bvmul ((_ sign_extend 32) in.34_32) ((_ sign_extend 32) (_ bv1048576 32))) ((_ sign_extend 32) (bvmul in.34_32 (_ bv1048576 32)))) true)))
(let (($x1005 (or false false (or $x767))))
(and (not $x1005) (or $x1005 (and (distinct (bvmul in.34_32 (_ bv1048576 32)) (bvmul in.34_32 (_ bv1048576 32))) true))))))
(check-sat)
; query 105: function partition_memory, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x328 (or false false false)))
(let (($x1395 (not $x328)))
(and $x1395 (or $x328 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
