; OptiPhase-Sigma refinement certificate for sweep K10-R3-306
; query 0: function xmalloc, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in7_32 () (_ BitVec 32))
(assert
 (let ((?x175 (ite (and (distinct (_ bv0 32) in7_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x138 (or false false false)))
(and (not $x138) (or $x138 (and (distinct ?x175 ?x175) true))))))
(check-sat)
