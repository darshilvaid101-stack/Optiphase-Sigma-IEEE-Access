; OptiPhase-Sigma refinement certificate for sweep K45-R3-265
; query 0: function Index_to_frequency, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x753 (ite (bvuge in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x59 (or false false false)))
(let (($x460 (not $x59)))
(and $x460 (or $x59 (and (distinct ?x753 ?x753) true)))))))
(check-sat)
; query 1: function IsPowerOfTwo, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x59 (or false false false)))
(let (($x460 (not $x59)))
(and $x460 (or $x59 (and (distinct (bvsub in0_32 (_ bv1 32)) (bvsub in0_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function IsPowerOfTwo, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x190 (bvsub in0_32 (_ bv1 32))))
(let ((?x26 (bvand in0_32 ?x190)))
(let (($x59 (or false false false)))
(let (($x49 (or false $x59 false)))
(and (not $x49) (or $x49 (and (distinct ?x26 ?x26) true))))))))
(check-sat)
; query 3: function IsPowerOfTwo, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x98 (ite (and (distinct (_ bv0 32) (bvand in0_32 (bvsub in0_32 (_ bv1 32)))) true) (_ bv1 1) (_ bv0 1))))
(let (($x59 (or false false false)))
(let (($x49 (or false $x59 false)))
(let (($x146 (or $x49 false false)))
(and (not $x146) (or $x146 (and (distinct ?x98 ?x98) true))))))))
(check-sat)
; query 4: function IsPowerOfTwo, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x405 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x59 (or false false false)))
(let (($x460 (not $x59)))
(and $x460 (or $x59 (and (distinct ?x405 ?x405) true)))))))
(check-sat)
; query 5: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x405 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x59 (or false false false)))
(let (($x460 (not $x59)))
(and $x460 (or $x59 (and (distinct ?x405 ?x405) true)))))))
(check-sat)
; query 6: function fft_float, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x6 (ite (and (distinct (_ bv0 32) in1_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x59 (or false false false)))
(let (($x460 (not $x59)))
(and $x460 (or $x59 (and (distinct ?x6 ?x6) true)))))))
(check-sat)
; query 7: function main, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x450 (ite (= (_ bv4 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x59 (or false false false)))
(let (($x460 (not $x59)))
(and $x460 (or $x59 (and (distinct ?x450 ?x450) true)))))))
(check-sat)
; query 8: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x96 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x59 (or false false false)))
(let (($x460 (not $x59)))
(and $x460 (or $x59 (and (distinct ?x96 ?x96) true)))))))
(check-sat)
