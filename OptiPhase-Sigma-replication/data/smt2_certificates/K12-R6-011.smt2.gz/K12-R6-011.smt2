; OptiPhase-Sigma refinement certificate for sweep K12-R6-011
