; OptiPhase-Sigma refinement certificate for sweep K09-R2-019
; query 0: function init_array, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x118 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x49 (or false false (or $x118))))
(and (not $x49) (or $x49 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function init_array, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x87 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x44 (or false false (or $x87))))
(and (not $x44) (or $x44 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function init_array, block 49, name %50
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x115 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x54 (or false false (or $x115))))
(and (not $x54) (or $x54 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 3: function init_array, block 52, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x86 (and (distinct (bvadd ((_ sign_extend 1) in.12_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.12_32 (_ bv1 32)))) true)))
(let (($x12 (or false false (or $x86))))
(and (not $x12) (or $x12 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 4: function init_array, block 72, name %73
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let (($x20 (and (distinct (bvadd ((_ sign_extend 1) in.2_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.2_32 (_ bv1 32)))) true)))
(let (($x124 (or false false (or $x20))))
(and (not $x124) (or $x124 (and (distinct (bvadd in.2_32 (_ bv1 32)) (bvadd in.2_32 (_ bv1 32))) true))))))
(check-sat)
; query 5: function init_array, block 75, name %76
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.23_32 () (_ BitVec 32))
(assert
 (let (($x30 (and (distinct (bvadd ((_ sign_extend 1) in.23_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.23_32 (_ bv1 32)))) true)))
(let (($x70 (or false false (or $x30))))
(and (not $x70) (or $x70 (and (distinct (bvadd in.23_32 (_ bv1 32)) (bvadd in.23_32 (_ bv1 32))) true))))))
(check-sat)
; query 6: function init_array, block 94, name %95
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.3_32 () (_ BitVec 32))
(assert
 (let (($x31 (and (distinct (bvadd ((_ sign_extend 1) in.3_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.3_32 (_ bv1 32)))) true)))
(let (($x43 (or false false (or $x31))))
(and (not $x43) (or $x43 (and (distinct (bvadd in.3_32 (_ bv1 32)) (bvadd in.3_32 (_ bv1 32))) true))))))
(check-sat)
; query 7: function init_array, block 97, name %98
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.34_32 () (_ BitVec 32))
(assert
 (let (($x60 (and (distinct (bvadd ((_ sign_extend 1) in.34_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.34_32 (_ bv1 32)))) true)))
(let (($x66 (or false false (or $x60))))
(and (not $x66) (or $x66 (and (distinct (bvadd in.34_32 (_ bv1 32)) (bvadd in.34_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function kernel_2mm, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x118 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x49 (or false false (or $x118))))
(and (not $x49) (or $x49 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 9: function kernel_2mm, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x87 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x44 (or false false (or $x87))))
(and (not $x44) (or $x44 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 10: function kernel_2mm, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_32 () (_ BitVec 32))
(assert
 (let (($x113 (and (distinct (bvadd ((_ sign_extend 1) in.03_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.03_32 (_ bv1 32)))) true)))
(let (($x103 (or false false (or $x113))))
(and (not $x103) (or $x103 (and (distinct (bvadd in.03_32 (_ bv1 32)) (bvadd in.03_32 (_ bv1 32))) true))))))
(check-sat)
; query 11: function kernel_2mm, block 82, name %83
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x115 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x54 (or false false (or $x115))))
(and (not $x54) (or $x54 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 12: function kernel_2mm, block 85, name %86
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x86 (and (distinct (bvadd ((_ sign_extend 1) in.12_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.12_32 (_ bv1 32)))) true)))
(let (($x12 (or false false (or $x86))))
(and (not $x12) (or $x12 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 13: function kernel_2mm, block 88, name %89
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.14_32 () (_ BitVec 32))
(assert
 (let (($x95 (and (distinct (bvadd ((_ sign_extend 1) in.14_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.14_32 (_ bv1 32)))) true)))
(let (($x127 (or false false (or $x95))))
(and (not $x127) (or $x127 (and (distinct (bvadd in.14_32 (_ bv1 32)) (bvadd in.14_32 (_ bv1 32))) true))))))
(check-sat)
; query 14: function polybench_flush_cache, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x87 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x44 (or false false (or $x87))))
(and (not $x44) (or $x44 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 15: function print_array, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x118 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x49 (or false false (or $x118))))
(and (not $x49) (or $x49 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 16: function print_array, block 32, name %33
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x87 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x44 (or false false (or $x87))))
(and (not $x44) (or $x44 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 17: function xmalloc, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in7_32 () (_ BitVec 32))
(assert
 (let ((?x145 (ite (and (distinct (_ bv0 32) in7_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x104 (or false false false)))
(and (not $x104) (or $x104 (and (distinct ?x145 ?x145) true))))))
(check-sat)
