; OptiPhase-Sigma refinement certificate for sweep K48-R6-010
; query 0: function APCM_inverse_quantization, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x776 (or false false)))
(let (($x133 (not $x776)))
(and $x133 (or $x776 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 1: function APCM_inverse_quantization, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1835 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x776 (or false false)))
(let (($x61 (or $x776 false false)))
(let (($x156 (not $x61)))
(and $x156 (or $x61 (and (distinct ?x1835 ?x1835) true))))))))
(check-sat)
; query 2: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x776 (or false false)))
(let (($x133 (not $x776)))
(and $x133 (or $x776 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 3: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x106 (ite (bvslt (_ bv15 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x776 (or false false)))
(let (($x61 (or $x776 false false)))
(let (($x156 (not $x61)))
(and $x156 (or $x61 (and (distinct ?x106 ?x106) true))))))))
(check-sat)
; query 4: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x776 (or false false)))
(let (($x133 (not $x776)))
(and $x133 (or $x776 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 5: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x58 (ite (bvsgt (_ bv40 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x776 (or false false)))
(let (($x61 (or $x776 false false)))
(let (($x156 (not $x61)))
(and $x156 (or $x61 (and (distinct ?x58 ?x58) true))))))))
(check-sat)
; query 6: function RPE_grid_positioning, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x776 (or false false)))
(let (($x133 (not $x776)))
(and $x133 (or $x776 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 7: function RPE_grid_positioning, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x525 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1867 (and (distinct ?x525 ?x525) true)))
(let (($x776 (or false false)))
(let (($x216 (or false $x776 false)))
(and (not $x216) (or $x216 $x1867)))))))
(check-sat)
; query 8: function gsm_L_add, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x596 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x1839 (or false false false)))
(let (($x1838 (not $x1839)))
(and $x1838 (or $x1839 (and (distinct ?x596 ?x596) true)))))))
(check-sat)
; query 9: function gsm_L_add, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x92 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvadd in0_64 in1_64))) true)))
(let (($x99 (or false false (or $x92))))
(let (($x1847 (or $x99 (and (distinct (bvadd in0_64 in1_64) (bvadd in0_64 in1_64)) true))))
(and (not $x99) $x1847)))))
(check-sat)
; query 10: function gsm_L_add, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1840 (bvadd in0_64 (_ bv1 64))))
(let ((?x514 (bvsub (_ bv0 64) ?x1840)))
(let (($x475 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1840)) ((_ sign_extend 1) ?x514)) true)))
(let ((?x19 ((_ sign_extend 1) ?x1840)))
(let (($x157 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x19) true)))))
(let (($x290 (or false $x157 (or $x475))))
(and (not $x290) (or $x290 (and (distinct ?x514 ?x514) true))))))))))
(check-sat)
; query 11: function gsm_L_add, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x428 (bvadd in1_64 (_ bv1 64))))
(let ((?x136 ((_ sign_extend 1) ?x428)))
(let (($x31 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x136) true)))))
(and (not $x31) (or $x31 (and (distinct ?x428 ?x428) true)))))))
(check-sat)
; query 12: function gsm_L_add, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x428 (bvadd in1_64 (_ bv1 64))))
(let ((?x540 (bvsub (_ bv0 64) ?x428)))
(let (($x402 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x428)) ((_ sign_extend 1) ?x540)) true)))
(let ((?x136 ((_ sign_extend 1) ?x428)))
(let (($x31 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x136) true)))))
(let (($x626 (or false $x31 (or $x402))))
(and (not $x626) (or $x626 (and (distinct ?x540 ?x540) true))))))))))
(check-sat)
; query 13: function gsm_L_add, block 8, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x428 (bvadd in1_64 (_ bv1 64))))
(let ((?x540 (bvsub (_ bv0 64) ?x428)))
(let ((?x1840 (bvadd in0_64 (_ bv1 64))))
(let ((?x514 (bvsub (_ bv0 64) ?x1840)))
(let ((?x274 (bvadd ?x514 ?x540)))
(let (($x402 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x428)) ((_ sign_extend 1) ?x540)) true)))
(let ((?x136 ((_ sign_extend 1) ?x428)))
(let (($x31 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x136) true)))))
(let (($x626 (or false $x31 (or $x402))))
(let (($x475 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1840)) ((_ sign_extend 1) ?x514)) true)))
(let ((?x19 ((_ sign_extend 1) ?x1840)))
(let (($x157 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x19) true)))))
(let (($x290 (or false $x157 (or $x475))))
(let (($x383 (or $x290 $x626 false)))
(and (not $x383) (or $x383 (and (distinct ?x274 ?x274) true))))))))))))))))))
(check-sat)
; query 14: function gsm_L_add, block 8, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x428 (bvadd in1_64 (_ bv1 64))))
(let ((?x540 (bvsub (_ bv0 64) ?x428)))
(let ((?x1840 (bvadd in0_64 (_ bv1 64))))
(let ((?x514 (bvsub (_ bv0 64) ?x1840)))
(let ((?x274 (bvadd ?x514 ?x540)))
(let ((?x642 (ite (bvuge ?x274 (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x402 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x428)) ((_ sign_extend 1) ?x540)) true)))
(let ((?x136 ((_ sign_extend 1) ?x428)))
(let (($x31 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x136) true)))))
(let (($x626 (or false $x31 (or $x402))))
(let (($x475 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1840)) ((_ sign_extend 1) ?x514)) true)))
(let ((?x19 ((_ sign_extend 1) ?x1840)))
(let (($x157 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x19) true)))))
(let (($x290 (or false $x157 (or $x475))))
(let (($x383 (or $x290 $x626 false)))
(let (($x647 (or $x383 false false)))
(and (not $x647) (or $x647 (and (distinct ?x642 ?x642) true))))))))))))))))))))
(check-sat)
; query 15: function gsm_L_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1840 (bvadd in0_64 (_ bv1 64))))
(let ((?x19 ((_ sign_extend 1) ?x1840)))
(let (($x157 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x19) true)))))
(and (not $x157) (or $x157 (and (distinct ?x1840 ?x1840) true)))))))
(check-sat)
; query 16: function gsm_L_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x131 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x1839 (or false false false)))
(let (($x1838 (not $x1839)))
(and $x1838 (or $x1839 (and (distinct ?x131 ?x131) true)))))))
(check-sat)
; query 17: function gsm_L_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x541 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x1839 (or false false false)))
(let (($x1838 (not $x1839)))
(and $x1838 (or $x1839 (and (distinct ?x541 ?x541) true)))))))
(check-sat)
; query 18: function gsm_L_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x131 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x1839 (or false false false)))
(let (($x1838 (not $x1839)))
(and $x1838 (or $x1839 (and (distinct ?x131 ?x131) true)))))))
(check-sat)
; query 19: function gsm_L_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x131 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x297 ((_ zero_extend 31) ?x131)))
(let (($x1839 (or false false false)))
(let (($x271 (or $x1839 false)))
(and (not $x271) (or $x271 (and (distinct ?x297 ?x297) true))))))))
(check-sat)
; query 20: function gsm_L_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x131 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x297 ((_ zero_extend 31) ?x131)))
(let ((?x84 (bvsub (_ bv0 32) ?x297)))
(let (($x108 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x297)) ((_ sign_extend 1) ?x84)) true)))
(let (($x1839 (or false false false)))
(let (($x271 (or $x1839 false)))
(let (($x85 (or false $x271 (or $x108))))
(and (not $x85) (or $x85 (and (distinct ?x84 ?x84) true)))))))))))
(check-sat)
; query 21: function gsm_L_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x131 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x297 ((_ zero_extend 31) ?x131)))
(let ((?x84 (bvsub (_ bv0 32) ?x297)))
(let ((?x343 ((_ sign_extend 32) ?x84)))
(let (($x108 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x297)) ((_ sign_extend 1) ?x84)) true)))
(let (($x1839 (or false false false)))
(let (($x271 (or $x1839 false)))
(let (($x85 (or false $x271 (or $x108))))
(let (($x52 (or $x85 false)))
(and (not $x52) (or $x52 (and (distinct ?x343 ?x343) true)))))))))))))
(check-sat)
; query 22: function gsm_L_asr, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x122 (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x1839 (or false false false)))
(let (($x1838 (not $x1839)))
(and $x1838 (or $x1839 (and (distinct ?x122 ?x122) true)))))))
(check-sat)
; query 23: function gsm_L_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x541 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x1839 (or false false false)))
(let (($x1838 (not $x1839)))
(and $x1838 (or $x1839 (and (distinct ?x541 ?x541) true)))))))
(check-sat)
; query 24: function gsm_L_sub, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x596 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x1839 (or false false false)))
(let (($x1838 (not $x1839)))
(and $x1838 (or $x1839 (and (distinct ?x596 ?x596) true)))))))
(check-sat)
; query 25: function gsm_L_sub, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x53 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvsub in0_64 in1_64))) true)))
(let (($x29 (or false false (or $x53))))
(let (($x449 (or $x29 (and (distinct (bvsub in0_64 in1_64) (bvsub in0_64 in1_64)) true))))
(and (not $x29) $x449)))))
(check-sat)
; query 26: function gsm_L_sub, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x428 (bvadd in1_64 (_ bv1 64))))
(let ((?x540 (bvsub (_ bv0 64) ?x428)))
(let (($x402 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x428)) ((_ sign_extend 1) ?x540)) true)))
(let ((?x136 ((_ sign_extend 1) ?x428)))
(let (($x31 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x136) true)))))
(let (($x626 (or false $x31 (or $x402))))
(and (not $x626) (or $x626 (and (distinct ?x540 ?x540) true))))))))))
(check-sat)
; query 27: function gsm_L_sub, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x428 (bvadd in1_64 (_ bv1 64))))
(let ((?x540 (bvsub (_ bv0 64) ?x428)))
(let ((?x301 (bvadd in0_64 ?x540)))
(let (($x402 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x428)) ((_ sign_extend 1) ?x540)) true)))
(let ((?x136 ((_ sign_extend 1) ?x428)))
(let (($x31 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x136) true)))))
(let (($x626 (or false $x31 (or $x402))))
(let (($x65 (or false $x626 false)))
(and (not $x65) (or $x65 (and (distinct ?x301 ?x301) true))))))))))))
(check-sat)
; query 28: function gsm_L_sub, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x163 (ite (bvuge (bvadd in0_64 (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64)))) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x402 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) (bvadd in1_64 (_ bv1 64)))) ((_ sign_extend 1) (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64))))) true)))
(let ((?x428 (bvadd in1_64 (_ bv1 64))))
(let ((?x136 ((_ sign_extend 1) ?x428)))
(let (($x31 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x136) true)))))
(let (($x626 (or false $x31 (or $x402))))
(let (($x65 (or false $x626 false)))
(let (($x166 (or $x65 false false)))
(and (not $x166) (or $x166 (and (distinct ?x163 ?x163) true))))))))))))
(check-sat)
; query 29: function gsm_L_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x428 (bvadd in1_64 (_ bv1 64))))
(let ((?x136 ((_ sign_extend 1) ?x428)))
(let (($x31 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x136) true)))))
(and (not $x31) (or $x31 (and (distinct ?x428 ?x428) true)))))))
(check-sat)
; query 30: function gsm_L_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x98 (ite (bvsle (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x1839 (or false false false)))
(let (($x1838 (not $x1839)))
(and $x1838 (or $x1839 (and (distinct ?x98 ?x98) true)))))))
(check-sat)
; query 31: function gsm_abs, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x776 (or false false)))
(let (($x133 (not $x776)))
(and $x133 (or $x776 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 32: function gsm_abs, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x74 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x776 (or false false)))
(let (($x61 (or $x776 false false)))
(let (($x156 (not $x61)))
(and $x156 (or $x61 (and (distinct ?x74 ?x74) true))))))))
(check-sat)
; query 33: function gsm_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x776 (or false false)))
(let (($x133 (not $x776)))
(and $x133 (or $x776 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 34: function gsm_add, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x776 (or false false)))
(let (($x133 (not $x776)))
(and $x133 (or $x776 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 35: function gsm_add, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x700 ((_ sign_extend 48) in1_16)))
(let ((?x1213 ((_ sign_extend 48) in0_16)))
(let ((?x1934 (bvadd ?x1213 ?x700)))
(let (($x306 (and (distinct (bvadd ((_ sign_extend 1) ?x1213) ((_ sign_extend 1) ?x700)) ((_ sign_extend 1) ?x1934)) true)))
(let (($x776 (or false false)))
(let (($x1658 (or $x776 $x776 (or $x306))))
(and (not $x1658) (or $x1658 (and (distinct ?x1934 ?x1934) true))))))))))
(check-sat)
; query 36: function gsm_add, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x49 (ite (bvsgt (_ bv18446744073709518848 64) (bvadd ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x700 ((_ sign_extend 48) in1_16)))
(let ((?x48 ((_ sign_extend 1) ?x700)))
(let ((?x1213 ((_ sign_extend 48) in0_16)))
(let ((?x27 ((_ sign_extend 1) ?x1213)))
(let (($x776 (or false false)))
(let (($x1658 (or $x776 $x776 (or (and (distinct (bvadd ?x27 ?x48) ((_ sign_extend 1) (bvadd ?x1213 ?x700))) true)))))
(let (($x612 (or $x1658 false false)))
(and (not $x612) (or $x612 (and (distinct ?x49 ?x49) true))))))))))))
(check-sat)
; query 37: function gsm_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x479 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x1839 (or false false false)))
(let (($x1838 (not $x1839)))
(and $x1838 (or $x1839 (and (distinct ?x479 ?x479) true)))))))
(check-sat)
; query 38: function gsm_asr, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1657 (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x1839 (or false false false)))
(let (($x1838 (not $x1839)))
(and $x1838 (or $x1839 (and (distinct ?x1657 ?x1657) true)))))))
(check-sat)
; query 39: function gsm_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x776 (or false false)))
(let (($x133 (not $x776)))
(and $x133 (or $x776 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 40: function gsm_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x74 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x776 (or false false)))
(let (($x61 (or $x776 false false)))
(let (($x156 (not $x61)))
(and $x156 (or $x61 (and (distinct ?x74 ?x74) true))))))))
(check-sat)
; query 41: function gsm_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x74 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1894 ((_ zero_extend 31) ?x74)))
(let (($x776 (or false false)))
(let (($x61 (or $x776 false false)))
(let (($x1724 (or $x61 false)))
(and (not $x1724) (or $x1724 (and (distinct ?x1894 ?x1894) true)))))))))
(check-sat)
; query 42: function gsm_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x74 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1894 ((_ zero_extend 31) ?x74)))
(let ((?x1665 (bvsub (_ bv0 32) ?x1894)))
(let (($x1666 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1894)) ((_ sign_extend 1) ?x1665)) true)))
(let (($x776 (or false false)))
(let (($x61 (or $x776 false false)))
(let (($x1724 (or $x61 false)))
(let (($x1661 (or false $x1724 (or $x1666))))
(and (not $x1661) (or $x1661 (and (distinct ?x1665 ?x1665) true))))))))))))
(check-sat)
; query 43: function gsm_asr, block 4, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x74 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1894 ((_ zero_extend 31) ?x74)))
(let ((?x1665 (bvsub (_ bv0 32) ?x1894)))
(let ((?x1652 ((_ extract 15 0) ?x1665)))
(let (($x1666 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1894)) ((_ sign_extend 1) ?x1665)) true)))
(let (($x776 (or false false)))
(let (($x61 (or $x776 false false)))
(let (($x1724 (or $x61 false)))
(let (($x1661 (or false $x1724 (or $x1666))))
(let (($x1662 (or $x1661 false)))
(and (not $x1662) (or $x1662 (and (distinct ?x1652 ?x1652) true))))))))))))))
(check-sat)
; query 44: function gsm_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x479 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x1839 (or false false false)))
(let (($x1838 (not $x1839)))
(and $x1838 (or $x1839 (and (distinct ?x479 ?x479) true)))))))
(check-sat)
; query 45: function gsm_debug_longwords, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in15_32 () (_ BitVec 32))
(assert
 (let ((?x1686 (ite (bvslt in15_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x1839 (or false false false)))
(let (($x1838 (not $x1839)))
(and $x1838 (or $x1839 (and (distinct ?x1686 ?x1686) true)))))))
(check-sat)
; query 46: function gsm_debug_words, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in16_32 () (_ BitVec 32))
(assert
 (let ((?x1707 (ite (bvslt in16_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x1839 (or false false false)))
(let (($x1838 (not $x1839)))
(and $x1838 (or $x1839 (and (distinct ?x1707 ?x1707) true)))))))
(check-sat)
; query 47: function gsm_div, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x776 (or false false)))
(let (($x133 (not $x776)))
(and $x133 (or $x776 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 48: function gsm_div, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x776 (or false false)))
(let (($x133 (not $x776)))
(and $x133 (or $x776 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 49: function gsm_div, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x776 (or false false)))
(let (($x133 (not $x776)))
(and $x133 (or $x776 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 50: function gsm_div, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x525 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1867 (and (distinct ?x525 ?x525) true)))
(let (($x776 (or false false)))
(let (($x61 (or $x776 false false)))
(let (($x156 (not $x61)))
(and $x156 (or $x61 $x1867))))))))
(check-sat)
; query 51: function gsm_norm, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1705 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x1839 (or false false false)))
(let (($x1838 (not $x1839)))
(and $x1838 (or $x1839 (and (distinct ?x1705 ?x1705) true)))))))
(check-sat)
; query 52: function gsm_norm, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1705 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x1701 (bvxor ?x1705 (_ bv1 1))))
(let (($x1839 (or false false false)))
(let (($x390 (or $x1839 false false)))
(and (not $x390) (or $x390 (and (distinct ?x1701 ?x1701) true))))))))
(check-sat)
; query 53: function gsm_norm, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1705 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x1701 (bvxor ?x1705 (_ bv1 1))))
(let ((?x1691 ((_ zero_extend 31) ?x1701)))
(let (($x1839 (or false false false)))
(let (($x390 (or $x1839 false false)))
(let (($x1692 (or $x390 false)))
(and (not $x1692) (or $x1692 (and (distinct ?x1691 ?x1691) true))))))))))
(check-sat)
; query 54: function gsm_norm, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1705 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x1701 (bvxor ?x1705 (_ bv1 1))))
(let ((?x1691 ((_ zero_extend 31) ?x1701)))
(let ((?x1709 ((_ sign_extend 32) ?x1691)))
(let (($x1839 (or false false false)))
(let (($x390 (or $x1839 false false)))
(let (($x1692 (or $x390 false)))
(let (($x1697 (or $x1692 false)))
(and (not $x1697) (or $x1697 (and (distinct ?x1709 ?x1709) true))))))))))))
(check-sat)
; query 55: function gsm_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x776 (or false false)))
(let (($x133 (not $x776)))
(and $x133 (or $x776 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 56: function gsm_sub, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x776 (or false false)))
(let (($x133 (not $x776)))
(and $x133 (or $x776 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 57: function gsm_sub, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x700 ((_ sign_extend 48) in1_16)))
(let ((?x1213 ((_ sign_extend 48) in0_16)))
(let ((?x1696 (bvsub ?x1213 ?x700)))
(let (($x1695 (and (distinct (bvsub ((_ sign_extend 1) ?x1213) ((_ sign_extend 1) ?x700)) ((_ sign_extend 1) ?x1696)) true)))
(let (($x776 (or false false)))
(let (($x1722 (or $x776 $x776 (or $x1695))))
(and (not $x1722) (or $x1722 (and (distinct ?x1696 ?x1696) true))))))))))
(check-sat)
; query 58: function gsm_sub, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1751 (ite (bvsgt (_ bv18446744073709518848 64) (bvsub ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x700 ((_ sign_extend 48) in1_16)))
(let ((?x48 ((_ sign_extend 1) ?x700)))
(let ((?x1213 ((_ sign_extend 48) in0_16)))
(let ((?x27 ((_ sign_extend 1) ?x1213)))
(let (($x776 (or false false)))
(let (($x1722 (or $x776 $x776 (or (and (distinct (bvsub ?x27 ?x48) ((_ sign_extend 1) (bvsub ?x1213 ?x700))) true)))))
(let (($x1730 (or $x1722 false false)))
(and (not $x1730) (or $x1730 (and (distinct ?x1751 ?x1751) true))))))))))))
(check-sat)
