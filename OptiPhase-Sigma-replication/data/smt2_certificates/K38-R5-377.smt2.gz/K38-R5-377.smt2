; OptiPhase-Sigma refinement certificate for sweep K38-R5-377
; query 0: function BF_ofb64_encrypt, block 82, name %83
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x19 (ite (= (_ bv0 32) in.04_32) (_ bv1 1) (_ bv0 1))))
(let (($x73 (or false false false)))
(and (not $x73) (or $x73 (and (distinct ?x19 ?x19) true))))))
(check-sat)
