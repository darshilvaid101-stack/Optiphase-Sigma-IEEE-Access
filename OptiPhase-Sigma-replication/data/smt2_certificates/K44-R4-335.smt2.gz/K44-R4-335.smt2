; OptiPhase-Sigma refinement certificate for sweep K44-R4-335
; query 0: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x287 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x168 (or false false false)))
(let (($x448 (not $x168)))
(and $x448 (or $x168 (and (distinct ?x287 ?x287) true)))))))
(check-sat)
; query 1: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x454 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x168 (or false false false)))
(let (($x448 (not $x168)))
(and $x448 (or $x168 (and (distinct ?x454 ?x454) true)))))))
(check-sat)
