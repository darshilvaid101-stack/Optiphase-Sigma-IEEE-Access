; OptiPhase-Sigma refinement certificate for sweep K52-R5-373
; query 0: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x462 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x276 (or false false false)))
(let (($x516 (not $x276)))
(and $x516 (or $x276 (and (distinct ?x462 ?x462) true)))))))
(check-sat)
; query 1: function s162, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x69 (ite (bvslt (_ bv0 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x276 (or false false false)))
(let (($x516 (not $x276)))
(and $x516 (or $x276 (and (distinct ?x69 ?x69) true)))))))
(check-sat)
