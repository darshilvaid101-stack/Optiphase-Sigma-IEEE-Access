; OptiPhase-Sigma refinement certificate for sweep K52-R4-326
; query 0: function s162, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x1679 (ite (bvslt (_ bv0 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x72 (or false false false)))
(and (not $x72) (or $x72 (and (distinct ?x1679 ?x1679) true))))))
(check-sat)
