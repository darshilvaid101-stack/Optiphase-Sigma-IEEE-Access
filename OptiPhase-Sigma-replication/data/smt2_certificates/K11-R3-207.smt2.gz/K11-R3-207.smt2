; OptiPhase-Sigma refinement certificate for sweep K11-R3-207
; query 0: function xmalloc, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in7_32 () (_ BitVec 32))
(assert
 (let ((?x152 (ite (and (distinct (_ bv0 32) in7_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x133 (or false false false)))
(and (not $x133) (or $x133 (and (distinct ?x152 ?x152) true))))))
(check-sat)
