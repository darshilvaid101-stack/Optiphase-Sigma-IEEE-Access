; OptiPhase-Sigma refinement certificate for sweep K36-R1-001
