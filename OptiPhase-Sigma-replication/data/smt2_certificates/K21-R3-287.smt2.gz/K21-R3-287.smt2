; OptiPhase-Sigma refinement certificate for sweep K21-R3-287
; query 0: function init_array, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x81 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x17 (or false false (or $x81))))
(and (not $x17) (or $x17 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function init_array, block 25, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x230 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x134 (or false false (or $x230))))
(and (not $x134) (or $x134 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function kernel_deriche, block 102, name %103
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.112_32 () (_ BitVec 32))
(assert
 (let (($x228 (and (distinct (bvadd ((_ sign_extend 1) in.112_32) ((_ sign_extend 1) (_ bv4294967295 32))) ((_ sign_extend 1) (bvadd in.112_32 (_ bv4294967295 32)))) true)))
(let (($x131 (or false false (or $x228))))
(and (not $x131) (or $x131 (and (distinct (bvadd in.112_32 (_ bv4294967295 32)) (bvadd in.112_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 3: function kernel_deriche, block 105, name %106
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.110_32 () (_ BitVec 32))
(assert
 (let (($x75 (and (distinct (bvadd ((_ sign_extend 1) in.110_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.110_32 (_ bv1 32)))) true)))
(let (($x83 (or false false (or $x75))))
(and (not $x83) (or $x83 (and (distinct (bvadd in.110_32 (_ bv1 32)) (bvadd in.110_32 (_ bv1 32))) true))))))
(check-sat)
; query 4: function kernel_deriche, block 130, name %131
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.213_32 () (_ BitVec 32))
(assert
 (let (($x23 (and (distinct (bvadd ((_ sign_extend 1) in.213_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.213_32 (_ bv1 32)))) true)))
(let (($x153 (or false false (or $x23))))
(and (not $x153) (or $x153 (and (distinct (bvadd in.213_32 (_ bv1 32)) (bvadd in.213_32 (_ bv1 32))) true))))))
(check-sat)
; query 5: function kernel_deriche, block 133, name %134
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let (($x118 (and (distinct (bvadd ((_ sign_extend 1) in.2_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.2_32 (_ bv1 32)))) true)))
(let (($x110 (or false false (or $x118))))
(and (not $x110) (or $x110 (and (distinct (bvadd in.2_32 (_ bv1 32)) (bvadd in.2_32 (_ bv1 32))) true))))))
(check-sat)
; query 6: function kernel_deriche, block 165, name %166
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.3_32 () (_ BitVec 32))
(assert
 (let (($x78 (and (distinct (bvadd ((_ sign_extend 1) in.3_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.3_32 (_ bv1 32)))) true)))
(let (($x20 (or false false (or $x78))))
(and (not $x20) (or $x20 (and (distinct (bvadd in.3_32 (_ bv1 32)) (bvadd in.3_32 (_ bv1 32))) true))))))
(check-sat)
; query 7: function kernel_deriche, block 168, name %169
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.314_32 () (_ BitVec 32))
(assert
 (let (($x29 (and (distinct (bvadd ((_ sign_extend 1) in.314_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.314_32 (_ bv1 32)))) true)))
(let (($x60 (or false false (or $x29))))
(and (not $x60) (or $x60 (and (distinct (bvadd in.314_32 (_ bv1 32)) (bvadd in.314_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function kernel_deriche, block 173, name %174
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x58 (and (distinct (bvsub ((_ sign_extend 1) in0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvsub in0_32 (_ bv1 32)))) true)))
(let (($x73 (or false false (or $x58))))
(and (not $x73) (or $x73 (and (distinct (bvsub in0_32 (_ bv1 32)) (bvsub in0_32 (_ bv1 32))) true))))))
(check-sat)
; query 9: function kernel_deriche, block 196, name %197
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.4_32 () (_ BitVec 32))
(assert
 (let (($x44 (and (distinct (bvadd ((_ sign_extend 1) in.4_32) ((_ sign_extend 1) (_ bv4294967295 32))) ((_ sign_extend 1) (bvadd in.4_32 (_ bv4294967295 32)))) true)))
(let (($x69 (or false false (or $x44))))
(and (not $x69) (or $x69 (and (distinct (bvadd in.4_32 (_ bv4294967295 32)) (bvadd in.4_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 10: function kernel_deriche, block 199, name %200
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.415_32 () (_ BitVec 32))
(assert
 (let (($x46 (and (distinct (bvadd ((_ sign_extend 1) in.415_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.415_32 (_ bv1 32)))) true)))
(let (($x57 (or false false (or $x46))))
(and (not $x57) (or $x57 (and (distinct (bvadd in.415_32 (_ bv1 32)) (bvadd in.415_32 (_ bv1 32))) true))))))
(check-sat)
; query 11: function kernel_deriche, block 224, name %225
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.516_32 () (_ BitVec 32))
(assert
 (let (($x127 (and (distinct (bvadd ((_ sign_extend 1) in.516_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.516_32 (_ bv1 32)))) true)))
(let (($x99 (or false false (or $x127))))
(and (not $x99) (or $x99 (and (distinct (bvadd in.516_32 (_ bv1 32)) (bvadd in.516_32 (_ bv1 32))) true))))))
(check-sat)
; query 12: function kernel_deriche, block 227, name %228
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.5_32 () (_ BitVec 32))
(assert
 (let (($x149 (and (distinct (bvadd ((_ sign_extend 1) in.5_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.5_32 (_ bv1 32)))) true)))
(let (($x147 (or false false (or $x149))))
(and (not $x147) (or $x147 (and (distinct (bvadd in.5_32 (_ bv1 32)) (bvadd in.5_32 (_ bv1 32))) true))))))
(check-sat)
; query 13: function kernel_deriche, block 71, name %72
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.011_32 () (_ BitVec 32))
(assert
 (let (($x154 (and (distinct (bvadd ((_ sign_extend 1) in.011_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.011_32 (_ bv1 32)))) true)))
(let (($x170 (or false false (or $x154))))
(and (not $x170) (or $x170 (and (distinct (bvadd in.011_32 (_ bv1 32)) (bvadd in.011_32 (_ bv1 32))) true))))))
(check-sat)
; query 14: function kernel_deriche, block 74, name %75
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.09_32 () (_ BitVec 32))
(assert
 (let (($x163 (and (distinct (bvadd ((_ sign_extend 1) in.09_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.09_32 (_ bv1 32)))) true)))
(let (($x178 (or false false (or $x163))))
(and (not $x178) (or $x178 (and (distinct (bvadd in.09_32 (_ bv1 32)) (bvadd in.09_32 (_ bv1 32))) true))))))
(check-sat)
; query 15: function kernel_deriche, block 79, name %80
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x183 (and (distinct (bvsub ((_ sign_extend 1) in1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvsub in1_32 (_ bv1 32)))) true)))
(let (($x185 (or false false (or $x183))))
(and (not $x185) (or $x185 (and (distinct (bvsub in1_32 (_ bv1 32)) (bvsub in1_32 (_ bv1 32))) true))))))
(check-sat)
; query 16: function print_array, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x81 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x17 (or false false (or $x81))))
(and (not $x17) (or $x17 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 17: function print_array, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x230 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x134 (or false false (or $x230))))
(and (not $x134) (or $x134 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
