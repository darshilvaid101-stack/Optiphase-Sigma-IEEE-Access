; OptiPhase-Sigma refinement certificate for sweep K33-R4-353
; query 0: function edge_draw, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let ((?x224 (ite (= (_ bv0 32) in4_32) (_ bv1 1) (_ bv0 1))))
(let (($x244 (or false false false)))
(and (not $x244) (or $x244 (and (distinct ?x224 ?x224) true))))))
(check-sat)
