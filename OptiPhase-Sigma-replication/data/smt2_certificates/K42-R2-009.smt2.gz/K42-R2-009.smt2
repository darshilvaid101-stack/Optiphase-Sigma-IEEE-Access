; OptiPhase-Sigma refinement certificate for sweep K42-R2-009
