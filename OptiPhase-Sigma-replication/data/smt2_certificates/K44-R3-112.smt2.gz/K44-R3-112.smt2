; OptiPhase-Sigma refinement certificate for sweep K44-R3-112
; query 0: function IsPowerOfTwo, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x36 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x642 (or false false false)))
(let (($x411 (not $x642)))
(and $x411 (or $x642 (and (distinct ?x36 ?x36) true)))))))
(check-sat)
; query 1: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x36 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x642 (or false false false)))
(let (($x411 (not $x642)))
(and $x411 (or $x642 (and (distinct ?x36 ?x36) true)))))))
(check-sat)
; query 2: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x110 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x642 (or false false false)))
(let (($x411 (not $x642)))
(and $x411 (or $x642 (and (distinct ?x110 ?x110) true)))))))
(check-sat)
