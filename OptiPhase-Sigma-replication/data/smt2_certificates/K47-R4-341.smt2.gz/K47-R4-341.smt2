; OptiPhase-Sigma refinement certificate for sweep K47-R4-341
; query 0: function main, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x144 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x276 (or false false false)))
(and (not $x276) (or $x276 (and (distinct ?x144 ?x144) true))))))
(check-sat)
