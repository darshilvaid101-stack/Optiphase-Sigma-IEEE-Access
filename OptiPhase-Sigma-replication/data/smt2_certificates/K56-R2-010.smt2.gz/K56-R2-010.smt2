; OptiPhase-Sigma refinement certificate for sweep K56-R2-010
; query 0: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x190 (or false false false)))
(let (($x43 (not $x190)))
(and $x43 (or $x190 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x96 (bvadd in.01_32 (_ bv1 32))))
(let ((?x3581 (bvmul ?x96 ?x96)))
(let (($x190 (or false false false)))
(let (($x169 (or $x190 $x190 false)))
(and (not $x169) (or $x169 (and (distinct ?x3581 ?x3581) true))))))))
(check-sat)
; query 2: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x96 (bvadd in.01_32 (_ bv1 32))))
(let ((?x3581 (bvmul ?x96 ?x96)))
(let ((?x701 (bvmul ?x3581 (_ bv2 32))))
(let (($x190 (or false false false)))
(let (($x169 (or $x190 $x190 false)))
(let (($x41 (or $x169 false false)))
(and (not $x41) (or $x41 (and (distinct ?x701 ?x701) true))))))))))
(check-sat)
; query 3: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x96 (bvadd in.01_32 (_ bv1 32))))
(let ((?x3581 (bvmul ?x96 ?x96)))
(let ((?x701 (bvmul ?x3581 (_ bv2 32))))
(let ((?x45 (bvmul ?x701 (_ bv4 32))))
(let (($x190 (or false false false)))
(let (($x169 (or $x190 $x190 false)))
(let (($x41 (or $x169 false false)))
(let (($x121 (or $x41 false false)))
(and (not $x121) (or $x121 (and (distinct ?x45 ?x45) true))))))))))))
(check-sat)
; query 4: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x544 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x190 (or false false false)))
(let (($x43 (not $x190)))
(and $x43 (or $x190 (and (distinct ?x544 ?x544) true)))))))
(check-sat)
; query 5: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x137 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x190 (or false false false)))
(let (($x43 (not $x190)))
(and $x43 (or $x190 (and (distinct ?x137 ?x137) true)))))))
(check-sat)
; query 6: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x190 (or false false false)))
(let (($x43 (not $x190)))
(and $x43 (or $x190 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 7: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x155 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x44 (or false false (or $x155))))
(and (not $x44) (or $x44 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x46 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x190 (or false false false)))
(let (($x43 (not $x190)))
(and $x43 (or $x190 (and (distinct ?x46 ?x46) true)))))))
(check-sat)
; query 9: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x409 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x190 (or false false false)))
(let (($x43 (not $x190)))
(and $x43 (or $x190 (and (distinct ?x409 ?x409) true)))))))
(check-sat)
; query 10: function matrix_add_const, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x190 (or false false false)))
(let (($x43 (not $x190)))
(and $x43 (or $x190 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 11: function matrix_add_const, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x190 (or false false false)))
(let (($x43 (not $x190)))
(and $x43 (or $x190 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 12: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x110 (or false false)))
(and (not $x110) (or $x110 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true)))))
(check-sat)
; query 13: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x235 ((_ sign_extend 16) in.1_16)))
(let ((?x67 (bvadd ?x235 (_ bv10 32))))
(let (($x1321 (and (distinct (bvadd ((_ sign_extend 1) ?x235) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x67)) true)))
(let (($x110 (or false false)))
(let (($x206 (or $x110 false (or $x1321))))
(and (not $x206) (or $x206 (and (distinct ?x67 ?x67) true)))))))))
(check-sat)
; query 14: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x235 ((_ sign_extend 16) in.1_16)))
(let ((?x67 (bvadd ?x235 (_ bv10 32))))
(let ((?x980 ((_ extract 15 0) ?x67)))
(let (($x1321 (and (distinct (bvadd ((_ sign_extend 1) ?x235) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x67)) true)))
(let (($x110 (or false false)))
(let (($x206 (or $x110 false (or $x1321))))
(let (($x14 (or $x206 false)))
(and (not $x14) (or $x14 (and (distinct ?x980 ?x980) true)))))))))))
(check-sat)
