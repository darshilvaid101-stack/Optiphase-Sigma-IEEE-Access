; OptiPhase-Sigma refinement certificate for sweep K38-R3-304
; query 0: function BF_cfb64_encrypt, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.07_32 () (_ BitVec 32))
(assert
 (let ((?x165 (ite (= (_ bv0 32) in.07_32) (_ bv1 1) (_ bv0 1))))
(let (($x231 (or false false false)))
(let (($x82 (not $x231)))
(and $x82 (or $x231 (and (distinct ?x165 ?x165) true)))))))
(check-sat)
; query 1: function BF_ofb64_encrypt, block 82, name %83
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x107 (ite (= (_ bv0 32) in.04_32) (_ bv1 1) (_ bv0 1))))
(let (($x231 (or false false false)))
(let (($x82 (not $x231)))
(and $x82 (or $x231 (and (distinct ?x107 ?x107) true)))))))
(check-sat)
