; OptiPhase-Sigma refinement certificate for sweep K38-R6-047
; query 0: function BF_cbc_encrypt, block 126, name %127
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.010_64 () (_ BitVec 64))
(assert
 (let (($x46 (and (distinct (bvsub ((_ sign_extend 1) in.010_64) ((_ sign_extend 1) (_ bv8 64))) ((_ sign_extend 1) (bvsub in.010_64 (_ bv8 64)))) true)))
(let (($x77 (or false false (or $x46))))
(and (not $x77) (or $x77 (and (distinct (bvsub in.010_64 (_ bv8 64)) (bvsub in.010_64 (_ bv8 64))) true))))))
(check-sat)
; query 1: function BF_cbc_encrypt, block 128, name %129
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.010_64 () (_ BitVec 64))
(assert
 (let ((?x61 (ite (and (distinct (_ bv18446744073709551608 64) in.010_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x467 (or false false false)))
(let (($x79 (not $x467)))
(and $x79 (or $x467 (and (distinct ?x61 ?x61) true)))))))
(check-sat)
; query 2: function BF_cfb64_encrypt, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.07_32 () (_ BitVec 32))
(assert
 (let ((?x28 (ite (= (_ bv0 32) in.07_32) (_ bv1 1) (_ bv0 1))))
(let (($x467 (or false false false)))
(let (($x79 (not $x467)))
(and $x79 (or $x467 (and (distinct ?x28 ?x28) true)))))))
(check-sat)
; query 3: function BF_set_key, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x377 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x62 (or false false (or $x377))))
(and (not $x62) (or $x62 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 4: function BF_set_key, block 69, name %70
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.13_32 () (_ BitVec 32))
(assert
 (let (($x457 (and (distinct (bvadd ((_ sign_extend 1) in.13_32) ((_ sign_extend 1) (_ bv2 32))) ((_ sign_extend 1) (bvadd in.13_32 (_ bv2 32)))) true)))
(let (($x56 (or false false (or $x457))))
(and (not $x56) (or $x56 (and (distinct (bvadd in.13_32 (_ bv2 32)) (bvadd in.13_32 (_ bv2 32))) true))))))
(check-sat)
; query 5: function BF_set_key, block 87, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.24_32 () (_ BitVec 32))
(assert
 (let (($x54 (and (distinct (bvadd ((_ sign_extend 1) in.24_32) ((_ sign_extend 1) (_ bv2 32))) ((_ sign_extend 1) (bvadd in.24_32 (_ bv2 32)))) true)))
(let (($x169 (or false false (or $x54))))
(and (not $x169) (or $x169 (and (distinct (bvadd in.24_32 (_ bv2 32)) (bvadd in.24_32 (_ bv2 32))) true))))))
(check-sat)
; query 6: function main, block 60, name %61
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x31 (or false false)))
(and (not $x31) (or $x31 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 7: function main, block 60, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x354 (ite (bvsge (_ bv57 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x31 (or false false)))
(let (($x319 (or $x31 false false)))
(let (($x311 (not $x319)))
(and $x311 (or $x319 (and (distinct ?x354 ?x354) true))))))))
(check-sat)
; query 8: function main, block 63, name %64
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x467 (or false false false)))
(and (not (or $x467 (bvuge (_ bv4 32) (_ bv32 32)))) (or $x467 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvmul in.01_32 (_ bv16 32))) true)))))
(check-sat)
; query 9: function main, block 63, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x31 (or false false)))
(and (not $x31) (or $x31 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 10: function main, block 63, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x11 (bvmul in.01_32 (_ bv16 32))))
(let ((?x75 (bvadd ?x11 (_ bv4294967248 32))))
(let ((?x494 ((_ sign_extend 24) in57_8)))
(let ((?x337 (bvshl in.01_32 (_ bv4 32))))
(let ((?x308 (bvadd ?x337 ?x494)))
(let (($x467 (or false false false)))
(let (($x30 (or $x467 false false)))
(let ((?x395 ((_ sign_extend 1) ?x308)))
(let (($x31 (or false false)))
(let (($x34 (or $x467 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x275 (or $x34 $x31 (or (and (distinct (bvadd ((_ sign_extend 1) ?x337) ((_ sign_extend 1) ?x494)) ?x395) true)))))
(let (($x663 (not $x275)))
(and $x663 (or $x30 (and (distinct ?x308 ?x75) true))))))))))))))))
(check-sat)
; query 11: function main, block 63, name %67
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x494 ((_ sign_extend 24) in57_8)))
(let ((?x337 (bvshl in.01_32 (_ bv4 32))))
(let ((?x308 (bvadd ?x337 ?x494)))
(let ((?x414 (bvsub ?x308 (_ bv48 32))))
(let (($x31 (or false false)))
(let (($x467 (or false false false)))
(let (($x30 (or $x467 false false)))
(let (($x43 (or $x30 $x31 false)))
(let (($x19 (or $x43 (and (distinct ?x414 (bvadd (bvadd (bvmul in.01_32 (_ bv16 32)) (_ bv4294967248 32)) ?x494)) true))))
(let (($x371 (and (distinct (bvsub ((_ sign_extend 1) ?x308) ((_ sign_extend 1) (_ bv48 32))) ((_ sign_extend 1) ?x414)) true)))
(let ((?x395 ((_ sign_extend 1) ?x308)))
(let (($x34 (or $x467 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x275 (or $x34 $x31 (or (and (distinct (bvadd ((_ sign_extend 1) ?x337) ((_ sign_extend 1) ?x494)) ?x395) true)))))
(and (not (or $x275 false (or $x371))) $x19)))))))))))))))
(check-sat)
; query 12: function main, block 68, name %69
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x31 (or false false)))
(and (not $x31) (or $x31 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 13: function main, block 68, name %70
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x17 (ite (bvsle (_ bv65 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x31 (or false false)))
(let (($x319 (or $x31 false false)))
(let (($x311 (not $x319)))
(and $x311 (or $x319 (and (distinct ?x17 ?x17) true))))))))
(check-sat)
; query 14: function main, block 71, name %72
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x31 (or false false)))
(and (not $x31) (or $x31 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 15: function main, block 71, name %73
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x177 (ite (bvsge (_ bv70 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x31 (or false false)))
(let (($x319 (or $x31 false false)))
(let (($x311 (not $x319)))
(and $x311 (or $x319 (and (distinct ?x177 ?x177) true))))))))
(check-sat)
; query 16: function main, block 74, name %75
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x467 (or false false false)))
(and (not (or $x467 (bvuge (_ bv4 32) (_ bv32 32)))) (or $x467 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvmul in.01_32 (_ bv16 32))) true)))))
(check-sat)
; query 17: function main, block 74, name %76
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x31 (or false false)))
(and (not $x31) (or $x31 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 18: function main, block 74, name %77
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x11 (bvmul in.01_32 (_ bv16 32))))
(let ((?x562 (bvadd ?x11 (_ bv4294967241 32))))
(let ((?x494 ((_ sign_extend 24) in57_8)))
(let ((?x337 (bvshl in.01_32 (_ bv4 32))))
(let ((?x308 (bvadd ?x337 ?x494)))
(let (($x467 (or false false false)))
(let (($x30 (or $x467 false false)))
(let ((?x395 ((_ sign_extend 1) ?x308)))
(let (($x31 (or false false)))
(let (($x34 (or $x467 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x275 (or $x34 $x31 (or (and (distinct (bvadd ((_ sign_extend 1) ?x337) ((_ sign_extend 1) ?x494)) ?x395) true)))))
(let (($x663 (not $x275)))
(and $x663 (or $x30 (and (distinct ?x308 ?x562) true))))))))))))))))
(check-sat)
; query 19: function main, block 74, name %78
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x494 ((_ sign_extend 24) in57_8)))
(let ((?x337 (bvshl in.01_32 (_ bv4 32))))
(let ((?x308 (bvadd ?x337 ?x494)))
(let ((?x300 (bvsub ?x308 (_ bv65 32))))
(let (($x31 (or false false)))
(let (($x467 (or false false false)))
(let (($x30 (or $x467 false false)))
(let (($x43 (or $x30 $x31 false)))
(let (($x7 (or $x43 (and (distinct ?x300 (bvadd (bvadd (bvmul in.01_32 (_ bv16 32)) (_ bv4294967241 32)) ?x494)) true))))
(let (($x576 (and (distinct (bvsub ((_ sign_extend 1) ?x308) ((_ sign_extend 1) (_ bv65 32))) ((_ sign_extend 1) ?x300)) true)))
(let ((?x395 ((_ sign_extend 1) ?x308)))
(let (($x34 (or $x467 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x275 (or $x34 $x31 (or (and (distinct (bvadd ((_ sign_extend 1) ?x337) ((_ sign_extend 1) ?x494)) ?x395) true)))))
(and (not (or $x275 false (or $x576))) $x7)))))))))))))))
(check-sat)
