; OptiPhase-Sigma refinement certificate for sweep K24-R6-038
