; OptiPhase-Sigma refinement certificate for sweep K47-R2-029
; query 0: function adpcm_coder, block 25, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in20_32 () (_ BitVec 32))
(assert
 (let (($x267 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in20_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in20_32))) true)))
(let (($x524 (or false false (or $x267))))
(and (not $x524) (or $x524 (and (distinct (bvsub (_ bv0 32) in20_32) (bvsub (_ bv0 32) in20_32)) true))))))
(check-sat)
; query 1: function adpcm_coder, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(declare-fun in.017_32 () (_ BitVec 32))
(assert
 (let ((?x411 (bvsub in.017_32 in.020_32)))
(let (($x26 (and (distinct (bvsub ((_ sign_extend 1) in.017_32) ((_ sign_extend 1) in.020_32)) ((_ sign_extend 1) ?x411)) true)))
(let (($x67 (or false false (or $x26))))
(and (not $x67) (or $x67 (and (distinct ?x411 ?x411) true)))))))
(check-sat)
; query 2: function adpcm_coder, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(declare-fun in28_32 () (_ BitVec 32))
(assert
 (let (($x79 (and (distinct (bvadd ((_ sign_extend 1) in28_32) ((_ sign_extend 1) in.020_32)) ((_ sign_extend 1) (bvadd in28_32 in.020_32))) true)))
(let (($x206 (or false false (or $x79))))
(let (($x681 (or $x206 (and (distinct (bvadd in28_32 in.020_32) (bvadd in28_32 in.020_32)) true))))
(and (not $x206) $x681)))))
(check-sat)
; query 3: function adpcm_coder, block 36, name %37
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.014_32 () (_ BitVec 32))
(assert
 (let (($x152 (or false false false)))
(let (($x270 (not $x152)))
(and $x270 (or $x152 (and (distinct (bvor in.014_32 (_ bv2 32)) (bvor in.014_32 (_ bv2 32))) true))))))
(check-sat)
; query 4: function adpcm_coder, block 36, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in34_32 () (_ BitVec 32))
(declare-fun in.118_32 () (_ BitVec 32))
(assert
 (let (($x269 (and (distinct (bvsub ((_ sign_extend 1) in.118_32) ((_ sign_extend 1) in34_32)) ((_ sign_extend 1) (bvsub in.118_32 in34_32))) true)))
(let (($x135 (or false false (or $x269))))
(let (($x90 (or $x135 (and (distinct (bvsub in.118_32 in34_32) (bvsub in.118_32 in34_32)) true))))
(and (not $x135) $x90)))))
(check-sat)
; query 5: function adpcm_coder, block 36, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in34_32 () (_ BitVec 32))
(declare-fun in.08_32 () (_ BitVec 32))
(assert
 (let (($x101 (and (distinct (bvadd ((_ sign_extend 1) in.08_32) ((_ sign_extend 1) in34_32)) ((_ sign_extend 1) (bvadd in.08_32 in34_32))) true)))
(let (($x61 (or false false (or $x101))))
(let (($x74 (or $x61 (and (distinct (bvadd in.08_32 in34_32) (bvadd in.08_32 in34_32)) true))))
(and (not $x61) $x74)))))
(check-sat)
; query 6: function adpcm_coder, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.115_32 () (_ BitVec 32))
(assert
 (let (($x152 (or false false false)))
(let (($x270 (not $x152)))
(and $x270 (or $x152 (and (distinct (bvor in.115_32 (_ bv1 32)) (bvor in.115_32 (_ bv1 32))) true))))))
(check-sat)
; query 7: function adpcm_coder, block 43, name %45
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in41_32 () (_ BitVec 32))
(declare-fun in.19_32 () (_ BitVec 32))
(assert
 (let (($x646 (and (distinct (bvadd ((_ sign_extend 1) in.19_32) ((_ sign_extend 1) in41_32)) ((_ sign_extend 1) (bvadd in.19_32 in41_32))) true)))
(let (($x127 (or false false (or $x646))))
(let (($x122 (or $x127 (and (distinct (bvadd in.19_32 in41_32) (bvadd in.19_32 in41_32)) true))))
(and (not $x127) $x122)))))
(check-sat)
; query 8: function adpcm_coder, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.210_32 () (_ BitVec 32))
(declare-fun in.011_32 () (_ BitVec 32))
(assert
 (let ((?x28 (bvsub in.011_32 in.210_32)))
(let (($x343 (and (distinct (bvsub ((_ sign_extend 1) in.011_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x28)) true)))
(let (($x18 (or false false (or $x343))))
(and (not $x18) (or $x18 (and (distinct ?x28 ?x28) true)))))))
(check-sat)
; query 9: function adpcm_coder, block 50, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.210_32 () (_ BitVec 32))
(declare-fun in.011_32 () (_ BitVec 32))
(assert
 (let ((?x175 (bvadd in.011_32 in.210_32)))
(let (($x359 (and (distinct (bvadd ((_ sign_extend 1) in.011_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x175)) true)))
(let (($x245 (or false false (or $x359))))
(and (not $x245) (or $x245 (and (distinct ?x175 ?x175) true)))))))
(check-sat)
; query 10: function adpcm_coder, block 55, name %56
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.112_32 () (_ BitVec 32))
(assert
 (let ((?x115 (ite (bvsgt (_ bv4294934528 32) in.112_32) (_ bv1 1) (_ bv0 1))))
(let (($x152 (or false false false)))
(let (($x270 (not $x152)))
(and $x270 (or $x152 (and (distinct ?x115 ?x115) true)))))))
(check-sat)
; query 11: function adpcm_coder, block 75, name %76
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in60_32 () (_ BitVec 32))
(assert
 (let (($x48 (bvuge (_ bv4 32) (_ bv32 32))))
(let (($x51 (or (and (distinct (bvlshr (bvshl in60_32 (_ bv4 32)) (_ bv4 32)) in60_32) true) (and (distinct (bvashr (bvshl in60_32 (_ bv4 32)) (_ bv4 32)) in60_32) true))))
(let (($x746 (or (or false false $x51) $x48)))
(and (not (or (or false false false) $x48)) (or $x746 (and (distinct (bvshl in60_32 (_ bv4 32)) (bvshl in60_32 (_ bv4 32))) true)))))))
(check-sat)
; query 12: function adpcm_coder, block 75, name %77
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in60_32 () (_ BitVec 32))
(assert
 (let ((?x17 (bvshl in60_32 (_ bv4 32))))
(let ((?x309 (bvand ?x17 (_ bv240 32))))
(let (($x48 (bvuge (_ bv4 32) (_ bv32 32))))
(let (($x51 (or (and (distinct (bvlshr ?x17 (_ bv4 32)) in60_32) true) (and (distinct (bvashr ?x17 (_ bv4 32)) in60_32) true))))
(let (($x746 (or (or false false $x51) $x48)))
(and (not (or (or (or false false false) $x48) false false)) (or (or $x746 false false) (and (distinct ?x309 ?x309) true)))))))))
(check-sat)
; query 13: function adpcm_decoder, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x429 (ite (and (distinct (_ bv0 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x152 (or false false false)))
(let (($x270 (not $x152)))
(and $x270 (or $x152 (and (distinct ?x429 ?x429) true)))))))
(check-sat)
; query 14: function adpcm_decoder, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x152 (or false false false)))
(let (($x270 (not $x152)))
(and $x270 (or $x152 (and (distinct (bvand in.01_32 (_ bv15 32)) (bvand in.01_32 (_ bv15 32))) true))))))
(check-sat)
; query 15: function adpcm_decoder, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.012_32 () (_ BitVec 32))
(declare-fun in42_32 () (_ BitVec 32))
(assert
 (let (($x1124 (and (distinct (bvadd ((_ sign_extend 1) in42_32) ((_ sign_extend 1) in.012_32)) ((_ sign_extend 1) (bvadd in42_32 in.012_32))) true)))
(let (($x14 (or false false (or $x1124))))
(let (($x699 (or $x14 (and (distinct (bvadd in42_32 in.012_32) (bvadd in42_32 in.012_32)) true))))
(and (not $x14) $x699)))))
(check-sat)
; query 16: function adpcm_decoder, block 50, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.012_32 () (_ BitVec 32))
(assert
 (let (($x152 (or false false false)))
(let (($x240 (or $x152 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x570 (or $x240 (and (distinct (bvashr in.012_32 (_ bv1 32)) (bvashr in.012_32 (_ bv1 32))) true))))
(and (not $x240) $x570)))))
(check-sat)
; query 17: function adpcm_decoder, block 50, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.012_32 () (_ BitVec 32))
(declare-fun in.08_32 () (_ BitVec 32))
(assert
 (let ((?x696 (bvashr in.012_32 (_ bv1 32))))
(let ((?x63 (bvadd in.08_32 ?x696)))
(let (($x211 (and (distinct (bvadd ((_ sign_extend 1) in.08_32) ((_ sign_extend 1) ?x696)) ((_ sign_extend 1) ?x63)) true)))
(let (($x152 (or false false false)))
(let (($x240 (or $x152 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x98 (or false $x240 (or $x211))))
(and (not $x98) (or $x98 (and (distinct ?x63 ?x63) true))))))))))
(check-sat)
; query 18: function adpcm_decoder, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.012_32 () (_ BitVec 32))
(assert
 (let (($x152 (or false false false)))
(let (($x655 (or $x152 (bvuge (_ bv2 32) (_ bv32 32)))))
(let (($x1532 (or $x655 (and (distinct (bvashr in.012_32 (_ bv2 32)) (bvashr in.012_32 (_ bv2 32))) true))))
(and (not $x655) $x1532)))))
(check-sat)
; query 19: function adpcm_decoder, block 56, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.012_32 () (_ BitVec 32))
(declare-fun in.19_32 () (_ BitVec 32))
(assert
 (let ((?x1059 (bvashr in.012_32 (_ bv2 32))))
(let ((?x1238 (bvadd in.19_32 ?x1059)))
(let (($x511 (and (distinct (bvadd ((_ sign_extend 1) in.19_32) ((_ sign_extend 1) ?x1059)) ((_ sign_extend 1) ?x1238)) true)))
(let (($x152 (or false false false)))
(let (($x655 (or $x152 (bvuge (_ bv2 32) (_ bv32 32)))))
(let (($x1292 (or false $x655 (or $x511))))
(and (not $x1292) (or $x1292 (and (distinct ?x1238 ?x1238) true))))))))))
(check-sat)
; query 20: function adpcm_decoder, block 61, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.210_32 () (_ BitVec 32))
(declare-fun in.013_32 () (_ BitVec 32))
(assert
 (let ((?x77 (bvsub in.013_32 in.210_32)))
(let (($x821 (and (distinct (bvsub ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x77)) true)))
(let (($x145 (or false false (or $x821))))
(and (not $x145) (or $x145 (and (distinct ?x77 ?x77) true)))))))
(check-sat)
; query 21: function adpcm_decoder, block 63, name %64
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.210_32 () (_ BitVec 32))
(declare-fun in.013_32 () (_ BitVec 32))
(assert
 (let ((?x1413 (bvadd in.013_32 in.210_32)))
(let (($x1383 (and (distinct (bvadd ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x1413)) true)))
(let (($x1443 (or false false (or $x1383))))
(and (not $x1443) (or $x1443 (and (distinct ?x1413 ?x1413) true)))))))
(check-sat)
; query 22: function adpcm_decoder, block 68, name %69
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.114_32 () (_ BitVec 32))
(assert
 (let ((?x1473 (ite (bvsgt (_ bv4294934528 32) in.114_32) (_ bv1 1) (_ bv0 1))))
(let (($x152 (or false false false)))
(let (($x270 (not $x152)))
(and $x270 (or $x152 (and (distinct ?x1473 ?x1473) true)))))))
(check-sat)
; query 23: function adpcm_decoder, block 78, name %79
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x1116 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv4294967295 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv4294967295 32)))) true)))
(let (($x1156 (or false false (or $x1116))))
(and (not $x1156) (or $x1156 (and (distinct (bvadd in.02_32 (_ bv4294967295 32)) (bvadd in.02_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 24: function main, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x1071 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x152 (or false false false)))
(let (($x270 (not $x152)))
(and $x270 (or $x152 (and (distinct ?x1071 ?x1071) true)))))))
(check-sat)
