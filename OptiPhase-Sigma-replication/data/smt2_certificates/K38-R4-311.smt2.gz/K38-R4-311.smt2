; OptiPhase-Sigma refinement certificate for sweep K38-R4-311
; query 0: function BF_cbc_encrypt, block 126, name %127
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.010_64 () (_ BitVec 64))
(assert
 (let (($x77 (and (distinct (bvsub ((_ sign_extend 1) in.010_64) ((_ sign_extend 1) (_ bv8 64))) ((_ sign_extend 1) (bvsub in.010_64 (_ bv8 64)))) true)))
(let (($x428 (or false false (or $x77))))
(and (not $x428) (or $x428 (and (distinct (bvsub in.010_64 (_ bv8 64)) (bvsub in.010_64 (_ bv8 64))) true))))))
(check-sat)
; query 1: function BF_cbc_encrypt, block 128, name %129
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.010_64 () (_ BitVec 64))
(assert
 (let ((?x10 (ite (and (distinct (_ bv18446744073709551608 64) in.010_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x98 (or false false false)))
(let (($x405 (not $x98)))
(and $x405 (or $x98 (and (distinct ?x10 ?x10) true)))))))
(check-sat)
; query 2: function BF_cbc_encrypt, block 366, name %367
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.111_64 () (_ BitVec 64))
(assert
 (let (($x91 (and (distinct (bvsub ((_ sign_extend 1) in.111_64) ((_ sign_extend 1) (_ bv8 64))) ((_ sign_extend 1) (bvsub in.111_64 (_ bv8 64)))) true)))
(let (($x51 (or false false (or $x91))))
(and (not $x51) (or $x51 (and (distinct (bvsub in.111_64 (_ bv8 64)) (bvsub in.111_64 (_ bv8 64))) true))))))
(check-sat)
; query 3: function BF_cbc_encrypt, block 368, name %369
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.111_64 () (_ BitVec 64))
(assert
 (let ((?x23 (ite (and (distinct (_ bv18446744073709551608 64) in.111_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x98 (or false false false)))
(let (($x405 (not $x98)))
(and $x405 (or $x98 (and (distinct ?x23 ?x23) true)))))))
(check-sat)
; query 4: function BF_cfb64_encrypt, block 111, name %112
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.18_32 () (_ BitVec 32))
(assert
 (let ((?x45 (ite (= (_ bv0 32) in.18_32) (_ bv1 1) (_ bv0 1))))
(let (($x98 (or false false false)))
(let (($x405 (not $x98)))
(and $x405 (or $x98 (and (distinct ?x45 ?x45) true)))))))
(check-sat)
; query 5: function BF_cfb64_encrypt, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.07_32 () (_ BitVec 32))
(assert
 (let ((?x88 (ite (= (_ bv0 32) in.07_32) (_ bv1 1) (_ bv0 1))))
(let (($x98 (or false false false)))
(let (($x405 (not $x98)))
(and $x405 (or $x98 (and (distinct ?x88 ?x88) true)))))))
(check-sat)
; query 6: function BF_ofb64_encrypt, block 135, name %136
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x86 (ite (and (distinct (_ bv0 32) in.02_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x98 (or false false false)))
(let (($x405 (not $x98)))
(and $x405 (or $x98 (and (distinct ?x86 ?x86) true)))))))
(check-sat)
; query 7: function BF_ofb64_encrypt, block 82, name %83
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x562 (ite (= (_ bv0 32) in.04_32) (_ bv1 1) (_ bv0 1))))
(let (($x98 (or false false false)))
(let (($x405 (not $x98)))
(and $x405 (or $x98 (and (distinct ?x562 ?x562) true)))))))
(check-sat)
; query 8: function BF_set_key, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x260 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x90 (or false false (or $x260))))
(and (not $x90) (or $x90 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 9: function BF_set_key, block 69, name %70
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.13_32 () (_ BitVec 32))
(assert
 (let (($x245 (and (distinct (bvadd ((_ sign_extend 1) in.13_32) ((_ sign_extend 1) (_ bv2 32))) ((_ sign_extend 1) (bvadd in.13_32 (_ bv2 32)))) true)))
(let (($x275 (or false false (or $x245))))
(and (not $x275) (or $x275 (and (distinct (bvadd in.13_32 (_ bv2 32)) (bvadd in.13_32 (_ bv2 32))) true))))))
(check-sat)
; query 10: function BF_set_key, block 87, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.24_32 () (_ BitVec 32))
(assert
 (let (($x411 (and (distinct (bvadd ((_ sign_extend 1) in.24_32) ((_ sign_extend 1) (_ bv2 32))) ((_ sign_extend 1) (bvadd in.24_32 (_ bv2 32)))) true)))
(let (($x182 (or false false (or $x411))))
(and (not $x182) (or $x182 (and (distinct (bvadd in.24_32 (_ bv2 32)) (bvadd in.24_32 (_ bv2 32))) true))))))
(check-sat)
; query 11: function main, block 124, name %125
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let ((?x398 (ite (bvsgt (_ bv40 32) in.2_32) (_ bv1 1) (_ bv0 1))))
(let (($x98 (or false false false)))
(let (($x405 (not $x98)))
(and $x405 (or $x98 (and (distinct ?x398 ?x398) true)))))))
(check-sat)
; query 12: function main, block 147, name %148
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x150 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x410 (or false false (or $x150))))
(and (not $x410) (or $x410 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 13: function main, block 60, name %61
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x460 (or false false)))
(and (not $x460) (or $x460 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 14: function main, block 60, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x61 (ite (bvsge (_ bv57 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x460 (or false false)))
(let (($x343 (or $x460 false false)))
(let (($x144 (not $x343)))
(and $x144 (or $x343 (and (distinct ?x61 ?x61) true))))))))
(check-sat)
; query 15: function main, block 63, name %64
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x98 (or false false false)))
(let (($x146 (or $x98 (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x146) (or $x146 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvshl in.01_32 (_ bv4 32))) true))))))
(check-sat)
; query 16: function main, block 63, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x460 (or false false)))
(and (not $x460) (or $x460 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 17: function main, block 63, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x159 ((_ sign_extend 24) in57_8)))
(let ((?x149 (bvshl in.01_32 (_ bv4 32))))
(let ((?x557 (bvadd ?x149 ?x159)))
(let ((?x307 ((_ sign_extend 1) ?x557)))
(let (($x460 (or false false)))
(let (($x98 (or false false false)))
(let (($x146 (or $x98 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x108 (or $x146 $x460 (or (and (distinct (bvadd ((_ sign_extend 1) ?x149) ((_ sign_extend 1) ?x159)) ?x307) true)))))
(and (not $x108) (or $x108 (and (distinct ?x557 ?x557) true))))))))))))
(check-sat)
; query 18: function main, block 63, name %67
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x159 ((_ sign_extend 24) in57_8)))
(let ((?x149 (bvshl in.01_32 (_ bv4 32))))
(let ((?x557 (bvadd ?x149 ?x159)))
(let ((?x426 (bvsub ?x557 (_ bv48 32))))
(let (($x48 (and (distinct (bvsub ((_ sign_extend 1) ?x557) ((_ sign_extend 1) (_ bv48 32))) ((_ sign_extend 1) ?x426)) true)))
(let ((?x307 ((_ sign_extend 1) ?x557)))
(let (($x460 (or false false)))
(let (($x98 (or false false false)))
(let (($x146 (or $x98 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x108 (or $x146 $x460 (or (and (distinct (bvadd ((_ sign_extend 1) ?x149) ((_ sign_extend 1) ?x159)) ?x307) true)))))
(let (($x611 (or $x108 false (or $x48))))
(and (not $x611) (or $x611 (and (distinct ?x426 ?x426) true)))))))))))))))
(check-sat)
; query 19: function main, block 68, name %69
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x460 (or false false)))
(and (not $x460) (or $x460 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 20: function main, block 68, name %70
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x176 (ite (bvsle (_ bv65 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x460 (or false false)))
(let (($x343 (or $x460 false false)))
(let (($x144 (not $x343)))
(and $x144 (or $x343 (and (distinct ?x176 ?x176) true))))))))
(check-sat)
; query 21: function main, block 71, name %72
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x460 (or false false)))
(and (not $x460) (or $x460 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 22: function main, block 71, name %73
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x118 (ite (bvsge (_ bv70 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x460 (or false false)))
(let (($x343 (or $x460 false false)))
(let (($x144 (not $x343)))
(and $x144 (or $x343 (and (distinct ?x118 ?x118) true))))))))
(check-sat)
; query 23: function main, block 74, name %75
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x98 (or false false false)))
(let (($x146 (or $x98 (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x146) (or $x146 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvshl in.01_32 (_ bv4 32))) true))))))
(check-sat)
; query 24: function main, block 74, name %76
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x460 (or false false)))
(and (not $x460) (or $x460 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 25: function main, block 74, name %77
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x159 ((_ sign_extend 24) in57_8)))
(let ((?x149 (bvshl in.01_32 (_ bv4 32))))
(let ((?x557 (bvadd ?x149 ?x159)))
(let ((?x307 ((_ sign_extend 1) ?x557)))
(let (($x460 (or false false)))
(let (($x98 (or false false false)))
(let (($x146 (or $x98 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x108 (or $x146 $x460 (or (and (distinct (bvadd ((_ sign_extend 1) ?x149) ((_ sign_extend 1) ?x159)) ?x307) true)))))
(and (not $x108) (or $x108 (and (distinct ?x557 ?x557) true))))))))))))
(check-sat)
; query 26: function main, block 74, name %78
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x159 ((_ sign_extend 24) in57_8)))
(let ((?x149 (bvshl in.01_32 (_ bv4 32))))
(let ((?x557 (bvadd ?x149 ?x159)))
(let ((?x329 (bvsub ?x557 (_ bv65 32))))
(let ((?x543 ((_ sign_extend 1) ?x329)))
(let ((?x307 ((_ sign_extend 1) ?x557)))
(let (($x460 (or false false)))
(let (($x98 (or false false false)))
(let (($x146 (or $x98 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x108 (or $x146 $x460 (or (and (distinct (bvadd ((_ sign_extend 1) ?x149) ((_ sign_extend 1) ?x159)) ?x307) true)))))
(let (($x257 (or $x108 false (or (and (distinct (bvsub ?x307 ((_ sign_extend 1) (_ bv65 32))) ?x543) true)))))
(and (not $x257) (or $x257 (and (distinct ?x329 ?x329) true)))))))))))))))
(check-sat)
; query 27: function main, block 74, name %79
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x159 ((_ sign_extend 24) in57_8)))
(let ((?x149 (bvshl in.01_32 (_ bv4 32))))
(let ((?x557 (bvadd ?x149 ?x159)))
(let ((?x329 (bvsub ?x557 (_ bv65 32))))
(let ((?x120 (bvadd ?x329 (_ bv10 32))))
(let (($x190 (and (distinct (bvadd ((_ sign_extend 1) ?x329) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x120)) true)))
(let ((?x543 ((_ sign_extend 1) ?x329)))
(let ((?x307 ((_ sign_extend 1) ?x557)))
(let (($x460 (or false false)))
(let (($x98 (or false false false)))
(let (($x146 (or $x98 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x108 (or $x146 $x460 (or (and (distinct (bvadd ((_ sign_extend 1) ?x149) ((_ sign_extend 1) ?x159)) ?x307) true)))))
(let (($x257 (or $x108 false (or (and (distinct (bvsub ?x307 ((_ sign_extend 1) (_ bv65 32))) ?x543) true)))))
(let (($x49 (or $x257 false (or $x190))))
(and (not $x49) (or $x49 (and (distinct ?x120 ?x120) true))))))))))))))))))
(check-sat)
