; OptiPhase-Sigma refinement certificate for sweep K25-R3-140
