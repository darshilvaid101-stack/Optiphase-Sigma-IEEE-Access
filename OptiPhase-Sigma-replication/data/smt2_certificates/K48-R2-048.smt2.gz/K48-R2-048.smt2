; OptiPhase-Sigma refinement certificate for sweep K48-R2-048
; query 0: function APCM_inverse_quantization, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 1: function APCM_inverse_quantization, block 7, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1856 (ite (bvsge (_ bv7 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x41 (not $x73)))
(and $x41 (or $x73 (and (distinct ?x1856 ?x1856) true))))))))
(check-sat)
; query 2: function APCM_inverse_quantization, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 3: function APCM_inverse_quantization, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x25 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x41 (not $x73)))
(and $x41 (or $x73 (and (distinct ?x25 ?x25) true))))))))
(check-sat)
; query 4: function APCM_quantization, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in13_16) ((_ sign_extend 16) in13_16)) true))))))
(check-sat)
; query 5: function APCM_quantization, block 16, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_16 () (_ BitVec 16))
(assert
 (let ((?x86 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in13_16)) (_ bv1 1) (_ bv0 1))))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x41 (not $x73)))
(and $x41 (or $x73 (and (distinct ?x86 ?x86) true))))))))
(check-sat)
; query 6: function APCM_quantization, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in13_16) ((_ sign_extend 16) in13_16)) true))))))
(check-sat)
; query 7: function APCM_quantization, block 20, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_16 () (_ BitVec 16))
(assert
 (let ((?x124 ((_ sign_extend 16) in13_16)))
(let ((?x167 (bvsub (_ bv0 32) ?x124)))
(let (($x229 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x124)) ((_ sign_extend 1) ?x167)) true)))
(let (($x224 (or false false)))
(let (($x29 (or false $x224 (or $x229))))
(and (not $x29) (or $x29 (and (distinct ?x167 ?x167) true)))))))))
(check-sat)
; query 8: function APCM_quantization, block 25, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in13_16) ((_ sign_extend 16) in13_16)) true))))))
(check-sat)
; query 9: function APCM_quantization, block 35, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_32 () (_ BitVec 32))
(assert
 (let (($x714 (and (distinct (bvadd ((_ sign_extend 1) in.03_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.03_32 (_ bv1 32)))) true)))
(let (($x66 (or false false (or $x714))))
(and (not $x66) (or $x66 (and (distinct (bvadd in.03_32 (_ bv1 32)) (bvadd in.03_32 (_ bv1 32))) true))))))
(check-sat)
; query 10: function APCM_quantization_xmaxc_to_exp_mant, block 24, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in.0_16) ((_ sign_extend 16) in.0_16)) true))))))
(check-sat)
; query 11: function APCM_quantization_xmaxc_to_exp_mant, block 24, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let ((?x113 ((_ sign_extend 16) in.0_16)))
(let ((?x48 (bvshl ?x113 (_ bv1 32))))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x17 (or $x73 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x379 (not $x17)))
(and $x379 (or $x17 (and (distinct ?x48 ?x48) true))))))))))
(check-sat)
; query 12: function APCM_quantization_xmaxc_to_exp_mant, block 24, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let ((?x113 ((_ sign_extend 16) in.0_16)))
(let ((?x48 (bvshl ?x113 (_ bv1 32))))
(let ((?x64 (bvor ?x48 (_ bv1 32))))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x17 (or $x73 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x209 (or $x17 false false)))
(and (not $x209) (or $x209 (and (distinct ?x64 ?x64) true)))))))))))
(check-sat)
; query 13: function APCM_quantization_xmaxc_to_exp_mant, block 24, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let ((?x113 ((_ sign_extend 16) in.0_16)))
(let ((?x48 (bvshl ?x113 (_ bv1 32))))
(let ((?x64 (bvor ?x48 (_ bv1 32))))
(let ((?x462 ((_ extract 15 0) ?x64)))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x17 (or $x73 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x209 (or $x17 false false)))
(let (($x151 (or $x209 false)))
(and (not $x151) (or $x151 (and (distinct ?x462 ?x462) true)))))))))))))
(check-sat)
; query 14: function APCM_quantization_xmaxc_to_exp_mant, block 24, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_16 () (_ BitVec 16))
(assert
 (let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct (bvadd in.12_16 (_ bv65535 16)) (bvadd in.12_16 (_ bv65535 16))) true))))))
(check-sat)
; query 15: function APCM_quantization_xmaxc_to_exp_mant, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in.0_16) ((_ sign_extend 16) in.0_16)) true))))))
(check-sat)
; query 16: function APCM_quantization_xmaxc_to_exp_mant, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let ((?x113 ((_ sign_extend 16) in.0_16)))
(let ((?x107 (bvsub ?x113 (_ bv8 32))))
(let (($x117 (and (distinct (bvsub ((_ sign_extend 1) ?x113) ((_ sign_extend 1) (_ bv8 32))) ((_ sign_extend 1) ?x107)) true)))
(let (($x224 (or false false)))
(let (($x51 (or $x224 false (or $x117))))
(and (not $x51) (or $x51 (and (distinct ?x107 ?x107) true)))))))))
(check-sat)
; query 17: function APCM_quantization_xmaxc_to_exp_mant, block 30, name %33
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let ((?x113 ((_ sign_extend 16) in.0_16)))
(let ((?x107 (bvsub ?x113 (_ bv8 32))))
(let ((?x179 ((_ extract 15 0) ?x107)))
(let (($x117 (and (distinct (bvsub ((_ sign_extend 1) ?x113) ((_ sign_extend 1) (_ bv8 32))) ((_ sign_extend 1) ?x107)) true)))
(let (($x224 (or false false)))
(let (($x51 (or $x224 false (or $x117))))
(let (($x653 (or $x51 false)))
(and (not $x653) (or $x653 (and (distinct ?x179 ?x179) true)))))))))))
(check-sat)
; query 18: function APCM_quantization_xmaxc_to_exp_mant, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in.2_16) ((_ sign_extend 16) in.2_16)) true))))))
(check-sat)
; query 19: function APCM_quantization_xmaxc_to_exp_mant, block 37, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_16 () (_ BitVec 16))
(assert
 (let ((?x131 (ite (bvsge (_ bv6 32) ((_ sign_extend 16) in.2_16)) (_ bv1 1) (_ bv0 1))))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x41 (not $x73)))
(and $x41 (or $x73 (and (distinct ?x131 ?x131) true))))))))
(check-sat)
; query 20: function APCM_quantization_xmaxc_to_exp_mant, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x90 ((_ sign_extend 16) in0_16)))
(let ((?x637 (bvashr ?x90 (_ bv3 32))))
(let ((?x8 (bvsub ?x637 (_ bv1 32))))
(let ((?x53 ((_ extract 15 0) ?x8)))
(let (($x623 (and (distinct (bvsub ((_ sign_extend 1) ?x637) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x8)) true)))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x13 (or $x73 (bvuge (_ bv3 32) (_ bv32 32)))))
(let (($x95 (or $x13 false (or $x623))))
(let (($x6 (or $x95 false)))
(and (not $x6) (or $x6 (and (distinct ?x53 ?x53) true))))))))))))))
(check-sat)
; query 21: function APCM_quantization_xmaxc_to_exp_mant, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 22: function APCM_quantization_xmaxc_to_exp_mant, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x90 ((_ sign_extend 16) in0_16)))
(let ((?x637 (bvashr ?x90 (_ bv3 32))))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x13 (or $x73 (bvuge (_ bv3 32) (_ bv32 32)))))
(and (not $x13) (or $x13 (and (distinct ?x637 ?x637) true)))))))))
(check-sat)
; query 23: function APCM_quantization_xmaxc_to_exp_mant, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x90 ((_ sign_extend 16) in0_16)))
(let ((?x637 (bvashr ?x90 (_ bv3 32))))
(let ((?x8 (bvsub ?x637 (_ bv1 32))))
(let (($x623 (and (distinct (bvsub ((_ sign_extend 1) ?x637) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x8)) true)))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x13 (or $x73 (bvuge (_ bv3 32) (_ bv32 32)))))
(let (($x95 (or $x13 false (or $x623))))
(and (not $x95) (or $x95 (and (distinct ?x8 ?x8) true))))))))))))
(check-sat)
; query 24: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 25: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x917 (ite (bvslt (_ bv15 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x41 (not $x73)))
(and $x41 (or $x73 (and (distinct ?x917 ?x917) true))))))))
(check-sat)
; query 26: function Autocorrelation, block 39, name %40
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x1658 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x618 (or false false (or $x1658))))
(and (not $x618) (or $x618 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 27: function Autocorrelation, block 41, name %42
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in.04_16) ((_ sign_extend 16) in.04_16)) true))))))
(check-sat)
; query 28: function Autocorrelation, block 41, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let ((?x1402 (ite (= (_ bv0 32) ((_ sign_extend 16) in.04_16)) (_ bv1 1) (_ bv0 1))))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x41 (not $x73)))
(and $x41 (or $x73 (and (distinct ?x1402 ?x1402) true))))))))
(check-sat)
; query 29: function Autocorrelation, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in.04_16) ((_ sign_extend 16) in.04_16)) true))))))
(check-sat)
; query 30: function Autocorrelation, block 45, name %47
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let ((?x1723 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.04_16)) (_ bv1 1) (_ bv0 1))))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x41 (not $x73)))
(and $x41 (or $x73 (and (distinct ?x1723 ?x1723) true))))))))
(check-sat)
; query 31: function Autocorrelation, block 45, name %48
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let ((?x1723 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.04_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1719 (bvxor ?x1723 (_ bv1 1))))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x1722 (or $x73 false false)))
(let (($x1029 (not $x1722)))
(and $x1029 (or $x1722 (and (distinct ?x1719 ?x1719) true))))))))))
(check-sat)
; query 32: function Autocorrelation, block 45, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let ((?x1723 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.04_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1719 (bvxor ?x1723 (_ bv1 1))))
(let ((?x1592 ((_ zero_extend 31) ?x1719)))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x1722 (or $x73 false false)))
(let (($x1730 (or $x1722 false)))
(let (($x1850 (not $x1730)))
(and $x1850 (or $x1730 (and (distinct ?x1592 ?x1592) true))))))))))))
(check-sat)
; query 33: function Autocorrelation, block 45, name %50
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let ((?x1723 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.04_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1719 (bvxor ?x1723 (_ bv1 1))))
(let ((?x1592 ((_ zero_extend 31) ?x1719)))
(let ((?x157 ((_ sign_extend 32) ?x1592)))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x1722 (or $x73 false false)))
(let (($x1730 (or $x1722 false)))
(let (($x1959 (or $x1730 false)))
(let (($x1868 (not $x1959)))
(and $x1868 (or $x1959 (and (distinct ?x157 ?x157) true))))))))))))))
(check-sat)
; query 34: function Autocorrelation, block 45, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let ((?x1723 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.04_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1719 (bvxor ?x1723 (_ bv1 1))))
(let ((?x1592 ((_ zero_extend 31) ?x1719)))
(let ((?x157 ((_ sign_extend 32) ?x1592)))
(let ((?x1214 (ite (and (distinct (_ bv0 64) ?x157) true) (_ bv1 1) (_ bv0 1))))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x1722 (or $x73 false false)))
(let (($x1730 (or $x1722 false)))
(let (($x1959 (or $x1730 false)))
(let (($x654 (or $x1959 false false)))
(let (($x1662 (not $x654)))
(and $x1662 (or $x654 (and (distinct ?x1214 ?x1214) true))))))))))))))))
(check-sat)
; query 35: function Calculation_of_the_LTP_parameters, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in11_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in11_16) ((_ sign_extend 16) in11_16)) true))))))
(check-sat)
; query 36: function Calculation_of_the_LTP_parameters, block 14, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in11_16 () (_ BitVec 16))
(assert
 (let ((?x1914 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in11_16)) (_ bv1 1) (_ bv0 1))))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x41 (not $x73)))
(and $x41 (or $x73 (and (distinct ?x1914 ?x1914) true))))))))
(check-sat)
; query 37: function Calculation_of_the_LTP_parameters, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in11_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in11_16) ((_ sign_extend 16) in11_16)) true))))))
(check-sat)
; query 38: function Calculation_of_the_LTP_parameters, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in11_16 () (_ BitVec 16))
(assert
 (let ((?x616 ((_ sign_extend 16) in11_16)))
(let ((?x1203 (bvsub (_ bv0 32) ?x616)))
(let (($x1476 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x616)) ((_ sign_extend 1) ?x1203)) true)))
(let (($x224 (or false false)))
(let (($x503 (or false $x224 (or $x1476))))
(and (not $x503) (or $x503 (and (distinct ?x1203 ?x1203) true)))))))))
(check-sat)
; query 39: function Calculation_of_the_LTP_parameters, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in11_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in11_16) ((_ sign_extend 16) in11_16)) true))))))
(check-sat)
; query 40: function Calculation_of_the_LTP_parameters, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_32 () (_ BitVec 32))
(assert
 (let (($x714 (and (distinct (bvadd ((_ sign_extend 1) in.03_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.03_32 (_ bv1 32)))) true)))
(let (($x66 (or false false (or $x714))))
(and (not $x66) (or $x66 (and (distinct (bvadd in.03_32 (_ bv1 32)) (bvadd in.03_32 (_ bv1 32))) true))))))
(check-sat)
; query 41: function Calculation_of_the_LTP_parameters, block 35, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in.02_16) ((_ sign_extend 16) in.02_16)) true))))))
(check-sat)
; query 42: function Calculation_of_the_LTP_parameters, block 35, name %37
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x588 (ite (= (_ bv0 32) ((_ sign_extend 16) in.02_16)) (_ bv1 1) (_ bv0 1))))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x41 (not $x73)))
(and $x41 (or $x73 (and (distinct ?x588 ?x588) true))))))))
(check-sat)
; query 43: function Calculation_of_the_LTP_parameters, block 39, name %40
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in.02_16) ((_ sign_extend 16) in.02_16)) true))))))
(check-sat)
; query 44: function Calculation_of_the_LTP_parameters, block 39, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x1983 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.02_16)) (_ bv1 1) (_ bv0 1))))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x41 (not $x73)))
(and $x41 (or $x73 (and (distinct ?x1983 ?x1983) true))))))))
(check-sat)
; query 45: function Calculation_of_the_LTP_parameters, block 39, name %42
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x1983 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.02_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1984 (bvxor ?x1983 (_ bv1 1))))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x1722 (or $x73 false false)))
(let (($x1029 (not $x1722)))
(and $x1029 (or $x1722 (and (distinct ?x1984 ?x1984) true))))))))))
(check-sat)
; query 46: function Calculation_of_the_LTP_parameters, block 39, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x1983 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.02_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1984 (bvxor ?x1983 (_ bv1 1))))
(let ((?x1898 ((_ zero_extend 31) ?x1984)))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x1722 (or $x73 false false)))
(let (($x1730 (or $x1722 false)))
(let (($x1850 (not $x1730)))
(and $x1850 (or $x1730 (and (distinct ?x1898 ?x1898) true))))))))))))
(check-sat)
; query 47: function Calculation_of_the_LTP_parameters, block 39, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x1983 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.02_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1984 (bvxor ?x1983 (_ bv1 1))))
(let ((?x1898 ((_ zero_extend 31) ?x1984)))
(let ((?x1935 ((_ sign_extend 32) ?x1898)))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x1722 (or $x73 false false)))
(let (($x1730 (or $x1722 false)))
(let (($x1959 (or $x1730 false)))
(let (($x1868 (not $x1959)))
(and $x1868 (or $x1959 (and (distinct ?x1935 ?x1935) true))))))))))))))
(check-sat)
; query 48: function Calculation_of_the_LTP_parameters, block 39, name %45
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x1983 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in.02_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x1984 (bvxor ?x1983 (_ bv1 1))))
(let ((?x1898 ((_ zero_extend 31) ?x1984)))
(let ((?x1935 ((_ sign_extend 32) ?x1898)))
(let ((?x1961 (ite (and (distinct (_ bv0 64) ?x1935) true) (_ bv1 1) (_ bv0 1))))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x1722 (or $x73 false false)))
(let (($x1730 (or $x1722 false)))
(let (($x1959 (or $x1730 false)))
(let (($x654 (or $x1959 false false)))
(let (($x1662 (not $x654)))
(and $x1662 (or $x654 (and (distinct ?x1961 ?x1961) true))))))))))))))))
(check-sat)
; query 49: function Coefficients_0_12, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in15_64 () (_ BitVec 64))
(assert
 (let ((?x1221 (ite (bvslt (_ bv0 64) in15_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x1221 ?x1221) true)))))))
(check-sat)
; query 50: function Coefficients_0_12, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in15_64 () (_ BitVec 64))
(assert
 (let ((?x1221 (ite (bvslt (_ bv0 64) in15_64) (_ bv1 1) (_ bv0 1))))
(let ((?x504 ((_ zero_extend 63) ?x1221)))
(let (($x57 (or false false false)))
(let (($x686 (or $x57 false)))
(let (($x1855 (not $x686)))
(and $x1855 (or $x686 (and (distinct ?x504 ?x504) true)))))))))
(check-sat)
; query 51: function Coefficients_0_12, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in15_64 () (_ BitVec 64))
(assert
 (let ((?x1221 (ite (bvslt (_ bv0 64) in15_64) (_ bv1 1) (_ bv0 1))))
(let (($x128 (= (_ bv1 1) ?x1221)))
(let ((?x631 (ite $x128 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x57 (or false false false)))
(let (($x598 (or $x57 (ite $x128 false false))))
(and (not $x598) (or $x598 (and (distinct ?x631 ?x631) true)))))))))
(check-sat)
; query 52: function Coefficients_0_12, block 18, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in15_64 () (_ BitVec 64))
(assert
 (let ((?x1221 (ite (bvslt (_ bv0 64) in15_64) (_ bv1 1) (_ bv0 1))))
(let (($x128 (= (_ bv1 1) ?x1221)))
(let ((?x631 (ite $x128 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x121 ((_ sign_extend 32) ?x631)))
(let (($x57 (or false false false)))
(let (($x598 (or $x57 (ite $x128 false false))))
(let (($x352 (or $x598 false)))
(and (not $x352) (or $x352 (and (distinct ?x121 ?x121) true)))))))))))
(check-sat)
; query 53: function Coefficients_0_12, block 36, name %37
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in33_64 () (_ BitVec 64))
(assert
 (let ((?x447 (ite (bvslt (_ bv0 64) in33_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x447 ?x447) true)))))))
(check-sat)
; query 54: function Coefficients_0_12, block 36, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in33_64 () (_ BitVec 64))
(assert
 (let ((?x447 (ite (bvslt (_ bv0 64) in33_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1889 ((_ zero_extend 63) ?x447)))
(let (($x57 (or false false false)))
(let (($x686 (or $x57 false)))
(let (($x1855 (not $x686)))
(and $x1855 (or $x686 (and (distinct ?x1889 ?x1889) true)))))))))
(check-sat)
; query 55: function Coefficients_0_12, block 36, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in33_64 () (_ BitVec 64))
(assert
 (let ((?x447 (ite (bvslt (_ bv0 64) in33_64) (_ bv1 1) (_ bv0 1))))
(let (($x351 (= (_ bv1 1) ?x447)))
(let ((?x1834 (ite $x351 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x57 (or false false false)))
(let (($x354 (or $x57 (ite $x351 false false))))
(and (not $x354) (or $x354 (and (distinct ?x1834 ?x1834) true)))))))))
(check-sat)
; query 56: function Coefficients_0_12, block 36, name %40
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in33_64 () (_ BitVec 64))
(assert
 (let ((?x447 (ite (bvslt (_ bv0 64) in33_64) (_ bv1 1) (_ bv0 1))))
(let (($x351 (= (_ bv1 1) ?x447)))
(let ((?x1834 (ite $x351 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x464 ((_ sign_extend 32) ?x1834)))
(let (($x57 (or false false false)))
(let (($x354 (or $x57 (ite $x351 false false))))
(let (($x1008 (or $x354 false)))
(and (not $x1008) (or $x1008 (and (distinct ?x464 ?x464) true)))))))))))
(check-sat)
; query 57: function Coefficients_13_26, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in15_64 () (_ BitVec 64))
(assert
 (let ((?x1221 (ite (bvslt (_ bv0 64) in15_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x1221 ?x1221) true)))))))
(check-sat)
; query 58: function Coefficients_13_26, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in15_64 () (_ BitVec 64))
(assert
 (let ((?x1221 (ite (bvslt (_ bv0 64) in15_64) (_ bv1 1) (_ bv0 1))))
(let ((?x504 ((_ zero_extend 63) ?x1221)))
(let (($x57 (or false false false)))
(let (($x686 (or $x57 false)))
(let (($x1855 (not $x686)))
(and $x1855 (or $x686 (and (distinct ?x504 ?x504) true)))))))))
(check-sat)
; query 59: function Coefficients_13_26, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in15_64 () (_ BitVec 64))
(assert
 (let ((?x1221 (ite (bvslt (_ bv0 64) in15_64) (_ bv1 1) (_ bv0 1))))
(let (($x128 (= (_ bv1 1) ?x1221)))
(let ((?x631 (ite $x128 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x57 (or false false false)))
(let (($x598 (or $x57 (ite $x128 false false))))
(and (not $x598) (or $x598 (and (distinct ?x631 ?x631) true)))))))))
(check-sat)
; query 60: function Coefficients_13_26, block 18, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in15_64 () (_ BitVec 64))
(assert
 (let ((?x1221 (ite (bvslt (_ bv0 64) in15_64) (_ bv1 1) (_ bv0 1))))
(let (($x128 (= (_ bv1 1) ?x1221)))
(let ((?x631 (ite $x128 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x121 ((_ sign_extend 32) ?x631)))
(let (($x57 (or false false false)))
(let (($x598 (or $x57 (ite $x128 false false))))
(let (($x352 (or $x598 false)))
(and (not $x352) (or $x352 (and (distinct ?x121 ?x121) true)))))))))))
(check-sat)
; query 61: function Coefficients_27_39, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in15_64 () (_ BitVec 64))
(assert
 (let ((?x1221 (ite (bvslt (_ bv0 64) in15_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x1221 ?x1221) true)))))))
(check-sat)
; query 62: function Coefficients_27_39, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in15_64 () (_ BitVec 64))
(assert
 (let ((?x1221 (ite (bvslt (_ bv0 64) in15_64) (_ bv1 1) (_ bv0 1))))
(let ((?x504 ((_ zero_extend 63) ?x1221)))
(let (($x57 (or false false false)))
(let (($x686 (or $x57 false)))
(let (($x1855 (not $x686)))
(and $x1855 (or $x686 (and (distinct ?x504 ?x504) true)))))))))
(check-sat)
; query 63: function Coefficients_27_39, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in15_64 () (_ BitVec 64))
(assert
 (let ((?x1221 (ite (bvslt (_ bv0 64) in15_64) (_ bv1 1) (_ bv0 1))))
(let (($x128 (= (_ bv1 1) ?x1221)))
(let ((?x631 (ite $x128 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x57 (or false false false)))
(let (($x598 (or $x57 (ite $x128 false false))))
(and (not $x598) (or $x598 (and (distinct ?x631 ?x631) true)))))))))
(check-sat)
; query 64: function Coefficients_27_39, block 18, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in15_64 () (_ BitVec 64))
(assert
 (let ((?x1221 (ite (bvslt (_ bv0 64) in15_64) (_ bv1 1) (_ bv0 1))))
(let (($x128 (= (_ bv1 1) ?x1221)))
(let ((?x631 (ite $x128 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x121 ((_ sign_extend 32) ?x631)))
(let (($x57 (or false false false)))
(let (($x598 (or $x57 (ite $x128 false false))))
(let (($x352 (or $x598 false)))
(and (not $x352) (or $x352 (and (distinct ?x121 ?x121) true)))))))))))
(check-sat)
; query 65: function Coefficients_27_39, block 36, name %37
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in33_64 () (_ BitVec 64))
(assert
 (let ((?x447 (ite (bvslt (_ bv0 64) in33_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x447 ?x447) true)))))))
(check-sat)
; query 66: function Coefficients_27_39, block 36, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in33_64 () (_ BitVec 64))
(assert
 (let ((?x447 (ite (bvslt (_ bv0 64) in33_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1889 ((_ zero_extend 63) ?x447)))
(let (($x57 (or false false false)))
(let (($x686 (or $x57 false)))
(let (($x1855 (not $x686)))
(and $x1855 (or $x686 (and (distinct ?x1889 ?x1889) true)))))))))
(check-sat)
; query 67: function Coefficients_27_39, block 36, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in33_64 () (_ BitVec 64))
(assert
 (let ((?x447 (ite (bvslt (_ bv0 64) in33_64) (_ bv1 1) (_ bv0 1))))
(let (($x351 (= (_ bv1 1) ?x447)))
(let ((?x1834 (ite $x351 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x57 (or false false false)))
(let (($x354 (or $x57 (ite $x351 false false))))
(and (not $x354) (or $x354 (and (distinct ?x1834 ?x1834) true)))))))))
(check-sat)
; query 68: function Coefficients_27_39, block 36, name %40
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in33_64 () (_ BitVec 64))
(assert
 (let ((?x447 (ite (bvslt (_ bv0 64) in33_64) (_ bv1 1) (_ bv0 1))))
(let (($x351 (= (_ bv1 1) ?x447)))
(let ((?x1834 (ite $x351 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x464 ((_ sign_extend 32) ?x1834)))
(let (($x57 (or false false false)))
(let (($x354 (or $x57 (ite $x351 false false))))
(let (($x1008 (or $x354 false)))
(and (not $x1008) (or $x1008 (and (distinct ?x464 ?x464) true)))))))))))
(check-sat)
; query 69: function Decoding_of_the_coded_Log_Area_Ratios, block 107, name %108
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in104_64 () (_ BitVec 64))
(assert
 (let ((?x655 (ite (bvslt (_ bv0 64) in104_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x655 ?x655) true)))))))
(check-sat)
; query 70: function Decoding_of_the_coded_Log_Area_Ratios, block 107, name %109
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in104_64 () (_ BitVec 64))
(assert
 (let ((?x655 (ite (bvslt (_ bv0 64) in104_64) (_ bv1 1) (_ bv0 1))))
(let ((?x739 ((_ zero_extend 63) ?x655)))
(let (($x57 (or false false false)))
(let (($x686 (or $x57 false)))
(let (($x1855 (not $x686)))
(and $x1855 (or $x686 (and (distinct ?x739 ?x739) true)))))))))
(check-sat)
; query 71: function Decoding_of_the_coded_Log_Area_Ratios, block 107, name %110
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in104_64 () (_ BitVec 64))
(assert
 (let ((?x655 (ite (bvslt (_ bv0 64) in104_64) (_ bv1 1) (_ bv0 1))))
(let (($x1131 (= (_ bv1 1) ?x655)))
(let ((?x1741 (ite $x1131 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x57 (or false false false)))
(let (($x103 (or $x57 (ite $x1131 false false))))
(and (not $x103) (or $x103 (and (distinct ?x1741 ?x1741) true)))))))))
(check-sat)
; query 72: function Decoding_of_the_coded_Log_Area_Ratios, block 107, name %111
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in104_64 () (_ BitVec 64))
(assert
 (let ((?x655 (ite (bvslt (_ bv0 64) in104_64) (_ bv1 1) (_ bv0 1))))
(let (($x1131 (= (_ bv1 1) ?x655)))
(let ((?x1741 (ite $x1131 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x1804 ((_ sign_extend 32) ?x1741)))
(let (($x57 (or false false false)))
(let (($x103 (or $x57 (ite $x1131 false false))))
(let (($x1829 (or $x103 false)))
(and (not $x1829) (or $x1829 (and (distinct ?x1804 ?x1804) true)))))))))))
(check-sat)
; query 73: function Decoding_of_the_coded_Log_Area_Ratios, block 121, name %122
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in118_64 () (_ BitVec 64))
(assert
 (let ((?x790 (ite (bvsge (_ bv18446744073709518848 64) in118_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x790 ?x790) true)))))))
(check-sat)
; query 74: function Decoding_of_the_coded_Log_Area_Ratios, block 140, name %141
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in137_64 () (_ BitVec 64))
(assert
 (let ((?x1864 (ite (bvslt (_ bv0 64) in137_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x1864 ?x1864) true)))))))
(check-sat)
; query 75: function Decoding_of_the_coded_Log_Area_Ratios, block 140, name %142
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in137_64 () (_ BitVec 64))
(assert
 (let ((?x1864 (ite (bvslt (_ bv0 64) in137_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1839 ((_ zero_extend 63) ?x1864)))
(let (($x57 (or false false false)))
(let (($x686 (or $x57 false)))
(let (($x1855 (not $x686)))
(and $x1855 (or $x686 (and (distinct ?x1839 ?x1839) true)))))))))
(check-sat)
; query 76: function Decoding_of_the_coded_Log_Area_Ratios, block 140, name %143
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in137_64 () (_ BitVec 64))
(assert
 (let ((?x1864 (ite (bvslt (_ bv0 64) in137_64) (_ bv1 1) (_ bv0 1))))
(let (($x1853 (= (_ bv1 1) ?x1864)))
(let ((?x1871 (ite $x1853 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x57 (or false false false)))
(let (($x1845 (or $x57 (ite $x1853 false false))))
(and (not $x1845) (or $x1845 (and (distinct ?x1871 ?x1871) true)))))))))
(check-sat)
; query 77: function Decoding_of_the_coded_Log_Area_Ratios, block 140, name %144
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in137_64 () (_ BitVec 64))
(assert
 (let ((?x1864 (ite (bvslt (_ bv0 64) in137_64) (_ bv1 1) (_ bv0 1))))
(let (($x1853 (= (_ bv1 1) ?x1864)))
(let ((?x1871 (ite $x1853 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x1854 ((_ sign_extend 32) ?x1871)))
(let (($x57 (or false false false)))
(let (($x1845 (or $x57 (ite $x1853 false false))))
(let (($x1006 (or $x1845 false)))
(and (not $x1006) (or $x1006 (and (distinct ?x1854 ?x1854) true)))))))))))
(check-sat)
; query 78: function Decoding_of_the_coded_Log_Area_Ratios, block 156, name %157
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in153_64 () (_ BitVec 64))
(assert
 (let ((?x1904 (ite (bvslt (_ bv0 64) in153_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x1904 ?x1904) true)))))))
(check-sat)
; query 79: function Decoding_of_the_coded_Log_Area_Ratios, block 156, name %158
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in153_64 () (_ BitVec 64))
(assert
 (let ((?x1904 (ite (bvslt (_ bv0 64) in153_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1911 ((_ zero_extend 63) ?x1904)))
(let (($x57 (or false false false)))
(let (($x686 (or $x57 false)))
(let (($x1855 (not $x686)))
(and $x1855 (or $x686 (and (distinct ?x1911 ?x1911) true)))))))))
(check-sat)
; query 80: function Decoding_of_the_coded_Log_Area_Ratios, block 156, name %159
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in153_64 () (_ BitVec 64))
(assert
 (let ((?x1904 (ite (bvslt (_ bv0 64) in153_64) (_ bv1 1) (_ bv0 1))))
(let (($x1920 (= (_ bv1 1) ?x1904)))
(let ((?x1915 (ite $x1920 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x57 (or false false false)))
(let (($x1614 (or $x57 (ite $x1920 false false))))
(and (not $x1614) (or $x1614 (and (distinct ?x1915 ?x1915) true)))))))))
(check-sat)
; query 81: function Decoding_of_the_coded_Log_Area_Ratios, block 156, name %160
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in153_64 () (_ BitVec 64))
(assert
 (let ((?x1904 (ite (bvslt (_ bv0 64) in153_64) (_ bv1 1) (_ bv0 1))))
(let (($x1920 (= (_ bv1 1) ?x1904)))
(let ((?x1915 (ite $x1920 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x1919 ((_ sign_extend 32) ?x1915)))
(let (($x57 (or false false false)))
(let (($x1614 (or $x57 (ite $x1920 false false))))
(let (($x1912 (or $x1614 false)))
(and (not $x1912) (or $x1912 (and (distinct ?x1919 ?x1919) true)))))))))))
(check-sat)
; query 82: function Decoding_of_the_coded_Log_Area_Ratios, block 170, name %171
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in167_64 () (_ BitVec 64))
(assert
 (let ((?x1955 (ite (bvsge (_ bv18446744073709518848 64) in167_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x1955 ?x1955) true)))))))
(check-sat)
; query 83: function Decoding_of_the_coded_Log_Area_Ratios, block 189, name %190
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in186_64 () (_ BitVec 64))
(assert
 (let ((?x1980 (ite (bvslt (_ bv0 64) in186_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x1980 ?x1980) true)))))))
(check-sat)
; query 84: function Decoding_of_the_coded_Log_Area_Ratios, block 189, name %191
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in186_64 () (_ BitVec 64))
(assert
 (let ((?x1980 (ite (bvslt (_ bv0 64) in186_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1548 ((_ zero_extend 63) ?x1980)))
(let (($x57 (or false false false)))
(let (($x686 (or $x57 false)))
(let (($x1855 (not $x686)))
(and $x1855 (or $x686 (and (distinct ?x1548 ?x1548) true)))))))))
(check-sat)
; query 85: function Decoding_of_the_coded_Log_Area_Ratios, block 189, name %192
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in186_64 () (_ BitVec 64))
(assert
 (let ((?x1980 (ite (bvslt (_ bv0 64) in186_64) (_ bv1 1) (_ bv0 1))))
(let (($x1981 (= (_ bv1 1) ?x1980)))
(let ((?x1982 (ite $x1981 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x57 (or false false false)))
(let (($x1977 (or $x57 (ite $x1981 false false))))
(and (not $x1977) (or $x1977 (and (distinct ?x1982 ?x1982) true)))))))))
(check-sat)
; query 86: function Decoding_of_the_coded_Log_Area_Ratios, block 189, name %193
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in186_64 () (_ BitVec 64))
(assert
 (let ((?x1980 (ite (bvslt (_ bv0 64) in186_64) (_ bv1 1) (_ bv0 1))))
(let (($x1981 (= (_ bv1 1) ?x1980)))
(let ((?x1982 (ite $x1981 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x1985 ((_ sign_extend 32) ?x1982)))
(let (($x57 (or false false false)))
(let (($x1977 (or $x57 (ite $x1981 false false))))
(let (($x474 (or $x1977 false)))
(and (not $x474) (or $x474 (and (distinct ?x1985 ?x1985) true)))))))))))
(check-sat)
; query 87: function Decoding_of_the_coded_Log_Area_Ratios, block 205, name %206
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in202_64 () (_ BitVec 64))
(assert
 (let ((?x353 (ite (bvslt (_ bv0 64) in202_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x353 ?x353) true)))))))
(check-sat)
; query 88: function Decoding_of_the_coded_Log_Area_Ratios, block 205, name %207
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in202_64 () (_ BitVec 64))
(assert
 (let ((?x353 (ite (bvslt (_ bv0 64) in202_64) (_ bv1 1) (_ bv0 1))))
(let ((?x843 ((_ zero_extend 63) ?x353)))
(let (($x57 (or false false false)))
(let (($x686 (or $x57 false)))
(let (($x1855 (not $x686)))
(and $x1855 (or $x686 (and (distinct ?x843 ?x843) true)))))))))
(check-sat)
; query 89: function Decoding_of_the_coded_Log_Area_Ratios, block 205, name %208
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in202_64 () (_ BitVec 64))
(assert
 (let ((?x353 (ite (bvslt (_ bv0 64) in202_64) (_ bv1 1) (_ bv0 1))))
(let (($x566 (= (_ bv1 1) ?x353)))
(let ((?x483 (ite $x566 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x57 (or false false false)))
(let (($x397 (or $x57 (ite $x566 false false))))
(and (not $x397) (or $x397 (and (distinct ?x483 ?x483) true)))))))))
(check-sat)
; query 90: function Decoding_of_the_coded_Log_Area_Ratios, block 205, name %209
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in202_64 () (_ BitVec 64))
(assert
 (let ((?x353 (ite (bvslt (_ bv0 64) in202_64) (_ bv1 1) (_ bv0 1))))
(let (($x566 (= (_ bv1 1) ?x353)))
(let ((?x483 (ite $x566 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x640 ((_ sign_extend 32) ?x483)))
(let (($x57 (or false false false)))
(let (($x397 (or $x57 (ite $x566 false false))))
(let (($x809 (or $x397 false)))
(and (not $x809) (or $x809 (and (distinct ?x640 ?x640) true)))))))))))
(check-sat)
; query 91: function Decoding_of_the_coded_Log_Area_Ratios, block 219, name %220
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in216_64 () (_ BitVec 64))
(assert
 (let ((?x222 (ite (bvsge (_ bv18446744073709518848 64) in216_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x222 ?x222) true)))))))
(check-sat)
; query 92: function Decoding_of_the_coded_Log_Area_Ratios, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in20_64 () (_ BitVec 64))
(assert
 (let ((?x639 (ite (bvsge (_ bv18446744073709518848 64) in20_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x639 ?x639) true)))))))
(check-sat)
; query 93: function Decoding_of_the_coded_Log_Area_Ratios, block 238, name %239
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in235_64 () (_ BitVec 64))
(assert
 (let ((?x75 (ite (bvslt (_ bv0 64) in235_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x75 ?x75) true)))))))
(check-sat)
; query 94: function Decoding_of_the_coded_Log_Area_Ratios, block 238, name %240
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in235_64 () (_ BitVec 64))
(assert
 (let ((?x75 (ite (bvslt (_ bv0 64) in235_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1967 ((_ zero_extend 63) ?x75)))
(let (($x57 (or false false false)))
(let (($x686 (or $x57 false)))
(let (($x1855 (not $x686)))
(and $x1855 (or $x686 (and (distinct ?x1967 ?x1967) true)))))))))
(check-sat)
; query 95: function Decoding_of_the_coded_Log_Area_Ratios, block 238, name %241
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in235_64 () (_ BitVec 64))
(assert
 (let ((?x75 (ite (bvslt (_ bv0 64) in235_64) (_ bv1 1) (_ bv0 1))))
(let (($x1694 (= (_ bv1 1) ?x75)))
(let ((?x1079 (ite $x1694 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x57 (or false false false)))
(let (($x771 (or $x57 (ite $x1694 false false))))
(and (not $x771) (or $x771 (and (distinct ?x1079 ?x1079) true)))))))))
(check-sat)
; query 96: function Decoding_of_the_coded_Log_Area_Ratios, block 238, name %242
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in235_64 () (_ BitVec 64))
(assert
 (let ((?x75 (ite (bvslt (_ bv0 64) in235_64) (_ bv1 1) (_ bv0 1))))
(let (($x1694 (= (_ bv1 1) ?x75)))
(let ((?x1079 (ite $x1694 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x1712 ((_ sign_extend 32) ?x1079)))
(let (($x57 (or false false false)))
(let (($x771 (or $x57 (ite $x1694 false false))))
(let (($x1254 (or $x771 false)))
(and (not $x1254) (or $x1254 (and (distinct ?x1712 ?x1712) true)))))))))))
(check-sat)
; query 97: function Decoding_of_the_coded_Log_Area_Ratios, block 254, name %255
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in251_64 () (_ BitVec 64))
(assert
 (let ((?x1677 (ite (bvslt (_ bv0 64) in251_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x1677 ?x1677) true)))))))
(check-sat)
; query 98: function Decoding_of_the_coded_Log_Area_Ratios, block 254, name %256
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in251_64 () (_ BitVec 64))
(assert
 (let ((?x1677 (ite (bvslt (_ bv0 64) in251_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1568 ((_ zero_extend 63) ?x1677)))
(let (($x57 (or false false false)))
(let (($x686 (or $x57 false)))
(let (($x1855 (not $x686)))
(and $x1855 (or $x686 (and (distinct ?x1568 ?x1568) true)))))))))
(check-sat)
; query 99: function Decoding_of_the_coded_Log_Area_Ratios, block 254, name %257
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in251_64 () (_ BitVec 64))
(assert
 (let ((?x1677 (ite (bvslt (_ bv0 64) in251_64) (_ bv1 1) (_ bv0 1))))
(let (($x1572 (= (_ bv1 1) ?x1677)))
(let ((?x952 (ite $x1572 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x57 (or false false false)))
(let (($x65 (or $x57 (ite $x1572 false false))))
(and (not $x65) (or $x65 (and (distinct ?x952 ?x952) true)))))))))
(check-sat)
; query 100: function Decoding_of_the_coded_Log_Area_Ratios, block 254, name %258
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in251_64 () (_ BitVec 64))
(assert
 (let ((?x1677 (ite (bvslt (_ bv0 64) in251_64) (_ bv1 1) (_ bv0 1))))
(let (($x1572 (= (_ bv1 1) ?x1677)))
(let ((?x952 (ite $x1572 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x295 ((_ sign_extend 32) ?x952)))
(let (($x57 (or false false false)))
(let (($x65 (or $x57 (ite $x1572 false false))))
(let (($x265 (or $x65 false)))
(and (not $x265) (or $x265 (and (distinct ?x295 ?x295) true)))))))))))
(check-sat)
; query 101: function Decoding_of_the_coded_Log_Area_Ratios, block 268, name %269
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in265_64 () (_ BitVec 64))
(assert
 (let ((?x934 (ite (bvsge (_ bv18446744073709518848 64) in265_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x934 ?x934) true)))))))
(check-sat)
; query 102: function Decoding_of_the_coded_Log_Area_Ratios, block 287, name %288
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in284_64 () (_ BitVec 64))
(assert
 (let ((?x1830 (ite (bvslt (_ bv0 64) in284_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x1830 ?x1830) true)))))))
(check-sat)
; query 103: function Decoding_of_the_coded_Log_Area_Ratios, block 287, name %289
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in284_64 () (_ BitVec 64))
(assert
 (let ((?x1830 (ite (bvslt (_ bv0 64) in284_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1843 ((_ zero_extend 63) ?x1830)))
(let (($x57 (or false false false)))
(let (($x686 (or $x57 false)))
(let (($x1855 (not $x686)))
(and $x1855 (or $x686 (and (distinct ?x1843 ?x1843) true)))))))))
(check-sat)
; query 104: function Decoding_of_the_coded_Log_Area_Ratios, block 287, name %290
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in284_64 () (_ BitVec 64))
(assert
 (let ((?x1830 (ite (bvslt (_ bv0 64) in284_64) (_ bv1 1) (_ bv0 1))))
(let (($x1892 (= (_ bv1 1) ?x1830)))
(let ((?x998 (ite $x1892 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x57 (or false false false)))
(let (($x1196 (or $x57 (ite $x1892 false false))))
(and (not $x1196) (or $x1196 (and (distinct ?x998 ?x998) true)))))))))
(check-sat)
; query 105: function Decoding_of_the_coded_Log_Area_Ratios, block 287, name %291
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in284_64 () (_ BitVec 64))
(assert
 (let ((?x1830 (ite (bvslt (_ bv0 64) in284_64) (_ bv1 1) (_ bv0 1))))
(let (($x1892 (= (_ bv1 1) ?x1830)))
(let ((?x998 (ite $x1892 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x1764 ((_ sign_extend 32) ?x998)))
(let (($x57 (or false false false)))
(let (($x1196 (or $x57 (ite $x1892 false false))))
(let (($x715 (or $x1196 false)))
(and (not $x715) (or $x715 (and (distinct ?x1764 ?x1764) true)))))))))))
(check-sat)
; query 106: function Decoding_of_the_coded_Log_Area_Ratios, block 303, name %304
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in300_64 () (_ BitVec 64))
(assert
 (let ((?x1939 (ite (bvslt (_ bv0 64) in300_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x1939 ?x1939) true)))))))
(check-sat)
; query 107: function Decoding_of_the_coded_Log_Area_Ratios, block 303, name %305
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in300_64 () (_ BitVec 64))
(assert
 (let ((?x1939 (ite (bvslt (_ bv0 64) in300_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1643 ((_ zero_extend 63) ?x1939)))
(let (($x57 (or false false false)))
(let (($x686 (or $x57 false)))
(let (($x1855 (not $x686)))
(and $x1855 (or $x686 (and (distinct ?x1643 ?x1643) true)))))))))
(check-sat)
; query 108: function Decoding_of_the_coded_Log_Area_Ratios, block 303, name %306
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in300_64 () (_ BitVec 64))
(assert
 (let ((?x1939 (ite (bvslt (_ bv0 64) in300_64) (_ bv1 1) (_ bv0 1))))
(let (($x721 (= (_ bv1 1) ?x1939)))
(let ((?x1664 (ite $x721 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x57 (or false false false)))
(let (($x535 (or $x57 (ite $x721 false false))))
(and (not $x535) (or $x535 (and (distinct ?x1664 ?x1664) true)))))))))
(check-sat)
; query 109: function Decoding_of_the_coded_Log_Area_Ratios, block 303, name %307
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in300_64 () (_ BitVec 64))
(assert
 (let ((?x1939 (ite (bvslt (_ bv0 64) in300_64) (_ bv1 1) (_ bv0 1))))
(let (($x721 (= (_ bv1 1) ?x1939)))
(let ((?x1664 (ite $x721 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x1436 ((_ sign_extend 32) ?x1664)))
(let (($x57 (or false false false)))
(let (($x535 (or $x57 (ite $x721 false false))))
(let (($x1467 (or $x535 false)))
(and (not $x1467) (or $x1467 (and (distinct ?x1436 ?x1436) true)))))))))))
(check-sat)
; query 110: function Decoding_of_the_coded_Log_Area_Ratios, block 317, name %318
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in314_64 () (_ BitVec 64))
(assert
 (let ((?x1240 (ite (bvsge (_ bv18446744073709518848 64) in314_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x1240 ?x1240) true)))))))
(check-sat)
; query 111: function Decoding_of_the_coded_Log_Area_Ratios, block 336, name %337
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in333_64 () (_ BitVec 64))
(assert
 (let ((?x188 (ite (bvslt (_ bv0 64) in333_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x188 ?x188) true)))))))
(check-sat)
; query 112: function Decoding_of_the_coded_Log_Area_Ratios, block 336, name %338
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in333_64 () (_ BitVec 64))
(assert
 (let ((?x188 (ite (bvslt (_ bv0 64) in333_64) (_ bv1 1) (_ bv0 1))))
(let ((?x734 ((_ zero_extend 63) ?x188)))
(let (($x57 (or false false false)))
(let (($x686 (or $x57 false)))
(let (($x1855 (not $x686)))
(and $x1855 (or $x686 (and (distinct ?x734 ?x734) true)))))))))
(check-sat)
; query 113: function Decoding_of_the_coded_Log_Area_Ratios, block 336, name %339
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in333_64 () (_ BitVec 64))
(assert
 (let ((?x188 (ite (bvslt (_ bv0 64) in333_64) (_ bv1 1) (_ bv0 1))))
(let (($x374 (= (_ bv1 1) ?x188)))
(let ((?x1088 (ite $x374 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x57 (or false false false)))
(let (($x111 (or $x57 (ite $x374 false false))))
(and (not $x111) (or $x111 (and (distinct ?x1088 ?x1088) true)))))))))
(check-sat)
; query 114: function Decoding_of_the_coded_Log_Area_Ratios, block 336, name %340
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in333_64 () (_ BitVec 64))
(assert
 (let ((?x188 (ite (bvslt (_ bv0 64) in333_64) (_ bv1 1) (_ bv0 1))))
(let (($x374 (= (_ bv1 1) ?x188)))
(let ((?x1088 (ite $x374 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x76 ((_ sign_extend 32) ?x1088)))
(let (($x57 (or false false false)))
(let (($x111 (or $x57 (ite $x374 false false))))
(let (($x145 (or $x111 false)))
(and (not $x145) (or $x145 (and (distinct ?x76 ?x76) true)))))))))))
(check-sat)
; query 115: function Decoding_of_the_coded_Log_Area_Ratios, block 352, name %353
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in349_64 () (_ BitVec 64))
(assert
 (let ((?x163 (ite (bvslt (_ bv0 64) in349_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x163 ?x163) true)))))))
(check-sat)
; query 116: function Decoding_of_the_coded_Log_Area_Ratios, block 352, name %354
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in349_64 () (_ BitVec 64))
(assert
 (let ((?x163 (ite (bvslt (_ bv0 64) in349_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1209 ((_ zero_extend 63) ?x163)))
(let (($x57 (or false false false)))
(let (($x686 (or $x57 false)))
(let (($x1855 (not $x686)))
(and $x1855 (or $x686 (and (distinct ?x1209 ?x1209) true)))))))))
(check-sat)
; query 117: function Decoding_of_the_coded_Log_Area_Ratios, block 352, name %355
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in349_64 () (_ BitVec 64))
(assert
 (let ((?x163 (ite (bvslt (_ bv0 64) in349_64) (_ bv1 1) (_ bv0 1))))
(let (($x160 (= (_ bv1 1) ?x163)))
(let ((?x595 (ite $x160 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x57 (or false false false)))
(let (($x698 (or $x57 (ite $x160 false false))))
(and (not $x698) (or $x698 (and (distinct ?x595 ?x595) true)))))))))
(check-sat)
; query 118: function Decoding_of_the_coded_Log_Area_Ratios, block 352, name %356
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in349_64 () (_ BitVec 64))
(assert
 (let ((?x163 (ite (bvslt (_ bv0 64) in349_64) (_ bv1 1) (_ bv0 1))))
(let (($x160 (= (_ bv1 1) ?x163)))
(let ((?x595 (ite $x160 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x515 ((_ sign_extend 32) ?x595)))
(let (($x57 (or false false false)))
(let (($x698 (or $x57 (ite $x160 false false))))
(let (($x1635 (or $x698 false)))
(and (not $x1635) (or $x1635 (and (distinct ?x515 ?x515) true)))))))))))
(check-sat)
; query 119: function Decoding_of_the_coded_Log_Area_Ratios, block 366, name %367
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in363_64 () (_ BitVec 64))
(assert
 (let ((?x500 (ite (bvsge (_ bv18446744073709518848 64) in363_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x500 ?x500) true)))))))
(check-sat)
; query 120: function Decoding_of_the_coded_Log_Area_Ratios, block 385, name %386
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in382_64 () (_ BitVec 64))
(assert
 (let ((?x1745 (ite (bvslt (_ bv0 64) in382_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x1745 ?x1745) true)))))))
(check-sat)
; query 121: function Decoding_of_the_coded_Log_Area_Ratios, block 385, name %387
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in382_64 () (_ BitVec 64))
(assert
 (let ((?x1745 (ite (bvslt (_ bv0 64) in382_64) (_ bv1 1) (_ bv0 1))))
(let ((?x484 ((_ zero_extend 63) ?x1745)))
(let (($x57 (or false false false)))
(let (($x686 (or $x57 false)))
(let (($x1855 (not $x686)))
(and $x1855 (or $x686 (and (distinct ?x484 ?x484) true)))))))))
(check-sat)
; query 122: function Decoding_of_the_coded_Log_Area_Ratios, block 385, name %388
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in382_64 () (_ BitVec 64))
(assert
 (let ((?x1745 (ite (bvslt (_ bv0 64) in382_64) (_ bv1 1) (_ bv0 1))))
(let (($x211 (= (_ bv1 1) ?x1745)))
(let ((?x192 (ite $x211 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x57 (or false false false)))
(let (($x1844 (or $x57 (ite $x211 false false))))
(and (not $x1844) (or $x1844 (and (distinct ?x192 ?x192) true)))))))))
(check-sat)
; query 123: function Decoding_of_the_coded_Log_Area_Ratios, block 385, name %389
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in382_64 () (_ BitVec 64))
(assert
 (let ((?x1745 (ite (bvslt (_ bv0 64) in382_64) (_ bv1 1) (_ bv0 1))))
(let (($x211 (= (_ bv1 1) ?x1745)))
(let ((?x192 (ite $x211 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x136 ((_ sign_extend 32) ?x192)))
(let (($x57 (or false false false)))
(let (($x1844 (or $x57 (ite $x211 false false))))
(let (($x962 (or $x1844 false)))
(and (not $x962) (or $x962 (and (distinct ?x136 ?x136) true)))))))))))
(check-sat)
; query 124: function Decoding_of_the_coded_Log_Area_Ratios, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in39_64 () (_ BitVec 64))
(assert
 (let ((?x1560 (ite (bvslt (_ bv0 64) in39_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x1560 ?x1560) true)))))))
(check-sat)
; query 125: function Decoding_of_the_coded_Log_Area_Ratios, block 42, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in39_64 () (_ BitVec 64))
(assert
 (let ((?x1560 (ite (bvslt (_ bv0 64) in39_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1945 ((_ zero_extend 63) ?x1560)))
(let (($x57 (or false false false)))
(let (($x686 (or $x57 false)))
(let (($x1855 (not $x686)))
(and $x1855 (or $x686 (and (distinct ?x1945 ?x1945) true)))))))))
(check-sat)
; query 126: function Decoding_of_the_coded_Log_Area_Ratios, block 42, name %45
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in39_64 () (_ BitVec 64))
(assert
 (let ((?x1560 (ite (bvslt (_ bv0 64) in39_64) (_ bv1 1) (_ bv0 1))))
(let (($x355 (= (_ bv1 1) ?x1560)))
(let ((?x614 (ite $x355 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x57 (or false false false)))
(let (($x699 (or $x57 (ite $x355 false false))))
(and (not $x699) (or $x699 (and (distinct ?x614 ?x614) true)))))))))
(check-sat)
; query 127: function Decoding_of_the_coded_Log_Area_Ratios, block 42, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in39_64 () (_ BitVec 64))
(assert
 (let ((?x1560 (ite (bvslt (_ bv0 64) in39_64) (_ bv1 1) (_ bv0 1))))
(let (($x355 (= (_ bv1 1) ?x1560)))
(let ((?x614 (ite $x355 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x577 ((_ sign_extend 32) ?x614)))
(let (($x57 (or false false false)))
(let (($x699 (or $x57 (ite $x355 false false))))
(let (($x1557 (or $x699 false)))
(and (not $x1557) (or $x1557 (and (distinct ?x577 ?x577) true)))))))))))
(check-sat)
; query 128: function Decoding_of_the_coded_Log_Area_Ratios, block 58, name %59
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in55_64 () (_ BitVec 64))
(assert
 (let ((?x610 (ite (bvslt (_ bv0 64) in55_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x610 ?x610) true)))))))
(check-sat)
; query 129: function Decoding_of_the_coded_Log_Area_Ratios, block 58, name %60
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in55_64 () (_ BitVec 64))
(assert
 (let ((?x610 (ite (bvslt (_ bv0 64) in55_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1696 ((_ zero_extend 63) ?x610)))
(let (($x57 (or false false false)))
(let (($x686 (or $x57 false)))
(let (($x1855 (not $x686)))
(and $x1855 (or $x686 (and (distinct ?x1696 ?x1696) true)))))))))
(check-sat)
; query 130: function Decoding_of_the_coded_Log_Area_Ratios, block 58, name %61
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in55_64 () (_ BitVec 64))
(assert
 (let ((?x610 (ite (bvslt (_ bv0 64) in55_64) (_ bv1 1) (_ bv0 1))))
(let (($x1714 (= (_ bv1 1) ?x610)))
(let ((?x1671 (ite $x1714 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x57 (or false false false)))
(let (($x1491 (or $x57 (ite $x1714 false false))))
(and (not $x1491) (or $x1491 (and (distinct ?x1671 ?x1671) true)))))))))
(check-sat)
; query 131: function Decoding_of_the_coded_Log_Area_Ratios, block 58, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in55_64 () (_ BitVec 64))
(assert
 (let ((?x610 (ite (bvslt (_ bv0 64) in55_64) (_ bv1 1) (_ bv0 1))))
(let (($x1714 (= (_ bv1 1) ?x610)))
(let ((?x1671 (ite $x1714 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x1992 ((_ sign_extend 32) ?x1671)))
(let (($x57 (or false false false)))
(let (($x1491 (or $x57 (ite $x1714 false false))))
(let (($x865 (or $x1491 false)))
(and (not $x865) (or $x865 (and (distinct ?x1992 ?x1992) true)))))))))))
(check-sat)
; query 132: function Decoding_of_the_coded_Log_Area_Ratios, block 72, name %73
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in69_64 () (_ BitVec 64))
(assert
 (let ((?x626 (ite (bvsge (_ bv18446744073709518848 64) in69_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x626 ?x626) true)))))))
(check-sat)
; query 133: function Decoding_of_the_coded_Log_Area_Ratios, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in6_64 () (_ BitVec 64))
(assert
 (let ((?x1500 (ite (bvslt (_ bv0 64) in6_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x1500 ?x1500) true)))))))
(check-sat)
; query 134: function Decoding_of_the_coded_Log_Area_Ratios, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in6_64 () (_ BitVec 64))
(assert
 (let ((?x1500 (ite (bvslt (_ bv0 64) in6_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1651 ((_ zero_extend 63) ?x1500)))
(let (($x57 (or false false false)))
(let (($x686 (or $x57 false)))
(let (($x1855 (not $x686)))
(and $x1855 (or $x686 (and (distinct ?x1651 ?x1651) true)))))))))
(check-sat)
; query 135: function Decoding_of_the_coded_Log_Area_Ratios, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in6_64 () (_ BitVec 64))
(assert
 (let ((?x1500 (ite (bvslt (_ bv0 64) in6_64) (_ bv1 1) (_ bv0 1))))
(let (($x1615 (= (_ bv1 1) ?x1500)))
(let ((?x1496 (ite $x1615 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x57 (or false false false)))
(let (($x753 (or $x57 (ite $x1615 false false))))
(and (not $x753) (or $x753 (and (distinct ?x1496 ?x1496) true)))))))))
(check-sat)
; query 136: function Decoding_of_the_coded_Log_Area_Ratios, block 9, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in6_64 () (_ BitVec 64))
(assert
 (let ((?x1500 (ite (bvslt (_ bv0 64) in6_64) (_ bv1 1) (_ bv0 1))))
(let (($x1615 (= (_ bv1 1) ?x1500)))
(let ((?x1496 (ite $x1615 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x1493 ((_ sign_extend 32) ?x1496)))
(let (($x57 (or false false false)))
(let (($x753 (or $x57 (ite $x1615 false false))))
(let (($x1888 (or $x753 false)))
(and (not $x1888) (or $x1888 (and (distinct ?x1493 ?x1493) true)))))))))))
(check-sat)
; query 137: function Decoding_of_the_coded_Log_Area_Ratios, block 91, name %92
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in88_64 () (_ BitVec 64))
(assert
 (let ((?x1411 (ite (bvslt (_ bv0 64) in88_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x1411 ?x1411) true)))))))
(check-sat)
; query 138: function Decoding_of_the_coded_Log_Area_Ratios, block 91, name %93
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in88_64 () (_ BitVec 64))
(assert
 (let ((?x1411 (ite (bvslt (_ bv0 64) in88_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1421 ((_ zero_extend 63) ?x1411)))
(let (($x57 (or false false false)))
(let (($x686 (or $x57 false)))
(let (($x1855 (not $x686)))
(and $x1855 (or $x686 (and (distinct ?x1421 ?x1421) true)))))))))
(check-sat)
; query 139: function Decoding_of_the_coded_Log_Area_Ratios, block 91, name %94
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in88_64 () (_ BitVec 64))
(assert
 (let ((?x1411 (ite (bvslt (_ bv0 64) in88_64) (_ bv1 1) (_ bv0 1))))
(let (($x1435 (= (_ bv1 1) ?x1411)))
(let ((?x1410 (ite $x1435 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x57 (or false false false)))
(let (($x1450 (or $x57 (ite $x1435 false false))))
(and (not $x1450) (or $x1450 (and (distinct ?x1410 ?x1410) true)))))))))
(check-sat)
; query 140: function Decoding_of_the_coded_Log_Area_Ratios, block 91, name %95
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in88_64 () (_ BitVec 64))
(assert
 (let ((?x1411 (ite (bvslt (_ bv0 64) in88_64) (_ bv1 1) (_ bv0 1))))
(let (($x1435 (= (_ bv1 1) ?x1411)))
(let ((?x1410 (ite $x1435 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x1053 ((_ sign_extend 32) ?x1410)))
(let (($x57 (or false false false)))
(let (($x1450 (or $x57 (ite $x1435 false false))))
(let (($x1049 (or $x1450 false)))
(and (not $x1049) (or $x1049 (and (distinct ?x1053 ?x1053) true)))))))))))
(check-sat)
; query 141: function Gsm_Coder, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in39_64 () (_ BitVec 64))
(assert
 (let ((?x1560 (ite (bvslt (_ bv0 64) in39_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x1560 ?x1560) true)))))))
(check-sat)
; query 142: function Gsm_Coder, block 42, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in39_64 () (_ BitVec 64))
(assert
 (let ((?x1560 (ite (bvslt (_ bv0 64) in39_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1945 ((_ zero_extend 63) ?x1560)))
(let (($x57 (or false false false)))
(let (($x686 (or $x57 false)))
(let (($x1855 (not $x686)))
(and $x1855 (or $x686 (and (distinct ?x1945 ?x1945) true)))))))))
(check-sat)
; query 143: function Gsm_Coder, block 42, name %45
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in39_64 () (_ BitVec 64))
(assert
 (let ((?x1560 (ite (bvslt (_ bv0 64) in39_64) (_ bv1 1) (_ bv0 1))))
(let (($x355 (= (_ bv1 1) ?x1560)))
(let ((?x614 (ite $x355 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x57 (or false false false)))
(let (($x699 (or $x57 (ite $x355 false false))))
(and (not $x699) (or $x699 (and (distinct ?x614 ?x614) true)))))))))
(check-sat)
; query 144: function Gsm_Coder, block 42, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in39_64 () (_ BitVec 64))
(assert
 (let ((?x1560 (ite (bvslt (_ bv0 64) in39_64) (_ bv1 1) (_ bv0 1))))
(let (($x355 (= (_ bv1 1) ?x1560)))
(let ((?x614 (ite $x355 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x577 ((_ sign_extend 32) ?x614)))
(let (($x57 (or false false false)))
(let (($x699 (or $x57 (ite $x355 false false))))
(let (($x1557 (or $x699 false)))
(and (not $x1557) (or $x1557 (and (distinct ?x577 ?x577) true)))))))))))
(check-sat)
; query 145: function Gsm_Coder, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1498 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x1513 (or false false (or $x1498))))
(and (not $x1513) (or $x1513 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 146: function Gsm_Decoder, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1498 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x1513 (or false false (or $x1498))))
(and (not $x1513) (or $x1513 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 147: function Gsm_Long_Term_Synthesis_Filtering, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 148: function Gsm_Long_Term_Synthesis_Filtering, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in19_16) ((_ sign_extend 16) in19_16)) true))))))
(check-sat)
; query 149: function Gsm_Long_Term_Synthesis_Filtering, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x1543 (ite (bvsge (_ bv120 32) ((_ sign_extend 16) in19_16)) (_ bv1 1) (_ bv0 1))))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x41 (not $x73)))
(and $x41 (or $x73 (and (distinct ?x1543 ?x1543) true))))))))
(check-sat)
; query 150: function Gsm_Long_Term_Synthesis_Filtering, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1538 (ite (bvslt (_ bv120 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x41 (not $x73)))
(and $x41 (or $x73 (and (distinct ?x1538 ?x1538) true))))))))
(check-sat)
; query 151: function Gsm_Long_Term_Synthesis_Filtering, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 152: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 153: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x1472 (ite (bvsgt (_ bv40 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x41 (not $x73)))
(and $x41 (or $x73 (and (distinct ?x1472 ?x1472) true))))))))
(check-sat)
; query 154: function LARp_to_rp, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in19_16) ((_ sign_extend 16) in19_16)) true))))))
(check-sat)
; query 155: function LARp_to_rp, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x1514 ((_ sign_extend 16) in19_16)))
(let ((?x1504 (bvshl ?x1514 (_ bv1 32))))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x17 (or $x73 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x379 (not $x17)))
(and $x379 (or $x17 (and (distinct ?x1504 ?x1504) true))))))))))
(check-sat)
; query 156: function LARp_to_rp, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x1514 ((_ sign_extend 16) in19_16)))
(let ((?x1504 (bvshl ?x1514 (_ bv1 32))))
(let ((?x1503 ((_ sign_extend 32) ?x1504)))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x17 (or $x73 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x1534 (or $x17 false)))
(let (($x1443 (not $x1534)))
(and $x1443 (or $x1534 (and (distinct ?x1503 ?x1503) true))))))))))))
(check-sat)
; query 157: function LARp_to_rp, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in19_16) ((_ sign_extend 16) in19_16)) true))))))
(check-sat)
; query 158: function LARp_to_rp, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x1429 (ite (bvsgt (_ bv20070 32) ((_ sign_extend 16) in19_16)) (_ bv1 1) (_ bv0 1))))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x41 (not $x73)))
(and $x41 (or $x73 (and (distinct ?x1429 ?x1429) true))))))))
(check-sat)
; query 159: function LARp_to_rp, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in19_16) ((_ sign_extend 16) in19_16)) true))))))
(check-sat)
; query 160: function LARp_to_rp, block 29, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x1514 ((_ sign_extend 16) in19_16)))
(let ((?x1382 (bvadd ?x1514 (_ bv11059 32))))
(let (($x542 (and (distinct (bvadd ((_ sign_extend 1) ?x1514) ((_ sign_extend 1) (_ bv11059 32))) ((_ sign_extend 1) ?x1382)) true)))
(let (($x224 (or false false)))
(let (($x1414 (or $x224 false (or $x542))))
(and (not $x1414) (or $x1414 (and (distinct ?x1382 ?x1382) true)))))))))
(check-sat)
; query 161: function LARp_to_rp, block 29, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x1514 ((_ sign_extend 16) in19_16)))
(let ((?x1382 (bvadd ?x1514 (_ bv11059 32))))
(let ((?x1367 ((_ sign_extend 32) ?x1382)))
(let (($x542 (and (distinct (bvadd ((_ sign_extend 1) ?x1514) ((_ sign_extend 1) (_ bv11059 32))) ((_ sign_extend 1) ?x1382)) true)))
(let (($x224 (or false false)))
(let (($x1414 (or $x224 false (or $x542))))
(let (($x1383 (or $x1414 false)))
(and (not $x1383) (or $x1383 (and (distinct ?x1367 ?x1367) true)))))))))))
(check-sat)
; query 162: function LARp_to_rp, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in19_16) ((_ sign_extend 16) in19_16)) true))))))
(check-sat)
; query 163: function LARp_to_rp, block 33, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x1514 ((_ sign_extend 16) in19_16)))
(let ((?x1369 (bvashr ?x1514 (_ bv2 32))))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x1338 (or $x73 (bvuge (_ bv2 32) (_ bv32 32)))))
(let (($x986 (not $x1338)))
(and $x986 (or $x1338 (and (distinct ?x1369 ?x1369) true))))))))))
(check-sat)
; query 164: function LARp_to_rp, block 33, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x1514 ((_ sign_extend 16) in19_16)))
(let ((?x1369 (bvashr ?x1514 (_ bv2 32))))
(let ((?x1324 ((_ sign_extend 32) ?x1369)))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x1338 (or $x73 (bvuge (_ bv2 32) (_ bv32 32)))))
(let (($x1307 (or $x1338 false)))
(let (($x1176 (not $x1307)))
(and $x1176 (or $x1307 (and (distinct ?x1324 ?x1324) true))))))))))))
(check-sat)
; query 165: function LARp_to_rp, block 33, name %37
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x1514 ((_ sign_extend 16) in19_16)))
(let ((?x1369 (bvashr ?x1514 (_ bv2 32))))
(let ((?x1324 ((_ sign_extend 32) ?x1369)))
(let ((?x1294 (bvadd ?x1324 (_ bv26112 64))))
(let ((?x682 ((_ sign_extend 1) ?x1294)))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x1338 (or $x73 (bvuge (_ bv2 32) (_ bv32 32)))))
(let (($x1307 (or $x1338 false)))
(let (($x1277 (or $x1307 false (or (and (distinct (bvadd ((_ sign_extend 1) ?x1324) ((_ sign_extend 1) (_ bv26112 64))) ?x682) true)))))
(and (not $x1277) (or $x1277 (and (distinct ?x1294 ?x1294) true))))))))))))))
(check-sat)
; query 166: function LARp_to_rp, block 33, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x1514 ((_ sign_extend 16) in19_16)))
(let ((?x1369 (bvashr ?x1514 (_ bv2 32))))
(let ((?x1324 ((_ sign_extend 32) ?x1369)))
(let ((?x1294 (bvadd ?x1324 (_ bv26112 64))))
(let ((?x1234 (bvsub ?x1294 (_ bv18446744073709518848 64))))
(let (($x205 (and (distinct (bvsub ((_ sign_extend 1) ?x1294) ((_ sign_extend 1) (_ bv18446744073709518848 64))) ((_ sign_extend 1) ?x1234)) true)))
(let ((?x682 ((_ sign_extend 1) ?x1294)))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x1338 (or $x73 (bvuge (_ bv2 32) (_ bv32 32)))))
(let (($x1307 (or $x1338 false)))
(let (($x1277 (or $x1307 false (or (and (distinct (bvadd ((_ sign_extend 1) ?x1324) ((_ sign_extend 1) (_ bv26112 64))) ?x682) true)))))
(let (($x1219 (or $x1277 false (or $x205))))
(and (not $x1219) (or $x1219 (and (distinct ?x1234 ?x1234) true)))))))))))))))))
(check-sat)
; query 167: function LARp_to_rp, block 33, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in19_16 () (_ BitVec 16))
(assert
 (let ((?x1514 ((_ sign_extend 16) in19_16)))
(let ((?x1369 (bvashr ?x1514 (_ bv2 32))))
(let ((?x1324 ((_ sign_extend 32) ?x1369)))
(let ((?x1294 (bvadd ?x1324 (_ bv26112 64))))
(let ((?x1234 (bvsub ?x1294 (_ bv18446744073709518848 64))))
(let ((?x852 (ite (bvugt ?x1234 (_ bv65535 64)) (_ bv1 1) (_ bv0 1))))
(let (($x205 (and (distinct (bvsub ((_ sign_extend 1) ?x1294) ((_ sign_extend 1) (_ bv18446744073709518848 64))) ((_ sign_extend 1) ?x1234)) true)))
(let ((?x682 ((_ sign_extend 1) ?x1294)))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x1338 (or $x73 (bvuge (_ bv2 32) (_ bv32 32)))))
(let (($x1307 (or $x1338 false)))
(let (($x1277 (or $x1307 false (or (and (distinct (bvadd ((_ sign_extend 1) ?x1324) ((_ sign_extend 1) (_ bv26112 64))) ?x682) true)))))
(let (($x1219 (or $x1277 false (or $x205))))
(let (($x1218 (or $x1219 false false)))
(and (not $x1218) (or $x1218 (and (distinct ?x852 ?x852) true)))))))))))))))))))
(check-sat)
; query 168: function LARp_to_rp, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in37_64 () (_ BitVec 64))
(assert
 (let ((?x1185 (ite (bvslt (_ bv0 64) in37_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x1185 ?x1185) true)))))))
(check-sat)
; query 169: function LARp_to_rp, block 40, name %42
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in37_64 () (_ BitVec 64))
(assert
 (let ((?x1185 (ite (bvslt (_ bv0 64) in37_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1370 ((_ zero_extend 63) ?x1185)))
(let (($x57 (or false false false)))
(let (($x686 (or $x57 false)))
(let (($x1855 (not $x686)))
(and $x1855 (or $x686 (and (distinct ?x1370 ?x1370) true)))))))))
(check-sat)
; query 170: function LARp_to_rp, block 40, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in37_64 () (_ BitVec 64))
(assert
 (let ((?x1185 (ite (bvslt (_ bv0 64) in37_64) (_ bv1 1) (_ bv0 1))))
(let (($x1325 (= (_ bv1 1) ?x1185)))
(let ((?x1400 (ite $x1325 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x57 (or false false false)))
(let (($x1310 (or $x57 (ite $x1325 false false))))
(and (not $x1310) (or $x1310 (and (distinct ?x1400 ?x1400) true)))))))))
(check-sat)
; query 171: function LARp_to_rp, block 40, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in37_64 () (_ BitVec 64))
(assert
 (let ((?x1185 (ite (bvslt (_ bv0 64) in37_64) (_ bv1 1) (_ bv0 1))))
(let (($x1325 (= (_ bv1 1) ?x1185)))
(let ((?x1400 (ite $x1325 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x1385 ((_ sign_extend 32) ?x1400)))
(let (($x57 (or false false false)))
(let (($x1310 (or $x57 (ite $x1325 false false))))
(let (($x1295 (or $x1310 false)))
(and (not $x1295) (or $x1295 (and (distinct ?x1385 ?x1385) true)))))))))))
(check-sat)
; query 172: function LARp_to_rp, block 58, name %59
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in55_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in55_16) ((_ sign_extend 16) in55_16)) true))))))
(check-sat)
; query 173: function LARp_to_rp, block 58, name %60
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in55_16 () (_ BitVec 16))
(assert
 (let ((?x1553 ((_ sign_extend 16) in55_16)))
(let ((?x1535 (bvshl ?x1553 (_ bv1 32))))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x17 (or $x73 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x379 (not $x17)))
(and $x379 (or $x17 (and (distinct ?x1535 ?x1535) true))))))))))
(check-sat)
; query 174: function LARp_to_rp, block 58, name %61
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in55_16 () (_ BitVec 16))
(assert
 (let ((?x1553 ((_ sign_extend 16) in55_16)))
(let ((?x1535 (bvshl ?x1553 (_ bv1 32))))
(let ((?x1074 ((_ sign_extend 32) ?x1535)))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x17 (or $x73 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x1534 (or $x17 false)))
(let (($x1443 (not $x1534)))
(and $x1443 (or $x1534 (and (distinct ?x1074 ?x1074) true))))))))))))
(check-sat)
; query 175: function LARp_to_rp, block 62, name %63
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in55_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in55_16) ((_ sign_extend 16) in55_16)) true))))))
(check-sat)
; query 176: function LARp_to_rp, block 62, name %64
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in55_16 () (_ BitVec 16))
(assert
 (let ((?x1023 (ite (bvsgt (_ bv20070 32) ((_ sign_extend 16) in55_16)) (_ bv1 1) (_ bv0 1))))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x41 (not $x73)))
(and $x41 (or $x73 (and (distinct ?x1023 ?x1023) true))))))))
(check-sat)
; query 177: function LARp_to_rp, block 65, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in55_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in55_16) ((_ sign_extend 16) in55_16)) true))))))
(check-sat)
; query 178: function LARp_to_rp, block 65, name %67
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in55_16 () (_ BitVec 16))
(assert
 (let ((?x1553 ((_ sign_extend 16) in55_16)))
(let ((?x1559 (bvadd ?x1553 (_ bv11059 32))))
(let (($x1724 (and (distinct (bvadd ((_ sign_extend 1) ?x1553) ((_ sign_extend 1) (_ bv11059 32))) ((_ sign_extend 1) ?x1559)) true)))
(let (($x224 (or false false)))
(let (($x1661 (or $x224 false (or $x1724))))
(and (not $x1661) (or $x1661 (and (distinct ?x1559 ?x1559) true)))))))))
(check-sat)
; query 179: function LARp_to_rp, block 65, name %68
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in55_16 () (_ BitVec 16))
(assert
 (let ((?x1553 ((_ sign_extend 16) in55_16)))
(let ((?x1559 (bvadd ?x1553 (_ bv11059 32))))
(let ((?x1622 ((_ sign_extend 32) ?x1559)))
(let (($x1724 (and (distinct (bvadd ((_ sign_extend 1) ?x1553) ((_ sign_extend 1) (_ bv11059 32))) ((_ sign_extend 1) ?x1559)) true)))
(let (($x224 (or false false)))
(let (($x1661 (or $x224 false (or $x1724))))
(let (($x1623 (or $x1661 false)))
(and (not $x1623) (or $x1623 (and (distinct ?x1622 ?x1622) true)))))))))))
(check-sat)
; query 180: function LARp_to_rp, block 69, name %70
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in55_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in55_16) ((_ sign_extend 16) in55_16)) true))))))
(check-sat)
; query 181: function LARp_to_rp, block 69, name %71
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in55_16 () (_ BitVec 16))
(assert
 (let ((?x1553 ((_ sign_extend 16) in55_16)))
(let ((?x345 (bvashr ?x1553 (_ bv2 32))))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x1338 (or $x73 (bvuge (_ bv2 32) (_ bv32 32)))))
(let (($x986 (not $x1338)))
(and $x986 (or $x1338 (and (distinct ?x345 ?x345) true))))))))))
(check-sat)
; query 182: function LARp_to_rp, block 69, name %72
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in55_16 () (_ BitVec 16))
(assert
 (let ((?x1553 ((_ sign_extend 16) in55_16)))
(let ((?x345 (bvashr ?x1553 (_ bv2 32))))
(let ((?x467 ((_ sign_extend 32) ?x345)))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x1338 (or $x73 (bvuge (_ bv2 32) (_ bv32 32)))))
(let (($x1307 (or $x1338 false)))
(let (($x1176 (not $x1307)))
(and $x1176 (or $x1307 (and (distinct ?x467 ?x467) true))))))))))))
(check-sat)
; query 183: function LARp_to_rp, block 69, name %73
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in55_16 () (_ BitVec 16))
(assert
 (let ((?x1553 ((_ sign_extend 16) in55_16)))
(let ((?x345 (bvashr ?x1553 (_ bv2 32))))
(let ((?x467 ((_ sign_extend 32) ?x345)))
(let ((?x207 (bvadd ?x467 (_ bv26112 64))))
(let ((?x362 ((_ sign_extend 1) ?x207)))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x1338 (or $x73 (bvuge (_ bv2 32) (_ bv32 32)))))
(let (($x1307 (or $x1338 false)))
(let (($x635 (or $x1307 false (or (and (distinct (bvadd ((_ sign_extend 1) ?x467) ((_ sign_extend 1) (_ bv26112 64))) ?x362) true)))))
(and (not $x635) (or $x635 (and (distinct ?x207 ?x207) true))))))))))))))
(check-sat)
; query 184: function LARp_to_rp, block 69, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in55_16 () (_ BitVec 16))
(assert
 (let ((?x1553 ((_ sign_extend 16) in55_16)))
(let ((?x345 (bvashr ?x1553 (_ bv2 32))))
(let ((?x467 ((_ sign_extend 32) ?x345)))
(let ((?x207 (bvadd ?x467 (_ bv26112 64))))
(let ((?x866 (bvsub ?x207 (_ bv18446744073709518848 64))))
(let (($x272 (and (distinct (bvsub ((_ sign_extend 1) ?x207) ((_ sign_extend 1) (_ bv18446744073709518848 64))) ((_ sign_extend 1) ?x866)) true)))
(let ((?x362 ((_ sign_extend 1) ?x207)))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x1338 (or $x73 (bvuge (_ bv2 32) (_ bv32 32)))))
(let (($x1307 (or $x1338 false)))
(let (($x635 (or $x1307 false (or (and (distinct (bvadd ((_ sign_extend 1) ?x467) ((_ sign_extend 1) (_ bv26112 64))) ?x362) true)))))
(let (($x921 (or $x635 false (or $x272))))
(and (not $x921) (or $x921 (and (distinct ?x866 ?x866) true)))))))))))))))))
(check-sat)
; query 185: function LARp_to_rp, block 69, name %75
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in55_16 () (_ BitVec 16))
(assert
 (let ((?x1553 ((_ sign_extend 16) in55_16)))
(let ((?x345 (bvashr ?x1553 (_ bv2 32))))
(let ((?x467 ((_ sign_extend 32) ?x345)))
(let ((?x207 (bvadd ?x467 (_ bv26112 64))))
(let ((?x866 (bvsub ?x207 (_ bv18446744073709518848 64))))
(let ((?x497 (ite (bvugt ?x866 (_ bv65535 64)) (_ bv1 1) (_ bv0 1))))
(let (($x272 (and (distinct (bvsub ((_ sign_extend 1) ?x207) ((_ sign_extend 1) (_ bv18446744073709518848 64))) ((_ sign_extend 1) ?x866)) true)))
(let ((?x362 ((_ sign_extend 1) ?x207)))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x1338 (or $x73 (bvuge (_ bv2 32) (_ bv32 32)))))
(let (($x1307 (or $x1338 false)))
(let (($x635 (or $x1307 false (or (and (distinct (bvadd ((_ sign_extend 1) ?x467) ((_ sign_extend 1) (_ bv26112 64))) ?x362) true)))))
(let (($x921 (or $x635 false (or $x272))))
(let (($x461 (or $x921 false false)))
(and (not $x461) (or $x461 (and (distinct ?x497 ?x497) true)))))))))))))))))))
(check-sat)
; query 186: function LARp_to_rp, block 76, name %77
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in73_64 () (_ BitVec 64))
(assert
 (let ((?x1806 (ite (bvslt (_ bv0 64) in73_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x1806 ?x1806) true)))))))
(check-sat)
; query 187: function LARp_to_rp, block 76, name %78
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in73_64 () (_ BitVec 64))
(assert
 (let ((?x1806 (ite (bvslt (_ bv0 64) in73_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1802 ((_ zero_extend 63) ?x1806)))
(let (($x57 (or false false false)))
(let (($x686 (or $x57 false)))
(let (($x1855 (not $x686)))
(and $x1855 (or $x686 (and (distinct ?x1802 ?x1802) true)))))))))
(check-sat)
; query 188: function LARp_to_rp, block 76, name %79
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in73_64 () (_ BitVec 64))
(assert
 (let ((?x1806 (ite (bvslt (_ bv0 64) in73_64) (_ bv1 1) (_ bv0 1))))
(let (($x1767 (= (_ bv1 1) ?x1806)))
(let ((?x1786 (ite $x1767 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x57 (or false false false)))
(let (($x1772 (or $x57 (ite $x1767 false false))))
(and (not $x1772) (or $x1772 (and (distinct ?x1786 ?x1786) true)))))))))
(check-sat)
; query 189: function LARp_to_rp, block 76, name %80
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in73_64 () (_ BitVec 64))
(assert
 (let ((?x1806 (ite (bvslt (_ bv0 64) in73_64) (_ bv1 1) (_ bv0 1))))
(let (($x1767 (= (_ bv1 1) ?x1806)))
(let ((?x1786 (ite $x1767 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x900 ((_ sign_extend 32) ?x1786)))
(let (($x57 (or false false false)))
(let (($x1772 (or $x57 (ite $x1767 false false))))
(let (($x1784 (or $x1772 false)))
(and (not $x1784) (or $x1784 (and (distinct ?x900 ?x900) true)))))))))))
(check-sat)
; query 190: function Long_term_analysis_filtering, block 117, name %118
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in114_64 () (_ BitVec 64))
(assert
 (let ((?x1796 (ite (bvsge (_ bv18446744073709518848 64) in114_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x1796 ?x1796) true)))))))
(check-sat)
; query 191: function Long_term_analysis_filtering, block 128, name %129
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let (($x398 (and (distinct (bvadd ((_ sign_extend 1) in.2_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.2_32 (_ bv1 32)))) true)))
(let (($x703 (or false false (or $x398))))
(and (not $x703) (or $x703 (and (distinct (bvadd in.2_32 (_ bv1 32)) (bvadd in.2_32 (_ bv1 32))) true))))))
(check-sat)
; query 192: function Long_term_analysis_filtering, block 158, name %159
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in155_64 () (_ BitVec 64))
(assert
 (let ((?x651 (ite (bvsge (_ bv18446744073709518848 64) in155_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x651 ?x651) true)))))))
(check-sat)
; query 193: function Long_term_analysis_filtering, block 169, name %170
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.3_32 () (_ BitVec 32))
(assert
 (let (($x954 (and (distinct (bvadd ((_ sign_extend 1) in.3_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.3_32 (_ bv1 32)))) true)))
(let (($x1108 (or false false (or $x954))))
(and (not $x1108) (or $x1108 (and (distinct (bvadd in.3_32 (_ bv1 32)) (bvadd in.3_32 (_ bv1 32))) true))))))
(check-sat)
; query 194: function Long_term_analysis_filtering, block 35, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in32_64 () (_ BitVec 64))
(assert
 (let ((?x347 (ite (bvsge (_ bv18446744073709518848 64) in32_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x347 ?x347) true)))))))
(check-sat)
; query 195: function Long_term_analysis_filtering, block 46, name %47
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1498 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x1513 (or false false (or $x1498))))
(and (not $x1513) (or $x1513 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 196: function Long_term_analysis_filtering, block 76, name %77
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in73_64 () (_ BitVec 64))
(assert
 (let ((?x1086 (ite (bvsge (_ bv18446744073709518848 64) in73_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x1086 ?x1086) true)))))))
(check-sat)
; query 197: function Long_term_analysis_filtering, block 87, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x879 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x991 (or false false (or $x879))))
(and (not $x991) (or $x991 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 198: function Postprocessing, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in17_64 () (_ BitVec 64))
(assert
 (let ((?x428 (ite (bvslt (_ bv0 64) in17_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x428 ?x428) true)))))))
(check-sat)
; query 199: function Postprocessing, block 20, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in17_64 () (_ BitVec 64))
(assert
 (let ((?x428 (ite (bvslt (_ bv0 64) in17_64) (_ bv1 1) (_ bv0 1))))
(let ((?x709 ((_ zero_extend 63) ?x428)))
(let (($x57 (or false false false)))
(let (($x686 (or $x57 false)))
(let (($x1855 (not $x686)))
(and $x1855 (or $x686 (and (distinct ?x709 ?x709) true)))))))))
(check-sat)
; query 200: function Postprocessing, block 20, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in17_64 () (_ BitVec 64))
(assert
 (let ((?x428 (ite (bvslt (_ bv0 64) in17_64) (_ bv1 1) (_ bv0 1))))
(let (($x826 (= (_ bv1 1) ?x428)))
(let ((?x1083 (ite $x826 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x57 (or false false false)))
(let (($x476 (or $x57 (ite $x826 false false))))
(and (not $x476) (or $x476 (and (distinct ?x1083 ?x1083) true)))))))))
(check-sat)
; query 201: function Postprocessing, block 20, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in17_64 () (_ BitVec 64))
(assert
 (let ((?x428 (ite (bvslt (_ bv0 64) in17_64) (_ bv1 1) (_ bv0 1))))
(let (($x826 (= (_ bv1 1) ?x428)))
(let ((?x1083 (ite $x826 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x913 ((_ sign_extend 32) ?x1083)))
(let (($x57 (or false false false)))
(let (($x476 (or $x57 (ite $x826 false false))))
(let (($x250 (or $x476 false)))
(and (not $x250) (or $x250 (and (distinct ?x913 ?x913) true)))))))))))
(check-sat)
; query 202: function Postprocessing, block 34, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in31_64 () (_ BitVec 64))
(assert
 (let ((?x1087 (ite (bvslt (_ bv0 64) in31_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x1087 ?x1087) true)))))))
(check-sat)
; query 203: function Postprocessing, block 34, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in31_64 () (_ BitVec 64))
(assert
 (let ((?x1087 (ite (bvslt (_ bv0 64) in31_64) (_ bv1 1) (_ bv0 1))))
(let ((?x254 ((_ zero_extend 63) ?x1087)))
(let (($x57 (or false false false)))
(let (($x686 (or $x57 false)))
(let (($x1855 (not $x686)))
(and $x1855 (or $x686 (and (distinct ?x254 ?x254) true)))))))))
(check-sat)
; query 204: function Postprocessing, block 34, name %37
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in31_64 () (_ BitVec 64))
(assert
 (let ((?x1087 (ite (bvslt (_ bv0 64) in31_64) (_ bv1 1) (_ bv0 1))))
(let (($x975 (= (_ bv1 1) ?x1087)))
(let ((?x1067 (ite $x975 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x57 (or false false false)))
(let (($x449 (or $x57 (ite $x975 false false))))
(and (not $x449) (or $x449 (and (distinct ?x1067 ?x1067) true)))))))))
(check-sat)
; query 205: function Postprocessing, block 34, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in31_64 () (_ BitVec 64))
(assert
 (let ((?x1087 (ite (bvslt (_ bv0 64) in31_64) (_ bv1 1) (_ bv0 1))))
(let (($x975 (= (_ bv1 1) ?x1087)))
(let ((?x1067 (ite $x975 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x941 ((_ sign_extend 32) ?x1067)))
(let (($x57 (or false false false)))
(let (($x449 (or $x57 (ite $x975 false false))))
(let (($x842 (or $x449 false)))
(and (not $x842) (or $x842 (and (distinct ?x941 ?x941) true)))))))))))
(check-sat)
; query 206: function Quantization_and_coding, block 11, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in8_64 () (_ BitVec 64))
(assert
 (let ((?x165 (ite (bvslt (_ bv0 64) in8_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x165 ?x165) true)))))))
(check-sat)
; query 207: function Quantization_and_coding, block 11, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in8_64 () (_ BitVec 64))
(assert
 (let ((?x165 (ite (bvslt (_ bv0 64) in8_64) (_ bv1 1) (_ bv0 1))))
(let ((?x251 ((_ zero_extend 63) ?x165)))
(let (($x57 (or false false false)))
(let (($x686 (or $x57 false)))
(let (($x1855 (not $x686)))
(and $x1855 (or $x686 (and (distinct ?x251 ?x251) true)))))))))
(check-sat)
; query 208: function Quantization_and_coding, block 11, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in8_64 () (_ BitVec 64))
(assert
 (let ((?x165 (ite (bvslt (_ bv0 64) in8_64) (_ bv1 1) (_ bv0 1))))
(let (($x864 (= (_ bv1 1) ?x165)))
(let ((?x769 (ite $x864 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x57 (or false false false)))
(let (($x244 (or $x57 (ite $x864 false false))))
(and (not $x244) (or $x244 (and (distinct ?x769 ?x769) true)))))))))
(check-sat)
; query 209: function Quantization_and_coding, block 11, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in8_64 () (_ BitVec 64))
(assert
 (let ((?x165 (ite (bvslt (_ bv0 64) in8_64) (_ bv1 1) (_ bv0 1))))
(let (($x864 (= (_ bv1 1) ?x165)))
(let ((?x769 (ite $x864 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x460 ((_ sign_extend 32) ?x769)))
(let (($x57 (or false false false)))
(let (($x244 (or $x57 (ite $x864 false false))))
(let (($x902 (or $x244 false)))
(and (not $x902) (or $x902 (and (distinct ?x460 ?x460) true)))))))))))
(check-sat)
; query 210: function Quantization_and_coding, block 111, name %112
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in108_64 () (_ BitVec 64))
(assert
 (let ((?x481 (ite (bvslt (_ bv0 64) in108_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x481 ?x481) true)))))))
(check-sat)
; query 211: function Quantization_and_coding, block 111, name %113
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in108_64 () (_ BitVec 64))
(assert
 (let ((?x481 (ite (bvslt (_ bv0 64) in108_64) (_ bv1 1) (_ bv0 1))))
(let ((?x556 ((_ zero_extend 63) ?x481)))
(let (($x57 (or false false false)))
(let (($x686 (or $x57 false)))
(let (($x1855 (not $x686)))
(and $x1855 (or $x686 (and (distinct ?x556 ?x556) true)))))))))
(check-sat)
; query 212: function Quantization_and_coding, block 111, name %114
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in108_64 () (_ BitVec 64))
(assert
 (let ((?x481 (ite (bvslt (_ bv0 64) in108_64) (_ bv1 1) (_ bv0 1))))
(let (($x261 (= (_ bv1 1) ?x481)))
(let ((?x1037 (ite $x261 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x57 (or false false false)))
(let (($x299 (or $x57 (ite $x261 false false))))
(and (not $x299) (or $x299 (and (distinct ?x1037 ?x1037) true)))))))))
(check-sat)
; query 213: function Quantization_and_coding, block 111, name %115
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in108_64 () (_ BitVec 64))
(assert
 (let ((?x481 (ite (bvslt (_ bv0 64) in108_64) (_ bv1 1) (_ bv0 1))))
(let (($x261 (= (_ bv1 1) ?x481)))
(let ((?x1037 (ite $x261 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x919 ((_ sign_extend 32) ?x1037)))
(let (($x57 (or false false false)))
(let (($x299 (or $x57 (ite $x261 false false))))
(let (($x801 (or $x299 false)))
(and (not $x801) (or $x801 (and (distinct ?x919 ?x919) true)))))))))))
(check-sat)
; query 214: function Quantization_and_coding, block 124, name %125
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in121_64 () (_ BitVec 64))
(assert
 (let ((?x1986 (ite (bvslt (_ bv0 64) in121_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x1986 ?x1986) true)))))))
(check-sat)
; query 215: function Quantization_and_coding, block 124, name %126
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in121_64 () (_ BitVec 64))
(assert
 (let ((?x1986 (ite (bvslt (_ bv0 64) in121_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1972 ((_ zero_extend 63) ?x1986)))
(let (($x57 (or false false false)))
(let (($x686 (or $x57 false)))
(let (($x1855 (not $x686)))
(and $x1855 (or $x686 (and (distinct ?x1972 ?x1972) true)))))))))
(check-sat)
; query 216: function Quantization_and_coding, block 124, name %127
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in121_64 () (_ BitVec 64))
(assert
 (let ((?x1986 (ite (bvslt (_ bv0 64) in121_64) (_ bv1 1) (_ bv0 1))))
(let (($x1923 (= (_ bv1 1) ?x1986)))
(let ((?x1931 (ite $x1923 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x57 (or false false false)))
(let (($x1900 (or $x57 (ite $x1923 false false))))
(and (not $x1900) (or $x1900 (and (distinct ?x1931 ?x1931) true)))))))))
(check-sat)
; query 217: function Quantization_and_coding, block 124, name %128
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in121_64 () (_ BitVec 64))
(assert
 (let ((?x1986 (ite (bvslt (_ bv0 64) in121_64) (_ bv1 1) (_ bv0 1))))
(let (($x1923 (= (_ bv1 1) ?x1986)))
(let ((?x1931 (ite $x1923 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x1862 ((_ sign_extend 32) ?x1931)))
(let (($x57 (or false false false)))
(let (($x1900 (or $x57 (ite $x1923 false false))))
(let (($x1860 (or $x1900 false)))
(and (not $x1860) (or $x1860 (and (distinct ?x1862 ?x1862) true)))))))))))
(check-sat)
; query 218: function Quantization_and_coding, block 139, name %140
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in135_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in135_16) ((_ sign_extend 16) in135_16)) true))))))
(check-sat)
; query 219: function Quantization_and_coding, block 139, name %141
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in135_16 () (_ BitVec 16))
(assert
 (let ((?x1859 (ite (bvsgt (_ bv4294967280 32) ((_ sign_extend 16) in135_16)) (_ bv1 1) (_ bv0 1))))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x41 (not $x73)))
(and $x41 (or $x73 (and (distinct ?x1859 ?x1859) true))))))))
(check-sat)
; query 220: function Quantization_and_coding, block 143, name %144
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in135_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in135_16) ((_ sign_extend 16) in135_16)) true))))))
(check-sat)
; query 221: function Quantization_and_coding, block 143, name %145
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in135_16 () (_ BitVec 16))
(assert
 (let ((?x1833 ((_ sign_extend 16) in135_16)))
(let ((?x1963 (bvsub ?x1833 (_ bv4294967280 32))))
(let (($x1971 (and (distinct (bvsub ((_ sign_extend 1) ?x1833) ((_ sign_extend 1) (_ bv4294967280 32))) ((_ sign_extend 1) ?x1963)) true)))
(let (($x224 (or false false)))
(let (($x1953 (or $x224 false (or $x1971))))
(and (not $x1953) (or $x1953 (and (distinct ?x1963 ?x1963) true)))))))))
(check-sat)
; query 222: function Quantization_and_coding, block 161, name %162
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in158_64 () (_ BitVec 64))
(assert
 (let ((?x1795 (ite (bvslt (_ bv0 64) in158_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x1795 ?x1795) true)))))))
(check-sat)
; query 223: function Quantization_and_coding, block 161, name %163
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in158_64 () (_ BitVec 64))
(assert
 (let ((?x1795 (ite (bvslt (_ bv0 64) in158_64) (_ bv1 1) (_ bv0 1))))
(let ((?x882 ((_ zero_extend 63) ?x1795)))
(let (($x57 (or false false false)))
(let (($x686 (or $x57 false)))
(let (($x1855 (not $x686)))
(and $x1855 (or $x686 (and (distinct ?x882 ?x882) true)))))))))
(check-sat)
; query 224: function Quantization_and_coding, block 161, name %164
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in158_64 () (_ BitVec 64))
(assert
 (let ((?x1795 (ite (bvslt (_ bv0 64) in158_64) (_ bv1 1) (_ bv0 1))))
(let (($x888 (= (_ bv1 1) ?x1795)))
(let ((?x560 (ite $x888 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x57 (or false false false)))
(let (($x1684 (or $x57 (ite $x888 false false))))
(and (not $x1684) (or $x1684 (and (distinct ?x560 ?x560) true)))))))))
(check-sat)
; query 225: function Quantization_and_coding, block 161, name %165
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in158_64 () (_ BitVec 64))
(assert
 (let ((?x1795 (ite (bvslt (_ bv0 64) in158_64) (_ bv1 1) (_ bv0 1))))
(let (($x888 (= (_ bv1 1) ?x1795)))
(let ((?x560 (ite $x888 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x47 ((_ sign_extend 32) ?x560)))
(let (($x57 (or false false false)))
(let (($x1684 (or $x57 (ite $x888 false false))))
(let (($x189 (or $x1684 false)))
(and (not $x189) (or $x189 (and (distinct ?x47 ?x47) true)))))))))))
(check-sat)
; query 226: function Quantization_and_coding, block 174, name %175
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in171_64 () (_ BitVec 64))
(assert
 (let ((?x366 (ite (bvslt (_ bv0 64) in171_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x366 ?x366) true)))))))
(check-sat)
; query 227: function Quantization_and_coding, block 174, name %176
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in171_64 () (_ BitVec 64))
(assert
 (let ((?x366 (ite (bvslt (_ bv0 64) in171_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1766 ((_ zero_extend 63) ?x366)))
(let (($x57 (or false false false)))
(let (($x686 (or $x57 false)))
(let (($x1855 (not $x686)))
(and $x1855 (or $x686 (and (distinct ?x1766 ?x1766) true)))))))))
(check-sat)
; query 228: function Quantization_and_coding, block 174, name %177
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in171_64 () (_ BitVec 64))
(assert
 (let ((?x366 (ite (bvslt (_ bv0 64) in171_64) (_ bv1 1) (_ bv0 1))))
(let (($x1317 (= (_ bv1 1) ?x366)))
(let ((?x784 (ite $x1317 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x57 (or false false false)))
(let (($x877 (or $x57 (ite $x1317 false false))))
(and (not $x877) (or $x877 (and (distinct ?x784 ?x784) true)))))))))
(check-sat)
; query 229: function Quantization_and_coding, block 174, name %178
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in171_64 () (_ BitVec 64))
(assert
 (let ((?x366 (ite (bvslt (_ bv0 64) in171_64) (_ bv1 1) (_ bv0 1))))
(let (($x1317 (= (_ bv1 1) ?x366)))
(let ((?x784 (ite $x1317 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x871 ((_ sign_extend 32) ?x784)))
(let (($x57 (or false false false)))
(let (($x877 (or $x57 (ite $x1317 false false))))
(let (($x1707 (or $x877 false)))
(and (not $x1707) (or $x1707 (and (distinct ?x871 ?x871) true)))))))))))
(check-sat)
; query 230: function Quantization_and_coding, block 189, name %190
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in185_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in185_16) ((_ sign_extend 16) in185_16)) true))))))
(check-sat)
; query 231: function Quantization_and_coding, block 189, name %191
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in185_16 () (_ BitVec 16))
(assert
 (let ((?x839 (ite (bvsgt (_ bv4294967280 32) ((_ sign_extend 16) in185_16)) (_ bv1 1) (_ bv0 1))))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x41 (not $x73)))
(and $x41 (or $x73 (and (distinct ?x839 ?x839) true))))))))
(check-sat)
; query 232: function Quantization_and_coding, block 193, name %194
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in185_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in185_16) ((_ sign_extend 16) in185_16)) true))))))
(check-sat)
; query 233: function Quantization_and_coding, block 193, name %195
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in185_16 () (_ BitVec 16))
(assert
 (let ((?x1408 ((_ sign_extend 16) in185_16)))
(let ((?x705 (bvsub ?x1408 (_ bv4294967280 32))))
(let (($x516 (and (distinct (bvsub ((_ sign_extend 1) ?x1408) ((_ sign_extend 1) (_ bv4294967280 32))) ((_ sign_extend 1) ?x705)) true)))
(let (($x224 (or false false)))
(let (($x340 (or $x224 false (or $x516))))
(and (not $x340) (or $x340 (and (distinct ?x705 ?x705) true)))))))))
(check-sat)
; query 234: function Quantization_and_coding, block 211, name %212
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in208_64 () (_ BitVec 64))
(assert
 (let ((?x320 (ite (bvslt (_ bv0 64) in208_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x320 ?x320) true)))))))
(check-sat)
; query 235: function Quantization_and_coding, block 211, name %213
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in208_64 () (_ BitVec 64))
(assert
 (let ((?x320 (ite (bvslt (_ bv0 64) in208_64) (_ bv1 1) (_ bv0 1))))
(let ((?x258 ((_ zero_extend 63) ?x320)))
(let (($x57 (or false false false)))
(let (($x686 (or $x57 false)))
(let (($x1855 (not $x686)))
(and $x1855 (or $x686 (and (distinct ?x258 ?x258) true)))))))))
(check-sat)
; query 236: function Quantization_and_coding, block 211, name %214
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in208_64 () (_ BitVec 64))
(assert
 (let ((?x320 (ite (bvslt (_ bv0 64) in208_64) (_ bv1 1) (_ bv0 1))))
(let (($x1095 (= (_ bv1 1) ?x320)))
(let ((?x262 (ite $x1095 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x57 (or false false false)))
(let (($x216 (or $x57 (ite $x1095 false false))))
(and (not $x216) (or $x216 (and (distinct ?x262 ?x262) true)))))))))
(check-sat)
; query 237: function Quantization_and_coding, block 211, name %215
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in208_64 () (_ BitVec 64))
(assert
 (let ((?x320 (ite (bvslt (_ bv0 64) in208_64) (_ bv1 1) (_ bv0 1))))
(let (($x1095 (= (_ bv1 1) ?x320)))
(let ((?x262 (ite $x1095 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x576 ((_ sign_extend 32) ?x262)))
(let (($x57 (or false false false)))
(let (($x216 (or $x57 (ite $x1095 false false))))
(let (($x920 (or $x216 false)))
(and (not $x920) (or $x920 (and (distinct ?x576 ?x576) true)))))))))))
(check-sat)
; query 238: function Quantization_and_coding, block 224, name %225
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in221_64 () (_ BitVec 64))
(assert
 (let ((?x1603 (ite (bvslt (_ bv0 64) in221_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x1603 ?x1603) true)))))))
(check-sat)
; query 239: function Quantization_and_coding, block 224, name %226
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in221_64 () (_ BitVec 64))
(assert
 (let ((?x1603 (ite (bvslt (_ bv0 64) in221_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1561 ((_ zero_extend 63) ?x1603)))
(let (($x57 (or false false false)))
(let (($x686 (or $x57 false)))
(let (($x1855 (not $x686)))
(and $x1855 (or $x686 (and (distinct ?x1561 ?x1561) true)))))))))
(check-sat)
; query 240: function Quantization_and_coding, block 224, name %227
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in221_64 () (_ BitVec 64))
(assert
 (let ((?x1603 (ite (bvslt (_ bv0 64) in221_64) (_ bv1 1) (_ bv0 1))))
(let (($x1032 (= (_ bv1 1) ?x1603)))
(let ((?x1040 (ite $x1032 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x57 (or false false false)))
(let (($x507 (or $x57 (ite $x1032 false false))))
(and (not $x507) (or $x507 (and (distinct ?x1040 ?x1040) true)))))))))
(check-sat)
; query 241: function Quantization_and_coding, block 224, name %228
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in221_64 () (_ BitVec 64))
(assert
 (let ((?x1603 (ite (bvslt (_ bv0 64) in221_64) (_ bv1 1) (_ bv0 1))))
(let (($x1032 (= (_ bv1 1) ?x1603)))
(let ((?x1040 (ite $x1032 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x967 ((_ sign_extend 32) ?x1040)))
(let (($x57 (or false false false)))
(let (($x507 (or $x57 (ite $x1032 false false))))
(let (($x805 (or $x507 false)))
(and (not $x805) (or $x805 (and (distinct ?x967 ?x967) true)))))))))))
(check-sat)
; query 242: function Quantization_and_coding, block 239, name %240
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in235_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in235_16) ((_ sign_extend 16) in235_16)) true))))))
(check-sat)
; query 243: function Quantization_and_coding, block 239, name %241
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in235_16 () (_ BitVec 16))
(assert
 (let ((?x853 (ite (bvsgt (_ bv4294967288 32) ((_ sign_extend 16) in235_16)) (_ bv1 1) (_ bv0 1))))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x41 (not $x73)))
(and $x41 (or $x73 (and (distinct ?x853 ?x853) true))))))))
(check-sat)
; query 244: function Quantization_and_coding, block 24, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_64 () (_ BitVec 64))
(assert
 (let ((?x712 (ite (bvslt (_ bv0 64) in21_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x712 ?x712) true)))))))
(check-sat)
; query 245: function Quantization_and_coding, block 24, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_64 () (_ BitVec 64))
(assert
 (let ((?x712 (ite (bvslt (_ bv0 64) in21_64) (_ bv1 1) (_ bv0 1))))
(let ((?x289 ((_ zero_extend 63) ?x712)))
(let (($x57 (or false false false)))
(let (($x686 (or $x57 false)))
(let (($x1855 (not $x686)))
(and $x1855 (or $x686 (and (distinct ?x289 ?x289) true)))))))))
(check-sat)
; query 246: function Quantization_and_coding, block 24, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_64 () (_ BitVec 64))
(assert
 (let ((?x712 (ite (bvslt (_ bv0 64) in21_64) (_ bv1 1) (_ bv0 1))))
(let (($x296 (= (_ bv1 1) ?x712)))
(let ((?x392 (ite $x296 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x57 (or false false false)))
(let (($x482 (or $x57 (ite $x296 false false))))
(and (not $x482) (or $x482 (and (distinct ?x392 ?x392) true)))))))))
(check-sat)
; query 247: function Quantization_and_coding, block 24, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in21_64 () (_ BitVec 64))
(assert
 (let ((?x712 (ite (bvslt (_ bv0 64) in21_64) (_ bv1 1) (_ bv0 1))))
(let (($x296 (= (_ bv1 1) ?x712)))
(let ((?x392 (ite $x296 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x292 ((_ sign_extend 32) ?x392)))
(let (($x57 (or false false false)))
(let (($x482 (or $x57 (ite $x296 false false))))
(let (($x412 (or $x482 false)))
(and (not $x412) (or $x412 (and (distinct ?x292 ?x292) true)))))))))))
(check-sat)
; query 248: function Quantization_and_coding, block 243, name %244
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in235_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in235_16) ((_ sign_extend 16) in235_16)) true))))))
(check-sat)
; query 249: function Quantization_and_coding, block 243, name %245
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in235_16 () (_ BitVec 16))
(assert
 (let ((?x785 ((_ sign_extend 16) in235_16)))
(let ((?x985 (bvsub ?x785 (_ bv4294967288 32))))
(let (($x458 (and (distinct (bvsub ((_ sign_extend 1) ?x785) ((_ sign_extend 1) (_ bv4294967288 32))) ((_ sign_extend 1) ?x985)) true)))
(let (($x224 (or false false)))
(let (($x894 (or $x224 false (or $x458))))
(and (not $x894) (or $x894 (and (distinct ?x985 ?x985) true)))))))))
(check-sat)
; query 250: function Quantization_and_coding, block 261, name %262
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in258_64 () (_ BitVec 64))
(assert
 (let ((?x273 (ite (bvslt (_ bv0 64) in258_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x273 ?x273) true)))))))
(check-sat)
; query 251: function Quantization_and_coding, block 261, name %263
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in258_64 () (_ BitVec 64))
(assert
 (let ((?x273 (ite (bvslt (_ bv0 64) in258_64) (_ bv1 1) (_ bv0 1))))
(let ((?x770 ((_ zero_extend 63) ?x273)))
(let (($x57 (or false false false)))
(let (($x686 (or $x57 false)))
(let (($x1855 (not $x686)))
(and $x1855 (or $x686 (and (distinct ?x770 ?x770) true)))))))))
(check-sat)
; query 252: function Quantization_and_coding, block 261, name %264
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in258_64 () (_ BitVec 64))
(assert
 (let ((?x273 (ite (bvslt (_ bv0 64) in258_64) (_ bv1 1) (_ bv0 1))))
(let (($x736 (= (_ bv1 1) ?x273)))
(let ((?x899 (ite $x736 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x57 (or false false false)))
(let (($x730 (or $x57 (ite $x736 false false))))
(and (not $x730) (or $x730 (and (distinct ?x899 ?x899) true)))))))))
(check-sat)
; query 253: function Quantization_and_coding, block 261, name %265
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in258_64 () (_ BitVec 64))
(assert
 (let ((?x273 (ite (bvslt (_ bv0 64) in258_64) (_ bv1 1) (_ bv0 1))))
(let (($x736 (= (_ bv1 1) ?x273)))
(let ((?x899 (ite $x736 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x599 ((_ sign_extend 32) ?x899)))
(let (($x57 (or false false false)))
(let (($x730 (or $x57 (ite $x736 false false))))
(let (($x338 (or $x730 false)))
(and (not $x338) (or $x338 (and (distinct ?x599 ?x599) true)))))))))))
(check-sat)
; query 254: function Quantization_and_coding, block 274, name %275
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in271_64 () (_ BitVec 64))
(assert
 (let ((?x206 (ite (bvslt (_ bv0 64) in271_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x206 ?x206) true)))))))
(check-sat)
; query 255: function Quantization_and_coding, block 274, name %276
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in271_64 () (_ BitVec 64))
(assert
 (let ((?x206 (ite (bvslt (_ bv0 64) in271_64) (_ bv1 1) (_ bv0 1))))
(let ((?x892 ((_ zero_extend 63) ?x206)))
(let (($x57 (or false false false)))
(let (($x686 (or $x57 false)))
(let (($x1855 (not $x686)))
(and $x1855 (or $x686 (and (distinct ?x892 ?x892) true)))))))))
(check-sat)
; query 256: function Quantization_and_coding, block 274, name %277
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in271_64 () (_ BitVec 64))
(assert
 (let ((?x206 (ite (bvslt (_ bv0 64) in271_64) (_ bv1 1) (_ bv0 1))))
(let (($x901 (= (_ bv1 1) ?x206)))
(let ((?x810 (ite $x901 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x57 (or false false false)))
(let (($x788 (or $x57 (ite $x901 false false))))
(and (not $x788) (or $x788 (and (distinct ?x810 ?x810) true)))))))))
(check-sat)
; query 257: function Quantization_and_coding, block 274, name %278
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in271_64 () (_ BitVec 64))
(assert
 (let ((?x206 (ite (bvslt (_ bv0 64) in271_64) (_ bv1 1) (_ bv0 1))))
(let (($x901 (= (_ bv1 1) ?x206)))
(let ((?x810 (ite $x901 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x268 ((_ sign_extend 32) ?x810)))
(let (($x57 (or false false false)))
(let (($x788 (or $x57 (ite $x901 false false))))
(let (($x830 (or $x788 false)))
(and (not $x830) (or $x830 (and (distinct ?x268 ?x268) true)))))))))))
(check-sat)
; query 258: function Quantization_and_coding, block 289, name %290
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in285_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in285_16) ((_ sign_extend 16) in285_16)) true))))))
(check-sat)
; query 259: function Quantization_and_coding, block 289, name %291
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in285_16 () (_ BitVec 16))
(assert
 (let ((?x841 (ite (bvsgt (_ bv4294967288 32) ((_ sign_extend 16) in285_16)) (_ bv1 1) (_ bv0 1))))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x41 (not $x73)))
(and $x41 (or $x73 (and (distinct ?x841 ?x841) true))))))))
(check-sat)
; query 260: function Quantization_and_coding, block 293, name %294
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in285_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in285_16) ((_ sign_extend 16) in285_16)) true))))))
(check-sat)
; query 261: function Quantization_and_coding, block 293, name %295
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in285_16 () (_ BitVec 16))
(assert
 (let ((?x1110 ((_ sign_extend 16) in285_16)))
(let ((?x240 (bvsub ?x1110 (_ bv4294967288 32))))
(let (($x776 (and (distinct (bvsub ((_ sign_extend 1) ?x1110) ((_ sign_extend 1) (_ bv4294967288 32))) ((_ sign_extend 1) ?x240)) true)))
(let (($x224 (or false false)))
(let (($x285 (or $x224 false (or $x776))))
(and (not $x285) (or $x285 (and (distinct ?x240 ?x240) true)))))))))
(check-sat)
; query 262: function Quantization_and_coding, block 311, name %312
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in308_64 () (_ BitVec 64))
(assert
 (let ((?x605 (ite (bvslt (_ bv0 64) in308_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x605 ?x605) true)))))))
(check-sat)
; query 263: function Quantization_and_coding, block 311, name %313
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in308_64 () (_ BitVec 64))
(assert
 (let ((?x605 (ite (bvslt (_ bv0 64) in308_64) (_ bv1 1) (_ bv0 1))))
(let ((?x663 ((_ zero_extend 63) ?x605)))
(let (($x57 (or false false false)))
(let (($x686 (or $x57 false)))
(let (($x1855 (not $x686)))
(and $x1855 (or $x686 (and (distinct ?x663 ?x663) true)))))))))
(check-sat)
; query 264: function Quantization_and_coding, block 311, name %314
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in308_64 () (_ BitVec 64))
(assert
 (let ((?x605 (ite (bvslt (_ bv0 64) in308_64) (_ bv1 1) (_ bv0 1))))
(let (($x737 (= (_ bv1 1) ?x605)))
(let ((?x440 (ite $x737 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x57 (or false false false)))
(let (($x309 (or $x57 (ite $x737 false false))))
(and (not $x309) (or $x309 (and (distinct ?x440 ?x440) true)))))))))
(check-sat)
; query 265: function Quantization_and_coding, block 311, name %315
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in308_64 () (_ BitVec 64))
(assert
 (let ((?x605 (ite (bvslt (_ bv0 64) in308_64) (_ bv1 1) (_ bv0 1))))
(let (($x737 (= (_ bv1 1) ?x605)))
(let ((?x440 (ite $x737 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x514 ((_ sign_extend 32) ?x440)))
(let (($x57 (or false false false)))
(let (($x309 (or $x57 (ite $x737 false false))))
(let (($x596 (or $x309 false)))
(and (not $x596) (or $x596 (and (distinct ?x514 ?x514) true)))))))))))
(check-sat)
; query 266: function Quantization_and_coding, block 324, name %325
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in321_64 () (_ BitVec 64))
(assert
 (let ((?x257 (ite (bvslt (_ bv0 64) in321_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x257 ?x257) true)))))))
(check-sat)
; query 267: function Quantization_and_coding, block 324, name %326
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in321_64 () (_ BitVec 64))
(assert
 (let ((?x257 (ite (bvslt (_ bv0 64) in321_64) (_ bv1 1) (_ bv0 1))))
(let ((?x521 ((_ zero_extend 63) ?x257)))
(let (($x57 (or false false false)))
(let (($x686 (or $x57 false)))
(let (($x1855 (not $x686)))
(and $x1855 (or $x686 (and (distinct ?x521 ?x521) true)))))))))
(check-sat)
; query 268: function Quantization_and_coding, block 324, name %327
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in321_64 () (_ BitVec 64))
(assert
 (let ((?x257 (ite (bvslt (_ bv0 64) in321_64) (_ bv1 1) (_ bv0 1))))
(let (($x904 (= (_ bv1 1) ?x257)))
(let ((?x1092 (ite $x904 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x57 (or false false false)))
(let (($x992 (or $x57 (ite $x904 false false))))
(and (not $x992) (or $x992 (and (distinct ?x1092 ?x1092) true)))))))))
(check-sat)
; query 269: function Quantization_and_coding, block 324, name %328
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in321_64 () (_ BitVec 64))
(assert
 (let ((?x257 (ite (bvslt (_ bv0 64) in321_64) (_ bv1 1) (_ bv0 1))))
(let (($x904 (= (_ bv1 1) ?x257)))
(let ((?x1092 (ite $x904 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x425 ((_ sign_extend 32) ?x1092)))
(let (($x57 (or false false false)))
(let (($x992 (or $x57 (ite $x904 false false))))
(let (($x1511 (or $x992 false)))
(and (not $x1511) (or $x1511 (and (distinct ?x425 ?x425) true)))))))))))
(check-sat)
; query 270: function Quantization_and_coding, block 339, name %340
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in335_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in335_16) ((_ sign_extend 16) in335_16)) true))))))
(check-sat)
; query 271: function Quantization_and_coding, block 339, name %341
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in335_16 () (_ BitVec 16))
(assert
 (let ((?x1301 (ite (bvsgt (_ bv4294967292 32) ((_ sign_extend 16) in335_16)) (_ bv1 1) (_ bv0 1))))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x41 (not $x73)))
(and $x41 (or $x73 (and (distinct ?x1301 ?x1301) true))))))))
(check-sat)
; query 272: function Quantization_and_coding, block 343, name %344
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in335_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in335_16) ((_ sign_extend 16) in335_16)) true))))))
(check-sat)
; query 273: function Quantization_and_coding, block 343, name %345
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in335_16 () (_ BitVec 16))
(assert
 (let ((?x1333 ((_ sign_extend 16) in335_16)))
(let ((?x1043 (bvsub ?x1333 (_ bv4294967292 32))))
(let (($x1180 (and (distinct (bvsub ((_ sign_extend 1) ?x1333) ((_ sign_extend 1) (_ bv4294967292 32))) ((_ sign_extend 1) ?x1043)) true)))
(let (($x224 (or false false)))
(let (($x558 (or $x224 false (or $x1180))))
(and (not $x558) (or $x558 (and (distinct ?x1043 ?x1043) true)))))))))
(check-sat)
; query 274: function Quantization_and_coding, block 361, name %362
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in358_64 () (_ BitVec 64))
(assert
 (let ((?x538 (ite (bvslt (_ bv0 64) in358_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x538 ?x538) true)))))))
(check-sat)
; query 275: function Quantization_and_coding, block 361, name %363
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in358_64 () (_ BitVec 64))
(assert
 (let ((?x538 (ite (bvslt (_ bv0 64) in358_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1756 ((_ zero_extend 63) ?x538)))
(let (($x57 (or false false false)))
(let (($x686 (or $x57 false)))
(let (($x1855 (not $x686)))
(and $x1855 (or $x686 (and (distinct ?x1756 ?x1756) true)))))))))
(check-sat)
; query 276: function Quantization_and_coding, block 361, name %364
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in358_64 () (_ BitVec 64))
(assert
 (let ((?x538 (ite (bvslt (_ bv0 64) in358_64) (_ bv1 1) (_ bv0 1))))
(let (($x1683 (= (_ bv1 1) ?x538)))
(let ((?x1698 (ite $x1683 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x57 (or false false false)))
(let (($x927 (or $x57 (ite $x1683 false false))))
(and (not $x927) (or $x927 (and (distinct ?x1698 ?x1698) true)))))))))
(check-sat)
; query 277: function Quantization_and_coding, block 361, name %365
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in358_64 () (_ BitVec 64))
(assert
 (let ((?x538 (ite (bvslt (_ bv0 64) in358_64) (_ bv1 1) (_ bv0 1))))
(let (($x1683 (= (_ bv1 1) ?x538)))
(let ((?x1698 (ite $x1683 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x673 ((_ sign_extend 32) ?x1698)))
(let (($x57 (or false false false)))
(let (($x927 (or $x57 (ite $x1683 false false))))
(let (($x1616 (or $x927 false)))
(and (not $x1616) (or $x1616 (and (distinct ?x673 ?x673) true)))))))))))
(check-sat)
; query 278: function Quantization_and_coding, block 374, name %375
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in371_64 () (_ BitVec 64))
(assert
 (let ((?x498 (ite (bvslt (_ bv0 64) in371_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x498 ?x498) true)))))))
(check-sat)
; query 279: function Quantization_and_coding, block 374, name %376
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in371_64 () (_ BitVec 64))
(assert
 (let ((?x498 (ite (bvslt (_ bv0 64) in371_64) (_ bv1 1) (_ bv0 1))))
(let ((?x230 ((_ zero_extend 63) ?x498)))
(let (($x57 (or false false false)))
(let (($x686 (or $x57 false)))
(let (($x1855 (not $x686)))
(and $x1855 (or $x686 (and (distinct ?x230 ?x230) true)))))))))
(check-sat)
; query 280: function Quantization_and_coding, block 374, name %377
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in371_64 () (_ BitVec 64))
(assert
 (let ((?x498 (ite (bvslt (_ bv0 64) in371_64) (_ bv1 1) (_ bv0 1))))
(let (($x989 (= (_ bv1 1) ?x498)))
(let ((?x732 (ite $x989 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x57 (or false false false)))
(let (($x951 (or $x57 (ite $x989 false false))))
(and (not $x951) (or $x951 (and (distinct ?x732 ?x732) true)))))))))
(check-sat)
; query 281: function Quantization_and_coding, block 374, name %378
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in371_64 () (_ BitVec 64))
(assert
 (let ((?x498 (ite (bvslt (_ bv0 64) in371_64) (_ bv1 1) (_ bv0 1))))
(let (($x989 (= (_ bv1 1) ?x498)))
(let ((?x732 (ite $x989 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x367 ((_ sign_extend 32) ?x732)))
(let (($x57 (or false false false)))
(let (($x951 (or $x57 (ite $x989 false false))))
(let (($x872 (or $x951 false)))
(and (not $x872) (or $x872 (and (distinct ?x367 ?x367) true)))))))))))
(check-sat)
; query 282: function Quantization_and_coding, block 389, name %390
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in385_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in385_16) ((_ sign_extend 16) in385_16)) true))))))
(check-sat)
; query 283: function Quantization_and_coding, block 389, name %391
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in385_16 () (_ BitVec 16))
(assert
 (let ((?x781 (ite (bvsgt (_ bv4294967292 32) ((_ sign_extend 16) in385_16)) (_ bv1 1) (_ bv0 1))))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x41 (not $x73)))
(and $x41 (or $x73 (and (distinct ?x781 ?x781) true))))))))
(check-sat)
; query 284: function Quantization_and_coding, block 39, name %40
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in35_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in35_16) ((_ sign_extend 16) in35_16)) true))))))
(check-sat)
; query 285: function Quantization_and_coding, block 39, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in35_16 () (_ BitVec 16))
(assert
 (let ((?x604 (ite (bvsgt (_ bv4294967264 32) ((_ sign_extend 16) in35_16)) (_ bv1 1) (_ bv0 1))))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x41 (not $x73)))
(and $x41 (or $x73 (and (distinct ?x604 ?x604) true))))))))
(check-sat)
; query 286: function Quantization_and_coding, block 393, name %394
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in385_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in385_16) ((_ sign_extend 16) in385_16)) true))))))
(check-sat)
; query 287: function Quantization_and_coding, block 393, name %395
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in385_16 () (_ BitVec 16))
(assert
 (let ((?x874 ((_ sign_extend 16) in385_16)))
(let ((?x1738 (bvsub ?x874 (_ bv4294967292 32))))
(let (($x1113 (and (distinct (bvsub ((_ sign_extend 1) ?x874) ((_ sign_extend 1) (_ bv4294967292 32))) ((_ sign_extend 1) ?x1738)) true)))
(let (($x224 (or false false)))
(let (($x1478 (or $x224 false (or $x1113))))
(and (not $x1478) (or $x1478 (and (distinct ?x1738 ?x1738) true)))))))))
(check-sat)
; query 288: function Quantization_and_coding, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in35_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in35_16) ((_ sign_extend 16) in35_16)) true))))))
(check-sat)
; query 289: function Quantization_and_coding, block 43, name %45
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in35_16 () (_ BitVec 16))
(assert
 (let ((?x1609 ((_ sign_extend 16) in35_16)))
(let ((?x1390 (bvsub ?x1609 (_ bv4294967264 32))))
(let (($x1147 (and (distinct (bvsub ((_ sign_extend 1) ?x1609) ((_ sign_extend 1) (_ bv4294967264 32))) ((_ sign_extend 1) ?x1390)) true)))
(let (($x224 (or false false)))
(let (($x1146 (or $x224 false (or $x1147))))
(and (not $x1146) (or $x1146 (and (distinct ?x1390 ?x1390) true)))))))))
(check-sat)
; query 290: function Quantization_and_coding, block 61, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in58_64 () (_ BitVec 64))
(assert
 (let ((?x1142 (ite (bvslt (_ bv0 64) in58_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x1142 ?x1142) true)))))))
(check-sat)
; query 291: function Quantization_and_coding, block 61, name %63
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in58_64 () (_ BitVec 64))
(assert
 (let ((?x1142 (ite (bvslt (_ bv0 64) in58_64) (_ bv1 1) (_ bv0 1))))
(let ((?x988 ((_ zero_extend 63) ?x1142)))
(let (($x57 (or false false false)))
(let (($x686 (or $x57 false)))
(let (($x1855 (not $x686)))
(and $x1855 (or $x686 (and (distinct ?x988 ?x988) true)))))))))
(check-sat)
; query 292: function Quantization_and_coding, block 61, name %64
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in58_64 () (_ BitVec 64))
(assert
 (let ((?x1142 (ite (bvslt (_ bv0 64) in58_64) (_ bv1 1) (_ bv0 1))))
(let (($x1328 (= (_ bv1 1) ?x1142)))
(let ((?x1330 (ite $x1328 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x57 (or false false false)))
(let (($x1270 (or $x57 (ite $x1328 false false))))
(and (not $x1270) (or $x1270 (and (distinct ?x1330 ?x1330) true)))))))))
(check-sat)
; query 293: function Quantization_and_coding, block 61, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in58_64 () (_ BitVec 64))
(assert
 (let ((?x1142 (ite (bvslt (_ bv0 64) in58_64) (_ bv1 1) (_ bv0 1))))
(let (($x1328 (= (_ bv1 1) ?x1142)))
(let ((?x1330 (ite $x1328 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x527 ((_ sign_extend 32) ?x1330)))
(let (($x57 (or false false false)))
(let (($x1270 (or $x57 (ite $x1328 false false))))
(let (($x798 (or $x1270 false)))
(and (not $x798) (or $x798 (and (distinct ?x527 ?x527) true)))))))))))
(check-sat)
; query 294: function Quantization_and_coding, block 74, name %75
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in71_64 () (_ BitVec 64))
(assert
 (let ((?x1212 (ite (bvslt (_ bv0 64) in71_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x1212 ?x1212) true)))))))
(check-sat)
; query 295: function Quantization_and_coding, block 74, name %76
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in71_64 () (_ BitVec 64))
(assert
 (let ((?x1212 (ite (bvslt (_ bv0 64) in71_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1231 ((_ zero_extend 63) ?x1212)))
(let (($x57 (or false false false)))
(let (($x686 (or $x57 false)))
(let (($x1855 (not $x686)))
(and $x1855 (or $x686 (and (distinct ?x1231 ?x1231) true)))))))))
(check-sat)
; query 296: function Quantization_and_coding, block 74, name %77
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in71_64 () (_ BitVec 64))
(assert
 (let ((?x1212 (ite (bvslt (_ bv0 64) in71_64) (_ bv1 1) (_ bv0 1))))
(let (($x1238 (= (_ bv1 1) ?x1212)))
(let ((?x1749 (ite $x1238 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x57 (or false false false)))
(let (($x1229 (or $x57 (ite $x1238 false false))))
(and (not $x1229) (or $x1229 (and (distinct ?x1749 ?x1749) true)))))))))
(check-sat)
; query 297: function Quantization_and_coding, block 74, name %78
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in71_64 () (_ BitVec 64))
(assert
 (let ((?x1212 (ite (bvslt (_ bv0 64) in71_64) (_ bv1 1) (_ bv0 1))))
(let (($x1238 (= (_ bv1 1) ?x1212)))
(let ((?x1749 (ite $x1238 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x1257 ((_ sign_extend 32) ?x1749)))
(let (($x57 (or false false false)))
(let (($x1229 (or $x57 (ite $x1238 false false))))
(let (($x1241 (or $x1229 false)))
(and (not $x1241) (or $x1241 (and (distinct ?x1257 ?x1257) true)))))))))))
(check-sat)
; query 298: function Quantization_and_coding, block 89, name %90
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in85_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in85_16) ((_ sign_extend 16) in85_16)) true))))))
(check-sat)
; query 299: function Quantization_and_coding, block 89, name %91
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in85_16 () (_ BitVec 16))
(assert
 (let ((?x1315 (ite (bvsgt (_ bv4294967264 32) ((_ sign_extend 16) in85_16)) (_ bv1 1) (_ bv0 1))))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x41 (not $x73)))
(and $x41 (or $x73 (and (distinct ?x1315 ?x1315) true))))))))
(check-sat)
; query 300: function Quantization_and_coding, block 93, name %94
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in85_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in85_16) ((_ sign_extend 16) in85_16)) true))))))
(check-sat)
; query 301: function Quantization_and_coding, block 93, name %95
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in85_16 () (_ BitVec 16))
(assert
 (let ((?x1306 ((_ sign_extend 16) in85_16)))
(let ((?x1336 (bvsub ?x1306 (_ bv4294967264 32))))
(let (($x1364 (and (distinct (bvsub ((_ sign_extend 1) ?x1306) ((_ sign_extend 1) (_ bv4294967264 32))) ((_ sign_extend 1) ?x1336)) true)))
(let (($x224 (or false false)))
(let (($x1361 (or $x224 false (or $x1364))))
(and (not $x1361) (or $x1361 (and (distinct ?x1336 ?x1336) true)))))))))
(check-sat)
; query 302: function RPE_grid_positioning, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 303: function RPE_grid_positioning, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x1416 (ite (bvsge (_ bv3 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x41 (not $x73)))
(and $x41 (or $x73 (and (distinct ?x1416 ?x1416) true))))))))
(check-sat)
; query 304: function RPE_grid_positioning, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 305: function RPE_grid_positioning, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x228 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1464 (and (distinct ?x228 ?x228) true)))
(let (($x224 (or false false)))
(let (($x1012 (or false $x224 false)))
(and (not $x1012) (or $x1012 $x1464)))))))
(check-sat)
; query 306: function RPE_grid_selection, block 308, name %309
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_32 () (_ BitVec 32))
(assert
 (let (($x714 (and (distinct (bvadd ((_ sign_extend 1) in.03_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.03_32 (_ bv1 32)))) true)))
(let (($x66 (or false false (or $x714))))
(and (not $x66) (or $x66 (and (distinct (bvadd in.03_32 (_ bv1 32)) (bvadd in.03_32 (_ bv1 32))) true))))))
(check-sat)
; query 307: function Short_term_analysis_filtering, block 34, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in31_64 () (_ BitVec 64))
(assert
 (let ((?x1087 (ite (bvslt (_ bv0 64) in31_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x1087 ?x1087) true)))))))
(check-sat)
; query 308: function Short_term_analysis_filtering, block 34, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in31_64 () (_ BitVec 64))
(assert
 (let ((?x1087 (ite (bvslt (_ bv0 64) in31_64) (_ bv1 1) (_ bv0 1))))
(let ((?x254 ((_ zero_extend 63) ?x1087)))
(let (($x57 (or false false false)))
(let (($x686 (or $x57 false)))
(let (($x1855 (not $x686)))
(and $x1855 (or $x686 (and (distinct ?x254 ?x254) true)))))))))
(check-sat)
; query 309: function Short_term_analysis_filtering, block 34, name %37
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in31_64 () (_ BitVec 64))
(assert
 (let ((?x1087 (ite (bvslt (_ bv0 64) in31_64) (_ bv1 1) (_ bv0 1))))
(let (($x975 (= (_ bv1 1) ?x1087)))
(let ((?x1067 (ite $x975 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x57 (or false false false)))
(let (($x449 (or $x57 (ite $x975 false false))))
(and (not $x449) (or $x449 (and (distinct ?x1067 ?x1067) true)))))))))
(check-sat)
; query 310: function Short_term_analysis_filtering, block 34, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in31_64 () (_ BitVec 64))
(assert
 (let ((?x1087 (ite (bvslt (_ bv0 64) in31_64) (_ bv1 1) (_ bv0 1))))
(let (($x975 (= (_ bv1 1) ?x1087)))
(let ((?x1067 (ite $x975 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x941 ((_ sign_extend 32) ?x1067)))
(let (($x57 (or false false false)))
(let (($x449 (or $x57 (ite $x975 false false))))
(let (($x842 (or $x449 false)))
(and (not $x842) (or $x842 (and (distinct ?x941 ?x941) true)))))))))))
(check-sat)
; query 311: function Short_term_analysis_filtering, block 54, name %55
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in51_64 () (_ BitVec 64))
(assert
 (let ((?x1452 (ite (bvslt (_ bv0 64) in51_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x1452 ?x1452) true)))))))
(check-sat)
; query 312: function Short_term_analysis_filtering, block 54, name %56
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in51_64 () (_ BitVec 64))
(assert
 (let ((?x1452 (ite (bvslt (_ bv0 64) in51_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1449 ((_ zero_extend 63) ?x1452)))
(let (($x57 (or false false false)))
(let (($x686 (or $x57 false)))
(let (($x1855 (not $x686)))
(and $x1855 (or $x686 (and (distinct ?x1449 ?x1449) true)))))))))
(check-sat)
; query 313: function Short_term_analysis_filtering, block 54, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in51_64 () (_ BitVec 64))
(assert
 (let ((?x1452 (ite (bvslt (_ bv0 64) in51_64) (_ bv1 1) (_ bv0 1))))
(let (($x1316 (= (_ bv1 1) ?x1452)))
(let ((?x1351 (ite $x1316 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x57 (or false false false)))
(let (($x1182 (or $x57 (ite $x1316 false false))))
(and (not $x1182) (or $x1182 (and (distinct ?x1351 ?x1351) true)))))))))
(check-sat)
; query 314: function Short_term_analysis_filtering, block 54, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in51_64 () (_ BitVec 64))
(assert
 (let ((?x1452 (ite (bvslt (_ bv0 64) in51_64) (_ bv1 1) (_ bv0 1))))
(let (($x1316 (= (_ bv1 1) ?x1452)))
(let ((?x1351 (ite $x1316 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x1198 ((_ sign_extend 32) ?x1351)))
(let (($x57 (or false false false)))
(let (($x1182 (or $x57 (ite $x1316 false false))))
(let (($x850 (or $x1182 false)))
(and (not $x850) (or $x850 (and (distinct ?x1198 ?x1198) true)))))))))))
(check-sat)
; query 315: function Short_term_analysis_filtering, block 63, name %64
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_32 () (_ BitVec 32))
(assert
 (let (($x714 (and (distinct (bvadd ((_ sign_extend 1) in.03_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.03_32 (_ bv1 32)))) true)))
(let (($x66 (or false false (or $x714))))
(and (not $x66) (or $x66 (and (distinct (bvadd in.03_32 (_ bv1 32)) (bvadd in.03_32 (_ bv1 32))) true))))))
(check-sat)
; query 316: function Short_term_synthesis_filtering, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in23_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in23_16) ((_ sign_extend 16) in23_16)) true))))))
(check-sat)
; query 317: function Short_term_synthesis_filtering, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in23_16 () (_ BitVec 16))
(assert
 (let ((?x333 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in23_16)) (_ bv1 1) (_ bv0 1))))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x41 (not $x73)))
(and $x41 (or $x73 (and (distinct ?x333 ?x333) true))))))))
(check-sat)
; query 318: function Short_term_synthesis_filtering, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in20_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 48) in20_16) ((_ sign_extend 48) in20_16)) true))))))
(check-sat)
; query 319: function Short_term_synthesis_filtering, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in23_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 48) in23_16) ((_ sign_extend 48) in23_16)) true))))))
(check-sat)
; query 320: function Short_term_synthesis_filtering, block 30, name %33
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in23_16 () (_ BitVec 16))
(declare-fun in20_16 () (_ BitVec 16))
(assert
 (let ((?x417 ((_ sign_extend 48) in23_16)))
(let ((?x1584 ((_ sign_extend 48) in20_16)))
(let ((?x1077 (bvmul ?x1584 ?x417)))
(let (($x1646 (and (distinct (bvmul ((_ sign_extend 64) ?x1584) ((_ sign_extend 64) ?x417)) ((_ sign_extend 64) ?x1077)) true)))
(let (($x224 (or false false)))
(let (($x1225 (or $x224 $x224 (or $x1646))))
(and (not $x1225) (or $x1225 (and (distinct ?x1077 ?x1077) true))))))))))
(check-sat)
; query 321: function Short_term_synthesis_filtering, block 30, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in23_16 () (_ BitVec 16))
(declare-fun in20_16 () (_ BitVec 16))
(assert
 (let ((?x417 ((_ sign_extend 48) in23_16)))
(let ((?x1584 ((_ sign_extend 48) in20_16)))
(let ((?x1077 (bvmul ?x1584 ?x417)))
(let ((?x58 (bvadd ?x1077 (_ bv16384 64))))
(let (($x1091 (and (distinct (bvadd ((_ sign_extend 1) ?x1077) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x58)) true)))
(let (($x1646 (and (distinct (bvmul ((_ sign_extend 64) ?x1584) ((_ sign_extend 64) ?x417)) ((_ sign_extend 64) ?x1077)) true)))
(let (($x224 (or false false)))
(let (($x1225 (or $x224 $x224 (or $x1646))))
(let (($x164 (or $x1225 false (or $x1091))))
(and (not $x164) (or $x164 (and (distinct ?x58 ?x58) true)))))))))))))
(check-sat)
; query 322: function Short_term_synthesis_filtering, block 30, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in23_16 () (_ BitVec 16))
(declare-fun in20_16 () (_ BitVec 16))
(assert
 (let ((?x417 ((_ sign_extend 48) in23_16)))
(let ((?x1584 ((_ sign_extend 48) in20_16)))
(let ((?x1077 (bvmul ?x1584 ?x417)))
(let ((?x58 (bvadd ?x1077 (_ bv16384 64))))
(let ((?x430 (bvashr ?x58 (_ bv15 64))))
(let (($x1321 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1091 (and (distinct (bvadd ((_ sign_extend 1) ?x1077) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x58)) true)))
(let (($x1646 (and (distinct (bvmul ((_ sign_extend 64) ?x1584) ((_ sign_extend 64) ?x417)) ((_ sign_extend 64) ?x1077)) true)))
(let (($x224 (or false false)))
(let (($x1225 (or $x224 $x224 (or $x1646))))
(let (($x164 (or $x1225 false (or $x1091))))
(let (($x1026 (or (or $x164 false false) $x1321)))
(and (not $x1026) (or $x1026 (and (distinct ?x430 ?x430) true))))))))))))))))
(check-sat)
; query 323: function Short_term_synthesis_filtering, block 30, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in23_16 () (_ BitVec 16))
(declare-fun in20_16 () (_ BitVec 16))
(assert
 (let ((?x417 ((_ sign_extend 48) in23_16)))
(let ((?x1584 ((_ sign_extend 48) in20_16)))
(let ((?x1077 (bvmul ?x1584 ?x417)))
(let ((?x58 (bvadd ?x1077 (_ bv16384 64))))
(let ((?x430 (bvashr ?x58 (_ bv15 64))))
(let ((?x1566 (bvand (_ bv65535 64) ?x430)))
(let (($x1321 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1091 (and (distinct (bvadd ((_ sign_extend 1) ?x1077) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x58)) true)))
(let (($x1646 (and (distinct (bvmul ((_ sign_extend 64) ?x1584) ((_ sign_extend 64) ?x417)) ((_ sign_extend 64) ?x1077)) true)))
(let (($x224 (or false false)))
(let (($x1225 (or $x224 $x224 (or $x1646))))
(let (($x164 (or $x1225 false (or $x1091))))
(let (($x1026 (or (or $x164 false false) $x1321)))
(let (($x196 (or false $x1026 false)))
(and (not $x196) (or $x196 (and (distinct ?x1566 ?x1566) true))))))))))))))))))
(check-sat)
; query 324: function Short_term_synthesis_filtering, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in42_64 () (_ BitVec 64))
(assert
 (let ((?x472 (ite (bvsge (_ bv18446744073709518848 64) in42_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x472 ?x472) true)))))))
(check-sat)
; query 325: function Short_term_synthesis_filtering, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in53_16) ((_ sign_extend 16) in53_16)) true))))))
(check-sat)
; query 326: function Short_term_synthesis_filtering, block 56, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let ((?x780 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in53_16)) (_ bv1 1) (_ bv0 1))))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x41 (not $x73)))
(and $x41 (or $x73 (and (distinct ?x780 ?x780) true))))))))
(check-sat)
; query 327: function Short_term_synthesis_filtering, block 60, name %61
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in20_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 48) in20_16) ((_ sign_extend 48) in20_16)) true))))))
(check-sat)
; query 328: function Short_term_synthesis_filtering, block 60, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 48) in53_16) ((_ sign_extend 48) in53_16)) true))))))
(check-sat)
; query 329: function Short_term_synthesis_filtering, block 60, name %63
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(declare-fun in20_16 () (_ BitVec 16))
(assert
 (let ((?x833 ((_ sign_extend 48) in53_16)))
(let ((?x1584 ((_ sign_extend 48) in20_16)))
(let ((?x893 (bvmul ?x1584 ?x833)))
(let (($x313 (and (distinct (bvmul ((_ sign_extend 64) ?x1584) ((_ sign_extend 64) ?x833)) ((_ sign_extend 64) ?x893)) true)))
(let (($x224 (or false false)))
(let (($x915 (or $x224 $x224 (or $x313))))
(and (not $x915) (or $x915 (and (distinct ?x893 ?x893) true))))))))))
(check-sat)
; query 330: function Short_term_synthesis_filtering, block 60, name %64
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(declare-fun in20_16 () (_ BitVec 16))
(assert
 (let ((?x833 ((_ sign_extend 48) in53_16)))
(let ((?x1584 ((_ sign_extend 48) in20_16)))
(let ((?x893 (bvmul ?x1584 ?x833)))
(let ((?x130 (bvadd ?x893 (_ bv16384 64))))
(let (($x1595 (and (distinct (bvadd ((_ sign_extend 1) ?x893) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x130)) true)))
(let (($x313 (and (distinct (bvmul ((_ sign_extend 64) ?x1584) ((_ sign_extend 64) ?x833)) ((_ sign_extend 64) ?x893)) true)))
(let (($x224 (or false false)))
(let (($x915 (or $x224 $x224 (or $x313))))
(let (($x1597 (or $x915 false (or $x1595))))
(and (not $x1597) (or $x1597 (and (distinct ?x130 ?x130) true)))))))))))))
(check-sat)
; query 331: function Short_term_synthesis_filtering, block 60, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(declare-fun in20_16 () (_ BitVec 16))
(assert
 (let ((?x833 ((_ sign_extend 48) in53_16)))
(let ((?x1584 ((_ sign_extend 48) in20_16)))
(let ((?x893 (bvmul ?x1584 ?x833)))
(let ((?x130 (bvadd ?x893 (_ bv16384 64))))
(let ((?x378 (bvashr ?x130 (_ bv15 64))))
(let (($x1321 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1595 (and (distinct (bvadd ((_ sign_extend 1) ?x893) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x130)) true)))
(let (($x313 (and (distinct (bvmul ((_ sign_extend 64) ?x1584) ((_ sign_extend 64) ?x833)) ((_ sign_extend 64) ?x893)) true)))
(let (($x224 (or false false)))
(let (($x915 (or $x224 $x224 (or $x313))))
(let (($x1597 (or $x915 false (or $x1595))))
(let (($x453 (or (or $x1597 false false) $x1321)))
(and (not $x453) (or $x453 (and (distinct ?x378 ?x378) true))))))))))))))))
(check-sat)
; query 332: function Short_term_synthesis_filtering, block 60, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in53_16 () (_ BitVec 16))
(declare-fun in20_16 () (_ BitVec 16))
(assert
 (let ((?x833 ((_ sign_extend 48) in53_16)))
(let ((?x1584 ((_ sign_extend 48) in20_16)))
(let ((?x893 (bvmul ?x1584 ?x833)))
(let ((?x130 (bvadd ?x893 (_ bv16384 64))))
(let ((?x378 (bvashr ?x130 (_ bv15 64))))
(let ((?x961 (bvand (_ bv65535 64) ?x378)))
(let (($x1321 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x1595 (and (distinct (bvadd ((_ sign_extend 1) ?x893) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x130)) true)))
(let (($x313 (and (distinct (bvmul ((_ sign_extend 64) ?x1584) ((_ sign_extend 64) ?x833)) ((_ sign_extend 64) ?x893)) true)))
(let (($x224 (or false false)))
(let (($x915 (or $x224 $x224 (or $x313))))
(let (($x1597 (or $x915 false (or $x1595))))
(let (($x453 (or (or $x1597 false false) $x1321)))
(let (($x625 (or false $x453 false)))
(and (not $x625) (or $x625 (and (distinct ?x961 ?x961) true))))))))))))))))))
(check-sat)
; query 333: function Short_term_synthesis_filtering, block 78, name %79
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in75_64 () (_ BitVec 64))
(assert
 (let ((?x700 (ite (bvslt (_ bv0 64) in75_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x700 ?x700) true)))))))
(check-sat)
; query 334: function Short_term_synthesis_filtering, block 78, name %80
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in75_64 () (_ BitVec 64))
(assert
 (let ((?x700 (ite (bvslt (_ bv0 64) in75_64) (_ bv1 1) (_ bv0 1))))
(let ((?x1673 ((_ zero_extend 63) ?x700)))
(let (($x57 (or false false false)))
(let (($x686 (or $x57 false)))
(let (($x1855 (not $x686)))
(and $x1855 (or $x686 (and (distinct ?x1673 ?x1673) true)))))))))
(check-sat)
; query 335: function Short_term_synthesis_filtering, block 78, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in75_64 () (_ BitVec 64))
(assert
 (let ((?x700 (ite (bvslt (_ bv0 64) in75_64) (_ bv1 1) (_ bv0 1))))
(let (($x906 (= (_ bv1 1) ?x700)))
(let ((?x1964 (ite $x906 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x57 (or false false false)))
(let (($x1186 (or $x57 (ite $x906 false false))))
(and (not $x1186) (or $x1186 (and (distinct ?x1964 ?x1964) true)))))))))
(check-sat)
; query 336: function Short_term_synthesis_filtering, block 78, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in75_64 () (_ BitVec 64))
(assert
 (let ((?x700 (ite (bvslt (_ bv0 64) in75_64) (_ bv1 1) (_ bv0 1))))
(let (($x906 (= (_ bv1 1) ?x700)))
(let ((?x1964 (ite $x906 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x1987 ((_ sign_extend 32) ?x1964)))
(let (($x57 (or false false false)))
(let (($x1186 (or $x57 (ite $x906 false false))))
(let (($x1224 (or $x1186 false)))
(and (not $x1224) (or $x1224 (and (distinct ?x1987 ?x1987) true)))))))))))
(check-sat)
; query 337: function Transformation_to_Log_Area_Ratios, block 12, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in5_16) ((_ sign_extend 16) in5_16)) true))))))
(check-sat)
; query 338: function Transformation_to_Log_Area_Ratios, block 12, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_16 () (_ BitVec 16))
(assert
 (let ((?x1588 ((_ sign_extend 16) in5_16)))
(let ((?x1611 (bvsub (_ bv0 32) ?x1588)))
(let (($x317 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x1588)) ((_ sign_extend 1) ?x1611)) true)))
(let (($x224 (or false false)))
(let (($x1596 (or false $x224 (or $x317))))
(and (not $x1596) (or $x1596 (and (distinct ?x1611 ?x1611) true)))))))))
(check-sat)
; query 339: function Transformation_to_Log_Area_Ratios, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in5_16) ((_ sign_extend 16) in5_16)) true))))))
(check-sat)
; query 340: function Transformation_to_Log_Area_Ratios, block 77, name %78
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 341: function Transformation_to_Log_Area_Ratios, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_16 () (_ BitVec 16))
(assert
 (let ((?x1692 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in5_16)) (_ bv1 1) (_ bv0 1))))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x41 (not $x73)))
(and $x41 (or $x73 (and (distinct ?x1692 ?x1692) true))))))))
(check-sat)
; query 342: function Transformation_to_Log_Area_Ratios, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in5_16) ((_ sign_extend 16) in5_16)) true))))))
(check-sat)
; query 343: function Weighting_filter, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in70_64 () (_ BitVec 64))
(assert
 (let ((?x1751 (ite (bvslt (_ bv32767 64) in70_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x1751 ?x1751) true)))))))
(check-sat)
; query 344: function Weighting_filter, block 84, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1498 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x1513 (or false false (or $x1498))))
(and (not $x1513) (or $x1513 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 345: function alaw_input, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x410 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x1004 (or false false (or $x410))))
(and (not $x1004) (or $x1004 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 346: function alaw_input, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let ((?x1081 (ite (= (_ bv4294967295 32) in.1_32) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x1081 ?x1081) true)))))))
(check-sat)
; query 347: function gsm_L_add, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_64 () (_ BitVec 64))
(assert
 (let ((?x1227 (bvsub (_ bv0 64) in13_64)))
(let ((?x1184 ((_ sign_extend 1) ?x1227)))
(let (($x1303 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in13_64)) ?x1184) true)))))
(and (not $x1303) (or $x1303 (and (distinct ?x1227 ?x1227) true)))))))
(check-sat)
; query 348: function gsm_L_add, block 16, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_64 () (_ BitVec 64))
(assert
 (let ((?x1227 (bvsub (_ bv0 64) in13_64)))
(let ((?x1332 (bvsub ?x1227 (_ bv2 64))))
(let (($x1422 (and (distinct (bvsub ((_ sign_extend 1) ?x1227) ((_ sign_extend 1) (_ bv2 64))) ((_ sign_extend 1) ?x1332)) true)))
(let ((?x1184 ((_ sign_extend 1) ?x1227)))
(let (($x1303 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in13_64)) ?x1184) true)))))
(let (($x1612 (or $x1303 false (or $x1422))))
(and (not $x1612) (or $x1612 (and (distinct ?x1332 ?x1332) true))))))))))
(check-sat)
; query 349: function gsm_L_add, block 21, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1038 (ite (bvsge (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x1038 ?x1038) true)))))))
(check-sat)
; query 350: function gsm_L_add, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1320 (bvadd in0_64 in1_64)))
(let (($x1326 (and (distinct ?x1320 ?x1320) true)))
(let (($x1318 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) ?x1320)) true)))
(let (($x1401 (or false false (or $x1318))))
(and (not $x1401) (or $x1401 $x1326)))))))
(check-sat)
; query 351: function gsm_L_add, block 25, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1320 (bvadd in0_64 in1_64)))
(let (($x1326 (and (distinct ?x1320 ?x1320) true)))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 $x1326)))))))
(check-sat)
; query 352: function gsm_L_add, block 25, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1266 (ite (bvugt (bvadd in0_64 in1_64) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x1145 (or $x57 false false)))
(let (($x485 (not $x1145)))
(and $x485 (or $x1145 (and (distinct ?x1266 ?x1266) true))))))))
(check-sat)
; query 353: function gsm_L_add, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1264 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x1264 ?x1264) true)))))))
(check-sat)
; query 354: function gsm_L_add, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1320 (bvadd in0_64 in1_64)))
(let (($x1326 (and (distinct ?x1320 ?x1320) true)))
(let (($x1318 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) ?x1320)) true)))
(let (($x1401 (or false false (or $x1318))))
(and (not $x1401) (or $x1401 $x1326)))))))
(check-sat)
; query 355: function gsm_L_add, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x255 (bvadd in0_64 (_ bv1 64))))
(let ((?x1933 (bvsub (_ bv0 64) ?x255)))
(let (($x1909 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x255)) ((_ sign_extend 1) ?x1933)) true)))
(let ((?x806 ((_ sign_extend 1) ?x255)))
(let (($x1777 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x806) true)))))
(let (($x1872 (or false $x1777 (or $x1909))))
(and (not $x1872) (or $x1872 (and (distinct ?x1933 ?x1933) true))))))))))
(check-sat)
; query 356: function gsm_L_add, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1824 (bvadd in1_64 (_ bv1 64))))
(let ((?x1573 ((_ sign_extend 1) ?x1824)))
(let (($x324 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1573) true)))))
(and (not $x324) (or $x324 (and (distinct ?x1824 ?x1824) true)))))))
(check-sat)
; query 357: function gsm_L_add, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1824 (bvadd in1_64 (_ bv1 64))))
(let ((?x132 (bvsub (_ bv0 64) ?x1824)))
(let (($x1841 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1824)) ((_ sign_extend 1) ?x132)) true)))
(let ((?x1573 ((_ sign_extend 1) ?x1824)))
(let (($x324 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1573) true)))))
(let (($x1958 (or false $x324 (or $x1841))))
(and (not $x1958) (or $x1958 (and (distinct ?x132 ?x132) true))))))))))
(check-sat)
; query 358: function gsm_L_add, block 8, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1824 (bvadd in1_64 (_ bv1 64))))
(let ((?x132 (bvsub (_ bv0 64) ?x1824)))
(let ((?x255 (bvadd in0_64 (_ bv1 64))))
(let ((?x1933 (bvsub (_ bv0 64) ?x255)))
(let ((?x1060 (bvadd ?x1933 ?x132)))
(let (($x1841 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1824)) ((_ sign_extend 1) ?x132)) true)))
(let ((?x1573 ((_ sign_extend 1) ?x1824)))
(let (($x324 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1573) true)))))
(let (($x1958 (or false $x324 (or $x1841))))
(let (($x1909 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x255)) ((_ sign_extend 1) ?x1933)) true)))
(let ((?x806 ((_ sign_extend 1) ?x255)))
(let (($x1777 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x806) true)))))
(let (($x1872 (or false $x1777 (or $x1909))))
(let (($x1969 (or $x1872 $x1958 false)))
(and (not $x1969) (or $x1969 (and (distinct ?x1060 ?x1060) true))))))))))))))))))
(check-sat)
; query 359: function gsm_L_add, block 8, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1824 (bvadd in1_64 (_ bv1 64))))
(let ((?x132 (bvsub (_ bv0 64) ?x1824)))
(let ((?x255 (bvadd in0_64 (_ bv1 64))))
(let ((?x1933 (bvsub (_ bv0 64) ?x255)))
(let ((?x1060 (bvadd ?x1933 ?x132)))
(let ((?x1907 (ite (bvuge ?x1060 (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x1841 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1824)) ((_ sign_extend 1) ?x132)) true)))
(let ((?x1573 ((_ sign_extend 1) ?x1824)))
(let (($x324 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1573) true)))))
(let (($x1958 (or false $x324 (or $x1841))))
(let (($x1909 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x255)) ((_ sign_extend 1) ?x1933)) true)))
(let ((?x806 ((_ sign_extend 1) ?x255)))
(let (($x1777 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x806) true)))))
(let (($x1872 (or false $x1777 (or $x1909))))
(let (($x1969 (or $x1872 $x1958 false)))
(let (($x1917 (or $x1969 false false)))
(and (not $x1917) (or $x1917 (and (distinct ?x1907 ?x1907) true))))))))))))))))))))
(check-sat)
; query 360: function gsm_L_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x255 (bvadd in0_64 (_ bv1 64))))
(let ((?x806 ((_ sign_extend 1) ?x255)))
(let (($x1777 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x806) true)))))
(and (not $x1777) (or $x1777 (and (distinct ?x255 ?x255) true)))))))
(check-sat)
; query 361: function gsm_L_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1996 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x1996 ?x1996) true)))))))
(check-sat)
; query 362: function gsm_L_asl, block 12, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x2002 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x2002 ?x2002) true)))))))
(check-sat)
; query 363: function gsm_L_asl, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ zero_extend 32) in1_32) ((_ zero_extend 32) in1_32)) true))))))
(check-sat)
; query 364: function gsm_L_asl, block 17, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2006 ((_ zero_extend 32) in1_32)))
(let ((?x2009 (bvshl in0_64 ?x2006)))
(let (($x224 (or false false)))
(let (($x1012 (or false $x224 false)))
(let (($x2008 (or $x1012 (bvuge ?x2006 (_ bv64 64)))))
(let (($x2013 (not $x2008)))
(and $x2013 (or $x2008 (and (distinct ?x2009 ?x2009) true))))))))))
(check-sat)
; query 365: function gsm_L_asl, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x2018 (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x2018 ?x2018) true)))))))
(check-sat)
; query 366: function gsm_L_asl, block 7, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1996 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x2022 ((_ zero_extend 31) ?x1996)))
(let ((?x2026 (bvsub (_ bv0 32) ?x2022)))
(let (($x2027 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x2022)) ((_ sign_extend 1) ?x2026)) true)))
(let (($x57 (or false false false)))
(let (($x686 (or $x57 false)))
(let (($x2029 (or false $x686 (or $x2027))))
(and (not $x2029) (or $x2029 (and (distinct ?x2026 ?x2026) true)))))))))))
(check-sat)
; query 367: function gsm_L_asl, block 7, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1996 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x2022 ((_ zero_extend 31) ?x1996)))
(let ((?x2026 (bvsub (_ bv0 32) ?x2022)))
(let ((?x2030 ((_ sign_extend 32) ?x2026)))
(let (($x2027 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x2022)) ((_ sign_extend 1) ?x2026)) true)))
(let (($x57 (or false false false)))
(let (($x686 (or $x57 false)))
(let (($x2029 (or false $x686 (or $x2027))))
(let (($x2031 (or $x2029 false)))
(and (not $x2031) (or $x2031 (and (distinct ?x2030 ?x2030) true)))))))))))))
(check-sat)
; query 368: function gsm_L_asl, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1996 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x1996 ?x1996) true)))))))
(check-sat)
; query 369: function gsm_L_asl, block 7, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1996 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x2022 ((_ zero_extend 31) ?x1996)))
(let (($x57 (or false false false)))
(let (($x686 (or $x57 false)))
(let (($x1855 (not $x686)))
(and $x1855 (or $x686 (and (distinct ?x2022 ?x2022) true)))))))))
(check-sat)
; query 370: function gsm_L_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x2044 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x2044 ?x2044) true)))))))
(check-sat)
; query 371: function gsm_L_asr, block 12, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x2002 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x2002 ?x2002) true)))))))
(check-sat)
; query 372: function gsm_L_asr, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x2052 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in1_32))) true)))
(let (($x2054 (or false false (or $x2052))))
(and (not $x2054) (or $x2054 (and (distinct (bvsub (_ bv0 32) in1_32) (bvsub (_ bv0 32) in1_32)) true))))))
(check-sat)
; query 373: function gsm_L_asr, block 14, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x2051 (bvsub (_ bv0 32) in1_32)))
(let ((?x2055 ((_ zero_extend 32) ?x2051)))
(let (($x2052 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x2051)) true)))
(let (($x2054 (or false false (or $x2052))))
(let (($x2056 (or $x2054 false)))
(and (not $x2056) (or $x2056 (and (distinct ?x2055 ?x2055) true)))))))))
(check-sat)
; query 374: function gsm_L_asr, block 14, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2051 (bvsub (_ bv0 32) in1_32)))
(let ((?x2055 ((_ zero_extend 32) ?x2051)))
(let ((?x2060 (bvshl in0_64 ?x2055)))
(let (($x2052 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x2051)) true)))
(let (($x2054 (or false false (or $x2052))))
(let (($x2056 (or $x2054 false)))
(let (($x2059 (or (or false $x2056 false) (bvuge ?x2055 (_ bv64 64)))))
(and (not $x2059) (or $x2059 (and (distinct ?x2060 ?x2060) true)))))))))))
(check-sat)
; query 375: function gsm_L_asr, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ zero_extend 32) in1_32) ((_ zero_extend 32) in1_32)) true))))))
(check-sat)
; query 376: function gsm_L_asr, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2006 ((_ zero_extend 32) in1_32)))
(let ((?x2073 (bvashr in0_64 ?x2006)))
(let (($x224 (or false false)))
(let (($x1012 (or false $x224 false)))
(let (($x2008 (or $x1012 (bvuge ?x2006 (_ bv64 64)))))
(let (($x2013 (not $x2008)))
(and $x2013 (or $x2008 (and (distinct ?x2073 ?x2073) true))))))))))
(check-sat)
; query 377: function gsm_L_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1996 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x1996 ?x1996) true)))))))
(check-sat)
; query 378: function gsm_L_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1996 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x2022 ((_ zero_extend 31) ?x1996)))
(let (($x57 (or false false false)))
(let (($x686 (or $x57 false)))
(let (($x1855 (not $x686)))
(and $x1855 (or $x686 (and (distinct ?x2022 ?x2022) true)))))))))
(check-sat)
; query 379: function gsm_L_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1996 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x2022 ((_ zero_extend 31) ?x1996)))
(let ((?x2026 (bvsub (_ bv0 32) ?x2022)))
(let (($x2027 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x2022)) ((_ sign_extend 1) ?x2026)) true)))
(let (($x57 (or false false false)))
(let (($x686 (or $x57 false)))
(let (($x2029 (or false $x686 (or $x2027))))
(and (not $x2029) (or $x2029 (and (distinct ?x2026 ?x2026) true)))))))))))
(check-sat)
; query 380: function gsm_L_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1996 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x2022 ((_ zero_extend 31) ?x1996)))
(let ((?x2026 (bvsub (_ bv0 32) ?x2022)))
(let ((?x2030 ((_ sign_extend 32) ?x2026)))
(let (($x2027 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x2022)) ((_ sign_extend 1) ?x2026)) true)))
(let (($x57 (or false false false)))
(let (($x686 (or $x57 false)))
(let (($x2029 (or false $x686 (or $x2027))))
(let (($x2031 (or $x2029 false)))
(and (not $x2031) (or $x2031 (and (distinct ?x2030 ?x2030) true)))))))))))))
(check-sat)
; query 381: function gsm_L_asr, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x2018 (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x2018 ?x2018) true)))))))
(check-sat)
; query 382: function gsm_L_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x2044 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x2044 ?x2044) true)))))))
(check-sat)
; query 383: function gsm_L_mult, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 384: function gsm_L_mult, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x2078 (ite (and (distinct (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) true) (_ bv1 1) (_ bv0 1))))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x41 (not $x73)))
(and $x41 (or $x73 (and (distinct ?x2078 ?x2078) true))))))))
(check-sat)
; query 385: function gsm_L_mult, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 386: function gsm_L_mult, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x2083 (ite (and (distinct (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) true) (_ bv1 1) (_ bv0 1))))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x41 (not $x73)))
(and $x41 (or $x73 (and (distinct ?x2083 ?x2083) true))))))))
(check-sat)
; query 387: function gsm_L_sub, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in11_64 () (_ BitVec 64))
(assert
 (let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct (bvadd in11_64 (_ bv1 64)) (bvadd in11_64 (_ bv1 64))) true))))))
(check-sat)
; query 388: function gsm_L_sub, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1038 (ite (bvsge (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x1038 ?x1038) true)))))))
(check-sat)
; query 389: function gsm_L_sub, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x2094 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvsub in0_64 in1_64))) true)))
(let (($x2097 (or false false (or $x2094))))
(let (($x2100 (or $x2097 (and (distinct (bvsub in0_64 in1_64) (bvsub in0_64 in1_64)) true))))
(and (not $x2097) $x2100)))))
(check-sat)
; query 390: function gsm_L_sub, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x255 (bvadd in0_64 (_ bv1 64))))
(let ((?x806 ((_ sign_extend 1) ?x255)))
(let (($x1777 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x806) true)))))
(and (not $x1777) (or $x1777 (and (distinct ?x255 ?x255) true)))))))
(check-sat)
; query 391: function gsm_L_sub, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x255 (bvadd in0_64 (_ bv1 64))))
(let ((?x1933 (bvsub (_ bv0 64) ?x255)))
(let (($x1909 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x255)) ((_ sign_extend 1) ?x1933)) true)))
(let ((?x806 ((_ sign_extend 1) ?x255)))
(let (($x1777 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x806) true)))))
(let (($x1872 (or false $x1777 (or $x1909))))
(and (not $x1872) (or $x1872 (and (distinct ?x1933 ?x1933) true))))))))))
(check-sat)
; query 392: function gsm_L_sub, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x255 (bvadd in0_64 (_ bv1 64))))
(let ((?x1933 (bvsub (_ bv0 64) ?x255)))
(let ((?x2102 (bvadd ?x1933 in1_64)))
(let (($x1909 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x255)) ((_ sign_extend 1) ?x1933)) true)))
(let ((?x806 ((_ sign_extend 1) ?x255)))
(let (($x1777 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x806) true)))))
(let (($x1872 (or false $x1777 (or $x1909))))
(let (($x2103 (or $x1872 false false)))
(and (not $x2103) (or $x2103 (and (distinct ?x2102 ?x2102) true))))))))))))
(check-sat)
; query 393: function gsm_L_sub, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2106 (ite (bvuge (bvadd (bvsub (_ bv0 64) (bvadd in0_64 (_ bv1 64))) in1_64) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x1909 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) (bvadd in0_64 (_ bv1 64)))) ((_ sign_extend 1) (bvsub (_ bv0 64) (bvadd in0_64 (_ bv1 64))))) true)))
(let ((?x255 (bvadd in0_64 (_ bv1 64))))
(let ((?x806 ((_ sign_extend 1) ?x255)))
(let (($x1777 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x806) true)))))
(let (($x1872 (or false $x1777 (or $x1909))))
(let (($x2103 (or $x1872 false false)))
(let (($x2105 (or $x2103 false false)))
(and (not $x2105) (or $x2105 (and (distinct ?x2106 ?x2106) true))))))))))))
(check-sat)
; query 394: function gsm_L_sub, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_64 () (_ BitVec 64))
(assert
 (let ((?x2119 (bvsub (_ bv0 64) in25_64)))
(let ((?x2117 ((_ sign_extend 1) ?x2119)))
(let (($x2122 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in25_64)) ?x2117) true)))))
(and (not $x2122) (or $x2122 (and (distinct ?x2119 ?x2119) true)))))))
(check-sat)
; query 395: function gsm_L_sub, block 28, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_64 () (_ BitVec 64))
(assert
 (let ((?x2119 (bvsub (_ bv0 64) in25_64)))
(let ((?x2125 (bvsub ?x2119 (_ bv1 64))))
(let (($x2126 (and (distinct (bvsub ((_ sign_extend 1) ?x2119) ((_ sign_extend 1) (_ bv1 64))) ((_ sign_extend 1) ?x2125)) true)))
(let ((?x2117 ((_ sign_extend 1) ?x2119)))
(let (($x2122 (or false false (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) in25_64)) ?x2117) true)))))
(let (($x2128 (or $x2122 false (or $x2126))))
(and (not $x2128) (or $x2128 (and (distinct ?x2125 ?x2125) true))))))))))
(check-sat)
; query 396: function gsm_L_sub, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1264 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x1264 ?x1264) true)))))))
(check-sat)
; query 397: function gsm_L_sub, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x2094 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvsub in0_64 in1_64))) true)))
(let (($x2097 (or false false (or $x2094))))
(let (($x2100 (or $x2097 (and (distinct (bvsub in0_64 in1_64) (bvsub in0_64 in1_64)) true))))
(and (not $x2097) $x2100)))))
(check-sat)
; query 398: function gsm_L_sub, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1824 (bvadd in1_64 (_ bv1 64))))
(let ((?x132 (bvsub (_ bv0 64) ?x1824)))
(let (($x1841 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1824)) ((_ sign_extend 1) ?x132)) true)))
(let ((?x1573 ((_ sign_extend 1) ?x1824)))
(let (($x324 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1573) true)))))
(let (($x1958 (or false $x324 (or $x1841))))
(and (not $x1958) (or $x1958 (and (distinct ?x132 ?x132) true))))))))))
(check-sat)
; query 399: function gsm_L_sub, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x1824 (bvadd in1_64 (_ bv1 64))))
(let ((?x132 (bvsub (_ bv0 64) ?x1824)))
(let ((?x2137 (bvadd in0_64 ?x132)))
(let (($x1841 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x1824)) ((_ sign_extend 1) ?x132)) true)))
(let ((?x1573 ((_ sign_extend 1) ?x1824)))
(let (($x324 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1573) true)))))
(let (($x1958 (or false $x324 (or $x1841))))
(let (($x2138 (or false $x1958 false)))
(and (not $x2138) (or $x2138 (and (distinct ?x2137 ?x2137) true))))))))))))
(check-sat)
; query 400: function gsm_L_sub, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2141 (ite (bvuge (bvadd in0_64 (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64)))) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x1841 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) (bvadd in1_64 (_ bv1 64)))) ((_ sign_extend 1) (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64))))) true)))
(let ((?x1824 (bvadd in1_64 (_ bv1 64))))
(let ((?x1573 ((_ sign_extend 1) ?x1824)))
(let (($x324 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1573) true)))))
(let (($x1958 (or false $x324 (or $x1841))))
(let (($x2138 (or false $x1958 false)))
(let (($x2140 (or $x2138 false false)))
(and (not $x2140) (or $x2140 (and (distinct ?x2141 ?x2141) true))))))))))))
(check-sat)
; query 401: function gsm_L_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x1824 (bvadd in1_64 (_ bv1 64))))
(let ((?x1573 ((_ sign_extend 1) ?x1824)))
(let (($x324 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x1573) true)))))
(and (not $x324) (or $x324 (and (distinct ?x1824 ?x1824) true)))))))
(check-sat)
; query 402: function gsm_L_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2151 (ite (bvsle (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x2151 ?x2151) true)))))))
(check-sat)
; query 403: function gsm_abs, block 13, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 404: function gsm_abs, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 405: function gsm_abs, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x2156 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x41 (not $x73)))
(and $x41 (or $x73 (and (distinct ?x2156 ?x2156) true))))))))
(check-sat)
; query 406: function gsm_abs, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x90 ((_ sign_extend 16) in0_16)))
(let ((?x2163 (bvsub (_ bv0 32) ?x90)))
(let (($x2164 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x90)) ((_ sign_extend 1) ?x2163)) true)))
(let (($x224 (or false false)))
(let (($x2166 (or false $x224 (or $x2164))))
(and (not $x2166) (or $x2166 (and (distinct ?x2163 ?x2163) true)))))))))
(check-sat)
; query 407: function gsm_abs, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 408: function gsm_abs, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 409: function gsm_abs, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x2172 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x41 (not $x73)))
(and $x41 (or $x73 (and (distinct ?x2172 ?x2172) true))))))))
(check-sat)
; query 410: function gsm_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_64 () (_ BitVec 64))
(assert
 (let ((?x2178 (ite (bvslt (_ bv32767 64) in5_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x2178 ?x2178) true)))))))
(check-sat)
; query 411: function gsm_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 412: function gsm_add, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 413: function gsm_add, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x2183 ((_ sign_extend 48) in1_16)))
(let ((?x2182 ((_ sign_extend 48) in0_16)))
(let ((?x2187 (bvadd ?x2182 ?x2183)))
(let (($x2189 (and (distinct (bvadd ((_ sign_extend 1) ?x2182) ((_ sign_extend 1) ?x2183)) ((_ sign_extend 1) ?x2187)) true)))
(let (($x224 (or false false)))
(let (($x2191 (or $x224 $x224 (or $x2189))))
(and (not $x2191) (or $x2191 (and (distinct ?x2187 ?x2187) true))))))))))
(check-sat)
; query 414: function gsm_add, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x2194 (ite (bvsgt (_ bv18446744073709518848 64) (bvadd ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x2183 ((_ sign_extend 48) in1_16)))
(let ((?x2185 ((_ sign_extend 1) ?x2183)))
(let ((?x2182 ((_ sign_extend 48) in0_16)))
(let ((?x2184 ((_ sign_extend 1) ?x2182)))
(let (($x224 (or false false)))
(let (($x2191 (or $x224 $x224 (or (and (distinct (bvadd ?x2184 ?x2185) ((_ sign_extend 1) (bvadd ?x2182 ?x2183))) true)))))
(let (($x2193 (or $x2191 false false)))
(and (not $x2193) (or $x2193 (and (distinct ?x2194 ?x2194) true))))))))))))
(check-sat)
; query 415: function gsm_asl, block 13, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x2002 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x2002 ?x2002) true)))))))
(check-sat)
; query 416: function gsm_asl, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 417: function gsm_asl, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x90 ((_ sign_extend 16) in0_16)))
(let ((?x2211 (bvshl ?x90 in1_32)))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x2210 (or $x73 (bvuge in1_32 (_ bv32 32)))))
(let (($x2214 (not $x2210)))
(and $x2214 (or $x2210 (and (distinct ?x2211 ?x2211) true))))))))))
(check-sat)
; query 418: function gsm_asl, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x90 ((_ sign_extend 16) in0_16)))
(let ((?x2211 (bvshl ?x90 in1_32)))
(let ((?x2212 ((_ extract 15 0) ?x2211)))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x2210 (or $x73 (bvuge in1_32 (_ bv32 32)))))
(let (($x2213 (or $x2210 false)))
(let (($x2218 (not $x2213)))
(and $x2218 (or $x2213 (and (distinct ?x2212 ?x2212) true))))))))))))
(check-sat)
; query 419: function gsm_asl, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x2223 (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x2223 ?x2223) true)))))))
(check-sat)
; query 420: function gsm_asl, block 7, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x2172 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x2227 ((_ zero_extend 31) ?x2172)))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x2228 (or $x73 false)))
(and (not $x2228) (or $x2228 (and (distinct ?x2227 ?x2227) true)))))))))
(check-sat)
; query 421: function gsm_asl, block 7, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x2172 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x2227 ((_ zero_extend 31) ?x2172)))
(let ((?x2232 (bvsub (_ bv0 32) ?x2227)))
(let (($x2233 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x2227)) ((_ sign_extend 1) ?x2232)) true)))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x2228 (or $x73 false)))
(let (($x2235 (or false $x2228 (or $x2233))))
(and (not $x2235) (or $x2235 (and (distinct ?x2232 ?x2232) true))))))))))))
(check-sat)
; query 422: function gsm_asl, block 7, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x2172 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x2227 ((_ zero_extend 31) ?x2172)))
(let ((?x2232 (bvsub (_ bv0 32) ?x2227)))
(let ((?x2236 ((_ extract 15 0) ?x2232)))
(let (($x2233 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x2227)) ((_ sign_extend 1) ?x2232)) true)))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x2228 (or $x73 false)))
(let (($x2235 (or false $x2228 (or $x2233))))
(let (($x2237 (or $x2235 false)))
(and (not $x2237) (or $x2237 (and (distinct ?x2236 ?x2236) true))))))))))))))
(check-sat)
; query 423: function gsm_asl, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 424: function gsm_asl, block 7, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x2172 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x41 (not $x73)))
(and $x41 (or $x73 (and (distinct ?x2172 ?x2172) true))))))))
(check-sat)
; query 425: function gsm_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x2252 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x2252 ?x2252) true)))))))
(check-sat)
; query 426: function gsm_asr, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x2223 (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x2223 ?x2223) true)))))))
(check-sat)
; query 427: function gsm_asr, block 13, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x2002 (ite (bvsgt (_ bv0 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x2002 ?x2002) true)))))))
(check-sat)
; query 428: function gsm_asr, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 429: function gsm_asr, block 15, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x2052 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in1_32))) true)))
(let (($x2054 (or false false (or $x2052))))
(and (not $x2054) (or $x2054 (and (distinct (bvsub (_ bv0 32) in1_32) (bvsub (_ bv0 32) in1_32)) true))))))
(check-sat)
; query 430: function gsm_asr, block 15, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x2051 (bvsub (_ bv0 32) in1_32)))
(let ((?x90 ((_ sign_extend 16) in0_16)))
(let ((?x2259 (bvshl ?x90 ?x2051)))
(let (($x2052 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x2051)) true)))
(let (($x2054 (or false false (or $x2052))))
(let (($x224 (or false false)))
(let (($x2258 (or (or $x224 $x2054 false) (bvuge ?x2051 (_ bv32 32)))))
(and (not $x2258) (or $x2258 (and (distinct ?x2259 ?x2259) true)))))))))))
(check-sat)
; query 431: function gsm_asr, block 15, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x2051 (bvsub (_ bv0 32) in1_32)))
(let ((?x90 ((_ sign_extend 16) in0_16)))
(let ((?x2259 (bvshl ?x90 ?x2051)))
(let ((?x2260 ((_ extract 15 0) ?x2259)))
(let (($x2052 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in1_32)) ((_ sign_extend 1) ?x2051)) true)))
(let (($x2054 (or false false (or $x2052))))
(let (($x224 (or false false)))
(let (($x2258 (or (or $x224 $x2054 false) (bvuge ?x2051 (_ bv32 32)))))
(let (($x2261 (or $x2258 false)))
(and (not $x2261) (or $x2261 (and (distinct ?x2260 ?x2260) true)))))))))))))
(check-sat)
; query 432: function gsm_asr, block 20, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 433: function gsm_asr, block 20, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x90 ((_ sign_extend 16) in0_16)))
(let ((?x2270 (bvashr ?x90 in1_32)))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x2210 (or $x73 (bvuge in1_32 (_ bv32 32)))))
(let (($x2214 (not $x2210)))
(and $x2214 (or $x2210 (and (distinct ?x2270 ?x2270) true))))))))))
(check-sat)
; query 434: function gsm_asr, block 20, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x90 ((_ sign_extend 16) in0_16)))
(let ((?x2270 (bvashr ?x90 in1_32)))
(let ((?x2271 ((_ extract 15 0) ?x2270)))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x2210 (or $x73 (bvuge in1_32 (_ bv32 32)))))
(let (($x2213 (or $x2210 false)))
(let (($x2218 (not $x2213)))
(and $x2218 (or $x2213 (and (distinct ?x2271 ?x2271) true))))))))))))
(check-sat)
; query 435: function gsm_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 436: function gsm_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x2172 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x41 (not $x73)))
(and $x41 (or $x73 (and (distinct ?x2172 ?x2172) true))))))))
(check-sat)
; query 437: function gsm_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x2172 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x2227 ((_ zero_extend 31) ?x2172)))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x2228 (or $x73 false)))
(and (not $x2228) (or $x2228 (and (distinct ?x2227 ?x2227) true)))))))))
(check-sat)
; query 438: function gsm_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x2172 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x2227 ((_ zero_extend 31) ?x2172)))
(let ((?x2232 (bvsub (_ bv0 32) ?x2227)))
(let (($x2233 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x2227)) ((_ sign_extend 1) ?x2232)) true)))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x2228 (or $x73 false)))
(let (($x2235 (or false $x2228 (or $x2233))))
(and (not $x2235) (or $x2235 (and (distinct ?x2232 ?x2232) true))))))))))))
(check-sat)
; query 439: function gsm_asr, block 4, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x2172 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x2227 ((_ zero_extend 31) ?x2172)))
(let ((?x2232 (bvsub (_ bv0 32) ?x2227)))
(let ((?x2236 ((_ extract 15 0) ?x2232)))
(let (($x2233 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x2227)) ((_ sign_extend 1) ?x2232)) true)))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x2228 (or $x73 false)))
(let (($x2235 (or false $x2228 (or $x2233))))
(let (($x2237 (or $x2235 false)))
(and (not $x2237) (or $x2237 (and (distinct ?x2236 ?x2236) true))))))))))))))
(check-sat)
; query 440: function gsm_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x2252 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x2252 ?x2252) true)))))))
(check-sat)
; query 441: function gsm_debug_longwords, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in15_32 () (_ BitVec 32))
(assert
 (let ((?x2281 (ite (bvslt in15_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x2281 ?x2281) true)))))))
(check-sat)
; query 442: function gsm_debug_words, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(declare-fun in16_32 () (_ BitVec 32))
(assert
 (let ((?x2287 (ite (bvslt in16_32 in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x2287 ?x2287) true)))))))
(check-sat)
; query 443: function gsm_div, block 7, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x2293 (ite (bvsge ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x224 (or false false)))
(let (($x2292 (or $x224 $x224 false)))
(and (not $x2292) (or $x2292 (and (distinct ?x2293 ?x2293) true)))))))
(check-sat)
; query 444: function gsm_div, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 445: function gsm_div, block 7, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 446: function gsm_div, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 447: function gsm_div, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 448: function gsm_div, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 449: function gsm_div, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x228 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1464 (and (distinct ?x228 ?x228) true)))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x41 (not $x73)))
(and $x41 (or $x73 $x1464))))))))
(check-sat)
; query 450: function gsm_mult, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 451: function gsm_mult, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x2301 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x41 (not $x73)))
(and $x41 (or $x73 (and (distinct ?x2301 ?x2301) true))))))))
(check-sat)
; query 452: function gsm_mult, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 453: function gsm_mult, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 454: function gsm_mult, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x2183 ((_ sign_extend 48) in1_16)))
(let ((?x2182 ((_ sign_extend 48) in0_16)))
(let ((?x2307 (bvmul ?x2182 ?x2183)))
(let (($x2310 (and (distinct (bvmul ((_ sign_extend 64) ?x2182) ((_ sign_extend 64) ?x2183)) ((_ sign_extend 64) ?x2307)) true)))
(let (($x224 (or false false)))
(let (($x2312 (or $x224 $x224 (or $x2310))))
(and (not $x2312) (or $x2312 (and (distinct ?x2307 ?x2307) true))))))))))
(check-sat)
; query 455: function gsm_mult, block 9, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x2183 ((_ sign_extend 48) in1_16)))
(let ((?x2182 ((_ sign_extend 48) in0_16)))
(let ((?x2307 (bvmul ?x2182 ?x2183)))
(let ((?x2315 (bvashr ?x2307 (_ bv15 64))))
(let (($x1321 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x2310 (and (distinct (bvmul ((_ sign_extend 64) ?x2182) ((_ sign_extend 64) ?x2183)) ((_ sign_extend 64) ?x2307)) true)))
(let (($x224 (or false false)))
(let (($x2312 (or $x224 $x224 (or $x2310))))
(let (($x2314 (or (or $x2312 false false) $x1321)))
(and (not $x2314) (or $x2314 (and (distinct ?x2315 ?x2315) true)))))))))))))
(check-sat)
; query 456: function gsm_mult, block 9, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x2183 ((_ sign_extend 48) in1_16)))
(let ((?x2182 ((_ sign_extend 48) in0_16)))
(let ((?x2307 (bvmul ?x2182 ?x2183)))
(let ((?x2315 (bvashr ?x2307 (_ bv15 64))))
(let ((?x2316 ((_ extract 15 0) ?x2315)))
(let (($x1321 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x2310 (and (distinct (bvmul ((_ sign_extend 64) ?x2182) ((_ sign_extend 64) ?x2183)) ((_ sign_extend 64) ?x2307)) true)))
(let (($x224 (or false false)))
(let (($x2312 (or $x224 $x224 (or $x2310))))
(let (($x2314 (or (or $x2312 false false) $x1321)))
(let (($x2317 (or $x2314 false)))
(and (not $x2317) (or $x2317 (and (distinct ?x2316 ?x2316) true)))))))))))))))
(check-sat)
; query 457: function gsm_mult, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 458: function gsm_mult, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x2156 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x41 (not $x73)))
(and $x41 (or $x73 (and (distinct ?x2156 ?x2156) true))))))))
(check-sat)
; query 459: function gsm_mult_r, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 460: function gsm_mult_r, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x2156 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x41 (not $x73)))
(and $x41 (or $x73 (and (distinct ?x2156 ?x2156) true))))))))
(check-sat)
; query 461: function gsm_mult_r, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 462: function gsm_mult_r, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 463: function gsm_mult_r, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x2183 ((_ sign_extend 48) in1_16)))
(let ((?x2182 ((_ sign_extend 48) in0_16)))
(let ((?x2307 (bvmul ?x2182 ?x2183)))
(let (($x2310 (and (distinct (bvmul ((_ sign_extend 64) ?x2182) ((_ sign_extend 64) ?x2183)) ((_ sign_extend 64) ?x2307)) true)))
(let (($x224 (or false false)))
(let (($x2312 (or $x224 $x224 (or $x2310))))
(and (not $x2312) (or $x2312 (and (distinct ?x2307 ?x2307) true))))))))))
(check-sat)
; query 464: function gsm_mult_r, block 9, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x2183 ((_ sign_extend 48) in1_16)))
(let ((?x2182 ((_ sign_extend 48) in0_16)))
(let ((?x2307 (bvmul ?x2182 ?x2183)))
(let ((?x2332 (bvadd ?x2307 (_ bv16384 64))))
(let (($x2334 (and (distinct (bvadd ((_ sign_extend 1) ?x2307) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x2332)) true)))
(let (($x2310 (and (distinct (bvmul ((_ sign_extend 64) ?x2182) ((_ sign_extend 64) ?x2183)) ((_ sign_extend 64) ?x2307)) true)))
(let (($x224 (or false false)))
(let (($x2312 (or $x224 $x224 (or $x2310))))
(let (($x2336 (or $x2312 false (or $x2334))))
(and (not $x2336) (or $x2336 (and (distinct ?x2332 ?x2332) true)))))))))))))
(check-sat)
; query 465: function gsm_mult_r, block 9, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x2183 ((_ sign_extend 48) in1_16)))
(let ((?x2182 ((_ sign_extend 48) in0_16)))
(let ((?x2307 (bvmul ?x2182 ?x2183)))
(let ((?x2332 (bvadd ?x2307 (_ bv16384 64))))
(let ((?x2339 (bvashr ?x2332 (_ bv15 64))))
(let (($x1321 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x2334 (and (distinct (bvadd ((_ sign_extend 1) ?x2307) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x2332)) true)))
(let (($x2310 (and (distinct (bvmul ((_ sign_extend 64) ?x2182) ((_ sign_extend 64) ?x2183)) ((_ sign_extend 64) ?x2307)) true)))
(let (($x224 (or false false)))
(let (($x2312 (or $x224 $x224 (or $x2310))))
(let (($x2336 (or $x2312 false (or $x2334))))
(let (($x2338 (or (or $x2336 false false) $x1321)))
(and (not $x2338) (or $x2338 (and (distinct ?x2339 ?x2339) true))))))))))))))))
(check-sat)
; query 466: function gsm_mult_r, block 9, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x2183 ((_ sign_extend 48) in1_16)))
(let ((?x2182 ((_ sign_extend 48) in0_16)))
(let ((?x2307 (bvmul ?x2182 ?x2183)))
(let ((?x2332 (bvadd ?x2307 (_ bv16384 64))))
(let ((?x2339 (bvashr ?x2332 (_ bv15 64))))
(let ((?x2341 (bvand ?x2339 (_ bv65535 64))))
(let (($x1321 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x2334 (and (distinct (bvadd ((_ sign_extend 1) ?x2307) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x2332)) true)))
(let (($x2310 (and (distinct (bvmul ((_ sign_extend 64) ?x2182) ((_ sign_extend 64) ?x2183)) ((_ sign_extend 64) ?x2307)) true)))
(let (($x224 (or false false)))
(let (($x2312 (or $x224 $x224 (or $x2310))))
(let (($x2336 (or $x2312 false (or $x2334))))
(let (($x2338 (or (or $x2336 false false) $x1321)))
(let (($x2340 (or $x2338 false false)))
(and (not $x2340) (or $x2340 (and (distinct ?x2341 ?x2341) true))))))))))))))))))
(check-sat)
; query 467: function gsm_mult_r, block 9, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x2183 ((_ sign_extend 48) in1_16)))
(let ((?x2182 ((_ sign_extend 48) in0_16)))
(let ((?x2307 (bvmul ?x2182 ?x2183)))
(let ((?x2332 (bvadd ?x2307 (_ bv16384 64))))
(let ((?x2339 (bvashr ?x2332 (_ bv15 64))))
(let ((?x2341 (bvand ?x2339 (_ bv65535 64))))
(let ((?x2342 ((_ extract 15 0) ?x2341)))
(let (($x1321 (bvuge (_ bv15 64) (_ bv64 64))))
(let (($x2334 (and (distinct (bvadd ((_ sign_extend 1) ?x2307) ((_ sign_extend 1) (_ bv16384 64))) ((_ sign_extend 1) ?x2332)) true)))
(let (($x2310 (and (distinct (bvmul ((_ sign_extend 64) ?x2182) ((_ sign_extend 64) ?x2183)) ((_ sign_extend 64) ?x2307)) true)))
(let (($x224 (or false false)))
(let (($x2312 (or $x224 $x224 (or $x2310))))
(let (($x2336 (or $x2312 false (or $x2334))))
(let (($x2338 (or (or $x2336 false false) $x1321)))
(let (($x2340 (or $x2338 false false)))
(let (($x2343 (or $x2340 false)))
(and (not $x2343) (or $x2343 (and (distinct ?x2342 ?x2342) true))))))))))))))))))))
(check-sat)
; query 468: function gsm_mult_r, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 469: function gsm_mult_r, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x2301 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x41 (not $x73)))
(and $x41 (or $x73 (and (distinct ?x2301 ?x2301) true))))))))
(check-sat)
; query 470: function gsm_norm, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2361 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x2361 ?x2361) true)))))))
(check-sat)
; query 471: function gsm_norm, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2361 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x2362 (bvxor ?x2361 (_ bv1 1))))
(let (($x57 (or false false false)))
(let (($x1145 (or $x57 false false)))
(let (($x485 (not $x1145)))
(and $x485 (or $x1145 (and (distinct ?x2362 ?x2362) true)))))))))
(check-sat)
; query 472: function gsm_norm, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2361 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x2362 (bvxor ?x2361 (_ bv1 1))))
(let ((?x2363 ((_ zero_extend 31) ?x2362)))
(let (($x57 (or false false false)))
(let (($x1145 (or $x57 false false)))
(let (($x2364 (or $x1145 false)))
(and (not $x2364) (or $x2364 (and (distinct ?x2363 ?x2363) true))))))))))
(check-sat)
; query 473: function gsm_norm, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2361 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x2362 (bvxor ?x2361 (_ bv1 1))))
(let ((?x2363 ((_ zero_extend 31) ?x2362)))
(let ((?x2365 ((_ sign_extend 32) ?x2363)))
(let (($x57 (or false false false)))
(let (($x1145 (or $x57 false false)))
(let (($x2364 (or $x1145 false)))
(let (($x2366 (or $x2364 false)))
(and (not $x2366) (or $x2366 (and (distinct ?x2365 ?x2365) true))))))))))))
(check-sat)
; query 474: function gsm_norm, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x2361 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x2362 (bvxor ?x2361 (_ bv1 1))))
(let ((?x2363 ((_ zero_extend 31) ?x2362)))
(let ((?x2365 ((_ sign_extend 32) ?x2363)))
(let ((?x2369 (ite (and (distinct (_ bv0 64) ?x2365) true) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x1145 (or $x57 false false)))
(let (($x2364 (or $x1145 false)))
(let (($x2366 (or $x2364 false)))
(let (($x2368 (or $x2366 false false)))
(and (not $x2368) (or $x2368 (and (distinct ?x2369 ?x2369) true))))))))))))))
(check-sat)
; query 475: function gsm_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in5_64 () (_ BitVec 64))
(assert
 (let ((?x2178 (ite (bvslt (_ bv32767 64) in5_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x2178 ?x2178) true)))))))
(check-sat)
; query 476: function gsm_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 477: function gsm_sub, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 478: function gsm_sub, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x2183 ((_ sign_extend 48) in1_16)))
(let ((?x2182 ((_ sign_extend 48) in0_16)))
(let ((?x2389 (bvsub ?x2182 ?x2183)))
(let (($x2391 (and (distinct (bvsub ((_ sign_extend 1) ?x2182) ((_ sign_extend 1) ?x2183)) ((_ sign_extend 1) ?x2389)) true)))
(let (($x224 (or false false)))
(let (($x2393 (or $x224 $x224 (or $x2391))))
(and (not $x2393) (or $x2393 (and (distinct ?x2389 ?x2389) true))))))))))
(check-sat)
; query 479: function gsm_sub, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x2396 (ite (bvsgt (_ bv18446744073709518848 64) (bvsub ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x2183 ((_ sign_extend 48) in1_16)))
(let ((?x2185 ((_ sign_extend 1) ?x2183)))
(let ((?x2182 ((_ sign_extend 48) in0_16)))
(let ((?x2184 ((_ sign_extend 1) ?x2182)))
(let (($x224 (or false false)))
(let (($x2393 (or $x224 $x224 (or (and (distinct (bvsub ?x2184 ?x2185) ((_ sign_extend 1) (bvsub ?x2182 ?x2183))) true)))))
(let (($x2395 (or $x2393 false false)))
(and (not $x2395) (or $x2395 (and (distinct ?x2396 ?x2396) true))))))))))))
(check-sat)
; query 480: function ok_to_replace, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x2406 (ite (and (distinct (_ bv4294967295 32) in.01_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x2406 ?x2406) true)))))))
(check-sat)
; query 481: function ok_to_replace, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in16_32 () (_ BitVec 32))
(assert
 (let ((?x2412 (ite (= (_ bv121 32) in16_32) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x2412 ?x2412) true)))))))
(check-sat)
; query 482: function process_decode, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 32) in14_32) ((_ sign_extend 32) in14_32)) true))))))
(check-sat)
; query 483: function process_decode, block 16, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x2420 (ite (and (distinct (_ bv33 64) ((_ sign_extend 32) in14_32)) true) (_ bv1 1) (_ bv0 1))))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x41 (not $x73)))
(and $x41 (or $x73 (and (distinct ?x2420 ?x2420) true))))))))
(check-sat)
; query 484: function process_decode, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x2428 (ite (bvsle (_ bv0 32) in14_32) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x2428 ?x2428) true)))))))
(check-sat)
; query 485: function process_decode, block 71, name %72
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x2433 (ite (bvsgt (_ bv0 32) in14_32) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x2433 ?x2433) true)))))))
(check-sat)
; query 486: function process_encode, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_32 () (_ BitVec 32))
(assert
 (let (($x224 (or false false)))
(let (($x744 (not $x224)))
(and $x744 (or $x224 (and (distinct ((_ sign_extend 32) in13_32) ((_ sign_extend 32) in13_32)) true))))))
(check-sat)
; query 487: function process_encode, block 15, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_32 () (_ BitVec 32))
(assert
 (let ((?x2441 (ite (bvult ((_ sign_extend 32) in13_32) (_ bv160 64)) (_ bv1 1) (_ bv0 1))))
(let (($x224 (or false false)))
(let (($x73 (or $x224 false false)))
(let (($x41 (not $x73)))
(and $x41 (or $x73 (and (distinct ?x2441 ?x2441) true))))))))
(check-sat)
; query 488: function process_encode, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_32 () (_ BitVec 32))
(assert
 (let ((?x2449 (ite (bvsgt (_ bv0 32) in13_32) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x2449 ?x2449) true)))))))
(check-sat)
; query 489: function suffix, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_64 () (_ BitVec 64))
(declare-fun in3_64 () (_ BitVec 64))
(assert
 (let ((?x2456 (ite (bvule in3_64 in4_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x2456 ?x2456) true)))))))
(check-sat)
; query 490: function ulaw_input, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x410 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x1004 (or false false (or $x410))))
(and (not $x1004) (or $x1004 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 491: function ulaw_input, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let ((?x1081 (ite (= (_ bv4294967295 32) in.1_32) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x679 (not $x57)))
(and $x679 (or $x57 (and (distinct ?x1081 ?x1081) true)))))))
(check-sat)
