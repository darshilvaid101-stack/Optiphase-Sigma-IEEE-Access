; OptiPhase-Sigma refinement certificate for sweep K09-R1-005
