; OptiPhase-Sigma refinement certificate for sweep K48-R5-402
; query 0: function gsm_L_add, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let (($x356 (and (distinct (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv18446744073709551615 64) in1_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x57 (or false false false)))
(let (($x64 (not $x57)))
(and $x64 (or $x57 $x356))))))
(check-sat)
; query 1: function gsm_L_add, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x720 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvadd in0_64 in1_64))) true)))
(let (($x40 (or false false (or $x720))))
(let (($x1039 (or $x40 (and (distinct (bvadd in0_64 in1_64) (bvadd in0_64 in1_64)) true))))
(and (not $x40) $x1039)))))
(check-sat)
; query 2: function gsm_L_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x37 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false false)))
(let (($x64 (not $x57)))
(and $x64 (or $x57 (and (distinct ?x37 ?x37) true)))))))
(check-sat)
; query 3: function gsm_L_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x45 (and (distinct (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv31 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x57 (or false false false)))
(let (($x64 (not $x57)))
(and $x64 (or $x57 $x45))))))
(check-sat)
; query 4: function gsm_L_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x45 (and (distinct (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv31 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x57 (or false false false)))
(let (($x64 (not $x57)))
(and $x64 (or $x57 $x45))))))
(check-sat)
; query 5: function gsm_L_sub, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let (($x356 (and (distinct (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv18446744073709551615 64) in1_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x57 (or false false false)))
(let (($x64 (not $x57)))
(and $x64 (or $x57 $x356))))))
(check-sat)
; query 6: function gsm_L_sub, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x945 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvsub in0_64 in1_64))) true)))
(let (($x1081 (or false false (or $x945))))
(let (($x1480 (or $x1081 (and (distinct (bvsub in0_64 in1_64) (bvsub in0_64 in1_64)) true))))
(and (not $x1081) $x1480)))))
(check-sat)
; query 7: function gsm_L_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x564 (and (distinct (ite (bvsle (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv18446744073709551615 64) in0_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x57 (or false false false)))
(let (($x64 (not $x57)))
(and $x64 (or $x57 $x564))))))
(check-sat)
; query 8: function gsm_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x1968 (and (distinct (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv15 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x57 (or false false false)))
(let (($x64 (not $x57)))
(and $x64 (or $x57 $x1968))))))
(check-sat)
; query 9: function gsm_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x1968 (and (distinct (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv15 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x57 (or false false false)))
(let (($x64 (not $x57)))
(and $x64 (or $x57 $x1968))))))
(check-sat)
