; OptiPhase-Sigma refinement certificate for sweep K55-R2-009
; query 0: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x164 (or false false)))
(let (($x232 (not $x164)))
(and $x232 (or $x164 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 1: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x233 ((_ sign_extend 16) in3_16)))
(let ((?x172 (bvand ?x233 (_ bv127 32))))
(let (($x164 (or false false)))
(let (($x20 (or $x164 false false)))
(let (($x868 (not $x20)))
(and $x868 (or $x20 (and (distinct ?x172 ?x172) true)))))))))
(check-sat)
; query 2: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x233 ((_ sign_extend 16) in3_16)))
(let ((?x172 (bvand ?x233 (_ bv127 32))))
(let ((?x296 ((_ extract 15 0) ?x172)))
(let (($x164 (or false false)))
(let (($x20 (or $x164 false false)))
(let (($x176 (or $x20 false)))
(let (($x26 (not $x176)))
(and $x26 (or $x176 (and (distinct ?x296 ?x296) true)))))))))))
(check-sat)
; query 3: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x164 (or false false)))
(let (($x232 (not $x164)))
(and $x232 (or $x164 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 4: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x160 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x164 (or false false)))
(let (($x20 (or $x164 false false)))
(let (($x868 (not $x20)))
(and $x868 (or $x20 (and (distinct ?x160 ?x160) true))))))))
(check-sat)
; query 5: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x18 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x228 (or false false false)))
(let (($x70 (not $x228)))
(and $x70 (or $x228 (and (distinct ?x18 ?x18) true)))))))
(check-sat)
; query 6: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x64 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x228 (or false false false)))
(let (($x70 (not $x228)))
(and $x70 (or $x228 (and (distinct ?x64 ?x64) true)))))))
(check-sat)
; query 7: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x228 (or false false false)))
(let (($x70 (not $x228)))
(and $x70 (or $x228 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 8: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x916 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x430 (or false false (or $x916))))
(and (not $x430) (or $x430 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 9: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x68 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x19 ((_ zero_extend 31) ?x68)))
(let ((?x156 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x614 ((_ zero_extend 31) ?x156)))
(let ((?x226 (bvand ?x614 ?x19)))
(let ((?x896 (ite (and (distinct (_ bv0 32) ?x226) true) (_ bv1 1) (_ bv0 1))))
(let ((?x165 ((_ zero_extend 63) ?x896)))
(let (($x164 (or false false)))
(let (($x20 (or $x164 false false)))
(let (($x176 (or $x20 false)))
(let (($x85 (or $x176 $x176 false)))
(let (($x162 (or $x85 false false)))
(let (($x106 (or $x162 false)))
(and (not $x106) (or $x106 (and (distinct ?x165 ?x165) true)))))))))))))))))
(check-sat)
; query 10: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x68 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x19 ((_ zero_extend 31) ?x68)))
(let ((?x156 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x614 ((_ zero_extend 31) ?x156)))
(let ((?x226 (bvand ?x614 ?x19)))
(let ((?x896 (ite (and (distinct (_ bv0 32) ?x226) true) (_ bv1 1) (_ bv0 1))))
(let (($x772 (= (_ bv1 1) ?x896)))
(let ((?x200 (ite $x772 (_ bv1 32) (_ bv0 32))))
(let (($x164 (or false false)))
(let (($x20 (or $x164 false false)))
(let (($x176 (or $x20 false)))
(let (($x85 (or $x176 $x176 false)))
(let (($x162 (or $x85 false false)))
(let (($x137 (or $x162 (ite $x772 false false))))
(and (not $x137) (or $x137 (and (distinct ?x200 ?x200) true))))))))))))))))))
(check-sat)
; query 11: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x68 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x19 ((_ zero_extend 31) ?x68)))
(let ((?x156 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x614 ((_ zero_extend 31) ?x156)))
(let ((?x226 (bvand ?x614 ?x19)))
(let ((?x896 (ite (and (distinct (_ bv0 32) ?x226) true) (_ bv1 1) (_ bv0 1))))
(let (($x772 (= (_ bv1 1) ?x896)))
(let ((?x200 (ite $x772 (_ bv1 32) (_ bv0 32))))
(let ((?x34 ((_ extract 7 0) ?x200)))
(let (($x164 (or false false)))
(let (($x20 (or $x164 false false)))
(let (($x176 (or $x20 false)))
(let (($x85 (or $x176 $x176 false)))
(let (($x162 (or $x85 false false)))
(let (($x137 (or $x162 (ite $x772 false false))))
(let (($x410 (or $x137 false)))
(and (not $x410) (or $x410 (and (distinct ?x34 ?x34) true))))))))))))))))))))
(check-sat)
; query 12: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x164 (or false false)))
(let (($x232 (not $x164)))
(and $x232 (or $x164 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 13: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x156 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x164 (or false false)))
(let (($x20 (or $x164 false false)))
(let (($x868 (not $x20)))
(and $x868 (or $x20 (and (distinct ?x156 ?x156) true))))))))
(check-sat)
; query 14: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x156 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x614 ((_ zero_extend 31) ?x156)))
(let (($x164 (or false false)))
(let (($x20 (or $x164 false false)))
(let (($x176 (or $x20 false)))
(let (($x26 (not $x176)))
(and $x26 (or $x176 (and (distinct ?x614 ?x614) true))))))))))
(check-sat)
; query 15: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x164 (or false false)))
(let (($x232 (not $x164)))
(and $x232 (or $x164 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 16: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x68 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x164 (or false false)))
(let (($x20 (or $x164 false false)))
(let (($x868 (not $x20)))
(and $x868 (or $x20 (and (distinct ?x68 ?x68) true))))))))
(check-sat)
; query 17: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x68 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x19 ((_ zero_extend 31) ?x68)))
(let (($x164 (or false false)))
(let (($x20 (or $x164 false false)))
(let (($x176 (or $x20 false)))
(let (($x26 (not $x176)))
(and $x26 (or $x176 (and (distinct ?x19 ?x19) true))))))))))
(check-sat)
; query 18: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x68 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x19 ((_ zero_extend 31) ?x68)))
(let ((?x156 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x614 ((_ zero_extend 31) ?x156)))
(let ((?x226 (bvand ?x614 ?x19)))
(let (($x164 (or false false)))
(let (($x20 (or $x164 false false)))
(let (($x176 (or $x20 false)))
(let (($x85 (or $x176 $x176 false)))
(and (not $x85) (or $x85 (and (distinct ?x226 ?x226) true)))))))))))))
(check-sat)
; query 19: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x68 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x19 ((_ zero_extend 31) ?x68)))
(let ((?x156 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x614 ((_ zero_extend 31) ?x156)))
(let ((?x226 (bvand ?x614 ?x19)))
(let ((?x896 (ite (and (distinct (_ bv0 32) ?x226) true) (_ bv1 1) (_ bv0 1))))
(let (($x164 (or false false)))
(let (($x20 (or $x164 false false)))
(let (($x176 (or $x20 false)))
(let (($x85 (or $x176 $x176 false)))
(let (($x162 (or $x85 false false)))
(and (not $x162) (or $x162 (and (distinct ?x896 ?x896) true)))))))))))))))
(check-sat)
; query 20: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x159 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x228 (or false false false)))
(let (($x70 (not $x228)))
(and $x70 (or $x228 (and (distinct ?x159 ?x159) true)))))))
(check-sat)
