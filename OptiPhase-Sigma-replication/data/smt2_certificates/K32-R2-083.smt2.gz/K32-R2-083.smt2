; OptiPhase-Sigma refinement certificate for sweep K32-R2-083
; query 0: function compare, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in7_32 () (_ BitVec 32))
(assert
 (let ((?x224 (ite (= (_ bv0 32) in7_32) (_ bv1 1) (_ bv0 1))))
(let (($x117 (or false false false)))
(let (($x316 (not $x117)))
(and $x316 (or $x117 (and (distinct ?x224 ?x224) true)))))))
(check-sat)
; query 1: function compare, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in7_32 () (_ BitVec 32))
(assert
 (let ((?x224 (ite (= (_ bv0 32) in7_32) (_ bv1 1) (_ bv0 1))))
(let ((?x197 ((_ zero_extend 63) ?x224)))
(let (($x117 (or false false false)))
(let (($x104 (or $x117 false)))
(and (not $x104) (or $x104 (and (distinct ?x197 ?x197) true))))))))
(check-sat)
; query 2: function compare, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in7_32 () (_ BitVec 32))
(assert
 (let ((?x224 (ite (= (_ bv0 32) in7_32) (_ bv1 1) (_ bv0 1))))
(let (($x131 (= (_ bv1 1) ?x224)))
(let ((?x55 (ite $x131 (_ bv0 32) (_ bv4294967295 32))))
(let (($x117 (or false false false)))
(let (($x249 (or $x117 (ite $x131 false false))))
(and (not $x249) (or $x249 (and (distinct ?x55 ?x55) true)))))))))
(check-sat)
; query 3: function main, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x13 (ite (bvsgt (_ bv60000 32) in.0_32) (_ bv1 1) (_ bv0 1))))
(let (($x117 (or false false false)))
(let (($x316 (not $x117)))
(and $x316 (or $x117 (and (distinct ?x13 ?x13) true)))))))
(check-sat)
; query 4: function main, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x191 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x95 (or false false (or $x191))))
(and (not $x95) (or $x95 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 5: function main, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x50 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x72 (or false false (or $x50))))
(and (not $x72) (or $x72 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
