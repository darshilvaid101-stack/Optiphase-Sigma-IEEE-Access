; OptiPhase-Sigma refinement certificate for sweep K38-R2-086
; query 0: function BF_cbc_encrypt, block 126, name %127
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.010_64 () (_ BitVec 64))
(assert
 (let (($x344 (and (distinct (bvsub ((_ sign_extend 1) in.010_64) ((_ sign_extend 1) (_ bv8 64))) ((_ sign_extend 1) (bvsub in.010_64 (_ bv8 64)))) true)))
(let (($x503 (or false false (or $x344))))
(and (not $x503) (or $x503 (and (distinct (bvsub in.010_64 (_ bv8 64)) (bvsub in.010_64 (_ bv8 64))) true))))))
(check-sat)
; query 1: function BF_cbc_encrypt, block 366, name %367
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.111_64 () (_ BitVec 64))
(assert
 (let (($x246 (and (distinct (bvsub ((_ sign_extend 1) in.111_64) ((_ sign_extend 1) (_ bv8 64))) ((_ sign_extend 1) (bvsub in.111_64 (_ bv8 64)))) true)))
(let (($x64 (or false false (or $x246))))
(and (not $x64) (or $x64 (and (distinct (bvsub in.111_64 (_ bv8 64)) (bvsub in.111_64 (_ bv8 64))) true))))))
(check-sat)
; query 2: function BF_cfb64_encrypt, block 111, name %112
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.18_32 () (_ BitVec 32))
(assert
 (let ((?x119 (ite (= (_ bv0 32) in.18_32) (_ bv1 1) (_ bv0 1))))
(let (($x569 (or false false false)))
(let (($x554 (not $x569)))
(and $x554 (or $x569 (and (distinct ?x119 ?x119) true)))))))
(check-sat)
; query 3: function BF_cfb64_encrypt, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.07_32 () (_ BitVec 32))
(assert
 (let ((?x110 (ite (= (_ bv0 32) in.07_32) (_ bv1 1) (_ bv0 1))))
(let (($x569 (or false false false)))
(let (($x554 (not $x569)))
(and $x554 (or $x569 (and (distinct ?x110 ?x110) true)))))))
(check-sat)
; query 4: function BF_ofb64_encrypt, block 82, name %83
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x74 (ite (= (_ bv0 32) in.04_32) (_ bv1 1) (_ bv0 1))))
(let (($x569 (or false false false)))
(let (($x554 (not $x569)))
(and $x554 (or $x569 (and (distinct ?x74 ?x74) true)))))))
(check-sat)
; query 5: function BF_set_key, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x96 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x583 (or false false (or $x96))))
(and (not $x583) (or $x583 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 6: function BF_set_key, block 69, name %70
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.13_32 () (_ BitVec 32))
(assert
 (let (($x242 (and (distinct (bvadd ((_ sign_extend 1) in.13_32) ((_ sign_extend 1) (_ bv2 32))) ((_ sign_extend 1) (bvadd in.13_32 (_ bv2 32)))) true)))
(let (($x18 (or false false (or $x242))))
(and (not $x18) (or $x18 (and (distinct (bvadd in.13_32 (_ bv2 32)) (bvadd in.13_32 (_ bv2 32))) true))))))
(check-sat)
; query 7: function BF_set_key, block 87, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.24_32 () (_ BitVec 32))
(assert
 (let (($x162 (and (distinct (bvadd ((_ sign_extend 1) in.24_32) ((_ sign_extend 1) (_ bv2 32))) ((_ sign_extend 1) (bvadd in.24_32 (_ bv2 32)))) true)))
(let (($x6 (or false false (or $x162))))
(and (not $x6) (or $x6 (and (distinct (bvadd in.24_32 (_ bv2 32)) (bvadd in.24_32 (_ bv2 32))) true))))))
(check-sat)
; query 8: function main, block 124, name %125
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let ((?x56 (ite (bvsgt (_ bv40 32) in.2_32) (_ bv1 1) (_ bv0 1))))
(let (($x569 (or false false false)))
(let (($x554 (not $x569)))
(and $x554 (or $x569 (and (distinct ?x56 ?x56) true)))))))
(check-sat)
; query 9: function main, block 147, name %148
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x130 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x321 (or false false (or $x130))))
(and (not $x321) (or $x321 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 10: function main, block 60, name %61
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x534 (or false false)))
(and (not $x534) (or $x534 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 11: function main, block 60, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x98 (ite (bvsge (_ bv57 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x534 (or false false)))
(let (($x265 (or $x534 false false)))
(let (($x65 (not $x265)))
(and $x65 (or $x265 (and (distinct ?x98 ?x98) true))))))))
(check-sat)
; query 12: function main, block 63, name %64
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x569 (or false false false)))
(let (($x121 (or $x569 (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x121) (or $x121 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvshl in.01_32 (_ bv4 32))) true))))))
(check-sat)
; query 13: function main, block 63, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x534 (or false false)))
(and (not $x534) (or $x534 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 14: function main, block 63, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x75 ((_ sign_extend 24) in57_8)))
(let ((?x287 (bvshl in.01_32 (_ bv4 32))))
(let ((?x163 (bvadd ?x287 ?x75)))
(let ((?x129 ((_ sign_extend 1) ?x163)))
(let (($x534 (or false false)))
(let (($x569 (or false false false)))
(let (($x121 (or $x569 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x312 (or $x121 $x534 (or (and (distinct (bvadd ((_ sign_extend 1) ?x287) ((_ sign_extend 1) ?x75)) ?x129) true)))))
(and (not $x312) (or $x312 (and (distinct ?x163 ?x163) true))))))))))))
(check-sat)
; query 15: function main, block 63, name %67
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x75 ((_ sign_extend 24) in57_8)))
(let ((?x287 (bvshl in.01_32 (_ bv4 32))))
(let ((?x163 (bvadd ?x287 ?x75)))
(let ((?x319 (bvsub ?x163 (_ bv48 32))))
(let (($x21 (and (distinct (bvsub ((_ sign_extend 1) ?x163) ((_ sign_extend 1) (_ bv48 32))) ((_ sign_extend 1) ?x319)) true)))
(let ((?x129 ((_ sign_extend 1) ?x163)))
(let (($x534 (or false false)))
(let (($x569 (or false false false)))
(let (($x121 (or $x569 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x312 (or $x121 $x534 (or (and (distinct (bvadd ((_ sign_extend 1) ?x287) ((_ sign_extend 1) ?x75)) ?x129) true)))))
(let (($x37 (or $x312 false (or $x21))))
(and (not $x37) (or $x37 (and (distinct ?x319 ?x319) true)))))))))))))))
(check-sat)
; query 16: function main, block 68, name %69
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x534 (or false false)))
(and (not $x534) (or $x534 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 17: function main, block 68, name %70
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x1529 (ite (bvsle (_ bv65 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x534 (or false false)))
(let (($x265 (or $x534 false false)))
(let (($x65 (not $x265)))
(and $x65 (or $x265 (and (distinct ?x1529 ?x1529) true))))))))
(check-sat)
; query 18: function main, block 71, name %72
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x534 (or false false)))
(and (not $x534) (or $x534 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 19: function main, block 71, name %73
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x973 (ite (bvsge (_ bv70 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x534 (or false false)))
(let (($x265 (or $x534 false false)))
(let (($x65 (not $x265)))
(and $x65 (or $x265 (and (distinct ?x973 ?x973) true))))))))
(check-sat)
; query 20: function main, block 74, name %75
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x569 (or false false false)))
(let (($x121 (or $x569 (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x121) (or $x121 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvshl in.01_32 (_ bv4 32))) true))))))
(check-sat)
; query 21: function main, block 74, name %76
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x534 (or false false)))
(and (not $x534) (or $x534 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 22: function main, block 74, name %77
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x75 ((_ sign_extend 24) in57_8)))
(let ((?x287 (bvshl in.01_32 (_ bv4 32))))
(let ((?x163 (bvadd ?x287 ?x75)))
(let ((?x129 ((_ sign_extend 1) ?x163)))
(let (($x534 (or false false)))
(let (($x569 (or false false false)))
(let (($x121 (or $x569 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x312 (or $x121 $x534 (or (and (distinct (bvadd ((_ sign_extend 1) ?x287) ((_ sign_extend 1) ?x75)) ?x129) true)))))
(and (not $x312) (or $x312 (and (distinct ?x163 ?x163) true))))))))))))
(check-sat)
; query 23: function main, block 74, name %78
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x75 ((_ sign_extend 24) in57_8)))
(let ((?x287 (bvshl in.01_32 (_ bv4 32))))
(let ((?x163 (bvadd ?x287 ?x75)))
(let ((?x314 (bvsub ?x163 (_ bv65 32))))
(let ((?x1134 ((_ sign_extend 1) ?x314)))
(let ((?x129 ((_ sign_extend 1) ?x163)))
(let (($x534 (or false false)))
(let (($x569 (or false false false)))
(let (($x121 (or $x569 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x312 (or $x121 $x534 (or (and (distinct (bvadd ((_ sign_extend 1) ?x287) ((_ sign_extend 1) ?x75)) ?x129) true)))))
(let (($x765 (or $x312 false (or (and (distinct (bvsub ?x129 ((_ sign_extend 1) (_ bv65 32))) ?x1134) true)))))
(and (not $x765) (or $x765 (and (distinct ?x314 ?x314) true)))))))))))))))
(check-sat)
; query 24: function main, block 74, name %79
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x75 ((_ sign_extend 24) in57_8)))
(let ((?x287 (bvshl in.01_32 (_ bv4 32))))
(let ((?x163 (bvadd ?x287 ?x75)))
(let ((?x314 (bvsub ?x163 (_ bv65 32))))
(let ((?x1598 (bvadd ?x314 (_ bv10 32))))
(let (($x205 (and (distinct (bvadd ((_ sign_extend 1) ?x314) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x1598)) true)))
(let ((?x1134 ((_ sign_extend 1) ?x314)))
(let ((?x129 ((_ sign_extend 1) ?x163)))
(let (($x534 (or false false)))
(let (($x569 (or false false false)))
(let (($x121 (or $x569 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x312 (or $x121 $x534 (or (and (distinct (bvadd ((_ sign_extend 1) ?x287) ((_ sign_extend 1) ?x75)) ?x129) true)))))
(let (($x765 (or $x312 false (or (and (distinct (bvsub ?x129 ((_ sign_extend 1) (_ bv65 32))) ?x1134) true)))))
(let (($x1541 (or $x765 false (or $x205))))
(and (not $x1541) (or $x1541 (and (distinct ?x1598 ?x1598) true))))))))))))))))))
(check-sat)
