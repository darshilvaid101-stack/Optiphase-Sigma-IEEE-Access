; OptiPhase-Sigma refinement certificate for sweep K18-R4-367
