; OptiPhase-Sigma refinement certificate for sweep K36-R6-023
