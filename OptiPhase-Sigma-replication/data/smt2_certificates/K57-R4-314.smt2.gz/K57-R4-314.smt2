; OptiPhase-Sigma refinement certificate for sweep K57-R4-314
; query 0: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x85 (or false false)))
(let (($x3322 (not $x85)))
(and $x3322 (or $x85 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 1: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x333 ((_ sign_extend 16) in3_16)))
(let ((?x21 (bvand ?x333 (_ bv127 32))))
(let (($x85 (or false false)))
(let (($x502 (or $x85 false false)))
(let (($x83 (not $x502)))
(and $x83 (or $x502 (and (distinct ?x21 ?x21) true)))))))))
(check-sat)
; query 2: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x333 ((_ sign_extend 16) in3_16)))
(let ((?x21 (bvand ?x333 (_ bv127 32))))
(let ((?x122 ((_ extract 15 0) ?x21)))
(let (($x85 (or false false)))
(let (($x502 (or $x85 false false)))
(let (($x521 (or $x502 false)))
(let (($x286 (not $x521)))
(and $x286 (or $x521 (and (distinct ?x122 ?x122) true)))))))))))
(check-sat)
; query 3: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x85 (or false false)))
(let (($x3322 (not $x85)))
(and $x3322 (or $x85 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 4: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x5705 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x85 (or false false)))
(let (($x502 (or $x85 false false)))
(let (($x83 (not $x502)))
(and $x83 (or $x502 (and (distinct ?x5705 ?x5705) true))))))))
(check-sat)
; query 5: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x383 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x172 (or false false false)))
(let (($x1874 (not $x172)))
(and $x1874 (or $x172 (and (distinct ?x383 ?x383) true)))))))
(check-sat)
; query 6: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x621 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x172 (or false false false)))
(let (($x1874 (not $x172)))
(and $x1874 (or $x172 (and (distinct ?x621 ?x621) true)))))))
(check-sat)
; query 7: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x172 (or false false false)))
(let (($x1874 (not $x172)))
(and $x1874 (or $x172 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 8: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x71 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x636 (or false false (or $x71))))
(and (not $x636) (or $x636 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 9: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x308 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x3177 ((_ zero_extend 31) ?x308)))
(let ((?x232 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x243 ((_ zero_extend 31) ?x232)))
(let ((?x76 (bvand ?x243 ?x3177)))
(let ((?x370 (ite (and (distinct (_ bv0 32) ?x76) true) (_ bv1 1) (_ bv0 1))))
(let ((?x613 ((_ zero_extend 63) ?x370)))
(let (($x85 (or false false)))
(let (($x502 (or $x85 false false)))
(let (($x521 (or $x502 false)))
(let (($x54 (or $x521 $x521 false)))
(let (($x507 (or $x54 false false)))
(let (($x108 (or $x507 false)))
(and (not $x108) (or $x108 (and (distinct ?x613 ?x613) true)))))))))))))))))
(check-sat)
; query 10: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x308 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x3177 ((_ zero_extend 31) ?x308)))
(let ((?x232 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x243 ((_ zero_extend 31) ?x232)))
(let ((?x76 (bvand ?x243 ?x3177)))
(let ((?x370 (ite (and (distinct (_ bv0 32) ?x76) true) (_ bv1 1) (_ bv0 1))))
(let (($x1933 (= (_ bv1 1) ?x370)))
(let ((?x125 (ite $x1933 (_ bv1 32) (_ bv0 32))))
(let (($x85 (or false false)))
(let (($x502 (or $x85 false false)))
(let (($x521 (or $x502 false)))
(let (($x54 (or $x521 $x521 false)))
(let (($x507 (or $x54 false false)))
(let (($x331 (or $x507 (ite $x1933 false false))))
(and (not $x331) (or $x331 (and (distinct ?x125 ?x125) true))))))))))))))))))
(check-sat)
; query 11: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x308 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x3177 ((_ zero_extend 31) ?x308)))
(let ((?x232 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x243 ((_ zero_extend 31) ?x232)))
(let ((?x76 (bvand ?x243 ?x3177)))
(let ((?x370 (ite (and (distinct (_ bv0 32) ?x76) true) (_ bv1 1) (_ bv0 1))))
(let (($x1933 (= (_ bv1 1) ?x370)))
(let ((?x125 (ite $x1933 (_ bv1 32) (_ bv0 32))))
(let ((?x151 ((_ extract 7 0) ?x125)))
(let (($x85 (or false false)))
(let (($x502 (or $x85 false false)))
(let (($x521 (or $x502 false)))
(let (($x54 (or $x521 $x521 false)))
(let (($x507 (or $x54 false false)))
(let (($x331 (or $x507 (ite $x1933 false false))))
(let (($x97 (or $x331 false)))
(and (not $x97) (or $x97 (and (distinct ?x151 ?x151) true))))))))))))))))))))
(check-sat)
; query 12: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x85 (or false false)))
(let (($x3322 (not $x85)))
(and $x3322 (or $x85 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 13: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x232 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x85 (or false false)))
(let (($x502 (or $x85 false false)))
(let (($x83 (not $x502)))
(and $x83 (or $x502 (and (distinct ?x232 ?x232) true))))))))
(check-sat)
; query 14: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x232 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x243 ((_ zero_extend 31) ?x232)))
(let (($x85 (or false false)))
(let (($x502 (or $x85 false false)))
(let (($x521 (or $x502 false)))
(let (($x286 (not $x521)))
(and $x286 (or $x521 (and (distinct ?x243 ?x243) true))))))))))
(check-sat)
; query 15: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x85 (or false false)))
(let (($x3322 (not $x85)))
(and $x3322 (or $x85 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 16: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x308 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x85 (or false false)))
(let (($x502 (or $x85 false false)))
(let (($x83 (not $x502)))
(and $x83 (or $x502 (and (distinct ?x308 ?x308) true))))))))
(check-sat)
; query 17: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x308 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x3177 ((_ zero_extend 31) ?x308)))
(let (($x85 (or false false)))
(let (($x502 (or $x85 false false)))
(let (($x521 (or $x502 false)))
(let (($x286 (not $x521)))
(and $x286 (or $x521 (and (distinct ?x3177 ?x3177) true))))))))))
(check-sat)
; query 18: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x308 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x3177 ((_ zero_extend 31) ?x308)))
(let ((?x232 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x243 ((_ zero_extend 31) ?x232)))
(let ((?x76 (bvand ?x243 ?x3177)))
(let (($x85 (or false false)))
(let (($x502 (or $x85 false false)))
(let (($x521 (or $x502 false)))
(let (($x54 (or $x521 $x521 false)))
(and (not $x54) (or $x54 (and (distinct ?x76 ?x76) true)))))))))))))
(check-sat)
; query 19: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x308 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x3177 ((_ zero_extend 31) ?x308)))
(let ((?x232 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x243 ((_ zero_extend 31) ?x232)))
(let ((?x76 (bvand ?x243 ?x3177)))
(let ((?x370 (ite (and (distinct (_ bv0 32) ?x76) true) (_ bv1 1) (_ bv0 1))))
(let (($x85 (or false false)))
(let (($x502 (or $x85 false false)))
(let (($x521 (or $x502 false)))
(let (($x54 (or $x521 $x521 false)))
(let (($x507 (or $x54 false false)))
(and (not $x507) (or $x507 (and (distinct ?x370 ?x370) true)))))))))))))))
(check-sat)
; query 20: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x408 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x172 (or false false false)))
(let (($x1874 (not $x172)))
(and $x1874 (or $x172 (and (distinct ?x408 ?x408) true)))))))
(check-sat)
