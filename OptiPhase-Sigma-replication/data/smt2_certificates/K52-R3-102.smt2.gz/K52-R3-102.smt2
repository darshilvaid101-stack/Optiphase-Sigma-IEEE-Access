; OptiPhase-Sigma refinement certificate for sweep K52-R3-102
; query 0: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x746 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x452 (or false false false)))
(and (not $x452) (or $x452 (and (distinct ?x746 ?x746) true))))))
(check-sat)
