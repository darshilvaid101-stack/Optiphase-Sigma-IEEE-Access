; OptiPhase-Sigma refinement certificate for sweep K58-R4-307
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x1125 (or false false)))
(let (($x977 (not $x1125)))
(and $x977 (or $x1125 (and (distinct ((_ sign_extend 16) in25_16) ((_ sign_extend 16) in25_16)) true))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let ((?x409 (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))))
(let (($x1125 (or false false)))
(let (($x17 (or $x1125 false false)))
(let (($x135 (not $x17)))
(and $x135 (or $x17 (and (distinct ?x409 ?x409) true))))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x1125 (or false false)))
(let (($x977 (not $x1125)))
(and $x977 (or $x1125 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x854 ((_ sign_extend 16) in3_16)))
(let ((?x291 (bvand ?x854 (_ bv127 32))))
(let (($x1125 (or false false)))
(let (($x17 (or $x1125 false false)))
(let (($x135 (not $x17)))
(and $x135 (or $x17 (and (distinct ?x291 ?x291) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x854 ((_ sign_extend 16) in3_16)))
(let ((?x291 (bvand ?x854 (_ bv127 32))))
(let ((?x99 ((_ extract 15 0) ?x291)))
(let (($x1125 (or false false)))
(let (($x17 (or $x1125 false false)))
(let (($x251 (or $x17 false)))
(let (($x669 (not $x251)))
(and $x669 (or $x251 (and (distinct ?x99 ?x99) true)))))))))))
(check-sat)
; query 5: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x1125 (or false false)))
(let (($x977 (not $x1125)))
(and $x977 (or $x1125 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 6: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x1042 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x1125 (or false false)))
(let (($x17 (or $x1125 false false)))
(let (($x135 (not $x17)))
(and $x135 (or $x17 (and (distinct ?x1042 ?x1042) true))))))))
(check-sat)
; query 7: function core_bench_list, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x140 (or false false false)))
(let (($x928 (not $x140)))
(and $x928 (or $x140 (and (distinct (bvadd in.0_16 (_ bv1 16)) (bvadd in.0_16 (_ bv1 16))) true))))))
(check-sat)
; query 8: function core_bench_state, block 105, name %106
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x140 (or false false false)))
(let (($x928 (not $x140)))
(and $x928 (or $x140 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 9: function core_bench_state, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x140 (or false false false)))
(let (($x928 (not $x140)))
(and $x928 (or $x140 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 10: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x257 (bvadd in.01_32 (_ bv1 32))))
(let (($x1034 (and (distinct ?x257 ?x257) true)))
(let (($x140 (or false false false)))
(let (($x928 (not $x140)))
(and $x928 (or $x140 $x1034)))))))
(check-sat)
; query 11: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x257 (bvadd in.01_32 (_ bv1 32))))
(let ((?x211 (bvmul ?x257 ?x257)))
(let (($x140 (or false false false)))
(let (($x45 (or $x140 $x140 false)))
(and (not $x45) (or $x45 (and (distinct ?x211 ?x211) true))))))))
(check-sat)
; query 12: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x257 (bvadd in.01_32 (_ bv1 32))))
(let ((?x211 (bvmul ?x257 ?x257)))
(let ((?x860 (bvmul ?x211 (_ bv2 32))))
(let (($x140 (or false false false)))
(let (($x45 (or $x140 $x140 false)))
(let (($x273 (or $x45 false false)))
(and (not $x273) (or $x273 (and (distinct ?x860 ?x860) true))))))))))
(check-sat)
; query 13: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x257 (bvadd in.01_32 (_ bv1 32))))
(let ((?x211 (bvmul ?x257 ?x257)))
(let ((?x860 (bvmul ?x211 (_ bv2 32))))
(let ((?x98 (bvmul ?x860 (_ bv4 32))))
(let (($x140 (or false false false)))
(let (($x45 (or $x140 $x140 false)))
(let (($x273 (or $x45 false false)))
(let (($x69 (or $x273 false false)))
(and (not $x69) (or $x69 (and (distinct ?x98 ?x98) true))))))))))))
(check-sat)
; query 14: function core_init_matrix, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x140 (or false false false)))
(let (($x928 (not $x140)))
(and $x928 (or $x140 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 15: function core_init_matrix, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x140 (or false false false)))
(let (($x928 (not $x140)))
(and $x928 (or $x140 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 16: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x157 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x140 (or false false false)))
(let (($x928 (not $x140)))
(and $x928 (or $x140 (and (distinct ?x157 ?x157) true)))))))
(check-sat)
; query 17: function core_init_state, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_32 () (_ BitVec 32))
(assert
 (let (($x140 (or false false false)))
(let (($x928 (not $x140)))
(and $x928 (or $x140 (and (distinct (bvadd in.06_32 (_ bv1 32)) (bvadd in.06_32 (_ bv1 32))) true))))))
(check-sat)
; query 18: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x48 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x140 (or false false false)))
(let (($x928 (not $x140)))
(and $x928 (or $x140 (and (distinct ?x48 ?x48) true)))))))
(check-sat)
; query 19: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x140 (or false false false)))
(let (($x928 (not $x140)))
(and $x928 (or $x140 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 20: function core_list_init, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x257 (bvadd in.01_32 (_ bv1 32))))
(let (($x1034 (and (distinct ?x257 ?x257) true)))
(let (($x140 (or false false false)))
(let (($x928 (not $x140)))
(and $x928 (or $x140 $x1034)))))))
(check-sat)
; query 21: function core_list_mergesort, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x257 (bvadd in.01_32 (_ bv1 32))))
(let (($x1034 (and (distinct ?x257 ?x257) true)))
(let (($x9 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x257)) true)))
(let (($x29 (or false false (or $x9))))
(and (not $x29) (or $x29 $x1034)))))))
(check-sat)
; query 22: function core_list_mergesort, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x347 (ite (bvslt (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x140 (or false false false)))
(let (($x928 (not $x140)))
(and $x928 (or $x140 (and (distinct ?x347 ?x347) true)))))))
(check-sat)
; query 23: function core_list_mergesort, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.224_32 () (_ BitVec 32))
(assert
 (let ((?x74 (ite (= (_ bv0 32) in.224_32) (_ bv1 1) (_ bv0 1))))
(let (($x140 (or false false false)))
(let (($x928 (not $x140)))
(and $x928 (or $x140 (and (distinct ?x74 ?x74) true)))))))
(check-sat)
; query 24: function core_list_mergesort, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x458 (ite (= (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x140 (or false false false)))
(let (($x928 (not $x140)))
(and $x928 (or $x140 (and (distinct ?x458 ?x458) true)))))))
(check-sat)
; query 25: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x360 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x380 (or false false (or $x360))))
(and (not $x380) (or $x380 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 26: function core_list_mergesort, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x444 (and (distinct (bvmul ((_ sign_extend 32) in.020_32) ((_ sign_extend 32) (_ bv2 32))) ((_ sign_extend 32) (bvmul in.020_32 (_ bv2 32)))) true)))
(let (($x724 (or false false (or $x444))))
(and (not $x724) (or $x724 (and (distinct (bvmul in.020_32 (_ bv2 32)) (bvmul in.020_32 (_ bv2 32))) true))))))
(check-sat)
; query 27: function core_state_transition, block 102, name %103
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1125 (or false false)))
(let (($x977 (not $x1125)))
(and $x977 (or $x1125 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 28: function core_state_transition, block 102, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x158 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1125 (or false false)))
(let (($x17 (or $x1125 false false)))
(let (($x135 (not $x17)))
(and $x135 (or $x17 (and (distinct ?x158 ?x158) true))))))))
(check-sat)
; query 29: function core_state_transition, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1125 (or false false)))
(let (($x977 (not $x1125)))
(and $x977 (or $x1125 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 30: function core_state_transition, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x880 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1125 (or false false)))
(let (($x17 (or $x1125 false false)))
(let (($x135 (not $x17)))
(and $x135 (or $x17 (and (distinct ?x880 ?x880) true))))))))
(check-sat)
; query 31: function core_state_transition, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1125 (or false false)))
(let (($x977 (not $x1125)))
(and $x977 (or $x1125 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 32: function core_state_transition, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x158 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1125 (or false false)))
(let (($x17 (or $x1125 false false)))
(let (($x135 (not $x17)))
(and $x135 (or $x17 (and (distinct ?x158 ?x158) true))))))))
(check-sat)
; query 33: function core_state_transition, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1125 (or false false)))
(let (($x977 (not $x1125)))
(and $x977 (or $x1125 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 34: function core_state_transition, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x208 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1125 (or false false)))
(let (($x17 (or $x1125 false false)))
(let (($x135 (not $x17)))
(and $x135 (or $x17 (and (distinct ?x208 ?x208) true))))))))
(check-sat)
; query 35: function core_state_transition, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1125 (or false false)))
(let (($x977 (not $x1125)))
(and $x977 (or $x1125 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 36: function core_state_transition, block 51, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x208 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1125 (or false false)))
(let (($x17 (or $x1125 false false)))
(let (($x135 (not $x17)))
(and $x135 (or $x17 (and (distinct ?x208 ?x208) true))))))))
(check-sat)
; query 37: function core_state_transition, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1125 (or false false)))
(let (($x977 (not $x1125)))
(and $x977 (or $x1125 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 38: function core_state_transition, block 64, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x208 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1125 (or false false)))
(let (($x17 (or $x1125 false false)))
(let (($x135 (not $x17)))
(and $x135 (or $x17 (and (distinct ?x208 ?x208) true))))))))
(check-sat)
; query 39: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x286 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x140 (or false false false)))
(let (($x928 (not $x140)))
(and $x928 (or $x140 (and (distinct ?x286 ?x286) true)))))))
(check-sat)
; query 40: function core_state_transition, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1125 (or false false)))
(let (($x977 (not $x1125)))
(and $x977 (or $x1125 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 41: function core_state_transition, block 80, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x149 (ite (= (_ bv69 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1125 (or false false)))
(let (($x17 (or $x1125 false false)))
(let (($x135 (not $x17)))
(and $x135 (or $x17 (and (distinct ?x149 ?x149) true))))))))
(check-sat)
; query 42: function core_state_transition, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1125 (or false false)))
(let (($x977 (not $x1125)))
(and $x977 (or $x1125 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 43: function core_state_transition, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1151 (ite (= (_ bv101 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1125 (or false false)))
(let (($x17 (or $x1125 false false)))
(let (($x135 (not $x17)))
(and $x135 (or $x17 (and (distinct ?x1151 ?x1151) true))))))))
(check-sat)
; query 44: function core_state_transition, block 99, name %100
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x1125 (or false false)))
(let (($x977 (not $x1125)))
(and $x977 (or $x1125 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 45: function core_state_transition, block 99, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x880 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1125 (or false false)))
(let (($x17 (or $x1125 false false)))
(let (($x135 (not $x17)))
(and $x135 (or $x17 (and (distinct ?x880 ?x880) true))))))))
(check-sat)
; query 46: function crcu8, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x1125 (or false false)))
(let (($x977 (not $x1125)))
(and $x977 (or $x1125 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 47: function crcu8, block 19, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x628 ((_ zero_extend 16) in.01_16)))
(let ((?x432 (bvxor ?x628 (_ bv16386 32))))
(let (($x1125 (or false false)))
(let (($x17 (or $x1125 false false)))
(let (($x135 (not $x17)))
(and $x135 (or $x17 (and (distinct ?x432 ?x432) true)))))))))
(check-sat)
; query 48: function crcu8, block 19, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x628 ((_ zero_extend 16) in.01_16)))
(let ((?x432 (bvxor ?x628 (_ bv16386 32))))
(let ((?x1179 ((_ extract 15 0) ?x432)))
(let (($x1125 (or false false)))
(let (($x17 (or $x1125 false false)))
(let (($x251 (or $x17 false)))
(let (($x669 (not $x251)))
(and $x669 (or $x251 (and (distinct ?x1179 ?x1179) true)))))))))))
(check-sat)
; query 49: function crcu8, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x1125 (or false false)))
(let (($x977 (not $x1125)))
(and $x977 (or $x1125 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 50: function crcu8, block 29, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1193 ((_ zero_extend 16) in27_16)))
(let ((?x1282 (bvor ?x1193 (_ bv32768 32))))
(let (($x1125 (or false false)))
(let (($x17 (or $x1125 false false)))
(let (($x135 (not $x17)))
(and $x135 (or $x17 (and (distinct ?x1282 ?x1282) true)))))))))
(check-sat)
; query 51: function crcu8, block 29, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1193 ((_ zero_extend 16) in27_16)))
(let ((?x1282 (bvor ?x1193 (_ bv32768 32))))
(let ((?x1184 ((_ extract 15 0) ?x1282)))
(let (($x1125 (or false false)))
(let (($x17 (or $x1125 false false)))
(let (($x251 (or $x17 false)))
(let (($x669 (not $x251)))
(and $x669 (or $x251 (and (distinct ?x1184 ?x1184) true)))))))))))
(check-sat)
; query 52: function crcu8, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x1125 (or false false)))
(let (($x977 (not $x1125)))
(and $x977 (or $x1125 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 53: function crcu8, block 33, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1193 ((_ zero_extend 16) in27_16)))
(let ((?x1134 (bvand ?x1193 (_ bv32767 32))))
(let (($x1125 (or false false)))
(let (($x17 (or $x1125 false false)))
(let (($x135 (not $x17)))
(and $x135 (or $x17 (and (distinct ?x1134 ?x1134) true)))))))))
(check-sat)
; query 54: function crcu8, block 33, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1193 ((_ zero_extend 16) in27_16)))
(let ((?x1134 (bvand ?x1193 (_ bv32767 32))))
(let ((?x383 ((_ extract 15 0) ?x1134)))
(let (($x1125 (or false false)))
(let (($x17 (or $x1125 false false)))
(let (($x251 (or $x17 false)))
(let (($x669 (not $x251)))
(and $x669 (or $x251 (and (distinct ?x383 ?x383) true)))))))))))
(check-sat)
; query 55: function crcu8, block 38, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_8 () (_ BitVec 8))
(assert
 (let (($x140 (or false false false)))
(let (($x928 (not $x140)))
(and $x928 (or $x140 (and (distinct (bvadd in.02_8 (_ bv1 8)) (bvadd in.02_8 (_ bv1 8))) true))))))
(check-sat)
; query 56: function crcu8, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x1267 ((_ extract 7 0) in.01_16)))
(let ((?x1312 ((_ zero_extend 24) ?x1267)))
(let (($x1125 (or false false)))
(let (($x1172 (or $x1125 false)))
(and (not $x1172) (or $x1172 (and (distinct ?x1312 ?x1312) true))))))))
(check-sat)
; query 57: function crcu8, block 6, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x1267 ((_ extract 7 0) in.01_16)))
(let ((?x1312 ((_ zero_extend 24) ?x1267)))
(let ((?x1169 (bvand ?x1312 (_ bv1 32))))
(let (($x1125 (or false false)))
(let (($x1172 (or $x1125 false)))
(let (($x1447 (or $x1172 false false)))
(and (not $x1447) (or $x1447 (and (distinct ?x1169 ?x1169) true))))))))))
(check-sat)
; query 58: function crcu8, block 6, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1267 ((_ extract 7 0) in.01_16)))
(let ((?x1312 ((_ zero_extend 24) ?x1267)))
(let ((?x1169 (bvand ?x1312 (_ bv1 32))))
(let ((?x779 ((_ zero_extend 24) in.0_8)))
(let ((?x1003 (bvand ?x779 (_ bv1 32))))
(let ((?x1067 (bvxor ?x1003 ?x1169)))
(let (($x1125 (or false false)))
(let (($x1172 (or $x1125 false)))
(let (($x1447 (or $x1172 false false)))
(let (($x17 (or $x1125 false false)))
(let (($x1492 (or $x17 $x1447 false)))
(and (not $x1492) (or $x1492 (and (distinct ?x1067 ?x1067) true)))))))))))))))
(check-sat)
; query 59: function crcu8, block 6, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1267 ((_ extract 7 0) in.01_16)))
(let ((?x1312 ((_ zero_extend 24) ?x1267)))
(let ((?x1169 (bvand ?x1312 (_ bv1 32))))
(let ((?x779 ((_ zero_extend 24) in.0_8)))
(let ((?x1003 (bvand ?x779 (_ bv1 32))))
(let ((?x1067 (bvxor ?x1003 ?x1169)))
(let ((?x1605 ((_ extract 7 0) ?x1067)))
(let (($x1125 (or false false)))
(let (($x1172 (or $x1125 false)))
(let (($x1447 (or $x1172 false false)))
(let (($x17 (or $x1125 false false)))
(let (($x1492 (or $x17 $x1447 false)))
(let (($x1402 (or $x1492 false)))
(and (not $x1402) (or $x1402 (and (distinct ?x1605 ?x1605) true)))))))))))))))))
(check-sat)
; query 60: function crcu8, block 6, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x1125 (or false false)))
(let (($x977 (not $x1125)))
(and $x977 (or $x1125 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 61: function crcu8, block 6, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x779 ((_ zero_extend 24) in.0_8)))
(let ((?x1327 (bvashr ?x779 (_ bv1 32))))
(let (($x1125 (or false false)))
(let (($x17 (or $x1125 false false)))
(let (($x1252 (or $x17 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not $x1252) (or $x1252 (and (distinct ?x1327 ?x1327) true)))))))))
(check-sat)
; query 62: function crcu8, block 6, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x779 ((_ zero_extend 24) in.0_8)))
(let ((?x1327 (bvashr ?x779 (_ bv1 32))))
(let ((?x1342 ((_ extract 7 0) ?x1327)))
(let (($x1125 (or false false)))
(let (($x17 (or $x1125 false false)))
(let (($x1252 (or $x17 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x781 (or $x1252 false)))
(and (not $x781) (or $x781 (and (distinct ?x1342 ?x1342) true)))))))))))
(check-sat)
; query 63: function crcu8, block 6, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1267 ((_ extract 7 0) in.01_16)))
(let ((?x1312 ((_ zero_extend 24) ?x1267)))
(let ((?x1169 (bvand ?x1312 (_ bv1 32))))
(let ((?x779 ((_ zero_extend 24) in.0_8)))
(let ((?x1003 (bvand ?x779 (_ bv1 32))))
(let ((?x1067 (bvxor ?x1003 ?x1169)))
(let ((?x1605 ((_ extract 7 0) ?x1067)))
(let ((?x1186 ((_ zero_extend 24) ?x1605)))
(let (($x1125 (or false false)))
(let (($x1172 (or $x1125 false)))
(let (($x1447 (or $x1172 false false)))
(let (($x17 (or $x1125 false false)))
(let (($x1492 (or $x17 $x1447 false)))
(let (($x1402 (or $x1492 false)))
(let (($x242 (or $x1402 false)))
(and (not $x242) (or $x242 (and (distinct ?x1186 ?x1186) true)))))))))))))))))))
(check-sat)
; query 64: function crcu8, block 6, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1267 ((_ extract 7 0) in.01_16)))
(let ((?x1312 ((_ zero_extend 24) ?x1267)))
(let ((?x1169 (bvand ?x1312 (_ bv1 32))))
(let ((?x779 ((_ zero_extend 24) in.0_8)))
(let ((?x1003 (bvand ?x779 (_ bv1 32))))
(let ((?x1067 (bvxor ?x1003 ?x1169)))
(let ((?x1605 ((_ extract 7 0) ?x1067)))
(let ((?x1186 ((_ zero_extend 24) ?x1605)))
(let ((?x484 (ite (= (_ bv1 32) ?x1186) (_ bv1 1) (_ bv0 1))))
(let (($x1125 (or false false)))
(let (($x1172 (or $x1125 false)))
(let (($x1447 (or $x1172 false false)))
(let (($x17 (or $x1125 false false)))
(let (($x1492 (or $x17 $x1447 false)))
(let (($x1402 (or $x1492 false)))
(let (($x242 (or $x1402 false)))
(let (($x1237 (or $x242 false false)))
(and (not $x1237) (or $x1237 (and (distinct ?x484 ?x484) true)))))))))))))))))))))
(check-sat)
; query 65: function crcu8, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x1125 (or false false)))
(let (($x977 (not $x1125)))
(and $x977 (or $x1125 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 66: function crcu8, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x779 ((_ zero_extend 24) in.0_8)))
(let ((?x1003 (bvand ?x779 (_ bv1 32))))
(let (($x1125 (or false false)))
(let (($x17 (or $x1125 false false)))
(let (($x135 (not $x17)))
(and $x135 (or $x17 (and (distinct ?x1003 ?x1003) true)))))))))
(check-sat)
; query 67: function crcu8, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x1125 (or false false)))
(let (($x977 (not $x1125)))
(and $x977 (or $x1125 (and (distinct ((_ extract 7 0) in.01_16) ((_ extract 7 0) in.01_16)) true))))))
(check-sat)
; query 68: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x2490 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2501 ((_ zero_extend 31) ?x2490)))
(let ((?x2488 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x9621 ((_ zero_extend 31) ?x2488)))
(let ((?x1379 (bvand ?x9621 ?x2501)))
(let ((?x1294 (ite (and (distinct (_ bv0 32) ?x1379) true) (_ bv1 1) (_ bv0 1))))
(let ((?x2503 ((_ zero_extend 63) ?x1294)))
(let (($x1125 (or false false)))
(let (($x17 (or $x1125 false false)))
(let (($x251 (or $x17 false)))
(let (($x2502 (or $x251 $x251 false)))
(let (($x1261 (or $x2502 false false)))
(let (($x2506 (or $x1261 false)))
(and (not $x2506) (or $x2506 (and (distinct ?x2503 ?x2503) true)))))))))))))))))
(check-sat)
; query 69: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x2490 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2501 ((_ zero_extend 31) ?x2490)))
(let ((?x2488 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x9621 ((_ zero_extend 31) ?x2488)))
(let ((?x1379 (bvand ?x9621 ?x2501)))
(let ((?x1294 (ite (and (distinct (_ bv0 32) ?x1379) true) (_ bv1 1) (_ bv0 1))))
(let (($x2491 (= (_ bv1 1) ?x1294)))
(let ((?x2534 (ite $x2491 (_ bv1 32) (_ bv0 32))))
(let (($x1125 (or false false)))
(let (($x17 (or $x1125 false false)))
(let (($x251 (or $x17 false)))
(let (($x2502 (or $x251 $x251 false)))
(let (($x1261 (or $x2502 false false)))
(let (($x2531 (or $x1261 (ite $x2491 false false))))
(and (not $x2531) (or $x2531 (and (distinct ?x2534 ?x2534) true))))))))))))))))))
(check-sat)
; query 70: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x2490 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2501 ((_ zero_extend 31) ?x2490)))
(let ((?x2488 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x9621 ((_ zero_extend 31) ?x2488)))
(let ((?x1379 (bvand ?x9621 ?x2501)))
(let ((?x1294 (ite (and (distinct (_ bv0 32) ?x1379) true) (_ bv1 1) (_ bv0 1))))
(let (($x2491 (= (_ bv1 1) ?x1294)))
(let ((?x2534 (ite $x2491 (_ bv1 32) (_ bv0 32))))
(let ((?x2530 ((_ extract 7 0) ?x2534)))
(let (($x1125 (or false false)))
(let (($x17 (or $x1125 false false)))
(let (($x251 (or $x17 false)))
(let (($x2502 (or $x251 $x251 false)))
(let (($x1261 (or $x2502 false false)))
(let (($x2531 (or $x1261 (ite $x2491 false false))))
(let (($x1420 (or $x2531 false)))
(and (not $x1420) (or $x1420 (and (distinct ?x2530 ?x2530) true))))))))))))))))))))
(check-sat)
; query 71: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x1125 (or false false)))
(let (($x977 (not $x1125)))
(and $x977 (or $x1125 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 72: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x2488 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1125 (or false false)))
(let (($x17 (or $x1125 false false)))
(let (($x135 (not $x17)))
(and $x135 (or $x17 (and (distinct ?x2488 ?x2488) true))))))))
(check-sat)
; query 73: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x2488 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x9621 ((_ zero_extend 31) ?x2488)))
(let (($x1125 (or false false)))
(let (($x17 (or $x1125 false false)))
(let (($x251 (or $x17 false)))
(let (($x669 (not $x251)))
(and $x669 (or $x251 (and (distinct ?x9621 ?x9621) true))))))))))
(check-sat)
; query 74: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x1125 (or false false)))
(let (($x977 (not $x1125)))
(and $x977 (or $x1125 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 75: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x2490 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x1125 (or false false)))
(let (($x17 (or $x1125 false false)))
(let (($x135 (not $x17)))
(and $x135 (or $x17 (and (distinct ?x2490 ?x2490) true))))))))
(check-sat)
; query 76: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x2490 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2501 ((_ zero_extend 31) ?x2490)))
(let (($x1125 (or false false)))
(let (($x17 (or $x1125 false false)))
(let (($x251 (or $x17 false)))
(let (($x669 (not $x251)))
(and $x669 (or $x251 (and (distinct ?x2501 ?x2501) true))))))))))
(check-sat)
; query 77: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x2490 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2501 ((_ zero_extend 31) ?x2490)))
(let ((?x2488 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x9621 ((_ zero_extend 31) ?x2488)))
(let ((?x1379 (bvand ?x9621 ?x2501)))
(let (($x1125 (or false false)))
(let (($x17 (or $x1125 false false)))
(let (($x251 (or $x17 false)))
(let (($x2502 (or $x251 $x251 false)))
(and (not $x2502) (or $x2502 (and (distinct ?x1379 ?x1379) true)))))))))))))
(check-sat)
; query 78: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x2490 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2501 ((_ zero_extend 31) ?x2490)))
(let ((?x2488 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x9621 ((_ zero_extend 31) ?x2488)))
(let ((?x1379 (bvand ?x9621 ?x2501)))
(let ((?x1294 (ite (and (distinct (_ bv0 32) ?x1379) true) (_ bv1 1) (_ bv0 1))))
(let (($x1125 (or false false)))
(let (($x17 (or $x1125 false false)))
(let (($x251 (or $x17 false)))
(let (($x2502 (or $x251 $x251 false)))
(let (($x1261 (or $x2502 false false)))
(and (not $x1261) (or $x1261 (and (distinct ?x1294 ?x1294) true)))))))))))))))
(check-sat)
; query 79: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x6852 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x140 (or false false false)))
(let (($x928 (not $x140)))
(and $x928 (or $x140 (and (distinct ?x6852 ?x6852) true)))))))
(check-sat)
; query 80: function matrix_add_const, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x140 (or false false false)))
(let (($x928 (not $x140)))
(and $x928 (or $x140 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 81: function matrix_add_const, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x257 (bvadd in.01_32 (_ bv1 32))))
(let (($x1034 (and (distinct ?x257 ?x257) true)))
(let (($x140 (or false false false)))
(let (($x928 (not $x140)))
(and $x928 (or $x140 $x1034)))))))
(check-sat)
; query 82: function matrix_mul_const, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x140 (or false false false)))
(let (($x928 (not $x140)))
(and $x928 (or $x140 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 83: function matrix_mul_const, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x257 (bvadd in.01_32 (_ bv1 32))))
(let (($x1034 (and (distinct ?x257 ?x257) true)))
(let (($x140 (or false false false)))
(let (($x928 (not $x140)))
(and $x928 (or $x140 $x1034)))))))
(check-sat)
; query 84: function matrix_mul_matrix, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x140 (or false false false)))
(let (($x928 (not $x140)))
(and $x928 (or $x140 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 85: function matrix_mul_matrix, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x257 (bvadd in.01_32 (_ bv1 32))))
(let (($x1034 (and (distinct ?x257 ?x257) true)))
(let (($x140 (or false false false)))
(let (($x928 (not $x140)))
(and $x928 (or $x140 $x1034)))))))
(check-sat)
; query 86: function matrix_mul_matrix, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x140 (or false false false)))
(let (($x928 (not $x140)))
(and $x928 (or $x140 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 87: function matrix_mul_matrix_bitextract, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x140 (or false false false)))
(let (($x928 (not $x140)))
(and $x928 (or $x140 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 88: function matrix_mul_matrix_bitextract, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x257 (bvadd in.01_32 (_ bv1 32))))
(let (($x1034 (and (distinct ?x257 ?x257) true)))
(let (($x140 (or false false false)))
(let (($x928 (not $x140)))
(and $x928 (or $x140 $x1034)))))))
(check-sat)
; query 89: function matrix_mul_matrix_bitextract, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x140 (or false false false)))
(let (($x928 (not $x140)))
(and $x928 (or $x140 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 90: function matrix_mul_vect, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x140 (or false false false)))
(let (($x928 (not $x140)))
(and $x928 (or $x140 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 91: function matrix_mul_vect, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x257 (bvadd in.01_32 (_ bv1 32))))
(let (($x1034 (and (distinct ?x257 ?x257) true)))
(let (($x140 (or false false false)))
(let (($x928 (not $x140)))
(and $x928 (or $x140 $x1034)))))))
(check-sat)
; query 92: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x1125 (or false false)))
(let (($x977 (not $x1125)))
(and $x977 (or $x1125 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 93: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x6867 ((_ sign_extend 16) in.1_16)))
(let ((?x6864 (bvadd ?x6867 (_ bv10 32))))
(let (($x6872 (and (distinct (bvadd ((_ sign_extend 1) ?x6867) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x6864)) true)))
(let (($x1125 (or false false)))
(let (($x6856 (or $x1125 false (or $x6872))))
(and (not $x6856) (or $x6856 (and (distinct ?x6864 ?x6864) true)))))))))
(check-sat)
; query 94: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x6867 ((_ sign_extend 16) in.1_16)))
(let ((?x6864 (bvadd ?x6867 (_ bv10 32))))
(let ((?x6871 ((_ extract 15 0) ?x6864)))
(let (($x6872 (and (distinct (bvadd ((_ sign_extend 1) ?x6867) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x6864)) true)))
(let (($x1125 (or false false)))
(let (($x6856 (or $x1125 false (or $x6872))))
(let (($x6887 (or $x6856 false)))
(and (not $x6887) (or $x6887 (and (distinct ?x6871 ?x6871) true)))))))))))
(check-sat)
; query 95: function matrix_sum, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x6903 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x140 (or false false false)))
(let (($x928 (not $x140)))
(and $x928 (or $x140 (and (distinct ?x6903 ?x6903) true)))))))
(check-sat)
; query 96: function matrix_sum, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x6903 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let ((?x1595 ((_ zero_extend 63) ?x6903)))
(let (($x140 (or false false false)))
(let (($x948 (or $x140 false)))
(and (not $x948) (or $x948 (and (distinct ?x1595 ?x1595) true))))))))
(check-sat)
; query 97: function matrix_sum, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x6903 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x2660 (= (_ bv1 1) ?x6903)))
(let ((?x6910 (ite $x2660 (_ bv1 32) (_ bv0 32))))
(let (($x140 (or false false false)))
(let (($x6908 (or $x140 (ite $x2660 false false))))
(and (not $x6908) (or $x6908 (and (distinct ?x6910 ?x6910) true)))))))))
(check-sat)
; query 98: function matrix_sum, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x1125 (or false false)))
(let (($x977 (not $x1125)))
(and $x977 (or $x1125 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 99: function matrix_sum, block 22, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x6903 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x2660 (= (_ bv1 1) ?x6903)))
(let ((?x6910 (ite $x2660 (_ bv1 32) (_ bv0 32))))
(let ((?x6867 ((_ sign_extend 16) in.1_16)))
(let ((?x2650 (bvadd ?x6867 ?x6910)))
(let (($x6909 (and (distinct (bvadd ((_ sign_extend 1) ?x6867) ((_ sign_extend 1) ?x6910)) ((_ sign_extend 1) ?x2650)) true)))
(let (($x140 (or false false false)))
(let (($x6908 (or $x140 (ite $x2660 false false))))
(let (($x1125 (or false false)))
(let (($x2852 (or $x1125 $x6908 (or $x6909))))
(and (not $x2852) (or $x2852 (and (distinct ?x2650 ?x2650) true))))))))))))))
(check-sat)
; query 100: function matrix_sum, block 22, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x6903 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x2660 (= (_ bv1 1) ?x6903)))
(let ((?x6910 (ite $x2660 (_ bv1 32) (_ bv0 32))))
(let ((?x6867 ((_ sign_extend 16) in.1_16)))
(let ((?x2650 (bvadd ?x6867 ?x6910)))
(let ((?x6893 ((_ extract 15 0) ?x2650)))
(let (($x6909 (and (distinct (bvadd ((_ sign_extend 1) ?x6867) ((_ sign_extend 1) ?x6910)) ((_ sign_extend 1) ?x2650)) true)))
(let (($x140 (or false false false)))
(let (($x6908 (or $x140 (ite $x2660 false false))))
(let (($x1125 (or false false)))
(let (($x2852 (or $x1125 $x6908 (or $x6909))))
(let (($x2854 (or $x2852 false)))
(and (not $x2854) (or $x2854 (and (distinct ?x6893 ?x6893) true))))))))))))))))
(check-sat)
; query 101: function matrix_sum, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x140 (or false false false)))
(let (($x928 (not $x140)))
(and $x928 (or $x140 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 102: function matrix_sum, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x257 (bvadd in.01_32 (_ bv1 32))))
(let (($x1034 (and (distinct ?x257 ?x257) true)))
(let (($x140 (or false false false)))
(let (($x928 (not $x140)))
(and $x928 (or $x140 $x1034)))))))
(check-sat)
; query 103: function parseval, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.23_32 () (_ BitVec 32))
(assert
 (let (($x2691 (and (distinct (bvmul ((_ sign_extend 32) in.23_32) ((_ sign_extend 32) (_ bv1024 32))) ((_ sign_extend 32) (bvmul in.23_32 (_ bv1024 32)))) true)))
(let (($x4465 (or false false (or $x2691))))
(and (not $x4465) (or $x4465 (and (distinct (bvmul in.23_32 (_ bv1024 32)) (bvmul in.23_32 (_ bv1024 32))) true))))))
(check-sat)
; query 104: function parseval, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.34_32 () (_ BitVec 32))
(assert
 (let (($x4760 (and (distinct (bvmul ((_ sign_extend 32) in.34_32) ((_ sign_extend 32) (_ bv1048576 32))) ((_ sign_extend 32) (bvmul in.34_32 (_ bv1048576 32)))) true)))
(let (($x2924 (or false false (or $x4760))))
(and (not $x2924) (or $x2924 (and (distinct (bvmul in.34_32 (_ bv1048576 32)) (bvmul in.34_32 (_ bv1048576 32))) true))))))
(check-sat)
; query 105: function partition_memory, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x140 (or false false false)))
(let (($x928 (not $x140)))
(and $x928 (or $x140 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 106: function run_crc_loop, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x257 (bvadd in.01_32 (_ bv1 32))))
(let (($x1034 (and (distinct ?x257 ?x257) true)))
(let (($x140 (or false false false)))
(let (($x928 (not $x140)))
(and $x928 (or $x140 $x1034)))))))
(check-sat)
