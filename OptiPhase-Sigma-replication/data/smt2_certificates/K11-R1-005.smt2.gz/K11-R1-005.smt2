; OptiPhase-Sigma refinement certificate for sweep K11-R1-005
