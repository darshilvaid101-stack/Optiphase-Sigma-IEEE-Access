; OptiPhase-Sigma refinement certificate for sweep K51-R3-118
; query 0: function check, block 115, name %116
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x64 (and (distinct (ite (= (_ bv0 32) in0_32) (_ bv1 1) (_ bv0 1)) (ite (= (_ bv13 32) in0_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x1968 (or false false false)))
(let (($x1462 (not $x1968)))
(and $x1462 (or $x1968 $x64))))))
(check-sat)
; query 1: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x654 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x1968 (or false false false)))
(let (($x1462 (not $x1968)))
(and $x1462 (or $x1968 (and (distinct ?x654 ?x654) true)))))))
(check-sat)
; query 2: function set1d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x687 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x1968 (or false false false)))
(let (($x1462 (not $x1968)))
(and $x1462 (or $x1968 (and (distinct ?x687 ?x687) true)))))))
(check-sat)
; query 3: function set1ds, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x1532 (ite (= (_ bv4294967295 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x1968 (or false false false)))
(let (($x1462 (not $x1968)))
(and $x1462 (or $x1968 (and (distinct ?x1532 ?x1532) true)))))))
(check-sat)
; query 4: function set2d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x687 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x1968 (or false false false)))
(let (($x1462 (not $x1968)))
(and $x1462 (or $x1968 (and (distinct ?x687 ?x687) true)))))))
(check-sat)
