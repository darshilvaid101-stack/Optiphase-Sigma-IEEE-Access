; OptiPhase-Sigma refinement certificate for sweep K47-R3-202
; query 0: function main, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x765 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x1586 (or false false false)))
(and (not $x1586) (or $x1586 (and (distinct ?x765 ?x765) true))))))
(check-sat)
