; OptiPhase-Sigma refinement certificate for sweep K52-R3-209
; query 0: function check, block 103, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x515 (ite (= (_ bv22 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x32 (or false false false)))
(let (($x309 (not $x32)))
(and $x309 (or $x32 (and (distinct ?x515 ?x515) true)))))))
(check-sat)
; query 1: function check, block 109, name %110
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x337 (ite (= (_ bv33 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x32 (or false false false)))
(let (($x309 (not $x32)))
(and $x309 (or $x32 (and (distinct ?x337 ?x337) true)))))))
(check-sat)
; query 2: function check, block 115, name %116
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x19 (ite (= (_ bv0 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x32 (or false false false)))
(let (($x309 (not $x32)))
(and $x309 (or $x32 (and (distinct ?x19 ?x19) true)))))))
(check-sat)
; query 3: function check, block 121, name %122
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x1732 (ite (= (_ bv12 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x32 (or false false false)))
(let (($x309 (not $x32)))
(and $x309 (or $x32 (and (distinct ?x1732 ?x1732) true)))))))
(check-sat)
; query 4: function check, block 128, name %129
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x235 (ite (= (_ bv25 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x32 (or false false false)))
(let (($x309 (not $x32)))
(and $x309 (or $x32 (and (distinct ?x235 ?x235) true)))))))
(check-sat)
; query 5: function check, block 135, name %136
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x155 (ite (= (_ bv13 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x32 (or false false false)))
(let (($x309 (not $x32)))
(and $x309 (or $x32 (and (distinct ?x155 ?x155) true)))))))
(check-sat)
; query 6: function check, block 142, name %143
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x104 (ite (= (_ bv123 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x32 (or false false false)))
(let (($x309 (not $x32)))
(and $x309 (or $x32 (and (distinct ?x104 ?x104) true)))))))
(check-sat)
; query 7: function check, block 150, name %151
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x150 (ite (= (_ bv1122 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x32 (or false false false)))
(let (($x309 (not $x32)))
(and $x309 (or $x32 (and (distinct ?x150 ?x150) true)))))))
(check-sat)
; query 8: function check, block 157, name %158
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x123 (ite (= (_ bv112233 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x32 (or false false false)))
(let (($x309 (not $x32)))
(and $x309 (or $x32 (and (distinct ?x123 ?x123) true)))))))
(check-sat)
; query 9: function check, block 165, name %166
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x68 (ite (= (_ bv111 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x32 (or false false false)))
(let (($x309 (not $x32)))
(and $x309 (or $x32 (and (distinct ?x68 ?x68) true)))))))
(check-sat)
; query 10: function check, block 172, name %173
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x204 (ite (= (_ bv4294967295 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x32 (or false false false)))
(let (($x309 (not $x32)))
(and $x309 (or $x32 (and (distinct ?x204 ?x204) true)))))))
(check-sat)
; query 11: function check, block 179, name %180
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x223 (ite (= (_ bv4294967284 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x32 (or false false false)))
(let (($x309 (not $x32)))
(and $x309 (or $x32 (and (distinct ?x223 ?x223) true)))))))
(check-sat)
; query 12: function check, block 25, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_32 () (_ BitVec 32))
(assert
 (let (($x17042 (and (distinct (bvadd ((_ sign_extend 1) in.06_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.06_32 (_ bv1 32)))) true)))
(let (($x9642 (or false false (or $x17042))))
(and (not $x9642) (or $x9642 (and (distinct (bvadd in.06_32 (_ bv1 32)) (bvadd in.06_32 (_ bv1 32))) true))))))
(check-sat)
; query 13: function check, block 52, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.013_32 () (_ BitVec 32))
(assert
 (let (($x248 (and (distinct (bvadd ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.013_32 (_ bv1 32)))) true)))
(let (($x270 (or false false (or $x248))))
(and (not $x270) (or $x270 (and (distinct (bvadd in.013_32 (_ bv1 32)) (bvadd in.013_32 (_ bv1 32))) true))))))
(check-sat)
; query 14: function check, block 55, name %56
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.012_32 () (_ BitVec 32))
(assert
 (let (($x1952 (and (distinct (bvadd ((_ sign_extend 1) in.012_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.012_32 (_ bv1 32)))) true)))
(let (($x1586 (or false false (or $x1952))))
(and (not $x1586) (or $x1586 (and (distinct (bvadd in.012_32 (_ bv1 32)) (bvadd in.012_32 (_ bv1 32))) true))))))
(check-sat)
; query 15: function check, block 65, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x203 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x649 (or false false (or $x203))))
(and (not $x649) (or $x649 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 16: function check, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x759 (ite (= (_ bv2 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x32 (or false false false)))
(let (($x309 (not $x32)))
(and $x309 (or $x32 (and (distinct ?x759 ?x759) true)))))))
(check-sat)
; query 17: function check, block 79, name %80
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x426 (ite (= (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x32 (or false false false)))
(let (($x309 (not $x32)))
(and $x309 (or $x32 (and (distinct ?x426 ?x426) true)))))))
(check-sat)
; query 18: function check, block 85, name %86
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x175 (ite (= (_ bv4 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x32 (or false false false)))
(let (($x309 (not $x32)))
(and $x309 (or $x32 (and (distinct ?x175 ?x175) true)))))))
(check-sat)
; query 19: function check, block 91, name %92
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x54 (ite (= (_ bv5 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x32 (or false false false)))
(let (($x309 (not $x32)))
(and $x309 (or $x32 (and (distinct ?x54 ?x54) true)))))))
(check-sat)
; query 20: function check, block 97, name %98
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x321 (ite (= (_ bv11 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x32 (or false false false)))
(let (($x309 (not $x32)))
(and $x309 (or $x32 (and (distinct ?x321 ?x321) true)))))))
(check-sat)
; query 21: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x435 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x32 (or false false false)))
(let (($x309 (not $x32)))
(and $x309 (or $x32 (and (distinct ?x435 ?x435) true)))))))
(check-sat)
; query 22: function s1161, block 41, name %42
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x203 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x649 (or false false (or $x203))))
(and (not $x649) (or $x649 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 23: function s1161, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x110 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x420 (or false false (or $x110))))
(and (not $x420) (or $x420 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 24: function s161, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x203 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x649 (or false false (or $x203))))
(and (not $x649) (or $x649 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 25: function s161, block 47, name %48
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x110 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x420 (or false false (or $x110))))
(and (not $x420) (or $x420 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 26: function s162, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x646 (ite (bvslt (_ bv0 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x32 (or false false false)))
(let (($x309 (not $x32)))
(and $x309 (or $x32 (and (distinct ?x646 ?x646) true)))))))
(check-sat)
; query 27: function s2710, block 79, name %80
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x203 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x649 (or false false (or $x203))))
(and (not $x649) (or $x649 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 28: function s2710, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x110 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x420 (or false false (or $x110))))
(and (not $x420) (or $x420 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 29: function s272, block 36, name %37
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x203 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x649 (or false false (or $x203))))
(and (not $x649) (or $x649 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 30: function s272, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x110 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x420 (or false false (or $x110))))
(and (not $x420) (or $x420 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 31: function s274, block 46, name %47
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x203 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x649 (or false false (or $x203))))
(and (not $x649) (or $x649 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 32: function s274, block 50, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x110 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x420 (or false false (or $x110))))
(and (not $x420) (or $x420 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 33: function s275, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x203 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x649 (or false false (or $x203))))
(and (not $x649) (or $x649 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 34: function s275, block 44, name %45
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x110 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x420 (or false false (or $x110))))
(and (not $x420) (or $x420 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 35: function s275, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x1302 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x1475 (or false false (or $x1302))))
(and (not $x1475) (or $x1475 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 36: function s276, block 35, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x203 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x649 (or false false (or $x203))))
(and (not $x649) (or $x649 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 37: function s276, block 39, name %40
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x110 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x420 (or false false (or $x110))))
(and (not $x420) (or $x420 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 38: function s276, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x203 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x649 (or false false (or $x203))))
(and (not $x649) (or $x649 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 39: function s276, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x19591 (ite (bvsgt (_ bv16000 32) (bvadd in.0_32 (_ bv1 32))) (_ bv1 1) (_ bv0 1))))
(let (($x203 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x649 (or false false (or $x203))))
(let (($x16806 (or $x649 false false)))
(and (not $x16806) (or $x16806 (and (distinct ?x19591 ?x19591) true))))))))
(check-sat)
; query 40: function s277, block 46, name %47
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x203 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x649 (or false false (or $x203))))
(and (not $x649) (or $x649 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 41: function s277, block 50, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x110 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x420 (or false false (or $x110))))
(and (not $x420) (or $x420 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 42: function s278, block 55, name %56
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x203 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x649 (or false false (or $x203))))
(and (not $x649) (or $x649 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 43: function s278, block 59, name %60
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x110 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x420 (or false false (or $x110))))
(and (not $x420) (or $x420 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 44: function s279, block 75, name %76
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x203 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x649 (or false false (or $x203))))
(and (not $x649) (or $x649 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 45: function s279, block 79, name %80
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x110 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x420 (or false false (or $x110))))
(and (not $x420) (or $x420 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 46: function s441, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x203 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x649 (or false false (or $x203))))
(and (not $x649) (or $x649 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 47: function s441, block 57, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x110 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x420 (or false false (or $x110))))
(and (not $x420) (or $x420 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 48: function s442, block 63, name %64
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x203 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x649 (or false false (or $x203))))
(and (not $x649) (or $x649 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 49: function s442, block 67, name %68
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x110 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x420 (or false false (or $x110))))
(and (not $x420) (or $x420 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 50: function s443, block 39, name %40
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x203 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x649 (or false false (or $x203))))
(and (not $x649) (or $x649 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 51: function s443, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x110 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x420 (or false false (or $x110))))
(and (not $x420) (or $x420 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 52: function s481, block 25, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x203 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x649 (or false false (or $x203))))
(and (not $x649) (or $x649 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 53: function s481, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x110 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x420 (or false false (or $x110))))
(and (not $x420) (or $x420 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 54: function s482, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x203 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x649 (or false false (or $x203))))
(and (not $x649) (or $x649 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 55: function s482, block 32, name %33
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x110 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x420 (or false false (or $x110))))
(and (not $x420) (or $x420 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 56: function set, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x283 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv5 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv5 32)))) true)))
(let (($x1786 (or false false (or $x283))))
(and (not $x1786) (or $x1786 (and (distinct (bvadd in.01_32 (_ bv5 32)) (bvadd in.01_32 (_ bv5 32))) true))))))
(check-sat)
; query 57: function set1d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x868 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x32 (or false false false)))
(let (($x309 (not $x32)))
(and $x309 (or $x32 (and (distinct ?x868 ?x868) true)))))))
(check-sat)
; query 58: function set1ds, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x860 (ite (= (_ bv4294967295 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x32 (or false false false)))
(let (($x309 (not $x32)))
(and $x309 (or $x32 (and (distinct ?x860 ?x860) true)))))))
(check-sat)
; query 59: function set2d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x868 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x32 (or false false false)))
(let (($x309 (not $x32)))
(and $x309 (or $x32 (and (distinct ?x868 ?x868) true)))))))
(check-sat)
; query 60: function sum1d, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x203 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x649 (or false false (or $x203))))
(and (not $x649) (or $x649 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
