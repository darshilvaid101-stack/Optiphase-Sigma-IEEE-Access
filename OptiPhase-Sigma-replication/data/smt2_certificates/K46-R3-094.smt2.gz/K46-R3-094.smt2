; OptiPhase-Sigma refinement certificate for sweep K46-R3-094
; query 0: function main, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x111 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x562 (or false false false)))
(and (not $x562) (or $x562 (and (distinct ?x111 ?x111) true))))))
(check-sat)
