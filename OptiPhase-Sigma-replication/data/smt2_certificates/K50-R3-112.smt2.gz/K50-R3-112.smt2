; OptiPhase-Sigma refinement certificate for sweep K50-R3-112
; query 0: function check, block 142, name %143
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x72 (and (distinct (ite (= (_ bv123 32) in0_32) (_ bv1 1) (_ bv0 1)) (ite (= (_ bv1122 32) in0_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x11 (or false false false)))
(let (($x1648 (not $x11)))
(and $x1648 (or $x11 $x72))))))
(check-sat)
; query 1: function check, block 157, name %158
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x459 (and (distinct (ite (= (_ bv112233 32) in0_32) (_ bv1 1) (_ bv0 1)) (ite (= (_ bv111 32) in0_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x11 (or false false false)))
(let (($x1648 (not $x11)))
(and $x1648 (or $x11 $x459))))))
(check-sat)
; query 2: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x1718 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x11 (or false false false)))
(let (($x1648 (not $x11)))
(and $x1648 (or $x11 (and (distinct ?x1718 ?x1718) true)))))))
(check-sat)
; query 3: function s115, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x776 (and (distinct (bvadd ((_ zero_extend 1) in.01_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x161 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x1722 (or (or false false (or $x161 $x776)) (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))
(and (not (or false false (or $x161))) $x1722)))))
(check-sat)
; query 4: function set1d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x460 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x11 (or false false false)))
(let (($x1648 (not $x11)))
(and $x1648 (or $x11 (and (distinct ?x460 ?x460) true)))))))
(check-sat)
; query 5: function set1ds, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x374 (ite (= (_ bv4294967295 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x11 (or false false false)))
(let (($x1648 (not $x11)))
(and $x1648 (or $x11 (and (distinct ?x374 ?x374) true)))))))
(check-sat)
; query 6: function set2d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x460 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x11 (or false false false)))
(let (($x1648 (not $x11)))
(and $x1648 (or $x11 (and (distinct ?x460 ?x460) true)))))))
(check-sat)
