; OptiPhase-Sigma refinement certificate for sweep K41-R4-363
