; OptiPhase-Sigma refinement certificate for sweep K48-R4-344
; query 0: function gsm_L_add, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let (($x25 (and (distinct (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv18446744073709551615 64) in1_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x159 (or false false false)))
(let (($x225 (not $x159)))
(and $x225 (or $x159 $x25))))))
(check-sat)
; query 1: function gsm_L_add, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x231 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvadd in0_64 in1_64))) true)))
(let (($x164 (or false false (or $x231))))
(let (($x82 (or $x164 (and (distinct (bvadd in0_64 in1_64) (bvadd in0_64 in1_64)) true))))
(and (not $x164) $x82)))))
(check-sat)
; query 2: function gsm_L_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x169 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x159 (or false false false)))
(let (($x225 (not $x159)))
(and $x225 (or $x159 (and (distinct ?x169 ?x169) true)))))))
(check-sat)
; query 3: function gsm_L_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x18 (and (distinct (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv31 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x159 (or false false false)))
(let (($x225 (not $x159)))
(and $x225 (or $x159 $x18))))))
(check-sat)
; query 4: function gsm_L_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x18 (and (distinct (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv31 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x159 (or false false false)))
(let (($x225 (not $x159)))
(and $x225 (or $x159 $x18))))))
(check-sat)
; query 5: function gsm_L_sub, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let (($x25 (and (distinct (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv18446744073709551615 64) in1_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x159 (or false false false)))
(let (($x225 (not $x159)))
(and $x225 (or $x159 $x25))))))
(check-sat)
; query 6: function gsm_L_sub, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x37 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvsub in0_64 in1_64))) true)))
(let (($x20 (or false false (or $x37))))
(let (($x293 (or $x20 (and (distinct (bvsub in0_64 in1_64) (bvsub in0_64 in1_64)) true))))
(and (not $x20) $x293)))))
(check-sat)
; query 7: function gsm_L_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x233 (and (distinct (ite (bvsle (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv18446744073709551615 64) in0_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x159 (or false false false)))
(let (($x225 (not $x159)))
(and $x225 (or $x159 $x233))))))
(check-sat)
; query 8: function gsm_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x95 (and (distinct (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv15 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x159 (or false false false)))
(let (($x225 (not $x159)))
(and $x225 (or $x159 $x95))))))
(check-sat)
; query 9: function gsm_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x95 (and (distinct (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv15 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x159 (or false false false)))
(let (($x225 (not $x159)))
(and $x225 (or $x159 $x95))))))
(check-sat)
