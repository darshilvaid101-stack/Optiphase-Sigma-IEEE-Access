; OptiPhase-Sigma refinement certificate for sweep K03-R2-009
