; OptiPhase-Sigma refinement certificate for sweep K59-R2-043
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x57 (or false false)))
(let (($x47 (not $x57)))
(and $x47 (or $x57 (and (distinct ((_ sign_extend 16) in25_16) ((_ sign_extend 16) in25_16)) true))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let ((?x368 (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false)))
(let (($x7026 (or $x57 false false)))
(let (($x188 (not $x7026)))
(and $x188 (or $x7026 (and (distinct ?x368 ?x368) true))))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x57 (or false false)))
(let (($x47 (not $x57)))
(and $x47 (or $x57 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x78 ((_ sign_extend 16) in3_16)))
(let ((?x62 (bvand ?x78 (_ bv127 32))))
(let (($x57 (or false false)))
(let (($x7026 (or $x57 false false)))
(let (($x188 (not $x7026)))
(and $x188 (or $x7026 (and (distinct ?x62 ?x62) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x78 ((_ sign_extend 16) in3_16)))
(let ((?x62 (bvand ?x78 (_ bv127 32))))
(let ((?x1675 ((_ extract 15 0) ?x62)))
(let (($x57 (or false false)))
(let (($x7026 (or $x57 false false)))
(let (($x110 (or $x7026 false)))
(let (($x74 (not $x110)))
(and $x74 (or $x110 (and (distinct ?x1675 ?x1675) true)))))))))))
(check-sat)
; query 5: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x57 (or false false)))
(let (($x47 (not $x57)))
(and $x47 (or $x57 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 6: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x145 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false)))
(let (($x7026 (or $x57 false false)))
(let (($x188 (not $x7026)))
(and $x188 (or $x7026 (and (distinct ?x145 ?x145) true))))))))
(check-sat)
; query 7: function core_bench_list, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x111 (or false false false)))
(let (($x1923 (not $x111)))
(and $x1923 (or $x111 (and (distinct (bvadd in.0_16 (_ bv1 16)) (bvadd in.0_16 (_ bv1 16))) true))))))
(check-sat)
; query 8: function core_bench_list, block 82, name %83
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let (($x57 (or false false)))
(let (($x47 (not $x57)))
(and $x47 (or $x57 (and (distinct ((_ zero_extend 16) in.02_16) ((_ zero_extend 16) in.02_16)) true))))))
(check-sat)
; query 9: function core_bench_list, block 82, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x173 ((_ zero_extend 16) in.02_16)))
(let ((?x169 (bvmul ?x173 (_ bv4 32))))
(let (($x97 (and (distinct (bvmul ((_ sign_extend 32) ?x173) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x169)) true)))
(let (($x57 (or false false)))
(let (($x685 (or $x57 false (or $x97))))
(and (not $x685) (or $x685 (and (distinct ?x169 ?x169) true)))))))))
(check-sat)
; query 10: function core_bench_list, block 82, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let (($x57 (or false false)))
(let (($x47 (not $x57)))
(and $x47 (or $x57 (and (distinct ((_ zero_extend 16) in.04_16) ((_ zero_extend 16) in.04_16)) true))))))
(check-sat)
; query 11: function core_bench_list, block 82, name %86
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x227 ((_ zero_extend 16) in.04_16)))
(let ((?x173 ((_ zero_extend 16) in.02_16)))
(let ((?x169 (bvmul ?x173 (_ bv4 32))))
(let ((?x586 (bvsub ?x169 ?x227)))
(let ((?x45 ((_ sign_extend 1) ?x586)))
(let (($x57 (or false false)))
(let (($x97 (and (distinct (bvmul ((_ sign_extend 32) ?x173) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x169)) true)))
(let (($x685 (or $x57 false (or $x97))))
(let (($x1389 (or $x685 $x57 (or (and (distinct (bvsub ((_ sign_extend 1) ?x169) ((_ sign_extend 1) ?x227)) ?x45) true)))))
(and (not $x1389) (or $x1389 (and (distinct ?x586 ?x586) true)))))))))))))
(check-sat)
; query 12: function core_bench_list, block 82, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x57 (or false false)))
(let (($x47 (not $x57)))
(and $x47 (or $x57 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 13: function core_bench_list, block 82, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x227 ((_ zero_extend 16) in.04_16)))
(let ((?x173 ((_ zero_extend 16) in.02_16)))
(let ((?x169 (bvmul ?x173 (_ bv4 32))))
(let ((?x586 (bvsub ?x169 ?x227)))
(let ((?x44 ((_ zero_extend 16) in.01_16)))
(let ((?x15 (bvadd ?x44 ?x586)))
(let (($x220 (and (distinct (bvadd ((_ sign_extend 1) ?x44) ((_ sign_extend 1) ?x586)) ((_ sign_extend 1) ?x15)) true)))
(let ((?x45 ((_ sign_extend 1) ?x586)))
(let (($x57 (or false false)))
(let (($x97 (and (distinct (bvmul ((_ sign_extend 32) ?x173) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x169)) true)))
(let (($x685 (or $x57 false (or $x97))))
(let (($x1389 (or $x685 $x57 (or (and (distinct (bvsub ((_ sign_extend 1) ?x169) ((_ sign_extend 1) ?x227)) ?x45) true)))))
(let (($x695 (or $x57 $x1389 (or $x220))))
(and (not $x695) (or $x695 (and (distinct ?x15 ?x15) true)))))))))))))))))
(check-sat)
; query 14: function core_bench_list, block 82, name %89
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x227 ((_ zero_extend 16) in.04_16)))
(let ((?x173 ((_ zero_extend 16) in.02_16)))
(let ((?x169 (bvmul ?x173 (_ bv4 32))))
(let ((?x586 (bvsub ?x169 ?x227)))
(let ((?x44 ((_ zero_extend 16) in.01_16)))
(let ((?x15 (bvadd ?x44 ?x586)))
(let ((?x2078 ((_ extract 15 0) ?x15)))
(let (($x220 (and (distinct (bvadd ((_ sign_extend 1) ?x44) ((_ sign_extend 1) ?x586)) ((_ sign_extend 1) ?x15)) true)))
(let ((?x45 ((_ sign_extend 1) ?x586)))
(let (($x57 (or false false)))
(let (($x97 (and (distinct (bvmul ((_ sign_extend 32) ?x173) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x169)) true)))
(let (($x685 (or $x57 false (or $x97))))
(let (($x1389 (or $x685 $x57 (or (and (distinct (bvsub ((_ sign_extend 1) ?x169) ((_ sign_extend 1) ?x227)) ?x45) true)))))
(let (($x695 (or $x57 $x1389 (or $x220))))
(let (($x49 (or $x695 false)))
(and (not $x49) (or $x49 (and (distinct ?x2078 ?x2078) true)))))))))))))))))))
(check-sat)
; query 15: function core_bench_list, block 82, name %90
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x57 (or false false)))
(let (($x47 (not $x57)))
(and $x47 (or $x57 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 16: function core_bench_list, block 82, name %91
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x3171 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false)))
(let (($x7026 (or $x57 false false)))
(let (($x188 (not $x7026)))
(and $x188 (or $x7026 (and (distinct ?x3171 ?x3171) true))))))))
(check-sat)
; query 17: function core_bench_state, block 105, name %106
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x111 (or false false false)))
(let (($x1923 (not $x111)))
(and $x1923 (or $x111 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 18: function core_bench_state, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x111 (or false false false)))
(let (($x1923 (not $x111)))
(and $x1923 (or $x111 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 19: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x666 (bvadd in.01_32 (_ bv1 32))))
(let (($x409 (and (distinct ?x666 ?x666) true)))
(let (($x111 (or false false false)))
(let (($x1923 (not $x111)))
(and $x1923 (or $x111 $x409)))))))
(check-sat)
; query 20: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x666 (bvadd in.01_32 (_ bv1 32))))
(let ((?x83 (bvmul ?x666 ?x666)))
(let (($x111 (or false false false)))
(let (($x88 (or $x111 $x111 false)))
(and (not $x88) (or $x88 (and (distinct ?x83 ?x83) true))))))))
(check-sat)
; query 21: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x666 (bvadd in.01_32 (_ bv1 32))))
(let ((?x83 (bvmul ?x666 ?x666)))
(let ((?x674 (bvmul ?x83 (_ bv2 32))))
(let (($x111 (or false false false)))
(let (($x88 (or $x111 $x111 false)))
(let (($x178 (or $x88 false false)))
(and (not $x178) (or $x178 (and (distinct ?x674 ?x674) true))))))))))
(check-sat)
; query 22: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x666 (bvadd in.01_32 (_ bv1 32))))
(let ((?x83 (bvmul ?x666 ?x666)))
(let ((?x674 (bvmul ?x83 (_ bv2 32))))
(let ((?x82 (bvmul ?x674 (_ bv4 32))))
(let (($x111 (or false false false)))
(let (($x88 (or $x111 $x111 false)))
(let (($x178 (or $x88 false false)))
(let (($x99 (or $x178 false false)))
(and (not $x99) (or $x99 (and (distinct ?x82 ?x82) true))))))))))))
(check-sat)
; query 23: function core_init_matrix, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x111 (or false false false)))
(let (($x1923 (not $x111)))
(and $x1923 (or $x111 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 24: function core_init_matrix, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x111 (or false false false)))
(let (($x1923 (not $x111)))
(and $x1923 (or $x111 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 25: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x180 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x111 (or false false false)))
(let (($x1923 (not $x111)))
(and $x1923 (or $x111 (and (distinct ?x180 ?x180) true)))))))
(check-sat)
; query 26: function core_init_state, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_32 () (_ BitVec 32))
(assert
 (let (($x111 (or false false false)))
(let (($x1923 (not $x111)))
(and $x1923 (or $x111 (and (distinct (bvadd in.06_32 (_ bv1 32)) (bvadd in.06_32 (_ bv1 32))) true))))))
(check-sat)
; query 27: function core_init_state, block 65, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let (($x111 (or false false false)))
(let (($x1923 (not $x111)))
(and $x1923 (or $x111 (and (distinct (bvadd in4_32 (_ bv1 32)) (bvadd in4_32 (_ bv1 32))) true))))))
(check-sat)
; query 28: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x5413 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x111 (or false false false)))
(let (($x1923 (not $x111)))
(and $x1923 (or $x111 (and (distinct ?x5413 ?x5413) true)))))))
(check-sat)
; query 29: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x111 (or false false false)))
(let (($x1923 (not $x111)))
(and $x1923 (or $x111 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 30: function core_list_init, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x666 (bvadd in.01_32 (_ bv1 32))))
(let (($x409 (and (distinct ?x666 ?x666) true)))
(let (($x111 (or false false false)))
(let (($x1923 (not $x111)))
(and $x1923 (or $x111 $x409)))))))
(check-sat)
; query 31: function core_list_mergesort, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x666 (bvadd in.01_32 (_ bv1 32))))
(let (($x409 (and (distinct ?x666 ?x666) true)))
(let (($x3085 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x666)) true)))
(let (($x6962 (or false false (or $x3085))))
(and (not $x6962) (or $x6962 $x409)))))))
(check-sat)
; query 32: function core_list_mergesort, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.224_32 () (_ BitVec 32))
(assert
 (let ((?x2695 (ite (= (_ bv0 32) in.224_32) (_ bv1 1) (_ bv0 1))))
(let (($x111 (or false false false)))
(let (($x1923 (not $x111)))
(and $x1923 (or $x111 (and (distinct ?x2695 ?x2695) true)))))))
(check-sat)
; query 33: function core_list_mergesort, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x1220 (ite (= (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x111 (or false false false)))
(let (($x1923 (not $x111)))
(and $x1923 (or $x111 (and (distinct ?x1220 ?x1220) true)))))))
(check-sat)
; query 34: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x5691 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x5492 (or false false (or $x5691))))
(and (not $x5492) (or $x5492 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 35: function core_list_mergesort, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x7432 (and (distinct (bvmul ((_ sign_extend 32) in.020_32) ((_ sign_extend 32) (_ bv2 32))) ((_ sign_extend 32) (bvmul in.020_32 (_ bv2 32)))) true)))
(let (($x11943 (or false false (or $x7432))))
(and (not $x11943) (or $x11943 (and (distinct (bvmul in.020_32 (_ bv2 32)) (bvmul in.020_32 (_ bv2 32))) true))))))
(check-sat)
; query 36: function core_state_transition, block 102, name %103
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x57 (or false false)))
(let (($x47 (not $x57)))
(and $x47 (or $x57 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 37: function core_state_transition, block 102, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x5455 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false)))
(let (($x7026 (or $x57 false false)))
(let (($x188 (not $x7026)))
(and $x188 (or $x7026 (and (distinct ?x5455 ?x5455) true))))))))
(check-sat)
; query 38: function core_state_transition, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x57 (or false false)))
(let (($x47 (not $x57)))
(and $x47 (or $x57 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 39: function core_state_transition, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1631 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false)))
(let (($x7026 (or $x57 false false)))
(let (($x188 (not $x7026)))
(and $x188 (or $x7026 (and (distinct ?x1631 ?x1631) true))))))))
(check-sat)
; query 40: function core_state_transition, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x57 (or false false)))
(let (($x47 (not $x57)))
(and $x47 (or $x57 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 41: function core_state_transition, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x5455 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false)))
(let (($x7026 (or $x57 false false)))
(let (($x188 (not $x7026)))
(and $x188 (or $x7026 (and (distinct ?x5455 ?x5455) true))))))))
(check-sat)
; query 42: function core_state_transition, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x57 (or false false)))
(let (($x47 (not $x57)))
(and $x47 (or $x57 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 43: function core_state_transition, block 51, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x11221 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false)))
(let (($x7026 (or $x57 false false)))
(let (($x188 (not $x7026)))
(and $x188 (or $x7026 (and (distinct ?x11221 ?x11221) true))))))))
(check-sat)
; query 44: function core_state_transition, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x57 (or false false)))
(let (($x47 (not $x57)))
(and $x47 (or $x57 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 45: function core_state_transition, block 64, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x11221 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false)))
(let (($x7026 (or $x57 false false)))
(let (($x188 (not $x7026)))
(and $x188 (or $x7026 (and (distinct ?x11221 ?x11221) true))))))))
(check-sat)
; query 46: function core_state_transition, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x57 (or false false)))
(let (($x47 (not $x57)))
(and $x47 (or $x57 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 47: function core_state_transition, block 80, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x2463 (ite (= (_ bv69 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false)))
(let (($x7026 (or $x57 false false)))
(let (($x188 (not $x7026)))
(and $x188 (or $x7026 (and (distinct ?x2463 ?x2463) true))))))))
(check-sat)
; query 48: function core_state_transition, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x57 (or false false)))
(let (($x47 (not $x57)))
(and $x47 (or $x57 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 49: function core_state_transition, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x11915 (ite (= (_ bv101 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false)))
(let (($x7026 (or $x57 false false)))
(let (($x188 (not $x7026)))
(and $x188 (or $x7026 (and (distinct ?x11915 ?x11915) true))))))))
(check-sat)
; query 50: function core_state_transition, block 99, name %100
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x57 (or false false)))
(let (($x47 (not $x57)))
(and $x47 (or $x57 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 51: function core_state_transition, block 99, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1631 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false)))
(let (($x7026 (or $x57 false false)))
(let (($x188 (not $x7026)))
(and $x188 (or $x7026 (and (distinct ?x1631 ?x1631) true))))))))
(check-sat)
; query 52: function crcu8, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x57 (or false false)))
(let (($x47 (not $x57)))
(and $x47 (or $x57 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 53: function crcu8, block 29, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1864 ((_ zero_extend 16) in27_16)))
(let ((?x5683 (bvor ?x1864 (_ bv32768 32))))
(let (($x57 (or false false)))
(let (($x7026 (or $x57 false false)))
(let (($x188 (not $x7026)))
(and $x188 (or $x7026 (and (distinct ?x5683 ?x5683) true)))))))))
(check-sat)
; query 54: function crcu8, block 29, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1864 ((_ zero_extend 16) in27_16)))
(let ((?x5683 (bvor ?x1864 (_ bv32768 32))))
(let ((?x3376 ((_ extract 15 0) ?x5683)))
(let (($x57 (or false false)))
(let (($x7026 (or $x57 false false)))
(let (($x110 (or $x7026 false)))
(let (($x74 (not $x110)))
(and $x74 (or $x110 (and (distinct ?x3376 ?x3376) true)))))))))))
(check-sat)
; query 55: function crcu8, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x57 (or false false)))
(let (($x47 (not $x57)))
(and $x47 (or $x57 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 56: function crcu8, block 33, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1864 ((_ zero_extend 16) in27_16)))
(let ((?x10178 (bvand ?x1864 (_ bv32767 32))))
(let (($x57 (or false false)))
(let (($x7026 (or $x57 false false)))
(let (($x188 (not $x7026)))
(and $x188 (or $x7026 (and (distinct ?x10178 ?x10178) true)))))))))
(check-sat)
; query 57: function crcu8, block 33, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1864 ((_ zero_extend 16) in27_16)))
(let ((?x10178 (bvand ?x1864 (_ bv32767 32))))
(let ((?x10182 ((_ extract 15 0) ?x10178)))
(let (($x57 (or false false)))
(let (($x7026 (or $x57 false false)))
(let (($x110 (or $x7026 false)))
(let (($x74 (not $x110)))
(and $x74 (or $x110 (and (distinct ?x10182 ?x10182) true)))))))))))
(check-sat)
; query 58: function crcu8, block 38, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_8 () (_ BitVec 8))
(assert
 (let (($x111 (or false false false)))
(let (($x1923 (not $x111)))
(and $x1923 (or $x111 (and (distinct (bvadd in.02_8 (_ bv1 8)) (bvadd in.02_8 (_ bv1 8))) true))))))
(check-sat)
; query 59: function crcu8, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x10202 ((_ extract 7 0) in.01_16)))
(let ((?x10488 ((_ zero_extend 24) ?x10202)))
(let (($x57 (or false false)))
(let (($x10495 (or $x57 false)))
(and (not $x10495) (or $x10495 (and (distinct ?x10488 ?x10488) true))))))))
(check-sat)
; query 60: function crcu8, block 6, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x10202 ((_ extract 7 0) in.01_16)))
(let ((?x10488 ((_ zero_extend 24) ?x10202)))
(let ((?x1297 (bvand ?x10488 (_ bv1 32))))
(let (($x57 (or false false)))
(let (($x10495 (or $x57 false)))
(let (($x7539 (or $x10495 false false)))
(and (not $x7539) (or $x7539 (and (distinct ?x1297 ?x1297) true))))))))))
(check-sat)
; query 61: function crcu8, block 6, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x10202 ((_ extract 7 0) in.01_16)))
(let ((?x10488 ((_ zero_extend 24) ?x10202)))
(let ((?x1297 (bvand ?x10488 (_ bv1 32))))
(let ((?x4995 ((_ zero_extend 24) in.0_8)))
(let ((?x10713 (bvand ?x4995 (_ bv1 32))))
(let ((?x10485 (bvxor ?x10713 ?x1297)))
(let (($x57 (or false false)))
(let (($x10495 (or $x57 false)))
(let (($x7539 (or $x10495 false false)))
(let (($x7026 (or $x57 false false)))
(let (($x4271 (or $x7026 $x7539 false)))
(and (not $x4271) (or $x4271 (and (distinct ?x10485 ?x10485) true)))))))))))))))
(check-sat)
; query 62: function crcu8, block 6, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x10202 ((_ extract 7 0) in.01_16)))
(let ((?x10488 ((_ zero_extend 24) ?x10202)))
(let ((?x1297 (bvand ?x10488 (_ bv1 32))))
(let ((?x4995 ((_ zero_extend 24) in.0_8)))
(let ((?x10713 (bvand ?x4995 (_ bv1 32))))
(let ((?x10485 (bvxor ?x10713 ?x1297)))
(let ((?x2605 ((_ extract 7 0) ?x10485)))
(let (($x57 (or false false)))
(let (($x10495 (or $x57 false)))
(let (($x7539 (or $x10495 false false)))
(let (($x7026 (or $x57 false false)))
(let (($x4271 (or $x7026 $x7539 false)))
(let (($x10813 (or $x4271 false)))
(and (not $x10813) (or $x10813 (and (distinct ?x2605 ?x2605) true)))))))))))))))))
(check-sat)
; query 63: function crcu8, block 6, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x57 (or false false)))
(let (($x47 (not $x57)))
(and $x47 (or $x57 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 64: function crcu8, block 6, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x4995 ((_ zero_extend 24) in.0_8)))
(let ((?x5430 (bvashr ?x4995 (_ bv1 32))))
(let (($x57 (or false false)))
(let (($x7026 (or $x57 false false)))
(let (($x4043 (or $x7026 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not $x4043) (or $x4043 (and (distinct ?x5430 ?x5430) true)))))))))
(check-sat)
; query 65: function crcu8, block 6, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x4995 ((_ zero_extend 24) in.0_8)))
(let ((?x5430 (bvashr ?x4995 (_ bv1 32))))
(let ((?x10490 ((_ extract 7 0) ?x5430)))
(let (($x57 (or false false)))
(let (($x7026 (or $x57 false false)))
(let (($x4043 (or $x7026 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x1729 (or $x4043 false)))
(and (not $x1729) (or $x1729 (and (distinct ?x10490 ?x10490) true)))))))))))
(check-sat)
; query 66: function crcu8, block 6, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x10202 ((_ extract 7 0) in.01_16)))
(let ((?x10488 ((_ zero_extend 24) ?x10202)))
(let ((?x1297 (bvand ?x10488 (_ bv1 32))))
(let ((?x4995 ((_ zero_extend 24) in.0_8)))
(let ((?x10713 (bvand ?x4995 (_ bv1 32))))
(let ((?x10485 (bvxor ?x10713 ?x1297)))
(let ((?x2605 ((_ extract 7 0) ?x10485)))
(let ((?x1600 ((_ zero_extend 24) ?x2605)))
(let (($x57 (or false false)))
(let (($x10495 (or $x57 false)))
(let (($x7539 (or $x10495 false false)))
(let (($x7026 (or $x57 false false)))
(let (($x4271 (or $x7026 $x7539 false)))
(let (($x10813 (or $x4271 false)))
(let (($x4245 (or $x10813 false)))
(and (not $x4245) (or $x4245 (and (distinct ?x1600 ?x1600) true)))))))))))))))))))
(check-sat)
; query 67: function crcu8, block 6, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x10202 ((_ extract 7 0) in.01_16)))
(let ((?x10488 ((_ zero_extend 24) ?x10202)))
(let ((?x1297 (bvand ?x10488 (_ bv1 32))))
(let ((?x4995 ((_ zero_extend 24) in.0_8)))
(let ((?x10713 (bvand ?x4995 (_ bv1 32))))
(let ((?x10485 (bvxor ?x10713 ?x1297)))
(let ((?x2605 ((_ extract 7 0) ?x10485)))
(let ((?x1600 ((_ zero_extend 24) ?x2605)))
(let ((?x10990 (ite (= (_ bv1 32) ?x1600) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false)))
(let (($x10495 (or $x57 false)))
(let (($x7539 (or $x10495 false false)))
(let (($x7026 (or $x57 false false)))
(let (($x4271 (or $x7026 $x7539 false)))
(let (($x10813 (or $x4271 false)))
(let (($x4245 (or $x10813 false)))
(let (($x10899 (or $x4245 false false)))
(and (not $x10899) (or $x10899 (and (distinct ?x10990 ?x10990) true)))))))))))))))))))))
(check-sat)
; query 68: function crcu8, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x57 (or false false)))
(let (($x47 (not $x57)))
(and $x47 (or $x57 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 69: function crcu8, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x4995 ((_ zero_extend 24) in.0_8)))
(let ((?x10713 (bvand ?x4995 (_ bv1 32))))
(let (($x57 (or false false)))
(let (($x7026 (or $x57 false false)))
(let (($x188 (not $x7026)))
(and $x188 (or $x7026 (and (distinct ?x10713 ?x10713) true)))))))))
(check-sat)
; query 70: function crcu8, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x57 (or false false)))
(let (($x47 (not $x57)))
(and $x47 (or $x57 (and (distinct ((_ extract 7 0) in.01_16) ((_ extract 7 0) in.01_16)) true))))))
(check-sat)
; query 71: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1649 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x3253 ((_ zero_extend 31) ?x1649)))
(let ((?x1152 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x4516 ((_ zero_extend 31) ?x1152)))
(let ((?x6260 (bvand ?x4516 ?x3253)))
(let ((?x4377 (ite (and (distinct (_ bv0 32) ?x6260) true) (_ bv1 1) (_ bv0 1))))
(let ((?x6240 ((_ zero_extend 63) ?x4377)))
(let (($x57 (or false false)))
(let (($x7026 (or $x57 false false)))
(let (($x110 (or $x7026 false)))
(let (($x3077 (or $x110 $x110 false)))
(let (($x5568 (or $x3077 false false)))
(let (($x2208 (or $x5568 false)))
(and (not $x2208) (or $x2208 (and (distinct ?x6240 ?x6240) true)))))))))))))))))
(check-sat)
; query 72: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1649 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x3253 ((_ zero_extend 31) ?x1649)))
(let ((?x1152 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x4516 ((_ zero_extend 31) ?x1152)))
(let ((?x6260 (bvand ?x4516 ?x3253)))
(let ((?x4377 (ite (and (distinct (_ bv0 32) ?x6260) true) (_ bv1 1) (_ bv0 1))))
(let (($x513 (= (_ bv1 1) ?x4377)))
(let ((?x7198 (ite $x513 (_ bv1 32) (_ bv0 32))))
(let (($x57 (or false false)))
(let (($x7026 (or $x57 false false)))
(let (($x110 (or $x7026 false)))
(let (($x3077 (or $x110 $x110 false)))
(let (($x5568 (or $x3077 false false)))
(let (($x4891 (or $x5568 (ite $x513 false false))))
(and (not $x4891) (or $x4891 (and (distinct ?x7198 ?x7198) true))))))))))))))))))
(check-sat)
; query 73: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1649 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x3253 ((_ zero_extend 31) ?x1649)))
(let ((?x1152 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x4516 ((_ zero_extend 31) ?x1152)))
(let ((?x6260 (bvand ?x4516 ?x3253)))
(let ((?x4377 (ite (and (distinct (_ bv0 32) ?x6260) true) (_ bv1 1) (_ bv0 1))))
(let (($x513 (= (_ bv1 1) ?x4377)))
(let ((?x7198 (ite $x513 (_ bv1 32) (_ bv0 32))))
(let ((?x2819 ((_ extract 7 0) ?x7198)))
(let (($x57 (or false false)))
(let (($x7026 (or $x57 false false)))
(let (($x110 (or $x7026 false)))
(let (($x3077 (or $x110 $x110 false)))
(let (($x5568 (or $x3077 false false)))
(let (($x4891 (or $x5568 (ite $x513 false false))))
(let (($x3820 (or $x4891 false)))
(and (not $x3820) (or $x3820 (and (distinct ?x2819 ?x2819) true))))))))))))))))))))
(check-sat)
; query 74: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x57 (or false false)))
(let (($x47 (not $x57)))
(and $x47 (or $x57 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 75: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1152 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false)))
(let (($x7026 (or $x57 false false)))
(let (($x188 (not $x7026)))
(and $x188 (or $x7026 (and (distinct ?x1152 ?x1152) true))))))))
(check-sat)
; query 76: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1152 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x4516 ((_ zero_extend 31) ?x1152)))
(let (($x57 (or false false)))
(let (($x7026 (or $x57 false false)))
(let (($x110 (or $x7026 false)))
(let (($x74 (not $x110)))
(and $x74 (or $x110 (and (distinct ?x4516 ?x4516) true))))))))))
(check-sat)
; query 77: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x57 (or false false)))
(let (($x47 (not $x57)))
(and $x47 (or $x57 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 78: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1649 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false)))
(let (($x7026 (or $x57 false false)))
(let (($x188 (not $x7026)))
(and $x188 (or $x7026 (and (distinct ?x1649 ?x1649) true))))))))
(check-sat)
; query 79: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1649 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x3253 ((_ zero_extend 31) ?x1649)))
(let (($x57 (or false false)))
(let (($x7026 (or $x57 false false)))
(let (($x110 (or $x7026 false)))
(let (($x74 (not $x110)))
(and $x74 (or $x110 (and (distinct ?x3253 ?x3253) true))))))))))
(check-sat)
; query 80: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1649 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x3253 ((_ zero_extend 31) ?x1649)))
(let ((?x1152 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x4516 ((_ zero_extend 31) ?x1152)))
(let ((?x6260 (bvand ?x4516 ?x3253)))
(let (($x57 (or false false)))
(let (($x7026 (or $x57 false false)))
(let (($x110 (or $x7026 false)))
(let (($x3077 (or $x110 $x110 false)))
(and (not $x3077) (or $x3077 (and (distinct ?x6260 ?x6260) true)))))))))))))
(check-sat)
; query 81: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1649 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x3253 ((_ zero_extend 31) ?x1649)))
(let ((?x1152 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x4516 ((_ zero_extend 31) ?x1152)))
(let ((?x6260 (bvand ?x4516 ?x3253)))
(let ((?x4377 (ite (and (distinct (_ bv0 32) ?x6260) true) (_ bv1 1) (_ bv0 1))))
(let (($x57 (or false false)))
(let (($x7026 (or $x57 false false)))
(let (($x110 (or $x7026 false)))
(let (($x3077 (or $x110 $x110 false)))
(let (($x5568 (or $x3077 false false)))
(and (not $x5568) (or $x5568 (and (distinct ?x4377 ?x4377) true)))))))))))))))
(check-sat)
; query 82: function matrix_add_const, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x111 (or false false false)))
(let (($x1923 (not $x111)))
(and $x1923 (or $x111 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 83: function matrix_add_const, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x666 (bvadd in.01_32 (_ bv1 32))))
(let (($x409 (and (distinct ?x666 ?x666) true)))
(let (($x111 (or false false false)))
(let (($x1923 (not $x111)))
(and $x1923 (or $x111 $x409)))))))
(check-sat)
; query 84: function matrix_mul_const, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x111 (or false false false)))
(let (($x1923 (not $x111)))
(and $x1923 (or $x111 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 85: function matrix_mul_const, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x666 (bvadd in.01_32 (_ bv1 32))))
(let (($x409 (and (distinct ?x666 ?x666) true)))
(let (($x111 (or false false false)))
(let (($x1923 (not $x111)))
(and $x1923 (or $x111 $x409)))))))
(check-sat)
; query 86: function matrix_mul_matrix, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x111 (or false false false)))
(let (($x1923 (not $x111)))
(and $x1923 (or $x111 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 87: function matrix_mul_matrix, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x666 (bvadd in.01_32 (_ bv1 32))))
(let (($x409 (and (distinct ?x666 ?x666) true)))
(let (($x111 (or false false false)))
(let (($x1923 (not $x111)))
(and $x1923 (or $x111 $x409)))))))
(check-sat)
; query 88: function matrix_mul_matrix, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x111 (or false false false)))
(let (($x1923 (not $x111)))
(and $x1923 (or $x111 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 89: function matrix_mul_matrix_bitextract, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x111 (or false false false)))
(let (($x1923 (not $x111)))
(and $x1923 (or $x111 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 90: function matrix_mul_matrix_bitextract, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x666 (bvadd in.01_32 (_ bv1 32))))
(let (($x409 (and (distinct ?x666 ?x666) true)))
(let (($x111 (or false false false)))
(let (($x1923 (not $x111)))
(and $x1923 (or $x111 $x409)))))))
(check-sat)
; query 91: function matrix_mul_matrix_bitextract, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x111 (or false false false)))
(let (($x1923 (not $x111)))
(and $x1923 (or $x111 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 92: function matrix_mul_vect, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x111 (or false false false)))
(let (($x1923 (not $x111)))
(and $x1923 (or $x111 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 93: function matrix_mul_vect, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x666 (bvadd in.01_32 (_ bv1 32))))
(let (($x409 (and (distinct ?x666 ?x666) true)))
(let (($x111 (or false false false)))
(let (($x1923 (not $x111)))
(and $x1923 (or $x111 $x409)))))))
(check-sat)
; query 94: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x57 (or false false)))
(let (($x47 (not $x57)))
(and $x47 (or $x57 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 95: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x3162 ((_ sign_extend 16) in.1_16)))
(let ((?x10487 (bvadd ?x3162 (_ bv10 32))))
(let (($x10180 (and (distinct (bvadd ((_ sign_extend 1) ?x3162) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x10487)) true)))
(let (($x57 (or false false)))
(let (($x10718 (or $x57 false (or $x10180))))
(and (not $x10718) (or $x10718 (and (distinct ?x10487 ?x10487) true)))))))))
(check-sat)
; query 96: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x3162 ((_ sign_extend 16) in.1_16)))
(let ((?x10487 (bvadd ?x3162 (_ bv10 32))))
(let ((?x10714 ((_ extract 15 0) ?x10487)))
(let (($x10180 (and (distinct (bvadd ((_ sign_extend 1) ?x3162) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x10487)) true)))
(let (($x57 (or false false)))
(let (($x10718 (or $x57 false (or $x10180))))
(let (($x10715 (or $x10718 false)))
(and (not $x10715) (or $x10715 (and (distinct ?x10714 ?x10714) true)))))))))))
(check-sat)
; query 97: function matrix_sum, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x11902 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x111 (or false false false)))
(let (($x1923 (not $x111)))
(and $x1923 (or $x111 (and (distinct ?x11902 ?x11902) true)))))))
(check-sat)
; query 98: function matrix_sum, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x11902 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let ((?x11891 ((_ zero_extend 63) ?x11902)))
(let (($x111 (or false false false)))
(let (($x10875 (or $x111 false)))
(and (not $x10875) (or $x10875 (and (distinct ?x11891 ?x11891) true))))))))
(check-sat)
; query 99: function matrix_sum, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x11902 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x10983 (= (_ bv1 1) ?x11902)))
(let ((?x10836 (ite $x10983 (_ bv1 32) (_ bv0 32))))
(let (($x111 (or false false false)))
(let (($x11900 (or $x111 (ite $x10983 false false))))
(and (not $x11900) (or $x11900 (and (distinct ?x10836 ?x10836) true)))))))))
(check-sat)
; query 100: function matrix_sum, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x57 (or false false)))
(let (($x47 (not $x57)))
(and $x47 (or $x57 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 101: function matrix_sum, block 22, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x11902 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x10983 (= (_ bv1 1) ?x11902)))
(let ((?x10836 (ite $x10983 (_ bv1 32) (_ bv0 32))))
(let ((?x3162 ((_ sign_extend 16) in.1_16)))
(let ((?x11911 (bvadd ?x3162 ?x10836)))
(let (($x11899 (and (distinct (bvadd ((_ sign_extend 1) ?x3162) ((_ sign_extend 1) ?x10836)) ((_ sign_extend 1) ?x11911)) true)))
(let (($x111 (or false false false)))
(let (($x11900 (or $x111 (ite $x10983 false false))))
(let (($x57 (or false false)))
(let (($x11382 (or $x57 $x11900 (or $x11899))))
(and (not $x11382) (or $x11382 (and (distinct ?x11911 ?x11911) true))))))))))))))
(check-sat)
; query 102: function matrix_sum, block 22, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x11902 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x10983 (= (_ bv1 1) ?x11902)))
(let ((?x10836 (ite $x10983 (_ bv1 32) (_ bv0 32))))
(let ((?x3162 ((_ sign_extend 16) in.1_16)))
(let ((?x11911 (bvadd ?x3162 ?x10836)))
(let ((?x2845 ((_ extract 15 0) ?x11911)))
(let (($x11899 (and (distinct (bvadd ((_ sign_extend 1) ?x3162) ((_ sign_extend 1) ?x10836)) ((_ sign_extend 1) ?x11911)) true)))
(let (($x111 (or false false false)))
(let (($x11900 (or $x111 (ite $x10983 false false))))
(let (($x57 (or false false)))
(let (($x11382 (or $x57 $x11900 (or $x11899))))
(let (($x11876 (or $x11382 false)))
(and (not $x11876) (or $x11876 (and (distinct ?x2845 ?x2845) true))))))))))))))))
(check-sat)
; query 103: function matrix_sum, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x111 (or false false false)))
(let (($x1923 (not $x111)))
(and $x1923 (or $x111 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 104: function matrix_sum, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x666 (bvadd in.01_32 (_ bv1 32))))
(let (($x409 (and (distinct ?x666 ?x666) true)))
(let (($x111 (or false false false)))
(let (($x1923 (not $x111)))
(and $x1923 (or $x111 $x409)))))))
(check-sat)
; query 105: function partition_memory, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x111 (or false false false)))
(let (($x1923 (not $x111)))
(and $x1923 (or $x111 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 106: function run_matrix_multiply, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x111 (or false false false)))
(let (($x1923 (not $x111)))
(and $x1923 (or $x111 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 107: function run_matrix_multiply, block 34, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x666 (bvadd in.01_32 (_ bv1 32))))
(let (($x409 (and (distinct ?x666 ?x666) true)))
(let (($x111 (or false false false)))
(let (($x1923 (not $x111)))
(and $x1923 (or $x111 $x409)))))))
(check-sat)
