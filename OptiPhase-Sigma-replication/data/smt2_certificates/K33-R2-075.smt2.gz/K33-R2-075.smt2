; OptiPhase-Sigma refinement certificate for sweep K33-R2-075
; query 0: function corner_draw, block 11, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x124 (ite (= (_ bv0 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x39 (or false false false)))
(let (($x103 (not $x39)))
(and $x103 (or $x39 (and (distinct ?x124 ?x124) true)))))))
(check-sat)
; query 1: function edge_draw, block 39, name %40
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x10 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x140 (or false false (or $x10))))
(and (not $x140) (or $x140 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function edge_draw, block 57, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x126 (and (distinct (bvadd ((_ sign_extend 1) in.12_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.12_32 (_ bv1 32)))) true)))
(let (($x117 (or false false (or $x126))))
(and (not $x117) (or $x117 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 3: function edge_draw, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let ((?x11 (ite (= (_ bv0 32) in4_32) (_ bv1 1) (_ bv0 1))))
(let (($x39 (or false false false)))
(let (($x103 (not $x39)))
(and $x103 (or $x39 (and (distinct ?x11 ?x11) true)))))))
(check-sat)
; query 4: function enlarge, block 106, name %107
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x79 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x339 (or false false (or $x79))))
(and (not $x339) (or $x339 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 5: function enlarge, block 158, name %159
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x48 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x171 (or false false (or $x48))))
(and (not $x171) (or $x171 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 6: function enlarge, block 161, name %162
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let (($x74 (and (distinct (bvadd ((_ sign_extend 1) in.2_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.2_32 (_ bv1 32)))) true)))
(let (($x72 (or false false (or $x74))))
(and (not $x72) (or $x72 (and (distinct (bvadd in.2_32 (_ bv1 32)) (bvadd in.2_32 (_ bv1 32))) true))))))
(check-sat)
; query 7: function enlarge, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x10 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x140 (or false false (or $x10))))
(and (not $x140) (or $x140 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function getint, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x161 (ite (bvsle (_ bv48 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x39 (or false false false)))
(let (($x103 (not $x39)))
(and $x103 (or $x39 (and (distinct ?x161 ?x161) true)))))))
(check-sat)
; query 9: function getint, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x123 (ite (bvsge (_ bv57 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x39 (or false false false)))
(let (($x103 (not $x39)))
(and $x103 (or $x39 (and (distinct ?x123 ?x123) true)))))))
(check-sat)
; query 10: function getint, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in26_32 () (_ BitVec 32))
(assert
 (let ((?x99 (ite (bvsgt (_ bv48 32) in26_32) (_ bv1 1) (_ bv0 1))))
(let (($x39 (or false false false)))
(let (($x103 (not $x39)))
(and $x103 (or $x39 (and (distinct ?x99 ?x99) true)))))))
(check-sat)
; query 11: function getint, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in26_32 () (_ BitVec 32))
(assert
 (let ((?x76 (ite (bvslt (_ bv57 32) in26_32) (_ bv1 1) (_ bv0 1))))
(let (($x39 (or false false false)))
(let (($x103 (not $x39)))
(and $x103 (or $x39 (and (distinct ?x76 ?x76) true)))))))
(check-sat)
; query 12: function getint, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x524 (ite (= (_ bv4294967295 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x39 (or false false false)))
(let (($x103 (not $x39)))
(and $x103 (or $x39 (and (distinct ?x524 ?x524) true)))))))
(check-sat)
; query 13: function int_to_uchar, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_32 () (_ BitVec 32))
(assert
 (let (($x308 (and (distinct (bvadd ((_ sign_extend 1) in.03_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.03_32 (_ bv1 32)))) true)))
(let (($x268 (or false false (or $x308))))
(and (not $x268) (or $x268 (and (distinct (bvadd in.03_32 (_ bv1 32)) (bvadd in.03_32 (_ bv1 32))) true))))))
(check-sat)
; query 14: function int_to_uchar, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.14_32 () (_ BitVec 32))
(assert
 (let (($x382 (and (distinct (bvadd ((_ sign_extend 1) in.14_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.14_32 (_ bv1 32)))) true)))
(let (($x321 (or false false (or $x382))))
(and (not $x321) (or $x321 (and (distinct (bvadd in.14_32 (_ bv1 32)) (bvadd in.14_32 (_ bv1 32))) true))))))
(check-sat)
; query 15: function main, block 35, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x131 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x604 (or false false (or $x131))))
(and (not $x604) (or $x604 (and (distinct (bvadd in.020_32 (_ bv1 32)) (bvadd in.020_32 (_ bv1 32))) true))))))
(check-sat)
; query 16: function main, block 35, name %37
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let ((?x374 (ite (bvsge (bvadd in.020_32 (_ bv1 32)) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x131 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x604 (or false false (or $x131))))
(let (($x508 (or $x604 false false)))
(and (not $x508) (or $x508 (and (distinct ?x374 ?x374) true))))))))
(check-sat)
; query 17: function main, block 49, name %50
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x131 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x604 (or false false (or $x131))))
(and (not $x604) (or $x604 (and (distinct (bvadd in.020_32 (_ bv1 32)) (bvadd in.020_32 (_ bv1 32))) true))))))
(check-sat)
; query 18: function main, block 49, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let ((?x374 (ite (bvsge (bvadd in.020_32 (_ bv1 32)) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x131 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x604 (or false false (or $x131))))
(let (($x508 (or $x604 false false)))
(and (not $x508) (or $x508 (and (distinct ?x374 ?x374) true))))))))
(check-sat)
; query 19: function median, block 103, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x48 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x171 (or false false (or $x48))))
(and (not $x171) (or $x171 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 20: function median, block 106, name %107
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x10 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x140 (or false false (or $x10))))
(and (not $x140) (or $x140 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 21: function setup_brightness_lut, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x10 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x140 (or false false (or $x10))))
(and (not $x140) (or $x140 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 22: function susan_corners, block 1066, name %1067
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x48 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x171 (or false false (or $x48))))
(and (not $x171) (or $x171 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 23: function susan_corners, block 1069, name %1070
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x10 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x140 (or false false (or $x10))))
(and (not $x140) (or $x140 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 24: function susan_corners, block 1549, name %1550
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x79 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x339 (or false false (or $x79))))
(and (not $x339) (or $x339 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 25: function susan_corners, block 1552, name %1553
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x126 (and (distinct (bvadd ((_ sign_extend 1) in.12_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.12_32 (_ bv1 32)))) true)))
(let (($x117 (or false false (or $x126))))
(and (not $x117) (or $x117 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 26: function susan_corners, block 845, name %846
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in839_32 () (_ BitVec 32))
(declare-fun in840_32 () (_ BitVec 32))
(assert
 (let ((?x458 (ite (bvslt in840_32 in839_32) (_ bv1 1) (_ bv0 1))))
(let (($x39 (or false false false)))
(let (($x103 (not $x39)))
(and $x103 (or $x39 (and (distinct ?x458 ?x458) true)))))))
(check-sat)
; query 27: function susan_corners_quick, block 1469, name %1470
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x79 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x339 (or false false (or $x79))))
(and (not $x339) (or $x339 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 28: function susan_corners_quick, block 1472, name %1473
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x126 (and (distinct (bvadd ((_ sign_extend 1) in.12_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.12_32 (_ bv1 32)))) true)))
(let (($x117 (or false false (or $x126))))
(and (not $x117) (or $x117 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 29: function susan_corners_quick, block 433, name %434
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x48 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x171 (or false false (or $x48))))
(and (not $x171) (or $x171 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 30: function susan_corners_quick, block 436, name %437
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x10 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x140 (or false false (or $x10))))
(and (not $x140) (or $x140 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 31: function susan_edges, block 1432, name %1433
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1417_32 () (_ BitVec 32))
(assert
 (let ((?x290 (ite (bvslt (_ bv0 32) in1417_32) (_ bv1 1) (_ bv0 1))))
(let (($x39 (or false false false)))
(let (($x103 (not $x39)))
(and $x103 (or $x39 (and (distinct ?x290 ?x290) true)))))))
(check-sat)
; query 32: function susan_edges, block 1486, name %1487
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.116_32 () (_ BitVec 32))
(assert
 (let (($x515 (and (distinct (bvadd ((_ sign_extend 1) in.116_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.116_32 (_ bv1 32)))) true)))
(let (($x118 (or false false (or $x515))))
(and (not $x118) (or $x118 (and (distinct (bvadd in.116_32 (_ bv1 32)) (bvadd in.116_32 (_ bv1 32))) true))))))
(check-sat)
; query 33: function susan_edges, block 1489, name %1490
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.114_32 () (_ BitVec 32))
(assert
 (let (($x127 (and (distinct (bvadd ((_ sign_extend 1) in.114_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.114_32 (_ bv1 32)))) true)))
(let (($x286 (or false false (or $x127))))
(and (not $x286) (or $x286 (and (distinct (bvadd in.114_32 (_ bv1 32)) (bvadd in.114_32 (_ bv1 32))) true))))))
(check-sat)
; query 34: function susan_edges, block 379, name %380
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.015_32 () (_ BitVec 32))
(assert
 (let (($x90 (and (distinct (bvadd ((_ sign_extend 1) in.015_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.015_32 (_ bv1 32)))) true)))
(let (($x645 (or false false (or $x90))))
(and (not $x645) (or $x645 (and (distinct (bvadd in.015_32 (_ bv1 32)) (bvadd in.015_32 (_ bv1 32))) true))))))
(check-sat)
; query 35: function susan_edges, block 382, name %383
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.013_32 () (_ BitVec 32))
(assert
 (let (($x334 (and (distinct (bvadd ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.013_32 (_ bv1 32)))) true)))
(let (($x613 (or false false (or $x334))))
(and (not $x613) (or $x613 (and (distinct (bvadd in.013_32 (_ bv1 32)) (bvadd in.013_32 (_ bv1 32))) true))))))
(check-sat)
; query 36: function susan_edges, block 850, name %851
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in834_32 () (_ BitVec 32))
(assert
 (let ((?x207 (ite (= (_ bv0 32) in834_32) (_ bv1 1) (_ bv0 1))))
(let (($x39 (or false false false)))
(let (($x103 (not $x39)))
(and $x103 (or $x39 (and (distinct ?x207 ?x207) true)))))))
(check-sat)
; query 37: function susan_edges, block 870, name %871
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x221 (ite (bvslt (_ bv0 32) in.0_32) (_ bv1 1) (_ bv0 1))))
(let (($x39 (or false false false)))
(let (($x103 (not $x39)))
(and $x103 (or $x39 (and (distinct ?x221 ?x221) true)))))))
(check-sat)
; query 38: function susan_edges_small, block 119, name %120
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.09_32 () (_ BitVec 32))
(assert
 (let (($x536 (and (distinct (bvadd ((_ sign_extend 1) in.09_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.09_32 (_ bv1 32)))) true)))
(let (($x238 (or false false (or $x536))))
(and (not $x238) (or $x238 (and (distinct (bvadd in.09_32 (_ bv1 32)) (bvadd in.09_32 (_ bv1 32))) true))))))
(check-sat)
; query 39: function susan_edges_small, block 122, name %123
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.07_32 () (_ BitVec 32))
(assert
 (let (($x459 (and (distinct (bvadd ((_ sign_extend 1) in.07_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.07_32 (_ bv1 32)))) true)))
(let (($x132 (or false false (or $x459))))
(and (not $x132) (or $x132 (and (distinct (bvadd in.07_32 (_ bv1 32)) (bvadd in.07_32 (_ bv1 32))) true))))))
(check-sat)
; query 40: function susan_edges_small, block 258, name %259
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in243_32 () (_ BitVec 32))
(assert
 (let ((?x642 (ite (= (_ bv0 32) in243_32) (_ bv1 1) (_ bv0 1))))
(let (($x39 (or false false false)))
(let (($x103 (not $x39)))
(and $x103 (or $x39 (and (distinct ?x642 ?x642) true)))))))
(check-sat)
; query 41: function susan_edges_small, block 278, name %279
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x221 (ite (bvslt (_ bv0 32) in.0_32) (_ bv1 1) (_ bv0 1))))
(let (($x39 (or false false false)))
(let (($x103 (not $x39)))
(and $x103 (or $x39 (and (distinct ?x221 ?x221) true)))))))
(check-sat)
; query 42: function susan_edges_small, block 426, name %427
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in411_32 () (_ BitVec 32))
(assert
 (let ((?x148 (ite (bvslt (_ bv0 32) in411_32) (_ bv1 1) (_ bv0 1))))
(let (($x39 (or false false false)))
(let (($x103 (not $x39)))
(and $x103 (or $x39 (and (distinct ?x148 ?x148) true)))))))
(check-sat)
; query 43: function susan_edges_small, block 458, name %459
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.110_32 () (_ BitVec 32))
(assert
 (let (($x529 (and (distinct (bvadd ((_ sign_extend 1) in.110_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.110_32 (_ bv1 32)))) true)))
(let (($x612 (or false false (or $x529))))
(and (not $x612) (or $x612 (and (distinct (bvadd in.110_32 (_ bv1 32)) (bvadd in.110_32 (_ bv1 32))) true))))))
(check-sat)
; query 44: function susan_edges_small, block 461, name %462
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.18_32 () (_ BitVec 32))
(assert
 (let (($x385 (and (distinct (bvadd ((_ sign_extend 1) in.18_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.18_32 (_ bv1 32)))) true)))
(let (($x528 (or false false (or $x385))))
(and (not $x528) (or $x528 (and (distinct (bvadd in.18_32 (_ bv1 32)) (bvadd in.18_32 (_ bv1 32))) true))))))
(check-sat)
; query 45: function susan_principle, block 378, name %379
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x48 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x171 (or false false (or $x48))))
(and (not $x171) (or $x171 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 46: function susan_principle, block 381, name %382
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x10 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x140 (or false false (or $x10))))
(and (not $x140) (or $x140 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 47: function susan_principle_small, block 118, name %119
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x48 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x171 (or false false (or $x48))))
(and (not $x171) (or $x171 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 48: function susan_principle_small, block 121, name %122
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x10 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x140 (or false false (or $x10))))
(and (not $x140) (or $x140 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 49: function susan_smoothing, block 123, name %124
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.09_32 () (_ BitVec 32))
(assert
 (let (($x315 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in.09_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in.09_32))) true)))
(let (($x276 (or false false (or $x315))))
(and (not $x276) (or $x276 (and (distinct (bvsub (_ bv0 32) in.09_32) (bvsub (_ bv0 32) in.09_32)) true))))))
(check-sat)
; query 50: function susan_smoothing, block 143, name %144
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.016_32 () (_ BitVec 32))
(assert
 (let (($x376 (and (distinct (bvadd ((_ sign_extend 1) in.016_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.016_32 (_ bv1 32)))) true)))
(let (($x179 (or false false (or $x376))))
(and (not $x179) (or $x179 (and (distinct (bvadd in.016_32 (_ bv1 32)) (bvadd in.016_32 (_ bv1 32))) true))))))
(check-sat)
; query 51: function susan_smoothing, block 148, name %149
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.017_32 () (_ BitVec 32))
(assert
 (let (($x794 (and (distinct (bvadd ((_ sign_extend 1) in.017_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.017_32 (_ bv1 32)))) true)))
(let (($x293 (or false false (or $x794))))
(and (not $x293) (or $x293 (and (distinct (bvadd in.017_32 (_ bv1 32)) (bvadd in.017_32 (_ bv1 32))) true))))))
(check-sat)
; query 52: function susan_smoothing, block 165, name %166
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.114_32 () (_ BitVec 32))
(assert
 (let (($x127 (and (distinct (bvadd ((_ sign_extend 1) in.114_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.114_32 (_ bv1 32)))) true)))
(let (($x286 (or false false (or $x127))))
(and (not $x286) (or $x286 (and (distinct (bvadd in.114_32 (_ bv1 32)) (bvadd in.114_32 (_ bv1 32))) true))))))
(check-sat)
; query 53: function susan_smoothing, block 168, name %169
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.111_32 () (_ BitVec 32))
(assert
 (let (($x392 (and (distinct (bvadd ((_ sign_extend 1) in.111_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.111_32 (_ bv1 32)))) true)))
(let (($x851 (or false false (or $x392))))
(and (not $x851) (or $x851 (and (distinct (bvadd in.111_32 (_ bv1 32)) (bvadd in.111_32 (_ bv1 32))) true))))))
(check-sat)
; query 54: function susan_smoothing, block 21, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x446 (ite (= (_ bv0 32) (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x39 (or false false false)))
(let (($x103 (not $x39)))
(and $x103 (or $x39 (and (distinct ?x446 ?x446) true)))))))
(check-sat)
; query 55: function susan_smoothing, block 319, name %320
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.215_32 () (_ BitVec 32))
(assert
 (let (($x577 (and (distinct (bvadd ((_ sign_extend 1) in.215_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.215_32 (_ bv1 32)))) true)))
(let (($x643 (or false false (or $x577))))
(and (not $x643) (or $x643 (and (distinct (bvadd in.215_32 (_ bv1 32)) (bvadd in.215_32 (_ bv1 32))) true))))))
(check-sat)
; query 56: function susan_smoothing, block 322, name %323
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.212_32 () (_ BitVec 32))
(assert
 (let (($x169 (and (distinct (bvadd ((_ sign_extend 1) in.212_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.212_32 (_ bv1 32)))) true)))
(let (($x371 (or false false (or $x169))))
(and (not $x371) (or $x371 (and (distinct (bvadd in.212_32 (_ bv1 32)) (bvadd in.212_32 (_ bv1 32))) true))))))
(check-sat)
; query 57: function susan_smoothing, block 67, name %68
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.09_32 () (_ BitVec 32))
(assert
 (let (($x315 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in.09_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in.09_32))) true)))
(let (($x276 (or false false (or $x315))))
(and (not $x276) (or $x276 (and (distinct (bvsub (_ bv0 32) in.09_32) (bvsub (_ bv0 32) in.09_32)) true))))))
(check-sat)
; query 58: function susan_smoothing, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.013_32 () (_ BitVec 32))
(assert
 (let (($x334 (and (distinct (bvadd ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.013_32 (_ bv1 32)))) true)))
(let (($x613 (or false false (or $x334))))
(and (not $x613) (or $x613 (and (distinct (bvadd in.013_32 (_ bv1 32)) (bvadd in.013_32 (_ bv1 32))) true))))))
(check-sat)
; query 59: function susan_smoothing, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.010_32 () (_ BitVec 32))
(assert
 (let (($x977 (and (distinct (bvadd ((_ sign_extend 1) in.010_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.010_32 (_ bv1 32)))) true)))
(let (($x101 (or false false (or $x977))))
(and (not $x101) (or $x101 (and (distinct (bvadd in.010_32 (_ bv1 32)) (bvadd in.010_32 (_ bv1 32))) true))))))
(check-sat)
; query 60: function susan_thin, block 100, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in93_32 () (_ BitVec 32))
(assert
 (let ((?x759 (ite (= (_ bv1 32) in93_32) (_ bv1 1) (_ bv0 1))))
(let (($x39 (or false false false)))
(let (($x103 (not $x39)))
(and $x103 (or $x39 (and (distinct ?x759 ?x759) true)))))))
(check-sat)
; query 61: function susan_thin, block 428, name %429
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.022_32 () (_ BitVec 32))
(assert
 (let (($x306 (and (distinct (bvadd ((_ sign_extend 1) in.022_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.022_32 (_ bv1 32)))) true)))
(let (($x97 (or false false (or $x306))))
(and (not $x97) (or $x97 (and (distinct (bvadd in.022_32 (_ bv1 32)) (bvadd in.022_32 (_ bv1 32))) true))))))
(check-sat)
; query 62: function susan_thin, block 431, name %432
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.018_32 () (_ BitVec 32))
(assert
 (let (($x767 (and (distinct (bvadd ((_ sign_extend 1) in.018_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.018_32 (_ bv1 32)))) true)))
(let (($x356 (or false false (or $x767))))
(and (not $x356) (or $x356 (and (distinct (bvadd in.018_32 (_ bv1 32)) (bvadd in.018_32 (_ bv1 32))) true))))))
(check-sat)
; query 63: function susan_thin, block 533, name %534
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in528_32 () (_ BitVec 32))
(declare-fun in498_32 () (_ BitVec 32))
(assert
 (let (($x39 (or false false false)))
(let (($x434 (or $x39 (and (distinct (bvor in498_32 in528_32) (bvor in498_32 in528_32)) true))))
(let (($x103 (not $x39)))
(and $x103 $x434)))))
(check-sat)
; query 64: function susan_thin, block 533, name %535
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in518_32 () (_ BitVec 32))
(declare-fun in508_32 () (_ BitVec 32))
(assert
 (let (($x39 (or false false false)))
(let (($x898 (or $x39 (and (distinct (bvor in508_32 in518_32) (bvor in508_32 in518_32)) true))))
(let (($x103 (not $x39)))
(and $x103 $x898)))))
(check-sat)
; query 65: function susan_thin, block 533, name %536
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in518_32 () (_ BitVec 32))
(declare-fun in508_32 () (_ BitVec 32))
(declare-fun in528_32 () (_ BitVec 32))
(declare-fun in498_32 () (_ BitVec 32))
(assert
 (let ((?x241 (bvor in508_32 in518_32)))
(let ((?x272 (bvor in498_32 in528_32)))
(let ((?x668 (bvand ?x272 ?x241)))
(let (($x39 (or false false false)))
(let (($x235 (or $x39 $x39 false)))
(let (($x474 (not $x235)))
(and $x474 (or $x235 (and (distinct ?x668 ?x668) true))))))))))
(check-sat)
; query 66: function susan_thin, block 533, name %537
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in518_32 () (_ BitVec 32))
(declare-fun in508_32 () (_ BitVec 32))
(declare-fun in528_32 () (_ BitVec 32))
(declare-fun in498_32 () (_ BitVec 32))
(assert
 (let ((?x241 (bvor in508_32 in518_32)))
(let ((?x272 (bvor in498_32 in528_32)))
(let ((?x668 (bvand ?x272 ?x241)))
(let ((?x569 (ite (and (distinct (_ bv0 32) ?x668) true) (_ bv1 1) (_ bv0 1))))
(let (($x39 (or false false false)))
(let (($x235 (or $x39 $x39 false)))
(let (($x586 (or $x235 false false)))
(let (($x454 (not $x586)))
(and $x454 (or $x586 (and (distinct ?x569 ?x569) true))))))))))))
(check-sat)
; query 67: function susan_thin, block 538, name %539
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in498_32 () (_ BitVec 32))
(assert
 (let ((?x623 (ite (and (distinct (_ bv0 32) in498_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x39 (or false false false)))
(let (($x103 (not $x39)))
(and $x103 (or $x39 (and (distinct ?x623 ?x623) true)))))))
(check-sat)
; query 68: function susan_thin, block 540, name %541
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in508_32 () (_ BitVec 32))
(assert
 (let ((?x106 (ite (and (distinct (_ bv0 32) in508_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x39 (or false false false)))
(let (($x103 (not $x39)))
(and $x103 (or $x39 (and (distinct ?x106 ?x106) true)))))))
(check-sat)
; query 69: function susan_thin, block 545, name %546
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in508_32 () (_ BitVec 32))
(assert
 (let ((?x106 (ite (and (distinct (_ bv0 32) in508_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x39 (or false false false)))
(let (($x103 (not $x39)))
(and $x103 (or $x39 (and (distinct ?x106 ?x106) true)))))))
(check-sat)
; query 70: function susan_thin, block 563, name %564
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.325_32 () (_ BitVec 32))
(assert
 (let ((?x574 (ite (= (_ bv0 32) in.325_32) (_ bv1 1) (_ bv0 1))))
(let (($x39 (or false false false)))
(let (($x103 (not $x39)))
(and $x103 (or $x39 (and (distinct ?x574 ?x574) true)))))))
(check-sat)
; query 71: function susan_thin, block 597, name %598
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.321_32 () (_ BitVec 32))
(assert
 (let ((?x526 (ite (= (_ bv0 32) in.321_32) (_ bv1 1) (_ bv0 1))))
(let (($x39 (or false false false)))
(let (($x103 (not $x39)))
(and $x103 (or $x39 (and (distinct ?x526 ?x526) true)))))))
(check-sat)
; query 72: function susan_thin, block 685, name %686
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in662_32 () (_ BitVec 32))
(declare-fun in680_32 () (_ BitVec 32))
(assert
 (let (($x39 (or false false false)))
(let (($x726 (or $x39 (and (distinct (bvor in680_32 in662_32) (bvor in680_32 in662_32)) true))))
(let (($x103 (not $x39)))
(and $x103 $x726)))))
(check-sat)
; query 73: function susan_thin, block 685, name %687
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in671_32 () (_ BitVec 32))
(declare-fun in653_32 () (_ BitVec 32))
(assert
 (let (($x39 (or false false false)))
(let (($x438 (or $x39 (and (distinct (bvor in653_32 in671_32) (bvor in653_32 in671_32)) true))))
(let (($x103 (not $x39)))
(and $x103 $x438)))))
(check-sat)
; query 74: function susan_thin, block 685, name %688
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in671_32 () (_ BitVec 32))
(declare-fun in653_32 () (_ BitVec 32))
(declare-fun in662_32 () (_ BitVec 32))
(declare-fun in680_32 () (_ BitVec 32))
(assert
 (let ((?x666 (bvor in653_32 in671_32)))
(let ((?x348 (bvor in680_32 in662_32)))
(let ((?x228 (bvand ?x348 ?x666)))
(let (($x39 (or false false false)))
(let (($x235 (or $x39 $x39 false)))
(let (($x474 (not $x235)))
(and $x474 (or $x235 (and (distinct ?x228 ?x228) true))))))))))
(check-sat)
; query 75: function susan_thin, block 685, name %689
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in671_32 () (_ BitVec 32))
(declare-fun in653_32 () (_ BitVec 32))
(declare-fun in662_32 () (_ BitVec 32))
(declare-fun in680_32 () (_ BitVec 32))
(assert
 (let ((?x666 (bvor in653_32 in671_32)))
(let ((?x348 (bvor in680_32 in662_32)))
(let ((?x228 (bvand ?x348 ?x666)))
(let ((?x658 (ite (and (distinct (_ bv0 32) ?x228) true) (_ bv1 1) (_ bv0 1))))
(let (($x39 (or false false false)))
(let (($x235 (or $x39 $x39 false)))
(let (($x586 (or $x235 false false)))
(let (($x454 (not $x586)))
(and $x454 (or $x586 (and (distinct ?x658 ?x658) true))))))))))))
(check-sat)
; query 76: function susan_thin, block 915, name %916
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.13_32 () (_ BitVec 32))
(assert
 (let (($x501 (and (distinct (bvadd ((_ sign_extend 1) in.13_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.13_32 (_ bv1 32)))) true)))
(let (($x627 (or false false (or $x501))))
(and (not $x627) (or $x627 (and (distinct (bvadd in.13_32 (_ bv1 32)) (bvadd in.13_32 (_ bv1 32))) true))))))
(check-sat)
