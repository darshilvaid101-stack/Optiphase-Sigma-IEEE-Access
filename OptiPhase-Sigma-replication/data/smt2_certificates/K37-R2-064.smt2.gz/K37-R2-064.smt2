; OptiPhase-Sigma refinement certificate for sweep K37-R2-064
; query 0: function main, block 104, name %105
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (and (not (or false false)) (or (or false false) (and (distinct ((_ extract 31 0) (_ bv4294967295 64)) ((_ extract 31 0) (_ bv4294967295 64))) true))))
(check-sat)
; query 1: function main, block 104, name %106
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x540 (or false false)))
(let (($x612 (or $x540 false false)))
(let (($x250 (or $x612 (and (distinct (bvand ((_ extract 31 0) (_ bv4294967295 64)) (_ bv4278190080 32)) (bvand ((_ extract 31 0) (_ bv4294967295 64)) (_ bv4278190080 32))) true))))
(let (($x498 (not $x612)))
(and $x498 $x250))))))
(check-sat)
; query 2: function main, block 104, name %107
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x807 ((_ extract 31 0) (_ bv4294967295 64))))
(let ((?x777 (bvand ?x807 (_ bv4278190080 32))))
(let ((?x35 (bvlshr ?x777 (_ bv24 32))))
(let (($x540 (or false false)))
(let (($x612 (or $x540 false false)))
(let (($x41 (or $x612 false false)))
(let (($x326 (or $x41 (bvuge (_ bv24 32) (_ bv32 32)))))
(let (($x130 (not $x326)))
(and $x130 (or $x326 (and (distinct ?x35 ?x35) true))))))))))))
(check-sat)
; query 3: function main, block 104, name %108
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (and (not (or false false)) (or (or false false) (and (distinct ((_ extract 31 0) (_ bv4294967295 64)) ((_ extract 31 0) (_ bv4294967295 64))) true))))
(check-sat)
; query 4: function main, block 104, name %109
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x540 (or false false)))
(let (($x612 (or $x540 false false)))
(let (($x240 (or $x612 (and (distinct (bvand ((_ extract 31 0) (_ bv4294967295 64)) (_ bv16711680 32)) (bvand ((_ extract 31 0) (_ bv4294967295 64)) (_ bv16711680 32))) true))))
(let (($x498 (not $x612)))
(and $x498 $x240))))))
(check-sat)
; query 5: function main, block 104, name %110
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x807 ((_ extract 31 0) (_ bv4294967295 64))))
(let ((?x608 (bvand ?x807 (_ bv16711680 32))))
(let ((?x583 (bvlshr ?x608 (_ bv8 32))))
(let (($x540 (or false false)))
(let (($x612 (or $x540 false false)))
(let (($x41 (or $x612 false false)))
(let (($x230 (or $x41 (bvuge (_ bv8 32) (_ bv32 32)))))
(let (($x11 (not $x230)))
(and $x11 (or $x230 (and (distinct ?x583 ?x583) true))))))))))))
(check-sat)
; query 6: function main, block 104, name %111
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x807 ((_ extract 31 0) (_ bv4294967295 64))))
(let ((?x608 (bvand ?x807 (_ bv16711680 32))))
(let ((?x583 (bvlshr ?x608 (_ bv8 32))))
(let ((?x777 (bvand ?x807 (_ bv4278190080 32))))
(let ((?x35 (bvlshr ?x777 (_ bv24 32))))
(let ((?x81 (bvor ?x35 ?x583)))
(let (($x540 (or false false)))
(let (($x612 (or $x540 false false)))
(let (($x41 (or $x612 false false)))
(let (($x230 (or $x41 (bvuge (_ bv8 32) (_ bv32 32)))))
(let (($x326 (or $x41 (bvuge (_ bv24 32) (_ bv32 32)))))
(let (($x506 (or $x326 $x230 false)))
(and (not $x506) (or $x506 (and (distinct ?x81 ?x81) true))))))))))))))))
(check-sat)
; query 7: function main, block 104, name %112
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (and (not (or false false)) (or (or false false) (and (distinct ((_ extract 31 0) (_ bv4294967295 64)) ((_ extract 31 0) (_ bv4294967295 64))) true))))
(check-sat)
; query 8: function main, block 104, name %113
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x540 (or false false)))
(let (($x612 (or $x540 false false)))
(let (($x21 (or $x612 (and (distinct (bvand ((_ extract 31 0) (_ bv4294967295 64)) (_ bv65280 32)) (bvand ((_ extract 31 0) (_ bv4294967295 64)) (_ bv65280 32))) true))))
(let (($x498 (not $x612)))
(and $x498 $x21))))))
(check-sat)
; query 9: function main, block 104, name %114
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x807 ((_ extract 31 0) (_ bv4294967295 64))))
(let ((?x12 (bvand ?x807 (_ bv65280 32))))
(let ((?x450 (bvshl ?x12 (_ bv8 32))))
(let (($x540 (or false false)))
(let (($x612 (or $x540 false false)))
(let (($x41 (or $x612 false false)))
(let (($x230 (or $x41 (bvuge (_ bv8 32) (_ bv32 32)))))
(let (($x11 (not $x230)))
(and $x11 (or $x230 (and (distinct ?x450 ?x450) true))))))))))))
(check-sat)
; query 10: function main, block 104, name %115
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x807 ((_ extract 31 0) (_ bv4294967295 64))))
(let ((?x12 (bvand ?x807 (_ bv65280 32))))
(let ((?x450 (bvshl ?x12 (_ bv8 32))))
(let ((?x608 (bvand ?x807 (_ bv16711680 32))))
(let ((?x583 (bvlshr ?x608 (_ bv8 32))))
(let ((?x777 (bvand ?x807 (_ bv4278190080 32))))
(let ((?x35 (bvlshr ?x777 (_ bv24 32))))
(let ((?x81 (bvor ?x35 ?x583)))
(let ((?x26 (bvor ?x81 ?x450)))
(let (($x540 (or false false)))
(let (($x612 (or $x540 false false)))
(let (($x41 (or $x612 false false)))
(let (($x230 (or $x41 (bvuge (_ bv8 32) (_ bv32 32)))))
(let (($x326 (or $x41 (bvuge (_ bv24 32) (_ bv32 32)))))
(let (($x506 (or $x326 $x230 false)))
(let (($x149 (or $x506 $x230 false)))
(and (not $x149) (or $x149 (and (distinct ?x26 ?x26) true))))))))))))))))))))
(check-sat)
; query 11: function main, block 104, name %116
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (and (not (or false false)) (or (or false false) (and (distinct ((_ extract 31 0) (_ bv4294967295 64)) ((_ extract 31 0) (_ bv4294967295 64))) true))))
(check-sat)
; query 12: function main, block 104, name %117
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x540 (or false false)))
(let (($x612 (or $x540 false false)))
(let (($x50 (or $x612 (and (distinct (bvand ((_ extract 31 0) (_ bv4294967295 64)) (_ bv255 32)) (bvand ((_ extract 31 0) (_ bv4294967295 64)) (_ bv255 32))) true))))
(let (($x498 (not $x612)))
(and $x498 $x50))))))
(check-sat)
; query 13: function main, block 104, name %118
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x807 ((_ extract 31 0) (_ bv4294967295 64))))
(let ((?x161 (bvand ?x807 (_ bv255 32))))
(let ((?x86 (bvshl ?x161 (_ bv24 32))))
(let (($x540 (or false false)))
(let (($x612 (or $x540 false false)))
(let (($x41 (or $x612 false false)))
(let (($x326 (or $x41 (bvuge (_ bv24 32) (_ bv32 32)))))
(let (($x130 (not $x326)))
(and $x130 (or $x326 (and (distinct ?x86 ?x86) true))))))))))))
(check-sat)
; query 14: function main, block 104, name %119
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x807 ((_ extract 31 0) (_ bv4294967295 64))))
(let ((?x161 (bvand ?x807 (_ bv255 32))))
(let ((?x86 (bvshl ?x161 (_ bv24 32))))
(let ((?x12 (bvand ?x807 (_ bv65280 32))))
(let ((?x450 (bvshl ?x12 (_ bv8 32))))
(let ((?x608 (bvand ?x807 (_ bv16711680 32))))
(let ((?x583 (bvlshr ?x608 (_ bv8 32))))
(let ((?x777 (bvand ?x807 (_ bv4278190080 32))))
(let ((?x35 (bvlshr ?x777 (_ bv24 32))))
(let ((?x81 (bvor ?x35 ?x583)))
(let ((?x26 (bvor ?x81 ?x450)))
(let ((?x77 (bvor ?x26 ?x86)))
(let (($x540 (or false false)))
(let (($x612 (or $x540 false false)))
(let (($x41 (or $x612 false false)))
(let (($x326 (or $x41 (bvuge (_ bv24 32) (_ bv32 32)))))
(let (($x230 (or $x41 (bvuge (_ bv8 32) (_ bv32 32)))))
(let (($x506 (or $x326 $x230 false)))
(let (($x149 (or $x506 $x230 false)))
(let (($x884 (or $x149 $x326 false)))
(and (not $x884) (or $x884 (and (distinct ?x77 ?x77) true))))))))))))))))))))))))
(check-sat)
