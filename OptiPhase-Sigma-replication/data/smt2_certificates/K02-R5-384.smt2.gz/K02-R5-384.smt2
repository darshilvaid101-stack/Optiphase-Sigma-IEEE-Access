; OptiPhase-Sigma refinement certificate for sweep K02-R5-384
; query 0: function xmalloc, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in7_32 () (_ BitVec 32))
(assert
 (let ((?x74 (ite (and (distinct (_ bv0 32) in7_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x70 (or false false false)))
(and (not $x70) (or $x70 (and (distinct ?x74 ?x74) true))))))
(check-sat)
