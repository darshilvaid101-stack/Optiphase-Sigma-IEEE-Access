; OptiPhase-Sigma refinement certificate for sweep K04-R1-005
