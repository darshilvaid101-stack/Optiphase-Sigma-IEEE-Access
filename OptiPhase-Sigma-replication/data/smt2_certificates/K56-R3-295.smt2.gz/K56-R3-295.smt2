; OptiPhase-Sigma refinement certificate for sweep K56-R3-295
; query 0: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x53 (or false false false)))
(let (($x2001 (not $x53)))
(and $x2001 (or $x53 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x320 (bvadd in.01_32 (_ bv1 32))))
(let ((?x132 (bvmul ?x320 ?x320)))
(let (($x53 (or false false false)))
(let (($x257 (or $x53 $x53 false)))
(and (not $x257) (or $x257 (and (distinct ?x132 ?x132) true))))))))
(check-sat)
; query 2: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x320 (bvadd in.01_32 (_ bv1 32))))
(let ((?x132 (bvmul ?x320 ?x320)))
(let ((?x157 (bvmul ?x132 (_ bv2 32))))
(let (($x53 (or false false false)))
(let (($x257 (or $x53 $x53 false)))
(let (($x22 (or $x257 false false)))
(and (not $x22) (or $x22 (and (distinct ?x157 ?x157) true))))))))))
(check-sat)
; query 3: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x320 (bvadd in.01_32 (_ bv1 32))))
(let ((?x132 (bvmul ?x320 ?x320)))
(let ((?x157 (bvmul ?x132 (_ bv2 32))))
(let ((?x571 (bvmul ?x157 (_ bv4 32))))
(let (($x53 (or false false false)))
(let (($x257 (or $x53 $x53 false)))
(let (($x22 (or $x257 false false)))
(let (($x1078 (or $x22 false false)))
(and (not $x1078) (or $x1078 (and (distinct ?x571 ?x571) true))))))))))))
(check-sat)
; query 4: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x220 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x53 (or false false false)))
(let (($x2001 (not $x53)))
(and $x2001 (or $x53 (and (distinct ?x220 ?x220) true)))))))
(check-sat)
; query 5: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x458 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x53 (or false false false)))
(let (($x2001 (not $x53)))
(and $x2001 (or $x53 (and (distinct ?x458 ?x458) true)))))))
(check-sat)
; query 6: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x53 (or false false false)))
(let (($x2001 (not $x53)))
(and $x2001 (or $x53 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 7: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x1879 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x1932 (or false false (or $x1879))))
(and (not $x1932) (or $x1932 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x254 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x53 (or false false false)))
(let (($x2001 (not $x53)))
(and $x2001 (or $x53 (and (distinct ?x254 ?x254) true)))))))
(check-sat)
; query 9: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x884 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x53 (or false false false)))
(let (($x2001 (not $x53)))
(and $x2001 (or $x53 (and (distinct ?x884 ?x884) true)))))))
(check-sat)
; query 10: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x29 (or false false)))
(and (not $x29) (or $x29 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true)))))
(check-sat)
; query 11: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x851 ((_ sign_extend 16) in.1_16)))
(let ((?x49 (bvadd ?x851 (_ bv10 32))))
(let (($x777 (and (distinct (bvadd ((_ sign_extend 1) ?x851) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x49)) true)))
(let (($x29 (or false false)))
(let (($x145 (or $x29 false (or $x777))))
(and (not $x145) (or $x145 (and (distinct ?x49 ?x49) true)))))))))
(check-sat)
; query 12: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x851 ((_ sign_extend 16) in.1_16)))
(let ((?x49 (bvadd ?x851 (_ bv10 32))))
(let ((?x232 ((_ extract 15 0) ?x49)))
(let (($x777 (and (distinct (bvadd ((_ sign_extend 1) ?x851) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x49)) true)))
(let (($x29 (or false false)))
(let (($x145 (or $x29 false (or $x777))))
(let (($x281 (or $x145 false)))
(and (not $x281) (or $x281 (and (distinct ?x232 ?x232) true)))))))))))
(check-sat)
; query 13: function matrix_sum, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x283 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x53 (or false false false)))
(let (($x2001 (not $x53)))
(and $x2001 (or $x53 (and (distinct ?x283 ?x283) true)))))))
(check-sat)
; query 14: function matrix_sum, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x283 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let ((?x263 ((_ zero_extend 63) ?x283)))
(let (($x53 (or false false false)))
(let (($x1946 (or $x53 false)))
(and (not $x1946) (or $x1946 (and (distinct ?x263 ?x263) true))))))))
(check-sat)
; query 15: function matrix_sum, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x283 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x344 (= (_ bv1 1) ?x283)))
(let ((?x81 (ite $x344 (_ bv1 32) (_ bv0 32))))
(let (($x53 (or false false false)))
(let (($x836 (or $x53 (ite $x344 false false))))
(and (not $x836) (or $x836 (and (distinct ?x81 ?x81) true)))))))))
(check-sat)
; query 16: function matrix_sum, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x29 (or false false)))
(and (not $x29) (or $x29 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true)))))
(check-sat)
; query 17: function matrix_sum, block 22, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x283 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x344 (= (_ bv1 1) ?x283)))
(let ((?x81 (ite $x344 (_ bv1 32) (_ bv0 32))))
(let ((?x851 ((_ sign_extend 16) in.1_16)))
(let ((?x506 (bvadd ?x851 ?x81)))
(let (($x243 (and (distinct (bvadd ((_ sign_extend 1) ?x851) ((_ sign_extend 1) ?x81)) ((_ sign_extend 1) ?x506)) true)))
(let (($x53 (or false false false)))
(let (($x836 (or $x53 (ite $x344 false false))))
(let (($x29 (or false false)))
(let (($x139 (or $x29 $x836 (or $x243))))
(and (not $x139) (or $x139 (and (distinct ?x506 ?x506) true))))))))))))))
(check-sat)
; query 18: function matrix_sum, block 22, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x283 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x344 (= (_ bv1 1) ?x283)))
(let ((?x81 (ite $x344 (_ bv1 32) (_ bv0 32))))
(let ((?x851 ((_ sign_extend 16) in.1_16)))
(let ((?x506 (bvadd ?x851 ?x81)))
(let ((?x161 ((_ extract 15 0) ?x506)))
(let (($x243 (and (distinct (bvadd ((_ sign_extend 1) ?x851) ((_ sign_extend 1) ?x81)) ((_ sign_extend 1) ?x506)) true)))
(let (($x53 (or false false false)))
(let (($x836 (or $x53 (ite $x344 false false))))
(let (($x29 (or false false)))
(let (($x139 (or $x29 $x836 (or $x243))))
(let (($x119 (or $x139 false)))
(and (not $x119) (or $x119 (and (distinct ?x161 ?x161) true))))))))))))))))
(check-sat)
