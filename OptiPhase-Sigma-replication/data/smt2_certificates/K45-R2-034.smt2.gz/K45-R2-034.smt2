; OptiPhase-Sigma refinement certificate for sweep K45-R2-034
; query 0: function Index_to_frequency, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x45 (ite (bvuge in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x586 (or false false false)))
(let (($x319 (not $x586)))
(and $x319 (or $x586 (and (distinct ?x45 ?x45) true)))))))
(check-sat)
; query 1: function IsPowerOfTwo, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x586 (or false false false)))
(let (($x319 (not $x586)))
(and $x319 (or $x586 (and (distinct (bvsub in0_32 (_ bv1 32)) (bvsub in0_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function IsPowerOfTwo, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x103 (bvsub in0_32 (_ bv1 32))))
(let ((?x220 (bvand in0_32 ?x103)))
(let (($x586 (or false false false)))
(let (($x111 (or false $x586 false)))
(and (not $x111) (or $x111 (and (distinct ?x220 ?x220) true))))))))
(check-sat)
; query 3: function IsPowerOfTwo, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x366 (ite (and (distinct (_ bv0 32) (bvand in0_32 (bvsub in0_32 (_ bv1 32)))) true) (_ bv1 1) (_ bv0 1))))
(let (($x586 (or false false false)))
(let (($x111 (or false $x586 false)))
(let (($x12 (or $x111 false false)))
(and (not $x12) (or $x12 (and (distinct ?x366 ?x366) true))))))))
(check-sat)
; query 4: function IsPowerOfTwo, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x41 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x586 (or false false false)))
(let (($x319 (not $x586)))
(and $x319 (or $x586 (and (distinct ?x41 ?x41) true)))))))
(check-sat)
; query 5: function NumberOfBitsNeeded, block 13, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x586 (or false false false)))
(let (($x319 (not $x586)))
(and $x319 (or $x586 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 6: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x41 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x586 (or false false false)))
(let (($x319 (not $x586)))
(and $x319 (or $x586 (and (distinct ?x41 ?x41) true)))))))
(check-sat)
; query 7: function ReverseBits, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x586 (or false false false)))
(let (($x319 (not $x586)))
(and $x319 (or $x586 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function ReverseBits, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x586 (or false false false)))
(let (($x113 (or $x586 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x8 (not $x113)))
(and $x8 (or $x113 (and (distinct (bvshl in.01_32 (_ bv1 32)) (bvshl in.01_32 (_ bv1 32))) true)))))))
(check-sat)
; query 9: function ReverseBits, block 5, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x586 (or false false false)))
(let (($x319 (not $x586)))
(and $x319 (or $x586 (and (distinct (bvand in.0_32 (_ bv1 32)) (bvand in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 10: function ReverseBits, block 5, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x329 (bvand in.0_32 (_ bv1 32))))
(let ((?x63 (bvshl in.01_32 (_ bv1 32))))
(let ((?x60 (bvor ?x63 ?x329)))
(let (($x586 (or false false false)))
(let (($x113 (or $x586 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x458 (or $x113 $x586 false)))
(and (not $x458) (or $x458 (and (distinct ?x60 ?x60) true))))))))))
(check-sat)
; query 11: function ReverseBits, block 5, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x586 (or false false false)))
(let (($x113 (or $x586 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x8 (not $x113)))
(and $x8 (or $x113 (and (distinct (bvlshr in.0_32 (_ bv1 32)) (bvlshr in.0_32 (_ bv1 32))) true)))))))
(check-sat)
; query 12: function fft_float, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x610 (ite (and (distinct (_ bv0 32) in1_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x586 (or false false false)))
(let (($x319 (not $x586)))
(and $x319 (or $x586 (and (distinct ?x610 ?x610) true)))))))
(check-sat)
; query 13: function fft_float, block 152, name %153
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let (($x586 (or false false false)))
(let (($x319 (not $x586)))
(and $x319 (or $x586 (and (distinct (bvadd in.04_32 (_ bv1 32)) (bvadd in.04_32 (_ bv1 32))) true))))))
(check-sat)
; query 14: function fft_float, block 152, name %154
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_32 () (_ BitVec 32))
(assert
 (let (($x586 (or false false false)))
(let (($x319 (not $x586)))
(and $x319 (or $x586 (and (distinct (bvadd in.03_32 (_ bv1 32)) (bvadd in.03_32 (_ bv1 32))) true))))))
(check-sat)
; query 15: function fft_float, block 156, name %157
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x586 (or false false false)))
(let (($x1596 (or $x586 (and (distinct (bvadd in.1_32 in.02_32) (bvadd in.1_32 in.02_32)) true))))
(let (($x319 (not $x586)))
(and $x319 $x1596)))))
(check-sat)
; query 16: function fft_float, block 159, name %160
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x586 (or false false false)))
(let (($x113 (or $x586 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x8 (not $x113)))
(and $x8 (or $x113 (and (distinct (bvshl in.02_32 (_ bv1 32)) (bvshl in.02_32 (_ bv1 32))) true)))))))
(check-sat)
; query 17: function fft_float, block 161, name %162
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x610 (ite (and (distinct (_ bv0 32) in1_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x586 (or false false false)))
(let (($x319 (not $x586)))
(and $x319 (or $x586 (and (distinct ?x610 ?x610) true)))))))
(check-sat)
; query 18: function fft_float, block 180, name %181
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let (($x586 (or false false false)))
(let (($x319 (not $x586)))
(and $x319 (or $x586 (and (distinct (bvadd in.2_32 (_ bv1 32)) (bvadd in.2_32 (_ bv1 32))) true))))))
(check-sat)
; query 19: function fft_float, block 41, name %42
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.05_32 () (_ BitVec 32))
(assert
 (let (($x586 (or false false false)))
(let (($x319 (not $x586)))
(and $x319 (or $x586 (and (distinct (bvadd in.05_32 (_ bv1 32)) (bvadd in.05_32 (_ bv1 32))) true))))))
(check-sat)
; query 20: function main, block 110, name %111
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x586 (or false false false)))
(let (($x319 (not $x586)))
(and $x319 (or $x586 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 21: function main, block 113, name %114
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x586 (or false false false)))
(let (($x319 (not $x586)))
(and $x319 (or $x586 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 22: function main, block 126, name %127
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let (($x586 (or false false false)))
(let (($x319 (not $x586)))
(and $x319 (or $x586 (and (distinct (bvadd in.2_32 (_ bv1 32)) (bvadd in.2_32 (_ bv1 32))) true))))))
(check-sat)
; query 23: function main, block 139, name %140
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.3_32 () (_ BitVec 32))
(assert
 (let (($x586 (or false false false)))
(let (($x319 (not $x586)))
(and $x319 (or $x586 (and (distinct (bvadd in.3_32 (_ bv1 32)) (bvadd in.3_32 (_ bv1 32))) true))))))
(check-sat)
; query 24: function main, block 57, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x586 (or false false false)))
(let (($x319 (not $x586)))
(and $x319 (or $x586 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 25: function main, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x1104 (ite (= (_ bv4 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x586 (or false false false)))
(let (($x319 (not $x586)))
(and $x319 (or $x586 (and (distinct ?x1104 ?x1104) true)))))))
(check-sat)
; query 26: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x434 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x586 (or false false false)))
(let (($x319 (not $x586)))
(and $x319 (or $x586 (and (distinct ?x434 ?x434) true)))))))
(check-sat)
