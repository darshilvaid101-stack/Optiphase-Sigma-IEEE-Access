; OptiPhase-Sigma refinement certificate for sweep K23-R6-015
