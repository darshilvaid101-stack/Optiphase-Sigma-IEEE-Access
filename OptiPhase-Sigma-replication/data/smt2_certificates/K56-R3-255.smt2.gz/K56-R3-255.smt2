; OptiPhase-Sigma refinement certificate for sweep K56-R3-255
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x364 (or false false)))
(let (($x15 (not $x364)))
(and $x15 (or $x364 (and (distinct ((_ sign_extend 16) in25_16) ((_ sign_extend 16) in25_16)) true))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let ((?x340 (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))))
(let (($x364 (or false false)))
(let (($x56 (or $x364 false false)))
(let (($x51 (not $x56)))
(and $x51 (or $x56 (and (distinct ?x340 ?x340) true))))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x364 (or false false)))
(let (($x15 (not $x364)))
(and $x15 (or $x364 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x402 ((_ sign_extend 16) in3_16)))
(let ((?x252 (bvand ?x402 (_ bv127 32))))
(let (($x364 (or false false)))
(let (($x56 (or $x364 false false)))
(let (($x51 (not $x56)))
(and $x51 (or $x56 (and (distinct ?x252 ?x252) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x402 ((_ sign_extend 16) in3_16)))
(let ((?x252 (bvand ?x402 (_ bv127 32))))
(let ((?x1499 ((_ extract 15 0) ?x252)))
(let (($x364 (or false false)))
(let (($x56 (or $x364 false false)))
(let (($x280 (or $x56 false)))
(let (($x68 (not $x280)))
(and $x68 (or $x280 (and (distinct ?x1499 ?x1499) true)))))))))))
(check-sat)
; query 5: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x364 (or false false)))
(let (($x15 (not $x364)))
(and $x15 (or $x364 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 6: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x60 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x364 (or false false)))
(let (($x56 (or $x364 false false)))
(let (($x51 (not $x56)))
(and $x51 (or $x56 (and (distinct ?x60 ?x60) true))))))))
(check-sat)
; query 7: function core_bench_list, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x1065 (or false false false)))
(let (($x896 (not $x1065)))
(and $x896 (or $x1065 (and (distinct (bvadd in.0_16 (_ bv1 16)) (bvadd in.0_16 (_ bv1 16))) true))))))
(check-sat)
; query 8: function core_bench_state, block 105, name %106
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x1065 (or false false false)))
(let (($x896 (not $x1065)))
(and $x896 (or $x1065 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 9: function core_bench_state, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1065 (or false false false)))
(let (($x896 (not $x1065)))
(and $x896 (or $x1065 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 10: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x83 (bvadd in.01_32 (_ bv1 32))))
(let (($x52 (and (distinct ?x83 ?x83) true)))
(let (($x1065 (or false false false)))
(let (($x896 (not $x1065)))
(and $x896 (or $x1065 $x52)))))))
(check-sat)
; query 11: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x83 (bvadd in.01_32 (_ bv1 32))))
(let ((?x278 (bvmul ?x83 ?x83)))
(let (($x1065 (or false false false)))
(let (($x12 (or $x1065 $x1065 false)))
(and (not $x12) (or $x12 (and (distinct ?x278 ?x278) true))))))))
(check-sat)
; query 12: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x83 (bvadd in.01_32 (_ bv1 32))))
(let ((?x278 (bvmul ?x83 ?x83)))
(let ((?x149 (bvmul ?x278 (_ bv2 32))))
(let (($x1065 (or false false false)))
(let (($x12 (or $x1065 $x1065 false)))
(let (($x226 (or $x12 false false)))
(and (not $x226) (or $x226 (and (distinct ?x149 ?x149) true))))))))))
(check-sat)
; query 13: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x83 (bvadd in.01_32 (_ bv1 32))))
(let ((?x278 (bvmul ?x83 ?x83)))
(let ((?x149 (bvmul ?x278 (_ bv2 32))))
(let ((?x67 (bvmul ?x149 (_ bv4 32))))
(let (($x1065 (or false false false)))
(let (($x12 (or $x1065 $x1065 false)))
(let (($x226 (or $x12 false false)))
(let (($x98 (or $x226 false false)))
(and (not $x98) (or $x98 (and (distinct ?x67 ?x67) true))))))))))))
(check-sat)
; query 14: function core_init_matrix, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x1065 (or false false false)))
(let (($x896 (not $x1065)))
(and $x896 (or $x1065 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 15: function core_init_matrix, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x1065 (or false false false)))
(let (($x896 (not $x1065)))
(and $x896 (or $x1065 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 16: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x594 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x1065 (or false false false)))
(let (($x896 (not $x1065)))
(and $x896 (or $x1065 (and (distinct ?x594 ?x594) true)))))))
(check-sat)
; query 17: function core_list_init, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x83 (bvadd in.01_32 (_ bv1 32))))
(let (($x52 (and (distinct ?x83 ?x83) true)))
(let (($x1065 (or false false false)))
(let (($x896 (not $x1065)))
(and $x896 (or $x1065 $x52)))))))
(check-sat)
; query 18: function core_list_mergesort, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x83 (bvadd in.01_32 (_ bv1 32))))
(let (($x52 (and (distinct ?x83 ?x83) true)))
(let (($x64 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x83)) true)))
(let (($x555 (or false false (or $x64))))
(and (not $x555) (or $x555 $x52)))))))
(check-sat)
; query 19: function core_list_mergesort, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x1851 (ite (bvslt (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x1065 (or false false false)))
(let (($x896 (not $x1065)))
(and $x896 (or $x1065 (and (distinct ?x1851 ?x1851) true)))))))
(check-sat)
; query 20: function core_list_mergesort, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.224_32 () (_ BitVec 32))
(assert
 (let ((?x308 (ite (= (_ bv0 32) in.224_32) (_ bv1 1) (_ bv0 1))))
(let (($x1065 (or false false false)))
(let (($x896 (not $x1065)))
(and $x896 (or $x1065 (and (distinct ?x308 ?x308) true)))))))
(check-sat)
; query 21: function core_list_mergesort, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x127 (ite (= (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x1065 (or false false false)))
(let (($x896 (not $x1065)))
(and $x896 (or $x1065 (and (distinct ?x127 ?x127) true)))))))
(check-sat)
; query 22: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x36 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x366 (or false false (or $x36))))
(and (not $x366) (or $x366 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 23: function core_list_mergesort, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x612 (and (distinct (bvmul ((_ sign_extend 32) in.020_32) ((_ sign_extend 32) (_ bv2 32))) ((_ sign_extend 32) (bvmul in.020_32 (_ bv2 32)))) true)))
(let (($x39 (or false false (or $x612))))
(and (not $x39) (or $x39 (and (distinct (bvmul in.020_32 (_ bv2 32)) (bvmul in.020_32 (_ bv2 32))) true))))))
(check-sat)
; query 24: function core_state_transition, block 102, name %103
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x364 (or false false)))
(let (($x15 (not $x364)))
(and $x15 (or $x364 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 25: function core_state_transition, block 102, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x456 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x364 (or false false)))
(let (($x56 (or $x364 false false)))
(let (($x51 (not $x56)))
(and $x51 (or $x56 (and (distinct ?x456 ?x456) true))))))))
(check-sat)
; query 26: function core_state_transition, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x364 (or false false)))
(let (($x15 (not $x364)))
(and $x15 (or $x364 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 27: function core_state_transition, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x2780 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x364 (or false false)))
(let (($x56 (or $x364 false false)))
(let (($x51 (not $x56)))
(and $x51 (or $x56 (and (distinct ?x2780 ?x2780) true))))))))
(check-sat)
; query 28: function core_state_transition, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x364 (or false false)))
(let (($x15 (not $x364)))
(and $x15 (or $x364 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 29: function core_state_transition, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x456 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x364 (or false false)))
(let (($x56 (or $x364 false false)))
(let (($x51 (not $x56)))
(and $x51 (or $x56 (and (distinct ?x456 ?x456) true))))))))
(check-sat)
; query 30: function core_state_transition, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x364 (or false false)))
(let (($x15 (not $x364)))
(and $x15 (or $x364 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 31: function core_state_transition, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1097 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x364 (or false false)))
(let (($x56 (or $x364 false false)))
(let (($x51 (not $x56)))
(and $x51 (or $x56 (and (distinct ?x1097 ?x1097) true))))))))
(check-sat)
; query 32: function core_state_transition, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x364 (or false false)))
(let (($x15 (not $x364)))
(and $x15 (or $x364 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 33: function core_state_transition, block 51, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1097 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x364 (or false false)))
(let (($x56 (or $x364 false false)))
(let (($x51 (not $x56)))
(and $x51 (or $x56 (and (distinct ?x1097 ?x1097) true))))))))
(check-sat)
; query 34: function core_state_transition, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x364 (or false false)))
(let (($x15 (not $x364)))
(and $x15 (or $x364 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 35: function core_state_transition, block 64, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1097 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x364 (or false false)))
(let (($x56 (or $x364 false false)))
(let (($x51 (not $x56)))
(and $x51 (or $x56 (and (distinct ?x1097 ?x1097) true))))))))
(check-sat)
; query 36: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x1900 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x1065 (or false false false)))
(let (($x896 (not $x1065)))
(and $x896 (or $x1065 (and (distinct ?x1900 ?x1900) true)))))))
(check-sat)
; query 37: function core_state_transition, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x364 (or false false)))
(let (($x15 (not $x364)))
(and $x15 (or $x364 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 38: function core_state_transition, block 80, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x627 (ite (= (_ bv69 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x364 (or false false)))
(let (($x56 (or $x364 false false)))
(let (($x51 (not $x56)))
(and $x51 (or $x56 (and (distinct ?x627 ?x627) true))))))))
(check-sat)
; query 39: function core_state_transition, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x364 (or false false)))
(let (($x15 (not $x364)))
(and $x15 (or $x364 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 40: function core_state_transition, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x117 (ite (= (_ bv101 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x364 (or false false)))
(let (($x56 (or $x364 false false)))
(let (($x51 (not $x56)))
(and $x51 (or $x56 (and (distinct ?x117 ?x117) true))))))))
(check-sat)
; query 41: function core_state_transition, block 99, name %100
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x364 (or false false)))
(let (($x15 (not $x364)))
(and $x15 (or $x364 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 42: function core_state_transition, block 99, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x2780 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x364 (or false false)))
(let (($x56 (or $x364 false false)))
(let (($x51 (not $x56)))
(and $x51 (or $x56 (and (distinct ?x2780 ?x2780) true))))))))
(check-sat)
; query 43: function crcu8, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x364 (or false false)))
(let (($x15 (not $x364)))
(and $x15 (or $x364 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 44: function crcu8, block 19, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x93 ((_ zero_extend 16) in.01_16)))
(let ((?x176 (bvxor ?x93 (_ bv16386 32))))
(let (($x364 (or false false)))
(let (($x56 (or $x364 false false)))
(let (($x51 (not $x56)))
(and $x51 (or $x56 (and (distinct ?x176 ?x176) true)))))))))
(check-sat)
; query 45: function crcu8, block 19, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x93 ((_ zero_extend 16) in.01_16)))
(let ((?x176 (bvxor ?x93 (_ bv16386 32))))
(let ((?x156 ((_ extract 15 0) ?x176)))
(let (($x364 (or false false)))
(let (($x56 (or $x364 false false)))
(let (($x280 (or $x56 false)))
(let (($x68 (not $x280)))
(and $x68 (or $x280 (and (distinct ?x156 ?x156) true)))))))))))
(check-sat)
; query 46: function crcu8, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x364 (or false false)))
(let (($x15 (not $x364)))
(and $x15 (or $x364 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 47: function crcu8, block 29, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x2316 ((_ zero_extend 16) in27_16)))
(let ((?x222 (bvor ?x2316 (_ bv32768 32))))
(let (($x364 (or false false)))
(let (($x56 (or $x364 false false)))
(let (($x51 (not $x56)))
(and $x51 (or $x56 (and (distinct ?x222 ?x222) true)))))))))
(check-sat)
; query 48: function crcu8, block 29, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x2316 ((_ zero_extend 16) in27_16)))
(let ((?x222 (bvor ?x2316 (_ bv32768 32))))
(let ((?x750 ((_ extract 15 0) ?x222)))
(let (($x364 (or false false)))
(let (($x56 (or $x364 false false)))
(let (($x280 (or $x56 false)))
(let (($x68 (not $x280)))
(and $x68 (or $x280 (and (distinct ?x750 ?x750) true)))))))))))
(check-sat)
; query 49: function crcu8, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x364 (or false false)))
(let (($x15 (not $x364)))
(and $x15 (or $x364 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 50: function crcu8, block 33, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x2316 ((_ zero_extend 16) in27_16)))
(let ((?x459 (bvand ?x2316 (_ bv32767 32))))
(let (($x364 (or false false)))
(let (($x56 (or $x364 false false)))
(let (($x51 (not $x56)))
(and $x51 (or $x56 (and (distinct ?x459 ?x459) true)))))))))
(check-sat)
; query 51: function crcu8, block 33, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x2316 ((_ zero_extend 16) in27_16)))
(let ((?x459 (bvand ?x2316 (_ bv32767 32))))
(let ((?x984 ((_ extract 15 0) ?x459)))
(let (($x364 (or false false)))
(let (($x56 (or $x364 false false)))
(let (($x280 (or $x56 false)))
(let (($x68 (not $x280)))
(and $x68 (or $x280 (and (distinct ?x984 ?x984) true)))))))))))
(check-sat)
; query 52: function crcu8, block 38, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_8 () (_ BitVec 8))
(assert
 (let (($x1065 (or false false false)))
(let (($x896 (not $x1065)))
(and $x896 (or $x1065 (and (distinct (bvadd in.02_8 (_ bv1 8)) (bvadd in.02_8 (_ bv1 8))) true))))))
(check-sat)
; query 53: function crcu8, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x379 ((_ extract 7 0) in.01_16)))
(let ((?x883 ((_ zero_extend 24) ?x379)))
(let (($x364 (or false false)))
(let (($x840 (or $x364 false)))
(and (not $x840) (or $x840 (and (distinct ?x883 ?x883) true))))))))
(check-sat)
; query 54: function crcu8, block 6, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x379 ((_ extract 7 0) in.01_16)))
(let ((?x883 ((_ zero_extend 24) ?x379)))
(let ((?x1351 (bvand ?x883 (_ bv1 32))))
(let (($x364 (or false false)))
(let (($x840 (or $x364 false)))
(let (($x48 (or $x840 false false)))
(and (not $x48) (or $x48 (and (distinct ?x1351 ?x1351) true))))))))))
(check-sat)
; query 55: function crcu8, block 6, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x379 ((_ extract 7 0) in.01_16)))
(let ((?x883 ((_ zero_extend 24) ?x379)))
(let ((?x1351 (bvand ?x883 (_ bv1 32))))
(let ((?x92 ((_ zero_extend 24) in.0_8)))
(let ((?x2059 (bvand ?x92 (_ bv1 32))))
(let ((?x163 (bvxor ?x2059 ?x1351)))
(let (($x364 (or false false)))
(let (($x840 (or $x364 false)))
(let (($x48 (or $x840 false false)))
(let (($x56 (or $x364 false false)))
(let (($x532 (or $x56 $x48 false)))
(and (not $x532) (or $x532 (and (distinct ?x163 ?x163) true)))))))))))))))
(check-sat)
; query 56: function crcu8, block 6, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x379 ((_ extract 7 0) in.01_16)))
(let ((?x883 ((_ zero_extend 24) ?x379)))
(let ((?x1351 (bvand ?x883 (_ bv1 32))))
(let ((?x92 ((_ zero_extend 24) in.0_8)))
(let ((?x2059 (bvand ?x92 (_ bv1 32))))
(let ((?x163 (bvxor ?x2059 ?x1351)))
(let ((?x704 ((_ extract 7 0) ?x163)))
(let (($x364 (or false false)))
(let (($x840 (or $x364 false)))
(let (($x48 (or $x840 false false)))
(let (($x56 (or $x364 false false)))
(let (($x532 (or $x56 $x48 false)))
(let (($x70 (or $x532 false)))
(and (not $x70) (or $x70 (and (distinct ?x704 ?x704) true)))))))))))))))))
(check-sat)
; query 57: function crcu8, block 6, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x364 (or false false)))
(let (($x15 (not $x364)))
(and $x15 (or $x364 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 58: function crcu8, block 6, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x92 ((_ zero_extend 24) in.0_8)))
(let ((?x179 (bvashr ?x92 (_ bv1 32))))
(let (($x364 (or false false)))
(let (($x56 (or $x364 false false)))
(let (($x318 (or $x56 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not $x318) (or $x318 (and (distinct ?x179 ?x179) true)))))))))
(check-sat)
; query 59: function crcu8, block 6, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x92 ((_ zero_extend 24) in.0_8)))
(let ((?x179 (bvashr ?x92 (_ bv1 32))))
(let ((?x1875 ((_ extract 7 0) ?x179)))
(let (($x364 (or false false)))
(let (($x56 (or $x364 false false)))
(let (($x318 (or $x56 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x1530 (or $x318 false)))
(and (not $x1530) (or $x1530 (and (distinct ?x1875 ?x1875) true)))))))))))
(check-sat)
; query 60: function crcu8, block 6, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x379 ((_ extract 7 0) in.01_16)))
(let ((?x883 ((_ zero_extend 24) ?x379)))
(let ((?x1351 (bvand ?x883 (_ bv1 32))))
(let ((?x92 ((_ zero_extend 24) in.0_8)))
(let ((?x2059 (bvand ?x92 (_ bv1 32))))
(let ((?x163 (bvxor ?x2059 ?x1351)))
(let ((?x704 ((_ extract 7 0) ?x163)))
(let ((?x953 ((_ zero_extend 24) ?x704)))
(let (($x364 (or false false)))
(let (($x840 (or $x364 false)))
(let (($x48 (or $x840 false false)))
(let (($x56 (or $x364 false false)))
(let (($x532 (or $x56 $x48 false)))
(let (($x70 (or $x532 false)))
(let (($x1825 (or $x70 false)))
(and (not $x1825) (or $x1825 (and (distinct ?x953 ?x953) true)))))))))))))))))))
(check-sat)
; query 61: function crcu8, block 6, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x379 ((_ extract 7 0) in.01_16)))
(let ((?x883 ((_ zero_extend 24) ?x379)))
(let ((?x1351 (bvand ?x883 (_ bv1 32))))
(let ((?x92 ((_ zero_extend 24) in.0_8)))
(let ((?x2059 (bvand ?x92 (_ bv1 32))))
(let ((?x163 (bvxor ?x2059 ?x1351)))
(let ((?x704 ((_ extract 7 0) ?x163)))
(let ((?x953 ((_ zero_extend 24) ?x704)))
(let ((?x877 (ite (= (_ bv1 32) ?x953) (_ bv1 1) (_ bv0 1))))
(let (($x364 (or false false)))
(let (($x840 (or $x364 false)))
(let (($x48 (or $x840 false false)))
(let (($x56 (or $x364 false false)))
(let (($x532 (or $x56 $x48 false)))
(let (($x70 (or $x532 false)))
(let (($x1825 (or $x70 false)))
(let (($x174 (or $x1825 false false)))
(and (not $x174) (or $x174 (and (distinct ?x877 ?x877) true)))))))))))))))))))))
(check-sat)
; query 62: function crcu8, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x364 (or false false)))
(let (($x15 (not $x364)))
(and $x15 (or $x364 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 63: function crcu8, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x92 ((_ zero_extend 24) in.0_8)))
(let ((?x2059 (bvand ?x92 (_ bv1 32))))
(let (($x364 (or false false)))
(let (($x56 (or $x364 false false)))
(let (($x51 (not $x56)))
(and $x51 (or $x56 (and (distinct ?x2059 ?x2059) true)))))))))
(check-sat)
; query 64: function crcu8, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x364 (or false false)))
(let (($x15 (not $x364)))
(and $x15 (or $x364 (and (distinct ((_ extract 7 0) in.01_16) ((_ extract 7 0) in.01_16)) true))))))
(check-sat)
; query 65: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x866 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x1065 (or false false false)))
(let (($x896 (not $x1065)))
(and $x896 (or $x1065 (and (distinct ?x866 ?x866) true)))))))
(check-sat)
; query 66: function matrix_mul_matrix, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1065 (or false false false)))
(let (($x896 (not $x1065)))
(and $x896 (or $x1065 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 67: function matrix_mul_matrix, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x83 (bvadd in.01_32 (_ bv1 32))))
(let (($x52 (and (distinct ?x83 ?x83) true)))
(let (($x1065 (or false false false)))
(let (($x896 (not $x1065)))
(and $x896 (or $x1065 $x52)))))))
(check-sat)
; query 68: function matrix_mul_matrix, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x1065 (or false false false)))
(let (($x896 (not $x1065)))
(and $x896 (or $x1065 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 69: function matrix_mul_matrix_bitextract, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1065 (or false false false)))
(let (($x896 (not $x1065)))
(and $x896 (or $x1065 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 70: function matrix_mul_matrix_bitextract, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x83 (bvadd in.01_32 (_ bv1 32))))
(let (($x52 (and (distinct ?x83 ?x83) true)))
(let (($x1065 (or false false false)))
(let (($x896 (not $x1065)))
(and $x896 (or $x1065 $x52)))))))
(check-sat)
; query 71: function matrix_mul_matrix_bitextract, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x1065 (or false false false)))
(let (($x896 (not $x1065)))
(and $x896 (or $x1065 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 72: function matrix_mul_vect, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1065 (or false false false)))
(let (($x896 (not $x1065)))
(and $x896 (or $x1065 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 73: function matrix_mul_vect, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x83 (bvadd in.01_32 (_ bv1 32))))
(let (($x52 (and (distinct ?x83 ?x83) true)))
(let (($x1065 (or false false false)))
(let (($x896 (not $x1065)))
(and $x896 (or $x1065 $x52)))))))
(check-sat)
; query 74: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x364 (or false false)))
(let (($x15 (not $x364)))
(and $x15 (or $x364 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 75: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x1168 ((_ sign_extend 16) in.1_16)))
(let ((?x1789 (bvadd ?x1168 (_ bv10 32))))
(let (($x1707 (and (distinct (bvadd ((_ sign_extend 1) ?x1168) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x1789)) true)))
(let (($x364 (or false false)))
(let (($x757 (or $x364 false (or $x1707))))
(and (not $x757) (or $x757 (and (distinct ?x1789 ?x1789) true)))))))))
(check-sat)
; query 76: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x1168 ((_ sign_extend 16) in.1_16)))
(let ((?x1789 (bvadd ?x1168 (_ bv10 32))))
(let ((?x313 ((_ extract 15 0) ?x1789)))
(let (($x1707 (and (distinct (bvadd ((_ sign_extend 1) ?x1168) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x1789)) true)))
(let (($x364 (or false false)))
(let (($x757 (or $x364 false (or $x1707))))
(let (($x2703 (or $x757 false)))
(and (not $x2703) (or $x2703 (and (distinct ?x313 ?x313) true)))))))))))
(check-sat)
; query 77: function parseval, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.23_32 () (_ BitVec 32))
(assert
 (let (($x635 (and (distinct (bvmul ((_ sign_extend 32) in.23_32) ((_ sign_extend 32) (_ bv1024 32))) ((_ sign_extend 32) (bvmul in.23_32 (_ bv1024 32)))) true)))
(let (($x1313 (or false false (or $x635))))
(and (not $x1313) (or $x1313 (and (distinct (bvmul in.23_32 (_ bv1024 32)) (bvmul in.23_32 (_ bv1024 32))) true))))))
(check-sat)
; query 78: function parseval, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.34_32 () (_ BitVec 32))
(assert
 (let (($x1019 (and (distinct (bvmul ((_ sign_extend 32) in.34_32) ((_ sign_extend 32) (_ bv1048576 32))) ((_ sign_extend 32) (bvmul in.34_32 (_ bv1048576 32)))) true)))
(let (($x650 (or false false (or $x1019))))
(and (not $x650) (or $x650 (and (distinct (bvmul in.34_32 (_ bv1048576 32)) (bvmul in.34_32 (_ bv1048576 32))) true))))))
(check-sat)
; query 79: function partition_memory, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x1065 (or false false false)))
(let (($x896 (not $x1065)))
(and $x896 (or $x1065 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
