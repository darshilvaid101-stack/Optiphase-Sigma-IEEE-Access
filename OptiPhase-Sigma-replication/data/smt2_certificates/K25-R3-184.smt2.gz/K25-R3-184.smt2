; OptiPhase-Sigma refinement certificate for sweep K25-R3-184
; query 0: function xmalloc, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in7_32 () (_ BitVec 32))
(assert
 (let ((?x72 (ite (and (distinct (_ bv0 32) in7_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x193 (or false false false)))
(and (not $x193) (or $x193 (and (distinct ?x72 ?x72) true))))))
(check-sat)
