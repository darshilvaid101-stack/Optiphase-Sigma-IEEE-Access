; OptiPhase-Sigma refinement certificate for sweep K57-R3-084
; query 0: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x384 (or false false false)))
(let (($x94 (not $x384)))
(and $x94 (or $x384 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x21 (bvadd in.01_32 (_ bv1 32))))
(let ((?x141 (bvmul ?x21 ?x21)))
(let (($x384 (or false false false)))
(let (($x1076 (or $x384 $x384 false)))
(and (not $x1076) (or $x1076 (and (distinct ?x141 ?x141) true))))))))
(check-sat)
; query 2: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x441 (and (distinct (bvmul (bvmul (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) (_ bv2 32)) (bvshl (bvmul (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) (_ bv3 32))) true)))
(let (($x384 (or false false false)))
(let (($x1076 (or $x384 $x384 false)))
(let (($x521 (or $x1076 false false)))
(and (not $x521) (or (or $x521 (bvuge (_ bv3 32) (_ bv32 32))) $x441)))))))
(check-sat)
; query 3: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x51 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x384 (or false false false)))
(let (($x94 (not $x384)))
(and $x94 (or $x384 (and (distinct ?x51 ?x51) true)))))))
(check-sat)
; query 4: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x384 (or false false false)))
(let (($x94 (not $x384)))
(and $x94 (or $x384 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 5: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x244 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x384 (or false false false)))
(let (($x94 (not $x384)))
(and $x94 (or $x384 (and (distinct ?x244 ?x244) true)))))))
(check-sat)
