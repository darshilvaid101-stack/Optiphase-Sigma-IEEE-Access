; OptiPhase-Sigma refinement certificate for sweep K37-R6-005
; query 0: function bit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x21 (and (distinct (bvsub ((_ sign_extend 1) (_ bv31 32)) ((_ sign_extend 1) in0_32)) ((_ sign_extend 1) (bvsub (_ bv31 32) in0_32))) true)))
(let (($x18 (or false false (or $x21))))
(and (not $x18) (or $x18 (and (distinct (bvsub (_ bv31 32) in0_32) (bvsub (_ bv31 32) in0_32)) true))))))
(check-sat)
; query 1: function bit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x273 (bvsub (_ bv31 32) in0_32)))
(let ((?x104 (bvshl (_ bv1 32) ?x273)))
(let (($x21 (and (distinct (bvsub ((_ sign_extend 1) (_ bv31 32)) ((_ sign_extend 1) in0_32)) ((_ sign_extend 1) ?x273)) true)))
(let (($x18 (or false false (or $x21))))
(let (($x417 (or (or false $x18 false) (bvuge ?x273 (_ bv32 32)))))
(and (not $x417) (or $x417 (and (distinct ?x104 ?x104) true)))))))))
(check-sat)
; query 2: function bit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x273 (bvsub (_ bv31 32) in0_32)))
(let ((?x104 (bvshl (_ bv1 32) ?x273)))
(let ((?x198 ((_ sign_extend 32) ?x104)))
(let (($x21 (and (distinct (bvsub ((_ sign_extend 1) (_ bv31 32)) ((_ sign_extend 1) in0_32)) ((_ sign_extend 1) ?x273)) true)))
(let (($x18 (or false false (or $x21))))
(let (($x417 (or (or false $x18 false) (bvuge ?x273 (_ bv32 32)))))
(let (($x20 (or $x417 false)))
(and (not $x20) (or $x20 (and (distinct ?x198 ?x198) true)))))))))))
(check-sat)
; query 3: function bit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x273 (bvsub (_ bv31 32) in0_32)))
(let ((?x104 (bvshl (_ bv1 32) ?x273)))
(let ((?x198 ((_ sign_extend 32) ?x104)))
(let ((?x73 (bvand in1_64 ?x198)))
(let (($x21 (and (distinct (bvsub ((_ sign_extend 1) (_ bv31 32)) ((_ sign_extend 1) in0_32)) ((_ sign_extend 1) ?x273)) true)))
(let (($x18 (or false false (or $x21))))
(let (($x417 (or (or false $x18 false) (bvuge ?x273 (_ bv32 32)))))
(let (($x20 (or $x417 false)))
(let (($x893 (or false $x20 false)))
(and (not $x893) (or $x893 (and (distinct ?x73 ?x73) true)))))))))))))
(check-sat)
