; OptiPhase-Sigma refinement certificate for sweep K23-R6-020
; query 0: function kernel_nussinov, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x27 (and (distinct (bvadd ((_ zero_extend 1) in.02_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x34 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x22 (or (or false false (or $x34 $x27)) (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))
(and (not (or false false (or $x34))) $x22)))))
(check-sat)
; query 1: function kernel_nussinov, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x124 (and (distinct (bvsub ((_ sign_extend 1) in0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvsub in0_32 (_ bv1 32)))) true)))
(let (($x410 (or false false (or $x124))))
(and (not $x410) (or $x410 (and (distinct (bvsub in0_32 (_ bv1 32)) (bvsub in0_32 (_ bv1 32))) true))))))
(check-sat)
