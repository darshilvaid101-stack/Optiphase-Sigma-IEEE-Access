; OptiPhase-Sigma refinement certificate for sweep K31-R1-001
