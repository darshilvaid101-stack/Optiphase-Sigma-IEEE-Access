; OptiPhase-Sigma refinement certificate for sweep K13-R3-085
