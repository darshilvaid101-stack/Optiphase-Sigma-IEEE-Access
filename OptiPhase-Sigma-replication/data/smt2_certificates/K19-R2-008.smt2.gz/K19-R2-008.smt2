; OptiPhase-Sigma refinement certificate for sweep K19-R2-008
; query 0: function init_array, block 21, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.07_32 () (_ BitVec 32))
(assert
 (let (($x59 (and (distinct (bvadd ((_ zero_extend 1) in.07_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.07_32 (_ bv1 32)))) true)))
(let (($x149 (and (distinct (bvadd ((_ sign_extend 1) in.07_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.07_32 (_ bv1 32)))) true)))
(let (($x65 (or (or false false (or $x149 $x59)) (and (distinct (bvadd in.07_32 (_ bv1 32)) (bvadd in.07_32 (_ bv1 32))) true))))
(and (not (or false false (or $x149))) $x65)))))
(check-sat)
; query 1: function kernel_ludcmp, block 108, name %109
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.18_32 () (_ BitVec 32))
(assert
 (let (($x63 (and (distinct (bvadd ((_ zero_extend 1) in.18_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.18_32 (_ bv1 32)))) true)))
(let (($x36 (and (distinct (bvadd ((_ sign_extend 1) in.18_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.18_32 (_ bv1 32)))) true)))
(let (($x26 (or (or false false (or $x36 $x63)) (and (distinct (bvadd in.18_32 (_ bv1 32)) (bvadd in.18_32 (_ bv1 32))) true))))
(and (not (or false false (or $x36))) $x26)))))
(check-sat)
; query 2: function kernel_ludcmp, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_32 () (_ BitVec 32))
(assert
 (let (($x129 (and (distinct (bvadd ((_ zero_extend 1) in.03_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.03_32 (_ bv1 32)))) true)))
(let (($x113 (and (distinct (bvadd ((_ sign_extend 1) in.03_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.03_32 (_ bv1 32)))) true)))
(let (($x108 (or (or false false (or $x113 $x129)) (and (distinct (bvadd in.03_32 (_ bv1 32)) (bvadd in.03_32 (_ bv1 32))) true))))
(and (not (or false false (or $x113))) $x108)))))
(check-sat)
; query 3: function kernel_ludcmp, block 78, name %79
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.14_32 () (_ BitVec 32))
(assert
 (let (($x84 (and (distinct (bvadd ((_ zero_extend 1) in.14_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.14_32 (_ bv1 32)))) true)))
(let (($x94 (and (distinct (bvadd ((_ sign_extend 1) in.14_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.14_32 (_ bv1 32)))) true)))
(let (($x79 (or (or false false (or $x94 $x84)) (and (distinct (bvadd in.14_32 (_ bv1 32)) (bvadd in.14_32 (_ bv1 32))) true))))
(and (not (or false false (or $x94))) $x79)))))
(check-sat)
; query 4: function kernel_ludcmp, block 81, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.07_32 () (_ BitVec 32))
(assert
 (let (($x59 (and (distinct (bvadd ((_ zero_extend 1) in.07_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.07_32 (_ bv1 32)))) true)))
(let (($x149 (and (distinct (bvadd ((_ sign_extend 1) in.07_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.07_32 (_ bv1 32)))) true)))
(let (($x65 (or (or false false (or $x149 $x59)) (and (distinct (bvadd in.07_32 (_ bv1 32)) (bvadd in.07_32 (_ bv1 32))) true))))
(and (not (or false false (or $x149))) $x65)))))
(check-sat)
