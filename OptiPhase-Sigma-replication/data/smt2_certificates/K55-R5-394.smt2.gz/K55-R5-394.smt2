; OptiPhase-Sigma refinement certificate for sweep K55-R5-394
; query 0: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x324 (or false false)))
(let (($x126 (not $x324)))
(and $x126 (or $x324 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 1: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x365 ((_ sign_extend 16) in3_16)))
(let ((?x1422 (bvand ?x365 (_ bv127 32))))
(let (($x324 (or false false)))
(let (($x71 (or $x324 false false)))
(let (($x434 (not $x71)))
(and $x434 (or $x71 (and (distinct ?x1422 ?x1422) true)))))))))
(check-sat)
; query 2: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x365 ((_ sign_extend 16) in3_16)))
(let ((?x1422 (bvand ?x365 (_ bv127 32))))
(let ((?x73 ((_ extract 15 0) ?x1422)))
(let (($x324 (or false false)))
(let (($x71 (or $x324 false false)))
(let (($x72 (or $x71 false)))
(let (($x1909 (not $x72)))
(and $x1909 (or $x72 (and (distinct ?x73 ?x73) true)))))))))))
(check-sat)
; query 3: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x324 (or false false)))
(let (($x126 (not $x324)))
(and $x126 (or $x324 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 4: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x502 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x324 (or false false)))
(let (($x71 (or $x324 false false)))
(let (($x434 (not $x71)))
(and $x434 (or $x71 (and (distinct ?x502 ?x502) true))))))))
(check-sat)
; query 5: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x1679 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x1874 (or false false false)))
(let (($x95 (not $x1874)))
(and $x95 (or $x1874 (and (distinct ?x1679 ?x1679) true)))))))
(check-sat)
; query 6: function crcu8, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x324 (or false false)))
(let (($x126 (not $x324)))
(and $x126 (or $x324 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 7: function crcu8, block 19, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x1681 ((_ zero_extend 16) in.01_16)))
(let ((?x108 (bvxor ?x1681 (_ bv16386 32))))
(let (($x324 (or false false)))
(let (($x71 (or $x324 false false)))
(let (($x434 (not $x71)))
(and $x434 (or $x71 (and (distinct ?x108 ?x108) true)))))))))
(check-sat)
; query 8: function crcu8, block 19, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x1681 ((_ zero_extend 16) in.01_16)))
(let ((?x108 (bvxor ?x1681 (_ bv16386 32))))
(let ((?x31 ((_ extract 15 0) ?x108)))
(let (($x324 (or false false)))
(let (($x71 (or $x324 false false)))
(let (($x72 (or $x71 false)))
(let (($x1909 (not $x72)))
(and $x1909 (or $x72 (and (distinct ?x31 ?x31) true)))))))))))
(check-sat)
; query 9: function crcu8, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x382 ((_ extract 7 0) in.01_16)))
(let ((?x616 ((_ zero_extend 24) ?x382)))
(let (($x324 (or false false)))
(let (($x111 (or $x324 false)))
(and (not $x111) (or $x111 (and (distinct ?x616 ?x616) true))))))))
(check-sat)
; query 10: function crcu8, block 6, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x382 ((_ extract 7 0) in.01_16)))
(let ((?x616 ((_ zero_extend 24) ?x382)))
(let ((?x1935 (bvand ?x616 (_ bv1 32))))
(let (($x324 (or false false)))
(let (($x111 (or $x324 false)))
(let (($x448 (or $x111 false false)))
(and (not $x448) (or $x448 (and (distinct ?x1935 ?x1935) true))))))))))
(check-sat)
; query 11: function crcu8, block 6, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x382 ((_ extract 7 0) in.01_16)))
(let ((?x616 ((_ zero_extend 24) ?x382)))
(let ((?x1935 (bvand ?x616 (_ bv1 32))))
(let ((?x1919 ((_ zero_extend 24) in.0_8)))
(let ((?x172 (bvand ?x1919 (_ bv1 32))))
(let ((?x244 (bvxor ?x172 ?x1935)))
(let (($x324 (or false false)))
(let (($x111 (or $x324 false)))
(let (($x448 (or $x111 false false)))
(let (($x71 (or $x324 false false)))
(let (($x486 (or $x71 $x448 false)))
(and (not $x486) (or $x486 (and (distinct ?x244 ?x244) true)))))))))))))))
(check-sat)
; query 12: function crcu8, block 6, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x382 ((_ extract 7 0) in.01_16)))
(let ((?x616 ((_ zero_extend 24) ?x382)))
(let ((?x1935 (bvand ?x616 (_ bv1 32))))
(let ((?x1919 ((_ zero_extend 24) in.0_8)))
(let ((?x172 (bvand ?x1919 (_ bv1 32))))
(let ((?x244 (bvxor ?x172 ?x1935)))
(let ((?x3177 ((_ extract 7 0) ?x244)))
(let (($x324 (or false false)))
(let (($x111 (or $x324 false)))
(let (($x448 (or $x111 false false)))
(let (($x71 (or $x324 false false)))
(let (($x486 (or $x71 $x448 false)))
(let (($x3322 (or $x486 false)))
(and (not $x3322) (or $x3322 (and (distinct ?x3177 ?x3177) true)))))))))))))))))
(check-sat)
; query 13: function crcu8, block 6, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x324 (or false false)))
(let (($x126 (not $x324)))
(and $x126 (or $x324 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 14: function crcu8, block 6, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1919 ((_ zero_extend 24) in.0_8)))
(let ((?x908 (bvashr ?x1919 (_ bv1 32))))
(let (($x324 (or false false)))
(let (($x71 (or $x324 false false)))
(let (($x1899 (or $x71 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not $x1899) (or $x1899 (and (distinct ?x908 ?x908) true)))))))))
(check-sat)
; query 15: function crcu8, block 6, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1919 ((_ zero_extend 24) in.0_8)))
(let ((?x908 (bvashr ?x1919 (_ bv1 32))))
(let ((?x1858 ((_ extract 7 0) ?x908)))
(let (($x324 (or false false)))
(let (($x71 (or $x324 false false)))
(let (($x1899 (or $x71 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x38 (or $x1899 false)))
(and (not $x38) (or $x38 (and (distinct ?x1858 ?x1858) true)))))))))))
(check-sat)
; query 16: function crcu8, block 6, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x382 ((_ extract 7 0) in.01_16)))
(let ((?x616 ((_ zero_extend 24) ?x382)))
(let ((?x1935 (bvand ?x616 (_ bv1 32))))
(let ((?x1919 ((_ zero_extend 24) in.0_8)))
(let ((?x172 (bvand ?x1919 (_ bv1 32))))
(let ((?x244 (bvxor ?x172 ?x1935)))
(let ((?x3177 ((_ extract 7 0) ?x244)))
(let ((?x120 ((_ zero_extend 24) ?x3177)))
(let (($x324 (or false false)))
(let (($x111 (or $x324 false)))
(let (($x448 (or $x111 false false)))
(let (($x71 (or $x324 false false)))
(let (($x486 (or $x71 $x448 false)))
(let (($x3322 (or $x486 false)))
(let (($x139 (or $x3322 false)))
(and (not $x139) (or $x139 (and (distinct ?x120 ?x120) true)))))))))))))))))))
(check-sat)
; query 17: function crcu8, block 6, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x382 ((_ extract 7 0) in.01_16)))
(let ((?x616 ((_ zero_extend 24) ?x382)))
(let ((?x1935 (bvand ?x616 (_ bv1 32))))
(let ((?x1919 ((_ zero_extend 24) in.0_8)))
(let ((?x172 (bvand ?x1919 (_ bv1 32))))
(let ((?x244 (bvxor ?x172 ?x1935)))
(let ((?x3177 ((_ extract 7 0) ?x244)))
(let ((?x120 ((_ zero_extend 24) ?x3177)))
(let ((?x92 (ite (= (_ bv1 32) ?x120) (_ bv1 1) (_ bv0 1))))
(let (($x324 (or false false)))
(let (($x111 (or $x324 false)))
(let (($x448 (or $x111 false false)))
(let (($x71 (or $x324 false false)))
(let (($x486 (or $x71 $x448 false)))
(let (($x3322 (or $x486 false)))
(let (($x139 (or $x3322 false)))
(let (($x85 (or $x139 false false)))
(and (not $x85) (or $x85 (and (distinct ?x92 ?x92) true)))))))))))))))))))))
(check-sat)
; query 18: function crcu8, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x324 (or false false)))
(let (($x126 (not $x324)))
(and $x126 (or $x324 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 19: function crcu8, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1919 ((_ zero_extend 24) in.0_8)))
(let ((?x172 (bvand ?x1919 (_ bv1 32))))
(let (($x324 (or false false)))
(let (($x71 (or $x324 false false)))
(let (($x434 (not $x71)))
(and $x434 (or $x71 (and (distinct ?x172 ?x172) true)))))))))
(check-sat)
; query 20: function crcu8, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x324 (or false false)))
(let (($x126 (not $x324)))
(and $x126 (or $x324 (and (distinct ((_ extract 7 0) in.01_16) ((_ extract 7 0) in.01_16)) true))))))
(check-sat)
; query 21: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1922 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x408 ((_ zero_extend 31) ?x1922)))
(let ((?x948 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x362 ((_ zero_extend 31) ?x948)))
(let ((?x509 (bvand ?x362 ?x408)))
(let ((?x432 (ite (and (distinct (_ bv0 32) ?x509) true) (_ bv1 1) (_ bv0 1))))
(let ((?x210 ((_ zero_extend 63) ?x432)))
(let (($x324 (or false false)))
(let (($x71 (or $x324 false false)))
(let (($x72 (or $x71 false)))
(let (($x161 (or $x72 $x72 false)))
(let (($x464 (or $x161 false false)))
(let (($x605 (or $x464 false)))
(and (not $x605) (or $x605 (and (distinct ?x210 ?x210) true)))))))))))))))))
(check-sat)
; query 22: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1922 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x408 ((_ zero_extend 31) ?x1922)))
(let ((?x948 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x362 ((_ zero_extend 31) ?x948)))
(let ((?x509 (bvand ?x362 ?x408)))
(let ((?x432 (ite (and (distinct (_ bv0 32) ?x509) true) (_ bv1 1) (_ bv0 1))))
(let (($x35 (= (_ bv1 1) ?x432)))
(let ((?x216 (ite $x35 (_ bv1 32) (_ bv0 32))))
(let (($x324 (or false false)))
(let (($x71 (or $x324 false false)))
(let (($x72 (or $x71 false)))
(let (($x161 (or $x72 $x72 false)))
(let (($x464 (or $x161 false false)))
(let (($x77 (or $x464 (ite $x35 false false))))
(and (not $x77) (or $x77 (and (distinct ?x216 ?x216) true))))))))))))))))))
(check-sat)
; query 23: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1922 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x408 ((_ zero_extend 31) ?x1922)))
(let ((?x948 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x362 ((_ zero_extend 31) ?x948)))
(let ((?x509 (bvand ?x362 ?x408)))
(let ((?x432 (ite (and (distinct (_ bv0 32) ?x509) true) (_ bv1 1) (_ bv0 1))))
(let (($x35 (= (_ bv1 1) ?x432)))
(let ((?x216 (ite $x35 (_ bv1 32) (_ bv0 32))))
(let ((?x96 ((_ extract 7 0) ?x216)))
(let (($x324 (or false false)))
(let (($x71 (or $x324 false false)))
(let (($x72 (or $x71 false)))
(let (($x161 (or $x72 $x72 false)))
(let (($x464 (or $x161 false false)))
(let (($x77 (or $x464 (ite $x35 false false))))
(let (($x167 (or $x77 false)))
(and (not $x167) (or $x167 (and (distinct ?x96 ?x96) true))))))))))))))))))))
(check-sat)
; query 24: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x324 (or false false)))
(let (($x126 (not $x324)))
(and $x126 (or $x324 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 25: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x948 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x324 (or false false)))
(let (($x71 (or $x324 false false)))
(let (($x434 (not $x71)))
(and $x434 (or $x71 (and (distinct ?x948 ?x948) true))))))))
(check-sat)
; query 26: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x948 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x362 ((_ zero_extend 31) ?x948)))
(let (($x324 (or false false)))
(let (($x71 (or $x324 false false)))
(let (($x72 (or $x71 false)))
(let (($x1909 (not $x72)))
(and $x1909 (or $x72 (and (distinct ?x362 ?x362) true))))))))))
(check-sat)
; query 27: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x324 (or false false)))
(let (($x126 (not $x324)))
(and $x126 (or $x324 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 28: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1922 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x324 (or false false)))
(let (($x71 (or $x324 false false)))
(let (($x434 (not $x71)))
(and $x434 (or $x71 (and (distinct ?x1922 ?x1922) true))))))))
(check-sat)
; query 29: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1922 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x408 ((_ zero_extend 31) ?x1922)))
(let (($x324 (or false false)))
(let (($x71 (or $x324 false false)))
(let (($x72 (or $x71 false)))
(let (($x1909 (not $x72)))
(and $x1909 (or $x72 (and (distinct ?x408 ?x408) true))))))))))
(check-sat)
; query 30: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1922 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x408 ((_ zero_extend 31) ?x1922)))
(let ((?x948 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x362 ((_ zero_extend 31) ?x948)))
(let ((?x509 (bvand ?x362 ?x408)))
(let (($x324 (or false false)))
(let (($x71 (or $x324 false false)))
(let (($x72 (or $x71 false)))
(let (($x161 (or $x72 $x72 false)))
(and (not $x161) (or $x161 (and (distinct ?x509 ?x509) true)))))))))))))
(check-sat)
; query 31: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x1922 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x408 ((_ zero_extend 31) ?x1922)))
(let ((?x948 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x362 ((_ zero_extend 31) ?x948)))
(let ((?x509 (bvand ?x362 ?x408)))
(let ((?x432 (ite (and (distinct (_ bv0 32) ?x509) true) (_ bv1 1) (_ bv0 1))))
(let (($x324 (or false false)))
(let (($x71 (or $x324 false false)))
(let (($x72 (or $x71 false)))
(let (($x161 (or $x72 $x72 false)))
(let (($x464 (or $x161 false false)))
(and (not $x464) (or $x464 (and (distinct ?x432 ?x432) true)))))))))))))))
(check-sat)
; query 32: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x922 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x1874 (or false false false)))
(let (($x95 (not $x1874)))
(and $x95 (or $x1874 (and (distinct ?x922 ?x922) true)))))))
(check-sat)
