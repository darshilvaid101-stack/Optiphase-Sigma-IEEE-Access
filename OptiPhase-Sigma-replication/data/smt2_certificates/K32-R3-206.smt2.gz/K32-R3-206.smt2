; OptiPhase-Sigma refinement certificate for sweep K32-R3-206
; query 0: function compare, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in7_32 () (_ BitVec 32))
(assert
 (let ((?x225 (ite (= (_ bv0 32) in7_32) (_ bv1 1) (_ bv0 1))))
(let (($x130 (or false false false)))
(let (($x100 (not $x130)))
(and $x100 (or $x130 (and (distinct ?x225 ?x225) true)))))))
(check-sat)
; query 1: function compare, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in7_32 () (_ BitVec 32))
(assert
 (let ((?x225 (ite (= (_ bv0 32) in7_32) (_ bv1 1) (_ bv0 1))))
(let ((?x82 ((_ zero_extend 63) ?x225)))
(let (($x130 (or false false false)))
(let (($x50 (or $x130 false)))
(and (not $x50) (or $x50 (and (distinct ?x82 ?x82) true))))))))
(check-sat)
; query 2: function compare, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in7_32 () (_ BitVec 32))
(assert
 (let ((?x225 (ite (= (_ bv0 32) in7_32) (_ bv1 1) (_ bv0 1))))
(let (($x72 (= (_ bv1 1) ?x225)))
(let ((?x231 (ite $x72 (_ bv0 32) (_ bv4294967295 32))))
(let (($x130 (or false false false)))
(let (($x48 (or $x130 (ite $x72 false false))))
(and (not $x48) (or $x48 (and (distinct ?x231 ?x231) true)))))))))
(check-sat)
; query 3: function main, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x314 (ite (bvsgt (_ bv60000 32) in.0_32) (_ bv1 1) (_ bv0 1))))
(let (($x130 (or false false false)))
(let (($x100 (not $x130)))
(and $x100 (or $x130 (and (distinct ?x314 ?x314) true)))))))
(check-sat)
; query 4: function main, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x315 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x126 (or false false (or $x315))))
(and (not $x126) (or $x126 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 5: function main, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x191 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x95 (or false false (or $x191))))
(and (not $x95) (or $x95 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
