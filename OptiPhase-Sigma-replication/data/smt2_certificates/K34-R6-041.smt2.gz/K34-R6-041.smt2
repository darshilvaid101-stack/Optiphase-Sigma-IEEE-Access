; OptiPhase-Sigma refinement certificate for sweep K34-R6-041
; query 0: function edge_draw, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let ((?x184 (ite (= (_ bv0 32) in4_32) (_ bv1 1) (_ bv0 1))))
(let (($x76 (or false false false)))
(let (($x271 (not $x76)))
(and $x271 (or $x76 (and (distinct ?x184 ?x184) true)))))))
(check-sat)
; query 1: function main, block 129, name %130
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.011.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x192 (ite (and (distinct (_ bv0 32) in.011.lcssa_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x76 (or false false false)))
(let (($x271 (not $x76)))
(and $x271 (or $x76 (and (distinct ?x192 ?x192) true)))))))
(check-sat)
; query 2: function main, block 160, name %161
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x301 (ite (and (distinct (_ bv0 32) in.01.lcssa_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x76 (or false false false)))
(let (($x271 (not $x76)))
(and $x271 (or $x76 (and (distinct ?x301 ?x301) true)))))))
(check-sat)
; query 3: function main, block 66, name %67
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x66 (ite (= (_ bv0 32) in.0.lcssa_32) (_ bv1 1) (_ bv0 1))))
(let (($x76 (or false false false)))
(let (($x271 (not $x76)))
(and $x271 (or $x76 (and (distinct ?x66 ?x66) true)))))))
(check-sat)
; query 4: function main, block 84, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.07.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x404 (ite (and (distinct (_ bv0 32) in.07.lcssa_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x76 (or false false false)))
(let (($x271 (not $x76)))
(and $x271 (or $x76 (and (distinct ?x404 ?x404) true)))))))
(check-sat)
