; OptiPhase-Sigma refinement certificate for sweep K44-R4-336
; query 0: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x99 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x135 (or false false false)))
(let (($x81 (not $x135)))
(and $x81 (or $x135 (and (distinct ?x99 ?x99) true)))))))
(check-sat)
; query 1: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x450 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x135 (or false false false)))
(let (($x81 (not $x135)))
(and $x81 (or $x135 (and (distinct ?x450 ?x450) true)))))))
(check-sat)
