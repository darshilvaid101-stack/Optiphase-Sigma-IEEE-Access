; OptiPhase-Sigma refinement certificate for sweep K00-R3-083
