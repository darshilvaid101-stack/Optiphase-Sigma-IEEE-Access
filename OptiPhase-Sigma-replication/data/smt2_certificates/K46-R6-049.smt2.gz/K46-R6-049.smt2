; OptiPhase-Sigma refinement certificate for sweep K46-R6-049
; query 0: function adpcm_decoder, block 61, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.210_32 () (_ BitVec 32))
(declare-fun in.013_32 () (_ BitVec 32))
(assert
 (let ((?x169 (bvadd in.013_32 in.210_32)))
(let ((?x127 (bvsub in.013_32 in.210_32)))
(let (($x243 (and (distinct (bvadd ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x169)) true)))
(let (($x49 (and (distinct (bvsub ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x127)) true)))
(and (not (or false false (or $x49))) (or (or false false (or $x243)) (and (distinct ?x127 ?x169) true))))))))
(check-sat)
; query 1: function main, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x199 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x28 (or false false false)))
(and (not $x28) (or $x28 (and (distinct ?x199 ?x199) true))))))
(check-sat)
