; OptiPhase-Sigma refinement certificate for sweep K56-R6-007
; query 0: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x336 (or false false false)))
(let (($x1128 (not $x336)))
(and $x1128 (or $x336 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x479 (bvadd in.01_32 (_ bv1 32))))
(let ((?x64 (bvmul ?x479 ?x479)))
(let (($x336 (or false false false)))
(let (($x18 (or $x336 $x336 false)))
(and (not $x18) (or $x18 (and (distinct ?x64 ?x64) true))))))))
(check-sat)
; query 2: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x479 (bvadd in.01_32 (_ bv1 32))))
(let ((?x64 (bvmul ?x479 ?x479)))
(let ((?x37 (bvmul ?x64 (_ bv2 32))))
(let (($x336 (or false false false)))
(let (($x18 (or $x336 $x336 false)))
(let (($x1667 (or $x18 false false)))
(and (not $x1667) (or $x1667 (and (distinct ?x37 ?x37) true))))))))))
(check-sat)
; query 3: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x479 (bvadd in.01_32 (_ bv1 32))))
(let ((?x64 (bvmul ?x479 ?x479)))
(let ((?x37 (bvmul ?x64 (_ bv2 32))))
(let ((?x191 (bvmul ?x37 (_ bv4 32))))
(let (($x336 (or false false false)))
(let (($x18 (or $x336 $x336 false)))
(let (($x1667 (or $x18 false false)))
(let (($x28 (or $x1667 false false)))
(and (not $x28) (or $x28 (and (distinct ?x191 ?x191) true))))))))))))
(check-sat)
; query 4: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x681 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x336 (or false false false)))
(let (($x1128 (not $x336)))
(and $x1128 (or $x336 (and (distinct ?x681 ?x681) true)))))))
(check-sat)
; query 5: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x1669 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x336 (or false false false)))
(let (($x1128 (not $x336)))
(and $x1128 (or $x336 (and (distinct ?x1669 ?x1669) true)))))))
(check-sat)
; query 6: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x336 (or false false false)))
(let (($x1128 (not $x336)))
(and $x1128 (or $x336 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 7: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x176 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x614 (or false false (or $x176))))
(and (not $x614) (or $x614 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x142 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x336 (or false false false)))
(let (($x1128 (not $x336)))
(and $x1128 (or $x336 (and (distinct ?x142 ?x142) true)))))))
(check-sat)
; query 9: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x74 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x336 (or false false false)))
(let (($x1128 (not $x336)))
(and $x1128 (or $x336 (and (distinct ?x74 ?x74) true)))))))
(check-sat)
; query 10: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x155 (or false false)))
(and (not $x155) (or $x155 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true)))))
(check-sat)
; query 11: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x418 ((_ sign_extend 16) in.1_16)))
(let ((?x725 (bvadd ?x418 (_ bv10 32))))
(let (($x24 (and (distinct (bvadd ((_ sign_extend 1) ?x418) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x725)) true)))
(let (($x155 (or false false)))
(let (($x114 (or $x155 false (or $x24))))
(and (not $x114) (or $x114 (and (distinct ?x725 ?x725) true)))))))))
(check-sat)
; query 12: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x418 ((_ sign_extend 16) in.1_16)))
(let ((?x725 (bvadd ?x418 (_ bv10 32))))
(let ((?x147 ((_ extract 15 0) ?x725)))
(let (($x24 (and (distinct (bvadd ((_ sign_extend 1) ?x418) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x725)) true)))
(let (($x155 (or false false)))
(let (($x114 (or $x155 false (or $x24))))
(let (($x781 (or $x114 false)))
(and (not $x781) (or $x781 (and (distinct ?x147 ?x147) true)))))))))))
(check-sat)
