; OptiPhase-Sigma refinement certificate for sweep K38-R3-207
; query 0: function main, block 60, name %61
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x44 (or false false)))
(and (not $x44) (or $x44 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 1: function main, block 60, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x62 (ite (bvsge (_ bv57 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x44 (or false false)))
(let (($x65 (or $x44 false false)))
(let (($x49 (not $x65)))
(and $x49 (or $x65 (and (distinct ?x62 ?x62) true))))))))
(check-sat)
; query 2: function main, block 63, name %64
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x521 (or (or false false false) (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x521) (or $x521 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvshl in.01_32 (_ bv4 32))) true)))))
(check-sat)
; query 3: function main, block 63, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x44 (or false false)))
(and (not $x44) (or $x44 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 4: function main, block 63, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x24 ((_ sign_extend 24) in57_8)))
(let ((?x146 (bvshl in.01_32 (_ bv4 32))))
(let ((?x210 (bvadd ?x146 ?x24)))
(let ((?x418 ((_ sign_extend 1) ?x210)))
(let (($x44 (or false false)))
(let (($x521 (or (or false false false) (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x161 (or $x521 $x44 (or (and (distinct (bvadd ((_ sign_extend 1) ?x146) ((_ sign_extend 1) ?x24)) ?x418) true)))))
(and (not $x161) (or $x161 (and (distinct ?x210 ?x210) true)))))))))))
(check-sat)
; query 5: function main, block 63, name %67
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x24 ((_ sign_extend 24) in57_8)))
(let ((?x146 (bvshl in.01_32 (_ bv4 32))))
(let ((?x210 (bvadd ?x146 ?x24)))
(let ((?x335 (bvsub ?x210 (_ bv48 32))))
(let (($x34 (and (distinct (bvsub ((_ sign_extend 1) ?x210) ((_ sign_extend 1) (_ bv48 32))) ((_ sign_extend 1) ?x335)) true)))
(let ((?x418 ((_ sign_extend 1) ?x210)))
(let (($x44 (or false false)))
(let (($x521 (or (or false false false) (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x161 (or $x521 $x44 (or (and (distinct (bvadd ((_ sign_extend 1) ?x146) ((_ sign_extend 1) ?x24)) ?x418) true)))))
(let (($x30 (or $x161 false (or $x34))))
(and (not $x30) (or $x30 (and (distinct ?x335 ?x335) true))))))))))))))
(check-sat)
; query 6: function main, block 68, name %69
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x44 (or false false)))
(and (not $x44) (or $x44 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 7: function main, block 68, name %70
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x73 (ite (bvsle (_ bv65 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x44 (or false false)))
(let (($x65 (or $x44 false false)))
(let (($x49 (not $x65)))
(and $x49 (or $x65 (and (distinct ?x73 ?x73) true))))))))
(check-sat)
; query 8: function main, block 71, name %72
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x44 (or false false)))
(and (not $x44) (or $x44 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 9: function main, block 71, name %73
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x96 (ite (bvsge (_ bv70 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x44 (or false false)))
(let (($x65 (or $x44 false false)))
(let (($x49 (not $x65)))
(and $x49 (or $x65 (and (distinct ?x96 ?x96) true))))))))
(check-sat)
; query 10: function main, block 74, name %75
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x521 (or (or false false false) (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x521) (or $x521 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvshl in.01_32 (_ bv4 32))) true)))))
(check-sat)
; query 11: function main, block 74, name %76
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x44 (or false false)))
(and (not $x44) (or $x44 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 12: function main, block 74, name %77
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x24 ((_ sign_extend 24) in57_8)))
(let ((?x146 (bvshl in.01_32 (_ bv4 32))))
(let ((?x210 (bvadd ?x146 ?x24)))
(let ((?x418 ((_ sign_extend 1) ?x210)))
(let (($x44 (or false false)))
(let (($x521 (or (or false false false) (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x161 (or $x521 $x44 (or (and (distinct (bvadd ((_ sign_extend 1) ?x146) ((_ sign_extend 1) ?x24)) ?x418) true)))))
(and (not $x161) (or $x161 (and (distinct ?x210 ?x210) true)))))))))))
(check-sat)
; query 13: function main, block 74, name %78
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x24 ((_ sign_extend 24) in57_8)))
(let ((?x146 (bvshl in.01_32 (_ bv4 32))))
(let ((?x210 (bvadd ?x146 ?x24)))
(let ((?x72 (bvsub ?x210 (_ bv65 32))))
(let ((?x77 ((_ sign_extend 1) ?x72)))
(let ((?x418 ((_ sign_extend 1) ?x210)))
(let (($x44 (or false false)))
(let (($x521 (or (or false false false) (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x161 (or $x521 $x44 (or (and (distinct (bvadd ((_ sign_extend 1) ?x146) ((_ sign_extend 1) ?x24)) ?x418) true)))))
(let (($x139 (or $x161 false (or (and (distinct (bvsub ?x418 ((_ sign_extend 1) (_ bv65 32))) ?x77) true)))))
(and (not $x139) (or $x139 (and (distinct ?x72 ?x72) true))))))))))))))
(check-sat)
; query 14: function main, block 74, name %79
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x24 ((_ sign_extend 24) in57_8)))
(let ((?x146 (bvshl in.01_32 (_ bv4 32))))
(let ((?x210 (bvadd ?x146 ?x24)))
(let ((?x72 (bvsub ?x210 (_ bv65 32))))
(let ((?x202 (bvadd ?x72 (_ bv10 32))))
(let (($x454 (and (distinct (bvadd ((_ sign_extend 1) ?x72) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x202)) true)))
(let ((?x77 ((_ sign_extend 1) ?x72)))
(let ((?x418 ((_ sign_extend 1) ?x210)))
(let (($x44 (or false false)))
(let (($x521 (or (or false false false) (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x161 (or $x521 $x44 (or (and (distinct (bvadd ((_ sign_extend 1) ?x146) ((_ sign_extend 1) ?x24)) ?x418) true)))))
(let (($x139 (or $x161 false (or (and (distinct (bvsub ?x418 ((_ sign_extend 1) (_ bv65 32))) ?x77) true)))))
(let (($x18 (or $x139 false (or $x454))))
(and (not $x18) (or $x18 (and (distinct ?x202 ?x202) true)))))))))))))))))
(check-sat)
