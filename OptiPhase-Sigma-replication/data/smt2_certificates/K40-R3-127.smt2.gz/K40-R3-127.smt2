; OptiPhase-Sigma refinement certificate for sweep K40-R3-127
; query 0: function set_key, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let (($x132 (or false false false)))
(and (not $x132) (or $x132 (and (distinct (bvand in1_64 (_ bv7 64)) (bvand in1_64 (_ bv7 64))) true)))))
(check-sat)
