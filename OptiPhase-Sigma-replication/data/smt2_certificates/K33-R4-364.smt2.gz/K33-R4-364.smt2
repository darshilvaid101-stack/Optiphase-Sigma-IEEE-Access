; OptiPhase-Sigma refinement certificate for sweep K33-R4-364
; query 0: function edge_draw, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let ((?x263 (ite (= (_ bv0 32) in4_32) (_ bv1 1) (_ bv0 1))))
(let (($x582 (or false false false)))
(and (not $x582) (or $x582 (and (distinct ?x263 ?x263) true))))))
(check-sat)
