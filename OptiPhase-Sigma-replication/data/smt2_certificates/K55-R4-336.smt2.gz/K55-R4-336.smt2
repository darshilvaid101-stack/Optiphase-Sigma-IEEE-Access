; OptiPhase-Sigma refinement certificate for sweep K55-R4-336
; query 0: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x111 (or false false false)))
(let (($x24 (not $x111)))
(and $x24 (or $x111 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 1: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x89 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x111 (or false false false)))
(let (($x24 (not $x111)))
(and $x24 (or $x111 (and (distinct ?x89 ?x89) true)))))))
(check-sat)
