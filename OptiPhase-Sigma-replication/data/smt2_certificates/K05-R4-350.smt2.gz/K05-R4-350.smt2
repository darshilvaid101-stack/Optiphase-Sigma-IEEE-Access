; OptiPhase-Sigma refinement certificate for sweep K05-R4-350
