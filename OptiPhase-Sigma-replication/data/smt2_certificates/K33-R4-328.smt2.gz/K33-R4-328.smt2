; OptiPhase-Sigma refinement certificate for sweep K33-R4-328
; query 0: function edge_draw, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let ((?x241 (ite (= (_ bv0 32) in4_32) (_ bv1 1) (_ bv0 1))))
(let (($x141 (or false false false)))
(and (not $x141) (or $x141 (and (distinct ?x241 ?x241) true))))))
(check-sat)
