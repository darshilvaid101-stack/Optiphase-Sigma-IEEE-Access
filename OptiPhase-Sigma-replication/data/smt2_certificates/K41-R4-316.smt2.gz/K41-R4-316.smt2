; OptiPhase-Sigma refinement certificate for sweep K41-R4-316
; query 0: function set_key, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let (($x114 (or false false false)))
(and (not $x114) (or $x114 (and (distinct (bvand in1_64 (_ bv7 64)) (bvand in1_64 (_ bv7 64))) true)))))
(check-sat)
; query 1: function set_key, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x7 (ite (and (distinct (_ bv0 64) (bvand in1_64 (_ bv7 64))) true) (_ bv1 1) (_ bv0 1))))
(let (($x114 (or false false false)))
(let (($x148 (or $x114 false false)))
(and (not $x148) (or $x148 (and (distinct ?x7 ?x7) true)))))))
(check-sat)
