; OptiPhase-Sigma refinement certificate for sweep K44-R3-092
; query 0: function IsPowerOfTwo, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x181 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x146 (or false false false)))
(let (($x89 (not $x146)))
(and $x89 (or $x146 (and (distinct ?x181 ?x181) true)))))))
(check-sat)
; query 1: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x181 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x146 (or false false false)))
(let (($x89 (not $x146)))
(and $x89 (or $x146 (and (distinct ?x181 ?x181) true)))))))
(check-sat)
; query 2: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x745 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x146 (or false false false)))
(let (($x89 (not $x146)))
(and $x89 (or $x146 (and (distinct ?x745 ?x745) true)))))))
(check-sat)
