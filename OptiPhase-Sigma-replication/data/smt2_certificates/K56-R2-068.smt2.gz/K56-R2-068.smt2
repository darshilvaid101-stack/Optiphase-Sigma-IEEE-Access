; OptiPhase-Sigma refinement certificate for sweep K56-R2-068
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x318 (or false false)))
(let (($x155 (not $x318)))
(and $x155 (or $x318 (and (distinct ((_ sign_extend 16) in25_16) ((_ sign_extend 16) in25_16)) true))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let ((?x1272 (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))))
(let (($x318 (or false false)))
(let (($x1266 (or $x318 false false)))
(let (($x173 (not $x1266)))
(and $x173 (or $x1266 (and (distinct ?x1272 ?x1272) true))))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x318 (or false false)))
(let (($x155 (not $x318)))
(and $x155 (or $x318 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x50 ((_ sign_extend 16) in3_16)))
(let ((?x99 (bvand ?x50 (_ bv127 32))))
(let (($x318 (or false false)))
(let (($x1266 (or $x318 false false)))
(let (($x173 (not $x1266)))
(and $x173 (or $x1266 (and (distinct ?x99 ?x99) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x50 ((_ sign_extend 16) in3_16)))
(let ((?x99 (bvand ?x50 (_ bv127 32))))
(let ((?x143 ((_ extract 15 0) ?x99)))
(let (($x318 (or false false)))
(let (($x1266 (or $x318 false false)))
(let (($x119 (or $x1266 false)))
(let (($x323 (not $x119)))
(and $x323 (or $x119 (and (distinct ?x143 ?x143) true)))))))))))
(check-sat)
; query 5: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x318 (or false false)))
(let (($x155 (not $x318)))
(and $x155 (or $x318 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 6: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x81 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x318 (or false false)))
(let (($x1266 (or $x318 false false)))
(let (($x173 (not $x1266)))
(and $x173 (or $x1266 (and (distinct ?x81 ?x81) true))))))))
(check-sat)
; query 7: function core_bench_list, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x347 (or false false false)))
(let (($x339 (not $x347)))
(and $x339 (or $x347 (and (distinct (bvadd in.0_16 (_ bv1 16)) (bvadd in.0_16 (_ bv1 16))) true))))))
(check-sat)
; query 8: function core_bench_state, block 105, name %106
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x347 (or false false false)))
(let (($x339 (not $x347)))
(and $x339 (or $x347 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 9: function core_bench_state, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x347 (or false false false)))
(let (($x339 (not $x347)))
(and $x339 (or $x347 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 10: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1273 (bvadd in.01_32 (_ bv1 32))))
(let (($x34 (and (distinct ?x1273 ?x1273) true)))
(let (($x347 (or false false false)))
(let (($x339 (not $x347)))
(and $x339 (or $x347 $x34)))))))
(check-sat)
; query 11: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1273 (bvadd in.01_32 (_ bv1 32))))
(let ((?x547 (bvmul ?x1273 ?x1273)))
(let (($x347 (or false false false)))
(let (($x1011 (or $x347 $x347 false)))
(and (not $x1011) (or $x1011 (and (distinct ?x547 ?x547) true))))))))
(check-sat)
; query 12: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1273 (bvadd in.01_32 (_ bv1 32))))
(let ((?x547 (bvmul ?x1273 ?x1273)))
(let ((?x365 (bvmul ?x547 (_ bv2 32))))
(let (($x347 (or false false false)))
(let (($x1011 (or $x347 $x347 false)))
(let (($x76 (or $x1011 false false)))
(and (not $x76) (or $x76 (and (distinct ?x365 ?x365) true))))))))))
(check-sat)
; query 13: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1273 (bvadd in.01_32 (_ bv1 32))))
(let ((?x547 (bvmul ?x1273 ?x1273)))
(let ((?x365 (bvmul ?x547 (_ bv2 32))))
(let ((?x181 (bvmul ?x365 (_ bv4 32))))
(let (($x347 (or false false false)))
(let (($x1011 (or $x347 $x347 false)))
(let (($x76 (or $x1011 false false)))
(let (($x42 (or $x76 false false)))
(and (not $x42) (or $x42 (and (distinct ?x181 ?x181) true))))))))))))
(check-sat)
; query 14: function core_init_matrix, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x347 (or false false false)))
(let (($x339 (not $x347)))
(and $x339 (or $x347 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 15: function core_init_matrix, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x347 (or false false false)))
(let (($x339 (not $x347)))
(and $x339 (or $x347 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 16: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x601 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x347 (or false false false)))
(let (($x339 (not $x347)))
(and $x339 (or $x347 (and (distinct ?x601 ?x601) true)))))))
(check-sat)
; query 17: function core_init_state, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_32 () (_ BitVec 32))
(assert
 (let (($x347 (or false false false)))
(let (($x339 (not $x347)))
(and $x339 (or $x347 (and (distinct (bvadd in.06_32 (_ bv1 32)) (bvadd in.06_32 (_ bv1 32))) true))))))
(check-sat)
; query 18: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x109 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x347 (or false false false)))
(let (($x339 (not $x347)))
(and $x339 (or $x347 (and (distinct ?x109 ?x109) true)))))))
(check-sat)
; query 19: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x347 (or false false false)))
(let (($x339 (not $x347)))
(and $x339 (or $x347 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 20: function core_list_init, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1273 (bvadd in.01_32 (_ bv1 32))))
(let (($x34 (and (distinct ?x1273 ?x1273) true)))
(let (($x347 (or false false false)))
(let (($x339 (not $x347)))
(and $x339 (or $x347 $x34)))))))
(check-sat)
; query 21: function core_list_mergesort, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1273 (bvadd in.01_32 (_ bv1 32))))
(let (($x34 (and (distinct ?x1273 ?x1273) true)))
(let (($x785 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x1273)) true)))
(let (($x806 (or false false (or $x785))))
(and (not $x806) (or $x806 $x34)))))))
(check-sat)
; query 22: function core_list_mergesort, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x120 (ite (bvslt (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x347 (or false false false)))
(let (($x339 (not $x347)))
(and $x339 (or $x347 (and (distinct ?x120 ?x120) true)))))))
(check-sat)
; query 23: function core_list_mergesort, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.224_32 () (_ BitVec 32))
(assert
 (let ((?x35 (ite (= (_ bv0 32) in.224_32) (_ bv1 1) (_ bv0 1))))
(let (($x347 (or false false false)))
(let (($x339 (not $x347)))
(and $x339 (or $x347 (and (distinct ?x35 ?x35) true)))))))
(check-sat)
; query 24: function core_list_mergesort, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x215 (ite (= (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x347 (or false false false)))
(let (($x339 (not $x347)))
(and $x339 (or $x347 (and (distinct ?x215 ?x215) true)))))))
(check-sat)
; query 25: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x490 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x1223 (or false false (or $x490))))
(and (not $x1223) (or $x1223 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 26: function core_list_mergesort, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x221 (and (distinct (bvmul ((_ sign_extend 32) in.020_32) ((_ sign_extend 32) (_ bv2 32))) ((_ sign_extend 32) (bvmul in.020_32 (_ bv2 32)))) true)))
(let (($x178 (or false false (or $x221))))
(and (not $x178) (or $x178 (and (distinct (bvmul in.020_32 (_ bv2 32)) (bvmul in.020_32 (_ bv2 32))) true))))))
(check-sat)
; query 27: function core_state_transition, block 102, name %103
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x318 (or false false)))
(let (($x155 (not $x318)))
(and $x155 (or $x318 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 28: function core_state_transition, block 102, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x94 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x318 (or false false)))
(let (($x1266 (or $x318 false false)))
(let (($x173 (not $x1266)))
(and $x173 (or $x1266 (and (distinct ?x94 ?x94) true))))))))
(check-sat)
; query 29: function core_state_transition, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x318 (or false false)))
(let (($x155 (not $x318)))
(and $x155 (or $x318 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 30: function core_state_transition, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x292 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x318 (or false false)))
(let (($x1266 (or $x318 false false)))
(let (($x173 (not $x1266)))
(and $x173 (or $x1266 (and (distinct ?x292 ?x292) true))))))))
(check-sat)
; query 31: function core_state_transition, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x318 (or false false)))
(let (($x155 (not $x318)))
(and $x155 (or $x318 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 32: function core_state_transition, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x94 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x318 (or false false)))
(let (($x1266 (or $x318 false false)))
(let (($x173 (not $x1266)))
(and $x173 (or $x1266 (and (distinct ?x94 ?x94) true))))))))
(check-sat)
; query 33: function core_state_transition, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x318 (or false false)))
(let (($x155 (not $x318)))
(and $x155 (or $x318 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 34: function core_state_transition, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x497 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x318 (or false false)))
(let (($x1266 (or $x318 false false)))
(let (($x173 (not $x1266)))
(and $x173 (or $x1266 (and (distinct ?x497 ?x497) true))))))))
(check-sat)
; query 35: function core_state_transition, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x318 (or false false)))
(let (($x155 (not $x318)))
(and $x155 (or $x318 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 36: function core_state_transition, block 51, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x497 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x318 (or false false)))
(let (($x1266 (or $x318 false false)))
(let (($x173 (not $x1266)))
(and $x173 (or $x1266 (and (distinct ?x497 ?x497) true))))))))
(check-sat)
; query 37: function core_state_transition, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x318 (or false false)))
(let (($x155 (not $x318)))
(and $x155 (or $x318 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 38: function core_state_transition, block 64, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x497 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x318 (or false false)))
(let (($x1266 (or $x318 false false)))
(let (($x173 (not $x1266)))
(and $x173 (or $x1266 (and (distinct ?x497 ?x497) true))))))))
(check-sat)
; query 39: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x30 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x347 (or false false false)))
(let (($x339 (not $x347)))
(and $x339 (or $x347 (and (distinct ?x30 ?x30) true)))))))
(check-sat)
; query 40: function core_state_transition, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x318 (or false false)))
(let (($x155 (not $x318)))
(and $x155 (or $x318 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 41: function core_state_transition, block 80, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1277 (ite (= (_ bv69 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x318 (or false false)))
(let (($x1266 (or $x318 false false)))
(let (($x173 (not $x1266)))
(and $x173 (or $x1266 (and (distinct ?x1277 ?x1277) true))))))))
(check-sat)
; query 42: function core_state_transition, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x318 (or false false)))
(let (($x155 (not $x318)))
(and $x155 (or $x318 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 43: function core_state_transition, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1301 (ite (= (_ bv101 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x318 (or false false)))
(let (($x1266 (or $x318 false false)))
(let (($x173 (not $x1266)))
(and $x173 (or $x1266 (and (distinct ?x1301 ?x1301) true))))))))
(check-sat)
; query 44: function core_state_transition, block 99, name %100
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x318 (or false false)))
(let (($x155 (not $x318)))
(and $x155 (or $x318 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 45: function core_state_transition, block 99, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x292 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x318 (or false false)))
(let (($x1266 (or $x318 false false)))
(let (($x173 (not $x1266)))
(and $x173 (or $x1266 (and (distinct ?x292 ?x292) true))))))))
(check-sat)
; query 46: function crcu8, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x318 (or false false)))
(let (($x155 (not $x318)))
(and $x155 (or $x318 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 47: function crcu8, block 19, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x1330 ((_ zero_extend 16) in.01_16)))
(let ((?x229 (bvxor ?x1330 (_ bv16386 32))))
(let (($x318 (or false false)))
(let (($x1266 (or $x318 false false)))
(let (($x173 (not $x1266)))
(and $x173 (or $x1266 (and (distinct ?x229 ?x229) true)))))))))
(check-sat)
; query 48: function crcu8, block 19, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x1330 ((_ zero_extend 16) in.01_16)))
(let ((?x229 (bvxor ?x1330 (_ bv16386 32))))
(let ((?x1350 ((_ extract 15 0) ?x229)))
(let (($x318 (or false false)))
(let (($x1266 (or $x318 false false)))
(let (($x119 (or $x1266 false)))
(let (($x323 (not $x119)))
(and $x323 (or $x119 (and (distinct ?x1350 ?x1350) true)))))))))))
(check-sat)
; query 49: function crcu8, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x318 (or false false)))
(let (($x155 (not $x318)))
(and $x155 (or $x318 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 50: function crcu8, block 29, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x9 ((_ zero_extend 16) in27_16)))
(let ((?x1365 (bvor ?x9 (_ bv32768 32))))
(let (($x318 (or false false)))
(let (($x1266 (or $x318 false false)))
(let (($x173 (not $x1266)))
(and $x173 (or $x1266 (and (distinct ?x1365 ?x1365) true)))))))))
(check-sat)
; query 51: function crcu8, block 29, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x9 ((_ zero_extend 16) in27_16)))
(let ((?x1365 (bvor ?x9 (_ bv32768 32))))
(let ((?x1360 ((_ extract 15 0) ?x1365)))
(let (($x318 (or false false)))
(let (($x1266 (or $x318 false false)))
(let (($x119 (or $x1266 false)))
(let (($x323 (not $x119)))
(and $x323 (or $x119 (and (distinct ?x1360 ?x1360) true)))))))))))
(check-sat)
; query 52: function crcu8, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x318 (or false false)))
(let (($x155 (not $x318)))
(and $x155 (or $x318 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 53: function crcu8, block 33, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x9 ((_ zero_extend 16) in27_16)))
(let ((?x614 (bvand ?x9 (_ bv32767 32))))
(let (($x318 (or false false)))
(let (($x1266 (or $x318 false false)))
(let (($x173 (not $x1266)))
(and $x173 (or $x1266 (and (distinct ?x614 ?x614) true)))))))))
(check-sat)
; query 54: function crcu8, block 33, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x9 ((_ zero_extend 16) in27_16)))
(let ((?x614 (bvand ?x9 (_ bv32767 32))))
(let ((?x1351 ((_ extract 15 0) ?x614)))
(let (($x318 (or false false)))
(let (($x1266 (or $x318 false false)))
(let (($x119 (or $x1266 false)))
(let (($x323 (not $x119)))
(and $x323 (or $x119 (and (distinct ?x1351 ?x1351) true)))))))))))
(check-sat)
; query 55: function crcu8, block 38, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_8 () (_ BitVec 8))
(assert
 (let (($x347 (or false false false)))
(let (($x339 (not $x347)))
(and $x339 (or $x347 (and (distinct (bvadd in.02_8 (_ bv1 8)) (bvadd in.02_8 (_ bv1 8))) true))))))
(check-sat)
; query 56: function crcu8, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x1381 ((_ extract 7 0) in.01_16)))
(let ((?x111 ((_ zero_extend 24) ?x1381)))
(let (($x318 (or false false)))
(let (($x580 (or $x318 false)))
(and (not $x580) (or $x580 (and (distinct ?x111 ?x111) true))))))))
(check-sat)
; query 57: function crcu8, block 6, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x1381 ((_ extract 7 0) in.01_16)))
(let ((?x111 ((_ zero_extend 24) ?x1381)))
(let ((?x789 (bvand ?x111 (_ bv1 32))))
(let (($x318 (or false false)))
(let (($x580 (or $x318 false)))
(let (($x907 (or $x580 false false)))
(and (not $x907) (or $x907 (and (distinct ?x789 ?x789) true))))))))))
(check-sat)
; query 58: function crcu8, block 6, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1381 ((_ extract 7 0) in.01_16)))
(let ((?x111 ((_ zero_extend 24) ?x1381)))
(let ((?x789 (bvand ?x111 (_ bv1 32))))
(let ((?x204 ((_ zero_extend 24) in.0_8)))
(let ((?x1353 (bvand ?x204 (_ bv1 32))))
(let ((?x438 (bvxor ?x1353 ?x789)))
(let (($x318 (or false false)))
(let (($x580 (or $x318 false)))
(let (($x907 (or $x580 false false)))
(let (($x1266 (or $x318 false false)))
(let (($x651 (or $x1266 $x907 false)))
(and (not $x651) (or $x651 (and (distinct ?x438 ?x438) true)))))))))))))))
(check-sat)
; query 59: function crcu8, block 6, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1381 ((_ extract 7 0) in.01_16)))
(let ((?x111 ((_ zero_extend 24) ?x1381)))
(let ((?x789 (bvand ?x111 (_ bv1 32))))
(let ((?x204 ((_ zero_extend 24) in.0_8)))
(let ((?x1353 (bvand ?x204 (_ bv1 32))))
(let ((?x438 (bvxor ?x1353 ?x789)))
(let ((?x535 ((_ extract 7 0) ?x438)))
(let (($x318 (or false false)))
(let (($x580 (or $x318 false)))
(let (($x907 (or $x580 false false)))
(let (($x1266 (or $x318 false false)))
(let (($x651 (or $x1266 $x907 false)))
(let (($x377 (or $x651 false)))
(and (not $x377) (or $x377 (and (distinct ?x535 ?x535) true)))))))))))))))))
(check-sat)
; query 60: function crcu8, block 6, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x318 (or false false)))
(let (($x155 (not $x318)))
(and $x155 (or $x318 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 61: function crcu8, block 6, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x204 ((_ zero_extend 24) in.0_8)))
(let ((?x1349 (bvashr ?x204 (_ bv1 32))))
(let (($x318 (or false false)))
(let (($x1266 (or $x318 false false)))
(let (($x487 (or $x1266 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not $x487) (or $x487 (and (distinct ?x1349 ?x1349) true)))))))))
(check-sat)
; query 62: function crcu8, block 6, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x204 ((_ zero_extend 24) in.0_8)))
(let ((?x1349 (bvashr ?x204 (_ bv1 32))))
(let ((?x1343 ((_ extract 7 0) ?x1349)))
(let (($x318 (or false false)))
(let (($x1266 (or $x318 false false)))
(let (($x487 (or $x1266 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x88 (or $x487 false)))
(and (not $x88) (or $x88 (and (distinct ?x1343 ?x1343) true)))))))))))
(check-sat)
; query 63: function crcu8, block 6, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1381 ((_ extract 7 0) in.01_16)))
(let ((?x111 ((_ zero_extend 24) ?x1381)))
(let ((?x789 (bvand ?x111 (_ bv1 32))))
(let ((?x204 ((_ zero_extend 24) in.0_8)))
(let ((?x1353 (bvand ?x204 (_ bv1 32))))
(let ((?x438 (bvxor ?x1353 ?x789)))
(let ((?x535 ((_ extract 7 0) ?x438)))
(let ((?x176 ((_ zero_extend 24) ?x535)))
(let (($x318 (or false false)))
(let (($x580 (or $x318 false)))
(let (($x907 (or $x580 false false)))
(let (($x1266 (or $x318 false false)))
(let (($x651 (or $x1266 $x907 false)))
(let (($x377 (or $x651 false)))
(let (($x1043 (or $x377 false)))
(and (not $x1043) (or $x1043 (and (distinct ?x176 ?x176) true)))))))))))))))))))
(check-sat)
; query 64: function crcu8, block 6, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1381 ((_ extract 7 0) in.01_16)))
(let ((?x111 ((_ zero_extend 24) ?x1381)))
(let ((?x789 (bvand ?x111 (_ bv1 32))))
(let ((?x204 ((_ zero_extend 24) in.0_8)))
(let ((?x1353 (bvand ?x204 (_ bv1 32))))
(let ((?x438 (bvxor ?x1353 ?x789)))
(let ((?x535 ((_ extract 7 0) ?x438)))
(let ((?x176 ((_ zero_extend 24) ?x535)))
(let ((?x243 (ite (= (_ bv1 32) ?x176) (_ bv1 1) (_ bv0 1))))
(let (($x318 (or false false)))
(let (($x580 (or $x318 false)))
(let (($x907 (or $x580 false false)))
(let (($x1266 (or $x318 false false)))
(let (($x651 (or $x1266 $x907 false)))
(let (($x377 (or $x651 false)))
(let (($x1043 (or $x377 false)))
(let (($x627 (or $x1043 false false)))
(and (not $x627) (or $x627 (and (distinct ?x243 ?x243) true)))))))))))))))))))))
(check-sat)
; query 65: function crcu8, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x318 (or false false)))
(let (($x155 (not $x318)))
(and $x155 (or $x318 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 66: function crcu8, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x204 ((_ zero_extend 24) in.0_8)))
(let ((?x1353 (bvand ?x204 (_ bv1 32))))
(let (($x318 (or false false)))
(let (($x1266 (or $x318 false false)))
(let (($x173 (not $x1266)))
(and $x173 (or $x1266 (and (distinct ?x1353 ?x1353) true)))))))))
(check-sat)
; query 67: function crcu8, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x318 (or false false)))
(let (($x155 (not $x318)))
(and $x155 (or $x318 (and (distinct ((_ extract 7 0) in.01_16) ((_ extract 7 0) in.01_16)) true))))))
(check-sat)
; query 68: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x504 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x259 ((_ zero_extend 31) ?x504)))
(let ((?x74 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x463 ((_ zero_extend 31) ?x74)))
(let ((?x270 (bvand ?x463 ?x259)))
(let ((?x710 (ite (and (distinct (_ bv0 32) ?x270) true) (_ bv1 1) (_ bv0 1))))
(let ((?x183 ((_ zero_extend 63) ?x710)))
(let (($x318 (or false false)))
(let (($x1266 (or $x318 false false)))
(let (($x119 (or $x1266 false)))
(let (($x348 (or $x119 $x119 false)))
(let (($x917 (or $x348 false false)))
(let (($x378 (or $x917 false)))
(and (not $x378) (or $x378 (and (distinct ?x183 ?x183) true)))))))))))))))))
(check-sat)
; query 69: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x504 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x259 ((_ zero_extend 31) ?x504)))
(let ((?x74 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x463 ((_ zero_extend 31) ?x74)))
(let ((?x270 (bvand ?x463 ?x259)))
(let ((?x710 (ite (and (distinct (_ bv0 32) ?x270) true) (_ bv1 1) (_ bv0 1))))
(let (($x578 (= (_ bv1 1) ?x710)))
(let ((?x409 (ite $x578 (_ bv1 32) (_ bv0 32))))
(let (($x318 (or false false)))
(let (($x1266 (or $x318 false false)))
(let (($x119 (or $x1266 false)))
(let (($x348 (or $x119 $x119 false)))
(let (($x917 (or $x348 false false)))
(let (($x429 (or $x917 (ite $x578 false false))))
(and (not $x429) (or $x429 (and (distinct ?x409 ?x409) true))))))))))))))))))
(check-sat)
; query 70: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x504 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x259 ((_ zero_extend 31) ?x504)))
(let ((?x74 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x463 ((_ zero_extend 31) ?x74)))
(let ((?x270 (bvand ?x463 ?x259)))
(let ((?x710 (ite (and (distinct (_ bv0 32) ?x270) true) (_ bv1 1) (_ bv0 1))))
(let (($x578 (= (_ bv1 1) ?x710)))
(let ((?x409 (ite $x578 (_ bv1 32) (_ bv0 32))))
(let ((?x192 ((_ extract 7 0) ?x409)))
(let (($x318 (or false false)))
(let (($x1266 (or $x318 false false)))
(let (($x119 (or $x1266 false)))
(let (($x348 (or $x119 $x119 false)))
(let (($x917 (or $x348 false false)))
(let (($x429 (or $x917 (ite $x578 false false))))
(let (($x397 (or $x429 false)))
(and (not $x397) (or $x397 (and (distinct ?x192 ?x192) true))))))))))))))))))))
(check-sat)
; query 71: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x318 (or false false)))
(let (($x155 (not $x318)))
(and $x155 (or $x318 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 72: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x74 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x318 (or false false)))
(let (($x1266 (or $x318 false false)))
(let (($x173 (not $x1266)))
(and $x173 (or $x1266 (and (distinct ?x74 ?x74) true))))))))
(check-sat)
; query 73: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x74 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x463 ((_ zero_extend 31) ?x74)))
(let (($x318 (or false false)))
(let (($x1266 (or $x318 false false)))
(let (($x119 (or $x1266 false)))
(let (($x323 (not $x119)))
(and $x323 (or $x119 (and (distinct ?x463 ?x463) true))))))))))
(check-sat)
; query 74: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x318 (or false false)))
(let (($x155 (not $x318)))
(and $x155 (or $x318 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 75: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x504 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x318 (or false false)))
(let (($x1266 (or $x318 false false)))
(let (($x173 (not $x1266)))
(and $x173 (or $x1266 (and (distinct ?x504 ?x504) true))))))))
(check-sat)
; query 76: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x504 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x259 ((_ zero_extend 31) ?x504)))
(let (($x318 (or false false)))
(let (($x1266 (or $x318 false false)))
(let (($x119 (or $x1266 false)))
(let (($x323 (not $x119)))
(and $x323 (or $x119 (and (distinct ?x259 ?x259) true))))))))))
(check-sat)
; query 77: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x504 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x259 ((_ zero_extend 31) ?x504)))
(let ((?x74 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x463 ((_ zero_extend 31) ?x74)))
(let ((?x270 (bvand ?x463 ?x259)))
(let (($x318 (or false false)))
(let (($x1266 (or $x318 false false)))
(let (($x119 (or $x1266 false)))
(let (($x348 (or $x119 $x119 false)))
(and (not $x348) (or $x348 (and (distinct ?x270 ?x270) true)))))))))))))
(check-sat)
; query 78: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x504 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x259 ((_ zero_extend 31) ?x504)))
(let ((?x74 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x463 ((_ zero_extend 31) ?x74)))
(let ((?x270 (bvand ?x463 ?x259)))
(let ((?x710 (ite (and (distinct (_ bv0 32) ?x270) true) (_ bv1 1) (_ bv0 1))))
(let (($x318 (or false false)))
(let (($x1266 (or $x318 false false)))
(let (($x119 (or $x1266 false)))
(let (($x348 (or $x119 $x119 false)))
(let (($x917 (or $x348 false false)))
(and (not $x917) (or $x917 (and (distinct ?x710 ?x710) true)))))))))))))))
(check-sat)
; query 79: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1317 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x347 (or false false false)))
(let (($x339 (not $x347)))
(and $x339 (or $x347 (and (distinct ?x1317 ?x1317) true)))))))
(check-sat)
; query 80: function matrix_add_const, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x347 (or false false false)))
(let (($x339 (not $x347)))
(and $x339 (or $x347 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 81: function matrix_add_const, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1273 (bvadd in.01_32 (_ bv1 32))))
(let (($x34 (and (distinct ?x1273 ?x1273) true)))
(let (($x347 (or false false false)))
(let (($x339 (not $x347)))
(and $x339 (or $x347 $x34)))))))
(check-sat)
; query 82: function matrix_mul_const, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x347 (or false false false)))
(let (($x339 (not $x347)))
(and $x339 (or $x347 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 83: function matrix_mul_const, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1273 (bvadd in.01_32 (_ bv1 32))))
(let (($x34 (and (distinct ?x1273 ?x1273) true)))
(let (($x347 (or false false false)))
(let (($x339 (not $x347)))
(and $x339 (or $x347 $x34)))))))
(check-sat)
; query 84: function matrix_mul_matrix, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x347 (or false false false)))
(let (($x339 (not $x347)))
(and $x339 (or $x347 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 85: function matrix_mul_matrix, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1273 (bvadd in.01_32 (_ bv1 32))))
(let (($x34 (and (distinct ?x1273 ?x1273) true)))
(let (($x347 (or false false false)))
(let (($x339 (not $x347)))
(and $x339 (or $x347 $x34)))))))
(check-sat)
; query 86: function matrix_mul_matrix, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x347 (or false false false)))
(let (($x339 (not $x347)))
(and $x339 (or $x347 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 87: function matrix_mul_matrix_bitextract, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x347 (or false false false)))
(let (($x339 (not $x347)))
(and $x339 (or $x347 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 88: function matrix_mul_matrix_bitextract, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1273 (bvadd in.01_32 (_ bv1 32))))
(let (($x34 (and (distinct ?x1273 ?x1273) true)))
(let (($x347 (or false false false)))
(let (($x339 (not $x347)))
(and $x339 (or $x347 $x34)))))))
(check-sat)
; query 89: function matrix_mul_matrix_bitextract, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x347 (or false false false)))
(let (($x339 (not $x347)))
(and $x339 (or $x347 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 90: function matrix_mul_vect, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x347 (or false false false)))
(let (($x339 (not $x347)))
(and $x339 (or $x347 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 91: function matrix_mul_vect, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1273 (bvadd in.01_32 (_ bv1 32))))
(let (($x34 (and (distinct ?x1273 ?x1273) true)))
(let (($x347 (or false false false)))
(let (($x339 (not $x347)))
(and $x339 (or $x347 $x34)))))))
(check-sat)
; query 92: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x318 (or false false)))
(let (($x155 (not $x318)))
(and $x155 (or $x318 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 93: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x610 ((_ sign_extend 16) in.1_16)))
(let ((?x542 (bvadd ?x610 (_ bv10 32))))
(let (($x361 (and (distinct (bvadd ((_ sign_extend 1) ?x610) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x542)) true)))
(let (($x318 (or false false)))
(let (($x654 (or $x318 false (or $x361))))
(and (not $x654) (or $x654 (and (distinct ?x542 ?x542) true)))))))))
(check-sat)
; query 94: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x610 ((_ sign_extend 16) in.1_16)))
(let ((?x542 (bvadd ?x610 (_ bv10 32))))
(let ((?x462 ((_ extract 15 0) ?x542)))
(let (($x361 (and (distinct (bvadd ((_ sign_extend 1) ?x610) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x542)) true)))
(let (($x318 (or false false)))
(let (($x654 (or $x318 false (or $x361))))
(let (($x282 (or $x654 false)))
(and (not $x282) (or $x282 (and (distinct ?x462 ?x462) true)))))))))))
(check-sat)
; query 95: function matrix_sum, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x472 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x347 (or false false false)))
(let (($x339 (not $x347)))
(and $x339 (or $x347 (and (distinct ?x472 ?x472) true)))))))
(check-sat)
; query 96: function matrix_sum, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x472 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let ((?x272 ((_ zero_extend 63) ?x472)))
(let (($x347 (or false false false)))
(let (($x444 (or $x347 false)))
(and (not $x444) (or $x444 (and (distinct ?x272 ?x272) true))))))))
(check-sat)
; query 97: function matrix_sum, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x472 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x643 (= (_ bv1 1) ?x472)))
(let ((?x446 (ite $x643 (_ bv1 32) (_ bv0 32))))
(let (($x347 (or false false false)))
(let (($x43 (or $x347 (ite $x643 false false))))
(and (not $x43) (or $x43 (and (distinct ?x446 ?x446) true)))))))))
(check-sat)
; query 98: function matrix_sum, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x318 (or false false)))
(let (($x155 (not $x318)))
(and $x155 (or $x318 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 99: function matrix_sum, block 22, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x472 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x643 (= (_ bv1 1) ?x472)))
(let ((?x446 (ite $x643 (_ bv1 32) (_ bv0 32))))
(let ((?x610 ((_ sign_extend 16) in.1_16)))
(let ((?x293 (bvadd ?x610 ?x446)))
(let (($x389 (and (distinct (bvadd ((_ sign_extend 1) ?x610) ((_ sign_extend 1) ?x446)) ((_ sign_extend 1) ?x293)) true)))
(let (($x347 (or false false false)))
(let (($x43 (or $x347 (ite $x643 false false))))
(let (($x318 (or false false)))
(let (($x694 (or $x318 $x43 (or $x389))))
(and (not $x694) (or $x694 (and (distinct ?x293 ?x293) true))))))))))))))
(check-sat)
; query 100: function matrix_sum, block 22, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x472 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x643 (= (_ bv1 1) ?x472)))
(let ((?x446 (ite $x643 (_ bv1 32) (_ bv0 32))))
(let ((?x610 ((_ sign_extend 16) in.1_16)))
(let ((?x293 (bvadd ?x610 ?x446)))
(let ((?x787 ((_ extract 15 0) ?x293)))
(let (($x389 (and (distinct (bvadd ((_ sign_extend 1) ?x610) ((_ sign_extend 1) ?x446)) ((_ sign_extend 1) ?x293)) true)))
(let (($x347 (or false false false)))
(let (($x43 (or $x347 (ite $x643 false false))))
(let (($x318 (or false false)))
(let (($x694 (or $x318 $x43 (or $x389))))
(let (($x430 (or $x694 false)))
(and (not $x430) (or $x430 (and (distinct ?x787 ?x787) true))))))))))))))))
(check-sat)
; query 101: function matrix_sum, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x347 (or false false false)))
(let (($x339 (not $x347)))
(and $x339 (or $x347 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 102: function matrix_sum, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1273 (bvadd in.01_32 (_ bv1 32))))
(let (($x34 (and (distinct ?x1273 ?x1273) true)))
(let (($x347 (or false false false)))
(let (($x339 (not $x347)))
(and $x339 (or $x347 $x34)))))))
(check-sat)
; query 103: function parseval, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.23_32 () (_ BitVec 32))
(assert
 (let (($x855 (and (distinct (bvmul ((_ sign_extend 32) in.23_32) ((_ sign_extend 32) (_ bv1024 32))) ((_ sign_extend 32) (bvmul in.23_32 (_ bv1024 32)))) true)))
(let (($x624 (or false false (or $x855))))
(and (not $x624) (or $x624 (and (distinct (bvmul in.23_32 (_ bv1024 32)) (bvmul in.23_32 (_ bv1024 32))) true))))))
(check-sat)
; query 104: function parseval, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.34_32 () (_ BitVec 32))
(assert
 (let (($x212 (and (distinct (bvmul ((_ sign_extend 32) in.34_32) ((_ sign_extend 32) (_ bv1048576 32))) ((_ sign_extend 32) (bvmul in.34_32 (_ bv1048576 32)))) true)))
(let (($x288 (or false false (or $x212))))
(and (not $x288) (or $x288 (and (distinct (bvmul in.34_32 (_ bv1048576 32)) (bvmul in.34_32 (_ bv1048576 32))) true))))))
(check-sat)
; query 105: function partition_memory, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x347 (or false false false)))
(let (($x339 (not $x347)))
(and $x339 (or $x347 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
