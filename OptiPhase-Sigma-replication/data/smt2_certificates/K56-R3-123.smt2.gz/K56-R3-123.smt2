; OptiPhase-Sigma refinement certificate for sweep K56-R3-123
; query 0: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x229 (or false false false)))
(let (($x110 (not $x229)))
(and $x110 (or $x229 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x544 (bvadd in.01_32 (_ bv1 32))))
(let ((?x227 (bvmul ?x544 ?x544)))
(let (($x229 (or false false false)))
(let (($x2851 (or $x229 $x229 false)))
(and (not $x2851) (or $x2851 (and (distinct ?x227 ?x227) true))))))))
(check-sat)
; query 2: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x544 (bvadd in.01_32 (_ bv1 32))))
(let ((?x227 (bvmul ?x544 ?x544)))
(let ((?x6389 (bvmul ?x227 (_ bv2 32))))
(let (($x229 (or false false false)))
(let (($x2851 (or $x229 $x229 false)))
(let (($x220 (or $x2851 false false)))
(and (not $x220) (or $x220 (and (distinct ?x6389 ?x6389) true))))))))))
(check-sat)
; query 3: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x544 (bvadd in.01_32 (_ bv1 32))))
(let ((?x227 (bvmul ?x544 ?x544)))
(let ((?x6389 (bvmul ?x227 (_ bv2 32))))
(let ((?x1892 (bvmul ?x6389 (_ bv4 32))))
(let (($x229 (or false false false)))
(let (($x2851 (or $x229 $x229 false)))
(let (($x220 (or $x2851 false false)))
(let (($x1869 (or $x220 false false)))
(and (not $x1869) (or $x1869 (and (distinct ?x1892 ?x1892) true))))))))))))
(check-sat)
; query 4: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x3171 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x229 (or false false false)))
(let (($x110 (not $x229)))
(and $x110 (or $x229 (and (distinct ?x3171 ?x3171) true)))))))
(check-sat)
; query 5: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x9 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x229 (or false false false)))
(let (($x110 (not $x229)))
(and $x110 (or $x229 (and (distinct ?x9 ?x9) true)))))))
(check-sat)
; query 6: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x229 (or false false false)))
(let (($x110 (not $x229)))
(and $x110 (or $x229 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 7: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x41 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x57 (or false false (or $x41))))
(and (not $x57) (or $x57 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x121 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x229 (or false false false)))
(let (($x110 (not $x229)))
(and $x110 (or $x229 (and (distinct ?x121 ?x121) true)))))))
(check-sat)
; query 9: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x15 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x229 (or false false false)))
(let (($x110 (not $x229)))
(and $x110 (or $x229 (and (distinct ?x15 ?x15) true)))))))
(check-sat)
; query 10: function matrix_add_const, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x229 (or false false false)))
(let (($x110 (not $x229)))
(and $x110 (or $x229 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 11: function matrix_add_const, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x229 (or false false false)))
(let (($x110 (not $x229)))
(and $x110 (or $x229 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 12: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x145 (or false false)))
(and (not $x145) (or $x145 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true)))))
(check-sat)
; query 13: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x137 ((_ sign_extend 16) in.1_16)))
(let ((?x231 (bvadd ?x137 (_ bv10 32))))
(let (($x135 (and (distinct (bvadd ((_ sign_extend 1) ?x137) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x231)) true)))
(let (($x145 (or false false)))
(let (($x13 (or $x145 false (or $x135))))
(and (not $x13) (or $x13 (and (distinct ?x231 ?x231) true)))))))))
(check-sat)
; query 14: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x137 ((_ sign_extend 16) in.1_16)))
(let ((?x231 (bvadd ?x137 (_ bv10 32))))
(let ((?x175 ((_ extract 15 0) ?x231)))
(let (($x135 (and (distinct (bvadd ((_ sign_extend 1) ?x137) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x231)) true)))
(let (($x145 (or false false)))
(let (($x13 (or $x145 false (or $x135))))
(let (($x1658 (or $x13 false)))
(and (not $x1658) (or $x1658 (and (distinct ?x175 ?x175) true)))))))))))
(check-sat)
