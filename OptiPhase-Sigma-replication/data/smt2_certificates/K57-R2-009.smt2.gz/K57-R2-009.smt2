; OptiPhase-Sigma refinement certificate for sweep K57-R2-009
; query 0: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x2031 (or false false)))
(let (($x701 (not $x2031)))
(and $x701 (or $x2031 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 1: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x283 ((_ sign_extend 16) in3_16)))
(let ((?x22 (bvand ?x283 (_ bv127 32))))
(let (($x2031 (or false false)))
(let (($x29 (or $x2031 false false)))
(let (($x668 (not $x29)))
(and $x668 (or $x29 (and (distinct ?x22 ?x22) true)))))))))
(check-sat)
; query 2: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x283 ((_ sign_extend 16) in3_16)))
(let ((?x22 (bvand ?x283 (_ bv127 32))))
(let ((?x157 ((_ extract 15 0) ?x22)))
(let (($x2031 (or false false)))
(let (($x29 (or $x2031 false false)))
(let (($x132 (or $x29 false)))
(let (($x87 (not $x132)))
(and $x87 (or $x132 (and (distinct ?x157 ?x157) true)))))))))))
(check-sat)
; query 3: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x2031 (or false false)))
(let (($x701 (not $x2031)))
(and $x701 (or $x2031 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 4: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x18 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x2031 (or false false)))
(let (($x29 (or $x2031 false false)))
(let (($x668 (not $x29)))
(and $x668 (or $x29 (and (distinct ?x18 ?x18) true))))))))
(check-sat)
; query 5: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x257 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x328 (or false false false)))
(let (($x1928 (not $x328)))
(and $x1928 (or $x328 (and (distinct ?x257 ?x257) true)))))))
(check-sat)
; query 6: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x124 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x328 (or false false false)))
(let (($x1928 (not $x328)))
(and $x1928 (or $x328 (and (distinct ?x124 ?x124) true)))))))
(check-sat)
; query 7: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x328 (or false false false)))
(let (($x1928 (not $x328)))
(and $x1928 (or $x328 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 8: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x77 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x10 (or false false (or $x77))))
(and (not $x10) (or $x10 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 9: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x271 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x282 ((_ zero_extend 31) ?x271)))
(let ((?x233 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x552 ((_ zero_extend 31) ?x233)))
(let ((?x663 (bvand ?x552 ?x282)))
(let ((?x164 (ite (and (distinct (_ bv0 32) ?x663) true) (_ bv1 1) (_ bv0 1))))
(let ((?x1932 ((_ zero_extend 63) ?x164)))
(let (($x2031 (or false false)))
(let (($x29 (or $x2031 false false)))
(let (($x132 (or $x29 false)))
(let (($x313 (or $x132 $x132 false)))
(let (($x1879 (or $x313 false false)))
(let (($x44 (or $x1879 false)))
(and (not $x44) (or $x44 (and (distinct ?x1932 ?x1932) true)))))))))))))))))
(check-sat)
; query 10: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x271 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x282 ((_ zero_extend 31) ?x271)))
(let ((?x233 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x552 ((_ zero_extend 31) ?x233)))
(let ((?x663 (bvand ?x552 ?x282)))
(let ((?x164 (ite (and (distinct (_ bv0 32) ?x663) true) (_ bv1 1) (_ bv0 1))))
(let (($x100 (= (_ bv1 1) ?x164)))
(let ((?x1874 (ite $x100 (_ bv1 32) (_ bv0 32))))
(let (($x2031 (or false false)))
(let (($x29 (or $x2031 false false)))
(let (($x132 (or $x29 false)))
(let (($x313 (or $x132 $x132 false)))
(let (($x1879 (or $x313 false false)))
(let (($x121 (or $x1879 (ite $x100 false false))))
(and (not $x121) (or $x121 (and (distinct ?x1874 ?x1874) true))))))))))))))))))
(check-sat)
; query 11: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x271 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x282 ((_ zero_extend 31) ?x271)))
(let ((?x233 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x552 ((_ zero_extend 31) ?x233)))
(let ((?x663 (bvand ?x552 ?x282)))
(let ((?x164 (ite (and (distinct (_ bv0 32) ?x663) true) (_ bv1 1) (_ bv0 1))))
(let (($x100 (= (_ bv1 1) ?x164)))
(let ((?x1874 (ite $x100 (_ bv1 32) (_ bv0 32))))
(let ((?x583 ((_ extract 7 0) ?x1874)))
(let (($x2031 (or false false)))
(let (($x29 (or $x2031 false false)))
(let (($x132 (or $x29 false)))
(let (($x313 (or $x132 $x132 false)))
(let (($x1879 (or $x313 false false)))
(let (($x121 (or $x1879 (ite $x100 false false))))
(let (($x254 (or $x121 false)))
(and (not $x254) (or $x254 (and (distinct ?x583 ?x583) true))))))))))))))))))))
(check-sat)
; query 12: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x2031 (or false false)))
(let (($x701 (not $x2031)))
(and $x701 (or $x2031 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 13: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x233 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x2031 (or false false)))
(let (($x29 (or $x2031 false false)))
(let (($x668 (not $x29)))
(and $x668 (or $x29 (and (distinct ?x233 ?x233) true))))))))
(check-sat)
; query 14: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x233 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x552 ((_ zero_extend 31) ?x233)))
(let (($x2031 (or false false)))
(let (($x29 (or $x2031 false false)))
(let (($x132 (or $x29 false)))
(let (($x87 (not $x132)))
(and $x87 (or $x132 (and (distinct ?x552 ?x552) true))))))))))
(check-sat)
; query 15: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x2031 (or false false)))
(let (($x701 (not $x2031)))
(and $x701 (or $x2031 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 16: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x271 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x2031 (or false false)))
(let (($x29 (or $x2031 false false)))
(let (($x668 (not $x29)))
(and $x668 (or $x29 (and (distinct ?x271 ?x271) true))))))))
(check-sat)
; query 17: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x271 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x282 ((_ zero_extend 31) ?x271)))
(let (($x2031 (or false false)))
(let (($x29 (or $x2031 false false)))
(let (($x132 (or $x29 false)))
(let (($x87 (not $x132)))
(and $x87 (or $x132 (and (distinct ?x282 ?x282) true))))))))))
(check-sat)
; query 18: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x271 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x282 ((_ zero_extend 31) ?x271)))
(let ((?x233 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x552 ((_ zero_extend 31) ?x233)))
(let ((?x663 (bvand ?x552 ?x282)))
(let (($x2031 (or false false)))
(let (($x29 (or $x2031 false false)))
(let (($x132 (or $x29 false)))
(let (($x313 (or $x132 $x132 false)))
(and (not $x313) (or $x313 (and (distinct ?x663 ?x663) true)))))))))))))
(check-sat)
; query 19: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x271 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x282 ((_ zero_extend 31) ?x271)))
(let ((?x233 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x552 ((_ zero_extend 31) ?x233)))
(let ((?x663 (bvand ?x552 ?x282)))
(let ((?x164 (ite (and (distinct (_ bv0 32) ?x663) true) (_ bv1 1) (_ bv0 1))))
(let (($x2031 (or false false)))
(let (($x29 (or $x2031 false false)))
(let (($x132 (or $x29 false)))
(let (($x313 (or $x132 $x132 false)))
(let (($x1879 (or $x313 false false)))
(and (not $x1879) (or $x1879 (and (distinct ?x164 ?x164) true)))))))))))))))
(check-sat)
; query 20: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x48 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x328 (or false false false)))
(let (($x1928 (not $x328)))
(and $x1928 (or $x328 (and (distinct ?x48 ?x48) true)))))))
(check-sat)
