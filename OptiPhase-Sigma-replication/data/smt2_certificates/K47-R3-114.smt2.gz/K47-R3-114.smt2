; OptiPhase-Sigma refinement certificate for sweep K47-R3-114
; query 0: function adpcm_decoder, block 61, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.210_32 () (_ BitVec 32))
(declare-fun in.013_32 () (_ BitVec 32))
(assert
 (let ((?x7 (bvadd in.013_32 in.210_32)))
(let ((?x83 (bvsub in.013_32 in.210_32)))
(let (($x229 (and (distinct (bvadd ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x7)) true)))
(let (($x316 (and (distinct (bvsub ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x83)) true)))
(and (not (or false false (or $x316))) (or (or false false (or $x229)) (and (distinct ?x83 ?x7) true))))))))
(check-sat)
; query 1: function main, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x129 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x169 (or false false false)))
(and (not $x169) (or $x169 (and (distinct ?x129 ?x129) true))))))
(check-sat)
