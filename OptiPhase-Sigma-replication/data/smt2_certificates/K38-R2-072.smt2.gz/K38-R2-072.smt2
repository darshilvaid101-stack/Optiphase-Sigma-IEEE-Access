; OptiPhase-Sigma refinement certificate for sweep K38-R2-072
; query 0: function BF_cbc_encrypt, block 126, name %127
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.010_64 () (_ BitVec 64))
(assert
 (let (($x69 (and (distinct (bvsub ((_ sign_extend 1) in.010_64) ((_ sign_extend 1) (_ bv8 64))) ((_ sign_extend 1) (bvsub in.010_64 (_ bv8 64)))) true)))
(let (($x96 (or false false (or $x69))))
(and (not $x96) (or $x96 (and (distinct (bvsub in.010_64 (_ bv8 64)) (bvsub in.010_64 (_ bv8 64))) true))))))
(check-sat)
; query 1: function BF_cbc_encrypt, block 128, name %129
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.010_64 () (_ BitVec 64))
(assert
 (let ((?x323 (ite (and (distinct (_ bv18446744073709551608 64) in.010_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x504 (or false false false)))
(let (($x12 (not $x504)))
(and $x12 (or $x504 (and (distinct ?x323 ?x323) true)))))))
(check-sat)
; query 2: function BF_cbc_encrypt, block 366, name %367
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.111_64 () (_ BitVec 64))
(assert
 (let (($x85 (and (distinct (bvsub ((_ sign_extend 1) in.111_64) ((_ sign_extend 1) (_ bv8 64))) ((_ sign_extend 1) (bvsub in.111_64 (_ bv8 64)))) true)))
(let (($x121 (or false false (or $x85))))
(and (not $x121) (or $x121 (and (distinct (bvsub in.111_64 (_ bv8 64)) (bvsub in.111_64 (_ bv8 64))) true))))))
(check-sat)
; query 3: function BF_cbc_encrypt, block 368, name %369
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.111_64 () (_ BitVec 64))
(assert
 (let ((?x19 (ite (and (distinct (_ bv18446744073709551608 64) in.111_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x504 (or false false false)))
(let (($x12 (not $x504)))
(and $x12 (or $x504 (and (distinct ?x19 ?x19) true)))))))
(check-sat)
; query 4: function BF_cfb64_encrypt, block 111, name %112
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.18_32 () (_ BitVec 32))
(assert
 (let ((?x88 (ite (= (_ bv0 32) in.18_32) (_ bv1 1) (_ bv0 1))))
(let (($x504 (or false false false)))
(let (($x12 (not $x504)))
(and $x12 (or $x504 (and (distinct ?x88 ?x88) true)))))))
(check-sat)
; query 5: function BF_cfb64_encrypt, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.07_32 () (_ BitVec 32))
(assert
 (let ((?x104 (ite (= (_ bv0 32) in.07_32) (_ bv1 1) (_ bv0 1))))
(let (($x504 (or false false false)))
(let (($x12 (not $x504)))
(and $x12 (or $x504 (and (distinct ?x104 ?x104) true)))))))
(check-sat)
; query 6: function BF_ofb64_encrypt, block 135, name %136
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x449 (ite (and (distinct (_ bv0 32) in.02_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x504 (or false false false)))
(let (($x12 (not $x504)))
(and $x12 (or $x504 (and (distinct ?x449 ?x449) true)))))))
(check-sat)
; query 7: function BF_ofb64_encrypt, block 82, name %83
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x83 (ite (= (_ bv0 32) in.04_32) (_ bv1 1) (_ bv0 1))))
(let (($x504 (or false false false)))
(let (($x12 (not $x504)))
(and $x12 (or $x504 (and (distinct ?x83 ?x83) true)))))))
(check-sat)
; query 8: function BF_set_key, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x102 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x392 (or false false (or $x102))))
(and (not $x392) (or $x392 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 9: function BF_set_key, block 69, name %70
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.13_32 () (_ BitVec 32))
(assert
 (let (($x30 (and (distinct (bvadd ((_ sign_extend 1) in.13_32) ((_ sign_extend 1) (_ bv2 32))) ((_ sign_extend 1) (bvadd in.13_32 (_ bv2 32)))) true)))
(let (($x44 (or false false (or $x30))))
(and (not $x44) (or $x44 (and (distinct (bvadd in.13_32 (_ bv2 32)) (bvadd in.13_32 (_ bv2 32))) true))))))
(check-sat)
; query 10: function BF_set_key, block 87, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.24_32 () (_ BitVec 32))
(assert
 (let (($x35 (and (distinct (bvadd ((_ sign_extend 1) in.24_32) ((_ sign_extend 1) (_ bv2 32))) ((_ sign_extend 1) (bvadd in.24_32 (_ bv2 32)))) true)))
(let (($x111 (or false false (or $x35))))
(and (not $x111) (or $x111 (and (distinct (bvadd in.24_32 (_ bv2 32)) (bvadd in.24_32 (_ bv2 32))) true))))))
(check-sat)
; query 11: function main, block 124, name %125
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let ((?x487 (ite (bvsgt (_ bv40 32) in.2_32) (_ bv1 1) (_ bv0 1))))
(let (($x504 (or false false false)))
(let (($x12 (not $x504)))
(and $x12 (or $x504 (and (distinct ?x487 ?x487) true)))))))
(check-sat)
; query 12: function main, block 147, name %148
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x382 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x327 (or false false (or $x382))))
(and (not $x327) (or $x327 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 13: function main, block 60, name %61
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x646 (or false false)))
(and (not $x646) (or $x646 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 14: function main, block 60, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x339 (ite (bvsge (_ bv57 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x646 (or false false)))
(let (($x9 (or $x646 false false)))
(let (($x54 (not $x9)))
(and $x54 (or $x9 (and (distinct ?x339 ?x339) true))))))))
(check-sat)
; query 15: function main, block 63, name %64
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x504 (or false false false)))
(let (($x175 (or $x504 (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x175) (or $x175 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvshl in.01_32 (_ bv4 32))) true))))))
(check-sat)
; query 16: function main, block 63, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x646 (or false false)))
(and (not $x646) (or $x646 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 17: function main, block 63, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x650 ((_ sign_extend 24) in57_8)))
(let ((?x18 (bvshl in.01_32 (_ bv4 32))))
(let ((?x45 (bvadd ?x18 ?x650)))
(let ((?x566 ((_ sign_extend 1) ?x45)))
(let (($x646 (or false false)))
(let (($x504 (or false false false)))
(let (($x175 (or $x504 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x345 (or $x175 $x646 (or (and (distinct (bvadd ((_ sign_extend 1) ?x18) ((_ sign_extend 1) ?x650)) ?x566) true)))))
(and (not $x345) (or $x345 (and (distinct ?x45 ?x45) true))))))))))))
(check-sat)
; query 18: function main, block 63, name %67
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x650 ((_ sign_extend 24) in57_8)))
(let ((?x18 (bvshl in.01_32 (_ bv4 32))))
(let ((?x45 (bvadd ?x18 ?x650)))
(let ((?x503 (bvsub ?x45 (_ bv48 32))))
(let (($x155 (and (distinct (bvsub ((_ sign_extend 1) ?x45) ((_ sign_extend 1) (_ bv48 32))) ((_ sign_extend 1) ?x503)) true)))
(let ((?x566 ((_ sign_extend 1) ?x45)))
(let (($x646 (or false false)))
(let (($x504 (or false false false)))
(let (($x175 (or $x504 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x345 (or $x175 $x646 (or (and (distinct (bvadd ((_ sign_extend 1) ?x18) ((_ sign_extend 1) ?x650)) ?x566) true)))))
(let (($x14 (or $x345 false (or $x155))))
(and (not $x14) (or $x14 (and (distinct ?x503 ?x503) true)))))))))))))))
(check-sat)
; query 19: function main, block 68, name %69
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x646 (or false false)))
(and (not $x646) (or $x646 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 20: function main, block 68, name %70
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x296 (ite (bvsle (_ bv65 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x646 (or false false)))
(let (($x9 (or $x646 false false)))
(let (($x54 (not $x9)))
(and $x54 (or $x9 (and (distinct ?x296 ?x296) true))))))))
(check-sat)
; query 21: function main, block 71, name %72
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x646 (or false false)))
(and (not $x646) (or $x646 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 22: function main, block 71, name %73
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x213 (ite (bvsge (_ bv70 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x646 (or false false)))
(let (($x9 (or $x646 false false)))
(let (($x54 (not $x9)))
(and $x54 (or $x9 (and (distinct ?x213 ?x213) true))))))))
(check-sat)
; query 23: function main, block 74, name %75
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x504 (or false false false)))
(let (($x175 (or $x504 (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x175) (or $x175 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvshl in.01_32 (_ bv4 32))) true))))))
(check-sat)
; query 24: function main, block 74, name %76
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x646 (or false false)))
(and (not $x646) (or $x646 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 25: function main, block 74, name %77
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x650 ((_ sign_extend 24) in57_8)))
(let ((?x18 (bvshl in.01_32 (_ bv4 32))))
(let ((?x45 (bvadd ?x18 ?x650)))
(let ((?x566 ((_ sign_extend 1) ?x45)))
(let (($x646 (or false false)))
(let (($x504 (or false false false)))
(let (($x175 (or $x504 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x345 (or $x175 $x646 (or (and (distinct (bvadd ((_ sign_extend 1) ?x18) ((_ sign_extend 1) ?x650)) ?x566) true)))))
(and (not $x345) (or $x345 (and (distinct ?x45 ?x45) true))))))))))))
(check-sat)
; query 26: function main, block 74, name %78
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x650 ((_ sign_extend 24) in57_8)))
(let ((?x18 (bvshl in.01_32 (_ bv4 32))))
(let ((?x45 (bvadd ?x18 ?x650)))
(let ((?x150 (bvsub ?x45 (_ bv65 32))))
(let ((?x267 ((_ sign_extend 1) ?x150)))
(let ((?x566 ((_ sign_extend 1) ?x45)))
(let (($x646 (or false false)))
(let (($x504 (or false false false)))
(let (($x175 (or $x504 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x345 (or $x175 $x646 (or (and (distinct (bvadd ((_ sign_extend 1) ?x18) ((_ sign_extend 1) ?x650)) ?x566) true)))))
(let (($x206 (or $x345 false (or (and (distinct (bvsub ?x566 ((_ sign_extend 1) (_ bv65 32))) ?x267) true)))))
(and (not $x206) (or $x206 (and (distinct ?x150 ?x150) true)))))))))))))))
(check-sat)
; query 27: function main, block 74, name %79
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x650 ((_ sign_extend 24) in57_8)))
(let ((?x18 (bvshl in.01_32 (_ bv4 32))))
(let ((?x45 (bvadd ?x18 ?x650)))
(let ((?x150 (bvsub ?x45 (_ bv65 32))))
(let ((?x269 (bvadd ?x150 (_ bv10 32))))
(let (($x555 (and (distinct (bvadd ((_ sign_extend 1) ?x150) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x269)) true)))
(let ((?x267 ((_ sign_extend 1) ?x150)))
(let ((?x566 ((_ sign_extend 1) ?x45)))
(let (($x646 (or false false)))
(let (($x504 (or false false false)))
(let (($x175 (or $x504 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x345 (or $x175 $x646 (or (and (distinct (bvadd ((_ sign_extend 1) ?x18) ((_ sign_extend 1) ?x650)) ?x566) true)))))
(let (($x206 (or $x345 false (or (and (distinct (bvsub ?x566 ((_ sign_extend 1) (_ bv65 32))) ?x267) true)))))
(let (($x508 (or $x206 false (or $x555))))
(and (not $x508) (or $x508 (and (distinct ?x269 ?x269) true))))))))))))))))))
(check-sat)
