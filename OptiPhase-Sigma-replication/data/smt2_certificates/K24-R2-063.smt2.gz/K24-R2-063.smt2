; OptiPhase-Sigma refinement certificate for sweep K24-R2-063
