; OptiPhase-Sigma refinement certificate for sweep K02-R3-147
; query 0: function xmalloc, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in7_32 () (_ BitVec 32))
(assert
 (let ((?x84 (ite (and (distinct (_ bv0 32) in7_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x83 (or false false false)))
(and (not $x83) (or $x83 (and (distinct ?x84 ?x84) true))))))
(check-sat)
