; OptiPhase-Sigma refinement certificate for sweep K47-R3-227
; query 0: function adpcm_coder, block 25, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in20_32 () (_ BitVec 32))
(assert
 (let (($x129 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in20_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in20_32))) true)))
(let (($x25 (or false false (or $x129))))
(and (not $x25) (or $x25 (and (distinct (bvsub (_ bv0 32) in20_32) (bvsub (_ bv0 32) in20_32)) true))))))
(check-sat)
; query 1: function adpcm_coder, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(declare-fun in.017_32 () (_ BitVec 32))
(assert
 (let ((?x161 (bvsub in.017_32 in.020_32)))
(let (($x127 (and (distinct (bvsub ((_ sign_extend 1) in.017_32) ((_ sign_extend 1) in.020_32)) ((_ sign_extend 1) ?x161)) true)))
(let (($x7 (or false false (or $x127))))
(and (not $x7) (or $x7 (and (distinct ?x161 ?x161) true)))))))
(check-sat)
; query 2: function adpcm_coder, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(declare-fun in28_32 () (_ BitVec 32))
(assert
 (let (($x49 (and (distinct (bvadd ((_ sign_extend 1) in28_32) ((_ sign_extend 1) in.020_32)) ((_ sign_extend 1) (bvadd in28_32 in.020_32))) true)))
(let (($x54 (or false false (or $x49))))
(let (($x105 (or $x54 (and (distinct (bvadd in28_32 in.020_32) (bvadd in28_32 in.020_32)) true))))
(and (not $x54) $x105)))))
(check-sat)
; query 3: function adpcm_coder, block 36, name %37
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.014_32 () (_ BitVec 32))
(assert
 (let (($x43 (or false false false)))
(let (($x224 (not $x43)))
(and $x224 (or $x43 (and (distinct (bvor in.014_32 (_ bv2 32)) (bvor in.014_32 (_ bv2 32))) true))))))
(check-sat)
; query 4: function adpcm_coder, block 36, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in34_32 () (_ BitVec 32))
(declare-fun in.118_32 () (_ BitVec 32))
(assert
 (let (($x16 (and (distinct (bvsub ((_ sign_extend 1) in.118_32) ((_ sign_extend 1) in34_32)) ((_ sign_extend 1) (bvsub in.118_32 in34_32))) true)))
(let (($x48 (or false false (or $x16))))
(let (($x462 (or $x48 (and (distinct (bvsub in.118_32 in34_32) (bvsub in.118_32 in34_32)) true))))
(and (not $x48) $x462)))))
(check-sat)
; query 5: function adpcm_coder, block 36, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in34_32 () (_ BitVec 32))
(declare-fun in.08_32 () (_ BitVec 32))
(assert
 (let (($x191 (and (distinct (bvadd ((_ sign_extend 1) in.08_32) ((_ sign_extend 1) in34_32)) ((_ sign_extend 1) (bvadd in.08_32 in34_32))) true)))
(let (($x379 (or false false (or $x191))))
(let (($x56 (or $x379 (and (distinct (bvadd in.08_32 in34_32) (bvadd in.08_32 in34_32)) true))))
(and (not $x379) $x56)))))
(check-sat)
; query 6: function adpcm_coder, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.115_32 () (_ BitVec 32))
(assert
 (let (($x43 (or false false false)))
(let (($x224 (not $x43)))
(and $x224 (or $x43 (and (distinct (bvor in.115_32 (_ bv1 32)) (bvor in.115_32 (_ bv1 32))) true))))))
(check-sat)
; query 7: function adpcm_coder, block 43, name %45
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in41_32 () (_ BitVec 32))
(declare-fun in.19_32 () (_ BitVec 32))
(assert
 (let (($x480 (and (distinct (bvadd ((_ sign_extend 1) in.19_32) ((_ sign_extend 1) in41_32)) ((_ sign_extend 1) (bvadd in.19_32 in41_32))) true)))
(let (($x37 (or false false (or $x480))))
(let (($x69 (or $x37 (and (distinct (bvadd in.19_32 in41_32) (bvadd in.19_32 in41_32)) true))))
(and (not $x37) $x69)))))
(check-sat)
; query 8: function adpcm_coder, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.210_32 () (_ BitVec 32))
(declare-fun in.011_32 () (_ BitVec 32))
(assert
 (let ((?x88 (bvsub in.011_32 in.210_32)))
(let (($x11 (and (distinct (bvsub ((_ sign_extend 1) in.011_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x88)) true)))
(let (($x182 (or false false (or $x11))))
(and (not $x182) (or $x182 (and (distinct ?x88 ?x88) true)))))))
(check-sat)
; query 9: function adpcm_coder, block 50, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.210_32 () (_ BitVec 32))
(declare-fun in.011_32 () (_ BitVec 32))
(assert
 (let ((?x225 (bvadd in.011_32 in.210_32)))
(let (($x361 (and (distinct (bvadd ((_ sign_extend 1) in.011_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x225)) true)))
(let (($x108 (or false false (or $x361))))
(and (not $x108) (or $x108 (and (distinct ?x225 ?x225) true)))))))
(check-sat)
; query 10: function adpcm_coder, block 55, name %56
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.112_32 () (_ BitVec 32))
(assert
 (let ((?x674 (ite (bvsgt (_ bv4294934528 32) in.112_32) (_ bv1 1) (_ bv0 1))))
(let (($x43 (or false false false)))
(let (($x224 (not $x43)))
(and $x224 (or $x43 (and (distinct ?x674 ?x674) true)))))))
(check-sat)
; query 11: function adpcm_coder, block 75, name %76
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in60_32 () (_ BitVec 32))
(assert
 (let (($x95 (bvuge (_ bv4 32) (_ bv32 32))))
(let (($x84 (or (and (distinct (bvlshr (bvshl in60_32 (_ bv4 32)) (_ bv4 32)) in60_32) true) (and (distinct (bvashr (bvshl in60_32 (_ bv4 32)) (_ bv4 32)) in60_32) true))))
(let (($x36 (or (or false false $x84) $x95)))
(and (not (or (or false false false) $x95)) (or $x36 (and (distinct (bvshl in60_32 (_ bv4 32)) (bvshl in60_32 (_ bv4 32))) true)))))))
(check-sat)
; query 12: function adpcm_coder, block 75, name %77
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in60_32 () (_ BitVec 32))
(assert
 (let ((?x312 (bvshl in60_32 (_ bv4 32))))
(let ((?x178 (bvand ?x312 (_ bv240 32))))
(let (($x95 (bvuge (_ bv4 32) (_ bv32 32))))
(let (($x84 (or (and (distinct (bvlshr ?x312 (_ bv4 32)) in60_32) true) (and (distinct (bvashr ?x312 (_ bv4 32)) in60_32) true))))
(let (($x36 (or (or false false $x84) $x95)))
(and (not (or (or (or false false false) $x95) false false)) (or (or $x36 false false) (and (distinct ?x178 ?x178) true)))))))))
(check-sat)
; query 13: function adpcm_decoder, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x1492 (ite (and (distinct (_ bv0 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x43 (or false false false)))
(let (($x224 (not $x43)))
(and $x224 (or $x43 (and (distinct ?x1492 ?x1492) true)))))))
(check-sat)
; query 14: function adpcm_decoder, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x43 (or false false false)))
(let (($x224 (not $x43)))
(and $x224 (or $x43 (and (distinct (bvand in.01_32 (_ bv15 32)) (bvand in.01_32 (_ bv15 32))) true))))))
(check-sat)
; query 15: function adpcm_decoder, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.012_32 () (_ BitVec 32))
(declare-fun in42_32 () (_ BitVec 32))
(assert
 (let (($x1389 (and (distinct (bvadd ((_ sign_extend 1) in42_32) ((_ sign_extend 1) in.012_32)) ((_ sign_extend 1) (bvadd in42_32 in.012_32))) true)))
(let (($x97 (or false false (or $x1389))))
(let (($x1723 (or $x97 (and (distinct (bvadd in42_32 in.012_32) (bvadd in42_32 in.012_32)) true))))
(and (not $x97) $x1723)))))
(check-sat)
; query 16: function adpcm_decoder, block 50, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.012_32 () (_ BitVec 32))
(assert
 (let (($x43 (or false false false)))
(let (($x1592 (or $x43 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x1934 (or $x1592 (and (distinct (bvashr in.012_32 (_ bv1 32)) (bvashr in.012_32 (_ bv1 32))) true))))
(and (not $x1592) $x1934)))))
(check-sat)
; query 17: function adpcm_decoder, block 50, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.012_32 () (_ BitVec 32))
(declare-fun in.08_32 () (_ BitVec 32))
(assert
 (let ((?x157 (bvashr in.012_32 (_ bv1 32))))
(let ((?x409 (bvadd in.08_32 ?x157)))
(let (($x727 (and (distinct (bvadd ((_ sign_extend 1) in.08_32) ((_ sign_extend 1) ?x157)) ((_ sign_extend 1) ?x409)) true)))
(let (($x43 (or false false false)))
(let (($x1592 (or $x43 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x1759 (or false $x1592 (or $x727))))
(and (not $x1759) (or $x1759 (and (distinct ?x409 ?x409) true))))))))))
(check-sat)
; query 18: function adpcm_decoder, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.012_32 () (_ BitVec 32))
(assert
 (let (($x43 (or false false false)))
(let (($x729 (or $x43 (bvuge (_ bv2 32) (_ bv32 32)))))
(let (($x935 (or $x729 (and (distinct (bvashr in.012_32 (_ bv2 32)) (bvashr in.012_32 (_ bv2 32))) true))))
(and (not $x729) $x935)))))
(check-sat)
; query 19: function adpcm_decoder, block 56, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.012_32 () (_ BitVec 32))
(declare-fun in.19_32 () (_ BitVec 32))
(assert
 (let ((?x1190 (bvashr in.012_32 (_ bv2 32))))
(let ((?x1282 (bvadd in.19_32 ?x1190)))
(let (($x616 (and (distinct (bvadd ((_ sign_extend 1) in.19_32) ((_ sign_extend 1) ?x1190)) ((_ sign_extend 1) ?x1282)) true)))
(let (($x43 (or false false false)))
(let (($x729 (or $x43 (bvuge (_ bv2 32) (_ bv32 32)))))
(let (($x1914 (or false $x729 (or $x616))))
(and (not $x1914) (or $x1914 (and (distinct ?x1282 ?x1282) true))))))))))
(check-sat)
; query 20: function adpcm_decoder, block 61, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.210_32 () (_ BitVec 32))
(declare-fun in.013_32 () (_ BitVec 32))
(assert
 (let ((?x1249 (bvsub in.013_32 in.210_32)))
(let (($x1203 (and (distinct (bvsub ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x1249)) true)))
(let (($x1682 (or false false (or $x1203))))
(and (not $x1682) (or $x1682 (and (distinct ?x1249 ?x1249) true)))))))
(check-sat)
; query 21: function adpcm_decoder, block 63, name %64
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.210_32 () (_ BitVec 32))
(declare-fun in.013_32 () (_ BitVec 32))
(assert
 (let ((?x180 (bvadd in.013_32 in.210_32)))
(let (($x1581 (and (distinct (bvadd ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x180)) true)))
(let (($x380 (or false false (or $x1581))))
(and (not $x380) (or $x380 (and (distinct ?x180 ?x180) true)))))))
(check-sat)
; query 22: function adpcm_decoder, block 68, name %69
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.114_32 () (_ BitVec 32))
(assert
 (let ((?x1983 (ite (bvsgt (_ bv4294934528 32) in.114_32) (_ bv1 1) (_ bv0 1))))
(let (($x43 (or false false false)))
(let (($x224 (not $x43)))
(and $x224 (or $x43 (and (distinct ?x1983 ?x1983) true)))))))
(check-sat)
; query 23: function adpcm_decoder, block 78, name %79
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x1895 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv4294967295 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv4294967295 32)))) true)))
(let (($x170 (or false false (or $x1895))))
(and (not $x170) (or $x170 (and (distinct (bvadd in.02_32 (_ bv4294967295 32)) (bvadd in.02_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 24: function main, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x1856 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x43 (or false false false)))
(let (($x224 (not $x43)))
(and $x224 (or $x43 (and (distinct ?x1856 ?x1856) true)))))))
(check-sat)
