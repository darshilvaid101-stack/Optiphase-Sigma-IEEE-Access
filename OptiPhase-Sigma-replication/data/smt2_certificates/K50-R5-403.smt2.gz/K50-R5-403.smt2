; OptiPhase-Sigma refinement certificate for sweep K50-R5-403
