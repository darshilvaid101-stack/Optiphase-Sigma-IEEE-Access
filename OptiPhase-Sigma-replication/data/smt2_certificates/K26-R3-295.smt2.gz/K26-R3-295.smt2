; OptiPhase-Sigma refinement certificate for sweep K26-R3-295
