; OptiPhase-Sigma refinement certificate for sweep K35-R6-048
; query 0: function edge_draw, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let ((?x177 (ite (= (_ bv0 32) in4_32) (_ bv1 1) (_ bv0 1))))
(let (($x194 (or false false false)))
(and (not $x194) (or $x194 (and (distinct ?x177 ?x177) true))))))
(check-sat)
