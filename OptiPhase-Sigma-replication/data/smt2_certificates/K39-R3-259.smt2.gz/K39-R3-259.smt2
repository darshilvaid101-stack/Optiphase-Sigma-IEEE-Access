; OptiPhase-Sigma refinement certificate for sweep K39-R3-259
; query 0: function BF_cbc_encrypt, block 126, name %127
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.010_64 () (_ BitVec 64))
(assert
 (let (($x679 (and (distinct (bvsub ((_ sign_extend 1) in.010_64) ((_ sign_extend 1) (_ bv8 64))) ((_ sign_extend 1) (bvsub in.010_64 (_ bv8 64)))) true)))
(let (($x7 (or false false (or $x679))))
(and (not $x7) (or $x7 (and (distinct (bvsub in.010_64 (_ bv8 64)) (bvsub in.010_64 (_ bv8 64))) true))))))
(check-sat)
; query 1: function BF_cbc_encrypt, block 128, name %129
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.010_64 () (_ BitVec 64))
(assert
 (let ((?x182 (ite (and (distinct (_ bv18446744073709551608 64) in.010_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x821 (or false false false)))
(let (($x68 (not $x821)))
(and $x68 (or $x821 (and (distinct ?x182 ?x182) true)))))))
(check-sat)
; query 2: function BF_cfb64_encrypt, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.07_32 () (_ BitVec 32))
(assert
 (let ((?x1039 (ite (= (_ bv0 32) in.07_32) (_ bv1 1) (_ bv0 1))))
(let (($x821 (or false false false)))
(let (($x68 (not $x821)))
(and $x68 (or $x821 (and (distinct ?x1039 ?x1039) true)))))))
(check-sat)
; query 3: function BF_set_key, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x176 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x43 (or false false (or $x176))))
(and (not $x43) (or $x43 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 4: function BF_set_key, block 69, name %70
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.13_32 () (_ BitVec 32))
(assert
 (let (($x311 (and (distinct (bvadd ((_ sign_extend 1) in.13_32) ((_ sign_extend 1) (_ bv2 32))) ((_ sign_extend 1) (bvadd in.13_32 (_ bv2 32)))) true)))
(let (($x104 (or false false (or $x311))))
(and (not $x104) (or $x104 (and (distinct (bvadd in.13_32 (_ bv2 32)) (bvadd in.13_32 (_ bv2 32))) true))))))
(check-sat)
; query 5: function BF_set_key, block 87, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.24_32 () (_ BitVec 32))
(assert
 (let (($x143 (and (distinct (bvadd ((_ sign_extend 1) in.24_32) ((_ sign_extend 1) (_ bv2 32))) ((_ sign_extend 1) (bvadd in.24_32 (_ bv2 32)))) true)))
(let (($x13 (or false false (or $x143))))
(and (not $x13) (or $x13 (and (distinct (bvadd in.24_32 (_ bv2 32)) (bvadd in.24_32 (_ bv2 32))) true))))))
(check-sat)
; query 6: function main, block 124, name %125
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let ((?x52 (ite (bvsgt (_ bv40 32) in.2_32) (_ bv1 1) (_ bv0 1))))
(let (($x821 (or false false false)))
(let (($x68 (not $x821)))
(and $x68 (or $x821 (and (distinct ?x52 ?x52) true)))))))
(check-sat)
; query 7: function main, block 147, name %148
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x228 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x147 (or false false (or $x228))))
(and (not $x147) (or $x147 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function main, block 60, name %61
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x74 (or false false)))
(and (not $x74) (or $x74 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 9: function main, block 60, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x132 (ite (bvsge (_ bv57 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x74 (or false false)))
(let (($x745 (or $x74 false false)))
(let (($x208 (not $x745)))
(and $x208 (or $x745 (and (distinct ?x132 ?x132) true))))))))
(check-sat)
; query 10: function main, block 63, name %64
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x821 (or false false false)))
(let (($x89 (or $x821 (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x89) (or $x89 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvshl in.01_32 (_ bv4 32))) true))))))
(check-sat)
; query 11: function main, block 63, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x74 (or false false)))
(and (not $x74) (or $x74 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 12: function main, block 63, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x123 ((_ sign_extend 24) in57_8)))
(let ((?x113 (bvshl in.01_32 (_ bv4 32))))
(let ((?x129 (bvadd ?x113 ?x123)))
(let ((?x124 ((_ sign_extend 1) ?x129)))
(let (($x74 (or false false)))
(let (($x821 (or false false false)))
(let (($x89 (or $x821 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x77 (or $x89 $x74 (or (and (distinct (bvadd ((_ sign_extend 1) ?x113) ((_ sign_extend 1) ?x123)) ?x124) true)))))
(and (not $x77) (or $x77 (and (distinct ?x129 ?x129) true))))))))))))
(check-sat)
; query 13: function main, block 63, name %67
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x123 ((_ sign_extend 24) in57_8)))
(let ((?x113 (bvshl in.01_32 (_ bv4 32))))
(let ((?x129 (bvadd ?x113 ?x123)))
(let ((?x35 (bvsub ?x129 (_ bv48 32))))
(let (($x128 (and (distinct (bvsub ((_ sign_extend 1) ?x129) ((_ sign_extend 1) (_ bv48 32))) ((_ sign_extend 1) ?x35)) true)))
(let ((?x124 ((_ sign_extend 1) ?x129)))
(let (($x74 (or false false)))
(let (($x821 (or false false false)))
(let (($x89 (or $x821 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x77 (or $x89 $x74 (or (and (distinct (bvadd ((_ sign_extend 1) ?x113) ((_ sign_extend 1) ?x123)) ?x124) true)))))
(let (($x172 (or $x77 false (or $x128))))
(and (not $x172) (or $x172 (and (distinct ?x35 ?x35) true)))))))))))))))
(check-sat)
; query 14: function main, block 68, name %69
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x74 (or false false)))
(and (not $x74) (or $x74 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 15: function main, block 68, name %70
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x33 (ite (bvsle (_ bv65 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x74 (or false false)))
(let (($x745 (or $x74 false false)))
(let (($x208 (not $x745)))
(and $x208 (or $x745 (and (distinct ?x33 ?x33) true))))))))
(check-sat)
; query 16: function main, block 71, name %72
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x74 (or false false)))
(and (not $x74) (or $x74 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 17: function main, block 71, name %73
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x60 (ite (bvsge (_ bv70 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x74 (or false false)))
(let (($x745 (or $x74 false false)))
(let (($x208 (not $x745)))
(and $x208 (or $x745 (and (distinct ?x60 ?x60) true))))))))
(check-sat)
; query 18: function main, block 74, name %75
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x821 (or false false false)))
(let (($x89 (or $x821 (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x89) (or $x89 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvshl in.01_32 (_ bv4 32))) true))))))
(check-sat)
; query 19: function main, block 74, name %76
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x74 (or false false)))
(and (not $x74) (or $x74 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 20: function main, block 74, name %77
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x123 ((_ sign_extend 24) in57_8)))
(let ((?x113 (bvshl in.01_32 (_ bv4 32))))
(let ((?x129 (bvadd ?x113 ?x123)))
(let ((?x124 ((_ sign_extend 1) ?x129)))
(let (($x74 (or false false)))
(let (($x821 (or false false false)))
(let (($x89 (or $x821 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x77 (or $x89 $x74 (or (and (distinct (bvadd ((_ sign_extend 1) ?x113) ((_ sign_extend 1) ?x123)) ?x124) true)))))
(and (not $x77) (or $x77 (and (distinct ?x129 ?x129) true))))))))))))
(check-sat)
; query 21: function main, block 74, name %78
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x123 ((_ sign_extend 24) in57_8)))
(let ((?x113 (bvshl in.01_32 (_ bv4 32))))
(let ((?x129 (bvadd ?x113 ?x123)))
(let ((?x109 (bvsub ?x129 (_ bv65 32))))
(let ((?x37 ((_ sign_extend 1) ?x109)))
(let ((?x124 ((_ sign_extend 1) ?x129)))
(let (($x74 (or false false)))
(let (($x821 (or false false false)))
(let (($x89 (or $x821 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x77 (or $x89 $x74 (or (and (distinct (bvadd ((_ sign_extend 1) ?x113) ((_ sign_extend 1) ?x123)) ?x124) true)))))
(let (($x199 (or $x77 false (or (and (distinct (bvsub ?x124 ((_ sign_extend 1) (_ bv65 32))) ?x37) true)))))
(and (not $x199) (or $x199 (and (distinct ?x109 ?x109) true)))))))))))))))
(check-sat)
; query 22: function main, block 74, name %79
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x123 ((_ sign_extend 24) in57_8)))
(let ((?x113 (bvshl in.01_32 (_ bv4 32))))
(let ((?x129 (bvadd ?x113 ?x123)))
(let ((?x109 (bvsub ?x129 (_ bv65 32))))
(let ((?x197 (bvadd ?x109 (_ bv10 32))))
(let (($x126 (and (distinct (bvadd ((_ sign_extend 1) ?x109) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x197)) true)))
(let ((?x37 ((_ sign_extend 1) ?x109)))
(let ((?x124 ((_ sign_extend 1) ?x129)))
(let (($x74 (or false false)))
(let (($x821 (or false false false)))
(let (($x89 (or $x821 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x77 (or $x89 $x74 (or (and (distinct (bvadd ((_ sign_extend 1) ?x113) ((_ sign_extend 1) ?x123)) ?x124) true)))))
(let (($x199 (or $x77 false (or (and (distinct (bvsub ?x124 ((_ sign_extend 1) (_ bv65 32))) ?x37) true)))))
(let (($x115 (or $x199 false (or $x126))))
(and (not $x115) (or $x115 (and (distinct ?x197 ?x197) true))))))))))))))))))
(check-sat)
