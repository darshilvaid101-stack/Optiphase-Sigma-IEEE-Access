; OptiPhase-Sigma refinement certificate for sweep K57-R2-057
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x229 (or false false)))
(let (($x148 (not $x229)))
(and $x148 (or $x229 (and (distinct ((_ sign_extend 16) in25_16) ((_ sign_extend 16) in25_16)) true))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let ((?x562 (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))))
(let (($x229 (or false false)))
(let (($x190 (or $x229 false false)))
(let (($x514 (not $x190)))
(and $x514 (or $x190 (and (distinct ?x562 ?x562) true))))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x229 (or false false)))
(let (($x148 (not $x229)))
(and $x148 (or $x229 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x142 ((_ sign_extend 16) in3_16)))
(let ((?x374 (bvand ?x142 (_ bv127 32))))
(let (($x229 (or false false)))
(let (($x190 (or $x229 false false)))
(let (($x514 (not $x190)))
(and $x514 (or $x190 (and (distinct ?x374 ?x374) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x142 ((_ sign_extend 16) in3_16)))
(let ((?x374 (bvand ?x142 (_ bv127 32))))
(let ((?x235 ((_ extract 15 0) ?x374)))
(let (($x229 (or false false)))
(let (($x190 (or $x229 false false)))
(let (($x120 (or $x190 false)))
(let (($x564 (not $x120)))
(and $x564 (or $x120 (and (distinct ?x235 ?x235) true)))))))))))
(check-sat)
; query 5: function check_data_types, block entry, name %1
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let (($x229 (or false false)))
(let (($x148 (not $x229)))
(and $x148 (or $x229 (and (distinct ((_ zero_extend 24) (_ bv0 8)) ((_ zero_extend 24) (_ bv0 8))) true))))))
(check-sat)
; query 6: function check_data_types, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x1734 (ite (bvslt (_ bv0 32) ((_ zero_extend 24) (_ bv0 8))) (_ bv1 1) (_ bv0 1))))
(let (($x229 (or false false)))
(let (($x190 (or $x229 false false)))
(let (($x514 (not $x190)))
(and $x514 (or $x190 (and (distinct ?x1734 ?x1734) true))))))))
(check-sat)
; query 7: function core_bench_list, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x108 (or false false false)))
(let (($x105 (not $x108)))
(and $x105 (or $x108 (and (distinct (bvadd in.0_16 (_ bv1 16)) (bvadd in.0_16 (_ bv1 16))) true))))))
(check-sat)
; query 8: function core_bench_list, block 82, name %83
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let (($x229 (or false false)))
(let (($x148 (not $x229)))
(and $x148 (or $x229 (and (distinct ((_ zero_extend 16) in.02_16) ((_ zero_extend 16) in.02_16)) true))))))
(check-sat)
; query 9: function core_bench_list, block 82, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x460 ((_ zero_extend 16) in.02_16)))
(let ((?x760 (bvmul ?x460 (_ bv4 32))))
(let (($x70 (and (distinct (bvmul ((_ sign_extend 32) ?x460) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x760)) true)))
(let (($x229 (or false false)))
(let (($x178 (or $x229 false (or $x70))))
(and (not $x178) (or $x178 (and (distinct ?x760 ?x760) true)))))))))
(check-sat)
; query 10: function core_bench_list, block 82, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(assert
 (let (($x229 (or false false)))
(let (($x148 (not $x229)))
(and $x148 (or $x229 (and (distinct ((_ zero_extend 16) in.04_16) ((_ zero_extend 16) in.04_16)) true))))))
(check-sat)
; query 11: function core_bench_list, block 82, name %86
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(assert
 (let ((?x28 ((_ zero_extend 16) in.04_16)))
(let ((?x460 ((_ zero_extend 16) in.02_16)))
(let ((?x760 (bvmul ?x460 (_ bv4 32))))
(let ((?x77 (bvsub ?x760 ?x28)))
(let ((?x87 ((_ sign_extend 1) ?x77)))
(let (($x229 (or false false)))
(let (($x70 (and (distinct (bvmul ((_ sign_extend 32) ?x460) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x760)) true)))
(let (($x178 (or $x229 false (or $x70))))
(let (($x432 (or $x178 $x229 (or (and (distinct (bvsub ((_ sign_extend 1) ?x760) ((_ sign_extend 1) ?x28)) ?x87) true)))))
(and (not $x432) (or $x432 (and (distinct ?x77 ?x77) true)))))))))))))
(check-sat)
; query 12: function core_bench_list, block 82, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x229 (or false false)))
(let (($x148 (not $x229)))
(and $x148 (or $x229 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 13: function core_bench_list, block 82, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x28 ((_ zero_extend 16) in.04_16)))
(let ((?x460 ((_ zero_extend 16) in.02_16)))
(let ((?x760 (bvmul ?x460 (_ bv4 32))))
(let ((?x77 (bvsub ?x760 ?x28)))
(let ((?x23 ((_ zero_extend 16) in.01_16)))
(let ((?x159 (bvadd ?x23 ?x77)))
(let (($x147 (and (distinct (bvadd ((_ sign_extend 1) ?x23) ((_ sign_extend 1) ?x77)) ((_ sign_extend 1) ?x159)) true)))
(let ((?x87 ((_ sign_extend 1) ?x77)))
(let (($x229 (or false false)))
(let (($x70 (and (distinct (bvmul ((_ sign_extend 32) ?x460) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x760)) true)))
(let (($x178 (or $x229 false (or $x70))))
(let (($x432 (or $x178 $x229 (or (and (distinct (bvsub ((_ sign_extend 1) ?x760) ((_ sign_extend 1) ?x28)) ?x87) true)))))
(let (($x1357 (or $x229 $x432 (or $x147))))
(and (not $x1357) (or $x1357 (and (distinct ?x159 ?x159) true)))))))))))))))))
(check-sat)
; query 14: function core_bench_list, block 82, name %89
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_16 () (_ BitVec 16))
(declare-fun in.02_16 () (_ BitVec 16))
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x28 ((_ zero_extend 16) in.04_16)))
(let ((?x460 ((_ zero_extend 16) in.02_16)))
(let ((?x760 (bvmul ?x460 (_ bv4 32))))
(let ((?x77 (bvsub ?x760 ?x28)))
(let ((?x23 ((_ zero_extend 16) in.01_16)))
(let ((?x159 (bvadd ?x23 ?x77)))
(let ((?x307 ((_ extract 15 0) ?x159)))
(let (($x147 (and (distinct (bvadd ((_ sign_extend 1) ?x23) ((_ sign_extend 1) ?x77)) ((_ sign_extend 1) ?x159)) true)))
(let ((?x87 ((_ sign_extend 1) ?x77)))
(let (($x229 (or false false)))
(let (($x70 (and (distinct (bvmul ((_ sign_extend 32) ?x460) ((_ sign_extend 32) (_ bv4 32))) ((_ sign_extend 32) ?x760)) true)))
(let (($x178 (or $x229 false (or $x70))))
(let (($x432 (or $x178 $x229 (or (and (distinct (bvsub ((_ sign_extend 1) ?x760) ((_ sign_extend 1) ?x28)) ?x87) true)))))
(let (($x1357 (or $x229 $x432 (or $x147))))
(let (($x1054 (or $x1357 false)))
(and (not $x1054) (or $x1054 (and (distinct ?x307 ?x307) true)))))))))))))))))))
(check-sat)
; query 15: function core_bench_list, block 82, name %90
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x229 (or false false)))
(let (($x148 (not $x229)))
(and $x148 (or $x229 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 16: function core_bench_list, block 82, name %91
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x88 (ite (bvslt (_ bv0 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x229 (or false false)))
(let (($x190 (or $x229 false false)))
(let (($x514 (not $x190)))
(and $x514 (or $x190 (and (distinct ?x88 ?x88) true))))))))
(check-sat)
; query 17: function core_bench_state, block 105, name %106
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x108 (or false false false)))
(let (($x105 (not $x108)))
(and $x105 (or $x108 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 18: function core_bench_state, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x108 (or false false false)))
(let (($x105 (not $x108)))
(and $x105 (or $x108 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 19: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x43 (bvadd in.01_32 (_ bv1 32))))
(let (($x49 (and (distinct ?x43 ?x43) true)))
(let (($x108 (or false false false)))
(let (($x105 (not $x108)))
(and $x105 (or $x108 $x49)))))))
(check-sat)
; query 20: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x43 (bvadd in.01_32 (_ bv1 32))))
(let ((?x1217 (bvmul ?x43 ?x43)))
(let (($x108 (or false false false)))
(let (($x226 (or $x108 $x108 false)))
(and (not $x226) (or $x226 (and (distinct ?x1217 ?x1217) true))))))))
(check-sat)
; query 21: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x43 (bvadd in.01_32 (_ bv1 32))))
(let ((?x1217 (bvmul ?x43 ?x43)))
(let ((?x977 (bvmul ?x1217 (_ bv2 32))))
(let (($x108 (or false false false)))
(let (($x226 (or $x108 $x108 false)))
(let (($x313 (or $x226 false false)))
(and (not $x313) (or $x313 (and (distinct ?x977 ?x977) true))))))))))
(check-sat)
; query 22: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x43 (bvadd in.01_32 (_ bv1 32))))
(let ((?x1217 (bvmul ?x43 ?x43)))
(let ((?x977 (bvmul ?x1217 (_ bv2 32))))
(let ((?x41 (bvmul ?x977 (_ bv4 32))))
(let (($x108 (or false false false)))
(let (($x226 (or $x108 $x108 false)))
(let (($x313 (or $x226 false false)))
(let (($x863 (or $x313 false false)))
(and (not $x863) (or $x863 (and (distinct ?x41 ?x41) true))))))))))))
(check-sat)
; query 23: function core_init_matrix, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x108 (or false false false)))
(let (($x105 (not $x108)))
(and $x105 (or $x108 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 24: function core_init_matrix, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x108 (or false false false)))
(let (($x105 (not $x108)))
(and $x105 (or $x108 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 25: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x85 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x108 (or false false false)))
(let (($x105 (not $x108)))
(and $x105 (or $x108 (and (distinct ?x85 ?x85) true)))))))
(check-sat)
; query 26: function core_init_state, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_32 () (_ BitVec 32))
(assert
 (let (($x108 (or false false false)))
(let (($x105 (not $x108)))
(and $x105 (or $x108 (and (distinct (bvadd in.06_32 (_ bv1 32)) (bvadd in.06_32 (_ bv1 32))) true))))))
(check-sat)
; query 27: function core_init_state, block 65, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let (($x108 (or false false false)))
(let (($x105 (not $x108)))
(and $x105 (or $x108 (and (distinct (bvadd in4_32 (_ bv1 32)) (bvadd in4_32 (_ bv1 32))) true))))))
(check-sat)
; query 28: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x103 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x108 (or false false false)))
(let (($x105 (not $x108)))
(and $x105 (or $x108 (and (distinct ?x103 ?x103) true)))))))
(check-sat)
; query 29: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x108 (or false false false)))
(let (($x105 (not $x108)))
(and $x105 (or $x108 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 30: function core_list_init, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x43 (bvadd in.01_32 (_ bv1 32))))
(let (($x49 (and (distinct ?x43 ?x43) true)))
(let (($x108 (or false false false)))
(let (($x105 (not $x108)))
(and $x105 (or $x108 $x49)))))))
(check-sat)
; query 31: function core_list_mergesort, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x43 (bvadd in.01_32 (_ bv1 32))))
(let (($x49 (and (distinct ?x43 ?x43) true)))
(let (($x1010 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x43)) true)))
(let (($x799 (or false false (or $x1010))))
(and (not $x799) (or $x799 $x49)))))))
(check-sat)
; query 32: function core_list_mergesort, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x66 (ite (bvslt (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x108 (or false false false)))
(let (($x105 (not $x108)))
(and $x105 (or $x108 (and (distinct ?x66 ?x66) true)))))))
(check-sat)
; query 33: function core_list_mergesort, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.224_32 () (_ BitVec 32))
(assert
 (let ((?x1084 (ite (= (_ bv0 32) in.224_32) (_ bv1 1) (_ bv0 1))))
(let (($x108 (or false false false)))
(let (($x105 (not $x108)))
(and $x105 (or $x108 (and (distinct ?x1084 ?x1084) true)))))))
(check-sat)
; query 34: function core_list_mergesort, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x1744 (ite (= (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x108 (or false false false)))
(let (($x105 (not $x108)))
(and $x105 (or $x108 (and (distinct ?x1744 ?x1744) true)))))))
(check-sat)
; query 35: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x1306 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x557 (or false false (or $x1306))))
(and (not $x557) (or $x557 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 36: function core_list_mergesort, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x168 (and (distinct (bvmul ((_ sign_extend 32) in.020_32) ((_ sign_extend 32) (_ bv2 32))) ((_ sign_extend 32) (bvmul in.020_32 (_ bv2 32)))) true)))
(let (($x1910 (or false false (or $x168))))
(and (not $x1910) (or $x1910 (and (distinct (bvmul in.020_32 (_ bv2 32)) (bvmul in.020_32 (_ bv2 32))) true))))))
(check-sat)
; query 37: function core_state_transition, block 102, name %103
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x229 (or false false)))
(let (($x148 (not $x229)))
(and $x148 (or $x229 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 38: function core_state_transition, block 102, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1922 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x229 (or false false)))
(let (($x190 (or $x229 false false)))
(let (($x514 (not $x190)))
(and $x514 (or $x190 (and (distinct ?x1922 ?x1922) true))))))))
(check-sat)
; query 39: function core_state_transition, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x229 (or false false)))
(let (($x148 (not $x229)))
(and $x148 (or $x229 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 40: function core_state_transition, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x791 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x229 (or false false)))
(let (($x190 (or $x229 false false)))
(let (($x514 (not $x190)))
(and $x514 (or $x190 (and (distinct ?x791 ?x791) true))))))))
(check-sat)
; query 41: function core_state_transition, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x229 (or false false)))
(let (($x148 (not $x229)))
(and $x148 (or $x229 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 42: function core_state_transition, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1922 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x229 (or false false)))
(let (($x190 (or $x229 false false)))
(let (($x514 (not $x190)))
(and $x514 (or $x190 (and (distinct ?x1922 ?x1922) true))))))))
(check-sat)
; query 43: function core_state_transition, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x229 (or false false)))
(let (($x148 (not $x229)))
(and $x148 (or $x229 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 44: function core_state_transition, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1857 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x229 (or false false)))
(let (($x190 (or $x229 false false)))
(let (($x514 (not $x190)))
(and $x514 (or $x190 (and (distinct ?x1857 ?x1857) true))))))))
(check-sat)
; query 45: function core_state_transition, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x229 (or false false)))
(let (($x148 (not $x229)))
(and $x148 (or $x229 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 46: function core_state_transition, block 51, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1857 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x229 (or false false)))
(let (($x190 (or $x229 false false)))
(let (($x514 (not $x190)))
(and $x514 (or $x190 (and (distinct ?x1857 ?x1857) true))))))))
(check-sat)
; query 47: function core_state_transition, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x229 (or false false)))
(let (($x148 (not $x229)))
(and $x148 (or $x229 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 48: function core_state_transition, block 64, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1857 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x229 (or false false)))
(let (($x190 (or $x229 false false)))
(let (($x514 (not $x190)))
(and $x514 (or $x190 (and (distinct ?x1857 ?x1857) true))))))))
(check-sat)
; query 49: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x483 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x108 (or false false false)))
(let (($x105 (not $x108)))
(and $x105 (or $x108 (and (distinct ?x483 ?x483) true)))))))
(check-sat)
; query 50: function core_state_transition, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x229 (or false false)))
(let (($x148 (not $x229)))
(and $x148 (or $x229 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 51: function core_state_transition, block 80, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1843 (ite (= (_ bv69 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x229 (or false false)))
(let (($x190 (or $x229 false false)))
(let (($x514 (not $x190)))
(and $x514 (or $x190 (and (distinct ?x1843 ?x1843) true))))))))
(check-sat)
; query 52: function core_state_transition, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x229 (or false false)))
(let (($x148 (not $x229)))
(and $x148 (or $x229 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 53: function core_state_transition, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1940 (ite (= (_ bv101 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x229 (or false false)))
(let (($x190 (or $x229 false false)))
(let (($x514 (not $x190)))
(and $x514 (or $x190 (and (distinct ?x1940 ?x1940) true))))))))
(check-sat)
; query 54: function core_state_transition, block 99, name %100
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x229 (or false false)))
(let (($x148 (not $x229)))
(and $x148 (or $x229 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 55: function core_state_transition, block 99, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x791 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x229 (or false false)))
(let (($x190 (or $x229 false false)))
(let (($x514 (not $x190)))
(and $x514 (or $x190 (and (distinct ?x791 ?x791) true))))))))
(check-sat)
; query 56: function crcu8, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x229 (or false false)))
(let (($x148 (not $x229)))
(and $x148 (or $x229 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 57: function crcu8, block 19, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x23 ((_ zero_extend 16) in.01_16)))
(let ((?x111 (bvxor ?x23 (_ bv16386 32))))
(let (($x229 (or false false)))
(let (($x190 (or $x229 false false)))
(let (($x514 (not $x190)))
(and $x514 (or $x190 (and (distinct ?x111 ?x111) true)))))))))
(check-sat)
; query 58: function crcu8, block 19, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x23 ((_ zero_extend 16) in.01_16)))
(let ((?x111 (bvxor ?x23 (_ bv16386 32))))
(let ((?x311 ((_ extract 15 0) ?x111)))
(let (($x229 (or false false)))
(let (($x190 (or $x229 false false)))
(let (($x120 (or $x190 false)))
(let (($x564 (not $x120)))
(and $x564 (or $x120 (and (distinct ?x311 ?x311) true)))))))))))
(check-sat)
; query 59: function crcu8, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x229 (or false false)))
(let (($x148 (not $x229)))
(and $x148 (or $x229 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 60: function crcu8, block 29, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1294 ((_ zero_extend 16) in27_16)))
(let ((?x92 (bvor ?x1294 (_ bv32768 32))))
(let (($x229 (or false false)))
(let (($x190 (or $x229 false false)))
(let (($x514 (not $x190)))
(and $x514 (or $x190 (and (distinct ?x92 ?x92) true)))))))))
(check-sat)
; query 61: function crcu8, block 29, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1294 ((_ zero_extend 16) in27_16)))
(let ((?x92 (bvor ?x1294 (_ bv32768 32))))
(let ((?x552 ((_ extract 15 0) ?x92)))
(let (($x229 (or false false)))
(let (($x190 (or $x229 false false)))
(let (($x120 (or $x190 false)))
(let (($x564 (not $x120)))
(and $x564 (or $x120 (and (distinct ?x552 ?x552) true)))))))))))
(check-sat)
; query 62: function crcu8, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x229 (or false false)))
(let (($x148 (not $x229)))
(and $x148 (or $x229 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true))))))
(check-sat)
; query 63: function crcu8, block 33, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1294 ((_ zero_extend 16) in27_16)))
(let ((?x1236 (bvand ?x1294 (_ bv32767 32))))
(let (($x229 (or false false)))
(let (($x190 (or $x229 false false)))
(let (($x514 (not $x190)))
(and $x514 (or $x190 (and (distinct ?x1236 ?x1236) true)))))))))
(check-sat)
; query 64: function crcu8, block 33, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x1294 ((_ zero_extend 16) in27_16)))
(let ((?x1236 (bvand ?x1294 (_ bv32767 32))))
(let ((?x1388 ((_ extract 15 0) ?x1236)))
(let (($x229 (or false false)))
(let (($x190 (or $x229 false false)))
(let (($x120 (or $x190 false)))
(let (($x564 (not $x120)))
(and $x564 (or $x120 (and (distinct ?x1388 ?x1388) true)))))))))))
(check-sat)
; query 65: function crcu8, block 38, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_8 () (_ BitVec 8))
(assert
 (let (($x108 (or false false false)))
(let (($x105 (not $x108)))
(and $x105 (or $x108 (and (distinct (bvadd in.02_8 (_ bv1 8)) (bvadd in.02_8 (_ bv1 8))) true))))))
(check-sat)
; query 66: function crcu8, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x1782 ((_ extract 7 0) in.01_16)))
(let ((?x171 ((_ zero_extend 24) ?x1782)))
(let (($x229 (or false false)))
(let (($x1068 (or $x229 false)))
(and (not $x1068) (or $x1068 (and (distinct ?x171 ?x171) true))))))))
(check-sat)
; query 67: function crcu8, block 6, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x1782 ((_ extract 7 0) in.01_16)))
(let ((?x171 ((_ zero_extend 24) ?x1782)))
(let ((?x2005 (bvand ?x171 (_ bv1 32))))
(let (($x229 (or false false)))
(let (($x1068 (or $x229 false)))
(let (($x2013 (or $x1068 false false)))
(and (not $x2013) (or $x2013 (and (distinct ?x2005 ?x2005) true))))))))))
(check-sat)
; query 68: function crcu8, block 6, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1782 ((_ extract 7 0) in.01_16)))
(let ((?x171 ((_ zero_extend 24) ?x1782)))
(let ((?x2005 (bvand ?x171 (_ bv1 32))))
(let ((?x588 ((_ zero_extend 24) in.0_8)))
(let ((?x884 (bvand ?x588 (_ bv1 32))))
(let ((?x1109 (bvxor ?x884 ?x2005)))
(let (($x229 (or false false)))
(let (($x1068 (or $x229 false)))
(let (($x2013 (or $x1068 false false)))
(let (($x190 (or $x229 false false)))
(let (($x1390 (or $x190 $x2013 false)))
(and (not $x1390) (or $x1390 (and (distinct ?x1109 ?x1109) true)))))))))))))))
(check-sat)
; query 69: function crcu8, block 6, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1782 ((_ extract 7 0) in.01_16)))
(let ((?x171 ((_ zero_extend 24) ?x1782)))
(let ((?x2005 (bvand ?x171 (_ bv1 32))))
(let ((?x588 ((_ zero_extend 24) in.0_8)))
(let ((?x884 (bvand ?x588 (_ bv1 32))))
(let ((?x1109 (bvxor ?x884 ?x2005)))
(let ((?x1157 ((_ extract 7 0) ?x1109)))
(let (($x229 (or false false)))
(let (($x1068 (or $x229 false)))
(let (($x2013 (or $x1068 false false)))
(let (($x190 (or $x229 false false)))
(let (($x1390 (or $x190 $x2013 false)))
(let (($x1297 (or $x1390 false)))
(and (not $x1297) (or $x1297 (and (distinct ?x1157 ?x1157) true)))))))))))))))))
(check-sat)
; query 70: function crcu8, block 6, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x229 (or false false)))
(let (($x148 (not $x229)))
(and $x148 (or $x229 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 71: function crcu8, block 6, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x588 ((_ zero_extend 24) in.0_8)))
(let ((?x1704 (bvashr ?x588 (_ bv1 32))))
(let (($x229 (or false false)))
(let (($x190 (or $x229 false false)))
(let (($x1103 (or $x190 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not $x1103) (or $x1103 (and (distinct ?x1704 ?x1704) true)))))))))
(check-sat)
; query 72: function crcu8, block 6, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x588 ((_ zero_extend 24) in.0_8)))
(let ((?x1704 (bvashr ?x588 (_ bv1 32))))
(let ((?x1961 ((_ extract 7 0) ?x1704)))
(let (($x229 (or false false)))
(let (($x190 (or $x229 false false)))
(let (($x1103 (or $x190 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x834 (or $x1103 false)))
(and (not $x834) (or $x834 (and (distinct ?x1961 ?x1961) true)))))))))))
(check-sat)
; query 73: function crcu8, block 6, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1782 ((_ extract 7 0) in.01_16)))
(let ((?x171 ((_ zero_extend 24) ?x1782)))
(let ((?x2005 (bvand ?x171 (_ bv1 32))))
(let ((?x588 ((_ zero_extend 24) in.0_8)))
(let ((?x884 (bvand ?x588 (_ bv1 32))))
(let ((?x1109 (bvxor ?x884 ?x2005)))
(let ((?x1157 ((_ extract 7 0) ?x1109)))
(let ((?x886 ((_ zero_extend 24) ?x1157)))
(let (($x229 (or false false)))
(let (($x1068 (or $x229 false)))
(let (($x2013 (or $x1068 false false)))
(let (($x190 (or $x229 false false)))
(let (($x1390 (or $x190 $x2013 false)))
(let (($x1297 (or $x1390 false)))
(let (($x1096 (or $x1297 false)))
(and (not $x1096) (or $x1096 (and (distinct ?x886 ?x886) true)))))))))))))))))))
(check-sat)
; query 74: function crcu8, block 6, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x1782 ((_ extract 7 0) in.01_16)))
(let ((?x171 ((_ zero_extend 24) ?x1782)))
(let ((?x2005 (bvand ?x171 (_ bv1 32))))
(let ((?x588 ((_ zero_extend 24) in.0_8)))
(let ((?x884 (bvand ?x588 (_ bv1 32))))
(let ((?x1109 (bvxor ?x884 ?x2005)))
(let ((?x1157 ((_ extract 7 0) ?x1109)))
(let ((?x886 ((_ zero_extend 24) ?x1157)))
(let ((?x829 (ite (= (_ bv1 32) ?x886) (_ bv1 1) (_ bv0 1))))
(let (($x229 (or false false)))
(let (($x1068 (or $x229 false)))
(let (($x2013 (or $x1068 false false)))
(let (($x190 (or $x229 false false)))
(let (($x1390 (or $x190 $x2013 false)))
(let (($x1297 (or $x1390 false)))
(let (($x1096 (or $x1297 false)))
(let (($x2034 (or $x1096 false false)))
(and (not $x2034) (or $x2034 (and (distinct ?x829 ?x829) true)))))))))))))))))))))
(check-sat)
; query 75: function crcu8, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x229 (or false false)))
(let (($x148 (not $x229)))
(and $x148 (or $x229 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 76: function crcu8, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x588 ((_ zero_extend 24) in.0_8)))
(let ((?x884 (bvand ?x588 (_ bv1 32))))
(let (($x229 (or false false)))
(let (($x190 (or $x229 false false)))
(let (($x514 (not $x190)))
(and $x514 (or $x190 (and (distinct ?x884 ?x884) true)))))))))
(check-sat)
; query 77: function crcu8, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x229 (or false false)))
(let (($x148 (not $x229)))
(and $x148 (or $x229 (and (distinct ((_ extract 7 0) in.01_16) ((_ extract 7 0) in.01_16)) true))))))
(check-sat)
; query 78: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x82 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1198 ((_ zero_extend 31) ?x82)))
(let ((?x841 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2043 ((_ zero_extend 31) ?x841)))
(let ((?x1325 (bvand ?x2043 ?x1198)))
(let ((?x732 (ite (and (distinct (_ bv0 32) ?x1325) true) (_ bv1 1) (_ bv0 1))))
(let ((?x919 ((_ zero_extend 63) ?x732)))
(let (($x229 (or false false)))
(let (($x190 (or $x229 false false)))
(let (($x120 (or $x190 false)))
(let (($x938 (or $x120 $x120 false)))
(let (($x710 (or $x938 false false)))
(let (($x728 (or $x710 false)))
(and (not $x728) (or $x728 (and (distinct ?x919 ?x919) true)))))))))))))))))
(check-sat)
; query 79: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x82 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1198 ((_ zero_extend 31) ?x82)))
(let ((?x841 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2043 ((_ zero_extend 31) ?x841)))
(let ((?x1325 (bvand ?x2043 ?x1198)))
(let ((?x732 (ite (and (distinct (_ bv0 32) ?x1325) true) (_ bv1 1) (_ bv0 1))))
(let (($x212 (= (_ bv1 1) ?x732)))
(let ((?x1371 (ite $x212 (_ bv1 32) (_ bv0 32))))
(let (($x229 (or false false)))
(let (($x190 (or $x229 false false)))
(let (($x120 (or $x190 false)))
(let (($x938 (or $x120 $x120 false)))
(let (($x710 (or $x938 false false)))
(let (($x1923 (or $x710 (ite $x212 false false))))
(and (not $x1923) (or $x1923 (and (distinct ?x1371 ?x1371) true))))))))))))))))))
(check-sat)
; query 80: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x82 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1198 ((_ zero_extend 31) ?x82)))
(let ((?x841 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2043 ((_ zero_extend 31) ?x841)))
(let ((?x1325 (bvand ?x2043 ?x1198)))
(let ((?x732 (ite (and (distinct (_ bv0 32) ?x1325) true) (_ bv1 1) (_ bv0 1))))
(let (($x212 (= (_ bv1 1) ?x732)))
(let ((?x1371 (ite $x212 (_ bv1 32) (_ bv0 32))))
(let ((?x1295 ((_ extract 7 0) ?x1371)))
(let (($x229 (or false false)))
(let (($x190 (or $x229 false false)))
(let (($x120 (or $x190 false)))
(let (($x938 (or $x120 $x120 false)))
(let (($x710 (or $x938 false false)))
(let (($x1923 (or $x710 (ite $x212 false false))))
(let (($x202 (or $x1923 false)))
(and (not $x202) (or $x202 (and (distinct ?x1295 ?x1295) true))))))))))))))))))))
(check-sat)
; query 81: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x229 (or false false)))
(let (($x148 (not $x229)))
(and $x148 (or $x229 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 82: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x841 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x229 (or false false)))
(let (($x190 (or $x229 false false)))
(let (($x514 (not $x190)))
(and $x514 (or $x190 (and (distinct ?x841 ?x841) true))))))))
(check-sat)
; query 83: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x841 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2043 ((_ zero_extend 31) ?x841)))
(let (($x229 (or false false)))
(let (($x190 (or $x229 false false)))
(let (($x120 (or $x190 false)))
(let (($x564 (not $x120)))
(and $x564 (or $x120 (and (distinct ?x2043 ?x2043) true))))))))))
(check-sat)
; query 84: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x229 (or false false)))
(let (($x148 (not $x229)))
(and $x148 (or $x229 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 85: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x82 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x229 (or false false)))
(let (($x190 (or $x229 false false)))
(let (($x514 (not $x190)))
(and $x514 (or $x190 (and (distinct ?x82 ?x82) true))))))))
(check-sat)
; query 86: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x82 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1198 ((_ zero_extend 31) ?x82)))
(let (($x229 (or false false)))
(let (($x190 (or $x229 false false)))
(let (($x120 (or $x190 false)))
(let (($x564 (not $x120)))
(and $x564 (or $x120 (and (distinct ?x1198 ?x1198) true))))))))))
(check-sat)
; query 87: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x82 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1198 ((_ zero_extend 31) ?x82)))
(let ((?x841 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2043 ((_ zero_extend 31) ?x841)))
(let ((?x1325 (bvand ?x2043 ?x1198)))
(let (($x229 (or false false)))
(let (($x190 (or $x229 false false)))
(let (($x120 (or $x190 false)))
(let (($x938 (or $x120 $x120 false)))
(and (not $x938) (or $x938 (and (distinct ?x1325 ?x1325) true)))))))))))))
(check-sat)
; query 88: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x82 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x1198 ((_ zero_extend 31) ?x82)))
(let ((?x841 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x2043 ((_ zero_extend 31) ?x841)))
(let ((?x1325 (bvand ?x2043 ?x1198)))
(let ((?x732 (ite (and (distinct (_ bv0 32) ?x1325) true) (_ bv1 1) (_ bv0 1))))
(let (($x229 (or false false)))
(let (($x190 (or $x229 false false)))
(let (($x120 (or $x190 false)))
(let (($x938 (or $x120 $x120 false)))
(let (($x710 (or $x938 false false)))
(and (not $x710) (or $x710 (and (distinct ?x732 ?x732) true)))))))))))))))
(check-sat)
; query 89: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1498 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x108 (or false false false)))
(let (($x105 (not $x108)))
(and $x105 (or $x108 (and (distinct ?x1498 ?x1498) true)))))))
(check-sat)
; query 90: function matrix_add_const, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x108 (or false false false)))
(let (($x105 (not $x108)))
(and $x105 (or $x108 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 91: function matrix_add_const, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x43 (bvadd in.01_32 (_ bv1 32))))
(let (($x49 (and (distinct ?x43 ?x43) true)))
(let (($x108 (or false false false)))
(let (($x105 (not $x108)))
(and $x105 (or $x108 $x49)))))))
(check-sat)
; query 92: function matrix_mul_const, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x108 (or false false false)))
(let (($x105 (not $x108)))
(and $x105 (or $x108 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 93: function matrix_mul_const, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x43 (bvadd in.01_32 (_ bv1 32))))
(let (($x49 (and (distinct ?x43 ?x43) true)))
(let (($x108 (or false false false)))
(let (($x105 (not $x108)))
(and $x105 (or $x108 $x49)))))))
(check-sat)
; query 94: function matrix_mul_matrix, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x108 (or false false false)))
(let (($x105 (not $x108)))
(and $x105 (or $x108 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 95: function matrix_mul_matrix, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x43 (bvadd in.01_32 (_ bv1 32))))
(let (($x49 (and (distinct ?x43 ?x43) true)))
(let (($x108 (or false false false)))
(let (($x105 (not $x108)))
(and $x105 (or $x108 $x49)))))))
(check-sat)
; query 96: function matrix_mul_matrix, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x108 (or false false false)))
(let (($x105 (not $x108)))
(and $x105 (or $x108 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 97: function matrix_mul_matrix_bitextract, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x108 (or false false false)))
(let (($x105 (not $x108)))
(and $x105 (or $x108 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 98: function matrix_mul_matrix_bitextract, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x43 (bvadd in.01_32 (_ bv1 32))))
(let (($x49 (and (distinct ?x43 ?x43) true)))
(let (($x108 (or false false false)))
(let (($x105 (not $x108)))
(and $x105 (or $x108 $x49)))))))
(check-sat)
; query 99: function matrix_mul_matrix_bitextract, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x108 (or false false false)))
(let (($x105 (not $x108)))
(and $x105 (or $x108 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 100: function matrix_mul_vect, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x108 (or false false false)))
(let (($x105 (not $x108)))
(and $x105 (or $x108 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 101: function matrix_mul_vect, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x43 (bvadd in.01_32 (_ bv1 32))))
(let (($x49 (and (distinct ?x43 ?x43) true)))
(let (($x108 (or false false false)))
(let (($x105 (not $x108)))
(and $x105 (or $x108 $x49)))))))
(check-sat)
; query 102: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x229 (or false false)))
(let (($x148 (not $x229)))
(and $x148 (or $x229 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 103: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x1984 ((_ sign_extend 16) in.1_16)))
(let ((?x1417 (bvadd ?x1984 (_ bv10 32))))
(let (($x1759 (and (distinct (bvadd ((_ sign_extend 1) ?x1984) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x1417)) true)))
(let (($x229 (or false false)))
(let (($x198 (or $x229 false (or $x1759))))
(and (not $x198) (or $x198 (and (distinct ?x1417 ?x1417) true)))))))))
(check-sat)
; query 104: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x1984 ((_ sign_extend 16) in.1_16)))
(let ((?x1417 (bvadd ?x1984 (_ bv10 32))))
(let ((?x1904 ((_ extract 15 0) ?x1417)))
(let (($x1759 (and (distinct (bvadd ((_ sign_extend 1) ?x1984) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x1417)) true)))
(let (($x229 (or false false)))
(let (($x198 (or $x229 false (or $x1759))))
(let (($x1807 (or $x198 false)))
(and (not $x1807) (or $x1807 (and (distinct ?x1904 ?x1904) true)))))))))))
(check-sat)
; query 105: function matrix_sum, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x321 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x108 (or false false false)))
(let (($x105 (not $x108)))
(and $x105 (or $x108 (and (distinct ?x321 ?x321) true)))))))
(check-sat)
; query 106: function matrix_sum, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x321 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let ((?x1729 ((_ zero_extend 63) ?x321)))
(let (($x108 (or false false false)))
(let (($x1808 (or $x108 false)))
(and (not $x1808) (or $x1808 (and (distinct ?x1729 ?x1729) true))))))))
(check-sat)
; query 107: function matrix_sum, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x321 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x932 (= (_ bv1 1) ?x321)))
(let ((?x1868 (ite $x932 (_ bv1 32) (_ bv0 32))))
(let (($x108 (or false false false)))
(let (($x568 (or $x108 (ite $x932 false false))))
(and (not $x568) (or $x568 (and (distinct ?x1868 ?x1868) true)))))))))
(check-sat)
; query 108: function matrix_sum, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x229 (or false false)))
(let (($x148 (not $x229)))
(and $x148 (or $x229 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 109: function matrix_sum, block 22, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x321 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x932 (= (_ bv1 1) ?x321)))
(let ((?x1868 (ite $x932 (_ bv1 32) (_ bv0 32))))
(let ((?x1984 ((_ sign_extend 16) in.1_16)))
(let ((?x314 (bvadd ?x1984 ?x1868)))
(let (($x733 (and (distinct (bvadd ((_ sign_extend 1) ?x1984) ((_ sign_extend 1) ?x1868)) ((_ sign_extend 1) ?x314)) true)))
(let (($x108 (or false false false)))
(let (($x568 (or $x108 (ite $x932 false false))))
(let (($x229 (or false false)))
(let (($x2054 (or $x229 $x568 (or $x733))))
(and (not $x2054) (or $x2054 (and (distinct ?x314 ?x314) true))))))))))))))
(check-sat)
; query 110: function matrix_sum, block 22, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x321 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x932 (= (_ bv1 1) ?x321)))
(let ((?x1868 (ite $x932 (_ bv1 32) (_ bv0 32))))
(let ((?x1984 ((_ sign_extend 16) in.1_16)))
(let ((?x314 (bvadd ?x1984 ?x1868)))
(let ((?x750 ((_ extract 15 0) ?x314)))
(let (($x733 (and (distinct (bvadd ((_ sign_extend 1) ?x1984) ((_ sign_extend 1) ?x1868)) ((_ sign_extend 1) ?x314)) true)))
(let (($x108 (or false false false)))
(let (($x568 (or $x108 (ite $x932 false false))))
(let (($x229 (or false false)))
(let (($x2054 (or $x229 $x568 (or $x733))))
(let (($x1865 (or $x2054 false)))
(and (not $x1865) (or $x1865 (and (distinct ?x750 ?x750) true))))))))))))))))
(check-sat)
; query 111: function matrix_sum, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x108 (or false false false)))
(let (($x105 (not $x108)))
(and $x105 (or $x108 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 112: function matrix_sum, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x43 (bvadd in.01_32 (_ bv1 32))))
(let (($x49 (and (distinct ?x43 ?x43) true)))
(let (($x108 (or false false false)))
(let (($x105 (not $x108)))
(and $x105 (or $x108 $x49)))))))
(check-sat)
; query 113: function parseval, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.23_32 () (_ BitVec 32))
(assert
 (let (($x1652 (and (distinct (bvmul ((_ sign_extend 32) in.23_32) ((_ sign_extend 32) (_ bv1024 32))) ((_ sign_extend 32) (bvmul in.23_32 (_ bv1024 32)))) true)))
(let (($x1893 (or false false (or $x1652))))
(and (not $x1893) (or $x1893 (and (distinct (bvmul in.23_32 (_ bv1024 32)) (bvmul in.23_32 (_ bv1024 32))) true))))))
(check-sat)
; query 114: function parseval, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.34_32 () (_ BitVec 32))
(assert
 (let (($x1258 (and (distinct (bvmul ((_ sign_extend 32) in.34_32) ((_ sign_extend 32) (_ bv1048576 32))) ((_ sign_extend 32) (bvmul in.34_32 (_ bv1048576 32)))) true)))
(let (($x1648 (or false false (or $x1258))))
(and (not $x1648) (or $x1648 (and (distinct (bvmul in.34_32 (_ bv1048576 32)) (bvmul in.34_32 (_ bv1048576 32))) true))))))
(check-sat)
; query 115: function partition_memory, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x108 (or false false false)))
(let (($x105 (not $x108)))
(and $x105 (or $x108 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
