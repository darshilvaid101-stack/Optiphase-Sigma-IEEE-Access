; OptiPhase-Sigma refinement certificate for sweep K12-R4-371
