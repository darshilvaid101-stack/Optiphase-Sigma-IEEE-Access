; OptiPhase-Sigma refinement certificate for sweep K57-R5-404
; query 0: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x1874 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x502 (or false false false)))
(and (not $x502) (or $x502 (and (distinct ?x1874 ?x1874) true))))))
(check-sat)
