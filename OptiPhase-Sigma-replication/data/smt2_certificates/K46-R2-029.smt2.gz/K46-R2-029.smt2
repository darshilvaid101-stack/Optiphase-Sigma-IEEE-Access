; OptiPhase-Sigma refinement certificate for sweep K46-R2-029
; query 0: function adpcm_coder, block 25, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in20_32 () (_ BitVec 32))
(assert
 (let (($x130 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in20_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in20_32))) true)))
(let (($x140 (or false false (or $x130))))
(and (not $x140) (or $x140 (and (distinct (bvsub (_ bv0 32) in20_32) (bvsub (_ bv0 32) in20_32)) true))))))
(check-sat)
; query 1: function adpcm_coder, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(declare-fun in.017_32 () (_ BitVec 32))
(assert
 (let ((?x896 (bvsub in.017_32 in.020_32)))
(let (($x11 (and (distinct (bvsub ((_ sign_extend 1) in.017_32) ((_ sign_extend 1) in.020_32)) ((_ sign_extend 1) ?x896)) true)))
(let (($x1248 (or false false (or $x11))))
(and (not $x1248) (or $x1248 (and (distinct ?x896 ?x896) true)))))))
(check-sat)
; query 2: function adpcm_coder, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(declare-fun in28_32 () (_ BitVec 32))
(assert
 (let (($x427 (and (distinct (bvadd ((_ sign_extend 1) in28_32) ((_ sign_extend 1) in.020_32)) ((_ sign_extend 1) (bvadd in28_32 in.020_32))) true)))
(let (($x283 (or false false (or $x427))))
(let (($x559 (or $x283 (and (distinct (bvadd in28_32 in.020_32) (bvadd in28_32 in.020_32)) true))))
(and (not $x283) $x559)))))
(check-sat)
; query 3: function adpcm_coder, block 36, name %37
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.014_32 () (_ BitVec 32))
(assert
 (let (($x287 (or false false false)))
(let (($x21 (not $x287)))
(and $x21 (or $x287 (and (distinct (bvor in.014_32 (_ bv2 32)) (bvor in.014_32 (_ bv2 32))) true))))))
(check-sat)
; query 4: function adpcm_coder, block 36, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in34_32 () (_ BitVec 32))
(declare-fun in.118_32 () (_ BitVec 32))
(assert
 (let (($x116 (and (distinct (bvsub ((_ sign_extend 1) in.118_32) ((_ sign_extend 1) in34_32)) ((_ sign_extend 1) (bvsub in.118_32 in34_32))) true)))
(let (($x938 (or false false (or $x116))))
(let (($x47 (or $x938 (and (distinct (bvsub in.118_32 in34_32) (bvsub in.118_32 in34_32)) true))))
(and (not $x938) $x47)))))
(check-sat)
; query 5: function adpcm_coder, block 36, name %39
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in34_32 () (_ BitVec 32))
(declare-fun in.08_32 () (_ BitVec 32))
(assert
 (let (($x90 (and (distinct (bvadd ((_ sign_extend 1) in.08_32) ((_ sign_extend 1) in34_32)) ((_ sign_extend 1) (bvadd in.08_32 in34_32))) true)))
(let (($x1059 (or false false (or $x90))))
(let (($x382 (or $x1059 (and (distinct (bvadd in.08_32 in34_32) (bvadd in.08_32 in34_32)) true))))
(and (not $x1059) $x382)))))
(check-sat)
; query 6: function adpcm_coder, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.115_32 () (_ BitVec 32))
(assert
 (let (($x287 (or false false false)))
(let (($x21 (not $x287)))
(and $x21 (or $x287 (and (distinct (bvor in.115_32 (_ bv1 32)) (bvor in.115_32 (_ bv1 32))) true))))))
(check-sat)
; query 7: function adpcm_coder, block 43, name %45
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in41_32 () (_ BitVec 32))
(declare-fun in.19_32 () (_ BitVec 32))
(assert
 (let (($x80 (and (distinct (bvadd ((_ sign_extend 1) in.19_32) ((_ sign_extend 1) in41_32)) ((_ sign_extend 1) (bvadd in.19_32 in41_32))) true)))
(let (($x54 (or false false (or $x80))))
(let (($x278 (or $x54 (and (distinct (bvadd in.19_32 in41_32) (bvadd in.19_32 in41_32)) true))))
(and (not $x54) $x278)))))
(check-sat)
; query 8: function adpcm_coder, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.210_32 () (_ BitVec 32))
(declare-fun in.011_32 () (_ BitVec 32))
(assert
 (let ((?x299 (bvsub in.011_32 in.210_32)))
(let (($x500 (and (distinct (bvsub ((_ sign_extend 1) in.011_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x299)) true)))
(let (($x105 (or false false (or $x500))))
(and (not $x105) (or $x105 (and (distinct ?x299 ?x299) true)))))))
(check-sat)
; query 9: function adpcm_coder, block 50, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.210_32 () (_ BitVec 32))
(declare-fun in.011_32 () (_ BitVec 32))
(assert
 (let ((?x103 (bvadd in.011_32 in.210_32)))
(let (($x193 (and (distinct (bvadd ((_ sign_extend 1) in.011_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x103)) true)))
(let (($x39 (or false false (or $x193))))
(and (not $x39) (or $x39 (and (distinct ?x103 ?x103) true)))))))
(check-sat)
; query 10: function adpcm_coder, block 55, name %56
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.112_32 () (_ BitVec 32))
(assert
 (let ((?x527 (ite (bvsgt (_ bv4294934528 32) in.112_32) (_ bv1 1) (_ bv0 1))))
(let (($x287 (or false false false)))
(let (($x21 (not $x287)))
(and $x21 (or $x287 (and (distinct ?x527 ?x527) true)))))))
(check-sat)
; query 11: function adpcm_coder, block 75, name %76
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in60_32 () (_ BitVec 32))
(assert
 (let (($x627 (bvuge (_ bv4 32) (_ bv32 32))))
(let (($x73 (or (and (distinct (bvlshr (bvshl in60_32 (_ bv4 32)) (_ bv4 32)) in60_32) true) (and (distinct (bvashr (bvshl in60_32 (_ bv4 32)) (_ bv4 32)) in60_32) true))))
(let (($x61 (or (or false false $x73) $x627)))
(and (not (or (or false false false) $x627)) (or $x61 (and (distinct (bvshl in60_32 (_ bv4 32)) (bvshl in60_32 (_ bv4 32))) true)))))))
(check-sat)
; query 12: function adpcm_coder, block 75, name %77
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in60_32 () (_ BitVec 32))
(assert
 (let ((?x23 (bvshl in60_32 (_ bv4 32))))
(let ((?x74 (bvand ?x23 (_ bv240 32))))
(let (($x627 (bvuge (_ bv4 32) (_ bv32 32))))
(let (($x73 (or (and (distinct (bvlshr ?x23 (_ bv4 32)) in60_32) true) (and (distinct (bvashr ?x23 (_ bv4 32)) in60_32) true))))
(let (($x61 (or (or false false $x73) $x627)))
(and (not (or (or (or false false false) $x627) false false)) (or (or $x61 false false) (and (distinct ?x74 ?x74) true)))))))))
(check-sat)
; query 13: function adpcm_decoder, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x45 (ite (and (distinct (_ bv0 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x287 (or false false false)))
(let (($x21 (not $x287)))
(and $x21 (or $x287 (and (distinct ?x45 ?x45) true)))))))
(check-sat)
; query 14: function adpcm_decoder, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x287 (or false false false)))
(let (($x21 (not $x287)))
(and $x21 (or $x287 (and (distinct (bvand in.01_32 (_ bv15 32)) (bvand in.01_32 (_ bv15 32))) true))))))
(check-sat)
; query 15: function adpcm_decoder, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.012_32 () (_ BitVec 32))
(declare-fun in42_32 () (_ BitVec 32))
(assert
 (let (($x514 (and (distinct (bvadd ((_ sign_extend 1) in42_32) ((_ sign_extend 1) in.012_32)) ((_ sign_extend 1) (bvadd in42_32 in.012_32))) true)))
(let (($x645 (or false false (or $x514))))
(let (($x876 (or $x645 (and (distinct (bvadd in42_32 in.012_32) (bvadd in42_32 in.012_32)) true))))
(and (not $x645) $x876)))))
(check-sat)
; query 16: function adpcm_decoder, block 50, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.012_32 () (_ BitVec 32))
(assert
 (let (($x287 (or false false false)))
(let (($x86 (or $x287 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x191 (or $x86 (and (distinct (bvashr in.012_32 (_ bv1 32)) (bvashr in.012_32 (_ bv1 32))) true))))
(and (not $x86) $x191)))))
(check-sat)
; query 17: function adpcm_decoder, block 50, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.012_32 () (_ BitVec 32))
(declare-fun in.08_32 () (_ BitVec 32))
(assert
 (let ((?x980 (bvashr in.012_32 (_ bv1 32))))
(let ((?x163 (bvadd in.08_32 ?x980)))
(let (($x348 (and (distinct (bvadd ((_ sign_extend 1) in.08_32) ((_ sign_extend 1) ?x980)) ((_ sign_extend 1) ?x163)) true)))
(let (($x287 (or false false false)))
(let (($x86 (or $x287 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x862 (or false $x86 (or $x348))))
(and (not $x862) (or $x862 (and (distinct ?x163 ?x163) true))))))))))
(check-sat)
; query 18: function adpcm_decoder, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.012_32 () (_ BitVec 32))
(assert
 (let (($x287 (or false false false)))
(let (($x942 (or $x287 (bvuge (_ bv2 32) (_ bv32 32)))))
(let (($x628 (or $x942 (and (distinct (bvashr in.012_32 (_ bv2 32)) (bvashr in.012_32 (_ bv2 32))) true))))
(and (not $x942) $x628)))))
(check-sat)
; query 19: function adpcm_decoder, block 56, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.012_32 () (_ BitVec 32))
(declare-fun in.19_32 () (_ BitVec 32))
(assert
 (let ((?x361 (bvashr in.012_32 (_ bv2 32))))
(let ((?x99 (bvadd in.19_32 ?x361)))
(let (($x475 (and (distinct (bvadd ((_ sign_extend 1) in.19_32) ((_ sign_extend 1) ?x361)) ((_ sign_extend 1) ?x99)) true)))
(let (($x287 (or false false false)))
(let (($x942 (or $x287 (bvuge (_ bv2 32) (_ bv32 32)))))
(let (($x16 (or false $x942 (or $x475))))
(and (not $x16) (or $x16 (and (distinct ?x99 ?x99) true))))))))))
(check-sat)
; query 20: function adpcm_decoder, block 61, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.210_32 () (_ BitVec 32))
(declare-fun in.013_32 () (_ BitVec 32))
(assert
 (let ((?x221 (bvsub in.013_32 in.210_32)))
(let (($x123 (and (distinct (bvsub ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x221)) true)))
(let (($x1012 (or false false (or $x123))))
(and (not $x1012) (or $x1012 (and (distinct ?x221 ?x221) true)))))))
(check-sat)
; query 21: function adpcm_decoder, block 63, name %64
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.210_32 () (_ BitVec 32))
(declare-fun in.013_32 () (_ BitVec 32))
(assert
 (let ((?x505 (bvadd in.013_32 in.210_32)))
(let (($x630 (and (distinct (bvadd ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x505)) true)))
(let (($x943 (or false false (or $x630))))
(and (not $x943) (or $x943 (and (distinct ?x505 ?x505) true)))))))
(check-sat)
; query 22: function adpcm_decoder, block 68, name %69
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.114_32 () (_ BitVec 32))
(assert
 (let ((?x1748 (ite (bvsgt (_ bv4294934528 32) in.114_32) (_ bv1 1) (_ bv0 1))))
(let (($x287 (or false false false)))
(let (($x21 (not $x287)))
(and $x21 (or $x287 (and (distinct ?x1748 ?x1748) true)))))))
(check-sat)
; query 23: function adpcm_decoder, block 78, name %79
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x860 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv4294967295 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv4294967295 32)))) true)))
(let (($x736 (or false false (or $x860))))
(and (not $x736) (or $x736 (and (distinct (bvadd in.02_32 (_ bv4294967295 32)) (bvadd in.02_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 24: function main, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x1065 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x287 (or false false false)))
(let (($x21 (not $x287)))
(and $x21 (or $x287 (and (distinct ?x1065 ?x1065) true)))))))
(check-sat)
