; OptiPhase-Sigma refinement certificate for sweep K13-R6-049
