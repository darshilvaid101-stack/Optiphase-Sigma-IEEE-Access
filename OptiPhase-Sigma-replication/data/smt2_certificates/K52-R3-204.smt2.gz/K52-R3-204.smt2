; OptiPhase-Sigma refinement certificate for sweep K52-R3-204
; query 0: function check, block 142, name %143
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x1599 (and (distinct (ite (= (_ bv123 32) in0_32) (_ bv1 1) (_ bv0 1)) (ite (= (_ bv1122 32) in0_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x1104 (or false false false)))
(let (($x79 (not $x1104)))
(and $x79 (or $x1104 $x1599))))))
(check-sat)
; query 1: function check, block 157, name %158
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x41 (and (distinct (ite (= (_ bv112233 32) in0_32) (_ bv1 1) (_ bv0 1)) (ite (= (_ bv111 32) in0_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x1104 (or false false false)))
(let (($x79 (not $x1104)))
(and $x79 (or $x1104 $x41))))))
(check-sat)
; query 2: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x813 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x1104 (or false false false)))
(let (($x79 (not $x1104)))
(and $x79 (or $x1104 (and (distinct ?x813 ?x813) true)))))))
(check-sat)
; query 3: function s162, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x1596 (ite (bvslt (_ bv0 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x1104 (or false false false)))
(let (($x79 (not $x1104)))
(and $x79 (or $x1104 (and (distinct ?x1596 ?x1596) true)))))))
(check-sat)
; query 4: function s276, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x297 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x116 (or false false (or $x297))))
(and (not $x116) (or $x116 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 5: function s276, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x786 (ite (bvsgt (_ bv16000 32) (bvadd in.0_32 (_ bv1 32))) (_ bv1 1) (_ bv0 1))))
(let (($x297 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x116 (or false false (or $x297))))
(let (($x176 (or $x116 false false)))
(and (not $x176) (or $x176 (and (distinct ?x786 ?x786) true))))))))
(check-sat)
; query 6: function set1d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x837 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x1104 (or false false false)))
(let (($x79 (not $x1104)))
(and $x79 (or $x1104 (and (distinct ?x837 ?x837) true)))))))
(check-sat)
; query 7: function set1ds, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x1117 (ite (= (_ bv4294967295 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x1104 (or false false false)))
(let (($x79 (not $x1104)))
(and $x79 (or $x1104 (and (distinct ?x1117 ?x1117) true)))))))
(check-sat)
; query 8: function set2d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x837 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x1104 (or false false false)))
(let (($x79 (not $x1104)))
(and $x79 (or $x1104 (and (distinct ?x837 ?x837) true)))))))
(check-sat)
; query 9: function sum1d, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x297 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x116 (or false false (or $x297))))
(and (not $x116) (or $x116 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
