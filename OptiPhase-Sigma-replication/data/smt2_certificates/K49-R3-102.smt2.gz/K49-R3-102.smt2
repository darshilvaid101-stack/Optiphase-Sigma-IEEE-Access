; OptiPhase-Sigma refinement certificate for sweep K49-R3-102
; query 0: function APCM_inverse_quantization, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x462 (or false false)))
(let (($x69 (not $x462)))
(and $x69 (or $x462 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 1: function APCM_inverse_quantization, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x686 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x462 (or false false)))
(let (($x755 (or $x462 false false)))
(let (($x38 (not $x755)))
(and $x38 (or $x755 (and (distinct ?x686 ?x686) true))))))))
(check-sat)
; query 2: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x462 (or false false)))
(let (($x69 (not $x462)))
(and $x69 (or $x462 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 3: function APCM_quantization_xmaxc_to_exp_mant, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x719 (ite (bvslt (_ bv15 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x462 (or false false)))
(let (($x755 (or $x462 false false)))
(let (($x38 (not $x755)))
(and $x38 (or $x755 (and (distinct ?x719 ?x719) true))))))))
(check-sat)
; query 4: function Decoding_of_the_coded_Log_Area_Ratios, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in6_64 () (_ BitVec 64))
(assert
 (let ((?x413 (ite (bvslt (_ bv0 64) in6_64) (_ bv1 1) (_ bv0 1))))
(let (($x62 (or false false false)))
(let (($x276 (not $x62)))
(and $x276 (or $x62 (and (distinct ?x413 ?x413) true)))))))
(check-sat)
; query 5: function Decoding_of_the_coded_Log_Area_Ratios, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in6_64 () (_ BitVec 64))
(assert
 (let ((?x413 (ite (bvslt (_ bv0 64) in6_64) (_ bv1 1) (_ bv0 1))))
(let ((?x72 ((_ zero_extend 63) ?x413)))
(let (($x62 (or false false false)))
(let (($x57 (or $x62 false)))
(let (($x128 (not $x57)))
(and $x128 (or $x57 (and (distinct ?x72 ?x72) true)))))))))
(check-sat)
; query 6: function Decoding_of_the_coded_Log_Area_Ratios, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in6_64 () (_ BitVec 64))
(assert
 (let ((?x413 (ite (bvslt (_ bv0 64) in6_64) (_ bv1 1) (_ bv0 1))))
(let (($x50 (= (_ bv1 1) ?x413)))
(let ((?x130 (ite $x50 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x62 (or false false false)))
(let (($x37 (or $x62 (ite $x50 false false))))
(and (not $x37) (or $x37 (and (distinct ?x130 ?x130) true)))))))))
(check-sat)
; query 7: function Decoding_of_the_coded_Log_Area_Ratios, block 9, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in6_64 () (_ BitVec 64))
(assert
 (let ((?x413 (ite (bvslt (_ bv0 64) in6_64) (_ bv1 1) (_ bv0 1))))
(let (($x50 (= (_ bv1 1) ?x413)))
(let ((?x130 (ite $x50 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x357 ((_ sign_extend 32) ?x130)))
(let (($x62 (or false false false)))
(let (($x37 (or $x62 (ite $x50 false false))))
(let (($x170 (or $x37 false)))
(and (not $x170) (or $x170 (and (distinct ?x357 ?x357) true)))))))))))
(check-sat)
; query 8: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x462 (or false false)))
(let (($x69 (not $x462)))
(and $x69 (or $x462 (and (distinct ((_ sign_extend 16) in1_16) ((_ sign_extend 16) in1_16)) true))))))
(check-sat)
; query 9: function Gsm_Long_Term_Synthesis_Filtering, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let ((?x80 (ite (bvsgt (_ bv40 32) ((_ sign_extend 16) in1_16)) (_ bv1 1) (_ bv0 1))))
(let (($x462 (or false false)))
(let (($x755 (or $x462 false false)))
(let (($x38 (not $x755)))
(and $x38 (or $x755 (and (distinct ?x80 ?x80) true))))))))
(check-sat)
; query 10: function Quantization_and_coding, block 11, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in8_64 () (_ BitVec 64))
(assert
 (let ((?x27 (ite (bvslt (_ bv0 64) in8_64) (_ bv1 1) (_ bv0 1))))
(let (($x62 (or false false false)))
(let (($x276 (not $x62)))
(and $x276 (or $x62 (and (distinct ?x27 ?x27) true)))))))
(check-sat)
; query 11: function Quantization_and_coding, block 11, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in8_64 () (_ BitVec 64))
(assert
 (let ((?x27 (ite (bvslt (_ bv0 64) in8_64) (_ bv1 1) (_ bv0 1))))
(let ((?x609 ((_ zero_extend 63) ?x27)))
(let (($x62 (or false false false)))
(let (($x57 (or $x62 false)))
(let (($x128 (not $x57)))
(and $x128 (or $x57 (and (distinct ?x609 ?x609) true)))))))))
(check-sat)
; query 12: function Quantization_and_coding, block 11, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in8_64 () (_ BitVec 64))
(assert
 (let ((?x27 (ite (bvslt (_ bv0 64) in8_64) (_ bv1 1) (_ bv0 1))))
(let (($x382 (= (_ bv1 1) ?x27)))
(let ((?x389 (ite $x382 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x62 (or false false false)))
(let (($x547 (or $x62 (ite $x382 false false))))
(and (not $x547) (or $x547 (and (distinct ?x389 ?x389) true)))))))))
(check-sat)
; query 13: function Quantization_and_coding, block 11, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in8_64 () (_ BitVec 64))
(assert
 (let ((?x27 (ite (bvslt (_ bv0 64) in8_64) (_ bv1 1) (_ bv0 1))))
(let (($x382 (= (_ bv1 1) ?x27)))
(let ((?x389 (ite $x382 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x630 ((_ sign_extend 32) ?x389)))
(let (($x62 (or false false false)))
(let (($x547 (or $x62 (ite $x382 false false))))
(let (($x48 (or $x547 false)))
(and (not $x48) (or $x48 (and (distinct ?x630 ?x630) true)))))))))))
(check-sat)
; query 14: function Quantization_and_coding, block 111, name %112
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in108_64 () (_ BitVec 64))
(assert
 (let ((?x119 (ite (bvslt (_ bv0 64) in108_64) (_ bv1 1) (_ bv0 1))))
(let (($x62 (or false false false)))
(let (($x276 (not $x62)))
(and $x276 (or $x62 (and (distinct ?x119 ?x119) true)))))))
(check-sat)
; query 15: function Quantization_and_coding, block 111, name %113
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in108_64 () (_ BitVec 64))
(assert
 (let ((?x119 (ite (bvslt (_ bv0 64) in108_64) (_ bv1 1) (_ bv0 1))))
(let ((?x333 ((_ zero_extend 63) ?x119)))
(let (($x62 (or false false false)))
(let (($x57 (or $x62 false)))
(let (($x128 (not $x57)))
(and $x128 (or $x57 (and (distinct ?x333 ?x333) true)))))))))
(check-sat)
; query 16: function Quantization_and_coding, block 111, name %114
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in108_64 () (_ BitVec 64))
(assert
 (let ((?x119 (ite (bvslt (_ bv0 64) in108_64) (_ bv1 1) (_ bv0 1))))
(let (($x113 (= (_ bv1 1) ?x119)))
(let ((?x268 (ite $x113 (_ bv32767 32) (_ bv4294934528 32))))
(let (($x62 (or false false false)))
(let (($x319 (or $x62 (ite $x113 false false))))
(and (not $x319) (or $x319 (and (distinct ?x268 ?x268) true)))))))))
(check-sat)
; query 17: function Quantization_and_coding, block 111, name %115
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in108_64 () (_ BitVec 64))
(assert
 (let ((?x119 (ite (bvslt (_ bv0 64) in108_64) (_ bv1 1) (_ bv0 1))))
(let (($x113 (= (_ bv1 1) ?x119)))
(let ((?x268 (ite $x113 (_ bv32767 32) (_ bv4294934528 32))))
(let ((?x54 ((_ sign_extend 32) ?x268)))
(let (($x62 (or false false false)))
(let (($x319 (or $x62 (ite $x113 false false))))
(let (($x252 (or $x319 false)))
(and (not $x252) (or $x252 (and (distinct ?x54 ?x54) true)))))))))))
(check-sat)
; query 18: function RPE_grid_positioning, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x462 (or false false)))
(let (($x69 (not $x462)))
(and $x69 (or $x462 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 19: function RPE_grid_positioning, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x428 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x490 (and (distinct ?x428 ?x428) true)))
(let (($x462 (or false false)))
(let (($x527 (or false $x462 false)))
(and (not $x527) (or $x527 $x490)))))))
(check-sat)
; query 20: function gsm_L_add, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x25 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x62 (or false false false)))
(let (($x276 (not $x62)))
(and $x276 (or $x62 (and (distinct ?x25 ?x25) true)))))))
(check-sat)
; query 21: function gsm_L_add, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x114 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvadd in0_64 in1_64))) true)))
(let (($x108 (or false false (or $x114))))
(let (($x79 (or $x108 (and (distinct (bvadd in0_64 in1_64) (bvadd in0_64 in1_64)) true))))
(and (not $x108) $x79)))))
(check-sat)
; query 22: function gsm_L_add, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x232 (bvadd in0_64 (_ bv1 64))))
(let ((?x90 (bvsub (_ bv0 64) ?x232)))
(let (($x33 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x232)) ((_ sign_extend 1) ?x90)) true)))
(let ((?x554 ((_ sign_extend 1) ?x232)))
(let (($x220 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x554) true)))))
(let (($x14 (or false $x220 (or $x33))))
(and (not $x14) (or $x14 (and (distinct ?x90 ?x90) true))))))))))
(check-sat)
; query 23: function gsm_L_add, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x217 (bvadd in1_64 (_ bv1 64))))
(let ((?x182 ((_ sign_extend 1) ?x217)))
(let (($x159 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x182) true)))))
(and (not $x159) (or $x159 (and (distinct ?x217 ?x217) true)))))))
(check-sat)
; query 24: function gsm_L_add, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x217 (bvadd in1_64 (_ bv1 64))))
(let ((?x75 (bvsub (_ bv0 64) ?x217)))
(let (($x126 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x217)) ((_ sign_extend 1) ?x75)) true)))
(let ((?x182 ((_ sign_extend 1) ?x217)))
(let (($x159 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x182) true)))))
(let (($x419 (or false $x159 (or $x126))))
(and (not $x419) (or $x419 (and (distinct ?x75 ?x75) true))))))))))
(check-sat)
; query 25: function gsm_L_add, block 8, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x217 (bvadd in1_64 (_ bv1 64))))
(let ((?x75 (bvsub (_ bv0 64) ?x217)))
(let ((?x232 (bvadd in0_64 (_ bv1 64))))
(let ((?x90 (bvsub (_ bv0 64) ?x232)))
(let ((?x309 (bvadd ?x90 ?x75)))
(let (($x126 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x217)) ((_ sign_extend 1) ?x75)) true)))
(let ((?x182 ((_ sign_extend 1) ?x217)))
(let (($x159 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x182) true)))))
(let (($x419 (or false $x159 (or $x126))))
(let (($x33 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x232)) ((_ sign_extend 1) ?x90)) true)))
(let ((?x554 ((_ sign_extend 1) ?x232)))
(let (($x220 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x554) true)))))
(let (($x14 (or false $x220 (or $x33))))
(let (($x274 (or $x14 $x419 false)))
(and (not $x274) (or $x274 (and (distinct ?x309 ?x309) true))))))))))))))))))
(check-sat)
; query 26: function gsm_L_add, block 8, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x217 (bvadd in1_64 (_ bv1 64))))
(let ((?x75 (bvsub (_ bv0 64) ?x217)))
(let ((?x232 (bvadd in0_64 (_ bv1 64))))
(let ((?x90 (bvsub (_ bv0 64) ?x232)))
(let ((?x309 (bvadd ?x90 ?x75)))
(let ((?x8 (ite (bvuge ?x309 (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x126 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x217)) ((_ sign_extend 1) ?x75)) true)))
(let ((?x182 ((_ sign_extend 1) ?x217)))
(let (($x159 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x182) true)))))
(let (($x419 (or false $x159 (or $x126))))
(let (($x33 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x232)) ((_ sign_extend 1) ?x90)) true)))
(let ((?x554 ((_ sign_extend 1) ?x232)))
(let (($x220 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x554) true)))))
(let (($x14 (or false $x220 (or $x33))))
(let (($x274 (or $x14 $x419 false)))
(let (($x271 (or $x274 false false)))
(and (not $x271) (or $x271 (and (distinct ?x8 ?x8) true))))))))))))))))))))
(check-sat)
; query 27: function gsm_L_add, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x232 (bvadd in0_64 (_ bv1 64))))
(let ((?x554 ((_ sign_extend 1) ?x232)))
(let (($x220 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) (_ bv1 64))) ?x554) true)))))
(and (not $x220) (or $x220 (and (distinct ?x232 ?x232) true)))))))
(check-sat)
; query 28: function gsm_L_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x900 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x62 (or false false false)))
(let (($x276 (not $x62)))
(and $x276 (or $x62 (and (distinct ?x900 ?x900) true)))))))
(check-sat)
; query 29: function gsm_L_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x451 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x62 (or false false false)))
(let (($x276 (not $x62)))
(and $x276 (or $x62 (and (distinct ?x451 ?x451) true)))))))
(check-sat)
; query 30: function gsm_L_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x900 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x62 (or false false false)))
(let (($x276 (not $x62)))
(and $x276 (or $x62 (and (distinct ?x900 ?x900) true)))))))
(check-sat)
; query 31: function gsm_L_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x900 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x183 ((_ zero_extend 31) ?x900)))
(let (($x62 (or false false false)))
(let (($x57 (or $x62 false)))
(let (($x128 (not $x57)))
(and $x128 (or $x57 (and (distinct ?x183 ?x183) true)))))))))
(check-sat)
; query 32: function gsm_L_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x900 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x183 ((_ zero_extend 31) ?x900)))
(let ((?x494 (bvsub (_ bv0 32) ?x183)))
(let (($x152 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x183)) ((_ sign_extend 1) ?x494)) true)))
(let (($x62 (or false false false)))
(let (($x57 (or $x62 false)))
(let (($x278 (or false $x57 (or $x152))))
(and (not $x278) (or $x278 (and (distinct ?x494 ?x494) true)))))))))))
(check-sat)
; query 33: function gsm_L_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x900 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let ((?x183 ((_ zero_extend 31) ?x900)))
(let ((?x494 (bvsub (_ bv0 32) ?x183)))
(let ((?x404 ((_ sign_extend 32) ?x494)))
(let (($x152 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x183)) ((_ sign_extend 1) ?x494)) true)))
(let (($x62 (or false false false)))
(let (($x57 (or $x62 false)))
(let (($x278 (or false $x57 (or $x152))))
(let (($x162 (or $x278 false)))
(and (not $x162) (or $x162 (and (distinct ?x404 ?x404) true)))))))))))))
(check-sat)
; query 34: function gsm_L_asr, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x24 (ite (bvsge (_ bv4294967264 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x62 (or false false false)))
(let (($x276 (not $x62)))
(and $x276 (or $x62 (and (distinct ?x24 ?x24) true)))))))
(check-sat)
; query 35: function gsm_L_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x451 (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x62 (or false false false)))
(let (($x276 (not $x62)))
(and $x276 (or $x62 (and (distinct ?x451 ?x451) true)))))))
(check-sat)
; query 36: function gsm_L_sub, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x25 (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1))))
(let (($x62 (or false false false)))
(let (($x276 (not $x62)))
(and $x276 (or $x62 (and (distinct ?x25 ?x25) true)))))))
(check-sat)
; query 37: function gsm_L_sub, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x902 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvsub in0_64 in1_64))) true)))
(let (($x707 (or false false (or $x902))))
(let (($x149 (or $x707 (and (distinct (bvsub in0_64 in1_64) (bvsub in0_64 in1_64)) true))))
(and (not $x707) $x149)))))
(check-sat)
; query 38: function gsm_L_sub, block 8, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x217 (bvadd in1_64 (_ bv1 64))))
(let ((?x75 (bvsub (_ bv0 64) ?x217)))
(let (($x126 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x217)) ((_ sign_extend 1) ?x75)) true)))
(let ((?x182 ((_ sign_extend 1) ?x217)))
(let (($x159 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x182) true)))))
(let (($x419 (or false $x159 (or $x126))))
(and (not $x419) (or $x419 (and (distinct ?x75 ?x75) true))))))))))
(check-sat)
; query 39: function gsm_L_sub, block 8, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x217 (bvadd in1_64 (_ bv1 64))))
(let ((?x75 (bvsub (_ bv0 64) ?x217)))
(let ((?x791 (bvadd in0_64 ?x75)))
(let (($x126 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) ?x217)) ((_ sign_extend 1) ?x75)) true)))
(let ((?x182 ((_ sign_extend 1) ?x217)))
(let (($x159 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x182) true)))))
(let (($x419 (or false $x159 (or $x126))))
(let (($x584 (or false $x419 false)))
(and (not $x584) (or $x584 (and (distinct ?x791 ?x791) true))))))))))))
(check-sat)
; query 40: function gsm_L_sub, block 8, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x28 (ite (bvuge (bvadd in0_64 (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64)))) (_ bv2147483647 64)) (_ bv1 1) (_ bv0 1))))
(let (($x126 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 64)) ((_ sign_extend 1) (bvadd in1_64 (_ bv1 64)))) ((_ sign_extend 1) (bvsub (_ bv0 64) (bvadd in1_64 (_ bv1 64))))) true)))
(let ((?x217 (bvadd in1_64 (_ bv1 64))))
(let ((?x182 ((_ sign_extend 1) ?x217)))
(let (($x159 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x182) true)))))
(let (($x419 (or false $x159 (or $x126))))
(let (($x584 (or false $x419 false)))
(let (($x560 (or $x584 false false)))
(and (not $x560) (or $x560 (and (distinct ?x28 ?x28) true))))))))))))
(check-sat)
; query 41: function gsm_L_sub, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x217 (bvadd in1_64 (_ bv1 64))))
(let ((?x182 ((_ sign_extend 1) ?x217)))
(let (($x159 (or false false (or (and (distinct (bvadd ((_ sign_extend 1) in1_64) ((_ sign_extend 1) (_ bv1 64))) ?x182) true)))))
(and (not $x159) (or $x159 (and (distinct ?x217 ?x217) true)))))))
(check-sat)
; query 42: function gsm_L_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x432 (ite (bvsle (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x62 (or false false false)))
(let (($x276 (not $x62)))
(and $x276 (or $x62 (and (distinct ?x432 ?x432) true)))))))
(check-sat)
; query 43: function gsm_abs, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x462 (or false false)))
(let (($x69 (not $x462)))
(and $x69 (or $x462 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 44: function gsm_abs, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x557 (ite (= (_ bv4294934528 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x462 (or false false)))
(let (($x755 (or $x462 false false)))
(let (($x38 (not $x755)))
(and $x38 (or $x755 (and (distinct ?x557 ?x557) true))))))))
(check-sat)
; query 45: function gsm_abs, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x462 (or false false)))
(let (($x69 (not $x462)))
(and $x69 (or $x462 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 46: function gsm_abs, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x385 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x462 (or false false)))
(let (($x755 (or $x462 false false)))
(let (($x38 (not $x755)))
(and $x38 (or $x755 (and (distinct ?x385 ?x385) true))))))))
(check-sat)
; query 47: function gsm_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x462 (or false false)))
(let (($x69 (not $x462)))
(and $x69 (or $x462 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 48: function gsm_add, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x462 (or false false)))
(let (($x69 (not $x462)))
(and $x69 (or $x462 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 49: function gsm_add, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x240 ((_ sign_extend 48) in1_16)))
(let ((?x161 ((_ sign_extend 48) in0_16)))
(let ((?x172 (bvadd ?x161 ?x240)))
(let (($x453 (and (distinct (bvadd ((_ sign_extend 1) ?x161) ((_ sign_extend 1) ?x240)) ((_ sign_extend 1) ?x172)) true)))
(let (($x462 (or false false)))
(let (($x692 (or $x462 $x462 (or $x453))))
(and (not $x692) (or $x692 (and (distinct ?x172 ?x172) true))))))))))
(check-sat)
; query 50: function gsm_add, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x231 (ite (bvsgt (_ bv18446744073709518848 64) (bvadd ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x240 ((_ sign_extend 48) in1_16)))
(let ((?x177 ((_ sign_extend 1) ?x240)))
(let ((?x161 ((_ sign_extend 48) in0_16)))
(let ((?x409 ((_ sign_extend 1) ?x161)))
(let (($x462 (or false false)))
(let (($x692 (or $x462 $x462 (or (and (distinct (bvadd ?x409 ?x177) ((_ sign_extend 1) (bvadd ?x161 ?x240))) true)))))
(let (($x706 (or $x692 false false)))
(and (not $x706) (or $x706 (and (distinct ?x231 ?x231) true))))))))))))
(check-sat)
; query 51: function gsm_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x375 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x62 (or false false false)))
(let (($x276 (not $x62)))
(and $x276 (or $x62 (and (distinct ?x375 ?x375) true)))))))
(check-sat)
; query 52: function gsm_asr, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x615 (ite (bvsge (_ bv4294967280 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x62 (or false false false)))
(let (($x276 (not $x62)))
(and $x276 (or $x62 (and (distinct ?x615 ?x615) true)))))))
(check-sat)
; query 53: function gsm_asr, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x462 (or false false)))
(let (($x69 (not $x462)))
(and $x69 (or $x462 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 54: function gsm_asr, block 4, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x385 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x462 (or false false)))
(let (($x755 (or $x462 false false)))
(let (($x38 (not $x755)))
(and $x38 (or $x755 (and (distinct ?x385 ?x385) true))))))))
(check-sat)
; query 55: function gsm_asr, block 4, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x385 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x680 ((_ zero_extend 31) ?x385)))
(let (($x462 (or false false)))
(let (($x755 (or $x462 false false)))
(let (($x179 (or $x755 false)))
(and (not $x179) (or $x179 (and (distinct ?x680 ?x680) true)))))))))
(check-sat)
; query 56: function gsm_asr, block 4, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x385 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x680 ((_ zero_extend 31) ?x385)))
(let ((?x641 (bvsub (_ bv0 32) ?x680)))
(let (($x150 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x680)) ((_ sign_extend 1) ?x641)) true)))
(let (($x462 (or false false)))
(let (($x755 (or $x462 false false)))
(let (($x179 (or $x755 false)))
(let (($x708 (or false $x179 (or $x150))))
(and (not $x708) (or $x708 (and (distinct ?x641 ?x641) true))))))))))))
(check-sat)
; query 57: function gsm_asr, block 4, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x385 (ite (bvsgt (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let ((?x680 ((_ zero_extend 31) ?x385)))
(let ((?x641 (bvsub (_ bv0 32) ?x680)))
(let ((?x422 ((_ extract 15 0) ?x641)))
(let (($x150 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) ?x680)) ((_ sign_extend 1) ?x641)) true)))
(let (($x462 (or false false)))
(let (($x755 (or $x462 false false)))
(let (($x179 (or $x755 false)))
(let (($x708 (or false $x179 (or $x150))))
(let (($x524 (or $x708 false)))
(and (not $x524) (or $x524 (and (distinct ?x422 ?x422) true))))))))))))))
(check-sat)
; query 58: function gsm_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x375 (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x62 (or false false false)))
(let (($x276 (not $x62)))
(and $x276 (or $x62 (and (distinct ?x375 ?x375) true)))))))
(check-sat)
; query 59: function gsm_div, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x462 (or false false)))
(let (($x69 (not $x462)))
(and $x69 (or $x462 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 60: function gsm_div, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x462 (or false false)))
(let (($x69 (not $x462)))
(and $x69 (or $x462 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 61: function gsm_div, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x462 (or false false)))
(let (($x69 (not $x462)))
(and $x69 (or $x462 (and (distinct ((_ sign_extend 16) in0_16) ((_ sign_extend 16) in0_16)) true))))))
(check-sat)
; query 62: function gsm_div, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x428 (ite (bvsle (_ bv0 32) ((_ sign_extend 16) in0_16)) (_ bv1 1) (_ bv0 1))))
(let (($x490 (and (distinct ?x428 ?x428) true)))
(let (($x462 (or false false)))
(let (($x755 (or $x462 false false)))
(let (($x38 (not $x755)))
(and $x38 (or $x755 $x490))))))))
(check-sat)
; query 63: function gsm_norm, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x900 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x62 (or false false false)))
(let (($x276 (not $x62)))
(and $x276 (or $x62 (and (distinct ?x900 (ite (bvsge (_ bv18446744072635809792 64) in0_64) (_ bv1 1) (_ bv0 1))) true)))))))
(check-sat)
; query 64: function gsm_norm, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x222 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x62 (or false false false)))
(let (($x276 (not $x62)))
(and $x276 (or $x62 (and (distinct ?x222 ?x222) true)))))))
(check-sat)
; query 65: function gsm_norm, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x222 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x710 (bvxor ?x222 (_ bv1 1))))
(let (($x62 (or false false false)))
(let (($x306 (or $x62 false false)))
(and (not $x306) (or $x306 (and (distinct ?x710 ?x710) true))))))))
(check-sat)
; query 66: function gsm_norm, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x222 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x710 (bvxor ?x222 (_ bv1 1))))
(let ((?x480 ((_ zero_extend 31) ?x710)))
(let (($x62 (or false false false)))
(let (($x306 (or $x62 false false)))
(let (($x166 (or $x306 false)))
(and (not $x166) (or $x166 (and (distinct ?x480 ?x480) true))))))))))
(check-sat)
; query 67: function gsm_norm, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x222 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x710 (bvxor ?x222 (_ bv1 1))))
(let ((?x480 ((_ zero_extend 31) ?x710)))
(let ((?x903 ((_ sign_extend 32) ?x480)))
(let (($x62 (or false false false)))
(let (($x306 (or $x62 false false)))
(let (($x166 (or $x306 false)))
(let (($x505 (or $x166 false)))
(and (not $x505) (or $x505 (and (distinct ?x903 ?x903) true))))))))))))
(check-sat)
; query 68: function gsm_norm, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x222 (ite (and (distinct (_ bv0 64) in0_64) true) (_ bv1 1) (_ bv0 1))))
(let ((?x710 (bvxor ?x222 (_ bv1 1))))
(let ((?x480 ((_ zero_extend 31) ?x710)))
(let ((?x903 ((_ sign_extend 32) ?x480)))
(let ((?x456 (ite (and (distinct (_ bv0 64) ?x903) true) (_ bv1 1) (_ bv0 1))))
(let (($x62 (or false false false)))
(let (($x306 (or $x62 false false)))
(let (($x166 (or $x306 false)))
(let (($x505 (or $x166 false)))
(let (($x269 (or $x505 false false)))
(and (not $x269) (or $x269 (and (distinct ?x456 ?x456) true))))))))))))))
(check-sat)
; query 69: function gsm_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x462 (or false false)))
(let (($x69 (not $x462)))
(and $x69 (or $x462 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 70: function gsm_sub, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x462 (or false false)))
(let (($x69 (not $x462)))
(and $x69 (or $x462 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 71: function gsm_sub, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x240 ((_ sign_extend 48) in1_16)))
(let ((?x161 ((_ sign_extend 48) in0_16)))
(let ((?x802 (bvsub ?x161 ?x240)))
(let (($x349 (and (distinct (bvsub ((_ sign_extend 1) ?x161) ((_ sign_extend 1) ?x240)) ((_ sign_extend 1) ?x802)) true)))
(let (($x462 (or false false)))
(let (($x860 (or $x462 $x462 (or $x349))))
(and (not $x860) (or $x860 (and (distinct ?x802 ?x802) true))))))))))
(check-sat)
; query 72: function gsm_sub, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x568 (ite (bvsgt (_ bv18446744073709518848 64) (bvsub ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x240 ((_ sign_extend 48) in1_16)))
(let ((?x177 ((_ sign_extend 1) ?x240)))
(let ((?x161 ((_ sign_extend 48) in0_16)))
(let ((?x409 ((_ sign_extend 1) ?x161)))
(let (($x462 (or false false)))
(let (($x860 (or $x462 $x462 (or (and (distinct (bvsub ?x409 ?x177) ((_ sign_extend 1) (bvsub ?x161 ?x240))) true)))))
(let (($x688 (or $x860 false false)))
(and (not $x688) (or $x688 (and (distinct ?x568 ?x568) true))))))))))))
(check-sat)
; query 73: function process_decode, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let (($x462 (or false false)))
(let (($x69 (not $x462)))
(and $x69 (or $x462 (and (distinct ((_ sign_extend 32) in14_32) ((_ sign_extend 32) in14_32)) true))))))
(check-sat)
; query 74: function process_decode, block 16, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x299 (ite (and (distinct (_ bv33 64) ((_ sign_extend 32) in14_32)) true) (_ bv1 1) (_ bv0 1))))
(let (($x462 (or false false)))
(let (($x755 (or $x462 false false)))
(let (($x38 (not $x755)))
(and $x38 (or $x755 (and (distinct ?x299 ?x299) true))))))))
(check-sat)
; query 75: function process_encode, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_32 () (_ BitVec 32))
(assert
 (let (($x462 (or false false)))
(let (($x69 (not $x462)))
(and $x69 (or $x462 (and (distinct ((_ sign_extend 32) in13_32) ((_ sign_extend 32) in13_32)) true))))))
(check-sat)
; query 76: function process_encode, block 15, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_32 () (_ BitVec 32))
(assert
 (let ((?x953 (ite (bvult ((_ sign_extend 32) in13_32) (_ bv160 64)) (_ bv1 1) (_ bv0 1))))
(let (($x462 (or false false)))
(let (($x755 (or $x462 false false)))
(let (($x38 (not $x755)))
(and $x38 (or $x755 (and (distinct ?x953 ?x953) true))))))))
(check-sat)
