; OptiPhase-Sigma refinement certificate for sweep K17-R4-331
