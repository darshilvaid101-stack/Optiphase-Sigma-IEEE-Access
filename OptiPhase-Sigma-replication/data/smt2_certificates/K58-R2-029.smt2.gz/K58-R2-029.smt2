; OptiPhase-Sigma refinement certificate for sweep K58-R2-029
; query 0: function calc_func, block 27, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x1730 (or false (or (= ((_ extract 15 15) in25_16) (_ bv1 1))))))
(let (($x374 (or false false)))
(let (($x184 (not $x374)))
(and $x184 (or $x1730 (and (distinct ((_ sign_extend 16) in25_16) ((_ zero_extend 16) in25_16)) true)))))))
(check-sat)
; query 1: function calc_func, block 27, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in25_16 () (_ BitVec 16))
(assert
 (let (($x1868 (and (distinct (ite (bvsgt (_ bv34 32) ((_ sign_extend 16) in25_16)) (_ bv1 1) (_ bv0 1)) (ite (bvsgt (_ bv34 32) ((_ zero_extend 16) in25_16)) (_ bv1 1) (_ bv0 1))) true)))
(let (($x221 (or (or (or false (or (= ((_ extract 15 15) in25_16) (_ bv1 1)))) false false) $x1868)))
(let (($x374 (or false false)))
(let (($x752 (or $x374 false false)))
(let (($x46 (not $x752)))
(and $x46 $x221)))))))
(check-sat)
; query 2: function calc_func, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let (($x374 (or false false)))
(let (($x184 (not $x374)))
(and $x184 (or $x374 (and (distinct ((_ sign_extend 16) in3_16) ((_ sign_extend 16) in3_16)) true))))))
(check-sat)
; query 3: function calc_func, block 9, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x101 ((_ sign_extend 16) in3_16)))
(let ((?x1771 (bvand ?x101 (_ bv127 32))))
(let (($x374 (or false false)))
(let (($x752 (or $x374 false false)))
(let (($x46 (not $x752)))
(and $x46 (or $x752 (and (distinct ?x1771 ?x1771) true)))))))))
(check-sat)
; query 4: function calc_func, block 9, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_16 () (_ BitVec 16))
(assert
 (let ((?x101 ((_ sign_extend 16) in3_16)))
(let ((?x1771 (bvand ?x101 (_ bv127 32))))
(let ((?x157 ((_ extract 15 0) ?x1771)))
(let (($x136 (or (and (distinct ((_ zero_extend 16) ?x157) ?x1771) true) (and (distinct ((_ sign_extend 16) ?x157) ?x1771) true))))
(let (($x374 (or false false)))
(let (($x752 (or $x374 false false)))
(let (($x1661 (or $x752 false)))
(let (($x1650 (not $x1661)))
(and $x1650 (or (or $x752 $x136) (and (distinct ?x157 ?x157) true))))))))))))
(check-sat)
; query 5: function core_bench_list, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_16 () (_ BitVec 16))
(assert
 (let (($x163 (or false false false)))
(let (($x156 (not $x163)))
(and $x156 (or $x163 (and (distinct (bvadd in.0_16 (_ bv1 16)) (bvadd in.0_16 (_ bv1 16))) true))))))
(check-sat)
; query 6: function core_bench_state, block 105, name %106
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let ((?x1354 (bvadd in.1_32 (_ bv1 32))))
(let (($x475 (and (distinct ?x1354 ?x1354) true)))
(let (($x54 (and (distinct (bvadd ((_ zero_extend 1) in.1_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) ?x1354)) true)))
(let (($x64 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x1354)) true)))
(let (($x163 (or false false false)))
(let (($x156 (not $x163)))
(and $x156 (or (or false false (or $x64 $x54)) $x475)))))))))
(check-sat)
; query 7: function core_bench_state, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x24 (bvadd in.0_32 (_ bv1 32))))
(let (($x326 (and (distinct ?x24 ?x24) true)))
(let (($x1838 (and (distinct (bvadd ((_ zero_extend 1) in.0_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) ?x24)) true)))
(let (($x1948 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x24)) true)))
(let (($x163 (or false false false)))
(let (($x156 (not $x163)))
(and $x156 (or (or false false (or $x1948 $x1838)) $x326)))))))))
(check-sat)
; query 8: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1901 (bvadd in.01_32 (_ bv1 32))))
(let (($x1922 (and (distinct ?x1901 ?x1901) true)))
(let (($x163 (or false false false)))
(let (($x156 (not $x163)))
(and $x156 (or $x163 $x1922)))))))
(check-sat)
; query 9: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1901 (bvadd in.01_32 (_ bv1 32))))
(let ((?x792 (bvmul ?x1901 ?x1901)))
(let (($x163 (or false false false)))
(let (($x120 (or $x163 $x163 false)))
(and (not $x120) (or $x120 (and (distinct ?x792 ?x792) true))))))))
(check-sat)
; query 10: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1901 (bvadd in.01_32 (_ bv1 32))))
(let ((?x792 (bvmul ?x1901 ?x1901)))
(let ((?x110 (bvmul ?x792 (_ bv2 32))))
(let (($x163 (or false false false)))
(let (($x120 (or $x163 $x163 false)))
(let (($x91 (or $x120 false false)))
(and (not $x91) (or $x91 (and (distinct ?x110 ?x110) true))))))))))
(check-sat)
; query 11: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1901 (bvadd in.01_32 (_ bv1 32))))
(let ((?x792 (bvmul ?x1901 ?x1901)))
(let ((?x110 (bvmul ?x792 (_ bv2 32))))
(let ((?x1818 (bvmul ?x110 (_ bv4 32))))
(let (($x163 (or false false false)))
(let (($x120 (or $x163 $x163 false)))
(let (($x91 (or $x120 false false)))
(let (($x700 (or $x91 false false)))
(and (not $x700) (or $x700 (and (distinct ?x1818 ?x1818) true))))))))))))
(check-sat)
; query 12: function core_init_matrix, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let ((?x1354 (bvadd in.1_32 (_ bv1 32))))
(let (($x475 (and (distinct ?x1354 ?x1354) true)))
(let (($x163 (or false false false)))
(let (($x156 (not $x163)))
(and $x156 (or $x163 $x475)))))))
(check-sat)
; query 13: function core_init_matrix, block 56, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x163 (or false false false)))
(let (($x156 (not $x163)))
(and $x156 (or $x163 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 14: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x1696 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x163 (or false false false)))
(let (($x156 (not $x163)))
(and $x156 (or $x163 (and (distinct ?x1696 ?x1696) true)))))))
(check-sat)
; query 15: function core_init_state, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06_32 () (_ BitVec 32))
(assert
 (let (($x972 (and (distinct (bvadd ((_ zero_extend 1) in.06_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) (bvadd in.06_32 (_ bv1 32)))) true)))
(let (($x1951 (and (distinct (bvadd ((_ sign_extend 1) in.06_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.06_32 (_ bv1 32)))) true)))
(let (($x244 (or (or false false (or $x1951 $x972)) (and (distinct (bvadd in.06_32 (_ bv1 32)) (bvadd in.06_32 (_ bv1 32))) true))))
(let (($x163 (or false false false)))
(let (($x156 (not $x163)))
(and $x156 $x244)))))))
(check-sat)
; query 16: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x1935 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x163 (or false false false)))
(let (($x156 (not $x163)))
(and $x156 (or $x163 (and (distinct ?x1935 ?x1935) true)))))))
(check-sat)
; query 17: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x163 (or false false false)))
(let (($x156 (not $x163)))
(and $x156 (or $x163 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 18: function core_list_init, block 53, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1901 (bvadd in.01_32 (_ bv1 32))))
(let (($x1922 (and (distinct ?x1901 ?x1901) true)))
(let (($x1721 (and (distinct (bvadd ((_ zero_extend 1) in.01_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) ?x1901)) true)))
(let (($x163 (or false false false)))
(let (($x156 (not $x163)))
(and $x156 (or (or false false (or $x1721)) $x1922))))))))
(check-sat)
; query 19: function core_list_mergesort, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1901 (bvadd in.01_32 (_ bv1 32))))
(let (($x1922 (and (distinct ?x1901 ?x1901) true)))
(let (($x349 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x1901)) true)))
(let (($x967 (or false false (or $x349))))
(and (not $x967) (or $x967 $x1922)))))))
(check-sat)
; query 20: function core_list_mergesort, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x447 (ite (bvslt (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x163 (or false false false)))
(let (($x156 (not $x163)))
(and $x156 (or $x163 (and (distinct ?x447 ?x447) true)))))))
(check-sat)
; query 21: function core_list_mergesort, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.224_32 () (_ BitVec 32))
(assert
 (let ((?x30 (ite (= (_ bv0 32) in.224_32) (_ bv1 1) (_ bv0 1))))
(let (($x163 (or false false false)))
(let (($x156 (not $x163)))
(and $x156 (or $x163 (and (distinct ?x30 ?x30) true)))))))
(check-sat)
; query 22: function core_list_mergesort, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x159 (ite (= (_ bv0 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x163 (or false false false)))
(let (($x156 (not $x163)))
(and $x156 (or $x163 (and (distinct ?x159 ?x159) true)))))))
(check-sat)
; query 23: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x720 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x1666 (or false false (or $x720))))
(and (not $x1666) (or $x1666 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 24: function core_list_mergesort, block 73, name %74
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x971 (and (distinct (bvmul ((_ sign_extend 32) in.020_32) ((_ sign_extend 32) (_ bv2 32))) ((_ sign_extend 32) (bvmul in.020_32 (_ bv2 32)))) true)))
(let (($x1202 (or false false (or $x971))))
(and (not $x1202) (or $x1202 (and (distinct (bvmul in.020_32 (_ bv2 32)) (bvmul in.020_32 (_ bv2 32))) true))))))
(check-sat)
; query 25: function core_state_transition, block 102, name %103
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x374 (or false false)))
(let (($x184 (not $x374)))
(and $x184 (or $x374 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 26: function core_state_transition, block 102, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x190 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x374 (or false false)))
(let (($x752 (or $x374 false false)))
(let (($x46 (not $x752)))
(and $x46 (or $x752 (and (distinct ?x190 ?x190) true))))))))
(check-sat)
; query 27: function core_state_transition, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x374 (or false false)))
(let (($x184 (not $x374)))
(and $x184 (or $x374 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 28: function core_state_transition, block 23, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1914 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x374 (or false false)))
(let (($x752 (or $x374 false false)))
(let (($x46 (not $x752)))
(and $x46 (or $x752 (and (distinct ?x1914 ?x1914) true))))))))
(check-sat)
; query 29: function core_state_transition, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x374 (or false false)))
(let (($x184 (not $x374)))
(and $x184 (or $x374 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 30: function core_state_transition, block 26, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x190 (ite (= (_ bv45 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x374 (or false false)))
(let (($x752 (or $x374 false false)))
(let (($x46 (not $x752)))
(and $x46 (or $x752 (and (distinct ?x190 ?x190) true))))))))
(check-sat)
; query 31: function core_state_transition, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x374 (or false false)))
(let (($x184 (not $x374)))
(and $x184 (or $x374 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 32: function core_state_transition, block 30, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x915 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x374 (or false false)))
(let (($x752 (or $x374 false false)))
(let (($x46 (not $x752)))
(and $x46 (or $x752 (and (distinct ?x915 ?x915) true))))))))
(check-sat)
; query 33: function core_state_transition, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x374 (or false false)))
(let (($x184 (not $x374)))
(and $x184 (or $x374 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 34: function core_state_transition, block 51, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x915 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x374 (or false false)))
(let (($x752 (or $x374 false false)))
(let (($x46 (not $x752)))
(and $x46 (or $x752 (and (distinct ?x915 ?x915) true))))))))
(check-sat)
; query 35: function core_state_transition, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x374 (or false false)))
(let (($x184 (not $x374)))
(and $x184 (or $x374 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 36: function core_state_transition, block 64, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x915 (ite (= (_ bv46 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x374 (or false false)))
(let (($x752 (or $x374 false false)))
(let (($x46 (not $x752)))
(and $x46 (or $x752 (and (distinct ?x915 ?x915) true))))))))
(check-sat)
; query 37: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x858 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x163 (or false false false)))
(let (($x156 (not $x163)))
(and $x156 (or $x163 (and (distinct ?x858 ?x858) true)))))))
(check-sat)
; query 38: function core_state_transition, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x374 (or false false)))
(let (($x184 (not $x374)))
(and $x184 (or $x374 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 39: function core_state_transition, block 80, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x396 (ite (= (_ bv69 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x374 (or false false)))
(let (($x752 (or $x374 false false)))
(let (($x46 (not $x752)))
(and $x46 (or $x752 (and (distinct ?x396 ?x396) true))))))))
(check-sat)
; query 40: function core_state_transition, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x374 (or false false)))
(let (($x184 (not $x374)))
(and $x184 (or $x374 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 41: function core_state_transition, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1934 (ite (= (_ bv101 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x374 (or false false)))
(let (($x752 (or $x374 false false)))
(let (($x46 (not $x752)))
(and $x46 (or $x752 (and (distinct ?x1934 ?x1934) true))))))))
(check-sat)
; query 42: function core_state_transition, block 99, name %100
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let (($x374 (or false false)))
(let (($x184 (not $x374)))
(and $x184 (or $x374 (and (distinct ((_ zero_extend 24) in13_8) ((_ zero_extend 24) in13_8)) true))))))
(check-sat)
; query 43: function core_state_transition, block 99, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in13_8 () (_ BitVec 8))
(assert
 (let ((?x1914 (ite (= (_ bv43 32) ((_ zero_extend 24) in13_8)) (_ bv1 1) (_ bv0 1))))
(let (($x374 (or false false)))
(let (($x752 (or $x374 false false)))
(let (($x46 (not $x752)))
(and $x46 (or $x752 (and (distinct ?x1914 ?x1914) true))))))))
(check-sat)
; query 44: function crcu8, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x374 (or false false)))
(let (($x184 (not $x374)))
(and $x184 (or $x374 (and (distinct ((_ zero_extend 16) in.01_16) ((_ zero_extend 16) in.01_16)) true))))))
(check-sat)
; query 45: function crcu8, block 19, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x1704 ((_ zero_extend 16) in.01_16)))
(let ((?x1182 (bvxor ?x1704 (_ bv16386 32))))
(let (($x374 (or false false)))
(let (($x752 (or $x374 false false)))
(let (($x46 (not $x752)))
(and $x46 (or $x752 (and (distinct ?x1182 ?x1182) true)))))))))
(check-sat)
; query 46: function crcu8, block 19, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x1704 ((_ zero_extend 16) in.01_16)))
(let ((?x1182 (bvxor ?x1704 (_ bv16386 32))))
(let ((?x93 ((_ extract 15 0) ?x1182)))
(let (($x374 (or false false)))
(let (($x752 (or $x374 false false)))
(let (($x1676 (or (or $x752 (or (and (distinct ((_ zero_extend 16) ?x93) ?x1182) true))) (and (distinct ?x93 ?x93) true))))
(let (($x1661 (or $x752 false)))
(let (($x1650 (not $x1661)))
(and $x1650 $x1676))))))))))
(check-sat)
; query 47: function crcu8, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let (($x931 (or false (or (= ((_ extract 15 15) in27_16) (_ bv1 1))))))
(let (($x374 (or false false)))
(let (($x184 (not $x374)))
(and $x184 (or $x931 (and (distinct ((_ zero_extend 16) in27_16) ((_ zero_extend 16) in27_16)) true)))))))
(check-sat)
; query 48: function crcu8, block 29, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x628 ((_ zero_extend 16) in27_16)))
(let ((?x1222 (bvor ?x628 (_ bv32768 32))))
(let (($x931 (or false (or (= ((_ extract 15 15) in27_16) (_ bv1 1))))))
(let (($x982 (or $x931 false false)))
(let (($x374 (or false false)))
(let (($x752 (or $x374 false false)))
(let (($x46 (not $x752)))
(and $x46 (or $x982 (and (distinct ?x1222 ?x1222) true)))))))))))
(check-sat)
; query 49: function crcu8, block 29, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in27_16 () (_ BitVec 16))
(assert
 (let ((?x628 ((_ zero_extend 16) in27_16)))
(let ((?x1222 (bvor ?x628 (_ bv32768 32))))
(let ((?x988 ((_ extract 15 0) ?x1222)))
(let (($x931 (or false (or (= ((_ extract 15 15) in27_16) (_ bv1 1))))))
(let (($x982 (or $x931 false false)))
(let (($x747 (or (or $x982 (or (and (distinct ((_ zero_extend 16) ?x988) ?x1222) true))) (and (distinct ?x988 ?x988) true))))
(let (($x374 (or false false)))
(let (($x752 (or $x374 false false)))
(let (($x1661 (or $x752 false)))
(let (($x1650 (not $x1661)))
(and $x1650 $x747))))))))))))
(check-sat)
; query 50: function crcu8, block 6, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x193 ((_ extract 7 0) in.01_16)))
(let ((?x452 ((_ zero_extend 24) ?x193)))
(let (($x374 (or false false)))
(let (($x943 (or $x374 false)))
(and (not $x943) (or $x943 (and (distinct ?x452 ?x452) true))))))))
(check-sat)
; query 51: function crcu8, block 6, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let ((?x193 ((_ extract 7 0) in.01_16)))
(let ((?x452 ((_ zero_extend 24) ?x193)))
(let ((?x705 (bvand ?x452 (_ bv1 32))))
(let (($x374 (or false false)))
(let (($x943 (or $x374 false)))
(let (($x601 (or $x943 false false)))
(and (not $x601) (or $x601 (and (distinct ?x705 ?x705) true))))))))))
(check-sat)
; query 52: function crcu8, block 6, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x193 ((_ extract 7 0) in.01_16)))
(let ((?x452 ((_ zero_extend 24) ?x193)))
(let ((?x705 (bvand ?x452 (_ bv1 32))))
(let ((?x991 ((_ zero_extend 24) in.0_8)))
(let ((?x734 (bvand ?x991 (_ bv1 32))))
(let ((?x969 (bvxor ?x734 ?x705)))
(let (($x374 (or false false)))
(let (($x943 (or $x374 false)))
(let (($x601 (or $x943 false false)))
(let (($x752 (or $x374 false false)))
(let (($x623 (or $x752 $x601 false)))
(and (not $x623) (or $x623 (and (distinct ?x969 ?x969) true)))))))))))))))
(check-sat)
; query 53: function crcu8, block 6, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x193 ((_ extract 7 0) in.01_16)))
(let ((?x452 ((_ zero_extend 24) ?x193)))
(let ((?x705 (bvand ?x452 (_ bv1 32))))
(let ((?x991 ((_ zero_extend 24) in.0_8)))
(let ((?x734 (bvand ?x991 (_ bv1 32))))
(let ((?x969 (bvxor ?x734 ?x705)))
(let ((?x986 ((_ extract 7 0) ?x969)))
(let (($x571 (or (and (distinct ((_ zero_extend 24) ?x986) ?x969) true) (and (distinct ((_ sign_extend 24) ?x986) ?x969) true))))
(let (($x374 (or false false)))
(let (($x943 (or $x374 false)))
(let (($x601 (or $x943 false false)))
(let (($x752 (or $x374 false false)))
(let (($x623 (or $x752 $x601 false)))
(let (($x331 (or $x623 $x571)))
(and (not (or $x623 false)) (or $x331 (and (distinct ?x986 ?x986) true))))))))))))))))))
(check-sat)
; query 54: function crcu8, block 6, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x374 (or false false)))
(let (($x184 (not $x374)))
(and $x184 (or $x374 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 55: function crcu8, block 6, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x991 ((_ zero_extend 24) in.0_8)))
(let ((?x674 (bvlshr ?x991 (_ bv1 32))))
(let ((?x812 (bvashr ?x991 (_ bv1 32))))
(let (($x374 (or false false)))
(let (($x752 (or $x374 false false)))
(let (($x794 (or $x752 (bvuge (_ bv1 32) (_ bv32 32)))))
(and (not $x794) (or $x794 (and (distinct ?x812 ?x674) true))))))))))
(check-sat)
; query 56: function crcu8, block 6, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x560 (and (distinct ((_ extract 7 0) (bvashr ((_ zero_extend 24) in.0_8) (_ bv1 32))) ((_ extract 7 0) (bvlshr ((_ zero_extend 24) in.0_8) (_ bv1 32)))) true)))
(let (($x374 (or false false)))
(let (($x752 (or $x374 false false)))
(let (($x794 (or $x752 (bvuge (_ bv1 32) (_ bv32 32)))))
(let (($x761 (or $x794 false)))
(and (not $x761) (or $x761 $x560))))))))
(check-sat)
; query 57: function crcu8, block 6, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x193 ((_ extract 7 0) in.01_16)))
(let ((?x452 ((_ zero_extend 24) ?x193)))
(let ((?x705 (bvand ?x452 (_ bv1 32))))
(let ((?x991 ((_ zero_extend 24) in.0_8)))
(let ((?x734 (bvand ?x991 (_ bv1 32))))
(let ((?x969 (bvxor ?x734 ?x705)))
(let ((?x986 ((_ extract 7 0) ?x969)))
(let ((?x850 ((_ zero_extend 24) ?x986)))
(let (($x374 (or false false)))
(let (($x943 (or $x374 false)))
(let (($x601 (or $x943 false false)))
(let (($x752 (or $x374 false false)))
(let (($x623 (or $x752 $x601 false)))
(let (($x331 (or $x623 (or (and (distinct ?x850 ?x969) true) (and (distinct ((_ sign_extend 24) ?x986) ?x969) true)))))
(let (($x169 (or $x331 (or (= ((_ extract 7 7) ?x986) (_ bv1 1))))))
(and (not (or (or $x623 false) false)) (or $x169 (and (distinct ?x850 ?x850) true)))))))))))))))))))
(check-sat)
; query 58: function crcu8, block 6, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x193 ((_ extract 7 0) in.01_16)))
(let ((?x452 ((_ zero_extend 24) ?x193)))
(let ((?x705 (bvand ?x452 (_ bv1 32))))
(let ((?x991 ((_ zero_extend 24) in.0_8)))
(let ((?x734 (bvand ?x991 (_ bv1 32))))
(let ((?x969 (bvxor ?x734 ?x705)))
(let ((?x986 ((_ extract 7 0) ?x969)))
(let ((?x850 ((_ zero_extend 24) ?x986)))
(let ((?x702 (ite (= (_ bv1 32) ?x850) (_ bv1 1) (_ bv0 1))))
(let (($x374 (or false false)))
(let (($x943 (or $x374 false)))
(let (($x601 (or $x943 false false)))
(let (($x752 (or $x374 false false)))
(let (($x623 (or $x752 $x601 false)))
(let (($x331 (or $x623 (or (and (distinct ?x850 ?x969) true) (and (distinct ((_ sign_extend 24) ?x986) ?x969) true)))))
(let (($x169 (or $x331 (or (= ((_ extract 7 7) ?x986) (_ bv1 1))))))
(and (not (or (or (or $x623 false) false) false false)) (or (or $x169 false false) (and (distinct ?x702 ?x702) true))))))))))))))))))))
(check-sat)
; query 59: function crcu8, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let (($x374 (or false false)))
(let (($x184 (not $x374)))
(and $x184 (or $x374 (and (distinct ((_ zero_extend 24) in.0_8) ((_ zero_extend 24) in.0_8)) true))))))
(check-sat)
; query 60: function crcu8, block 6, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_8 () (_ BitVec 8))
(assert
 (let ((?x991 ((_ zero_extend 24) in.0_8)))
(let ((?x734 (bvand ?x991 (_ bv1 32))))
(let (($x374 (or false false)))
(let (($x752 (or $x374 false false)))
(let (($x46 (not $x752)))
(and $x46 (or $x752 (and (distinct ?x734 ?x734) true)))))))))
(check-sat)
; query 61: function crcu8, block 6, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_16 () (_ BitVec 16))
(assert
 (let (($x374 (or false false)))
(let (($x184 (not $x374)))
(and $x184 (or $x374 (and (distinct ((_ extract 7 0) in.01_16) ((_ extract 7 0) in.01_16)) true))))))
(check-sat)
; query 62: function ee_isdigit, block entry, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x780 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x172 ((_ zero_extend 31) ?x780)))
(let ((?x766 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x249 ((_ zero_extend 31) ?x766)))
(let ((?x738 (bvand ?x249 ?x172)))
(let ((?x867 (ite (and (distinct (_ bv0 32) ?x738) true) (_ bv1 1) (_ bv0 1))))
(let ((?x506 ((_ zero_extend 63) ?x867)))
(let (($x374 (or false false)))
(let (($x752 (or $x374 false false)))
(let (($x1661 (or $x752 false)))
(let (($x808 (or $x1661 $x1661 false)))
(let (($x144 (or $x808 false false)))
(let (($x823 (or $x144 false)))
(and (not $x823) (or $x823 (and (distinct ?x506 ?x506) true)))))))))))))))))
(check-sat)
; query 63: function ee_isdigit, block entry, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x780 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x172 ((_ zero_extend 31) ?x780)))
(let ((?x766 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x249 ((_ zero_extend 31) ?x766)))
(let ((?x738 (bvand ?x249 ?x172)))
(let ((?x867 (ite (and (distinct (_ bv0 32) ?x738) true) (_ bv1 1) (_ bv0 1))))
(let (($x900 (= (_ bv1 1) ?x867)))
(let ((?x292 (ite $x900 (_ bv1 32) (_ bv0 32))))
(let (($x374 (or false false)))
(let (($x752 (or $x374 false false)))
(let (($x1661 (or $x752 false)))
(let (($x808 (or $x1661 $x1661 false)))
(let (($x144 (or $x808 false false)))
(let (($x372 (or $x144 (ite $x900 false false))))
(and (not $x372) (or $x372 (and (distinct ?x292 ?x292) true))))))))))))))))))
(check-sat)
; query 64: function ee_isdigit, block entry, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x780 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x172 ((_ zero_extend 31) ?x780)))
(let ((?x766 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x249 ((_ zero_extend 31) ?x766)))
(let ((?x738 (bvand ?x249 ?x172)))
(let ((?x867 (ite (and (distinct (_ bv0 32) ?x738) true) (_ bv1 1) (_ bv0 1))))
(let (($x900 (= (_ bv1 1) ?x867)))
(let ((?x292 (ite $x900 (_ bv1 32) (_ bv0 32))))
(let ((?x392 ((_ extract 7 0) ?x292)))
(let (($x804 (or (and (distinct ((_ zero_extend 24) ?x392) ?x292) true) (and (distinct ((_ sign_extend 24) ?x392) ?x292) true))))
(let (($x374 (or false false)))
(let (($x752 (or $x374 false false)))
(let (($x1661 (or $x752 false)))
(let (($x808 (or $x1661 $x1661 false)))
(let (($x144 (or $x808 false false)))
(let (($x372 (or $x144 (ite $x900 false false))))
(and (not (or $x372 false)) (or (or $x372 $x804) (and (distinct ?x392 ?x392) true))))))))))))))))))))
(check-sat)
; query 65: function ee_isdigit, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x374 (or false false)))
(let (($x184 (not $x374)))
(and $x184 (or $x374 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 66: function ee_isdigit, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x766 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x374 (or false false)))
(let (($x752 (or $x374 false false)))
(let (($x46 (not $x752)))
(and $x46 (or $x752 (and (distinct ?x766 ?x766) true))))))))
(check-sat)
; query 67: function ee_isdigit, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x766 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x249 ((_ zero_extend 31) ?x766)))
(let (($x374 (or false false)))
(let (($x752 (or $x374 false false)))
(let (($x1661 (or $x752 false)))
(let (($x1650 (not $x1661)))
(and $x1650 (or $x1661 (and (distinct ?x249 ?x249) true))))))))))
(check-sat)
; query 68: function ee_isdigit, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let (($x374 (or false false)))
(let (($x184 (not $x374)))
(and $x184 (or $x374 (and (distinct ((_ zero_extend 24) in0_8) ((_ zero_extend 24) in0_8)) true))))))
(check-sat)
; query 69: function ee_isdigit, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x780 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let (($x374 (or false false)))
(let (($x752 (or $x374 false false)))
(let (($x46 (not $x752)))
(and $x46 (or $x752 (and (distinct ?x780 ?x780) true))))))))
(check-sat)
; query 70: function ee_isdigit, block entry, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x780 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x172 ((_ zero_extend 31) ?x780)))
(let (($x374 (or false false)))
(let (($x752 (or $x374 false false)))
(let (($x1661 (or $x752 false)))
(let (($x1650 (not $x1661)))
(and $x1650 (or $x1661 (and (distinct ?x172 ?x172) true))))))))))
(check-sat)
; query 71: function ee_isdigit, block entry, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x780 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x172 ((_ zero_extend 31) ?x780)))
(let ((?x766 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x249 ((_ zero_extend 31) ?x766)))
(let ((?x738 (bvand ?x249 ?x172)))
(let (($x374 (or false false)))
(let (($x752 (or $x374 false false)))
(let (($x1661 (or $x752 false)))
(let (($x808 (or $x1661 $x1661 false)))
(and (not $x808) (or $x808 (and (distinct ?x738 ?x738) true)))))))))))))
(check-sat)
; query 72: function ee_isdigit, block entry, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_8 () (_ BitVec 8))
(assert
 (let ((?x780 (ite (bvsge (_ bv57 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x172 ((_ zero_extend 31) ?x780)))
(let ((?x766 (ite (bvsle (_ bv48 32) ((_ zero_extend 24) in0_8)) (_ bv1 1) (_ bv0 1))))
(let ((?x249 ((_ zero_extend 31) ?x766)))
(let ((?x738 (bvand ?x249 ?x172)))
(let ((?x867 (ite (and (distinct (_ bv0 32) ?x738) true) (_ bv1 1) (_ bv0 1))))
(let (($x374 (or false false)))
(let (($x752 (or $x374 false false)))
(let (($x1661 (or $x752 false)))
(let (($x808 (or $x1661 $x1661 false)))
(let (($x144 (or $x808 false false)))
(and (not $x144) (or $x144 (and (distinct ?x867 ?x867) true)))))))))))))))
(check-sat)
; query 73: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x426 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x163 (or false false false)))
(let (($x156 (not $x163)))
(and $x156 (or $x163 (and (distinct ?x426 ?x426) true)))))))
(check-sat)
; query 74: function matrix_add_const, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x24 (bvadd in.0_32 (_ bv1 32))))
(let (($x326 (and (distinct ?x24 ?x24) true)))
(let (($x163 (or false false false)))
(let (($x156 (not $x163)))
(and $x156 (or $x163 $x326)))))))
(check-sat)
; query 75: function matrix_add_const, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1901 (bvadd in.01_32 (_ bv1 32))))
(let (($x1922 (and (distinct ?x1901 ?x1901) true)))
(let (($x163 (or false false false)))
(let (($x156 (not $x163)))
(and $x156 (or $x163 $x1922)))))))
(check-sat)
; query 76: function matrix_mul_const, block 23, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x24 (bvadd in.0_32 (_ bv1 32))))
(let (($x326 (and (distinct ?x24 ?x24) true)))
(let (($x163 (or false false false)))
(let (($x156 (not $x163)))
(and $x156 (or $x163 $x326)))))))
(check-sat)
; query 77: function matrix_mul_const, block 26, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1901 (bvadd in.01_32 (_ bv1 32))))
(let (($x1922 (and (distinct ?x1901 ?x1901) true)))
(let (($x163 (or false false false)))
(let (($x156 (not $x163)))
(and $x156 (or $x163 $x1922)))))))
(check-sat)
; query 78: function matrix_mul_matrix, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x24 (bvadd in.0_32 (_ bv1 32))))
(let (($x326 (and (distinct ?x24 ?x24) true)))
(let (($x163 (or false false false)))
(let (($x156 (not $x163)))
(and $x156 (or $x163 $x326)))))))
(check-sat)
; query 79: function matrix_mul_matrix, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1901 (bvadd in.01_32 (_ bv1 32))))
(let (($x1922 (and (distinct ?x1901 ?x1901) true)))
(let (($x163 (or false false false)))
(let (($x156 (not $x163)))
(and $x156 (or $x163 $x1922)))))))
(check-sat)
; query 80: function matrix_mul_matrix, block 43, name %44
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x163 (or false false false)))
(let (($x156 (not $x163)))
(and $x156 (or $x163 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 81: function matrix_mul_matrix_bitextract, block 42, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x24 (bvadd in.0_32 (_ bv1 32))))
(let (($x326 (and (distinct ?x24 ?x24) true)))
(let (($x163 (or false false false)))
(let (($x156 (not $x163)))
(and $x156 (or $x163 $x326)))))))
(check-sat)
; query 82: function matrix_mul_matrix_bitextract, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1901 (bvadd in.01_32 (_ bv1 32))))
(let (($x1922 (and (distinct ?x1901 ?x1901) true)))
(let (($x163 (or false false false)))
(let (($x156 (not $x163)))
(and $x156 (or $x163 $x1922)))))))
(check-sat)
; query 83: function matrix_mul_matrix_bitextract, block 48, name %49
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x163 (or false false false)))
(let (($x156 (not $x163)))
(and $x156 (or $x163 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 84: function matrix_mul_vect, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x24 (bvadd in.0_32 (_ bv1 32))))
(let (($x326 (and (distinct ?x24 ?x24) true)))
(let (($x163 (or false false false)))
(let (($x156 (not $x163)))
(and $x156 (or $x163 $x326)))))))
(check-sat)
; query 85: function matrix_mul_vect, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1901 (bvadd in.01_32 (_ bv1 32))))
(let (($x1922 (and (distinct ?x1901 ?x1901) true)))
(let (($x163 (or false false false)))
(let (($x156 (not $x163)))
(and $x156 (or $x163 $x1922)))))))
(check-sat)
; query 86: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x374 (or false false)))
(let (($x184 (not $x374)))
(and $x184 (or $x374 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 87: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x160 ((_ sign_extend 16) in.1_16)))
(let ((?x1645 (bvadd ?x160 (_ bv10 32))))
(let (($x1329 (and (distinct (bvadd ((_ sign_extend 1) ?x160) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x1645)) true)))
(let (($x374 (or false false)))
(let (($x1337 (or $x374 false (or $x1329))))
(and (not $x1337) (or $x1337 (and (distinct ?x1645 ?x1645) true)))))))))
(check-sat)
; query 88: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x160 ((_ sign_extend 16) in.1_16)))
(let ((?x1645 (bvadd ?x160 (_ bv10 32))))
(let ((?x1335 ((_ extract 15 0) ?x1645)))
(let (($x1329 (and (distinct (bvadd ((_ sign_extend 1) ?x160) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x1645)) true)))
(let (($x374 (or false false)))
(let (($x1337 (or $x374 false (or $x1329))))
(let (($x1332 (or $x1337 false)))
(and (not $x1332) (or $x1332 (and (distinct ?x1335 ?x1335) true)))))))))))
(check-sat)
; query 89: function matrix_sum, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x1263 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x163 (or false false false)))
(let (($x156 (not $x163)))
(and $x156 (or $x163 (and (distinct ?x1263 ?x1263) true)))))))
(check-sat)
; query 90: function matrix_sum, block 22, name %24
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x1263 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let ((?x1287 ((_ zero_extend 63) ?x1263)))
(let (($x163 (or false false false)))
(let (($x604 (or $x163 false)))
(and (not $x604) (or $x604 (and (distinct ?x1287 ?x1287) true))))))))
(check-sat)
; query 91: function matrix_sum, block 22, name %25
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(assert
 (let ((?x1263 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x1308 (= (_ bv1 1) ?x1263)))
(let ((?x1268 (ite $x1308 (_ bv1 32) (_ bv0 32))))
(let (($x163 (or false false false)))
(let (($x1265 (or $x163 (ite $x1308 false false))))
(and (not $x1265) (or $x1265 (and (distinct ?x1268 ?x1268) true)))))))))
(check-sat)
; query 92: function matrix_sum, block 22, name %26
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x374 (or false false)))
(let (($x184 (not $x374)))
(and $x184 (or $x374 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true))))))
(check-sat)
; query 93: function matrix_sum, block 22, name %27
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x1263 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x1308 (= (_ bv1 1) ?x1263)))
(let ((?x1268 (ite $x1308 (_ bv1 32) (_ bv0 32))))
(let ((?x160 ((_ sign_extend 16) in.1_16)))
(let ((?x262 (bvadd ?x160 ?x1268)))
(let (($x1269 (and (distinct (bvadd ((_ sign_extend 1) ?x160) ((_ sign_extend 1) ?x1268)) ((_ sign_extend 1) ?x262)) true)))
(let (($x163 (or false false false)))
(let (($x1265 (or $x163 (ite $x1308 false false))))
(let (($x374 (or false false)))
(let (($x1301 (or $x374 $x1265 (or $x1269))))
(and (not $x1301) (or $x1301 (and (distinct ?x262 ?x262) true))))))))))))))
(check-sat)
; query 94: function matrix_sum, block 22, name %28
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.17_32 () (_ BitVec 32))
(declare-fun in14_32 () (_ BitVec 32))
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x1263 (ite (bvsgt in14_32 in.17_32) (_ bv1 1) (_ bv0 1))))
(let (($x1308 (= (_ bv1 1) ?x1263)))
(let ((?x1268 (ite $x1308 (_ bv1 32) (_ bv0 32))))
(let ((?x160 ((_ sign_extend 16) in.1_16)))
(let ((?x262 (bvadd ?x160 ?x1268)))
(let ((?x660 ((_ extract 15 0) ?x262)))
(let (($x1269 (and (distinct (bvadd ((_ sign_extend 1) ?x160) ((_ sign_extend 1) ?x1268)) ((_ sign_extend 1) ?x262)) true)))
(let (($x163 (or false false false)))
(let (($x1265 (or $x163 (ite $x1308 false false))))
(let (($x374 (or false false)))
(let (($x1301 (or $x374 $x1265 (or $x1269))))
(let (($x561 (or $x1301 false)))
(and (not $x561) (or $x561 (and (distinct ?x660 ?x660) true))))))))))))))))
(check-sat)
; query 95: function matrix_sum, block 30, name %31
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x24 (bvadd in.0_32 (_ bv1 32))))
(let (($x326 (and (distinct ?x24 ?x24) true)))
(let (($x163 (or false false false)))
(let (($x156 (not $x163)))
(and $x156 (or $x163 $x326)))))))
(check-sat)
; query 96: function matrix_sum, block 33, name %34
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1901 (bvadd in.01_32 (_ bv1 32))))
(let (($x1922 (and (distinct ?x1901 ?x1901) true)))
(let (($x163 (or false false false)))
(let (($x156 (not $x163)))
(and $x156 (or $x163 $x1922)))))))
(check-sat)
; query 97: function parseval, block 80, name %81
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.23_32 () (_ BitVec 32))
(assert
 (let (($x391 (and (distinct (bvmul ((_ sign_extend 32) in.23_32) ((_ sign_extend 32) (_ bv1024 32))) ((_ sign_extend 32) (bvmul in.23_32 (_ bv1024 32)))) true)))
(let (($x1264 (or false false (or $x391))))
(and (not $x1264) (or $x1264 (and (distinct (bvmul in.23_32 (_ bv1024 32)) (bvmul in.23_32 (_ bv1024 32))) true))))))
(check-sat)
; query 98: function parseval, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.34_32 () (_ BitVec 32))
(assert
 (let (($x704 (and (distinct (bvmul ((_ sign_extend 32) in.34_32) ((_ sign_extend 32) (_ bv1048576 32))) ((_ sign_extend 32) (bvmul in.34_32 (_ bv1048576 32)))) true)))
(let (($x1291 (or false false (or $x704))))
(and (not $x1291) (or $x1291 (and (distinct (bvmul in.34_32 (_ bv1048576 32)) (bvmul in.34_32 (_ bv1048576 32))) true))))))
(check-sat)
; query 99: function partition_memory, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x24 (bvadd in.0_32 (_ bv1 32))))
(let (($x326 (and (distinct ?x24 ?x24) true)))
(let (($x1838 (and (distinct (bvadd ((_ zero_extend 1) in.0_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) ?x24)) true)))
(let (($x1948 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x24)) true)))
(let (($x163 (or false false false)))
(let (($x156 (not $x163)))
(and $x156 (or (or false false (or $x1948 $x1838)) $x326)))))))))
(check-sat)
; query 100: function run_crc_loop, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x1901 (bvadd in.01_32 (_ bv1 32))))
(let (($x1922 (and (distinct ?x1901 ?x1901) true)))
(let (($x1721 (and (distinct (bvadd ((_ zero_extend 1) in.01_32) ((_ zero_extend 1) (_ bv1 32))) ((_ zero_extend 1) ?x1901)) true)))
(let (($x349 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) ?x1901)) true)))
(let (($x163 (or false false false)))
(let (($x156 (not $x163)))
(and $x156 (or (or false false (or $x349 $x1721)) $x1922)))))))))
(check-sat)
