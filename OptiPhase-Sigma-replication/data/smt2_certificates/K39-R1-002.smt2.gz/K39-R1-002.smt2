; OptiPhase-Sigma refinement certificate for sweep K39-R1-002
