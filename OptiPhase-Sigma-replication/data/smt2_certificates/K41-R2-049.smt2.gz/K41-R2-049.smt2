; OptiPhase-Sigma refinement certificate for sweep K41-R2-049
; query 0: function decfile, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in17_32 () (_ BitVec 32))
(assert
 (let ((?x64 (ite (and (distinct (_ bv16 32) in17_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x127 (or false false false)))
(let (($x134 (not $x127)))
(and $x134 (or $x127 (and (distinct ?x64 ?x64) true)))))))
(check-sat)
; query 1: function decfile, block 40, name %41
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x32 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x20 (or false false (or $x32))))
(and (not $x20) (or $x20 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function decfile, block 82, name %83
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x51 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x40 (or false false (or $x51))))
(and (not $x40) (or $x40 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 3: function decfile, block 85, name %86
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x365 (ite (= (_ bv15 32) in.01.lcssa_32) (_ bv1 1) (_ bv0 1))))
(let (($x127 (or false false false)))
(let (($x134 (not $x127)))
(and $x134 (or $x127 (and (distinct ?x365 ?x365) true)))))))
(check-sat)
; query 4: function decfile, block 85, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x365 (ite (= (_ bv15 32) in.01.lcssa_32) (_ bv1 1) (_ bv0 1))))
(let ((?x85 ((_ zero_extend 63) ?x365)))
(let (($x127 (or false false false)))
(let (($x97 (or $x127 false)))
(and (not $x97) (or $x97 (and (distinct ?x85 ?x85) true))))))))
(check-sat)
; query 5: function decfile, block 85, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x365 (ite (= (_ bv15 32) in.01.lcssa_32) (_ bv1 1) (_ bv0 1))))
(let (($x111 (= (_ bv1 1) ?x365)))
(let ((?x465 (ite $x111 (_ bv1 32) (_ bv0 32))))
(let (($x127 (or false false false)))
(let (($x443 (or $x127 (ite $x111 false false))))
(and (not $x443) (or $x443 (and (distinct ?x465 ?x465) true)))))))))
(check-sat)
; query 6: function decfile, block 85, name %89
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x365 (ite (= (_ bv15 32) in.01.lcssa_32) (_ bv1 1) (_ bv0 1))))
(let (($x111 (= (_ bv1 1) ?x365)))
(let ((?x465 (ite $x111 (_ bv1 32) (_ bv0 32))))
(let ((?x179 (bvsub (_ bv1 32) ?x465)))
(let ((?x295 ((_ sign_extend 1) ?x179)))
(let (($x127 (or false false false)))
(let (($x443 (or $x127 (ite $x111 false false))))
(let (($x25 (or false $x443 (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv1 32)) ((_ sign_extend 1) ?x465)) ?x295) true)))))
(and (not $x25) (or $x25 (and (distinct ?x179 ?x179) true))))))))))))
(check-sat)
; query 7: function decfile, block 85, name %90
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01.lcssa_32 () (_ BitVec 32))
(declare-fun in46_32 () (_ BitVec 32))
(assert
 (let ((?x365 (ite (= (_ bv15 32) in.01.lcssa_32) (_ bv1 1) (_ bv0 1))))
(let (($x111 (= (_ bv1 1) ?x365)))
(let ((?x465 (ite $x111 (_ bv1 32) (_ bv0 32))))
(let ((?x179 (bvsub (_ bv1 32) ?x465)))
(let ((?x154 (bvadd in46_32 ?x179)))
(let (($x196 (and (distinct (bvadd ((_ sign_extend 1) in46_32) ((_ sign_extend 1) ?x179)) ((_ sign_extend 1) ?x154)) true)))
(let ((?x295 ((_ sign_extend 1) ?x179)))
(let (($x127 (or false false false)))
(let (($x443 (or $x127 (ite $x111 false false))))
(let (($x25 (or false $x443 (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv1 32)) ((_ sign_extend 1) ?x465)) ?x295) true)))))
(let (($x423 (or false $x25 (or $x196))))
(and (not $x423) (or $x423 (and (distinct ?x154 ?x154) true)))))))))))))))
(check-sat)
; query 8: function decfile, block 85, name %91
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01.lcssa_32 () (_ BitVec 32))
(declare-fun in46_32 () (_ BitVec 32))
(assert
 (let ((?x365 (ite (= (_ bv15 32) in.01.lcssa_32) (_ bv1 1) (_ bv0 1))))
(let (($x111 (= (_ bv1 1) ?x365)))
(let ((?x465 (ite $x111 (_ bv1 32) (_ bv0 32))))
(let ((?x179 (bvsub (_ bv1 32) ?x465)))
(let ((?x154 (bvadd in46_32 ?x179)))
(let ((?x993 (ite (and (distinct (_ bv0 32) ?x154) true) (_ bv1 1) (_ bv0 1))))
(let (($x196 (and (distinct (bvadd ((_ sign_extend 1) in46_32) ((_ sign_extend 1) ?x179)) ((_ sign_extend 1) ?x154)) true)))
(let ((?x295 ((_ sign_extend 1) ?x179)))
(let (($x127 (or false false false)))
(let (($x443 (or $x127 (ite $x111 false false))))
(let (($x25 (or false $x443 (or (and (distinct (bvsub ((_ sign_extend 1) (_ bv1 32)) ((_ sign_extend 1) ?x465)) ?x295) true)))))
(let (($x423 (or false $x25 (or $x196))))
(let (($x59 (or $x423 false false)))
(and (not $x59) (or $x59 (and (distinct ?x993 ?x993) true)))))))))))))))))
(check-sat)
; query 9: function encfile, block 50, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_64 () (_ BitVec 64))
(assert
 (let (($x127 (or false false false)))
(let (($x134 (not $x127)))
(and $x134 (or $x127 (and (distinct (bvadd in.1_64 (_ bv1 64)) (bvadd in.1_64 (_ bv1 64))) true))))))
(check-sat)
; query 10: function encfile, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_64 () (_ BitVec 64))
(assert
 (let (($x127 (or false false false)))
(let (($x134 (not $x127)))
(and $x134 (or $x127 (and (distinct (bvadd in.2_64 (_ bv1 64)) (bvadd in.2_64 (_ bv1 64))) true))))))
(check-sat)
; query 11: function encfile, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.5_64 () (_ BitVec 64))
(assert
 (let (($x127 (or false false false)))
(let (($x134 (not $x127)))
(and $x134 (or $x127 (and (distinct (bvadd in.5_64 (_ bv1 64)) (bvadd in.5_64 (_ bv1 64))) true))))))
(check-sat)
; query 12: function fillrand, block 34, name %35
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x91 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x41 (or false false (or $x91))))
(and (not $x41) (or $x41 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 13: function main, block 41, name %42
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let (($x232 (or false false)))
(and (not $x232) (or $x232 (and (distinct ((_ sign_extend 24) in38_8) ((_ sign_extend 24) in38_8)) true)))))
(check-sat)
; query 14: function main, block 41, name %43
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let ((?x106 (ite (bvsge (_ bv57 32) ((_ sign_extend 24) in38_8)) (_ bv1 1) (_ bv0 1))))
(let (($x232 (or false false)))
(let (($x17 (or $x232 false false)))
(let (($x33 (not $x17)))
(and $x33 (or $x17 (and (distinct ?x106 ?x106) true))))))))
(check-sat)
; query 15: function main, block 44, name %45
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x127 (or false false false)))
(let (($x81 (or $x127 (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x81) (or $x81 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvshl in.01_32 (_ bv4 32))) true))))))
(check-sat)
; query 16: function main, block 44, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let (($x232 (or false false)))
(and (not $x232) (or $x232 (and (distinct ((_ sign_extend 24) in38_8) ((_ sign_extend 24) in38_8)) true)))))
(check-sat)
; query 17: function main, block 44, name %47
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x223 ((_ sign_extend 24) in38_8)))
(let ((?x62 (bvshl in.01_32 (_ bv4 32))))
(let ((?x38 (bvadd ?x62 ?x223)))
(let ((?x118 ((_ sign_extend 1) ?x38)))
(let (($x232 (or false false)))
(let (($x127 (or false false false)))
(let (($x81 (or $x127 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x55 (or $x81 $x232 (or (and (distinct (bvadd ((_ sign_extend 1) ?x62) ((_ sign_extend 1) ?x223)) ?x118) true)))))
(and (not $x55) (or $x55 (and (distinct ?x38 ?x38) true))))))))))))
(check-sat)
; query 18: function main, block 44, name %48
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x223 ((_ sign_extend 24) in38_8)))
(let ((?x62 (bvshl in.01_32 (_ bv4 32))))
(let ((?x38 (bvadd ?x62 ?x223)))
(let ((?x105 (bvsub ?x38 (_ bv48 32))))
(let (($x68 (and (distinct (bvsub ((_ sign_extend 1) ?x38) ((_ sign_extend 1) (_ bv48 32))) ((_ sign_extend 1) ?x105)) true)))
(let ((?x118 ((_ sign_extend 1) ?x38)))
(let (($x232 (or false false)))
(let (($x127 (or false false false)))
(let (($x81 (or $x127 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x55 (or $x81 $x232 (or (and (distinct (bvadd ((_ sign_extend 1) ?x62) ((_ sign_extend 1) ?x223)) ?x118) true)))))
(let (($x37 (or $x55 false (or $x68))))
(and (not $x37) (or $x37 (and (distinct ?x105 ?x105) true)))))))))))))))
(check-sat)
; query 19: function main, block 49, name %50
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let (($x232 (or false false)))
(and (not $x232) (or $x232 (and (distinct ((_ sign_extend 24) in38_8) ((_ sign_extend 24) in38_8)) true)))))
(check-sat)
; query 20: function main, block 49, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let ((?x57 (ite (bvsle (_ bv65 32) ((_ sign_extend 24) in38_8)) (_ bv1 1) (_ bv0 1))))
(let (($x232 (or false false)))
(let (($x17 (or $x232 false false)))
(let (($x33 (not $x17)))
(and $x33 (or $x17 (and (distinct ?x57 ?x57) true))))))))
(check-sat)
; query 21: function main, block 52, name %53
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let (($x232 (or false false)))
(and (not $x232) (or $x232 (and (distinct ((_ sign_extend 24) in38_8) ((_ sign_extend 24) in38_8)) true)))))
(check-sat)
; query 22: function main, block 52, name %54
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let ((?x510 (ite (bvsge (_ bv70 32) ((_ sign_extend 24) in38_8)) (_ bv1 1) (_ bv0 1))))
(let (($x232 (or false false)))
(let (($x17 (or $x232 false false)))
(let (($x33 (not $x17)))
(and $x33 (or $x17 (and (distinct ?x510 ?x510) true))))))))
(check-sat)
; query 23: function main, block 55, name %56
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x127 (or false false false)))
(let (($x81 (or $x127 (bvuge (_ bv4 32) (_ bv32 32)))))
(and (not $x81) (or $x81 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvshl in.01_32 (_ bv4 32))) true))))))
(check-sat)
; query 24: function main, block 55, name %57
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(assert
 (let (($x232 (or false false)))
(and (not $x232) (or $x232 (and (distinct ((_ sign_extend 24) in38_8) ((_ sign_extend 24) in38_8)) true)))))
(check-sat)
; query 25: function main, block 55, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x223 ((_ sign_extend 24) in38_8)))
(let ((?x62 (bvshl in.01_32 (_ bv4 32))))
(let ((?x38 (bvadd ?x62 ?x223)))
(let ((?x118 ((_ sign_extend 1) ?x38)))
(let (($x232 (or false false)))
(let (($x127 (or false false false)))
(let (($x81 (or $x127 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x55 (or $x81 $x232 (or (and (distinct (bvadd ((_ sign_extend 1) ?x62) ((_ sign_extend 1) ?x223)) ?x118) true)))))
(and (not $x55) (or $x55 (and (distinct ?x38 ?x38) true))))))))))))
(check-sat)
; query 26: function main, block 55, name %59
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x223 ((_ sign_extend 24) in38_8)))
(let ((?x62 (bvshl in.01_32 (_ bv4 32))))
(let ((?x38 (bvadd ?x62 ?x223)))
(let ((?x290 (bvsub ?x38 (_ bv65 32))))
(let ((?x130 ((_ sign_extend 1) ?x290)))
(let ((?x118 ((_ sign_extend 1) ?x38)))
(let (($x232 (or false false)))
(let (($x127 (or false false false)))
(let (($x81 (or $x127 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x55 (or $x81 $x232 (or (and (distinct (bvadd ((_ sign_extend 1) ?x62) ((_ sign_extend 1) ?x223)) ?x118) true)))))
(let (($x403 (or $x55 false (or (and (distinct (bvsub ?x118 ((_ sign_extend 1) (_ bv65 32))) ?x130) true)))))
(and (not $x403) (or $x403 (and (distinct ?x290 ?x290) true)))))))))))))))
(check-sat)
; query 27: function main, block 55, name %60
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in38_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x223 ((_ sign_extend 24) in38_8)))
(let ((?x62 (bvshl in.01_32 (_ bv4 32))))
(let ((?x38 (bvadd ?x62 ?x223)))
(let ((?x290 (bvsub ?x38 (_ bv65 32))))
(let ((?x434 (bvadd ?x290 (_ bv10 32))))
(let (($x48 (and (distinct (bvadd ((_ sign_extend 1) ?x290) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x434)) true)))
(let ((?x130 ((_ sign_extend 1) ?x290)))
(let ((?x118 ((_ sign_extend 1) ?x38)))
(let (($x232 (or false false)))
(let (($x127 (or false false false)))
(let (($x81 (or $x127 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x55 (or $x81 $x232 (or (and (distinct (bvadd ((_ sign_extend 1) ?x62) ((_ sign_extend 1) ?x223)) ?x118) true)))))
(let (($x403 (or $x55 false (or (and (distinct (bvsub ?x118 ((_ sign_extend 1) (_ bv65 32))) ?x130) true)))))
(let (($x241 (or $x403 false (or $x48))))
(and (not $x241) (or $x241 (and (distinct ?x434 ?x434) true))))))))))))))))))
(check-sat)
; query 28: function main, block 81, name %82
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x820 (ite (bvsgt (_ bv32 32) in.06.lcssa_32) (_ bv1 1) (_ bv0 1))))
(let (($x127 (or false false false)))
(let (($x134 (not $x127)))
(and $x134 (or $x127 (and (distinct ?x820 ?x820) true)))))))
(check-sat)
; query 29: function main, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06.lcssa_32 () (_ BitVec 32))
(assert
 (let (($x127 (or false false false)))
(let (($x86 (or $x127 (and (distinct (bvand in.06.lcssa_32 (_ bv15 32)) (bvand in.06.lcssa_32 (_ bv15 32))) true))))
(let (($x134 (not $x127)))
(and $x134 $x86)))))
(check-sat)
; query 30: function main, block 83, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.06.lcssa_32 () (_ BitVec 32))
(assert
 (let ((?x665 (ite (and (distinct (_ bv0 32) (bvand in.06.lcssa_32 (_ bv15 32))) true) (_ bv1 1) (_ bv0 1))))
(let (($x127 (or false false false)))
(let (($x89 (or $x127 false false)))
(let (($x181 (not $x89)))
(and $x181 (or $x89 (and (distinct ?x665 ?x665) true))))))))
(check-sat)
; query 31: function set_key, block 11, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let (($x127 (or false false false)))
(let (($x134 (not $x127)))
(and $x134 (or $x127 (and (distinct (bvand in2_32 (_ bv1 32)) (bvand in2_32 (_ bv1 32))) true))))))
(check-sat)
; query 32: function set_key, block 11, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x424 (ite (and (distinct (_ bv0 32) (bvand in2_32 (_ bv1 32))) true) (_ bv1 1) (_ bv0 1))))
(let (($x127 (or false false false)))
(let (($x89 (or $x127 false false)))
(let (($x181 (not $x89)))
(and $x181 (or $x89 (and (distinct ?x424 ?x424) true))))))))
(check-sat)
; query 33: function set_key, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let (($x127 (or false false false)))
(let (($x134 (not $x127)))
(and $x134 (or $x127 (and (distinct (bvand in2_32 (_ bv2 32)) (bvand in2_32 (_ bv2 32))) true))))))
(check-sat)
; query 34: function set_key, block 14, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x261 (ite (and (distinct (_ bv0 32) (bvand in2_32 (_ bv2 32))) true) (_ bv1 1) (_ bv0 1))))
(let (($x127 (or false false false)))
(let (($x89 (or $x127 false false)))
(let (($x181 (not $x89)))
(and $x181 (or $x89 (and (distinct ?x261 ?x261) true))))))))
(check-sat)
; query 35: function set_key, block 17, name %18
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x346 (ite (and (distinct (_ bv0 64) in1_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x127 (or false false false)))
(let (($x134 (not $x127)))
(and $x134 (or $x127 (and (distinct ?x346 ?x346) true)))))))
(check-sat)
; query 36: function set_key, block 514, name %515
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_64 () (_ BitVec 64))
(assert
 (let (($x127 (or false false false)))
(let (($x134 (not $x127)))
(and $x134 (or $x127 (and (distinct (bvadd in.01_64 (_ bv1 64)) (bvadd in.01_64 (_ bv1 64))) true))))))
(check-sat)
; query 37: function set_key, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x208 (ite (bvult in1_64 (_ bv16 64)) (_ bv1 1) (_ bv0 1))))
(let (($x127 (or false false false)))
(let (($x134 (not $x127)))
(and $x134 (or $x127 (and (distinct ?x208 ?x208) true)))))))
(check-sat)
; query 38: function set_key, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x828 (ite (bvugt in1_64 (_ bv32 64)) (_ bv1 1) (_ bv0 1))))
(let (($x127 (or false false false)))
(let (($x134 (not $x127)))
(and $x134 (or $x127 (and (distinct ?x828 ?x828) true)))))))
(check-sat)
; query 39: function set_key, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let (($x127 (or false false false)))
(let (($x134 (not $x127)))
(and $x134 (or $x127 (and (distinct (bvand in1_64 (_ bv7 64)) (bvand in1_64 (_ bv7 64))) true))))))
(check-sat)
; query 40: function set_key, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let ((?x452 (ite (and (distinct (_ bv0 64) (bvand in1_64 (_ bv7 64))) true) (_ bv1 1) (_ bv0 1))))
(let (($x127 (or false false false)))
(let (($x89 (or $x127 false false)))
(let (($x181 (not $x89)))
(and $x181 (or $x89 (and (distinct ?x452 ?x452) true))))))))
(check-sat)
