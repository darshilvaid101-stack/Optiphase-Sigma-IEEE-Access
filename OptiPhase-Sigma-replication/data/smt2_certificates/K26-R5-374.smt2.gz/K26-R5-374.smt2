; OptiPhase-Sigma refinement certificate for sweep K26-R5-374
; query 0: function xmalloc, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in7_32 () (_ BitVec 32))
(assert
 (let ((?x22 (ite (and (distinct (_ bv0 32) in7_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x113 (or false false false)))
(and (not $x113) (or $x113 (and (distinct ?x22 ?x22) true))))))
(check-sat)
