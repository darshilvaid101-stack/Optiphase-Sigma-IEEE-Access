; OptiPhase-Sigma refinement certificate for sweep K46-R4-316
; query 0: function main, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x159 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x179 (or false false false)))
(and (not $x179) (or $x179 (and (distinct ?x159 ?x159) true))))))
(check-sat)
