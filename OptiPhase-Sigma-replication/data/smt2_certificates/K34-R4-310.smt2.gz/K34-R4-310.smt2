; OptiPhase-Sigma refinement certificate for sweep K34-R4-310
; query 0: function corner_draw, block 11, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x432 (ite (= (_ bv0 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x793 (or false false false)))
(let (($x92 (not $x793)))
(and $x92 (or $x793 (and (distinct ?x432 ?x432) true)))))))
(check-sat)
; query 1: function edge_draw, block 39, name %40
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x153 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x920 (or false false (or $x153))))
(and (not $x920) (or $x920 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function edge_draw, block 57, name %58
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x37 (and (distinct (bvadd ((_ sign_extend 1) in.12_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.12_32 (_ bv1 32)))) true)))
(let (($x15 (or false false (or $x37))))
(and (not $x15) (or $x15 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 3: function edge_draw, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in4_32 () (_ BitVec 32))
(assert
 (let ((?x181 (ite (= (_ bv0 32) in4_32) (_ bv1 1) (_ bv0 1))))
(let (($x793 (or false false false)))
(let (($x92 (not $x793)))
(and $x92 (or $x793 (and (distinct ?x181 ?x181) true)))))))
(check-sat)
; query 4: function enlarge, block 106, name %107
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x476 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x566 (or false false (or $x476))))
(and (not $x566) (or $x566 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 5: function enlarge, block 158, name %159
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x405 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x398 (or false false (or $x405))))
(and (not $x398) (or $x398 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 6: function enlarge, block 161, name %162
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.2_32 () (_ BitVec 32))
(assert
 (let (($x10 (and (distinct (bvadd ((_ sign_extend 1) in.2_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.2_32 (_ bv1 32)))) true)))
(let (($x30 (or false false (or $x10))))
(and (not $x30) (or $x30 (and (distinct (bvadd in.2_32 (_ bv1 32)) (bvadd in.2_32 (_ bv1 32))) true))))))
(check-sat)
; query 7: function enlarge, block 37, name %38
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x153 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x920 (or false false (or $x153))))
(and (not $x920) (or $x920 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function getint, block 14, name %15
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x25 (ite (bvsle (_ bv48 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x793 (or false false false)))
(let (($x92 (not $x793)))
(and $x92 (or $x793 (and (distinct ?x25 ?x25) true)))))))
(check-sat)
; query 9: function getint, block 16, name %17
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x277 (ite (bvsge (_ bv57 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x793 (or false false false)))
(let (($x92 (not $x793)))
(and $x92 (or $x793 (and (distinct ?x277 ?x277) true)))))))
(check-sat)
; query 10: function getint, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in26_32 () (_ BitVec 32))
(assert
 (let ((?x104 (ite (bvsgt (_ bv48 32) in26_32) (_ bv1 1) (_ bv0 1))))
(let (($x793 (or false false false)))
(let (($x92 (not $x793)))
(and $x92 (or $x793 (and (distinct ?x104 ?x104) true)))))))
(check-sat)
; query 11: function getint, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in26_32 () (_ BitVec 32))
(assert
 (let ((?x117 (ite (bvslt (_ bv57 32) in26_32) (_ bv1 1) (_ bv0 1))))
(let (($x793 (or false false false)))
(let (($x92 (not $x793)))
(and $x92 (or $x793 (and (distinct ?x117 ?x117) true)))))))
(check-sat)
; query 12: function getint, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let ((?x349 (ite (= (_ bv4294967295 32) in.02_32) (_ bv1 1) (_ bv0 1))))
(let (($x793 (or false false false)))
(let (($x92 (not $x793)))
(and $x92 (or $x793 (and (distinct ?x349 ?x349) true)))))))
(check-sat)
; query 13: function int_to_uchar, block 29, name %30
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.03_32 () (_ BitVec 32))
(assert
 (let (($x235 (and (distinct (bvadd ((_ sign_extend 1) in.03_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.03_32 (_ bv1 32)))) true)))
(let (($x420 (or false false (or $x235))))
(and (not $x420) (or $x420 (and (distinct (bvadd in.03_32 (_ bv1 32)) (bvadd in.03_32 (_ bv1 32))) true))))))
(check-sat)
; query 14: function int_to_uchar, block 31, name %32
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x679 (and (distinct (bvsub ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) in.0_32)) ((_ sign_extend 1) (bvsub in.01_32 in.0_32))) true)))
(let (($x46 (or false false (or $x679))))
(let (($x27 (or $x46 (and (distinct (bvsub in.01_32 in.0_32) (bvsub in.01_32 in.0_32)) true))))
(and (not $x46) $x27)))))
(check-sat)
; query 15: function int_to_uchar, block 45, name %46
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.14_32 () (_ BitVec 32))
(assert
 (let (($x167 (and (distinct (bvadd ((_ sign_extend 1) in.14_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.14_32 (_ bv1 32)))) true)))
(let (($x96 (or false false (or $x167))))
(and (not $x96) (or $x96 (and (distinct (bvadd in.14_32 (_ bv1 32)) (bvadd in.14_32 (_ bv1 32))) true))))))
(check-sat)
; query 16: function main, block 129, name %130
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.011_32 () (_ BitVec 32))
(assert
 (let ((?x106 (ite (and (distinct (_ bv0 32) in.011_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x793 (or false false false)))
(let (($x92 (not $x793)))
(and $x92 (or $x793 (and (distinct ?x106 ?x106) true)))))))
(check-sat)
; query 17: function main, block 160, name %161
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x474 (ite (and (distinct (_ bv0 32) in.01_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x793 (or false false false)))
(let (($x92 (not $x793)))
(and $x92 (or $x793 (and (distinct ?x474 ?x474) true)))))))
(check-sat)
; query 18: function main, block 35, name %36
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x348 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x147 (or false false (or $x348))))
(and (not $x147) (or $x147 (and (distinct (bvadd in.020_32 (_ bv1 32)) (bvadd in.020_32 (_ bv1 32))) true))))))
(check-sat)
; query 19: function main, block 35, name %37
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let ((?x49 (ite (bvsge (bvadd in.020_32 (_ bv1 32)) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x348 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x147 (or false false (or $x348))))
(let (($x120 (or $x147 false false)))
(and (not $x120) (or $x120 (and (distinct ?x49 ?x49) true))))))))
(check-sat)
; query 20: function main, block 49, name %50
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let (($x348 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x147 (or false false (or $x348))))
(and (not $x147) (or $x147 (and (distinct (bvadd in.020_32 (_ bv1 32)) (bvadd in.020_32 (_ bv1 32))) true))))))
(check-sat)
; query 21: function main, block 49, name %51
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in.020_32 () (_ BitVec 32))
(assert
 (let ((?x49 (ite (bvsge (bvadd in.020_32 (_ bv1 32)) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x348 (and (distinct (bvadd ((_ sign_extend 1) in.020_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.020_32 (_ bv1 32)))) true)))
(let (($x147 (or false false (or $x348))))
(let (($x120 (or $x147 false false)))
(and (not $x120) (or $x120 (and (distinct ?x49 ?x49) true))))))))
(check-sat)
; query 22: function main, block 64, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.014_32 () (_ BitVec 32))
(assert
 (let ((?x64 (ite (= (_ bv1 32) in.014_32) (_ bv1 1) (_ bv0 1))))
(let (($x793 (or false false false)))
(let (($x92 (not $x793)))
(and $x92 (or $x793 (and (distinct ?x64 ?x64) true)))))))
(check-sat)
; query 23: function main, block 66, name %67
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x8 (ite (= (_ bv0 32) in.0_32) (_ bv1 1) (_ bv0 1))))
(let (($x793 (or false false false)))
(let (($x92 (not $x793)))
(and $x92 (or $x793 (and (distinct ?x8 ?x8) true)))))))
(check-sat)
; query 24: function main, block 84, name %85
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.07_32 () (_ BitVec 32))
(assert
 (let ((?x40 (ite (and (distinct (_ bv0 32) in.07_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x793 (or false false false)))
(let (($x92 (not $x793)))
(and $x92 (or $x793 (and (distinct ?x40 ?x40) true)))))))
(check-sat)
; query 25: function median, block 103, name %104
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x405 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x398 (or false false (or $x405))))
(and (not $x398) (or $x398 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 26: function median, block 106, name %107
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x153 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x920 (or false false (or $x153))))
(and (not $x920) (or $x920 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 27: function setup_brightness_lut, block 28, name %29
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x153 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x920 (or false false (or $x153))))
(and (not $x920) (or $x920 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 28: function susan_corners, block 1066, name %1067
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x405 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x398 (or false false (or $x405))))
(and (not $x398) (or $x398 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 29: function susan_corners, block 1069, name %1070
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x153 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x920 (or false false (or $x153))))
(and (not $x920) (or $x920 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 30: function susan_corners, block 1549, name %1550
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x476 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x566 (or false false (or $x476))))
(and (not $x566) (or $x566 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 31: function susan_corners, block 1552, name %1553
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x37 (and (distinct (bvadd ((_ sign_extend 1) in.12_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.12_32 (_ bv1 32)))) true)))
(let (($x15 (or false false (or $x37))))
(and (not $x15) (or $x15 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 32: function susan_corners, block 845, name %846
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in839_32 () (_ BitVec 32))
(declare-fun in840_32 () (_ BitVec 32))
(assert
 (let ((?x266 (ite (bvslt in840_32 in839_32) (_ bv1 1) (_ bv0 1))))
(let (($x793 (or false false false)))
(let (($x92 (not $x793)))
(and $x92 (or $x793 (and (distinct ?x266 ?x266) true)))))))
(check-sat)
; query 33: function susan_corners_quick, block 1469, name %1470
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_32 () (_ BitVec 32))
(assert
 (let (($x476 (and (distinct (bvadd ((_ sign_extend 1) in.1_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.1_32 (_ bv1 32)))) true)))
(let (($x566 (or false false (or $x476))))
(and (not $x566) (or $x566 (and (distinct (bvadd in.1_32 (_ bv1 32)) (bvadd in.1_32 (_ bv1 32))) true))))))
(check-sat)
; query 34: function susan_corners_quick, block 1472, name %1473
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.12_32 () (_ BitVec 32))
(assert
 (let (($x37 (and (distinct (bvadd ((_ sign_extend 1) in.12_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.12_32 (_ bv1 32)))) true)))
(let (($x15 (or false false (or $x37))))
(and (not $x15) (or $x15 (and (distinct (bvadd in.12_32 (_ bv1 32)) (bvadd in.12_32 (_ bv1 32))) true))))))
(check-sat)
; query 35: function susan_corners_quick, block 433, name %434
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x405 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x398 (or false false (or $x405))))
(and (not $x398) (or $x398 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 36: function susan_corners_quick, block 436, name %437
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x153 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x920 (or false false (or $x153))))
(and (not $x920) (or $x920 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 37: function susan_edges, block 1432, name %1433
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1417_32 () (_ BitVec 32))
(assert
 (let ((?x175 (ite (bvslt (_ bv0 32) in1417_32) (_ bv1 1) (_ bv0 1))))
(let (($x793 (or false false false)))
(let (($x92 (not $x793)))
(and $x92 (or $x793 (and (distinct ?x175 ?x175) true)))))))
(check-sat)
; query 38: function susan_edges, block 1486, name %1487
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.116_32 () (_ BitVec 32))
(assert
 (let (($x611 (and (distinct (bvadd ((_ sign_extend 1) in.116_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.116_32 (_ bv1 32)))) true)))
(let (($x80 (or false false (or $x611))))
(and (not $x80) (or $x80 (and (distinct (bvadd in.116_32 (_ bv1 32)) (bvadd in.116_32 (_ bv1 32))) true))))))
(check-sat)
; query 39: function susan_edges, block 1489, name %1490
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.114_32 () (_ BitVec 32))
(assert
 (let (($x242 (and (distinct (bvadd ((_ sign_extend 1) in.114_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.114_32 (_ bv1 32)))) true)))
(let (($x387 (or false false (or $x242))))
(and (not $x387) (or $x387 (and (distinct (bvadd in.114_32 (_ bv1 32)) (bvadd in.114_32 (_ bv1 32))) true))))))
(check-sat)
; query 40: function susan_edges, block 379, name %380
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.015_32 () (_ BitVec 32))
(assert
 (let (($x84 (and (distinct (bvadd ((_ sign_extend 1) in.015_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.015_32 (_ bv1 32)))) true)))
(let (($x378 (or false false (or $x84))))
(and (not $x378) (or $x378 (and (distinct (bvadd in.015_32 (_ bv1 32)) (bvadd in.015_32 (_ bv1 32))) true))))))
(check-sat)
; query 41: function susan_edges, block 382, name %383
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.013_32 () (_ BitVec 32))
(assert
 (let (($x583 (and (distinct (bvadd ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.013_32 (_ bv1 32)))) true)))
(let (($x383 (or false false (or $x583))))
(and (not $x383) (or $x383 (and (distinct (bvadd in.013_32 (_ bv1 32)) (bvadd in.013_32 (_ bv1 32))) true))))))
(check-sat)
; query 42: function susan_edges, block 850, name %851
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in834_32 () (_ BitVec 32))
(assert
 (let ((?x615 (ite (= (_ bv0 32) in834_32) (_ bv1 1) (_ bv0 1))))
(let (($x793 (or false false false)))
(let (($x92 (not $x793)))
(and $x92 (or $x793 (and (distinct ?x615 ?x615) true)))))))
(check-sat)
; query 43: function susan_edges, block 870, name %871
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x683 (ite (bvslt (_ bv0 32) in.0_32) (_ bv1 1) (_ bv0 1))))
(let (($x793 (or false false false)))
(let (($x92 (not $x793)))
(and $x92 (or $x793 (and (distinct ?x683 ?x683) true)))))))
(check-sat)
; query 44: function susan_edges_small, block 119, name %120
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.09_32 () (_ BitVec 32))
(assert
 (let (($x573 (and (distinct (bvadd ((_ sign_extend 1) in.09_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.09_32 (_ bv1 32)))) true)))
(let (($x314 (or false false (or $x573))))
(and (not $x314) (or $x314 (and (distinct (bvadd in.09_32 (_ bv1 32)) (bvadd in.09_32 (_ bv1 32))) true))))))
(check-sat)
; query 45: function susan_edges_small, block 122, name %123
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.07_32 () (_ BitVec 32))
(assert
 (let (($x409 (and (distinct (bvadd ((_ sign_extend 1) in.07_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.07_32 (_ bv1 32)))) true)))
(let (($x363 (or false false (or $x409))))
(and (not $x363) (or $x363 (and (distinct (bvadd in.07_32 (_ bv1 32)) (bvadd in.07_32 (_ bv1 32))) true))))))
(check-sat)
; query 46: function susan_edges_small, block 258, name %259
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in243_32 () (_ BitVec 32))
(assert
 (let ((?x305 (ite (= (_ bv0 32) in243_32) (_ bv1 1) (_ bv0 1))))
(let (($x793 (or false false false)))
(let (($x92 (not $x793)))
(and $x92 (or $x793 (and (distinct ?x305 ?x305) true)))))))
(check-sat)
; query 47: function susan_edges_small, block 278, name %279
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x683 (ite (bvslt (_ bv0 32) in.0_32) (_ bv1 1) (_ bv0 1))))
(let (($x793 (or false false false)))
(let (($x92 (not $x793)))
(and $x92 (or $x793 (and (distinct ?x683 ?x683) true)))))))
(check-sat)
; query 48: function susan_edges_small, block 426, name %427
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in411_32 () (_ BitVec 32))
(assert
 (let ((?x233 (ite (bvslt (_ bv0 32) in411_32) (_ bv1 1) (_ bv0 1))))
(let (($x793 (or false false false)))
(let (($x92 (not $x793)))
(and $x92 (or $x793 (and (distinct ?x233 ?x233) true)))))))
(check-sat)
; query 49: function susan_edges_small, block 458, name %459
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.110_32 () (_ BitVec 32))
(assert
 (let (($x438 (and (distinct (bvadd ((_ sign_extend 1) in.110_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.110_32 (_ bv1 32)))) true)))
(let (($x317 (or false false (or $x438))))
(and (not $x317) (or $x317 (and (distinct (bvadd in.110_32 (_ bv1 32)) (bvadd in.110_32 (_ bv1 32))) true))))))
(check-sat)
; query 50: function susan_edges_small, block 461, name %462
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.18_32 () (_ BitVec 32))
(assert
 (let (($x574 (and (distinct (bvadd ((_ sign_extend 1) in.18_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.18_32 (_ bv1 32)))) true)))
(let (($x452 (or false false (or $x574))))
(and (not $x452) (or $x452 (and (distinct (bvadd in.18_32 (_ bv1 32)) (bvadd in.18_32 (_ bv1 32))) true))))))
(check-sat)
; query 51: function susan_principle, block 378, name %379
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x405 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x398 (or false false (or $x405))))
(and (not $x398) (or $x398 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 52: function susan_principle, block 381, name %382
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x153 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x920 (or false false (or $x153))))
(and (not $x920) (or $x920 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 53: function susan_principle_small, block 118, name %119
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x405 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.0_32 (_ bv1 32)))) true)))
(let (($x398 (or false false (or $x405))))
(and (not $x398) (or $x398 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 54: function susan_principle_small, block 121, name %122
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x153 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x920 (or false false (or $x153))))
(and (not $x920) (or $x920 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 55: function susan_smoothing, block 123, name %124
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.09_32 () (_ BitVec 32))
(assert
 (let (($x137 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in.09_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in.09_32))) true)))
(let (($x648 (or false false (or $x137))))
(and (not $x648) (or $x648 (and (distinct (bvsub (_ bv0 32) in.09_32) (bvsub (_ bv0 32) in.09_32)) true))))))
(check-sat)
; query 56: function susan_smoothing, block 143, name %144
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.016_32 () (_ BitVec 32))
(assert
 (let (($x501 (and (distinct (bvadd ((_ sign_extend 1) in.016_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.016_32 (_ bv1 32)))) true)))
(let (($x418 (or false false (or $x501))))
(and (not $x418) (or $x418 (and (distinct (bvadd in.016_32 (_ bv1 32)) (bvadd in.016_32 (_ bv1 32))) true))))))
(check-sat)
; query 57: function susan_smoothing, block 148, name %149
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.017_32 () (_ BitVec 32))
(assert
 (let (($x380 (and (distinct (bvadd ((_ sign_extend 1) in.017_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.017_32 (_ bv1 32)))) true)))
(let (($x844 (or false false (or $x380))))
(and (not $x844) (or $x844 (and (distinct (bvadd in.017_32 (_ bv1 32)) (bvadd in.017_32 (_ bv1 32))) true))))))
(check-sat)
; query 58: function susan_smoothing, block 150, name %151
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.018_32 () (_ BitVec 32))
(assert
 (let (($x933 (and (distinct (bvsub ((_ sign_extend 1) in.018_32) ((_ sign_extend 1) (_ bv10000 32))) ((_ sign_extend 1) (bvsub in.018_32 (_ bv10000 32)))) true)))
(let (($x571 (or false false (or $x933))))
(and (not $x571) (or $x571 (and (distinct (bvsub in.018_32 (_ bv10000 32)) (bvsub in.018_32 (_ bv10000 32))) true))))))
(check-sat)
; query 59: function susan_smoothing, block 150, name %152
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.018_32 () (_ BitVec 32))
(assert
 (let ((?x753 (ite (= (_ bv0 32) (bvsub in.018_32 (_ bv10000 32))) (_ bv1 1) (_ bv0 1))))
(let (($x933 (and (distinct (bvsub ((_ sign_extend 1) in.018_32) ((_ sign_extend 1) (_ bv10000 32))) ((_ sign_extend 1) (bvsub in.018_32 (_ bv10000 32)))) true)))
(let (($x571 (or false false (or $x933))))
(let (($x775 (or $x571 false false)))
(and (not $x775) (or $x775 (and (distinct ?x753 ?x753) true))))))))
(check-sat)
; query 60: function susan_smoothing, block 165, name %166
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.114_32 () (_ BitVec 32))
(assert
 (let (($x242 (and (distinct (bvadd ((_ sign_extend 1) in.114_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.114_32 (_ bv1 32)))) true)))
(let (($x387 (or false false (or $x242))))
(and (not $x387) (or $x387 (and (distinct (bvadd in.114_32 (_ bv1 32)) (bvadd in.114_32 (_ bv1 32))) true))))))
(check-sat)
; query 61: function susan_smoothing, block 168, name %169
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.111_32 () (_ BitVec 32))
(assert
 (let (($x676 (and (distinct (bvadd ((_ sign_extend 1) in.111_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.111_32 (_ bv1 32)))) true)))
(let (($x230 (or false false (or $x676))))
(and (not $x230) (or $x230 (and (distinct (bvadd in.111_32 (_ bv1 32)) (bvadd in.111_32 (_ bv1 32))) true))))))
(check-sat)
; query 62: function susan_smoothing, block 21, name %22
(reset)
; benchmark generated from python API
(set-info :status unknown)
(assert
 (let ((?x644 (ite (= (_ bv0 32) (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x793 (or false false false)))
(let (($x92 (not $x793)))
(and $x92 (or $x793 (and (distinct ?x644 ?x644) true)))))))
(check-sat)
; query 63: function susan_smoothing, block 319, name %320
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.215_32 () (_ BitVec 32))
(assert
 (let (($x783 (and (distinct (bvadd ((_ sign_extend 1) in.215_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.215_32 (_ bv1 32)))) true)))
(let (($x162 (or false false (or $x783))))
(and (not $x162) (or $x162 (and (distinct (bvadd in.215_32 (_ bv1 32)) (bvadd in.215_32 (_ bv1 32))) true))))))
(check-sat)
; query 64: function susan_smoothing, block 322, name %323
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.212_32 () (_ BitVec 32))
(assert
 (let (($x871 (and (distinct (bvadd ((_ sign_extend 1) in.212_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.212_32 (_ bv1 32)))) true)))
(let (($x268 (or false false (or $x871))))
(and (not $x268) (or $x268 (and (distinct (bvadd in.212_32 (_ bv1 32)) (bvadd in.212_32 (_ bv1 32))) true))))))
(check-sat)
; query 65: function susan_smoothing, block 67, name %68
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.09_32 () (_ BitVec 32))
(assert
 (let (($x137 (and (distinct (bvsub ((_ sign_extend 1) (_ bv0 32)) ((_ sign_extend 1) in.09_32)) ((_ sign_extend 1) (bvsub (_ bv0 32) in.09_32))) true)))
(let (($x648 (or false false (or $x137))))
(and (not $x648) (or $x648 (and (distinct (bvsub (_ bv0 32) in.09_32) (bvsub (_ bv0 32) in.09_32)) true))))))
(check-sat)
; query 66: function susan_smoothing, block 83, name %84
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.013_32 () (_ BitVec 32))
(assert
 (let (($x583 (and (distinct (bvadd ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.013_32 (_ bv1 32)))) true)))
(let (($x383 (or false false (or $x583))))
(and (not $x383) (or $x383 (and (distinct (bvadd in.013_32 (_ bv1 32)) (bvadd in.013_32 (_ bv1 32))) true))))))
(check-sat)
; query 67: function susan_smoothing, block 86, name %87
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.010_32 () (_ BitVec 32))
(assert
 (let (($x602 (and (distinct (bvadd ((_ sign_extend 1) in.010_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.010_32 (_ bv1 32)))) true)))
(let (($x926 (or false false (or $x602))))
(and (not $x926) (or $x926 (and (distinct (bvadd in.010_32 (_ bv1 32)) (bvadd in.010_32 (_ bv1 32))) true))))))
(check-sat)
; query 68: function susan_thin, block 100, name %101
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in93_32 () (_ BitVec 32))
(assert
 (let ((?x345 (ite (= (_ bv1 32) in93_32) (_ bv1 1) (_ bv0 1))))
(let (($x793 (or false false false)))
(let (($x92 (not $x793)))
(and $x92 (or $x793 (and (distinct ?x345 ?x345) true)))))))
(check-sat)
; query 69: function susan_thin, block 428, name %429
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.022_32 () (_ BitVec 32))
(assert
 (let (($x785 (and (distinct (bvadd ((_ sign_extend 1) in.022_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.022_32 (_ bv1 32)))) true)))
(let (($x1026 (or false false (or $x785))))
(and (not $x1026) (or $x1026 (and (distinct (bvadd in.022_32 (_ bv1 32)) (bvadd in.022_32 (_ bv1 32))) true))))))
(check-sat)
; query 70: function susan_thin, block 431, name %432
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.018_32 () (_ BitVec 32))
(assert
 (let (($x953 (and (distinct (bvadd ((_ sign_extend 1) in.018_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.018_32 (_ bv1 32)))) true)))
(let (($x274 (or false false (or $x953))))
(and (not $x274) (or $x274 (and (distinct (bvadd in.018_32 (_ bv1 32)) (bvadd in.018_32 (_ bv1 32))) true))))))
(check-sat)
; query 71: function susan_thin, block 433, name %434
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.040_32 () (_ BitVec 32))
(assert
 (let ((?x302 (ite (bvslt (_ bv0 32) in.040_32) (_ bv1 1) (_ bv0 1))))
(let (($x793 (or false false false)))
(let (($x92 (not $x793)))
(and $x92 (or $x793 (and (distinct ?x302 ?x302) true)))))))
(check-sat)
; query 72: function susan_thin, block 469, name %470
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.235_32 () (_ BitVec 32))
(assert
 (let ((?x280 (bvadd in.235_32 in.235_32)))
(let ((?x767 ((_ sign_extend 1) ?x280)))
(let (($x304 (and (distinct (bvadd ((_ sign_extend 1) in.235_32) ((_ sign_extend 1) in.235_32)) ?x767) true)))
(let (($x466 (or false false (or $x304))))
(and (not $x466) (or $x466 (and (distinct ?x280 ?x280) true))))))))
(check-sat)
; query 73: function susan_thin, block 469, name %471
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.228_32 () (_ BitVec 32))
(declare-fun in.235_32 () (_ BitVec 32))
(assert
 (let ((?x280 (bvadd in.235_32 in.235_32)))
(let ((?x312 (bvadd ?x280 in.228_32)))
(let (($x673 (and (distinct (bvadd ((_ sign_extend 1) ?x280) ((_ sign_extend 1) in.228_32)) ((_ sign_extend 1) ?x312)) true)))
(let ((?x767 ((_ sign_extend 1) ?x280)))
(let (($x304 (and (distinct (bvadd ((_ sign_extend 1) in.235_32) ((_ sign_extend 1) in.235_32)) ?x767) true)))
(let (($x466 (or false false (or $x304))))
(let (($x347 (or $x466 false (or $x673))))
(and (not $x347) (or $x347 (and (distinct ?x312 ?x312) true)))))))))))
(check-sat)
; query 74: function susan_thin, block 469, name %472
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.228_32 () (_ BitVec 32))
(declare-fun in.235_32 () (_ BitVec 32))
(assert
 (let ((?x787 (ite (bvsgt (_ bv3 32) (bvadd (bvadd in.235_32 in.235_32) in.228_32)) (_ bv1 1) (_ bv0 1))))
(let ((?x568 ((_ sign_extend 1) in.228_32)))
(let ((?x280 (bvadd in.235_32 in.235_32)))
(let ((?x767 ((_ sign_extend 1) ?x280)))
(let (($x890 (or (and (distinct (bvadd ?x767 ?x568) ((_ sign_extend 1) (bvadd ?x280 in.228_32))) true))))
(let (($x304 (and (distinct (bvadd ((_ sign_extend 1) in.235_32) ((_ sign_extend 1) in.235_32)) ?x767) true)))
(let (($x466 (or false false (or $x304))))
(let (($x347 (or $x466 false $x890)))
(let (($x172 (or $x347 false false)))
(and (not $x172) (or $x172 (and (distinct ?x787 ?x787) true)))))))))))))
(check-sat)
; query 75: function susan_thin, block 473, name %474
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.235_32 () (_ BitVec 32))
(assert
 (let ((?x258 (bvsub in.235_32 (_ bv1 32))))
(let ((?x692 ((_ sign_extend 1) ?x258)))
(let (($x870 (or (and (distinct (bvsub ((_ sign_extend 1) in.235_32) ((_ sign_extend 1) (_ bv1 32))) ?x692) true))))
(let (($x350 (or false false $x870)))
(and (not $x350) (or $x350 (and (distinct ?x258 ?x258) true))))))))
(check-sat)
; query 76: function susan_thin, block 473, name %475
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.235_32 () (_ BitVec 32))
(declare-fun in.14_32 () (_ BitVec 32))
(assert
 (let ((?x258 (bvsub in.235_32 (_ bv1 32))))
(let ((?x193 (bvadd in.14_32 ?x258)))
(let (($x585 (and (distinct (bvadd ((_ sign_extend 1) in.14_32) ((_ sign_extend 1) ?x258)) ((_ sign_extend 1) ?x193)) true)))
(let ((?x692 ((_ sign_extend 1) ?x258)))
(let (($x870 (or (and (distinct (bvsub ((_ sign_extend 1) in.235_32) ((_ sign_extend 1) (_ bv1 32))) ?x692) true))))
(let (($x350 (or false false $x870)))
(let (($x1015 (or false $x350 (or $x585))))
(and (not $x1015) (or $x1015 (and (distinct ?x193 ?x193) true)))))))))))
(check-sat)
; query 77: function susan_thin, block 473, name %476
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.228_32 () (_ BitVec 32))
(assert
 (let ((?x991 (bvsub in.228_32 (_ bv2 32))))
(let ((?x761 ((_ sign_extend 1) ?x991)))
(let (($x523 (or (and (distinct (bvsub ((_ sign_extend 1) in.228_32) ((_ sign_extend 1) (_ bv2 32))) ?x761) true))))
(let (($x191 (or false false $x523)))
(and (not $x191) (or $x191 (and (distinct ?x991 ?x991) true))))))))
(check-sat)
; query 78: function susan_thin, block 473, name %477
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.228_32 () (_ BitVec 32))
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x991 (bvsub in.228_32 (_ bv2 32))))
(let ((?x912 (bvadd in.0_32 ?x991)))
(let (($x510 (and (distinct (bvadd ((_ sign_extend 1) in.0_32) ((_ sign_extend 1) ?x991)) ((_ sign_extend 1) ?x912)) true)))
(let ((?x761 ((_ sign_extend 1) ?x991)))
(let (($x523 (or (and (distinct (bvsub ((_ sign_extend 1) in.228_32) ((_ sign_extend 1) (_ bv2 32))) ?x761) true))))
(let (($x191 (or false false $x523)))
(let (($x975 (or false $x191 (or $x510))))
(and (not $x975) (or $x975 (and (distinct ?x912 ?x912) true)))))))))))
(check-sat)
; query 79: function susan_thin, block 473, name %478
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.235_32 () (_ BitVec 32))
(declare-fun in.14_32 () (_ BitVec 32))
(assert
 (let ((?x415 (ite (bvsgt (_ bv4 32) (bvadd in.14_32 (bvsub in.235_32 (_ bv1 32)))) (_ bv1 1) (_ bv0 1))))
(let (($x585 (and (distinct (bvadd ((_ sign_extend 1) in.14_32) ((_ sign_extend 1) (bvsub in.235_32 (_ bv1 32)))) ((_ sign_extend 1) (bvadd in.14_32 (bvsub in.235_32 (_ bv1 32))))) true)))
(let ((?x258 (bvsub in.235_32 (_ bv1 32))))
(let ((?x692 ((_ sign_extend 1) ?x258)))
(let (($x870 (or (and (distinct (bvsub ((_ sign_extend 1) in.235_32) ((_ sign_extend 1) (_ bv1 32))) ?x692) true))))
(let (($x350 (or false false $x870)))
(let (($x1015 (or false $x350 (or $x585))))
(let (($x522 (or $x1015 false false)))
(and (not $x522) (or $x522 (and (distinct ?x415 ?x415) true))))))))))))
(check-sat)
; query 80: function susan_thin, block 533, name %534
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in528_32 () (_ BitVec 32))
(declare-fun in498_32 () (_ BitVec 32))
(assert
 (let (($x793 (or false false false)))
(let (($x998 (or $x793 (and (distinct (bvor in498_32 in528_32) (bvor in498_32 in528_32)) true))))
(let (($x92 (not $x793)))
(and $x92 $x998)))))
(check-sat)
; query 81: function susan_thin, block 533, name %535
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in518_32 () (_ BitVec 32))
(declare-fun in508_32 () (_ BitVec 32))
(assert
 (let (($x793 (or false false false)))
(let (($x817 (or $x793 (and (distinct (bvor in508_32 in518_32) (bvor in508_32 in518_32)) true))))
(let (($x92 (not $x793)))
(and $x92 $x817)))))
(check-sat)
; query 82: function susan_thin, block 533, name %536
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in518_32 () (_ BitVec 32))
(declare-fun in508_32 () (_ BitVec 32))
(declare-fun in528_32 () (_ BitVec 32))
(declare-fun in498_32 () (_ BitVec 32))
(assert
 (let ((?x468 (bvor in508_32 in518_32)))
(let ((?x593 (bvor in498_32 in528_32)))
(let ((?x463 (bvand ?x593 ?x468)))
(let (($x793 (or false false false)))
(let (($x915 (or $x793 $x793 false)))
(let (($x315 (not $x915)))
(and $x315 (or $x915 (and (distinct ?x463 ?x463) true))))))))))
(check-sat)
; query 83: function susan_thin, block 533, name %537
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in518_32 () (_ BitVec 32))
(declare-fun in508_32 () (_ BitVec 32))
(declare-fun in528_32 () (_ BitVec 32))
(declare-fun in498_32 () (_ BitVec 32))
(assert
 (let ((?x468 (bvor in508_32 in518_32)))
(let ((?x593 (bvor in498_32 in528_32)))
(let ((?x463 (bvand ?x593 ?x468)))
(let ((?x500 (ite (and (distinct (_ bv0 32) ?x463) true) (_ bv1 1) (_ bv0 1))))
(let (($x793 (or false false false)))
(let (($x915 (or $x793 $x793 false)))
(let (($x58 (or $x915 false false)))
(let (($x344 (not $x58)))
(and $x344 (or $x58 (and (distinct ?x500 ?x500) true))))))))))))
(check-sat)
; query 84: function susan_thin, block 538, name %539
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in498_32 () (_ BitVec 32))
(assert
 (let ((?x247 (ite (and (distinct (_ bv0 32) in498_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x793 (or false false false)))
(let (($x92 (not $x793)))
(and $x92 (or $x793 (and (distinct ?x247 ?x247) true)))))))
(check-sat)
; query 85: function susan_thin, block 540, name %541
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in508_32 () (_ BitVec 32))
(assert
 (let ((?x229 (ite (and (distinct (_ bv0 32) in508_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x793 (or false false false)))
(let (($x92 (not $x793)))
(and $x92 (or $x793 (and (distinct ?x229 ?x229) true)))))))
(check-sat)
; query 86: function susan_thin, block 545, name %546
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in508_32 () (_ BitVec 32))
(assert
 (let ((?x229 (ite (and (distinct (_ bv0 32) in508_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x793 (or false false false)))
(let (($x92 (not $x793)))
(and $x92 (or $x793 (and (distinct ?x229 ?x229) true)))))))
(check-sat)
; query 87: function susan_thin, block 563, name %564
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.325_32 () (_ BitVec 32))
(assert
 (let ((?x125 (ite (= (_ bv0 32) in.325_32) (_ bv1 1) (_ bv0 1))))
(let (($x793 (or false false false)))
(let (($x92 (not $x793)))
(and $x92 (or $x793 (and (distinct ?x125 ?x125) true)))))))
(check-sat)
; query 88: function susan_thin, block 597, name %598
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.321_32 () (_ BitVec 32))
(assert
 (let ((?x734 (ite (= (_ bv0 32) in.321_32) (_ bv1 1) (_ bv0 1))))
(let (($x793 (or false false false)))
(let (($x92 (not $x793)))
(and $x92 (or $x793 (and (distinct ?x734 ?x734) true)))))))
(check-sat)
; query 89: function susan_thin, block 685, name %686
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in662_32 () (_ BitVec 32))
(declare-fun in680_32 () (_ BitVec 32))
(assert
 (let (($x793 (or false false false)))
(let (($x716 (or $x793 (and (distinct (bvor in680_32 in662_32) (bvor in680_32 in662_32)) true))))
(let (($x92 (not $x793)))
(and $x92 $x716)))))
(check-sat)
; query 90: function susan_thin, block 685, name %687
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in671_32 () (_ BitVec 32))
(declare-fun in653_32 () (_ BitVec 32))
(assert
 (let (($x793 (or false false false)))
(let (($x735 (or $x793 (and (distinct (bvor in653_32 in671_32) (bvor in653_32 in671_32)) true))))
(let (($x92 (not $x793)))
(and $x92 $x735)))))
(check-sat)
; query 91: function susan_thin, block 685, name %688
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in671_32 () (_ BitVec 32))
(declare-fun in653_32 () (_ BitVec 32))
(declare-fun in662_32 () (_ BitVec 32))
(declare-fun in680_32 () (_ BitVec 32))
(assert
 (let ((?x451 (bvor in653_32 in671_32)))
(let ((?x643 (bvor in680_32 in662_32)))
(let ((?x291 (bvand ?x643 ?x451)))
(let (($x793 (or false false false)))
(let (($x915 (or $x793 $x793 false)))
(let (($x315 (not $x915)))
(and $x315 (or $x915 (and (distinct ?x291 ?x291) true))))))))))
(check-sat)
; query 92: function susan_thin, block 685, name %689
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in671_32 () (_ BitVec 32))
(declare-fun in653_32 () (_ BitVec 32))
(declare-fun in662_32 () (_ BitVec 32))
(declare-fun in680_32 () (_ BitVec 32))
(assert
 (let ((?x451 (bvor in653_32 in671_32)))
(let ((?x643 (bvor in680_32 in662_32)))
(let ((?x291 (bvand ?x643 ?x451)))
(let ((?x372 (ite (and (distinct (_ bv0 32) ?x291) true) (_ bv1 1) (_ bv0 1))))
(let (($x793 (or false false false)))
(let (($x915 (or $x793 $x793 false)))
(let (($x58 (or $x915 false false)))
(let (($x344 (not $x58)))
(and $x344 (or $x58 (and (distinct ?x372 ?x372) true))))))))))))
(check-sat)
; query 93: function susan_thin, block 915, name %916
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.13_32 () (_ BitVec 32))
(assert
 (let (($x161 (and (distinct (bvadd ((_ sign_extend 1) in.13_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.13_32 (_ bv1 32)))) true)))
(let (($x342 (or false false (or $x161))))
(and (not $x342) (or $x342 (and (distinct (bvadd in.13_32 (_ bv1 32)) (bvadd in.13_32 (_ bv1 32))) true))))))
(check-sat)
; query 94: function susan_thin, block 918, name %919
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.14_32 () (_ BitVec 32))
(assert
 (let (($x167 (and (distinct (bvadd ((_ sign_extend 1) in.14_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.14_32 (_ bv1 32)))) true)))
(let (($x96 (or false false (or $x167))))
(and (not $x96) (or $x96 (and (distinct (bvadd in.14_32 (_ bv1 32)) (bvadd in.14_32 (_ bv1 32))) true))))))
(check-sat)
