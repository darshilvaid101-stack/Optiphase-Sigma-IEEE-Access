; OptiPhase-Sigma refinement certificate for sweep K46-R1-005
; query 0: function main, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x86 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x167 (or false false false)))
(and (not $x167) (or $x167 (and (distinct ?x86 ?x86) true))))))
(check-sat)
