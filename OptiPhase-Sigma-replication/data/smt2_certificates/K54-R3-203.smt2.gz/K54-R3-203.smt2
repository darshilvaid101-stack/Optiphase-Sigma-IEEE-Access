; OptiPhase-Sigma refinement certificate for sweep K54-R3-203
; query 0: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x592 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x135 (or false false false)))
(and (not $x135) (or $x135 (and (distinct ?x592 ?x592) true))))))
(check-sat)
