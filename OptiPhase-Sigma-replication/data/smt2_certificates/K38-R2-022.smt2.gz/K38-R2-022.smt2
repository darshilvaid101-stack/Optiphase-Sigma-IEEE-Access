; OptiPhase-Sigma refinement certificate for sweep K38-R2-022
; query 0: function BF_cbc_encrypt, block 126, name %127
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.010_64 () (_ BitVec 64))
(assert
 (let (($x668 (and (distinct (bvsub ((_ sign_extend 1) in.010_64) ((_ sign_extend 1) (_ bv8 64))) ((_ sign_extend 1) (bvsub in.010_64 (_ bv8 64)))) true)))
(let (($x107 (or false false (or $x668))))
(and (not $x107) (or $x107 (and (distinct (bvsub in.010_64 (_ bv8 64)) (bvsub in.010_64 (_ bv8 64))) true))))))
(check-sat)
; query 1: function BF_cbc_encrypt, block 128, name %129
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.010_64 () (_ BitVec 64))
(assert
 (let ((?x69 (ite (and (distinct (_ bv18446744073709551608 64) in.010_64) true) (_ bv1 1) (_ bv0 1))))
(let (($x62 (or false false false)))
(let (($x70 (not $x62)))
(and $x70 (or $x62 (and (distinct ?x69 ?x69) true)))))))
(check-sat)
; query 2: function BF_cfb64_encrypt, block 15, name %16
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.07_32 () (_ BitVec 32))
(assert
 (let ((?x275 (ite (= (_ bv0 32) in.07_32) (_ bv1 1) (_ bv0 1))))
(let (($x62 (or false false false)))
(let (($x70 (not $x62)))
(and $x70 (or $x62 (and (distinct ?x275 ?x275) true)))))))
(check-sat)
; query 3: function BF_set_key, block 51, name %52
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.02_32 () (_ BitVec 32))
(assert
 (let (($x43 (and (distinct (bvadd ((_ sign_extend 1) in.02_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.02_32 (_ bv1 32)))) true)))
(let (($x30 (or false false (or $x43))))
(and (not $x30) (or $x30 (and (distinct (bvadd in.02_32 (_ bv1 32)) (bvadd in.02_32 (_ bv1 32))) true))))))
(check-sat)
; query 4: function BF_set_key, block 69, name %70
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.13_32 () (_ BitVec 32))
(assert
 (let (($x5 (and (distinct (bvadd ((_ sign_extend 1) in.13_32) ((_ sign_extend 1) (_ bv2 32))) ((_ sign_extend 1) (bvadd in.13_32 (_ bv2 32)))) true)))
(let (($x13 (or false false (or $x5))))
(and (not $x13) (or $x13 (and (distinct (bvadd in.13_32 (_ bv2 32)) (bvadd in.13_32 (_ bv2 32))) true))))))
(check-sat)
; query 5: function BF_set_key, block 87, name %88
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.24_32 () (_ BitVec 32))
(assert
 (let (($x17 (and (distinct (bvadd ((_ sign_extend 1) in.24_32) ((_ sign_extend 1) (_ bv2 32))) ((_ sign_extend 1) (bvadd in.24_32 (_ bv2 32)))) true)))
(let (($x65 (or false false (or $x17))))
(and (not $x65) (or $x65 (and (distinct (bvadd in.24_32 (_ bv2 32)) (bvadd in.24_32 (_ bv2 32))) true))))))
(check-sat)
; query 6: function main, block 60, name %61
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x178 (or false false)))
(and (not $x178) (or $x178 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 7: function main, block 60, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x663 (ite (bvsge (_ bv57 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x178 (or false false)))
(let (($x40 (or $x178 false false)))
(let (($x19 (not $x40)))
(and $x19 (or $x40 (and (distinct ?x663 ?x663) true))))))))
(check-sat)
; query 8: function main, block 63, name %64
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x62 (or false false false)))
(and (not (or $x62 (bvuge (_ bv4 32) (_ bv32 32)))) (or $x62 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvmul in.01_32 (_ bv16 32))) true)))))
(check-sat)
; query 9: function main, block 63, name %65
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x178 (or false false)))
(and (not $x178) (or $x178 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 10: function main, block 63, name %66
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x109 (bvmul in.01_32 (_ bv16 32))))
(let ((?x146 (bvadd ?x109 (_ bv4294967248 32))))
(let ((?x547 ((_ sign_extend 24) in57_8)))
(let ((?x550 (bvshl in.01_32 (_ bv4 32))))
(let ((?x103 (bvadd ?x550 ?x547)))
(let (($x62 (or false false false)))
(let (($x306 (or $x62 false false)))
(let ((?x56 ((_ sign_extend 1) ?x103)))
(let (($x178 (or false false)))
(let (($x119 (or $x62 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x9 (or $x119 $x178 (or (and (distinct (bvadd ((_ sign_extend 1) ?x550) ((_ sign_extend 1) ?x547)) ?x56) true)))))
(let (($x93 (not $x9)))
(and $x93 (or $x306 (and (distinct ?x103 ?x146) true))))))))))))))))
(check-sat)
; query 11: function main, block 63, name %67
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x547 ((_ sign_extend 24) in57_8)))
(let ((?x550 (bvshl in.01_32 (_ bv4 32))))
(let ((?x103 (bvadd ?x550 ?x547)))
(let ((?x112 (bvsub ?x103 (_ bv48 32))))
(let (($x178 (or false false)))
(let (($x62 (or false false false)))
(let (($x306 (or $x62 false false)))
(let (($x21 (or $x306 $x178 false)))
(let (($x83 (or $x21 (and (distinct ?x112 (bvadd (bvadd (bvmul in.01_32 (_ bv16 32)) (_ bv4294967248 32)) ?x547)) true))))
(let (($x10 (and (distinct (bvsub ((_ sign_extend 1) ?x103) ((_ sign_extend 1) (_ bv48 32))) ((_ sign_extend 1) ?x112)) true)))
(let ((?x56 ((_ sign_extend 1) ?x103)))
(let (($x119 (or $x62 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x9 (or $x119 $x178 (or (and (distinct (bvadd ((_ sign_extend 1) ?x550) ((_ sign_extend 1) ?x547)) ?x56) true)))))
(and (not (or $x9 false (or $x10))) $x83)))))))))))))))
(check-sat)
; query 12: function main, block 68, name %69
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x178 (or false false)))
(and (not $x178) (or $x178 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 13: function main, block 68, name %70
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x116 (ite (bvsle (_ bv65 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x178 (or false false)))
(let (($x40 (or $x178 false false)))
(let (($x19 (not $x40)))
(and $x19 (or $x40 (and (distinct ?x116 ?x116) true))))))))
(check-sat)
; query 14: function main, block 71, name %72
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x178 (or false false)))
(and (not $x178) (or $x178 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 15: function main, block 71, name %73
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x646 (ite (bvsge (_ bv70 32) ((_ sign_extend 24) in57_8)) (_ bv1 1) (_ bv0 1))))
(let (($x178 (or false false)))
(let (($x40 (or $x178 false false)))
(let (($x19 (not $x40)))
(and $x19 (or $x40 (and (distinct ?x646 ?x646) true))))))))
(check-sat)
; query 16: function main, block 74, name %75
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x62 (or false false false)))
(and (not (or $x62 (bvuge (_ bv4 32) (_ bv32 32)))) (or $x62 (and (distinct (bvshl in.01_32 (_ bv4 32)) (bvmul in.01_32 (_ bv16 32))) true)))))
(check-sat)
; query 17: function main, block 74, name %76
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let (($x178 (or false false)))
(and (not $x178) (or $x178 (and (distinct ((_ sign_extend 24) in57_8) ((_ sign_extend 24) in57_8)) true)))))
(check-sat)
; query 18: function main, block 74, name %77
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(declare-fun in57_8 () (_ BitVec 8))
(assert
 (let ((?x109 (bvmul in.01_32 (_ bv16 32))))
(let ((?x185 (bvadd ?x109 (_ bv4294967241 32))))
(let ((?x547 ((_ sign_extend 24) in57_8)))
(let ((?x550 (bvshl in.01_32 (_ bv4 32))))
(let ((?x103 (bvadd ?x550 ?x547)))
(let (($x62 (or false false false)))
(let (($x306 (or $x62 false false)))
(let ((?x56 ((_ sign_extend 1) ?x103)))
(let (($x178 (or false false)))
(let (($x119 (or $x62 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x9 (or $x119 $x178 (or (and (distinct (bvadd ((_ sign_extend 1) ?x550) ((_ sign_extend 1) ?x547)) ?x56) true)))))
(let (($x93 (not $x9)))
(and $x93 (or $x306 (and (distinct ?x103 ?x185) true))))))))))))))))
(check-sat)
; query 19: function main, block 74, name %78
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in57_8 () (_ BitVec 8))
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x547 ((_ sign_extend 24) in57_8)))
(let ((?x550 (bvshl in.01_32 (_ bv4 32))))
(let ((?x103 (bvadd ?x550 ?x547)))
(let ((?x656 (bvsub ?x103 (_ bv65 32))))
(let (($x178 (or false false)))
(let (($x62 (or false false false)))
(let (($x306 (or $x62 false false)))
(let (($x21 (or $x306 $x178 false)))
(let (($x494 (or $x21 (and (distinct ?x656 (bvadd (bvadd (bvmul in.01_32 (_ bv16 32)) (_ bv4294967241 32)) ?x547)) true))))
(let (($x506 (and (distinct (bvsub ((_ sign_extend 1) ?x103) ((_ sign_extend 1) (_ bv65 32))) ((_ sign_extend 1) ?x656)) true)))
(let ((?x56 ((_ sign_extend 1) ?x103)))
(let (($x119 (or $x62 (bvuge (_ bv4 32) (_ bv32 32)))))
(let (($x9 (or $x119 $x178 (or (and (distinct (bvadd ((_ sign_extend 1) ?x550) ((_ sign_extend 1) ?x547)) ?x56) true)))))
(and (not (or $x9 false (or $x506))) $x494)))))))))))))))
(check-sat)
