; OptiPhase-Sigma refinement certificate for sweep K45-R4-334
; query 0: function NumberOfBitsNeeded, block entry, name %2
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x32 (ite (bvult in0_32 (_ bv2 32)) (_ bv1 1) (_ bv0 1))))
(let (($x144 (or false false false)))
(let (($x7 (not $x144)))
(and $x7 (or $x144 (and (distinct ?x32 ?x32) true)))))))
(check-sat)
; query 1: function main, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x124 (ite (bvsgt (_ bv3 32) in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x144 (or false false false)))
(let (($x7 (not $x144)))
(and $x7 (or $x144 (and (distinct ?x124 ?x124) true)))))))
(check-sat)
