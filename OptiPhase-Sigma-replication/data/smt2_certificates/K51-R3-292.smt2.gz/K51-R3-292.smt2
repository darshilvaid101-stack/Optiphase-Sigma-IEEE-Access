; OptiPhase-Sigma refinement certificate for sweep K51-R3-292
; query 0: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x1374 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x96 (or false false false)))
(let (($x1446 (not $x96)))
(and $x1446 (or $x96 (and (distinct ?x1374 ?x1374) true)))))))
(check-sat)
; query 1: function set1d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x81 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x96 (or false false false)))
(let (($x1446 (not $x96)))
(and $x1446 (or $x96 (and (distinct ?x81 ?x81) true)))))))
(check-sat)
; query 2: function set1ds, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x1923 (ite (= (_ bv4294967295 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x96 (or false false false)))
(let (($x1446 (not $x96)))
(and $x1446 (or $x96 (and (distinct ?x1923 ?x1923) true)))))))
(check-sat)
; query 3: function set2d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x81 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x96 (or false false false)))
(let (($x1446 (not $x96)))
(and $x1446 (or $x96 (and (distinct ?x81 ?x81) true)))))))
(check-sat)
