; OptiPhase-Sigma refinement certificate for sweep K28-R1-003
