; OptiPhase-Sigma refinement certificate for sweep K58-R3-121
; query 0: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x169 (or false false false)))
(let (($x382 (not $x169)))
(and $x382 (or $x169 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x623 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x169 (or false false false)))
(let (($x382 (not $x169)))
(and $x382 (or $x169 (and (distinct ?x623 ?x623) true)))))))
(check-sat)
; query 2: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x664 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x169 (or false false false)))
(let (($x382 (not $x169)))
(and $x382 (or $x169 (and (distinct ?x664 ?x664) true)))))))
(check-sat)
; query 3: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x169 (or false false false)))
(let (($x382 (not $x169)))
(and $x382 (or $x169 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 4: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x83 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x379 (or false false (or $x83))))
(and (not $x379) (or $x379 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 5: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x124 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x169 (or false false false)))
(let (($x382 (not $x169)))
(and $x382 (or $x169 (and (distinct ?x124 ?x124) true)))))))
(check-sat)
; query 6: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x18 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x169 (or false false false)))
(let (($x382 (not $x169)))
(and $x382 (or $x169 (and (distinct ?x18 ?x18) true)))))))
(check-sat)
; query 7: function matrix_add_const, block 19, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let (($x169 (or false false false)))
(let (($x382 (not $x169)))
(and $x382 (or $x169 (and (distinct (bvadd in.0_32 (_ bv1 32)) (bvadd in.0_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function matrix_add_const, block 22, name %23
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x169 (or false false false)))
(let (($x382 (not $x169)))
(and $x382 (or $x169 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 9: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x1967 (or false false)))
(and (not $x1967) (or $x1967 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true)))))
(check-sat)
; query 10: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x1052 ((_ sign_extend 16) in.1_16)))
(let ((?x560 (bvadd ?x1052 (_ bv10 32))))
(let (($x224 (and (distinct (bvadd ((_ sign_extend 1) ?x1052) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x560)) true)))
(let (($x1967 (or false false)))
(let (($x905 (or $x1967 false (or $x224))))
(and (not $x905) (or $x905 (and (distinct ?x560 ?x560) true)))))))))
(check-sat)
; query 11: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x1052 ((_ sign_extend 16) in.1_16)))
(let ((?x560 (bvadd ?x1052 (_ bv10 32))))
(let ((?x113 ((_ extract 15 0) ?x560)))
(let (($x224 (and (distinct (bvadd ((_ sign_extend 1) ?x1052) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x560)) true)))
(let (($x1967 (or false false)))
(let (($x905 (or $x1967 false (or $x224))))
(let (($x235 (or $x905 false)))
(and (not $x235) (or $x235 (and (distinct ?x113 ?x113) true)))))))))))
(check-sat)
; query 12: function run_crc_loop, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x169 (or false false false)))
(let (($x382 (not $x169)))
(and $x382 (or $x169 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
