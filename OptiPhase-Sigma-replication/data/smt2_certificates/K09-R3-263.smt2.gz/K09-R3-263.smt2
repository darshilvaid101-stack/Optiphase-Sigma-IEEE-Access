; OptiPhase-Sigma refinement certificate for sweep K09-R3-263
