; OptiPhase-Sigma refinement certificate for sweep K46-R6-055
; query 0: function adpcm_decoder, block 61, name %62
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.013_32 () (_ BitVec 32))
(declare-fun in.210_32 () (_ BitVec 32))
(assert
 (let ((?x848 (bvadd in.210_32 in.013_32)))
(let ((?x1754 (bvsub in.013_32 in.210_32)))
(let (($x253 (and (distinct (bvadd ((_ sign_extend 1) in.210_32) ((_ sign_extend 1) in.013_32)) ((_ sign_extend 1) ?x848)) true)))
(let (($x515 (and (distinct (bvsub ((_ sign_extend 1) in.013_32) ((_ sign_extend 1) in.210_32)) ((_ sign_extend 1) ?x1754)) true)))
(and (not (or false false (or $x515))) (or (or false false (or $x253)) (and (distinct ?x1754 ?x848) true))))))))
(check-sat)
; query 1: function main, block 5, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x10 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x274 (or false false false)))
(and (not $x274) (or $x274 (and (distinct ?x10 ?x10) true))))))
(check-sat)
