; OptiPhase-Sigma refinement certificate for sweep K50-R3-305
; query 0: function min, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let ((?x6 (ite (bvslt in0_32 in1_32) (_ bv1 1) (_ bv0 1))))
(let (($x87 (or false false false)))
(let (($x99 (not $x87)))
(and $x99 (or $x87 (and (distinct ?x6 ?x6) true)))))))
(check-sat)
; query 1: function s115, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x46 (and (distinct (bvadd ((_ sign_extend 1) in.01_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.01_32 (_ bv1 32)))) true)))
(let (($x609 (or false false (or $x46))))
(and (not $x609) (or $x609 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 2: function set1d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x135 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x87 (or false false false)))
(let (($x99 (not $x87)))
(and $x99 (or $x87 (and (distinct ?x135 ?x135) true)))))))
(check-sat)
; query 3: function set1ds, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in3_32 () (_ BitVec 32))
(assert
 (let ((?x953 (ite (= (_ bv4294967295 32) in3_32) (_ bv1 1) (_ bv0 1))))
(let (($x87 (or false false false)))
(let (($x99 (not $x87)))
(and $x99 (or $x87 (and (distinct ?x953 ?x953) true)))))))
(check-sat)
; query 4: function set2d, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x135 (ite (= (_ bv4294967295 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x87 (or false false false)))
(let (($x99 (not $x87)))
(and $x99 (or $x87 (and (distinct ?x135 ?x135) true)))))))
(check-sat)
