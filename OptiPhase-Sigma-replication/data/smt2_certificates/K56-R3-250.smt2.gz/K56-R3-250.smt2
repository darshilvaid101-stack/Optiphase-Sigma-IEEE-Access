; OptiPhase-Sigma refinement certificate for sweep K56-R3-250
; query 0: function core_init_matrix, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let (($x22 (or false false false)))
(let (($x382 (not $x22)))
(and $x382 (or $x22 (and (distinct (bvadd in.01_32 (_ bv1 32)) (bvadd in.01_32 (_ bv1 32))) true))))))
(check-sat)
; query 1: function core_init_matrix, block 10, name %12
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x2764 (bvadd in.01_32 (_ bv1 32))))
(let ((?x139 (bvmul ?x2764 ?x2764)))
(let (($x22 (or false false false)))
(let (($x76 (or $x22 $x22 false)))
(and (not $x76) (or $x76 (and (distinct ?x139 ?x139) true))))))))
(check-sat)
; query 2: function core_init_matrix, block 10, name %13
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x2764 (bvadd in.01_32 (_ bv1 32))))
(let ((?x139 (bvmul ?x2764 ?x2764)))
(let ((?x3177 (bvmul ?x139 (_ bv2 32))))
(let (($x22 (or false false false)))
(let (($x76 (or $x22 $x22 false)))
(let (($x105 (or $x76 false false)))
(and (not $x105) (or $x105 (and (distinct ?x3177 ?x3177) true))))))))))
(check-sat)
; query 3: function core_init_matrix, block 10, name %14
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.01_32 () (_ BitVec 32))
(assert
 (let ((?x2764 (bvadd in.01_32 (_ bv1 32))))
(let ((?x139 (bvmul ?x2764 ?x2764)))
(let ((?x3177 (bvmul ?x139 (_ bv2 32))))
(let ((?x507 (bvmul ?x3177 (_ bv4 32))))
(let (($x22 (or false false false)))
(let (($x76 (or $x22 $x22 false)))
(let (($x105 (or $x76 false false)))
(let (($x384 (or $x105 false false)))
(and (not $x384) (or $x384 (and (distinct ?x507 ?x507) true))))))))))))
(check-sat)
; query 4: function core_init_matrix, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in2_32 () (_ BitVec 32))
(assert
 (let ((?x324 (ite (= (_ bv0 32) in2_32) (_ bv1 1) (_ bv0 1))))
(let (($x22 (or false false false)))
(let (($x382 (not $x22)))
(and $x382 (or $x22 (and (distinct ?x324 ?x324) true)))))))
(check-sat)
; query 5: function core_init_state, block 9, name %10
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.04_32 () (_ BitVec 32))
(assert
 (let ((?x434 (ite (bvugt in.04_32 (_ bv0 32)) (_ bv1 1) (_ bv0 1))))
(let (($x22 (or false false false)))
(let (($x382 (not $x22)))
(and $x382 (or $x22 (and (distinct ?x434 ?x434) true)))))))
(check-sat)
; query 6: function core_init_state, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(assert
 (let (($x22 (or false false false)))
(let (($x382 (not $x22)))
(and $x382 (or $x22 (and (distinct (bvadd in0_32 (_ bv4294967295 32)) (bvadd in0_32 (_ bv4294967295 32))) true))))))
(check-sat)
; query 7: function core_list_mergesort, block 7, name %8
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.021_32 () (_ BitVec 32))
(assert
 (let (($x65 (and (distinct (bvadd ((_ sign_extend 1) in.021_32) ((_ sign_extend 1) (_ bv1 32))) ((_ sign_extend 1) (bvadd in.021_32 (_ bv1 32)))) true)))
(let (($x365 (or false false (or $x65))))
(and (not $x365) (or $x365 (and (distinct (bvadd in.021_32 (_ bv1 32)) (bvadd in.021_32 (_ bv1 32))) true))))))
(check-sat)
; query 8: function core_state_transition, block 8, name %9
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.0_32 () (_ BitVec 32))
(assert
 (let ((?x636 (ite (and (distinct (_ bv1 32) in.0_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x22 (or false false false)))
(let (($x382 (not $x22)))
(and $x382 (or $x22 (and (distinct ?x636 ?x636) true)))))))
(check-sat)
; query 9: function get_seed_args, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_32 () (_ BitVec 32))
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let ((?x49 (ite (bvsgt in1_32 in0_32) (_ bv1 1) (_ bv0 1))))
(let (($x22 (or false false false)))
(let (($x382 (not $x22)))
(and $x382 (or $x22 (and (distinct ?x49 ?x49) true)))))))
(check-sat)
; query 10: function matrix_sum, block 18, name %19
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let (($x502 (or false false)))
(and (not $x502) (or $x502 (and (distinct ((_ sign_extend 16) in.1_16) ((_ sign_extend 16) in.1_16)) true)))))
(check-sat)
; query 11: function matrix_sum, block 18, name %20
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x712 ((_ sign_extend 16) in.1_16)))
(let ((?x441 (bvadd ?x712 (_ bv10 32))))
(let (($x51 (and (distinct (bvadd ((_ sign_extend 1) ?x712) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x441)) true)))
(let (($x502 (or false false)))
(let (($x85 (or $x502 false (or $x51))))
(and (not $x85) (or $x85 (and (distinct ?x441 ?x441) true)))))))))
(check-sat)
; query 12: function matrix_sum, block 18, name %21
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in.1_16 () (_ BitVec 16))
(assert
 (let ((?x712 ((_ sign_extend 16) in.1_16)))
(let ((?x441 (bvadd ?x712 (_ bv10 32))))
(let ((?x7 ((_ extract 15 0) ?x441)))
(let (($x51 (and (distinct (bvadd ((_ sign_extend 1) ?x712) ((_ sign_extend 1) (_ bv10 32))) ((_ sign_extend 1) ?x441)) true)))
(let (($x502 (or false false)))
(let (($x85 (or $x502 false (or $x51))))
(let (($x172 (or $x85 false)))
(and (not $x172) (or $x172 (and (distinct ?x7 ?x7) true)))))))))))
(check-sat)
