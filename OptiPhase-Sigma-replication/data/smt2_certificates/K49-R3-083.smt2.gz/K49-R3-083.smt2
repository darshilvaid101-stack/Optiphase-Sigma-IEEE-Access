; OptiPhase-Sigma refinement certificate for sweep K49-R3-083
; query 0: function gsm_L_add, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let (($x120 (and (distinct (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv18446744073709551615 64) in1_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x60 (or false false false)))
(let (($x10 (not $x60)))
(and $x10 (or $x60 $x120))))))
(check-sat)
; query 1: function gsm_L_add, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x53 (and (distinct (bvadd ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvadd in0_64 in1_64))) true)))
(let (($x44 (or false false (or $x53))))
(let (($x164 (or $x44 (and (distinct (bvadd in0_64 in1_64) (bvadd in0_64 in1_64)) true))))
(and (not $x44) $x164)))))
(check-sat)
; query 2: function gsm_L_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let ((?x192 (ite (bvsgt (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1))))
(let (($x60 (or false false false)))
(let (($x10 (not $x60)))
(and $x10 (or $x60 (and (distinct ?x192 ?x192) true)))))))
(check-sat)
; query 3: function gsm_L_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x149 (and (distinct (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv31 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x60 (or false false false)))
(let (($x10 (not $x60)))
(and $x10 (or $x60 $x149))))))
(check-sat)
; query 4: function gsm_L_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x149 (and (distinct (ite (bvsle (_ bv32 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv31 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x60 (or false false false)))
(let (($x10 (not $x60)))
(and $x10 (or $x60 $x149))))))
(check-sat)
; query 5: function gsm_L_sub, block 4, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(assert
 (let (($x120 (and (distinct (ite (bvsle (_ bv0 64) in1_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv18446744073709551615 64) in1_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x60 (or false false false)))
(let (($x10 (not $x60)))
(and $x10 (or $x60 $x120))))))
(check-sat)
; query 6: function gsm_L_sub, block 6, name %7
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_64 () (_ BitVec 64))
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x347 (and (distinct (bvsub ((_ sign_extend 1) in0_64) ((_ sign_extend 1) in1_64)) ((_ sign_extend 1) (bvsub in0_64 in1_64))) true)))
(let (($x79 (or false false (or $x347))))
(let (($x104 (or $x79 (and (distinct (bvsub in0_64 in1_64) (bvsub in0_64 in1_64)) true))))
(and (not $x79) $x104)))))
(check-sat)
; query 7: function gsm_L_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_64 () (_ BitVec 64))
(assert
 (let (($x20 (and (distinct (ite (bvsle (_ bv0 64) in0_64) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv18446744073709551615 64) in0_64) (_ bv1 1) (_ bv0 1))) true)))
(let (($x60 (or false false false)))
(let (($x10 (not $x60)))
(and $x10 (or $x60 $x20))))))
(check-sat)
; query 8: function gsm_add, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x180 (or false false)))
(let (($x28 (not $x180)))
(and $x28 (or $x180 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 9: function gsm_add, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x180 (or false false)))
(let (($x28 (not $x180)))
(and $x28 (or $x180 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 10: function gsm_add, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x165 ((_ sign_extend 48) in1_16)))
(let ((?x134 ((_ sign_extend 48) in0_16)))
(let ((?x188 (bvadd ?x134 ?x165)))
(let (($x56 (and (distinct (bvadd ((_ sign_extend 1) ?x134) ((_ sign_extend 1) ?x165)) ((_ sign_extend 1) ?x188)) true)))
(let (($x180 (or false false)))
(let (($x169 (or $x180 $x180 (or $x56))))
(and (not $x169) (or $x169 (and (distinct ?x188 ?x188) true))))))))))
(check-sat)
; query 11: function gsm_add, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x199 (ite (bvsgt (_ bv18446744073709518848 64) (bvadd ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x165 ((_ sign_extend 48) in1_16)))
(let ((?x45 ((_ sign_extend 1) ?x165)))
(let ((?x134 ((_ sign_extend 48) in0_16)))
(let ((?x166 ((_ sign_extend 1) ?x134)))
(let (($x180 (or false false)))
(let (($x169 (or $x180 $x180 (or (and (distinct (bvadd ?x166 ?x45) ((_ sign_extend 1) (bvadd ?x134 ?x165))) true)))))
(let (($x1084 (or $x169 false false)))
(and (not $x1084) (or $x1084 (and (distinct ?x199 ?x199) true))))))))))))
(check-sat)
; query 12: function gsm_asl, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x117 (and (distinct (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv15 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x60 (or false false false)))
(let (($x10 (not $x60)))
(and $x10 (or $x60 $x117))))))
(check-sat)
; query 13: function gsm_asr, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_32 () (_ BitVec 32))
(assert
 (let (($x117 (and (distinct (ite (bvsle (_ bv16 32) in1_32) (_ bv1 1) (_ bv0 1)) (ite (bvslt (_ bv15 32) in1_32) (_ bv1 1) (_ bv0 1))) true)))
(let (($x60 (or false false false)))
(let (($x10 (not $x60)))
(and $x10 (or $x60 $x117))))))
(check-sat)
; query 14: function gsm_sub, block entry, name %3
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let (($x180 (or false false)))
(let (($x28 (not $x180)))
(and $x28 (or $x180 (and (distinct ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in0_16)) true))))))
(check-sat)
; query 15: function gsm_sub, block entry, name %4
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(assert
 (let (($x180 (or false false)))
(let (($x28 (not $x180)))
(and $x28 (or $x180 (and (distinct ((_ sign_extend 48) in1_16) ((_ sign_extend 48) in1_16)) true))))))
(check-sat)
; query 16: function gsm_sub, block entry, name %5
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x165 ((_ sign_extend 48) in1_16)))
(let ((?x134 ((_ sign_extend 48) in0_16)))
(let ((?x86 (bvsub ?x134 ?x165)))
(let (($x109 (and (distinct (bvsub ((_ sign_extend 1) ?x134) ((_ sign_extend 1) ?x165)) ((_ sign_extend 1) ?x86)) true)))
(let (($x180 (or false false)))
(let (($x11 (or $x180 $x180 (or $x109))))
(and (not $x11) (or $x11 (and (distinct ?x86 ?x86) true))))))))))
(check-sat)
; query 17: function gsm_sub, block entry, name %6
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in1_16 () (_ BitVec 16))
(declare-fun in0_16 () (_ BitVec 16))
(assert
 (let ((?x161 (ite (bvsgt (_ bv18446744073709518848 64) (bvsub ((_ sign_extend 48) in0_16) ((_ sign_extend 48) in1_16))) (_ bv1 1) (_ bv0 1))))
(let ((?x165 ((_ sign_extend 48) in1_16)))
(let ((?x45 ((_ sign_extend 1) ?x165)))
(let ((?x134 ((_ sign_extend 48) in0_16)))
(let ((?x166 ((_ sign_extend 1) ?x134)))
(let (($x180 (or false false)))
(let (($x11 (or $x180 $x180 (or (and (distinct (bvsub ?x166 ?x45) ((_ sign_extend 1) (bvsub ?x134 ?x165))) true)))))
(let (($x125 (or $x11 false false)))
(and (not $x125) (or $x125 (and (distinct ?x161 ?x161) true))))))))))))
(check-sat)
