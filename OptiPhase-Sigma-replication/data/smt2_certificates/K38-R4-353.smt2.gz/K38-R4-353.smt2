; OptiPhase-Sigma refinement certificate for sweep K38-R4-353
