; OptiPhase-Sigma refinement certificate for sweep K19-R3-246
; query 0: function xmalloc, block 10, name %11
(reset)
; benchmark generated from python API
(set-info :status unknown)
(declare-fun in7_32 () (_ BitVec 32))
(assert
 (let ((?x492 (ite (and (distinct (_ bv0 32) in7_32) true) (_ bv1 1) (_ bv0 1))))
(let (($x566 (or false false false)))
(and (not $x566) (or $x566 (and (distinct ?x492 ?x492) true))))))
(check-sat)
